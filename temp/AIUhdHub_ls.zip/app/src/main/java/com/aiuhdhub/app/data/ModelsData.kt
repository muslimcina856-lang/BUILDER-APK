package com.aiuhdhub.app.data

data class DownloadableModel(
    val id: String,
    val name: String,
    val type: String,
    val size: String,
    val description: String,
    val downloadUrl: String,
    val filename: String,
    val engineType: String = "TFLite / GPU",
    val compatibility: String = "Sangat Baik (GPU)"
)

object ModelsRepository {
    fun getDownloadableModels(): List<DownloadableModel> = listOf(
        DownloadableModel(
            id = "realesrgan_photo_pro",
            name = "Real-ESRGAN UHD Photo (PRO - Full)",
            type = "Super Resolution (Asli/FP32)",
            size = "67.2 MB",
            description = "Model penuh tanpa mampatan (FP32) terus dari TFHub. Menghasilkan perincian visual UHD yang paling segar, tajam, dan asli tanpa kehilangan ketepatan data.",
            downloadUrl = "https://tfhub.dev/captain-pool/esrgan-tf2/1?lite=tflite",
            filename = "realesrgan_photo_pro.tflite",
            engineType = "TFLite / GPU",
            compatibility = "Memerlukan Peranti Tinggi"
        ),
        DownloadableModel(
            id = "realesrgan_photo_lite",
            name = "Real-ESRGAN UHD Photo (LITE)",
            type = "Super Resolution (Mampat/FP16)",
            size = "7.8 MB",
            description = "Model versi mampat (FP16/INT8) untuk peranti mudah alih. Dioptimumkan untuk kelajuan tinggi, penjimatan bateri, dan penggunaan RAM rendah.",
            downloadUrl = "https://github.com/tensorflow/examples/raw/master/lite/examples/super_resolution/android/app/src/main/assets/esrgan.tflite",
            filename = "realesrgan_photo_lite.tflite",
            engineType = "TFLite / GPU",
            compatibility = "Semua Peranti (Sangat Pantas)"
        ),
        DownloadableModel(
            id = "waifu2x_anime",
            name = "Waifu2x Anime Ultra",
            type = "Super Resolution (Anime)",
            size = "4.2 MB",
            description = "Model khusus untuk ilustrasi anime dan seni lukisan digital. Mengurangkan artifak JPEG dan melicinkan garisan luar objek.",
            downloadUrl = "https://github.com/nihui/realcugan-ncnn-vulkan/releases/download/v0.1.0/realcugan-v0.1.0.zip",
            filename = "waifu2x_anime.bin",
            engineType = "NCNN / GPU",
            compatibility = "Sederhana (GPU)"
        ),
        DownloadableModel(
            id = "realcugan_restoration",
            name = "RealCUGAN Restoration",
            type = "Super Resolution (Ilustrasi)",
            size = "5.1 MB",
            description = "Model pemulihan ilustrasi berkualiti tinggi dengan denoising pelbagai peringkat untuk membaiki imej lama ke UHD.",
            downloadUrl = "https://github.com/xinntao/Real-ESRGAN-ncnn-vulkan/releases/download/v0.2.0/realesrgan-ncnn-vulkan-v0.2.0.zip",
            filename = "realcugan_model.param",
            engineType = "NCNN / GPU",
            compatibility = "Sederhana (GPU)"
        )
    )
}
