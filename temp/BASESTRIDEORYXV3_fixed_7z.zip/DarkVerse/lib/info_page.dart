import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = const Color(0xFF6C63FF);
  String apiStatusText = "CHECKING...";
  Timer? _pingTimer;

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  // ============ XENORA GLASSMORPHISM PALETTE ============
  static const Color _bgPrimary = Color(0xFF0A0E17);
  static const Color _bgSecondary = Color(0xFF141B2B);
  static const Color _glassBg = Color(0x33FFFFFF);
  static const Color _glassBorder = Color(0x4DFFFFFF);
  static const Color _glassBorderLight = Color(0x1AFFFFFF);
  static const Color _cardBg = Color(0x1AFFFFFF);
  static const Color _accent = Color(0xFF6C63FF);
  static const Color _accentGlow = Color(0xFF8B83FF);
  static const Color _accentPink = Color(0xFFFF6B9D);
  static const Color _textPrimary = Color(0xFFF0F4FF);
  static const Color _textSecondary = Color(0xFF8892B0);
  static const Color _textMuted = Color(0xFF4A5578);
  static const Color _borderColor = Color(0xFF2A3550);

  final List<Map<String, dynamic>> rulesList = [
    {
      "title": "NO ACCOUNT BARTERING",
      "icon": Icons.swap_horizontal_circle_outlined,
      "desc": "Akun eksklusif XENORA PROJECT tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau.",
    },
    {
      "title": "STRICTLY PERSONAL USE",
      "icon": Icons.person_off_outlined,
      "desc": "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID).",
    },
    {
      "title": "RESELLING PROHIBITED",
      "icon": Icons.money_off_csred_outlined,
      "desc": "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller).",
    },
    {
      "title": "ILLEGAL DURATION SALES",
      "icon": Icons.timer_off_outlined,
      "desc": "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi.",
    },
    {
      "title": "PRICE DUMPING BAN",
      "icon": Icons.trending_down_rounded,
      "desc": "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami.",
    },
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.15, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _glowController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      await http
          .get(Uri.parse(
              'http://muzz.pterocloud.my.id:10912/getServerInfo?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 5));
      if (mounted) setState(() => isLoading = false);
    } catch (_) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http
          .get(Uri.parse(
              'http://muzz.pterocloud.my.id:10912/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final duration = DateTime.now().difference(start).inMilliseconds;

      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = _accent;
          } else if (duration < 500) {
            apiStatusColor = _accent.withOpacity(0.7);
          } else {
            apiStatusColor = _accent.withOpacity(0.5);
          }
          apiStatusText = "SYS.ONLINE :: ${duration}ms";
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          isApiOnline = false;
          apiPingMs = 0;
          apiStatusColor = _textMuted;
          apiStatusText = "SYS.OFFLINE :: DEST";
        });
      }
    }
  }

  Widget _buildLoadingScreen() {
    return Scaffold(
      backgroundColor: _bgPrimary,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _pulseAnimation,
              builder: (context, child) {
                return Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _accent.withOpacity(
                          0.3 + _pulseAnimation.value * 0.7),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _accent
                            .withOpacity(_pulseAnimation.value * 0.4),
                        blurRadius: 30,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: _accent,
                      backgroundColor: Colors.transparent,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 24),
            Text(
              "AUTHENTICATING",
              style: TextStyle(
                color: _accent.withOpacity(0.6),
                fontWeight: FontWeight.w700,
                fontSize: 11,
                letterSpacing: 4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusHeader() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return Container(
          margin: const EdgeInsets.only(bottom: 28),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          decoration: BoxDecoration(
            color: _glassBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: apiStatusColor.withOpacity(0.3 + _glowAnimation.value * 0.3),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: apiStatusColor.withOpacity(_glowAnimation.value * 0.08),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: apiStatusColor,
                  boxShadow: [
                    BoxShadow(
                      color: apiStatusColor
                          .withOpacity(_glowAnimation.value * 0.8),
                      blurRadius: 12,
                      spreadRadius: 3,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  apiStatusText,
                  style: TextStyle(
                    color: apiStatusColor == _textMuted
                        ? _textSecondary
                        : apiStatusColor,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    letterSpacing: 2.5,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _glassBg,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: _glassBorderLight, width: 0.5),
                ),
                child: Icon(Icons.memory,
                    color: _textMuted.withOpacity(0.4), size: 16),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18, top: 4),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 16,
            decoration: BoxDecoration(
              color: _accent,
              borderRadius: BorderRadius.circular(2),
              boxShadow: [
                BoxShadow(
                  color: _accent.withOpacity(0.4),
                  blurRadius: 6,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            title,
            style: TextStyle(
              color: _textMuted,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRuleCard(int index, Map<String, dynamic> rule) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: _glassBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _glassBorderLight, width: 0.8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () {},
          splashColor: _accent.withOpacity(0.05),
          highlightColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: _glassBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: _glassBorderLight, width: 0.8),
                  ),
                  child: Center(
                    child: Icon(rule['icon'], color: _accent, size: 20),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            "0${index + 1}",
                            style: TextStyle(
                              color: _textMuted.withOpacity(0.4),
                              fontWeight: FontWeight.w900,
                              fontSize: 10,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              rule['title'],
                              style: TextStyle(
                                color: _textPrimary,
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        rule['desc'],
                        style: TextStyle(
                          color: _textSecondary,
                          fontSize: 12,
                          height: 1.6,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPenaltyBox() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, _) {
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(top: 16, bottom: 32),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _accent.withOpacity(0.08 + _pulseAnimation.value * 0.08),
                _bgSecondary,
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: _accent
                  .withOpacity(0.3 + _pulseAnimation.value * 0.25),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: _accent
                    .withOpacity(_pulseAnimation.value * 0.08),
                blurRadius: 40,
                spreadRadius: 4,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                      color: _accent.withOpacity(0.3),
                      width: 0.5),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.warning_amber_rounded,
                        color: _accentPink, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      "VIOLATION PENALTY",
                      style: TextStyle(
                        color: _accentPink,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Text(
                "Jika pengguna terdeteksi melanggar salah satu protokol kerahasiaan & aturan di atas secara sengaja:",
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 12,
                  height: 1.6,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: _accentPink.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      color: _accentPink.withOpacity(0.3),
                      width: 1),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.delete_forever_rounded,
                        color: _accentPink, size: 20),
                    const SizedBox(width: 10),
                    Text(
                      "AKUN DIHAPUS PERMANEN",
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "TIDAK ADA PENGEMBALIAN SALDO ATAU KOMPENSASI.",
                style: TextStyle(
                  color: _textMuted,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _glassBg,
            border: Border.all(
                color: _glassBorderLight, width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 10,
              ),
            ],
          ),
          child: Center(
            child: Icon(Icons.shield_moon_rounded,
                color: _accent, size: 24),
          ),
        ),
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            "Peraturan ini dibuat semata-mata untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem server XENORA PROJECT. Dengan mengakses aplikasi, Anda secara otomatis menyetujui seluruh protokol di atas.",
            style: TextStyle(
              color: _textMuted,
              fontSize: 11,
              fontStyle: FontStyle.italic,
              height: 1.7,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 24),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 30,
              height: 1,
              decoration: BoxDecoration(
                color: _glassBorderLight,
                borderRadius: BorderRadius.circular(1),
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                color: _accent,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _accent.withOpacity(0.5),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 30,
              height: 1,
              decoration: BoxDecoration(
                color: _glassBorderLight,
                borderRadius: BorderRadius.circular(1),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          "XENORA PROJECT © ${DateTime.now().year}",
          style: TextStyle(
            color: _textMuted,
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 3,
          ),
        ),
        const SizedBox(height: 40),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return _buildLoadingScreen();

    return Scaffold(
      backgroundColor: _bgPrimary,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverAppBar(
              backgroundColor: _bgSecondary.withOpacity(0.9),
              elevation: 0,
              pinned: true,
              automaticallyImplyLeading: false,
              expandedHeight: 70,
              flexibleSpace: FlexibleSpaceBar(
                titlePadding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                title: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: _accent,
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: [
                          BoxShadow(
                            color: _accent.withOpacity(0.5),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      "EULA & SYSTEM INFO",
                      style: TextStyle(
                        color: _textPrimary,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.0,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                centerTitle: false,
              ),
              bottom: PreferredSize(
                preferredSize: const Size.fromHeight(1),
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        _accent.withOpacity(0.3),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  _buildStatusHeader(),
                  _buildSectionTitle("USER PROTOCOLS"),
                  ...rulesList.asMap().entries
                      .map((e) => _buildRuleCard(e.key, e.value))
                      .toList(),
                  _buildPenaltyBox(),
                  _buildFooter(),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}