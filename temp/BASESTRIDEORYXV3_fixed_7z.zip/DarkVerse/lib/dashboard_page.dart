// ============================================================
// NAME : XENORA
// BASE : http://muzz.pterocloud.my.id:10912
// WS   : ws://muzz.pterocloud.my.id:10912
// ============================================================

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as dart_ui;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

import 'login_page.dart';
import 'home_page.dart';
import 'info_page.dart';
import 'tools_gateway.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'owner_page.dart';
import 'riwayat_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  int onlineUsers = 0;
  int activeConnections = 0;

  late PageController _newsPageController;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;

  // ============ XENORA PALETTE ============
  static const Color _bgPrimary = Color(0xFF0A0E17);
  static const Color _bgSecondary = Color(0xFF141B2B);
  static const Color _bgCard = Color(0xFF1A2335);
  static const Color _bgCardLight = Color(0xFF222D45);
  static const Color _accent = Color(0xFF6C63FF);
  static const Color _accentGlow = Color(0xFF8B83FF);
  static const Color _accentSecondary = Color(0xFFFF6B9D);
  static const Color _textPrimary = Color(0xFFF0F4FF);
  static const Color _textSecondary = Color(0xFF8892B0);
  static const Color _textMuted = Color(0xFF4A5578);
  static const Color _borderColor = Color(0xFF2A3550);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _initNewsBanner();
    _selectedPage = _buildNewsPage();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _controller.forward();

    _initAndroidIdAndConnect();
    _loadProfileImage();
  }

  @override
  void dispose() {
    _newsTimer?.cancel();
    _newsPageController.dispose();
    _controller.dispose();
    channel.sink.close(status.goingAway);
    super.dispose();
  }

  void _initNewsBanner() {
    _newsPageController = PageController(initialPage: 0, viewportFraction: 0.92);
    _newsPageController.addListener(() {
      if (_newsPageController.hasClients && _newsPageController.page != null) {
        _currentNewsPage = _newsPageController.page!;
      }
    });
    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (Timer timer) {
        if (_newsPageController.hasClients) {
          int targetIndex = (_currentNewsPage + 1).round() % newsList.length;
          _newsPageController.animateToPage(targetIndex,
              duration: const Duration(milliseconds: 800), curve: Curves.easeInOut);
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() { _profileImage = File(imagePath); });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(Uri.parse('ws://muzz.pterocloud.my.id:10912'));
      channel.sink.add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
      channel.sink.add(jsonEncode({"type": "stats"}));
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          String message = data['reason'] == 'androidIdMismatch'
              ? "Your account has logged on another device."
              : "Key is not valid. Please login again.";
          _handleInvalidSession(message);
        }
        if (data['type'] == 'stats') {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }, onError: (error) {
        debugPrint('WebSocket error: $error');
      });
    } catch (e) {
      debugPrint('Failed to connect WebSocket: $e');
    }
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withValues(alpha: 0.7),
      builder: (_) => AlertDialog(
        backgroundColor: _bgCard,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: _accent.withValues(alpha: 0.3))),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: _accentSecondary, size: 24),
            const SizedBox(width: 12),
            const Text("Session Expired", style: TextStyle(color: _textPrimary, fontWeight: FontWeight.bold, fontSize: 16))
          ],
        ),
        content: Text(message, style: TextStyle(color: _textSecondary, fontSize: 13, height: 1.5)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false),
            child: Text("OK", style: TextStyle(color: _accent, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    if (index == 1) { _showWhatsAppMenu(); return; }
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) _selectedPage = _buildNewsPage();
      else if (index == 2) _selectedPage = InfoPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
    });
  }

  void _showWhatsAppMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          decoration: BoxDecoration(
            color: _bgSecondary,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border(top: BorderSide(color: _borderColor.withValues(alpha: 0.5))),
          ),
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 24),
                decoration: BoxDecoration(
                  color: _textMuted,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _accent.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(FontAwesomeIcons.whatsapp, color: _accent, size: 20),
                  ),
                  const SizedBox(width: 14),
                  const Text("WHATSAPP TOOLS", 
                    style: TextStyle(color: _textPrimary, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.2),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _buildSheetItem(
                icon: Icons.bug_report_rounded,
                iconColor: _accent,
                iconBg: _bgCard,
                title: "WhatsApp Crash",
                subtitle: "Send payloads & crash codes",
                onTap: () {
                  Navigator.pop(context);
                  setState(() { 
                    _bottomNavIndex = 1; 
                    _selectedPage = HomePage(
                      username: username,
                      password: password,
                      listBug: listBug,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    );
                  });
                }
              ),
              const SizedBox(height: 8),
              Divider(color: _borderColor, height: 24),
              _buildSheetItem(
                icon: Icons.devices_rounded,
                iconColor: _accentSecondary,
                iconBg: _bgCard,
                title: "Manage Sender",
                subtitle: "Pair devices & manage sessions",
                onTap: () {
                  Navigator.pop(context);
Navigator.push(context, MaterialPageRoute(builder: (_) => SenderPage(
                    sessionKey: sessionKey,
                  )));
                }
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSheetItem({
    required IconData icon,
    required Color iconColor,
    required Color iconBg,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: _bgCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _borderColor),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: iconBg.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: iconColor, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(color: _textPrimary, fontWeight: FontWeight.w600, fontSize: 15)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: TextStyle(color: _textSecondary, fontSize: 12)),
                  ]
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: _textMuted, size: 14),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: _bgPrimary,
        drawer: _buildCustomDrawer(),
        body: _selectedPage,
        bottomNavigationBar: _buildBottomNav(),
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      height: 72,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: _bgSecondary,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _borderColor.withValues(alpha: 0.6)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: _accent.withValues(alpha: 0.05),
            blurRadius: 30,
            offset: const Offset(0, 0),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildNavIcon(index: 0, icon: Icons.home_filled),
          _buildNavIcon(index: 1, icon: FontAwesomeIcons.whatsapp),
          _buildNavIcon(index: 2, icon: Icons.notifications_none_rounded),
          _buildNavIcon(index: 3, icon: Icons.build_outlined),
        ],
      ),
    );
  }

  Widget _buildNavIcon({required int index, required IconData icon}) {
    final bool isActive = _bottomNavIndex == index;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _onBottomNavTapped(index),
        splashColor: _accent.withValues(alpha: 0.1),
        highlightColor: Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isActive ? _accent.withValues(alpha: 0.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            border: isActive ? Border.all(color: _accent.withValues(alpha: 0.2)) : null,
          ),
          child: Icon(
            icon,
            size: 24,
            color: isActive ? _accent : _textMuted,
          ),
        ),
      ),
    );
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(height: MediaQuery.of(context).padding.top + 8),

          // ═══════════════════════════════════════════════════════
          //  HEADER - XENORA
          // ═══════════════════════════════════════════════════════
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: Icon(Icons.menu, color: _textPrimary, size: 26),
                  onPressed: () => _scaffoldKey.currentState?.openDrawer(),
                ),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: _accent,
                        borderRadius: BorderRadius.circular(4),
                        boxShadow: [
                          BoxShadow(color: _accent, blurRadius: 12, spreadRadius: 2),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      "XENORA",
                      style: TextStyle(
                        color: _textPrimary,
                        fontWeight: FontWeight.w700,
                        fontSize: 20,
                        letterSpacing: 2.0,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.headset_mic_outlined, color: _textSecondary, size: 24),
                      onPressed: () { 
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage())); 
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.account_circle_outlined, color: _textSecondary, size: 26),
                      onPressed: () { 
                        Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(
                          username: username,
                          password: password,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey
                        ))); 
                      },
                    ),
                  ],
                )
              ],
            ),
          ),
          const SizedBox(height: 20),

          // ═══════════════════════════════════════════════════════
          //  PROFILE CARD - GLASSMORPHISM
          // ═══════════════════════════════════════════════════════
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              width: double.infinity,
              height: 220,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _accent.withValues(alpha: 0.15), width: 1),
                boxShadow: [
                  BoxShadow(
                    color: _accent.withValues(alpha: 0.05),
                    blurRadius: 40,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(23),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    const _ProfileVideoBackground(
                      videoPath: 'assets/videos/bg_profile.mp4',
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.black.withValues(alpha: 0.6),
                            Colors.transparent,
                          ],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 24,
                      left: 20,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Welcome Back",
                            style: TextStyle(color: _textSecondary, fontSize: 12, letterSpacing: 1.0),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            "Hai, ${username.toUpperCase()}",
                            style: const TextStyle(
                              color: _textPrimary,
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      bottom: 20,
                      left: 20,
                      right: 20,
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.3),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _buildStatusItem(Icons.security, "Role", role.toUpperCase(), _accent),
                            _buildStatusItem(Icons.access_time, "Expired", expiredDate, _accentSecondary),
                            _buildStatusItem(Icons.people_outline, "Online", "$onlineUsers", _accentGlow),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 30),

          // ═══════════════════════════════════════════════════════
          //  COMMUNITY HUB
          // ═══════════════════════════════════════════════════════
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 3,
                      height: 18,
                      decoration: BoxDecoration(
                        color: _accent,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      "COMMUNITY HUB",
                      style: TextStyle(color: _textPrimary, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  "Stay connected with the XENORA community. Get real-time updates, access exclusive payloads, and participate in discussions.",
                  style: TextStyle(color: _textSecondary, fontSize: 13, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              height: 54,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_accent, _accentGlow],
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(color: _accent.withValues(alpha: 0.3), blurRadius: 20, offset: const Offset(0, 6)),
                ],
              ),
              child: TextButton.icon(
                icon: const Icon(FontAwesomeIcons.telegram, color: Colors.white, size: 20),
                label: const Text(
                  "Join Telegram Channel",
                  style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600),
                ),
                onPressed: () => _openUrl("https://t.me/trzvloid"),
              ),
            ),
          ),
          const SizedBox(height: 32),

          // ═══════════════════════════════════════════════════════
          //  LATEST UPDATES
          // ═══════════════════════════════════════════════════════
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 3,
                      height: 18,
                      decoration: BoxDecoration(
                        color: _accentSecondary,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      "LATEST UPDATES",
                      style: TextStyle(color: _textPrimary, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  "Keep yourself informed about recent system maintenance, newly added tools, and important announcements.",
                  style: TextStyle(color: _textSecondary, fontSize: 13, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          if (newsList.isNotEmpty)
            Container(
              width: double.infinity,
              height: 190,
              margin: const EdgeInsets.symmetric(horizontal: 12),
              child: Stack(
                children: [
                  PageView.builder(
                    controller: _newsPageController,
                    itemCount: newsList.length,
                    itemBuilder: (context, index) {
                      final item = newsList[index];
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          color: _bgCard,
                          border: Border.all(color: _borderColor),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.3),
                              blurRadius: 20,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (item['image'] != null && item['image'].toString().isNotEmpty) 
                                _NewsMedia(url: item['image']),
                              if (item['image'] == null) 
                                Container(
                                  color: _bgCard,
                                  child: Icon(Icons.newspaper_rounded, color: _textMuted, size: 50),
                                ),
                              Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.black.withValues(alpha: 0.8),
                                      Colors.transparent,
                                      Colors.transparent,
                                    ],
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                  )
                                ),
                              ),
                              Positioned(
                                bottom: 20,
                                left: 18,
                                right: 16,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: _accent.withValues(alpha: 0.2),
                                        borderRadius: BorderRadius.circular(6),
                                        border: Border.all(color: _accent.withValues(alpha: 0.3)),
                                      ),
                                      child: Text(
                                        "NEWS",
                                        style: TextStyle(
                                          color: _accent,
                                          fontSize: 9,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 1.5,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      item['title'] ?? 'No Title',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700,
                                        height: 1.2,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      item['desc'] ?? '',
                                      style: TextStyle(
                                        color: _textSecondary,
                                        fontSize: 12,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  Positioned(
                    bottom: 8,
                    left: 0,
                    right: 0,
                    child: AnimatedBuilder(
                      animation: _newsPageController,
                      builder: (context, child) {
                        double page = _newsPageController.hasClients && _newsPageController.page != null 
                          ? _newsPageController.page! 
                          : _currentNewsPage;
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(newsList.length, (index) {
                            double diff = (index - page).abs();
                            double width = diff < 1 ? 20.0 - (diff * 14.0) : 6.0;
                            double opacity = diff < 1 ? 1.0 - (diff * 0.5) : 0.2;
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              margin: const EdgeInsets.symmetric(horizontal: 3),
                              width: width,
                              height: 4,
                              decoration: BoxDecoration(
                                color: _accent.withValues(alpha: opacity),
                                borderRadius: BorderRadius.circular(4),
                              ),
                            );
                          }),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  Widget _buildStatusItem(IconData icon, String label, String value, Color color) {
    return Column(
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(color: _textSecondary, fontSize: 11, fontWeight: FontWeight.w500),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            color: _textPrimary,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  CUSTOM DRAWER - GLASSMORPHISM
  // ═══════════════════════════════════════════════════════════════
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: _bgPrimary,
      child: Container(
        decoration: BoxDecoration(
          border: Border(right: BorderSide(color: _borderColor.withValues(alpha: 0.5))),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(24, 50, 24, 28),
              decoration: BoxDecoration(
                color: _bgSecondary,
                border: Border(bottom: BorderSide(color: _borderColor.withValues(alpha: 0.3))),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _accent, width: 2),
                          boxShadow: [
                            BoxShadow(color: _accent.withValues(alpha: 0.2), blurRadius: 20),
                          ],
                        ),
                        child: ClipOval(
                          child: _profileImage != null 
                            ? Image.file(_profileImage!, fit: BoxFit.cover) 
                            : Container(
                              color: _bgCard,
                              child: Icon(Icons.person, size: 30, color: _textMuted),
                            ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              username,
                              style: const TextStyle(
                                color: _textPrimary,
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                              decoration: BoxDecoration(
                                color: _accent.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: _accent.withValues(alpha: 0.2)),
                              ),
                              child: Text(
                                role.toUpperCase(),
                                style: TextStyle(
                                  color: _accent,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.0,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 12),
                children: [
                  if (role == "owner") 
                    _buildDrawerMenuItem(
                      icon: Icons.workspace_premium,
                      label: "Owner Panel",
                      onTap: () { 
                        Navigator.pop(context); 
                        setState(() { 
                          _selectedPage = OwnerPage(sessionKey: sessionKey, username: username); 
                        }); 
                      },
                    ),
                  _buildDrawerMenuItem(
                    icon: Icons.history,
                    label: "Activity History",
                    onTap: () { 
                      Navigator.pop(context); 
                      Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role))); 
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.person_outline,
                    label: "My Profile",
                    onTap: () { 
                      Navigator.pop(context); 
                      Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(
                        username: username,
                        password: password,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey
                      ))); 
                    },
                  ),
                  const Divider(color: _borderColor, height: 24),
                  _buildDrawerMenuItem(
                    icon: Icons.contact_support_outlined,
                    label: "Contact Support",
                    onTap: () { 
                      Navigator.pop(context); 
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage())); 
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent.withValues(alpha: 0.15),
                  foregroundColor: Colors.redAccent,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: Colors.redAccent.withValues(alpha: 0.2)),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                onPressed: () async { 
                  final prefs = await SharedPreferences.getInstance(); 
                  await prefs.clear(); 
                  if (!mounted) return; 
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()), 
                    (route) => false
                  ); 
                },
                child: const Text(
                  "LOGOUT",
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: _textSecondary, size: 22),
      title: Text(label, style: TextStyle(color: _textPrimary, fontWeight: FontWeight.w500, fontSize: 14)),
      trailing: Icon(Icons.chevron_right, color: _textMuted, size: 20),
      onTap: onTap,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  VIDEO BACKGROUND
// ═══════════════════════════════════════════════════════════════
class _ProfileVideoBackground extends StatefulWidget {
  final String videoPath;
  const _ProfileVideoBackground({required this.videoPath});

  @override
  State<_ProfileVideoBackground> createState() => _ProfileVideoBackgroundState();
}

class _ProfileVideoBackgroundState extends State<_ProfileVideoBackground> {
  late VideoPlayerController _videoController;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.asset(widget.videoPath)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _isInitialized = true);
          _videoController.setVolume(0);
          _videoController.setLooping(true);
          _videoController.play();
        }
      }).catchError((e) {
        debugPrint("Video background error: $e");
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return Container(
        color: _DashboardPageState._bgCard,
        child: const Center(
          child: SizedBox(
            width: 24, height: 24,
            child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF6C63FF)),
          ),
        ),
      );
    }
    return FittedBox(
      fit: BoxFit.cover,
      child: SizedBox(
        width: _videoController.value.size.width,
        height: _videoController.value.size.height,
        child: VideoPlayer(_videoController),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  NEWS MEDIA
// ═══════════════════════════════════════════════════════════════
class _NewsMedia extends StatefulWidget {
  final String url;
  const _NewsMedia({required this.url});

  @override
  State<_NewsMedia> createState() => __NewsMediaState();
}

class __NewsMediaState extends State<_NewsMedia> {
  @override
  Widget build(BuildContext context) {
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return Container(
          color: _DashboardPageState._bgCard,
          child: const Center(
            child: SizedBox(
              width: 28, height: 28,
              child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF6C63FF)),
            ),
          ),
        );
      },
      errorBuilder: (_, __, ___) => Container(
        color: _DashboardPageState._bgCard,
        child: Icon(Icons.broken_image_rounded, color: _DashboardPageState._textMuted, size: 40),
      ),
    );
  }
}