import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'info_page.dart';
import 'tools_gateway.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'owner_page.dart';
import 'riwayat_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'XENORA',
      theme: _buildXenoraTheme(),
      initialRoute: '/login',
      onGenerateRoute: _onGenerateRoute,
    );
  }

  // ============ XENORA THEME ============
  ThemeData _buildXenoraTheme() {
    const Color primary = Color(0xFF6C63FF);
    const Color primaryGlow = Color(0xFF8B83FF);
    const Color secondary = Color(0xFFFF6B9D);
    const Color bgPrimary = Color(0xFF0A0E17);
    const Color bgSecondary = Color(0xFF141B2B);
    const Color bgCard = Color(0xFF1A2335);
    const Color textPrimary = Color(0xFFF0F4FF);
    const Color textSecondary = Color(0xFF8892B0);
    const Color textMuted = Color(0xFF4A5578);
    const Color borderColor = Color(0xFF2A3550);

    return ThemeData(
      brightness: Brightness.dark,
      fontFamily: 'ShareTechMono',
      
      // ============ COLORS ============
      scaffoldBackgroundColor: bgPrimary,
      colorScheme: const ColorScheme.dark().copyWith(
        primary: primary,
        secondary: secondary,
        background: bgPrimary,
        surface: bgSecondary,
        tertiary: primaryGlow,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onBackground: textPrimary,
        onSurface: textPrimary,
      ),
      primaryColor: primary,
      
      // ============ APP BAR ============
      appBarTheme: AppBarTheme(
        backgroundColor: bgSecondary.withOpacity(0.9),
        foregroundColor: textPrimary,
        elevation: 0,
        iconTheme: const IconThemeData(color: textPrimary),
        titleTextStyle: const TextStyle(
          color: textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.5,
        ),
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
        ),
      ),
      
      // ============ BUTTONS ============
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          textStyle: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1.2,
          ),
        ),
      ),
      
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primary,
          textStyle: const TextStyle(
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
        ),
      ),
      
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: textPrimary,
          side: BorderSide(color: borderColor),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
        ),
      ),
      
      // ============ INPUTS ============
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: bgCard,
        hintStyle: TextStyle(color: textMuted, fontSize: 14),
        labelStyle: TextStyle(color: textSecondary, fontSize: 13),
        border: OutlineInputBorder(
          borderSide: BorderSide(color: borderColor),
          borderRadius: BorderRadius.circular(14),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: borderColor),
          borderRadius: BorderRadius.circular(14),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: primary, width: 2),
          borderRadius: BorderRadius.circular(14),
        ),
        errorBorder: OutlineInputBorder(
          borderSide: BorderSide(color: secondary, width: 1.5),
          borderRadius: BorderRadius.circular(14),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      ),
      
      // ============ CARDS ============
      cardTheme: CardThemeData(
        color: bgCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: borderColor.withOpacity(0.5)),
        ),
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 0),
      ),
      
      // ============ DIALOGS ============
      dialogTheme: DialogThemeData(
        backgroundColor: bgSecondary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: borderColor),
        ),
        titleTextStyle: const TextStyle(
          color: textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
        contentTextStyle: TextStyle(
          color: textSecondary,
          fontSize: 14,
        ),
      ),
      
      // ============ SNACKBAR ============
      snackBarTheme: SnackBarThemeData(
        backgroundColor: bgCard,
        contentTextStyle: const TextStyle(color: textPrimary),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        behavior: SnackBarBehavior.floating,
        elevation: 8,
      ),
      
      // ============ BOTTOM SHEET ============
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: bgSecondary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        modalBackgroundColor: bgSecondary,
      ),
      
      // ============ DIVIDER ============
      dividerTheme: DividerThemeData(
        color: borderColor,
        thickness: 1,
        space: 0,
      ),
      
      // ============ LIST TILE ============
      listTileTheme: ListTileThemeData(
        textColor: textPrimary,
        iconColor: textSecondary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        tileColor: Colors.transparent,
      ),
      
      // ============ ICON ============
      iconTheme: IconThemeData(
        color: textSecondary,
        size: 24,
      ),
      
      // ============ FLOATING ACTION BUTTON ============
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        elevation: 8,
        shape: CircleBorder(),
      ),
      
      // ============ TAB BAR ============
      tabBarTheme: TabBarThemeData(
        labelColor: primary,
        unselectedLabelColor: textMuted,
        indicator: BoxDecoration(
          color: primary.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        labelStyle: const TextStyle(
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
        unselectedLabelStyle: TextStyle(
          fontWeight: FontWeight.w400,
          color: textMuted,
        ),
      ),
      
      // ============ POPUP MENU ============
      popupMenuTheme: PopupMenuThemeData(
        color: bgSecondary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: borderColor),
        ),
        textStyle: TextStyle(color: textPrimary),
      ),
      
      // ============ SWITCH ============
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return primary;
          return textMuted;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return primary.withOpacity(0.3);
          }
          return textMuted.withOpacity(0.3);
        }),
      ),
      
      // ============ CHECKBOX ============
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return primary;
          return Colors.transparent;
        }),
        side: BorderSide(color: borderColor),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
        ),
      ),
      
      // ============ RADIO ============
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return primary;
          return textMuted;
        }),
      ),
    );
  }

  // ============ ROUTE GENERATOR ============
  Route<dynamic> _onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/login':
        return MaterialPageRoute(builder: (_) => const LoginPage());

      case '/dashboard':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => DashboardPage(
            username: args['username'] ?? '',
            password: args['password'] ?? '',
            role: args['role'] ?? 'user',
            sessionKey: args['key'] ?? '',
            expiredDate: args['expiredDate'] ?? '',
            listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
            listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
            news: List<Map<String, dynamic>>.from(args['news'] ?? []),
          ),
        );

      case '/home':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => HomePage(
            username: args['username'] ?? '',
            password: args['password'] ?? '',
            listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
            role: args['role'] ?? 'user',
            expiredDate: args['expiredDate'] ?? '',
            sessionKey: args['sessionKey'] ?? '',
          ),
        );

      case '/info':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => InfoPage(
            sessionKey: args['sessionKey'] ?? '',
          ),
        );

      case '/tools':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => ToolsPage(
            sessionKey: args['sessionKey'] ?? '',
            userRole: args['role'] ?? 'user',
            listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
          ),
        );

      case '/partner':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => PartnerPage(
            sessionKey: args['sessionKey'] ?? '',
            username: args['username'] ?? '',
          ),
        );

      case '/moderator':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => ModeratorPage(
            sessionKey: args['sessionKey'] ?? '',
            username: args['username'] ?? '',
          ),
        );

      case '/seller':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
builder: (_) => SellerPage(
            keyToken: args['sessionKey'] ?? args['keyToken'] ?? '',
          ),
        );

      case '/admin':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
builder: (_) => AdminPage(
            sessionKey: args['sessionKey'] ?? '',
          ),
        );

      case '/bug_sender':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
builder: (_) => SenderPage(
            sessionKey: args['sessionKey'] ?? '',
          ),
        );

      case '/contact':
        return MaterialPageRoute(builder: (_) => const ContactPage());

      case '/profile':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => ProfilePage(
            username: args['username'] ?? '',
            password: args['password'] ?? '',
            role: args['role'] ?? 'user',
            expiredDate: args['expiredDate'] ?? '',
            sessionKey: args['sessionKey'] ?? '',
          ),
        );

      case '/owner':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => OwnerPage(
            sessionKey: args['sessionKey'] ?? '',
            username: args['username'] ?? '',
          ),
        );

      case '/riwayat':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => RiwayatPage(
            sessionKey: args['sessionKey'] ?? '',
            role: args['role'] ?? 'user',
          ),
        );

      default:
        return MaterialPageRoute(
builder: (routeContext) => Scaffold(
            backgroundColor: const Color(0xFF0A0E17),
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.error_outline_rounded,
                    color: const Color(0xFF6C63FF),
                    size: 60,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "404 - Page Not Found",
                    style: TextStyle(
                      color: const Color(0xFFF0F4FF),
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "The page you're looking for doesn't exist.",
                    style: TextStyle(
                      color: const Color(0xFF8892B0),
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamedAndRemoveUntil(
                        routeContext,
                        '/login',
                        (route) => false,
                      );
                    },
                    child: const Text("GO BACK TO LOGIN"),
                  ),
                ],
              ),
            ),
          ),
        );
    }
  }
}