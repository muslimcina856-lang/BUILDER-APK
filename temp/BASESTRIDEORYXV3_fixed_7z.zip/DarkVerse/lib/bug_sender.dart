import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ============================================================
// METALLIC PALETTE
// ============================================================
const Color kSilverLight = Color(0xFFE8E8EC);
const Color kSilver = Color(0xFFC5C5CB);
const Color kSilverMid = Color(0xFF9A9AA2);
const Color kSilverDark = Color(0xFF5A5A62);
const Color kGraphite = Color(0xFF2A2A30);
const Color kObsidian = Color(0xFF141418);
const Color kSuccess = Color(0xFF22E07A);
const Color kError = Color(0xFFFF6B6B);
const Color kInfo = Color(0xFF6BCBFF);
const Color kWarning = Color(0xFFFFB84D);

// ============================================================
// COMMON COUNTRY CODES (tanpa +)
// ============================================================
const List<MapEntry<String, String>> kCountryCodes = [
  MapEntry('62', '🇮🇩 Indonesia'),
  MapEntry('60', '🇲🇾 Malaysia'),
  MapEntry('65', '🇸🇬 Singapore'),
  MapEntry('66', '🇹🇭 Thailand'),
  MapEntry('63', '🇵🇭 Philippines'),
  MapEntry('84', '🇻🇳 Vietnam'),
  MapEntry('855', '🇰🇭 Cambodia'),
  MapEntry('856', '🇱🇦 Laos'),
  MapEntry('95', '🇲🇲 Myanmar'),
  MapEntry('670', '🇹🇱 Timor-Leste'),
  MapEntry('91', '🇮🇳 India'),
  MapEntry('880', '🇧🇩 Bangladesh'),
  MapEntry('977', '🇳🇵 Nepal'),
  MapEntry('92', '🇵🇰 Pakistan'),
  MapEntry('94', '🇱🇰 Sri Lanka'),
  MapEntry('960', '🇲🇻 Maldives'),
  MapEntry('1', '🇺🇸 USA / Canada'),
  MapEntry('44', '🇬🇧 UK'),
  MapEntry('49', '🇩🇪 Germany'),
  MapEntry('33', '🇫🇷 France'),
  MapEntry('34', '🇪🇸 Spain'),
  MapEntry('39', '🇮🇹 Italy'),
  MapEntry('31', '🇳🇱 Netherlands'),
  MapEntry('7', '🇷🇺 Russia'),
  MapEntry('86', '🇨🇳 China'),
  MapEntry('81', '🇯🇵 Japan'),
  MapEntry('82', '🇰🇷 South Korea'),
  MapEntry('61', '🇦🇺 Australia'),
  MapEntry('64', '🇳🇿 New Zealand'),
  MapEntry('27', '🇿🇦 South Africa'),
  MapEntry('20', '🇪🇬 Egypt'),
  MapEntry('55', '🇧🇷 Brazil'),
  MapEntry('52', '🇲🇽 Mexico'),
  MapEntry('54', '🇦🇷 Argentina'),
  MapEntry('966', '🇸🇦 Saudi Arabia'),
  MapEntry('971', '🇦🇪 UAE'),
  MapEntry('974', '🇶🇦 Qatar'),
  MapEntry('965', '🇰🇼 Kuwait'),
  MapEntry('968', '🇴🇲 Oman'),
  MapEntry('973', '🇧🇭 Bahrain'),
  MapEntry('962', '🇯🇴 Jordan'),
  MapEntry('961', '🇱🇧 Lebanon'),
  MapEntry('964', '🇮🇶 Iraq'),
  MapEntry('963', '🇸🇾 Syria'),
  MapEntry('90', '🇹🇷 Turkey'),
  MapEntry('972', '🇮🇱 Israel'),
  MapEntry('351', '🇵🇹 Portugal'),
  MapEntry('30', '🇬🇷 Greece'),
  MapEntry('48', '🇵🇱 Poland'),
  MapEntry('46', '🇸🇪 Sweden'),
  MapEntry('47', '🇳🇴 Norway'),
  MapEntry('45', '🇩🇰 Denmark'),
  MapEntry('358', '🇫🇮 Finland'),
  MapEntry('41', '🇨🇭 Switzerland'),
  MapEntry('43', '🇦🇹 Austria'),
  MapEntry('32', '🇧🇪 Belgium'),
  MapEntry('354', '🇮🇸 Iceland'),
  MapEntry('352', '🇱🇺 Luxembourg'),
  MapEntry('353', '🇮🇪 Ireland'),
  MapEntry('371', '🇱🇻 Latvia'),
  MapEntry('370', '🇱🇹 Lithuania'),
  MapEntry('372', '🇪🇪 Estonia'),
  MapEntry('421', '🇸🇰 Slovakia'),
  MapEntry('420', '🇨🇿 Czech Republic'),
  MapEntry('36', '🇭🇺 Hungary'),
  MapEntry('40', '🇷🇴 Romania'),
  MapEntry('359', '🇧🇬 Bulgaria'),
  MapEntry('385', '🇭🇷 Croatia'),
  MapEntry('381', '🇷🇸 Serbia'),
  MapEntry('387', '🇧🇦 Bosnia'),
  MapEntry('382', '🇲🇪 Montenegro'),
  MapEntry('389', '🇲🇰 North Macedonia'),
  MapEntry('355', '🇦🇱 Albania'),
  MapEntry('386', '🇸🇮 Slovenia'),
  MapEntry('590', '🇬🇵 Guadeloupe'),
  MapEntry('594', '🇬🇾 French Guiana'),
  MapEntry('596', '🇲🇶 Martinique'),
  MapEntry('509', '🇭🇹 Haiti'),
  MapEntry('809', '🇩🇴 Dominican Rep.'),
  MapEntry('53', '🇨🇺 Cuba'),
  MapEntry('57', '🇨🇴 Colombia'),
  MapEntry('56', '🇨🇱 Chile'),
  MapEntry('51', '🇵🇪 Peru'),
  MapEntry('591', '🇧🇴 Bolivia'),
  MapEntry('598', '🇺🇾 Uruguay'),
  MapEntry('595', '🇵🇾 Paraguay'),
  MapEntry('507', '🇵🇦 Panama'),
  MapEntry('504', '🇭🇳 Honduras'),
  MapEntry('503', '🇸🇻 El Salvador'),
  MapEntry('502', '🇬🇹 Guatemala'),
  MapEntry('505', '🇳🇮 Nicaragua'),
  MapEntry('506', '🇨🇷 Costa Rica'),
  MapEntry('880', '🇧🇩 Bangladesh'),
  MapEntry('254', '🇰🇪 Kenya'),
  MapEntry('255', '🇹🇿 Tanzania'),
  MapEntry('256', '🇺🇬 Uganda'),
  MapEntry('234', '🇳🇬 Nigeria'),
  MapEntry('233', '🇬🇭 Ghana'),
  MapEntry('225', '🇨🇮 Côte d\'Ivoire'),
  MapEntry('237', '🇨🇲 Cameroon'),
  MapEntry('243', '🇨🇩 DR Congo'),
  MapEntry('258', '🇲🇿 Mozambique'),
  MapEntry('260', '🇿🇲 Zambia'),
  MapEntry('263', '🇿🇼 Zimbabwe'),
  MapEntry('27', '🇿🇦 South Africa'),
  MapEntry('356', '🇲🇹 Malta'),
  MapEntry('377', '🇲🇨 Monaco'),
  MapEntry('376', '🇦🇩 Andorra'),
  MapEntry('378', '🇸🇲 San Marino'),
  MapEntry('379', '🇻🇦 Vatican'),
  MapEntry('675', '🇵🇬 Papua New Guinea'),
  MapEntry('678', '🇻🇺 Vanuatu'),
  MapEntry('679', '🇫🇯 Fiji'),
  MapEntry('685', '🇼🇸 Samoa'),
  MapEntry('676', '🇹🇴 Tonga'),
];

// ============================================================
// INPUT FORMATTER: Hapus + dan karakter non-digit
// ============================================================
class NoPlusFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final clean = newValue.text
        .replaceAll('+', '')
        .replaceAll(RegExp(r'[^\d]'), '');
    return TextEditingValue(
      text: clean,
      selection: TextSelection.collapsed(offset: clean.length),
    );
  }
}

// ============================================================
// SENDER PAGE
// ============================================================
class SenderPage extends StatefulWidget {
  final String sessionKey;

  const SenderPage({super.key, required this.sessionKey});

  @override
  State<SenderPage> createState() => _SenderPageState();
}

class _SenderPageState extends State<SenderPage> with TickerProviderStateMixin {
  Map<String, dynamic> connections = {"private": [], "global": []};
  bool isLoading = false;
  String _currentFilter = "all";
  String _userRole = '';
  Map<String, dynamic>? _usageInfo; // null = tidak restricted

  // --- Animation Controllers ---
  late final AnimationController _fadeController;
  late final AnimationController _shimmerController;
  late final AnimationController _pulseController;
  late final AnimationController _fabController;
  late final Animation<double> _fabAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    )..forward();

    _shimmerController = AnimationController(
      duration: const Duration(milliseconds: 2500),
      vsync: this,
    )..repeat();

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1600),
      vsync: this,
    )..repeat(reverse: true);

    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    _fabAnimation = Tween<double>(
      begin: 1.0,
      end: 1.15,
    ).animate(CurvedAnimation(parent: _fabController, curve: Curves.easeInOut));

    _fetchSenders();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _shimmerController.dispose();
    _pulseController.dispose();
    _fabController.dispose();
    super.dispose();
  }

  // ── API ──────────────────────────────────────────────────
  Future<void> _fetchSenders() async {
    if (isLoading) return;
    setState(() => isLoading = true);

    try {
      final res = await ApiService.getMySender(widget.sessionKey);
      if (res['valid'] == true) {
        setState(() {
          connections = res["connections"] ?? {"private": [], "global": []};
          _userRole = res['role']?.toString() ?? '';
          _usageInfo = res['usageInfo'] as Map<String, dynamic>?;
        });
      } else {
        _showToast(res['message'] ?? "Failed to fetch senders", isError: true);
      }
    } catch (_) {
      _showToast("Failed to fetch senders.", isError: true);
    }

    setState(() => isLoading = false);
  }

  // ── Toast ────────────────────────────────────────────────
  void _showToast(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError
                  ? Icons.error_outline_rounded
                  : Icons.check_circle_outline_rounded,
              color: kSilverLight,
              size: 18,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  fontFamily: "ShareTechMono",
                  fontSize: 12,
                  color: kSilverLight,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? const Color(0xFFB0185C) : kGraphite,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      ),
    );
  }

  // ── Filter Logic ─────────────────────────────────────────
  List<dynamic> _getFilteredSenders() {
    switch (_currentFilter) {
      case "private":
        return connections["private"] ?? [];
      case "global":
        return connections["global"] ?? [];
      default:
        return [
          ...connections["private"] ?? [],
          ...connections["global"] ?? [],
        ];
    }
  }

  int get _totalCount =>
      (connections["private"]?.length ?? 0) +
      (connections["global"]?.length ?? 0);

  // ── Phone Validation ─────────────────────────────────────
  /// Validasi: hanya digit, min 8 digit, tanpa +
  String? _validatePhone(String number) {
    if (number.isEmpty) return "Nomor tidak boleh kosong";
    if (number.contains('+'))
      return "Jangan pakai +, langsung kode negara (contoh: 62)";
    if (!RegExp(r'^\d+$').hasMatch(number))
      return "Hanya angka yang diperbolehkan";
    if (number.length < 8) return "Nomor terlalu pendek (min 8 digit)";
    if (number.startsWith('0'))
      return "Ganti awalan 0 dengan kode negara (contoh: 0812 → 62812)";
    return null;
  }

  /// Deteksi country code dari nomor
  String _detectCountry(String number) {
    for (final entry in kCountryCodes) {
      if (number.startsWith(entry.key)) {
        return entry.value;
      }
    }
    return '';
  }

  // ── Build ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kObsidian,
      floatingActionButton: _buildFab(),
      body: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),
          SafeArea(
            child: FadeTransition(
              opacity: _fadeController,
              child: Column(
                children: [
                  _buildHeader(),
                  _buildStatsBar(),
                  _buildFilterChips(),
                  const SizedBox(height: 8),
                  Expanded(
                    child: isLoading
                        ? const Center(
                            child: CircularProgressIndicator(
                              color: kSilverLight,
                              strokeWidth: 2,
                            ),
                          )
                        : _totalCount == 0
                        ? _buildEmptyState()
                        : _buildSenderList(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Header ───────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 12, 14, 16),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [
            kGraphite.withValues(alpha: 0.85),
            kObsidian.withValues(alpha: 0.95),
          ],
        ),
        border: Border.all(color: kSilver.withValues(alpha: 0.25), width: 1),
      ),
      child: Row(
        children: [
          // Back Button
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kSilverLight.withValues(alpha: 0.08),
                border: Border.all(color: kSilver.withValues(alpha: 0.4)),
              ),
              child: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: kSilverMid,
                size: 16,
              ),
            ),
          ),
          const SizedBox(width: 14),
          // Icon
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: const LinearGradient(
                colors: [kSilverLight, kSilver],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: kSilverLight.withValues(alpha: 0.25),
                  blurRadius: 12,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: const Icon(
              Icons.phone_android_rounded,
              color: kObsidian,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          // Title
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _shimmerText("MY SENDERS", size: 18),
                const SizedBox(height: 4),
                Text(
                  "DEVICE MANAGEMENT",
                  style: TextStyle(
                    color: kSilver.withValues(alpha: 0.6),
                    fontSize: 10,
                    fontFamily: "ShareTechMono",
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          // Refresh
          GestureDetector(
            onTap: _fetchSenders,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kSilverLight.withValues(alpha: 0.06),
                border: Border.all(color: kSilver.withValues(alpha: 0.3)),
              ),
              child: const Icon(
                Icons.refresh_rounded,
                color: kSilverMid,
                size: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Stats Bar ────────────────────────────────────────────
  Widget _buildStatsBar() {
    final priv = connections["private"]?.length ?? 0;
    final glob = connections["global"]?.length ?? 0;
    final isRestricted = ['member', 'reseller'].contains(_userRole);
    final usedToday = _usageInfo?['globalUsedToday'] as int? ?? 0;
    final maxToday = _usageInfo?['globalMaxToday'] as int? ?? 3;

    return Column(
      children: [
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 14),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: [
                kGraphite.withValues(alpha: 0.7),
                kObsidian.withValues(alpha: 0.85),
              ],
            ),
            border: Border.all(color: kSilverDark.withValues(alpha: 0.5), width: 1),
          ),
          child: Row(
            children: [
              Expanded(
                child: _statCell(
                  "PRIVATE",
                  "$priv",
                  Icons.shield_outlined,
                  kSilverLight,
                ),
              ),
              _statDivider(),
              Expanded(
                child: _statCell("GLOBAL", "$glob", Icons.public_rounded, kInfo),
              ),
              _statDivider(),
              Expanded(
                child: _statCell(
                  "TOTAL",
                  "${priv + glob}",
                  Icons.dns_outlined,
                  kSuccess,
                ),
              ),
            ],
          ),
        ),
        // ── Usage quota bar untuk member/reseller ──
        if (isRestricted) ...[
          const SizedBox(height: 8),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 14),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: kGraphite.withValues(alpha: 0.6),
              border: Border.all(
                color: usedToday >= maxToday
                    ? kError.withValues(alpha: 0.5)
                    : kWarning.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.bolt_rounded,
                  color: usedToday >= maxToday ? kError : kWarning,
                  size: 14,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    "Global Sender Usage Today",
                    style: TextStyle(
                      color: kSilver.withValues(alpha: 0.7),
                      fontSize: 10,
                      fontFamily: "ShareTechMono",
                      letterSpacing: 1,
                    ),
                  ),
                ),
                Text(
                  "$usedToday / $maxToday",
                  style: TextStyle(
                    color: usedToday >= maxToday ? kError : kWarning,
                    fontSize: 12,
                    fontFamily: "ShareTechMono",
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(width: 8),
                // Progress bar mini
                SizedBox(
                  width: 50,
                  height: 6,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: maxToday > 0 ? (usedToday / maxToday).clamp(0.0, 1.0) : 0,
                      backgroundColor: kSilverDark.withValues(alpha: 0.3),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        usedToday >= maxToday ? kError : kWarning,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _statCell(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 16,
            fontFamily: "ShareTechMono",
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: color.withValues(alpha: 0.6),
            fontSize: 8.5,
            fontFamily: "ShareTechMono",
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }

  Widget _statDivider() => Container(
    width: 1,
    height: 36,
    color: kSilverDark.withValues(alpha: 0.5),
  );

  // ── Filter Chips ─────────────────────────────────────────
  Widget _buildFilterChips() {
    final filters = ["ALL", "PRIVATE", "GLOBAL"];
    final vals = ["all", "private", "global"];

    return SizedBox(
      height: 40,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        itemCount: filters.length,
        itemBuilder: (_, i) {
          final sel = _currentFilter == vals[i];
          return GestureDetector(
            onTap: () => setState(() => _currentFilter = vals[i]),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 280),
              curve: Curves.easeOutCubic,
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: sel
                    ? const LinearGradient(colors: [kSilverLight, kSilver])
                    : null,
                color: sel ? null : kGraphite.withValues(alpha: 0.6),
                border: Border.all(
                  color: sel
                      ? Colors.white.withValues(alpha: 0.4)
                      : kSilverDark.withValues(alpha: 0.5),
                  width: 1,
                ),
                boxShadow: sel
                    ? [
                        BoxShadow(
                          color: kSilverLight.withValues(alpha: 0.3),
                          blurRadius: 10,
                        ),
                      ]
                    : null,
              ),
              child: Center(
                child: Text(
                  filters[i],
                  style: TextStyle(
                    color: sel ? kObsidian : kSilver.withValues(alpha: 0.8),
                    fontSize: 10.5,
                    fontWeight: FontWeight.w900,
                    fontFamily: "ShareTechMono",
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ── Empty State ──────────────────────────────────────────
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _pulseController,
              builder: (_, __) => Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: kSilverDark.withValues(alpha: 0.1),
                  border: Border.all(color: kSilverDark.withValues(alpha: 0.3)),
                  boxShadow: [
                    BoxShadow(
                      color: kSilverDark.withValues(
                        alpha: 0.1 + _pulseController.value * 0.2,
                      ),
                      blurRadius: 30,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.phonelink_erase_rounded,
                  color: kSilverDark,
                  size: 60,
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              "NO DEVICES FOUND",
              style: TextStyle(
                color: kSilverLight,
                fontSize: 18,
                fontFamily: "ShareTechMono",
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "Connect your first device to get started",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: kSilver.withValues(alpha: 0.6),
                fontSize: 12,
                fontFamily: "ShareTechMono",
              ),
            ),
            const SizedBox(height: 24),
            GestureDetector(
              onTap: _showAddSenderDialog,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 14,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: const LinearGradient(
                    colors: [kSilverLight, kSilver, kSilverMid],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: kSilverLight.withValues(alpha: 0.3),
                      blurRadius: 14,
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.add_circle_outline_rounded,
                      color: kObsidian,
                      size: 20,
                    ),
                    SizedBox(width: 8),
                    Text(
                      "ADD SENDER",
                      style: TextStyle(
                        color: kObsidian,
                        fontSize: 13,
                        fontFamily: "ShareTechMono",
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Sender List ──────────────────────────────────────────
  Widget _buildSenderList() {
    final filteredSenders = _getFilteredSenders();

    if (filteredSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.filter_list_off_rounded,
              color: kSilverDark.withValues(alpha: 0.6),
              size: 50,
            ),
            const SizedBox(height: 16),
            Text(
              "Empty in '${_currentFilter.toUpperCase()}'",
              style: TextStyle(
                color: kSilver.withValues(alpha: 0.7),
                fontSize: 14,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchSenders,
      color: kSilverLight,
      backgroundColor: kGraphite,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 100),
        itemCount: filteredSenders.length,
        physics: const BouncingScrollPhysics(),
        itemBuilder: (context, index) {
          final sender = filteredSenders[index];
          final isGlobal = sender['owner'] == "global";
          return _SenderCard(sender: sender, isGlobal: isGlobal);
        },
      ),
    );
  }

  // ── FAB ──────────────────────────────────────────────────
  Widget _buildFab() {
    return AnimatedBuilder(
      animation: _fabAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _fabAnimation.value,
          child: Container(
            margin: const EdgeInsets.only(bottom: 16, right: 16),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [kSilverLight, kSilver],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: kSilverLight.withValues(alpha: 0.4),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: FloatingActionButton(
              onPressed: () {
                _fabController.forward().then((_) => _fabController.reverse());
                _showAddSenderDialog();
              },
              backgroundColor: Colors.transparent,
              elevation: 0,
              child: const Icon(Icons.add_rounded, color: kObsidian, size: 30),
            ),
          ),
        );
      },
    );
  }

  // ── Shimmer Text ─────────────────────────────────────────
  Widget _shimmerText(String text, {double size = 16}) {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (_, __) {
        return ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            begin: Alignment(-1 + _shimmerController.value * 2, 0),
            end: Alignment(1 + _shimmerController.value * 2, 0),
            colors: const [
              kSilverDark,
              kSilverLight,
              Colors.white,
              kSilverLight,
              kSilverDark,
            ],
            stops: const [0.0, 0.35, 0.5, 0.65, 1.0],
          ).createShader(bounds),
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontSize: size,
              fontWeight: FontWeight.w900,
              fontFamily: "ShareTechMono",
              letterSpacing: 2,
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // DIALOGS
  // ============================================================

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();
    String detectedCountry = '';
    String? errorMsg;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return _buildModernDialog(
              title: "ADD NEW SENDER",
              icon: Icons.person_add_rounded,
              children: [
                // ── Tips Box ──
                _buildTipsBox(),
                const SizedBox(height: 16),
                // ── Phone Input ──
                _buildPhoneInput(
                  phoneController,
                  detectedCountry,
                  errorMsg,
                  onCountryDetected: (country) {
                    setDialogState(() => detectedCountry = country);
                  },
                  onErrorChanged: (error) {
                    setDialogState(() => errorMsg = error);
                  },
                ),
              ],
              onConfirm: () async {
                final number = phoneController.text.trim();
                final validation = _validatePhone(number);

                if (validation != null) {
                  setDialogState(() => errorMsg = validation);
                  return;
                }

                Navigator.pop(dialogContext);

                try {
                  final res = await ApiService.getPairing(
                    widget.sessionKey,
                    number,
                  );
                  if (res['valid'] == true) {
                    _showPairingCodeDialog(number, res['pairingCode']);
                    _fetchSenders();
                  } else {
                    _showToast(
                      "Failed: ${res['message'] ?? 'Unknown error'}",
                      isError: true,
                    );
                  }
                } catch (_) {
                  _showToast("An error occurred.", isError: true);
                }
              },
            );
          },
        );
      },
    );
  }

  // ── Tips Box ─────────────────────────────────────────────
  Widget _buildTipsBox() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: kWarning.withValues(alpha: 0.06),
        border: Border.all(color: kWarning.withValues(alpha: 0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.lightbulb_outline_rounded, color: kWarning, size: 16),
              const SizedBox(width: 8),
              Text(
                "TIPS FORMAT NOMOR",
                style: TextStyle(
                  color: kWarning,
                  fontSize: 10,
                  fontFamily: "ShareTechMono",
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _tipRow("✗", "+62812345678", kError),
          const SizedBox(height: 4),
          _tipRow("✗", "0812345678", kError),
          const SizedBox(height: 4),
          _tipRow("✓", "62812345678", kSuccess),
          const SizedBox(height: 10),
          Text(
            "→ Pakai kode negara tanpa + dan tanpa 0 di depan",
            style: TextStyle(
              color: kWarning.withValues(alpha: 0.8),
              fontSize: 10,
              fontFamily: "ShareTechMono",
            ),
          ),
          const SizedBox(height: 2),
          Text(
            "→ Contoh: Indonesia = 62, Malaysia = 60, US = 1",
            style: TextStyle(
              color: kWarning.withValues(alpha: 0.6),
              fontSize: 10,
              fontFamily: "ShareTechMono",
            ),
          ),
        ],
      ),
    );
  }

  Widget _tipRow(String symbol, String text, Color color) {
    return Row(
      children: [
        SizedBox(
          width: 18,
          child: Text(
            symbol,
            style: TextStyle(
              color: color,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              fontFamily: "ShareTechMono",
            ),
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            color: color.withValues(alpha: 0.1),
            border: Border.all(color: color.withValues(alpha: 0.3)),
          ),
          child: Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontFamily: "ShareTechMono",
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }

  // ── Phone Input ──────────────────────────────────────────
  Widget _buildPhoneInput(
    TextEditingController controller,
    String detectedCountry,
    String? errorMsg, {
    required Function(String) onCountryDetected,
    required Function(String?) onErrorChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "PHONE NUMBER",
          style: TextStyle(
            color: kSilver.withValues(alpha: 0.7),
            fontSize: 11,
            fontFamily: "ShareTechMono",
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: Colors.black.withValues(alpha: 0.5),
            border: Border.all(
              color: errorMsg != null
                  ? kError.withValues(alpha: 0.6)
                  : kSilverDark.withValues(alpha: 0.5),
              width: errorMsg != null ? 1.5 : 1,
            ),
          ),
          child: TextField(
            controller: controller,
            keyboardType: TextInputType.phone,
            inputFormatters: [
              NoPlusFormatter(),
              LengthLimitingTextInputFormatter(15),
            ],
            style: const TextStyle(
              color: kSilverLight,
              fontSize: 16,
              fontFamily: "ShareTechMono",
              letterSpacing: 1,
            ),
            cursorColor: kSilverLight,
            onChanged: (value) {
              final clean = value
                  .replaceAll('+', '')
                  .replaceAll(RegExp(r'[^\d]'), '');
              onCountryDetected(_detectCountry(clean));
              onErrorChanged(null);
            },
            decoration: InputDecoration(
              prefixIcon: Container(
                margin: const EdgeInsets.all(8),
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: const LinearGradient(
                    colors: [kSilverLight, kSilver],
                  ),
                ),
                child: const Icon(
                  Icons.phone_rounded,
                  color: kObsidian,
                  size: 14,
                ),
              ),
              hintText: "62812345678",
              hintStyle: TextStyle(
                color: kSilverDark.withValues(alpha: 0.5),
                fontSize: 14,
                fontFamily: "ShareTechMono",
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
        // Error message
        if (errorMsg != null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.error_outline_rounded, color: kError, size: 13),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  errorMsg,
                  style: TextStyle(
                    color: kError,
                    fontSize: 10,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ),
            ],
          ),
        ],
        // Detected country
        if (detectedCountry.isNotEmpty && errorMsg == null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                Icons.check_circle_outline_rounded,
                color: kSuccess,
                size: 13,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  detectedCountry,
                  style: TextStyle(
                    color: kSuccess.withValues(alpha: 0.8),
                    fontSize: 10,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  // ── Pairing Code Dialog ──────────────────────────────────
  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _buildGlassDialog(
        accentColor: kSuccess,
        title: "PAIRING CODE",
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kSuccess.withValues(alpha: 0.3)),
            ),
            child: Column(
              children: [
                Text(
                  number,
                  style: TextStyle(
                    color: kSilver.withValues(alpha: 0.7),
                    fontSize: 13,
                    fontFamily: "ShareTechMono",
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  decoration: BoxDecoration(
                    color: kSuccess.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: kSuccess.withValues(alpha: 0.4)),
                  ),
                  child: Text(
                    code,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: kSuccess,
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      fontFamily: "ShareTechMono",
                      letterSpacing: 4,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  "Enter this code in your WhatsApp linked devices.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: kSilver.withValues(alpha: 0.5),
                    fontSize: 11,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: _dialogButton(
                  label: "COPY",
                  icon: Icons.copy_rounded,
                  foregroundColor: kSuccess,
                  backgroundColor: kSuccess.withValues(alpha: 0.1),
                  borderColor: kSuccess.withValues(alpha: 0.5),
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: code));
                    Navigator.pop(context);
                    _showToast("Pairing code copied!");
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _dialogButton(
                  label: "CLOSE",
                  foregroundColor: kObsidian,
                  gradient: const LinearGradient(
                    colors: [kSilverLight, kSilver, kSilverMid],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  onTap: () => Navigator.pop(context),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Modern Dialog (Add Sender) ───────────────────────────
  Widget _buildModernDialog({
    required String title,
    required IconData icon,
    required List<Widget> children,
    required VoidCallback onConfirm,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
            decoration: _glassDecoration(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _dialogHeader(title),
                const SizedBox(height: 24),
                ...children,
                const SizedBox(height: 24),
                _dialogActions(onConfirm),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Glass Dialog (Pairing Code) ──────────────────────────
  Widget _buildGlassDialog({
    required Color accentColor,
    required String title,
    required List<Widget> children,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
            decoration: _glassDecoration(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Container(
                      width: 28,
                      height: 4,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            accentColor,
                            accentColor.withValues(alpha: 0.6),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          color: accentColor,
                          fontSize: 18,
                          fontFamily: "ShareTechMono",
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                ...children,
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Dialog Helpers ───────────────────────────────────────
  BoxDecoration _glassDecoration() {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(28),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          kGraphite.withValues(alpha: 0.97),
          kObsidian.withValues(alpha: 0.99),
        ],
      ),
      border: Border.all(color: kSilver.withValues(alpha: 0.3), width: 1),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.6),
          blurRadius: 30,
          offset: const Offset(0, 15),
        ),
      ],
    );
  }

  Widget _dialogHeader(String title) {
    return Row(
      children: [
        Container(
          width: 28,
          height: 4,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [kSilverLight, kSilver]),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: kSilverLight,
              fontSize: 18,
              fontFamily: "ShareTechMono",
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
        ),
      ],
    );
  }

  Widget _dialogActions(VoidCallback onConfirm) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: kSilverDark.withValues(alpha: 0.2),
              border: Border.all(color: kSilverDark.withValues(alpha: 0.5)),
            ),
            child: const Text(
              "CANCEL",
              style: TextStyle(
                color: kSilverMid,
                fontSize: 12,
                fontFamily: "ShareTechMono",
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        GestureDetector(
          onTap: onConfirm,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: const LinearGradient(
                colors: [kSilverLight, kSilver, kSilverMid],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: kSilverLight.withValues(alpha: 0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Center(
              child: Text(
                "SUBMIT",
                style: TextStyle(
                  color: kObsidian,
                  fontSize: 12,
                  fontFamily: "ShareTechMono",
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _dialogButton({
    required String label,
    required Color foregroundColor,
    IconData? icon,
    Color? backgroundColor,
    Color? borderColor,
    Gradient? gradient,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: backgroundColor,
          gradient: gradient,
          border: Border.all(
            color: borderColor ?? Colors.transparent,
            width: borderColor != null ? 1 : 0,
          ),
          boxShadow: gradient != null
              ? [
                  BoxShadow(
                    color: kSilverLight.withValues(alpha: 0.3),
                    blurRadius: 12,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, color: foregroundColor, size: 18),
              const SizedBox(width: 8),
            ],
            Text(
              label,
              style: TextStyle(
                color: foregroundColor,
                fontSize: 13,
                fontFamily: "ShareTechMono",
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SENDER CARD
// ============================================================
class _SenderCard extends StatelessWidget {
  final Map<String, dynamic> sender;
  final bool isGlobal;

  const _SenderCard({required this.sender, required this.isGlobal});

  @override
  Widget build(BuildContext context) {
    final accentColor = isGlobal ? kInfo : kSilverLight;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: LinearGradient(
                colors: [
                  kGraphite.withValues(alpha: 0.75),
                  kObsidian.withValues(alpha: 0.9),
                ],
              ),
              border: Border.all(
                color: accentColor.withValues(alpha: 0.3),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.4),
                  blurRadius: 14,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                // Icon
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: LinearGradient(
                      colors: isGlobal
                          ? [kInfo, const Color(0xFF0099CC)]
                          : [kSilverLight, kSilver],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: accentColor.withValues(alpha: 0.3),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: Icon(
                    isGlobal ? Icons.public_rounded : Icons.shield_outlined,
                    color: kObsidian,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 16),
                // Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        sender['sessionName'] ?? 'Unknown Device',
                        style: const TextStyle(
                          color: kSilverLight,
                          fontSize: 14,
                          fontFamily: "ShareTechMono",
                          fontWeight: FontWeight.w900,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: kSilverDark.withValues(alpha: 0.6),
                            ),
                            child: Text(
                              "${sender['type'] ?? 'N/A'}",
                              style: TextStyle(
                                color: kSilver.withValues(alpha: 0.85),
                                fontSize: 9,
                                fontWeight: FontWeight.bold,
                                fontFamily: "ShareTechMono",
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Flexible(
                            child: Text(
                              isGlobal
                                  ? "Owner: Global (VIP)"
                                  : "Owner: ${sender['owner'] ?? 'N/A'}",
                              style: TextStyle(
                                color: kSilver.withValues(alpha: 0.6),
                                fontSize: 10,
                                fontFamily: "ShareTechMono",
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Status Badge
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: kSuccess.withValues(alpha: 0.1),
                    border: Border.all(color: kSuccess.withValues(alpha: 0.5)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: kSuccess,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text(
                        "LIVE",
                        style: TextStyle(
                          color: kSuccess,
                          fontSize: 9,
                          fontFamily: "ShareTechMono",
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// API SERVICE
// ============================================================
class ApiService {
  static const String _baseUrl = "http://muzz.pterocloud.my.id:10912";

  static Future<Map<String, dynamic>> getMySender(String sessionKey) async {
    try {
      final response = await http.get(
        Uri.parse("$_baseUrl/api/whatsapp/mySender?key=$sessionKey"),
      );
      if (response.statusCode == 200) return jsonDecode(response.body);
      throw Exception('Failed: ${response.statusCode}');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  static Future<Map<String, dynamic>> getPairing(
    String sessionKey,
    String number,
  ) async {
    try {
      final response = await http.get(
        Uri.parse(
          "$_baseUrl/api/whatsapp/getPairing?key=$sessionKey&number=$number",
        ),
      );
      if (response.statusCode == 200) return jsonDecode(response.body);
      throw Exception('Failed: ${response.statusCode}');
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}

// ============================================================
// BACKGROUND GRID PAINTER
// ============================================================
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = kSilver.withValues(alpha: 0.025)
      ..strokeWidth = 0.5;

    const spacing = 32.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
