import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  late VideoPlayerController _videoController;
  String selectedBugId = "";

  String _selectedBugMode = "number"; // "number" atau "group"
  String _senderMode = "private";     // "private" atau "global"
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;
  
  bool _showSenderPopup = false;
  bool _showTargetPopup = false;
  bool _isPrivateActive = true;

  // ============ XENORA GLASSMORPHISM PALETTE ============
  static const Color _bgPrimary = Color(0xFF0A0E17);
  static const Color _bgSecondary = Color(0xFF141B2B);
  static const Color _glassBg = Color(0x33FFFFFF);
  static const Color _glassBorder = Color(0x4DFFFFFF);
  static const Color _glassBorderLight = Color(0x1AFFFFFF);
  static const Color _cardBg = Color(0x1AFFFFFF);
  static const Color _accent = Color(0xFF6C63FF);
  static const Color _accentGlow = Color(0xFF8B83FF);
  static const Color _accentPink = Color(0xFFFF6B9D);
  static const Color _textPrimary = Color(0xFFF0F4FF);
  static const Color _textSecondary = Color(0xFF8892B0);
  static const Color _textMuted = Color(0xFF4A5578);
  static const Color _activeGreen = Color(0xFF4CAF50);
  static const Color _inactiveRed = Color(0xFFEF5350);
  static const Color _borderColor = Color(0xFF2A3550);

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      }).catchError((e) {
        debugPrint("Video init error: $e");
      });

    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }

    _fetchSenderStats();
  }

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://projectsxteam.clouderz.my.id:2032/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
            _isPrivateActive = data['private_active'] ?? true;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _videoController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() { selectedBugId = currentBugs[0]['bug_id']; });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() { _isSending = true; });

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip') ? _senderMode : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://projectsxteam.clouderz.my.id:2032/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance atau terjadi kegagalan.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
    } finally {
      setState(() { _isSending = false; });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.6),
      builder: (_) => AlertDialog(
        backgroundColor: _bgSecondary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _accent.withOpacity(0.3), width: 1),
        ),
        title: Text(title, style: TextStyle(color: _textPrimary, fontWeight: FontWeight.bold, fontSize: 16)),
        content: Text(msg, style: TextStyle(color: _textSecondary, fontSize: 14)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: _accent, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showSenderSelectionPopup() {
    if (widget.role != 'owner' && widget.role != 'vip') {
      _showAlert("Akses Terbatas", "Mode pengirim global hanya untuk Owner/VIP.");
      return;
    }
    
    setState(() { _showSenderPopup = true; });
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateBottomSheet) {
          return Container(
            decoration: BoxDecoration(
              color: _bgSecondary,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border(top: BorderSide(color: _borderColor.withOpacity(0.5))),
            ),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: _textMuted,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Center(
                  child: Text(
                    "PILIH SENDER",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFF0F4FF),
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                
                GestureDetector(
                  onTap: () {
                    setStateBottomSheet(() {
                      _senderMode = "private";
                      _showSenderPopup = false;
                    });
                    setState(() {});
                    Navigator.pop(context);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: _senderMode == "private" ? _accent.withOpacity(0.15) : Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: _senderMode == "private" ? _accent : _borderColor,
                        width: _senderMode == "private" ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _isPrivateActive ? _activeGreen.withOpacity(0.15) : _inactiveRed.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                Icons.person_outline,
                                color: _isPrivateActive ? _activeGreen : _inactiveRed,
                                size: 20,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "PRIVATE SENDER",
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: _textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  _isPrivateActive ? "Active · $_privateSenderCount device" : "Inactive",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: _isPrivateActive ? _activeGreen : _inactiveRed,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        if (_senderMode == "private")
                          Icon(Icons.check_circle, color: _accent, size: 24),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                
                GestureDetector(
                  onTap: () {
                    setStateBottomSheet(() {
                      _senderMode = "global";
                      _showSenderPopup = false;
                    });
                    setState(() {});
                    Navigator.pop(context);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: _senderMode == "global" ? _accent.withOpacity(0.15) : Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: _senderMode == "global" ? _accent : _borderColor,
                        width: _senderMode == "global" ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _globalSenderCount > 0 ? _activeGreen.withOpacity(0.15) : _inactiveRed.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                Icons.public_outlined,
                                color: _globalSenderCount > 0 ? _activeGreen : _inactiveRed,
                                size: 20,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "GLOBAL SENDER",
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: _textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  _globalSenderCount > 0 ? "Active · $_globalSenderCount device" : "Inactive",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: _globalSenderCount > 0 ? _activeGreen : _inactiveRed,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        if (_senderMode == "global")
                          Icon(Icons.check_circle, color: _accent, size: 24),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showTargetSelectionPopup() {
    setState(() { _showTargetPopup = true; });
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateBottomSheet) {
          return Container(
            decoration: BoxDecoration(
              color: _bgSecondary,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border(top: BorderSide(color: _borderColor.withOpacity(0.5))),
            ),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: _textMuted,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Center(
                  child: Text(
                    "PILIH TARGET",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFF0F4FF),
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                
                GestureDetector(
                  onTap: () {
                    setStateBottomSheet(() {
                      _selectedBugMode = "number";
                      _showTargetPopup = false;
                      targetController.clear();
                      final newBugs = _getFilteredBugs();
                      if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                    });
                    setState(() {});
                    Navigator.pop(context);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: _selectedBugMode == "number" ? _accent.withOpacity(0.15) : Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: _selectedBugMode == "number" ? _accent : _borderColor,
                        width: _selectedBugMode == "number" ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _accent.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(
                                Icons.phone_android_rounded,
                                color: Color(0xFF6C63FF),
                                size: 20,
                              ),
                            ),
                            const SizedBox(width: 12),
                            const Text(
                              "BUG NOMOR",
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFFF0F4FF),
                              ),
                            ),
                          ],
                        ),
                        if (_selectedBugMode == "number")
                          Icon(Icons.check_circle, color: _accent, size: 24),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                
                GestureDetector(
                  onTap: () {
                    setStateBottomSheet(() {
                      _selectedBugMode = "group";
                      _showTargetPopup = false;
                      targetController.clear();
                      final newBugs = _getFilteredBugs();
                      if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                    });
                    setState(() {});
                    Navigator.pop(context);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: _selectedBugMode == "group" ? _accent.withOpacity(0.15) : Colors.transparent,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: _selectedBugMode == "group" ? _accent : _borderColor,
                        width: _selectedBugMode == "group" ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: _accentPink.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(
                                Icons.group_rounded,
                                color: Color(0xFFFF6B9D),
                                size: 20,
                              ),
                            ),
                            const SizedBox(width: 12),
                            const Text(
                              "BUG GROUP",
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFFF0F4FF),
                              ),
                            ),
                          ],
                        ),
                        if (_selectedBugMode == "group")
                          Icon(Icons.check_circle, color: _accent, size: 24),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        },
      ),
    );
  }

  // ============ BUILD UI ============

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgPrimary,
      body: SafeArea(
        child: Column(
          children: [
            _buildTopAppBar(),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildTopHeader(),
                    const SizedBox(height: 16),
                    _buildVideoBox(),
                    const SizedBox(height: 16),
                    
                    // ============ BUG CARDS HORIZONTAL SCROLL ============
                    _buildBugCards(),
                    
                    const SizedBox(height: 16),
                    _buildTargetTypeSelector(),
                    const SizedBox(height: 12),
                    _buildSenderModeSelector(),
                    const SizedBox(height: 20),
                    _buildInputPanel(),
                    const SizedBox(height: 20),
                    if (_getFilteredBugs().isNotEmpty) ...[
                      _buildPayloadDropdown(),
                      const SizedBox(height: 24),
                    ],
                    _buildLaunchButton(),
                    const SizedBox(height: 24),
                    Center(
                      child: Text(
                        "Session: ${widget.expiredDate} | Active: P($_privateSenderCount) G($_globalSenderCount)", 
                        style: TextStyle(color: _textMuted, fontSize: 11)
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============ GLASSMORPHISM BUG CARDS ============
  Widget _buildBugCards() {
    final bugs = _getFilteredBugs();
    
    if (bugs.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: _glassBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _glassBorderLight),
        ),
        child: Center(
          child: Text(
            "Tidak ada bug tersedia",
            style: TextStyle(color: _textSecondary, fontSize: 14),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 16,
                decoration: BoxDecoration(
                  color: _accent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                "PAYLOAD BUG CARDS",
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 110,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: bugs.length,
            itemBuilder: (context, index) {
              final bug = bugs[index];
              final isSelected = selectedBugId == bug['bug_id'];
              return _buildBugCard(bug, isSelected);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildBugCard(Map<String, dynamic> bug, bool isSelected) {
    final bugName = bug['bug_name'] ?? 'Unknown Bug';
    final bugId = bug['bug_id'] ?? '';
    final isGroup = bugId.contains('_group');
    
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedBugId = bugId;
        });
      },
      child: Container(
        width: 140,
        margin: const EdgeInsets.only(right: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected 
            ? _accent.withOpacity(0.15) 
            : _glassBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected 
              ? _accent 
              : _glassBorderLight,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected ? [
            BoxShadow(
              color: _accent.withOpacity(0.2),
              blurRadius: 20,
              spreadRadius: 5,
            ),
          ] : [],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: isGroup 
                      ? _accentPink.withOpacity(0.15) 
                      : _accent.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    isGroup ? Icons.group_rounded : Icons.bug_report_rounded,
                    color: isGroup ? _accentPink : _accent,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    bugName.length > 15 ? '${bugName.substring(0, 15)}...' : bugName,
                    style: TextStyle(
                      color: isSelected ? _accent : _textPrimary,
                      fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                      fontSize: 13,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: isSelected 
                  ? _accent.withOpacity(0.2) 
                  : _glassBorderLight,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                isGroup ? "GROUP" : "NUMBER",
                style: TextStyle(
                  color: isSelected ? _accent : _textMuted,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============ HEADER ============
  Widget _buildTopAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: const Icon(Icons.menu, color: _textPrimary, size: 26), 
            onPressed: () {},
          ),
          const Text(
            "XENORA",
            style: TextStyle(
              color: Color(0xFFF0F4FF), 
              fontSize: 20, 
              fontWeight: FontWeight.w700, 
              letterSpacing: 2.0,
            ),
          ),
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.headset_mic_outlined, color: Color(0xFF8892B0), size: 24), 
                onPressed: () {},
              ),
              IconButton(
                icon: const Icon(Icons.account_circle_outlined, color: Color(0xFF8892B0), size: 26), 
                onPressed: () {},
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildTopHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _glassBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _glassBorderLight),
        boxShadow: [
          BoxShadow(
            color: _accent.withOpacity(0.05),
            blurRadius: 30,
            spreadRadius: 10,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: _accent.withOpacity(0.2)),
            ),
            child: const Icon(Icons.bug_report_rounded, color: Color(0xFF6C63FF), size: 24),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "WHATSAPP CRASH",
                  style: TextStyle(
                    color: Color(0xFFF0F4FF), 
                    fontWeight: FontWeight.bold, 
                    fontSize: 18, 
                    letterSpacing: 0.5,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  "Advanced Payload Injection Tool",
                  style: TextStyle(color: Color(0xFF8892B0), fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoBox() {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        color: _bgSecondary,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: _videoController.value.isInitialized
          ? FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _videoController.value.size.width,
                height: _videoController.value.size.height,
                child: VideoPlayer(_videoController),
              ),
            )
          : Container(
              color: _bgSecondary,
              child: const Center(
                child: CircularProgressIndicator(color: Color(0xFF6C63FF)),
              ),
            ),
    );
  }

  Widget _buildTargetTypeSelector() {
    return InkWell(
      onTap: _showTargetSelectionPopup,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _glassBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _glassBorderLight),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.group_rounded,
                color: _accent,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "TARGET TYPE",
                    style: TextStyle(color: _textMuted, fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 1),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _selectedBugMode == "number" ? "BUG NOMOR" : "BUG GROUP",
                    style: TextStyle(color: _textPrimary, fontWeight: FontWeight.w600, fontSize: 15),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: _textMuted, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSenderModeSelector() {
    final isActive = _senderMode == "private" ? _isPrivateActive : _globalSenderCount > 0;
    final count = _senderMode == "private" ? _privateSenderCount : _globalSenderCount;

    return InkWell(
      onTap: _showSenderSelectionPopup,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _glassBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _glassBorderLight),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: isActive ? _activeGreen.withOpacity(0.15) : _inactiveRed.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                _senderMode == "private" ? Icons.person_outline : Icons.public_outlined,
                color: isActive ? _activeGreen : _inactiveRed,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        "SENDER MODE",
                        style: TextStyle(color: _textMuted, fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 1),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: isActive ? _activeGreen : _inactiveRed,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          isActive ? "Active" : "Inactive",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _senderMode == "private" ? "PRIVATE SENDER" : "GLOBAL SENDER",
                    style: TextStyle(color: _textPrimary, fontWeight: FontWeight.w600, fontSize: 15),
                  ),
                  Text(
                    "$count Active",
                    style: TextStyle(
                      color: isActive ? _activeGreen : _inactiveRed,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: _textMuted, size: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            _selectedBugMode == "number" ? "TARGET NUMBER" : "WHATSAPP GROUP LINK",
            style: TextStyle(color: _textSecondary, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 1),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: _glassBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _glassBorderLight),
          ),
          child: TextField(
            controller: targetController,
            style: TextStyle(color: _textPrimary, fontSize: 15),
            cursorColor: _accent,
            keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
            decoration: InputDecoration(
              hintText: _selectedBugMode == "number" ? "e.g. +628xxxxxxxx" : "e.g. https://chat.whatsapp.com/...",
              hintStyle: TextStyle(color: _textMuted, fontSize: 14),
              border: InputBorder.none,
              prefixIcon: Icon(
                _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link_rounded,
                color: _textMuted,
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPayloadDropdown() {
    final availableBugs = _getFilteredBugs();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            "SELECT PAYLOAD BUG",
            style: TextStyle(color: _textSecondary, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 1),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          decoration: BoxDecoration(
            color: _glassBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _glassBorderLight),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              dropdownColor: _bgSecondary,
              value: selectedBugId.isNotEmpty ? selectedBugId : null,
              isExpanded: true,
              icon: Icon(Icons.arrow_drop_down, color: _textSecondary, size: 24),
              style: TextStyle(color: _textPrimary, fontSize: 14, fontWeight: FontWeight.w500),
              items: availableBugs.map((bug) {
                return DropdownMenuItem<String>(
                  value: bug['bug_id'],
                  child: Text(bug['bug_name'] ?? 'Unknown'),
                );
              }).toList(),
              onChanged: (value) {
                setState(() { selectedBugId = value ?? ""; });
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLaunchButton() {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton(
        onPressed: _isSending ? null : _sendBug,
        style: ElevatedButton.styleFrom(
          backgroundColor: _accent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 0,
        ),
        child: _isSending
            ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.flash_on_rounded, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  const Text(
                    "LAUNCH ATTACK",
                    style: TextStyle(
                      color: Colors.white, 
                      fontWeight: FontWeight.bold, 
                      fontSize: 15, 
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}