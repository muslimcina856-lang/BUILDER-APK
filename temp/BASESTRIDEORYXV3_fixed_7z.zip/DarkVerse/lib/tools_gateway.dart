import 'dart:ui';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'hentai_page.dart' as hentai;

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  // ============ XENORA PALETTE ============
  static const Color _bgPrimary = Color(0xFF0A0E17);
  static const Color _bgSecondary = Color(0xFF141B2B);
  static const Color _bgCard = Color(0xFF1A2335);
  static const Color _glassBg = Color(0x33FFFFFF);
  static const Color _glassBorder = Color(0x4DFFFFFF);
  static const Color _glassBorderLight = Color(0x1AFFFFFF);
  static const Color _accent = Color(0xFF6C63FF);
  static const Color _accentGlow = Color(0xFF8B83FF);
  static const Color _accentPink = Color(0xFFFF6B9D);
  static const Color _textPrimary = Color(0xFFF0F4FF);
  static const Color _textSecondary = Color(0xFF8892B0);
  static const Color _textMuted = Color(0xFF4A5578);
  static const Color _borderColor = Color(0xFF2A3550);
  static const Color _success = Color(0xFF4CAF50);
  static const Color _warning = Color(0xFFFF9800);
  static const Color _danger = Color(0xFFEF5350);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgPrimary,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          children: [
            // === HEADER ===
            _buildHeader(),
            const SizedBox(height: 20),

            // === STAT BAR ===
            _buildStatBar(),
            const SizedBox(height: 20),

            // === TOOL CATEGORIES ===
            _buildCategoryTile(
              icon: Icons.flash_on_rounded,
              title: "DDOS Tools",
              subtitle: "Attack & Server",
              children: [
                _buildToolItem(
                  context: context,
                  icon: Icons.flash_on_rounded,
                  label: "Attack Panel",
                  badge: "LIVE",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AttackPanel(
                          sessionKey: sessionKey,
                          listDoos: listDoos,
                        ),
                      ),
                    );
                  },
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.dns_rounded,
                  label: "Manage Server",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ManageServerPage(keyToken: sessionKey),
                      ),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 6),

            _buildCategoryTile(
              icon: Icons.wifi_rounded,
              title: "Network",
              subtitle: "WiFi & Spam",
              children: [
                _buildToolItem(
                  context: context,
                  icon: Icons.newspaper_rounded,
                  label: "Spam NGL",
                  badge: "NEW",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => NglPage()));
                  },
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.wifi_off_rounded,
                  label: "WiFi Killer (Internal)",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => WifiKillerPage()));
                  },
                ),
                if (userRole == "vip" || userRole == "owner")
                  _buildToolItem(
                    context: context,
                    icon: Icons.router_rounded,
                    label: "WiFi Killer (External)",
                    badge: "VIP",
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)));
                    },
                  ),
              ],
            ),
            const SizedBox(height: 6),

            _buildCategoryTile(
              icon: Icons.search_rounded,
              title: "OSINT",
              subtitle: "Investigation",
              children: [
                _buildToolItem(
                  context: context,
                  icon: Icons.badge_rounded,
                  label: "NIK Detail",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
                  },
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.domain_rounded,
                  label: "Domain OSINT",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
                  },
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.person_search_rounded,
                  label: "Phone Lookup",
                  locked: true,
                  onTap: () => _showComingSoon(context),
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.email_rounded,
                  label: "Email OSINT",
                  locked: true,
                  onTap: () => _showComingSoon(context),
                ),
              ],
            ),
            const SizedBox(height: 6),

            _buildCategoryTile(
              icon: Icons.download_rounded,
              title: "Downloader",
              subtitle: "Social Media",
              children: [
                _buildToolItem(
                  context: context,
                  icon: Icons.video_library_rounded,
                  label: "TikTok Downloader",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
                  },
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.camera_alt_rounded,
                  label: "Instagram Downloader",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
                  },
                ),
              ],
            ),
            const SizedBox(height: 6),

            _buildCategoryTile(
              icon: Icons.build_rounded,
              title: "Utilities",
              subtitle: "Extra Tools",
              children: [
                _buildToolItem(
                  context: context,
                  icon: Icons.qr_code_rounded,
                  label: "QR Generator",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
                  },
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.security_rounded,
                  label: "IP Scanner",
                  locked: true,
                  onTap: () => _showComingSoon(context),
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.network_check_rounded,
                  label: "Port Scanner",
                  locked: true,
                  onTap: () => _showComingSoon(context),
                ),
              ],
            ),
            const SizedBox(height: 6),

            _buildCategoryTile(
              icon: Icons.movie_filter_rounded,
              title: "Watch",
              subtitle: "Entertainment & Media",
              children: [
                _buildToolItem(
                  context: context,
                  icon: Icons.live_tv_rounded,
                  label: "Anime Streaming",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeAnimePage()));
                  },
                ),
                _buildToolItem(
                  context: context,
                  icon: Icons.local_fire_department_rounded,
                  label: "Hentai Media",
                  badge: "18+",
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const hentai.HomeScreen()));
                  },
                ),
              ],
            ),
            const SizedBox(height: 6),

            _buildCategoryTile(
              icon: Icons.rocket_launch_rounded,
              title: "Quick Access",
              subtitle: "Favorites",
              children: [
                _buildToolItem(
                  context: context,
                  icon: Icons.star_border_rounded,
                  label: "Add Quick Access",
                  locked: true,
                  onTap: () => _showComingSoon(context),
                ),
              ],
            ),

            const SizedBox(height: 32),
            // === FOOTER ===
            Center(
              child: Column(
                children: [
                  Container(
                    width: 40,
                    height: 3,
                    decoration: BoxDecoration(
                      color: _accent.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    "XENORA TOOLS v2.0",
                    style: TextStyle(
                      color: _textMuted,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "All tools are for educational purposes only.",
                    style: TextStyle(
                      color: _textMuted.withOpacity(0.5),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  // === HEADER WIDGET ===
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _glassBg,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _glassBorderLight, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _accent.withOpacity(0.2)),
              boxShadow: [
                BoxShadow(
                  color: _accent.withOpacity(0.1),
                  blurRadius: 20,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Icon(Icons.shield_rounded, color: _accent, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "XENORA",
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "TOOLS DASHBOARD",
                  style: TextStyle(
                    color: _textSecondary,
                    fontSize: 12,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _accent.withOpacity(0.2)),
            ),
            child: Text(
              userRole.toUpperCase(),
              style: TextStyle(
                color: _accent,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // === STAT BAR ===
  Widget _buildStatBar() {
    return Row(
      children: [
        _buildStatChip(
          icon: Icons.flash_on_rounded,
          label: "${listDoos.length} Methods",
          color: _accentPink,
        ),
        const SizedBox(width: 8),
        _buildStatChip(
          icon: Icons.category_rounded,
          label: "7 Categories",
          color: _accent,
        ),
        const SizedBox(width: 8),
        _buildStatChip(
          icon: Icons.lock_rounded,
          label: userRole.toUpperCase(),
          color: _success,
        ),
      ],
    );
  }

  Widget _buildStatChip({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: _glassBg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.15)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color.withOpacity(0.8), size: 14),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                style: TextStyle(
                  color: color.withOpacity(0.9),
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // === CATEGORY TILE (Accordion) ===
  Widget _buildCategoryTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _glassBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _glassBorderLight, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Theme(
        data: ThemeData(
          dividerColor: Colors.transparent,
          colorScheme: ColorScheme.dark(
            surfaceContainerHighest: Colors.transparent,
          ),
        ),
        child: ExpansionTile(
          iconColor: _accent,
          collapsedIconColor: _textMuted,
          tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          childrenPadding: EdgeInsets.zero,
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _accent.withOpacity(0.15)),
            ),
            child: Icon(icon, color: _accent, size: 20),
          ),
          title: Text(
            title,
            style: TextStyle(
              color: _textPrimary,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.8,
            ),
          ),
          subtitle: Text(
            subtitle,
            style: TextStyle(
              color: _textMuted,
              fontSize: 11,
            ),
          ),
          children: [
            Container(
              padding: const EdgeInsets.only(left: 14, right: 14, bottom: 12, top: 2),
              child: Column(
                children: children,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // === TOOL ITEM ===
  Widget _buildToolItem({
    required BuildContext context,
    required IconData icon,
    required String label,
    String? badge,
    bool locked = false,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _borderColor.withOpacity(0.5)),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          splashColor: _accent.withOpacity(0.06),
          highlightColor: _accent.withOpacity(0.03),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: locked
                        ? _textMuted.withOpacity(0.1)
                        : _accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    icon,
                    color: locked ? _textMuted.withOpacity(0.3) : _accent.withOpacity(0.9),
                    size: 16,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      color: locked ? _textMuted.withOpacity(0.4) : _textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
                if (badge != null) ...[
                  _buildBadge(badge),
                  const SizedBox(width: 8),
                ],
                if (locked)
                  Icon(Icons.lock_outline_rounded, color: _textMuted, size: 14)
                else
                  Icon(Icons.arrow_forward_ios_rounded, color: _textMuted.withOpacity(0.3), size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // === BADGE WIDGET ===
  Widget _buildBadge(String text) {
    Color bgColor;
    Color textColor;

    switch (text.toUpperCase()) {
      case "LIVE":
        bgColor = _danger.withOpacity(0.15);
        textColor = _danger;
        break;
      case "NEW":
        bgColor = _accent.withOpacity(0.15);
        textColor = _accent;
        break;
      case "VIP":
        bgColor = _warning.withOpacity(0.15);
        textColor = _warning;
        break;
      case "18+":
        bgColor = _accentPink.withOpacity(0.15);
        textColor = _accentPink;
        break;
      default:
        bgColor = _accent.withOpacity(0.1);
        textColor = _accent;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: textColor.withOpacity(0.15)),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: textColor,
          fontSize: 8,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.6,
        ),
      ),
    );
  }

  // === COMING SOON DIALOG ===
  void _showComingSoon(BuildContext context) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (_) => AlertDialog(
        backgroundColor: _bgSecondary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _glassBorder, width: 1),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.lock_clock_rounded, color: _accent, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              "Coming Soon",
              style: TextStyle(
                color: _textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
        content: Text(
          "Fitur ini masih dalam tahap pengembangan.\nNantikan update selanjutnya.",
          style: TextStyle(color: _textSecondary, fontSize: 14, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "OK",
              style: TextStyle(
                color: _accent,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}