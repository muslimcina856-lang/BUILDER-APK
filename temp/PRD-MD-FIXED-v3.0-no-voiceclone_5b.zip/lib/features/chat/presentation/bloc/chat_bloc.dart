import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

import '../../domain/entities/chat_session.dart';
import '../../domain/entities/chat_message.dart';
import '../../domain/repositories/chat_repository.dart';
import '../../data/repositories/chat_repository_impl.dart';
import '../../../../core/utils/prompt_assembler.dart';
import '../../../../core/utils/clarification_parser.dart';
import '../../../../core/utils/mimo_key_manager.dart';
import '../../../../core/utils/mimo_api_client.dart';
import '../../../../services/database_service.dart';
import '../../../skills/domain/entities/ai_skill.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class ChatEvent extends Equatable {
  const ChatEvent();
  @override
  List<Object?> get props => [];
}

class LoadChatSessions extends ChatEvent {}

class CreateNewSession extends ChatEvent {
  final String title;
  final String modelType;
  final List<String> skillIds;

  const CreateNewSession({
    required this.title,
    required this.modelType,
    required this.skillIds,
  });

  @override
  List<Object?> get props => [title, modelType, skillIds];
}

class LoadMessages extends ChatEvent {
  final String sessionId;
  const LoadMessages(this.sessionId);
  @override
  List<Object?> get props => [sessionId];
}

class SendMessage extends ChatEvent {
  final String sessionId;
  final String content;
  final String apiKey;

  /// ID kunci API MiMo yang digunakan untuk permintaan ini. Diperlukan
  /// supaya hasil (berjaya/gagal) boleh direkodkan terhadap kunci yang
  /// betul dalam sistem fallback.
  final String keyId;
  final String model;

  const SendMessage({
    required this.sessionId,
    required this.content,
    required this.apiKey,
    required this.keyId,
    required this.model,
  });

  @override
  List<Object?> get props => [sessionId, content, apiKey, keyId, model];
}

/// Menghantar semula mesej AI yang gagal atau tidak memuaskan, dengan
/// membuang mesej AI terakhir dan menjana semula respons menggunakan
/// mesej pengguna yang sama (konteks perbualan yang lain kekal tidak
/// berubah).
class RetryLastMessage extends ChatEvent {
  final String sessionId;
  final String apiKey;
  final String keyId;
  final String model;

  const RetryLastMessage({
    required this.sessionId,
    required this.apiKey,
    required this.keyId,
    required this.model,
  });

  @override
  List<Object?> get props => [sessionId, apiKey, keyId, model];
}

/// Mengedit satu mesej pengguna yang sedia ada dan menghantarnya semula.
/// Semua mesej selepas mesej yang diedit (termasuk mesej asal itu
/// sendiri) akan dibuang daripada sejarah, supaya konteks perbualan
/// kekal tekal dengan kandungan baharu yang menggantikannya.
class EditAndResendMessage extends ChatEvent {
  final String sessionId;
  final String messageId;
  final DateTime messageTimestamp;
  final String newContent;
  final String apiKey;
  final String keyId;
  final String model;

  const EditAndResendMessage({
    required this.sessionId,
    required this.messageId,
    required this.messageTimestamp,
    required this.newContent,
    required this.apiKey,
    required this.keyId,
    required this.model,
  });

  @override
  List<Object?> get props =>
      [sessionId, messageId, messageTimestamp, newContent, apiKey, keyId, model];
}

class SubmitFormResponse extends ChatEvent {
  final String sessionId;
  final String messageId; // message id that contains the form
  final String fieldName;
  final List<String> selectedValues;
  final String? customValue;
  final String apiKey;
  final String keyId;
  final String model;

  const SubmitFormResponse({
    required this.sessionId,
    required this.messageId,
    required this.fieldName,
    required this.selectedValues,
    this.customValue,
    required this.apiKey,
    required this.keyId,
    required this.model,
  });

  @override
  List<Object?> get props => [sessionId, messageId, fieldName, selectedValues, customValue, apiKey, keyId, model];
}

class UpdateSessionTitle extends ChatEvent {
  final String sessionId;
  final String newTitle;
  const UpdateSessionTitle({required this.sessionId, required this.newTitle});
  @override
  List<Object?> get props => [sessionId, newTitle];
}

class DeleteSession extends ChatEvent {
  final String sessionId;
  const DeleteSession(this.sessionId);
  @override
  List<Object?> get props => [sessionId];
}

class StopGeneration extends ChatEvent {}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class ChatState extends Equatable {
  const ChatState();
  @override
  List<Object?> get props => [];
}

class ChatInitial extends ChatState {}

class ChatLoading extends ChatState {}

class SessionsLoaded extends ChatState {
  final List<ChatSession> sessions;
  const SessionsLoaded(this.sessions);
  @override
  List<Object?> get props => [sessions];
}

class MessagesLoaded extends ChatState {
  final List<ChatMessage> messages;
  final String sessionId;
  final bool isGenerating;

  const MessagesLoaded({
    required this.messages,
    required this.sessionId,
    this.isGenerating = false,
  });

  MessagesLoaded copyWith({
    List<ChatMessage>? messages,
    String? sessionId,
    bool? isGenerating,
  }) {
    return MessagesLoaded(
      messages: messages ?? this.messages,
      sessionId: sessionId ?? this.sessionId,
      isGenerating: isGenerating ?? this.isGenerating,
    );
  }

  @override
  List<Object?> get props => [messages, sessionId, isGenerating];
}

class MessageStreaming extends ChatState {
  final List<ChatMessage> messages;
  final String currentStreamText;
  final String sessionId;

  const MessageStreaming({
    required this.messages,
    required this.currentStreamText,
    required this.sessionId,
  });

  @override
  List<Object?> get props => [messages, currentStreamText, sessionId];
}

class ChatError extends ChatState {
  final String message;
  const ChatError(this.message);
  @override
  List<Object?> get props => [message];
}

class SessionCreated extends ChatState {
  final ChatSession session;
  const SessionCreated(this.session);
  @override
  List<Object?> get props => [session];
}

// -----------------------------------------------------------------------------
// BLOC IMPLEMENTATION
// -----------------------------------------------------------------------------
class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final ChatRepository _chatRepository;
  final PromptAssembler _promptAssembler = const PromptAssembler();
  final ClarificationParser _clarificationParser = const ClarificationParser();
  final DatabaseService _dbService = DatabaseService();
  final MimoKeyManager _keyManager = MimoKeyManager();
  final Uuid _uuid = const Uuid();
  
  StreamSubscription<MimoChunk>? _apiSubscription;

  /// ID mesej AI yang sedang aktif distrim, dan teks yang telah terkumpul
  /// setakat ini. Dikongsi antara [_streamResponse] dan [_onStopGeneration]
  /// supaya kedua-duanya menulis ke row DB yang SAMA (melalui
  /// ConflictAlgorithm.replace di saveMessage) apabila streaming
  /// dihentikan secara manual — mengelakkan mesej AI yang berganda
  /// (satu daripada progress separa, satu lagi daripada StopGeneration).
  String? _currentStreamingMsgId;
  String _currentStreamingText = '';
  String? _currentStreamingReasoning;

  ChatBloc({ChatRepository? chatRepository})
      : _chatRepository = chatRepository ?? ChatRepositoryImpl(),
        super(ChatInitial()) {
    on<LoadChatSessions>(_onLoadChatSessions);
    on<CreateNewSession>(_onCreateNewSession);
    on<LoadMessages>(_onLoadMessages);
    on<SendMessage>(_onSendMessage);
    on<RetryLastMessage>(_onRetryLastMessage);
    on<EditAndResendMessage>(_onEditAndResendMessage);
    on<SubmitFormResponse>(_onSubmitFormResponse);
    on<UpdateSessionTitle>(_onUpdateSessionTitle);
    on<DeleteSession>(_onDeleteSession);
    on<StopGeneration>(_onStopGeneration);
  }

  Future<void> _onLoadChatSessions(LoadChatSessions event, Emitter<ChatState> emit) async {
    try {
      final List<ChatSession> sessions = await _chatRepository.getAllSessions();
      emit(SessionsLoaded(sessions));
    } catch (e) {
      emit(ChatError('Gagal memuatkan perbualan: $e'));
    }
  }

  Future<void> _onCreateNewSession(CreateNewSession event, Emitter<ChatState> emit) async {
    emit(ChatLoading());
    try {
      final ChatSession session = await _chatRepository.createSession(
        title: event.title,
        modelType: event.modelType,
        skillIds: event.skillIds,
      );
      emit(SessionCreated(session));
      add(LoadChatSessions());
    } catch (e) {
      emit(ChatError('Gagal membina sesi perbualan: $e'));
    }
  }

  Future<void> _onLoadMessages(LoadMessages event, Emitter<ChatState> emit) async {
    emit(ChatLoading());
    try {
      final List<ChatMessage> messages = await _chatRepository.getMessages(event.sessionId);
      emit(MessagesLoaded(messages: messages, sessionId: event.sessionId));
    } catch (e) {
      emit(ChatError('Gagal memuatkan mesej perbualan: $e'));
    }
  }

  Future<void> _onSendMessage(SendMessage event, Emitter<ChatState> emit) async {
    final List<ChatMessage> currentMessages = await _chatRepository.getMessages(event.sessionId);
    
    // 1. Simpan & letak mesej user ke senarai
    final ChatMessage userMsg = ChatMessage(
      id: _uuid.v4(),
      sessionId: event.sessionId,
      role: ChatMessage.roleUser,
      content: event.content,
      timestamp: DateTime.now(),
    );

    await _chatRepository.saveMessage(userMsg);
    final List<ChatMessage> updatedMessages = [...currentMessages, userMsg];
    
    emit(MessagesLoaded(messages: updatedMessages, sessionId: event.sessionId, isGenerating: true));

    await _assembleAndStream(
      emit: emit,
      sessionId: event.sessionId,
      apiKey: event.apiKey,
      keyId: event.keyId,
      model: event.model,
      historyMessages: updatedMessages,
    );
  }

  Future<void> _onRetryLastMessage(RetryLastMessage event, Emitter<ChatState> emit) async {
    final List<ChatMessage> currentMessages = await _chatRepository.getMessages(event.sessionId);
    if (currentMessages.isEmpty) return;

    // Cari mesej AI terakhir untuk dibuang (jika ada) — retry sepatutnya
    // menjana semula respons AI, bukan menambah mesej pengguna baharu.
    List<ChatMessage> historyForRetry = currentMessages;
    final ChatMessage lastMessage = currentMessages.last;
    if (lastMessage.isAssistant) {
      await _chatRepository.deleteMessage(lastMessage.id);
      historyForRetry = currentMessages.sublist(0, currentMessages.length - 1);
    }

    if (historyForRetry.isEmpty || !historyForRetry.last.isUser) {
      // Tiada mesej pengguna untuk dijadikan asas percubaan semula.
      emit(ChatError('Tiada mesej pengguna untuk dihantar semula.'));
      add(LoadMessages(event.sessionId));
      return;
    }

    emit(MessagesLoaded(messages: historyForRetry, sessionId: event.sessionId, isGenerating: true));

    await _assembleAndStream(
      emit: emit,
      sessionId: event.sessionId,
      apiKey: event.apiKey,
      keyId: event.keyId,
      model: event.model,
      historyMessages: historyForRetry,
    );
  }

  Future<void> _onEditAndResendMessage(
      EditAndResendMessage event, Emitter<ChatState> emit) async {
    // 1. Buang mesej asal yang diedit serta semua mesej selepasnya, supaya
    // konteks perbualan kekal tekal dengan kandungan baharu.
    await _chatRepository.deleteMessagesFromTimestamp(
      event.sessionId,
      event.messageTimestamp,
    );

    final List<ChatMessage> remainingMessages =
        await _chatRepository.getMessages(event.sessionId);

    // 2. Simpan mesej baharu (menggantikan yang diedit) dengan id baharu —
    // menggunakan id baharu (bukan id asal) mengelakkan konflik jika
    // timestamp asal masih tersimpan di tempat lain secara tidak sengaja.
    final ChatMessage newUserMsg = ChatMessage(
      id: _uuid.v4(),
      sessionId: event.sessionId,
      role: ChatMessage.roleUser,
      content: event.newContent,
      timestamp: DateTime.now(),
    );

    await _chatRepository.saveMessage(newUserMsg);
    final List<ChatMessage> updatedMessages = [...remainingMessages, newUserMsg];

    emit(MessagesLoaded(messages: updatedMessages, sessionId: event.sessionId, isGenerating: true));

    await _assembleAndStream(
      emit: emit,
      sessionId: event.sessionId,
      apiKey: event.apiKey,
      keyId: event.keyId,
      model: event.model,
      historyMessages: updatedMessages,
    );
  }

  /// Membina system prompt daripada skills aktif, menyusun senarai mesej
  /// untuk dihantar ke API MiMo, dan memulakan streaming. Dikongsi oleh
  /// [_onSendMessage], [_onRetryLastMessage], dan [_onEditAndResendMessage]
  /// supaya logik penyusunan prompt tidak berulang tiga kali.
  Future<void> _assembleAndStream({
    required Emitter<ChatState> emit,
    required String sessionId,
    required String apiKey,
    required String keyId,
    required String model,
    required List<ChatMessage> historyMessages,
  }) async {
    final List<Map<String, dynamic>> rawSkills = await _dbService.getActiveSkillsForSession(sessionId);
    final List<AISkill> activeSkills = rawSkills.map((row) {
      final Map<String, dynamic> mapped = Map<String, dynamic>.from(row);
      mapped['isDefault'] = row['is_default'];
      mapped['isActive'] = row['is_active'];
      mapped['instruction'] = row['system_prompt'];
      return AISkill.fromMap(mapped);
    }).toList();

    final String systemPrompt = _promptAssembler.assembleSystemPrompt(activeSkills);
    
    final List<Map<String, String>> apiMessages = [];
    apiMessages.add({'role': 'system', 'content': systemPrompt});

    for (final ChatMessage msg in historyMessages) {
      apiMessages.add({'role': msg.role, 'content': msg.content});
    }

    await _streamResponse(
      emit: emit,
      sessionId: sessionId,
      apiKey: apiKey,
      keyId: keyId,
      model: model,
      apiMessages: apiMessages,
      historyMessages: historyMessages,
    );
  }

  Future<void> _streamResponse({
    required Emitter<ChatState> emit,
    required String sessionId,
    required String apiKey,
    required String keyId,
    required String model,
    required List<Map<String, String>> apiMessages,
    required List<ChatMessage> historyMessages,
  }) async {
    final Completer<void> completer = Completer<void>();

    // Teks jawapan sebenar (content) — inilah yang dipaparkan sebagai
    // mesej AI kepada pengguna.
    String accumulatedText = '';

    // Teks penaakulan (reasoning) — disimpan berasingan dan TIDAK
    // dipaparkan sebagai mesej utama. Model MiMo boleh menghantar teks
    // "berfikir" sebelum jawapan sebenar; menggabungkannya dengan content
    // akan membuatkan pengguna nampak nota dalaman AI seperti "The user
    // wants me to..." yang nampak tidak profesional.
    String accumulatedReasoning = '';
    
    final String assistantMsgId = _uuid.v4();
    final DateTime assistantTimestamp = DateTime.now();

    _currentStreamingMsgId = assistantMsgId;
    _currentStreamingText = '';
    _currentStreamingReasoning = null;

    // Simpan progress ke pangkalan data secara berkala (bukan setiap
    // chunk, untuk elak tulis disk berlebihan) supaya jawapan AI yang
    // sedang dijana tidak hilang jika pengguna menutup aplikasi (atau
    // proses dibunuh oleh OS) sebelum streaming selesai. Bila pengguna
    // membuka semula sesi ini, sekurang-kurangnya progress terkini yang
    // sempat disimpan akan kelihatan, bukan kosong.
    Timer? persistTimer;
    String lastPersistedText = '';

    Future<void> persistProgress() async {
      if (accumulatedText == lastPersistedText) return;
      lastPersistedText = accumulatedText;
      final ChatMessage partialMsg = ChatMessage(
        id: assistantMsgId,
        sessionId: sessionId,
        role: ChatMessage.roleAssistant,
        content: accumulatedText,
        timestamp: assistantTimestamp,
        reasoningContent: accumulatedReasoning.isNotEmpty ? accumulatedReasoning : null,
        // false kerana ini progress separa — streaming belum tamat lagi.
        // Ditukar kepada true di onDone apabila streaming berjaya selesai.
        isComplete: false,
      );
      try {
        await _chatRepository.saveMessage(partialMsg);
      } catch (_) {
        // Kegagalan simpan progress separa tidak sepatutnya menggagalkan
        // keseluruhan streaming; percubaan seterusnya akan cuba lagi.
      }
    }

    persistTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      persistProgress();
    });

    final Stream<MimoChunk> stream = _chatRepository.sendChatMessage(
      apiKey: apiKey,
      model: model,
      messages: apiMessages,
    );

    _apiSubscription = stream.listen(
      (chunk) {
        if (chunk.type == MimoChunkType.reasoning) {
          accumulatedReasoning += chunk.text;
          _currentStreamingReasoning = accumulatedReasoning;
          // Reasoning tidak dipaparkan sebagai currentStreamText; hanya
          // status "sedang menjana" yang kekal kelihatan kepada pengguna.
          emit(MessageStreaming(
            messages: historyMessages,
            currentStreamText: accumulatedText,
            sessionId: sessionId,
          ));
          return;
        }

        // content atau error — kedua-dua ini yang dipaparkan.
        accumulatedText += chunk.text;
        _currentStreamingText = accumulatedText;
        emit(MessageStreaming(
          messages: historyMessages,
          currentStreamText: accumulatedText,
          sessionId: sessionId,
        ));
      },
      onError: (dynamic error) async {
        persistTimer?.cancel();
        await _keyManager.recordFailure(
          keyId: keyId,
          errorReason: error.toString(),
        );
        // Simpan apa sahaja yang sempat dijana sebelum ralat berlaku,
        // supaya progress separa itu tidak hilang begitu sahaja.
        if (accumulatedText.isNotEmpty) {
          await persistProgress();
        }
        _currentStreamingMsgId = null;
        _currentStreamingText = '';
        _currentStreamingReasoning = null;
        emit(ChatError('Ralat penstriman: $error'));
        completer.complete();
      },
      onDone: () async {
        persistTimer?.cancel();

        // Semak sama ada MimoApiClient menghantar penanda ralat sebagai
        // bahagian teks (bukan sebagai stream error) — ini berlaku untuk
        // ralat HTTP seperti 401/402/429 yang ditangkap oleh MimoApiClient
        // dan di-yield sebagai teks supaya boleh dipaparkan terus.
        final bool isErrorResponse = accumulatedText.trimLeft().startsWith('[ERROR]');

        if (isErrorResponse) {
          await _keyManager.recordFailure(
            keyId: keyId,
            errorReason: accumulatedText,
          );
        } else if (accumulatedText.isNotEmpty) {
          await _keyManager.recordSuccess(keyId);
        }

        // 5. Stream Selesai -> Parse Clarification Form
        // PENTING: parse hanya accumulatedText (content sahaja), bukan
        // accumulatedReasoning, supaya reasoning tidak tersasar masuk ke
        // dalam mesej yang dipaparkan atau mengganggu pengesanan tag
        // [CLARIFICATION_FORM].
        final ClarificationResult parsed = _clarificationParser.parse(accumulatedText);
        
        final ChatMessage aiMsg = ChatMessage(
          id: assistantMsgId,
          sessionId: sessionId,
          role: ChatMessage.roleAssistant,
          content: parsed.beforeText + parsed.afterText,
          containsForm: parsed.hasForm,
          rawFormJson: parsed.formData != null ? accumulatedText.substring(
            accumulatedText.indexOf('[CLARIFICATION_FORM]'),
            accumulatedText.indexOf('[/CLARIFICATION_FORM]') + '[/CLARIFICATION_FORM]'.length,
          ) : null,
          isFormSubmitted: false,
          timestamp: assistantTimestamp,
          reasoningContent: accumulatedReasoning.isNotEmpty ? accumulatedReasoning : null,
          // Streaming tamat secara normal — mesej ini lengkap sepenuhnya.
          isComplete: true,
        );

        await _chatRepository.saveMessage(aiMsg);
        
        _currentStreamingMsgId = null;
        _currentStreamingText = '';
        _currentStreamingReasoning = null;

        final List<ChatMessage> finalHistory = [...historyMessages, aiMsg];
        emit(MessagesLoaded(messages: finalHistory, sessionId: sessionId, isGenerating: false));
        completer.complete();
      },
      cancelOnError: true,
    );

    await completer.future;
  }

  Future<void> _onSubmitFormResponse(SubmitFormResponse event, Emitter<ChatState> emit) async {
    // 1. Kemaskini status borang lama
    await _chatRepository.updateMessageFormStatus(event.messageId, true);

    // 2. Format jawapan mesra-AI
    final String formattedAnswer = _clarificationParser.formatResponse(
      event.fieldName,
      event.selectedValues,
      customValue: event.customValue,
    );

    // 3. Hantar jawapan sebagai user message baharu
    add(SendMessage(
      sessionId: event.sessionId,
      content: formattedAnswer,
      apiKey: event.apiKey,
      keyId: event.keyId,
      model: event.model,
    ));
  }

  Future<void> _onUpdateSessionTitle(UpdateSessionTitle event, Emitter<ChatState> emit) async {
    try {
      await _chatRepository.updateSessionTitle(event.sessionId, event.newTitle);
      add(LoadChatSessions());
      
      final List<ChatMessage> messages = await _chatRepository.getMessages(event.sessionId);
      emit(MessagesLoaded(messages: messages, sessionId: event.sessionId));
    } catch (e) {
      emit(ChatError('Gagal mengemaskini tajuk: $e'));
    }
  }

  Future<void> _onDeleteSession(DeleteSession event, Emitter<ChatState> emit) async {
    try {
      await _chatRepository.deleteSession(event.sessionId);
      add(LoadChatSessions());
      emit(ChatInitial());
    } catch (e) {
      emit(ChatError('Gagal memadam sesi perbualan: $e'));
    }
  }

  Future<void> _onStopGeneration(StopGeneration event, Emitter<ChatState> emit) async {
    _apiSubscription?.cancel();
    _apiSubscription = null;
    
    // Kemaskini keadaan semasa
    final ChatState currentState = state;
    if (currentState is MessageStreaming) {
      // Guna ID mesej yang sama dengan yang sedang distrim (jika ada)
      // supaya ConflictAlgorithm.replace di saveMessage menimpa row
      // progress separa yang sama, bukan mencipta mesej AI berganda.
      final String msgId = _currentStreamingMsgId ?? _uuid.v4();

      final ChatMessage aiMsg = ChatMessage(
        id: msgId,
        sessionId: currentState.sessionId,
        role: ChatMessage.roleAssistant,
        content: '${currentState.currentStreamText}\n\n*[Penjanaan dihentikan oleh pengguna]*',
        timestamp: DateTime.now(),
        reasoningContent: _currentStreamingReasoning,
      );
      
      await _chatRepository.saveMessage(aiMsg);

      _currentStreamingMsgId = null;
      _currentStreamingText = '';
      _currentStreamingReasoning = null;
      
      emit(MessagesLoaded(
        messages: [...currentState.messages, aiMsg],
        sessionId: currentState.sessionId,
        isGenerating: false,
      ));
    }
  }

  @override
  Future<void> close() {
    _apiSubscription?.cancel();
    return super.close();
  }
}
