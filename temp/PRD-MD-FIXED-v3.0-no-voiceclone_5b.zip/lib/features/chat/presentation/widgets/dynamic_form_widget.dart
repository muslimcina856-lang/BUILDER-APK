import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/clarification_parser.dart';

class DynamicFormWidget extends StatefulWidget {
  final String rawFormJson;
  final bool isSubmitted;
  final Function(String fieldName, List<String> selectedValues, String? customValue) onSubmit;

  const DynamicFormWidget({
    super.key,
    required this.rawFormJson,
    required this.isSubmitted,
    required this.onSubmit,
  });

  @override
  State<DynamicFormWidget> createState() => _DynamicFormWidgetState();
}

class _DynamicFormWidgetState extends State<DynamicFormWidget> {
  static const String _customOptionValue = '__custom_option__';

  final ClarificationParser _parser = const ClarificationParser();
  final TextEditingController _customInputController = TextEditingController();
  
  ClarificationFormData? _formData;
  String? _singleSelectedValue;
  final List<String> _multipleSelectedValues = [];
  bool _formError = false;

  /// `true` apabila pengguna memilih opsyen "Lain-lain (nyatakan)" —
  /// hanya dalam keadaan ini medan input tersuai dipaparkan.
  bool get _isCustomOptionSelected =>
      _singleSelectedValue == _customOptionValue ||
      _multipleSelectedValues.contains(_customOptionValue);

  @override
  void initState() {
    super.initState();
    _parseForm();
  }

  @override
  void dispose() {
    _customInputController.dispose();
    super.dispose();
  }

  void _parseForm() {
    try {
      final ClarificationResult result = _parser.parse(widget.rawFormJson);
      if (result.hasForm && result.formData != null) {
        setState(() {
          _formData = result.formData;
          // Set default values
          if (_formData!.selectionType == 'single' && _formData!.options.isNotEmpty) {
            _singleSelectedValue = _formData!.options.first.value;
          }
        });
      } else {
        setState(() {
          _formError = true;
        });
      }
    } catch (_) {
      setState(() {
        _formError = true;
      });
    }
  }

  void _handleSubmit() {
    if (_formData == null) return;

    List<String> selected = [];
    if (_formData!.selectionType == 'single') {
      if (_singleSelectedValue != null && _singleSelectedValue != _customOptionValue) {
        // Dapatkan label untuk value yang dipilih
        final option = _formData!.options.firstWhere((o) => o.value == _singleSelectedValue);
        selected.add(option.label);
      }
    } else {
      for (final val in _multipleSelectedValues) {
        if (val == _customOptionValue) continue;
        final option = _formData!.options.firstWhere((o) => o.value == val);
        selected.add(option.label);
      }
    }

    final String? customText = _isCustomOptionSelected && _customInputController.text.trim().isNotEmpty
        ? _customInputController.text.trim()
        : null;

    widget.onSubmit(_formData!.fieldName, selected, customText);
  }

  @override
  Widget build(BuildContext context) {
    if (_formError) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.error.withOpacity( 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.error.withOpacity( 0.3)),
        ),
        child: const Text(
          'Gagal memaparkan borang pengesahan AI. Ralat format JSON.',
          style: TextStyle(color: AppColors.error, fontSize: 13),
        ),
      );
    }

    if (_formData == null) {
      return const SizedBox(
        height: 60,
        child: Center(
          child: CircularProgressIndicator(color: AppColors.accent),
        ),
      );
    }

    final bool disabled = widget.isSubmitted;

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.scaffold,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(
          color: disabled ? AppColors.cardBorder : AppColors.accent.withOpacity( 0.4),
          width: disabled ? 1.0 : 1.5,
        ),
        boxShadow: [
          if (!disabled)
            BoxShadow(
              color: AppColors.accent.withOpacity( 0.1),
              blurRadius: 12,
              spreadRadius: 1,
            ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.help_outline_rounded,
                color: disabled ? AppColors.textMuted : AppColors.accent,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Borang Pengesahan AI',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: disabled ? AppColors.textMuted : AppColors.accent,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            _formData!.question,
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),
          // Options
          if (_formData!.selectionType == 'single') ...[
            ..._formData!.options.map((option) {
              return Theme(
                data: Theme.of(context).copyWith(
                  unselectedWidgetColor: AppColors.textMuted,
                ),
                child: RadioListTile<String>(
                  title: Text(option.label, style: const TextStyle(color: Colors.white, fontSize: 13)),
                  value: option.value,
                  groupValue: _singleSelectedValue,
                  activeColor: AppColors.accent,
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  onChanged: disabled
                      ? null
                      : (val) {
                          setState(() {
                            _singleSelectedValue = val;
                          });
                        },
                ),
              );
            }),
            if (_formData!.allowCustom)
              Theme(
                data: Theme.of(context).copyWith(
                  unselectedWidgetColor: AppColors.textMuted,
                ),
                child: RadioListTile<String>(
                  title: const Text('Lain-lain (nyatakan)', style: TextStyle(color: Colors.white, fontSize: 13, fontStyle: FontStyle.italic)),
                  value: _customOptionValue,
                  groupValue: _singleSelectedValue,
                  activeColor: AppColors.accent,
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  onChanged: disabled
                      ? null
                      : (val) {
                          setState(() {
                            _singleSelectedValue = val;
                          });
                        },
                ),
              ),
          ] else ...[
            ..._formData!.options.map((option) {
              final bool checked = _multipleSelectedValues.contains(option.value);
              return Theme(
                data: Theme.of(context).copyWith(
                  unselectedWidgetColor: AppColors.textMuted,
                ),
                child: CheckboxListTile(
                  title: Text(option.label, style: const TextStyle(color: Colors.white, fontSize: 13)),
                  value: checked,
                  activeColor: AppColors.accent,
                  checkColor: AppColors.scaffold,
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  onChanged: disabled
                      ? null
                      : (val) {
                          setState(() {
                            if (val == true) {
                              _multipleSelectedValues.add(option.value);
                            } else {
                              _multipleSelectedValues.remove(option.value);
                            }
                          });
                        },
                ),
              );
            }),
            if (_formData!.allowCustom)
              Theme(
                data: Theme.of(context).copyWith(
                  unselectedWidgetColor: AppColors.textMuted,
                ),
                child: CheckboxListTile(
                  title: const Text('Lain-lain (nyatakan)', style: TextStyle(color: Colors.white, fontSize: 13, fontStyle: FontStyle.italic)),
                  value: _multipleSelectedValues.contains(_customOptionValue),
                  activeColor: AppColors.accent,
                  checkColor: AppColors.scaffold,
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  onChanged: disabled
                      ? null
                      : (val) {
                          setState(() {
                            if (val == true) {
                              _multipleSelectedValues.add(_customOptionValue);
                            } else {
                              _multipleSelectedValues.remove(_customOptionValue);
                            }
                          });
                        },
                ),
              ),
          ],
          // Medan input tersuai HANYA dipaparkan apabila pengguna secara
          // eksplisit memilih opsyen "Lain-lain (nyatakan)" — bukan
          // sentiasa dipaparkan setiap kali allowCustom bernilai true.
          if (_isCustomOptionSelected) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _customInputController,
              enabled: !disabled,
              autofocus: !disabled,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: _formData!.customPlaceholder.isNotEmpty
                    ? _formData!.customPlaceholder
                    : 'Nyatakan pilihan tersuai anda...',
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
            ),
          ],
          const SizedBox(height: 16),
          // Submit Button
          if (!disabled)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.send_rounded, size: 16),
                label: const Text('Hantar Jawapan'),
                onPressed: _handleSubmit,
              ),
            )
          else
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.cardBorder.withOpacity( 0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle_outline, color: AppColors.success, size: 16),
                    SizedBox(width: 8),
                    Text(
                      'Jawapan Borang Dihantar',
                      style: TextStyle(color: AppColors.success, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
