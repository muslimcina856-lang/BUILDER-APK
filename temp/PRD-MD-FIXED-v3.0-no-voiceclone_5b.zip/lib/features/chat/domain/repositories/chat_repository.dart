import '../../domain/entities/chat_session.dart';
import '../../domain/entities/chat_message.dart';
import '../../../../core/utils/mimo_api_client.dart';

/// Kontrak repositori untuk menguruskan sesi sembang dan mesej.
abstract class ChatRepository {
  /// Mendapatkan semua sesi sembang yang tersimpan di peranti.
  Future<List<ChatSession>> getAllSessions();

  /// Mencari sesi sembang berdasarkan tajuk secara masa nyata.
  Future<List<ChatSession>> searchSessions(String query);

  /// Cipta sesi sembang baharu.
  Future<ChatSession> createSession({
    required String title,
    required String modelType,
    required List<String> skillIds,
  });

  /// Kemaskini tajuk sesi sembang.
  Future<void> updateSessionTitle(String sessionId, String newTitle);

  /// Padam sesi sembang beserta semua mesej di dalamnya.
  Future<void> deleteSession(String sessionId);

  /// Padam semua data sembang dari peranti (Danger Zone).
  Future<void> deleteAllSessions();

  /// Mendapatkan semua mesej bagi sesuatu sesi sembang.
  Future<List<ChatMessage>> getMessages(String sessionId);

  /// Menyimpan mesej baharu ke pangkalan data.
  Future<void> saveMessage(ChatMessage message);

  /// Mengemas kini status borang mesej (sama ada telah dihantar atau belum).
  Future<void> updateMessageFormStatus(String messageId, bool isSubmitted);

  /// Memadam satu mesej tunggal. Digunakan oleh fungsi Retry untuk
  /// membuang mesej AI yang gagal sebelum menghantar semula.
  Future<void> deleteMessage(String messageId);

  /// Memadam semua mesej dalam sesi ini yang dicipta pada atau selepas
  /// `fromTimestamp`. Digunakan oleh fungsi Edit & Hantar Semula.
  Future<void> deleteMessagesFromTimestamp(
      String sessionId, DateTime fromTimestamp);

  /// Menghantar mesej ke MiMo AI API dan memulangkan aliran respons (Stream)
  /// sebagai [MimoChunk], supaya teks penaakulan (reasoning) dan teks
  /// jawapan sebenar (content) boleh dibezakan oleh pemanggil.
  Stream<MimoChunk> sendChatMessage({
    required String apiKey,
    required String model,
    required List<Map<String, String>> messages,
  });

  /// Uji sambungan kunci API MiMo AI.
  Future<bool> testApiConnection(String apiKey);
}
