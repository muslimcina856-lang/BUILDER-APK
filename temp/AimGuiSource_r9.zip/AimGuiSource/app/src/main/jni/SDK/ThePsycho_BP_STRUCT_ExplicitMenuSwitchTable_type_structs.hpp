#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:09 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_ExplicitMenuSwitchTable_type.BP_STRUCT_ExplicitMenuSwitchTable_type
// 0x000C
struct FBP_STRUCT_ExplicitMenuSwitchTable_type
{
	int                                                ID_0_7968950070B6BF9030F4C9B10FE59CF4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MenuID_1_34555A404892A56F3281DD1D0D15BC44;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_2_05BAF64071DEC1497EAE9170059D495E;                  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

