#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:09 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_ExplicitMenuSwitchTable_BuleHole_type.BP_STRUCT_ExplicitMenuSwitchTable_BuleHole_type
// 0x000C
struct FBP_STRUCT_ExplicitMenuSwitchTable_BuleHole_type
{
	int                                                ID_0_79BBF0C004265AC77DAC2749037579A4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MenuID_1_488136007386E6C02F28F4410A492CA4;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_2_4A1A920048095B047BF41863057A15CE;                  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

