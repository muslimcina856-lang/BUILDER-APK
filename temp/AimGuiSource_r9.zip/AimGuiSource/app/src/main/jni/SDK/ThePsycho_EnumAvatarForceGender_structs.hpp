#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:10 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Enums
//---------------------By RIYAZ @RIYAZXERO---------------------------

#ifdef PF_MAX
#undef PF_MAX
#endif

// UserDefinedEnum EnumAvatarForceGender.EnumAvatarForceGender
enum class EnumAvatarForceGender : uint8_t
{
	EnumAvatarForceGender__NewEnumerator0 = 0,
	EnumAvatarForceGender__NewEnumerator1 = 1,
	EnumAvatarForceGender__NewEnumerator2 = 2,
	EnumAvatarForceGender__EnumAvatarForceGender_MAX = 3
};



}

