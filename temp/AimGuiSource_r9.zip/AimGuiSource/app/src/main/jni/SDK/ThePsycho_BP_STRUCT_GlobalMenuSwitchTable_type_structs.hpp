#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:09 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_GlobalMenuSwitchTable_type.BP_STRUCT_GlobalMenuSwitchTable_type
// 0x0008
struct FBP_STRUCT_GlobalMenuSwitchTable_type
{
	int                                                ID_0_14E478C009E418DF06E7F5440259BAA4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_1_4FBB1A0034F5B7D2525FA9D509BB14EE;                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

