#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:09 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_BlueHoleMenuSwitchTable_type.BP_STRUCT_BlueHoleMenuSwitchTable_type
// 0x0008
struct FBP_STRUCT_BlueHoleMenuSwitchTable_type
{
	int                                                ID_0_5F0348800013FD827BF3E8B40CF9CC34;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_1_4DF229C00107A107250A3BE209CD8A4E;                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

