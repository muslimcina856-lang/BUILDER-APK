#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:11 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_RegionNo_type.BP_STRUCT_RegionNo_type
// 0x0008
struct FBP_STRUCT_RegionNo_type
{
	int                                                country_0_3B96D2C060DA453F186EAF900DC8C429;               // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                region_1_1913AEC0609F05AD760068620AD117AE;                // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

