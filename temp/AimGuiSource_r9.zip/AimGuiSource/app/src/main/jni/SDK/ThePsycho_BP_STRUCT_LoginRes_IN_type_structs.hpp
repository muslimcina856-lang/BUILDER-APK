#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:07 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_LoginRes_IN_type.BP_STRUCT_LoginRes_IN_type
// 0x0078
struct FBP_STRUCT_LoginRes_IN_type
{
	struct FString                                     BeginTime_0_1FB3C8C00894B4D337DDB7F8029A1645;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BGMPath_1_6EF4C4801E0C87C40DE5396F048D1118;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     EndTime_2_1F37154033E741B96BD4F1770A86D785;               // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_3_434FAF001F032AC066CFD9C40CF79BF4;                    // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FString                                     ResPath_4_174F198031EA311C63D7B62C0A071108;               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     TexPath_5_2B921B407E0643DF30AA111D08021108;               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     VideoPath_6_6AD72CC004A876FB26AFF1A205DDC698;             // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ResLodPath_7_1C94A14017357F0141AEC22106C3C838;            // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

