#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:07 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_LocalizeRes_type.BP_STRUCT_LocalizeRes_type
// 0x0010
struct FBP_STRUCT_LocalizeRes_type
{
	struct FString                                     TextValue_0_4D37165A410D67320AF278A1C1028E4F;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

