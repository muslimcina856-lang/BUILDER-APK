#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:07 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_TransColumns_type.BP_STRUCT_TransColumns_type
// 0x0020
struct FBP_STRUCT_TransColumns_type
{
	struct FString                                     Columns_0_47AC24714CA709ABE62AB2B97B02C861;               // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Table_1_B0FEB2B8486D4078687135A2F1589ADF;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

