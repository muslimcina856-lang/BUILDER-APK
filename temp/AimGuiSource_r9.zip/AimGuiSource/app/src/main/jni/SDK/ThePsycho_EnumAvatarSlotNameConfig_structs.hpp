#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:10 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Enums
//---------------------By RIYAZ @RIYAZXERO---------------------------

#ifdef PF_MAX
#undef PF_MAX
#endif

// UserDefinedEnum EnumAvatarSlotNameConfig.EnumAvatarSlotNameConfig
enum class EnumAvatarSlotNameConfig : uint8_t
{
	EnumAvatarSlotNameConfig__NewEnumerator0 = 0,
	EnumAvatarSlotNameConfig__NewEnumerator1 = 1,
	EnumAvatarSlotNameConfig__NewEnumerator2 = 2,
	EnumAvatarSlotNameConfig__NewEnumerator4 = 3,
	EnumAvatarSlotNameConfig__NewEnumerator3 = 4,
	EnumAvatarSlotNameConfig__NewEnumerator5 = 5,
	EnumAvatarSlotNameConfig__NewEnumerator6 = 6,
	EnumAvatarSlotNameConfig__NewEnumerator7 = 7,
	EnumAvatarSlotNameConfig__EnumAvatarSlotNameConfig_MAX = 8
};



}

