#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:11 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_PickUpCountSetting_type.BP_STRUCT_PickUpCountSetting_type
// 0x0008
struct FBP_STRUCT_PickUpCountSetting_type
{
	int                                                ItemID_0_545B594077C2AB55279AB97B0BD162B4;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                PickUpMaxCount_1_7F45D10069EF87FA21D7CBCA0C4BDCD4;        // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

