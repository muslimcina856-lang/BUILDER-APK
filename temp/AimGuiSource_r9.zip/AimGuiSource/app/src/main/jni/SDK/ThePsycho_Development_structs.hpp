#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:02 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Enums
//---------------------By RIYAZ @RIYAZXERO---------------------------

#ifdef PF_MAX
#undef PF_MAX
#endif

// Enum Development.EImGuiWindowDisplayMode
enum class EImGuiWindowDisplayMode : uint8_t
{
	EImGuiWindowDisplayMode__Embedded = 0,
	EImGuiWindowDisplayMode__Standalone = 1,
	EImGuiWindowDisplayMode__EImGuiWindowDisplayMode_MAX = 2
};



//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// ScriptStruct Development.PropertyItemData
// 0x0028
struct FPropertyItemData
{
	struct FString                                     PropertyName;                                             // 0x0000(0x0010) (ZeroConstructor)
	class UEditableTextBox*                            EditableTextBox;                                          // 0x0010(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UWidget*                                     ContainerWidget;                                          // 0x0018(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UButton*                                     NameButton;                                               // 0x0020(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

}

