#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:06 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// UserDefinedStruct BP_STRUCT_AvatarWeaponHitFXData_type.BP_STRUCT_AvatarWeaponHitFXData_type
// 0x0014
struct FBP_STRUCT_AvatarWeaponHitFXData_type
{
	struct FString                                     EffectPath_0_10BE9D8007788EA45AF4C54C06DC3028;            // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_5D54EA4001CDCE7777865F5B044D7534;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

