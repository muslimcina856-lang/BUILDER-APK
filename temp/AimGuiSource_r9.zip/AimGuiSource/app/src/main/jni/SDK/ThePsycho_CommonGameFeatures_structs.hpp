#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:04 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// ScriptStruct CommonGameFeatures.RepControlGroupData
// 0x0050
struct FRepControlGroupData
{
	TMap<int64_t, int>                                 RepControlMap;                                            // 0x0000(0x0050) (ZeroConstructor)
};

}

