#pragma once

// SDK TOOL By  - @RIYAZXERO (4.6.0 -- 64Bit) SDK TOOL By RIYAZ @RIYAZXERO
// Telegram DM:- @RIYAZXERO
// File generation timeWed Sep 16 11:58:02 2026
 
namespace SDK
{
//---------------------By RIYAZ @RIYAZXERO---------------------------
//Script Structs
//---------------------By RIYAZ @RIYAZXERO---------------------------

// ScriptStruct JsonUtilities.JsonObjectWrapper
// 0x0020
struct FJsonObjectWrapper
{
	struct FString                                     jsonString;                                               // 0x0000(0x0010) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0010(0x0010) MISSED OFFSET
};

}

