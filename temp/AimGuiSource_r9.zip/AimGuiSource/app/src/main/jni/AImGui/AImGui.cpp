#include "AImGui.hpp"
#include "ANwCreator.hpp"
#include "ThePsycho/Font.h"

#include <android/log.h>

#define AIMGUI_TAG "AImGui"
#define AIMGUI_LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, AIMGUI_TAG, __VA_ARGS__)
#define AIMGUI_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, AIMGUI_TAG, __VA_ARGS__)

#ifndef EGL_OPENGL_ES3_BIT
#define EGL_OPENGL_ES3_BIT 0x00000040
#endif

namespace {
    struct TouchState {
        float x  = 0.0f;
        float y  = 0.0f;
        bool down = false;
    };

    TouchState g_Touch;
}

// Called from our input hook (see TouchHook.cpp below)
extern "C" void ImGui_SetTouchEvent(int action, float x, float y)
{
    int masked = action & AMOTION_EVENT_ACTION_MASK;

    switch (masked) {
        case AMOTION_EVENT_ACTION_DOWN:
        case AMOTION_EVENT_ACTION_POINTER_DOWN:
        case AMOTION_EVENT_ACTION_MOVE:
            g_Touch.down = true;
            g_Touch.x = x;
            g_Touch.y = y;
            break;

        case AMOTION_EVENT_ACTION_UP:
        case AMOTION_EVENT_ACTION_POINTER_UP:
        case AMOTION_EVENT_ACTION_CANCEL:
            g_Touch.down = false;
            g_Touch.x = x;
            g_Touch.y = y;
            break;

        default:
            break;
    }
}
// Short alias for JNI helper
using JNIEnvHelper = ::android::anwcreator::detail::jni::JNIEnvironment;

namespace android
{
    // --------------------------------------------------
    // Helper: get Activity window visibility
    //   returns:
    //     0   -> View.VISIBLE
    //     4   -> View.INVISIBLE
    //     8   -> View.GONE
    //    -1   -> error
    // --------------------------------------------------
    static int GetActivityWindowVisibility(ANativeActivity* activity)
    {
        if (!activity || !activity->vm || !activity->clazz)
            return -1;

        JNIEnvHelper jniEnv(activity->vm);
        if (!jniEnv.IsValid())
            return -1;

        JNIEnv* env = jniEnv;

        jobject activityObj = activity->clazz;
        jclass activityCls  = env->GetObjectClass(activityObj);
        if (!activityCls)
            return -1;

        jmethodID getWindow = env->GetMethodID(activityCls, "getWindow", "()Landroid/view/Window;");
        if (!getWindow)
            return -1;

        jobject windowObj = env->CallObjectMethod(activityObj, getWindow);
        if (!windowObj)
            return -1;

        jclass windowCls = env->GetObjectClass(windowObj);
        if (!windowCls)
        {
            env->DeleteLocalRef(windowObj);
            return -1;
        }

        jmethodID getDecorView = env->GetMethodID(windowCls, "getDecorView", "()Landroid/view/View;");
        if (!getDecorView)
        {
            env->DeleteLocalRef(windowCls);
            env->DeleteLocalRef(windowObj);
            return -1;
        }

        jobject decorView = env->CallObjectMethod(windowObj, getDecorView);
        if (!decorView)
        {
            env->DeleteLocalRef(windowCls);
            env->DeleteLocalRef(windowObj);
            return -1;
        }

        jclass viewCls = env->GetObjectClass(decorView);
        if (!viewCls)
        {
            env->DeleteLocalRef(decorView);
            env->DeleteLocalRef(windowCls);
            env->DeleteLocalRef(windowObj);
            return -1;
        }

        jmethodID getVisibility = env->GetMethodID(viewCls, "getWindowVisibility", "()I");
        if (!getVisibility)
        {
            env->DeleteLocalRef(viewCls);
            env->DeleteLocalRef(decorView);
            env->DeleteLocalRef(windowCls);
            env->DeleteLocalRef(windowObj);
            return -1;
        }

        jint visibility = env->CallIntMethod(decorView, getVisibility);

        env->DeleteLocalRef(viewCls);
        env->DeleteLocalRef(decorView);
        env->DeleteLocalRef(windowCls);
        env->DeleteLocalRef(windowObj);

        return static_cast<int>(visibility);
    }

    // ==================================================
    // AImGui implementation
    // ==================================================

    AImGui::AImGui(const Options &options)
        : m_options(options),
          m_secureRequested(options.skipScreenshot)
    {
        //AIMGUI_LOGD("Constructor: calling InitEnvironment()");
        InitEnvironment();
    }

    AImGui::~AImGui()
    {
        //AIMGUI_LOGD("Destructor: calling UnInitEnvironment()");
        UnInitEnvironment();
    }

    void AImGui::BeginFrame()
{
    // --- 1) Detect Activity window visibility changes ---
    static bool sVisibilityInitialized = false;
    static int  sLastVisibility        = -2; // -2 = uninitialized

    if (m_options.activity)
    {
        int vis = GetActivityWindowVisibility(m_options.activity);
        if (vis != -1)
        {
            if (!sVisibilityInitialized)
            {
                // First time: just record current visibility, don't recreate
                sLastVisibility        = vis;
                sVisibilityInitialized = true;
                AIMGUI_LOGD("Window visibility initial: %d", vis);
            }
            else if (vis != sLastVisibility)
            {
                AIMGUI_LOGD("Window visibility changed: %d -> %d", sLastVisibility, vis);

                // If we were NOT visible before, and now became VISIBLE (0),
                // then recreate overlay + EGL + ImGui.
                if (sLastVisibility != 0 && vis == 0)
                {
                    AIMGUI_LOGD("Window became VISIBLE -> recreate overlay (UnInit + Init)");
                    ReinitEnvironment();
                }

                sLastVisibility = vis;
            }
        }
    }

    // If init failed or not ready, retry instead of staying dead forever
    if (!m_state)
    {
        if (++m_recoverTicks >= 120)
        {
            m_recoverTicks = 0;
            AIMGUI_LOGD("Overlay not ready, retrying init");
            ReinitEnvironment();
        }

        if (!m_state)
            return;
    }
    else
    {
        m_recoverTicks = 0;
    }

    // --- 2) Force SurfaceControl visible / re-parent (ANwCreator side) ---
    if (m_options.activity && m_nativeWindow)
    {
        ANwCreator::EnsureVisible(m_options.activity, m_nativeWindow);
    }

    // --- 3) Sync touch state into ImGui IO ---
    if (m_imguiContext)
    {
        ImGui::SetCurrentContext(m_imguiContext);

        ImGuiIO& io = ImGui::GetIO();
        io.DisplaySize = ImVec2((float)m_screenWidth, (float)m_screenHeight);

        // Map our single finger to ImGui's "mouse"
        io.MousePos    = ImVec2(g_Touch.x, g_Touch.y);
        io.MouseDown[0] = g_Touch.down;
    }

    // --- 4) Normal ImGui frame setup ---
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
}

    void AImGui::EndFrame()
    {
        if (!m_state)
            return;

        ImGui::Render();
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        if (m_display == EGL_NO_DISPLAY || m_surface == EGL_NO_SURFACE)
        {
            //AIMGUI_LOGE("EndFrame: invalid EGL (display=%p surface=%p)", (void*)m_display, (void*)m_surface);
            return;
        }

        if (!eglSwapBuffers(m_display, m_surface))
        {
            EGLint err = eglGetError();
            //AIMGUI_LOGE("eglSwapBuffers failed: 0x%x", err);
            // If you want, you can add context loss handling here
        }
    }

    bool AImGui::InitEnvironment()
    {
        if (!m_options.activity)
        {
            //AIMGUI_LOGE("Invalid activity");
            //AIMGUI_LOGE("InitEnvironment: Invalid activity");
            return false;
        }

        ANwCreator::CreateOptions createOptions;
        createOptions.name           = "AImGui";
        createOptions.skipScreenshot = m_options.skipScreenshot;

        m_nativeWindow = ANwCreator::Create(m_options.activity, createOptions);
        if (!m_nativeWindow)
        {
            //AIMGUI_LOGE("ANativeWindow create failed");
            //AIMGUI_LOGE("InitEnvironment: ANativeWindow create failed");
            return false;
        }

        ANativeWindow_acquire(m_nativeWindow);
        //AIMGUI_LOGD("InitEnvironment: ANativeWindow created: %p", m_nativeWindow);

        auto displayInfo = ANwCreator::GetDisplayInfo(m_options.activity);
        m_screenWidth    = displayInfo.width;
        m_screenHeight   = displayInfo.height;
        //AIMGUI_LOGD("InitEnvironment: Display size: %d x %d", m_screenWidth, m_screenHeight);

        m_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        if (EGL_NO_DISPLAY == m_display)
        {
            EGLint err = eglGetError();
            //AIMGUI_LOGE("eglGetDisplay failed: %d", err);
            //AIMGUI_LOGE("eglGetDisplay failed: 0x%x", err);
            return false;
        }

        if (EGL_TRUE != eglInitialize(m_display, nullptr, nullptr))
        {
            EGLint err = eglGetError();
            //AIMGUI_LOGE("eglInitialize failed: %d", err);
            //AIMGUI_LOGE("eglInitialize failed: 0x%x", err);
            return false;
        }

        EGLint   numConfig = 0;
        EGLConfig config{};
        const EGLint attribs[] = {
            EGL_SURFACE_TYPE,    EGL_WINDOW_BIT,
            EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
            EGL_RED_SIZE,        8,
            EGL_GREEN_SIZE,      8,
            EGL_BLUE_SIZE,       8,
            EGL_ALPHA_SIZE,      8,
            EGL_DEPTH_SIZE,      24,
            EGL_STENCIL_SIZE,    8,
            EGL_SAMPLE_BUFFERS,  0,
            EGL_NONE};

        if (EGL_TRUE != eglChooseConfig(m_display, attribs, &config, 1, &numConfig))
        {
            EGLint err = eglGetError();
            //AIMGUI_LOGE("eglChooseConfig failed: %d", err);
            //AIMGUI_LOGE("eglChooseConfig failed: 0x%x", err);
            return false;
        }

        if (0 == numConfig)
        {
            //AIMGUI_LOGE("eglChooseConfig failed: Unsupported config");
            //AIMGUI_LOGE("eglChooseConfig: numConfig == 0");
            return false;
        }

        EGLint format;
        if (EGL_TRUE != eglGetConfigAttrib(m_display, config, EGL_NATIVE_VISUAL_ID, &format))
        {
            EGLint err = eglGetError();
            //AIMGUI_LOGE("eglGetConfigAttrib failed: %d", err);
            //AIMGUI_LOGE("eglGetConfigAttrib failed: 0x%x", err);
            return false;
        }

        ANativeWindow_setBuffersGeometry(m_nativeWindow, 0, 0, format);

        m_surface = eglCreateWindowSurface(m_display, config, m_nativeWindow, nullptr);
        if (EGL_NO_SURFACE == m_surface)
        {
            EGLint err = eglGetError();
            //AIMGUI_LOGE("eglCreateWindowSurface failed: %d", err);
            //AIMGUI_LOGE("eglCreateWindowSurface failed: 0x%x", err);
            return false;
        }
        //AIMGUI_LOGD("InitEnvironment: egl surface created: %p", m_surface);

        const EGLint contextAttribs[] = {
            EGL_CONTEXT_CLIENT_VERSION, 3,
            EGL_NONE};

        m_context = eglCreateContext(m_display, config, EGL_NO_CONTEXT, contextAttribs);
        if (EGL_NO_CONTEXT == m_context)
        {
            EGLint err = eglGetError();
            //AIMGUI_LOGE("eglCreateContext failed: %d", err);
            //AIMGUI_LOGE("eglCreateContext failed: 0x%x", err);
            return false;
        }
        //AIMGUI_LOGD("InitEnvironment: egl context created: %p", m_context);

        if (EGL_TRUE != eglMakeCurrent(m_display, m_surface, m_surface, m_context))
        {
            EGLint err = eglGetError();
            //AIMGUI_LOGE("eglMakeCurrent failed: %d", err);
            //AIMGUI_LOGE("eglMakeCurrent failed: 0x%x", err);
            return false;
        }
        //AIMGUI_LOGD("InitEnvironment: eglMakeCurrent OK");

        IMGUI_CHECKVERSION();

        m_imguiContext = ImGui::CreateContext();
        if (nullptr == m_imguiContext)
        {
            //AIMGUI_LOGE("ImGui create context failed");
            //AIMGUI_LOGE("InitEnvironment: ImGui CreateContext failed");
            return false;
        }

        ImGui::SetCurrentContext(m_imguiContext);
        //AIMGUI_LOGD("InitEnvironment: ImGui context created: %p", m_imguiContext);

        auto &io     = ImGui::GetIO();
        io.IniFilename = nullptr;

        ImGui::StyleColorsDark();
        ImGui::GetStyle().ScaleAllSizes(3.0f);

        ImFontConfig fontConfig;
        fontConfig.SizePixels = 22.0f;
        io.Fonts->AddFontDefault(&fontConfig);

        ImFontConfig rubikConfig;
        rubikConfig.SizePixels = 22.0f;
        rubikConfig.FontDataOwnedByAtlas = false;
        rubikConfig.OversampleH = 2;
        rubikConfig.OversampleV = 2;
        rubikConfig.PixelSnapH = true;
        ImFont* rubikFont = io.Fonts->AddFontFromMemoryTTF((void*)Custom, (int)sizeof(Custom), 22.0f, &rubikConfig);
        if (rubikFont)
            io.FontDefault = rubikFont;

        if (!ImGui_ImplAndroid_Init(m_nativeWindow))
        {
            //AIMGUI_LOGE("ImGui_ImplAndroid_Init failed");
            //AIMGUI_LOGE("InitEnvironment: ImGui_ImplAndroid_Init failed");
            return false;
        }
        //AIMGUI_LOGD("InitEnvironment: ImGui_ImplAndroid_Init OK");

        if (!ImGui_ImplOpenGL3_Init("#version 300 es"))
        {
            //AIMGUI_LOGE("ImGui_ImplOpenGL3_Init failed");
            //AIMGUI_LOGE("InitEnvironment: ImGui_ImplOpenGL3_Init failed");
            return false;
        }
        //AIMGUI_LOGD("InitEnvironment: ImGui_ImplOpenGL3_Init OK");

        glViewport(0, 0, m_screenWidth, m_screenHeight);
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

        //AIMGUI_LOGD("InitEnvironment: DONE (state=true)");
        return (m_state = true);
    }

    void AImGui::UnInitEnvironment()
    {
        //AIMGUI_LOGD("UnInitEnvironment: start (state=%d)", m_state);

        m_state = false;

        if (nullptr != m_imguiContext)
        {
            ImGui::SetCurrentContext(m_imguiContext);
            ImGui_ImplOpenGL3_Shutdown();
            ImGui_ImplAndroid_Shutdown();
            ImGui::DestroyContext(m_imguiContext);
            m_imguiContext = nullptr;
        }

        if (EGL_NO_DISPLAY != m_display)
        {
            eglMakeCurrent(m_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

            if (EGL_NO_CONTEXT != m_context)
            {
                eglDestroyContext(m_display, m_context);
                m_context = EGL_NO_CONTEXT;
            }

            if (EGL_NO_SURFACE != m_surface)
            {
                eglDestroySurface(m_display, m_surface);
                m_surface = EGL_NO_SURFACE;
            }

            eglTerminate(m_display);
            m_display = EGL_NO_DISPLAY;
        }

        if (nullptr != m_nativeWindow)
        {
            // First destroy the internal context (releases one ref)
            ANwCreator::Destroy(m_options.activity, m_nativeWindow);
            // Then release our local reference
            ANativeWindow_release(m_nativeWindow);
            m_nativeWindow = nullptr;
        }

    //AIMGUI_LOGD("UnInitEnvironment: end");
    }

    bool AImGui::ReinitEnvironment()
    {
        UnInitEnvironment();

        if (!InitEnvironment())
        {
            // Secure surface creation (Builder.setFlags) can fail on some devices.
            // Recover without the secure flag so the overlay never stays dead.
            AIMGUI_LOGD("InitEnvironment failed (skipScreenshot=%d), retrying without secure flag",
                        (int)m_options.skipScreenshot);

            m_options.skipScreenshot = false;
            UnInitEnvironment();

            if (!InitEnvironment())
                return false;
        }

        if (m_secureRequested && m_nativeWindow)
        {
            // Re-apply the capture-protection flag lost during re-creation.
            ANwCreator::SetSkipScreenshot(m_options.activity, m_nativeWindow, true);
        }

        return true;
    }

    void AImGui::SetSecureMode(bool enable)
    {
        if (m_secureRequested == enable)
            return;

        m_secureRequested = enable;

        // Never tear down / rebuild the overlay here: recreating EGL + ImGui
        // while the game is running made the overlay vanish and could crash
        // the host process. Apply the flag live on the existing surface.
        //
        // Use SKIP_SCREENSHOT (0x40), not SECURE (0x80): SECURE makes the whole
        // screen recording black; SKIP_SCREENSHOT hides only this overlay layer.
        if (m_state && m_nativeWindow)
            ANwCreator::SetSkipScreenshot(m_options.activity, m_nativeWindow, enable);
    }

} // namespace android
