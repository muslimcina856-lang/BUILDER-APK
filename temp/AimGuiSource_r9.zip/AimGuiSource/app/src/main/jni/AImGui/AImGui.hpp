#pragma once

#include <imgui/imgui.h>
#include <imgui/backends/imgui_impl_android.h>
#include <imgui/backends/imgui_impl_opengl3.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/native_window.h>
#include <android/native_activity.h>
#include <string>

namespace android
{
    class AImGui
    {
    public:
        struct Options
        {
            ANativeActivity *activity = nullptr;
            bool skipScreenshot = true;
        };

    public:
        AImGui() : AImGui(Options{}) {}
        AImGui(const Options &options);
        ~AImGui();

        void BeginFrame();
        void EndFrame();
        void SetSecureMode(bool enable);

        constexpr operator bool() const
        {
            return m_state;
        }

    private:
        bool InitEnvironment();
        bool ReinitEnvironment();
        void UnInitEnvironment();

    private:
        bool m_state = false;
        bool m_secureRequested = false;
        int32_t m_recoverTicks = 0;
        int32_t m_screenWidth = -1;
        int32_t m_screenHeight = -1;
        Options m_options;

        ANativeWindow *m_nativeWindow = nullptr;
        EGLDisplay m_display = EGL_NO_DISPLAY;
        EGLSurface m_surface = EGL_NO_SURFACE;
        EGLContext m_context = EGL_NO_CONTEXT;
        ImGuiContext *m_imguiContext = nullptr;
    };

} // namespace android
