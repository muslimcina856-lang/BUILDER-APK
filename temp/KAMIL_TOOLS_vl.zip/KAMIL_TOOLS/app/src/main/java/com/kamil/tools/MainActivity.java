package com.kamil.tools;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements OptimizerService.ResultListener {

    // Core helper classes
    private DeviceAnalyzer deviceAnalyzer;
    private SensitivityGenerator sensitivityGenerator;
    private GameLauncher gameLauncher;

    private DeviceAnalyzer.DeviceInfo currentDeviceInfo;

    // Views - device card
    private TextView tvDeviceName, tvDeviceStatus, tvRefreshRate, tvRam, tvDpi, tvResolution, tvScoreValue;

    // Views - two action buttons
    private View btnAiSensitivity, btnBestOptimizer, btnLoginFf;
    private ImageView ivGameIcon;
    private TextView tvGameName, tvGameStatus, tvChangeGame, tvLogout;

    // Views - sensitivity result card
    private View containerSensitivityResult;
    private TextView tvSensRedDotLabel, tvSensRedDotValue;
    private TextView tvSens2xLabel, tvSens2xValue;
    private TextView tvSens4xLabel, tvSens4xValue;
    private TextView tvSensSniperLabel, tvSensSniperValue;
    private TextView tvSensFreeLookLabel, tvSensFreeLookValue;
    private TextView tvSensGeneralLabel, tvSensGeneralValue;
    private Button btnApplySensitivity;

    private SensitivityGenerator.SensitivityResult lastSensitivityResult;

    // RecyclerView
    private RecyclerView rvFeatures;
    private FeatureAdapter featureAdapter;
    private final List<Feature> featureList = new ArrayList<>();

    // Crosshair state
    private String crosshairShape = "Dot";
    private String crosshairColor = "Biru Elegan";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        deviceAnalyzer = new DeviceAnalyzer(this);
        sensitivityGenerator = new SensitivityGenerator();
        gameLauncher = new GameLauncher(this);

        bindViews();
        loadDeviceInfo();
        setupFeatureList();
        setupActionButtons();
        refreshGameStatus();

        OptimizerService.setResultListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        OptimizerService.setResultListener(null);
    }

    // ---------------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------------

    private void bindViews() {
        tvDeviceName = findViewById(R.id.tvDeviceName);
        tvDeviceStatus = findViewById(R.id.tvDeviceStatus);
        tvRefreshRate = findViewById(R.id.tvRefreshRate);
        tvRam = findViewById(R.id.tvRam);
        tvDpi = findViewById(R.id.tvDpi);
        tvResolution = findViewById(R.id.tvResolution);
        tvScoreValue = findViewById(R.id.tvScoreValue);

        btnAiSensitivity = findViewById(R.id.btnAiSensitivity);
        btnBestOptimizer = findViewById(R.id.btnBestOptimizer);
        btnLoginFf = findViewById(R.id.btnLoginFf);
        ivGameIcon = findViewById(R.id.ivGameIcon);
        tvGameName = findViewById(R.id.tvGameName);
        tvGameStatus = findViewById(R.id.tvGameStatus);
        tvChangeGame = findViewById(R.id.tvChangeGame);
        tvLogout = findViewById(R.id.tvLogout);

        containerSensitivityResult = findViewById(R.id.containerSensitivityResult);

        View sensInclude = findViewById(R.id.includeSensitivityResult);

        View itemRedDot = sensInclude.findViewById(R.id.itemRedDot);
        View item2x = sensInclude.findViewById(R.id.item2x);
        View item4x = sensInclude.findViewById(R.id.item4x);
        View itemSniper = sensInclude.findViewById(R.id.itemSniper);
        View itemFreeLook = sensInclude.findViewById(R.id.itemFreeLook);
        View itemGeneral = sensInclude.findViewById(R.id.itemGeneral);

        tvSensRedDotLabel = itemRedDot.findViewById(R.id.tvSensLabel);
        tvSensRedDotValue = itemRedDot.findViewById(R.id.tvSensValue);
        tvSens2xLabel = item2x.findViewById(R.id.tvSensLabel);
        tvSens2xValue = item2x.findViewById(R.id.tvSensValue);
        tvSens4xLabel = item4x.findViewById(R.id.tvSensLabel);
        tvSens4xValue = item4x.findViewById(R.id.tvSensValue);
        tvSensSniperLabel = itemSniper.findViewById(R.id.tvSensLabel);
        tvSensSniperValue = itemSniper.findViewById(R.id.tvSensValue);
        tvSensFreeLookLabel = itemFreeLook.findViewById(R.id.tvSensLabel);
        tvSensFreeLookValue = itemFreeLook.findViewById(R.id.tvSensValue);
        tvSensGeneralLabel = itemGeneral.findViewById(R.id.tvSensLabel);
        tvSensGeneralValue = itemGeneral.findViewById(R.id.tvSensValue);

        tvSensRedDotLabel.setText(R.string.sens_red_dot);
        tvSens2xLabel.setText(R.string.sens_2x);
        tvSens4xLabel.setText(R.string.sens_4x);
        tvSensSniperLabel.setText(R.string.sens_sniper);
        tvSensFreeLookLabel.setText(R.string.sens_free_look);
        tvSensGeneralLabel.setText(R.string.sens_general);

        btnApplySensitivity = sensInclude.findViewById(R.id.btnApplySensitivity);

        rvFeatures = findViewById(R.id.rvFeatures);
    }

    private void loadDeviceInfo() {
        currentDeviceInfo = deviceAnalyzer.analyze();

        tvDeviceName.setText(currentDeviceInfo.deviceName);
        tvDeviceStatus.setText(R.string.device_status_detected);
        tvRefreshRate.setText(deviceAnalyzer.formatRefreshRate(currentDeviceInfo.refreshRate));
        tvRam.setText(deviceAnalyzer.formatRam(currentDeviceInfo.totalRamBytes));
        tvDpi.setText(String.valueOf(currentDeviceInfo.dpi));
        tvResolution.setText(deviceAnalyzer.formatResolution(currentDeviceInfo.widthPx, currentDeviceInfo.heightPx));
        tvScoreValue.setText(String.valueOf(currentDeviceInfo.performanceScore));
    }

    private void setupFeatureList() {
        String[] ids = getResources().getStringArray(R.array.feature_ids);
        String[] titles = getResources().getStringArray(R.array.feature_titles);
        String[] subtitles = getResources().getStringArray(R.array.feature_subtitles);

        featureList.clear();
        for (int i = 0; i < ids.length; i++) {
            featureList.add(new Feature(ids[i], titles[i], subtitles[i]));
        }

        featureAdapter = new FeatureAdapter(featureList, this::handleFeatureGenerate);
        rvFeatures.setLayoutManager(new LinearLayoutManager(this));
        rvFeatures.setAdapter(featureAdapter);
    }

    private void setupActionButtons() {
        btnAiSensitivity.setOnClickListener(v -> generateSensitivity());
        btnBestOptimizer.setOnClickListener(v -> runBestOptimizer());
        btnApplySensitivity.setOnClickListener(v -> applySensitivity());

        // Tap baris game -> auto-launch versi FF yang terdeteksi terpasang.
        btnLoginFf.setOnClickListener(v -> autoLaunchGame());
        // Tap "Ganti versi" -> buka dialog pilih Free Fire / Free Fire MAX manual.
        tvChangeGame.setOnClickListener(v -> showLoginFfDialog());

        tvLogout.setOnClickListener(v -> logout());
    }

    // ---------------------------------------------------------------------
    // Game status & auto-launch
    // ---------------------------------------------------------------------

    private void refreshGameStatus() {
        GameLauncher.GameOption detected = gameLauncher.detectInstalled();
        GameLauncher.GameOption toShow = detected != null ? detected : GameLauncher.GameOption.FREE_FIRE;

        tvGameName.setText(gameLauncher.getInstalledLabel(toShow));

        Drawable icon = gameLauncher.getInstalledIcon(toShow);
        if (icon != null) {
            ivGameIcon.setImageDrawable(icon);
        } else {
            ivGameIcon.setImageResource(R.drawable.ic_game_placeholder);
        }

        if (detected != null) {
            tvGameStatus.setText(R.string.login_ff_desc_installed);
        } else {
            tvGameStatus.setText(R.string.login_ff_desc_not_installed);
        }
    }

    private void autoLaunchGame() {
        gameLauncher.launchAuto();
    }

    private void logout() {
        SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        prefs.edit().clear().apply();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameLauncher != null && tvGameStatus != null) {
            refreshGameStatus();
        }
    }

    // ---------------------------------------------------------------------
    // Feature dispatch
    // ---------------------------------------------------------------------

    private void handleFeatureGenerate(Feature feature, int position) {
        switch (feature.getId()) {
            case "easy_drag":
                startOptimize(OptimizerService.MODE_EASY_DRAG, "Easy Drag 95%");
                break;
            case "surfaceflinger":
                startOptimize(OptimizerService.MODE_SURFACEFLINGER, "SurfaceFlinger Boost");
                break;
            case "func_sensitivity":
                generateSensitivity();
                break;
            case "stable_aim":
                startOptimize(OptimizerService.MODE_STABLE_AIM, "Stable Aim");
                break;
            case "boost_fps":
                startOptimize(OptimizerService.MODE_BOOST_FPS, "Boost FPS 120");
                break;
            case "monitoring_rog":
                showMonitoringDialog();
                break;
            case "crosshair":
                showCrosshairDialog();
                break;
            case "optimize_system":
                startOptimize(OptimizerService.MODE_OPTIMIZE_SYSTEM, "Optimize System");
                break;
            case "aiming_drag":
                startOptimize(OptimizerService.MODE_AIMING_DRAG, "AimingDrag");
                break;
            case "sensi_ai":
                runSensiAi();
                break;
            case "touch_booster":
                startOptimize(OptimizerService.MODE_TOUCH_BOOSTER, "Touch Response Booster");
                break;
            case "network_priority":
                startOptimize(OptimizerService.MODE_NETWORK_PRIORITY, "Network Priority");
                break;
            case "battery_boost":
                startOptimize(OptimizerService.MODE_BATTERY_BOOST, "Battery Efficiency Boost");
                break;
            case "gpu_render":
                startOptimize(OptimizerService.MODE_GPU_RENDER, "GPU Render Booster");
                break;
            default:
                Toast.makeText(this, feature.getTitle() + " diterapkan", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    // ---------------------------------------------------------------------
    // Optimizer
    // ---------------------------------------------------------------------

    private void startOptimize(String mode, String label) {
        Toast.makeText(this, "Menjalankan " + label + "...", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, OptimizerService.class);
        intent.putExtra(OptimizerService.EXTRA_MODE, mode);
        startService(intent);
    }

    private void runBestOptimizer() {
        Toast.makeText(this, "Menjalankan One Click Optimization...", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, OptimizerService.class);
        intent.putExtra(OptimizerService.EXTRA_MODE, OptimizerService.MODE_ALL);
        startService(intent);
    }

    @Override
    public void onOptimizeFinished(String mode, boolean success) {
        mainHandler.post(() -> {
            String msg = success
                    ? "Optimasi berhasil diterapkan"
                    : "Optimasi selesai (sebagian memerlukan akses root)";
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        });
    }

    // ---------------------------------------------------------------------
    // Sensitivity
    // ---------------------------------------------------------------------

    private void generateSensitivity() {
        lastSensitivityResult = sensitivityGenerator.generate(
                currentDeviceInfo.performanceScore, currentDeviceInfo.refreshRate);

        tvSensRedDotValue.setText(String.valueOf(lastSensitivityResult.redDot));
        tvSens2xValue.setText(String.valueOf(lastSensitivityResult.scope2x));
        tvSens4xValue.setText(String.valueOf(lastSensitivityResult.scope4x));
        tvSensSniperValue.setText(String.valueOf(lastSensitivityResult.sniper));
        tvSensFreeLookValue.setText(String.valueOf(lastSensitivityResult.freeLook));
        tvSensGeneralValue.setText(String.valueOf(lastSensitivityResult.general));

        containerSensitivityResult.setVisibility(View.VISIBLE);

        Toast.makeText(this, "AI Sensitivity berhasil dibuat", Toast.LENGTH_SHORT).show();
    }

    private void applySensitivity() {
        if (lastSensitivityResult == null) {
            Toast.makeText(this, "Generate sensitivity terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Sensitivity diterapkan (98% Accuracy)", Toast.LENGTH_SHORT).show();
    }

    private void runSensiAi() {
        int value = sensitivityGenerator.generateSensiAi(
                currentDeviceInfo.performanceScore, currentDeviceInfo.totalRamBytes);
        Toast.makeText(this, "SensiAi Rekomendasi: " + value + " / 200", Toast.LENGTH_LONG).show();
    }

    // ---------------------------------------------------------------------
    // Dialogs
    // ---------------------------------------------------------------------

    private void showMonitoringDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_monitoring, null);
        TextView tvCpu = view.findViewById(R.id.tvCpuInfo);
        TextView tvGpu = view.findViewById(R.id.tvGpuInfo);
        TextView tvRamUsage = view.findViewById(R.id.tvRamInfo);
        TextView tvTemp = view.findViewById(R.id.tvTempInfo);
        Button btnClose = view.findViewById(R.id.btnCloseMonitoring);

        MonitoringHelper monitoringHelper = new MonitoringHelper(this);
        MonitoringHelper.Snapshot snapshot = monitoringHelper.getSnapshot();

        tvCpu.setText("CPU Usage: " + snapshot.cpuUsagePercent + "%");
        tvGpu.setText("GPU Render: " + snapshot.gpuRenderer);
        tvRamUsage.setText("RAM Used: " + snapshot.usedRamGb + " / " + snapshot.totalRamGb + " GB");
        tvTemp.setText("Battery Temp: " + snapshot.batteryTempCelsius + "°C");

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(view)
                .create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
        btnClose.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showCrosshairDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_crosshair, null);
        Spinner spinnerShape = view.findViewById(R.id.spinnerShape);
        Spinner spinnerColor = view.findViewById(R.id.spinnerColor);
        Button btnSave = view.findViewById(R.id.btnSaveCrosshair);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(view)
                .create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        btnSave.setOnClickListener(v -> {
            crosshairShape = spinnerShape.getSelectedItem().toString();
            crosshairColor = spinnerColor.getSelectedItem().toString();
            Toast.makeText(this, "Crosshair: " + crosshairShape + " - " + crosshairColor, Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();
    }

    /** Dipanggil dari item fitur "Menu Login FF" jika ditambahkan sebagai tombol terpisah. */
    private void showLoginFfDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_login_ff, null);
        RadioGroup radioGroup = view.findViewById(R.id.radioGroupGame);
        Button btnLaunch = view.findViewById(R.id.btnLaunchGame);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(view)
                .create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        btnLaunch.setOnClickListener(v -> {
            int checkedId = radioGroup.getCheckedRadioButtonId();
            GameLauncher.GameOption option = checkedId == R.id.radioFFMax
                    ? GameLauncher.GameOption.FREE_FIRE_MAX
                    : GameLauncher.GameOption.FREE_FIRE;
            gameLauncher.launch(option);
            dialog.dismiss();
            refreshGameStatus();
        });

        dialog.show();
    }
}
