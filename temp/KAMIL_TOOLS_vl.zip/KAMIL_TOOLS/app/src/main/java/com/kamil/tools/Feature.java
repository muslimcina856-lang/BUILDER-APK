package com.kamil.tools;

/**
 * Model sederhana untuk merepresentasikan satu fitur pada daftar RecyclerView.
 */
public class Feature {

    private final String id;
    private final String title;
    private final String subtitle;
    private boolean generated;

    public Feature(String id, String title, String subtitle) {
        this.id = id;
        this.title = title;
        this.subtitle = subtitle;
        this.generated = false;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public boolean isGenerated() {
        return generated;
    }

    public void setGenerated(boolean generated) {
        this.generated = generated;
    }
}
