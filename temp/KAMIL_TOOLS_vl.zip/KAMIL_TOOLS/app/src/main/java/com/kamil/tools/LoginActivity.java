package com.kamil.tools;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Halaman login berbasis access key saja (tanpa username/password).
 * Key valid dikonfigurasi di res/values/arrays.xml (valid_access_keys).
 * Status login disimpan di SharedPreferences supaya user tidak perlu
 * login ulang setiap membuka app.
 */
public class LoginActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "kamil_tools_prefs";
    public static final String KEY_IS_LOGGED_IN = "is_logged_in";
    public static final String KEY_ACCESS_KEY = "access_key";

    private EditText etAccessKey;
    private TextView tvLoginError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (isAlreadyLoggedIn()) {
            goToMain();
            return;
        }

        setContentView(R.layout.activity_login);

        etAccessKey = findViewById(R.id.etAccessKey);
        tvLoginError = findViewById(R.id.tvLoginError);
        Button btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> attemptLogin());
    }

    private boolean isAlreadyLoggedIn() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    private void attemptLogin() {
        String input = etAccessKey.getText().toString().trim();

        if (TextUtils.isEmpty(input)) {
            showError(getString(R.string.login_error_empty));
            return;
        }

        if (isValidKey(input)) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                    .putBoolean(KEY_IS_LOGGED_IN, true)
                    .putString(KEY_ACCESS_KEY, input)
                    .apply();
            goToMain();
        } else {
            showError(getString(R.string.login_error_invalid));
        }
    }

    private boolean isValidKey(String input) {
        String[] validKeys = getResources().getStringArray(R.array.valid_access_keys);
        for (String key : validKeys) {
            if (key.equalsIgnoreCase(input)) {
                return true;
            }
        }
        return false;
    }

    private void showError(String message) {
        tvLoginError.setText(message);
        tvLoginError.setVisibility(View.VISIBLE);
    }

    private void goToMain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
