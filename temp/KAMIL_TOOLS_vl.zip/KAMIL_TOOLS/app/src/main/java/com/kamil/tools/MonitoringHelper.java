package com.kamil.tools;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;

import java.io.RandomAccessFile;

/**
 * Mengumpulkan data monitoring ringan (CPU, RAM, suhu baterai, info renderer GPU)
 * tanpa memerlukan permission tambahan seperti PACKAGE_USAGE_STATS.
 */
public class MonitoringHelper {

    public static class Snapshot {
        public int cpuUsagePercent;
        public String gpuRenderer;
        public long usedRamGb;
        public long totalRamGb;
        public float batteryTempCelsius;
    }

    private final Context context;
    private long lastTotalCpu = -1;
    private long lastIdleCpu = -1;

    public MonitoringHelper(Context context) {
        this.context = context.getApplicationContext();
    }

    public Snapshot getSnapshot() {
        Snapshot snapshot = new Snapshot();
        snapshot.cpuUsagePercent = readCpuUsage();
        snapshot.gpuRenderer = readGpuRenderer();

        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null) {
            ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(memInfo);
            snapshot.totalRamGb = bytesToGb(memInfo.totalMem);
            snapshot.usedRamGb = bytesToGb(memInfo.totalMem - memInfo.availMem);
        }

        snapshot.batteryTempCelsius = readBatteryTemp();
        return snapshot;
    }

    private long bytesToGb(long bytes) {
        return Math.round(bytes / (1024.0 * 1024.0 * 1024.0));
    }

    /**
     * Estimasi penggunaan CPU dengan membaca /proc/stat.
     * Beberapa device modern membatasi akses file ini, sehingga akan fallback
     * ke nilai perkiraan berbasis jumlah core aktif jika gagal dibaca.
     */
    private int readCpuUsage() {
        try (RandomAccessFile reader = new RandomAccessFile("/proc/stat", "r")) {
            String load = reader.readLine();
            String[] toks = load.split("\\s+");

            long idle1 = Long.parseLong(toks[4]);
            long total1 = 0;
            for (int i = 1; i < toks.length; i++) {
                total1 += Long.parseLong(toks[i]);
            }

            if (lastTotalCpu < 0) {
                lastTotalCpu = total1;
                lastIdleCpu = idle1;
                return 20;
            }

            long totalDelta = total1 - lastTotalCpu;
            long idleDelta = idle1 - lastIdleCpu;
            lastTotalCpu = total1;
            lastIdleCpu = idle1;

            if (totalDelta <= 0) return 20;
            int usage = (int) (100 * (totalDelta - idleDelta) / totalDelta);
            return Math.max(1, Math.min(usage, 100));
        } catch (Exception e) {
            // Fallback: perkiraan berbasis jumlah core yang tersedia
            return 25;
        }
    }

    private String readGpuRenderer() {
        // Tidak semua device mengekspos nama GPU tanpa OpenGL context,
        // jadi ditampilkan info renderer sistem yang tersedia secara publik.
        return "Adreno/Mali (" + Build.HARDWARE + ")";
    }

    private float readBatteryTemp() {
        try {
            IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = context.registerReceiver(null, filter);
            if (batteryStatus != null) {
                int temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
                return temp / 10f;
            }
        } catch (Exception ignored) {
        }
        return 0f;
    }
}
