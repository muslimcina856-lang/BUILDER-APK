package com.kamil.tools;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Service ringan yang menjalankan sekumpulan perintah "setprop" untuk fitur
 * optimasi sistem (bukan modifikasi memori game / cheat engine).
 *
 * Catatan: pada device non-root, sebagian besar system property bersifat
 * read-only sehingga eksekusi setprop bisa gagal secara diam-diam. Service ini
 * tetap mencoba menjalankannya dan melaporkan hasil lewat callback/broadcast
 * sederhana ke Activity melalui listener statis.
 */
public class OptimizerService extends Service {

    private static final String TAG = "OptimizerService";
    public static final String EXTRA_MODE = "extra_mode";

    public static final String MODE_EASY_DRAG = "easy_drag";
    public static final String MODE_SURFACEFLINGER = "surfaceflinger";
    public static final String MODE_STABLE_AIM = "stable_aim";
    public static final String MODE_BOOST_FPS = "boost_fps";
    public static final String MODE_OPTIMIZE_SYSTEM = "optimize_system";
    public static final String MODE_AIMING_DRAG = "aiming_drag";
    public static final String MODE_TOUCH_BOOSTER = "touch_booster";
    public static final String MODE_NETWORK_PRIORITY = "network_priority";
    public static final String MODE_BATTERY_BOOST = "battery_boost";
    public static final String MODE_GPU_RENDER = "gpu_render";
    public static final String MODE_ALL = "all";

    public interface ResultListener {
        void onOptimizeFinished(String mode, boolean success);
    }

    private static ResultListener resultListener;

    public static void setResultListener(ResultListener listener) {
        resultListener = listener;
    }

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String mode = intent != null ? intent.getStringExtra(EXTRA_MODE) : MODE_ALL;
        if (mode == null) mode = MODE_ALL;
        final String finalMode = mode;

        new Thread(() -> {
            boolean success = runOptimization(finalMode);
            mainHandler.post(() -> {
                if (resultListener != null) {
                    resultListener.onOptimizeFinished(finalMode, success);
                }
                stopSelf();
            });
        }).start();

        return START_NOT_STICKY;
    }

    private boolean runOptimization(String mode) {
        boolean allOk = true;
        switch (mode) {
            case MODE_EASY_DRAG:
                allOk &= exec("setprop debug.easy_drag.level 95");
                allOk &= exec("setprop debug.input.sensitivity high");
                break;
            case MODE_SURFACEFLINGER:
                allOk &= exec("setprop debug.sf.latch_unsignaled 1");
                allOk &= exec("setprop debug.sf.hw 1");
                break;
            case MODE_STABLE_AIM:
                allOk &= exec("setprop debug.stable_aim.enable 1");
                allOk &= exec("setprop debug.input.smooth_touch 1");
                break;
            case MODE_BOOST_FPS:
                allOk &= exec("setprop debug.fps.target 120");
                allOk &= exec("setprop debug.graphics.max_frame_rate 120");
                break;
            case MODE_AIMING_DRAG:
                allOk &= exec("setprop debug.aiming_drag.optimize 1");
                allOk &= exec("setprop debug.input.drag_smooth 1");
                break;
            case MODE_TOUCH_BOOSTER:
                allOk &= exec("setprop debug.touch.samplerate high");
                break;
            case MODE_NETWORK_PRIORITY:
                allOk &= exec("setprop debug.net.game_priority 1");
                break;
            case MODE_BATTERY_BOOST:
                allOk &= exec("setprop debug.power.game_mode 1");
                break;
            case MODE_GPU_RENDER:
                allOk &= exec("setprop debug.hwui.renderer skiagl");
                allOk &= exec("setprop debug.egl.hw 1");
                break;
            case MODE_OPTIMIZE_SYSTEM:
                allOk &= exec("setprop debug.sys.game_priority high");
                allOk &= exec("setprop debug.sys.thermal_headroom 1");
                allOk &= exec("trim caches: freeing background memory");
                break;
            case MODE_ALL:
            default:
                allOk &= runOptimization(MODE_EASY_DRAG);
                allOk &= runOptimization(MODE_SURFACEFLINGER);
                allOk &= runOptimization(MODE_STABLE_AIM);
                allOk &= runOptimization(MODE_BOOST_FPS);
                allOk &= runOptimization(MODE_AIMING_DRAG);
                allOk &= runOptimization(MODE_TOUCH_BOOSTER);
                allOk &= runOptimization(MODE_NETWORK_PRIORITY);
                allOk &= runOptimization(MODE_BATTERY_BOOST);
                allOk &= runOptimization(MODE_GPU_RENDER);
                allOk &= runOptimization(MODE_OPTIMIZE_SYSTEM);
                break;
        }
        return allOk;
    }

    /**
     * Menjalankan satu baris perintah shell (setprop) via Runtime.exec.
     * Pada device tanpa akses root, perintah ini umumnya akan gagal dengan
     * exit code != 0 karena keterbatasan izin sistem — hal ini normal dan
     * ditangani dengan aman (tidak menyebabkan crash).
     */
    private boolean exec(String command) {
        // Baris komentar biasa (bukan perintah shell) hanya untuk logging pesan status
        if (command.startsWith("trim caches")) {
            Log.d(TAG, command);
            return true;
        }
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while (reader.readLine() != null) {
                // drain stream
            }
            int exitCode = process.waitFor();
            Log.d(TAG, "exec: " + command + " -> exit=" + exitCode);
            return exitCode == 0;
        } catch (IOException | InterruptedException e) {
            Log.w(TAG, "Gagal menjalankan: " + command + " (" + e.getMessage() + ")");
            return false;
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
    }
}
