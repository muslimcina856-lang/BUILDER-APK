package com.kamil.tools;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.Toast;

/**
 * Membantu membuka aplikasi Free Fire / Free Fire MAX yang sudah terpasang.
 * Jika belum terpasang, arahkan ke Play Store.
 *
 * Icon & nama aplikasi yang ditampilkan di UI diambil langsung dari aplikasi
 * Free Fire yang benar-benar terpasang di device (via PackageManager), bukan
 * aset logo yang ditanam di dalam app ini.
 */
public class GameLauncher {

    public static final String PACKAGE_FREE_FIRE = "com.dts.freefireth";
    public static final String PACKAGE_FREE_FIRE_MAX = "com.dts.freefiremax";

    private final Context context;

    public GameLauncher(Context context) {
        this.context = context.getApplicationContext();
    }

    public enum GameOption {
        FREE_FIRE,
        FREE_FIRE_MAX
    }

    public String packageOf(GameOption option) {
        return option == GameOption.FREE_FIRE ? PACKAGE_FREE_FIRE : PACKAGE_FREE_FIRE_MAX;
    }

    public void launch(GameOption option) {
        String packageName = packageOf(option);

        if (isPackageInstalled(packageName)) {
            Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage(packageName);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launchIntent);
                return;
            }
        }
        openPlayStore(packageName);
    }

    /**
     * Deteksi otomatis versi Free Fire yang terpasang di device (prioritas:
     * Free Fire reguler, lalu Free Fire MAX). Null jika tidak ada yang terpasang.
     */
    public GameOption detectInstalled() {
        if (isPackageInstalled(PACKAGE_FREE_FIRE)) return GameOption.FREE_FIRE;
        if (isPackageInstalled(PACKAGE_FREE_FIRE_MAX)) return GameOption.FREE_FIRE_MAX;
        return null;
    }

    /**
     * Tombol "otomatis": langsung membuka versi Free Fire yang terdeteksi
     * terpasang. Jika belum ada yang terpasang, arahkan ke Play Store
     * Free Fire (versi reguler).
     */
    public void launchAuto() {
        GameOption detected = detectInstalled();
        if (detected != null) {
            launch(detected);
        } else {
            openPlayStore(PACKAGE_FREE_FIRE);
        }
    }

    public boolean isPackageInstalled(String packageName) {
        try {
            context.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /** Ambil icon asli aplikasi FF yang terpasang di device (bukan aset internal). */
    public Drawable getInstalledIcon(GameOption option) {
        String packageName = packageOf(option);
        try {
            ApplicationInfo appInfo = context.getPackageManager().getApplicationInfo(packageName, 0);
            return context.getPackageManager().getApplicationIcon(appInfo);
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    /** Ambil label asli aplikasi FF yang terpasang di device. */
    public String getInstalledLabel(GameOption option) {
        String packageName = packageOf(option);
        try {
            ApplicationInfo appInfo = context.getPackageManager().getApplicationInfo(packageName, 0);
            return context.getPackageManager().getApplicationLabel(appInfo).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return option == GameOption.FREE_FIRE ? "Free Fire" : "Free Fire MAX";
        }
    }

    private void openPlayStore(String packageName) {
        Toast.makeText(context, "Game belum terpasang, membuka Play Store...", Toast.LENGTH_SHORT).show();
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
    }
}
