package com.kamil.tools;

import java.util.Random;

/**
 * Menghasilkan nilai sensitivity (0-200) untuk tiap mode scope berdasarkan
 * skor performa device (dari DeviceAnalyzer) dan sedikit variasi acak
 * agar terasa "personal" untuk tiap generate (fitur SensiAi).
 */
public class SensitivityGenerator {

    public static class SensitivityResult {
        public int general;
        public int redDot;
        public int scope2x;
        public int scope4x;
        public int sniper;
        public int freeLook;
    }

    private final Random random = new Random();

    /**
     * @param performanceScore skor 0-100 dari DeviceAnalyzer
     * @param refreshRate      refresh rate layar device
     */
    public SensitivityResult generate(int performanceScore, float refreshRate) {
        SensitivityResult result = new SensitivityResult();

        // Base value dipengaruhi skor performa + refresh rate device
        int base = clamp((int) (performanceScore * 1.4 + refreshRate * 0.3), 60, 200);

        result.general = clamp(base + variance(6), 0, 200);
        result.redDot = clamp((int) (base * 0.95) + variance(6), 0, 200);
        result.scope2x = clamp((int) (base * 0.80) + variance(6), 0, 200);
        result.scope4x = clamp((int) (base * 0.65) + variance(5), 0, 200);
        result.sniper = clamp((int) (base * 0.45) + variance(4), 0, 200);
        result.freeLook = clamp((int) (base * 1.05) + variance(6), 0, 200);

        return result;
    }

    /**
     * SensiAi: generate sensitivity umum tunggal 0-200 murni berdasarkan spek HP,
     * dipakai sebagai rekomendasi cepat tanpa breakdown per mode.
     */
    public int generateSensiAi(int performanceScore, long ramBytes) {
        double ramGb = ramBytes / (1024.0 * 1024.0 * 1024.0);
        int value = (int) (performanceScore * 1.2 + Math.min(ramGb, 12) * 4);
        return clamp(value + variance(8), 0, 200);
    }

    private int variance(int range) {
        return random.nextInt(range * 2 + 1) - range;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
