package com.kamil.tools;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

/**
 * Mengumpulkan informasi spesifikasi perangkat (refresh rate, RAM, DPI, resolusi)
 * dan menghitung skor performa perkiraan (heuristik sederhana, bukan benchmark nyata).
 */
public class DeviceAnalyzer {

    public static class DeviceInfo {
        public String deviceName;
        public float refreshRate;
        public long totalRamBytes;
        public int dpi;
        public int widthPx;
        public int heightPx;
        public int performanceScore;
    }

    private final Context context;

    public DeviceAnalyzer(Context context) {
        this.context = context.getApplicationContext();
    }

    public DeviceInfo analyze() {
        DeviceInfo info = new DeviceInfo();

        info.deviceName = buildDeviceName();

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        float refreshRate = 60f;
        if (wm != null) {
            Display display = wm.getDefaultDisplay();
            display.getRealMetrics(metrics);
            refreshRate = display.getRefreshRate();
        } else {
            metrics = context.getResources().getDisplayMetrics();
        }

        info.refreshRate = refreshRate;
        info.dpi = metrics.densityDpi;
        info.widthPx = metrics.widthPixels;
        info.heightPx = metrics.heightPixels;

        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        long totalRam = 0;
        if (am != null) {
            ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(memInfo);
            totalRam = memInfo.totalMem;
        }
        info.totalRamBytes = totalRam;

        info.performanceScore = calculateScore(info);

        return info;
    }

    private String buildDeviceName() {
        String manufacturer = Build.MANUFACTURER == null ? "UNKNOWN" : Build.MANUFACTURER.toUpperCase();
        String model = Build.MODEL == null ? "DEVICE" : Build.MODEL.toUpperCase().replace(" ", "_");
        return manufacturer + "_" + model;
    }

    /**
     * Skor performa 0-100 berdasarkan RAM, refresh rate, dan jumlah core CPU.
     * Ini adalah heuristik lokal, bukan hasil benchmark eksternal.
     */
    private int calculateScore(DeviceInfo info) {
        int cores = Runtime.getRuntime().availableProcessors();
        double ramGb = info.totalRamBytes / (1024.0 * 1024.0 * 1024.0);

        double ramScore = Math.min(ramGb / 12.0, 1.0) * 40;
        double refreshScore = Math.min(info.refreshRate / 120.0, 1.0) * 35;
        double coreScore = Math.min(cores / 8.0, 1.0) * 25;

        int score = (int) Math.round(ramScore + refreshScore + coreScore);
        if (score > 99) score = 99;
        if (score < 40) score = 40;
        return score;
    }

    public String formatRam(long bytes) {
        double gb = bytes / (1024.0 * 1024.0 * 1024.0);
        return Math.round(gb) + " GB";
    }

    public String formatResolution(int width, int height) {
        return width + "x" + height;
    }

    public String formatRefreshRate(float refreshRate) {
        return Math.round(refreshRate) + "Hz";
    }
}
