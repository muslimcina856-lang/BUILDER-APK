package com.kamil.tools;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter untuk menampilkan daftar fitur (14 item) pada RecyclerView di MainActivity.
 * Setiap item punya tombol "Generate" yang memanggil callback ke Activity.
 */
public class FeatureAdapter extends RecyclerView.Adapter<FeatureAdapter.FeatureViewHolder> {

    public interface OnFeatureActionListener {
        void onGenerateClicked(Feature feature, int position);
    }

    private final List<Feature> featureList;
    private final OnFeatureActionListener listener;

    public FeatureAdapter(List<Feature> featureList, OnFeatureActionListener listener) {
        this.featureList = featureList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FeatureViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.feature_item, parent, false);
        return new FeatureViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeatureViewHolder holder, int position) {
        Feature feature = featureList.get(position);
        holder.title.setText(feature.getTitle());
        holder.subtitle.setText(feature.getSubtitle());

        if (feature.isGenerated()) {
            holder.generateButton.setText("Applied");
        } else {
            holder.generateButton.setText(R.string.btn_generate);
        }

        holder.generateButton.setOnClickListener(v -> {
            feature.setGenerated(true);
            notifyItemChanged(position);
            if (listener != null) {
                listener.onGenerateClicked(feature, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return featureList == null ? 0 : featureList.size();
    }

    static class FeatureViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView subtitle;
        Button generateButton;

        FeatureViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tvFeatureTitle);
            subtitle = itemView.findViewById(R.id.tvFeatureSubtitle);
            generateButton = itemView.findViewById(R.id.btnFeatureGenerate);
        }
    }
}
