# KAMIL TOOLS — Smart Optimizer

Project Android Studio (Java) lengkap.

## Update terbaru
- **Fix build error**: file `res/drawable/styles.xml` (isinya shape lingkaran,
  salah nama) diubah jadi `res/drawable/circle_score.xml` — ini yang
  menyebabkan error `resource drawable/circle_score not found` saat build.
- **Tema biru elegan**: semua warna neon hijau/merah diganti jadi palet biru
  gelap premium (`accent_blue` dkk di `res/values/colors.xml`).
- **Halaman Login pakai Access Key**: `LoginActivity` jadi launcher pertama.
  Key valid diatur di `res/values/arrays.xml` → `valid_access_keys`
  (default: `KAMIL-VIP-2026` atau `KAMILTOOLS`, tidak case-sensitive).
  Status login disimpan di SharedPreferences; ada tombol **Keluar** di
  MainActivity untuk logout.
- **Auto-launch game + icon asli**: baris "Free Fire" di halaman utama
  sekarang otomatis mendeteksi versi FF yang terpasang, menampilkan icon &
  nama app **asli** (diambil langsung dari app FF yang terpasang di device
  via `PackageManager`, bukan aset logo tiruan), dan langsung membuka game
  saat diketuk. Tombol "Ganti versi" tetap tersedia untuk memilih manual
  antara Free Fire / Free Fire MAX. Ditambahkan `<queries>` di
  `AndroidManifest.xml` supaya deteksi ini tetap jalan di Android 11+.

## Spesifikasi
- Package: `com.kamil.tools`
- Min SDK: 21
- Target SDK: 34
- Bahasa: Java

## Cara membuka
1. Buka Android Studio (versi terbaru disarankan, mendukung AGP 8.2+).
2. Pilih **Open**, arahkan ke folder hasil ekstrak `KAMIL_TOOLS`.
3. Tunggu proses **Gradle Sync** selesai (Android Studio otomatis melengkapi `gradle-wrapper.jar` jika belum ada).
4. Klik **Run** ke device/emulator (minimal Android 5.0 / API 21).

## Struktur fitur
Semua fitur "optimasi" (Easy Drag, SurfaceFlinger Boost, Stable Aim, Boost FPS,
AimingDrag, Optimize System, dll) bekerja dengan memanggil perintah `setprop`
melalui `OptimizerService`. Perlu dicatat:

- Pada device **tanpa akses root**, sebagian besar system property bersifat
  read-only sehingga eksekusi `setprop` bisa gagal secara diam-diam
  (tidak menyebabkan crash, hanya tidak memberi efek nyata di sistem).
- Fitur **Function Sensitivity** dan **SensiAi** murni kalkulasi lokal
  (heuristik berbasis skor performa device), bukan hasil pengukuran resmi.
- Fitur **Menu Login FF** hanya membuka aplikasi Free Fire / Free Fire MAX
  yang sudah terpasang di device (via `Intent` launcher biasa), atau
  mengarahkan ke Play Store bila belum terpasang.
- Fitur **Monitoring ROG** membaca info CPU (dari `/proc/stat`), RAM
  (`ActivityManager.MemoryInfo`), dan suhu baterai (`Intent.ACTION_BATTERY_CHANGED`)
  — semuanya tanpa permission tambahan seperti `PACKAGE_USAGE_STATS`.

## Permission yang digunakan
- `INTERNET`
- `FOREGROUND_SERVICE`

Tidak ada `SYSTEM_ALERT_WINDOW`, `PACKAGE_USAGE_STATS`, maupun
`BIND_ACCESSIBILITY_SERVICE`.

## Struktur file utama
```
app/src/main/java/com/kamil/tools/
  MainActivity.java          -> UI utama & penghubung semua fitur
  DeviceAnalyzer.java        -> analisa spek device & skor performa
  SensitivityGenerator.java  -> generator nilai sensitivity & SensiAi
  OptimizerService.java      -> eksekusi setprop per fitur
  GameLauncher.java          -> launcher Free Fire / Free Fire MAX
  FeatureAdapter.java        -> adapter RecyclerView 14 fitur
  Feature.java               -> model data fitur
  MonitoringHelper.java      -> data CPU/RAM/suhu untuk Monitoring ROG

app/src/main/res/layout/
  activity_main.xml
  device_card.xml
  sensitivity_result.xml
  sensitivity_item.xml
  feature_item.xml
  dialog_login_ff.xml
  dialog_monitoring.xml
  dialog_crosshair.xml
```
