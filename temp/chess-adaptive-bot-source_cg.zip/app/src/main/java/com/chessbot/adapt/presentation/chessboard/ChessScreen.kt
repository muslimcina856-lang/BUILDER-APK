package com.chessbot.adapt.presentation.chessboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.chessbot.adapt.domain.model.PieceType
import com.chessbot.adapt.domain.model.Color as ChessColor

private val AppBackground = Color(0xFF0D0F12)
private val Panel = Color(0xFF171A1F)
private val PanelSoft = Color(0xFF1E2228)
private val Ivory = Color(0xFFF3EEE4)
private val Muted = Color(0xFFA6A39C)
private val Gold = Color(0xFFD8B477)
private val Mint = Color(0xFF76C8A5)
private val Danger = Color(0xFFE07171)

@Composable
fun ChessScreen(
    modifier: Modifier = Modifier,
    viewModel: ChessBoardViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    if (state.isMasteryVictory) {
        MasteryCompletionScreen(state, modifier)
        return
    }

    if (state.isColorSelectionVisible) {
        PlayerColorDialog(onChoose = viewModel::choosePlayerColor)
    }

    if (state.pendingPromotionMoves.isNotEmpty()) {
        PromotionDialog(
            onChoose = viewModel::choosePromotion,
            onDismiss = viewModel::dismissPromotion
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF11151A), AppBackground, Color(0xFF0A0C0F))
                )
            )
    ) {
        TopBar(state)

        BoxWithConstraints(
            modifier = Modifier.fillMaxWidth().weight(1f),
            contentAlignment = Alignment.Center
        ) {
            val boardSize = min(maxWidth - 8.dp, maxHeight * 0.98f)
            if (state.board == null) {
                if (!state.isReady) {
                    CircularProgressIndicator(color = Gold, strokeWidth = 2.dp)
                }
            } else {
                ChessBoard3DView(
                    board = state.board,
                    selectedSquare = state.selectedSquare,
                    validMoves = state.validMoves,
                    lastMove = state.lastMove,
                    isCheck = state.isCheck,
                    checkColor = if (state.isCheck) state.currentTurn else null,
                    playerColor = state.playerColor,
                    boardSize = boardSize,
                    onSquareTap = viewModel::onSquareTapped,
                    onMoveAnimationFinished = viewModel::onMoveAnimationFinished
                )
            }
        }

        BottomPanel(state, viewModel::advanceOrRetry)
    }
}

@Composable
private fun TopBar(state: ChessBoardUiState) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                "ADAPTIVE CHESS",
                color = Ivory,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.2.sp
            )
            Text(
                "Bot membina strategi daripada permainanmu",
                color = Muted,
                fontSize = 11.sp
            )
        }

        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Surface(
                color = Gold.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.38f))
            ) {
                Text(
                    "LEVEL ${state.currentLevel}",
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                    color = Gold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(6.dp).clip(CircleShape).background(statusColor(state))
                )
                Spacer(Modifier.width(6.dp))
                Text(statusText(state), color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun BottomPanel(state: ChessBoardUiState, onAction: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        color = Panel,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 1.dp
    ) {
        when (state.gameResult) {
            null -> GameStatus(state)
            else -> GameResultCard(state, onAction)
        }
    }
}

@Composable
private fun GameStatus(state: ChessBoardUiState) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 13.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        if (state.isBotThinking) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(15.dp),
                    color = Mint,
                    strokeWidth = 2.dp
                )
                Spacer(Modifier.width(9.dp))
                Text("Bot sedang menilai corak kamu…", color = Mint, fontSize = 13.sp)
            }
        } else {
            Text(
                when {
                    state.isMoveAnimating -> "Bidak sedang bergerak…"
                    state.isCheck -> "Raja sedang dalam ancaman"
                    state.currentTurn == state.playerColor -> "Pilih bidak untuk bergerak"
                    else -> "Menunggu giliran bot"
                },
                color = if (state.isCheck) Danger else Ivory,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
        Text(
            "Seret ke atas untuk pandangan strategi • ${state.moveHistory.size} langkah",
            color = Muted.copy(alpha = 0.62f),
            fontSize = 10.sp
        )
        state.errorMessage?.let {
            Text(it, color = Danger, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun GameResultCard(state: ChessBoardUiState, onAction: () -> Unit) {
    val result = state.gameResult ?: return
    val title = when (result) {
        "WIN" -> "Level Ditakluki"
        "LOSS" -> "Bot Menang"
        else -> "Permainan Seri"
    }
    val description = when (result) {
        "WIN" -> "Lawan kamu sudah berkembang ke Level ${state.currentLevel}."
        "LOSS" -> "Cuba lagi—bot kini mengenali lebih banyak corak permainanmu."
        else -> "Kekuatan kamu dan bot hampir seimbang pada permainan ini."
    }
    val buttonText = when (result) {
        "WIN" -> "Level Seterusnya"
        "LOSS" -> "Cuba Semula"
        else -> "Main Semula"
    }

    Column(
        modifier = Modifier.fillMaxWidth().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Ivory, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(description, color = Muted, fontSize = 12.sp)
            }
            Surface(color = resultColor(result).copy(alpha = 0.13f), shape = CircleShape) {
                Text(
                    when (result) { "WIN" -> "W"; "LOSS" -> "L"; else -> "D" },
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
                    color = resultColor(result),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        if (state.learningInsights.isNotEmpty()) {
            Surface(color = PanelSoft, shape = RoundedCornerShape(13.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "APA YANG BOT PELAJARI",
                        color = Gold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    state.learningInsights.forEach { insight ->
                        Text("• $insight", color = Ivory.copy(alpha = 0.88f), fontSize = 11.sp)
                    }
                }
            }
        } else if (state.isResultProcessing) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(14.dp), color = Gold, strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("Menyimpan corak permainan…", color = Muted, fontSize = 11.sp)
            }
        }

        Button(
            onClick = onAction,
            enabled = !state.isResultProcessing,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (result == "LOSS") Ivory else Gold,
                contentColor = Color(0xFF17130D),
                disabledContainerColor = PanelSoft,
                disabledContentColor = Muted
            ),
            shape = RoundedCornerShape(13.dp)
        ) {
            Text(buttonText, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
private fun MasteryCompletionScreen(state: ChessBoardUiState, modifier: Modifier = Modifier) {
    val profile = state.playerProfile
    val pendingFinalWin = if (state.isResultProcessing && state.gameResult == "WIN") 1 else 0
    val totalGames = (profile?.totalGames ?: 0) + pendingFinalWin
    val wins = (profile?.wins ?: 0) + pendingFinalWin
    val draws = profile?.draws ?: 0
    val losses = profile?.losses ?: 0
    val winRate = if (totalGames == 0) 0 else wins * 100 / totalGames
    val playMinutes = (profile?.totalPlayTimeMs ?: 0L) / 60_000L

    val playingIdentity = when {
        winRate >= 65 -> "Permainanmu konsisten dan dominan, dengan kadar kemenangan $winRate%."
        wins > losses -> "Kamu menang lebih kerap daripada kalah dan tahu menukar tekanan menjadi peluang."
        draws > losses -> "Kamu sukar ditumbangkan; keputusan seri menunjukkan pertahanan yang sabar."
        else -> "Kekuatan utamamu ialah ketahanan—kamu terus menyesuaikan diri sehingga tahap terakhir."
    }
    val botMessage = when {
        losses > wins -> "Kamu mengajar aku bahawa pemain hebat bukan pemain yang tidak pernah kalah, tetapi pemain yang tidak pernah berhenti kembali."
        draws > losses -> "Banyak kali kita berdiri seimbang. Pada akhirnya, kamulah yang menemui langkah yang tidak mampu aku jawab."
        else -> "Aku belajar daripada setiap langkahmu, tetapi pada Level 999 kamulah yang membaca aku dengan lebih baik."
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF17140E), AppBackground, Color(0xFF090B0E))
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    "ADAPTIVE CHESS",
                    color = Ivory,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp
                )
                Text("Hall of Mastery", color = Muted, fontSize = 11.sp)
            }
            Surface(
                color = Gold.copy(alpha = 0.13f),
                shape = RoundedCornerShape(50),
                border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.38f))
            ) {
                Text(
                    "PENCAPAIAN KEKAL",
                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                    color = Gold,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.7.sp
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.radialGradient(
                        listOf(Gold.copy(alpha = 0.24f), Color(0xFF201A10), Panel),
                        radius = 650f
                    )
                )
                .border(1.dp, Gold.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                .padding(horizontal = 18.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(color = Gold.copy(alpha = 0.13f), shape = CircleShape) {
                    Text("♛", modifier = Modifier.padding(13.dp), color = Gold, fontSize = 34.sp)
                }
                Spacer(Modifier.height(10.dp))
                Text("999", color = Ivory, fontSize = 56.sp, fontWeight = FontWeight.Black)
                Text(
                    "LEVEL TERTINGGI DITAKLUKI",
                    color = Gold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.1.sp
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Kamu telah menguasai lawan yang berkembang daripada setiap permainan.",
                    color = Muted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(
                    "TERIMA KASIH, GRANDMASTER",
                    color = Gold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp
                )
                Text(
                    "Terima kasih kerana menemani bot ini berkembang dari Level 1 hingga 999. " +
                        "Setiap kemenangan, kekalahan dan seri membentuk lawan yang kamu kalahkan hari ini.",
                    color = Ivory,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MasteryMetric("Permainan", totalGames, Gold, Modifier.weight(1f))
                MasteryMetric("Menang", wins, Mint, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MasteryMetric("Seri", draws, Gold, Modifier.weight(1f))
                MasteryMetric("Kalah", losses, Danger, Modifier.weight(1f))
            }
        }

        Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Text(
                    "ANALISIS AKHIR",
                    color = Gold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp
                )
                MasteryAnalysisRow("Identiti permainan", playingIdentity)
                HorizontalDivider(color = Color(0xFF292D33))
                MasteryAnalysisRow(
                    "Perjalanan",
                    "$totalGames permainan selesai, $wins kemenangan dan kira-kira $playMinutes minit di papan."
                )
                HorizontalDivider(color = Color(0xFF292D33))
                MasteryAnalysisRow(
                    "Evolusi bot",
                    "Bot mengenali ${state.learnedPatternCount} corak permainan dan terus belajar walaupun keputusan seri atau bot menang."
                )
            }
        }

        Surface(
            color = Gold.copy(alpha = 0.08f),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.22f))
        ) {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier.width(3.dp).height(72.dp).clip(RoundedCornerShape(50)).background(Gold)
                )
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(
                        "DARIPADA BOT LEVEL 999",
                        color = Gold,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.7.sp
                    )
                    Text(
                        "“$botMessage”",
                        color = Ivory,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                }
            }
        }

        if (state.isResultProcessing) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(Modifier.size(14.dp), color = Gold, strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("Menyimpan pencapaian…", color = Muted, fontSize = 11.sp)
            }
        } else {
            Text(
                "Pencapaian ini disimpan kekal. Sejarah dan prestasi masih boleh dilihat melalui menu di bawah.",
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                color = Muted.copy(alpha = 0.75f),
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun MasteryMetric(
    label: String,
    value: Int,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(modifier = modifier, color = Panel, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(label, color = Muted, fontSize = 10.sp)
            Text(value.toString(), color = accent, fontSize = 25.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun MasteryAnalysisRow(label: String, text: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, color = Ivory, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(text, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

private fun statusText(state: ChessBoardUiState): String = when {
    !state.isReady -> "Menyediakan permainan"
    state.isColorSelectionVisible -> "Pilih warna bidak"
    state.isBotThinking -> "Bot berfikir"
    state.isMoveAnimating -> "Bidak bergerak"
    state.gameResult != null -> "Permainan tamat"
    state.currentTurn == state.playerColor -> "Giliran kamu"
    else -> "Giliran bot"
}

private fun statusColor(state: ChessBoardUiState): Color = when {
    state.isCheck -> Danger
    state.isBotThinking || state.isMoveAnimating -> Gold
    state.currentTurn == state.playerColor -> Mint
    else -> Muted
}

private fun resultColor(result: String): Color = when (result) {
    "WIN" -> Mint
    "LOSS" -> Danger
    else -> Gold
}

@Composable
private fun PlayerColorDialog(onChoose: (ChessColor) -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        containerColor = Panel,
        titleContentColor = Ivory,
        textContentColor = Muted,
        title = { Text("Pilih warna bidak", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Pilihan ini digunakan sepanjang level seterusnya. Selepas kalah atau seri, kamu boleh memilih semula.",
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
                ColorChoiceButton(
                    symbol = "♙",
                    title = "Bidak Putih",
                    containerColor = Ivory,
                    contentColor = Color(0xFF17130D),
                    onClick = { onChoose(ChessColor.WHITE) }
                )
                ColorChoiceButton(
                    symbol = "♟",
                    title = "Bidak Hitam",
                    containerColor = Color(0xFF292D33),
                    contentColor = Ivory,
                    onClick = { onChoose(ChessColor.BLACK) }
                )
            }
        },
        confirmButton = {}
    )
}

@Composable
private fun ColorChoiceButton(
    symbol: String,
    title: String,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = RoundedCornerShape(13.dp)
    ) {
        Text(symbol, fontSize = 24.sp)
        Spacer(Modifier.width(12.dp))
        Text(
            title,
            modifier = Modifier.weight(1f),
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Start
        )
    }
}

@Composable
private fun PromotionDialog(onChoose: (PieceType) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        titleContentColor = Ivory,
        textContentColor = Muted,
        title = { Text("Pilih kenaikan bidak", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Bidak ini boleh dinaikkan menjadi:", fontSize = 12.sp)
                listOf(
                    PieceType.QUEEN to "Menteri",
                    PieceType.ROOK to "Benteng",
                    PieceType.BISHOP to "Gajah",
                    PieceType.KNIGHT to "Kuda"
                ).forEach { (piece, label) ->
                    OutlinedButton(
                        onClick = { onChoose(piece) },
                        modifier = Modifier.fillMaxWidth(),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.45f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Ivory)
                    ) { Text(label) }
                }
            }
        },
        confirmButton = {}
    )
}
