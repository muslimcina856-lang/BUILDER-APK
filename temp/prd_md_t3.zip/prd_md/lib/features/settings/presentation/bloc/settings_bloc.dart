import 'dart:async';
import 'dart:convert';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import 'package:sqflite/sqflite.dart';
import '../../../../core/utils/secure_storage_helper.dart';
import '../../../../services/database_service.dart';
import '../../../chat/domain/repositories/chat_repository.dart';
import '../../../chat/data/repositories/chat_repository_impl.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class SettingsEvent extends Equatable {
  const SettingsEvent();
  @override
  List<Object?> get props => [];
}

class LoadSettings extends SettingsEvent {}

class SaveApiKey extends SettingsEvent {
  final String apiKey;
  const SaveApiKey(this.apiKey);
  @override
  List<Object?> get props => [apiKey];
}

class TestApiConnection extends SettingsEvent {
  final String apiKey;
  const TestApiConnection(this.apiKey);
  @override
  List<Object?> get props => [apiKey];
}

class UpdateDefaultModel extends SettingsEvent {
  final String model;
  const UpdateDefaultModel(this.model);
  @override
  List<Object?> get props => [model];
}

class ToggleWebSearchDefault extends SettingsEvent {
  final bool enabled;
  const ToggleWebSearchDefault(this.enabled);
  @override
  List<Object?> get props => [enabled];
}

class ClearAllData extends SettingsEvent {}

class ExportData extends SettingsEvent {}

class ImportData extends SettingsEvent {
  final String jsonBackup;
  const ImportData(this.jsonBackup);
  @override
  List<Object?> get props => [jsonBackup];
}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class SettingsState extends Equatable {
  const SettingsState();
  @override
  List<Object?> get props => [];
}

class SettingsInitial extends SettingsState {}

class SettingsLoaded extends SettingsState {
  final String apiKey;
  final String defaultModel;
  final bool isWebSearchEnabled;
  final bool isDarkMode;
  final bool isApiKeyValid;

  const SettingsLoaded({
    required this.apiKey,
    required this.defaultModel,
    required this.isWebSearchEnabled,
    required this.isDarkMode,
    required this.isApiKeyValid,
  });

  SettingsLoaded copyWith({
    String? apiKey,
    String? defaultModel,
    bool? isWebSearchEnabled,
    bool? isDarkMode,
    bool? isApiKeyValid,
  }) {
    return SettingsLoaded(
      apiKey: apiKey ?? this.apiKey,
      defaultModel: defaultModel ?? this.defaultModel,
      isWebSearchEnabled: isWebSearchEnabled ?? this.isWebSearchEnabled,
      isDarkMode: isDarkMode ?? this.isDarkMode,
      isApiKeyValid: isApiKeyValid ?? this.isApiKeyValid,
    );
  }

  @override
  List<Object?> get props => [apiKey, defaultModel, isWebSearchEnabled, isDarkMode, isApiKeyValid];
}

class SettingsSaving extends SettingsState {}

class SettingsError extends SettingsState {
  final String message;
  const SettingsError(this.message);
  @override
  List<Object?> get props => [message];
}

class ApiTestResult extends SettingsState {
  final bool success;
  final String message;

  const ApiTestResult({required this.success, required this.message});

  @override
  List<Object?> get props => [success, message];
}

class DataCleared extends SettingsState {}

class DataBackupResult extends SettingsState {
  final String? backupJson;
  final bool success;
  final String message;

  const DataBackupResult({this.backupJson, required this.success, required this.message});

  @override
  List<Object?> get props => [backupJson, success, message];
}

// -----------------------------------------------------------------------------
// BLOC IMPLEMENTATION
// -----------------------------------------------------------------------------
class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  final SecureStorageHelper _secureStorageHelper;
  final DatabaseService _dbService;
  final ChatRepository _chatRepository;

  SettingsBloc({
    SecureStorageHelper? secureStorageHelper,
    DatabaseService? dbService,
    ChatRepository? chatRepository,
  })  : _secureStorageHelper = secureStorageHelper ?? SecureStorageHelper(),
        _dbService = dbService ?? DatabaseService(),
        _chatRepository = chatRepository ?? ChatRepositoryImpl(),
        super(SettingsInitial()) {
    on<LoadSettings>(_onLoadSettings);
    on<SaveApiKey>(_onSaveApiKey);
    on<TestApiConnection>(_onTestApiConnection);
    on<UpdateDefaultModel>(_onUpdateDefaultModel);
    on<ToggleWebSearchDefault>(_onToggleWebSearchDefault);
    on<ClearAllData>(_onClearAllData);
    on<ExportData>(_onExportData);
    on<ImportData>(_onImportData);
  }

  Future<void> _onLoadSettings(LoadSettings event, Emitter<SettingsState> emit) async {
    try {
      final String apiKey = await _secureStorageHelper.getApiKey() ?? '';
      final String defaultModel = await _secureStorageHelper.getDefaultModel();
      final bool isWebSearchEnabled = await _secureStorageHelper.getWebSearchDefault();
      final bool isDarkMode = await _secureStorageHelper.isDarkMode();
      
      final bool isApiKeyValid = apiKey.isNotEmpty; // basic validation placeholder

      emit(SettingsLoaded(
        apiKey: apiKey,
        defaultModel: defaultModel,
        isWebSearchEnabled: isWebSearchEnabled,
        isDarkMode: isDarkMode,
        isApiKeyValid: isApiKeyValid,
      ));
    } catch (e) {
      emit(SettingsError('Gagal memuatkan tetapan: $e'));
    }
  }

  Future<void> _onSaveApiKey(SaveApiKey event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is SettingsLoaded) {
      emit(SettingsSaving());
      try {
        final String sanitizedKey = event.apiKey.replaceAll(RegExp(r'\s+'), '');
        await _secureStorageHelper.saveApiKey(sanitizedKey);
        
        emit(currentState.copyWith(
          apiKey: sanitizedKey,
          isApiKeyValid: sanitizedKey.isNotEmpty,
        ));
      } catch (e) {
        emit(SettingsError('Gagal menyimpan Kunci API: $e'));
      }
    }
  }

  Future<void> _onTestApiConnection(TestApiConnection event, Emitter<SettingsState> emit) async {
    emit(SettingsSaving());
    try {
      final String sanitizedKey = event.apiKey.replaceAll(RegExp(r'\s+'), '');
      if (sanitizedKey.isEmpty) {
        emit(const ApiTestResult(success: false, message: 'Kunci API kosong. Sila masukkan kunci API dahulu.'));
        add(LoadSettings());
        return;
      }

      final bool isValid = await _chatRepository.testApiConnection(sanitizedKey);
      
      if (isValid) {
        emit(const ApiTestResult(success: true, message: 'Kombinasi berjaya! Kunci API anda sah.'));
      } else {
        emit(const ApiTestResult(success: false, message: 'Gagal menyambung. Sila pastikan kunci API adalah betul.'));
      }
      add(LoadSettings());
    } catch (e) {
      emit(ApiTestResult(success: false, message: 'Ralat sambungan: $e'));
      add(LoadSettings());
    }
  }

  Future<void> _onUpdateDefaultModel(UpdateDefaultModel event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is SettingsLoaded) {
      try {
        await _secureStorageHelper.saveDefaultModel(event.model);
        emit(currentState.copyWith(defaultModel: event.model));
      } catch (e) {
        emit(SettingsError('Gagal menukar model lalai: $e'));
      }
    }
  }

  Future<void> _onToggleWebSearchDefault(ToggleWebSearchDefault event, Emitter<SettingsState> emit) async {
    final SettingsState currentState = state;
    if (currentState is SettingsLoaded) {
      try {
        await _secureStorageHelper.saveWebSearchDefault(event.enabled);
        emit(currentState.copyWith(isWebSearchEnabled: event.enabled));
      } catch (e) {
        emit(SettingsError('Gagal menukar pilihan carian web: $e'));
      }
    }
  }

  Future<void> _onClearAllData(ClearAllData event, Emitter<SettingsState> emit) async {
    emit(SettingsSaving());
    try {
      // Padam secure storage
      await _secureStorageHelper.deleteApiKey();
      
      // Padam database SQLite
      await _dbService.deleteAllSessions();
      
      // Padam settings kustom & skills
      final Database db = await _dbService.database;
      await db.delete('ai_skills');
      await db.delete('settings');
      
      emit(DataCleared());
      add(LoadSettings());
    } catch (e) {
      emit(SettingsError('Gagal memadam semua data: $e'));
    }
  }

  Future<void> _onExportData(ExportData event, Emitter<SettingsState> emit) async {
    try {
      final Database db = await _dbService.database;
      
      // Ambil data untuk eksport
      final List<Map<String, dynamic>> skills = await db.query('ai_skills');
      final List<Map<String, dynamic>> sessions = await db.query('chat_sessions');
      final List<Map<String, dynamic>> messages = await db.query('messages');
      final List<Map<String, dynamic>> junction = await db.query('session_skills');
      final List<Map<String, dynamic>> settings = await db.query('settings');

      final Map<String, dynamic> backup = {
        'version': 1,
        'ai_skills': skills,
        'chat_sessions': sessions,
        'messages': messages,
        'session_skills': junction,
        'settings': settings,
      };

      final String backupJson = jsonEncode(backup);
      emit(DataBackupResult(
        backupJson: backupJson,
        success: true,
        message: 'Data berjaya dieksport untuk sandaran (backup).',
      ));
      add(LoadSettings());
    } catch (e) {
      emit(DataBackupResult(success: false, message: 'Gagal mengeksport data: $e'));
      add(LoadSettings());
    }
  }

  Future<void> _onImportData(ImportData event, Emitter<SettingsState> emit) async {
    emit(SettingsSaving());
    try {
      final Map<String, dynamic> backup = jsonDecode(event.jsonBackup) as Map<String, dynamic>;
      final Database db = await _dbService.database;

      await db.transaction((txn) async {
        // Padam jadual sedia ada
        await txn.delete('ai_skills');
        await txn.delete('chat_sessions');
        await txn.delete('messages');
        await txn.delete('session_skills');
        await txn.delete('settings');

        // Masukkan data import
        if (backup['ai_skills'] != null) {
          for (final dynamic item in backup['ai_skills']) {
            await txn.insert('ai_skills', item as Map<String, dynamic>);
          }
        }
        if (backup['chat_sessions'] != null) {
          for (final dynamic item in backup['chat_sessions']) {
            await txn.insert('chat_sessions', item as Map<String, dynamic>);
          }
        }
        if (backup['messages'] != null) {
          for (final dynamic item in backup['messages']) {
            await txn.insert('messages', item as Map<String, dynamic>);
          }
        }
        if (backup['session_skills'] != null) {
          for (final dynamic item in backup['session_skills']) {
            await txn.insert('session_skills', item as Map<String, dynamic>);
          }
        }
        if (backup['settings'] != null) {
          for (final dynamic item in backup['settings']) {
            await txn.insert('settings', item as Map<String, dynamic>);
          }
        }
      });

      emit(const DataBackupResult(success: true, message: 'Data sandaran berjaya diimport kembali.'));
      add(LoadSettings());
    } catch (e) {
      emit(DataBackupResult(success: false, message: 'Gagal mengimport data: $e'));
      add(LoadSettings());
    }
  }
}
