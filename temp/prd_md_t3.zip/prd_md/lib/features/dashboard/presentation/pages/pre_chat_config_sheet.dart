import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../chat/domain/entities/chat_session.dart';
import '../../../chat/presentation/bloc/chat_bloc.dart';
import '../../../skills/domain/entities/ai_skill.dart';
import '../../../skills/presentation/bloc/skills_bloc.dart';
import '../../../skills/presentation/widgets/skill_selector_widget.dart';
import '../../../chat/presentation/pages/chat_room_page.dart';

class PreChatConfigSheet extends StatefulWidget {
  const PreChatConfigSheet({super.key});

  @override
  State<PreChatConfigSheet> createState() => _PreChatConfigSheetState();
}

class _PreChatConfigSheetState extends State<PreChatConfigSheet> {
  final TextEditingController _titleController = TextEditingController();
  String _selectedModel = ChatSession.modelDeepseekFlash;

  @override
  void initState() {
    super.initState();
    context.read<SkillsBloc>().add(LoadSkills());
  }

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  void _startChat(List<String> activeSkillIds) {
    final String title = _titleController.text.trim();
    final String finalTitle = title.isEmpty ? 'Sembang Baru' : title;

    context.read<ChatBloc>().add(
          CreateNewSession(
            title: finalTitle,
            modelType: _selectedModel,
            skillIds: activeSkillIds,
          ),
        );
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<ChatBloc, ChatState>(
      listener: (context, state) {
        if (state is SessionCreated) {
          Navigator.pop(context); // Tutup bottom sheet
          Navigator.push(
            context,
            MaterialPageRoute<void>(
              builder: (context) => ChatRoomPage(session: state.session),
            ),
          );
        }
      },
      child: Container(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 10,
          bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        decoration: const BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
          border: Border(
            top: BorderSide(color: AppColors.cardBorder),
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Drag handle
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.cardBorder,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Konfigurasi Sembang Baru',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 20),
              // Session Title
              Text(
                'Tajuk Perbualan (Opsional)',
                style: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _titleController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Contoh: PRD E-Commerce App',
                ),
              ),
              const SizedBox(height: 20),
              // Model Selection Cards
              Text(
                'Pilih Model AI DeepSeek',
                style: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  _buildModelCard(
                    title: 'DeepSeek Flash',
                    subtitle: 'Pantas & Cekap',
                    model: ChatSession.modelDeepseekFlash,
                    icon: Icons.bolt,
                    color: AppColors.accent,
                  ),
                  const SizedBox(width: 12),
                  _buildModelCard(
                    title: 'DeepSeek Pro',
                    subtitle: 'Penaakulan Khas',
                    model: ChatSession.modelDeepseekPro,
                    icon: Icons.psychology,
                    color: AppColors.secondary,
                  ),
                ],
              ),
              const SizedBox(height: 24),
              // Skills Configuration Info
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Kemahiran AI (Skills)',
                    style: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  GestureDetector(
                    onTap: () {
                      showModalBottomSheet<void>(
                        context: context,
                        backgroundColor: Colors.transparent,
                        isScrollControlled: true,
                        builder: (_) => const SkillSelectorWidget(),
                      );
                    },
                    child: const Row(
                      children: [
                        Text('Urus Skills', style: TextStyle(color: AppColors.accent, fontSize: 13)),
                        Icon(Icons.chevron_right, size: 16, color: AppColors.accent),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              BlocBuilder<SkillsBloc, SkillsState>(
                builder: (context, state) {
                  int activeCount = 0;
                  List<String> activeNames = [];

                  if (state is SkillsLoaded) {
                    final activeSkills = state.allSkills.where((s) => s.isActive);
                    activeCount = activeSkills.length;
                    activeNames = activeSkills.map((s) => s.name).toList();
                  }

                  return Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.scaffold,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: activeCount == 0
                        ? const Text(
                            'Tiada skill aktif. AI akan menggunakan fallback standard.',
                            style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Aktif ($activeCount):',
                                style: const TextStyle(color: AppColors.accent, fontSize: 12, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 4),
                              Wrap(
                                spacing: 6,
                                runSpacing: 6,
                                children: activeNames.map((name) {
                                  return Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.accent.withOpacity( 0.1),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(color: AppColors.accent.withOpacity( 0.3), width: 0.5),
                                    ),
                                    child: Text(
                                      name,
                                      style: const TextStyle(color: Colors.white, fontSize: 10),
                                    ),
                                  );
                                }).toList(),
                              ),
                            ],
                          ),
                  );
                },
              ),
              const SizedBox(height: 24),
              // Submit button
              BlocBuilder<SkillsBloc, SkillsState>(
                builder: (context, skillsState) {
                  final List<String> activeIds = skillsState is SkillsLoaded ? skillsState.activeSkillIds : [];
                  return SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => _startChat(activeIds),
                      child: const Text('Mula Sembang'),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModelCard({
    required String title,
    required String subtitle,
    required String model,
    required IconData icon,
    required Color color,
  }) {
    final bool selected = _selectedModel == model;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedModel = model;
          });
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: selected ? color.withOpacity( 0.15) : AppColors.scaffold,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? color : AppColors.cardBorder,
              width: selected ? 1.5 : 1.0,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: selected ? color : AppColors.textMuted, size: 24),
              const SizedBox(height: 12),
              Text(
                title,
                style: GoogleFonts.inter(
                  fontWeight: FontWeight.bold,
                  color: selected ? Colors.white : AppColors.textPrimary,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: GoogleFonts.inter(
                  color: selected ? Colors.white.withOpacity( 0.8) : AppColors.textMuted,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
