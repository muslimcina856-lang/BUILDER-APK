import 'dart:async';
import 'package:uuid/uuid.dart';
import 'package:sqflite/sqflite.dart';
import '../../domain/entities/chat_session.dart';
import '../../domain/entities/chat_message.dart';
import '../../domain/repositories/chat_repository.dart';
import '../../../../services/database_service.dart';
import '../../../../core/utils/api_client.dart';

/// Implementasi repositori ChatRepository menggunakan SQLite dan DeepSeekApiClient.
class ChatRepositoryImpl implements ChatRepository {
  final DatabaseService _dbService;
  final Uuid _uuid = const Uuid();

  ChatRepositoryImpl({DatabaseService? dbService})
      : _dbService = dbService ?? DatabaseService();

  @override
  Future<List<ChatSession>> getAllSessions() async {
    final List<Map<String, dynamic>> rawSessions = await _dbService.getAllSessions();
    final List<ChatSession> sessions = [];

    for (final Map<String, dynamic> row in rawSessions) {
      final String id = row['id'] as String;
      // Dapatkan skill-skill aktif dari junction table
      final List<Map<String, dynamic>> rawSkills = await _dbService.getActiveSkillsForSession(id);
      final List<String> skillIds = rawSkills.map((s) => s['id'] as String).toList();
      
      final Map<String, dynamic> sessionMap = Map<String, dynamic>.from(row);
      sessionMap['modelType'] = row['model'] ?? ChatSession.modelDeepseekFlash;
      sessionMap['createdAt'] = DateTime.parse(row['created_at'] as String).millisecondsSinceEpoch;
      sessionMap['updatedAt'] = DateTime.parse(row['updated_at'] as String).millisecondsSinceEpoch;
      sessionMap['activeSkillIds'] = skillIds.join(',');

      sessions.add(ChatSession.fromMap(sessionMap));
    }
    return sessions;
  }

  @override
  Future<List<ChatSession>> searchSessions(String query) async {
    final List<Map<String, dynamic>> rawSessions = await _dbService.searchSessions(query);
    final List<ChatSession> sessions = [];

    for (final Map<String, dynamic> row in rawSessions) {
      final String id = row['id'] as String;
      final List<Map<String, dynamic>> rawSkills = await _dbService.getActiveSkillsForSession(id);
      final List<String> skillIds = rawSkills.map((s) => s['id'] as String).toList();
      
      final Map<String, dynamic> sessionMap = Map<String, dynamic>.from(row);
      sessionMap['modelType'] = row['model'] ?? ChatSession.modelDeepseekFlash;
      sessionMap['createdAt'] = DateTime.parse(row['created_at'] as String).millisecondsSinceEpoch;
      sessionMap['updatedAt'] = DateTime.parse(row['updated_at'] as String).millisecondsSinceEpoch;
      sessionMap['activeSkillIds'] = skillIds.join(',');

      sessions.add(ChatSession.fromMap(sessionMap));
    }
    return sessions;
  }

  @override
  Future<ChatSession> createSession({
    required String title,
    required String modelType,
    required List<String> skillIds,
  }) async {
    final String sessionId = _uuid.v4();
    
    // Simpan sesi ke database SQLite
    await _dbService.createSession(
      id: sessionId,
      title: title,
      model: modelType,
    );

    // Hubungkan skill dengan sesi dalam database junction
    if (skillIds.isNotEmpty) {
      await _dbService.linkSkillsToSession(sessionId, skillIds);
    }

    final DateTime now = DateTime.now();
    return ChatSession(
      id: sessionId,
      title: title,
      modelType: modelType,
      createdAt: now,
      updatedAt: now,
      activeSkillIds: skillIds,
    );
  }

  @override
  Future<void> updateSessionTitle(String sessionId, String newTitle) async {
    await _dbService.updateSessionTitle(sessionId, newTitle);
  }

  @override
  Future<void> deleteSession(String sessionId) async {
    await _dbService.deleteSession(sessionId);
  }

  @override
  Future<void> deleteAllSessions() async {
    await _dbService.deleteAllSessions();
  }

  @override
  Future<List<ChatMessage>> getMessages(String sessionId) async {
    final List<Map<String, dynamic>> rawMessages = await _dbService.getMessagesBySessionId(sessionId);
    return rawMessages.map((row) {
      final Map<String, dynamic> msgMap = Map<String, dynamic>.from(row);
      // SQLite tidak menyokong BOOLEAN, tukarkan semula untuk data mapping
      msgMap['sessionId'] = row['session_id'];
      msgMap['containsForm'] = (row['contains_form'] ?? 0);
      msgMap['isFormSubmitted'] = (row['is_form_submitted'] ?? 0);
      msgMap['timestamp'] = DateTime.parse(row['created_at'] as String).millisecondsSinceEpoch;
      
      // sqlite model may lack fields
      if (!msgMap.containsKey('rawFormJson')) msgMap['rawFormJson'] = null;
      
      return ChatMessage.fromMap(msgMap);
    }).toList();
  }

  @override
  Future<void> saveMessage(ChatMessage message) async {
    final DatabaseService db = _dbService;
    final Database dbInst = await db.database;
    
    await dbInst.insert(
      'messages',
      {
        'id': message.id,
        'session_id': message.sessionId,
        'role': message.role,
        'content': message.content,
        // model fields
        'contains_form': message.containsForm ? 1 : 0,
        'raw_form_json': message.rawFormJson,
        'is_form_submitted': message.isFormSubmitted ? 1 : 0,
        'created_at': message.timestamp.toUtc().toIso8601String(),
      },
    );
    await db.touchSession(message.sessionId);
  }

  @override
  Future<void> updateMessageFormStatus(String messageId, bool isSubmitted) async {
    final DatabaseService db = _dbService;
    final Database dbInst = await db.database;
    await dbInst.update(
      'messages',
      {
        'is_form_submitted': isSubmitted ? 1 : 0,
      },
      where: 'id = ?',
      whereArgs: [messageId],
    );
  }

  @override
  Stream<String> sendChatMessage({
    required String apiKey,
    required String model,
    required List<Map<String, String>> messages,
  }) {
    // translate model names to deepseek specific if needed
    final String deepseekModel = (model == ChatSession.modelDeepseekFlash)
        ? 'deepseek-chat'
        : 'deepseek-reasoner'; // deepseek-v4-pro -> deepseek-reasoner

    final DeepSeekApiClient client = DeepSeekApiClient(
      apiKey: apiKey,
      model: deepseekModel,
    );
    return client.sendChatMessage(messages, stream: true);
  }

  @override
  Future<bool> testApiConnection(String apiKey) async {
    final DeepSeekApiClient client = DeepSeekApiClient(
      apiKey: apiKey,
      model: 'deepseek-chat',
    );
    return await client.testConnection();
  }
}
