package com.mafia.ai

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.style.StyleSpan
import android.text.style.RelativeSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * mafia.ai Screen Assistant:
 * floating ball (drag / tap / triple-tap / long-press-and-pull), pemilih area,
 * MediaProjection capture (RAM only), panggilan AI vision, kartu jawaban.
 */
class ArcOverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.arcai.app.STOP"
        private const val CHANNEL = "arc_assistant"
        private const val NOTIF_ID = 77

        @Volatile var running = false
        @Volatile var instance: ArcOverlayService? = null
        var stateListener: ((Boolean) -> Unit)? = null
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var capturer: ScreenCapturer? = null
    private var pal = Palette(false)

    private var ball: BallView? = null
    private var ballLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var touchSelect: View? = null
    private var passiveSelect: SelectionView? = null
    private var card: View? = null
    private var cardLp: WindowManager.LayoutParams? = null
    private var answerTv: TextView? = null
    private var statusTv: TextView? = null
    private var inputEt: EditText? = null

    // gambar disimpan di RAM saja selama kartu jawaban terbuka
    private var lastJpeg: ByteArray? = null
    private var lastQuestion = ""
    private var lastAnswer = ""
    private var requestId = 0

    // Auto Answer (Play/Stop): AI membaca layar lalu mengetuk & menggulir sendiri
    @Volatile private var autoActive = false
    @Volatile private var autoToken = 0
    private val autoLog = ArrayList<String>()
    private val maxAutoSteps = 150
    private val maxPasses = 3   // putaran balik ke soal yang masih kosong (maks 2 kali ulang)
    // progres soal untuk pill melayang
    private var pill: View? = null
    private var pillText: TextView? = null
    private val seenQ = ArrayList<String>()
    private val doneQ = HashSet<String>()
    @Volatile private var totalFinal = false
    private val essayTries = HashMap<String, Int>()
    private var emptyRetry = 0   // baca ulang bila AI bilang ada soal kosong tapi tidak memberi jawaban   // percobaan ketik per soal uraian (per halaman)

    // gesture state
    private enum class Mode { NONE, DRAG, SELECT }
    private var mode = Mode.NONE
    private var downRawX = 0f; private var downRawY = 0f
    private var startX = 0; private var startY = 0
    private var anchorX = 0f; private var anchorY = 0f
    private var lastRawX = 0f; private var lastRawY = 0f
    private var tapCount = 0
    private var lastTapUp = 0L

    private val longPress = Runnable { onBallLongPress() }
    private val tapRunnable = Runnable { if (tapCount in 1..2) togglePanel(); tapCount = 0 }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (capturer != null) return START_NOT_STICKY // sudah berjalan

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (data == null || code == 0) { stopSelf(); return START_NOT_STICKY }

        // Urutan wajib: startForeground (type mediaProjection) -> getMediaProjection.
        try {
            startForegroundCompat()
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = mgr.getMediaProjection(code, data)
                ?: throw IllegalStateException("MediaProjection tidak tersedia (izin dibatalkan?)")
            val cap = ScreenCapturer(this, projection)
            cap.onStopped = { stopSelf() }
            cap.start()
            capturer = cap
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memulai capture: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        pal = Palette.from(this, NativeStore.config(this).themeMode)
        showBall()
        main.removeCallbacks(greetRunnable)
        main.postDelayed(greetRunnable, 800)
        running = true
        stateListener?.invoke(true)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen Helper", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, ArcOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Screen Helper aktif")
            .setContentText("Bantuan layar aktif.")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notification), "Matikan", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIF_ID, n)
    }

    // ---------------------------------------------------------------- window helpers

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun fullScreenLp(touchable: Boolean): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(), f, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }

    private fun safeRemove(v: View?) { if (v != null) runCatching { wm.removeView(v) } }

    private fun cfg() = NativeStore.config(this)

    // ---------------------------------------------------------------- sapaan robot

    private var greetView: TextView? = null
    private val greetHide = Runnable { hideGreeting() }
    private val greetRunnable = object : Runnable {
        override fun run() { greet(); main.postDelayed(this, 14000) }
    }

    /** Robot melambai + gelembung "Halo!" di samping bola selama ~2,6 detik. */
    private fun greet() {
        val b = ball ?: return
        val lp = ballLp ?: return
        if (panel != null || ballInvisible || mode != Mode.NONE) return
        hideGreeting()
        b.waving = true
        val tv = TextView(this).apply {
            text = "Halo!"
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(pal.ink)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = glassBox(this@ArcOverlayService, 0xF2171A24.toInt(), 0x33FFFFFF, 14)
        }
        tv.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val (sw, _) = realScreenSize()
        val onRight = lp.x + lp.width / 2 > sw / 2
        val gx = if (onRight) lp.x - tv.measuredWidth - dp(2) else lp.x + lp.width + dp(2)
        val glp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = gx; y = lp.y + dp(18) }
        runCatching { wm.addView(tv, glp); greetView = tv }
        main.postDelayed(greetHide, 2600)
    }

    private fun hideGreeting() {
        main.removeCallbacks(greetHide)
        safeRemove(greetView); greetView = null
        ball?.waving = false
    }

    // ---------------------------------------------------------------- floating ball

    private fun showBall() {
        val size = dp(72)
        val v = BallView(this)
        val (sw, _) = realScreenSize()
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = sw - size - dp(8); y = dp(220) }
        v.setOnTouchListener { _, e -> onBallTouch(e, lp) }
        wm.addView(v, lp)
        ball = v; ballLp = lp
    }

    private fun onBallTouch(e: MotionEvent, lp: WindowManager.LayoutParams): Boolean {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        lastRawX = e.rawX; lastRawY = e.rawY
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = Mode.NONE
                downRawX = e.rawX; downRawY = e.rawY; startX = lp.x; startY = lp.y
                main.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    Mode.NONE -> if (abs(e.rawX - downRawX) > slop || abs(e.rawY - downRawY) > slop) {
                        main.removeCallbacks(longPress)
                        mode = Mode.DRAG
                        hideGreeting()
                        hidePanel()
                    }
                    Mode.DRAG -> {
                        lp.x = startX + (e.rawX - downRawX).toInt()
                        lp.y = startY + (e.rawY - downRawY).toInt()
                        runCatching { wm.updateViewLayout(ball, lp) }
                    }
                    Mode.SELECT -> passiveSelect?.setCorners(anchorX, anchorY, e.rawX, e.rawY)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                main.removeCallbacks(longPress)
                val up = e.actionMasked == MotionEvent.ACTION_UP
                when (mode) {
                    Mode.DRAG -> snapToEdge(lp)
                    Mode.SELECT -> finishPassiveSelect(up)
                    Mode.NONE -> if (up) onBallTap()
                }
                mode = Mode.NONE
            }
        }
        return true
    }

    private fun snapToEdge(lp: WindowManager.LayoutParams) {
        val (sw, sh) = realScreenSize()
        val size = lp.width
        val targetX = if (lp.x + size / 2 < sw / 2) dp(4) else sw - size - dp(4)
        val targetY = lp.y.coerceIn(dp(24), sh - size - dp(48))
        val fromX = lp.x
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 160
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.x = (fromX + (targetX - fromX) * f).toInt(); lp.y = targetY
                runCatching { wm.updateViewLayout(ball, lp) }
            }
            start()
        }
    }

    private fun onBallTap() {
        if (autoActive) { stopAuto("Dihentikan."); return }   // ketuk bola = Stop saat Auto Answer berjalan
        val now = SystemClock.uptimeMillis()
        tapCount = if (now - lastTapUp < 400) tapCount + 1 else 1
        lastTapUp = now
        main.removeCallbacks(tapRunnable)
        if (cfg().tripleTap) {
            if (tapCount >= 3) { tapCount = 0; showTouchSelection() }
            else main.postDelayed(tapRunnable, 380)
        } else {
            tapCount = 0; togglePanel()
        }
    }

    /** Tekan lama bola lalu tarik ke layar = pilih area (kotak dari titik tekan ke posisi jari). */
    private fun onBallLongPress() {
        if (mode != Mode.NONE) return
        mode = Mode.SELECT
        hidePanel()
        ball?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        ball?.active = true
        anchorX = lastRawX; anchorY = lastRawY
        val v = SelectionView(this, false, pal).apply {
            hintText = "Tarik lalu lepas untuk mengambil area"
            setCorners(anchorX, anchorY, anchorX, anchorY)
        }
        passiveSelect = v
        wm.addView(v, fullScreenLp(false))
    }

    private fun finishPassiveSelect(up: Boolean) {
        val v = passiveSelect
        val r = v?.rect
        passiveSelect = null
        ball?.active = false
        if (v != null) safeRemove(v)
        if (!up || r == null || r.width() < dp(40) || r.height() < dp(40)) {
            if (up) toast("Area terlalu kecil. Tarik lebih jauh.")
            return
        }
        capture(Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt()), cfg().autoAnswer)
    }

    // ---------------------------------------------------------------- panel

    private var ballInvisible = false

    /** Baris menu: tile ikon + judul + subjudul (sama dengan _MenuItem di FloatingRobot). */
    private fun menuRow(
        icon: Int,
        label: String,
        subtitle: String,
        destructive: Boolean = false,
        onClick: () -> Unit,
    ): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(6), dp(8), dp(6), dp(8))
        isClickable = true
        setOnClickListener { onClick() }
        val accent = if (destructive) 0xFFFF6B7A.toInt() else pal.accent
        addView(android.widget.ImageView(this@ArcOverlayService).apply {
            setImageResource(icon)
            setColorFilter(accent)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor((accent and 0x00FFFFFF) or 0x1F000000)
                cornerRadius = dp(10).toFloat()
            }
        }, LinearLayout.LayoutParams(dp(34), dp(34)))
        val col = LinearLayout(this@ArcOverlayService).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        col.addView(TextView(this@ArcOverlayService).apply {
            text = label
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(if (destructive) 0xFFFF6B7A.toInt() else pal.ink)
        })
        if (subtitle.isNotEmpty()) {
            col.addView(TextView(this@ArcOverlayService).apply {
                text = subtitle
                textSize = 11f
                setTextColor(pal.muted)
            })
        }
        addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    }

    /** Kept for small action buttons on result card. */
    private fun neoBtn(label: String, fill: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(if (fill == pal.coral || fill == 0xFFFF6B7A.toInt()) Color.WHITE else pal.ink)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = glassBox(this@ArcOverlayService, fill, pal.border, 12)
        setOnClickListener { onClick() }
    }

    private fun togglePanel() { if (panel != null) hidePanel() else showPanel() }

    private fun hidePanel() { safeRemove(panel); panel = null }

    private fun showPanel() {
        hideGreeting()
        val b = ball ?: return
        val blp = ballLp ?: return
        pal = Palette.from(this, cfg().themeMode)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            minimumWidth = dp(260)
            setPadding(dp(14), dp(14), dp(14), dp(10))
            background = glassBox(this@ArcOverlayService, pal.bg, pal.border, 18)
        }
        fun add(btn: View) {
            col.addView(btn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(4) })
        }
        // header: avatar robot + sapaan
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(10))
        }
        head.addView(RobotAvatarView(this, true), LinearLayout.LayoutParams(dp(40), dp(40)))
        val hc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        hc.addView(TextView(this).apply {
            text = "Halo!"; textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(pal.ink)
        })
        hc.addView(TextView(this).apply {
            text = "Ada yang bisa dibantu?"; textSize = 11f; setTextColor(pal.muted)
        })
        head.addView(hc)
        col.addView(head)
        col.addView(View(this).apply { setBackgroundColor(0x14FFFFFF) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply { bottomMargin = dp(4) })
        // Menu sama dengan FloatingRobot mafia.ai (bukan menu Nword)
        add(menuRow(R.drawable.ic_menu_screen, "Auto lihat layar", "Scan & analisis layar") {
            hidePanel(); capture(null, false)
        })
        add(menuRow(R.drawable.ic_menu_robot, "Auto", "Play: AI jawab sendiri") {
            hidePanel(); showAutoCard()
        })
        add(menuRow(
            if (ballInvisible) R.drawable.ic_menu_eye else R.drawable.ic_menu_eye_off,
            if (ballInvisible) "Tampilkan robot" else "Invisible",
            if (ballInvisible) "Kembalikan robot" else "Sembunyikan, hanya titik",
        ) {
            hidePanel()
            ballInvisible = !ballInvisible
            ball?.invisible = ballInvisible
            ball?.invalidate()
        })
        add(menuRow(R.drawable.ic_menu_screen, "Ulangan Anti Detect", "Masukkan link quiz → bypass") {
            hidePanel()
            showUrlPrompt()
        })
        add(menuRow(R.drawable.ic_menu_power, "Close", "Tutup aplikasi", destructive = true) {
            hidePanel(); stopSelf()
        })

        val root = FrameLayout(this).apply {
            addView(col)
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) { hidePanel(); true } else false }
        }
        root.measure(
            View.MeasureSpec.makeMeasureSpec(dp(260), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val (sw, sh) = realScreenSize()
        val pw = root.measuredWidth; val ph = root.measuredHeight
        val ballRight = blp.x + blp.width / 2 > sw / 2
        val px = if (ballRight) blp.x - pw - dp(6) else blp.x + blp.width + dp(6)
        val py = blp.y.coerceIn(dp(24), maxOf(dp(24), sh - ph - dp(48)))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px.coerceAtLeast(0); y = py }
        wm.addView(root, lp)
        panel = root
        b.bringToFront()
    }

    // ---------------------------------------------------------------- selection (touch)

    /** Dipanggil juga oleh ArcAccessibilityService saat tombol Accessibility ditekan. */
    fun beginAreaSelection() = main.post { showTouchSelection() }

    private fun showTouchSelection() {
        if (touchSelect != null) return
        hidePanel(); closeCard()
        pal = Palette.from(this, cfg().themeMode)
        val root = FrameLayout(this)
        val sel = SelectionView(this, true, pal)
        root.addView(sel, FrameLayout.LayoutParams(-1, -1))
        val cancel = neoBtn("Batal", pal.coral) { removeTouchSelection() }
        root.addView(cancel, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(48); rightMargin = dp(20)
        })
        sel.onSelected = { r ->
            if (r.width() < dp(40) || r.height() < dp(40)) {
                toast("Area terlalu kecil."); sel.rect = null; sel.invalidate()
            } else {
                removeTouchSelection()
                capture(r, cfg().autoAnswer)
            }
        }
        touchSelect = root
        wm.addView(root, fullScreenLp(true))
        ball?.visibility = View.INVISIBLE
    }

    private fun removeTouchSelection() {
        safeRemove(touchSelect); touchSelect = null
        ball?.visibility = View.VISIBLE
    }

    // ---------------------------------------------------------------- capture + AI

    private fun capture(rect: Rect?, auto: Boolean) {
        val cap = capturer ?: run { toast("Capture belum siap."); return }
        closeCard()
        ball?.visibility = View.INVISIBLE   // sembunyikan semua UI Arc sebelum ambil frame
        val (sw, sh) = realScreenSize()
        main.postDelayed({
            val jpeg = try { cap.captureJpeg(rect, sw, sh) } catch (e: Exception) { null }
            ball?.visibility = View.VISIBLE
            if (jpeg == null) { toast("Belum ada frame layar. Coba lagi."); return@postDelayed }
            lastJpeg = jpeg
            buildCard()
            ask("", auto)
        }, 320)
    }

    private fun ask(userQuestion: String, auto: Boolean) {
        val jpeg = lastJpeg ?: return
        val q = userQuestion.trim()
        val prompt = when {
            auto -> Prompts.AUTO_ANSWER + (if (q.isNotEmpty()) "\n\nCatatan pengguna: $q" else "")
            q.isEmpty() -> Prompts.READ_AND_ANSWER
            else -> "Pertanyaan pengguna: $q\nJawab berdasarkan gambar layar ini."
        }
        lastQuestion = if (auto) "Auto Answer (layar)" else if (q.isEmpty()) "Baca & jawab layar" else q
        lastAnswer = ""
        showLoading(if (auto) "Membaca semua soal dan memverifikasi jawaban..." else "Menganalisis layar...")
        val id = ++requestId
        val config = cfg()
        io.execute {
            val result: Result<String> = try { Result.success(AiClient.ask(config, prompt, jpeg)) } catch (e: Exception) { Result.failure(e) }
            main.post {
                if (id != requestId || card == null) return@post
                result.onSuccess { text ->
                    lastAnswer = text
                    answerTv?.setTextColor(pal.text)
                    answerTv?.text = SimpleMarkdown.render(text, pal, answerTv!!)
                    setStatus("Selesai")
                }.onFailure { err ->
                    showError(err.message ?: err.javaClass.simpleName)
                }
            }
        }
    }

    // ---------------------------------------------------------------- Auto Answer (Play / Stop)

    private fun showAutoCard() {
        closeCard()
        autoLog.clear()
        buildCard(autoMode = true)
        answerTv?.apply {
            setTextColor(pal.muted)
            text = "Buka halaman kuis / Google Form di belakang, lalu tekan Play.\n" +
                "AI membaca layar, memilih jawaban, mengetuknya, dan menggulir sendiri. " +
                "Tombol Kirim/Submit tidak pernah ditekan: periksa lalu kirim sendiri."
        }
    }

    /** Harus di main thread. Sembunyi = INVISIBLE + NOT_TOUCHABLE (jendela INVISIBLE saja tetap menyerap ketukan). */
    private fun applyUi(visible: Boolean) {
        // Saat Auto Answer berjalan, biarkan logo robot tetap terlihat sebagai indikator,
        // tetapi jadikan jendelanya non-touchable agar gesture jatuh ke halaman di bawahnya.
        val keepLogo = !visible && autoActive
        ball?.visibility = if (visible || keepLogo) View.VISIBLE else View.INVISIBLE
        card?.visibility = if (visible) View.VISIBLE else View.INVISIBLE
        fun touch(view: View?, lp: WindowManager.LayoutParams?, canTouch: Boolean) {
            if (view == null || lp == null) return
            lp.flags = if (canTouch) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            runCatching { wm.updateViewLayout(view, lp) }
        }
        touch(ball, ballLp, visible && !keepLogo)
        touch(card, cardLp, visible)
    }

    private fun setUiVisible(visible: Boolean, settleMs: Long = 0) {
        val done = java.util.concurrent.CountDownLatch(1)
        // While Auto Answer is active, never re-show the overlay between actions.
        // It can obscure answer fields and cause accessibility taps to hit the panel.
        if (visible && autoActive) {
            if (settleMs > 0) Thread.sleep(settleMs)
            return
        }
        main.post { try { applyUi(visible) } finally { done.countDown() } }
        done.await(1, java.util.concurrent.TimeUnit.SECONDS)
        if (settleMs > 0) Thread.sleep(settleMs)
    }


    /** Overlay input link quiz → buka Protected Browser. */
    private fun showUrlPrompt() {
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post { showUrlPrompt() }; return }
        val et = EditText(this).apply {
            hint = "Tempel link ujian / Wayground"
            setText("https://wayground.com")
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(0x99FFFFFF.toInt())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0x33FFFFFF)
            }
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val go = TextView(this).apply {
            text = "BUKA"
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xFF6F5CF0.toInt())
            }
            isClickable = true
        }
        val cancel = TextView(this).apply {
            text = "Batal"
            textSize = 13f
            setTextColor(0xCCFFFFFF.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            isClickable = true
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(0xF0171A24.toInt())
                setStroke(dp(1), 0x669A8CFF)
            }
            addView(TextView(this@ArcOverlayService).apply {
                text = "Ulangan Anti Detect"
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(Color.WHITE)
                setPadding(0, 0, 0, dp(6))
            })
            addView(TextView(this@ArcOverlayService).apply {
                text = "Tempel link quiz. Bypass tab/resize/klik kanan aktif di dalam app."
                textSize = 12f
                setTextColor(0x99FFFFFF.toInt())
                setPadding(0, 0, 0, dp(12))
            })
            addView(et, LinearLayout.LayoutParams(-1, -2))
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.END
                setPadding(0, dp(12), 0, 0)
                addView(cancel)
                addView(go, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
            }
            addView(row)
        }
        var dlg: View? = null
        val lp = WindowManager.LayoutParams(
            dp(320), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        go.setOnClickListener {
            val url = et.text.toString().trim().ifBlank { "https://wayground.com" }
            safeRemove(dlg)
            val i = Intent(this, ProtectedBrowser::class.java)
            i.putExtra(ProtectedBrowser.EXTRA_URL, url)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        cancel.setOnClickListener { safeRemove(dlg) }
        runCatching { wm.addView(box, lp); dlg = box }
    }

    // ---- pill melayang status + tombol CANCEL (selalu bisa ditekan saat auto jalan)
    private fun showPill() {
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post { showPill() }; return }
        if (pill != null) return
        val tv = TextView(this).apply {
            text = "AI berpikir..."
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(8), dp(8))
        }
        pillText = tv
        val cancel = TextView(this).apply {
            text = "CANCEL"
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(0xFFE53935.toInt())
            }
            isClickable = true
            setOnClickListener { stopAuto("Dibatalkan.") }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0xF0171A24.toInt())
                setStroke(dp(1), 0x669A8CFF)
            }
            addView(tv)
            addView(cancel)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(48) }
        runCatching { wm.addView(row, lp); pill = row }
    }

    private fun hidePill() {
        if (Looper.myLooper() != Looper.getMainLooper()) { main.post { hidePill() }; return }
        safeRemove(pill); pill = null; pillText = null
    }

    private fun setPill(t: String) { main.post { pillText?.text = t } }

    /** Sembunyikan/tampilkan pill secara sinkron (dipakai sekitar screenshot agar tidak ikut terbaca AI). */
    private fun pillVisible(v: Boolean) {
        // Hanya sembunyikan teks status saat screenshot; tombol CANCEL tetap terlihat & bisa ditekan
        val done = java.util.concurrent.CountDownLatch(1)
        main.post {
            try {
                pillText?.visibility = if (v) View.VISIBLE else View.INVISIBLE
                // pastikan bar CANCEL selalu VISIBLE
                pill?.visibility = View.VISIBLE
            } finally { done.countDown() }
        }
        done.await(1, java.util.concurrent.TimeUnit.SECONDS)
    }

    /** Nomor urut soal (1-based) di antara soal yang sudah terdeteksi. Thread io saja. */
    private fun qIndex(no: String): Int {
        val k = AutoPilot.norm(no)
        var i = seenQ.indexOf(k)
        if (i < 0) { seenQ.add(k); i = seenQ.size - 1 }
        return i + 1
    }

    private fun total() = seenQ.size.toString() + if (totalFinal) "" else "+"

    private fun autoLine(t: String) {
        main.post {
            autoLog.add(t)
            while (autoLog.size > 14) autoLog.removeAt(0)
            answerTv?.setTextColor(pal.text)
            answerTv?.text = autoLog.joinToString("\n")
        }
    }

    private fun autoStatus(t: String) { main.post { setStatus(t) } }

    private fun autoAlive(token: Int) = autoActive && token == autoToken

    /** Tidur dalam potongan kecil supaya Stop langsung terasa. */
    private fun nap(ms: Long, token: Int) {
        var left = ms
        while (left > 0 && autoAlive(token)) { Thread.sleep(minOf(100L, left)); left -= 100 }
    }

    /** Jeda acak mirip manusia (450–1100 ms). */
    private fun humanNap(token: Int) {
        val ms = (450L..1100L).random()
        nap(ms, token)
    }

    private fun startAuto() {
        if (autoActive) { toast("Auto sedang berjalan."); return }
        if (capturer == null) { toast("Capture belum siap."); return }
        if (ArcAccessibilityService.instance == null) {
            toast("Aktifkan Aksesibilitas Screen Helper dulu, lalu tekan Play lagi.")
            runCatching {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return
        }
        val config = cfg()
        if (config.apiKey.isBlank()) { toast("API key belum diisi. Buka Settings dulu."); return }
        val token = ++autoToken
        autoActive = true
        autoLog.clear()
        seenQ.clear(); doneQ.clear(); totalFinal = false
        showPill(); setPill("Membaca soal...")
        ball?.active = true
        setStatus("Auto - berjalan")
        autoLine("Mulai. Overlay disembunyikan agar tidak menutupi soal.")
        // Hide the panel before the first screenshot/gesture; otherwise the overlay can
        // cover Google Forms fields and receive taps intended for the page.
        setUiVisible(false, 180)
        io.execute { runAuto(token, config) }
    }

    /** msg != null: tampilkan pesan di kartu. Aman dipanggil dari thread mana pun. */
    private fun stopAuto(msg: String?) {
        if (!autoActive) return
        autoActive = false
        autoToken++
        main.post {
            hidePill()
            ball?.active = false
            applyUi(true)
            if (msg != null) { setStatus("Auto Answer - berhenti"); autoLine(msg) }
        }
    }

    private fun finishAuto(token: Int, summary: String, transcript: String) {
        if (!autoAlive(token)) return
        autoActive = false
        main.post {
            hidePill()
            ball?.active = false
            applyUi(true)
            setStatus("Auto Answer - selesai")
        }
        autoLine(summary)
        if (transcript.isNotBlank()) NativeStore.addPending(this, "Auto Answer (Play)", transcript + "\n" + summary)
    }

    private fun askPlan(config: NativeStore.Config, jpeg: ByteArray, atEnd: Boolean, token: Int, retry: Boolean = false): AutoPilot.Plan? {
        val prompt = Prompts.AUTOPILOT +
            (if (retry) "\n\nCATATAN: ini putaran ULANG untuk soal yang tadi terlewat/kosong. WAJIB jawab setiap soal kosong yang terlihat; jika ragu pilih jawaban paling mungkin, jangan dilewati." else "") +
            if (atEnd) "\n\nCATATAN: halaman sudah mentok di dasar dan tidak bisa digulir lagi. Isi \"scroll\":\"none\"." else ""
        var attempt = 0
        while (autoAlive(token) && attempt < 3) {
            attempt++
            try {
                val raw = AiClient.ask(config, prompt, jpeg, Prompts.AUTOPILOT_SYSTEM, json = true)
                val plan = AutoPilot.parsePlan(raw)
                if (plan != null) return plan
                if (attempt >= 2) return null
            } catch (e: Exception) {
                val m = e.message.orEmpty()
                val transient = m.contains("429") || m.contains("500") || m.contains("502") ||
                    m.contains("503") || m.contains("timed out", true) || m.contains("Unable to resolve", true)
                if (!transient || attempt >= 3) throw e
                autoLine("AI sibuk, mencoba lagi...")
                nap(2000L * attempt, token)
            }
        }
        return null
    }

    /** Gulir ke atas sampai layar tidak bergeser lagi (maks 25 kali). */
    private fun scrollToTop(token: Int, svc: ArcAccessibilityService, sw: Int, sh: Int) {
        var prev: IntArray? = null
        for (i in 0 until 25) {
            if (!autoAlive(token)) return
            setUiVisible(false, 40)
            svc.swipe(sw * 0.5f, sh * 0.30f, sw * 0.5f, sh * 0.85f, 200)
            nap((380L..650L).random(), token)
            val jpeg = try { capturer?.captureJpeg(null, sw, sh) } catch (e: Exception) { null }
            setUiVisible(true)
            val sig = if (jpeg != null) AutoPilot.signature(jpeg) else null
            val p = prev
            if (sig != null && p != null && AutoPilot.similar(sig, p)) return
            prev = sig
        }
    }

    /** Loop utama (thread io): baca layar -> tanya AI -> ketuk jawaban -> verifikasi -> scroll -> ulangi. */
    private fun runAuto(token: Int, config: NativeStore.Config) {
        val (sw, sh) = realScreenSize()
        val transcript = StringBuilder()
        var steps = 0
        var answered = 0
        var prevSig: IntArray? = null
        var lastWasScroll = false
        var atEnd = false
        var prevKey: String? = null
        var sameCount = 0
        var lastReport = ""
        var justActed = false
        var pass = 1          // putaran di halaman ini (1 = isi, 2+ = verifikasi dari atas)
        var passActs = 0      // jumlah soal yang diisi pada putaran ini
        essayTries.clear()
        try {
            while (autoAlive(token)) {
                justActed = false
                // Accessibility can be disabled while the worker is running; stop cleanly.
                if (ArcAccessibilityService.instance == null) {
                    finishAuto(token, "Berhenti: izin Aksesibilitas dimatikan. Aktifkan kembali lalu tekan Play.", transcript.toString())
                    return
                }
                if (++steps > maxAutoSteps) { finishAuto(token, "Berhenti: batas langkah tercapai. $answered soal dijawab (belum terverifikasi).", transcript.toString()); return }

                autoStatus("Auto Answer - membaca layar")
                setPill("Soal ${doneQ.size}/${total()} · membaca layar")
                setUiVisible(false, 25)
                pillVisible(false)
                val jpeg = try { capturer?.captureJpeg(null, sw, sh, 1000, 70) } catch (e: Exception) { null }
                pillVisible(true)
                setUiVisible(true)
                if (!autoAlive(token)) return
                if (jpeg == null) { finishAuto(token, "Belum ada frame layar. Coba Play lagi.", transcript.toString()); return }

                val sig = AutoPilot.signature(jpeg)
                if (lastWasScroll) atEnd = sig != null && prevSig != null && AutoPilot.similar(sig, prevSig)
                prevSig = sig
                lastWasScroll = false

                autoStatus("Auto Answer - AI berpikir")
                setPill("Soal ${doneQ.size}/${total()} · AI berpikir")
                val plan = askPlan(config, jpeg, atEnd, token, pass > 1)
                if (!autoAlive(token)) return
                if (plan == null) { finishAuto(token, "Berhenti: balasan AI tidak terbaca.", transcript.toString()); return }

                val svc = ArcAccessibilityService.instance
                if (svc == null) { finishAuto(token, "Berhenti: Aksesibilitas mafia.ai mati.", transcript.toString()); return }

                // progres: catat soal yang terlihat & yang sudah terisi
                for (q in plan.questions) { qIndex(q.no); if (q.status == "terisi") doneQ.add(AutoPilot.norm(q.no)) }
                if (plan.finished || (!plan.scroll && plan.next == null) || atEnd) totalFinal = true

                // 0) laporan deteksi: berapa soal sudah terisi / masih kosong
                if (plan.questions.isNotEmpty()) {
                    val filled = plan.questions.filter { it.status == "terisi" }
                    val empty = plan.questions.count { it.status == "kosong" }
                    val unclear = plan.questions.count { it.status == "tidak_jelas" }
                    val sig2 = plan.questions.joinToString("|") { "${AutoPilot.norm(it.no)}:${it.status}" }
                    if (sig2 != lastReport) {
                        lastReport = sig2
                        var line = "Terdeteksi ${plan.questions.size} soal: ${filled.size} terisi, $empty kosong"
                        if (unclear > 0) line += ", $unclear tidak jelas"
                        autoLine(line)
                        if (filled.isNotEmpty())
                            autoLine("Sudah terisi: " + filled.joinToString(", ") { "\"${it.no.take(20)}\"" + if (it.selected.isNotBlank()) "(${it.selected})" else "" })
                    }
                }

                // 1) ketuk jawaban yang belum terisi
                if (plan.acts.isNotEmpty()) {
                    val key = plan.acts.map { "${AutoPilot.norm(it.no)}:${it.answer}" }.sorted().joinToString("|")
                    sameCount = if (key == prevKey) sameCount + 1 else 0
                    prevKey = key
                    if (sameCount >= 2) {
                        finishAuto(token, "Berhenti: ketukan tidak membuat jawaban terpilih. Cek Aksesibilitas / izin gesture.", transcript.toString())
                        return
                    }
                    autoStatus("Auto Answer - menjawab")
                    emptyRetry = 0
                    passActs += plan.acts.size
                    if (pass > 1) autoLine("Ditemukan ${plan.acts.size} soal belum terisi, mengisi ulang")
                    setUiVisible(false, 30)
                    // Percobaan ulang: geser ketukan ke baris teks opsi (lebih mudah kena daripada lingkaran kecil)
                    val dx = if (sameCount >= 1) sw * 0.08f else 0f
                    for (a in plan.acts) {
                        if (!autoAlive(token)) break
                        if (ArcAccessibilityService.instance == null) {
                            finishAuto(token, "Berhenti: izin Aksesibilitas dimatikan saat proses berjalan.", transcript.toString())
                            return
                        }
                        setPill("Mengerjakan soal ${qIndex(a.no)}/${total()}")
                        val ok = svc.tap(a.x / 1000f * sw + dx, a.y / 1000f * sh)
                        if (ok) doneQ.add(AutoPilot.norm(a.no))
                        val line = "> ${a.no.take(34)}\n   = ${a.answer}" + if (ok) "" else "  (ketukan gagal)"
                        autoLine(line)
                        if (sameCount == 0) transcript.append(line).append('\n')
                        humanNap(token)
                    }
                    setUiVisible(true)
                    if (sameCount == 0) answered += plan.acts.size
                    justActed = true
                    // Cepat: langsung gulir tanpa baca ulang. Yang terlewat dikejar di putaran balik.
                    if (plan.essays.isEmpty() && !(plan.scroll && !atEnd && !plan.finished)) continue
                }

                // 1b) soal uraian: ketuk kolom, ketik jawaban dari AI. Maks 2 percobaan per soal supaya tidak berputar.
                val essays = plan.essays.filter { (essayTries[AutoPilot.norm(it.no)] ?: 0) < 2 }
                if (essays.isNotEmpty()) {
                    autoStatus("Menulis uraian")
                    setUiVisible(false, 30)
                    for (e in essays) {
                        if (!autoAlive(token)) break
                        if (ArcAccessibilityService.instance == null) {
                            finishAuto(token, "Berhenti: izin Aksesibilitas dimatikan saat menulis uraian.", transcript.toString())
                            return
                        }
                        AutoPilot.norm(e.no).let { essayTries[it] = (essayTries[it] ?: 0) + 1 }
                        setPill("Mengerjakan soal ${qIndex(e.no)}/${total()} (uraian)")
                        val tapped = svc.tap(e.x / 1000f * sw, e.y / 1000f * sh)
                        if (!tapped) {
                            autoLine("> ${e.no.take(34)} — kolom tidak berhasil difokuskan; coba pindahkan posisi kolom.")
                            nap(250, token)
                            continue
                        }
                        nap(250, token)   // tunggu kolom fokus & keyboard muncul
                        if (!autoAlive(token)) break
                        // Kirim koordinat kolom yang diketuk supaya Accessibility mencari
                        // field uraian yang tepat, bukan field lain yang kebetulan fokus.
                        val essayX = e.x / 1000f * sw
                        val essayY = e.y / 1000f * sh
                        val ok = svc.typeText(e.text, essayX, essayY)
                        val line = "> ${e.no.take(34)}\n   = " + e.text.take(70) + (if (e.text.length > 70) "..." else "") + if (ok) "" else "  (gagal mengetik)"
                        autoLine(line)
                        transcript.append("${e.no} (uraian): ${e.text}\n")
                        if (ok) { answered++; passActs++; doneQ.add(AutoPilot.norm(e.no)) }
                        nap((300L..550L).random(), token)
                    }
                    svc.hideKeyboardIfShown()
                    nap((400L..700L).random(), token)
                    setUiVisible(true)
                    prevKey = null; sameCount = 0
                    continue   // baca ulang: verifikasi kolom terisi
                }
                prevKey = null; sameCount = 0

                // Jangan menggulir selagi masih ada soal kosong yang utuh: minta AI memeriksa ulang dulu.
                if (!justActed && plan.questions.any { it.status == "kosong" } && emptyRetry < 2) {
                    emptyRetry++
                    autoLine("Ada soal kosong belum terjawab, periksa ulang...")
                    nap((350L..600L).random(), token)
                    continue
                }
                emptyRetry = 0
                if (plan.skipped.isNotEmpty()) {
                    val line = "Dilewati: " + plan.skipped.joinToString(", ")
                    autoLine(line); transcript.append(line).append('\n')
                }
                // 2) gulir ke bawah selama masih ada soal di bawah
                if (!plan.finished && plan.scroll && !atEnd) {
                    autoStatus("Auto Answer - menggulir")
                    setUiVisible(false, 30)
                    svc.swipe(sw * 0.5f, sh * 0.74f, sw * 0.5f, sh * 0.28f, 250)
                    setUiVisible(true)
                    nap((500L..900L).random(), token)
                    lastWasScroll = true
                    continue
                }

                // 3) ujung halaman. Jika putaran ini masih mengisi soal, periksa ulang semuanya dari atas
                val missing = seenQ.withIndex().filter { it.value !in doneQ }.map { it.index + 1 }
                if (missing.isNotEmpty() && pass < maxPasses) {
                    pass++; passActs = 0
                    autoStatus("Auto Answer - kembali ke soal kosong")
                    autoLine("Soal kosong: " + missing.joinToString(", ") + ". Kembali ke atas & jawab ulang (putaran $pass)")
                    setPill("Kembali ke soal " + missing.joinToString(", "))
                    scrollToTop(token, svc, sw, sh)
                    prevSig = null; atEnd = false; lastWasScroll = false; prevKey = null; sameCount = 0; lastReport = ""
                    continue
                }

                // 4) halaman berikutnya (formulir multi-halaman)
                val nx = plan.next
                if (!plan.finished && nx != null) {
                    autoStatus("Auto Answer - halaman berikutnya")
                    autoLine("Semua terisi. Ke halaman berikutnya")
                    setUiVisible(false, 30)
                    svc.tap(nx.x / 1000f * sw, nx.y / 1000f * sh)
                    setUiVisible(true)
                    nap(700, token)
                    prevSig = null; atEnd = false; lastWasScroll = false; lastReport = ""
                    pass = 1; passActs = 0; essayTries.clear()
                    seenQ.clear(); doneQ.clear(); totalFinal = false
                    continue
                }

                val left = seenQ.withIndex().filter { it.value !in doneQ }.map { it.index + 1 }
                val verified = if (left.isEmpty()) "semua soal terisi" else "soal ${left.joinToString(", ")} masih kosong, cek manual"
                finishAuto(token, "Selesai ($verified). $answered soal dijawab. Periksa lalu tekan Kirim sendiri.", transcript.toString())
                return
            }
        } catch (e: Exception) {
            finishAuto(token, "Berhenti: " + (e.message ?: e.javaClass.simpleName).take(160), transcript.toString())
        }
    }

    // ---------------------------------------------------------------- result card

    private class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }
    }

    private class CardRoot(ctx: Context, val onBack: () -> Unit) : FrameLayout(ctx) {
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP) { onBack(); return true }
            return super.dispatchKeyEvent(e)
        }
    }

    private fun gradient(c1: Int, c2: Int, radiusDp: Int, strokeColor: Int = 0, orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.TOP_BOTTOM) =
        GradientDrawable(orientation, intArrayOf(c1, c2)).apply {
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != 0) setStroke(dp(1), strokeColor)
        }

    private fun iconView(res: Int, sizeDp: Int, tint: Int) = android.widget.ImageView(this).apply {
        setImageResource(res); setColorFilter(tint)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    /** Tombol aksi: ikon vektor + label. primary = violet gradient, lainnya glass. */
    private fun actionBtn(icon: Int, label: String, primary: Boolean, danger: Boolean = false, onClick: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(dp(10), 0, dp(10), 0)
        background = if (primary)
            gradient(0xFF9A8CFF.toInt(), 0xFF6F5CF0.toInt(), 14, 0, GradientDrawable.Orientation.LEFT_RIGHT)
        else if (danger) gradient(0x33FF6B7A, 0x22FF6B7A, 14, 0x66FF6B7A)
        else gradient(0x14FFFFFF, 0x0DFFFFFF, 14, 0x1FFFFFFF)
        isClickable = true
        setOnClickListener { onClick() }
        addView(iconView(icon, 16, if (primary) Color.WHITE else if (danger) 0xFFFF8A96.toInt() else pal.ink))
        addView(TextView(this@ArcOverlayService).apply {
            text = label; textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(if (primary) Color.WHITE else if (danger) 0xFFFF8A96.toInt() else pal.ink)
            setPadding(dp(7), 0, 0, 0)
        })
    }

    private fun setStatus(t: String) { statusTv?.text = t }

    private fun showLoading(msg: String) {
        answerTv?.apply {
            setTextColor(pal.muted)
            text = msg
        }
        setStatus("Memproses")
    }

    private fun showError(raw: String) {
        val hint = when {
            raw.contains("404") -> "Model AI tidak tersedia lagi. Ganti model di Settings > Model."
            raw.contains("401") || raw.contains("403") || raw.contains("API key", true) -> "Periksa API key di Settings."
            raw.contains("429") -> "Kuota atau batas permintaan tercapai. Coba lagi sebentar lagi."
            else -> ""
        }
        val sb = SpannableStringBuilder()
        sb.append("Terjadi kesalahan\n")
        sb.setSpan(StyleSpan(android.graphics.Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(ForegroundColorSpan(0xFFFF6B7A.toInt()), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (hint.isNotEmpty()) {
            val s = sb.length
            sb.append(hint).append('\n')
            sb.setSpan(ForegroundColorSpan(pal.ink), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val s2 = sb.length
        sb.append(raw.take(280))
        sb.setSpan(ForegroundColorSpan(pal.muted), s2, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(RelativeSizeSpan(0.85f), s2, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        answerTv?.text = sb
        setStatus("Gagal")
    }

    private fun buildCard(autoMode: Boolean = false) {
        pal = Palette.from(this, cfg().themeMode)
        val (_, sh) = realScreenSize()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(18))
            background = gradient(0xFA1D2130.toInt(), 0xFA11131C.toInt(), 28, 0x26FFFFFF)
            elevation = dp(16).toFloat()
        }
        // grab handle
        box.addView(View(this).apply { background = gradient(0x33FFFFFF, 0x33FFFFFF, 2) },
            LinearLayout.LayoutParams(dp(36), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(12) })

        // header: avatar + judul + status + tombol tutup
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(RobotAvatarView(this, false), LinearLayout.LayoutParams(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titles.addView(TextView(this).apply {
            text = "mafia.ai"; textSize = 17f; setTextColor(pal.text)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        val st = TextView(this).apply { text = if (autoMode) "Auto Answer - siap" else "Screen Assistant"; textSize = 12f; setTextColor(pal.accent) }
        statusTv = st
        titles.addView(st)
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(android.widget.FrameLayout(this).apply {
            background = GradientDrawable().apply { setColor(0x1AFFFFFF); shape = GradientDrawable.OVAL }
            isClickable = true
            setOnClickListener { closeCard() }
            addView(iconView(R.drawable.ic_close, 18, pal.ink),
                FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(38), dp(38)))
        box.addView(header)

        // area jawaban (panel terangkat)
        val tv = TextView(this).apply {
            textSize = 15f; setTextColor(pal.text); setLineSpacing(0f, 1.2f)
            setTextIsSelectable(true)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        answerTv = tv
        val scroll = MaxHeightScroll(this, (sh * (if (autoMode) 0.22f else 0.38f)).toInt()).apply {
            isVerticalScrollBarEnabled = false
            background = gradient(0x0FFFFFFF, 0x0AFFFFFF, 18, 0x14FFFFFF)
            addView(tv)
        }
        box.addView(scroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // aksi
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun lpA(last: Boolean = false) = LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (!last) rightMargin = dp(8) }
        if (autoMode) {
            actions.addView(actionBtn(R.drawable.ic_play, "Play", true) { startAuto() }, lpA())
            actions.addView(actionBtn(R.drawable.ic_stop, "Stop", false, danger = true) { stopAuto("Dihentikan.") }, lpA(true))
        } else {
            actions.addView(actionBtn(R.drawable.ic_copy, "Salin", false) { copyAnswer() }, lpA())
            actions.addView(actionBtn(R.drawable.ic_bolt, "Auto", true) { ask("", true) }, lpA())
            actions.addView(actionBtn(R.drawable.ic_bookmark, "Simpan", false) { saveToChat() }, lpA(true))
        }
        box.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // tanya lanjutan (tidak dipakai di mode Auto Answer)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(this).apply {
            hint = "Tanya lanjutan tentang gambar ini"
            textSize = 14f; setTextColor(pal.text); setHintTextColor(pal.muted)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 3
            background = gradient(0x14FFFFFF, 0x0DFFFFFF, 24, 0x1FFFFFFF)
            setPadding(dp(18), dp(11), dp(18), dp(11))
        }
        inputEt = et
        row.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(android.widget.FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF9A8CFF.toInt(), 0xFF6F5CF0.toInt()))
                .apply { shape = GradientDrawable.OVAL }
            isClickable = true
            setOnClickListener {
                val q = et.text.toString()
                if (q.isNotBlank()) {
                    (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
                    et.setText("")
                    ask(q, false)
                }
            }
            addView(iconView(R.drawable.ic_send, 20, Color.WHITE),
                FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { leftMargin = dp(10) })
        if (!autoMode) box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val root = CardRoot(this) { closeCard() }.apply {
            setPadding(dp(8), 0, dp(8), dp(8))
            addView(box)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(root, lp)
        card = root; cardLp = lp
        ball?.bringToFront()
    }

    private fun closeCard() {
        stopAuto(null)                     // menutup kartu = menghentikan Auto Answer
        requestId++                       // batalkan hasil request yang masih jalan
        safeRemove(card); card = null; answerTv = null; statusTv = null; inputEt = null
        lastJpeg = null                    // buang gambar dari memori
        lastAnswer = ""
    }

    private fun copyAnswer() {
        if (lastAnswer.isBlank()) { toast("Belum ada jawaban."); return }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("mafia.ai", lastAnswer))
        toast("Jawaban disalin")
    }

    private fun saveToChat() {
        if (lastAnswer.isBlank()) { toast("Belum ada jawaban."); return }
        NativeStore.addPending(this, lastQuestion, lastAnswer)   // teks saja, tanpa screenshot
        toast("Disimpan. Buka mafia.ai > History")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- lifecycle

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        capturer?.onConfigChanged()
        hidePanel()
        removeTouchSelection()
        ballLp?.let { lp ->
            val (sw, sh) = realScreenSize()
            lp.x = lp.x.coerceIn(0, sw - lp.width); lp.y = lp.y.coerceIn(0, sh - lp.height)
            runCatching { wm.updateViewLayout(ball, lp) }
        }
    }

    override fun onDestroy() {
        autoActive = false; autoToken++
        main.removeCallbacksAndMessages(null)
        main.removeCallbacks(greetRunnable); hideGreeting()
        hidePanel(); hidePill(); safeRemove(touchSelect); safeRemove(passiveSelect); closeCard(); safeRemove(ball)
        ball = null; touchSelect = null; passiveSelect = null
        capturer?.release(); capturer = null
        io.shutdownNow()
        val was = running
        running = false; instance = null
        if (was) stateListener?.invoke(false)
        super.onDestroy()
    }
}
