package com.mafia.ai

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 1) Tombol Accessibility (nav bar / floating button) untuk membuka pemilih area.
 * 2) "Tangan" Auto Answer: mengetuk dan menggulir layar lewat dispatchGesture.
 * Service ini TIDAK membaca isi layar (canRetrieveWindowContent=false); layar dibaca lewat screenshot.
 */
class ArcAccessibilityService : AccessibilityService() {

    // dispatchGesture callback harus memakai Looper yang valid walau pemanggil berasal dari thread IO.
    private val gestureHandler = Handler(Looper.getMainLooper())

    companion object {
        @Volatile var instance: ArcAccessibilityService? = null
    }

    private val callback = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) {
            val svc = ArcOverlayService.instance
            if (svc != null) svc.beginAreaSelection()
            else Toast.makeText(
                this@ArcAccessibilityService,
                "Aktifkan Floating Assistant di Settings dulu.", Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        accessibilityButtonController.registerAccessibilityButtonCallback(callback)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        runCatching { accessibilityButtonController.unregisterAccessibilityButtonCallback(callback) }
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** Ketuk satu titik (koordinat piksel layar). Blocking: JANGAN panggil dari main thread. */
    fun tap(x: Float, y: Float): Boolean {
        // jitter kecil biar koordinat tidak selalu pas di tengah (lebih mirip manusia)
        val jx = (-14..14).random().toFloat()
        val jy = (-12..12).random().toFloat()
        val p = Path().apply { moveTo(x + jx, y + jy) }
        // durasi tekan sedikit acak 35–70 ms
        return gesture(p, (35L..70L).random())
    }

    /** Geser dari (x1,y1) ke (x2,y2). Blocking: JANGAN panggil dari main thread. */
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 500): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return gesture(p, durationMs)
    }

    /**
     * Ketik [text] ke kolom input yang sedang fokus (setelah diketuk). Blocking, jangan dari main thread.
     * Utama: ACTION_SET_TEXT; cadangan: tempel lewat clipboard.
     */
    fun typeText(text: String, screenX: Float? = null, screenY: Float? = null): Boolean {
        // Semua akses node/clipboard dilakukan di main looper. Cari node berdasarkan
        // fokus terlebih dahulu, lalu gunakan koordinat kolom yang baru saja diketuk.
        repeat(4) {
            val done = CountDownLatch(1)
            val success = AtomicBoolean(false)
            val posted = gestureHandler.post {
                try {
                    val node = findInputNode(screenX, screenY)
                    if (node != null) {
                        runCatching { node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) }
                        val args = Bundle().apply {
                            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                        }
                        val setOk = runCatching {
                            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                        }.getOrDefault(false)
                        if (setOk) {
                            // Pastikan framework sudah menerima teks sebelum melaporkan sukses.
                            success.set(runCatching { node.text?.toString() == text || node.isEditable }.getOrDefault(true))
                        } else {
                            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("answer", text))
                            val focused = runCatching { node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) }.getOrDefault(false)
                            success.set((focused || node.isFocused) && runCatching {
                                node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                            }.getOrDefault(false))
                        }
                    }
                } catch (_: Throwable) {
                    success.set(false)
                } finally {
                    done.countDown()
                }
            }
            if (!posted) return false
            if (!done.await(2000, TimeUnit.MILLISECONDS)) return false
            if (success.get()) return true
            Thread.sleep(180)
        }
        return false
    }

    private fun findInputNode(screenX: Float?, screenY: Float?): AccessibilityNodeInfo? {
        // Root aktif tidak selalu merupakan halaman web yang menerima input (misalnya
        // ketika ada overlay). Periksa semua window yang dapat diakses.
        runCatching { rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }
            .getOrNull()?.let { if (it.isEditable) return it }

        val editableNodes = ArrayList<AccessibilityNodeInfo>()
        fun collect(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 35) return
            if (node.isEditable && node.isEnabled) editableNodes.add(AccessibilityNodeInfo.obtain(node))
            for (i in 0 until node.childCount) {
                val child = runCatching { node.getChild(i) }.getOrNull() ?: continue
                collect(child, depth + 1)
            }
        }
        runCatching {
            windows.sortedByDescending { it.isActive }.forEach { window ->
                collect(window.root, 0)
            }
        }
        if (editableNodes.isEmpty()) return null

        // Prioritaskan kolom znajdujące się pod współrzędnymi tapnięcia, a następnie
        // najbliższe pole tekstowe. To ważne dla formularzy webowych z wieloma polami.
        if (screenX != null && screenY != null) {
            val target = android.graphics.Rect()
            var best: AccessibilityNodeInfo? = null
            var bestDistance = Float.MAX_VALUE
            for (node in editableNodes) {
                node.getBoundsInScreen(target)
                if (target.contains(screenX.toInt(), screenY.toInt())) return node
                val cx = (target.left + target.right) / 2f
                val cy = (target.top + target.bottom) / 2f
                val d = kotlin.math.hypot(cx - screenX, cy - screenY)
                if (d < bestDistance) { bestDistance = d; best = node }
            }
            if (bestDistance <= 260f) return best
        }
        return editableNodes.firstOrNull { it.isFocused }
    }

    /** Tutup keyboard hanya bila memang tampil (BACK tanpa keyboard bisa keluar dari halaman). */
    fun hideKeyboardIfShown() {
        val shown = runCatching { windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } }.getOrDefault(false)
        if (shown) performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val done = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val desc = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        val cb = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { ok.set(true); done.countDown() }
            override fun onCancelled(gestureDescription: GestureDescription?) { done.countDown() }
        }
        // dispatchGesture must be initiated on the service main thread. Posting it also
        // avoids framework code trying to create a Handler on an IO/worker thread.
        val accepted = AtomicBoolean(false)
        val posted = gestureHandler.post {
            try {
                accepted.set(dispatchGesture(desc, cb, gestureHandler))
                if (!accepted.get()) done.countDown()
            } catch (_: Throwable) {
                done.countDown()
            }
        }
        if (!posted) return false
        val completed = done.await(durationMs + 3000, TimeUnit.MILLISECONDS)
        return completed && accepted.get() && ok.get()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* sengaja kosong */ }
    override fun onInterrupt() {}
}
