package com.mafia.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import kotlin.math.abs

/** Parser rencana aksi dari AI + pembanding frame (deteksi dasar halaman). Tanpa dependensi Android UI. */
object AutoPilot {

    data class Act(val no: String, val answer: String, val x: Float, val y: Float)   // x,y: 0..1000
    /** Soal uraian/esai/isian: kolom jawaban diketuk di (x,y) lalu [text] diketik. */
    data class Essay(val no: String, val text: String, val x: Float, val y: Float)
    data class Pt(val x: Float, val y: Float)
    /** status: "terisi" | "kosong" | "tidak_jelas" */
    data class Q(val no: String, val status: String, val selected: String)
    data class Plan(
        val questions: List<Q>,
        val acts: List<Act>,
        val essays: List<Essay>,
        val skipped: List<String>,
        val scroll: Boolean,
        val next: Pt?,
        val finished: Boolean,
        val note: String,
    )

    /** Kunci stabil dari teks soal (tanpa nomor): huruf/angka saja, 28 karakter pertama. */
    fun norm(q: String): String = q.lowercase().filter { it.isLetterOrDigit() }.take(28)

    private fun JSONObject.qText(): String =
        optString("q", "").ifBlank { optString("no", "") }.trim().ifBlank { "?" }

    /** Ambil objek JSON dari balasan AI (toleran terhadap ```json ... ``` atau teks tambahan). */
    fun parsePlan(raw: String): Plan? {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        val o = try { JSONObject(raw.substring(s, e + 1)) } catch (_: Exception) { return null }

        val qs = ArrayList<Q>()
        o.optJSONArray("questions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val q = arr.optJSONObject(i) ?: continue
                val st = q.optString("status", "tidak_jelas").lowercase().let {
                    when {
                        it.startsWith("terisi") || it == "filled" || it == "answered" -> "terisi"
                        it.startsWith("kosong") || it == "empty" || it == "unanswered" -> "kosong"
                        else -> "tidak_jelas"
                    }
                }
                qs.add(Q(q.qText(), st, q.optString("selected", "")))
            }
        }
        val filledNos = qs.filter { it.status == "terisi" }.map { norm(it.no) }.toSet()
        val acts = ArrayList<Act>()
        o.optJSONArray("actions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val a = arr.optJSONObject(i) ?: continue
                val x = a.optDouble("x", -1.0).toFloat()
                val y = a.optDouble("y", -1.0).toFloat()
                if (x !in 0f..1000f || y !in 0f..1000f) continue
                val no = a.qText()
                if (norm(no) in filledNos) continue   // pengaman: soal terisi tidak boleh diketuk lagi
                acts.add(Act(no, a.optString("answer", "?").trim() + a.optString("text", "").trim().let { if (it.isNotEmpty()) ". $it" else "" }, x, y))
            }
        }
        val essays = ArrayList<Essay>()
        o.optJSONArray("essays")?.let { arr ->
            for (i in 0 until arr.length()) {
                val a = arr.optJSONObject(i) ?: continue
                val x = a.optDouble("x", -1.0).toFloat()
                val y = a.optDouble("y", -1.0).toFloat()
                val text = a.optString("text", "").trim()
                if (x !in 0f..1000f || y !in 0f..1000f || text.isEmpty()) continue
                val no = a.qText()
                if (norm(no) in filledNos) continue
                essays.add(Essay(no, text.take(1500), x, y))
            }
        }
        val skipped = ArrayList<String>()
        o.optJSONArray("skipped")?.let { arr ->
            for (i in 0 until arr.length()) skipped.add(arr.optString(i))
        }
        val next = o.optJSONObject("next")?.let {
            val x = it.optDouble("x", -1.0).toFloat()
            val y = it.optDouble("y", -1.0).toFloat()
            if (x in 0f..1000f && y in 0f..1000f) Pt(x, y) else null
        }
        val scroll = o.optString("scroll", "none").equals("down", ignoreCase = true)
        return Plan(
            questions = qs,
            acts = acts,  // semua aksi di layar, tanpa batas 20
            essays = essays.take(8),
            skipped = skipped,
            scroll = scroll,
            next = next,
            finished = o.optBoolean("finished", false),
            note = o.optString("note", ""),
        )
    }

    /** Sidik jari frame: gambar 24x24 abu-abu. */
    fun signature(jpeg: ByteArray): IntArray? {
        val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
        val bmp: Bitmap = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, opts) ?: return null
        val small = Bitmap.createScaledBitmap(bmp, 24, 24, true)
        val px = IntArray(24 * 24)
        small.getPixels(px, 0, 24, 0, 0, 24, 24)
        if (small !== bmp) small.recycle()
        bmp.recycle()
        return IntArray(px.size) { i ->
            val c = px[i]
            (((c shr 16) and 0xFF) * 3 + ((c shr 8) and 0xFF) * 6 + (c and 0xFF)) / 10
        }
    }

    /** True jika dua frame praktis sama (halaman tidak bergeser setelah scroll). */
    fun similar(a: IntArray, b: IntArray): Boolean {
        if (a.size != b.size) return false
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toDouble() / a.size < 2.5
    }
}
