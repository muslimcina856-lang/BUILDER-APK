package com.mafia.ai

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var channel: MethodChannel? = null
    private var pendingResult: MethodChannel.Result? = null
    private val reqProjection = 7211
    private val reqNotif = 7212

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "mafia_ai/native")
        channel = ch
        ArcOverlayService.stateListener = { running ->
            runOnUiThread { channel?.invokeMethod("assistantState", running) }
        }
        ch.setMethodCallHandler { call, result ->
            when (call.method) {
                "hasOverlayPermission" -> result.success(Settings.canDrawOverlays(this))
                "requestOverlayPermission" -> { openOverlaySettings(); result.success(true) }
                "isAccessibilityEnabled" -> result.success(isA11yEnabled())
                "openAccessibilitySettings" -> { openA11ySettings(); result.success(true) }
                "openAppDetails" -> { openAppDetails(); result.success(true) }
                "isAssistantRunning" -> result.success(ArcOverlayService.running)
                "startAssistant" -> startAssistant(result)
                "stopAssistant" -> {
                    startService(Intent(this, ArcOverlayService::class.java).setAction(ArcOverlayService.ACTION_STOP))
                    result.success(true)
                }
                "syncSettings" -> {
                    (call.arguments as? Map<*, *>)?.let { NativeStore.saveConfig(this, it) }
                    result.success(true)
                }
                "takePendingChats" -> result.success(NativeStore.takePending(this))
                else -> result.notImplemented()
            }
        }
    }

    override fun cleanUpFlutterEngine(flutterEngine: FlutterEngine) {
        ArcOverlayService.stateListener = null
        channel?.setMethodCallHandler(null)
        channel = null
        super.cleanUpFlutterEngine(flutterEngine)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    /** Buka layar Aksesibilitas dan langsung sorot layanan mafia.ai (cara yang dipakai auto clicker). */
    private fun openA11ySettings() {
        val cn = ComponentName(this, ArcAccessibilityService::class.java).flattenToString()
        val args = Bundle().apply { putString(":settings:fragment_args_key", cn) }
        val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            putExtra(":settings:fragment_args_key", cn)
            putExtra(":settings:show_fragment_args", args)
        }
        try { startActivity(i) }
        catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            catch (e2: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
    }

    /** Info Aplikasi: tempat menu "Izinkan pengaturan terbatas" (Android 13+ untuk app di luar Play Store). */
    private fun openAppDetails() {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        try { startActivity(i) } catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    private fun isA11yEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, ArcAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun startAssistant(result: MethodChannel.Result) {
        if (ArcOverlayService.running) { result.success("already_running"); return }
        if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); result.success("overlay_permission"); return }
        if (pendingResult != null) { result.success("busy"); return }
        pendingResult = result
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
        } else launchProjectionConsent()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif) launchProjectionConsent() // notifikasi tidak wajib; lanjut apa pun hasilnya
    }

    private fun launchProjectionConsent() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), reqProjection)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqProjection) return
        val res = pendingResult; pendingResult = null
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ArcOverlayService::class.java)
                .putExtra(ArcOverlayService.EXTRA_CODE, resultCode)
                .putExtra(ArcOverlayService.EXTRA_DATA, data)
            startForegroundService(i)
            res?.success("started")
        } else res?.success("denied")
    }
}
