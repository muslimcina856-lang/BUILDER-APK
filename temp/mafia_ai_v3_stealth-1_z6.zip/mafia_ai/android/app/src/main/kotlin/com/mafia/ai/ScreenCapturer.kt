package com.mafia.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream

/**
 * MediaProjection session. Satu VirtualDisplay seumur sesi (aturan Android 14+).
 * Frame terakhir disimpan di RAM saja; tidak ada file yang ditulis.
 */
class ScreenCapturer(private val ctx: Context, private val projection: MediaProjection) {
    private val handler = Handler(Looper.getMainLooper())
    private val lock = Any()
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var latest: Image? = null
    var onStopped: (() -> Unit)? = null

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() {
            handler.post { release(); onStopped?.invoke() }
        }
    }

    private fun screenSize(): Triple<Int, Int, Int> {
        val (w, h) = ctx.realScreenSize()
        return Triple(w, h, ctx.resources.displayMetrics.densityDpi)
    }

    fun start() {
        // Wajib di Android 14+: daftarkan callback SEBELUM createVirtualDisplay.
        projection.registerCallback(callback, handler)
        val (w, h, dpi) = screenSize()
        val r = newReader(w, h)
        reader = r
        display = projection.createVirtualDisplay(
            "disp_hlp", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (_: Exception) { null } ?: return@setOnImageAvailableListener
            synchronized(lock) { latest?.close(); latest = img }
        }, handler)
        return r
    }

    /** Dipanggil saat rotasi / ukuran layar berubah. */
    fun onConfigChanged() {
        val d = display ?: return
        val (w, h, dpi) = screenSize()
        val old = reader
        val r = newReader(w, h)
        reader = r
        d.resize(w, h, dpi)
        d.surface = r.surface
        synchronized(lock) { latest?.close(); latest = null }
        old?.close()
    }

    /** Ambil frame terakhir, crop ke rect (koordinat layar) lalu encode JPEG. Null jika belum ada frame. */
    fun captureJpeg(rect: Rect?, screenW: Int, screenH: Int, maxSide: Int = 1600, quality: Int = 88): ByteArray? {
        val bmp: Bitmap = synchronized(lock) {
            val img = latest ?: return null
            toBitmap(img)
        }
        var out = bmp
        try {
            if (rect != null && screenW > 0 && screenH > 0) {
                val sx = bmp.width.toFloat() / screenW
                val sy = bmp.height.toFloat() / screenH
                val l = (rect.left * sx).toInt().coerceIn(0, bmp.width - 2)
                val t = (rect.top * sy).toInt().coerceIn(0, bmp.height - 2)
                val r = (rect.right * sx).toInt().coerceIn(l + 1, bmp.width)
                val b = (rect.bottom * sy).toInt().coerceIn(t + 1, bmp.height)
                out = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
            }
            // Batasi sisi terpanjang supaya payload kecil (limit base64 Groq ~4MB).
            val scale = maxSide.toFloat() / maxOf(out.width, out.height)
            if (scale < 1f) {
                val scaled = Bitmap.createScaledBitmap(out, (out.width * scale).toInt(), (out.height * scale).toInt(), true)
                if (out !== bmp) out.recycle()
                out = scaled
            }
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, quality, bos)
            return bos.toByteArray()
        } finally {
            if (out !== bmp) out.recycle()
            bmp.recycle()
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * img.width
        val padded = Bitmap.createBitmap(img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        if (padded.width == img.width) return padded
        val exact = Bitmap.createBitmap(padded, 0, 0, img.width, img.height)
        padded.recycle()
        return exact
    }

    fun release() {
        synchronized(lock) { latest?.close(); latest = null }
        runCatching { display?.release() }; display = null
        runCatching { reader?.close() }; reader = null
        runCatching { projection.unregisterCallback(callback) }
        runCatching { projection.stop() }
    }
}
