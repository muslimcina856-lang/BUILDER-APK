package com.mafia.ai

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.*
import android.view.MotionEvent
import android.view.View
import android.widget.TextView

/** Palet dark glass mafia.ai (bukan neo-brutalism). */
class Palette(val dark: Boolean) {
    val bg = 0xF2171A24.toInt()          // glass surface
    val bgElevated = 0xF2222633.toInt()
    val ink = 0xFFF5F6FC.toInt()         // primary text
    val text = ink
    val shadow = 0x99000000.toInt()
    val accent = 0xFF8B7CFF.toInt()      // electric violet
    val accentSoft = 0x338B7CFF.toInt()
    val coral = 0xFFFF6B7A.toInt()
    val muted = 0xFF9298AA.toInt()
    val border = 0x33FFFFFF.toInt()
    // kept for any leftover refs
    val yellow = accent
    val violet = accent
    val mint = 0xFF63C7FF.toInt()

    companion object {
        fun from(ctx: Context, mode: String): Palette {
            val sysDark = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            return Palette(if (mode == "light") false else true || sysDark)
        }
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** Soft glass panel background. */
fun glassBox(ctx: Context, fill: Int, border: Int, radiusDp: Int = 16): GradientDrawable {
    return GradientDrawable().apply {
        setColor(fill)
        cornerRadius = ctx.dp(radiusDp).toFloat()
        setStroke(ctx.dp(1), border)
    }
}

/** @deprecated kept for compatibility with older call sites */
fun neoBox(ctx: Context, fill: Int, border: Int, shadow: Int, radiusDp: Int = 14, offsetDp: Int = 4): LayerDrawable {
    val r = ctx.dp(radiusDp).toFloat()
    val sh = GradientDrawable().apply { setColor(shadow); cornerRadius = r }
    val box = GradientDrawable().apply { setColor(fill); cornerRadius = r; setStroke(ctx.dp(1), border) }
    val ld = LayerDrawable(arrayOf(sh, box))
    val o = ctx.dp(maxOf(1, offsetDp / 2))
    ld.setLayerInset(0, o, o, 0, 0)
    ld.setLayerInset(1, 0, 0, o, o)
    return ld
}

/** Gambar robot mafia.ai (dipakai bola mengambang & avatar menu). Koordinat internal 100x100. */
object RobotDrawer {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private const val VIOLET = 0xFF8B7CFF.toInt()
    private const val CYAN = 0xFF63C7FF.toInt()
    private const val LAV = 0xFFB9B3F2.toInt()
    private val bodyShader = LinearGradient(34f, 62f, 66f, 88f, 0xFFF4F2FF.toInt(), 0xFFAFA8EE.toInt(), Shader.TileMode.CLAMP)
    private val headShader = LinearGradient(18f, 18f, 82f, 66f, 0xFFFFFFFF.toInt(), 0xFFC2BCF6.toInt(), Shader.TileMode.CLAMP)
    private val visorShader = LinearGradient(0f, 26f, 0f, 58f, 0xFF1A1E38.toInt(), 0xFF0A0C18.toInt(), Shader.TileMode.CLAMP)
    private val eyeShader = LinearGradient(0f, 36f, 0f, 49f, 0xFF9BE3FF.toInt(), 0xFF4FB4F5.toInt(), Shader.TileMode.CLAMP)
    private val glowShader = RadialGradient(50f, 54f, 46f, intArrayOf(0x588B7CFF, 0x008B7CFF), null, Shader.TileMode.CLAMP)

    private fun blink(t: Float): Float {
        fun b(c: Float): Float { val d = Math.abs(t - c); return if (d < 0.025f) 1f - d / 0.025f else 0f }
        return Math.max(b(0.30f), b(0.78f))
    }

    private fun arm(c: Canvas, sx: Float, sy: Float, hx: Float, hy: Float) {
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 6.4f; p.strokeCap = Paint.Cap.ROUND; p.color = LAV
        c.drawLine(sx, sy, hx, hy, p)
        p.style = Paint.Style.FILL; p.color = 0xFFF4F2FF.toInt()
        c.drawCircle(hx, hy, 5.2f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 0.9f; p.color = LAV
        c.drawCircle(hx, hy, 5.2f, p)
        p.style = Paint.Style.FILL
    }

    /** t: 0..1 (siklus 6 detik). */
    fun draw(c: Canvas, left: Float, top: Float, size: Float, t: Float, waving: Boolean, glow: Boolean) {
        val phase = (t * Math.PI * 2)
        val bob = (Math.sin(phase) * 2.2).toFloat()
        val tilt = Math.sin(phase * 0.5) * 0.045
        c.save()
        c.translate(left, top)
        val sc = size / 100f
        c.scale(sc, sc)

        p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
        if (glow) {
            p.shader = glowShader
            c.drawCircle(50f, 54f, 46f, p)
            p.shader = null
        }
        // bayangan lantai
        p.shader = null; p.color = 0x52000000
        val sw = 32f - bob * 1.2f
        rect.set(50f - sw / 2f, 92.7f, 50f + sw / 2f, 97.2f)
        c.drawOval(rect, p)

        c.translate(50f, 54f + bob)
        c.rotate(Math.toDegrees(tilt).toFloat())
        c.translate(-50f, -54f)

        // badan
        p.shader = bodyShader; p.style = Paint.Style.FILL
        rect.set(34f, 62f, 66f, 88f); c.drawRoundRect(rect, 13f, 13f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0xB3FFFFFF.toInt()
        c.drawRoundRect(rect, 13f, 13f, p)
        val pulse = (0.5 + 0.5 * Math.sin(phase * 2)).toFloat()
        p.style = Paint.Style.FILL; p.color = VIOLET; p.alpha = (255 * (0.18f + 0.18f * pulse)).toInt()
        c.drawCircle(50f, 75f, 6.5f, p)
        p.alpha = 255; c.drawCircle(50f, 75f, 3.2f, p)
        p.color = 0xD9FFFFFF.toInt(); c.drawCircle(49f, 74f, 1.1f, p)

        // kepala
        p.shader = headShader; p.style = Paint.Style.FILL
        rect.set(18f, 18f, 82f, 66f); c.drawRoundRect(rect, 23f, 23f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 1.1f; p.color = 0xCCFFFFFF.toInt()
        c.drawRoundRect(rect, 23f, 23f, p)
        p.style = Paint.Style.FILL; p.color = 0x8CFFFFFF.toInt()
        rect.set(26f, 21f, 46f, 27f); c.drawOval(rect, p)

        // telinga
        for (ex in floatArrayOf(17f, 83f)) {
            p.color = VIOLET; c.drawCircle(ex, 42f, 6.2f, p)
            p.color = CYAN; c.drawCircle(ex, 42f, 3.2f, p)
        }
        // antena
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f; p.strokeCap = Paint.Cap.ROUND; p.color = LAV
        c.drawLine(50f, 18f, 50f, 9.5f, p)
        p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
        val tip = if (Math.sin(phase * 3) > 0.1) CYAN else VIOLET
        p.color = tip; p.alpha = 64; c.drawCircle(50f, 8f, 7f, p)
        p.alpha = 255; c.drawCircle(50f, 8f, 3.8f, p)
        p.color = 0xCCFFFFFF.toInt(); c.drawCircle(49f, 7f, 1.2f, p)

        // visor
        p.shader = visorShader
        rect.set(25f, 26f, 75f, 58f); c.drawRoundRect(rect, 16f, 16f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = VIOLET; p.alpha = 128
        c.drawRoundRect(rect, 16f, 16f, p)
        p.style = Paint.Style.FILL; p.alpha = 255

        // pipi merona
        p.color = 0x61FF7FB0
        for (bx in floatArrayOf(33f, 67f)) { rect.set(bx - 3.5f, 49.2f, bx + 3.5f, 52.8f); c.drawOval(rect, p) }

        // mata
        val lookX = (Math.sin(phase * 0.5) * 2.2).toFloat()
        val bl = blink(t)
        for (ex in floatArrayOf(39.5f, 60.5f)) {
            val cx = ex + lookX
            if (waving) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2.8f; p.strokeCap = Paint.Cap.ROUND; p.color = CYAN
                rect.set(cx - 4.5f, 38.5f, cx + 4.5f, 47.5f)
                c.drawArc(rect, 180f, 180f, false, p)
                p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
            } else {
                val h = 11f * (1f - bl) + 1.6f
                p.color = CYAN; p.alpha = 72
                rect.set(cx - 6.3f, 42.5f - h / 2f - 2f, cx + 6.3f, 42.5f + h / 2f + 2f)
                c.drawRoundRect(rect, 6f, 6f, p)
                p.alpha = 255
                p.shader = eyeShader
                rect.set(cx - 4.3f, 42.5f - h / 2f, cx + 4.3f, 42.5f + h / 2f)
                c.drawRoundRect(rect, 4.6f, 4.6f, p)
                p.shader = null
                if (bl < 0.5f) { p.color = 0xF2FFFFFF.toInt(); c.drawCircle(cx - 1.6f, 39.5f, 1.5f, p) }
            }
        }
        // mulut
        if (waving) {
            path.reset(); path.moveTo(45f, 51.5f); path.quadTo(50f, 59.5f, 55f, 51.5f); path.close()
            p.style = Paint.Style.FILL; p.color = CYAN
            c.drawPath(path, p)
        } else {
            path.reset(); path.moveTo(46f, 52.5f); path.quadTo(50f, 55.7f, 54f, 52.5f)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f; p.strokeCap = Paint.Cap.ROUND; p.color = CYAN
            c.drawPath(path, p)
            p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
        }

        // lengan dan tangan
        arm(c, 35f, 70f, 21f, 82f)
        if (waving) {
            val hx = (86 + Math.sin(phase * 16) * 5).toFloat()
            val hy = (37 + Math.cos(phase * 16) * 1.5).toFloat()
            arm(c, 65f, 70f, hx, hy)
        } else {
            arm(c, 65f, 70f, 79f, 82f)
        }
        c.restore()
    }
}

/** Avatar robot kecil (header menu / panel jawaban). */
class RobotAvatarView(ctx: Context, private val waving: Boolean = true) : View(ctx) {
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000; repeatCount = ValueAnimator.INFINITE; interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val side = minOf(width, height).toFloat()
        RobotDrawer.draw(c, (width - side) / 2f, (height - side) / 2f, side, t, waving, false)
    }
}

/**
 * Floating ball - robot mafia.ai animasi (melayang, berkedip, melirik, melambai saat menyapa).
 * Saat [invisible] = true: 3 titik.
 */
class BallView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dens = ctx.resources.displayMetrics.density
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000; repeatCount = ValueAnimator.INFINITE; interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    var active = false
        set(v) { field = v; invalidate() }
    var invisible = false
        set(v) { field = v; invalidate() }
    var waving = false
        set(v) { field = v; invalidate() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f
        if (invisible) {
            val r = 4f * dens
            val gap = 10f * dens
            p.style = Paint.Style.FILL
            for (i in 0 until 3) {
                val ph = (t * 5f + i * 0.25f) % 1f
                val k = Math.sin(ph * Math.PI).toFloat()
                p.color = 0xFF8B7CFF.toInt()
                p.alpha = (255 * (0.35f + k * 0.55f)).toInt()
                c.drawCircle(cx + (i - 1) * gap, cy, r * (0.55f + k * 0.45f), p)
            }
            p.alpha = 255
            return
        }
        val side = minOf(w, h) - 2f * dens
        val scale = if (active) 1.1f else 1f
        val s = side * scale
        RobotDrawer.draw(c, cx - s / 2f, cy - s / 2f, s, t, waving, true)
    }
}

/** Overlay pemilih area. */
class SelectionView(ctx: Context, private val touchable: Boolean, private val pal: Palette) : View(ctx) {
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFF8B7CFF.toInt(); strokeWidth = 2.5f * ctx.resources.displayMetrics.density
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 14f * ctx.resources.displayMetrics.scaledDensity
        typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    var rect: RectF? = null
    var hintText = "Seret untuk memilih area"
    var onSelected: ((Rect) -> Unit)? = null
    private var sx = 0f; private var sy = 0f

    init { setLayerType(LAYER_TYPE_HARDWARE, null) }

    fun setCorners(x1: Float, y1: Float, x2: Float, y2: Float) {
        rect = RectF(minOf(x1, x2), minOf(y1, y2), maxOf(x1, x2), maxOf(y1, y2)); invalidate()
    }

    override fun onDraw(c: Canvas) {
        val sc = c.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        rect?.let {
            c.drawRect(it, clear)
            c.drawRect(it, stroke)
        }
        c.restoreToCount(sc)
        c.drawText(hintText, width / 2f, height * 0.12f, hint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!touchable) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; setCorners(sx, sy, sx, sy) }
            MotionEvent.ACTION_MOVE -> setCorners(sx, sy, e.x, e.y)
            MotionEvent.ACTION_UP -> {
                val r = rect ?: return true
                if (r.width() >= 40 && r.height() >= 40) {
                    onSelected?.invoke(Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt()))
                }
            }
        }
        return true
    }
}

/** Markdown ringan -> Spannable untuk TextView overlay. */
object SimpleMarkdown {
    fun render(src: String, pal: Palette, tv: TextView): CharSequence {
        val sb = SpannableStringBuilder()
        var inCode = false
        for (raw in src.split("\n")) {
            var line = raw
            if (line.trim().startsWith("```")) { inCode = !inCode; continue }
            val start = sb.length
            if (inCode) {
                sb.append(line).append('\n')
                sb.setSpan(TypefaceSpan("monospace"), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(BackgroundColorSpan(if (pal.dark) 0xFF2C2C34.toInt() else 0xFFEFE7D2.toInt()), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                continue
            }
            var header = 0
            val m = Regex("^(#{1,4})\\s+(.*)$").find(line)
            if (m != null) { header = m.groupValues[1].length; line = m.groupValues[2] }
            val bullet = Regex("^\\s*[-*]\\s+").containsMatchIn(line)
            if (bullet) line = line.replace(Regex("^\\s*[-*]\\s+"), "")
            appendInline(sb, line)
            if (bullet) sb.setSpan(BulletSpan(tv.context.dp(10), 0xFF8B7CFF.toInt()), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (header > 0) {
                sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(RelativeSizeSpan(if (header == 1) 1.3f else 1.15f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            sb.append('\n')
        }
        return sb.trimEnd()
    }

    private fun appendInline(sb: SpannableStringBuilder, text: String) {
        val re = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`")
        var idx = 0
        for (m in re.findAll(text)) {
            sb.append(text.substring(idx, m.range.first))
            val s = sb.length
            if (m.groups[1] != null) {
                sb.append(m.groupValues[1]); sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                sb.append(m.groupValues[2])
                sb.setSpan(TypefaceSpan("monospace"), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(BackgroundColorSpan(0x33888888), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            idx = m.range.last + 1
        }
        sb.append(text.substring(idx))
    }
}

/** Ukuran layar penuh (px) termasuk system bar, ikut rotasi. */
@Suppress("DEPRECATION")
fun Context.realScreenSize(): Pair<Int, Int> {
    val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
    val pt = Point()
    wm.defaultDisplay.getRealSize(pt)
    return Pair(pt.x, pt.y)
}
