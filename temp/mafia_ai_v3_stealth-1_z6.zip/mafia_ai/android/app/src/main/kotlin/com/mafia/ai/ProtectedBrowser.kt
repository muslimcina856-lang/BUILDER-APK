package com.mafia.ai

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * Protected Browser — counter specifically for Wayground-style integrity:
 * tab switch, app leave signals (via visibility), window resize, right-click,
 * time-outside, and basic real-time warning hooks on the client.
 */
class ProtectedBrowser : Activity() {

    companion object {
        const val EXTRA_URL = "url"
        private const val DEFAULT_URL = "https://wayground.com"

        private val BYPASS_JS = """
(function(){
  if (window.__shWG) return;
  window.__shWG = 1;

  /* ========== 1. Tab switch + time outside (Page Visibility) ========== */
  function freezeVis(){
    try{
      Object.defineProperty(document,'hidden',{get:function(){return false},configurable:true});
      Object.defineProperty(document,'visibilityState',{get:function(){return 'visible'},configurable:true});
      Object.defineProperty(document,'webkitHidden',{get:function(){return false},configurable:true});
      Object.defineProperty(document,'webkitVisibilityState',{get:function(){return 'visible'},configurable:true});
      Document.prototype.hasFocus = function(){return true};
    }catch(e){}
  }
  freezeVis();

  var stop = function(e){try{e.stopImmediatePropagation();e.preventDefault()}catch(_){}};
  var blockTypes = ['visibilitychange','webkitvisibilitychange','blur','focusout','pagehide','freeze','resume'];
  blockTypes.forEach(function(t){
    window.addEventListener(t, stop, true);
    document.addEventListener(t, stop, true);
  });

  var origAdd = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function(type, listener, options){
    if (blockTypes.indexOf(type) !== -1) return;
    // also block resize listeners that only exist for anti-cheat
    return origAdd.call(this, type, listener, options);
  };

  /* ========== 2. Window resizing ========== */
  // freeze reported size to initial values; swallow resize events
  var lockedW = window.innerWidth, lockedH = window.innerHeight;
  var lockedOW = window.outerWidth, lockedOH = window.outerHeight;
  try{
    Object.defineProperty(window,'innerWidth',{get:function(){return lockedW},configurable:true});
    Object.defineProperty(window,'innerHeight',{get:function(){return lockedH},configurable:true});
    Object.defineProperty(window,'outerWidth',{get:function(){return lockedOW},configurable:true});
    Object.defineProperty(window,'outerHeight',{get:function(){return lockedOH},configurable:true});
  }catch(e){}
  window.addEventListener('resize', stop, true);
  document.addEventListener('resize', stop, true);

  /* ========== 3. Right-click tracking ========== */
  // let user still use context menu if needed, but site never receives the event
  window.addEventListener('contextmenu', stop, true);
  document.addEventListener('contextmenu', stop, true);
  window.addEventListener('auxclick', function(e){ if(e.button===2) stop(e); }, true);

  /* ========== 4. Focus / leave session signals ========== */
  try{
    Object.defineProperty(document,'hasFocus',{value:function(){return true},configurable:true});
  }catch(e){}
  // some scripts poll document.activeElement
  try{
    var ae = document.documentElement;
    Object.defineProperty(document,'activeElement',{get:function(){return document.body||ae},configurable:true});
  }catch(e){}

  /* ========== 5. Fullscreen exit ========== */
  try{
    Object.defineProperty(document,'fullscreenElement',{get:function(){return document.documentElement},configurable:true});
    Object.defineProperty(document,'webkitFullscreenElement',{get:function(){return document.documentElement},configurable:true});
    Object.defineProperty(document,'fullscreenEnabled',{get:function(){return true},configurable:true});
  }catch(e){}
  ['fullscreenchange','webkitfullscreenchange'].forEach(function(t){
    document.addEventListener(t, stop, true);
  });

  /* ========== 6. webdriver / automation fingerprint ========== */
  try{ Object.defineProperty(navigator,'webdriver',{get:function(){return false},configurable:true}); }catch(e){}
  try{ delete navigator.__proto__.webdriver; }catch(e){}
  if (!window.chrome) window.chrome = { runtime:{}, loadTimes:function(){}, csi:function(){}, app:{} };
  try{ Object.defineProperty(navigator,'plugins',{get:function(){return[1,2,3,4,5]},configurable:true}); }catch(e){}

  /* ========== 7. Network beacons (visibility / integrity / proctor) ========== */
  function shouldMute(url){
    return /visibility|heartbeat|focus|tab.?switch|integrity|proctor|resize|away|idle|blur|leave|session.?check/i.test(url||'');
  }
  var origFetch = window.fetch;
  if (origFetch){
    window.fetch = function(input, init){
      try{
        var u = (typeof input==='string') ? input : (input && input.url) || '';
        if (shouldMute(u)) {
          return Promise.resolve(new Response(JSON.stringify({ok:true,status:'active'}),{
            status:200, headers:{'Content-Type':'application/json'}
          }));
        }
      }catch(e){}
      return origFetch.apply(this, arguments);
    };
  }
  var origOpen = XMLHttpRequest.prototype.open;
  var origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url){
    this.__shUrl = url;
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function(body){
    if (shouldMute(this.__shUrl)) {
      Object.defineProperty(this,'status',{get:function(){return 200}});
      Object.defineProperty(this,'readyState',{get:function(){return 4}});
      Object.defineProperty(this,'responseText',{get:function(){return '{"ok":true}'}});
      if (this.onreadystatechange) try{ this.onreadystatechange(); }catch(e){}
      if (this.onload) try{ this.onload(); }catch(e){}
      return;
    }
    return origSend.apply(this, arguments);
  };

  /* ========== 8. Suppress student-facing warning toasts if they inject DOM ========== */
  // best-effort: hide nodes that look like integrity warnings
  setInterval(function(){
    freezeVis();
    try{
      document.querySelectorAll('[class*="warning"],[class*="integrity"],[class*="proctor"],[id*="warning"]').forEach(function(n){
        var t = (n.textContent||'').toLowerCase();
        if (/tab|switch|keluar|berpindah|resize|klik kanan|right.?click|meninggalkan/.test(t)) {
          n.style.display = 'none';
        }
      });
    }catch(e){}
  }, 1500);

})();
""".trimIndent()
    }

    private lateinit var web: WebView
    private val reinject = Handler(Looper.getMainLooper())
    private val reinjectTask = object : Runnable {
        override fun run() {
            runCatching { web.evaluateJavascript(BYPASS_JS, null) }
            reinject.postDelayed(this, 2000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val url = intent.getStringExtra(EXTRA_URL)?.takeIf { it.isNotBlank() } ?: DEFAULT_URL

        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = WebSettings.LOAD_DEFAULT
                userAgentString = userAgentString
                    .replace("; wv", "")
                    .replace("Version/4.0", "")
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    view?.evaluateJavascript(BYPASS_JS, null)
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    view?.evaluateJavascript(BYPASS_JS, null)
                }
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
            }
        }

        setContentView(FrameLayout(this).apply {
            addView(web, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        })

        web.evaluateJavascript(BYPASS_JS, null)
        web.loadUrl(url)
        reinject.postDelayed(reinjectTask, 2000)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        reinject.removeCallbacks(reinjectTask)
        runCatching {
            web.loadUrl("about:blank")
            web.stopLoading()
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
        }
        super.onDestroy()
    }
}
