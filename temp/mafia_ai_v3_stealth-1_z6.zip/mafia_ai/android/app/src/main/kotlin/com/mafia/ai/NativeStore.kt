package com.mafia.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Setting yang di-sync dari Flutter + antrian teks "Simpan ke Chat" (tanpa screenshot). */
object NativeStore {
    private const val PREFS = "arc_native"

    data class Config(
        val provider: String,        // "gemini" | "groq"
        val geminiKey: String,
        val groqKey: String,
        val geminiVision: String,
        val groqVision: String,
        val tripleTap: Boolean,
        val autoAnswer: Boolean,
        val themeMode: String,       // "light" | "dark" | "system"
    ) {
        val apiKey get() = if (provider == "groq") groqKey else geminiKey
        val visionModel get() = if (provider == "groq") groqVision else geminiVision
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveConfig(ctx: Context, m: Map<*, *>) {
        val e = prefs(ctx).edit()
        for ((k, v) in m) {
            when (v) {
                is String -> e.putString(k as String, v)
                is Boolean -> e.putBoolean(k as String, v)
            }
        }
        e.apply()
    }

    fun config(ctx: Context): Config {
        val p = prefs(ctx)
        return Config(
            provider = p.getString("provider", "gemini") ?: "gemini",
            geminiKey = p.getString("geminiKey", "") ?: "",
            groqKey = p.getString("groqKey", "") ?: "",
            geminiVision = p.getString("geminiVision", "gemini-flash-latest") ?: "gemini-flash-latest",
            groqVision = p.getString("groqVision", "qwen/qwen3.6-27b") ?: "qwen/qwen3.6-27b",
            tripleTap = p.getBoolean("tripleTap", true),
            autoAnswer = p.getBoolean("autoAnswer", false),
            themeMode = p.getString("themeMode", "system") ?: "system",
        )
    }

    @Synchronized
    fun addPending(ctx: Context, question: String, answer: String) {
        val p = prefs(ctx)
        val arr = JSONArray(p.getString("pending", "[]"))
        arr.put(JSONObject().put("question", question).put("answer", answer)
            .put("time", System.currentTimeMillis()))
        p.edit().putString("pending", arr.toString()).apply()
    }

    @Synchronized
    fun takePending(ctx: Context): List<Map<String, Any>> {
        val p = prefs(ctx)
        val arr = JSONArray(p.getString("pending", "[]"))
        p.edit().remove("pending").apply()
        val out = ArrayList<Map<String, Any>>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(mapOf(
                "question" to o.optString("question"),
                "answer" to o.optString("answer"),
                "time" to o.optLong("time"),
            ))
        }
        return out
    }
}
