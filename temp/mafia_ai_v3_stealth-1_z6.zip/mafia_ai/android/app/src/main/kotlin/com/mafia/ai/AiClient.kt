package com.mafia.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

/** Klien vision Gemini / Groq. Blocking: panggil dari thread background. */
object AiClient {

    fun ask(cfg: NativeStore.Config, prompt: String, jpeg: ByteArray, system: String = Prompts.SYSTEM, json: Boolean = false): String {
        if (cfg.apiKey.isBlank()) {
            throw IllegalStateException(
                (if (cfg.provider == "groq") "Groq" else "Gemini") +
                    " API key belum diisi. Buka Settings."
            )
        }
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val raw = if (cfg.provider == "groq") groq(cfg, prompt, b64, system) else gemini(cfg, prompt, b64, system, json)
        // Buang blok <think> dari model reasoning
        return raw.replace(Regex("(?s)<think>.*?</think>"), "").trim()
    }

    private fun gemini(cfg: NativeStore.Config, prompt: String, b64: String, system: String, json: Boolean): String {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject()
                .put("role", "user")
                .put("parts", JSONArray()
                    .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
                    .put(JSONObject().put("text", prompt)))))
        if (json) body.put("generationConfig", JSONObject()
            .put("responseMimeType", "application/json")
            .put("temperature", 0.2)
            .put("thinkingConfig", JSONObject().put("thinkingBudget", 512)))   // seimbang: cukup untuk hitungan, tetap cepat
        val url = "https://generativelanguage.googleapis.com/v1beta/models/${cfg.visionModel}:generateContent"
        val res = try {
            post(url, mapOf("x-goog-api-key" to cfg.geminiKey), body.toString(), "Gemini")
        } catch (e: RuntimeException) {
            // Model yang tidak mendukung thinkingConfig: ulangi tanpa itu
            if (json && e.message.orEmpty().contains("400") && e.message.orEmpty().contains("think", true)) {
                body.getJSONObject("generationConfig").remove("thinkingConfig")
                post(url, mapOf("x-goog-api-key" to cfg.geminiKey), body.toString(), "Gemini")
            } else throw e
        }
        val j = JSONObject(res)
        val cands = j.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = j.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return if (block.isNotEmpty()) "Permintaan diblokir oleh Gemini ($block)." else "Tidak ada jawaban."
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
        }
        return sb.toString().ifBlank { "Tidak ada jawaban." }
    }

    private fun groq(cfg: NativeStore.Config, prompt: String, b64: String, system: String): String {
        val text = system + "\n\n" + prompt
        val body = JSONObject()
            .put("model", cfg.visionModel)
            .put("temperature", 0.3)
            .put("messages", JSONArray().put(JSONObject()
                .put("role", "user")
                .put("content", JSONArray()
                    .put(JSONObject().put("type", "text").put("text", text))
                    .put(JSONObject().put("type", "image_url")
                        .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))))))
        val res = post("https://api.groq.com/openai/v1/chat/completions",
            mapOf("Authorization" to "Bearer ${cfg.groqKey}"), body.toString(), "Groq")
        val choices = JSONObject(res).optJSONArray("choices")
        return choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
            ?.ifBlank { null } ?: "Tidak ada jawaban."
    }

    private fun post(url: String, headers: Map<String, String>, body: String, name: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use(BufferedReader::readText).orEmpty()
            if (code !in 200..299) {
                val msg = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw RuntimeException("$name $code: ${msg ?: text.take(300)}")
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
