import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'core/theme/app_theme.dart';
import 'core/widgets/glass_container.dart';
import 'core/widgets/floating_robot.dart';
import 'core/services/ai_service.dart';
import 'core/services/native_bridge.dart';
import 'features/home/home_screen.dart';
import 'features/chat/chat_screen.dart';
import 'features/history/history_screen.dart';
import 'features/settings/settings_screen.dart';
import 'features/auto_answer/floating_answer_panel.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  NativeBridge.init();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF08090D),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const MafiaAIApp());
}

class MafiaAIApp extends StatelessWidget {
  const MafiaAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'mafia.ai',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.dark,
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;
  bool _showChat = false;
  bool _showAnswerPanel = false;

  String _answerQNumber = '1';
  String _answerText = '';
  String _answerExplanation = '';
  bool _answerLoading = false;
  String? _answerError;

  /// Saat overlay native aktif, robot native (tampilan sama) yang dipakai,
  /// jadi robot Flutter disembunyikan agar tidak dobel.
  bool _nativeRunning = false;

  @override
  void initState() {
    super.initState();
    NativeBridge.onAssistantState = (running) {
      if (mounted) setState(() => _nativeRunning = running);
    };
    NativeBridge.isAssistantRunning().then((r) {
      if (mounted) setState(() => _nativeRunning = r);
    });
  }

  @override
  void dispose() {
    NativeBridge.onAssistantState = null;
    super.dispose();
  }

  void _openChat() => setState(() => _showChat = true);
  void _closeChat() => setState(() => _showChat = false);

  /// Screen Assistant: uses clipboard text as the "screen content" when MediaProjection
  /// is not available. Full system screen capture requires a native Android service.
  Future<void> _onAutoScreen() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    if (text.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Screen Assistant: salin teks soal ke clipboard dulu, lalu tekan lagi. '
            '(Capture layar penuh butuh izin MediaProjection native.)',
          ),
          duration: Duration(seconds: 4),
        ),
      );
      return;
    }
    await _runAutoAnswer(text);
  }

  Future<void> _onAutoAnswer() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final clipboard = data?.text?.trim() ?? '';
    if (clipboard.isNotEmpty) {
      await _runAutoAnswer(clipboard);
      return;
    }
    if (!mounted) return;
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF171A24),
        title: const Text('Auto Answer', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: controller,
          maxLines: 5,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Tempel atau ketik soal di sini...',
            hintStyle: TextStyle(color: Colors.white54),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Jawab'),
          ),
        ],
      ),
    );
    if (result != null && result.isNotEmpty) {
      await _runAutoAnswer(result);
    }
  }

  Future<void> _runAutoAnswer(String question) async {
    setState(() {
      _showAnswerPanel = true;
      _answerLoading = true;
      _answerError = null;
      _answerText = '';
      _answerExplanation = '';
      _answerQNumber = '1';
    });

    try {
      final raw = await AIService.answerQuestion(question);
      if (!mounted) return;

      // Best-effort split: first line = answer, rest = explanation
      final lines = raw.trim().split('\n');
      String answer = raw.trim();
      String explanation = '';
      if (lines.length > 1) {
        answer = lines.first.trim();
        explanation = lines.skip(1).join('\n').trim();
      }

      setState(() {
        _answerLoading = false;
        _answerText = answer;
        _answerExplanation = explanation;
      });

      // Persist to history
      final p = await SharedPreferences.getInstance();
      final h = p.getStringList('chat_history') ?? <String>[];
      h.insert(
        0,
        jsonEncode({
          'title': question,
          'answer': raw,
          'timestamp': DateTime.now().toIso8601String(),
        }),
      );
      await p.setStringList('chat_history', h.take(200).toList());
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _answerLoading = false;
        _answerError = e.toString();
      });
    }
  }


  void _onCloseApp() {
    SystemNavigator.pop();
  }

  Widget _buildAnswerPanel() {
    return FloatingAnswerPanel(
      questionNumber: _answerQNumber,
      answer: _answerText,
      explanation: _answerExplanation,
      isLoading: _answerLoading,
      errorMessage: _answerError,
      onClose: () => setState(() => _showAnswerPanel = false),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_showChat) {
      return Stack(
        children: [
          ChatScreen(onBack: _closeChat),
          if (!_nativeRunning)
            FloatingRobot(
              onAutoScreen: _onAutoScreen,
              onAutoAnswer: _onAutoAnswer,
              onCloseApp: _onCloseApp,
            ),
          if (_showAnswerPanel) _buildAnswerPanel(),
        ],
      );
    }

    return Scaffold(
      backgroundColor: context.background,
      body: Stack(
        children: [
          IndexedStack(
            index: _currentIndex,
            children: [
              HomeScreen(
                onStartChat: _openChat,
                onOpenSettings: () => setState(() => _currentIndex = 2),
              ),
              HistoryScreen(onOpenChat: _openChat),
              const SettingsScreen(),
            ],
          ),
          if (!_nativeRunning)
            FloatingRobot(
              onAutoScreen: _onAutoScreen,
              onAutoAnswer: _onAutoAnswer,
              onCloseApp: _onCloseApp,
            ),
          if (_showAnswerPanel) _buildAnswerPanel(),
        ],
      ),
      bottomNavigationBar: GlassNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) {
          HapticFeedback.selectionClick();
          setState(() => _currentIndex = i);
        },
        items: [
          const GlassNavItem(icon: Icons.chat_bubble_outline_rounded, label: 'Chat'),
          const GlassNavItem(icon: Icons.history_rounded, label: 'History'),
          const GlassNavItem(icon: Icons.settings_outlined, label: 'Settings'),
        ],
      ),
    );
  }
}
