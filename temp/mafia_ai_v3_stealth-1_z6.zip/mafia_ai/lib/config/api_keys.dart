/// API keys (Gemini & Groq). Optional compile-time defaults.
/// Priority: Settings (SharedPreferences) > values here.
class ApiKeys {
  ApiKeys._();

  static const String gemini =
      String.fromEnvironment('API_KEY_GEMINI', defaultValue: '');

  static const String groq =
      String.fromEnvironment('API_KEY_GROQ', defaultValue: '');
}
