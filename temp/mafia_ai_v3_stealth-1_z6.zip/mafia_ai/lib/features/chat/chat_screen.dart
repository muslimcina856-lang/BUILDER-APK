import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/glass_container.dart';
import '../../core/widgets/ai_orb.dart';
import '../../core/services/ai_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.content,
    required this.isUser,
    this.isStreaming = false,
  });

  final String id;
  final String content;
  final bool isUser;
  final bool isStreaming;
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, this.onBack});

  final VoidCallback? onBack;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final _focusNode = FocusNode();
  final List<ChatMessage> _messages = [];
  bool _isGenerating = false;
  String _selectedModel = 'Claude 3.5';

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _isGenerating) return;
    HapticFeedback.lightImpact();

    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final rid = '${id}_ai';

    setState(() {
      _messages.add(ChatMessage(id: id, content: text, isUser: true));
      _messages.add(
        ChatMessage(
          id: rid,
          content: '',
          isUser: false,
          isStreaming: true,
        ),
      );
      _isGenerating = true;
    });
    _controller.clear();
    _scrollToBottom();

    final buffer = StringBuffer();
    try {
      await for (final chunk in AIService.streamComplete(text)) {
        if (!mounted) return;
        buffer.write(chunk);
        setState(() {
          final i = _messages.indexWhere((m) => m.id == rid);
          if (i >= 0) {
            _messages[i] = ChatMessage(
              id: rid,
              content: buffer.toString(),
              isUser: false,
              isStreaming: true,
            );
          }
        });
        _scrollToBottom();
      }

      if (!mounted) return;
      final answer = buffer.toString().trim().isEmpty
          ? 'AI tidak mengembalikan teks.'
          : buffer.toString();
      setState(() {
        final i = _messages.indexWhere((m) => m.id == rid);
        if (i >= 0) {
          _messages[i] = ChatMessage(id: rid, content: answer, isUser: false);
        }
        _isGenerating = false;
      });

      final p = await SharedPreferences.getInstance();
      final h = p.getStringList('chat_history') ?? <String>[];
      h.insert(
        0,
        jsonEncode({
          'title': text,
          'answer': answer,
          'timestamp': DateTime.now().toIso8601String(),
        }),
      );
      await p.setStringList('chat_history', h.take(200).toList());
    } catch (e) {
      if (!mounted) return;
      setState(() {
        final i = _messages.indexWhere((m) => m.id == rid);
        if (i >= 0) {
          _messages[i] = ChatMessage(
            id: rid,
            content: 'Gagal menghubungi AI. $e',
            isUser: false,
          );
        }
        _isGenerating = false;
      });
    }
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(context),
            Expanded(
              child: _messages.isEmpty
                  ? _buildEmptyState(context)
                  : ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                      itemCount: _messages.length,
                      itemBuilder: (context, index) {
                        return _MessageBubble(message: _messages[index]);
                      },
                    ),
            ),
            _buildComposer(context),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 16, 8),
      child: Row(
        children: [
          IconButton(
            onPressed: widget.onBack,
            icon: Icon(Icons.arrow_back_ios_new_rounded,
                size: 20, color: context.primaryText),
          ),
          Expanded(
            child: Text(
              'Conversation',
              style: Theme.of(context).textTheme.titleLarge,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Model selector glass pill
          GestureDetector(
            onTap: () => _showModelSheet(context),
            child: GlassContainer(
              borderRadius: 20,
              blur: 12,
              opacity: 0.7,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _selectedModel,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: context.primaryText,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(Icons.expand_more_rounded,
                      size: 16, color: context.secondaryText),
                ],
              ),
            ),
          ),
          const SizedBox(width: 4),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.more_horiz_rounded,
                size: 22, color: context.secondaryText),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AIOrb(size: 80, state: OrbState.idle),
          const SizedBox(height: 20),
          Text(
            'Start a conversation',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: context.secondaryText,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildComposer(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom > 0 ? 8 : 12,
        top: 4,
      ),
      child: GlassInput(
        controller: _controller,
        focusNode: _focusNode,
        hintText: 'Message mafia.ai...',
        maxLines: 5,
        minLines: 1,
        textInputAction: TextInputAction.send,
        onSubmitted: (_) => _send(),
        prefix: IconButton(
          onPressed: () {},
          icon: Icon(Icons.add_circle_outline_rounded,
              size: 22, color: context.secondaryText),
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
        ),
        suffix: GestureDetector(
          onTap: _send,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            width: 36,
            height: 36,
            margin: const EdgeInsets.only(right: 4, bottom: 2),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: _isGenerating
                    ? [context.tertiaryText, context.tertiaryText]
                    : [context.primaryAccent, context.secondaryAccent],
              ),
            ),
            child: Icon(
              _isGenerating ? Icons.stop_rounded : Icons.arrow_upward_rounded,
              size: 18,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

  void _showModelSheet(BuildContext context) {
    final models = ['Claude 3.5', 'GPT-4o', 'Gemini 1.5', 'Llama 3.1'];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return GlassContainer(
          borderRadius: 24,
          blur: 30,
          opacity: 0.9,
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: context.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text('Select Model',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              ...models.map((m) {
                final selected = m == _selectedModel;
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(m,
                      style: TextStyle(
                        color: context.primaryText,
                        fontWeight:
                            selected ? FontWeight.w600 : FontWeight.w400,
                      )),
                  trailing: selected
                      ? Icon(Icons.check_rounded,
                          color: context.primaryAccent, size: 20)
                      : null,
                  onTap: () {
                    setState(() => _selectedModel = m);
                    Navigator.pop(ctx);
                  },
                );
              }),
            ],
          ),
        );
      },
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.message});
  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    if (message.isUser) {
      return Align(
        alignment: Alignment.centerRight,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12, left: 48),
          child: GlassContainer(
            borderRadius: 18,
            blur: 12,
            opacity: 0.65,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            gradient: LinearGradient(
              colors: [
                context.primaryAccent.withOpacity(0.25),
                context.primaryAccent.withOpacity(0.12),
              ],
            ),
            child: Text(
              message.content,
              style: TextStyle(
                color: context.primaryText,
                fontSize: 15,
                height: 1.45,
              ),
            ),
          ),
        ),
      );
    }

    // AI message - clean, no heavy bubble
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16, right: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            MarkdownBody(
              data: message.content,
              selectable: true,
              styleSheet: MarkdownStyleSheet(
                p: TextStyle(
                  color: context.primaryText,
                  fontSize: 15,
                  height: 1.55,
                ),
                h1: TextStyle(
                  color: context.primaryText,
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
                h2: TextStyle(
                  color: context.primaryText,
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
                code: TextStyle(
                  backgroundColor: context.glassElevated,
                  color: context.secondaryAccent,
                  fontSize: 13,
                ),
                codeblockDecoration: BoxDecoration(
                  color: context.glassElevated,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: context.border),
                ),
                blockquoteDecoration: BoxDecoration(
                  border: Border(
                    left: BorderSide(
                      color: context.primaryAccent.withOpacity(0.5),
                      width: 3,
                    ),
                  ),
                ),
                listBullet: TextStyle(color: context.primaryAccent),
              ),
            ),
            if (message.isStreaming)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: _TypingDots(),
              ),
            if (!message.isStreaming && message.content.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(
                  children: [
                    _ActionIcon(icon: Icons.copy_rounded, onTap: () {}),
                    const SizedBox(width: 8),
                    _ActionIcon(icon: Icons.refresh_rounded, onTap: () {}),
                    const SizedBox(width: 8),
                    _ActionIcon(icon: Icons.more_horiz_rounded, onTap: () {}),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _ActionIcon extends StatelessWidget {
  const _ActionIcon({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Icon(icon, size: 16, color: context.tertiaryText),
    );
  }
}

class _TypingDots extends StatefulWidget {
  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            final t = (_c.value + i * 0.2) % 1.0;
            final opacity = 0.3 + (1 - (t - 0.5).abs() * 2).clamp(0.0, 1.0) * 0.7;
            return Container(
              margin: const EdgeInsets.only(right: 4),
              width: 5,
              height: 5,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: context.primaryAccent.withOpacity(opacity),
              ),
            );
          }),
        );
      },
    );
  }
}
