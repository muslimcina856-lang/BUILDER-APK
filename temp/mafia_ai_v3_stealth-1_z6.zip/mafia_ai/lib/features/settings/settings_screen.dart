import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../config/api_keys.dart';
import '../../core/services/ai_service.dart';
import '../../core/services/native_bridge.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/glass_container.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
    with WidgetsBindingObserver {
  bool _darkMode = true;
  bool _haptic = true;
  bool _autoAnswer = false;
  bool _tripleTap = true;
  bool _floating = false;
  bool _starting = false;
  bool _overlayGranted = false;
  bool _a11yEnabled = false;
  String _provider = 'Google Gemini';
  String _model = 'gemini-flash-latest';
  String _visionModel = 'gemini-flash-latest';
  final _geminiKeyController = TextEditingController();
  final _groqKeyController = TextEditingController();
  bool _showGemini = false;
  bool _showGroq = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _provider = p.getString('ai_provider') ?? 'Google Gemini';
      _model = AIService.migrateModel(
          p.getString('ai_model') ?? AIService.defaultModel(_provider));
      _visionModel = p.getString('ai_vision_model') ??
          AIService.defaultVisionModel(_provider);
      _geminiKeyController.text =
          p.getString('api_key_Google Gemini') ??
              p.getString('api_key_Gemini') ??
              '';
      _groqKeyController.text = p.getString('api_key_Groq') ?? '';
      _autoAnswer = p.getBool('auto_answer') ?? false;
      _tripleTap = p.getBool('triple_tap') ?? true;
      _darkMode = p.getBool('dark_mode') ?? true;
      _haptic = p.getBool('haptic') ?? true;
    });
    await _refreshNative();
    await AIService.syncNative();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Kembali dari layar Pengaturan -> segarkan status izin.
    if (state == AppLifecycleState.resumed) _refreshNative();
  }

  /// Dialog panduan aksesibilitas ala auto clicker: penjelasan, buka layanan, dan
  /// jalan keluar untuk "Pengaturan dibatasi" (Android 13+).
  Future<void> _askAccessibility() async {
    if (_a11yEnabled) {
      await NativeBridge.openAccessibilitySettings();
      return;
    }
    final go = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF171A24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Aktifkan Aksesibilitas',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        content: const SingleChildScrollView(
          child: Text(
            'Dibutuhkan agar Auto Answer (tombol Play) bisa mengetuk jawaban dan '
            'menggulir layar atas perintah Anda, serta untuk membuka Screen Assistant '
            'dari aplikasi mana pun. Layanan ini tidak membaca isi layar dan tidak '
            'mengumpulkan data.\n\n'
            '1. Tekan Buka Pengaturan, pilih "mafia.ai Screen Assistant", lalu nyalakan.\n\n'
            '2. Jika tombolnya abu-abu atau muncul "Pengaturan dibatasi", tekan Info Aplikasi, '
            'buka menu titik tiga di kanan atas, pilih "Izinkan pengaturan terbatas", '
            'lalu ulangi langkah 1.',
            style: TextStyle(color: Colors.white70, height: 1.45, fontSize: 14),
          ),
        ),
        actionsAlignment: MainAxisAlignment.spaceBetween,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, 'details'),
            child: const Text('Info Aplikasi'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, 'open'),
            child: const Text('Buka Pengaturan'),
          ),
        ],
      ),
    );
    if (go == 'open') {
      await NativeBridge.openAccessibilitySettings();
    } else if (go == 'details') {
      await NativeBridge.openAppDetails();
    }
  }

  Future<void> _refreshNative() async {
    final overlay = await NativeBridge.hasOverlayPermission();
    final a11y = await NativeBridge.isAccessibilityEnabled();
    final running = await NativeBridge.isAssistantRunning();
    if (!mounted) return;
    setState(() {
      _overlayGranted = overlay;
      _a11yEnabled = a11y;
      _floating = running;
    });
  }

  Future<void> _saveKeys() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('api_key_Google Gemini', _geminiKeyController.text.trim());
    await p.setString('api_key_Groq', _groqKeyController.text.trim());
    await p.setString('ai_provider', _provider);
    await p.setString('ai_model', _model);
    await p.setString('ai_vision_model', _visionModel);
    await AIService.syncNative();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Pengaturan AI disimpan.')),
    );
  }

  bool get _hasKey {
    if (_provider == 'Groq') {
      final k = _groqKeyController.text.trim();
      return k.isNotEmpty || ApiKeys.groq.trim().isNotEmpty;
    }
    final k = _geminiKeyController.text.trim();
    return k.isNotEmpty || ApiKeys.gemini.trim().isNotEmpty;
  }

  Future<void> _toggleFloating(bool on) async {
    if (!on) {
      await NativeBridge.stopAssistant();
      if (!mounted) return;
      setState(() => _floating = false);
      return;
    }
    if (!_hasKey) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Isi $_provider API key dulu.')),
      );
      return;
    }
    await _saveKeys();
    setState(() => _starting = true);
    final r = await NativeBridge.startAssistant();
    if (!mounted) return;
    setState(() => _starting = false);
    switch (r) {
      case 'started':
      case 'already_running':
        setState(() => _floating = true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Floating Assistant aktif. Tap = menu, tarik = geser, tahan+tarik = pilih area.',
            ),
          ),
        );
      case 'overlay_permission':
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Izinkan "Tampil di atas aplikasi lain", lalu nyalakan lagi.',
            ),
          ),
        );
      case 'denied':
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Izin perekaman layar ditolak.')),
        );
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal mengaktifkan ($r).')),
        );
    }
    await _refreshNative();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _geminiKeyController.dispose();
    _groqKeyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.background,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // ignore: prefer_const_constructors
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(24, 16, 24, 8),
                child: Text(
                  'Settings',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.5,
                    color: Color(0xFFF5F6FC),
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  _Section(
                    title: 'AI Provider',
                    children: [
                      _SettingsTile(
                        title: 'Provider',
                        trailing: Text(
                          _provider == 'Google Gemini' ? 'Gemini' : 'Groq',
                          style: TextStyle(
                            color: context.secondaryText,
                            fontSize: 14,
                          ),
                        ),
                        onTap: () => _showProviderSheet(),
                      ),
                      _SettingsTile(
                        title: 'Model chat',
                        trailing: Text(
                          _model,
                          style: TextStyle(
                            color: context.secondaryText,
                            fontSize: 13,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        onTap: () => _showModelSheet(vision: false),
                      ),
                      _SettingsTile(
                        title: 'Vision model',
                        trailing: Text(
                          _visionModel,
                          style: TextStyle(
                            color: context.secondaryText,
                            fontSize: 13,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        onTap: () => _showModelSheet(vision: true),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _Section(
                    title: 'API Keys',
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Gemini API Key',
                              style: TextStyle(
                                fontSize: 13,
                                color: context.secondaryText,
                              ),
                            ),
                            const SizedBox(height: 8),
                            TextField(
                              controller: _geminiKeyController,
                              obscureText: !_showGemini,
                              style: TextStyle(
                                color: context.primaryText,
                                fontSize: 14,
                                letterSpacing: 1.2,
                              ),
                              decoration: _keyDecoration(
                                context,
                                hint: ApiKeys.gemini.isNotEmpty
                                    ? 'Memakai key dari api_keys.dart'
                                    : 'AIza...',
                                shown: _showGemini,
                                onToggle: () => setState(
                                  () => _showGemini = !_showGemini,
                                ),
                              ),
                            ),
                            const SizedBox(height: 14),
                            Text(
                              'Groq API Key',
                              style: TextStyle(
                                fontSize: 13,
                                color: context.secondaryText,
                              ),
                            ),
                            const SizedBox(height: 8),
                            TextField(
                              controller: _groqKeyController,
                              obscureText: !_showGroq,
                              style: TextStyle(
                                color: context.primaryText,
                                fontSize: 14,
                                letterSpacing: 1.2,
                              ),
                              decoration: _keyDecoration(
                                context,
                                hint: ApiKeys.groq.isNotEmpty
                                    ? 'Memakai key dari api_keys.dart'
                                    : 'gsk_...',
                                shown: _showGroq,
                                onToggle: () =>
                                    setState(() => _showGroq = !_showGroq),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              'Key disimpan lokal di perangkat. Bisa juga diisi di lib/config/api_keys.dart.',
                              style: TextStyle(
                                fontSize: 12,
                                color: context.tertiaryText,
                                height: 1.4,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Align(
                              alignment: Alignment.centerRight,
                              child: FilledButton(
                                onPressed: _saveKeys,
                                child: const Text('Save AI settings'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _Section(
                    title: 'Screen Assistant',
                    children: [
                      _SettingsToggle(
                        title: 'Enable Floating Assistant',
                        subtitle: _floating
                            ? 'Aktif: bola melayang di atas aplikasi lain'
                            : 'Tampilkan bola sistem. Android meminta izin rekam layar.',
                        value: _floating,
                        onChanged: _starting ? null : _toggleFloating,
                      ),
                      if (_starting)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Center(
                            child: SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          ),
                        ),
                      _SettingsToggle(
                        title: 'Triple Tap',
                        subtitle:
                            'Ketuk bola 3x untuk pilih area. Jika mati, 1 ketukan membuka menu.',
                        value: _tripleTap,
                        onChanged: (v) async {
                          setState(() => _tripleTap = v);
                          final p = await SharedPreferences.getInstance();
                          await p.setBool('triple_tap', v);
                          await AIService.syncNative();
                        },
                      ),
                      _SettingsToggle(
                        title: 'Auto Answer',
                        subtitle:
                            'Untuk pilih-area: tampilkan jawaban tertulis. Mode Play (menu bola > Auto Answer) mengetuk jawaban sendiri.',
                        value: _autoAnswer,
                        onChanged: (v) async {
                          setState(() => _autoAnswer = v);
                          final p = await SharedPreferences.getInstance();
                          await p.setBool('auto_answer', v);
                          await AIService.syncNative();
                        },
                      ),
                      _PermissionRow(
                        title: 'Display over other apps',
                        granted: _overlayGranted,
                        actionLabel: _overlayGranted ? 'Diizinkan' : 'Izinkan',
                        onTap: () async {
                          await NativeBridge.requestOverlayPermission();
                          await Future.delayed(const Duration(seconds: 1));
                          await _refreshNative();
                        },
                      ),
                      _PermissionRow(
                        title: 'Accessibility (wajib untuk Play)',
                        granted: _a11yEnabled,
                        actionLabel: _a11yEnabled ? 'Aktif' : 'Aktifkan',
                        onTap: _askAccessibility,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _Section(
                    title: 'Appearance',
                    children: [
                      _SettingsToggle(
                        title: 'Dark Mode',
                        subtitle: 'Use dark glass theme',
                        value: _darkMode,
                        onChanged: (v) async {
                          setState(() => _darkMode = v);
                          final p = await SharedPreferences.getInstance();
                          await p.setBool('dark_mode', v);
                        },
                      ),
                      _SettingsToggle(
                        title: 'Haptic Feedback',
                        value: _haptic,
                        onChanged: (v) async {
                          setState(() => _haptic = v);
                          final p = await SharedPreferences.getInstance();
                          await p.setBool('haptic', v);
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _Section(
                    title: 'Privacy',
                    children: [
                      _SettingsTile(
                        title: 'Clear Conversation History',
                        icon: Icons.delete_outline_rounded,
                        destructive: true,
                        onTap: () => _confirmClear(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _Section(
                    title: 'About',
                    children: [
                      _SettingsTile(
                        title: 'Version',
                        trailing: Text(
                          '1.0.0',
                          style: TextStyle(
                            color: context.secondaryText,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 40),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _keyDecoration(
    BuildContext context, {
    required String hint,
    required bool shown,
    required VoidCallback onToggle,
  }) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: context.tertiaryText, fontSize: 13),
      filled: true,
      fillColor: context.glassElevated,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: context.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: context.border),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      suffixIcon: IconButton(
        icon: Icon(
          shown ? Icons.visibility_outlined : Icons.visibility_off_outlined,
          size: 18,
          color: context.tertiaryText,
        ),
        onPressed: onToggle,
      ),
    );
  }

  void _showProviderSheet() {
    _showSelectionSheet(
      'AI Provider',
      AIService.providers,
      _provider,
      (v) async {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('ai_provider', v);
        if (!mounted) return;
        setState(() {
          _provider = v;
          _model = AIService.defaultModel(v);
          _visionModel = AIService.defaultVisionModel(v);
        });
        await prefs.setString('ai_model', _model);
        await prefs.setString('ai_vision_model', _visionModel);
        await AIService.syncNative();
      },
    );
  }

  void _showModelSheet({required bool vision}) {
    final models = AIService.suggestedModels(_provider);
    final current = vision ? _visionModel : _model;
    _showSelectionSheet(vision ? 'Vision model' : 'Model chat', models, current,
        (v) async {
      setState(() {
        if (vision) {
          _visionModel = v;
        } else {
          _model = v;
        }
      });
      final p = await SharedPreferences.getInstance();
      if (vision) {
        await p.setString('ai_vision_model', v);
      } else {
        await p.setString('ai_model', v);
      }
      await AIService.syncNative();
    });
  }

  void _showSelectionSheet(
    String title,
    List<String> options,
    String current,
    ValueChanged<String> onSelect,
  ) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return GlassContainer(
          borderRadius: 24,
          blur: 30,
          opacity: 0.92,
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.fromLTRB(8, 16, 8, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              ...options.map((o) {
                final selected = o == current;
                return ListTile(
                  title: Text(
                    o,
                    style: TextStyle(
                      color: context.primaryText,
                      fontWeight:
                          selected ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                  trailing: selected
                      ? Icon(Icons.check_rounded,
                          color: context.primaryAccent, size: 20)
                      : null,
                  onTap: () {
                    onSelect(o);
                    Navigator.pop(ctx);
                  },
                );
              }),
            ],
          ),
        );
      },
    );
  }

  void _confirmClear(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: GlassContainer(
            borderRadius: 20,
            blur: 24,
            opacity: 0.95,
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Clear History?',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  'This will permanently delete all conversations.',
                  style: TextStyle(color: context.secondaryText, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: GlassButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Center(child: Text('Cancel')),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GlassButton(
                        isPrimary: true,
                        onPressed: () async {
                          Navigator.pop(ctx);
                          HapticFeedback.mediumImpact();
                          final p = await SharedPreferences.getInstance();
                          await p.remove('chat_history');
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Riwayat dihapus.'),
                              ),
                            );
                          }
                        },
                        backgroundColor: context.error,
                        child: const Center(child: Text('Clear')),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.children});
  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            title.toUpperCase(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: context.tertiaryText,
              letterSpacing: 0.8,
            ),
          ),
        ),
        GlassCard(
          padding: EdgeInsets.zero,
          borderRadius: 16,
          child: Column(children: children),
        ),
      ],
    );
  }
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({
    required this.title,
    this.trailing,
    this.icon,
    this.onTap,
    this.destructive = false,
  });

  final String title;
  final Widget? trailing;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            if (icon != null) ...[
              Icon(
                icon,
                size: 20,
                color: destructive ? context.error : context.secondaryText,
              ),
              const SizedBox(width: 12),
            ],
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 15,
                  color: destructive ? context.error : context.primaryText,
                ),
              ),
            ),
            if (trailing != null) Flexible(child: trailing!),
            if (onTap != null && trailing == null)
              Icon(Icons.chevron_right_rounded,
                  size: 18, color: context.tertiaryText),
          ],
        ),
      ),
    );
  }
}

class _SettingsToggle extends StatelessWidget {
  const _SettingsToggle({
    required this.title,
    this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 15, color: context.primaryText),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 3),
                  Text(
                    subtitle!,
                    style: TextStyle(
                      fontSize: 12,
                      color: context.tertiaryText,
                      height: 1.35,
                    ),
                  ),
                ],
              ],
            ),
          ),
          Switch.adaptive(
            value: value,
            onChanged: onChanged,
            activeColor: context.primaryAccent,
          ),
        ],
      ),
    );
  }
}

class _PermissionRow extends StatelessWidget {
  const _PermissionRow({
    required this.title,
    required this.granted,
    required this.actionLabel,
    required this.onTap,
  });

  final String title;
  final bool granted;
  final String actionLabel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Icon(
            granted ? Icons.check_circle_rounded : Icons.circle_outlined,
            size: 18,
            color: granted ? Colors.greenAccent : context.tertiaryText,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: TextStyle(fontSize: 14, color: context.primaryText),
            ),
          ),
          TextButton(
            onPressed: onTap,
            child: Text(actionLabel),
          ),
        ],
      ),
    );
  }
}
