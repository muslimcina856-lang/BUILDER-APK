import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/app_theme.dart';
import '../../core/widgets/glass_container.dart';
import '../../core/widgets/mafia_robot.dart';

/// Draggable Liquid Glass panel used by the Auto Answer feature.
///
/// Place this widget inside a Stack. Updating [answer], [explanation], or
/// [questionNumber] automatically refreshes the displayed result.
class FloatingAnswerPanel extends StatefulWidget {
  const FloatingAnswerPanel({
    super.key,
    required this.questionNumber,
    required this.answer,
    required this.explanation,
    this.onClose,
    this.onCopy,
    this.isLoading = false,
    this.errorMessage,
  });

  final String questionNumber;
  final String answer;
  final String explanation;
  final VoidCallback? onClose;
  final VoidCallback? onCopy;
  final bool isLoading;
  final String? errorMessage;

  @override
  State<FloatingAnswerPanel> createState() => _FloatingAnswerPanelState();
}

class _FloatingAnswerPanelState extends State<FloatingAnswerPanel>
    with SingleTickerProviderStateMixin {
  static const double _panelWidth = 280;

  bool _expanded = true;
  Offset _position = const Offset(24, 120);
  late final AnimationController _appearController;
  late final Animation<double> _fadeAnimation;
  late final Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _appearController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _appearController,
      curve: Curves.easeOut,
    );
    _scaleAnimation = Tween<double>(begin: 0.92, end: 1).animate(
      CurvedAnimation(parent: _appearController, curve: Curves.easeOutBack),
    );
    _appearController.forward();
  }

  @override
  void didUpdateWidget(covariant FloatingAnswerPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.answer != widget.answer ||
        oldWidget.explanation != widget.explanation ||
        oldWidget.questionNumber != widget.questionNumber ||
        oldWidget.isLoading != widget.isLoading ||
        oldWidget.errorMessage != widget.errorMessage) {
      _appearController
        ..reset()
        ..forward();
    }
  }

  @override
  void dispose() {
    _appearController.dispose();
    super.dispose();
  }

  void _copyAnswer() {
    HapticFeedback.lightImpact();
    if (widget.onCopy != null) {
      widget.onCopy!.call();
      return;
    }

    final text = [
      'Question ${widget.questionNumber}',
      if (widget.answer.trim().isNotEmpty) 'Answer: ${widget.answer}',
      if (widget.explanation.trim().isNotEmpty)
        'Explanation: ${widget.explanation}',
    ].join('\n\n');

    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.maybeOf(context)?.showSnackBar(
      const SnackBar(
        content: Text('Answer copied'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    final screen = media.size;
    final maxHeight = (screen.height -
            media.padding.top -
            media.padding.bottom -
            24)
        .clamp(160.0, screen.height)
        .toDouble();

    return AnimatedBuilder(
      animation: _appearController,
      builder: (context, child) => Positioned(
        left: _position.dx,
        top: _position.dy,
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: ScaleTransition(
            scale: _scaleAnimation,
            alignment: Alignment.topLeft,
            child: child,
          ),
        ),
      ),
      child: GestureDetector(
        onPanUpdate: (details) {
          final maxX = (screen.width - _panelWidth).clamp(0.0, double.infinity);
          final maxY = (screen.height -
                  media.padding.bottom -
                  (_expanded ? 160.0 : 60.0))
              .clamp(0.0, double.infinity);

          setState(() {
            _position = Offset(
              (_position.dx + details.delta.dx).clamp(0.0, maxX).toDouble(),
              (_position.dy + details.delta.dy)
                  .clamp(media.padding.top, maxY)
                  .toDouble(),
            );
          });
        },
        child: GlassContainer(
          width: _panelWidth,
          borderRadius: 18,
          blur: 28,
          opacity: 0.88,
          padding: const EdgeInsets.all(14),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: maxHeight),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(context),
                if (_expanded) ...[
                  const SizedBox(height: 12),
                  Flexible(
                    child: SingleChildScrollView(
                      child: _buildBody(context),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        const MafiaRobot(size: 32, glow: false),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Auto Answer',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: context.primaryText,
                ),
              ),
              Text(
                widget.isLoading ? 'Analyzing...' : 'Assistant',
                style: TextStyle(
                  fontSize: 10,
                  color: context.secondaryText,
                ),
              ),
            ],
          ),
        ),
        _headerButton(
          icon: _expanded
              ? Icons.expand_less_rounded
              : Icons.expand_more_rounded,
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() => _expanded = !_expanded);
          },
        ),
        const SizedBox(width: 4),
        _headerButton(
          icon: Icons.close_rounded,
          onTap: widget.onClose,
        ),
      ],
    );
  }

  Widget _headerButton({
    required IconData icon,
    required VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: SizedBox(
        width: 26,
        height: 28,
        child: Icon(
          icon,
          size: 18,
          color: context.secondaryText,
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    if (widget.isLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: Column(
            children: [
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
              const SizedBox(height: 12),
              Text(
                'Finding the answer...',
                style: TextStyle(
                  fontSize: 12,
                  color: context.secondaryText,
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (widget.errorMessage != null) {
      return Text(
        widget.errorMessage!,
        style: const TextStyle(fontSize: 13, color: Colors.redAccent),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Q${widget.questionNumber}',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: context.primaryAccent,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          widget.answer.trim().isEmpty ? 'Waiting for a question...' : widget.answer,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: context.primaryText,
            height: 1.4,
          ),
        ),
        if (widget.explanation.trim().isNotEmpty) ...[
          const SizedBox(height: 8),
          Text(
            widget.explanation,
            style: TextStyle(
              fontSize: 13,
              color: context.secondaryText,
              height: 1.5,
            ),
          ),
        ],
        const SizedBox(height: 12),
        Align(
          alignment: Alignment.centerLeft,
          child: GlassButton(
            onPressed: _copyAnswer,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            borderRadius: 10,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.copy_rounded,
                    size: 14, color: context.primaryText),
                const SizedBox(width: 5),
                Text(
                  'Copy',
                  style: TextStyle(
                    fontSize: 12,
                    color: context.primaryText,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
