import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/glass_container.dart';
import '../../core/widgets/ai_orb.dart';
import '../../core/widgets/robot_assistant.dart';
import '../../core/widgets/mafia_robot.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    this.onStartChat,
    this.onOpenSettings,
  });

  final VoidCallback? onStartChat;
  final VoidCallback? onOpenSettings;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _inputController = TextEditingController();
  final _focusNode = FocusNode();
  OrbState _orbState = OrbState.idle;
  RobotState _robotState = RobotState.idle;

  @override
  void dispose() {
    _inputController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _inputController.text.trim();
    if (text.isEmpty) return;
    HapticFeedback.lightImpact();
    setState(() => _orbState = OrbState.thinking);
    // Navigate / hand off to chat
    widget.onStartChat?.call();
    _inputController.clear();
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) setState(() => _orbState = OrbState.idle);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildTopBar(context),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  children: [
                    const SizedBox(height: 32),
                    Text(
                      'Good evening',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: context.secondaryText,
                            letterSpacing: 0.3,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'What can I help you with?',
                      style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                            letterSpacing: -0.5,
                          ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 40),
                    AIOrb(
                      size: 130,
                      state: _orbState,
                      onTap: () {
                        HapticFeedback.selectionClick();
                        setState(() {
                          _orbState = _orbState == OrbState.idle
                              ? OrbState.listening
                              : OrbState.idle;
                        });
                      },
                    ),
                    const SizedBox(height: 36),
                    _buildComposer(context),
                    const SizedBox(height: 28),
                    _buildQuickActions(context),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      child: Row(
        children: [
          // Logo wordmark
          Text(
            'mafia.ai',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: context.primaryText,
              letterSpacing: -0.6,
            ),
          ),
          const Spacer(),
          // Provider status pill
          GlassContainer(
            borderRadius: 20,
            blur: 12,
            opacity: 0.7,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: context.success,
                    boxShadow: [
                      BoxShadow(
                        color: context.success.withOpacity(0.5),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 7),
                Text(
                  'Claude',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: context.secondaryText,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          // Profile / settings
          GlassButton(
            onPressed: widget.onOpenSettings,
            padding: const EdgeInsets.all(10),
            borderRadius: 14,
            child: Icon(
              Icons.person_outline_rounded,
              size: 20,
              color: context.primaryText,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildComposer(BuildContext context) {
    return GlassInput(
      controller: _inputController,
      focusNode: _focusNode,
      hintText: 'Ask anything...',
      maxLines: 4,
      minLines: 1,
      textInputAction: TextInputAction.send,
      onSubmitted: (_) => _submit(),
      prefix: IconButton(
        onPressed: () => HapticFeedback.selectionClick(),
        icon: Icon(
          Icons.attach_file_rounded,
          size: 20,
          color: context.secondaryText,
        ),
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
      ),
      suffix: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Auto Answer shortcut
          GestureDetector(
            onTap: () {
              HapticFeedback.lightImpact();
              setState(() {
                _robotState = _robotState == RobotState.idle
                    ? RobotState.scanning
                    : RobotState.idle;
              });
            },
            child: Padding(
              padding: const EdgeInsets.only(right: 4),
              child: const MafiaRobot(size: 36, glow: false),
            ),
          ),
          // Send
          GestureDetector(
            onTap: _submit,
            child: Container(
              width: 36,
              height: 36,
              margin: const EdgeInsets.only(right: 4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    context.primaryAccent,
                    context.secondaryAccent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: context.primaryAccent.withOpacity(0.35),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: const Icon(
                Icons.arrow_upward_rounded,
                size: 18,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    final actions = [
      _QuickAction(
        icon: Icons.chat_bubble_outline_rounded,
        label: 'Ask anything',
        onTap: widget.onStartChat,
      ),
      _QuickAction(
        icon: Icons.screenshot_monitor_rounded,
        label: 'Analyze screen',
        onTap: () => HapticFeedback.selectionClick(),
      ),
      _QuickAction(
        icon: Icons.smart_toy_outlined,
        label: 'Auto Answer',
        onTap: () {
          HapticFeedback.lightImpact();
          setState(() => _robotState = RobotState.scanning);
        },
      ),
      _QuickAction(
        icon: Icons.add_comment_outlined,
        label: 'New chat',
        onTap: widget.onStartChat,
      ),
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 2.4,
      children: actions.map((a) {
        return GlassCard(
          onTap: () {
            HapticFeedback.selectionClick();
            a.onTap?.call();
          },
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          borderRadius: 16,
          child: Row(
            children: [
              Icon(a.icon, size: 20, color: context.primaryAccent),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  a.label,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: context.primaryText,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}

class _QuickAction {
  const _QuickAction({
    required this.icon,
    required this.label,
    this.onTap,
  });
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
}
