import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/glass_container.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key, this.onOpenChat});
  final VoidCallback? onOpenChat;
  @override State<HistoryScreen> createState()=>_HistoryScreenState();
}
class _HistoryScreenState extends State<HistoryScreen> {
  List<_HistoryItem> items=[];
  @override void initState(){super.initState();_load();}
  Future<void> _load() async {final p=await SharedPreferences.getInstance();final raw=p.getStringList('chat_history')??[];if(!mounted)return;setState(()=>items=raw.map((s){try{final d=jsonDecode(s);return _HistoryItem(d['title']??'Untitled',_relative(d['timestamp']??''));}catch(_){return const _HistoryItem('Conversation','');}}).toList());}
  String _relative(String iso){final d=DateTime.tryParse(iso);if(d==null)return '';final diff=DateTime.now().difference(d);if(diff.inMinutes<1)return 'Just now';if(diff.inHours<1)return '${diff.inMinutes}m ago';if(diff.inDays<1)return '${diff.inHours}h ago';if(diff.inDays<7)return '${diff.inDays}d ago';return '${d.day}/${d.month}/${d.year}';}
  @override Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: context.background,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
                child: Row(
                  children: [
                    Text(
                      'History',
                      style: Theme.of(context).textTheme.displayMedium,
                    ),
                    const Spacer(),
                    GlassButton(
                      onPressed: () {},
                      padding: const EdgeInsets.all(10),
                      borderRadius: 12,
                      child: Icon(
                        Icons.search_rounded,
                        size: 20,
                        color: context.primaryText,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final item = items[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: GlassCard(
                        onTap: () {
                          HapticFeedback.selectionClick();
                          widget.onOpenChat?.call();
                        },
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 14,
                        ),
                        borderRadius: 16,
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: context.primaryAccent.withOpacity(0.12),
                              ),
                              child: Icon(
                                Icons.chat_bubble_outline_rounded,
                                size: 18,
                                color: context.primaryAccent,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item.title,
                                    style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w500,
                                      color: context.primaryText,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    item.time,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: context.tertiaryText,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.chevron_right_rounded,
                              size: 18,
                              color: context.tertiaryText,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  childCount: items.length,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HistoryItem {
  const _HistoryItem(this.title, this.time);
  final String title;
  final String time;
}
