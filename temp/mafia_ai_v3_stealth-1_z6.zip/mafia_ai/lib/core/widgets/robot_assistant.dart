import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_theme.dart';

enum RobotState { idle, scanning, thinking, answering, success, error }

/// Minimalist metallic-glass robot assistant for Auto Answer.
class RobotAssistant extends StatefulWidget {
  const RobotAssistant({
    super.key,
    this.size = 56,
    this.state = RobotState.idle,
    this.onTap,
  });

  final double size;
  final RobotState state;
  final VoidCallback? onTap;

  @override
  State<RobotAssistant> createState() => _RobotAssistantState();
}

class _RobotAssistantState extends State<RobotAssistant>
    with TickerProviderStateMixin {
  late final AnimationController _floatController;
  late final AnimationController _scanController;
  late final AnimationController _thinkController;
  late final AnimationController _headController;

  @override
  void initState() {
    super.initState();
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    );

    _thinkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    );

    _headController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _sync(widget.state);
  }

  @override
  void didUpdateWidget(RobotAssistant oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.state != widget.state) _sync(widget.state);
  }

  void _sync(RobotState state) {
    switch (state) {
      case RobotState.idle:
      case RobotState.success:
        _scanController.stop();
        _thinkController.stop();
        if (!_floatController.isAnimating) {
          _floatController.repeat(reverse: true);
        }
        break;
      case RobotState.scanning:
        _thinkController.stop();
        _scanController.repeat();
        break;
      case RobotState.thinking:
        _scanController.stop();
        _thinkController.repeat();
        break;
      case RobotState.answering:
        _scanController.stop();
        _thinkController.repeat();
        break;
      case RobotState.error:
        _scanController.stop();
        _thinkController.stop();
        _floatController.stop();
        break;
    }
  }

  @override
  void dispose() {
    _floatController.dispose();
    _scanController.dispose();
    _thinkController.dispose();
    _headController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;
    return GestureDetector(
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: Listenable.merge([
          _floatController,
          _scanController,
          _thinkController,
        ]),
        builder: (context, _) {
          final floatY = (widget.state == RobotState.idle ||
                  widget.state == RobotState.success)
              ? math.sin(_floatController.value * math.pi) * 3.0
              : 0.0;

          return Transform.translate(
            offset: Offset(0, floatY),
            child: SizedBox(
              width: size,
              height: size * 1.25,
              child: CustomPaint(
                size: Size(size, size * 1.25),
                painter: _RobotPainter(
                  state: widget.state,
                  scanValue: _scanController.value,
                  thinkValue: _thinkController.value,
                  isDark: context.isDark,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _RobotPainter extends CustomPainter {
  _RobotPainter({
    required this.state,
    required this.scanValue,
    required this.thinkValue,
    required this.isDark,
  });

  final RobotState state;
  final double scanValue;
  final double thinkValue;
  final bool isDark;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w / 2;

    // Body (rounded rectangle)
    final bodyRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(cx, h * 0.62),
        width: w * 0.72,
        height: h * 0.55,
      ),
      const Radius.circular(10),
    );

    final bodyPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          const Color(0xFF2A2E3A),
          const Color(0xFF1A1D28),
          const Color(0xFF252836),
        ],
      ).createShader(bodyRect.outerRect);
    canvas.drawRRect(bodyRect, bodyPaint);

    // Body border
    canvas.drawRRect(
      bodyRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withOpacity(0.12),
    );

    // Head
    final headRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(cx, h * 0.28),
        width: w * 0.78,
        height: h * 0.38,
      ),
      const Radius.circular(12),
    );

    final headPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          const Color(0xFF32364A),
          const Color(0xFF1E2230),
        ],
      ).createShader(headRect.outerRect);
    canvas.drawRRect(headRect, headPaint);

    canvas.drawRRect(
      headRect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withOpacity(0.15),
    );

    // Faceplate
    final faceRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(cx, h * 0.28),
        width: w * 0.58,
        height: h * 0.22,
      ),
      const Radius.circular(8),
    );
    canvas.drawRRect(
      faceRect,
      Paint()..color = const Color(0xFF0C0E14),
    );

    // Eyes
    final eyeY = h * 0.27;
    final eyeRadius = w * 0.055;
    final leftEye = Offset(cx - w * 0.14, eyeY);
    final rightEye = Offset(cx + w * 0.14, eyeY);

    Color eyeColor;
    switch (state) {
      case RobotState.error:
        eyeColor = AppColors.darkError;
        break;
      case RobotState.success:
        eyeColor = AppColors.darkSuccess;
        break;
      case RobotState.answering:
      case RobotState.thinking:
        eyeColor = AppColors.darkPrimaryAccent;
        break;
      default:
        eyeColor = AppColors.darkSecondaryAccent;
    }

    final eyePaint = Paint()..color = eyeColor;
    final eyeGlow = Paint()
      ..color = eyeColor.withOpacity(0.4)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    canvas.drawCircle(leftEye, eyeRadius * 1.6, eyeGlow);
    canvas.drawCircle(rightEye, eyeRadius * 1.6, eyeGlow);
    canvas.drawCircle(leftEye, eyeRadius, eyePaint);
    canvas.drawCircle(rightEye, eyeRadius, eyePaint);

    // Scanning line
    if (state == RobotState.scanning) {
      final scanX = faceRect.left + faceRect.width * scanValue;
      canvas.drawLine(
        Offset(scanX, faceRect.top + 2),
        Offset(scanX, faceRect.bottom - 2),
        Paint()
          ..color = AppColors.darkSecondaryAccent.withOpacity(0.7)
          ..strokeWidth = 1.5
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
      );
    }

    // Thinking indicator (small rotating arc above head)
    if (state == RobotState.thinking || state == RobotState.answering) {
      final arcCenter = Offset(cx, h * 0.06);
      final arcPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round
        ..color = AppColors.darkPrimaryAccent.withOpacity(0.8);
      canvas.drawArc(
        Rect.fromCircle(center: arcCenter, radius: 6),
        thinkValue * math.pi * 2,
        math.pi * 1.2,
        false,
        arcPaint,
      );
    }

    // Neck connector
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(cx, h * 0.42),
          width: w * 0.18,
          height: h * 0.06,
        ),
        const Radius.circular(3),
      ),
      Paint()..color = const Color(0xFF1A1D28),
    );

    // Accent line on chest
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(cx, h * 0.58),
          width: w * 0.35,
          height: 3,
        ),
        const Radius.circular(2),
      ),
      Paint()
        ..shader = LinearGradient(
          colors: AppColors.robotAccentGradient,
        ).createShader(Rect.fromLTWH(cx - w * 0.175, h * 0.57, w * 0.35, 3)),
    );

    // Soft glow under robot
    if (state != RobotState.error) {
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(cx, h * 0.95),
          width: w * 0.5,
          height: 6,
        ),
        Paint()
          ..color = AppColors.darkPrimaryAccent.withOpacity(0.15)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RobotPainter old) {
    return old.scanValue != scanValue ||
        old.thinkValue != thinkValue ||
        old.state != state;
  }
}
