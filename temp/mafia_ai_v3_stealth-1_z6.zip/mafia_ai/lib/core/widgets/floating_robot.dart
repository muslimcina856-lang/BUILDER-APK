import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_colors.dart';
import '../theme/app_theme.dart';
import 'glass_container.dart';
import 'robot_assistant.dart';
import 'mafia_robot.dart';
import 'dart:async';

/// Floating robot overlay - draggable, animated, with greeting menu.
/// Invisible mode: robot becomes dots only.
class FloatingRobot extends StatefulWidget {
  const FloatingRobot({
    super.key,
    this.onAutoScreen,
    this.onAutoAnswer,
    this.onCloseApp,
  });

  final VoidCallback? onAutoScreen;
  final VoidCallback? onAutoAnswer;
  final VoidCallback? onCloseApp;

  @override
  State<FloatingRobot> createState() => _FloatingRobotState();
}

class _FloatingRobotState extends State<FloatingRobot>
    with TickerProviderStateMixin {
  Offset _position = const Offset(0, 0);
  bool _initialized = false;
  bool _menuOpen = false;
  bool _invisible = false;
  bool _greeting = false;
  Timer? _greetTimer;
  RobotState _robotState = RobotState.idle;

  late final AnimationController _floatController;
  late final AnimationController _menuController;
  late final AnimationController _pulseController;
  late final AnimationController _dotController;

  static const double _robotSize = 64;
  static const double _hitSize = 72;

  @override
  void initState() {
    super.initState();
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..repeat(reverse: true);

    _menuController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _dotController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();

    // Robot menyapa saat muncul, lalu tiap ~14 detik.
    Future.delayed(const Duration(milliseconds: 700), _greet);
    _greetTimer = Timer.periodic(const Duration(seconds: 14), (_) => _greet());
  }

  void _greet() {
    if (!mounted || _invisible || _menuOpen) return;
    setState(() => _greeting = true);
    Future.delayed(const Duration(milliseconds: 2600), () {
      if (mounted) setState(() => _greeting = false);
    });
  }

  @override
  void dispose() {
    _greetTimer?.cancel();
    _floatController.dispose();
    _menuController.dispose();
    _pulseController.dispose();
    _dotController.dispose();
    super.dispose();
  }

  void _ensurePosition(Size screen) {
    if (_initialized) return;
    _initialized = true;
    // Default bottom-right, above nav bar
    _position = Offset(
      screen.width - _hitSize - 16,
      screen.height - _hitSize - 100,
    );
  }

  void _toggleMenu() {
    HapticFeedback.lightImpact();
    setState(() {
      _menuOpen = !_menuOpen;
      if (_menuOpen) {
        _menuController.forward();
        _robotState = RobotState.idle;
      } else {
        _menuController.reverse();
      }
    });
  }

  void _closeMenu() {
    if (!_menuOpen) return;
    setState(() {
      _menuOpen = false;
      _menuController.reverse();
    });
  }

  void _onSelect(String action) {
    HapticFeedback.selectionClick();
    _closeMenu();

    switch (action) {
      case 'screen':
        setState(() => _robotState = RobotState.scanning);
        widget.onAutoScreen?.call();
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) setState(() => _robotState = RobotState.idle);
        });
        break;
      case 'answer':
        setState(() => _robotState = RobotState.thinking);
        widget.onAutoAnswer?.call();
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) setState(() => _robotState = RobotState.idle);
        });
        break;
      case 'close':
        widget.onCloseApp?.call();
        break;
      case 'invisible':
        setState(() {
          _invisible = !_invisible;
          if (_invisible) {
            _robotState = RobotState.idle;
          }
        });
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final screen = MediaQuery.of(context).size;
    final padding = MediaQuery.of(context).padding;
    _ensurePosition(screen);

    return Stack(
      children: [
        // Tap outside to close menu
        if (_menuOpen)
          Positioned.fill(
            child: GestureDetector(
              onTap: _closeMenu,
              behavior: HitTestBehavior.opaque,
              child: const ColoredBox(color: Colors.transparent),
            ),
          ),

        // Menu bubble (appears above robot)
        if (_menuOpen || _menuController.isAnimating)
          Positioned(
            left: (_position.dx + _hitSize / 2 - 130)
                .clamp(12.0, screen.width - 272),
            top: (_position.dy - 220).clamp(padding.top + 8, screen.height),
            child: FadeTransition(
              opacity: _menuController,
              child: ScaleTransition(
                scale: Tween<double>(begin: 0.85, end: 1.0).animate(
                  CurvedAnimation(
                    parent: _menuController,
                    curve: Curves.easeOutBack,
                  ),
                ),
                alignment: Alignment.bottomCenter,
                child: _GreetingMenu(
                  invisible: _invisible,
                  onSelect: _onSelect,
                ),
              ),
            ),
          ),

        // Floating robot / dots
        Positioned(
          left: _position.dx,
          top: _position.dy,
          child: GestureDetector(
            onPanStart: (_) => _closeMenu(),
            onPanUpdate: (details) {
              setState(() {
                _position += details.delta;
                _position = Offset(
                  _position.dx.clamp(0, screen.width - _hitSize),
                  _position.dy.clamp(
                    padding.top,
                    screen.height - _hitSize - padding.bottom,
                  ),
                );
              });
            },
            onPanEnd: (_) {
              // Snap to nearest edge (left or right)
              final mid = screen.width / 2;
              final targetX = _position.dx + _hitSize / 2 < mid
                  ? 12.0
                  : screen.width - _hitSize - 12;
              setState(() {
                _position = Offset(targetX, _position.dy);
              });
            },
            onTap: _toggleMenu,
            child: SizedBox(
              width: _hitSize,
              height: _hitSize,
              child: AnimatedBuilder(
                animation: Listenable.merge([
                  _floatController,
                  _pulseController,
                  _dotController,
                ]),
                builder: (context, _) {
                  final floatY =
                      math.sin(_floatController.value * math.pi) * 4.0;
                  return Transform.translate(
                    offset: Offset(0, floatY),
                    child: _invisible
                        ? _buildDots()
                        : _buildRobot(),
                  );
                },
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRobot() {
    return Center(
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: [
          MafiaRobot(size: _robotSize + 8, waving: _greeting),
          // gelembung sapaan
          Positioned(
            bottom: _robotSize + 4,
            right: -4,
            child: IgnorePointer(
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 220),
                opacity: _greeting ? 1 : 0,
                child: AnimatedScale(
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.easeOutBack,
                  scale: _greeting ? 1 : 0.6,
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xF2171A24),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.18)),
                    ),
                    child: const Text(
                      'Halo!',
                      softWrap: false,
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDots() {
    // 3 pulsing dots - "invisible" mode
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final phase = (_dotController.value + i * 0.25) % 1.0;
          final scale = 0.55 + math.sin(phase * math.pi) * 0.45;
          final opacity = 0.35 + math.sin(phase * math.pi) * 0.55;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: Transform.scale(
              scale: scale,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.darkPrimaryAccent.withOpacity(opacity),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.darkPrimaryAccent.withOpacity(0.4),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _GreetingMenu extends StatelessWidget {
  const _GreetingMenu({
    required this.invisible,
    required this.onSelect,
  });

  final bool invisible;
  final void Function(String action) onSelect;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      width: 260,
      borderRadius: 18,
      blur: 28,
      opacity: 0.92,
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Greeting header
          Row(
            children: [
              const MafiaRobot(size: 40, waving: true, glow: false),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Halo!',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: context.primaryText,
                      ),
                    ),
                    Text(
                      'Ada yang bisa dibantu?',
                      style: TextStyle(
                        fontSize: 11,
                        color: context.secondaryText,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 0.5,
            color: Colors.white.withOpacity(0.08),
          ),
          const SizedBox(height: 6),
          _MenuItem(
            icon: Icons.screenshot_monitor_rounded,
            label: 'Auto lihat layar',
            subtitle: 'Scan & analisis layar',
            onTap: () => onSelect('screen'),
          ),
          _MenuItem(
            icon: Icons.smart_toy_outlined,
            label: 'Auto Answer',
            subtitle: 'Jawab soal otomatis',
            onTap: () => onSelect('answer'),
          ),
          _MenuItem(
            icon: invisible
                ? Icons.visibility_rounded
                : Icons.visibility_off_rounded,
            label: invisible ? 'Tampilkan robot' : 'Invisible',
            subtitle: invisible
                ? 'Kembalikan robot'
                : 'Sembunyikan, hanya titik',
            onTap: () => onSelect('invisible'),
          ),
          _MenuItem(
            icon: Icons.power_settings_new_rounded,
            label: 'Close mafia.ai',
            subtitle: 'Tutup aplikasi',
            isDestructive: true,
            onTap: () => onSelect('close'),
          ),
        ],
      ),
    );
  }
}

class _MenuItem extends StatelessWidget {
  const _MenuItem({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
    this.isDestructive = false,
  });

  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;
  final bool isDestructive;

  @override
  Widget build(BuildContext context) {
    final color = isDestructive
        ? AppColors.darkError
        : context.primaryText;
    final accent = isDestructive
        ? AppColors.darkError
        : context.primaryAccent;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: accent.withOpacity(0.12),
                ),
                child: Icon(icon, size: 18, color: accent),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: color,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 11,
                        color: context.secondaryText,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
