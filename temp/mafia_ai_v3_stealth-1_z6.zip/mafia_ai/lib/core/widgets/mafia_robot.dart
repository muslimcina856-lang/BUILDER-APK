import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Robot mafia.ai animasi.
/// - melayang, berkedip, mata melirik
/// - [waving]: melambai dengan mata senyum (menyapa)
/// - [cover]: menutup mata dengan kedua tangan (dipakai saat isi password)
/// - [look]: -1.0 (kiri) sampai 1.0 (kanan), arah pandang mata. Null = melirik otomatis
class MafiaRobot extends StatefulWidget {
  const MafiaRobot({
    super.key,
    this.size = 64,
    this.waving = false,
    this.glow = true,
    this.cover = false,
    this.look,
  });

  final double size;
  final bool waving;
  final bool glow;
  final bool cover;
  final double? look;

  @override
  State<MafiaRobot> createState() => _MafiaRobotState();
}

class _MafiaRobotState extends State<MafiaRobot> with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(end: widget.cover ? 1.0 : 0.0),
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
        builder: (context, cover, _) => TweenAnimationBuilder<double>(
          tween: Tween<double>(end: widget.look ?? 0.0),
          duration: const Duration(milliseconds: 160),
          builder: (context, look, __) => AnimatedBuilder(
            animation: _c,
            builder: (_, ___) => CustomPaint(
              painter: _RobotPainter(
                t: _c.value,
                waving: widget.waving,
                glow: widget.glow,
                cover: cover,
                look: look,
                manualLook: widget.look != null,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RobotPainter extends CustomPainter {
  _RobotPainter({
    required this.t,
    required this.waving,
    required this.glow,
    required this.cover,
    required this.look,
    required this.manualLook,
  });

  final double t;
  final bool waving;
  final bool glow;
  final double cover;
  final double look;
  final bool manualLook;

  static const _violet = Color(0xFF8B7CFF);
  static const _cyan = Color(0xFF63C7FF);
  static const _lav = Color(0xFFB9B3F2);

  Offset _lerp(Offset a, Offset b, double k) => Offset(a.dx + (b.dx - a.dx) * k, a.dy + (b.dy - a.dy) * k);

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width / 100.0;
    canvas.save();
    canvas.scale(s);

    final phase = t * math.pi * 2;
    final bob = math.sin(phase) * 2.2;
    final tilt = math.sin(phase * 0.5) * 0.045;

    // cahaya latar
    if (glow) {
      canvas.drawCircle(
        const Offset(50, 54),
        46,
        Paint()
          ..shader = RadialGradient(colors: [
            _violet.withOpacity(0.34 + 0.06 * math.sin(phase)),
            _violet.withOpacity(0),
          ]).createShader(Rect.fromCircle(center: const Offset(50, 54), radius: 46)),
      );
    }

    // bayangan lantai
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(50, 95), width: 32 - bob * 1.2, height: 4.5),
      Paint()..color = Colors.black.withOpacity(0.32),
    );

    canvas.translate(50, 54 + bob);
    canvas.rotate(tilt);
    canvas.translate(-50, -54);

    // badan
    final body = RRect.fromRectAndRadius(const Rect.fromLTWH(34, 62, 32, 26), const Radius.circular(13));
    canvas.drawRRect(
      body,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFF4F2FF), Color(0xFFAFA8EE)],
        ).createShader(body.outerRect),
    );
    canvas.drawRRect(body, Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = Colors.white.withOpacity(0.7));
    final pulse = 0.5 + 0.5 * math.sin(phase * 2);
    canvas.drawCircle(const Offset(50, 75), 6.5, Paint()..color = _violet.withOpacity(0.18 + 0.18 * pulse));
    canvas.drawCircle(const Offset(50, 75), 3.2, Paint()..color = _violet);
    canvas.drawCircle(const Offset(49, 74), 1.1, Paint()..color = Colors.white.withOpacity(0.85));

    // kepala
    final head = RRect.fromRectAndRadius(const Rect.fromLTWH(18, 18, 64, 48), const Radius.circular(23));
    canvas.drawRRect(
      head,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFFFF), Color(0xFFC2BCF6)],
        ).createShader(head.outerRect),
    );
    canvas.drawRRect(head, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.1..color = Colors.white.withOpacity(0.8));
    // kilau kepala
    canvas.drawOval(Rect.fromLTWH(26, 21, 20, 6), Paint()..color = Colors.white.withOpacity(0.55));

    // telinga
    for (final ex in [17.0, 83.0]) {
      canvas.drawCircle(Offset(ex, 42), 6.2, Paint()..color = _violet);
      canvas.drawCircle(Offset(ex, 42), 3.2, Paint()..color = _cyan.withOpacity(0.9));
    }

    // antena
    canvas.drawLine(const Offset(50, 18), const Offset(50, 9.5), Paint()..color = _lav..strokeWidth = 2.4..strokeCap = StrokeCap.round);
    final tipOn = math.sin(phase * 3) > 0.1;
    final tipColor = tipOn ? _cyan : _violet;
    canvas.drawCircle(const Offset(50, 8), 7, Paint()..color = tipColor.withOpacity(0.25));
    canvas.drawCircle(const Offset(50, 8), 3.8, Paint()..color = tipColor);
    canvas.drawCircle(const Offset(49, 7), 1.2, Paint()..color = Colors.white.withOpacity(0.8));

    // visor
    final visor = RRect.fromRectAndRadius(const Rect.fromLTWH(25, 26, 50, 32), const Radius.circular(16));
    canvas.drawRRect(
      visor,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF1A1E38), Color(0xFF0A0C18)],
        ).createShader(visor.outerRect),
    );
    canvas.drawRRect(visor, Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = _violet.withOpacity(0.5));

    // pipi merona
    for (final bx in [33.0, 67.0]) {
      canvas.drawOval(Rect.fromCenter(center: Offset(bx, 51), width: 7, height: 3.6), Paint()..color = const Color(0xFFFF7FB0).withOpacity(0.38));
    }

    // mata
    final lookX = manualLook ? look * 3.2 : math.sin(phase * 0.5) * 2.2;
    final happy = waving && cover < 0.5;
    final blinkK = _blink(t);
    for (final ex in [39.5, 60.5]) {
      final cx = ex + lookX;
      if (happy) {
        // mata senyum ^ ^
        canvas.drawArc(
          Rect.fromCenter(center: Offset(cx, 43), width: 9, height: 9),
          math.pi,
          math.pi,
          false,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2.8
            ..strokeCap = StrokeCap.round
            ..color = _cyan,
        );
      } else {
        final h = 11.0 * (1 - blinkK) + 1.6;
        final r = Rect.fromCenter(center: Offset(cx, 42.5), width: 8.6, height: h);
        canvas.drawRRect(RRect.fromRectAndRadius(r.inflate(2), const Radius.circular(6)), Paint()..color = _cyan.withOpacity(0.28));
        canvas.drawRRect(
          RRect.fromRectAndRadius(r, const Radius.circular(4.6)),
          Paint()
            ..shader = const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF9BE3FF), Color(0xFF4FB4F5)],
            ).createShader(r),
        );
        if (blinkK < 0.5) {
          canvas.drawCircle(Offset(cx - 1.6, 39.5), 1.5, Paint()..color = Colors.white.withOpacity(0.95));
        }
      }
    }

    // mulut
    final mouthY = 52.5;
    if (waving && cover < 0.5) {
      final m = Path()
        ..moveTo(45, mouthY - 1)
        ..quadraticBezierTo(50, mouthY + 7, 55, mouthY - 1)
        ..close();
      canvas.drawPath(m, Paint()..color = _cyan);
    } else {
      final m = Path()
        ..moveTo(46, mouthY)
        ..quadraticBezierTo(50, mouthY + 3.2, 54, mouthY);
      canvas.drawPath(m, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.8..strokeCap = StrokeCap.round..color = _cyan);
    }

    // lengan + tangan (digambar di atas kepala agar bisa menutup mata)
    const shL = Offset(35, 70);
    const shR = Offset(65, 70);
    final leftRest = const Offset(21, 82);
    final rightRest = waving ? Offset(86 + math.sin(phase * 16) * 5, 37 + math.cos(phase * 16) * 1.5) : const Offset(79, 82);
    final leftHand = _lerp(leftRest, const Offset(41, 46), cover);
    final rightHand = _lerp(rightRest, const Offset(59, 46), cover);
    _arm(canvas, shL, leftHand);
    _arm(canvas, shR, rightHand);

    canvas.restore();
  }

  void _arm(Canvas canvas, Offset shoulder, Offset hand) {
    canvas.drawLine(shoulder, hand, Paint()..color = _lav..strokeWidth = 6.4..strokeCap = StrokeCap.round);
    canvas.drawCircle(hand, 5.2, Paint()..color = const Color(0xFFF4F2FF));
    canvas.drawCircle(hand, 5.2, Paint()..style = PaintingStyle.stroke..strokeWidth = 0.9..color = _lav);
  }

  double _blink(double t) {
    double b(double c) {
      final d = (t - c).abs();
      return d < 0.025 ? 1 - d / 0.025 : 0;
    }

    return math.max(b(0.30), b(0.78));
  }

  @override
  bool shouldRepaint(covariant _RobotPainter old) =>
      old.t != t || old.waving != waving || old.glow != glow || old.cover != cover || old.look != look;
}
