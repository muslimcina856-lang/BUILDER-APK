import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_theme.dart';

enum OrbState { idle, listening, thinking, generating, error }

/// Premium liquid-glass AI Orb - central visual identity of mafia.ai
class AIOrb extends StatefulWidget {
  const AIOrb({
    super.key,
    this.size = 140,
    this.state = OrbState.idle,
    this.onTap,
  });

  final double size;
  final OrbState state;
  final VoidCallback? onTap;

  @override
  State<AIOrb> createState() => _AIOrbState();
}

class _AIOrbState extends State<AIOrb> with TickerProviderStateMixin {
  late final AnimationController _idleController;
  late final AnimationController _thinkingController;
  late final AnimationController _generatingController;
  late final AnimationController _glowController;

  @override
  void initState() {
    super.initState();
    _idleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat(reverse: true);

    _thinkingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );

    _generatingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);

    _syncState(widget.state);
  }

  @override
  void didUpdateWidget(AIOrb oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.state != widget.state) {
      _syncState(widget.state);
    }
  }

  void _syncState(OrbState state) {
    switch (state) {
      case OrbState.idle:
        _thinkingController.stop();
        _generatingController.stop();
        if (!_idleController.isAnimating) _idleController.repeat(reverse: true);
        break;
      case OrbState.listening:
        _thinkingController.stop();
        _generatingController.stop();
        if (!_idleController.isAnimating) _idleController.repeat(reverse: true);
        break;
      case OrbState.thinking:
        _idleController.stop();
        _generatingController.stop();
        _thinkingController.repeat();
        break;
      case OrbState.generating:
        _idleController.stop();
        _thinkingController.stop();
        _generatingController.repeat();
        break;
      case OrbState.error:
        _thinkingController.stop();
        _generatingController.stop();
        _idleController.stop();
        break;
    }
  }

  @override
  void dispose() {
    _idleController.dispose();
    _thinkingController.dispose();
    _generatingController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;
    return GestureDetector(
      onTap: widget.onTap,
      child: SizedBox(
        width: size * 1.4,
        height: size * 1.4,
        child: AnimatedBuilder(
          animation: Listenable.merge([
            _idleController,
            _thinkingController,
            _generatingController,
            _glowController,
          ]),
          builder: (context, _) {
            return CustomPaint(
              size: Size(size * 1.4, size * 1.4),
              painter: _OrbPainter(
                size: size,
                state: widget.state,
                idleValue: _idleController.value,
                thinkingValue: _thinkingController.value,
                generatingValue: _generatingController.value,
                glowValue: _glowController.value,
                isDark: context.isDark,
              ),
            );
          },
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  _OrbPainter({
    required this.size,
    required this.state,
    required this.idleValue,
    required this.thinkingValue,
    required this.generatingValue,
    required this.glowValue,
    required this.isDark,
  });

  final double size;
  final OrbState state;
  final double idleValue;
  final double thinkingValue;
  final double generatingValue;
  final double glowValue;
  final bool isDark;

  @override
  void paint(Canvas canvas, Size canvasSize) {
    final center = Offset(canvasSize.width / 2, canvasSize.height / 2);
    final radius = size / 2;

    // Outer soft glow
    final glowRadius = radius * (1.15 + glowValue * 0.08);
    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: state == OrbState.error
            ? [
                AppColors.darkError.withOpacity(0.25),
                AppColors.darkError.withOpacity(0.0),
              ]
            : [
                AppColors.orbGradient[0].withOpacity(0.35 + glowValue * 0.1),
                AppColors.orbGradient[2].withOpacity(0.12),
                Colors.transparent,
              ],
      ).createShader(Rect.fromCircle(center: center, radius: glowRadius * 1.6));
    canvas.drawCircle(center, glowRadius * 1.5, glowPaint);

    // Breathing scale for idle / listening
    final breath = state == OrbState.idle || state == OrbState.listening
        ? 1.0 + (idleValue - 0.5) * 0.04
        : 1.0;
    final effectiveRadius = radius * breath;

    // Main orb body - liquid glass gradient
    final bodyRect = Rect.fromCircle(center: center, radius: effectiveRadius);
    final bodyPaint = Paint()
      ..shader = SweepGradient(
        center: Alignment.center,
        startAngle: state == OrbState.thinking
            ? thinkingValue * math.pi * 2
            : state == OrbState.generating
                ? generatingValue * math.pi * 2
                : idleValue * math.pi * 0.3,
        colors: state == OrbState.error
            ? [
                const Color(0xFF4A4A55),
                const Color(0xFF3A3A45),
                const Color(0xFF5A5A68),
                const Color(0xFF4A4A55),
              ]
            : [
                AppColors.orbGradient[0],
                AppColors.orbGradient[1],
                AppColors.orbGradient[2],
                AppColors.orbGradient[0].withOpacity(0.9),
                AppColors.orbGradient[0],
              ],
      ).createShader(bodyRect);

    // Glass highlight layer
    canvas.drawCircle(center, effectiveRadius, bodyPaint);

    // Inner glass highlight (top-left reflection)
    final highlightPaint = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.45, -0.55),
        radius: 0.7,
        colors: [
          Colors.white.withOpacity(0.45),
          Colors.white.withOpacity(0.12),
          Colors.transparent,
        ],
      ).createShader(bodyRect);
    canvas.drawCircle(center, effectiveRadius * 0.92, highlightPaint);

    // Subtle inner ring
    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.white.withOpacity(0.18);
    canvas.drawCircle(center, effectiveRadius * 0.88, ringPaint);

    // Thinking / generating wave rings
    if (state == OrbState.thinking || state == OrbState.generating) {
      final waveProgress =
          state == OrbState.thinking ? thinkingValue : generatingValue;
      for (int i = 0; i < 3; i++) {
        final t = (waveProgress + i * 0.25) % 1.0;
        final waveRadius = effectiveRadius * (1.05 + t * 0.35);
        final waveOpacity = (1.0 - t) * 0.35;
        final wavePaint = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = AppColors.orbGradient[i % 3].withOpacity(waveOpacity);
        canvas.drawCircle(center, waveRadius, wavePaint);
      }
    }

    // Core glow center
    final corePaint = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.white.withOpacity(0.55),
          Colors.white.withOpacity(0.0),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: effectiveRadius * 0.35));
    canvas.drawCircle(center, effectiveRadius * 0.3, corePaint);
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) {
    return old.idleValue != idleValue ||
        old.thinkingValue != thinkingValue ||
        old.generatingValue != generatingValue ||
        old.glowValue != glowValue ||
        old.state != state;
  }
}
