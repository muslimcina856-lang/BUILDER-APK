import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_colors.dart';

class AppTheme {
  AppTheme._();

  static ThemeData dark() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.darkBackground,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.darkPrimaryAccent,
        secondary: AppColors.darkSecondaryAccent,
        surface: AppColors.darkGlassSurface,
        error: AppColors.darkError,
        onPrimary: AppColors.darkPrimaryText,
        onSecondary: AppColors.darkPrimaryText,
        onSurface: AppColors.darkPrimaryText,
        onError: AppColors.darkPrimaryText,
      ),
      textTheme: _textTheme(
        primary: AppColors.darkPrimaryText,
        secondary: AppColors.darkSecondaryText,
        tertiary: AppColors.darkTertiaryText,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        iconTheme: IconThemeData(color: AppColors.darkPrimaryText),
        titleTextStyle: TextStyle(
          color: AppColors.darkPrimaryText,
          fontSize: 17,
          fontWeight: FontWeight.w600,
          letterSpacing: -0.2,
        ),
      ),
      dividerColor: AppColors.darkBorder,
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.darkPrimaryText;
          }
          return AppColors.darkSecondaryText;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.darkPrimaryAccent;
          }
          return AppColors.darkGlassSurfaceElevated;
        }),
        trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.darkGlassSurface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.darkBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.darkBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.darkPrimaryAccent, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        hintStyle: const TextStyle(color: AppColors.darkTertiaryText, fontSize: 15),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.darkGlassSurfaceElevated,
        contentTextStyle: const TextStyle(color: AppColors.darkPrimaryText),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: AppColors.lightBackground,
      colorScheme: const ColorScheme.light(
        primary: AppColors.lightPrimaryAccent,
        secondary: AppColors.lightSecondaryAccent,
        surface: AppColors.lightGlassSurface,
        error: AppColors.lightError,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: AppColors.lightPrimaryText,
        onError: Colors.white,
      ),
      textTheme: _textTheme(
        primary: AppColors.lightPrimaryText,
        secondary: AppColors.lightSecondaryText,
        tertiary: AppColors.lightTertiaryText,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        iconTheme: IconThemeData(color: AppColors.lightPrimaryText),
        titleTextStyle: TextStyle(
          color: AppColors.lightPrimaryText,
          fontSize: 17,
          fontWeight: FontWeight.w600,
          letterSpacing: -0.2,
        ),
      ),
      dividerColor: AppColors.lightBorder,
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return Colors.white;
          }
          return AppColors.lightSecondaryText;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return AppColors.lightPrimaryAccent;
          }
          return AppColors.lightSecondaryBackground;
        }),
        trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.lightGlassSurface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.lightBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.lightBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.lightPrimaryAccent, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        hintStyle: const TextStyle(color: AppColors.lightTertiaryText, fontSize: 15),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.lightGlassSurfaceElevated,
        contentTextStyle: const TextStyle(color: AppColors.lightPrimaryText),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  static TextTheme _textTheme({
    required Color primary,
    required Color secondary,
    required Color tertiary,
  }) {
    return TextTheme(
      displayLarge: TextStyle(
        fontSize: 34,
        fontWeight: FontWeight.w700,
        color: primary,
        letterSpacing: -0.8,
        height: 1.15,
      ),
      displayMedium: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w700,
        color: primary,
        letterSpacing: -0.6,
        height: 1.2,
      ),
      headlineLarge: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w600,
        color: primary,
        letterSpacing: -0.4,
        height: 1.25,
      ),
      headlineMedium: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w600,
        color: primary,
        letterSpacing: -0.3,
        height: 1.3,
      ),
      titleLarge: TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w600,
        color: primary,
        letterSpacing: -0.2,
        height: 1.35,
      ),
      titleMedium: TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w600,
        color: primary,
        letterSpacing: -0.1,
        height: 1.4,
      ),
      bodyLarge: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: primary,
        letterSpacing: -0.1,
        height: 1.5,
      ),
      bodyMedium: TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w400,
        color: primary,
        height: 1.5,
      ),
      bodySmall: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w400,
        color: secondary,
        height: 1.45,
      ),
      labelLarge: TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w500,
        color: primary,
        letterSpacing: -0.1,
      ),
      labelMedium: TextStyle(
        fontSize: 13,
        fontWeight: FontWeight.w500,
        color: secondary,
      ),
      labelSmall: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: tertiary,
        letterSpacing: 0.2,
      ),
    );
  }
}

/// Extension for easy access to theme-aware colors
extension AppThemeExtension on BuildContext {
  bool get isDark => Theme.of(this).brightness == Brightness.dark;

  Color get background => isDark ? AppColors.darkBackground : AppColors.lightBackground;
  Color get secondaryBackground =>
      isDark ? AppColors.darkSecondaryBackground : AppColors.lightSecondaryBackground;
  Color get glassSurface => isDark ? AppColors.darkGlassSurface : AppColors.lightGlassSurface;
  Color get glassElevated =>
      isDark ? AppColors.darkGlassSurfaceElevated : AppColors.lightGlassSurfaceElevated;
  Color get primaryAccent => isDark ? AppColors.darkPrimaryAccent : AppColors.lightPrimaryAccent;
  Color get secondaryAccent =>
      isDark ? AppColors.darkSecondaryAccent : AppColors.lightSecondaryAccent;
  Color get primaryText => isDark ? AppColors.darkPrimaryText : AppColors.lightPrimaryText;
  Color get secondaryText => isDark ? AppColors.darkSecondaryText : AppColors.lightSecondaryText;
  Color get tertiaryText => isDark ? AppColors.darkTertiaryText : AppColors.lightTertiaryText;
  Color get border => isDark ? AppColors.darkBorder : AppColors.lightBorder;
  Color get borderSubtle => isDark ? AppColors.darkBorderSubtle : AppColors.lightBorderSubtle;
  Color get shadow => isDark ? AppColors.darkShadow : AppColors.lightShadow;
  Color get error => isDark ? AppColors.darkError : AppColors.lightError;
  Color get success => isDark ? AppColors.darkSuccess : AppColors.lightSuccess;
}
