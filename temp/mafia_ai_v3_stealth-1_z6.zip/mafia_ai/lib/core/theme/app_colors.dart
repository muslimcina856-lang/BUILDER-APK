import 'package:flutter/material.dart';

/// Premium Liquid Glass color system for mafia.ai
class AppColors {
  AppColors._();

  // --- Dark Mode (Default) -----------------------------------------------
  static const Color darkBackground = Color(0xFF08090D);
  static const Color darkSecondaryBackground = Color(0xFF101219);
  static const Color darkGlassSurface = Color(0xFF171A24);
  static const Color darkGlassSurfaceElevated = Color(0xFF1E2230);
  static const Color darkPrimaryAccent = Color(0xFF8B7CFF);
  static const Color darkSecondaryAccent = Color(0xFF63C7FF);
  static const Color darkPrimaryText = Color(0xFFF5F6FC);
  static const Color darkSecondaryText = Color(0xFF9298AA);
  static const Color darkTertiaryText = Color(0xFF6B7280);
  static const Color darkBorder = Color(0x1AFFFFFF); // white @ 10%
  static const Color darkBorderSubtle = Color(0x0DFFFFFF); // white @ 5%
  static const Color darkShadow = Color(0x40000000);
  static const Color darkError = Color(0xFFFF6B6B);
  static const Color darkSuccess = Color(0xFF4ADE80);
  static const Color darkWarning = Color(0xFFFBBF24);

  // --- Light Mode --------------------------------------------------------
  static const Color lightBackground = Color(0xFFF7F8FC);
  static const Color lightSecondaryBackground = Color(0xFFEEF0F6);
  static const Color lightGlassSurface = Color(0xE6FFFFFF); // white @ 90%
  static const Color lightGlassSurfaceElevated = Color(0xF2FFFFFF);
  static const Color lightPrimaryAccent = Color(0xFF6B5CE7);
  static const Color lightSecondaryAccent = Color(0xFF3BA8E0);
  static const Color lightPrimaryText = Color(0xFF1A1C25);
  static const Color lightSecondaryText = Color(0xFF5C6370);
  static const Color lightTertiaryText = Color(0xFF8B919E);
  static const Color lightBorder = Color(0x1A000000); // black @ 10%
  static const Color lightBorderSubtle = Color(0x0A000000);
  static const Color lightShadow = Color(0x14000000);
  static const Color lightError = Color(0xFFE5484D);
  static const Color lightSuccess = Color(0xFF30A46C);
  static const Color lightWarning = Color(0xFFF5A623);

  // --- Shared / Orb Gradients --------------------------------------------
  static const List<Color> orbGradient = [
    Color(0xFF8B7CFF),
    Color(0xFF6B5CE7),
    Color(0xFF63C7FF),
  ];

  static const List<Color> orbGlowGradient = [
    Color(0x668B7CFF),
    Color(0x3363C7FF),
    Color(0x00FFFFFF),
  ];

  static const List<Color> robotAccentGradient = [
    Color(0xFF8B7CFF),
    Color(0xFF63C7FF),
  ];
}
