import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../config/api_keys.dart';
import 'native_bridge.dart';

class AIService {
  static const providers = ['Google Gemini', 'Groq'];

  static String defaultModel(String provider) => switch (provider) {
        'Groq' => 'llama-3.3-70b-versatile',
        _ => 'gemini-flash-latest',
      };

  static String defaultVisionModel(String provider) => switch (provider) {
        'Groq' => 'meta-llama/llama-4-scout-17b-16e-instruct',
        _ => 'gemini-flash-latest',
      };

  /// Model Gemini lama (1.5 / 2.0) sudah dihapus Google (404) -> pakai alias terbaru.
  static String migrateModel(String m) =>
      RegExp(r'^gemini-(1\.5|2\.0)').hasMatch(m) ? 'gemini-flash-latest' : m;

  static List<String> suggestedModels(String provider) => switch (provider) {
        'Groq' => const [
            'llama-3.3-70b-versatile',
            'llama-3.1-8b-instant',
            'openai/gpt-oss-120b',
            'qwen/qwen3-32b',
            'meta-llama/llama-4-scout-17b-16e-instruct',
          ],
        _ => const [
            'gemini-flash-latest',
            'gemini-3.5-flash-lite',
            'gemini-pro-latest',
          ],
      };

  static Future<({String provider, String model, String key})> _config() async {
    final p = await SharedPreferences.getInstance();
    final provider = p.getString('ai_provider') ?? 'Google Gemini';
    final model =
        migrateModel(p.getString('ai_model') ?? defaultModel(provider));
    String key;
    if (provider == 'Groq') {
      final stored = p.getString('api_key_Groq') ?? '';
      key = stored.trim().isNotEmpty ? stored.trim() : ApiKeys.groq.trim();
    } else {
      final stored = p.getString('api_key_Google Gemini') ??
          p.getString('api_key_Gemini') ??
          '';
      key = stored.trim().isNotEmpty ? stored.trim() : ApiKeys.gemini.trim();
    }
    return (provider: provider, model: model, key: key);
  }

  static Future<String> complete(String prompt) async {
    final cfg = await _config();
    if (cfg.key.isEmpty) {
      throw Exception(
        'API key ${cfg.provider} belum diatur. Buka Settings -> API Keys.',
      );
    }
    if (cfg.provider == 'Groq') {
      return _groq(cfg.key, cfg.model, prompt);
    }
    return _gemini(cfg.key, cfg.model, prompt);
  }

  static Future<String> _gemini(String key, String model, String prompt) async {
    final uri = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent',
    );
    final body = {
      'contents': [
        {
          'parts': [
            {'text': prompt},
          ],
        },
      ],
    };
    final r = await http
        .post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': key,
          },
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 60));
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Gemini API (${r.statusCode}): ${r.body}');
    }
    final d = jsonDecode(r.body);
    final parts = d['candidates']?[0]?['content']?['parts'];
    if (parts is List) {
      return parts.map((x) => x['text'] ?? '').join('');
    }
    return 'AI tidak mengembalikan teks.';
  }

  static Future<String> _groq(String key, String model, String prompt) async {
    final r = await http
        .post(
          Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $key',
          },
          body: jsonEncode({
            'model': model,
            'messages': [
              {'role': 'user', 'content': prompt},
            ],
          }),
        )
        .timeout(const Duration(seconds: 60));
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Groq API (${r.statusCode}): ${r.body}');
    }
    final d = jsonDecode(r.body);
    return d['choices']?[0]?['message']?['content']?.toString() ??
        'AI tidak mengembalikan teks.';
  }

  static Stream<String> streamComplete(String prompt) async* {
    final cfg = await _config();
    if (cfg.key.isEmpty) {
      throw Exception(
        'API key ${cfg.provider} belum diatur. Buka Settings -> API Keys.',
      );
    }

    if (cfg.provider != 'Groq') {
      final full = await complete(prompt);
      const step = 12;
      for (var i = 0; i < full.length; i += step) {
        yield full.substring(i, (i + step).clamp(0, full.length));
        await Future.delayed(const Duration(milliseconds: 18));
      }
      return;
    }

    final request = http.Request(
      'POST',
      Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
    );
    request.headers.addAll({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${cfg.key}',
      'Accept': 'text/event-stream',
    });
    request.body = jsonEncode({
      'model': cfg.model,
      'stream': true,
      'messages': [
        {'role': 'user', 'content': prompt},
      ],
    });

    final client = http.Client();
    try {
      final streamed =
          await client.send(request).timeout(const Duration(seconds: 60));
      if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
        final body = await streamed.stream.bytesToString();
        throw Exception('Groq API (${streamed.statusCode}): $body');
      }
      var buffer = '';
      await for (final chunk in streamed.stream.transform(utf8.decoder)) {
        buffer += chunk;
        final lines = buffer.split('\n');
        buffer = lines.isNotEmpty ? lines.removeLast() : '';
        for (final line in lines) {
          final trimmed = line.trim();
          if (trimmed.isEmpty || !trimmed.startsWith('data:')) continue;
          final payload = trimmed.substring(5).trim();
          if (payload == '[DONE]') return;
          try {
            final json = jsonDecode(payload) as Map<String, dynamic>;
            final delta =
                json['choices']?[0]?['delta']?['content']?.toString() ?? '';
            if (delta.isNotEmpty) yield delta;
          } catch (_) {}
        }
      }
    } finally {
      client.close();
    }
  }

  static Future<String> answerQuestion(String questionText) {
    final prompt = '''
Kamu adalah asisten yang menjawab soal ujian / kuis dengan akurat dan ringkas.
Jawab dalam bahasa yang sama dengan soal.

Format jawaban:
1) Jawaban akhir (huruf pilihan / angka / teks singkat)
2) Penjelasan singkat (2-5 kalimat)

Soal:
$questionText
''';
    return complete(prompt);
  }

  /// Sync effective keys/models to native overlay service.
  static Future<void> syncNative() async {
    final p = await SharedPreferences.getInstance();
    final provider = p.getString('ai_provider') ?? 'Google Gemini';
    final geminiKey = (p.getString('api_key_Google Gemini') ??
            p.getString('api_key_Gemini') ??
            ApiKeys.gemini)
        .trim();
    final groqKey =
        (p.getString('api_key_Groq') ?? ApiKeys.groq).trim();
    final model =
        migrateModel(p.getString('ai_model') ?? defaultModel(provider));
    final vision = migrateModel(p.getString('ai_vision_model') ??
        defaultVisionModel(provider));
    await NativeBridge.syncSettings({
      'provider': provider == 'Groq' ? 'groq' : 'gemini',
      'geminiKey': geminiKey.isNotEmpty ? geminiKey : ApiKeys.gemini,
      'groqKey': groqKey.isNotEmpty ? groqKey : ApiKeys.groq,
      'geminiVision': provider == 'Groq' ? vision : model,
      'groqVision': provider == 'Groq' ? vision : model,
      'tripleTap': p.getBool('triple_tap') ?? true,
      'autoAnswer': p.getBool('auto_answer') ?? false,
      'themeMode': 'dark',
    });
  }
}
