import 'package:flutter/services.dart';

/// Flutter <-> Kotlin MethodChannel for system overlay + screen capture.
class NativeBridge {
  NativeBridge._();
  static const _ch = MethodChannel('mafia_ai/native');

  static void Function(bool running)? onAssistantState;

  static void init() {
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'assistantState') {
        onAssistantState?.call(call.arguments == true);
      }
      return null;
    });
  }

  static Future<T?> _call<T>(String m, [dynamic args]) async {
    try {
      return await _ch.invokeMethod<T>(m, args);
    } on MissingPluginException {
      return null;
    } on PlatformException {
      return null;
    }
  }

  static Future<bool> hasOverlayPermission() async =>
      (await _call<bool>('hasOverlayPermission')) ?? false;

  static Future<void> requestOverlayPermission() =>
      _call('requestOverlayPermission');

  static Future<bool> isAccessibilityEnabled() async =>
      (await _call<bool>('isAccessibilityEnabled')) ?? false;

  static Future<void> openAccessibilitySettings() =>
      _call('openAccessibilitySettings');

  static Future<void> openAppDetails() => _call('openAppDetails');

  static Future<bool> isAssistantRunning() async =>
      (await _call<bool>('isAssistantRunning')) ?? false;

  /// "started" | "already_running" | "overlay_permission" | "denied" | "busy" | "error"
  static Future<String> startAssistant() async =>
      (await _call<String>('startAssistant')) ?? 'error';

  static Future<void> stopAssistant() => _call('stopAssistant');

  static Future<void> syncSettings(Map<String, dynamic> m) =>
      _call('syncSettings', m);

  static Future<List<Map<String, dynamic>>> takePendingChats() async {
    final r = await _call<List<dynamic>>('takePendingChats');
    if (r == null) return [];
    return r.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }
}
