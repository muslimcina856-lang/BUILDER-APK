# mafia.ai - Premium Liquid Glass UI

Premium AI assistant redesign inspired by iOS Liquid Glass, Apple minimalism, and high-end AI interfaces (2026).

## Fitur yang sudah diperbaiki / diaktifkan

| # | Fitur | Status |
|---|--------|--------|
| 1 | Screen Assistant | Clipboard-based: salin teks dari layar -> robot "Auto Screen". Full MediaProjection butuh native Android service (belum). |
| 2 | Scan Soal | Lewat clipboard / input manual -> OCR native belum; teks soal dikirim ke AI. |
| 3 | Auto Answer | **Nyata** - memanggil `AIService.answerQuestion` dengan API key yang disimpan. |
| 4 | Mengisi jawaban otomatis | Belum (butuh AccessibilityService native). Panel menampilkan jawaban untuk disalin. |
| 5 | Respons streaming AI | **Aktif** - SSE stream untuk OpenAI/Groq/OpenRouter/DeepSeek/Mistral; fallback progressive untuk Anthropic/Gemini. |
| 6 | Riwayat chat | **Nyata** - SharedPreferences, persist setelah restart, clear history berfungsi. |
| 7 | Multi-provider AI | OpenAI, Anthropic, Gemini, Groq, OpenRouter, DeepSeek, Mistral - key + model per provider. |
| 8 | Pengaturan aplikasi | Load & save provider/model/API key/toggles ke SharedPreferences. |
| 9 | Floating panel | Draggable Liquid Glass panel + loading/error/answer states. |
| 10 | Build | Jalankan `flutter pub get && flutter run` di perangkat Android. |

## Cara pakai Auto Answer

1. Buka **Settings** -> pilih provider -> isi API key -> **Save AI settings**.
2. Salin teks soal ke clipboard (dari browser / app lain).
3. Ketuk robot mengambang -> **Auto Answer** (atau Auto Screen).
4. Panel menampilkan jawaban dari AI.

## Run

```bash
cd mafia_ai
flutter pub get
flutter run
```

## Catatan teknis

- `lib/core/services/ai_service.dart` - complete + streamComplete + answerQuestion.
- Chat memakai `streamComplete` sehingga teks muncul bertahap.
- Overlay sistem sejati (di atas app lain) dan MediaProjection / OCR / auto-fill form memerlukan kode native Kotlin + permission runtime; Flutter widget overlay hanya aktif di dalam proses app.

## Auto Answer Play / Stop (native, di atas aplikasi lain)

1. Settings: isi API key, aktifkan **Display over other apps**, **Accessibility** (mafia.ai Screen Assistant), lalu **Enable Floating Assistant**.
2. Buka kuis / Google Form di aplikasi lain, tap bola mafia.ai > **Auto Answer**.
3. Tekan **Play**: AI membaca layar (screenshot), menentukan jawaban A/B/C/D, mengetuk opsi lewat Accessibility, menggulir ke bawah, dan mengulang sampai soal habis (maks 80 langkah). Tiap layar AI mendeteksi status soal (terisi / kosong / tidak jelas) dan hanya mengetuk yang kosong. Tombol "Berikutnya" ditekan untuk form multi-halaman.
4. **Stop** (atau ketuk bola) menghentikan kapan saja. Tombol Kirim/Submit tidak pernah ditekan otomatis.

Soal uraian/isian diisi otomatis: AI menulis jawaban, mengetuk kolom, lalu mengetiknya (butuh Aksesibilitas aktif; izin "baca isi layar" dipakai hanya untuk kolom yang sedang fokus). Siklus dipercepat: screenshot 1280px, thinking AI dibatasi, jeda ketukan/scroll dipangkas.
Soal dikenali lewat kutipan teks (bukan nomor). Ketukan kini tembus overlay (NOT_TOUCHABLE saat overlay disembunyikan).
