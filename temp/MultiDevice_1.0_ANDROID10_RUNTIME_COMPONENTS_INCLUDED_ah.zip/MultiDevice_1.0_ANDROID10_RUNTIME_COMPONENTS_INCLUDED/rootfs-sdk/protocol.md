# Multi Device rootfs protocol v2

The Android host owns the bootstrap. A rootfs bundle uses `"bootstrap": "@host-native"`; arbitrary
bundle executables are rejected. `RootfsEngineService` launches an APK-owned `app_process` child,
which loads `BootstrapMain` and the packaged native runtime before replacing itself with guest
Android `/system/bin/init` through the host linker.

The child receives:

- `MD_ROOTFS` - installed rootfs directory
- `MD_DATA` - private profile data directory
- `MD_PROFILE_DIR` - profile working directory
- `MD_FRAMEBUFFER` - shared double framebuffer file
- `MD_GUEST_SOCKET` - authenticated guest/control socket
- `MD_BINDER_SOCKET` - separate userspace Android IPC broker socket
- `MD_BINDER_TOKEN` - broker authentication token
- `MD_SESSION_TOKEN` - per-start guest/control authentication token
- `MD_RUNTIME_LIB_DIR` - APK native library directory containing `libmdruntime.so`,
  `libmdguestshim.so`, `libmdframebridge.so`
- `MD_PHONE_WIDTH`, `MD_PHONE_HEIGHT`, `MD_PHONE_DPI`, `MD_PHONE_REFRESH` - fixed phone contract
- `MD_PROTOCOL=2`

The device geometry is not configurable by profiles.

## Guest control socket

Connect to the abstract socket and send:

```text
AUTH <MD_SESSION_TOKEN>
```

The service replies `OK`. Guest -> host messages:

```text
BOOTSTRAP_READY
ANDROID_FRAMEWORK_READY
FRAME <sequence> <slot>
SUSPENDED
RESUMED
ERROR <message>
```

The host does not mark the session RUNNING until Android framework readiness and at least one real
frame have both been observed.

Host -> guest messages include:

```text
TOUCH DOWN|MOVE|UP <x> <y>
KEY DOWN|UP <android-keycode>
TEXT <escaped-utf8>
SUSPEND
RESUME
SHUTDOWN
```

## Isolated Binder transport

The guest must not use the host phone's `/dev/binder` context. `libmdruntime.so` starts a separate,
token-authenticated userspace broker on `MD_BINDER_SOCKET`. The Android 10 guest build must adapt
libbinder to that transport. `libmdguestshim.so` deliberately returns `ENOTSUP` for unadapted
`BINDER_WRITE_READ` calls instead of pretending transactions succeeded or leaking into the host
service manager.

## Shared framebuffer

`MD_FRAMEBUFFER` uses a 64-byte little-endian header followed by two fixed phone-size pixel slots.
Pixels use Android native ARGB_8888 memory layout.

Header offsets:

```text
0   u32 magic      0x4D444652 (MDFR)
4   u32 version    2
8   u32 width
12  u32 height
16  u32 stride
20  u32 format     1 = Android ARGB_8888
24  u32 activeSlot 0 or 1
28  u32 reserved
32  u64 sequence
40  u32 flags
64  slot 0 pixels
64 + frameBytes  slot 1 pixels
```

The patched Android 10 display/HWC path should call `md_present_argb8888()` from
`libmdframebridge.so`. The library writes the inactive slot, publishes slot/sequence in the header,
then sends `FRAME <sequence> <slot>` on the guest socket.
