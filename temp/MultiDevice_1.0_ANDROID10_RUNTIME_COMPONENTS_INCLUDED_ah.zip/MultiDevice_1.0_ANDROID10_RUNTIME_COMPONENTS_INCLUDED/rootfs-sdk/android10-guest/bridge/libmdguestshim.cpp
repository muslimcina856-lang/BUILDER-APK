#include "md_guest_socket.h"

#include <cstdarg>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <fcntl.h>
#include <linux/android/binder.h>
#include <map>
#include <mutex>
#include <set>
#include <string>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

namespace {

std::mutex gBinderLock;
std::set<int> gBinderFds;

const char* rootfs() { return std::getenv("MD_ROOTFS"); }
const char* dataDir() { return std::getenv("MD_DATA"); }

bool componentPrefix(const std::string& path, const char* prefix) {
    const size_t n = std::strlen(prefix);
    return path == prefix || (path.size() > n && path.compare(0, n, prefix) == 0 && path[n] == '/');
}

std::string normalize(const char* input) {
    if (!input || input[0] != '/') return input ? std::string(input) : std::string();
    std::string path(input);
    if (path.find("/../") != std::string::npos || (path.size() >= 3 && path.compare(path.size() - 3, 3, "/..") == 0)) {
        errno = EACCES;
        return {};
    }
    return path;
}

std::string mapPath(const char* input) {
    const std::string path = normalize(input);
    if (path.empty() || path[0] != '/') return path;
    const char* root = rootfs();
    const char* data = dataDir();
    if (!root || !data) return path;
    if (componentPrefix(path, "/data")) return std::string(data) + path.substr(5);
    if (componentPrefix(path, "/proc") || componentPrefix(path, "/sys")) return path;
    if (componentPrefix(path, "/dev") && path != "/dev/binder" && path != "/dev/hwbinder" && path != "/dev/vndbinder") return path;
    return std::string(root) + path;
}

template <typename T>
T next(const char* symbol) {
    return reinterpret_cast<T>(::dlsym(RTLD_NEXT, symbol));
}

bool isBinderPath(const char* path) {
    return path && (!std::strcmp(path, "/dev/binder") || !std::strcmp(path, "/dev/hwbinder") || !std::strcmp(path, "/dev/vndbinder"));
}

int openBinder() {
    const char* socketName = std::getenv("MD_BINDER_SOCKET");
    const char* token = std::getenv("MD_BINDER_TOKEN");
    if (!socketName || !token) { errno = ENODEV; return -1; }
    std::string error;
    const int fd = mdguest::connectAbstract(socketName, &error);
    if (fd < 0 || !mdguest::authenticate(fd, token, &error)) {
        if (fd >= 0) ::close(fd);
        errno = ECONNREFUSED;
        return -1;
    }
    std::lock_guard<std::mutex> guard(gBinderLock);
    gBinderFds.insert(fd);
    return fd;
}

bool isBinderFd(int fd) {
    std::lock_guard<std::mutex> guard(gBinderLock);
    return gBinderFds.find(fd) != gBinderFds.end();
}

void removeBinderFd(int fd) {
    std::lock_guard<std::mutex> guard(gBinderLock);
    gBinderFds.erase(fd);
}

}  // namespace

extern "C" int open(const char* pathname, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) { va_list args; va_start(args, flags); mode = static_cast<mode_t>(va_arg(args, int)); va_end(args); }
    if (isBinderPath(pathname)) return openBinder();
    auto real = next<int (*)(const char*, int, ...)>("open");
    const std::string mapped = mapPath(pathname);
    if (mapped.empty()) return -1;
    return (flags & O_CREAT) ? real(mapped.c_str(), flags, mode) : real(mapped.c_str(), flags);
}

extern "C" int open64(const char* pathname, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) { va_list args; va_start(args, flags); mode = static_cast<mode_t>(va_arg(args, int)); va_end(args); }
    if (isBinderPath(pathname)) return openBinder();
    auto real = next<int (*)(const char*, int, ...)>("open64");
    if (!real) real = next<int (*)(const char*, int, ...)>("open");
    const std::string mapped = mapPath(pathname);
    if (mapped.empty()) return -1;
    return (flags & O_CREAT) ? real(mapped.c_str(), flags, mode) : real(mapped.c_str(), flags);
}

extern "C" int access(const char* pathname, int mode) {
    auto real = next<int (*)(const char*, int)>("access");
    const std::string mapped = mapPath(pathname);
    return mapped.empty() ? -1 : real(mapped.c_str(), mode);
}

extern "C" int stat(const char* pathname, struct stat* info) {
    auto real = next<int (*)(const char*, struct stat*)>("stat");
    const std::string mapped = mapPath(pathname);
    return mapped.empty() ? -1 : real(mapped.c_str(), info);
}

extern "C" int lstat(const char* pathname, struct stat* info) {
    auto real = next<int (*)(const char*, struct stat*)>("lstat");
    const std::string mapped = mapPath(pathname);
    return mapped.empty() ? -1 : real(mapped.c_str(), info);
}

extern "C" int mkdir(const char* pathname, mode_t mode) {
    auto real = next<int (*)(const char*, mode_t)>("mkdir");
    const std::string mapped = mapPath(pathname);
    return mapped.empty() ? -1 : real(mapped.c_str(), mode);
}

extern "C" int unlink(const char* pathname) {
    auto real = next<int (*)(const char*)>("unlink");
    const std::string mapped = mapPath(pathname);
    return mapped.empty() ? -1 : real(mapped.c_str());
}

extern "C" int rename(const char* oldPath, const char* newPath) {
    auto real = next<int (*)(const char*, const char*)>("rename");
    const std::string oldMapped = mapPath(oldPath);
    const std::string newMapped = mapPath(newPath);
    return oldMapped.empty() || newMapped.empty() ? -1 : real(oldMapped.c_str(), newMapped.c_str());
}

extern "C" int chroot(const char*) { return 0; }
extern "C" int mount(const char*, const char*, const char*, unsigned long, const void*) { return 0; }
extern "C" int umount2(const char*, int) { return 0; }
extern "C" int mknod(const char*, mode_t, dev_t) { return 0; }
extern "C" int setuid(uid_t) { return 0; }
extern "C" int setgid(gid_t) { return 0; }

extern "C" int close(int fd) {
    if (isBinderFd(fd)) removeBinderFd(fd);
    auto real = next<int (*)(int)>("close");
    return real(fd);
}

extern "C" void* mmap(void* address, size_t length, int prot, int flags, int fd, off_t offset) {
    auto real = next<void* (*)(void*, size_t, int, int, int, off_t)>("mmap");
    if (isBinderFd(fd)) {
        // Android Binder expects a driver-owned receive window. Reserve a private userspace window;
        // the socket Binder adapter fills it when translating broker transactions.
        return real(address, length, prot | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    }
    return real(address, length, prot, flags, fd, offset);
}

extern "C" int ioctl(int fd, unsigned long request, ...) {
    va_list args;
    va_start(args, request);
    void* arg = va_arg(args, void*);
    va_end(args);
    if (!isBinderFd(fd)) {
        auto real = next<int (*)(int, unsigned long, ...)>("ioctl");
        return real(fd, request, arg);
    }

    if (request == BINDER_VERSION) {
        auto* version = static_cast<binder_version*>(arg);
        if (!version) { errno = EINVAL; return -1; }
        version->protocol_version = BINDER_CURRENT_PROTOCOL_VERSION;
        return 0;
    }
    if (request == BINDER_SET_MAX_THREADS || request == BINDER_SET_CONTEXT_MGR ||
        request == BINDER_SET_IDLE_TIMEOUT || request == BINDER_SET_IDLE_PRIORITY) {
        return 0;
    }
    if (request == BINDER_WRITE_READ) {
        auto* transfer = static_cast<binder_write_read*>(arg);
        if (!transfer) { errno = EINVAL; return -1; }
        // This shim intentionally refuses to fake successful Binder transactions. The accompanying
        // Android 10 ROM patch routes libbinder transactions to MD_BINDER_SOCKET before they reach
        // this ioctl compatibility path. Reaching here means the ROM was not patched correctly.
        transfer->write_consumed = 0;
        transfer->read_consumed = 0;
        errno = ENOTSUP;
        return -1;
    }
    errno = ENOTSUP;
    return -1;
}
