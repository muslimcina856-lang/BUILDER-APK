#include "md_guest_socket.h"

#include <cerrno>
#include <csignal>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sys/wait.h>
#include <unistd.h>

namespace {

const char* envRequired(const char* name) {
    const char* value = std::getenv(name);
    return value != nullptr && *value != '\0' ? value : nullptr;
}

void sendError(int fd, const std::string& message) {
    if (fd >= 0) mdguest::sendLine(fd, "ERROR " + message);
}

}  // namespace

int main() {
    const char* rootfs = envRequired("MD_ROOTFS");
    const char* guestSocket = envRequired("MD_GUEST_SOCKET");
    const char* token = envRequired("MD_SESSION_TOKEN");
    if (!rootfs || !guestSocket || !token) return 64;

    std::string error;
    const int control = mdguest::connectAbstract(guestSocket, &error);
    if (control < 0 || !mdguest::authenticate(control, token, &error)) return 65;
    mdguest::sendLine(control, "BOOTSTRAP_READY");

    const std::string root(rootfs);
    const std::string guestInit = root + "/system/bin/init";
    const std::string shim = root + "/bridge/lib64/libmdguestshim.so";
    if (::access(guestInit.c_str(), R_OK) != 0) {
        sendError(control, "Android 10 rootfs is missing /system/bin/init");
        return 66;
    }
    if (::access(shim.c_str(), R_OK) != 0) {
        sendError(control, "Android 10 rootfs is missing libmdguestshim.so");
        return 67;
    }

    const std::string libraries =
        root + "/system/lib64:" + root + "/system/lib64/bootstrap:" + root + "/system_ext/lib64:" +
        root + "/product/lib64:" + root + "/vendor/lib64:" + root + "/bridge/lib64";
    ::setenv("LD_LIBRARY_PATH", libraries.c_str(), 1);
    ::setenv("LD_PRELOAD", shim.c_str(), 1);
    ::setenv("ANDROID_ROOT", (root + "/system").c_str(), 1);
    ::setenv("ANDROID_DATA", envRequired("MD_DATA") ? envRequired("MD_DATA") : (root + "/data").c_str(), 1);
    ::setenv("MD_CONTAINER_GUEST", "1", 1);

    const pid_t pid = ::fork();
    if (pid < 0) {
        sendError(control, std::string("fork failed: ") + std::strerror(errno));
        return 68;
    }
    if (pid == 0) {
        ::execl("/system/bin/linker64", "linker64", guestInit.c_str(), "second_stage", nullptr);
        _exit(127);
    }

    int status = 0;
    while (::waitpid(pid, &status, 0) < 0 && errno == EINTR) {}
    if (WIFEXITED(status)) {
        sendError(control, "Android init exited with code " + std::to_string(WEXITSTATUS(status)));
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        sendError(control, "Android init terminated by signal " + std::to_string(WTERMSIG(status)));
        return 128 + WTERMSIG(status);
    }
    return 69;
}
