#include "md_guest_socket.h"

#include <cerrno>
#include <cstring>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

namespace mdguest {

int connectAbstract(const std::string& socketName, std::string* error) {
    if (socketName.empty() || socketName.size() > sizeof(sockaddr_un::sun_path) - 2) {
        if (error) *error = "invalid abstract socket name";
        return -1;
    }
    const int fd = ::socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) {
        if (error) *error = std::string("socket failed: ") + std::strerror(errno);
        return -1;
    }
    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    address.sun_path[0] = '\0';
    std::memcpy(address.sun_path + 1, socketName.data(), socketName.size());
    const socklen_t length = static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + 1 + socketName.size());
    if (::connect(fd, reinterpret_cast<sockaddr*>(&address), length) != 0) {
        if (error) *error = std::string("connect failed: ") + std::strerror(errno);
        ::close(fd);
        return -1;
    }
    return fd;
}

bool sendLine(int fd, const std::string& line) {
    const std::string data = line + "\n";
    size_t offset = 0;
    while (offset < data.size()) {
        const ssize_t n = ::send(fd, data.data() + offset, data.size() - offset, MSG_NOSIGNAL);
        if (n <= 0) return false;
        offset += static_cast<size_t>(n);
    }
    return true;
}

bool readLine(int fd, std::string* line, size_t limit) {
    if (line == nullptr) return false;
    line->clear();
    char c = 0;
    while (line->size() < limit) {
        const ssize_t n = ::recv(fd, &c, 1, 0);
        if (n <= 0) return false;
        if (c == '\n') return true;
        if (c != '\r') line->push_back(c);
    }
    return false;
}

bool authenticate(int fd, const std::string& token, std::string* error) {
    if (!sendLine(fd, "AUTH " + token)) {
        if (error) *error = "unable to send authentication token";
        return false;
    }
    std::string reply;
    if (!readLine(fd, &reply, 4096) || reply.rfind("OK", 0) != 0) {
        if (error) *error = "engine rejected authentication";
        return false;
    }
    return true;
}

}  // namespace mdguest
