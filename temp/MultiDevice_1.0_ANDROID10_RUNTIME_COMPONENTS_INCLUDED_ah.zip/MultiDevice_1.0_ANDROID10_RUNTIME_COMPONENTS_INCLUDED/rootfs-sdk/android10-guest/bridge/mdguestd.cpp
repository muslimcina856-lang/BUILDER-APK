#include "md_guest_socket.h"

#include <chrono>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <string>
#include <thread>
#include <unistd.h>

namespace {

using PropertyGet = int (*)(const char*, char*);

std::string getProperty(const char* key) {
    auto getter = reinterpret_cast<PropertyGet>(::dlsym(RTLD_DEFAULT, "__system_property_get"));
    if (!getter) return {};
    char value[256]{};
    const int count = getter(key, value);
    return count > 0 ? std::string(value, static_cast<size_t>(count)) : std::string();
}

}  // namespace

int main() {
    const char* socketName = std::getenv("MD_GUEST_SOCKET");
    const char* token = std::getenv("MD_SESSION_TOKEN");
    if (!socketName || !token) return 64;

    std::string error;
    const int fd = mdguest::connectAbstract(socketName, &error);
    if (fd < 0 || !mdguest::authenticate(fd, token, &error)) return 65;

    // Do not lie to the host. Framework readiness is emitted only after Android reports boot complete.
    for (int i = 0; i < 360; ++i) {
        if (getProperty("sys.boot_completed") == "1") {
            mdguest::sendLine(fd, "ANDROID_FRAMEWORK_READY");
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }

    std::string command;
    while (mdguest::readLine(fd, &command)) {
        if (command == "SUSPEND") {
            mdguest::sendLine(fd, "SUSPENDED");
        } else if (command == "RESUME") {
            mdguest::sendLine(fd, "RESUMED");
        } else if (command == "SHUTDOWN") {
            ::sync();
            break;
        }
        // TOUCH/KEY/TEXT are consumed by the input bridge in the production ROM patch.
    }
    ::close(fd);
    return 0;
}
