#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Publishes one RGBA8888/ARGB8888 scanout into the shared double framebuffer.
// Returns 0 on success. This is designed to be called by a patched Android 10 display/HWC path.
int md_present_argb8888(const void* pixels, uint32_t width, uint32_t height, uint32_t stridePixels);

#ifdef __cplusplus
}
#endif
