#include "md_frame_bridge.h"
#include "md_guest_socket.h"
#include "md_protocol.h"

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <mutex>
#include <string>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

namespace {

std::mutex gLock;
int gFrameFd = -1;
void* gMap = MAP_FAILED;
size_t gMapSize = 0;
int gSocket = -1;
std::atomic<uint64_t> gSequence{0};

const char* requiredEnv(const char* name) {
    const char* value = std::getenv(name);
    return value != nullptr && *value != '\0' ? value : nullptr;
}

void closeState() {
    if (gMap != MAP_FAILED) ::munmap(gMap, gMapSize);
    if (gFrameFd >= 0) ::close(gFrameFd);
    if (gSocket >= 0) ::close(gSocket);
    gMap = MAP_FAILED;
    gFrameFd = -1;
    gSocket = -1;
    gMapSize = 0;
}

bool ensureState() {
    if (gMap != MAP_FAILED && gSocket >= 0) return true;
    closeState();
    const char* framePath = requiredEnv("MD_FRAMEBUFFER");
    const char* socketName = requiredEnv("MD_GUEST_SOCKET");
    const char* token = requiredEnv("MD_SESSION_TOKEN");
    if (!framePath || !socketName || !token) return false;

    const int frameFd = ::open(framePath, O_RDWR | O_CLOEXEC);
    if (frameFd < 0) return false;
    struct stat info{};
    if (::fstat(frameFd, &info) != 0 || info.st_size < static_cast<off_t>(MD_FRAME_HEADER_SIZE)) {
        ::close(frameFd);
        return false;
    }
    void* map = ::mmap(nullptr, static_cast<size_t>(info.st_size), PROT_READ | PROT_WRITE, MAP_SHARED, frameFd, 0);
    if (map == MAP_FAILED) {
        ::close(frameFd);
        return false;
    }

    std::string error;
    const int socket = mdguest::connectAbstract(socketName, &error);
    if (socket < 0 || !mdguest::authenticate(socket, token, &error)) {
        if (socket >= 0) ::close(socket);
        ::munmap(map, static_cast<size_t>(info.st_size));
        ::close(frameFd);
        return false;
    }

    gFrameFd = frameFd;
    gMap = map;
    gMapSize = static_cast<size_t>(info.st_size);
    gSocket = socket;
    return true;
}

}  // namespace

extern "C" int md_present_argb8888(const void* pixels, uint32_t width, uint32_t height, uint32_t stridePixels) {
    if (pixels == nullptr || width == 0 || height == 0 || stridePixels < width) return -EINVAL;
    std::lock_guard<std::mutex> guard(gLock);
    if (!ensureState()) return -ENOTCONN;

    auto* header = static_cast<md_frame_header*>(gMap);
    if (header->magic != MD_FRAME_MAGIC || header->version != MD_FRAME_VERSION) return -EPROTO;
    if (width != header->width || height != header->height) return -EINVAL;

    const uint64_t frameBytes = static_cast<uint64_t>(header->stride) * header->height * 4u;
    const uint64_t requiredSize = MD_FRAME_HEADER_SIZE + frameBytes * MD_FRAME_SLOT_COUNT;
    if (requiredSize > gMapSize) return -EOVERFLOW;

    const uint32_t slot = header->active_slot == 0 ? 1u : 0u;
    auto* destination = static_cast<uint8_t*>(gMap) + MD_FRAME_HEADER_SIZE + frameBytes * slot;
    const auto* source = static_cast<const uint8_t*>(pixels);
    const size_t destinationRowBytes = static_cast<size_t>(header->stride) * 4u;
    const size_t sourceRowBytes = static_cast<size_t>(stridePixels) * 4u;
    const size_t copyBytes = static_cast<size_t>(width) * 4u;
    for (uint32_t y = 0; y < height; ++y) {
        std::memcpy(destination + static_cast<size_t>(y) * destinationRowBytes,
                    source + static_cast<size_t>(y) * sourceRowBytes,
                    copyBytes);
    }
    ::msync(destination, static_cast<size_t>(frameBytes), MS_ASYNC);

    const uint64_t sequence = gSequence.fetch_add(1) + 1;
    header->active_slot = slot;
    header->sequence = sequence;
    __sync_synchronize();
    if (!mdguest::sendLine(gSocket, "FRAME " + std::to_string(sequence) + " " + std::to_string(slot))) {
        closeState();
        return -EPIPE;
    }
    return 0;
}
