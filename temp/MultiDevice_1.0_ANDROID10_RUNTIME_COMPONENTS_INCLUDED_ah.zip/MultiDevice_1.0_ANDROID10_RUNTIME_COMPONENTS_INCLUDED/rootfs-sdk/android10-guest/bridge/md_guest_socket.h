#pragma once

#include <string>

namespace mdguest {

int connectAbstract(const std::string& socketName, std::string* error = nullptr);
bool authenticate(int fd, const std::string& token, std::string* error = nullptr);
bool sendLine(int fd, const std::string& line);
bool readLine(int fd, std::string* line, size_t limit = 65536);

}  // namespace mdguest
