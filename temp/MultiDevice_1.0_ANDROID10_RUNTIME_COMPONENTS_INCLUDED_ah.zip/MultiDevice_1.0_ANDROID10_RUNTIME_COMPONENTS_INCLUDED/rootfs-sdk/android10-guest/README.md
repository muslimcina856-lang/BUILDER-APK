# Multi Device Android 10 guest component kit

This directory contains the guest-side source that was missing from earlier host-only revisions.
It is clean-room Multi Device code; it does not contain VMOS binaries, VMOS rootfs files, or the
prebuilt proprietary Twoyi ROM.

## Included components

- `md-container-init`: container bootstrap launched by the Android app through the host linker.
- `libmdguestshim`: path/privilege compatibility layer for `/system`, `/vendor`, `/product`, `/data`
  and a guarded Binder compatibility entry point.
- `mdguestd`: authenticated framework-ready/lifecycle agent. It only reports framework readiness
  after `sys.boot_completed=1`.
- `libmdframebridge`: zero-copy-ish bridge from a patched Android 10 display path into the shared
  double framebuffer used by the app.
- AOSP `Android.bp`, init rc, product make fragment and minimal SELinux policy.

## Important Binder rule

The host now includes a separate token-authenticated user-space Binder transport broker. Do not
point the guest at the host phone's `/dev/binder`: that would destroy isolation and collide with the
host service manager.

`libmdguestshim` recognizes Binder device opens and provides version/mmap compatibility, but it
*intentionally fails* `BINDER_WRITE_READ` if an unpatched Android 10 `libbinder` reaches the kernel
ioctl layer. A production guest ROM must route libbinder transactions to `MD_BINDER_SOCKET` before
that point. This fail-closed behavior is deliberate: pretending the transaction succeeded would
make Android hang or silently cross the isolation boundary.

## Display integration

Patch the Android 10 virtual display/HWC path to call:

```c
md_present_argb8888(pixels, width, height, stride_pixels);
```

from `libmdframebridge` after each composed frame. The app fixes geometry to one portrait phone
(720x1560); it is not a user setting.

## Building into Android 10

1. Prepare an Android 10 AOSP-derived source tree for ARM64.
2. Run `tools/install_into_aosp10.sh /path/to/aosp`.
3. Include `device/multidevice/phone/multidevice_product.mk` in the product.
4. Wire Android 10 libbinder to the `MD_BINDER_SOCKET` transport and the virtual display/HWC to
   `libmdframebridge`.
5. Build the ROM/rootfs, then package the resulting filesystem with the project's rootfs bundle
   tool. The bundle bootstrap must be `bridge/md-container-init` and protocol must be 2.

The source is intentionally included in the repository so the missing runtime is no longer an
opaque placeholder. A device-tested Android 10 ROM artifact still has to be produced from these
sources before the app can truthfully unlock Create Phone.
