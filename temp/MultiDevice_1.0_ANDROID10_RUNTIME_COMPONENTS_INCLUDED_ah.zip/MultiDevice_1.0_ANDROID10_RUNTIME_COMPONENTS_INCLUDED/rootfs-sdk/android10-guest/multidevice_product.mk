# Include from an Android 10 product makefile used to build the Multi Device guest ROM.
PRODUCT_PACKAGES += \
    md-container-init \
    mdguestd \
    libmdguestshim \
    libmdframebridge

PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/init/init.multidevice.rc:$(TARGET_COPY_OUT_SYSTEM)/etc/init/init.multidevice.rc

PRODUCT_SYSTEM_PROPERTIES += \
    ro.multidevice.container=1 \
    ro.sf.lcd_density=320
