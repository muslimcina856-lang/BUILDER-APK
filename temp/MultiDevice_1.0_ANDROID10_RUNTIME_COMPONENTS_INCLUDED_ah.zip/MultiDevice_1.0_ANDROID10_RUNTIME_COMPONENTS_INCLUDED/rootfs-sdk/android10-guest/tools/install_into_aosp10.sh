#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "usage: $0 /path/to/aosp-android10" >&2
  exit 64
fi

SRC="$(cd "$(dirname "$0")/.." && pwd)"
AOSP="$1"
DEST="$AOSP/device/multidevice/phone"

if [ ! -d "$AOSP/build/make" ] || [ ! -d "$AOSP/frameworks/native" ]; then
  echo "not an Android 10 source tree: $AOSP" >&2
  exit 65
fi

rm -rf "$DEST"
mkdir -p "$DEST"
cp -a "$SRC/Android.bp" "$SRC/bridge" "$SRC/init" "$SRC/sepolicy" "$SRC/multidevice_product.mk" "$DEST/"

echo "Installed Multi Device guest bridge sources at: $DEST"
echo "Next: include device/multidevice/phone/multidevice_product.mk from your Android 10 product."
echo "The Binder socket adapter and display integration described in README.md must be wired into that product before release."
