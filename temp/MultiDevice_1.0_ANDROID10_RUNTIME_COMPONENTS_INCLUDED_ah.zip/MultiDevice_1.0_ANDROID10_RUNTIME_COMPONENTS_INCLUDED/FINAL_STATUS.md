# Current engineering status

## Added in this revision

- Missing host-native runtime components are now in the Android project and CMake build:
  `libmdruntime.so`, `libmdguestshim.so`, `libmdframebridge.so` (ARM64 only).
- External ROM bootstrap removed. The engine now launches an APK-owned `app_process` child and
  `BootstrapMain`; rootfs bundles are pinned to `@host-native`.
- Separate token-authenticated userspace IPC/Binder transport broker added. It never reuses the host
  phone's Binder service-manager context.
- Native path mapper and per-profile virtual property store added.
- Guest-side Android 10 source kit added under `rootfs-sdk/android10-guest/`:
  bootstrap reference, path/Binder compatibility shim, framework-ready agent, frame bridge,
  Android.bp, init rc, product make fragment and SELinux policy.
- CMake/Gradle native build wiring added with `arm64-v8a` as the only ABI.
- QEMU/QMP/VNC/UTM/UEFI remain completely absent.

## Verified in this container

- Project verifier: PASS.
- Android 10 download/preparation verifier: PASS.
- Runtime-component verifier: PASS.
- C++ host/runtime + guest kit syntax with `-Wall -Wextra -Werror`: PASS.
- Native path/property/broker functional smoke test: PASS.
- Core Kotlin self-test: PASS.

## Still not honestly device-complete

The downloaded PHH Android 10 GSI is not itself a rootless container ROM. The source package now
contains the missing runtime implementation/build kit, but a production Android 10 guest artifact
still has to be rebuilt with two ROM-level integrations:

1. Android 10 libbinder must use the Multi Device userspace broker instead of kernel `/dev/binder`.
2. The Android virtual display/HWC path must publish composed frames through `libmdframebridge`.

The compatibility shim intentionally returns `ENOTSUP` if unpatched libbinder reaches
`BINDER_WRITE_READ`; the app therefore remains fail-closed instead of showing a fake RUNNING phone.

## Full APK build in this environment

Not executed. The local wrapper attempts to fetch Gradle 8.7 from `services.gradle.org`, but this
container cannot resolve that host. Android SDK/NDK are also not installed in this container.
The source-level and native host syntax tests above are included in the delivery logs.
