Implementation previews for the current phone-only Android 10 flow.
01/02 show actual setup-state UI intent. 03 shows the create screen once a compatible Android 10
native runtime is available. 04 is the target Running Phone layout and is not proof that the generic
GSI can boot without the missing Android 10 container bridge described in FINAL_STATUS.md.
