# Multi Device native rootfs bundle

This build accepts only **native-rootfs protocol 2** bundles. It does not accept QEMU/UTM disk
images and it does not cold-boot firmware.

Bundle layout:

```text
manifest.json
rootfs/                 extracted Android 10 root filesystem
```

The container bootstrap is no longer supplied by the ROM bundle. It is built into the Multi Device
APK (`libmdruntime.so`, `libmdguestshim.so`, `libmdframebridge.so`) and launched in the isolated
`:rootfs_engine` process through an APK-owned `app_process` child. A bundle therefore cannot replace
or inject the host bootstrap.

The Android 10 rootfs itself still has to be built with the guest-side integration in
`rootfs-sdk/android10-guest/`: isolated Binder transport and a virtual display/HWC path that calls
`md_present_argb8888()`.

Use `tools/make_rootfs_bundle.py` to package a prepared rootfs. The packer records rootfs symlinks
in `manifest.json`; the Android importer restores only relative symlinks that remain inside the
rootfs tree.
