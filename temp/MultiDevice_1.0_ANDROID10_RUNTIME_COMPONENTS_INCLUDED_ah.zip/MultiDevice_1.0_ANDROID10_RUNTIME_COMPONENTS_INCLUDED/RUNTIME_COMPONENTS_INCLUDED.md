# Android 10 runtime components included

This revision moves the missing runtime boundary into the Multi Device repository instead of
leaving an opaque `bridge/md-container-init` placeholder inside every ROM bundle.

## What is now physically built with the app

The Android Gradle project uses CMake for ARM64 and builds:

- `libmdruntime.so` - host-native path/property runtime and token-authenticated userspace IPC broker.
- `libmdguestshim.so` - guest path/privilege compatibility layer and fail-closed Binder entry point.
- `libmdframebridge.so` - writer for the v2 shared double framebuffer.

`RootfsEngineService` starts a dedicated `app_process` child from the APK. `BootstrapMain` then calls
`libmdruntime.so`, which replaces that child with the Android guest init through the host linker.
Therefore ROM bundles no longer provide or execute an arbitrary external bootstrap file.

## Guest Android 10 source kit

`rootfs-sdk/android10-guest/` contains the AOSP-side pieces:

- `md-container-init` reference bootstrap source.
- `mdguestd`, which reports readiness only after `sys.boot_completed=1`.
- `libmdguestshim` and `libmdframebridge` sources.
- Android.bp, init rc, product make fragment and minimal SELinux policy.
- an installer helper for an Android 10 AOSP source checkout.

## The remaining hard boundary

A stock Android 10 GSI still uses Linux Binder driver semantics and a device/vendor display stack.
The app deliberately does not fake `BINDER_WRITE_READ` success. A production Android 10 guest ROM
must route libbinder into the Multi Device userspace broker and wire its virtual display/HWC path to
`libmdframebridge` during the ROM build. Until such a patched ROM artifact is produced, Create Phone
stays gated after the stock GSI download/preparation step.

This is intentional: enabling the button without those ROM changes would produce a fake "ready"
state rather than a working virtual phone.
