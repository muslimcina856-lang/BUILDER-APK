# Phone-only host-native rootfs engine

Multi Device exposes one fixed 720x1560 portrait phone. `RootfsEngineService` owns the engine in
process `:rootfs_engine`; Activity rotation only detaches/reattaches the display client.

## Runtime path

1. The service validates a protocol-v2 Android 10 rootfs and creates per-profile data.
2. `libmdruntime.so` starts a token-authenticated userspace IPC broker separate from the host Binder
   context.
3. The service launches an APK-owned `app_process` child with `BootstrapMain` on the APK classpath.
4. `BootstrapMain` calls `libmdruntime.so`, which execs guest `/system/bin/init` through the host
   linker with `libmdguestshim.so` preloaded.
5. A patched Android 10 display/HWC path calls `libmdframebridge.so` to publish frames into the
   shared double framebuffer.
6. The session is RUNNING only after framework-ready + first real frame.

The rootfs manifest uses `"bootstrap": "@host-native"`; external bootstrap binaries are rejected.
QEMU/QMP/VNC/UTM/UEFI are absent.

## Guest ROM integration

`rootfs-sdk/android10-guest/` provides the guest-side build kit. The remaining ROM-specific job is
to wire Android 10 libbinder to `MD_BINDER_SOCKET` and the virtual display/HWC to
`md_present_argb8888()`. The compatibility shim fails closed if stock libbinder reaches
`BINDER_WRITE_READ`, so a non-patched GSI cannot be misreported as a working phone.
