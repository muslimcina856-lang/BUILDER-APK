#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import zipfile


def collect_rootfs(root: Path):
    files = []
    symlinks = {}
    for current, dirs, names in os.walk(root, followlinks=False):
        current_path = Path(current)
        kept_dirs = []
        for name in dirs:
            p = current_path / name
            rel = p.relative_to(root).as_posix()
            if p.is_symlink():
                target = os.readlink(p)
                if os.path.isabs(target):
                    raise SystemExit(f'absolute symlink is not allowed: {rel} -> {target}')
                symlinks[rel] = target
            else:
                kept_dirs.append(name)
        dirs[:] = kept_dirs
        for name in names:
            p = current_path / name
            rel = p.relative_to(root).as_posix()
            if p.is_symlink():
                target = os.readlink(p)
                if os.path.isabs(target):
                    raise SystemExit(f'absolute symlink is not allowed: {rel} -> {target}')
                symlinks[rel] = target
            elif p.is_file():
                files.append((p, rel))
    return files, symlinks


def main():
    ap = argparse.ArgumentParser(description='Build a Multi Device host-native rootfs protocol 2 bundle')
    ap.add_argument('--rootfs', required=True, type=Path)
    ap.add_argument('--id', required=True)
    ap.add_argument('--name', required=True)
    ap.add_argument('--android-version', required=True, type=int)
    ap.add_argument('--api-level', required=True, type=int)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()

    rootfs = args.rootfs.resolve()
    if not rootfs.is_dir():
        raise SystemExit('rootfs directory is missing')
    init = rootfs / 'system/bin/init'
    if not init.is_file():
        raise SystemExit('rootfs is missing system/bin/init')

    files, symlinks = collect_rootfs(rootfs)
    manifest = {
        'id': args.id,
        'name': args.name,
        'androidVersion': args.android_version,
        'apiLevel': args.api_level,
        'architecture': 'ARM64',
        'engine': 'native-rootfs',
        'rootfsProtocol': 2,
        'rootfsDir': 'rootfs',
        'bootstrap': '@host-native',
        'symlinks': symlinks,
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, 'w', compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        z.writestr('manifest.json', json.dumps(manifest, indent=2, sort_keys=True))
        for p, rel in files:
            z.write(p, 'rootfs/' + rel)
    print(args.output)


if __name__ == '__main__':
    main()
