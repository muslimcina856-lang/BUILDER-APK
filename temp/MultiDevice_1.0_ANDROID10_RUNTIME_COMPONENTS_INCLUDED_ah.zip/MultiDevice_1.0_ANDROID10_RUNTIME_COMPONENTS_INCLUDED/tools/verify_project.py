#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

def need(path, text=None):
    p = ROOT / path
    if not p.is_file():
        errors.append(f"missing: {path}")
        return ""
    data = p.read_text(errors="replace")
    if text is not None and text not in data:
        errors.append(f"{path}: missing required text {text!r}")
    return data

def absent(path):
    if (ROOT / path).exists():
        errors.append(f"path must be absent: {path}")

models = need("app/src/main/java/com/virtual/devicelization/core/model/Models.kt", "object VirtualPhoneSpec")
need("app/src/main/java/com/virtual/devicelization/core/vm/RootfsEngineService.kt", "class RootfsEngineService")
need("app/src/main/java/com/virtual/devicelization/core/vm/NativeRuntime.kt", "object NativeRuntime")
need("app/src/main/java/com/virtual/devicelization/core/vm/BootstrapMain.kt", "object BootstrapMain")
need("app/src/main/cpp/mdruntime/md_binder_broker.cpp", "BinderBroker::start")
need("rootfs-sdk/android10-guest/bridge/md_frame_bridge.cpp", "md_present_argb8888")
need("app/src/main/java/com/virtual/devicelization/core/vm/RootfsVmBackend.kt", "class RootfsVmBackend")
need("app/src/main/java/com/virtual/devicelization/ui/components/RootfsGuestView.kt", "fun RootfsGuestView")
image_store = need("app/src/main/java/com/virtual/devicelization/core/image/GuestImageStore.kt", 'ENGINE_NATIVE_ROOTFS = "native-rootfs"')
create = need("app/src/main/java/com/virtual/devicelization/ui/screens/CreateProfileScreen.kt")
home = need("app/src/main/java/com/virtual/devicelization/ui/screens/HomeScreen.kt")
common = need("app/src/main/java/com/virtual/devicelization/ui/screens/Common.kt")
viewmodel = need("app/src/main/java/com/virtual/devicelization/ui/MainViewModel.kt")
build = need("app/build.gradle.kts", "isMinifyEnabled = true")
manifest = need("app/src/main/AndroidManifest.xml", 'android:process=":rootfs_engine"')
need("app/src/main/java/com/virtual/devicelization/core/image/Android10SetupService.kt", "XZInputStream")
need("app/src/main/java/com/virtual/devicelization/core/image/Android10SetupStore.kt", "RUNTIME_BRIDGE_REQUIRED")
need("app/proguard-rules.pro", "com.google.errorprone.annotations.RestrictedApi")
need("rootfs-sdk/protocol.md", "rootfs protocol v2")

for legacy in [
    "app/src/main/java/com/virtual/devicelization/core/vm/LocalQemuVmBackend.kt",
    "app/src/main/java/com/virtual/devicelization/core/vm/QemuCommandBuilder.kt",
    "app/src/main/java/com/virtual/devicelization/core/vm/QmpClient.kt",
    "app/src/main/java/com/virtual/devicelization/ui/components/QmpGuestView.kt",
    "app/src/main/java/com/virtual/devicelization/ui/components/VncGuestView.kt",
    "app/src/main/java/com/virtual/devicelization/core/image/RemoteImageCatalog.kt",
    "app/src/main/java/com/virtual/devicelization/core/image/UtmConfigParser.kt",
    "app/src/main/java/com/virtual/devicelization/ui/screens/ImagesScreen.kt",
    "native-engine",
    "app/src/main/assets/qemu",
    "app/src/main/res/raw/edk2_aarch64_code_fd.gz",
]:
    absent(legacy)

if "data class DeviceConfig" in models:
    errors.append("DeviceConfig must be removed")
for forbidden in ["DeviceStep(", "devicePresets", "ConfigNumberField(", "ConfigSlider(", "AndroidImageStep("]:
    if forbidden in create:
        errors.append(f"CreateProfileScreen still exposes removed choice: {forbidden}")
for forbidden_text in ["Tablet", "Desktop", "Foldable", "Device Configuration", "Custom Resolution", "Import another Android system"]:
    if forbidden_text in create:
        errors.append(f"CreateProfileScreen exposes removed option: {forbidden_text}")
if 'val labels = listOf("Basic", "Network", "Review")' not in create:
    errors.append("create wizard is not Basic -> Network -> Review")
if "MainTab.IMAGES" in common or "Library" in common:
    errors.append("Android systems/library tab still exposed")
if "FRAMEBUFFER_PROTOCOL = 2" not in models or "const val WIDTH = 720" not in models or "const val HEIGHT = 1560" not in models:
    errors.append("fixed portrait phone contract missing")
if "rootfsProtocol == VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL" not in image_store:
    errors.append("rootfs protocol validation missing")
if "org.tukaani:xz:1.10" not in build:
    errors.append("XZ preparation dependency missing")
if "isShrinkResources = true" not in build:
    errors.append("release resource shrinking not enabled")
if "Android10SetupService" not in manifest or 'foregroundServiceType="dataSync"' not in manifest:
    errors.append("Android 10 setup foreground service missing")
if "android10RuntimeReady" not in viewmodel:
    errors.append("runtime readiness gate missing")
if "enabled = runtimeReady" not in home:
    errors.append("Create action is not gated on real runtime readiness")

if errors:
    print("PROJECT VERIFICATION FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("PROJECT VERIFICATION PASSED")
print("Engine: native rootfs only; QEMU absent")
print("UI: one fixed portrait phone; no device/system picker")
print("Android 10: first-launch DownloadManager + XZ preparation service")
print("Safety gate: generic GSI is not marked runnable until it is converted into the patched host-native rootfs format")
print("Rootfs protocol: v2 shared double framebuffer")
print("Release R8 minify/shrink: enabled")
