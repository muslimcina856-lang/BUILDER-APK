#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manager = (root / 'app/src/main/java/com/virtual/devicelization/core/image/Android10AutoDownloadManager.kt').read_text()
setup = (root / 'app/src/main/java/com/virtual/devicelization/core/image/Android10SetupService.kt').read_text()
vm = (root / 'app/src/main/java/com/virtual/devicelization/ui/MainViewModel.kt').read_text()
home = (root / 'app/src/main/java/com/virtual/devicelization/ui/screens/HomeScreen.kt').read_text()
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()

checks = {
    'fixed Android 10 URL': 'system-quack-arm64-ab-vanilla.img.xz' in manager,
    'system DownloadManager': 'DownloadManager.Request' in manager and 'downloadManager.enqueue' in manager,
    'first-launch enqueue': 'startAndroid10FirstLaunchDownload()' in vm and 'android10Downloader.ensureStarted' in vm,
    'survives UI rotation by stored download id': 'KEY_DOWNLOAD_ID' in manager and 'currentState' in manager,
    'retry action': 'retryAndroid10Download' in vm and 'Retry Android 10 Setup' in home,
    'app-specific storage': 'setDestinationInExternalFilesDir' in manager,
    'xz archive validation': 'XZ_MAGIC' in manager,
    '6 GiB free-space guard': 'MIN_RECOMMENDED_FREE_BYTES = 6L * 1024L * 1024L * 1024L' in manager,
    'actual XZ decompression': 'XZInputStream' in setup and 'system.img.part' in setup,
    'atomic prepared image': 'renameTo(finalImage)' in setup,
    'sparse/raw ext4 validation': '0xED26FF3A' in setup and 'ext4Magic' in setup,
    'preparation foreground service': 'Android10SetupService' in manifest and 'foregroundServiceType="dataSync"' in manifest,
    'no false runnable state': 'RUNTIME_BRIDGE_REQUIRED' in setup and 'runtimeReady' in home,
    'no broad storage permission': 'WRITE_EXTERNAL_STORAGE' not in manifest and 'READ_EXTERNAL_STORAGE' not in manifest,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(1)
print('ANDROID 10 DOWNLOAD/PREP VERIFICATION PASSED')
