# Android 10 automatic first-launch setup

- Fixed source: PHH Treble Android 10 v222 ARM64 A/B vanilla `.img.xz`.
- Transfer owner: Android `DownloadManager`.
- Destination: app-specific external Downloads directory.
- Download id is persisted to avoid duplicate transfers after rotation/reopen.
- Minimum free-space guard: 6 GiB.
- Download validation: minimum archive size + XZ magic.
- Preparation owner: `Android10SetupService` foreground `dataSync` service.
- Preparation output: internal `android10_system/v222/system.img`.
- Commit: `system.img.part` -> validation -> atomic rename.
- Accepted image container: Android sparse or raw ext4.
- Prepared GSI is never promoted to a runnable rootfs without a compatible native Android 10
  container bridge.
