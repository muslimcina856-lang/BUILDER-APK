# Multi Device 1.0 - Android 10 phone runtime components

Multi Device is a **phone-only** Android project. The UI exposes one fixed portrait virtual phone
format and one guest target: **Android 10 / API 29 / ARM64**. There is no QEMU fallback and no
phone/tablet/desktop or resolution picker.

## User flow

1. First app launch automatically downloads the fixed Android 10 ARM64 vanilla GSI source with
   Android `DownloadManager`.
2. `Android10SetupService` unpacks the `.img.xz` archive in a foreground `dataSync` service.
3. The unpacked image is validated as Android sparse/raw ext4 and committed atomically.
4. Runtime components are now part of this repository and the APK native build:
   `libmdruntime.so`, `libmdguestshim.so`, and `libmdframebridge.so`.
5. The rootfs engine starts an APK-owned `app_process` child, so ROM bundles no longer supply an
   arbitrary bootstrap executable.
6. Create Phone remains fail-closed until the stock GSI has been converted/rebuilt as a compatible
   Android 10 rootfs with the included guest-side Binder/display integration.

## Included native runtime

- `libmdruntime.so`: host path/property runtime and an isolated, token-authenticated userspace IPC
  broker for the Android guest.
- `libmdguestshim.so`: guest path/privilege compatibility layer. It never exposes the host phone's
  Binder context and deliberately rejects unadapted `BINDER_WRITE_READ` traffic.
- `libmdframebridge.so`: writes composed Android frames directly into the protocol-v2 shared double
  framebuffer without QMP screenshots.
- `BootstrapMain`: child-process bootstrap shipped inside the APK and launched through Android
  `app_process`.

The AOSP-side source kit is under `rootfs-sdk/android10-guest/` and contains `Android.bp`, init rc,
SELinux policy, `mdguestd`, frame bridge source and install tooling for an Android 10 source tree.

## Why the stock GSI is still gated

A generic Android 10 GSI is a system payload, not a rootless VMOS-style ROM. Its framework still
expects Linux Binder semantics and a device/vendor graphics/HAL stack. Multi Device intentionally
does not pretend those calls succeeded. The Android 10 guest ROM must be built so libbinder uses
Multi Device's isolated userspace broker and its virtual display path publishes through
`libmdframebridge`.

This is a hard correctness boundary: `RUNNING` is only accepted after the guest reports
`ANDROID_FRAMEWORK_READY` and publishes a real frame.

## Android 10 first-launch source

`https://github.com/phhusson/treble_experimentations/releases/download/v222/system-quack-arm64-ab-vanilla.img.xz`

At least 6 GiB free space is required for download, unpacking and rootfs preparation.

## Build

Requirements: Java 17+, Android SDK 34, Android NDK with CMake 3.22.1+, Gradle 8.7.

```bash
./gradlew assembleDebug
./gradlew assembleRelease
```

Release R8 minification/resource shrinking remain enabled. The targeted Error Prone/Tink R8 guards
are kept in `app/proguard-rules.pro`.

## Verification

```bash
python3 tools/verify_project.py
python3 tools/verify_android10_autodownload.py
python3 tools/verify_runtime_components.py
```

See `FINAL_STATUS.md` and `RUNTIME_COMPONENTS_INCLUDED.md` for the exact device-tested boundary.
