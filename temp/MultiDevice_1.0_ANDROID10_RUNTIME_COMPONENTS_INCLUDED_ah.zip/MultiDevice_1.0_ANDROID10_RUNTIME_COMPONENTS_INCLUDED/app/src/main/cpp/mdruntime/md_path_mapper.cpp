#include "md_path_mapper.h"

#include <sstream>
#include <vector>

namespace md {
namespace {

std::string trimTrailingSlash(std::string value) {
    while (value.size() > 1 && value.back() == '/') value.pop_back();
    return value;
}

bool startsWithComponent(const std::string& value, const std::string& prefix) {
    return value == prefix || (value.size() > prefix.size() && value.compare(0, prefix.size(), prefix) == 0 && value[prefix.size()] == '/');
}

}  // namespace

bool normalizeAbsoluteGuestPath(const std::string& input, std::string* normalized, std::string* error) {
    if (normalized == nullptr) return false;
    if (input.empty() || input.front() != '/') {
        if (error) *error = "guest path is not absolute";
        return false;
    }

    std::vector<std::string> parts;
    std::stringstream stream(input);
    std::string part;
    while (std::getline(stream, part, '/')) {
        if (part.empty() || part == ".") continue;
        if (part == "..") {
            if (parts.empty()) {
                if (error) *error = "guest path escapes root";
                return false;
            }
            parts.pop_back();
            continue;
        }
        if (part.find('\0') != std::string::npos) {
            if (error) *error = "guest path contains NUL";
            return false;
        }
        parts.push_back(part);
    }

    std::string out = "/";
    for (size_t i = 0; i < parts.size(); ++i) {
        if (i != 0) out.push_back('/');
        out += parts[i];
    }
    *normalized = out;
    return true;
}

PathMapper::PathMapper(std::string rootfs, std::string data)
    : rootfs_(trimTrailingSlash(std::move(rootfs))), data_(trimTrailingSlash(std::move(data))) {}

bool PathMapper::resolve(const std::string& guestPath, std::string* hostPath, std::string* error) const {
    if (hostPath == nullptr) return false;
    std::string path;
    if (!normalizeAbsoluteGuestPath(guestPath, &path, error)) return false;

    if (rootfs_.empty() || data_.empty()) {
        if (error) *error = "rootfs/data mapping is not configured";
        return false;
    }

    if (startsWithComponent(path, "/data")) {
        *hostPath = data_ + path.substr(5);
        return true;
    }

    static const char* kRootfsPrefixes[] = {
        "/system", "/system_ext", "/vendor", "/product", "/odm", "/oem", "/apex", "/metadata", "/mnt"
    };
    for (const char* prefix : kRootfsPrefixes) {
        if (startsWithComponent(path, prefix)) {
            *hostPath = rootfs_ + path;
            return true;
        }
    }

    if (path == "/") {
        *hostPath = rootfs_;
        return true;
    }

    // Kernel-backed pseudo filesystems stay on the host. The guest shim separately filters
    // sensitive nodes and virtualizes binder/property access.
    if (startsWithComponent(path, "/proc") || startsWithComponent(path, "/sys") || startsWithComponent(path, "/dev")) {
        *hostPath = path;
        return true;
    }

    *hostPath = rootfs_ + path;
    return true;
}

}  // namespace md
