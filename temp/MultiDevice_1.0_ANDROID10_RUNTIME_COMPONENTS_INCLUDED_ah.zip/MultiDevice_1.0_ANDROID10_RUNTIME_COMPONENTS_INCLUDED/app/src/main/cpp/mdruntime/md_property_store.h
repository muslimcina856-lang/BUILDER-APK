#pragma once

#include <map>
#include <mutex>
#include <string>

namespace md {

class PropertyStore {
public:
    explicit PropertyStore(std::string backingFile);
    bool load(std::string* error = nullptr);
    bool set(const std::string& key, const std::string& value, std::string* error = nullptr);
    bool get(const std::string& key, std::string* value) const;
    bool flush(std::string* error = nullptr) const;

private:
    static bool validKey(const std::string& key);
    static bool validValue(const std::string& value);

    std::string backingFile_;
    mutable std::mutex mutex_;
    std::map<std::string, std::string> values_;
};

}  // namespace md
