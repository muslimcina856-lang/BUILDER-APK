#pragma once

#include <string>

namespace md {

class PathMapper {
public:
    PathMapper(std::string rootfs, std::string data);
    bool resolve(const std::string& guestPath, std::string* hostPath, std::string* error = nullptr) const;

private:
    std::string rootfs_;
    std::string data_;
};

bool normalizeAbsoluteGuestPath(const std::string& input, std::string* normalized, std::string* error = nullptr);

}  // namespace md
