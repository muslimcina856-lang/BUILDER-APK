#include "md_binder_broker.h"

#include <cerrno>
#include <cstring>
#include <sstream>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

namespace md {
namespace {

constexpr size_t kMaxLine = 64 * 1024;

bool validName(const std::string& value) {
    if (value.empty() || value.size() > 160) return false;
    for (char c : value) {
        const bool ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                        (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-' || c == '/';
        if (!ok) return false;
    }
    return true;
}

bool readLine(int fd, std::string* out) {
    if (out == nullptr) return false;
    out->clear();
    char ch = 0;
    while (out->size() < kMaxLine) {
        const ssize_t n = ::recv(fd, &ch, 1, 0);
        if (n <= 0) return false;
        if (ch == '\n') return true;
        if (ch != '\r') out->push_back(ch);
    }
    return false;
}

}  // namespace

BinderBroker::BinderBroker() = default;
BinderBroker::~BinderBroker() { stop(); }

bool BinderBroker::start(const std::string& abstractSocketName, const std::string& token, std::string* error) {
    stop();
    if (abstractSocketName.empty() || abstractSocketName.size() > sizeof(sockaddr_un::sun_path) - 2 || token.size() < 24) {
        if (error) *error = "invalid broker socket/token";
        return false;
    }

    const int fd = ::socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (fd < 0) {
        if (error) *error = std::string("socket failed: ") + std::strerror(errno);
        return false;
    }

    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    address.sun_path[0] = '\0';
    std::memcpy(address.sun_path + 1, abstractSocketName.data(), abstractSocketName.size());
    const socklen_t length = static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + 1 + abstractSocketName.size());
    if (::bind(fd, reinterpret_cast<sockaddr*>(&address), length) != 0 || ::listen(fd, 16) != 0) {
        if (error) *error = std::string("bind/listen failed: ") + std::strerror(errno);
        ::close(fd);
        return false;
    }

    socketName_ = abstractSocketName;
    token_ = token;
    serverFd_ = fd;
    running_.store(true);
    acceptThread_ = std::thread(&BinderBroker::acceptLoop, this);
    return true;
}

void BinderBroker::stop() {
    if (!running_.exchange(false)) return;
    const int server = serverFd_;
    serverFd_ = -1;
    if (server >= 0) {
        ::shutdown(server, SHUT_RDWR);
        ::close(server);
    }
    {
        std::lock_guard<std::mutex> guard(mutex_);
        for (const auto& [id, fd] : clients_) {
            (void)id;
            ::shutdown(fd, SHUT_RDWR);
            ::close(fd);
        }
        clients_.clear();
        services_.clear();
    }
    if (acceptThread_.joinable()) acceptThread_.join();
    token_.clear();
    socketName_.clear();
}

void BinderBroker::acceptLoop() {
    while (running_.load()) {
        const int fd = ::accept4(serverFd_, nullptr, nullptr, SOCK_CLOEXEC);
        if (fd < 0) {
            if (!running_.load()) break;
            if (errno == EINTR) continue;
            continue;
        }
        uint64_t id = 0;
        {
            std::lock_guard<std::mutex> guard(mutex_);
            id = nextClientId_++;
            clients_[id] = fd;
        }
        std::thread(&BinderBroker::clientLoop, this, fd, id).detach();
    }
}

bool BinderBroker::sendLine(int fd, const std::string& line) {
    const std::string payload = line + "\n";
    size_t offset = 0;
    while (offset < payload.size()) {
        const ssize_t n = ::send(fd, payload.data() + offset, payload.size() - offset, MSG_NOSIGNAL);
        if (n <= 0) return false;
        offset += static_cast<size_t>(n);
    }
    return true;
}

void BinderBroker::clientLoop(int fd, uint64_t clientId) {
    std::string line;
    if (!readLine(fd, &line) || line != "AUTH " + token_) {
        sendLine(fd, "DENY");
        removeClient(clientId, fd);
        return;
    }
    sendLine(fd, "OK " + std::to_string(clientId));

    while (running_.load() && readLine(fd, &line)) {
        std::istringstream input(line);
        std::string command;
        input >> command;
        if (command == "REGISTER") {
            std::string name;
            input >> name;
            if (!validName(name)) {
                sendLine(fd, "ERR invalid-service");
                continue;
            }
            {
                std::lock_guard<std::mutex> guard(mutex_);
                services_[name] = clientId;
            }
            sendLine(fd, "REGISTERED " + name);
        } else if (command == "LOOKUP") {
            std::string name;
            input >> name;
            uint64_t target = 0;
            {
                std::lock_guard<std::mutex> guard(mutex_);
                const auto it = services_.find(name);
                if (it != services_.end()) target = it->second;
            }
            sendLine(fd, target == 0 ? "NOT_FOUND" : "FOUND " + std::to_string(target));
        } else if (command == "SEND") {
            uint64_t target = 0;
            std::string transactionId;
            input >> target >> transactionId;
            std::string payload;
            std::getline(input, payload);
            if (!payload.empty() && payload.front() == ' ') payload.erase(payload.begin());
            int targetFd = -1;
            {
                std::lock_guard<std::mutex> guard(mutex_);
                const auto it = clients_.find(target);
                if (it != clients_.end()) targetFd = it->second;
            }
            if (targetFd < 0 || transactionId.empty() || payload.size() > kMaxLine / 2) {
                sendLine(fd, "ERR invalid-send");
                continue;
            }
            if (!sendLine(targetFd, "TRANSACTION " + std::to_string(clientId) + " " + transactionId + " " + payload)) {
                sendLine(fd, "ERR target-dead");
            } else {
                sendLine(fd, "SENT " + transactionId);
            }
        } else if (command == "REPLY") {
            uint64_t target = 0;
            std::string transactionId;
            input >> target >> transactionId;
            std::string payload;
            std::getline(input, payload);
            if (!payload.empty() && payload.front() == ' ') payload.erase(payload.begin());
            int targetFd = -1;
            {
                std::lock_guard<std::mutex> guard(mutex_);
                const auto it = clients_.find(target);
                if (it != clients_.end()) targetFd = it->second;
            }
            if (targetFd < 0 || transactionId.empty() || !sendLine(targetFd, "REPLY " + transactionId + " " + payload)) {
                sendLine(fd, "ERR reply-target-dead");
            }
        } else if (command == "PING") {
            sendLine(fd, "PONG");
        } else {
            sendLine(fd, "ERR unsupported-command");
        }
    }
    removeClient(clientId, fd);
}

void BinderBroker::removeClient(uint64_t clientId, int fd) {
    std::vector<int> survivors;
    bool ownsFd = false;
    {
        std::lock_guard<std::mutex> guard(mutex_);
        const auto client = clients_.find(clientId);
        if (client != clients_.end() && client->second == fd) {
            clients_.erase(client);
            ownsFd = true;
        }
        for (auto it = services_.begin(); it != services_.end();) {
            if (it->second == clientId) it = services_.erase(it); else ++it;
        }
        for (const auto& [id, survivorFd] : clients_) {
            (void)id;
            survivors.push_back(survivorFd);
        }
    }
    if (ownsFd) {
        ::shutdown(fd, SHUT_RDWR);
        ::close(fd);
    }
    for (int survivor : survivors) sendLine(survivor, "DEAD " + std::to_string(clientId));
}

}  // namespace md
