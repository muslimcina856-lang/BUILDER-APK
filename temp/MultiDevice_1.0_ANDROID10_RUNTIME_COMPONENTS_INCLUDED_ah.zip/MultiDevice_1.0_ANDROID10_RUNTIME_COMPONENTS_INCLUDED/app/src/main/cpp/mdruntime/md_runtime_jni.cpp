#include "md_binder_broker.h"
#include "md_path_mapper.h"
#include "md_property_store.h"

#include <jni.h>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

namespace {

std::mutex gMutex;
md::BinderBroker gBroker;

std::string toString(JNIEnv* env, jstring value) {
    if (value == nullptr) return {};
    const char* raw = env->GetStringUTFChars(value, nullptr);
    if (raw == nullptr) return {};
    std::string result(raw);
    env->ReleaseStringUTFChars(value, raw);
    return result;
}

jstring toJString(JNIEnv* env, const std::string& value) {
    return env->NewStringUTF(value.c_str());
}

bool isDirectory(const std::string& path) {
    struct stat info{};
    return !path.empty() && ::stat(path.c_str(), &info) == 0 && S_ISDIR(info.st_mode);
}

}  // namespace

extern "C" JNIEXPORT jint JNICALL
Java_com_virtual_devicelization_core_vm_NativeRuntime_nativeVersion(JNIEnv*, jobject) {
    return 1;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_virtual_devicelization_core_vm_NativeRuntime_nativeSelfTest(
    JNIEnv* env,
    jobject,
    jstring rootfsValue,
    jstring dataValue) {
    const std::string rootfs = toString(env, rootfsValue);
    const std::string data = toString(env, dataValue);
    if (!isDirectory(rootfs)) return toJString(env, "native runtime: rootfs directory is missing");
    if (!isDirectory(data)) return toJString(env, "native runtime: profile data directory is missing");

    md::PathMapper mapper(rootfs, data);
    std::string mapped;
    std::string error;
    if (!mapper.resolve("/system/bin/init", &mapped, &error) || mapped != rootfs + "/system/bin/init") {
        return toJString(env, "native runtime: path mapper self-test failed: " + error);
    }
    if (mapper.resolve("/../../data/escape", &mapped, &error)) {
        return toJString(env, "native runtime: path escape guard failed");
    }

    md::PropertyStore properties(data + "/.multidevice/properties.env");
    if (!properties.load(&error)) return toJString(env, "native runtime: property store load failed: " + error);
    if (!properties.set("ro.multidevice.runtime", "1", &error)) {
        return toJString(env, "native runtime: property store write failed: " + error);
    }
    std::string readBack;
    if (!properties.get("ro.multidevice.runtime", &readBack) || readBack != "1") {
        return toJString(env, "native runtime: property store readback failed");
    }
    return toJString(env, "");
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_virtual_devicelization_core_vm_NativeRuntime_nativeStartBinderBroker(
    JNIEnv* env,
    jobject,
    jstring socketValue,
    jstring tokenValue) {
    std::lock_guard<std::mutex> guard(gMutex);
    std::string error;
    const bool ok = gBroker.start(toString(env, socketValue), toString(env, tokenValue), &error);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_virtual_devicelization_core_vm_NativeRuntime_nativeStopBinderBroker(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> guard(gMutex);
    gBroker.stop();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_virtual_devicelization_core_vm_NativeRuntime_nativeBinderBrokerRunning(JNIEnv*, jobject) {
    return gBroker.running() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_virtual_devicelization_core_vm_NativeRuntime_nativeExecAndroidInit(JNIEnv* env, jobject) {
    const char* rootfs = std::getenv("MD_ROOTFS");
    const char* data = std::getenv("MD_DATA");
    const char* nativeLibDir = std::getenv("MD_RUNTIME_LIB_DIR");
    if (!rootfs || !*rootfs) return toJString(env, "MD_ROOTFS is missing");
    if (!data || !*data) return toJString(env, "MD_DATA is missing");
    if (!nativeLibDir || !*nativeLibDir) return toJString(env, "MD_RUNTIME_LIB_DIR is missing");

    const std::string root(rootfs);
    const std::string guestInit = root + "/system/bin/init";
    struct stat info{};
    if (::stat(guestInit.c_str(), &info) != 0 || !S_ISREG(info.st_mode)) {
        return toJString(env, "Android rootfs is missing /system/bin/init");
    }

    const std::string runtime(nativeLibDir);
    const std::string shim = runtime + "/libmdguestshim.so";
    const std::string frameBridge = runtime + "/libmdframebridge.so";
    if (::stat(shim.c_str(), &info) != 0) return toJString(env, "libmdguestshim.so is not packaged in the APK");
    if (::stat(frameBridge.c_str(), &info) != 0) return toJString(env, "libmdframebridge.so is not packaged in the APK");

    const std::string libraries =
        root + "/system/lib64:" + root + "/system/lib64/bootstrap:" + root + "/system_ext/lib64:" +
        root + "/product/lib64:" + root + "/vendor/lib64:" + runtime;
    ::setenv("LD_LIBRARY_PATH", libraries.c_str(), 1);
    ::setenv("LD_PRELOAD", shim.c_str(), 1);
    ::setenv("MD_FRAME_BRIDGE", frameBridge.c_str(), 1);
    ::setenv("ANDROID_ROOT", (root + "/system").c_str(), 1);
    ::setenv("ANDROID_DATA", data, 1);
    ::setenv("MD_CONTAINER_GUEST", "1", 1);

    ::execl("/system/bin/linker64", "linker64", guestInit.c_str(), "second_stage", nullptr);
    return toJString(env, std::string("exec linker64 failed: ") + std::strerror(errno));
}
