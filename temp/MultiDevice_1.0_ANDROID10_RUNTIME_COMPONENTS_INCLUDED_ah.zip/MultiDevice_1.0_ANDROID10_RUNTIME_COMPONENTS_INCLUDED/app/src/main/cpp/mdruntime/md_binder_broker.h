#pragma once

#include <atomic>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace md {

/**
 * A token-authenticated user-space IPC broker used by the Android 10 guest adapter.
 *
 * It deliberately has its own protocol instead of pretending to be /dev/binder. The guest-side
 * libbinder adapter translates Android Binder concepts to this broker, which prevents accidental
 * exposure to the host device's Binder context.
 */
class BinderBroker {
public:
    BinderBroker();
    ~BinderBroker();

    bool start(const std::string& abstractSocketName, const std::string& token, std::string* error = nullptr);
    void stop();
    bool running() const { return running_.load(); }

private:
    void acceptLoop();
    void clientLoop(int fd, uint64_t clientId);
    bool sendLine(int fd, const std::string& line);
    void removeClient(uint64_t clientId, int fd);

    std::atomic<bool> running_{false};
    int serverFd_{-1};
    std::string socketName_;
    std::string token_;
    std::thread acceptThread_;
    std::mutex mutex_;
    uint64_t nextClientId_{1};
    std::map<uint64_t, int> clients_;
    std::map<std::string, uint64_t> services_;
};

}  // namespace md
