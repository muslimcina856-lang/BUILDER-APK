#include "md_property_store.h"

#include <cerrno>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <sys/stat.h>
#include <unistd.h>

namespace md {
namespace {

bool ensureParent(const std::string& path) {
    const size_t slash = path.find_last_of('/');
    if (slash == std::string::npos || slash == 0) return true;
    std::string current;
    std::stringstream stream(path.substr(0, slash));
    std::string part;
    while (std::getline(stream, part, '/')) {
        if (part.empty()) continue;
        current += "/" + part;
        if (::mkdir(current.c_str(), 0700) != 0 && errno != EEXIST) return false;
    }
    return true;
}

}  // namespace

PropertyStore::PropertyStore(std::string backingFile) : backingFile_(std::move(backingFile)) {}

bool PropertyStore::validKey(const std::string& key) {
    if (key.empty() || key.size() > 96) return false;
    for (char c : key) {
        const bool ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                        (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-';
        if (!ok) return false;
    }
    return true;
}

bool PropertyStore::validValue(const std::string& value) {
    return value.size() <= 4096 && value.find('\n') == std::string::npos && value.find('\r') == std::string::npos;
}

bool PropertyStore::load(std::string* error) {
    std::lock_guard<std::mutex> guard(mutex_);
    values_.clear();
    std::ifstream input(backingFile_);
    if (!input.good()) return true;
    std::string line;
    while (std::getline(input, line)) {
        const size_t sep = line.find('=');
        if (sep == std::string::npos) continue;
        const std::string key = line.substr(0, sep);
        const std::string value = line.substr(sep + 1);
        if (validKey(key) && validValue(value)) values_[key] = value;
    }
    if (!input.eof() && input.fail()) {
        if (error) *error = "unable to read property store";
        return false;
    }
    return true;
}

bool PropertyStore::set(const std::string& key, const std::string& value, std::string* error) {
    if (!validKey(key) || !validValue(value)) {
        if (error) *error = "invalid virtual property";
        return false;
    }
    {
        std::lock_guard<std::mutex> guard(mutex_);
        values_[key] = value;
    }
    return flush(error);
}

bool PropertyStore::get(const std::string& key, std::string* value) const {
    if (value == nullptr) return false;
    std::lock_guard<std::mutex> guard(mutex_);
    const auto it = values_.find(key);
    if (it == values_.end()) return false;
    *value = it->second;
    return true;
}

bool PropertyStore::flush(std::string* error) const {
    std::lock_guard<std::mutex> guard(mutex_);
    if (!ensureParent(backingFile_)) {
        if (error) *error = "unable to create property directory";
        return false;
    }
    const std::string temp = backingFile_ + ".part";
    {
        std::ofstream output(temp, std::ios::trunc);
        if (!output.good()) {
            if (error) *error = "unable to create property store";
            return false;
        }
        for (const auto& [key, value] : values_) output << key << '=' << value << '\n';
        output.flush();
        if (!output.good()) {
            if (error) *error = "unable to flush property store";
            return false;
        }
    }
    ::chmod(temp.c_str(), 0600);
    if (::rename(temp.c_str(), backingFile_.c_str()) != 0) {
        ::unlink(temp.c_str());
        if (error) *error = "unable to commit property store";
        return false;
    }
    return true;
}

}  // namespace md
