package com.virtual.devicelization.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.core.model.VmStatus
import com.virtual.devicelization.ui.components.GradientButton
import com.virtual.devicelization.ui.components.NeonCard
import com.virtual.devicelization.ui.theme.*

@Composable
fun ProfilesScreen(
    profiles: List<Profile>,
    canCreate: Boolean,
    onOpen: (Profile) -> Unit,
    onStart: (Profile) -> Unit,
    onClone: (Profile) -> Unit,
    onEdit: (Profile) -> Unit,
    onSnapshot: (Profile) -> Unit,
    onRestoreSnapshot: (Profile) -> Unit,
    onDelete: (Profile) -> Unit,
    onCreate: () -> Unit,
) {
    var filter by remember { mutableStateOf("All") }
    var searchVisible by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val visible = profiles.filter { p ->
        val statusMatches = when (filter) {
            "Running" -> p.status == VmStatus.RUNNING
            "Stopped" -> p.status == VmStatus.STOPPED || p.status == VmStatus.ERROR
            "Suspended" -> p.status == VmStatus.SUSPENDED
            else -> true
        }
        val searchMatches = query.isBlank() ||
            p.name.contains(query, ignoreCase = true) ||
            "Android ${p.androidVersion}".contains(query, ignoreCase = true)
        statusMatches && searchMatches
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Header(
                "Phones",
                if (profiles.isEmpty()) "No virtual phones created yet" else "${profiles.size} saved virtual phone${if (profiles.size == 1) "" else "s"}",
                trailing = {
                    IconButton(onClick = { searchVisible = !searchVisible; if (!searchVisible) query = "" }) {
                        Icon(if (searchVisible) Icons.Outlined.Close else Icons.Outlined.Search, "Search", tint = Cyan)
                    }
                },
            )
        }

        if (profiles.isEmpty()) {
            item {
                NeonCard(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    borderColor = Cyan,
                    contentPadding = PaddingValues(22.dp),
                ) {
                    Icon(Icons.Outlined.DevicesOther, null, tint = Cyan, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No phones", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Android 10 is the only phone system. Once first-launch setup is ready, create your phone here.",
                        color = TextMuted,
                    )
                    Spacer(Modifier.height(16.dp))
                    GradientButton("Create Phone", onCreate, Modifier.fillMaxWidth(), enabled = canCreate)
                }
            }
        } else {
            if (searchVisible) {
                item {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it.take(60) },
                        modifier = Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                        placeholder = { Text("Search name or Android version", color = TextSubtle) },
                        leadingIcon = { Icon(Icons.Outlined.Search, null) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan,
                            unfocusedBorderColor = Outline,
                        ),
                    )
                }
            }
            item {
                Row(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("All", "Running", "Stopped", "Suspended").forEach { f ->
                        FilterChip(
                            selected = filter == f,
                            onClick = { filter = f },
                            label = { Text(f) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Surface,
                                labelColor = TextMuted,
                                selectedContainerColor = Cyan.copy(alpha = .16f),
                                selectedLabelColor = TextPrimary,
                            ),
                            border = BorderStroke(1.dp, if (filter == f) Cyan else Outline),
                        )
                    }
                }
            }
            if (visible.isEmpty()) {
                item {
                    NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Purple) {
                        Text("No matching phones", fontWeight = FontWeight.Bold)
                        Text("Change the filter or search text.", color = TextMuted)
                    }
                }
            } else {
                items(visible, key = { it.id }) { p ->
                    ProfileListItem(p, onOpen, onStart, onClone, onEdit, onSnapshot, onRestoreSnapshot, onDelete)
                }
            }
            item {
                GradientButton("＋  New Phone", onCreate, Modifier.padding(horizontal = 18.dp).fillMaxWidth(), enabled = canCreate)
            }
        }
    }
}

@Composable
private fun ProfileListItem(
    profile: Profile,
    onOpen: (Profile) -> Unit,
    onStart: (Profile) -> Unit,
    onClone: (Profile) -> Unit,
    onEdit: (Profile) -> Unit,
    onSnapshot: (Profile) -> Unit,
    onRestoreSnapshot: (Profile) -> Unit,
    onDelete: (Profile) -> Unit,
) {
    var menuOpen by remember(profile.id) { mutableStateOf(false) }
    ProfileCard(
        profile = profile,
        onClick = { onOpen(profile) },
        actions = {
            val hasActiveSession = profile.status == VmStatus.RUNNING || profile.status == VmStatus.SUSPENDED
            SmallAction(
                icon = if (hasActiveSession) Icons.Outlined.OpenInNew else Icons.Outlined.PlayArrow,
                label = if (hasActiveSession) "Open" else "Start",
                enabled = profile.status !in setOf(VmStatus.CREATING, VmStatus.STARTING, VmStatus.STOPPING),
                tint = Cyan,
                onClick = { if (hasActiveSession) onOpen(profile) else onStart(profile) },
            )
            SmallAction(Icons.Outlined.ContentCopy, "Clone", tint = TextMuted) { onClone(profile) }
            SmallAction(
                Icons.Outlined.Edit,
                "Edit",
                enabled = profile.status !in setOf(VmStatus.RUNNING, VmStatus.SUSPENDED, VmStatus.STARTING, VmStatus.STOPPING),
                tint = TextMuted,
            ) { onEdit(profile) }
            Box {
                SmallAction(Icons.Outlined.MoreVert, "More", tint = TextMuted) { menuOpen = true }
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                ) {
                    DropdownMenuItem(
                        text = { Text("Create phone snapshot") },
                        leadingIcon = { Icon(Icons.Outlined.CameraAlt, null) },
                        onClick = { menuOpen = false; onSnapshot(profile) },
                    )
                    DropdownMenuItem(
                        text = { Text("Restore latest snapshot") },
                        leadingIcon = { Icon(Icons.Outlined.Restore, null) },
                        enabled = profile.status !in setOf(VmStatus.RUNNING, VmStatus.SUSPENDED, VmStatus.STARTING, VmStatus.STOPPING),
                        onClick = { menuOpen = false; onRestoreSnapshot(profile) },
                    )
                    DropdownMenuItem(
                        text = { Text("Delete profile", color = Danger) },
                        leadingIcon = { Icon(Icons.Outlined.DeleteOutline, null, tint = Danger) },
                        onClick = { menuOpen = false; onDelete(profile) },
                    )
                }
            }
        },
    )
}

@Composable
private fun SmallAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    enabled: Boolean = true,
    tint: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.widthIn(min = 54.dp)) {
        IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(38.dp)) {
            Icon(icon, label, tint = if (enabled) tint else TextSubtle.copy(alpha = .45f))
        }
        Text(
            label,
            color = if (enabled) TextMuted else TextSubtle.copy(alpha = .45f),
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
        )
    }
}
