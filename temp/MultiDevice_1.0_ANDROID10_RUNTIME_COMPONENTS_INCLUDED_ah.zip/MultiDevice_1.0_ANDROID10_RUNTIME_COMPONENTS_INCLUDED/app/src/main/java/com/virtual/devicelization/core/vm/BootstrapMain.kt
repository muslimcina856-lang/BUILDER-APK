package com.virtual.devicelization.core.vm

import kotlin.system.exitProcess

/**
 * Small child-process entry point launched through Android app_process.
 *
 * Keeping this bootstrap in the APK removes the old requirement for every Android rootfs bundle to
 * carry an executable bridge. The child immediately hands control to libmdruntime, which execs the
 * guest Android 10 init through the host linker with the clean-room guest shim preloaded.
 */
object BootstrapMain {
    @JvmStatic
    fun main(args: Array<String>) {
        val error = NativeRuntime.execAndroidInit()
        if (error != null) {
            System.err.println("Multi Device guest bootstrap failed: $error")
            exitProcess(70)
        }
        exitProcess(0)
    }
}
