package com.virtual.devicelization.core.image

import android.app.DownloadManager
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import java.io.File

/**
 * First-launch downloader for the fixed Android 10 ARM64 phone system source.
 *
 * DownloadManager owns the transfer so it survives Activity recreation and may continue while the
 * app process is not in the foreground. Multi Device never starts a second transfer while an
 * existing DownloadManager request is active.
 */
class Android10AutoDownloadManager(context: Context) {
    private val appContext = context.applicationContext
    private val downloadManager = appContext.getSystemService(DownloadManager::class.java)
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val destinationFile: File
        get() {
            val base = appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                ?: File(appContext.filesDir, "downloads")
            return File(base, RELATIVE_DESTINATION)
        }

    fun ensureStarted(android10AlreadyInstalled: Boolean): Android10DownloadState {
        if (android10AlreadyInstalled) {
            return Android10DownloadState(Android10DownloadPhase.INSTALLED, progressPercent = 100)
        }

        val downloaded = downloadedStateOrNull()
        if (downloaded != null) return downloaded

        val existingId = prefs.getLong(KEY_DOWNLOAD_ID, -1L)
        if (existingId > 0L) {
            val existing = queryDownload(existingId)
            if (existing != null && existing.phase !in TERMINAL_RETRY_PHASES) return existing
            if (existing?.phase == Android10DownloadPhase.FAILED) return existing
            prefs.edit().remove(KEY_DOWNLOAD_ID).apply()
        }

        return enqueueFresh()
    }

    fun currentState(android10AlreadyInstalled: Boolean): Android10DownloadState {
        if (android10AlreadyInstalled) {
            return Android10DownloadState(Android10DownloadPhase.INSTALLED, progressPercent = 100)
        }
        downloadedStateOrNull()?.let { return it }
        val id = prefs.getLong(KEY_DOWNLOAD_ID, -1L)
        if (id <= 0L) return Android10DownloadState(Android10DownloadPhase.IDLE)
        return queryDownload(id) ?: Android10DownloadState(Android10DownloadPhase.IDLE)
    }

    fun retry(): Android10DownloadState {
        val previous = prefs.getLong(KEY_DOWNLOAD_ID, -1L)
        if (previous > 0L) runCatching { downloadManager.remove(previous) }
        prefs.edit().remove(KEY_DOWNLOAD_ID).apply()
        runCatching { destinationFile.delete() }
        return enqueueFresh()
    }

    private fun enqueueFresh(): Android10DownloadState {
        val target = destinationFile
        target.parentFile?.mkdirs()

        // Keep enough room for the downloaded archive plus the later rootfs preparation stage.
        val free = target.parentFile?.usableSpace ?: 0L
        if (free in 1 until MIN_RECOMMENDED_FREE_BYTES) {
            return Android10DownloadState(
                phase = Android10DownloadPhase.FAILED,
                message = "At least 6 GB free storage is required before Android 10 setup can start.",
            )
        }

        if (target.exists()) runCatching { target.delete() }

        return runCatching {
            val request = DownloadManager.Request(Uri.parse(ANDROID10_URL))
                .setTitle("Multi Device • Android 10")
                .setDescription("Downloading Android 10 ARM64 system")
                .setMimeType("application/x-xz")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(
                    appContext,
                    Environment.DIRECTORY_DOWNLOADS,
                    RELATIVE_DESTINATION,
                )
            val id = downloadManager.enqueue(request)
            prefs.edit().putLong(KEY_DOWNLOAD_ID, id).apply()
            Android10DownloadState(
                phase = Android10DownloadPhase.QUEUED,
                downloadId = id,
                message = "Android 10 download queued.",
            )
        }.getOrElse { error ->
            Android10DownloadState(
                phase = Android10DownloadPhase.FAILED,
                message = error.message ?: "Unable to start Android 10 download.",
            )
        }
    }

    private fun queryDownload(id: Long): Android10DownloadState? {
        val query = DownloadManager.Query().setFilterById(id)
        return downloadManager.query(query)?.use { cursor ->
            if (!cursor.moveToFirst()) return@use null
            readCursor(id, cursor)
        }
    }

    private fun readCursor(id: Long, cursor: Cursor): Android10DownloadState {
        val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
        val downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
        val total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
        val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
        val progress = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else null

        return when (status) {
            DownloadManager.STATUS_PENDING -> Android10DownloadState(
                phase = Android10DownloadPhase.QUEUED,
                progressPercent = progress,
                downloadedBytes = downloaded,
                totalBytes = total.takeIf { it > 0L },
                downloadId = id,
                message = "Waiting for Android download service…",
            )
            DownloadManager.STATUS_PAUSED -> Android10DownloadState(
                phase = Android10DownloadPhase.PAUSED,
                progressPercent = progress,
                downloadedBytes = downloaded,
                totalBytes = total.takeIf { it > 0L },
                downloadId = id,
                message = "Android 10 download is paused by the system.",
            )
            DownloadManager.STATUS_RUNNING -> Android10DownloadState(
                phase = Android10DownloadPhase.DOWNLOADING,
                progressPercent = progress,
                downloadedBytes = downloaded,
                totalBytes = total.takeIf { it > 0L },
                downloadId = id,
            )
            DownloadManager.STATUS_SUCCESSFUL -> downloadedStateOrNull()
                ?: Android10DownloadState(
                    phase = Android10DownloadPhase.FAILED,
                    downloadId = id,
                    message = "Android 10 download finished but the archive failed validation.",
                )
            DownloadManager.STATUS_FAILED -> Android10DownloadState(
                phase = Android10DownloadPhase.FAILED,
                progressPercent = progress,
                downloadedBytes = downloaded,
                totalBytes = total.takeIf { it > 0L },
                downloadId = id,
                message = "Android 10 download failed (system reason $reason).",
            )
            else -> Android10DownloadState(Android10DownloadPhase.IDLE)
        }
    }

    private fun downloadedStateOrNull(): Android10DownloadState? {
        val file = destinationFile
        if (!file.isFile || file.length() < MIN_VALID_ARCHIVE_BYTES) return null
        if (!hasXzMagic(file)) return null
        return Android10DownloadState(
            phase = Android10DownloadPhase.DOWNLOADED,
            progressPercent = 100,
            downloadedBytes = file.length(),
            totalBytes = file.length(),
            downloadId = prefs.getLong(KEY_DOWNLOAD_ID, -1L).takeIf { it > 0L },
            localPath = file.absolutePath,
            message = "Android 10 download complete.",
        )
    }

    private fun hasXzMagic(file: File): Boolean = runCatching {
        file.inputStream().use { input ->
            val header = ByteArray(XZ_MAGIC.size)
            input.read(header) == header.size && header.contentEquals(XZ_MAGIC)
        }
    }.getOrDefault(false)

    companion object {
        const val ANDROID10_URL =
            "https://github.com/phhusson/treble_experimentations/releases/download/v222/system-quack-arm64-ab-vanilla.img.xz"
        const val ANDROID10_FILE_NAME = "system-quack-arm64-ab-vanilla.img.xz"
        const val ANDROID10_SOURCE_ID = "aosp10-phh-v222-arm64-ab-vanilla"

        private const val PREFS = "android10_first_launch_download"
        private const val KEY_DOWNLOAD_ID = "download_id"
        private const val RELATIVE_DESTINATION = "multidevice/android10/$ANDROID10_FILE_NAME"
        private const val MIN_VALID_ARCHIVE_BYTES = 300L * 1024L * 1024L
        private const val MIN_RECOMMENDED_FREE_BYTES = 6L * 1024L * 1024L * 1024L
        private val XZ_MAGIC = byteArrayOf(0xFD.toByte(), 0x37, 0x7A, 0x58, 0x5A, 0x00)
        private val TERMINAL_RETRY_PHASES = setOf(Android10DownloadPhase.IDLE)
    }
}

enum class Android10DownloadPhase {
    IDLE,
    QUEUED,
    DOWNLOADING,
    PAUSED,
    DOWNLOADED,
    INSTALLED,
    FAILED,
}

data class Android10DownloadState(
    val phase: Android10DownloadPhase,
    val progressPercent: Int? = null,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long? = null,
    val downloadId: Long? = null,
    val localPath: String? = null,
    val message: String? = null,
) {
    val active: Boolean
        get() = phase in setOf(
            Android10DownloadPhase.QUEUED,
            Android10DownloadPhase.DOWNLOADING,
            Android10DownloadPhase.PAUSED,
        )
}
