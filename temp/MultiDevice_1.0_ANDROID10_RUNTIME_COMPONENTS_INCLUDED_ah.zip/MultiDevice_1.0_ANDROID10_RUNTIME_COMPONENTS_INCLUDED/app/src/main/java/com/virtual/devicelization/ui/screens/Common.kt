package com.virtual.devicelization.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.R
import com.virtual.devicelization.ui.theme.*

enum class MainTab { HOME, PROFILES, SETTINGS }

@Composable
fun Header(
    title: String,
    subtitle: String? = null,
    showLogo: Boolean = true,
    trailing: @Composable (() -> Unit)? = null,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (showLogo) {
            Image(painterResource(R.drawable.app_logo), null, Modifier.size(52.dp))
            Spacer(Modifier.width(14.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    color = Cyan,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
fun BottomNav(tab: MainTab, onTab: (MainTab) -> Unit) {
    NavigationBar(containerColor = Surface, tonalElevation = 0.dp) {
        NavItem(MainTab.HOME, tab, Icons.Outlined.Home, "Home", onTab)
        NavItem(MainTab.PROFILES, tab, Icons.Outlined.Group, "Profiles", onTab)
        NavItem(MainTab.SETTINGS, tab, Icons.Outlined.Settings, "Settings", onTab)
    }
}

@Composable
private fun RowScope.NavItem(
    item: MainTab,
    selected: MainTab,
    icon: ImageVector,
    label: String,
    onTab: (MainTab) -> Unit,
) {
    NavigationBarItem(
        selected = item == selected,
        onClick = { onTab(item) },
        icon = { Icon(icon, label) },
        label = { Text(label, maxLines = 1) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Cyan,
            selectedTextColor = Cyan,
            indicatorColor = Cyan.copy(alpha = .12f),
            unselectedIconColor = TextMuted,
            unselectedTextColor = TextMuted,
        ),
    )
}
