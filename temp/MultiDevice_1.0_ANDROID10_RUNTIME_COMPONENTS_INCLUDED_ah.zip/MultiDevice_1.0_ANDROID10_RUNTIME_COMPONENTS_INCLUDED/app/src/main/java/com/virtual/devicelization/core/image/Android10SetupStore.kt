package com.virtual.devicelization.core.image

import android.content.Context
import org.json.JSONObject
import java.io.File

enum class Android10SetupPhase {
    WAITING_FOR_DOWNLOAD,
    PREPARING,
    SOURCE_IMAGE_READY,
    RUNTIME_BRIDGE_REQUIRED,
    FAILED,
}

data class Android10SetupState(
    val phase: Android10SetupPhase = Android10SetupPhase.WAITING_FOR_DOWNLOAD,
    val message: String? = null,
    val preparedImagePath: String? = null,
    val preparedBytes: Long = 0L,
    val updatedAt: Long = System.currentTimeMillis(),
)

class Android10SetupStore(context: Context) {
    private val stateFile = File(context.filesDir, "android10_system/setup_state.json")

    fun read(): Android10SetupState {
        if (!stateFile.isFile) return Android10SetupState()
        return runCatching {
            val o = JSONObject(stateFile.readText())
            Android10SetupState(
                phase = runCatching { Android10SetupPhase.valueOf(o.optString("phase")) }
                    .getOrDefault(Android10SetupPhase.WAITING_FOR_DOWNLOAD),
                message = o.optString("message").takeIf { it.isNotBlank() },
                preparedImagePath = o.optString("preparedImagePath").takeIf { it.isNotBlank() },
                preparedBytes = o.optLong("preparedBytes", 0L),
                updatedAt = o.optLong("updatedAt", 0L),
            )
        }.getOrDefault(Android10SetupState())
    }

    @Synchronized
    fun write(state: Android10SetupState) {
        stateFile.parentFile?.mkdirs()
        val tmp = File(stateFile.parentFile, stateFile.name + ".part")
        tmp.writeText(
            JSONObject().apply {
                put("phase", state.phase.name)
                put("message", state.message ?: "")
                put("preparedImagePath", state.preparedImagePath ?: "")
                put("preparedBytes", state.preparedBytes)
                put("updatedAt", System.currentTimeMillis())
            }.toString()
        )
        if (stateFile.exists()) stateFile.delete()
        check(tmp.renameTo(stateFile)) { "Unable to commit Android 10 setup state." }
    }

    fun reset() {
        val systemDir = File(stateFile.parentFile, "v222")
        runCatching { systemDir.deleteRecursively() }
        runCatching { stateFile.delete() }
    }

    fun preparedImageFile(): File? = read().preparedImagePath?.let(::File)?.takeIf { it.isFile }
}
