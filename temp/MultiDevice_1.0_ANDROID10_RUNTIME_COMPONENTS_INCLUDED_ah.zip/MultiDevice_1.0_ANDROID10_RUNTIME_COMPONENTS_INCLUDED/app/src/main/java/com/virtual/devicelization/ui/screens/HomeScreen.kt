package com.virtual.devicelization.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.R
import com.virtual.devicelization.core.image.*
import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.core.model.VmStatus
import com.virtual.devicelization.ui.components.*
import com.virtual.devicelization.ui.theme.*

@Composable
fun HomeScreen(
    profiles: List<Profile>,
    android10DownloadState: Android10DownloadState,
    android10SetupState: Android10SetupState,
    runtimeReady: Boolean,
    onRetryAndroid10Download: () -> Unit,
    onProfile: (Profile) -> Unit,
    onCreate: () -> Unit,
) {
    val active = profiles.firstOrNull {
        it.status in setOf(
            VmStatus.STARTING, VmStatus.RUNNING, VmStatus.SUSPENDING, VmStatus.SUSPENDED,
            VmStatus.RESUMING, VmStatus.STOPPING,
        )
    }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Header(
                "Multi Device",
                when {
                    active != null -> "1 active virtual phone"
                    runtimeReady && profiles.isEmpty() -> "Android 10 ready • create your first phone"
                    else -> "Android 10 phone setup"
                },
            )
        }

        item {
            Android10SystemCard(
                download = android10DownloadState,
                setup = android10SetupState,
                runtimeReady = runtimeReady,
                onRetry = onRetryAndroid10Download,
            )
        }

        if (profiles.isEmpty()) {
            item {
                NeonCard(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    borderColor = Cyan,
                    contentPadding = PaddingValues(22.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.app_logo), null, Modifier.size(86.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Your Android 10 phone", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (runtimeReady) {
                                    "Android 10 is ready. Create a phone profile to start it."
                                } else {
                                    "Multi Device uses one fixed portrait phone format. Android 10 is installed automatically on first launch."
                                },
                                color = TextMuted,
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    GradientButton(
                        text = if (runtimeReady) "Create First Phone" else "Waiting for Android 10 Runtime",
                        onClick = onCreate,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = runtimeReady,
                    )
                }
            }
            item {
                NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Purple) {
                    Text("Phone-only flow", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    InfoRow(Icons.Outlined.CloudDownload, "1. Android 10 downloads automatically")
                    InfoRow(Icons.Outlined.BuildCircle, "2. The system image is verified and prepared")
                    InfoRow(Icons.Outlined.Smartphone, "3. One portrait virtual phone format only")
                }
            }
        } else {
            item {
                NeonCard(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    borderColor = if (active != null) Cyan else Blue,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Active Phone", color = Cyan, fontWeight = FontWeight.Medium)
                            Text(
                                active?.name ?: "No Phone Active",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Spacer(Modifier.height(10.dp))
                            StatusPill(active?.status ?: VmStatus.STOPPED)
                        }
                        Image(painterResource(R.drawable.app_logo), null, Modifier.size(92.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = .12f))
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Metric("Android", "10", Icons.Outlined.Android, Modifier.weight(1f))
                        Metric("Format", "Phone", Icons.Outlined.Smartphone, Modifier.weight(1f))
                        Metric("Network", active?.network?.mode?.name?.substringBefore('_') ?: "—", Icons.Outlined.Public, Modifier.weight(1f))
                    }
                }
            }
            item {
                Row(
                    Modifier.padding(horizontal = 20.dp, vertical = 4.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("Phones", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${profiles.size} total", color = TextMuted)
                }
            }
            items(profiles.take(3), key = { it.id }) { p -> ProfileCard(p, onClick = { onProfile(p) }) }
            item {
                GradientButton(
                    "＋  Create Phone",
                    onCreate,
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    enabled = runtimeReady,
                )
            }
        }
    }
}

@Composable
private fun Android10SystemCard(
    download: Android10DownloadState,
    setup: Android10SetupState,
    runtimeReady: Boolean,
    onRetry: () -> Unit,
) {
    val (title, subtitle, icon, tint) = when {
        runtimeReady -> Quad("Android 10 ready", "Native phone runtime is installed and ready to start.", Icons.Outlined.CheckCircle, Green)
        setup.phase == Android10SetupPhase.PREPARING -> Quad("Preparing Android 10", setup.message ?: "Unpacking the Android system image…", Icons.Outlined.BuildCircle, Cyan)
        setup.phase == Android10SetupPhase.RUNTIME_BRIDGE_REQUIRED -> Quad("Android 10 source prepared", setup.message ?: "Guest ROM conversion is required.", Icons.Outlined.Info, Purple)
        setup.phase == Android10SetupPhase.FAILED -> Quad("Android 10 preparation failed", setup.message ?: "Unable to prepare Android 10.", Icons.Outlined.ErrorOutline, Danger)
        download.phase == Android10DownloadPhase.DOWNLOADING -> Quad("Downloading Android 10", "AOSP 10 ARM64 • ${download.progressPercent?.let { "$it%" } ?: "in progress"} • continues in background", Icons.Outlined.CloudDownload, Cyan)
        download.phase == Android10DownloadPhase.QUEUED -> Quad("Android 10 queued", download.message ?: "Waiting for the Android download service…", Icons.Outlined.CloudDownload, Cyan)
        download.phase == Android10DownloadPhase.PAUSED -> Quad("Android 10 download paused", download.message ?: "The system paused the transfer.", Icons.Outlined.PauseCircleOutline, Purple)
        download.phase == Android10DownloadPhase.FAILED -> Quad("Android 10 download failed", download.message ?: "Unable to download Android 10.", Icons.Outlined.ErrorOutline, Danger)
        download.phase == Android10DownloadPhase.DOWNLOADED -> Quad("Android 10 downloaded", "The source archive is ready for automatic preparation.", Icons.Outlined.CheckCircle, Cyan)
        else -> Quad("Android 10 setup", "First launch installs the single Android 10 ARM64 phone system automatically.", Icons.Outlined.Android, Cyan)
    }

    NeonCard(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
        borderColor = tint,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = tint.copy(alpha = .08f),
                border = androidx.compose.foundation.BorderStroke(1.dp, tint.copy(alpha = .35f)),
            ) {
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (download.active) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = (download.progressPercent ?: 0).coerceIn(0, 100) / 100f,
                modifier = Modifier.fillMaxWidth(),
            )
        } else if (setup.phase == Android10SetupPhase.PREPARING) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
        if (download.phase == Android10DownloadPhase.FAILED || setup.phase == Android10SetupPhase.FAILED) {
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onRetry, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Retry Android 10 Setup")
            }
        }
    }
}

private data class Quad(
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val tint: androidx.compose.ui.graphics.Color,
)

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, color = TextMuted, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun Metric(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = TextMuted, style = MaterialTheme.typography.labelMedium)
        Text(value, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun ProfileCard(
    profile: Profile,
    onClick: () -> Unit,
    actions: (@Composable RowScope.() -> Unit)? = null,
) {
    val border = when (profile.status) {
        VmStatus.RUNNING -> Green
        VmStatus.SUSPENDED -> Purple
        VmStatus.ERROR -> Danger
        else -> Blue
    }
    NeonCard(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth().clickable(onClick = onClick),
        borderColor = border,
        contentPadding = PaddingValues(16.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = Cyan.copy(alpha = .08f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(alpha = .45f)),
            ) {
                Box(Modifier.size(50.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Smartphone, null, tint = Cyan, modifier = Modifier.size(30.dp))
                }
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(profile.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text("Android 10  •  Virtual Phone", color = TextMuted, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(3.dp))
                Text(profile.network.virtualMac, color = TextSubtle, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), maxLines = 1)
            }
            Spacer(Modifier.width(8.dp))
            StatusPill(profile.status)
        }
        actions?.let { actionContent ->
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = Color.White.copy(alpha = .10f))
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically, content = actionContent)
        }
    }
}
