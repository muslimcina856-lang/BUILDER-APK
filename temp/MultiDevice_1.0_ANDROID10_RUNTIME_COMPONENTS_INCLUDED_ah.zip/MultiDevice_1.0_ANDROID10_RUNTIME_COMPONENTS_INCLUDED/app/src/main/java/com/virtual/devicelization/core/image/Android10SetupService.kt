package com.virtual.devicelization.core.image

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.virtual.devicelization.R
import org.tukaani.xz.XZInputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Converts the first-launch Android 10 .img.xz download into a verified local system image.
 *
 * This deliberately does not mark the image as a runnable native-rootfs bundle. A generic GSI is
 * only the Android system payload; the separate Multi Device Android 10 container bridge still has
 * to provide the virtualized init/Binder/HAL contract before the rootfs engine may launch it.
 */
class Android10SetupService : Service() {
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "MD-A10-Setup") }
    private val working = AtomicBoolean(false)
    private val store by lazy { Android10SetupStore(this) }
    private val downloader by lazy { Android10AutoDownloadManager(this) }

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        startForeground(NOTIFICATION_ID, notification("Preparing Android 10…", true))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (working.compareAndSet(false, true)) executor.execute { prepare() }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun prepare() {
        val source = downloader.destinationFile
        if (!source.isFile) {
            finishWith(Android10SetupPhase.FAILED, "Android 10 archive is missing. Retry the download first.")
            return
        }

        val outDir = File(filesDir, "android10_system/v222").apply { mkdirs() }
        val finalImage = File(outDir, "system.img")
        val partImage = File(outDir, "system.img.part")
        val digestFile = File(outDir, "system.img.sha256")

        if (finalImage.isFile && validateImage(finalImage)) {
            store.write(
                Android10SetupState(
                    phase = Android10SetupPhase.RUNTIME_BRIDGE_REQUIRED,
                    message = BRIDGE_MESSAGE,
                    preparedImagePath = finalImage.absolutePath,
                    preparedBytes = finalImage.length(),
                )
            )
            updateNotification("Android 10 system source is prepared", false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        store.write(Android10SetupState(Android10SetupPhase.PREPARING, "Unpacking Android 10 system image…"))
        updateNotification("Unpacking Android 10 system image…", true)
        runCatching {
            partImage.delete()
            val md = MessageDigest.getInstance("SHA-256")
            var written = 0L
            XZInputStream(BufferedInputStream(FileInputStream(source), 1024 * 1024)).use { input ->
                BufferedOutputStream(FileOutputStream(partImage), 1024 * 1024).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count == 0) continue
                        written += count
                        require(written <= MAX_DECOMPRESSED_BYTES) { "Android 10 image exceeds the safe size limit." }
                        md.update(buffer, 0, count)
                        output.write(buffer, 0, count)
                    }
                    output.flush()
                }
            }
            require(partImage.length() >= MIN_IMAGE_BYTES) { "Unpacked Android 10 image is unexpectedly small." }
            require(validateImage(partImage)) { "Downloaded file unpacked, but it is not a valid Android sparse/raw ext4 image." }
            if (finalImage.exists()) finalImage.delete()
            require(partImage.renameTo(finalImage)) { "Unable to commit the prepared Android 10 image." }
            digestFile.writeText(md.digest().joinToString("") { "%02x".format(it) } + "\n")
            store.write(
                Android10SetupState(
                    phase = Android10SetupPhase.RUNTIME_BRIDGE_REQUIRED,
                    message = BRIDGE_MESSAGE,
                    preparedImagePath = finalImage.absolutePath,
                    preparedBytes = finalImage.length(),
                )
            )
            updateNotification("Android 10 system source is prepared", false)
        }.onFailure { error ->
            partImage.delete()
            store.write(
                Android10SetupState(
                    phase = Android10SetupPhase.FAILED,
                    message = error.message ?: "Android 10 preparation failed.",
                )
            )
            updateNotification("Android 10 preparation failed", false)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun finishWith(phase: Android10SetupPhase, message: String) {
        store.write(Android10SetupState(phase, message))
        updateNotification(message, false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun validateImage(file: File): Boolean = runCatching {
        FileInputStream(file).use { input ->
            val head = ByteArray(4096)
            val read = input.read(head)
            if (read < 1082) return@runCatching false
            val little = ByteBuffer.wrap(head).order(ByteOrder.LITTLE_ENDIAN)
            val sparseMagic = little.getInt(0) == 0xED26FF3A.toInt()
            val ext4Magic = (head[1080].toInt() and 0xff) == 0x53 && (head[1081].toInt() and 0xff) == 0xEF
            sparseMagic || ext4Magic
        }
    }.getOrDefault(false)

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Android system setup", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String, ongoing: Boolean): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_vm_notification)
            .setContentTitle("Multi Device • Android 10")
            .setContentText(text)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)
            .build()

    private fun updateNotification(text: String, ongoing: Boolean) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text, ongoing))
    }

    companion object {
        private const val CHANNEL_ID = "android10_setup"
        private const val NOTIFICATION_ID = 1011
        private const val MIN_IMAGE_BYTES = 500L * 1024L * 1024L
        private const val MAX_DECOMPRESSED_BYTES = 8L * 1024L * 1024L * 1024L
        const val BRIDGE_MESSAGE =
            "Android 10 system image is prepared and the native runtime components are bundled in the app. This stock GSI must still be rebuilt/converted with the included Android 10 guest patches before it can boot as the isolated virtual phone."

        fun start(context: Context) {
            val intent = Intent(context, Android10SetupService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
