package com.virtual.devicelization.core.vm

import java.io.File

/**
 * JNI entry point for Multi Device's clean-room native Android container support.
 *
 * This library does not expose the host phone's Binder context to the guest. It owns a separate,
 * token-authenticated userspace broker which the Android 10 guest adapter can use after its
 * libbinder layer is patched for the Multi Device protocol.
 */
object NativeRuntime {
    private val libraryLoaded: Boolean = runCatching {
        val explicitDir = System.getenv("MD_RUNTIME_LIB_DIR")?.takeIf { it.isNotBlank() }
        if (explicitDir != null) {
            System.load(File(explicitDir, "libmdruntime.so").absolutePath)
        } else {
            System.loadLibrary("mdruntime")
        }
        true
    }.getOrDefault(false)

    val isLoaded: Boolean get() = libraryLoaded
    val version: Int get() = if (libraryLoaded) runCatching { nativeVersion() }.getOrDefault(0) else 0

    fun selfTest(rootfs: File, data: File): String? {
        if (!libraryLoaded) return "Native runtime library libmdruntime.so is unavailable."
        if (version != EXPECTED_VERSION) return "Native runtime protocol mismatch (host=$version expected=$EXPECTED_VERSION)."
        return runCatching { nativeSelfTest(rootfs.absolutePath, data.absolutePath) }
            .getOrElse { it.message ?: it.javaClass.simpleName }
            .takeIf { it.isNotBlank() }
    }

    fun startBinderBroker(socketName: String, token: String): Boolean =
        libraryLoaded && runCatching { nativeStartBinderBroker(socketName, token) }.getOrDefault(false)

    fun stopBinderBroker() {
        if (libraryLoaded) runCatching { nativeStopBinderBroker() }
    }

    fun binderBrokerRunning(): Boolean =
        libraryLoaded && runCatching { nativeBinderBrokerRunning() }.getOrDefault(false)

    /** Returns only when exec failed. A successful call replaces the bootstrap child process. */
    fun execAndroidInit(): String? {
        if (!libraryLoaded) return "Native runtime library libmdruntime.so is unavailable."
        return runCatching { nativeExecAndroidInit() }
            .getOrElse { it.message ?: it.javaClass.simpleName }
            .takeIf { it.isNotBlank() }
    }

    private external fun nativeVersion(): Int
    private external fun nativeSelfTest(rootfs: String, data: String): String
    private external fun nativeStartBinderBroker(socketName: String, token: String): Boolean
    private external fun nativeStopBinderBroker()
    private external fun nativeBinderBrokerRunning(): Boolean
    private external fun nativeExecAndroidInit(): String

    private const val EXPECTED_VERSION = 1
}
