package com.virtual.devicelization.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.virtual.devicelization.core.image.Android10AutoDownloadManager
import com.virtual.devicelization.core.image.Android10DownloadPhase
import com.virtual.devicelization.core.image.Android10DownloadState
import com.virtual.devicelization.core.image.Android10SetupPhase
import com.virtual.devicelization.core.image.Android10SetupService
import com.virtual.devicelization.core.image.Android10SetupState
import com.virtual.devicelization.core.image.Android10SetupStore
import com.virtual.devicelization.core.image.GuestImageManifest
import com.virtual.devicelization.core.model.*
import com.virtual.devicelization.core.network.MacAddressGenerator
import com.virtual.devicelization.core.vm.LocalEngineRegistry
import com.virtual.devicelization.core.vm.SingleVmPolicy
import com.virtual.devicelization.core.vm.VmBackend
import com.virtual.devicelization.core.vm.VmBackendStatus
import com.virtual.devicelization.data.ProfileStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.UUID

enum class StartResult { STARTED, CONFLICT, FAILED }

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val store = ProfileStore(application)
    private val imageStore = LocalEngineRegistry.imageStore(application)
    private val backend: VmBackend = LocalEngineRegistry.backend(application)
    private val android10Downloader = Android10AutoDownloadManager(application)
    private val android10SetupStore = Android10SetupStore(application)
    private val vmOperationMutex = Mutex()

    val profiles = mutableStateListOf<Profile>()
    val guestImages = mutableStateListOf<GuestImageManifest>()
    val backendStatus: VmBackendStatus get() = backend.status()

    var operationMessage by mutableStateOf<String?>(null)
        private set

    var android10DownloadState by mutableStateOf(Android10DownloadState(Android10DownloadPhase.IDLE))
        private set

    var android10SetupState by mutableStateOf(android10SetupStore.read())
        private set

    val android10RuntimeReady: Boolean
        get() = guestImages.any { it.androidVersion == 10 && it.apiLevel == 29 && it.architecture.equals("ARM64", ignoreCase = true) }

    init {
        refreshImages()
        var legacyProfileFound = false
        val loaded = store.load().map { profile ->
            val imageSupported = profile.imageId != null && guestImages.any { it.id == profile.imageId }
            if (!imageSupported && profile.imageId != null) legacyProfileFound = true
            when {
                !imageSupported && profile.imageId != null -> profile.copy(status = VmStatus.ERROR)
                backend.isRunning(profile.id) && profile.status !in activeStates -> profile.copy(status = VmStatus.RUNNING)
                !backend.isRunning(profile.id) && profile.status in activeStates -> profile.copy(status = VmStatus.STOPPED)
                profile.status == VmStatus.CREATING -> profile.copy(status = VmStatus.STOPPED)
                else -> profile
            }
        }
        profiles.addAll(loaded)
        SingleVmPolicy.assertInvariant(profiles)
        persist()
        if (legacyProfileFound) {
            operationMessage = "Some saved phones use an older or missing runtime. This build supports only the Android 10 phone runtime."
        }
        startAndroid10FirstLaunchDownload()
    }

    val activeProfile: Profile? get() = SingleVmPolicy.activeProfile(profiles)


    private fun startAndroid10FirstLaunchDownload(forceRetry: Boolean = false) {
        viewModelScope.launch {
            if (forceRetry) {
                withContext(Dispatchers.IO) { android10SetupStore.reset() }
                android10SetupState = android10SetupStore.read()
            }

            android10DownloadState = withContext(Dispatchers.IO) {
                if (forceRetry) android10Downloader.retry()
                else {
                    val sourcePrepared = android10SetupStore.preparedImageFile() != null
                    android10Downloader.ensureStarted(android10RuntimeReady || sourcePrepared)
                }
            }

            while (android10DownloadState.active) {
                delay(1000)
                android10DownloadState = withContext(Dispatchers.IO) {
                    val sourcePrepared = android10SetupStore.preparedImageFile() != null
                    android10Downloader.currentState(android10RuntimeReady || sourcePrepared)
                }
            }

            if (android10DownloadState.phase == Android10DownloadPhase.DOWNLOADED && !android10RuntimeReady) {
                Android10SetupService.start(getApplication<Application>())
                operationMessage = "Android 10 downloaded. Preparing the local system image…"
            }

            var setupPolls = 0
            while (setupPolls < 900) {
                android10SetupState = withContext(Dispatchers.IO) { android10SetupStore.read() }
                if (android10SetupState.phase != Android10SetupPhase.PREPARING) break
                setupPolls++
                delay(1000)
            }
        }
    }

    fun retryAndroid10Download() {
        startAndroid10FirstLaunchDownload(forceRetry = true)
    }

    fun consumeMessage() { operationMessage = null }

    fun refreshImages() {
        guestImages.clear()
        guestImages.addAll(imageStore.list())
    }

    fun reconcileBackendState() {
        var changed = false
        profiles.indices.forEach { index ->
            val p = profiles[index]
            val alive = backend.isRunning(p.id)
            when {
                alive && p.status !in activeStates -> {
                    profiles[index] = p.copy(status = VmStatus.RUNNING)
                    changed = true
                }
                !alive && p.status in setOf(VmStatus.RUNNING, VmStatus.SUSPENDED, VmStatus.RESUMING, VmStatus.SUSPENDING) -> {
                    profiles[index] = p.copy(status = VmStatus.ERROR)
                    operationMessage = "${p.name} stopped unexpectedly. Check the native rootfs engine log."
                    changed = true
                }
            }
        }
        if (changed) {
            SingleVmPolicy.assertInvariant(profiles)
            persist()
        }
    }

    fun createProfile(name: String, network: NetworkConfig): Profile? {
        val image = guestImages.firstOrNull { it.androidVersion == 10 && it.apiLevel == 29 }
        if (image == null) {
            operationMessage = android10SetupState.message
                ?: "Android 10 is not runnable yet. The native Android 10 container runtime must be installed before a phone can be created."
            return null
        }
        val profile = Profile(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Virtual Phone" },
            androidVersion = 10,
            apiLevel = 29,
            architecture = "ARM64",
            imageId = image.id,
            network = ensureUniqueMac(network),
            status = VmStatus.CREATING,
        )
        profiles += profile
        persist()
        operationMessage = "Preparing private phone data…"
        prepareProfileStorage(profile, image, resetWorkingData = false)
        return profile
    }

    fun updateProfile(profile: Profile): Boolean {
        val index = profiles.indexOfFirst { it.id == profile.id }
        if (index < 0) return false
        val original = profiles[index]
        if (original.status in activeStates || original.status == VmStatus.CREATING) {
            operationMessage = "Stop this phone before changing its network."
            return false
        }
        val image = guestImages.firstOrNull { it.androidVersion == 10 && it.apiLevel == 29 }
        if (image == null) {
            operationMessage = "The Android 10 native phone runtime is not installed."
            return false
        }
        profiles[index] = original.copy(
            name = profile.name.trim().ifBlank { original.name },
            androidVersion = 10,
            apiLevel = 29,
            architecture = "ARM64",
            imageId = image.id,
            network = ensureUniqueMac(profile.network, profile.id),
            status = VmStatus.STOPPED,
        )
        persist()
        operationMessage = "Phone profile updated."
        return true
    }

    private fun prepareProfileStorage(profile: Profile, image: GuestImageManifest, resetWorkingData: Boolean) {
        viewModelScope.launch {
            runCatching {
                imageStore.prepareProfileData(profile, image, reset = resetWorkingData)
            }.onSuccess {
                val current = profiles.firstOrNull { it.id == profile.id }
                if (current != null && current.imageId == image.id && current.status == VmStatus.CREATING) {
                    setStatusInternal(profile.id, VmStatus.STOPPED)
                    operationMessage = "${profile.name} is ready."
                }
            }.onFailure { error ->
                val current = profiles.firstOrNull { it.id == profile.id }
                if (current != null && current.imageId == image.id && current.status == VmStatus.CREATING) {
                    setStatusInternal(profile.id, VmStatus.ERROR)
                    operationMessage = error.message ?: "Unable to prepare private phone data."
                }
            }
        }
    }

    fun cloneProfile(profileId: String): Profile? {
        val source = profiles.firstOrNull { it.id == profileId } ?: return null
        if (source.status in activeStates || source.status == VmStatus.CREATING) {
            operationMessage = "Stop this phone before cloning it."
            return null
        }
        if (source.imageId == null || guestImages.none { it.id == source.imageId }) {
            operationMessage = "This profile's native Android rootfs is missing."
            return null
        }
        val clone = source.copy(
            id = UUID.randomUUID().toString(),
            name = "${source.name} Copy",
            network = source.network.copy(virtualMac = generateUniqueMac()),
            status = VmStatus.CREATING,
            createdAtEpochMs = System.currentTimeMillis(),
        )
        profiles += clone
        persist()
        operationMessage = "Cloning private phone data…"
        viewModelScope.launch {
            runCatching { imageStore.cloneProfileData(source.id, clone.id) }
                .onSuccess {
                    setStatusInternal(clone.id, VmStatus.STOPPED)
                    operationMessage = "Phone cloned with isolated data and a new virtual MAC."
                }
                .onFailure {
                    setStatusInternal(clone.id, VmStatus.ERROR)
                    operationMessage = it.message ?: "Unable to clone phone data."
                }
        }
        return clone
    }

    fun createSnapshot(profileId: String) {
        val profile = profiles.firstOrNull { it.id == profileId } ?: return
        if (profile.status in activeStates || profile.status == VmStatus.CREATING) {
            operationMessage = "Suspend/stop the phone before creating a data snapshot."
            return
        }
        viewModelScope.launch {
            runCatching { imageStore.createProfileSnapshot(profile) }
                .onSuccess { operationMessage = "Phone data snapshot created." }
                .onFailure { operationMessage = it.message ?: "Unable to create snapshot." }
        }
    }

    fun restoreLatestSnapshot(profileId: String) {
        val profile = profiles.firstOrNull { it.id == profileId } ?: return
        if (profile.status in activeStates || profile.status == VmStatus.CREATING) {
            operationMessage = "Stop the phone before restoring a snapshot."
            return
        }
        viewModelScope.launch {
            runCatching { imageStore.restoreLatestProfileSnapshot(profile) }
                .onSuccess { restored -> operationMessage = if (restored) "Latest phone snapshot restored." else "No snapshot exists for this phone." }
                .onFailure { operationMessage = it.message ?: "Unable to restore snapshot." }
        }
    }

    fun resetMac(profileId: String): String? {
        val index = profiles.indexOfFirst { it.id == profileId }
        if (index < 0) return null
        val mac = generateUniqueMac()
        profiles[index] = profiles[index].copy(network = profiles[index].network.copy(virtualMac = mac))
        persist()
        operationMessage = if (profiles[index].status in activeStates) {
            "Virtual MAC changed to $mac. It applies on the next phone start."
        } else {
            "Virtual MAC reset to $mac"
        }
        return mac
    }

    fun startProfile(profileId: String, forceSwitch: Boolean = false, onResult: (StartResult) -> Unit) {
        if (profiles.none { it.id == profileId }) {
            onResult(StartResult.FAILED)
            return
        }
        viewModelScope.launch {
            vmOperationMutex.withLock {
                if (!forceSwitch && !SingleVmPolicy.canStart(profiles, profileId)) {
                    onResult(StartResult.CONFLICT)
                    return@withLock
                }

                if (forceSwitch) {
                    val other = SingleVmPolicy.activeProfile(profiles)?.takeIf { it.id != profileId }
                    if (other != null) {
                        val stopped = backend.shutdown(other)
                        if (stopped.isFailure) {
                            setStatusInternal(other.id, VmStatus.ERROR)
                            operationMessage = stopped.exceptionOrNull()?.message ?: "Unable to stop the current phone."
                            onResult(StartResult.FAILED)
                            return@withLock
                        }
                        setStatusInternal(other.id, VmStatus.STOPPED)
                    }
                }

                var target = profiles.firstOrNull { it.id == profileId } ?: run {
                    onResult(StartResult.FAILED)
                    return@withLock
                }
                if (target.status == VmStatus.CREATING) {
                    operationMessage = "This phone profile is still being prepared."
                    onResult(StartResult.FAILED)
                    return@withLock
                }
                if (target.imageId == null || guestImages.none { it.id == target.imageId }) {
                    setStatusInternal(target.id, VmStatus.ERROR)
                    operationMessage = "This phone has no compatible Android rootfs system selected."
                    onResult(StartResult.FAILED)
                    return@withLock
                }

                if (backend.isRunning(target.id)) {
                    if (target.status == VmStatus.SUSPENDED) {
                        setStatusInternal(target.id, VmStatus.RESUMING)
                        val resumed = backend.resume(target)
                        if (resumed.isSuccess) {
                            setStatusInternal(target.id, VmStatus.RUNNING)
                            onResult(StartResult.STARTED)
                        } else {
                            setStatusInternal(target.id, VmStatus.ERROR)
                            operationMessage = resumed.exceptionOrNull()?.message ?: "Unable to resume phone."
                            onResult(StartResult.FAILED)
                        }
                    } else {
                        if (target.status != VmStatus.RUNNING) setStatusInternal(target.id, VmStatus.RUNNING)
                        onResult(StartResult.STARTED)
                    }
                    return@withLock
                }

                if (target.network.macMode == MacMode.RANDOM_EVERY_BOOT) {
                    resetMac(profileId)
                    target = profiles.firstOrNull { it.id == profileId } ?: target
                }

                setStatusInternal(profileId, VmStatus.STARTING)
                val prepared = backend.prepare(target)
                if (prepared.isFailure) {
                    setStatusInternal(profileId, VmStatus.STOPPED)
                    operationMessage = prepared.exceptionOrNull()?.message ?: "Unable to prepare phone engine."
                    onResult(StartResult.FAILED)
                    return@withLock
                }

                val started = backend.start(target)
                if (started.isSuccess) {
                    setStatusInternal(profileId, VmStatus.RUNNING)
                    onResult(StartResult.STARTED)
                } else {
                    setStatusInternal(profileId, VmStatus.ERROR)
                    operationMessage = started.exceptionOrNull()?.message ?: "Unable to start virtual phone."
                    onResult(StartResult.FAILED)
                }
            }
        }
    }

    fun stopProfile(profileId: String, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                setStatusInternal(profileId, VmStatus.STOPPING)
                val result = backend.shutdown(profile)
                setStatusInternal(profileId, if (result.isSuccess) VmStatus.STOPPED else VmStatus.ERROR)
                if (result.isFailure) operationMessage = result.exceptionOrNull()?.message ?: "Unable to stop phone."
            }
            onDone?.invoke()
        }
    }

    fun forceStopProfile(profileId: String, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                val result = backend.forceStop(profile)
                setStatusInternal(profileId, if (result.isSuccess) VmStatus.STOPPED else VmStatus.ERROR)
                if (result.isFailure) operationMessage = result.exceptionOrNull()?.message ?: "Unable to force-stop phone."
            }
            onDone?.invoke()
        }
    }

    fun suspendProfile(profileId: String, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                setStatusInternal(profileId, VmStatus.SUSPENDING)
                val result = backend.suspendVm(profile)
                setStatusInternal(profileId, if (result.isSuccess) VmStatus.SUSPENDED else VmStatus.ERROR)
                if (result.isFailure) operationMessage = result.exceptionOrNull()?.message ?: "Unable to suspend phone."
            }
            onDone?.invoke()
        }
    }

    fun resumeProfile(profileId: String, onDone: (() -> Unit)? = null) {
        viewModelScope.launch {
            vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock
                setStatusInternal(profileId, VmStatus.RESUMING)
                val result = backend.resume(profile)
                setStatusInternal(profileId, if (result.isSuccess) VmStatus.RUNNING else VmStatus.ERROR)
                if (result.isFailure) operationMessage = result.exceptionOrNull()?.message ?: "Unable to resume phone."
            }
            onDone?.invoke()
        }
    }

    fun restartProfile(profileId: String) {
        viewModelScope.launch {
            val shouldStart = vmOperationMutex.withLock {
                val profile = profiles.firstOrNull { it.id == profileId } ?: return@withLock false
                val stopped = backend.shutdown(profile)
                if (stopped.isFailure) {
                    setStatusInternal(profileId, VmStatus.ERROR)
                    operationMessage = stopped.exceptionOrNull()?.message ?: "Unable to restart phone."
                    false
                } else {
                    setStatusInternal(profileId, VmStatus.STOPPED)
                    true
                }
            }
            if (shouldStart) startProfile(profileId, forceSwitch = false) { }
        }
    }

    fun deleteProfile(id: String) {
        val currentStatus = profiles.firstOrNull { it.id == id }?.status
        if (currentStatus in activeStates || currentStatus == VmStatus.CREATING) {
            operationMessage = "Stop this phone before deleting it."
            return
        }
        profiles.removeAll { it.id == id }
        persist()
        viewModelScope.launch {
            imageStore.deleteProfileData(id)
            operationMessage = "Phone profile and its private data deleted."
        }
    }

    private fun setStatusInternal(id: String, status: VmStatus) {
        val index = profiles.indexOfFirst { it.id == id }
        if (index >= 0) profiles[index] = profiles[index].copy(status = status)
        SingleVmPolicy.assertInvariant(profiles)
        persist()
    }

    private fun ensureUniqueMac(network: NetworkConfig, exceptProfileId: String? = null): NetworkConfig {
        val duplicate = profiles.any {
            it.id != exceptProfileId && it.network.virtualMac.equals(network.virtualMac, ignoreCase = true)
        }
        return if (duplicate || !MacAddressGenerator.isLocallyAdministeredUnicast(network.virtualMac)) {
            network.copy(virtualMac = generateUniqueMac())
        } else network
    }

    private fun generateUniqueMac(): String {
        var mac: String
        do mac = MacAddressGenerator.generate()
        while (profiles.any { it.network.virtualMac.equals(mac, ignoreCase = true) })
        return mac
    }

    private fun persist() = store.save(profiles)

    companion object {
        private val activeStates = setOf(
            VmStatus.STARTING, VmStatus.RUNNING, VmStatus.SUSPENDING, VmStatus.SUSPENDED,
            VmStatus.RESUMING, VmStatus.STOPPING,
        )
    }
}
