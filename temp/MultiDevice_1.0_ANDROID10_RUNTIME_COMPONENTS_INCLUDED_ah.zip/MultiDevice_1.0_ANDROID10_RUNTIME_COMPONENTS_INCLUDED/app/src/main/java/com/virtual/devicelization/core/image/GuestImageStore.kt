package com.virtual.devicelization.core.image

import android.content.Context
import android.net.Uri
import android.system.Os
import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.core.model.VirtualPhoneSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipInputStream

/** Native Android rootfs image format used by the phone engine. */
data class GuestImageManifest(
    val id: String,
    val name: String,
    val androidVersion: Int,
    val apiLevel: Int,
    val architecture: String = "ARM64",
    val engine: String = ENGINE_NATIVE_ROOTFS,
    val rootfsProtocol: Int = VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL,
    val rootfsDir: String = "rootfs",
    val bootstrap: String = HOST_NATIVE_BOOTSTRAP,
    val symlinks: Map<String, String> = emptyMap(),
    val directory: File,
) {
    fun resolve(relative: String): File {
        require(relative.isNotBlank()) { "Bundle path is empty." }
        val base = directory.canonicalFile
        val target = File(base, relative).canonicalFile
        require(target.path == base.path || target.path.startsWith(base.path + File.separator)) {
            "Image path escapes its bundle: $relative"
        }
        return target
    }

    val rootfsDirectory: File get() = resolve(rootfsDir)

    companion object {
        const val ENGINE_NATIVE_ROOTFS = "native-rootfs"
        const val HOST_NATIVE_BOOTSTRAP = "@host-native"
    }
}

data class ImageImportResult(val manifest: GuestImageManifest?, val error: String? = null)
data class ProfileSnapshotInfo(val id: String, val createdAtEpochMs: Long, val imageId: String?)

class GuestImageStore(private val context: Context) {
    private val root = File(context.filesDir, "guest_rootfs").apply { mkdirs() }
    private val profileRoot = File(context.filesDir, "profile_data").apply { mkdirs() }
    private val snapshotRoot = File(context.filesDir, "profile_snapshots").apply { mkdirs() }

    fun list(): List<GuestImageManifest> = root.listFiles()
        ?.filter { it.isDirectory && !it.name.startsWith(".") }
        ?.mapNotNull { readManifest(it) }
        ?.filter { validate(it) == null }
        ?.sortedByDescending { it.androidVersion }
        ?: emptyList()

    /** Profiles stay pinned to their exact rootfs id. There is intentionally no legacy fallback. */
    fun findFor(profile: Profile): GuestImageManifest? = profile.imageId?.let(::get)

    fun get(id: String): GuestImageManifest? {
        val dir = File(root, sanitizeId(id))
        val manifest = readManifest(dir) ?: return null
        return manifest.takeIf { validate(it) == null }
    }

    suspend fun importBundle(uri: Uri): ImageImportResult = withContext(Dispatchers.IO) {
        val temp = File(root, ".import-${UUID.randomUUID()}").apply { mkdirs() }
        try {
            val safeFree = (root.usableSpace - MIN_FREE_BYTES).coerceAtLeast(0L).coerceAtMost(MAX_EXTRACT_BYTES)
            require(safeFree > 0L) { "Not enough free storage to import an Android rootfs." }
            context.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input.buffered()).use { zip ->
                    var totalWritten = 0L
                    var entries = 0
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        entries++
                        require(entries <= MAX_ARCHIVE_ENTRIES) { "Rootfs bundle contains too many files." }
                        require(entry.name.length <= MAX_ARCHIVE_PATH_CHARS) { "Rootfs bundle path is too long." }
                        val out = safeDestination(temp, entry.name)
                        if (entry.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fileOut ->
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count <= 0) break
                                    totalWritten += count
                                    require(totalWritten <= safeFree) { "Rootfs bundle exceeds safe available storage." }
                                    fileOut.write(buffer, 0, count)
                                }
                            }
                        }
                        zip.closeEntry()
                    }
                }
            } ?: return@withContext ImageImportResult(null, "Unable to open the selected rootfs bundle.")

            val parsed = readManifest(temp)
                ?: return@withContext ImageImportResult(null, "manifest.json is missing or invalid.")
            val validation = validate(parsed, requireSymlinksApplied = false)
            if (validation != null) return@withContext ImageImportResult(null, validation)
            applyDeclaredSymlinks(parsed)
            val finalValidation = validate(parsed)
            if (finalValidation != null) return@withContext ImageImportResult(null, finalValidation)

            val target = File(root, sanitizeId(parsed.id))
            require(!target.exists()) { "An Android rootfs with id '${parsed.id}' is already installed." }
            if (!temp.renameTo(target)) {
                copyDirectory(temp, target)
                temp.deleteRecursively()
            }
            val installed = readManifest(target)
                ?: return@withContext ImageImportResult(null, "Imported rootfs could not be reopened.")
            validate(installed)?.let { return@withContext ImageImportResult(null, it) }
            ImageImportResult(installed)
        } catch (t: Throwable) {
            ImageImportResult(null, t.message ?: t.javaClass.simpleName)
        } finally {
            if (temp.exists()) temp.deleteRecursively()
        }
    }

    fun delete(imageId: String): Boolean {
        val dir = File(root, sanitizeId(imageId))
        return dir.exists() && dir.deleteRecursively()
    }

    suspend fun prepareProfileData(profile: Profile, manifest: GuestImageManifest, reset: Boolean = false) =
        withContext(Dispatchers.IO) {
            require(validate(manifest) == null) { "The selected Android rootfs is invalid." }
            val dir = profileDirectory(profile.id)
            if (reset && dir.exists()) dir.deleteRecursively()
            val data = File(dir, "data").apply { mkdirs() }
            File(dir, "image.id").writeText(manifest.id)
            File(dir, "phone.contract").writeText(
                "portrait-phone\nprotocol=${VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL}\n"
            )
            data
        }

    fun profileDirectory(profileId: String): File = File(profileRoot, sanitizeId(profileId))
    fun profileDataDirectory(profileId: String): File = File(profileDirectory(profileId), "data")

    suspend fun cloneProfileData(sourceProfileId: String, targetProfileId: String) = withContext(Dispatchers.IO) {
        val source = profileDirectory(sourceProfileId)
        require(source.isDirectory) { "Source profile data is missing." }
        val target = profileDirectory(targetProfileId)
        require(!target.exists()) { "Target profile data already exists." }
        copyDirectory(source, target)
    }

    suspend fun createProfileSnapshot(profile: Profile): ProfileSnapshotInfo = withContext(Dispatchers.IO) {
        val source = profileDirectory(profile.id)
        require(source.isDirectory) { "Profile data is missing." }
        val created = System.currentTimeMillis()
        val id = "$created-${UUID.randomUUID().toString().take(8)}"
        val target = File(File(snapshotRoot, sanitizeId(profile.id)), id)
        target.parentFile?.mkdirs()
        copyDirectory(source, target)
        File(target, "snapshot.meta").writeText(
            JSONObject().apply {
                put("profileId", profile.id)
                put("imageId", profile.imageId ?: "")
                put("createdAt", created)
            }.toString()
        )
        trimSnapshots(profile.id)
        ProfileSnapshotInfo(id, created, profile.imageId)
    }

    suspend fun restoreLatestProfileSnapshot(profile: Profile): Boolean = withContext(Dispatchers.IO) {
        val latest = File(snapshotRoot, sanitizeId(profile.id)).listFiles()
            ?.filter { it.isDirectory }
            ?.maxByOrNull { it.name.substringBefore('-').toLongOrNull() ?: 0L }
            ?: return@withContext false
        val meta = File(latest, "snapshot.meta")
        if (meta.isFile) {
            val imageId = runCatching { JSONObject(meta.readText()).optString("imageId") }.getOrDefault("")
            require(imageId.isBlank() || imageId == profile.imageId) {
                "Snapshot belongs to a different Android rootfs image."
            }
        }
        val target = profileDirectory(profile.id)
        val staging = File(profileRoot, ".restore-${UUID.randomUUID()}")
        copyDirectory(latest, staging, skipNames = setOf("snapshot.meta"))
        target.deleteRecursively()
        if (!staging.renameTo(target)) {
            copyDirectory(staging, target)
            staging.deleteRecursively()
        }
        true
    }

    suspend fun resetProfileWorkingData(profileId: String) = withContext(Dispatchers.IO) {
        profileDirectory(profileId).deleteRecursively()
    }

    suspend fun deleteProfileData(profileId: String) = withContext(Dispatchers.IO) {
        profileDirectory(profileId).deleteRecursively()
        File(snapshotRoot, sanitizeId(profileId)).deleteRecursively()
    }

    fun directorySizeBytes(manifest: GuestImageManifest): Long = manifest.directory.walkTopDown()
        .filter { it.isFile }
        .sumOf { it.length() }

    fun validate(manifest: GuestImageManifest, requireSymlinksApplied: Boolean = true): String? = runCatching {
        require(manifest.engine == GuestImageManifest.ENGINE_NATIVE_ROOTFS) {
            "Unsupported image engine '${manifest.engine}'."
        }
        require(manifest.rootfsProtocol == VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL) {
            "Unsupported rootfs protocol ${manifest.rootfsProtocol}; expected ${VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL}."
        }
        require(manifest.architecture.equals("ARM64", ignoreCase = true)) { "Only ARM64 Android rootfs bundles are supported." }
        require(manifest.rootfsDirectory.isDirectory) { "Rootfs directory '${manifest.rootfsDir}' is missing." }
        require(manifest.bootstrap == GuestImageManifest.HOST_NATIVE_BOOTSTRAP) {
            "This rootfs uses an obsolete external bootstrap. Rebuild it for the host-native Android 10 runtime."
        }
        val guestInit = File(manifest.rootfsDirectory, "system/bin/init")
        require(guestInit.isFile && guestInit.length() > 0L) {
            "Android rootfs is missing /system/bin/init."
        }
        if (requireSymlinksApplied) {
            manifest.symlinks.keys.forEach { link ->
                val file = File(manifest.rootfsDirectory, link)
                require(java.nio.file.Files.isSymbolicLink(file.toPath())) { "Declared rootfs symlink was not restored: $link" }
            }
        }
        null
    }.getOrElse { it.message ?: "Invalid Android rootfs bundle." }

    private fun applyDeclaredSymlinks(manifest: GuestImageManifest) {
        val rootDir = manifest.rootfsDirectory
        val rootPath = rootDir.toPath().toAbsolutePath().normalize()
        manifest.symlinks.forEach { (link, target) ->
            require(link.isNotBlank()) { "Rootfs symlink path is empty." }
            require(target.isNotBlank() && !target.startsWith("/")) { "Rootfs symlink target must be relative: $link" }
            val linkPath = rootDir.toPath().resolve(link).toAbsolutePath().normalize()
            require(linkPath.startsWith(rootPath) && linkPath != rootPath) { "Rootfs symlink escapes rootfs: $link" }
            val resolvedTarget = linkPath.parent.resolve(target).normalize()
            require(resolvedTarget.startsWith(rootPath)) { "Rootfs symlink target escapes rootfs: $link -> $target" }
            val linkFile = linkPath.toFile()
            linkFile.parentFile?.mkdirs()
            if (linkFile.exists() || java.nio.file.Files.isSymbolicLink(linkPath)) linkFile.delete()
            Os.symlink(target, linkFile.absolutePath)
        }
    }

    private fun readManifest(dir: File): GuestImageManifest? = runCatching {
        val file = File(dir, "manifest.json")
        if (!file.isFile) return null
        val o = JSONObject(file.readText())
        val linksObject = o.optJSONObject("symlinks")
        val links = linkedMapOf<String, String>()
        if (linksObject != null) {
            val keys = linksObject.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                links[key] = linksObject.getString(key)
            }
        }
        GuestImageManifest(
            id = o.getString("id"),
            name = o.optString("name", o.getString("id")),
            androidVersion = o.getInt("androidVersion"),
            apiLevel = o.getInt("apiLevel"),
            architecture = o.optString("architecture", "ARM64"),
            engine = o.optString("engine", ""),
            rootfsProtocol = o.optInt("rootfsProtocol", -1),
            rootfsDir = o.optString("rootfsDir", "rootfs"),
            bootstrap = o.optString("bootstrap", GuestImageManifest.HOST_NATIVE_BOOTSTRAP),
            symlinks = links,
            directory = dir,
        )
    }.getOrNull()

    private fun safeDestination(base: File, rawName: String): File {
        require(rawName.isNotBlank() && !rawName.contains('\u0000')) { "Invalid rootfs archive entry." }
        val basePath = base.canonicalFile.toPath()
        val destination = File(base, rawName).canonicalFile.toPath()
        require(destination.startsWith(basePath)) { "Rootfs archive entry escapes destination: $rawName" }
        return destination.toFile()
    }

    private fun copyDirectory(source: File, target: File, skipNames: Set<String> = emptySet()) {
        require(source.isDirectory) { "Source directory is missing: ${source.name}" }
        target.mkdirs()
        source.listFiles()?.forEach { child ->
            if (child.name in skipNames) return@forEach
            val out = File(target, child.name)
            if (java.nio.file.Files.isSymbolicLink(child.toPath())) {
                val targetText = java.nio.file.Files.readSymbolicLink(child.toPath()).toString()
                out.parentFile?.mkdirs()
                Os.symlink(targetText, out.absolutePath)
            } else if (child.isDirectory) {
                copyDirectory(child, out, skipNames)
            } else {
                out.parentFile?.mkdirs()
                child.inputStream().buffered(1024 * 1024).use { input ->
                    out.outputStream().buffered(1024 * 1024).use { output -> input.copyTo(output, 1024 * 1024) }
                }
            }
        }
    }

    private fun trimSnapshots(profileId: String) {
        val dir = File(snapshotRoot, sanitizeId(profileId))
        val snapshots = dir.listFiles()?.filter { it.isDirectory }?.sortedByDescending {
            it.name.substringBefore('-').toLongOrNull() ?: 0L
        } ?: return
        snapshots.drop(MAX_SNAPSHOTS_PER_PROFILE).forEach { it.deleteRecursively() }
    }


    companion object {
        private const val MIN_FREE_BYTES = 256L * 1024 * 1024
        private const val MAX_EXTRACT_BYTES = 24L * 1024 * 1024 * 1024
        private const val MAX_ARCHIVE_ENTRIES = 250_000
        private const val MAX_ARCHIVE_PATH_CHARS = 768
        private const val MAX_SNAPSHOTS_PER_PROFILE = 3

        fun sanitizeId(id: String): String = id.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96)
    }
}
