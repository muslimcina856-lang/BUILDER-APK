package com.virtual.devicelization.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.core.model.*
import com.virtual.devicelization.core.network.MacAddressGenerator
import com.virtual.devicelization.ui.components.GradientButton
import com.virtual.devicelization.ui.components.NeonCard
import com.virtual.devicelization.ui.theme.*

@Composable
fun CreateProfileScreen(
    onCancel: () -> Unit,
    initialProfile: Profile? = null,
    onCreate: (String, NetworkConfig) -> Unit,
) {
    var step by remember(initialProfile?.id) { mutableIntStateOf(1) }
    var name by remember(initialProfile?.id) { mutableStateOf(initialProfile?.name.orEmpty()) }
    var network by remember(initialProfile?.id) {
        mutableStateOf(initialProfile?.network ?: NetworkConfig(MacAddressGenerator.generate()))
    }
    val canContinue = step != 1 || name.trim().isNotEmpty()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onCancel) { Icon(Icons.Outlined.ArrowBack, "Back") }
            Text(
                if (initialProfile == null) "Create Phone" else "Edit Phone",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            )
        }
        Stepper(step)

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (step) {
                1 -> BasicStep(name) { name = it }
                2 -> NetworkStep(network) { network = it }
                else -> ReviewStep(name, network)
            }
        }

        Row(
            Modifier.padding(18.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedButton(
                onClick = { if (step > 1) step-- else onCancel() },
                modifier = Modifier.weight(1f).heightIn(min = 54.dp),
            ) { Text("Back", color = TextPrimary) }
            GradientButton(
                text = if (step < 3) "Continue ›" else if (initialProfile == null) "Create Phone" else "Save Changes",
                enabled = canContinue,
                onClick = {
                    if (!canContinue) return@GradientButton
                    if (step < 3) step++ else onCreate(name.trim(), network)
                },
                modifier = Modifier.weight(1.25f),
            )
        }
    }
}

@Composable
private fun Stepper(step: Int) {
    val labels = listOf("Basic", "Network", "Review")
    Row(
        Modifier.padding(horizontal = 28.dp, vertical = 4.dp).fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        labels.forEachIndexed { i, label ->
            val complete = i + 1 < step
            val current = i + 1 == step
            val color = if (complete || current) Cyan else TextSubtle
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    shape = MaterialTheme.shapes.extraLarge,
                    color = if (current) Cyan.copy(alpha = .16f) else Surface2,
                    border = BorderStroke(1.dp, if (complete || current) Cyan else Outline),
                ) {
                    Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                        if (complete) Icon(Icons.Outlined.Check, null, tint = Green, modifier = Modifier.size(18.dp))
                        else Text("${i + 1}", color = color, fontWeight = FontWeight.Bold)
                    }
                }
                Text(label, color = color, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun BasicStep(name: String, onName: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("Phone", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(4.dp))
            Text("Every phone uses the built-in Android 10 ARM64 system and the fixed portrait phone format.", color = TextMuted)
        }
        item {
            OutlinedTextField(
                value = name,
                onValueChange = { onName(it.take(60)) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Phone name") },
                placeholder = { Text("Example: Work Phone", color = TextSubtle) },
                leadingIcon = { Icon(Icons.Outlined.Badge, null) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    focusedLabelColor = Cyan,
                    unfocusedBorderColor = Outline,
                    unfocusedLabelColor = TextMuted,
                ),
            )
        }
        item {
            NeonCard(Modifier.fillMaxWidth(), Cyan) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Android, null, tint = Green, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Android 10", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("ARM64 • fixed portrait phone", color = TextMuted)
                    }
                }
            }
        }
    }
}

@Composable
private fun NetworkStep(value: NetworkConfig, onChange: (NetworkConfig) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Network & Privacy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("These settings belong only to this phone.", color = TextMuted)
        }
        item {
            NeonCard(Modifier.fillMaxWidth(), Cyan) {
                Text("Virtual MAC Address", color = Cyan)
                Text(value.virtualMac, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { onChange(value.copy(virtualMac = MacAddressGenerator.generate())) }) {
                    Icon(Icons.Outlined.Refresh, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Generate new MAC")
                }
            }
        }
        item { SectionLabel("MAC Mode") }
        items(MacMode.entries.size) { i ->
            val mode = MacMode.entries[i]
            RadioLine(modeLabel(mode), value.macMode == mode) { onChange(value.copy(macMode = mode)) }
        }
        item { SectionLabel("Connection Mode") }
        items(NetworkMode.entries.size) { i ->
            val mode = NetworkMode.entries[i]
            RadioLine(networkLabel(mode), value.mode == mode) { onChange(value.copy(mode = mode)) }
        }
        if (value.mode == NetworkMode.ENCRYPTED_TUNNEL) {
            item {
                NeonCard(Modifier.fillMaxWidth(), Purple) {
                    Text("Encrypted Tunnel", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = value.exitRegion,
                        onValueChange = { onChange(value.copy(exitRegion = it.take(64))) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("VPN profile / region note") },
                        supportingText = { Text("The actual exit location is controlled by your VPN app.", color = TextMuted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Outline),
                    )
                    ToggleLine("Require VPN DNS", value.dnsProtection) { onChange(value.copy(dnsProtection = it)) }
                    ToggleLine("Kill Switch", value.killSwitch) { onChange(value.copy(killSwitch = it)) }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
}

@Composable
private fun ToggleLine(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), color = TextPrimary)
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun RadioLine(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = MaterialTheme.shapes.large,
        color = if (selected) Cyan.copy(alpha = .09f) else Surface,
        border = BorderStroke(1.dp, if (selected) Cyan else Outline.copy(alpha = .8f)),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Text(text, color = TextPrimary)
        }
    }
}

private fun modeLabel(mode: MacMode) = when (mode) {
    MacMode.KEEP_CURRENT -> "Keep Current"
    MacMode.RANDOM_EVERY_BOOT -> "Random Every Boot"
    MacMode.MANUAL_RESET_ONLY -> "Manual Reset Only"
}

private fun networkLabel(mode: NetworkMode) = when (mode) {
    NetworkMode.DIRECT_NAT -> "Direct / NAT"
    NetworkMode.ENCRYPTED_TUNNEL -> "Encrypted Tunnel"
    NetworkMode.OFFLINE -> "Offline"
}

@Composable
private fun ReviewStep(name: String, network: NetworkConfig) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Review", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TextPrimary) }
        item {
            NeonCard(Modifier.fillMaxWidth()) {
                Text(name.ifBlank { "New Phone" }, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                Text("Android 10 • API 29 • ARM64", color = Cyan, fontWeight = FontWeight.Medium)
                Text("Fixed portrait virtual phone", color = TextMuted)
                Spacer(Modifier.height(10.dp))
                Text(network.virtualMac, color = Cyan, fontWeight = FontWeight.Medium)
                Text("${networkLabel(network.mode)} • ${modeLabel(network.macMode)}", color = TextMuted)
            }
        }
    }
}
