# Third-party notices

Multi Device source uses AndroidX / Kotlin dependencies plus **XZ for Java** (`org.tukaani:xz`) for
first-launch `.xz` decompression.

The fixed Android 10 source URL points to PHH Treble Experimentations / AOSP-derived GSI artifacts.
Those Android system files are downloaded by the installed app and are not redistributed inside
this source ZIP.

Twoyi was inspected only as an open-source architectural reference for rootless Android-container
separation. No Twoyi prebuilt ROM/rootfs, native libraries or binary engine are redistributed here.
No VMOS proprietary code, rootfs, native engine, artwork or libraries are included.

All new Multi Device host/guest runtime sources in this revision are clean-room project code.
