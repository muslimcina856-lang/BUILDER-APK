import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class OwnerPage extends StatefulWidget {
  final String sessionKey; 
  final String username; 
  const OwnerPage({super.key, required this.sessionKey, required this.username});
  @override State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  final List<String> roleOptions = ['admin', 'vip', 'reseller', 'member'];
  String selectedRole = 'member'; 
  int currentPage = 1;
  int itemsPerPage = 25;
  
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;
  
  final Color bgDark = const Color(0xFF1A0000);
  final Color primaryRed = const Color(0xFFC62828); 
  final Color accentRed = const Color(0xFFFF5252); 
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  @override void initState() { super.initState(); sessionKey = widget.sessionKey; _fetchUsers(); }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://akiraxilusia.kennhosting.my.id:1117/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else { _alert("Info", data['message'] ?? 'Gagal memuat user.'); }
    } catch (_) { _alert("Error", "Gagal terhubung ke server."); }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() { 
    setState(() { 
      currentPage = 1; 
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList(); 
    }); 
  }
  
  List<dynamic> _getCurrentPageData() { 
    final start = (currentPage - 1) * itemsPerPage; 
    final end = (start + itemsPerPage); 
    if(filteredList.isEmpty) return []; 
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end); 
  }
  
  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) { _alert("Peringatan", "Masukkan username yang ingin dihapus."); return; }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://akiraxilusia.kennhosting.my.id:1117/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) { _alert("Sukses", "User berhasil dihapus."); deleteController.clear(); _fetchUsers(); }
      else { _alert("Gagal", data['message'] ?? 'Gagal menghapus user.'); }
    } catch (_) { _alert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim(); 
    final p = createPasswordController.text.trim(); 
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) { _alert("Peringatan", "Semua field wajib diisi."); return; }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('http://akiraxilusia.kennhosting.my.id:1117/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole');
      final res = await http.get(url); 
      final data = jsonDecode(res.body);
      if (data['created'] == true) { _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}."); createUsernameController.clear(); createPasswordController.clear(); createDayController.clear(); newUserRole = 'member'; _fetchUsers(); }
      else { _alert("Gagal", data['message'] ?? 'Gagal membuat akun.'); }
    } catch (_) { _alert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim(); 
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) { _alert("Peringatan", "Semua field wajib diisi."); return; }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('http://akiraxilusia.kennhosting.my.id:1117/editUser?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url); 
      final data = jsonDecode(res.body);
      if (data['edited'] == true) { _alert("Sukses", "Durasi berhasil diperbarui."); editUsernameController.clear(); editDayController.clear(); _fetchUsers(); }
      else { _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.'); }
    } catch (_) { _alert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: bgDark, title: Text(title, style: TextStyle(color: primaryWhite)), content: Text(message, style: TextStyle(color: textGrey)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text("OK", style: TextStyle(color: accentRed)))]));
  }

  Widget _buildInput({required String label, required TextEditingController controller, required IconData icon, TextInputType type = TextInputType.text}) {
    return Padding(padding: const EdgeInsets.only(bottom: 20), child: TextField(controller: controller, keyboardType: type, style: TextStyle(color: primaryWhite), decoration: InputDecoration(labelText: label, labelStyle: TextStyle(color: accentRed), prefixIcon: Icon(icon, color: accentRed), filled: true, fillColor: cardGlass, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: borderGlass)))));
  }

  Widget _buildGlassCard({required String title, required IconData icon, required List<Widget> children}) {
    List<Widget> allChildren = [];
    allChildren.add(Row(children: [Icon(icon, color: accentRed), SizedBox(width: 12), Text(title, style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold))]));
    allChildren.add(SizedBox(height: 24));
    allChildren.addAll(children);
    return Container(margin: EdgeInsets.only(bottom: 25), padding: EdgeInsets.all(24), decoration: BoxDecoration(color: cardGlass, borderRadius: BorderRadius.circular(20), border: Border.all(color: borderGlass)), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: allChildren));
  }

  Widget _buildUserItem(Map user) {
    return Container(margin: EdgeInsets.symmetric(vertical: 8), padding: EdgeInsets.all(16), decoration: BoxDecoration(color: cardGlass, borderRadius: BorderRadius.circular(16), border: Border.all(color: borderGlass)), child: Row(children: [Icon(Icons.person, color: accentRed), SizedBox(width: 16), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(user['username'], style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)), Text("ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}", style: TextStyle(color: textGrey, fontSize: 13))])), IconButton(icon: Icon(Icons.delete_outline, color: Colors.redAccent), onPressed: () async { final confirm = await showDialog<bool>(context: context, builder: (_) => AlertDialog(backgroundColor: bgDark, title: Text("Konfirmasi", style: TextStyle(color: primaryWhite)), content: Text("Hapus user ini?", style: TextStyle(color: textGrey)), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Batal")), TextButton(onPressed: () => Navigator.pop(context, true), child: Text("Hapus"))])); if (confirm == true) { deleteController.text = user['username']; _deleteUser(); } })]));
  }

  Widget _buildPagination() {
    if(totalPages <= 1) return SizedBox();
    List<Widget> buttons = [];
    for(int i = 1; i <= totalPages; i++){
      buttons.add(ElevatedButton(onPressed: () => setState(() => currentPage = i), style: ElevatedButton.styleFrom(backgroundColor: currentPage == i ? accentRed : Colors.grey), child: Text("$i")));
    }
    return Wrap(spacing: 8, children: buttons);
  }

  @override Widget build(BuildContext context) {
    List<Widget> userWidgets = [];
    if (isLoading) {
      userWidgets.add(Center(child: CircularProgressIndicator(color: accentRed)));
    } else if (filteredList.isEmpty) {
      userWidgets.add(Text("No users", style: TextStyle(color: textGrey)));
    } else {
      for(var u in _getCurrentPageData()) {
        userWidgets.add(_buildUserItem(u));
      }
      userWidgets.add(SizedBox(height: 10));
      userWidgets.add(_buildPagination());
    }

    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(backgroundColor: bgDark, title: Text("Owner Panel", style: TextStyle(color: primaryWhite))),
      body: Container(
        color: bgDark,
        child: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  Icon(Icons.workspace_premium, color: accentRed, size: 50), 
                  SizedBox(height: 10),
                  Text("OWNER DASHBOARD", style: TextStyle(color: primaryWhite, fontSize: 24, fontWeight: FontWeight.bold)),
                  SizedBox(height: 40),
                  DropdownButton<String>(value: selectedRole, dropdownColor: bgDark, style: TextStyle(color: primaryWhite), items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(), onChanged: (val) { setState(() => selectedRole = val ?? 'member'); _filterAndPaginate(); }),
                  SizedBox(height: 20),
                  _buildGlassCard(title: "USER LIST", icon: Icons.people, children: userWidgets),
                  _buildGlassCard(title: "CREATE ACCOUNT", icon: Icons.person_add, children: [_buildInput(label: "Username", controller: createUsernameController, icon: Icons.person), _buildInput(label: "Password", controller: createPasswordController, icon: Icons.lock), _buildInput(label: "Durasi Hari", controller: createDayController, icon: Icons.calendar_today, type: TextInputType.number), DropdownButton<String>(value: newUserRole, dropdownColor: bgDark, style: TextStyle(color: primaryWhite), items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(), onChanged: (val) => setState(() => newUserRole = val ?? 'member')), SizedBox(height: 20), ElevatedButton(onPressed: isLoading? null : _createAccount, style: ElevatedButton.styleFrom(backgroundColor: accentRed, minimumSize: Size(double.infinity, 50)), child: Text("CREATE ACCOUNT"))]),
                  _buildGlassCard(title: "EXTEND USER", icon: Icons.edit_calendar, children: [_buildInput(label: "Username", controller: editUsernameController, icon: Icons.person), _buildInput(label: "Tambah Hari", controller: editDayController, icon: Icons.add, type: TextInputType.number), SizedBox(height: 20), ElevatedButton(onPressed: isLoading? null : _editUser, style: ElevatedButton.styleFrom(backgroundColor: accentRed, minimumSize: Size(double.infinity, 50)), child: Text("EXTEND"))]),
                  _buildGlassCard(title: "DELETE USER", icon: Icons.person_off, children: [_buildInput(label: "Username Target", controller: deleteController, icon: Icons.person), SizedBox(height: 10), ElevatedButton(onPressed: isLoading? null : _deleteUser, style: ElevatedButton.styleFrom(backgroundColor: Colors.red, minimumSize: Size(double.infinity, 50)), child: Text("DELETE ACCOUNT"))]),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}