import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:npc_life/game/systems/grid_navigator.dart';

void main() {
  test('pathfinding mengelilingi halangan dan sampai ke destinasi', () {
    const Rect obstacle = Rect.fromLTWH(100, 0, 50, 150);
    final GridNavigator navigator = GridNavigator(
      worldWidth: 300,
      worldHeight: 200,
      cellSize: 50,
      obstacles: <Rect>[obstacle],
    );

    final Vector2 destination = Vector2(225, 25);
    final List<Vector2> path = navigator.findPath(
      Vector2(25, 25),
      destination,
    );

    expect(path, isNotEmpty);
    expect(path.last.x, destination.x);
    expect(path.last.y, destination.y);
    for (final Vector2 point in path) {
      expect(
        obstacle.inflate(12).contains(Offset(point.x, point.y)),
        isFalse,
        reason: 'Titik laluan tidak boleh berada di dalam halangan.',
      );
    }
  });

  test('pathfinding tidak menembusi dinding apabila tiada laluan', () {
    const Rect wall = Rect.fromLTWH(100, 0, 50, 200);
    final GridNavigator navigator = GridNavigator(
      worldWidth: 300,
      worldHeight: 200,
      cellSize: 50,
      obstacles: <Rect>[wall],
    );

    final List<Vector2> path = navigator.findPath(
      Vector2(25, 25),
      Vector2(225, 25),
    );

    expect(path, isEmpty);
  });
}
