# NPC LIFE — Code Audit

Tarikh audit: 3 Ogos 2026  
Skop: sumber Flutter/Flame, ujian, data JSON, jadual NPC, dan skrip build Android.

## Penemuan yang dibetulkan

1. `lib/ui/main_menu_screen.dart`
   - `ConstrainedBox` tidak lagi dipanggil sebagai ekspresi `const` dalam lokasi yang gagal pada toolchain sasaran.

2. `lib/ui/game_screen.dart`
   - Dua rujukan `Colors.black65` yang tidak wujud diganti dengan `Color(0xA6000000)`, iaitu hitam dengan alpha 65%.
   - Import Flame yang berada bersama Material menggunakan `hide Colors` untuk mengelakkan resolusi nama palet yang tidak jelas.

3. `lib/game/components/npc_component.dart`
   - Import Flame diasingkan daripada `Colors` Material.

4. `lib/game/components/damageable_object.dart`
   - Import Flame diasingkan daripada `Colors` Material.

5. `lib/game/systems/grid_navigator.dart`
   - `previousDirection` tidak lagi diisytihar `final` kerana nilainya memang perlu dikemas kini dalam gelung penyederhanaan laluan.
   - Jika tiada laluan sah, navigator kini memulangkan laluan kosong dan bukannya mengarahkan NPC menembusi halangan.
   - Titik destinasi tidak lagi ditambah dua kali apabila ia sudah sama dengan titik terakhir grid.

6. Import enjin
   - Import `dart:ui` dan Material yang bertindih dibuang daripada fail berkaitan bagi mengelakkan amaran `unused_import` atau `unnecessary_import`.

7. `tool/bootstrap_and_build.sh`
   - Java 21 disahkan sebelum build.
   - Penukaran package ID hanya menyentuh fail teks yang benar-benar mengandungi package lama.
   - Keystore dan `key.properties` mesti wujud berpasangan.
   - Audit sumber, struktur, dan simulasi dijalankan sebelum `flutter pub get`, `flutter analyze`, ujian, APK, dan AAB.

## Perlindungan audit automatik

`tool/source_audit.py` kini memeriksa:

- semua import projek setempat;
- JSON dan ID data yang dirujuk kod;
- kesahihan semua `Colors.*` yang digunakan;
- tiada `Colors.black65`;
- tiada pola `const ConstrainedBox` yang pernah gagal;
- tiada import UI bertindih;
- tiada pemboleh ubah `final` berinisialisasi yang diberikan nilai semula dalam skopnya;
- tiada penanda merge, TODO kritikal, `UnimplementedError`, atau `print()` dalam sumber Dart;
- konsistensi 11 bangunan, 19 lokasi, 12 NPC, item, dan skema save;
- perlindungan Java 21, keystore, dan penukaran package ID dalam skrip build.

## Ujian tambahan

`test/grid_navigator_test.dart` ditambah untuk memastikan:

- laluan mengelilingi halangan dan sampai ke destinasi;
- laluan mustahil tidak bertukar menjadi pergerakan terus melalui dinding.

## Keputusan audit tempatan

Lulus:

- 30 fail Dart dan lebih 3,000 baris diperiksa;
- delimiter Dart dan string seimbang;
- semua JSON sah;
- semua import setempat ditemui;
- semua deklarasi kelas/enum/mixin/extension unik;
- tiada aksara kawalan atau penanda merge;
- 12 jadual NPC bersambung dari 06:00 hingga 24:00;
- satu hari permainan berada dalam sasaran 10–15 minit sebenar;
- event pertama masih memberi 90 minit permainan sebelum gudang tutup;
- sintaks Bash dan semua skrip Python sah.

## Had pengesahan

Audit ini mengurangkan risiko kesalahan sumber dengan ketara tetapi bukan pengganti compiler sebenar. Persekitaran audit ini tidak mempunyai Flutter SDK dan Android SDK, jadi `flutter analyze`, `flutter test`, dan build APK/AAB sebenar belum dapat dijalankan di sini. Keputusan muktamad perlu datang daripada build semula pada toolchain Flutter/Android yang lengkap.
