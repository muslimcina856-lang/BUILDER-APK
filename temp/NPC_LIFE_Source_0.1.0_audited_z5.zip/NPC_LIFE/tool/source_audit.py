#!/usr/bin/env python3
"""Static, data, and build-script audit for NPC LIFE.

This complements (but does not replace) `flutter analyze`, `flutter test`, and
an actual Android build. It intentionally fails on known source patterns that
have already caused compiler failures in the target toolchain.
"""

from __future__ import annotations

import json
import re
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / "lib"
TEST = ROOT / "test"

errors: list[str] = []
notes: list[str] = []


def fail(message: str) -> None:
    errors.append(message)


def read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        fail(f"Fail UTF-8 tidak sah: {path.relative_to(ROOT)} ({exc})")
        return ""


# 1. Project and YAML/JSON integrity.
required_paths = [
    ROOT / "pubspec.yaml",
    ROOT / "analysis_options.yaml",
    LIB / "main.dart",
    LIB / "game/npc_life_game.dart",
    LIB / "ui/game_screen.dart",
    ROOT / "tool/bootstrap_and_build.sh",
]
for path in required_paths:
    if not path.is_file() or path.stat().st_size == 0:
        fail(f"Fail wajib hilang atau kosong: {path.relative_to(ROOT)}")

pubspec_path = ROOT / "pubspec.yaml"
pubspec_text = read(pubspec_path)
name_match = re.search(r"^name:\s*([A-Za-z0-9_]+)\s*$", pubspec_text, re.MULTILINE)
package_name = name_match.group(1) if name_match else ""
if package_name != "npc_life":
    fail("pubspec.yaml: nama pakej mesti 'npc_life'")

sdk_match = re.search(r"^\s*sdk:\s*['\"]([^'\"]+)['\"]\s*$", pubspec_text, re.MULTILINE)
sdk_constraint = sdk_match.group(1) if sdk_match else ""
if "3.12" not in sdk_constraint:
    fail("pubspec.yaml: kekangan Dart SDK tidak dikunci pada siri 3.12+")

flame_match = re.search(r"^\s*flame:\s*([^\s#]+)", pubspec_text, re.MULTILINE)
preferences_match = re.search(r"^\s*shared_preferences:\s*([^\s#]+)", pubspec_text, re.MULTILINE)
if flame_match is None or flame_match.group(1) != "^1.38.0":
    fail("pubspec.yaml: Flame mesti kekal pada ^1.38.0 untuk audit ini")
if preferences_match is None or preferences_match.group(1) != "^2.5.5":
    fail("pubspec.yaml: shared_preferences mesti kekal pada ^2.5.5 untuk audit ini")

declared_packages = set(
    re.findall(r"^  ([a-zA-Z_][a-zA-Z0-9_]*):", pubspec_text, re.MULTILINE)
)

asset_json: dict[str, object] = {}
for path in sorted((ROOT / "assets/data").glob("*.json")):
    try:
        asset_json[path.name] = json.loads(read(path))
    except json.JSONDecodeError as exc:
        fail(f"JSON tidak sah: {path.relative_to(ROOT)} ({exc})")

for expected in ("events.json", "items.json", "simulation_rules.json"):
    if expected not in asset_json:
        fail(f"Aset data wajib tiada: assets/data/{expected}")

# 2. Dart files, import resolution, known compiler-risk patterns.
dart_files = sorted([*LIB.rglob("*.dart"), *TEST.rglob("*.dart")])
if not dart_files:
    fail("Tiada fail Dart ditemui")

import_re = re.compile(r"^\s*import\s+['\"]([^'\"]+)['\"]", re.MULTILINE)

valid_material_colors = {
    "transparent",
    "black",
    "black87",
    "black54",
    "black45",
    "black38",
    "black26",
    "black12",
    "white",
    "white70",
    "white60",
    "white54",
    "white38",
    "white30",
    "white24",
    "white12",
    "white10",
    "red",
    "pink",
    "purple",
    "deepPurple",
    "indigo",
    "blue",
    "lightBlue",
    "cyan",
    "teal",
    "green",
    "lightGreen",
    "lime",
    "yellow",
    "amber",
    "orange",
    "deepOrange",
    "brown",
    "grey",
    "blueGrey",
}

all_color_members: set[str] = set()
for path in dart_files:
    text = read(path)
    rel = path.relative_to(ROOT)

    if "const ConstrainedBox(" in text:
        fail(f"{rel}: pola 'const ConstrainedBox' dilarang kerana gagal dalam build sasaran")
    if "Colors.black65" in text:
        fail(f"{rel}: Colors.black65 tidak wujud dalam Flutter Material")

    for member in re.findall(r"\bColors\.([A-Za-z_][A-Za-z0-9_]*)", text):
        all_color_members.add(member)
        if member not in valid_material_colors:
            fail(f"{rel}: Colors.{member} tidak berada dalam senarai API Material yang diaudit")

    has_flame = "package:flame/" in text
    has_material = "package:flutter/material.dart" in text
    has_dart_ui = "import 'dart:ui';" in text
    uses_colors = "Colors." in text
    if has_material and has_dart_ui:
        fail(
            f"{rel}: import dart:ui dan material bertindih; kekalkan hanya import yang diperlukan"
        )
    if has_flame and has_material and uses_colors:
        for line_number, line in enumerate(text.splitlines(), 1):
            if "import 'package:flame/" in line and "hide Colors" not in line:
                fail(
                    f"{rel}:{line_number}: import Flame yang berkongsi fail dengan Material Colors "
                    "mesti menggunakan 'hide Colors'"
                )

    for uri in import_re.findall(text):
        if uri.startswith("dart:") or uri.startswith("package:flutter") or uri.startswith("package:flame") or uri.startswith("package:shared_preferences") or uri.startswith("package:flutter_test"):
            continue
        if uri.startswith(f"package:{package_name}/"):
            target = LIB / uri.split("/", 1)[1]
        elif uri.startswith("package:"):
            # Any other package must be explicitly declared.
            imported_package = uri[len("package:") :].split("/", 1)[0]
            if imported_package not in declared_packages:
                fail(f"{rel}: pakej import tidak dinyatakan dalam pubspec: {imported_package}")
            continue
        else:
            target = (path.parent / uri).resolve()
        if not target.is_file():
            fail(f"{rel}: import tidak ditemui: {uri}")

    # Detect a common Dart compile error: an initialized local `final` that is
    # assigned again later in the same indentation scope. This caught the
    # pathfinding `previousDirection` regression found during the full audit.
    lines = text.splitlines()
    for declaration_index, line in enumerate(lines):
        match = re.match(
            r"^(\s*)final\s+(?:[A-Za-z_][\w<>?,. ]*\s+)?([A-Za-z_]\w*)\s*=.*$",
            line,
        )
        if match is None:
            continue
        declaration_indent = len(match.group(1).replace("\t", "  "))
        variable_name = match.group(2)
        assignment_re = re.compile(
            rf"^\s{{{declaration_indent},}}{re.escape(variable_name)}\s*=(?!=)"
        )
        for later_index in range(declaration_index + 1, len(lines)):
            later_line = lines[later_index]
            stripped = later_line.strip()
            later_indent = len(later_line) - len(later_line.lstrip(" "))
            if stripped and later_indent < declaration_indent:
                break
            if assignment_re.match(later_line):
                fail(
                    f"{rel}:{declaration_index + 1}: pemboleh ubah final "
                    f"'{variable_name}' diberikan nilai semula pada baris {later_index + 1}"
                )

# 3. Parse source constants and cross-reference IDs.
town_text = read(LIB / "data/town_data.dart")
item_text = read(LIB / "models/item.dart")
game_text = read(LIB / "game/npc_life_game.dart")

building_section = town_text.split("const List<BuildingDefinition> townBuildings", 1)[-1].split("];") [0]
building_ids = re.findall(r"\bid:\s*'([^']+)'", building_section)
if len(building_ids) != len(set(building_ids)):
    duplicates = [key for key, count in Counter(building_ids).items() if count > 1]
    fail(f"ID bangunan berganda: {duplicates}")
if len(building_ids) != 11:
    fail(f"Dijangka 11 bangunan, ditemui {len(building_ids)}")

location_match = re.search(
    r"const Map<String, WorldPoint> townLocations\s*=\s*<String, WorldPoint>\{(.*?)\n\};",
    town_text,
    re.DOTALL,
)
if location_match is None:
    fail("Tidak dapat membaca townLocations")
    location_ids: list[str] = []
else:
    location_ids = re.findall(r"'([^']+)'\s*:\s*WorldPoint", location_match.group(1))
    if len(location_ids) != len(set(location_ids)):
        duplicates = [key for key, count in Counter(location_ids).items() if count > 1]
        fail(f"ID lokasi berganda: {duplicates}")

npc_section = town_text.split("const List<NpcProfile> npcProfiles", 1)[-1]
npc_ids = re.findall(r"\bNpcProfile\(\s*\n\s*id:\s*'([^']+)'", npc_section)
if len(npc_ids) != 12:
    fail(f"Dijangka 12 NPC, ditemui {len(npc_ids)}")
if len(npc_ids) != len(set(npc_ids)):
    duplicates = [key for key, count in Counter(npc_ids).items() if count > 1]
    fail(f"ID NPC berganda: {duplicates}")

location_refs = re.findall(
    r"(?:homeLocationId|eventResponseLocationId|locationId):\s*'([^']+)'",
    npc_section,
)
location_refs += re.findall(r"townLocations\['([^']+)'\]", game_text)
unknown_locations = sorted(set(location_refs) - set(location_ids))
if unknown_locations:
    fail(f"Rujukan lokasi tidak wujud: {unknown_locations}")

item_map_match = re.search(
    r"const Map<String, ItemDefinition> itemCatalog\s*=\s*<String, ItemDefinition>\{(.*?)\n\};",
    item_text,
    re.DOTALL,
)
if item_map_match is None:
    fail("Tidak dapat membaca itemCatalog")
    item_ids: list[str] = []
else:
    item_ids = re.findall(r"^\s*'([^']+)'\s*:\s*ItemDefinition", item_map_match.group(1), re.MULTILINE)
    internal_item_ids = re.findall(r"\bid:\s*'([^']+)'", item_map_match.group(1))
    if item_ids != internal_item_ids:
        fail(f"Kunci itemCatalog tidak sepadan dengan ItemDefinition.id: {item_ids} vs {internal_item_ids}")
    if len(item_ids) != len(set(item_ids)):
        fail("ID item berganda dalam itemCatalog")

source_item_refs: set[str] = set()
for path in dart_files:
    text = read(path)
    source_item_refs.update(
        re.findall(
            r"(?:itemCount|addItem|removeItem|warehousePrice|buyFromWarehouse)\(\s*'([^']+)'",
            text,
        )
    )
    source_item_refs.update(re.findall(r"itemCatalog\['([^']+)'\]", text))
unknown_items = sorted(source_item_refs - set(item_ids))
if unknown_items:
    fail(f"Rujukan item tidak wujud: {unknown_items}")

items_json = asset_json.get("items.json")
if isinstance(items_json, dict):
    json_item_ids = [str(item.get("id")) for item in items_json.get("items", []) if isinstance(item, dict)]
    if set(json_item_ids) != set(item_ids):
        fail(f"items.json tidak sepadan dengan itemCatalog: JSON={json_item_ids}, Dart={item_ids}")

rules = asset_json.get("simulation_rules.json")
if isinstance(rules, dict):
    expected_snippets = {
        "minutes_per_real_second": "this.minutesPerSecond = 1.2",
        "shop_hours": "minute >= 480 && minute < 1200",
        "warehouse_hours": "state.clock.minute >= 480 && state.clock.minute < 1080",
        "customer_interval_minutes": "< 45",
    }
    combined = read(LIB / "models/game_clock.dart") + "\n" + game_text + "\n" + read(LIB / "game/systems/economy_system.dart")
    for key, snippet in expected_snippets.items():
        if snippet not in combined:
            fail(f"Peraturan {key} dalam JSON tidak dapat dipadankan dengan logik Dart yang dijangka")

# 4. Save schema sanity.
state_text = read(LIB / "models/game_state.dart")
for key in ("clock", "coins", "reputation", "inventory", "relationships", "flags"):
    if f"'{key}'" not in state_text:
        fail(f"Skema save tidak mengandungi kunci: {key}")

# 5. Build script hardening checks.
build_script = read(ROOT / "tool/bootstrap_and_build.sh")
required_build_fragments = [
    "JavaVersion.VERSION_21",
    "flutter pub get",
    "dart format lib test",
    "flutter analyze",
    "flutter test",
    "flutter build apk --release",
    "flutter build appbundle --release",
    "grep -RIl 'com\\.earlxz\\.npc_life'",
    "Keystore and android/key.properties must either both exist or both be absent.",
]
for fragment in required_build_fragments:
    if fragment not in build_script:
        fail(f"Skrip build tiada perlindungan/langkah wajib: {fragment}")
if "find \"$ROOT_DIR/android\" -type f" in build_script and "xargs -0 sed" in build_script:
    fail("Skrip build masih berisiko menjalankan sed pada fail binari Android")

# 6. Basic source hygiene.
for path in dart_files:
    text = read(path)
    rel = path.relative_to(ROOT)
    if "TODO" in text or "FIXME" in text or "UnimplementedError" in text:
        fail(f"{rel}: masih mengandungi TODO/FIXME/UnimplementedError")
    if "print(" in text:
        fail(f"{rel}: print() dilarang oleh analysis_options")

if errors:
    print("SOURCE AUDIT: FAIL")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print("SOURCE AUDIT: PASS")
print(f"- {len(dart_files)} fail Dart / {sum(len(read(p).splitlines()) for p in dart_files)} baris diaudit")
print(f"- {len(building_ids)} bangunan, {len(location_ids)} lokasi, {len(npc_ids)} NPC")
print(f"- Item sah: {', '.join(sorted(item_ids))}")
print(f"- Material Colors sah: {', '.join(sorted(all_color_members))}")
print("- Semua import projek setempat ditemui dan tiada import UI bertindih")
print("- Tiada pemboleh ubah final berinisialisasi yang diberikan nilai semula")
print("- ID data Dart dan JSON konsisten")
print("- Skrip build menggunakan Java 21 dan tidak menyentuh fail binari semasa rename")
print("- Nota: audit ini bukan pengganti flutter analyze/test/build sebenar")
