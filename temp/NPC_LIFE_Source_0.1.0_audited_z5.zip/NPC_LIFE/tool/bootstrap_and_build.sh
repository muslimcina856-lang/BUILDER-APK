#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TOOLING_DIR="$ROOT_DIR/.tooling"
FLUTTER_DIR="$TOOLING_DIR/flutter"
FLUTTER_VERSION="3.44.8"
FLUTTER_ARCHIVE="flutter_linux_${FLUTTER_VERSION}-stable.tar.xz"
FLUTTER_URL="https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/$FLUTTER_ARCHIVE"
FLUTTER_SHA256="672089e001571a9fbb209a495c583580c0c6c73ef98999264ba07fa93ace332d"
RELEASE_DIR="$ROOT_DIR/release"

for command_name in curl tar java keytool python3; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "Missing required command: $command_name" >&2
    exit 1
  fi
done

JAVA_VERSION_LINE="$(java -version 2>&1 | head -n 1)"
JAVA_MAJOR="$(printf '%s' "$JAVA_VERSION_LINE" | sed -E 's/.*version "([0-9]+).*/\1/')"
if ! [[ "$JAVA_MAJOR" =~ ^[0-9]+$ ]] || [ "$JAVA_MAJOR" -lt 21 ]; then
  echo "Java 21 or newer is required. Detected: $JAVA_VERSION_LINE" >&2
  exit 1
fi

if [ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then
  echo "ANDROID_HOME or ANDROID_SDK_ROOT must point to an installed Android SDK." >&2
  exit 1
fi

mkdir -p "$TOOLING_DIR" "$RELEASE_DIR"

if [ ! -x "$FLUTTER_DIR/bin/flutter" ]; then
  ARCHIVE_PATH="$TOOLING_DIR/$FLUTTER_ARCHIVE"
  echo "Downloading Flutter $FLUTTER_VERSION..."
  curl -fL "$FLUTTER_URL" -o "$ARCHIVE_PATH"
  echo "$FLUTTER_SHA256  $ARCHIVE_PATH" | sha256sum -c -
  tar -xf "$ARCHIVE_PATH" -C "$TOOLING_DIR"
  rm -f "$ARCHIVE_PATH"
fi

export PATH="$FLUTTER_DIR/bin:$PATH"
flutter config --no-analytics >/dev/null

echo "Flutter version:"
flutter --version

if [ ! -d "$ROOT_DIR/android" ]; then
  TEMP_DIR="$(mktemp -d)"
  flutter create \
    --platforms=android \
    --org com.earlxz \
    --project-name npc_life \
    "$TEMP_DIR/bootstrap"
  cp -a "$TEMP_DIR/bootstrap/android" "$ROOT_DIR/android"
  cp "$TEMP_DIR/bootstrap/.metadata" "$ROOT_DIR/.metadata"
  rm -rf "$TEMP_DIR"

  while IFS= read -r file_path; do
    sed -i 's/com\.earlxz\.npc_life/com.earlxz.npclife/g' "$file_path"
  done < <(grep -RIl 'com\.earlxz\.npc_life' "$ROOT_DIR/android" || true)

  OLD_KOTLIN_DIR="$ROOT_DIR/android/app/src/main/kotlin/com/earlxz/npc_life"
  NEW_KOTLIN_DIR="$ROOT_DIR/android/app/src/main/kotlin/com/earlxz/npclife"
  if [ -d "$OLD_KOTLIN_DIR" ]; then
    mkdir -p "$NEW_KOTLIN_DIR"
    mv "$OLD_KOTLIN_DIR/MainActivity.kt" "$NEW_KOTLIN_DIR/MainActivity.kt"
    rmdir "$OLD_KOTLIN_DIR" || true
  fi

  sed -i 's/android:label="npc_life"/android:label="NPC LIFE"/' \
    "$ROOT_DIR/android/app/src/main/AndroidManifest.xml"
fi

KEYSTORE_PATH="$ROOT_DIR/android/app/upload-keystore.jks"
KEY_PROPERTIES="$ROOT_DIR/android/key.properties"
KEY_INFO="$RELEASE_DIR/NPC_LIFE_Keystore_Info.txt"

if { [ -f "$KEYSTORE_PATH" ] && [ ! -f "$KEY_PROPERTIES" ]; } || \
   { [ ! -f "$KEYSTORE_PATH" ] && [ -f "$KEY_PROPERTIES" ]; }; then
  echo "Keystore and android/key.properties must either both exist or both be absent." >&2
  echo "Do not delete an existing release keystore; restore its matching key.properties file." >&2
  exit 1
fi

if [ ! -f "$KEYSTORE_PATH" ] && [ ! -f "$KEY_PROPERTIES" ]; then
  KEYSTORE_PASSWORD="$(od -An -N24 -tx1 /dev/urandom | tr -d ' \n')"
  keytool -genkeypair \
    -v \
    -keystore "$KEYSTORE_PATH" \
    -storepass "$KEYSTORE_PASSWORD" \
    -keypass "$KEYSTORE_PASSWORD" \
    -alias npclife \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -dname "CN=NPC LIFE, OU=Release, O=Earlxz, L=Kuala Lumpur, ST=Kuala Lumpur, C=MY"

  cat > "$KEY_PROPERTIES" <<KEYEOF
storePassword=$KEYSTORE_PASSWORD
keyPassword=$KEYSTORE_PASSWORD
keyAlias=npclife
storeFile=upload-keystore.jks
KEYEOF

  cat > "$KEY_INFO" <<INFOEOF
NPC LIFE upload keystore

Alias: npclife
Store password: $KEYSTORE_PASSWORD
Key password: $KEYSTORE_PASSWORD
Keystore file: android/app/upload-keystore.jks

Keep this file and the keystore private. Every future Google Play update must use the same upload key.
INFOEOF
  chmod 600 "$KEY_PROPERTIES" "$KEY_INFO" "$KEYSTORE_PATH"
fi

cat > "$ROOT_DIR/android/app/build.gradle.kts" <<'GRADLEEOF'
import java.io.FileInputStream
import java.util.Properties

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "com.earlxz.npclife"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_21.toString()
    }

    defaultConfig {
        applicationId = "com.earlxz.npclife"
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

flutter {
    source = "../.."
}
GRADLEEOF

cd "$ROOT_DIR"
python3 tool/check_project.py
python3 tool/source_audit.py
python3 tool/simulation_audit.py
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --release
flutter build appbundle --release

cp "$ROOT_DIR/build/app/outputs/flutter-apk/app-release.apk" \
  "$RELEASE_DIR/NPC_LIFE_Release.apk"
cp "$ROOT_DIR/build/app/outputs/bundle/release/app-release.aab" \
  "$RELEASE_DIR/NPC_LIFE_Release.aab"
sha256sum \
  "$RELEASE_DIR/NPC_LIFE_Release.apk" \
  "$RELEASE_DIR/NPC_LIFE_Release.aab" \
  > "$RELEASE_DIR/SHA256SUMS.txt"

echo "Build complete. Files are in: $RELEASE_DIR"
