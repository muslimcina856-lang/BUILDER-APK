import 'package:flutter/material.dart';

import '../app/app_theme.dart';
import '../models/game_state.dart';
import '../services/save_service.dart';
import 'game_screen.dart';

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({required this.saveService, super.key});

  final SaveService saveService;

  @override
  State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen> {
  bool _loading = true;
  bool _hasSave = false;

  @override
  void initState() {
    super.initState();
    _refreshSaveState();
  }

  Future<void> _refreshSaveState() async {
    final bool value = await widget.saveService.hasSave();
    if (!mounted) {
      return;
    }
    setState(() {
      _hasSave = value;
      _loading = false;
    });
  }

  Future<void> _startNewGame() async {
    await widget.saveService.delete();
    if (!mounted) {
      return;
    }
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => GameScreen(
          initialState: GameState(),
          saveService: widget.saveService,
        ),
      ),
    );
    await _refreshSaveState();
  }

  Future<void> _continueGame() async {
    final GameState? state = await widget.saveService.load();
    if (!mounted || state == null) {
      await _refreshSaveState();
      return;
    }
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (BuildContext context) => GameScreen(
          initialState: state,
          saveService: widget.saveService,
        ),
      ),
    );
    await _refreshSaveState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const _MenuBackdrop(),
          SafeArea(
            child: Row(
              children: <Widget>[
                Expanded(
                  flex: 6,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(54, 30, 20, 30),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          'NPC LIFE',
                          style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                                fontSize: 62,
                                shadows: const <Shadow>[
                                  Shadow(offset: Offset(4, 5), blurRadius: 1, color: Colors.black45),
                                ],
                              ),
                        ),
                        const SizedBox(height: 12),
                        ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 620),
                          child: const Text(
                            'Hero menyelamatkan dunia. Penduduk biasa membayar kosnya. '
                            'Urus kedai, jaga hubungan, dan pulihkan Pekan Luma.',
                            style: TextStyle(
                              color: AppTheme.parchment,
                              fontSize: 21,
                              height: 1.4,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(height: 34),
                        SizedBox(
                          width: 280,
                          child: FilledButton.icon(
                            onPressed: _loading ? null : _startNewGame,
                            icon: const Icon(Icons.play_arrow_rounded),
                            label: const Text('MULA BARU'),
                          ),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: 280,
                          child: OutlinedButton.icon(
                            onPressed: !_loading && _hasSave ? _continueGame : null,
                            icon: const Icon(Icons.history_rounded),
                            label: const Text('SAMBUNG'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppTheme.parchment,
                              side: const BorderSide(color: AppTheme.parchment, width: 2),
                              padding: const EdgeInsets.symmetric(vertical: 16),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          _loading
                              ? 'Memeriksa simpanan...'
                              : _hasSave
                                  ? 'Simpanan tempatan ditemui.'
                                  : 'Tiada simpanan lagi.',
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                ),
                const Expanded(flex: 4, child: _TownNoticeBoard()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuBackdrop extends StatelessWidget {
  const _MenuBackdrop();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _MenuBackdropPainter());
  }
}

class _MenuBackdropPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Paint sky = Paint()..color = const Color(0xFF30463A);
    final Paint hill = Paint()..color = const Color(0xFF45654D);
    final Paint road = Paint()..color = const Color(0xFFBDA77B);
    final Paint roof = Paint()..color = const Color(0xFF744238);
    final Paint wall = Paint()..color = const Color(0xFFC9A36D);
    canvas.drawRect(Offset.zero & size, sky);
    canvas.drawOval(Rect.fromLTWH(-100, size.height * 0.46, size.width * 0.8, size.height * 0.7), hill);
    canvas.drawOval(Rect.fromLTWH(size.width * 0.3, size.height * 0.42, size.width * 0.9, size.height * 0.75), hill);
    canvas.drawPath(
      Path()
        ..moveTo(size.width * 0.45, size.height)
        ..quadraticBezierTo(size.width * 0.58, size.height * 0.62, size.width * 0.72, size.height * 0.53)
        ..lineTo(size.width * 0.85, size.height * 0.57)
        ..quadraticBezierTo(size.width * 0.68, size.height * 0.72, size.width * 0.62, size.height)
        ..close(),
      road,
    );
    for (int i = 0; i < 5; i += 1) {
      final double x = size.width * (0.56 + i * 0.085);
      final double y = size.height * (0.38 + (i % 2) * 0.06);
      canvas.drawRect(Rect.fromLTWH(x, y, 80, 65), wall);
      canvas.drawPath(
        Path()
          ..moveTo(x - 8, y)
          ..lineTo(x + 40, y - 34)
          ..lineTo(x + 88, y)
          ..close(),
        roof,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _TownNoticeBoard extends StatelessWidget {
  const _TownNoticeBoard();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Transform.rotate(
        angle: 0.025,
        child: Container(
          width: 330,
          padding: const EdgeInsets.all(26),
          decoration: BoxDecoration(
            color: AppTheme.parchment,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: AppTheme.ink, width: 4),
            boxShadow: const <BoxShadow>[
              BoxShadow(offset: Offset(8, 10), blurRadius: 0, color: Colors.black38),
            ],
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('NOTIS PEKAN LUMA', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              Divider(thickness: 2),
              SizedBox(height: 8),
              Text('• Kedai dibuka 08:00–20:00.'),
              Text('• Gudang ditutup pada 18:00.'),
              Text('• Jauhkan kanak-kanak daripada portal.'),
              Text('• Kerosakan hero perlu disertakan resit.'),
              SizedBox(height: 14),
              Text(
                '“Bandar hidup kerana rutin kecil yang dilakukan dengan baik.”',
                style: TextStyle(fontStyle: FontStyle.italic, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
