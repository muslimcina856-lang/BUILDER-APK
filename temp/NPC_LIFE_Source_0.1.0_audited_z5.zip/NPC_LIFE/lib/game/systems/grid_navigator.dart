import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';

class GridNavigator {
  GridNavigator({
    required this.worldWidth,
    required this.worldHeight,
    required this.obstacles,
    this.cellSize = 50,
  })  : columns = (worldWidth / cellSize).ceil(),
        rows = (worldHeight / cellSize).ceil();

  final double worldWidth;
  final double worldHeight;
  final double cellSize;
  final int columns;
  final int rows;
  final List<Rect> obstacles;

  List<Vector2> findPath(Vector2 start, Vector2 end) {
    final _GridCell startCell = _nearestWalkable(_cellFor(start));
    final _GridCell endCell = _nearestWalkable(_cellFor(end));
    if (startCell == endCell) {
      return <Vector2>[end.clone()];
    }

    final List<_GridCell> open = <_GridCell>[startCell];
    final Set<_GridCell> closed = <_GridCell>{};
    final Map<_GridCell, _GridCell> cameFrom = <_GridCell, _GridCell>{};
    final Map<_GridCell, double> gScore = <_GridCell, double>{startCell: 0};
    final Map<_GridCell, double> fScore = <_GridCell, double>{
      startCell: _heuristic(startCell, endCell),
    };

    while (open.isNotEmpty) {
      open.sort((_GridCell a, _GridCell b) =>
          (fScore[a] ?? double.infinity).compareTo(fScore[b] ?? double.infinity));
      final _GridCell current = open.removeAt(0);
      if (current == endCell) {
        return _reconstruct(cameFrom, current, end);
      }
      closed.add(current);

      for (final _GridCell neighbor in _neighbors(current)) {
        if (closed.contains(neighbor) || _isBlocked(neighbor)) {
          continue;
        }
        final double tentative = (gScore[current] ?? double.infinity) + 1;
        if (tentative < (gScore[neighbor] ?? double.infinity)) {
          cameFrom[neighbor] = current;
          gScore[neighbor] = tentative;
          fScore[neighbor] = tentative + _heuristic(neighbor, endCell);
          if (!open.contains(neighbor)) {
            open.add(neighbor);
          }
        }
      }
    }

    return <Vector2>[];
  }

  List<Vector2> _reconstruct(
    Map<_GridCell, _GridCell> cameFrom,
    _GridCell current,
    Vector2 preciseEnd,
  ) {
    final List<_GridCell> cells = <_GridCell>[current];
    while (cameFrom.containsKey(current)) {
      current = cameFrom[current]!;
      cells.add(current);
    }
    final List<Vector2> result = cells.reversed.map(_centerFor).toList(growable: true);
    if (result.isNotEmpty) {
      result.removeAt(0);
    }
    if (result.isEmpty || result.last.distanceTo(preciseEnd) > 0.01) {
      result.add(preciseEnd.clone());
    }
    return _simplify(result);
  }

  List<Vector2> _simplify(List<Vector2> path) {
    if (path.length < 3) {
      return path;
    }
    final List<Vector2> simplified = <Vector2>[path.first];
    Vector2 previousDirection = (path[1] - path[0])..normalize();
    for (int i = 1; i < path.length - 1; i += 1) {
      final Vector2 direction = (path[i + 1] - path[i])..normalize();
      if ((direction - previousDirection).length > 0.01) {
        simplified.add(path[i]);
      }
      previousDirection = direction;
    }
    simplified.add(path.last);
    return simplified;
  }

  Iterable<_GridCell> _neighbors(_GridCell cell) sync* {
    const List<_GridCell> directions = <_GridCell>[
      _GridCell(1, 0),
      _GridCell(-1, 0),
      _GridCell(0, 1),
      _GridCell(0, -1),
    ];
    for (final _GridCell direction in directions) {
      final _GridCell candidate = _GridCell(cell.x + direction.x, cell.y + direction.y);
      if (candidate.x >= 0 &&
          candidate.y >= 0 &&
          candidate.x < columns &&
          candidate.y < rows) {
        yield candidate;
      }
    }
  }

  _GridCell _cellFor(Vector2 point) => _GridCell(
        (point.x / cellSize).floor().clamp(0, columns - 1).toInt(),
        (point.y / cellSize).floor().clamp(0, rows - 1).toInt(),
      );

  Vector2 _centerFor(_GridCell cell) => Vector2(
        cell.x * cellSize + cellSize / 2,
        cell.y * cellSize + cellSize / 2,
      );

  bool _isBlocked(_GridCell cell) {
    final Vector2 center = _centerFor(cell);
    final Offset point = Offset(center.x, center.y);
    return obstacles.any((Rect obstacle) => obstacle.inflate(12).contains(point));
  }

  _GridCell _nearestWalkable(_GridCell origin) {
    if (!_isBlocked(origin)) {
      return origin;
    }
    for (int radius = 1; radius < math.max(columns, rows); radius += 1) {
      for (int x = origin.x - radius; x <= origin.x + radius; x += 1) {
        for (int y = origin.y - radius; y <= origin.y + radius; y += 1) {
          final _GridCell candidate = _GridCell(x, y);
          if (x >= 0 && y >= 0 && x < columns && y < rows && !_isBlocked(candidate)) {
            return candidate;
          }
        }
      }
    }
    return origin;
  }

  double _heuristic(_GridCell a, _GridCell b) =>
      (a.x - b.x).abs().toDouble() + (a.y - b.y).abs().toDouble();
}

class _GridCell {
  const _GridCell(this.x, this.y);

  final int x;
  final int y;

  @override
  bool operator ==(Object other) => other is _GridCell && other.x == x && other.y == y;

  @override
  int get hashCode => Object.hash(x, y);
}
