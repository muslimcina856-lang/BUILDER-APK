import 'dart:ui';

import 'package:flame/components.dart';

import '../../data/town_data.dart';

class TownGround extends PositionComponent {
  TownGround() : super(size: Vector2(townWidth, townHeight));

  final Paint _grass = Paint()..color = const Color(0xFF7D9B63);
  final Paint _grassAlt = Paint()..color = const Color(0xFF78935F);
  final Paint _road = Paint()..color = const Color(0xFFC9B58A);
  final Paint _roadEdge = Paint()
    ..color = const Color(0xFFA28A61)
    ..style = PaintingStyle.stroke
    ..strokeWidth = 5;
  final Paint _water = Paint()..color = const Color(0xFF79AFC1);

  @override
  void render(Canvas canvas) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.x, size.y), _grass);
    for (int x = 0; x < townWidth; x += 160) {
      for (int y = 0; y < townHeight; y += 160) {
        if ((x ~/ 160 + y ~/ 160).isEven) {
          canvas.drawRect(Rect.fromLTWH(x.toDouble(), y.toDouble(), 160, 160), _grassAlt);
        }
      }
    }

    final List<RRect> roads = <RRect>[
      RRect.fromRectAndRadius(const Rect.fromLTWH(0, 510, 1800, 180), const Radius.circular(24)),
      RRect.fromRectAndRadius(const Rect.fromLTWH(820, 0, 170, 1200), const Radius.circular(24)),
      RRect.fromRectAndRadius(const Rect.fromLTWH(230, 260, 1450, 120), const Radius.circular(20)),
      RRect.fromRectAndRadius(const Rect.fromLTWH(250, 720, 1350, 120), const Radius.circular(20)),
    ];
    for (final RRect road in roads) {
      canvas.drawRRect(road, _road);
      canvas.drawRRect(road, _roadEdge);
    }

    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(0, 1050, 1800, 120), const Radius.circular(20)),
      _water,
    );

    final Paint plaza = Paint()..color = const Color(0xFFD8C69D);
    final Paint plazaEdge = Paint()
      ..color = const Color(0xFF9F8A65)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6;
    canvas.drawCircle(const Offset(905, 600), 190, plaza);
    canvas.drawCircle(const Offset(905, 600), 190, plazaEdge);

    final Paint garden = Paint()..color = const Color(0xFF5F874E);
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(480, 470, 180, 260), const Radius.circular(30)),
      garden,
    );
  }
}
