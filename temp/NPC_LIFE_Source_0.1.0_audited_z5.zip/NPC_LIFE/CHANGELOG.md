# Changelog

## 0.1.0 - Vertical Slice

- Added a playable top-down town built with Flame components.
- Added player movement, world collision, camera follow, and touch controls.
- Added twelve named NPCs with jobs, homes, daily schedules, contextual dialogue, and emergency behavior.
- Added game time, shop attendance, automatic customer sales, warehouse stock, scarcity pricing, and daily accounting.
- Added the first hero-caused town event, persistent damage, material-based repair, reputation, and relationship consequences.
- Added local save/load, autosave points, end-of-day summaries, and app lifecycle saving.
- Added unit tests for time, state serialization, economy constraints, and event triggering.

## 0.1.0 Audit Fix

- Fixed an initialized `final` variable that was reassigned in path simplification.
- Prevented pathfinding from falling back to movement through blocked buildings.
- Removed redundant UI imports that could trigger analyzer warnings.
- Hardened Flutter Material color resolution alongside Flame imports.
- Hardened the Android build script for Java 21, release-key consistency, and text-only package renaming.
- Added a full source audit and pathfinding regression tests.
