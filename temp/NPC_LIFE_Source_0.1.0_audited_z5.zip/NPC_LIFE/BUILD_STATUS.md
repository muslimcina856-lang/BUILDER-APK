# Build Status

Source milestone: **0.1.0 vertical slice — audited revision**.

The first external debug build exposed three compiler errors in the menu and UI color declarations. Those errors have been corrected. A later full-source audit also found and corrected an initialized `final` variable that was reassigned inside pathfinding.

Current local audit status:

- source/data audit: PASS;
- Dart delimiter and UTF-8 scan: PASS;
- NPC schedule audit: PASS;
- Bash syntax check: PASS;
- Python audit-script compilation: PASS;
- Flutter analyze/test/build: NOT RUN in this environment.

This execution environment does not contain Flutter or the Android SDK. The included `tool/bootstrap_and_build.sh` requires Java 21 and an installed Android SDK, then automates Flutter setup, Android wrapper generation, formatting, analysis, tests, release signing, APK build, and AAB build.
