package com.railway.deck.linux

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * Embedded Linux (experimental) + **proot performance optimisations**.
 *
 * Optimisations:
 * - PROOT_TMP_DIR on app private storage (required + faster than /tmp)
 * - Minimal bind mounts (only /dev, /proc — skip /sys unless needed)
 * - PROOT_NO_SECCOMP=1 when helpful on Android
 * - link2symlink for fewer heavy path translations on create
 * - Kill-on-exit to avoid zombie processes
 * - Reuse extracted rootfs (no re-extract if ready)
 * - TMPDIR/HOME inside rootfs
 * - Single-thread friendly PATH
 */
class EmbeddedLinuxEnv(private val context: Context) {

    companion object {
        private const val TAG = "EmbeddedLinux"
    }

    private val baseDir = File(context.filesDir, "linux").also { it.mkdirs() }
    private val rootfsDir = File(baseDir, "rootfs")
    private val binDir = File(baseDir, "bin").also { it.mkdirs() }
    private val prootTmpDir = File(baseDir, "proot-tmp").also { it.mkdirs() }
    private val markerFile = File(baseDir, ".ready")

    private val prootFile get() = File(binDir, "proot")
    private val railwayFile get() = File(rootfsDir, "usr/local/bin/railway")

    fun isReady(): Boolean {
        if (!markerFile.exists()) return false
        val hasShell = File(rootfsDir, "bin/sh").exists() || File(rootfsDir, "bin/busybox").exists()
        return rootfsDir.exists() && hasShell &&
            prootFile.exists() && prootFile.canExecute() &&
            railwayFile.exists() && railwayFile.canExecute()
    }

    fun ensureReady(onProgress: (Float, String) -> Unit): Result<Unit> {
        return try {
            if (isReady()) {
                onProgress(1f, "Environment sudah siap")
                return Result.success(Unit)
            }

            val abi = preferredAbi()
            onProgress(0.08f, "Extract assets (ABI: $abi)...")

            // Alpine
            onProgress(0.12f, "Extract Alpine rootfs...")
            val alpineTar = File(baseDir, "alpine.tar.gz")
            copyAsset("linux/alpine-aarch64.tar.gz", alpineTar)
            if (rootfsDir.exists()) rootfsDir.deleteRecursively()
            rootfsDir.mkdirs()
            extractTarGz(alpineTar, rootfsDir)
            alpineTar.delete()
            onProgress(0.48f, "Rootfs OK")

            // proot
            onProgress(0.52f, "Install proot...")
            val prootAsset = if (abi == "x86_64") "linux/proot-x86_64" else "linux/proot-aarch64"
            copyAsset(prootAsset, prootFile)
            prootFile.setExecutable(true, false)
            chmod755(prootFile)
            onProgress(0.65f, "proot OK")

            // Railway CLI
            onProgress(0.70f, "Install Railway CLI...")
            val railwayTar = File(baseDir, "railway.tar.gz")
            copyAsset("linux/railway.tar.gz", railwayTar)
            File(rootfsDir, "usr/local/bin").mkdirs()
            extractNamedBinaryFromTarGz(railwayTar, "railway", railwayFile)
            railwayTar.delete()
            railwayFile.setExecutable(true, false)
            chmod755(railwayFile)
            onProgress(0.88f, "Railway CLI OK")

            // Fast dirs inside rootfs
            File(rootfsDir, "tmp").mkdirs()
            File(rootfsDir, "root").mkdirs()
            File(rootfsDir, "root/project").mkdirs()
            File(rootfsDir, "root/.railway").mkdirs()
            prootTmpDir.mkdirs()

            // DNS for network inside proot (railway login / up)
            writeResolvConf()

            markerFile.writeText("ready")
            onProgress(1f, "Siap (optimised proot)")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "ensureReady failed", e)
            Result.failure(e)
        }
    }

    fun railway(args: List<String>, timeoutSec: Long = 180): CmdResult {
        if (!isReady()) return CmdResult(false, "", "Environment belum siap — Setup dulu")

        return try {
            // Clean proot tmp occasionally for performance
            if (prootTmpDir.listFiles()?.size ?: 0 > 200) {
                prootTmpDir.listFiles()?.forEach { it.deleteRecursively() }
            }

            val cmd = buildProotCommand(listOf("/usr/local/bin/railway") + args)
            Log.i(TAG, "exec: ${cmd.joinToString(" ")}")

            val pb = ProcessBuilder(cmd)
                .directory(baseDir)
                .redirectErrorStream(true)

            applyProotEnv(pb.environment())

            val process = pb.start()
            val finished = process.waitFor(timeoutSec, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                return CmdResult(false, "", "Timeout")
            }
            val out = process.inputStream.bufferedReader().readText().trim()
            val code = process.exitValue()
            CmdResult(code == 0, out, if (code != 0) out else null, code)
        } catch (e: Exception) {
            CmdResult(false, "", e.message)
        }
    }

    fun copyProjectAndUp(localProjectDir: File): CmdResult {
        val dest = File(rootfsDir, "root/project")
        return try {
            // Faster: delete only if exists, then copy
            if (dest.exists()) dest.deleteRecursively()
            dest.mkdirs()
            localProjectDir.copyRecursively(dest, overwrite = true)
            // Run from project dir via -w
            railwayInWorkdir("/root/project", listOf("up", "--detach"), 300)
        } catch (e: Exception) {
            CmdResult(false, "", e.message)
        }
    }

    fun railwayInWorkdir(workdir: String, args: List<String>, timeoutSec: Long = 180): CmdResult {
        if (!isReady()) return CmdResult(false, "", "Environment belum siap")
        return try {
            val cmd = buildProotCommand(
                args = listOf("/usr/local/bin/railway") + args,
                workdir = workdir
            )
            val pb = ProcessBuilder(cmd).directory(baseDir).redirectErrorStream(true)
            applyProotEnv(pb.environment())
            val process = pb.start()
            if (!process.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                process.destroyForcibly()
                return CmdResult(false, "", "Timeout")
            }
            val out = process.inputStream.bufferedReader().readText().trim()
            val code = process.exitValue()
            CmdResult(code == 0, out, if (code != 0) out else null, code)
        } catch (e: Exception) {
            CmdResult(false, "", e.message)
        }
    }

    /**
     * Optimised proot argv:
     * -0          : fake root (needed for many package ops)
     * -r rootfs   : root
     * -b /dev,/proc : minimal binds (skip /sys for less overhead)
     * -w          : working directory inside rootfs
     * --kill-on-exit : cleanup child processes
     * -L          : force absolute path resolution (can help consistency)
     */
    private fun buildProotCommand(args: List<String>, workdir: String = "/root"): List<String> {
        return buildList {
            add(prootFile.absolutePath)
            add("--kill-on-exit")
            add("-0")
            add("-r")
            add(rootfsDir.absolutePath)
            // Minimal mounts — fewer binds = less overhead
            add("-b")
            add("/dev")
            add("-b")
            add("/proc")
            // Optional: bind app cache for faster temp if needed
            // add("-b"); add("${context.cacheDir.absolutePath}:/cache")
            add("-w")
            add(workdir)
            // link2symlink reduces expensive fake hardlinks on Android
            add("-l")
            addAll(args)
        }
    }

    private fun applyProotEnv(env: MutableMap<String, String>) {
        env["PATH"] = "/usr/local/bin:/usr/bin:/bin"
        env["HOME"] = "/root"
        env["TERM"] = "xterm-256color"
        env["TMPDIR"] = "/tmp"
        env["TEMP"] = "/tmp"
        env["TMP"] = "/tmp"
        // Critical for portable proot on Android
        env["PROOT_TMP_DIR"] = prootTmpDir.absolutePath
        // Reduce seccomp overhead / compatibility on some kernels
        env["PROOT_NO_SECCOMP"] = "1"
        // Avoid verbose debug (slower I/O)
        env.remove("PROOT_VERBOSE")
        env.remove("PROOT_DEBUG")
    }

    private fun writeResolvConf() {
        try {
            val resolv = File(rootfsDir, "etc/resolv.conf")
            resolv.parentFile?.mkdirs()
            resolv.writeText("nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
        } catch (e: Exception) {
            Log.w(TAG, "resolv.conf: ${e.message}")
        }
    }

    private fun preferredAbi(): String {
        val abis = Build.SUPPORTED_ABIS
        return when {
            abis.any { it.contains("arm64") } -> "aarch64"
            abis.any { it.contains("x86_64") } -> "x86_64"
            else -> "aarch64"
        }
    }

    private fun copyAsset(assetPath: String, dest: File) {
        context.assets.open(assetPath).use { input ->
            dest.parentFile?.mkdirs()
            FileOutputStream(dest).use { output -> input.copyTo(output) }
        }
    }

    private fun extractTarGz(tarGz: File, destDir: File) {
        val p = ProcessBuilder("tar", "-xzf", tarGz.absolutePath, "-C", destDir.absolutePath)
            .redirectErrorStream(true).start()
        val ok = p.waitFor(180, TimeUnit.SECONDS)
        if (!ok || p.exitValue() != 0) {
            val err = p.inputStream.bufferedReader().readText()
            throw Exception("tar extract gagal: $err")
        }
    }

    private fun extractNamedBinaryFromTarGz(tarGz: File, name: String, outFile: File) {
        val tmp = File(baseDir, "extract_tmp").also {
            it.deleteRecursively()
            it.mkdirs()
        }
        val p = ProcessBuilder("tar", "-xzf", tarGz.absolutePath, "-C", tmp.absolutePath)
            .redirectErrorStream(true).start()
        p.waitFor(60, TimeUnit.SECONDS)
        val found = tmp.walkTopDown().firstOrNull { it.isFile && it.name == name }
            ?: throw Exception("Binary '$name' tak jumpa")
        outFile.parentFile?.mkdirs()
        found.copyTo(outFile, overwrite = true)
        tmp.deleteRecursively()
    }

    private fun chmod755(f: File) {
        try {
            Runtime.getRuntime().exec(arrayOf("chmod", "755", f.absolutePath)).waitFor()
        } catch (_: Exception) {
            f.setExecutable(true, false)
        }
    }

    data class CmdResult(
        val success: Boolean,
        val output: String,
        val error: String? = null,
        val exitCode: Int = -1
    )
}
