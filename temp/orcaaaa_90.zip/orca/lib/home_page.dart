import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  String? key;
  late List<Map<String, dynamic>> bugs;
  String selectedBugId = "";
  final targetController = TextEditingController();
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    bugs = widget.listBug;
    selectedBugId = bugs.isNotEmpty ? bugs[0]['bug_id'] : "";
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  String? formatPhoneNumber(String input) {
    String cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0')) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    key = widget.sessionKey;

    if (target == null || key == null || target.isEmpty) {
      _showAlert("❌ Invalid Number", "Gunakan nomor dengan awalan kode negara.\nContoh: +62, 1, 44. Format seperti 08xxxx tidak diperbolehkan.");
      return;
    }

    try {
      final url = Uri.parse("http://kizuuserver3.panel-freefire.biz.id:3021/sendBug?key=$key&target=$target&bug=$selectedBugId");
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "You are still in cooldown.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Invalid Key", "Key is invalid. Please log in again.");
      } else if (data["sended"] == false) {
        _showAlert("🔧 Failed", "WhatsApp is under maintenance.");
      } else {
        _showAlert("✅ Success", "Bug sent to $target successfully.");
      }
    } catch (_) {
      _showAlert("❌ Failed", "Failed to send bug. Please try again.");
    }
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title,
            style: const TextStyle(
              color: Colors.blue,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            )),
        content: Text(message,
            style: const TextStyle(
              color: Colors.blueAccent,
              fontSize: 16,
              fontFamily: 'ShareTechMono',
            )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.blue)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    super.dispose();
  }

  Widget _hoverCard({required Widget child}) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          )
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Attack Menu", style: TextStyle(fontFamily: 'Orbitron', color: Colors.blue)),
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.blue),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              FadeTransition(
                opacity: Tween(begin: 0.6, end: 2.0).animate(_controller),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue.withOpacity(0.5),
                        blurRadius: 20,
                        spreadRadius: 5,
                      )
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/logo.jpg',
                      height: 180,
                      width: 180,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 30),

              // === TITLE ===
              const Text(
                "Select Target & Bug",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  color: Colors.blue,
                  shadows: [
                    Shadow(
                      color: Colors.blue,
                      blurRadius: 10,
                      offset: Offset(0, 1),
                    )
                  ],
                ),
              ),
              Divider(color: Colors.blue, thickness: 0.4),
              const SizedBox(height: 30),

              // === CARD INPUT ===
              _hoverCard(
                child: _inputField(
                  controller: targetController,
                  hint: "Target number (e.g. +62 812xxxx)",
                ),
              ),
              const SizedBox(height: 25),

              // === CARD DROPDOWN ===
              _hoverCard(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.black, Colors.black],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: Colors.blue, width: 1.4),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      dropdownColor: Colors.black,
                      value: selectedBugId,
                      isExpanded: true,
                      iconEnabledColor: Colors.blue,
                      style: const TextStyle(color: Colors.blue),
                      items: bugs.map((bug) {
                        return DropdownMenuItem<String>(
                          value: bug['bug_id'],
                          child: Text(
                            bug['bug_name'],
                            style: const TextStyle(color: Colors.blue),
                          ),
                        );
                      }).toList(),
                      onChanged: (val) {
                        setState(() {
                          selectedBugId = val!;
                        });
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 40),

              // === CARD BUTTON ===
              _hoverCard(
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _sendBug,
                    icon: const Icon(Icons.send, color: Colors.black),
                    label: const Text(
                      "SEND BUG",
                      style: TextStyle(
                        fontSize: 16,
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        color: Colors.black,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      elevation: 4,
                      shadowColor: Colors.blue.withOpacity(0.6),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _inputField({required TextEditingController controller, required String hint}) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.blue),
      cursorColor: Colors.blue,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.blueAccent),
        filled: true,
        fillColor: Colors.black45,
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.blue),
          borderRadius: BorderRadius.circular(15),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.blue, width: 2),
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }
}