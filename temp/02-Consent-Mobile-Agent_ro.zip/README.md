# ALZZXNXX Consent Mobile Agent v2.0

Android lab agent that connects to the ALZZXNXX dashboard after explicit consent.

Features:
- C2 registration + per-agent token
- heartbeat
- camera permission request
- Android system file picker
- event logging
- visible consent UI
- no hidden capture, arbitrary shell, stealth persistence, or background remote control

Open this directory in Android Studio and build the debug APK.
Enter the C2 URL, tick consent, then Connect.
