package com.alzzxnxx.mobileagent
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity:AppCompatActivity(){
 private val id=UUID.randomUUID().toString(); var base=""; var token=""; lateinit var st:TextView
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);st=findViewById(R.id.status)
 findViewById<Button>(R.id.connect).setOnClickListener{
  if(!findViewById<CheckBox>(R.id.consent).isChecked){st.text="CONSENT REQUIRED";return@setOnClickListener}
  base=findViewById<EditText>(R.id.url).text.toString().trimEnd('/');register()
 }
 findViewById<Button>(R.id.camera).setOnClickListener{
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
   ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),50)
  else event("CAMERA_PERMISSION","User initiated camera permission flow")
 }
 findViewById<Button>(R.id.file).setOnClickListener{
  startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE)},60)
 }
 }
 private fun register(){thread{try{
  val name=findViewById<EditText>(R.id.name).text.toString().ifBlank{"LAB-ANDROID-01"}
  val res=post("/api/register","""{"agent_id":"$id","name":"${esc(name)}","platform":"Android","version":"2.0","consent":true}""")
  token=Regex("\"token\"\\s*:\\s*\"([^\"]+)\"").find(res)?.groupValues?.get(1) ?: throw Exception("Token missing")
  runOnUiThread{st.text="CONNECTED • $id"}
  while(true){Thread.sleep(10000);try{post("/api/heartbeat","""{"agent_id":"$id","token":"$token"}""")}catch(_:Exception){}}
 }catch(e:Exception){runOnUiThread{st.text="CONNECTION FAILED: ${e.message}"}}}}
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==60&&c==Activity.RESULT_OK)event("FILE_SELECTED","User selected a file with Android system picker")}
 private fun event(k:String,v:String){if(base.isBlank()||token.isBlank())return;thread{try{post("/api/event","""{"agent_id":"$id","token":"$token","kind":"$k","detail":"${esc(v)}"}""")}catch(_:Exception){}}}
 private fun post(path:String,body:String):String{val c=URL(base+path).openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.connectTimeout=8000;c.readTimeout=8000;c.outputStream.use{it.write(body.toByteArray())};val code=c.responseCode;if(code !in 200..299)throw Exception("HTTP $code");val out=c.inputStream.bufferedReader().readText();c.disconnect();return out}
 private fun esc(s:String)=s.replace("\\","\\\\").replace("\"","\\\"")
}
