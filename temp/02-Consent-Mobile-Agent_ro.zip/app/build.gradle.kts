plugins { id("com.android.application") }
android { namespace="com.alzzxnxx.mobileagent"; compileSdk=35
 defaultConfig { applicationId="com.alzzxnxx.mobileagent"; minSdk=26; targetSdk=35; versionCode=2; versionName="2.0" } }
dependencies { implementation("androidx.core:core-ktx:1.16.0"); implementation("androidx.appcompat:appcompat:1.7.0") }
