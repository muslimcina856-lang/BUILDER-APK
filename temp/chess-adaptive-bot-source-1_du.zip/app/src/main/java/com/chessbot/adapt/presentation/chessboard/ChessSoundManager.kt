package com.chessbot.adapt.presentation.chessboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.*
import kotlin.random.Random

/**
 * Menjana bunyi catur secara programatik (tiada fail audio diperlukan).
 * Dua bunyi: letak bidak (place) dan tangkap bidak (capture).
 */
class ChessSoundManager(context: Context) {

    private val sampleRate = 44100
    private var placeTrack:   AudioTrack? = null
    private var captureTrack: AudioTrack? = null

    init {
        runCatching {
            placeTrack   = buildTrack(generatePlace())
            captureTrack = buildTrack(generateCapture())
        }
    }

    /** Bunyi letak bidak — "krek" pendek dan kering */
    fun playPlace()   = play(placeTrack)

    /** Bunyi tangkap bidak — lebih berat dan dalam */
    fun playCapture() = play(captureTrack)

    fun release() {
        runCatching { placeTrack?.release() }
        runCatching { captureTrack?.release() }
        placeTrack   = null
        captureTrack = null
    }

    // ─── private ─────────────────────────────────────────────────────────────

    private fun play(track: AudioTrack?) {
        runCatching {
            track?.let {
                if (it.state == AudioTrack.STATE_INITIALIZED) {
                    it.stop()
                    it.reloadStaticData()
                    it.play()
                }
            }
        }
    }

    private fun buildTrack(buf: ShortArray): AudioTrack {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        return AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(buf.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
            .also { it.write(buf, 0, buf.size) }
    }

    /** Kayu keras tipis — "krek" frekuensi tinggi, redam cepat ~90ms */
    private fun generatePlace(): ShortArray {
        val n = sampleRate * 90 / 1000
        val buf = ShortArray(n)
        val rng = Random(42)
        for (i in buf.indices) {
            val t   = i.toFloat() / sampleRate
            val env = exp(-40f * t)
            // Harmonik kayu: 350, 700, 1050 Hz + noise percussif
            val sig = sin(2f * PI.toFloat() * 350f * t) * 0.30f +
                      sin(2f * PI.toFloat() * 700f * t) * 0.20f +
                      sin(2f * PI.toFloat() * 1050f * t)* 0.10f +
                      (rng.nextFloat() * 2f - 1f)       * 0.40f
            buf[i]  = (sig * env * 22_000f)
                .toInt().coerceIn(-32_767, 32_767).toShort()
        }
        return buf
    }

    /** Kayu tebal — "thud" lebih rendah dan berat ~130ms, bunyi dua kali ganda */
    private fun generateCapture(): ShortArray {
        val n   = sampleRate * 130 / 1000
        val buf = ShortArray(n)
        val rng = Random(7)
        for (i in buf.indices) {
            val t    = i.toFloat() / sampleRate
            val env  = exp(-24f * t)
            // Impak pertama + gema kecil di ~30ms
            val echo = if (t > 0.03f) exp(-50f * (t - 0.03f)) * 0.25f else 0f
            val sig  = sin(2f * PI.toFloat() * 210f * t) * 0.40f +
                       sin(2f * PI.toFloat() * 420f * t) * 0.25f +
                       sin(2f * PI.toFloat() * 630f * t) * 0.12f +
                       (rng.nextFloat() * 2f - 1f)        * 0.23f
            buf[i]   = (sig * (env + echo) * 26_000f)
                .toInt().coerceIn(-32_767, 32_767).toShort()
        }
        return buf
    }
}
