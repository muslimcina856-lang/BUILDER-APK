package com.chessbot.adapt.presentation.chessboard

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.chessbot.adapt.domain.model.*
import kotlin.math.PI

@Composable
fun ChessBoard3DView(
    board:          Board?,
    selectedSquare: Square?,
    validMoves:     List<Move>,
    lastMove:       Move?,
    isCheck:        Boolean,
    checkColor:     com.chessbot.adapt.domain.model.Color?,
    playerColor:    com.chessbot.adapt.domain.model.Color,
    boardSize:      Dp = 360.dp,
    onSquareTap:    (Square) -> Unit
) {
    // ── Sound ────────────────────────────────────────────────────────────────
    val context      = LocalContext.current
    val soundManager = remember { ChessSoundManager(context) }
    DisposableEffect(Unit) { onDispose { soundManager.release() } }

    // Track board sebelum move untuk detect capture
    var prevBoard by remember { mutableStateOf<Board?>(null) }

    // ── Camera — reset bila player side tukar ────────────────────────────────
    val initTheta = if (playerColor == com.chessbot.adapt.domain.model.Color.WHITE)
        PI.toFloat() * 1.2f else PI.toFloat() * 0.2f

    var camTheta by remember(playerColor) { mutableFloatStateOf(initTheta) }
    var camPhi   by remember { mutableFloatStateOf(PI.toFloat() / 3.2f) }

    // ── Piece lift animation (spring) ────────────────────────────────────────
    val selLift by animateFloatAsState(
        targetValue   = if (selectedSquare != null) 0.48f else 0f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow),
        label         = "selLift"
    )

    // ── Move arc animation ───────────────────────────────────────────────────
    var animMove     by remember { mutableStateOf<Move?>(null) }
    var animProgress by remember { mutableFloatStateOf(1f) }

    // PENTING: LaunchedEffect(lastMove) mesti SEBELUM LaunchedEffect(board)
    // supaya prevBoard masih board lama ketika sound detection
    LaunchedEffect(lastMove) {
        lastMove ?: return@LaunchedEffect

        // Detect capture: cek prevBoard (sebelum move) ada bidak kat destinasi
        val isCapture = prevBoard?.squares
            ?.getOrNull(lastMove.toSquare.rank)
            ?.getOrNull(lastMove.toSquare.file) != null

        // Main bunyi
        if (isCapture) soundManager.playCapture() else soundManager.playPlace()

        // Animate pergerakan bidak (lebih slow, lebih natural)
        animMove     = lastMove
        animProgress = 0f
        animate(
            initialValue = 0f,
            targetValue  = 1f,
            animationSpec = tween(
                durationMillis = 620,
                easing         = CubicBezierEasing(0.25f, 0.1f, 0.25f, 1.0f)
            )
        ) { v, _ -> animProgress = v }
        animMove     = null
        animProgress = 1f
    }

    // Update prevBoard SELEPAS lastMove effect
    LaunchedEffect(board) { prevBoard = board }

    // ── Canvas ───────────────────────────────────────────────────────────────
    val density = LocalDensity.current
    val sizePx  = with(density) { boardSize.toPx() }

    Canvas(
        modifier = Modifier
            .size(boardSize)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, _, _ ->
                    camTheta -= pan.x * 0.009f
                    camPhi    = (camPhi - pan.y * 0.006f).coerceIn(0.22f, 1.15f)
                }
            }
            .pointerInput(board, selectedSquare, camTheta, camPhi) {
                detectTapGestures { offset ->
                    if (sizePx > 0f) {
                        tapToSquare(offset.x, offset.y, sizePx, sizePx, camTheta, camPhi)
                            ?.let { onSquareTap(it) }
                    }
                }
            }
    ) {
        draw3DChessBoard(
            board          = board,
            selected       = selectedSquare,
            validMoves     = validMoves,
            lastMove       = lastMove,
            isCheck        = isCheck,
            checkSideColor = checkColor,
            cameraTheta    = camTheta,
            cameraPhi      = camPhi,
            selectedLift   = selLift,
            animMove       = animMove,
            animProgress   = animProgress
        )
    }
}
