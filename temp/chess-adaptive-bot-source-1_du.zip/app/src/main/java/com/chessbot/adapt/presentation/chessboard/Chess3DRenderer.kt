package com.chessbot.adapt.presentation.chessboard

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import com.chessbot.adapt.domain.model.PieceType
import com.chessbot.adapt.domain.model.Piece
import com.chessbot.adapt.domain.model.Square
import com.chessbot.adapt.domain.model.Move
import com.chessbot.adapt.domain.model.Board
import kotlin.math.*

// ══════════════════════════════════════════════════════════════════════════════
//  VECTOR MATH  (inlined for performance — no boxing)
// ══════════════════════════════════════════════════════════════════════════════

internal data class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3)     = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3)    = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = V3(x * s, y * s, z * s)
    infix fun dot(o: V3)         = x*o.x + y*o.y + z*o.z
    infix fun cross(o: V3)       = V3(y*o.z - z*o.y, z*o.x - x*o.z, x*o.y - y*o.x)
    fun len()  = sqrt(x*x + y*y + z*z)
    fun norm() = len().let { l -> if (l > 1e-7f) this*(1f/l) else V3(0f,0f,0f) }
}

// Column-major 4×4 matrix multiply (a × b)
private fun mm(a: FloatArray, b: FloatArray): FloatArray {
    val r = FloatArray(16)
    for (row in 0..3) for (col in 0..3) {
        var s = 0f
        for (k in 0..3) s += a[row + k*4] * b[k + col*4]
        r[row + col*4] = s
    }
    return r
}

private fun perspM(fovDeg: Float, asp: Float, n: Float, f: Float): FloatArray {
    val h = 1f / tan(fovDeg * PI.toFloat() / 360f)
    return floatArrayOf(
        h/asp, 0f, 0f,  0f,
        0f,    h,  0f,  0f,
        0f,    0f, (f+n)/(n-f), -1f,
        0f,    0f, (2f*f*n)/(n-f), 0f
    )
}

private fun lookM(eye: V3): FloatArray {
    val f = (V3(0f,0f,0f) - eye).norm()
    val r = (f cross V3(0f,1f,0f)).norm()
    val u = r cross f
    return floatArrayOf(
        r.x, u.x, -f.x, 0f,
        r.y, u.y, -f.y, 0f,
        r.z, u.z, -f.z, 0f,
        -(r dot eye), -(u dot eye), (f dot eye), 1f
    )
}

// ── Public helpers used by ChessBoard3DView ───────────────────────────────────

internal fun camPos(theta: Float, phi: Float, radius: Float = 11.5f) = V3(
    radius * sin(phi) * sin(theta),
    radius * cos(phi),
    radius * sin(phi) * cos(theta)
)

internal fun vpMat(theta: Float, phi: Float, w: Float, h: Float): FloatArray {
    val eye = camPos(theta, phi)
    return mm(perspM(52f, w / h.coerceAtLeast(1f), 0.5f, 50f), lookM(eye))
}

internal fun prj(w: V3, vp: FloatArray, sw: Float, sh: Float): Offset? {
    val m  = vp
    val cx = m[0]*w.x + m[4]*w.y + m[8]*w.z  + m[12]
    val cy = m[1]*w.x + m[5]*w.y + m[9]*w.z  + m[13]
    val cw = m[3]*w.x + m[7]*w.y + m[11]*w.z + m[15]
    if (cw <= 0.01f) return null
    return Offset((cx/cw + 1f)*0.5f*sw, (1f - cy/cw)*0.5f*sh)
}

/** Ray-plane intersection → board Square. Returns null if tap misses board. */
internal fun tapToSquare(
    tx: Float, ty: Float, sw: Float, sh: Float,
    theta: Float, phi: Float
): Square? {
    if (sw <= 0f || sh <= 0f) return null
    val eye = camPos(theta, phi)
    val fwd = (V3(0f,0f,0f) - eye).norm()
    val rgt = (fwd cross V3(0f,1f,0f)).norm()
    val up  = rgt cross fwd
    val tanH = tan(52f * PI.toFloat() / 360f)
    val tanW = tanH * (sw / sh)
    val ndcX = (tx / sw) * 2f - 1f
    val ndcY = 1f - (ty / sh) * 2f
    val dv   = V3(ndcX * tanW, ndcY * tanH, -1f).norm()
    val dw   = V3(
        rgt.x*dv.x + up.x*dv.y - fwd.x*dv.z,
        rgt.y*dv.x + up.y*dv.y - fwd.y*dv.z,
        rgt.z*dv.x + up.z*dv.y - fwd.z*dv.z
    ).norm()
    if (abs(dw.y) < 1e-6f) return null
    val t = (TILE_H - eye.y) / dw.y
    if (t < 0f || t > 200f) return null
    val file = floor(eye.x + dw.x*t + 4f).toInt()
    val rank = floor(eye.z + dw.z*t + 4f).toInt()
    return if (file in 0..7 && rank in 0..7) Square(file, rank) else null
}

// ══════════════════════════════════════════════════════════════════════════════
//  CONSTANTS & PALETTE
// ══════════════════════════════════════════════════════════════════════════════

private const val TILE_HS  = 0.47f
internal const val TILE_H  = 0.18f
private const val FRAME_EX = 0.62f

// Background
private val cBg1 = Color(0xFF0B0B1C); private val cBg2 = Color(0xFF181836)

// Board frame — dark walnut
private val cFrameTop  = Color(0xFF3E2008); private val cFrameSide = Color(0xFF261304)

// Light squares — warm maple
private val cLtTop  = Color(0xFFE2BF88); private val cLtTopHi = Color(0xFFF0D4A2)
private val cLtSide = Color(0xFFBB9865)

// Dark squares — rich mahogany
private val cDkTop  = Color(0xFF8C5726); private val cDkTopHi = Color(0xFF9E6330)
private val cDkSide = Color(0xFF6A3E18)

// White pieces — polished ivory
private val cWBase = Color(0xFFF3EDD8); private val cWHi = Color(0xFFFFFFFF)
private val cWShade= Color(0xFFC0B488)

// Black pieces — polished ebony
private val cBBase = Color(0xFF252525); private val cBHi = Color(0xFF4A4A4A)
private val cBShade= Color(0xFF0E0E0E)

// UI accents
private val cSelect  = Color(0xFF00E676); private val cValid   = Color(0xFF00BCD4)
private val cLast    = Color(0xFFFFD54F); private val cCheck   = Color(0xFFFF1744)
private val cCapture = Color(0xFFFF3D3D)  // merah terang — boleh tangkap

// ══════════════════════════════════════════════════════════════════════════════
//  MAIN RENDER
// ══════════════════════════════════════════════════════════════════════════════

fun DrawScope.draw3DChessBoard(
    board:          Board?,
    selected:       Square?,
    validMoves:     List<Move>,
    lastMove:       Move?,
    isCheck:        Boolean,
    checkSideColor: com.chessbot.adapt.domain.model.Color?,
    cameraTheta:    Float,
    cameraPhi:      Float,
    selectedLift:   Float,
    animMove:       Move?,
    animProgress:   Float
) {
    val sw = size.width;  val sh = size.height
    if (sw <= 0f || sh <= 0f) return

    val vp  = vpMat(cameraTheta, cameraPhi, sw, sh)
    val eye = camPos(cameraTheta, cameraPhi)

    fun p(w: V3): Offset? = prj(w, vp, sw, sh)
    fun dist(w: V3): Float = (w - eye).len()

    val validTargets = validMoves.mapTo(HashSet()) { it.toSquare }

    // ── Background ────────────────────────────────────────────────────────────
    drawRect(Brush.radialGradient(
        listOf(cBg2, cBg1),
        center = Offset(sw*0.5f, sh*0.5f),
        radius = sw * 0.9f
    ))

    // ── Collect items ─────────────────────────────────────────────────────────
    data class RItem(val depth: Float, val fn: DrawScope.() -> Unit)
    val items = ArrayList<RItem>(100)

    // Board frame
    items += RItem(dist(V3(0f,0f,0f)) + 35f) {
        val hs = 4f + FRAME_EX
        val yT = TILE_H * 0.05f; val yB = -0.14f
        val c0 = arrayOf(V3(-hs,yT,-hs), V3(hs,yT,-hs), V3(hs,yT,hs), V3(-hs,yT,hs))
        val t  = c0.mapNotNull { p(it) }
        val b  = c0.mapNotNull { p(it.copy(y = yB)) }
        if (t.size == 4 && b.size == 4) {
            quad4(t[0],t[1],t[2],t[3], cFrameTop)
            quad4(t[2],t[3],b[3],b[2], cFrameSide)
            quad4(t[1],t[2],b[2],b[1], cFrameSide.copy(alpha=0.85f))
        }
    }

    // Tiles
    for (rank in 0..7) for (file in 0..7) {
        val sq    = Square(file, rank)
        val cx    = file - 3.5f;  val cz = rank - 3.5f
        val light = (file + rank) % 2 == 0
        val isSel     = selected == sq
        val isLastF   = lastMove?.fromSquare == sq
        val isLastT   = lastMove?.toSquare   == sq
        val isVT      = sq in validTargets
        val isKingChk = isCheck && checkSideColor != null &&
            board?.squares?.getOrNull(rank)?.getOrNull(file)?.let {
                it.type == PieceType.KING && it.color == checkSideColor
            } == true

        items += RItem(dist(V3(cx, TILE_H, cz))) {
            val x0 = cx-TILE_HS; val x1 = cx+TILE_HS
            val z0 = cz-TILE_HS; val z1 = cz+TILE_HS

            val tfl = p(V3(x0,TILE_H,z0)) ?: return@RItem
            val tfr = p(V3(x1,TILE_H,z0)) ?: return@RItem
            val tbr = p(V3(x1,TILE_H,z1)) ?: return@RItem
            val tbl = p(V3(x0,TILE_H,z1)) ?: return@RItem

            val side = if (light) cLtSide else cDkSide

            // Near side face
            val bbl = p(V3(x0,0f,z1)) ?: return@RItem
            val bbr = p(V3(x1,0f,z1)) ?: return@RItem
            quad4(tbl,tbr,bbr,bbl, side)
            // Right side face
            val bfr = p(V3(x1,0f,z0)) ?: return@RItem
            quad4(tfr,tbr,bbr,bfr, side.copy(alpha=0.88f))

            // Top face — diagonal wood-grain gradient
            val tilePath = Path().apply {
                moveTo(tfl.x,tfl.y); lineTo(tfr.x,tfr.y)
                lineTo(tbr.x,tbr.y); lineTo(tbl.x,tbl.y); close()
            }
            drawPath(tilePath, Brush.linearGradient(
                if (light) listOf(cLtTopHi, cLtTop) else listOf(cDkTopHi, cDkTop),
                start = tfl, end = tbr
            ))

            // Overlay
            val tint = when {
                isKingChk           -> cCheck
                isSel               -> cSelect
                isLastF || isLastT  -> cLast
                else                -> null
            }
            if (tint != null) quad4(tfl,tfr,tbr,tbl, tint, alpha=0.38f)

            // Valid-move: cyan dot (kosong) atau merah ring (boleh tangkap)
            if (isVT) {
                val cc      = p(V3(cx, TILE_H+0.01f, cz)) ?: return@RItem
                val rr      = ((tfr.x - tfl.x).absoluteValue * 0.15f).coerceIn(5f, 18f)
                val isCapSq = board?.squares?.getOrNull(rank)?.getOrNull(file) != null
                if (isCapSq) {
                    // MERAH — bidak musuh boleh ditangkap
                    drawCircle(cCapture, rr * 1.7f, cc, alpha = 0.18f)
                    drawCircle(cCapture, rr * 1.4f, cc, style = Stroke(rr * 0.34f), alpha = 0.95f)
                } else {
                    // CYAN — petak kosong boleh diduduki
                    drawCircle(cValid, rr * 1.1f, cc, alpha = 0.90f)
                    drawCircle(cValid, rr * 0.45f, cc, alpha = 0.55f)
                }
            }
        }
    }

    // Pieces
    if (board != null) {
        val animDstSq = if (animMove != null && animProgress < 1f) animMove.toSquare else null

        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file] ?: continue
            val sq    = Square(file, rank)
            if (sq == selected || sq == animDstSq) continue

            val cx = file - 3.5f; val cz = rank - 3.5f
            val ph = pHeight(piece.type)
            items += RItem(dist(V3(cx, TILE_H + ph*0.5f, cz))) {
                piece3D(piece, cx, cz, 0f, ph, ::p, sw)
            }
        }

        // Animated piece — arcing through air
        if (animMove != null && animProgress < 1f) {
            val dstPiece = board.squares.getOrNull(animMove.toSquare.rank)
                ?.getOrNull(animMove.toSquare.file)
                ?: board.squares.getOrNull(animMove.fromSquare.rank)
                    ?.getOrNull(animMove.fromSquare.file)
            if (dstPiece != null) {
                val fx = animMove.fromSquare.file - 3.5f
                val fz = animMove.fromSquare.rank - 3.5f
                val tx = animMove.toSquare.file - 3.5f
                val tz = animMove.toSquare.rank - 3.5f
                val arc = sin(animProgress * PI.toFloat()) * 1.5f   // lebih tinggi, lebih dramatic
                val ix  = fx + (tx - fx) * animProgress
                val iz  = fz + (tz - fz) * animProgress
                val ph  = pHeight(dstPiece.type)
                items += RItem(dist(V3(ix, TILE_H + arc + ph*0.5f, iz))) {
                    piece3D(dstPiece, ix, iz, arc, ph, ::p, sw)
                }
            }
        }

        // Selected piece — lifted with glow ring
        if (selected != null) {
            val piece = board.squares.getOrNull(selected.rank)?.getOrNull(selected.file)
            if (piece != null) {
                val cx = selected.file - 3.5f; val cz = selected.rank - 3.5f
                val ph = pHeight(piece.type)
                items += RItem(dist(V3(cx, TILE_H + selectedLift + ph*0.5f, cz))) {
                    val bc = p(V3(cx, TILE_H + selectedLift*0.05f, cz)) ?: return@RItem
                    val refR = p(V3(cx + pRadius(piece.type)*1.7f, TILE_H, cz))?.x
                        ?: (bc.x + 22f)
                    val glowR = (refR - bc.x).absoluteValue.coerceIn(14f, 50f)
                    drawCircle(cSelect, glowR, bc, alpha=0.22f)
                    drawCircle(cSelect, glowR*0.68f, bc, style=Stroke(3.5f), alpha=0.85f)
                    piece3D(piece, cx, cz, selectedLift, ph, ::p, sw)
                }
            }
        }
    }

    // Depth sort → draw back-to-front
    items.sortByDescending { it.depth }
    for (item in items) item.fn(this)
}

// ══════════════════════════════════════════════════════════════════════════════
//  PIECE RENDERER — 3-D cylinder with Phong-like gradient shading
// ══════════════════════════════════════════════════════════════════════════════

private fun DrawScope.piece3D(
    piece: Piece, cx: Float, cz: Float, lift: Float, ph: Float,
    proj: (V3) -> Offset?, sw: Float
) {
    val isW  = piece.color == com.chessbot.adapt.domain.model.Color.WHITE
    val rad  = pRadius(piece.type)
    val yBot = TILE_H + lift
    val yTop = yBot + ph

    val bc = proj(V3(cx, yBot, cz)) ?: return
    val tc = proj(V3(cx, yTop, cz)) ?: return

    val rL = proj(V3(cx - rad, yTop, cz))?.x ?: (tc.x - 14f)
    val rR = proj(V3(cx + rad, yTop, cz))?.x ?: (tc.x + 14f)
    val pr = ((rR - rL).absoluteValue * 0.5f).coerceIn(7f, 42f)

    val base  = if (isW) cWBase  else cBBase
    val hi    = if (isW) cWHi    else cBHi
    val shade = if (isW) cWShade else cBShade

    // Shadow ellipse
    val sc = proj(V3(cx, TILE_H + 0.01f, cz)) ?: return
    val sL = proj(V3(cx - rad*1.4f, TILE_H+0.01f, cz))?.x ?: (sc.x - pr*1.4f)
    val sR = proj(V3(cx + rad*1.4f, TILE_H+0.01f, cz))?.x ?: (sc.x + pr*1.4f)
    val sr = ((sR - sL).absoluteValue * 0.5f).coerceIn(5f, 48f)
    drawOval(
        Brush.radialGradient(
            listOf(Color(0f,0f,0f,0.55f), Color(0f,0f,0f,0f)),
            center = sc, radius = sr * 1.2f
        ),
        topLeft = Offset(sc.x - sr, sc.y - sr*0.38f),
        size    = Size(sr*2f, sr*0.76f)
    )

    // Bottom cap
    drawOval(shade,
        topLeft = Offset(bc.x - pr, bc.y - pr*0.32f),
        size    = Size(pr*2f, pr*0.64f)
    )

    // Cylinder body — horizontal gradient (left lit, right shadow)
    val body = Path().apply {
        moveTo(tc.x - pr, tc.y)
        lineTo(tc.x + pr, tc.y)
        lineTo(bc.x + pr, bc.y)
        lineTo(bc.x - pr, bc.y)
        close()
    }
    drawPath(body, Brush.horizontalGradient(
        listOf(hi, base, base, shade),
        startX = tc.x - pr, endX = tc.x + pr
    ))

    // Top cap — radial gradient dome
    drawOval(
        Brush.radialGradient(
            listOf(hi, base, shade),
            center = Offset(tc.x - pr*0.2f, tc.y - pr*0.1f),
            radius = pr * 1.5f
        ),
        topLeft = Offset(tc.x - pr, tc.y - pr*0.36f),
        size    = Size(pr*2f, pr*0.72f)
    )

    // Type symbol
    drawIntoCanvas { canvas ->
        val tSize = (pr * 1.65f).coerceIn(9f, 34f)
        val paint = android.graphics.Paint().apply {
            textSize    = tSize
            textAlign   = android.graphics.Paint.Align.CENTER
            isAntiAlias = true
            color = if (isW)
                android.graphics.Color.argb(200, 90, 68, 24)
            else
                android.graphics.Color.argb(220, 235, 228, 205)
            setShadowLayer(
                tSize * 0.06f, 0f, tSize * 0.04f,
                if (isW) android.graphics.Color.argb(60, 0, 0, 0)
                else     android.graphics.Color.argb(60, 255, 255, 255)
            )
        }
        canvas.nativeCanvas.drawText(pSymbol(piece), tc.x, tc.y + tSize*0.33f, paint)
    }
}

// ══════════════════════════════════════════════════════════════════════════════
//  HELPERS
// ══════════════════════════════════════════════════════════════════════════════

private fun DrawScope.quad4(
    a: Offset, b: Offset, c: Offset, d: Offset,
    color: Color, alpha: Float = 1f
) = drawPath(Path().apply {
    moveTo(a.x,a.y); lineTo(b.x,b.y); lineTo(c.x,c.y); lineTo(d.x,d.y); close()
}, color, alpha = alpha)

private fun pHeight(t: PieceType) = when(t) {
    PieceType.PAWN   -> 0.48f; PieceType.KNIGHT -> 0.63f
    PieceType.BISHOP -> 0.72f; PieceType.ROOK   -> 0.60f
    PieceType.QUEEN  -> 0.84f; PieceType.KING   -> 0.95f
}

private fun pRadius(t: PieceType) = when(t) {
    PieceType.PAWN   -> 0.19f; PieceType.KNIGHT -> 0.23f
    PieceType.BISHOP -> 0.20f; PieceType.ROOK   -> 0.25f
    PieceType.QUEEN  -> 0.25f; PieceType.KING   -> 0.24f
}

private fun pSymbol(p: Piece) = when(p.type) {
    PieceType.KING   -> "♚"; PieceType.QUEEN  -> "♛"
    PieceType.ROOK   -> "♜"; PieceType.BISHOP -> "♝"
    PieceType.KNIGHT -> "♞"; PieceType.PAWN   -> "♟"
}
