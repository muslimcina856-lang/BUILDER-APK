package com.chessbot.adapt.domain.engine

import com.chessbot.adapt.domain.model.*

class GameStateDetector(private val validator: MoveValidator) {

    fun isInCheck(board: Board, color: Color): Boolean {
        val king = findKing(board, color) ?: return false
        val opp  = color.opposite()
        return validator.isSquareAttacked(board, king, opp)
    }

    fun isCheckmate(board: Board, color: Color): Boolean =
        isInCheck(board, color) && !hasAnyLegalMove(board, color)

    fun isStalemate(board: Board, color: Color): Boolean =
        !isInCheck(board, color) && !hasAnyLegalMove(board, color)

    fun isDraw(board: Board): Boolean = isInsufficientMaterial(board)

    private fun hasAnyLegalMove(board: Board, color: Color): Boolean {
        for (r in 0..7) for (f in 0..7) {
            val piece = board.squares[r][f] ?: continue
            if (piece.color != color) continue
            val moves = validator.generatePieceMoves(board, Square(f, r))
            if (moves.any { !isInCheck(applyMove(board, it), color) }) return true
        }
        return false
    }

    fun findKing(board: Board, color: Color): Square? {
        for (r in 0..7) for (f in 0..7) {
            val p = board.squares[r][f]
            if (p?.type == PieceType.KING && p.color == color) return Square(f, r)
        }
        return null
    }

    fun applyMove(board: Board, move: Move): Board {
        val ns = Array(8) { r -> Array<Piece?>(8) { f -> board.squares[r][f] } }
        ns[move.fromSquare.rank][move.fromSquare.file] = null
        ns[move.toSquare.rank][move.toSquare.file] = move.promotionPiece
            ?.let { Piece(it, move.piece.color) } ?: move.piece
        return Board(ns)
    }

    private fun isInsufficientMaterial(board: Board): Boolean {
        val pieces = mutableListOf<Piece>()
        for (r in 0..7) for (f in 0..7) board.squares[r][f]?.let { pieces += it }
        if (pieces.size == 2) return true   // K vs K
        if (pieces.size == 3) {
            return pieces.any { it.type == PieceType.BISHOP || it.type == PieceType.KNIGHT }
        }
        return false
    }
}

fun Color.opposite() = if (this == Color.WHITE) Color.BLACK else Color.WHITE
