package com.chessbot.adapt.presentation.chessboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chessbot.adapt.data.local.dao.BotConfigDao
import com.chessbot.adapt.data.local.dao.BotLearningDataDao
import com.chessbot.adapt.data.local.entity.BotConfig
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.data.local.entity.GameSession
import com.chessbot.adapt.data.local.entity.MoveEntity
import com.chessbot.adapt.data.local.entity.PlayerProfile
import com.chessbot.adapt.domain.bot.PatternAnalyzer
import com.chessbot.adapt.domain.engine.ChessEngineImpl
import com.chessbot.adapt.domain.engine.opposite
import com.chessbot.adapt.domain.model.*
import com.chessbot.adapt.domain.repository.GameRepository
import com.chessbot.adapt.domain.repository.PlayerRepository
import com.chessbot.adapt.domain.usecase.AnalyzePatternsUseCase
import com.chessbot.adapt.domain.usecase.GetBotMoveUseCase
import com.chessbot.adapt.domain.usecase.UpdateBotLevelUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChessBoardUiState(
    val board: Board?           = null,
    val validMoves: List<Move>  = emptyList(),
    val selectedSquare: Square? = null,
    val isBotThinking: Boolean  = false,
    val gameResult: String?     = null,
    val currentLevel: Int       = 1,
    val moveHistory: List<Move> = emptyList(),
    val lastMove: Move?         = null,
    val playerColor: Color      = Color.WHITE,
    val botColor: Color         = Color.BLACK,
    val currentTurn: Color      = Color.WHITE,
    val isCheck: Boolean        = false,
    val isCheckmate: Boolean    = false,
    val isReady: Boolean        = false
)

@HiltViewModel
class ChessBoardViewModel @Inject constructor(
    private val getBotMoveUseCase:     GetBotMoveUseCase,
    private val updateBotLevelUseCase: UpdateBotLevelUseCase,
    private val analyzePatternsUseCase:AnalyzePatternsUseCase,
    private val gameRepository:        GameRepository,
    private val playerRepository:      PlayerRepository,
    private val botConfigDao:          BotConfigDao,
    private val botLearningDataDao:    BotLearningDataDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChessBoardUiState())
    val uiState: StateFlow<ChessBoardUiState> = _uiState.asStateFlow()

    private val engine         = ChessEngineImpl()
    private val patternAnalyzer= PatternAnalyzer()

    private var currentGameId  = 0L
    private var currentPlayerId= 0L
    private var botConfig      = BotConfig()
    private var learningData   = emptyList<BotLearningData>()
    private var botMoveJob: Job? = null

    // Global error handler — prevents unhandled coroutine crash
    private val errHandler = CoroutineExceptionHandler { _, e ->
        android.util.Log.e("ChessVM", "Coroutine error: ${e.message}", e)
        _uiState.value = _uiState.value.copy(isBotThinking = false)
    }

    init {
        viewModelScope.launch(errHandler) { initPlayer() }
    }

    // ──────────────────────────────────────────────────────────────────────────
    //  INIT
    // ──────────────────────────────────────────────────────────────────────────

    private suspend fun initPlayer() {
        val now = System.currentTimeMillis()
        val player = playerRepository.getFirstPlayer() ?: run {
            val id = playerRepository.savePlayer(
                PlayerProfile(username = "Player", createdAt = now, updatedAt = now)
            )
            playerRepository.getPlayer(id) ?: PlayerProfile(id = id, username = "Player",
                createdAt = now, updatedAt = now)
        }
        currentPlayerId = player.id

        botConfig = botConfigDao.getConfig(currentPlayerId) ?: BotConfig(
            playerId = currentPlayerId
        ).also { botConfigDao.upsert(it) }

        learningData = botLearningDataDao.getLearningDataForPlayer(currentPlayerId)

        _uiState.value = _uiState.value.copy(
            currentLevel = botConfig.currentLevel,
            isReady      = true
        )
    }

    // ──────────────────────────────────────────────────────────────────────────
    //  GAME CONTROL
    // ──────────────────────────────────────────────────────────────────────────

    fun startNewGame(playerColor: Color = Color.WHITE) {
        botMoveJob?.cancel()
        val board    = engine.initializeBoard()
        val botColor = playerColor.opposite()

        _uiState.value = ChessBoardUiState(
            board        = board,
            playerColor  = playerColor,
            botColor     = botColor,
            currentTurn  = Color.WHITE,
            currentLevel = botConfig.currentLevel,
            isReady      = true
        )

        viewModelScope.launch(errHandler) {
            currentGameId = gameRepository.saveGame(
                GameSession(
                    playerId      = currentPlayerId,
                    playerColor   = playerColor.name,
                    result        = "IN_PROGRESS",
                    botLevelStart = botConfig.currentLevel,
                    botLevelEnd   = botConfig.currentLevel,
                    startedAt     = System.currentTimeMillis()
                )
            )
        }

        if (playerColor == Color.BLACK) makeBotMove()
    }

    fun resetGame() {
        botMoveJob?.cancel()
        _uiState.value = ChessBoardUiState(
            currentLevel = botConfig.currentLevel,
            isReady      = true
        )
        startNewGame(Color.WHITE)
    }

    // ──────────────────────────────────────────────────────────────────────────
    //  PLAYER INPUT
    // ──────────────────────────────────────────────────────────────────────────

    fun onSquareTapped(square: Square) {
        val state = _uiState.value
        // Guard: ignore taps when game over, bot thinking, not player turn, board null
        if (!state.isReady) return
        if (state.isBotThinking || state.gameResult != null) return
        if (state.currentTurn != state.playerColor) return
        val board = state.board ?: return

        // Bounds guard
        if (square.file !in 0..7 || square.rank !in 0..7) return

        val tappedPiece = board.squares[square.rank][square.file]

        if (state.selectedSquare == null) {
            // Select piece
            if (tappedPiece?.color == state.playerColor) {
                val valid = engine.getValidMoves(board, square)
                _uiState.value = state.copy(selectedSquare = square, validMoves = valid)
            }
        } else {
            // Try execute move
            val move = state.validMoves.find {
                it.fromSquare == state.selectedSquare && it.toSquare == square
            }
            when {
                move != null -> executePlayerMove(move)
                tappedPiece?.color == state.playerColor -> {
                    // Switch selection to another piece
                    val valid = engine.getValidMoves(board, square)
                    _uiState.value = state.copy(selectedSquare = square, validMoves = valid)
                }
                else -> _uiState.value = state.copy(selectedSquare = null, validMoves = emptyList())
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    //  MOVE EXECUTION
    // ──────────────────────────────────────────────────────────────────────────

    private fun executePlayerMove(move: Move) {
        val state    = _uiState.value
        val board    = state.board ?: return
        val newBoard = engine.makeMove(board, move)
        val history  = state.moveHistory + move
        val opp      = state.playerColor.opposite()

        val isCheck  = engine.isCheck(newBoard, opp)
        val isMate   = engine.isCheckmate(newBoard, opp)
        val isStale  = engine.isStalemate(newBoard, opp)
        val isDraw   = engine.isDraw(newBoard)

        viewModelScope.launch(errHandler) {
            runCatching {
                gameRepository.saveMove(buildMoveEntity(state.playerColor, move, history.size,
                    isCheck, isMate, newBoard))
            }
        }

        _uiState.value = state.copy(
            board          = newBoard,
            selectedSquare = null,
            validMoves     = emptyList(),
            moveHistory    = history,
            lastMove       = move,
            currentTurn    = opp,
            isCheck        = isCheck,
            isCheckmate    = isMate
        )

        when {
            isMate  -> onGameEnd("WIN")
            isStale -> onGameEnd("DRAW")
            isDraw  -> onGameEnd("DRAW")
            else    -> makeBotMove()
        }
    }

    private fun makeBotMove() {
        val state = _uiState.value
        val board = state.board ?: return
        _uiState.value = state.copy(isBotThinking = true)

        botMoveJob = viewModelScope.launch(errHandler) {
            runCatching {
                getBotMoveUseCase(board, state.botColor, botConfig, learningData)
            }.onSuccess { botMove ->
                val curState = _uiState.value
                val curBoard = curState.board ?: return@onSuccess
                val newBoard = engine.makeMove(curBoard, botMove)
                val history  = curState.moveHistory + botMove
                val isCheck  = engine.isCheck(newBoard, curState.playerColor)
                val isMate   = engine.isCheckmate(newBoard, curState.playerColor)
                val isStale  = engine.isStalemate(newBoard, curState.playerColor)
                val isDraw   = engine.isDraw(newBoard)

                runCatching {
                    gameRepository.saveMove(buildMoveEntity(curState.botColor, botMove,
                        history.size, isCheck, isMate, newBoard))
                }

                _uiState.value = curState.copy(
                    board         = newBoard,
                    isBotThinking = false,
                    moveHistory   = history,
                    lastMove      = botMove,
                    currentTurn   = curState.playerColor,
                    isCheck       = isCheck,
                    isCheckmate   = isMate
                )
                when {
                    isMate  -> onGameEnd("LOSS")
                    isStale -> onGameEnd("DRAW")
                    isDraw  -> onGameEnd("DRAW")
                }
            }.onFailure { e ->
                android.util.Log.e("ChessVM", "Bot move error: ${e.message}", e)
                _uiState.value = _uiState.value.copy(isBotThinking = false)
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    //  GAME END
    // ──────────────────────────────────────────────────────────────────────────

    private fun onGameEnd(result: String) {
        val state = _uiState.value
        _uiState.value = state.copy(gameResult = result, isBotThinking = false)

        viewModelScope.launch(errHandler) {
            runCatching {
                analyzePatternsUseCase(currentPlayerId, state.moveHistory, result)
                learningData = botLearningDataDao.getLearningDataForPlayer(currentPlayerId)

                if (currentGameId > 0) {
                    gameRepository.getGame(currentGameId)?.let { session ->
                        gameRepository.updateGame(session.copy(
                            result      = result,
                            botLevelEnd = botConfig.currentLevel,
                            totalMoves  = state.moveHistory.size,
                            openingUsed = patternAnalyzer.identifyOpening(state.moveHistory),
                            endedAt     = System.currentTimeMillis()
                        ))
                    }
                }
                botConfig = updateBotLevelUseCase(
                    botConfig.copy(playerId = currentPlayerId), result == "WIN"
                )
                _uiState.value = _uiState.value.copy(currentLevel = botConfig.currentLevel)
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ──────────────────────────────────────────────────────────────────────────

    private fun buildMoveEntity(
        color: Color, move: Move, moveNo: Int,
        isCheck: Boolean, isMate: Boolean, board: Board
    ) = MoveEntity(
        gameId         = currentGameId,
        moveNumber     = moveNo,
        color          = color.name,
        fromSquare     = "${('a' + move.fromSquare.file)}${move.fromSquare.rank + 1}",
        toSquare       = "${('a' + move.toSquare.file)}${move.toSquare.rank + 1}",
        pieceType      = move.piece.type.name,
        promotionPiece = move.promotionPiece?.name,
        isCheck        = isCheck,
        isCheckmate    = isMate,
        fenAfter       = engine.toFEN(board)
    )
}
