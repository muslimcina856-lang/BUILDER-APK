package com.chessbot.adapt.domain.bot

import com.chessbot.adapt.data.local.entity.BotConfig
import com.chessbot.adapt.data.local.entity.BotLearningData
import com.chessbot.adapt.domain.engine.GameStateDetector
import com.chessbot.adapt.domain.engine.MoveValidator
import com.chessbot.adapt.domain.engine.opposite
import com.chessbot.adapt.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MinimaxEngine(
    private val patternAnalyzer: PatternAnalyzer = PatternAnalyzer(),
    private val adaptiveLearner: AdaptiveLearner  = AdaptiveLearner()
) : BotEngine {

    private val validator     = MoveValidator()
    private val stateDetector = GameStateDetector(validator)

    // Time limit: bot must finish within 2 seconds
    private val timeLimitMs = 2000L
    private var startTimeMs = 0L

    override suspend fun getBestMove(
        board: Board,
        color: Color,
        config: BotConfig,
        learningData: List<BotLearningData>
    ): Move = withContext(Dispatchers.Default) {

        startTimeMs = System.currentTimeMillis()

        val weights = buildWeights(config, learningData)
        val depth   = config.searchDepth.coerceIn(1, 6)

        val legalMoves = getAllLegalMoves(board, color)
        if (legalMoves.isEmpty()) throw IllegalStateException("No legal moves for $color")
        if (legalMoves.size == 1) return@withContext legalMoves.first()

        var bestMove  = legalMoves.first()
        var bestScore = Int.MIN_VALUE + 1

        // Iterative deepening — return best found if time runs out
        for (d in 1..depth) {
            if (timeExpired()) break
            var alpha = Int.MIN_VALUE + 1
            val beta  = Int.MAX_VALUE - 1

            for (move in legalMoves.sortedByMVVLVA(board)) {
                if (timeExpired()) break
                val newBoard = stateDetector.applyMove(board, move)
                val score    = alphaBeta(newBoard, d - 1, alpha, beta, false, color, weights)
                if (score > bestScore) {
                    bestScore = score
                    bestMove  = move
                }
                alpha = max(alpha, bestScore)
            }
        }
        bestMove
    }

    private fun alphaBeta(
        board: Board, depth: Int,
        alphaIn: Int, beta: Int,
        maximizing: Boolean,
        botColor: Color,
        weights: EvalWeights
    ): Int {
        if (depth == 0 || timeExpired())
            return evaluatePosition(board, botColor, weights)

        val color      = if (maximizing) botColor else botColor.opposite()
        val legalMoves = getAllLegalMoves(board, color)

        if (legalMoves.isEmpty()) {
            return if (stateDetector.isInCheck(board, color)) {
                if (maximizing) -(100_000 - depth) else (100_000 - depth)
            } else 0   // stalemate
        }

        var alpha = alphaIn
        var best  = if (maximizing) Int.MIN_VALUE + 1 else Int.MAX_VALUE - 1

        for (move in legalMoves.sortedByMVVLVA(board)) {
            val newBoard = stateDetector.applyMove(board, move)
            val score    = alphaBeta(newBoard, depth - 1, alpha, beta, !maximizing, botColor, weights)
            if (maximizing) {
                if (score > best) best = score
                if (score > alpha) alpha = score
            } else {
                if (score < best) best = score
                if (score < beta)  return best    // beta cutoff simplification
            }
            if (alpha >= beta) break   // alpha-beta prune
        }
        return best
    }

    override fun evaluatePosition(board: Board, color: Color, weights: EvalWeights): Int {
        var score = 0
        for (r in 0..7) for (f in 0..7) {
            val piece = board.squares[r][f] ?: continue
            val v     = pieceValue(piece.type)
            val bonus = positionalBonus(piece, r, f)
            score += if (piece.color == color) v + bonus else -(v + bonus)
        }
        score = (score * weights.material).toInt()
        score += (mobilityScore(board, color) * weights.mobility).toInt()
        score += (kingSafetyScore(board, color) * weights.kingSafety).toInt()
        score -= (mobilityScore(board, color.opposite()) * weights.aggression * 0.3f).toInt()
        return score
    }

    private fun getAllLegalMoves(board: Board, color: Color): List<Move> {
        val moves = ArrayList<Move>(40)
        for (r in 0..7) for (f in 0..7) {
            val piece = board.squares[r][f] ?: continue
            if (piece.color != color) continue
            for (move in validator.generatePieceMoves(board, Square(f, r))) {
                if (!stateDetector.isInCheck(stateDetector.applyMove(board, move), color))
                    moves += move
            }
        }
        return moves
    }

    private fun List<Move>.sortedByMVVLVA(board: Board) = sortedByDescending { move ->
        val victim = board.squares[move.toSquare.rank][move.toSquare.file]
        if (victim != null) pieceValue(victim.type) * 10 - pieceValue(move.piece.type) else 0
    }

    private fun mobilityScore(board: Board, color: Color): Int {
        var m = 0
        for (r in 0..7) for (f in 0..7) {
            val p = board.squares[r][f] ?: continue
            if (p.color != color) continue
            m += validator.generatePieceMoves(board, Square(f, r)).size
        }
        return m
    }

    private fun kingSafetyScore(board: Board, color: Color): Int {
        val ks  = stateDetector.findKing(board, color) ?: return 0
        val dir = if (color == Color.WHITE) 1 else -1
        var safety = 0
        for (df in -1..1) {
            val f = ks.file + df; val r = ks.rank + dir
            if (f in 0..7 && r in 0..7) {
                val p = board.squares[r][f]
                if (p?.type == PieceType.PAWN && p.color == color) safety += 10
            }
        }
        return safety
    }

    private fun positionalBonus(piece: Piece, rank: Int, file: Int): Int {
        val cd = abs(3.5 - rank) + abs(3.5 - file)
        return when (piece.type) {
            PieceType.KNIGHT, PieceType.BISHOP -> max(0, ((7 - cd) * 5).toInt())
            PieceType.PAWN   -> max(0, ((7 - cd) * 2).toInt())
            PieceType.KING   -> if (piece.color == Color.WHITE) -(rank * 3) else -((7 - rank) * 3)
            else             -> max(0, ((7 - cd) * 2).toInt())
        }
    }

    private fun buildWeights(config: BotConfig, learningData: List<BotLearningData>): EvalWeights {
        val base = patternAnalyzer.getCounterStrategy(patternAnalyzer.identifyOpening(emptyList()))
        return if (learningData.isEmpty()) base else {
            val avgAgg = learningData.map { it.aggressionModifier }.average().toFloat()
            val avgDef = learningData.map { it.defenseModifier }.average().toFloat()
            base.copy(
                aggression = (base.aggression + avgAgg).coerceIn(0f, 1f),
                defense    = (base.defense    + avgDef).coerceIn(0f, 1f)
            )
        }
    }

    private fun timeExpired() = System.currentTimeMillis() - startTimeMs > timeLimitMs

    private fun pieceValue(type: PieceType) = when (type) {
        PieceType.PAWN   -> 100;  PieceType.KNIGHT -> 320
        PieceType.BISHOP -> 330;  PieceType.ROOK   -> 500
        PieceType.QUEEN  -> 900;  PieceType.KING   -> 20_000
    }

    override fun setDifficulty(level: Int) {}
    override fun updateWeights(learningData: BotLearningData) {}
}
