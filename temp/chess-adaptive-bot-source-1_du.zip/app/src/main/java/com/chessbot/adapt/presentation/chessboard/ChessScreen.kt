package com.chessbot.adapt.presentation.chessboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.hilt.navigation.compose.hiltViewModel
import com.chessbot.adapt.domain.model.Color as ChessColor

@Composable
fun ChessScreen(viewModel: ChessBoardViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    // Start game once DB is ready
    LaunchedEffect(state.isReady) {
        if (state.isReady && state.board == null) {
            viewModel.startNewGame(ChessColor.WHITE)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(horizontal = 12.dp)
    ) {
        val boardSize = min(maxWidth, maxHeight * 0.68f)

        Column(
            modifier             = Modifier.fillMaxSize(),
            horizontalAlignment  = Alignment.CenterHorizontally
        ) {
            // ── Top bar ────────────────────────────────────────────────────
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Chess Bot",
                        style      = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color      = Color(0xFFE8E8F0)
                    )
                    Text(
                        "Level ${state.currentLevel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF00E676)
                    )
                }
                if (state.isCheck && state.gameResult == null) {
                    Surface(
                        color  = Color(0xFFFF1744).copy(alpha = 0.2f),
                        shape  = MaterialTheme.shapes.small,
                        border = BorderStroke(1.dp, Color(0xFFFF1744))
                    ) {
                        Text(
                            "⚠ CHECK",
                            modifier   = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            color      = Color(0xFFFF1744),
                            style      = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            // ── 3D Board ───────────────────────────────────────────────────
            when {
                !state.isReady -> Box(Modifier.size(boardSize), Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF00E676))
                }
                else -> ChessBoard3DView(
                    board          = state.board,
                    selectedSquare = state.selectedSquare,
                    validMoves     = state.validMoves,
                    lastMove       = state.lastMove,
                    isCheck        = state.isCheck,
                    checkColor     = if (state.isCheck) {
                        if (state.currentTurn == state.playerColor) state.playerColor
                        else state.botColor
                    } else null,
                    playerColor    = state.playerColor,
                    boardSize      = boardSize,
                    onSquareTap    = viewModel::onSquareTapped
                )
            }

            Spacer(Modifier.height(10.dp))

            // ── Status / Result ────────────────────────────────────────────
            when {
                state.gameResult != null -> GameResultCard(
                    result     = state.gameResult!!,
                    level      = state.currentLevel,
                    onPlayAgain= viewModel::resetGame
                )
                state.isBotThinking -> Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CircularProgressIndicator(
                        modifier    = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color       = Color(0xFF00BCD4)
                    )
                    Text(
                        "Bot sedang berfikir…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF00BCD4)
                    )
                }
                else -> Text(
                    if (state.currentTurn == state.playerColor) "✦ Giliran kamu" else "◌ Giliran bot",
                    style      = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color      = if (state.currentTurn == state.playerColor)
                        Color(0xFF00E676) else Color(0xFF9090B0)
                )
            }

            if (state.moveHistory.isNotEmpty()) {
                Text(
                    "Langkah ke-${state.moveHistory.size}",
                    style    = MaterialTheme.typography.bodySmall,
                    color    = Color(0xFF6060A0)
                )
            }

            Spacer(Modifier.weight(1f))
            Text(
                "Drag untuk putar papan",
                style    = MaterialTheme.typography.labelSmall,
                color    = Color(0xFF3A3A5C),
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

@Composable
private fun GameResultCard(result: String, level: Int, onPlayAgain: () -> Unit) {
    val (emoji, title, sub) = when (result) {
        "WIN"  -> Triple("🏆", "Kamu Menang!", "Bot dinaikkan ke Level $level")
        "LOSS" -> Triple("♟", "Bot Menang", "Cuba lagi — kamu boleh buat!")
        "DRAW" -> Triple("🤝", "Seri!", "Permainan yang seimbang")
        else   -> Triple("🎯", result, "")
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = Color(0xFF13132A))
    ) {
        Column(
            Modifier.padding(20.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(emoji, style = MaterialTheme.typography.displaySmall)
            Text(title,
                style      = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color      = Color(0xFFE8E8F0),
                textAlign  = TextAlign.Center
            )
            if (sub.isNotEmpty()) Text(sub,
                style     = MaterialTheme.typography.bodyMedium,
                color     = Color(0xFF9090B0),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = onPlayAgain,
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676))
            ) {
                Text("Main Lagi", color = Color(0xFF003919), fontWeight = FontWeight.Bold)
            }
        }
    }
}
