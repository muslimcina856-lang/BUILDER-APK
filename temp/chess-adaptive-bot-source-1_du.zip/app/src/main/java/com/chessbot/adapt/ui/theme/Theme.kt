package com.chessbot.adapt.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary          = Color(0xFF00E676),
    onPrimary        = Color(0xFF003919),
    primaryContainer = Color(0xFF00522A),
    secondary        = Color(0xFF00BCD4),
    background       = Color(0xFF0B0B1C),
    surface          = Color(0xFF13132A),
    onBackground     = Color(0xFFE8E8F0),
    onSurface        = Color(0xFFD0D0E0),
    error            = Color(0xFFFF1744),
    outline          = Color(0xFF3A3A5C)
)

@Composable
fun ChessBotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content     = content
    )
}
