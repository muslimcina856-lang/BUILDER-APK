package com.chessbot.adapt.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.chessbot.adapt.presentation.chessboard.ChessScreen
import com.chessbot.adapt.ui.theme.ChessBotTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            ChessBotTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color    = Color(0xFF0B0B1C)
                ) {
                    ChessScreen()
                }
            }
        }
    }
}
