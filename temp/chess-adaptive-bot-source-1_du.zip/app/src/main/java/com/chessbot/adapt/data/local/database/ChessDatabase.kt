package com.chessbot.adapt.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.RoomDatabase.Callback
import androidx.sqlite.db.SupportSQLiteDatabase
import com.chessbot.adapt.data.local.dao.*
import com.chessbot.adapt.data.local.entity.*

@Database(
    entities = [
        PlayerProfile::class,
        GameSession::class,
        MoveEntity::class,
        PatternDefinition::class,
        PlayerPatternStats::class,
        BotLearningData::class,
        BotConfig::class,
        OpeningBook::class
    ],
    version = 2,
    exportSchema = true
)
abstract class ChessDatabase : RoomDatabase() {
    abstract fun playerProfileDao(): PlayerProfileDao
    abstract fun gameSessionDao(): GameSessionDao
    abstract fun moveDao(): MoveDao
    abstract fun patternDefinitionDao(): PatternDefinitionDao
    abstract fun playerPatternStatsDao(): PlayerPatternStatsDao
    abstract fun botLearningDataDao(): BotLearningDataDao
    abstract fun botConfigDao(): BotConfigDao
    abstract fun openingBookDao(): OpeningBookDao

    companion object {
        @Volatile
        private var INSTANCE: ChessDatabase? = null

        fun create(context: Context): ChessDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ChessDatabase::class.java, "chess_bot.db"
                )
                    .addCallback(PrepopulateCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }

    class PrepopulateCallback : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            db.execSQL("""
                INSERT OR IGNORE INTO opening_book (name, eco_code, move_sequence, category, popularity_score)
                VALUES ('Queen Gambit', 'D06', '["d4","d5","c4"]', 'OPENING', 80)
            """)
            db.execSQL("""
                INSERT OR IGNORE INTO opening_book (name, eco_code, move_sequence, category, popularity_score)
                VALUES ('Sicilian Defense', 'B20', '["e4","c5"]', 'OPENING', 90)
            """)
            db.execSQL("""
                INSERT OR IGNORE INTO opening_book (name, eco_code, move_sequence, category, popularity_score)
                VALUES ('Ruy Lopez', 'C60', '["e4","e5","Nf3","Nc6","Bb5"]', 'OPENING', 85)
            """)
            db.execSQL("""
                INSERT OR IGNORE INTO pattern_definitions (pattern_key, category, name, detection_rules, base_weight)
                VALUES ('OPENING_QUEEN_GAMBIT', 'OPENING', 'Queen Gambit', '{"moves":["d4","d5","c4"]}', 1.0)
            """)
            db.execSQL("""
                INSERT OR IGNORE INTO pattern_definitions (pattern_key, category, name, detection_rules, base_weight)
                VALUES ('TACTICAL_HANGING_PIECE', 'TACTICAL', 'Hanging Piece', '{"undefended":true}', 0.8)
            """)
            db.execSQL("""
                INSERT OR IGNORE INTO pattern_definitions (pattern_key, category, name, detection_rules, base_weight)
                VALUES ('POSITIONAL_CENTER_CONTROL', 'POSITIONAL', 'Center Control', '{"center_pawns":true}', 0.7)
            """)
        }
    }
}
