package com.aiuhdhub.app.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

object UhdUpscaleEngine {

    suspend fun upscaleImage(
        context: Context,
        inputBitmap: Bitmap,
        scaleFactor: Float,
        denoiseLevel: Float, // 0.0 to 1.0
        sharpenIntensity: Float, // 0.0 to 1.0
        modelFilename: String? = null
    ): Bitmap = withContext(Dispatchers.Default) {
        // Tukar hardware bitmap kepada software bitmap jika perlu untuk mengelakkan ralat getPixels()
        val softwareBitmap = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && 
            inputBitmap.config == Bitmap.Config.HARDWARE) {
            inputBitmap.copy(Bitmap.Config.ARGB_8888, true) ?: inputBitmap
        } else {
            inputBitmap
        }

        val modelFile = if (modelFilename != null) ModelDownloader.getModelFile(context, modelFilename) else null

        // A. JALANKAN AI INTERPRETER SEBENAR JIKA MODEL TFLITE TERSEDIA
        val processedBitmap = if (modelFile != null && modelFile.name.endsWith(".tflite")) {
            try {
                runTfliteSuperResolution(modelFile, softwareBitmap)
            } catch (e: Exception) {
                e.printStackTrace()
                // Jika gagal, teruskan dengan fallback upscaling di bawah
                runFallbackScaling(softwareBitmap, scaleFactor)
            }
        } else {
            runFallbackScaling(softwareBitmap, scaleFactor)
        }

        val result = applyWinkStyleEnhancement(processedBitmap, denoiseLevel, sharpenIntensity)
        
        if (softwareBitmap != inputBitmap) {
            softwareBitmap.recycle()
        }
        
        return@withContext result
    }

    private fun runFallbackScaling(inputBitmap: Bitmap, scaleFactor: Float): Bitmap {
        val maxInputDim = 1200
        val srcWidth = inputBitmap.width
        val srcHeight = inputBitmap.height
        
        val (tempWidth, tempHeight) = if (srcWidth > maxInputDim || srcHeight > maxInputDim) {
            val ratio = srcWidth.toFloat() / srcHeight.toFloat()
            if (srcWidth > srcHeight) {
                maxInputDim to (maxInputDim / ratio).toInt()
            } else {
                (maxInputDim * ratio).toInt() to maxInputDim
            }
        } else {
            srcWidth to srcHeight
        }

        val resizedSrc = Bitmap.createScaledBitmap(inputBitmap, tempWidth, tempHeight, true)
        val targetWidth = (tempWidth * scaleFactor).toInt()
        val targetHeight = (tempHeight * scaleFactor).toInt()
        val scaledBitmap = Bitmap.createScaledBitmap(resizedSrc, targetWidth, targetHeight, true)
        
        if (resizedSrc != inputBitmap) {
            resizedSrc.recycle()
        }
        return scaledBitmap
    }

    /**
     * Mengaplikasikan pemprosesan pasca premium gaya Wink/Winkit:
     * - Unsharp Mask (USM) menggunakan perbezaan Gaussian Blur 3x3 untuk mengeluarkan liang pori & perincian halus.
     * - Suntikan Butiran Monokromatik Halus (Photographic Micro-Grain) untuk mengelakkan kesan "plastik/lukisan AI".
     * - Lengkung Kontras Dinamik S-Curve (Hermite spline) untuk kesan hitam pekat & putih berkilau yang kaya.
     */
    private suspend fun applyWinkStyleEnhancement(
        input: Bitmap,
        denoiseLevel: Float,
        sharpenIntensity: Float
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = input.width
        val height = input.height
        val output = input.copy(Bitmap.Config.ARGB_8888, true)

        val srcPixels = IntArray(width * height)
        val destPixels = IntArray(width * height)
        output.getPixels(srcPixels, 0, width, 0, 0, width, height)

        val numCores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val chunkSize = (height / numCores).coerceAtLeast(1)

        val deferreds = (0 until numCores).map { coreIndex ->
            async(Dispatchers.Default) {
                val startY = coreIndex * chunkSize
                val endY = if (coreIndex == numCores - 1) height else (coreIndex + 1) * chunkSize

                val kSharpen = sharpenIntensity * 1.6f // Skala penajaman USM yang lebih ketara
                val kDenoise = denoiseLevel * 0.4f
                val kContrast = 0.08f // Skala kontras S-curve

                for (y in startY until endY) {
                    for (x in 0 until width) {
                        val idx = y * width + x

                        // Untuk tepi imej, kekalkan piksel asal
                        if (x <= 1 || x >= width - 2 || y <= 1 || y >= height - 2) {
                            destPixels[idx] = srcPixels[idx]
                            continue
                        }

                        val center = srcPixels[idx]
                        val cR = (center shr 16) and 0xFF
                        val cG = (center shr 8) and 0xFF
                        val cB = center and 0xFF
                        val cA = (center shr 24) and 0xFF

                        // A. Denoise (Bilateral filter approximation)
                        var rR = cR.toFloat()
                        var rG = cG.toFloat()
                        var rB = cB.toFloat()

                        if (kDenoise > 0f) {
                            // Purata wajaran jiran terdekat
                            var sumR = 0f
                            var sumG = 0f
                            var sumB = 0f
                            var totalWeight = 0f

                            for (dy in -1..1) {
                                for (dx in -1..1) {
                                    val nIdx = (y + dy) * width + (x + dx)
                                    val nPixel = srcPixels[nIdx]
                                    val nR = (nPixel shr 16) and 0xFF
                                    val nG = (nPixel shr 8) and 0xFF
                                    val nB = nPixel and 0xFF

                                    // Kira perbezaan warna untuk mengekalkan tepi (Bilateral factor)
                                    val colorDiff = Math.abs(nR - cR) + Math.abs(nG - cG) + Math.abs(nB - cB)
                                    val weight = 1.0f / (1.0f + colorDiff * 0.05f)

                                    sumR += nR * weight
                                    sumG += nG * weight
                                    sumB += nB * weight
                                    totalWeight += weight
                                }
                            }
                            if (totalWeight > 0f) {
                                val denoiseR = sumR / totalWeight
                                val denoiseG = sumG / totalWeight
                                val denoiseB = sumB / totalWeight
                                
                                rR = rR * (1f - kDenoise) + denoiseR * kDenoise
                                rG = rG * (1f - kDenoise) + denoiseG * kDenoise
                                rB = rB * (1f - kDenoise) + denoiseB * kDenoise
                            }
                        }

                        // B. Unsharp Masking (USM) menggunakan perbezaan Gaussian Blur 3x3
                        if (kSharpen > 0f) {
                            val left = srcPixels[idx - 1]
                            val right = srcPixels[idx + 1]
                            val top = srcPixels[idx - width]
                            val bottom = srcPixels[idx + width]
                            val topLeft = srcPixels[idx - width - 1]
                            val topRight = srcPixels[idx - width + 1]
                            val bottomLeft = srcPixels[idx + width - 1]
                            val bottomRight = srcPixels[idx + width + 1]

                            // Kira Gaussian Blur R, G, B
                            val blurR = (
                                cR * 4 + 
                                (((left shr 16) and 0xFF) + ((right shr 16) and 0xFF) + ((top shr 16) and 0xFF) + ((bottom shr 16) and 0xFF)) * 2 +
                                (((topLeft shr 16) and 0xFF) + ((topRight shr 16) and 0xFF) + ((bottomLeft shr 16) and 0xFF) + ((bottomRight shr 16) and 0xFF)) * 1
                            ) / 16f

                            val blurG = (
                                cG * 4 + 
                                (((left shr 8) and 0xFF) + ((right shr 8) and 0xFF) + ((top shr 8) and 0xFF) + ((bottom shr 8) and 0xFF)) * 2 +
                                (((topLeft shr 8) and 0xFF) + ((topRight shr 8) and 0xFF) + ((bottomLeft shr 8) and 0xFF) + ((bottomRight shr 8) and 0xFF)) * 1
                            ) / 16f

                            val blurB = (
                                cB * 4 + 
                                ((left and 0xFF) + (right and 0xFF) + (top and 0xFF) + (bottom and 0xFF)) * 2 +
                                ((topLeft and 0xFF) + (topRight and 0xFF) + (bottomLeft and 0xFF) + (bottomRight and 0xFF)) * 1
                            ) / 16f

                            // Rujukan detail frekuensi tinggi (High-pass details)
                            val detailR = rR - blurR
                            val detailG = rG - blurG
                            val detailB = rB - blurB

                            // Tambah semula perincian dengan faktor gandaan
                            rR = (rR + detailR * kSharpen).coerceIn(0f, 255f)
                            rG = (rG + detailG * kSharpen).coerceIn(0f, 255f)
                            rB = (rB + detailB * kSharpen).coerceIn(0f, 255f)
                        }

                        // C. S-Curve Contrast (Hermite Spline) untuk popping shadows & highlights
                        val tR = rR / 255.0f
                        val tG = rG / 255.0f
                        val tB = rB / 255.0f

                        val sCurveR = (tR * tR * (3f - 2f * tR)) * 255.0f
                        val sCurveG = (tG * tG * (3f - 2f * tG)) * 255.0f
                        val sCurveB = (tB * tB * (3f - 2f * tB)) * 255.0f

                        rR = rR * (1f - kContrast) + sCurveR * kContrast
                        rG = rG * (1f - kContrast) + sCurveG * kContrast
                        rB = rB * (1f - kContrast) + sCurveB * kContrast

                        // D. Suntikan Butiran Halus Monokromatik (Replicate Wink realistic camera grain)
                        // Penjanaan rawak pseudo yang sangat pantas menggunakan kedudukan piksel
                        val noiseSeed = (x * 12547 + y * 97843)
                        val rand = ((noiseSeed % 100) / 100.0f) - 0.5f
                        val grainStrength = 3.5f * (1.0f - denoiseLevel * 0.4f) // Kurangkan sedikit jika denoise tinggi
                        val grain = rand * grainStrength

                        val finalR = (rR + grain).coerceIn(0f, 255f).toInt()
                        val finalG = (rG + grain).coerceIn(0f, 255f).toInt()
                        val finalB = (rB + grain).coerceIn(0f, 255f).toInt()

                        destPixels[idx] = (cA shl 24) or (finalR shl 16) or (finalG shl 8) or finalB
                    }
                }
            }
        }
        deferreds.awaitAll()
        output.setPixels(destPixels, 0, width, 0, 0, width, height)

        // 3. Peningkatan Saturation & Vibrancy melalui Hardware Canvas
        val finalBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(finalBitmap)
        val paint = Paint()

        val cm = ColorMatrix().apply {
            setSaturation(1.15f) // 1.15x boost saturation supaya warna lebih hidup
            
            // Sedikit kecerahan untuk bayang-bayang gelap
            val translate = 3f
            postConcat(ColorMatrix(floatArrayOf(
                1f, 0f, 0f, 0f, translate,
                0f, 1f, 0f, 0f, translate,
                0f, 0f, 1f, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )))
        }

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(output, 0f, 0f, paint)

        output.recycle()
        finalBitmap
    }

    /**
     * Memproses super resolution sebenar menggunakan sliding window (tiled inference)
     * untuk model ESRGAN TFLite.
     */
    private fun runTfliteSuperResolution(modelFile: File, inputBitmap: Bitmap): Bitmap {
        val interpreter = Interpreter(modelFile)

        val inputSize = 50
        val outputSize = 200
        val scale = 4 

        // Resolusi input dihadkan kepada max 300px untuk inferens mudah alih yang pantas
        val maxInputDim = 300
        val srcWidth = inputBitmap.width
        val srcHeight = inputBitmap.height
        
        val (tempWidth, tempHeight) = if (srcWidth > maxInputDim || srcHeight > maxInputDim) {
            val ratio = srcWidth.toFloat() / srcHeight.toFloat()
            if (srcWidth > srcHeight) {
                maxInputDim to (maxInputDim / ratio).toInt()
            } else {
                (maxInputDim * ratio).toInt() to maxInputDim
            }
        } else {
            srcWidth to srcHeight
        }

        val resizedInput = Bitmap.createScaledBitmap(inputBitmap, tempWidth, tempHeight, true)

        val outWidth = tempWidth * scale
        val outHeight = tempHeight * scale
        val outputBitmap = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outputBitmap)

        val inputBuffer = ByteBuffer.allocateDirect(1 * inputSize * inputSize * 3 * 4).apply {
            order(ByteOrder.nativeOrder())
        }
        val outputBuffer = ByteBuffer.allocateDirect(1 * outputSize * outputSize * 3 * 4).apply {
            order(ByteOrder.nativeOrder())
        }

        for (y in 0 until tempHeight step inputSize) {
            for (x in 0 until tempWidth step inputSize) {
                val tileWidth = if (x + inputSize <= tempWidth) inputSize else tempWidth - x
                val tileHeight = if (y + inputSize <= tempHeight) inputSize else tempHeight - y

                val srcTile = Bitmap.createBitmap(resizedInput, x, y, tileWidth, tileHeight)
                val modelTile = if (tileWidth == inputSize && tileHeight == inputSize) {
                    srcTile
                } else {
                    Bitmap.createScaledBitmap(srcTile, inputSize, inputSize, true)
                }

                inputBuffer.rewind()
                val intValues = IntArray(inputSize * inputSize)
                modelTile.getPixels(intValues, 0, inputSize, 0, 0, inputSize, inputSize)

                for (pixel in intValues) {
                    val r = (pixel shr 16) and 0xFF
                    val g = (pixel shr 8) and 0xFF
                    val b = pixel and 0xFF
                    inputBuffer.putFloat(r.toFloat())
                    inputBuffer.putFloat(g.toFloat())
                    inputBuffer.putFloat(b.toFloat())
                }

                outputBuffer.rewind()
                interpreter.run(inputBuffer, outputBuffer)

                outputBuffer.rewind()
                val outPixels = IntArray(outputSize * outputSize)
                for (i in 0 until outputSize * outputSize) {
                    val r = outputBuffer.float.coerceIn(0f, 255f).toInt()
                    val g = outputBuffer.float.coerceIn(0f, 255f).toInt()
                    val b = outputBuffer.float.coerceIn(0f, 255f).toInt()
                    outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }

                val outTile = Bitmap.createBitmap(outputSize, outputSize, Bitmap.Config.ARGB_8888)
                outTile.setPixels(outPixels, 0, outputSize, 0, 0, outputSize, outputSize)

                val drawX = x * scale
                val drawY = y * scale
                val drawW = tileWidth * scale
                val drawH = tileHeight * scale

                val finalTile = if (drawW == outputSize && drawH == outputSize) {
                    outTile
                } else {
                    Bitmap.createScaledBitmap(outTile, drawW, drawH, true)
                }

                canvas.drawBitmap(finalTile, drawX.toFloat(), drawY.toFloat(), null)

                if (modelTile != srcTile) modelTile.recycle()
                srcTile.recycle()
                outTile.recycle()
                if (finalTile != outTile) finalTile.recycle()
            }
        }

        if (resizedInput != inputBitmap) {
            resizedInput.recycle()
        }
        interpreter.close()

        return outputBitmap
    }
}
