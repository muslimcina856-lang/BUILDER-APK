import 'package:ayonz_app/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const String _tokenKey = 'auth_token';
  static const String _usernameKey = 'username';

  Future<bool> login(String username, String password) async {
    // Simulate API call delay
    await Future.delayed(const Duration(seconds: 1));

    // Check credentials
    bool isValid = false;
    if (username == TEST_ADMIN_USERNAME && password == TEST_ADMIN_PASSWORD) {
      isValid = true;
    } else if (username == TEST_USER_USERNAME && password == TEST_USER_PASSWORD) {
      isValid = true;
    }

    if (isValid) {
      // Save token and username to local storage
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_tokenKey, 'mock_token_${DateTime.now().millisecondsSinceEpoch}');
      await prefs.setString(_usernameKey, username);
      return true;
    }

    return false;
  }

  Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey(_tokenKey);
  }

  Future<String?> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_usernameKey);
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_usernameKey);
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }
}
