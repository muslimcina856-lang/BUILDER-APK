// App Information
const String APP_NAME = 'AYONZ Soul Founder';
const String APP_VERSION = '1.0.0';
const String AUTHOR_EMAIL = 'ayonsoulfounder@gmail.com';

// API Configuration
const String API_BASE_URL = 'https://api.example.com';
const Duration API_TIMEOUT = Duration(seconds: 30);

// Colors
const int PRIMARY_COLOR = 0xFF00D9FF;
const int PRIMARY_DARK = 0xFF0A0E27;
const int SECONDARY_COLOR = 0xFFFF00FF;
const int ACCENT_COLOR = 0xFF00D9FF;
const int TEXT_COLOR = 0xFFFFFFFF;
const int TEXT_SECONDARY = 0xFFCCCCCC;

// Typography
const String FONT_FAMILY_PRIMARY = 'Exo2';
const double FONT_SIZE_LARGE = 32;
const double FONT_SIZE_MEDIUM = 16;
const double FONT_SIZE_SMALL = 12;

// Spacing
const double SPACING_SMALL = 8;
const double SPACING_MEDIUM = 16;
const double SPACING_LARGE = 32;

// Border Radius
const double RADIUS_SMALL = 8;
const double RADIUS_MEDIUM = 12;
const double RADIUS_LARGE = 16;

// Animation Durations
const Duration ANIMATION_DURATION_SHORT = Duration(milliseconds: 300);
const Duration ANIMATION_DURATION_MEDIUM = Duration(milliseconds: 500);
const Duration ANIMATION_DURATION_LONG = Duration(milliseconds: 1000);

// Cache Durations
const Duration CACHE_DURATION_SHORT = Duration(minutes: 5);
const Duration CACHE_DURATION_MEDIUM = Duration(hours: 1);
const Duration CACHE_DURATION_LONG = Duration(days: 7);

// ===== TEST LOGIN CREDENTIALS =====
// Username: admin@ayonz.com
// Password: Ayonz@2024
// Username: user@ayonz.com
// Password: User@2024
// ===================================

const String TEST_ADMIN_USERNAME = 'admin@ayonz.com';
const String TEST_ADMIN_PASSWORD = 'Ayonz@2024';

const String TEST_USER_USERNAME = 'user@ayonz.com';
const String TEST_USER_PASSWORD = 'User@2024';
