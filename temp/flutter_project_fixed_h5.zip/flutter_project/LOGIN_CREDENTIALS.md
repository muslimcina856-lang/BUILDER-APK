# 🔐 LOGIN CREDENTIALS - AYONZ Soul Founder

## Test Accounts

### Admin Account
- **Username:** `admin@ayonz.com`
- **Password:** `Ayonz@2024`
- **Role:** Administrator with full access

### User Account
- **Username:** `user@ayonz.com`
- **Password:** `User@2024`
- **Role:** Regular user

---

## 📝 How to Use

1. **Launch the app** - You'll see the login screen
2. **Enter credentials** - Use one of the test accounts above
3. **Click LOGIN** - Wait for authentication (1 second delay simulated)
4. **Access granted** - You'll enter the main app
5. **Logout** - Click the logout icon in the top-right corner

---

## 🔧 Technical Details

### Authentication Flow

```
LoginScreen
  ↓
AuthService.login()
  ↓ (Check against TEST credentials)
  ↓
SharedPreferences (Save token + username)
  ↓
Navigate to HomePage
```

### Local Storage

- **Token Key:** `auth_token`
- **Username Key:** `username`
- **Storage:** SharedPreferences (persistent local storage)

### Files Involved

- `lib/screens/login_screen.dart` - Login UI
- `lib/services/auth_service.dart` - Authentication logic
- `lib/constants.dart` - Test credentials
- `lib/main.dart` - App navigation (RootPage)

---

## 🚀 Production Migration

For production, replace:

```dart
// Change from hardcoded test credentials
const String TEST_ADMIN_USERNAME = 'admin@ayonz.com';
const String TEST_ADMIN_PASSWORD = 'Ayonz@2024';
```

To API-based authentication:

```dart
Future<bool> login(String username, String password) async {
  final response = await post('/auth/login', data: {
    'username': username,
    'password': password,
  });
  
  if (response.success) {
    await _saveToken(response.token);
    return true;
  }
  return false;
}
```

---

## ⚠️ Security Notes

- These credentials are **ONLY for testing/development**
- **Never hardcode credentials** in production apps
- Use secure token storage (flutter_secure_storage)
- Implement proper password hashing on backend
- Use HTTPS for all API calls
- Implement refresh token mechanism

---

**Last Updated:** 2024  
**Version:** 1.0.0
