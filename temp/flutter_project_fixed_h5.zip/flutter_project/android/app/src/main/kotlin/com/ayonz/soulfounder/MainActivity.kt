package com.ayonz.soulfounder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
