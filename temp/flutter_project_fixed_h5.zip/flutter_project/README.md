# AYONZ Soul Founder - Flutter Mobile App

A professional Flutter/Android application by **AYONZ Soul Founder**.

## Project Structure

```
flutter_project/
├── lib/                    # Dart source code
│   └── main.dart          # Application entry point
├── android/               # Android native code
│   ├── app/              # Android app module
│   │   ├── build.gradle  # Android build config
│   │   └── src/          # Android source files
│   └── build.gradle      # Project-level build config
├── ios/                  # iOS native code
├── web/                  # Web platform files
├── test/                 # Unit and widget tests
├── assets/               # Images, fonts, and other assets
├── pubspec.yaml         # Flutter dependencies & configuration
└── analysis_options.yaml # Linting rules
```

## Getting Started

### Prerequisites
- Flutter SDK (>=3.0.0) - [Download](https://flutter.dev/docs/get-started/install)
- Android SDK (API Level 34+) 
- **Java 17 or higher** ⚠️ **IMPORTANT!**
- Gradle 8.0+ (automatically managed by Flutter)

### Installation

1. **Clone the project:**
   ```bash
   cd flutter_project
   ```

2. **Install dependencies:**
   ```bash
   flutter pub get
   ```

3. **Verify setup:**
   ```bash
   flutter doctor -v
   java -version        # Must be Java 17+
   ```

4. **Run the app:**
   ```bash
   # On Android emulator/device
   flutter run
   
   # With verbose output
   flutter run -v
   ```

### Build Release APK

```bash
# Clean previous builds
flutter clean
flutter pub get

# Build APK
flutter build apk --release
```

Output: `build/app/outputs/flutter-app.apk`

### Build Release Bundle (for Play Store)

```bash
flutter build appbundle --release
```

Output: `build/app/outputs/app-release.aab`

### ⚠️ Gradle Configuration Notes

- **Gradle Version:** 8.0+
- **Android Gradle Plugin:** 8.1.0
- **Java Required:** 17+
- **min SDK:** 21
- **target SDK:** 34
- **compile SDK:** 34

If you encounter build errors, see `GRADLE_FIX.md` for troubleshooting.

## Project Features

- ✨ Modern Material 3 UI design
- 🌙 Dark theme with cyan accent colors
- 🎯 Responsive layout
- 📱 Android-optimized
- 🚀 Production-ready structure
- 📦 Dependency injection ready
- 🧪 Test structure included

## Key Dependencies

- **provider** - State management
- **http** - HTTP requests
- **cached_network_image** - Image caching
- **shared_preferences** - Local storage
- **get_it** - Service locator
- **dio** - Advanced HTTP client

## Code Style & Linting

This project follows strict Dart/Flutter linting rules defined in `analysis_options.yaml`.

Run linting:
```bash
flutter analyze
```

Format code:
```bash
dart format lib/
```

## Development Workflow

1. **Create new screens** in `lib/screens/`
2. **Add models** in `lib/models/`
3. **Create services** in `lib/services/`
4. **Write unit tests** in `test/`
5. **Update assets** in `assets/`

## Contact

**AYONZ Soul Founder**  
Email: ayonsoulfounder@gmail.com  
WhatsApp: [Your WhatsApp Link]

---

**Version:** 1.0.0  
**Last Updated:** 2024
