import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class CreateAdScreen extends StatefulWidget {
  const CreateAdScreen({super.key});

  @override
  State<CreateAdScreen> createState() => _CreateAdScreenState();
}

class _CreateAdScreenState extends State<CreateAdScreen> {
  final _mediaUrlController = TextEditingController();
  final _clickUrlController = TextEditingController();
  final _titleController = TextEditingController();
  final _captionController = TextEditingController();
  final _targetController = TextEditingController();
  final _limitValueController = TextEditingController(text: '1');

  String _targetType = 'device_id'; // 'device_id' or 'telegram_id'
  String _limitType = 'views'; // 'views' or 'days'
  bool _isLoading = false;
  String? _result;
  bool _isSuccess = false;

  @override
  void dispose() {
    _mediaUrlController.dispose();
    _clickUrlController.dispose();
    _titleController.dispose();
    _captionController.dispose();
    _targetController.dispose();
    _limitValueController.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final mediaUrl = _mediaUrlController.text.trim();
    final target = _targetController.text.trim();
    final limitValue = int.tryParse(_limitValueController.text.trim());

    if (mediaUrl.isEmpty) {
      setState(() {
        _isSuccess = false;
        _result = 'Please enter a media URL (image or video link).';
      });
      return;
    }
    if (limitValue == null || limitValue <= 0) {
      setState(() {
        _isSuccess = false;
        _result = 'Please enter a valid limit value.';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _result = null;
    });

    try {
      final result = await OwnerApiService.createAd(
        mediaUrl: mediaUrl,
        clickUrl: _clickUrlController.text.trim(),
        title: _titleController.text.trim(),
        caption: _captionController.text.trim(),
        targetDeviceId: _targetType == 'device_id' ? target : null,
        targetTelegramId: _targetType == 'telegram_id' ? target : null,
        limitType: _limitType,
        limitValue: limitValue,
      );
      if (!mounted) return;
      setState(() {
        _isSuccess = result['success'] == true;
        _result = _isSuccess
            ? (target.isEmpty
                ? 'Ad created — visible to everyone.'
                : 'Ad created — it will only appear for that one user.')
            : (result['error'] ?? 'Failed to create ad.').toString();
        if (_isSuccess) {
          _mediaUrlController.clear();
          _clickUrlController.clear();
          _titleController.clear();
          _captionController.clear();
          _targetController.clear();
          _limitValueController.text = '1';
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSuccess = false;
        _result = 'Failed: $e';
      });
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Ad')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            const Text('Create Ad', style: AppText.title),
            const SizedBox(height: AppSpacing.xs),
            const Text(
              'Leave the target blank to show this ad to everyone. Fill it '
              'in to show it only to that one user.',
              style: AppText.subtitle,
            ),
            const SizedBox(height: AppSpacing.xxl),
            TextField(
              controller: _mediaUrlController,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'Media URL (image or video)',
                hintText: 'https://files.catbox.moe/xxxxx.mp4',
                prefixIcon: Icon(
                  Icons.perm_media_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _clickUrlController,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'Click-through URL (optional)',
                hintText: 'Opens when the ad is tapped',
                prefixIcon: Icon(
                  Icons.link_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Title (optional)',
                prefixIcon: Icon(
                  Icons.title_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _captionController,
              decoration: const InputDecoration(
                labelText: 'Caption (optional)',
                prefixIcon: Icon(
                  Icons.short_text_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
              maxLines: 2,
            ),
            const SizedBox(height: AppSpacing.xxl),
            const Text('TARGET (OPTIONAL)', style: AppText.sectionLabel),
            const SizedBox(height: AppSpacing.sm),
            _SegmentedChoice(
              value: _targetType,
              options: const {'device_id': 'Device ID', 'telegram_id': 'Telegram ID'},
              onChanged: (v) => setState(() => _targetType = v),
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _targetController,
              decoration: InputDecoration(
                labelText: _targetType == 'device_id' ? 'Device ID' : 'Telegram ID',
                hintText: 'Leave blank to show to everyone',
                prefixIcon: const Icon(
                  Icons.person_search_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.xxl),
            const Text('LIMIT', style: AppText.sectionLabel),
            const SizedBox(height: AppSpacing.sm),
            _SegmentedChoice(
              value: _limitType,
              options: const {'views': 'Max views', 'days': 'Max days'},
              onChanged: (v) => setState(() => _limitType = v),
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _limitValueController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: _limitType == 'views' ? 'Number of views' : 'Number of days',
                prefixIcon: const Icon(
                  Icons.timelapse_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _isLoading ? null : _create,
                icon: _isLoading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.onAccent,
                        ),
                      )
                    : const Icon(Icons.add_rounded, size: AppIcons.md),
                label: const Text('CREATE AD'),
              ),
            ),
            if (_result != null) ...[
              const SizedBox(height: AppSpacing.xl),
              _ResultBanner(isSuccess: _isSuccess, message: _result!),
            ],
          ],
        ),
      ),
    );
  }
}

class _SegmentedChoice extends StatelessWidget {
  final String value;
  final Map<String, String> options;
  final ValueChanged<String> onChanged;

  const _SegmentedChoice({
    required this.value,
    required this.options,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: options.entries.map((entry) {
        final isSelected = entry.key == value;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: entry.key == options.keys.first ? AppSpacing.sm : 0),
            child: GestureDetector(
              onTap: () => onChanged(entry.key),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.accent.withAlpha(30) : AppColors.bgElevated,
                  borderRadius: BorderRadius.circular(AppRadius.input),
                  border: Border.all(
                    color: isSelected ? AppColors.accent : Colors.transparent,
                  ),
                ),
                alignment: Alignment.center,
                child: Text(
                  entry.value,
                  style: AppText.body.copyWith(
                    fontSize: 13,
                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                    color: isSelected ? AppColors.accent : AppColors.textSecondary,
                  ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _ResultBanner extends StatelessWidget {
  final bool isSuccess;
  final String message;
  const _ResultBanner({required this.isSuccess, required this.message});

  @override
  Widget build(BuildContext context) {
    final color = isSuccess ? AppColors.success : AppColors.error;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: color.withAlpha(15),
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: color.withAlpha(60)),
      ),
      child: Row(
        children: [
          Icon(
            isSuccess ? Icons.check_circle_rounded : Icons.error_rounded,
            size: AppIcons.md,
            color: color,
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Text(message, style: AppText.body.copyWith(color: color)),
          ),
        ],
      ),
    );
  }
}
