import 'package:dio/dio.dart';
import 'package:earl_builder_owner/config.dart';

/// API service for all owner backend communication.
class OwnerApiService {
  static final Dio _dio = Dio(BaseOptions(
    baseUrl: OwnerConfig.baseUrl,
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(seconds: 30),
  ));

  static void setApiKey(String value) {
    _dio.options.headers['X-Owner-API-Key'] = value.trim();
  }

  static void clearApiKey() {
    _dio.options.headers.remove('X-Owner-API-Key');
  }

  static Future<bool> verifyApiKey(String value) async {
    try {
      final response = await _dio.get(
        '/api/owner/server-status',
        options: Options(headers: {'X-Owner-API-Key': value.trim()}),
      );
      return response.statusCode == 200;
    } on DioException catch (error) {
      if (error.response?.statusCode == 401 || error.response?.statusCode == 503) {
        return false;
      }
      rethrow;
    }
  }

  // ─── Users ──────────────────────────────────────────────────

  /// Get all users list.
  static Future<Map<String, dynamic>> getUsers() async {
    final res = await _dio.get('/api/owner/users');
    return res.data;
  }

  /// Delete a user by device_id.
  static Future<Map<String, dynamic>> deleteUser(String deviceId) async {
    final res = await _dio.post('/api/owner/delete-user', data: {
      'device_id': deviceId,
    });
    return res.data;
  }

  /// Bulk-delete users by device_id.
  static Future<Map<String, dynamic>> bulkDeleteUsers(List<String> deviceIds) async {
    final res = await _dio.post('/api/owner/bulk-delete-users', data: {
      'device_ids': deviceIds,
    });
    return res.data;
  }

  // ─── Credits ────────────────────────────────────────────────

  /// Add credit to user by device_id or telegram_id.
  static Future<Map<String, dynamic>> addCredits({
    required String target,
    required int amount,
  }) async {
    final res = await _dio.post('/api/owner/add-credit', data: {
      'target': target,
      'amount': amount,
    });
    return res.data;
  }

  // ─── Codes ──────────────────────────────────────────────────

  /// Generate credit codes.
  static Future<Map<String, dynamic>> generateCodes({
    required int amount,
    required int count,
  }) async {
    final res = await _dio.post('/api/owner/generate-code', data: {
      'amount': amount,
      'count': count,
    });
    return res.data;
  }

  /// Get active codes list.
  static Future<Map<String, dynamic>> getCodes() async {
    final res = await _dio.get('/api/owner/codes');
    return res.data;
  }

  /// Bulk-delete credit codes.
  static Future<Map<String, dynamic>> bulkDeleteCodes(List<String> codes) async {
    final res = await _dio.post('/api/owner/bulk-delete-codes', data: {
      'codes': codes,
    });
    return res.data;
  }

  // ─── Ads ────────────────────────────────────────────────────

  /// Create a new ad targeted at one user (device_id or telegram_id).
  static Future<Map<String, dynamic>> createAd({
    required String mediaUrl,
    String? clickUrl,
    String? title,
    String? caption,
    String? targetDeviceId,
    String? targetTelegramId,
    required String limitType,
    required int limitValue,
  }) async {
    final res = await _dio.post('/api/owner/create-ad', data: {
      'media_url': mediaUrl,
      if (clickUrl != null && clickUrl.isNotEmpty) 'click_url': clickUrl,
      if (title != null && title.isNotEmpty) 'title': title,
      if (caption != null && caption.isNotEmpty) 'caption': caption,
      if (targetDeviceId != null && targetDeviceId.isNotEmpty) 'target_device_id': targetDeviceId,
      if (targetTelegramId != null && targetTelegramId.isNotEmpty) 'target_telegram_id': targetTelegramId,
      'limit_type': limitType,
      'limit_value': limitValue,
    });
    return res.data;
  }

  /// Get all ads.
  static Future<Map<String, dynamic>> getAds() async {
    final res = await _dio.get('/api/owner/ads');
    return res.data;
  }

  /// Bulk-delete ads by id.
  static Future<Map<String, dynamic>> deleteAds(List<int> ids) async {
    final res = await _dio.post('/api/owner/delete-ads', data: {
      'ids': ids,
    });
    return res.data;
  }

  // ─── Server ─────────────────────────────────────────────────

  /// Toggle maintenance mode.
  static Future<Map<String, dynamic>> toggleServer({
    required String mode,
    String? title,
    String? message,
    String? musicUrl,
  }) async {
    final res = await _dio.post('/api/owner/toggle-server', data: {
      'mode': mode,
      if (title != null) 'title': title,
      if (message != null) 'message': message,
      if (musicUrl != null) 'music_url': musicUrl,
    });
    return res.data;
  }

  /// Get server status.
  static Future<Map<String, dynamic>> getServerStatus() async {
    final res = await _dio.get('/api/owner/server-status');
    return res.data;
  }
}
