# Owner App — Map

Internal control panel for the Earl Builder owner. Not intended for
Play Store distribution (sideload / internal use). R8 and resource shrinking
are still enabled for release builds.

## What it does

Talks to the Next.js API deployed on Vercel to manage users, credits,
redeemable codes, maintenance mode, and ads. Data is stored in Turso.
Nothing here builds or touches APKs directly; that is the user app and
GitHub build worker's job.

## Screens

| Screen | File | Does |
|---|---|---|
| Dashboard | `dashboard_screen.dart` | Home — quick stats, links to every screen below |
| Owner login | `owner_login_screen.dart` | Verify `OWNER_API_KEY` and store it in encrypted device storage |
| User List | `user_list_screen.dart` | Search, select, bulk-delete users; copy a user's full device ID (needed to target an ad at them) |
| Add Credit | `add_credit_screen.dart` | Manually credit a user by device ID or Telegram ID |
| Generate Codes | `generate_code_screen.dart` | Create redeemable credit codes |
| Active Codes | `code_list_screen.dart` | Search, select, bulk-delete, copy active codes |
| Server Toggle | `server_toggle_screen.dart` | Maintenance on/off, custom title/message, background music URL for the user app's offline screen |
| Create Ad | `create_ad_screen.dart` | New ad — broadcast (no target) or aimed at one device/Telegram ID |
| Manage Ads | `ads_list_screen.dart` | Search, select, bulk-delete ads; see view counts against each ad's limit |
| About | `about_screen.dart` | App info, owner/channel links |

## Permissions used

| Permission | Why |
|---|---|
| `INTERNET` | Every screen talks to the Vercel API |
| `ACCESS_NETWORK_STATE` | Detect connectivity before showing network errors |
| `POST_NOTIFICATIONS` | Background-music-related local notifications (see `server_toggle_screen.dart`) |
| `WAKE_LOCK` | Keep audio-related background work running |

Nothing sensitive (no storage, camera, location, contacts).

## Dependencies (`pubspec.yaml`)

`dio` (HTTP), `flutter_secure_storage` (encrypted owner key),
`shared_preferences` (local prefs), `url_launcher` (open Telegram links),
`share_plus` (share codes/text).

## Updating this app

1. Point `lib/config.dart`'s base URL at the same Vercel deployment used
   by the user app, without a trailing `/`.
2. Set a random `OWNER_API_KEY` of at least 16 characters in Vercel and enter
   the same value on the owner login screen.
3. Signing secrets are not included; use `android/key.properties.example`
   when configuring a private release key.
