package com.example.data.repository

import com.example.data.local.TransactionDao
import com.example.data.local.SavingsGoalDao
import com.example.data.local.CodingProgressDao
import com.example.data.model.Transaction
import com.example.data.model.SavingsGoal
import com.example.data.model.CodingProgress
import kotlinx.coroutines.flow.Flow

class FinanceRepository(
    private val transactionDao: TransactionDao,
    private val savingsGoalDao: SavingsGoalDao,
    private val codingProgressDao: CodingProgressDao
) {
    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactions()
    val allGoals: Flow<List<SavingsGoal>> = savingsGoalDao.getAllGoals()
    val allProgress: Flow<List<CodingProgress>> = codingProgressDao.getAllProgress()

    // Transaction functions
    suspend fun insertTransaction(transaction: Transaction) {
        transactionDao.insertTransaction(transaction)
    }

    suspend fun deleteTransaction(id: Int) {
        transactionDao.deleteTransactionById(id)
    }

    suspend fun clearAllTransactions() {
        transactionDao.clearAllTransactions()
    }

    // Savings Goals functions
    suspend fun insertGoal(goal: SavingsGoal) {
        savingsGoalDao.insertGoal(goal)
    }

    suspend fun updateGoalAmount(id: Int, amount: Double) {
        savingsGoalDao.updateGoalAmount(id, amount)
    }

    suspend fun deleteGoal(id: Int) {
        savingsGoalDao.deleteGoalById(id)
    }

    // Coding Progress functions
    suspend fun getProgressForLanguage(language: String): CodingProgress {
        return codingProgressDao.getProgressForLanguage(language)
            ?: CodingProgress(language = language)
    }

    suspend fun updateProgress(progress: CodingProgress) {
        codingProgressDao.insertProgress(progress)
    }
}
