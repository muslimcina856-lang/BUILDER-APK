package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.SavingsGoal
import com.example.data.model.Transaction
import com.example.ui.theme.*
import com.example.ui.viewmodel.TabungKodingViewModel
import java.text.NumberFormat
import java.util.*
import kotlin.math.ceil

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FinanceScreen(
    viewModel: TabungKodingViewModel,
    modifier: Modifier = Modifier
) {
    val transactions by viewModel.transactions.collectAsState()
    val savingsGoals by viewModel.savingsGoals.collectAsState()
    val balance by viewModel.currentBalance.collectAsState()
    val income by viewModel.totalIncome.collectAsState()
    val expense by viewModel.totalExpense.collectAsState()

    var showAddTransDialog by remember { mutableStateOf(false) }
    var showAddGoalDialog by remember { mutableStateOf(false) }
    var selectedGoalForDeposit by remember { mutableStateOf<SavingsGoal?>(null) }

    val idLocale = Locale("in", "ID")
    val rupiahFormatter = NumberFormat.getCurrencyInstance(idLocale).apply {
        maximumFractionDigits = 0
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
        // Leave space for bottom navigation bar
    ) {
        // Welcome and Header
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Ringkasan Finansial",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Kelola uangmu & penuhi impian tabunganmu!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                }
            }
        }

        // Wallet Balance Card (Premium Theme Card)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("balance_card"),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = SleekPrimaryContainer
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "SALDO UTAMA WALLET",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = SleekOnPrimaryContainer.copy(alpha = 0.7f),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = rupiahFormatter.format(balance),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                        color = SleekOnPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Income Stats
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .background(IncomeGreen.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(IncomeGreen.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowDownward,
                                    contentDescription = "Pemasukan",
                                    tint = IncomeGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Pemasukan",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                                Text(
                                    text = rupiahFormatter.format(income),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = IncomeGreen
                                )
                            }
                        }

                        // Expense Stats
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .background(ExpenseRed.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(ExpenseRed.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowUpward,
                                    contentDescription = "Pengeluaran",
                                    tint = ExpenseRed,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Pengeluaran",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                                Text(
                                    text = rupiahFormatter.format(expense),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ExpenseRed
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action Buttons Grid (Floating buttons in row format)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { showAddTransDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("add_trans_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Transaksi Baru", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { showAddGoalDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("add_goal_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(imageVector = Icons.Default.Star, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Target Tabungan", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Section: Savings Target
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🎯 Target Tabungan Anda",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (savingsGoals.isNotEmpty()) {
                    Text(
                        text = "${savingsGoals.size} Aktif",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        if (savingsGoals.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.StarBorder,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Belum Ada Target Tabungan",
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Tetapkan target impianmu (beli laptop, biaya kuliah, etc.) dan hitung kapan pencapaiannya!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { showAddGoalDialog = true },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Mulai Buat Target")
                        }
                    }
                }
            }
        } else {
            items(savingsGoals, key = { it.id }) { goal ->
                SavingsGoalItem(
                    goal = goal,
                    currencyFormatter = rupiahFormatter,
                    onDepositClick = { selectedGoalForDeposit = goal },
                    onDeleteClick = { viewModel.deleteSavingsGoal(goal.id) }
                )
            }
        }

        // Section: Historic Transactions
        item {
            Text(
                text = "📜 Riwayat Transaksi",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        if (transactions.isEmpty()) {
            item {
                Text(
                    text = "Belum ada transaksi tercatat. Mulai catat keuanganmu atau jawab kuis di Koding Hub untuk mendapatkan reward uang tunai!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                )
            }
        } else {
            items(transactions, key = { it.id }) { trans ->
                TransactionRow(
                    transaction = trans,
                    currencyFormatter = rupiahFormatter,
                    onDeleteClick = { viewModel.deleteTransaction(trans.id) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(100.dp)) // Safe padding for bottom nav bar
        }
    }

    // --- Interactive Dialogue Modals ---

    // 1. Add Transaction Dialog
    if (showAddTransDialog) {
        var title by remember { mutableStateOf("") }
        var amountStr by remember { mutableStateOf("") }
        var isExpense by remember { mutableStateOf(true) }
        var category by remember { mutableStateOf("Konsumsi") }
        var error by remember { mutableStateOf("") }

        val categories = if (isExpense) {
            listOf("Konsumsi", "Transportasi", "Gawai", "Sewa/Utilitas", "Kesehatan", "Tabungan", "Lainnya")
        } else {
            listOf("Gaji/Gaji", "Bonus Belajar", "Uang Saku", "Pemberian", "Tabungan", "Lainnya")
        }

        Dialog(onDismissRequest = { showAddTransDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Tambah Transaksi Baru",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )

                    // Type Toggle (Pemasukan vs Pengeluaran)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Text(
                            text = "Pengeluaran",
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    isExpense = true
                                    category = "Konsumsi"
                                }
                                .background(if (isExpense) ExpenseRed.copy(alpha = 0.2f) else Color.Transparent)
                                .padding(vertical = 10.dp),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            color = if (isExpense) ExpenseRed else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Divider(modifier = Modifier.width(1.dp).fillMaxHeight())
                        Text(
                            text = "Pemasukan",
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    isExpense = false
                                    category = "Gaji/Gaji"
                                }
                                .background(if (!isExpense) IncomeGreen.copy(alpha = 0.2f) else Color.Transparent)
                                .padding(vertical = 10.dp),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            color = if (!isExpense) IncomeGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Nama Transaksi (eg. Kopi, Gaji)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("trans_title_input")
                    )

                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("Jumlah (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("trans_amount_input")
                    )

                    // Category Selector Scroll
                    Text(text = "Kategori", style = MaterialTheme.typography.labelLarge)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    if (error.isNotEmpty()) {
                        Text(text = error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showAddTransDialog = false }) {
                            Text("Batal")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val amt = amountStr.toDoubleOrNull()
                                if (title.trim().isEmpty()) {
                                    error = "Judul transaksi tidak boleh kosong."
                                } else if (amt == null || amt <= 0) {
                                    error = "Masukkan jumlah nominal yang valid."
                                } else {
                                    viewModel.addTransaction(title, amt, isExpense, category)
                                    showAddTransDialog = false
                                }
                            },
                            modifier = Modifier.testTag("save_trans_button")
                        ) {
                            Text("Simpan")
                        }
                    }
                }
            }
        }
    }

    // 2. Add Savings Goal Dialog
    if (showAddGoalDialog) {
        var title by remember { mutableStateOf("") }
        var targetAmountStr by remember { mutableStateOf("") }
        var currentAmountStr by remember { mutableStateOf("") }
        var monthlyContributionStr by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        var error by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddGoalDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.padding(20.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = "Buat Target Tabungan Baru",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("Nama Impian (eg. Laptop Koding, iPad)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("goal_title_input")
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = targetAmountStr,
                            onValueChange = { targetAmountStr = it },
                            label = { Text("Dana yang Dibutuhkan (Rp)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("goal_target_input")
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = currentAmountStr,
                            onValueChange = { currentAmountStr = it },
                            label = { Text("Jumlah Terkumpul Awal (Rp)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("goal_current_input")
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = monthlyContributionStr,
                            onValueChange = { monthlyContributionStr = it },
                            label = { Text("Rencana Nabung Rutin (Rp / Bulan)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            placeholder = { Text("eg. 200000") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("goal_monthly_input")
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("Catatan / Motifasi") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (error.isNotEmpty()) {
                        item {
                            Text(text = error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { showAddGoalDialog = false }) {
                                Text("Batal")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val targetAmt = targetAmountStr.toDoubleOrNull()
                                    val currentAmt = currentAmountStr.toDoubleOrNull() ?: 0.0
                                    val speed = monthlyContributionStr.toDoubleOrNull() ?: 0.0

                                    if (title.trim().isEmpty()) {
                                        error = "Masukkan nama impian Anda."
                                    } else if (targetAmt == null || targetAmt <= 0) {
                                        error = "Masukkan nominal dana yang sah."
                                    } else if (currentAmt > targetAmt) {
                                        error = "Awal terkumpul tidak boleh melebihi target."
                                    } else {
                                        viewModel.addSavingsGoal(title, targetAmt, currentAmt, note, speed)
                                        showAddGoalDialog = false
                                    }
                                },
                                modifier = Modifier.testTag("save_goal_button")
                            ) {
                                Text("Buat Mimpi")
                            }
                        }
                    }
                }
            }
        }
    }

    // 3. Deposit to Savings Goal Dialog
    selectedGoalForDeposit?.let { goal ->
        var depositStr by remember { mutableStateOf("") }
        var error by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { selectedGoalForDeposit = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Setor Tabungan: ${goal.title}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Saldo walletmu saat ini: ${rupiahFormatter.format(balance)}. Tabungan akan dialokasikan langsung dari wallet utamamu.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    OutlinedTextField(
                        value = depositStr,
                        onValueChange = { depositStr = it },
                        label = { Text("Nominal Setoran (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("deposit_input")
                    )

                    if (error.isNotEmpty()) {
                        Text(text = error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { selectedGoalForDeposit = null }) {
                            Text("Batal")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val depAmt = depositStr.toDoubleOrNull()
                                if (depAmt == null || depAmt <= 0) {
                                    error = "Masukkan nominal setoran yang valid."
                                } else if (depAmt > balance) {
                                    error = "Sisa saldo utama walletmu tidak mencukupi."
                                } else {
                                    viewModel.addSavingFromWallet(goal, depAmt)
                                    selectedGoalForDeposit = null
                                }
                            },
                            modifier = Modifier.testTag("submit_deposit_button")
                        ) {
                            Text("Setor Sekarang")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SavingsGoalItem(
    goal: SavingsGoal,
    currencyFormatter: NumberFormat,
    onDepositClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val progressPercent = if (goal.targetAmount > 0) (goal.currentAmount / goal.targetAmount).coerceIn(0.0, 1.0) else 0.0
    val remaining = goal.targetAmount - goal.currentAmount

    // Dynamic Estimation formatting
    val timeEstimationText = if (remaining <= 0) {
        "Target Tercapai! Luar biasa! 🎉"
    } else if (goal.monthlyContribution > 0) {
        val monthsRemaining = ceil(remaining / goal.monthlyContribution).toInt()
        "Sisa ${currencyFormatter.format(remaining)} lagi. Perkiraan rampung: $monthsRemaining bulan lagi (dengan menabung ${currencyFormatter.format(goal.monthlyContribution)} / bulan)"
    } else {
        "Tambahkan kontribusi tabungan rutin untuk melihat estimasi waktu pencapainnya secara instan."
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("savings_goal_item_${goal.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, SleekTonalBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = goal.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (goal.note.isNotEmpty()) {
                        Text(
                            text = goal.note,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    }
                }
                
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(24.dp)) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Hapus Target",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress text: Collected / Target
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "Terkumpul",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                    Text(
                        text = currencyFormatter.format(goal.currentAmount),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Target Sasaran",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                    Text(
                        text = currencyFormatter.format(goal.targetAmount),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = { progressPercent.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(CircleShape),
                color = if (progressPercent >= 1.0) IncomeGreen else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Dynamic estimated accomplishment text (Indonesian Indonesian)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.DateRange,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(16.dp).padding(top = 1.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = timeEstimationText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                    fontWeight = FontWeight.Medium,
                    lineHeight = 16.sp
                )
            }

            // Quick deposit action
            if (goal.currentAmount < goal.targetAmount) {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onDepositClick,
                    modifier = Modifier
                        .align(Alignment.End)
                        .height(36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Nabung Dari Dompet", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun TransactionRow(
    transaction: Transaction,
    currencyFormatter: NumberFormat,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Category Icon indicators
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            color = if (transaction.isExpense) ExpenseRed.copy(alpha = 0.12f) else IncomeGreen.copy(alpha = 0.12f),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            transaction.category == "Tabungan" -> Icons.Default.Savings
                            transaction.category == "Bonus Belajar" -> Icons.Default.EmojiEvents
                            transaction.isExpense -> Icons.Default.TrendingDown
                            else -> Icons.Default.TrendingUp
                        },
                        contentDescription = null,
                        tint = if (transaction.isExpense) ExpenseRed else IncomeGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = transaction.title,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = transaction.category,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${if (transaction.isExpense) "-" else "+"}${currencyFormatter.format(transaction.amount)}",
                    fontWeight = FontWeight.Bold,
                    color = if (transaction.isExpense) ExpenseRed else IncomeGreen,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(24.dp)) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Hapus",
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
