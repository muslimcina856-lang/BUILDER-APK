package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "coding_progress")
data class CodingProgress(
    @PrimaryKey val language: String, // e.g., "kotlin", "javascript", "python", "html_css"
    val completedLessonsUnit: Int = 0,
    val totalQuizzesPassed: Int = 0,
    val scoreExp: Int = 0
)
