package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CourseData
import com.example.data.model.LanguageCourse
import com.example.data.model.Lesson
import com.example.ui.theme.*
import com.example.ui.viewmodel.TabungKodingViewModel

@Composable
fun CodingScreen(
    viewModel: TabungKodingViewModel,
    modifier: Modifier = Modifier
) {
    val selectedCourse by viewModel.selectedCourse.collectAsState()
    val selectedLesson by viewModel.selectedLesson.collectAsState()
    val codingProgress by viewModel.codingProgress.collectAsState()
    
    // Smooth transition between screens
    AnimatedContent(
        targetState = Pair(selectedCourse, selectedLesson),
        transitionSpec = {
            fadeIn() togetherWith fadeOut()
        },
        label = "CodingNavigation"
    ) { (course, lesson) ->
        when {
            lesson != null -> {
                LessonDetailScreen(
                    course = course!!,
                    lesson = lesson,
                    viewModel = viewModel,
                    modifier = modifier
                )
            }
            course != null -> {
                CourseDetailScreen(
                    course = course,
                    viewModel = viewModel,
                    codingProgress = codingProgress,
                    modifier = modifier
                )
            }
            else -> {
                CourseListScreen(
                    viewModel = viewModel,
                    codingProgress = codingProgress,
                    modifier = modifier
                )
            }
        }
    }
}

@Composable
fun CourseListScreen(
    viewModel: TabungKodingViewModel,
    codingProgress: List<com.example.data.model.CodingProgress>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "💻 Akademi Koding",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Belajar coding dasar, selesaikan kuis interaktif, raih bonus Uang Tunai + EXP untuk penuhi target tabunganmu!",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        }

        items(CourseData.courses) { course ->
            val progress = codingProgress.find { it.language == course.id }
            val completedLessons = progress?.completedLessonsUnit ?: 0
            val totalLessons = course.lessons.size
            val passedQuizzes = progress?.totalQuizzesPassed ?: 0
            val scoreExp = progress?.scoreExp ?: 0

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectCourse(course) }
                    .testTag("course_card_${course.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Emoji / Mascot Box
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = course.iconEmoji, fontSize = 32.sp)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = course.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = course.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))

                        // Stats bar (XP & Progress)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = null,
                                    tint = TertiaryAmber,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$scoreExp EXP",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TertiaryAmber
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.DoneAll,
                                    contentDescription = null,
                                    tint = SecondaryTeal,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Progress: $completedLessons/$totalLessons Bab",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SecondaryTeal
                                )
                            }
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.KeyboardArrowRight,
                        contentDescription = "Masuk",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        item {
            // High Motivation Tip Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Lightbulb,
                        contentDescription = "Tips",
                        tint = TertiaryAmber,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Tahukah Kamu?",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Setiap kuis coding yang kamu selesaikan akan ditukar dengan HADIAH uang saku (hingga Rp 30.000/kuis). Kamu bisa membagikan/menyetorkan bonus saldo ini ke dalam impian target tabunganmu!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@Composable
fun CourseDetailScreen(
    course: LanguageCourse,
    viewModel: TabungKodingViewModel,
    codingProgress: List<com.example.data.model.CodingProgress>,
    modifier: Modifier = Modifier
) {
    val progress = codingProgress.find { it.language == course.id }
    val completedLessons = progress?.completedLessonsUnit ?: 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = { viewModel.selectCourse(null) }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Kembali")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = course.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Card Description
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Deskripsi Kelas",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = course.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Text(
                text = "📚 Daftar Pembelajaran",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // List of Lessons
        items(course.lessons) { lesson ->
            val isUnlocked = lesson.id == 1 || lesson.id <= completedLessons + 1
            val isCompleted = lesson.id <= completedLessons

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = isUnlocked) { viewModel.selectLesson(lesson) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isUnlocked) {
                        if (isCompleted) IncomeGreen.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                    } else {
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f).run { Color(0xFFE2E8F0) } // generic light gray
                    }
                )
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Lesson Number Indicators
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    color = when {
                                        isCompleted -> IncomeGreen
                                        isUnlocked -> MaterialTheme.colorScheme.primary
                                        else -> Color.Gray.copy(alpha = 0.4f)
                                    },
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCompleted) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            } else {
                                Text(
                                    text = lesson.id.toString(),
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = lesson.title,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                            )
                            Text(
                                text = lesson.summary,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isUnlocked) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                            )
                        }
                    }

                    if (isUnlocked) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Mulai",
                            tint = if (isCompleted) IncomeGreen else MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Terkunci",
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

@Composable
fun LessonDetailScreen(
    course: LanguageCourse,
    lesson: Lesson,
    viewModel: TabungKodingViewModel,
    modifier: Modifier = Modifier
) {
    val quizAnswer by viewModel.userQuizAnswer.collectAsState()
    val quizIsCorrect by viewModel.quizIsCorrect.collectAsState()

    var consoleOutput by remember { mutableStateOf<String?>(null) }
    var isSimulating by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Upper Navigation
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = { viewModel.selectLesson(null) }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Kembali ke bab")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Bab ${lesson.id}: ${lesson.title}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = course.name,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Lesson Theory Content
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "📖 Teori Dasar & Analogi",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = lesson.content,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        // Live Interactive Code Sandbox Simulator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CodingSnippetBg)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📝 Playground Kode",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color(0xFFA5B4FC), // Indigo Hue
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = null,
                            tint = Color(0xFFA5B4FC),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = lesson.codeSnippet,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFF8FAFC),
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CodingSnippetBg, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (consoleOutput != null) {
                        // Console simulated terminal of outputs
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF020617), RoundedCornerShape(8.dp))
                                .border(1.dp, Color.Green.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "CONSOLE OUTPUT [SIMULASI]:",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Green,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = consoleOutput!!,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.Green,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Button(
                        onClick = {
                            isSimulating = true
                            // Simulate compile logger output delay
                            consoleOutput = "Compiling and executing...\n${lesson.expectedOutput}"
                            isSimulating = false
                        },
                        modifier = Modifier
                            .align(Alignment.End)
                            .testTag("run_code_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                    ) {
                        Text("Simulasikan Kompilasi", fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Interactive Multiple-Choice Quiz Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("quiz_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "⚡ Mini Kuis Bab ${lesson.id}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Hadiah: +Rp ${lesson.rewardAmount.toInt()} & +${lesson.rewardExp} EXP",
                        style = MaterialTheme.typography.labelSmall,
                        color = TertiaryAmber,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = lesson.quizQuestion,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quiz choice components list
                    lesson.quizChoices.forEachIndexed { idx, choice ->
                        val isSelected = quizAnswer == idx
                        val outlineColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                        val containerBg = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(containerBg)
                                .border(1.5.dp, outlineColor, RoundedCornerShape(10.dp))
                                .clickable {
                                    if (quizIsCorrect != true) {
                                        viewModel.chooseQuizAnswer(idx)
                                    }
                                }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    if (quizIsCorrect != true) {
                                        viewModel.chooseQuizAnswer(idx)
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = choice, style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Feedback banners
                    AnimatedVisibility(visible = quizIsCorrect != null) {
                        if (quizIsCorrect == true) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(containerColor = IncomeGreen.copy(alpha = 0.15f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = IncomeGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(text = "JAWABAN TEPAT! 🎉", fontWeight = FontWeight.Bold, color = IncomeGreen)
                                        Text(
                                            text = "Selamat! Saldo hadiah Rp ${lesson.rewardAmount.toInt()} sudah ditambahkan ke Wallet Utamamu. Ambil bonus dan setor ke Target Tabungan sekarang!",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = IncomeGreen.copy(0.9f)
                                        )
                                    }
                                }
                            }
                        } else if (quizIsCorrect == false) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(containerColor = ExpenseRed.copy(alpha = 0.15f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Cancel, contentDescription = null, tint = ExpenseRed)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Aduh, jawaban masih belum pas. Baca analoginya lagi lalu coba lagi ya!",
                                        fontWeight = FontWeight.Bold,
                                        color = ExpenseRed,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                    
                    // Action confirm quiz answer button
                    Button(
                        onClick = { viewModel.submitQuiz() },
                        enabled = quizAnswer != null && quizIsCorrect != true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_quiz_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Kirim Jawabanku", fontWeight = FontWeight.Bold)
                    }

                    if (quizIsCorrect == true) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { viewModel.selectLesson(null) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Selesai & Bab Selanjutnya")
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}
