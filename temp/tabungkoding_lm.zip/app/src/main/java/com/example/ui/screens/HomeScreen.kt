package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SavingsGoal
import com.example.ui.theme.SleekDarkTerminal
import com.example.ui.theme.SleekPrimary
import com.example.ui.theme.SleekPrimaryContainer
import com.example.ui.theme.SleekTonalBorder
import com.example.ui.viewmodel.TabungKodingViewModel
import java.text.NumberFormat
import java.util.*
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    viewModel: TabungKodingViewModel,
    onNavigateToTab: (com.example.NavigationTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val goals by viewModel.savingsGoals.collectAsState()
    val balance by viewModel.currentBalance.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val codingProgress by viewModel.codingProgress.collectAsState()

    val rupiahFormatter = remember {
        NumberFormat.getCurrencyInstance(Locale("in", "ID")).apply {
            maximumFractionDigits = 0
        }
    }

    // Helper: format large currency compactly (e.g. Rp 12.4M)
    fun formatCompactRupiah(value: Double): String {
        return when {
            value >= 1_000_000_000 -> {
                val valInM = value / 1_000_000_000.0
                String.format(Locale.US, "Rp %.1fB", valInM)
            }
            value >= 1_000_000 -> {
                val valInM = value / 1_000_000.0
                String.format(Locale.US, "Rp %.1fM", valInM)
            }
            value >= 1_000 -> {
                val valInK = value / 1_000.0
                String.format(Locale.US, "Rp %.1fK", valInK)
            }
            else -> rupiahFormatter.format(value)
        }
    }

    // Dynamic extraction of Active Target
    val activeGoal = goals.firstOrNull() ?: SavingsGoal(
        title = "MacBook Air M3",
        targetAmount = 15000000.0,
        currentAmount = 7350000.0,
        note = "Impian Laptop Desain & Coding",
        monthlyContribution = 1800000.0,
        id = -1
    )

    val progressPercent = if (activeGoal.targetAmount > 0) {
        ((activeGoal.currentAmount / activeGoal.targetAmount) * 100).roundToInt()
    } else 0

    // Calculate savings of current month (Transactions categorized as "Tabungan")
    val savingsThisMonth = transactions
        .filter { it.category.lowercase(Locale.ROOT).contains("tabung") }
        .sumOf { it.amount }

    // Aggregate overall progress points
    val totalExp = codingProgress.sumOf { it.scoreExp }
    val totalLessonsPassed = codingProgress.sumOf { it.completedLessonsUnit }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))
        }

        // SECTION 1: Active Target Card (Sleek Border & shadow representation)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, SleekTonalBorder, RoundedCornerShape(24.dp))
                    .padding(20.dp)
                    .testTag("active_target_card")
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrackChanges,
                                contentDescription = "Sleek Target",
                                tint = SleekPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Text(
                                text = "Target Tabungan: ${activeGoal.title}",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        
                        // Percentage Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SleekPrimaryContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "$progressPercent%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = SleekPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = rupiahFormatter.format(activeGoal.currentAmount),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "dari " + formatCompactRupiah(activeGoal.targetAmount),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Progress Track Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFE6E1E5))
                    ) {
                        val fraction = (activeGoal.currentAmount / activeGoal.targetAmount).coerceIn(0.0, 1.0).toFloat()
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(fraction)
                                .clip(RoundedCornerShape(10.dp))
                                .background(SleekPrimary)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Time estimate
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Estimasi waktu",
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            modifier = Modifier.size(16.dp)
                        )
                        val remaining = maxOf(0.0, activeGoal.targetAmount - activeGoal.currentAmount)
                        val monthlyContribution = if (activeGoal.monthlyContribution > 0) activeGoal.monthlyContribution else 500000.0
                        val estimatedMonths = if (remaining > 0) {
                            (remaining / monthlyContribution).toInt().coerceAtLeast(1)
                        } else 0

                        val estimasiText = if (estimatedMonths > 0) {
                            "Estimasi tercapai dalam $estimatedMonths Bulan lagi"
                        } else {
                            "Impian telah Tercapai! Selamat! 🎉"
                        }

                        Text(
                            text = estimasiText,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }

        // SECTION 2: Grid aspect cards (1. Total Saldo | 2. Saved This Month)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Total Balance (Active colored background matching HTML)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(24.dp))
                        .background(SleekPrimaryContainer)
                        .padding(16.dp)
                        .aspectRatio(1.1f)
                        .testTag("dashboard_balance_box")
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "Wallet",
                            tint = Color(0xFF21005D),
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = "Total Saldo",
                                fontSize = 12.sp,
                                color = Color(0xFF21005D).copy(alpha = 0.7f),
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = formatCompactRupiah(balance),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF21005D)
                            )
                        }
                    }
                }

                // Saved This Month (Transparent light background with slate border matching HTML)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFFF3EDF7))
                        .border(1.dp, SleekTonalBorder, RoundedCornerShape(24.dp))
                        .padding(16.dp)
                        .aspectRatio(1.1f)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = "Trending naik",
                            tint = SleekPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = "Tabungan Masuk",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "+" + formatCompactRupiah(savingsThisMonth),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // SECTION 3: Learn Coding Terminal Box (Sleek Dark Theme section matching HTML)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(SleekDarkTerminal)
                    .padding(20.dp)
                    .testTag("terminal_learn_card")
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = "Terminal",
                                tint = Color(0xFFD0BCFF),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Akademi Coding",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }
                        
                        Text(
                            text = "OFFLINE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD0BCFF),
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "Struktur Data & Kuis Logika",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Text(
                        text = "Selesaikan kurikulum pelajaran bahasa pemrograman untuk meraih koin bonus dan menyalurkannya langsung ke tabung impianmu.",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.65f),
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy((-6).dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFD0BCFF))
                                    .border(2.dp, SleekDarkTerminal, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("XP", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF381E72))
                            }
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFFB800))
                                    .border(2.dp, SleekDarkTerminal, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Star, null, tint = Color.Black, modifier = Modifier.size(12.dp))
                            }
                            
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "$totalExp XP • $totalLessonsPassed Kuis",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.5f)
                            )
                        }

                        Button(
                            onClick = { onNavigateToTab(com.example.NavigationTab.CODING) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD0BCFF),
                                contentColor = Color(0xFF381E72)
                            ),
                            shape = RoundedCornerShape(100.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "Mulai Belajar",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}
