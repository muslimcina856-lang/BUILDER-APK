package com.example.data.model

data class Lesson(
    val id: Int,
    val title: String,
    val summary: String,
    val content: String,
    val codeSnippet: String,
    val expectedOutput: String,
    val quizQuestion: String,
    val quizChoices: List<String>,
    val correctChoiceIndex: Int,
    val rewardAmount: Double,
    val rewardExp: Int
)

data class LanguageCourse(
    val id: String, // kotlin, js, python, web
    val name: String,
    val subtitle: String,
    val description: String,
    val iconEmoji: String,
    val lessons: List<Lesson>
)

object CourseData {
    val courses = listOf(
        LanguageCourse(
            id = "kotlin",
            name = "Kotlin (Android)",
            subtitle = "Bahasa resmi pembuatan aplikasi Android modern.",
            description = "Kotlin sengaja dirancang ringkas, aman, dan fully-interoperable dengan Java. Di sini kamu akan belajar dasar-dasar Kotlin yang dipakai langsung oleh developer profesional.",
            iconEmoji = "🤖",
            lessons = listOf(
                Lesson(
                    id = 1,
                    title = "Variabel & Tipe Data",
                    summary = "Mengenal val (read-only) dan var (mutable).",
                    content = "Di Kotlin, kita mendefinisikan variabel menggunakan dua kata kunci utama:\n- `val`: Dipakai untuk variabel CONSTANT / TIDAK BISA diubah setelah ditetapkan pertama kali (Immutable).\n- `var`: Dipakai untuk variabel biasa yang nilainya BISA berubah (Mutable).\n\nAnalogi Tabungan: `val` mirip seperti No. Rekening Bank kamu (tidak pernah berubah), sedangkan `var` mirip dengan Saldo Dompet kamu yang terus berkurang atau bertambah ketika bertransaksi.",
                    codeSnippet = "val noRekening = \"123-456\"\nvar saldoDompet = 50000\n\nsaldoDompet = saldoDompet - 10000\nprintln(\"Saldo sekarang: \$saldoDompet\")",
                    expectedOutput = "Saldo sekarang: 40000",
                    quizQuestion = "Manakah deklarasi variabel yang benar jika nilainya tidak ingin bisa diubah kemudian hari?",
                    quizChoices = listOf(
                        "var nama = \"Budi\"",
                        "val nama = \"Budi\"",
                        "const nama = \"Budi\"",
                        "let nama = \"Budi\""
                    ),
                    correctChoiceIndex = 1,
                    rewardAmount = 15000.0,
                    rewardExp = 15
                ),
                Lesson(
                    id = 2,
                    title = "Pengkondisian (If-Else)",
                    summary = "Percabangan logika keputusan dalam program.",
                    content = "Gunakan `if` dan `else` untuk membuat keputusan.\n\nContoh logika menabung:\nJika saldo lebih besar dari harga barang, maka kita bisa membeli barang tersebut. Selain itu, mari kumpulkan uang lagi!\n\nDi Kotlin, Expression `if` juga bisa langsung mengembalikan nilai lho!",
                    codeSnippet = "val hargaBuku = 35000\nval tabunganKita = 50000\n\nif (tabunganKita >= hargaBuku) {\n    println(\"Buku berhasil dibeli!\")\n} else {\n    println(\"Menabunglah lagi!\")\n}",
                    expectedOutput = "Buku berhasil dibeli!",
                    quizQuestion = "Jika tabunganKita bernilai 20000 dan hargaBuku bernilai 35000, pernyataan mana yang dieksekusi koordinat diatas?",
                    quizChoices = listOf(
                        "Membeli buku",
                        "Menabunglah lagi!",
                        "Error kompilasi",
                        "Kedua blok dieksekusi"
                    ),
                    correctChoiceIndex = 1,
                    rewardAmount = 20000.0,
                    rewardExp = 20
                )
            )
        ),
        LanguageCourse(
            id = "js",
            name = "JavaScript (Web)",
            subtitle = "Bahasa interaktif penunjang seisi jaring internet.",
            description = "JavaScript adalah motor penggerak interaktivitas di halaman web. Dari validasi kalkulator tabungan hingga web game,JS adalah dasarnya.",
            iconEmoji = "🌐",
            lessons = listOf(
                Lesson(
                    id = 1,
                    title = "Pengenalan Fungsi",
                    summary = "Fungsi (Function) membungkus kode kerja berulang.",
                    content = "Fungsi (`function`) adalah blok kode yang dirancang untuk melakukan tugas tertentu. Kita mendefinisikannya sekali, lalu memanggilnya berulang kali di berbagai tempat.\n\nFungsi ini mirip dengan mesin ATM otomatis: kamu masukkan kartu dan PIN (input parameter), mesin akan memproses dan mengeluarkan uang (return value).",
                    codeSnippet = "function hitungSisaTarget(target, terkumpul) {\n    return target - terkumpul;\n}\n\nlet sisa = hitungSisaTarget(100000, 30000);\nconsole.log(\"Sisa target: \" + sisa);",
                    expectedOutput = "Sisa target: 70000",
                    quizQuestion = "Kata kunci apa yang dipakai untuk mengembalikan nilai hasil perhitungan dari dalam fungsi?",
                    quizChoices = listOf(
                        "send",
                        "give",
                        "return",
                        "break"
                    ),
                    correctChoiceIndex = 2,
                    rewardAmount = 25000.0,
                    rewardExp = 30
                )
            )
        ),
        LanguageCourse(
            id = "python",
            name = "Python (Data Science)",
            subtitle = "Bahasa populer untuk AI dan pengolahan statistik keuangan.",
            description = "Python terkenal dengan kodenya yang bersih menyerupai bahasa Inggris manusia, sering kali digunakan untuk analisis finansial data sains.",
            iconEmoji = "🐍",
            lessons = listOf(
                Lesson(
                    id = 1,
                    title = "Perulangan (For-Loops)",
                    summary = "Eksekusi kumpulan instruksi berulang kali otomatis.",
                    content = "Di Python, kita menggunakan `for` untuk mengulangi baris kode tertentu beberapa kali sesuai range yang kita mau.\n\nMisalkan kamu ingin menyetor uang jajan sebesar Rp10k setiap minggu selama 4 minggu berturut-turut. Komputer bisa melakukan looping penjumlahan ini dengan sangat mudah dalam hitungan milidetik!",
                    codeSnippet = "saldo = 0\nfor minggu in range(1, 5):\n    saldo += 10000\n    print(f\"Minggu {minggu}: Saldo {saldo}\")",
                    expectedOutput = "Minggu 4: Saldo 40000",
                    quizQuestion = "Berapakah jumlah pengulangan yang dilakukan oleh perintah Python 'for i in range(1, 5)'?",
                    quizChoices = listOf(
                        "3 kali",
                        "4 kali (i = 1, 2, 3, 4)",
                        "5 kali",
                        "Tak terhingga"
                    ),
                    correctChoiceIndex = 1,
                    rewardAmount = 30000.0,
                    rewardExp = 25
                )
            )
        )
    )
}
