package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.CodingScreen
import com.example.ui.screens.FinanceScreen
import com.example.ui.screens.AiTutorScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.TabungKodingViewModel

enum class NavigationTab {
    FINANCE,
    CODING,
    AI_TUTOR
}

class MainActivity : ComponentActivity() {
    private val viewModel: TabungKodingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                var activeTab by remember { mutableStateOf(NavigationTab.FINANCE) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Custom styled bottom navigation bar following Material 3 guidelines
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Transparent)
                                .windowInsetsPadding(WindowInsets.navigationBars)
                        ) {
                            NavigationBar(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                                    .clip(RoundedCornerShape(24.dp))
                                    .testTag("bottom_nav_bar"),
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
                            ) {
                                NavigationBarItem(
                                    selected = activeTab == NavigationTab.FINANCE,
                                    onClick = { activeTab = NavigationTab.FINANCE },
                                    label = { Text("Keuangan", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    icon = {
                                        Icon(
                                            imageVector = Icons.Default.Home,
                                            contentDescription = "Menu Keuangan",
                                            modifier = Modifier.size(24.dp)
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                    ),
                                    modifier = Modifier.testTag("nav_finance")
                                )

                                NavigationBarItem(
                                    selected = activeTab == NavigationTab.CODING,
                                    onClick = { activeTab = NavigationTab.CODING },
                                    label = { Text("Akademi", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    icon = {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "Menu Koding",
                                            modifier = Modifier.size(24.dp)
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                    ),
                                    modifier = Modifier.testTag("nav_coding")
                                )

                                NavigationBarItem(
                                    selected = activeTab == NavigationTab.AI_TUTOR,
                                    onClick = { activeTab = NavigationTab.AI_TUTOR },
                                    label = { Text("Tutor AI", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    icon = {
                                        Icon(
                                            imageVector = Icons.Default.Face,
                                            contentDescription = "Tutor AI",
                                            modifier = Modifier.size(24.dp)
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                    ),
                                    modifier = Modifier.testTag("nav_ai")
                                )
                            }
                        }
                    },
                    contentWindowInsets = WindowInsets.statusBars
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                            .padding(innerPadding)
                    ) {
                        when (activeTab) {
                            NavigationTab.FINANCE -> {
                                FinanceScreen(viewModel = viewModel)
                            }
                            NavigationTab.CODING -> {
                                CodingScreen(viewModel = viewModel)
                            }
                            NavigationTab.AI_TUTOR -> {
                                AiTutorScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
