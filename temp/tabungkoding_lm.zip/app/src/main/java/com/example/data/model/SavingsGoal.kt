package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "savings_goals")
data class SavingsGoal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val note: String = "",
    val monthlyContribution: Double = 0.0, // Manual saving speed inputted by user (or 0 for auto)
    val creationTimestamp: Long = System.currentTimeMillis()
)
