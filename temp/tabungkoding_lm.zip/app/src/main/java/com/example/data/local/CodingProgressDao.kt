package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.CodingProgress
import kotlinx.coroutines.flow.Flow

@Dao
interface CodingProgressDao {
    @Query("SELECT * FROM coding_progress")
    fun getAllProgress(): Flow<List<CodingProgress>>

    @Query("SELECT * FROM coding_progress WHERE language = :language LIMIT 1")
    suspend fun getProgressForLanguage(language: String): CodingProgress?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: CodingProgress)
}
