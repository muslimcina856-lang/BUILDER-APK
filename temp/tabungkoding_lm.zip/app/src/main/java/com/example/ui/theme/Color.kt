package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Cozy Lavender Theme
val SleekPrimary = Color(0xFF6750A4)
val SleekOnPrimary = Color(0xFFFFFFFF)
val SleekPrimaryContainer = Color(0xFFEADDFF)
val SleekOnPrimaryContainer = Color(0xFF21005D)
val SleekBackground = Color(0xFFF7F9FC)
val SleekSurface = Color(0xFFFFFFFF)
val SleekOnSurface = Color(0xFF1C1B1F)
val SleekSecondary = Color(0xFF625B71)
val SleekTonalBorder = Color(0xFFE7E0EC)
val SleekDarkTerminal = Color(0xFF1C1B1F)

val SecondaryTeal = Color(0xFF14B8A6) // Teal Targets
val TertiaryAmber = Color(0xFFF59E0B) // Amber Goal/Coins

// Custom UI Colors
val IncomeGreen = Color(0xFF1F9D55) // Richer Emerald Green
val ExpenseRed = Color(0xFFD9383A) // Energetic Rose Red
val CodingSnippetBg = Color(0xFF0F172A) // Sleek Sandbox Editor Background
