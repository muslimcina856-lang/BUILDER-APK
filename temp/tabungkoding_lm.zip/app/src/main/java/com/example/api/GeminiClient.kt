package com.example.api

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    suspend fun generateCodingExplanation(
        prompt: String, 
        systemInstruction: String = "Anda adalah tutor coding santai, ramah, interaktif dan berbahasa Indonesia gaul. Senang memakai analogi menabung di kehidupan sehari-hari."
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey == "GEMINI_API_KEY" || apiKey == "null") {
            return@withContext "API Key Gemini belum diatur di panel Secrets AI Studio. Silakan masukkan GEMINI_API_KEY di pengaturan agar Tutor AI dapat menjawab pertanyaan coding Anda secara instan!"
        }

        val url = "$BASE_URL/$MODEL:generateContent?key=$apiKey"
        
        try {
            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", systemInstruction)
                        })
                    })
                })
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val code = response.code
                    val body = response.body?.string() ?: ""
                    Log.e("GeminiClient", "API Error: $code - $body")
                    return@withContext "Waduh, Tutor AI sedang istirahat sejenak (Error $code). Coba lagi nanti ya!"
                }

                val responseBodyStr = response.body?.string() ?: ""
                val responseJson = JSONObject(responseBodyStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val contentObj = candidates.getJSONObject(0).optJSONObject("content")
                    if (contentObj != null) {
                        val parts = contentObj.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", "Tidak ada teks penjelasan.")
                        }
                    }
                }
                "Koneksi berhasil tetapi tidak ada respon teks dari AI."
            }
        } catch (e: Exception) {
            Log.e("GeminiClient", "Error calling Gemini", e)
            "Gagal terhubung dengan Tutor AI. Periksa koneksi internet Anda. Detail: ${e.localizedMessage ?: "Unknown Error"}"
        }
    }
}
