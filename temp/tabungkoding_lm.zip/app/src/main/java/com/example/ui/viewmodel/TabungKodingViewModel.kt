package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiClient
import com.example.data.local.AppDatabase
import com.example.data.model.CourseData
import com.example.data.model.LanguageCourse
import com.example.data.model.Lesson
import com.example.data.model.SavingsGoal
import com.example.data.model.Transaction
import com.example.data.model.CodingProgress
import com.example.data.repository.FinanceRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatMessage(val content: String, val isUser: Boolean)

class TabungKodingViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FinanceRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = FinanceRepository(
            transactionDao = db.transactionDao(),
            savingsGoalDao = db.savingsGoalDao(),
            codingProgressDao = db.codingProgressDao()
        )
    }

    // --- State Streams ---
    val transactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savingsGoals: StateFlow<List<SavingsGoal>> = repository.allGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val codingProgress: StateFlow<List<CodingProgress>> = repository.allProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Derived Finance Metrics ---
    val totalIncome: StateFlow<Double> = transactions
        .map { list -> list.filter { !it.isExpense }.sumOf { it.amount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpense: StateFlow<Double> = transactions
        .map { list -> list.filter { it.isExpense }.sumOf { it.amount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val currentBalance: StateFlow<Double> = combine(totalIncome, totalExpense) { income, expense ->
        income - expense
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // --- Active Learn Navigation State ---
    private val _selectedCourse = MutableStateFlow<LanguageCourse?>(null)
    val selectedCourse = _selectedCourse.asStateFlow()

    private val _selectedLesson = MutableStateFlow<Lesson?>(null)
    val selectedLesson = _selectedLesson.asStateFlow()

    private val _userQuizAnswer = MutableStateFlow<Int?>(null)
    val userQuizAnswer = _userQuizAnswer.asStateFlow()

    private val _quizIsCorrect = MutableStateFlow<Boolean?>(null)
    val quizIsCorrect = _quizIsCorrect.asStateFlow()

    // --- AI Chat Tutor State ---
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(ChatMessage("Halo! Selamat datang di Tutor AI TabungKoding. Bertanyalah apa saja soal pemrograman, atau minta saya menjelaskan kode buatanmu! 🎯\n\nTips: Setiap kuis coding yang kamu selesaikan akan memberikan hadiah uang digital yang bisa disalurkan ke Target Tabunganmu!", false))
    )
    val chatMessages = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading = _isChatLoading.asStateFlow()

    // --- Operations: Finance ---
    fun addTransaction(title: String, amount: Double, isExpense: Boolean, category: String) {
        viewModelScope.launch {
            repository.insertTransaction(
                Transaction(
                    title = title,
                    amount = amount,
                    isExpense = isExpense,
                    category = category
                )
            )
        }
    }

    fun deleteTransaction(id: Int) {
        viewModelScope.launch {
            repository.deleteTransaction(id)
        }
    }

    // --- Operations: Savings Targets ---
    fun addSavingsGoal(title: String, targetAmount: Double, initialAmount: Double, note: String, monthlySpeed: Double) {
        viewModelScope.launch {
            repository.insertGoal(
                SavingsGoal(
                    title = title,
                    targetAmount = targetAmount,
                    currentAmount = initialAmount,
                    note = note,
                    monthlyContribution = monthlySpeed
                )
            )
            // Log as initial expense if wanted or just let them add manually
            if (initialAmount > 0.0) {
                repository.insertTransaction(
                    Transaction(
                        title = "Setor Awal: $title",
                        amount = initialAmount,
                        isExpense = true,
                        category = "Tabungan"
                    )
                )
            }
        }
    }

    fun deleteSavingsGoal(id: Int) {
        viewModelScope.launch {
            repository.deleteGoal(id)
        }
    }

    fun setSavingsGoalProgress(goal: SavingsGoal, newAmount: Double) {
        viewModelScope.launch {
            val oldAmount = goal.currentAmount
            val diff = newAmount - oldAmount
            repository.updateGoalAmount(goal.id, newAmount)
            
            // Record in general ledger as Transaction to reflect accurate liquidity
            if (diff != 0.0) {
                repository.insertTransaction(
                    Transaction(
                        title = "Penyesuaian Tabungan: ${goal.title}",
                        amount = if (diff > 0) diff else -diff,
                        isExpense = diff > 0, // dynamic allocation
                        category = "Tabungan"
                    )
                )
            }
        }
    }

    fun addSavingFromWallet(goal: SavingsGoal, amount: Double) {
        viewModelScope.launch {
            val walletBalance = currentBalance.value
            val actualAmount = if (amount > walletBalance) walletBalance else amount
            if (actualAmount <= 0.0) return@launch

            val targetNew = goal.currentAmount + actualAmount
            val finalNew = if (targetNew > goal.targetAmount) goal.targetAmount else targetNew

            repository.updateGoalAmount(goal.id, finalNew)
            repository.insertTransaction(
                Transaction(
                    title = "Setor Tabungan: ${goal.title}",
                    amount = actualAmount,
                    isExpense = true,
                    category = "Tabungan"
                )
            )
        }
    }

    // --- Operations: Learning & Quizzes ---
    fun selectCourse(course: LanguageCourse?) {
        _selectedCourse.value = course
        _selectedLesson.value = null
        _userQuizAnswer.value = null
        _quizIsCorrect.value = null
    }

    fun selectLesson(lesson: Lesson?) {
        _selectedLesson.value = lesson
        _userQuizAnswer.value = null
        _quizIsCorrect.value = null
    }

    fun chooseQuizAnswer(index: Int) {
        _userQuizAnswer.value = index
    }

    fun submitQuiz() {
        val lesson = selectedLesson.value ?: return
        val answerIndex = userQuizAnswer.value ?: return

        val isCorrect = (answerIndex == lesson.correctChoiceIndex)
        _quizIsCorrect.value = isCorrect

        if (isCorrect) {
            viewModelScope.launch {
                val course = selectedCourse.value ?: return@launch
                val currentProg = repository.getProgressForLanguage(course.id)
                
                // Only award points and money once per lesson if possible, but to keep prototype fun, let them earn bonuses!
                val updatedProg = currentProg.copy(
                    completedLessonsUnit = maxOf(currentProg.completedLessonsUnit, lesson.id),
                    totalQuizzesPassed = currentProg.totalQuizzesPassed + 1,
                    scoreExp = currentProg.scoreExp + lesson.rewardExp
                )
                repository.updateProgress(updatedProg)

                // Add money reward directly as Income!
                repository.insertTransaction(
                    Transaction(
                        title = "Hadiah Kuis: ${lesson.title}",
                        amount = lesson.rewardAmount,
                        isExpense = false,
                        category = "Bonus Belajar"
                    )
                )
            }
        }
    }

    // --- Operations: AI Ask Tutorial ---
    fun sendAskAI(userPrompt: String) {
        if (userPrompt.trim().isEmpty()) return
        
        val userMsg = ChatMessage(userPrompt, true)
        _chatMessages.update { it + userMsg }
        _isChatLoading.value = true

        viewModelScope.launch {
            val response = GeminiClient.generateCodingExplanation(userPrompt)
            val aiMsg = ChatMessage(response, false)
            _chatMessages.update { it + aiMsg }
            _isChatLoading.value = false
        }
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            ChatMessage("Halo! Selamat datang di Tutor AI TabungKoding. Silakan tanyakan hal-hal yang membingungkan seputar dunia coding! Saya akan membimbingmu dengan analogi sederhana dan penuh motivasi. 🚀", false)
        )
    }
}
