import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../services/terminal_provider.dart';
import '../theme/term_theme.dart';
import '../widgets/term_output.dart';
import '../widgets/term_input.dart';
import '../widgets/session_tabs.dart';

class TerminalScreen extends StatelessWidget {
  const TerminalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<TerminalProvider>();
    final sess = prov.active;

    return Scaffold(
      backgroundColor: TermTheme.bg950,
      body: Column(
        children: [
          // ── Top bar ──────────────────────────────────────────
          _TopBar(),

          // ── Session tabs ─────────────────────────────────────
          SessionTabs(
            sessions: prov.sessions,
            activeIndex: prov.sessions.indexOf(prov.active!),
            onSwitch: prov.switchSession,
            onClose: prov.closeSession,
            onNew: () => prov.newSession(),
          ),

          // ── Output area ──────────────────────────────────────
          Expanded(
            child: sess == null
                ? const Center(child: Text('No session', style: TextStyle(color: TermTheme.textMuted)))
                : TermOutputView(
                    lines: sess.lines,
                    isExecuting: prov.isExecuting,
                  ),
          ),

          // ── Input bar ────────────────────────────────────────
          TermInputBar(
            isExecuting: prov.isExecuting,
            onSubmit: (code) => prov.runCode(code),
            onHistoryPrev: () => prov.historyPrev(''),
            onHistoryNext: () => prov.historyNext(),
          ),
        ],
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52 + MediaQuery.of(context).padding.top,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top,
        left: 16,
        right: 12,
      ),
      decoration: BoxDecoration(
        color: TermTheme.bg900,
        border: Border(
          bottom: BorderSide(color: TermTheme.bg600, width: 1),
        ),
      ),
      child: Row(
        children: [
          // Logo / title
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: TermTheme.greenGlow,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: TermTheme.green.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: Center(
                  child: Text(
                    '>_',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 11,
                      color: TermTheme.green,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Da1chi Terminal',
                    style: GoogleFonts.spaceGrotesk(
                      fontSize: 14,
                      color: TermTheme.textPrime,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    'Python Interpreter',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 10,
                      color: TermTheme.green.withOpacity(0.7),
                    ),
                  ),
                ],
              ),
            ],
          ),

          const Spacer(),

          // Status indicator
          _StatusDot(),

          const SizedBox(width: 12),

          // Action buttons
          _IconBtn(
            icon: Icons.delete_sweep_outlined,
            tooltip: 'Bersihkan terminal',
            onTap: () => context.read<TerminalProvider>().clearSession(),
          ),
          _IconBtn(
            icon: Icons.help_outline_rounded,
            tooltip: 'Bantuan',
            onTap: () => context.read<TerminalProvider>().runCode('help'),
          ),
        ],
      ),
    );
  }
}

class _StatusDot extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final prov = context.watch<TerminalProvider>();
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 7,
          height: 7,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: prov.isExecuting ? TermTheme.amber : TermTheme.green,
            boxShadow: [
              BoxShadow(
                color: (prov.isExecuting ? TermTheme.amber : TermTheme.green)
                    .withOpacity(0.5),
                blurRadius: 6,
                spreadRadius: 1,
              ),
            ],
          ),
        ),
        const SizedBox(width: 5),
        Text(
          prov.isExecuting ? 'running' : 'ready',
          style: GoogleFonts.jetBrainsMono(
            fontSize: 11,
            color: prov.isExecuting ? TermTheme.amber : TermTheme.green,
          ),
        ),
      ],
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  const _IconBtn({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 34,
          height: 34,
          alignment: Alignment.center,
          child: Icon(icon, size: 18, color: TermTheme.textMuted),
        ),
      ),
    );
  }
}
