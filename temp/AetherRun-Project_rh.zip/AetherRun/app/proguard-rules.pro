# AetherRun ProGuard rules - keep game classes
-keep class com.premium.aetherrun.game.** { *; }
-keepclassmembers class * {
    public <init>(...);
}
