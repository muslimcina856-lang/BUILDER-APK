package com.premium.aetherrun.ui

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.premium.aetherrun.databinding.ActivityCharacterSelectBinding
import com.premium.aetherrun.model.CharacterType
import com.premium.aetherrun.utils.PrefsManager

class CharacterSelectActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCharacterSelectBinding
    private lateinit var prefs: PrefsManager
    private var selected = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding = ActivityCharacterSelectBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager(this)
        selected = prefs.selectedCharacterIndex

        val characters = CharacterType.entries.toList()

        binding.recyclerCharacters.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        binding.recyclerCharacters.adapter = CharacterAdapter(characters, selected) { index ->
            selected = index
            prefs.selectedCharacterIndex = index
            Toast.makeText(this, "${characters[index].displayName} dipilih", Toast.LENGTH_SHORT).show()
            finish()
        }

        binding.btnBack.setOnClickListener { finish() }
    }
}
