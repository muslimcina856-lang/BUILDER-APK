package com.premium.aetherrun.model

/**
 * Premium character roster for AetherRun.
 * Designed as selectable high-end runners with unique visual identities.
 */
enum class CharacterType(
    val displayName: String,
    val primaryColor: Long,
    val secondaryColor: Long,
    val trailColor: Long,
    val description: String
) {
    AETHER_PHANTOM(
        "Aether Phantom",
        0xFFB026FF,
        0xFF7B2FFF,
        0xFFD580FF,
        "Bayang-bayang elegan dengan jubah tenaga ungu mengalir"
    ),
    NOVA_STRIKER(
        "Nova Striker",
        0xFF00F5FF,
        0xFF00A8FF,
        0xFF80F9FF,
        "Atlet cyberpunk dengan armor ringan & energy trail biru"
    ),
    EMBER_RONIN(
        "Ember Ronin",
        0xFFFF4D00,
        0xFFFF8C00,
        0xFFFFAA55,
        "Samurai masa depan dengan aura api merah-jingga"
    ),
    VOID_RUNNER(
        "Void Runner",
        0xFF2E1A47,
        0xFF6B3FA0,
        0xFF9B6DFF,
        "Makhluk gelap semi-transparan dengan glitch effect"
    ),
    SOLARIX(
        "Solarix",
        0xFFFFD700,
        0xFFFFAA00,
        0xFFFFF0A0,
        "Entity bercahaya emas dengan aura pure energy"
    ),
    KAIROS(
        "Kairos",
        0xFFE0E0E0,
        0xFF90CAF9,
        0xFFBBDEFB,
        "Parkour specialist realistis dengan gerakan natural"
    );

    companion object {
        fun fromOrdinalSafe(index: Int): CharacterType {
            return entries.getOrElse(index) { AETHER_PHANTOM }
        }
    }
}
