package com.premium.aetherrun.game

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader

/**
 * Premium obstacle with layered neon look.
 * Uses object pooling pattern externally.
 */
class Obstacle {

    var x: Float = 0f
    var y: Float = 0f
    var width: Float = 70f
    var height: Float = 90f
    var active: Boolean = false
    var type: Int = 0 // 0 = low, 1 = tall, 2 = floating

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun reset(startX: Float, groundY: Float, obstacleType: Int) {
        x = startX
        type = obstacleType
        active = true

        when (type) {
            0 -> { // low barrier
                width = 65f
                height = 55f
                y = groundY
            }
            1 -> { // tall spike-like
                width = 50f
                height = 110f
                y = groundY
            }
            else -> { // floating
                width = 80f
                height = 45f
                y = groundY - 130f
            }
        }
    }

    fun update(speed: Float, deltaTime: Float) {
        if (!active) return
        x -= speed * deltaTime
        if (x + width < -50f) {
            active = false
        }
    }

    fun draw(canvas: Canvas) {
        if (!active) return

        val left = x
        val top = y - height
        val right = x + width
        val bottom = y

        // Glow
        glowPaint.shader = LinearGradient(
            left, top, right, bottom,
            intArrayOf(0x55FF2E97.toInt(), 0x00FF2E97),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(left - 8f, top - 8f, right + 8f, bottom + 4f, 12f, 12f, glowPaint)

        // Main body - sharp geometric premium shape
        path.reset()
        when (type) {
            1 -> { // tall pointed
                path.moveTo(left + width / 2f, top)
                path.lineTo(right, bottom)
                path.lineTo(left, bottom)
                path.close()
            }
            else -> {
                path.addRoundRect(left, top, right, bottom, 10f, 10f, Path.Direction.CW)
            }
        }

        paint.shader = LinearGradient(
            left, top, left, bottom,
            intArrayOf(0xFFFF2E97.toInt(), 0xFFB026FF.toInt()),
            null,
            Shader.TileMode.CLAMP
        )
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)

        // Edge highlight
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = 0xFFFF80AB.toInt()
        canvas.drawPath(path, paint)
    }

    fun getLeft() = x
    fun getRight() = x + width
    fun getTop() = y - height
    fun getBottom() = y
}
