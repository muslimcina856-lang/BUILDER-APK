package com.premium.aetherrun.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.premium.aetherrun.model.CharacterType
import com.premium.aetherrun.utils.PrefsManager

/**
 * High-performance SurfaceView game loop.
 * Fixed timestep + interpolation ready architecture.
 * Target 60 FPS.
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    @Volatile private var running = false

    private val gameManager = GameManager(1, 1)
    private val prefs = PrefsManager(context)

    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 52f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCCFFFFFF.toInt()
        textSize = 38f
        textAlign = Paint.Align.CENTER
    }
    private val overlayPaint = Paint().apply {
        color = 0xAA000000.toInt()
    }

    init {
        holder.addCallback(this)
        isFocusable = true
        gameManager.highScore = prefs.highScore
        val charIndex = prefs.selectedCharacterIndex
        gameManager.setCharacter(CharacterType.fromOrdinalSafe(charIndex))
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this).also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        gameManager.resize(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        try {
            thread?.join(800)
        } catch (_: InterruptedException) {}
    }

    override fun run() {
        var lastTime = System.nanoTime()
        val targetFps = 60.0
        val optimalTime = 1_000_000_000.0 / targetFps

        while (running) {
            val now = System.nanoTime()
            val deltaTime = ((now - lastTime) / 1_000_000_000.0).toFloat().coerceIn(0.001f, 0.05f)
            lastTime = now

            update(deltaTime)
            render()

            val sleepTime = ((lastTime - System.nanoTime() + optimalTime) / 1_000_000).toLong()
            if (sleepTime > 0) {
                try {
                    Thread.sleep(sleepTime)
                } catch (_: InterruptedException) {}
            }
        }
    }

    private fun update(dt: Float) {
        gameManager.update(dt)
        if (gameManager.state == GameManager.State.GAME_OVER) {
            prefs.highScore = gameManager.score
            gameManager.highScore = prefs.highScore
        }
    }

    private fun render() {
        var canvas: Canvas? = null
        try {
            canvas = holder.lockCanvas()
            if (canvas != null) {
                synchronized(holder) {
                    gameManager.draw(canvas)

                    // HUD
                    hudPaint.textAlign = Paint.Align.LEFT
                    canvas.drawText("SKOR  ${gameManager.score}", 40f, 80f, hudPaint)

                    hudPaint.textAlign = Paint.Align.RIGHT
                    canvas.drawText("TERBAIK  ${gameManager.highScore}", width - 40f, 80f, hudPaint)

                    when (gameManager.state) {
                        GameManager.State.READY -> {
                            canvas.drawText(
                                "KETIK UNTUK MULA",
                                width / 2f,
                                height * 0.45f,
                                hintPaint
                            )
                        }
                        GameManager.State.GAME_OVER -> {
                            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), overlayPaint)
                            hintPaint.textSize = 64f
                            canvas.drawText("TAMAT", width / 2f, height * 0.42f, hintPaint)
                            hintPaint.textSize = 42f
                            canvas.drawText(
                                "Skor: ${gameManager.score}",
                                width / 2f,
                                height * 0.50f,
                                hintPaint
                            )
                            canvas.drawText(
                                "Ketik untuk cuba lagi",
                                width / 2f,
                                height * 0.58f,
                                hintPaint
                            )
                        }
                        else -> {}
                    }
                }
            }
        } finally {
            canvas?.let {
                try {
                    holder.unlockCanvasAndPost(it)
                } catch (_: Exception) {}
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            gameManager.onTap()
            return true
        }
        return super.onTouchEvent(event)
    }

    fun setCharacter(type: CharacterType) {
        gameManager.setCharacter(type)
        prefs.selectedCharacterIndex = type.ordinal
    }
}
