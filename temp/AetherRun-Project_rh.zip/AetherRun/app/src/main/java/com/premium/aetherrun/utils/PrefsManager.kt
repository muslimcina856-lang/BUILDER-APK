package com.premium.aetherrun.utils

import android.content.Context
import android.content.SharedPreferences

/**
 * Lightweight high-score & character preference manager.
 * Thread-safe for simple game needs.
 */
class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("aetherrun_prefs", Context.MODE_PRIVATE)

    var highScore: Int
        get() = prefs.getInt(KEY_HIGH_SCORE, 0)
        set(value) {
            if (value > highScore) {
                prefs.edit().putInt(KEY_HIGH_SCORE, value).apply()
            }
        }

    var selectedCharacterIndex: Int
        get() = prefs.getInt(KEY_CHARACTER, 0)
        set(value) = prefs.edit().putInt(KEY_CHARACTER, value).apply()

    companion object {
        private const val KEY_HIGH_SCORE = "high_score"
        private const val KEY_CHARACTER = "selected_character"
    }
}
