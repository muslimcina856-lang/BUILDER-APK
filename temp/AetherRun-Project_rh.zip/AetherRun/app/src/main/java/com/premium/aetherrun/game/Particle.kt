package com.premium.aetherrun.game

import android.graphics.Canvas
import android.graphics.Paint

/**
 * Lightweight particle for trail dust, jump burst, impact.
 * Designed for object pooling.
 */
class Particle {
    var x: Float = 0f
    var y: Float = 0f
    var vx: Float = 0f
    var vy: Float = 0f
    var life: Float = 0f
    var maxLife: Float = 1f
    var size: Float = 6f
    var color: Int = 0xFF00F5FF.toInt()
    var active: Boolean = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun reset(px: Float, py: Float, pvx: Float, pvy: Float, pLife: Float, pSize: Float, pColor: Int) {
        x = px
        y = py
        vx = pvx
        vy = pvy
        life = pLife
        maxLife = pLife
        size = pSize
        color = pColor
        active = true
    }

    fun update(deltaTime: Float) {
        if (!active) return
        x += vx * deltaTime
        y += vy * deltaTime
        vy += 400f * deltaTime // slight gravity
        life -= deltaTime
        if (life <= 0f) active = false
    }

    fun draw(canvas: Canvas) {
        if (!active) return
        val alpha = (255 * (life / maxLife)).toInt().coerceIn(0, 255)
        paint.color = (color and 0x00FFFFFF) or (alpha shl 24)
        canvas.drawCircle(x, y, size * (life / maxLife), paint)
    }
}
