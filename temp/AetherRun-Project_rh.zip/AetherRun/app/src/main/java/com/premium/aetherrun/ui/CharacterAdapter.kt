package com.premium.aetherrun.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.premium.aetherrun.databinding.ItemCharacterBinding
import com.premium.aetherrun.model.CharacterType

class CharacterAdapter(
    private val items: List<CharacterType>,
    private var selectedIndex: Int,
    private val onSelect: (Int) -> Unit
) : RecyclerView.Adapter<CharacterAdapter.VH>() {

    inner class VH(val binding: ItemCharacterBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemCharacterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.tvName.text = item.displayName
        holder.binding.tvDesc.text = item.description

        // Color indicator
        holder.binding.viewColor.setBackgroundColor(item.primaryColor.toInt())

        if (position == selectedIndex) {
            holder.binding.root.setBackgroundColor(0x3300F5FF)
            holder.binding.tvName.setTextColor(Color.parseColor("#00F5FF"))
        } else {
            holder.binding.root.setBackgroundColor(0x22000000)
            holder.binding.tvName.setTextColor(Color.WHITE)
        }

        holder.binding.root.setOnClickListener {
            val old = selectedIndex
            selectedIndex = position
            notifyItemChanged(old)
            notifyItemChanged(position)
            onSelect(position)
        }
    }

    override fun getItemCount() = items.size
}
