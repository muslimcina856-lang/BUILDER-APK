package com.premium.aetherrun.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.premium.aetherrun.databinding.ActivityMainBinding
import com.premium.aetherrun.utils.PrefsManager

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager(this)

        binding.tvHighScore.text = "Rekod Tertinggi: ${prefs.highScore}"

        binding.btnPlay.setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java))
        }

        binding.btnCharacters.setOnClickListener {
            startActivity(Intent(this, CharacterSelectActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        binding.tvHighScore.text = "Rekod Tertinggi: ${prefs.highScore}"
    }
}
