package com.premium.aetherrun.ui

import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.premium.aetherrun.databinding.ActivityGameBinding
import com.premium.aetherrun.model.CharacterType
import com.premium.aetherrun.utils.PrefsManager

class GameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = PrefsManager(this)
        val char = CharacterType.fromOrdinalSafe(prefs.selectedCharacterIndex)
        binding.gameView.setCharacter(char)
    }

    override fun onPause() {
        super.onPause()
        // GameView handles its own thread lifecycle via SurfaceHolder
    }
}
