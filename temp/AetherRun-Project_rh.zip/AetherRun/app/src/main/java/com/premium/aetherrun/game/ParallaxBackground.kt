package com.premium.aetherrun.game

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader

/**
 * Multi-layer parallax background for premium depth.
 * Layer 0 = far stars / nebula
 * Layer 1 = mid city silhouettes
 * Layer 2 = near ground fog / light streaks
 */
class ParallaxBackground(
    private var screenWidth: Int,
    private var screenHeight: Int
) {
    private val layerSpeeds = floatArrayOf(0.15f, 0.4f, 0.75f)
    private val offsets = floatArrayOf(0f, 0f, 0f)

    private val bgPaint = Paint()
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cityPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val groundPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val stars = Array(40) {
        floatArrayOf(
            (Math.random() * 2000).toFloat(),
            (Math.random() * screenHeight * 0.6).toFloat(),
            (1f + Math.random() * 2.5).toFloat()
        )
    }

    fun resize(w: Int, h: Int) {
        screenWidth = w
        screenHeight = h
    }

    fun update(speed: Float, deltaTime: Float) {
        for (i in offsets.indices) {
            offsets[i] -= speed * layerSpeeds[i] * deltaTime
            if (offsets[i] < -screenWidth) offsets[i] += screenWidth.toFloat()
        }
    }

    fun draw(canvas: Canvas) {
        // Deep space base
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, screenHeight.toFloat(),
            intArrayOf(0xFF050510.toInt(), 0xFF0F0A1F.toInt(), 0xFF1A0A2E.toInt()),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, screenWidth.toFloat(), screenHeight.toFloat(), bgPaint)

        // Stars (layer 0)
        starPaint.color = 0xAAFFFFFF.toInt()
        for (s in stars) {
            val sx = (s[0] + offsets[0]) % (screenWidth + 100) - 50
            canvas.drawCircle(sx, s[1], s[2], starPaint)
        }

        // Mid city silhouettes (layer 1)
        cityPaint.color = 0xFF1A1030.toInt()
        val baseY = screenHeight * 0.62f
        for (i in 0..8) {
            val bx = (i * 180f + offsets[1]) % (screenWidth + 200) - 100
            val bh = 80f + (i % 4) * 40f
            canvas.drawRect(bx, baseY - bh, bx + 60f + (i % 3) * 20f, baseY + 20f, cityPaint)
        }

        // Near ground glow
        groundPaint.shader = LinearGradient(
            0f, screenHeight * 0.7f, 0f, screenHeight.toFloat(),
            intArrayOf(0x00000000, 0x3300F5FF.toInt(), 0x2200A8FF.toInt()),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, screenHeight * 0.7f, screenWidth.toFloat(), screenHeight.toFloat(), groundPaint)

        // Ground line
        groundPaint.shader = null
        groundPaint.color = 0xFF00F5FF.toInt()
        groundPaint.strokeWidth = 3f
        canvas.drawLine(0f, screenHeight * 0.78f, screenWidth.toFloat(), screenHeight * 0.78f, groundPaint)
    }
}
