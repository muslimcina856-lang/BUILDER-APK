package com.premium.aetherrun.game

import android.graphics.Canvas
import com.premium.aetherrun.model.CharacterType
import kotlin.random.Random

/**
 * Central game logic controller.
 * Handles spawning, scoring, collision, state, difficulty ramp.
 * Written for perfect deterministic feel + smooth ramp.
 */
class GameManager(
    private var screenWidth: Int,
    private var screenHeight: Int
) {
    enum class State { READY, PLAYING, GAME_OVER }

    var state: State = State.READY
    var score: Int = 0
    var highScore: Int = 0

    val player = Player(screenWidth, screenHeight)
    private val background = ParallaxBackground(screenWidth, screenHeight)

    // Object pools
    private val obstacles = Array(12) { Obstacle() }
    private val particles = Array(60) { Particle() }

    private var baseSpeed = 480f
    private var currentSpeed = baseSpeed
    private var spawnTimer = 0f
    private var nextSpawnInterval = 1.4f
    private var distanceAccum = 0f

    private val groundY: Float
        get() = screenHeight * 0.78f

    fun resize(w: Int, h: Int) {
        screenWidth = w
        screenHeight = h
        player.resize(w, h)
        background.resize(w, h)
    }

    fun setCharacter(type: CharacterType) {
        player.character = type
    }

    fun startGame() {
        state = State.PLAYING
        score = 0
        currentSpeed = baseSpeed
        spawnTimer = 0f
        nextSpawnInterval = 1.3f
        distanceAccum = 0f
        player.isAlive = true
        player.y = groundY
        player.velocityY = 0f
        player.isOnGround = true

        obstacles.forEach { it.active = false }
        particles.forEach { it.active = false }
    }

    fun onTap() {
        when (state) {
            State.READY -> startGame()
            State.PLAYING -> player.jump()
            State.GAME_OVER -> startGame()
        }
    }

    fun update(deltaTime: Float) {
        if (state != State.PLAYING) {
            background.update(currentSpeed * 0.3f, deltaTime)
            return
        }

        // Difficulty ramp
        currentSpeed = baseSpeed + (score * 1.8f).coerceAtMost(420f)

        background.update(currentSpeed, deltaTime)
        player.update(deltaTime)

        // Spawn obstacles
        spawnTimer += deltaTime
        if (spawnTimer >= nextSpawnInterval) {
            spawnObstacle()
            spawnTimer = 0f
            nextSpawnInterval = Random.nextFloat() * 0.7f + 0.9f - (score * 0.0015f).coerceAtMost(0.4f)
        }

        // Update obstacles + collision
        for (obs in obstacles) {
            if (!obs.active) continue
            obs.update(currentSpeed, deltaTime)

            if (checkCollision(player, obs)) {
                player.isAlive = false
                state = State.GAME_OVER
                spawnImpactParticles(player.x, player.y - 40f)
                if (score > highScore) highScore = score
                break
            }
        }

        // Particles
        for (p in particles) {
            if (p.active) p.update(deltaTime)
        }

        // Score by distance
        distanceAccum += currentSpeed * deltaTime
        if (distanceAccum >= 25f) {
            score += 1
            distanceAccum = 0f
            if (player.isOnGround && Random.nextFloat() < 0.3f) {
                spawnDust(player.x - 20f, player.y)
            }
        }
    }

    private fun spawnObstacle() {
        val obs = obstacles.firstOrNull { !it.active } ?: return
        val type = when {
            score < 30 -> 0
            score < 80 -> Random.nextInt(0, 2)
            else -> Random.nextInt(0, 3)
        }
        obs.reset(screenWidth + 80f, groundY, type)
    }

    private fun checkCollision(p: Player, o: Obstacle): Boolean {
        return p.getHitboxLeft() < o.getRight() &&
                p.getHitboxRight() > o.getLeft() &&
                p.getHitboxTop() < o.getBottom() &&
                p.getHitboxBottom() > o.getTop()
    }

    private fun spawnDust(px: Float, py: Float) {
        repeat(4) {
            val p = particles.firstOrNull { !it.active } ?: return
            p.reset(
                px + Random.nextFloat() * 20f,
                py,
                -Random.nextFloat() * 80f - 40f,
                -Random.nextFloat() * 120f,
                0.4f + Random.nextFloat() * 0.3f,
                3f + Random.nextFloat() * 4f,
                player.character.trailColor.toInt()
            )
        }
    }

    private fun spawnImpactParticles(px: Float, py: Float) {
        repeat(18) {
            val p = particles.firstOrNull { !it.active } ?: return
            p.reset(
                px,
                py,
                (Random.nextFloat() - 0.5f) * 600f,
                (Random.nextFloat() - 0.8f) * 500f,
                0.6f + Random.nextFloat() * 0.5f,
                4f + Random.nextFloat() * 6f,
                0xFFFF2E97.toInt()
            )
        }
    }

    fun draw(canvas: Canvas) {
        background.draw(canvas)

        for (obs in obstacles) {
            if (obs.active) obs.draw(canvas)
        }

        player.draw(canvas)

        for (p in particles) {
            if (p.active) p.draw(canvas)
        }
    }
}
