package com.premium.aetherrun.game

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import com.premium.aetherrun.model.CharacterType
import kotlin.math.sin

/**
 * Premium Player entity with advanced procedural rendering.
 * No simple boxes — multi-layer body, trail, glow, and animation.
 */
class Player(
    private var screenWidth: Int,
    private var screenHeight: Int
) {
    var x: Float = 0f
    var y: Float = 0f
    var velocityY: Float = 0f
    var isOnGround: Boolean = true
    var isAlive: Boolean = true

    private val gravity = 2800f
    private val jumpForce = -1150f
    private val groundY: Float
        get() = screenHeight * 0.78f

    var character: CharacterType = CharacterType.AETHER_PHANTOM

    // Animation
    private var runCycle = 0f
    private var trailPhase = 0f

    // Paints (reused for performance)
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val bodyPath = Path()
    private val trailPath = Path()

    fun resize(width: Int, height: Int) {
        screenWidth = width
        screenHeight = height
        x = width * 0.22f
        y = groundY
    }

    fun jump() {
        if (isOnGround && isAlive) {
            velocityY = jumpForce
            isOnGround = false
        }
    }

    fun update(deltaTime: Float) {
        if (!isAlive) return

        // Physics
        velocityY += gravity * deltaTime
        y += velocityY * deltaTime

        if (y >= groundY) {
            y = groundY
            velocityY = 0f
            isOnGround = true
        }

        // Animation timers
        runCycle += deltaTime * 12f
        trailPhase += deltaTime * 8f
    }

    fun draw(canvas: Canvas) {
        if (!isAlive) return

        val centerX = x
        val centerY = y - 55f   // body center above feet

        // === Energy Trail (behind body) ===
        drawTrail(canvas, centerX, centerY)

        // === Outer Glow ===
        glowPaint.shader = RadialGradient(
            centerX, centerY, 90f,
            intArrayOf(
                (character.primaryColor or 0x55000000).toInt(),
                0x00000000
            ),
            floatArrayOf(0.2f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(centerX, centerY, 90f, glowPaint)

        // === Body (procedural multi-layer) ===
        drawBody(canvas, centerX, centerY)

        // === Core highlight ===
        corePaint.shader = RadialGradient(
            centerX - 8f, centerY - 15f, 25f,
            intArrayOf(0xAAFFFFFF.toInt(), 0x00FFFFFF),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(centerX - 8f, centerY - 15f, 22f, corePaint)
    }

    private fun drawTrail(canvas: Canvas, cx: Float, cy: Float) {
        trailPath.reset()
        val wave = sin(trailPhase.toDouble()).toFloat() * 12f

        trailPath.moveTo(cx - 30f, cy)
        trailPath.cubicTo(
            cx - 80f, cy - 40f + wave,
            cx - 140f, cy + 30f - wave,
            cx - 200f, cy + 10f
        )
        trailPath.lineTo(cx - 200f, cy + 25f)
        trailPath.cubicTo(
            cx - 140f, cy + 50f - wave,
            cx - 80f, cy + 10f + wave,
            cx - 30f, cy + 15f
        )
        trailPath.close()

        trailPaint.shader = LinearGradient(
            cx, cy, cx - 200f, cy,
            intArrayOf(
                (character.trailColor or 0xAA000000).toInt(),
                (character.trailColor and 0x00FFFFFF).toInt()
            ),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(trailPath, trailPaint)
    }

    private fun drawBody(canvas: Canvas, cx: Float, cy: Float) {
        bodyPath.reset()

        // Stylized athletic silhouette (not a box)
        // Head
        bodyPath.addCircle(cx, cy - 48f, 18f, Path.Direction.CW)

        // Torso
        bodyPath.moveTo(cx - 16f, cy - 32f)
        bodyPath.lineTo(cx + 18f, cy - 28f)
        bodyPath.lineTo(cx + 14f, cy + 18f)
        bodyPath.lineTo(cx - 12f, cy + 22f)
        bodyPath.close()

        // Front leg (running pose)
        val legSwing = sin(runCycle.toDouble()).toFloat() * 18f
        bodyPath.moveTo(cx - 6f, cy + 20f)
        bodyPath.lineTo(cx - 22f + legSwing, cy + 55f)
        bodyPath.lineTo(cx - 8f + legSwing, cy + 55f)
        bodyPath.lineTo(cx + 4f, cy + 20f)
        bodyPath.close()

        // Back leg
        bodyPath.moveTo(cx + 4f, cy + 18f)
        bodyPath.lineTo(cx + 28f - legSwing, cy + 52f)
        bodyPath.lineTo(cx + 14f - legSwing, cy + 52f)
        bodyPath.lineTo(cx - 2f, cy + 18f)
        bodyPath.close()

        // Front arm
        bodyPath.moveTo(cx + 12f, cy - 20f)
        bodyPath.lineTo(cx + 38f, cy - 5f + legSwing * 0.6f)
        bodyPath.lineTo(cx + 32f, cy + 5f + legSwing * 0.6f)
        bodyPath.lineTo(cx + 8f, cy - 8f)
        bodyPath.close()

        bodyPaint.shader = LinearGradient(
            cx - 20f, cy - 50f, cx + 20f, cy + 40f,
            intArrayOf(
                character.primaryColor.toInt(),
                character.secondaryColor.toInt()
            ),
            null,
            Shader.TileMode.CLAMP
        )
        bodyPaint.style = Paint.Style.FILL
        canvas.drawPath(bodyPath, bodyPaint)

        // Outline for definition
        bodyPaint.shader = null
        bodyPaint.style = Paint.Style.STROKE
        bodyPaint.strokeWidth = 2.5f
        bodyPaint.color = (character.trailColor or 0xFF000000).toInt()
        canvas.drawPath(bodyPath, bodyPaint)
    }

    fun getHitboxLeft(): Float = x - 28f
    fun getHitboxRight(): Float = x + 28f
    fun getHitboxTop(): Float = y - 95f
    fun getHitboxBottom(): Float = y
}
