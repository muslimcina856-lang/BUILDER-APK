# AetherRun

**Premium Endless Runner** — dibina dengan standard production.

## Spesifikasi Teknikal

- **compileSdk / targetSdk**: 36
- **minSdk**: 26
- **Language**: Kotlin
- **Architecture**: Modular (game core berasingan dari UI)
- **Rendering**: Custom SurfaceView + Canvas 60 FPS
- **Physics**: Gravity + jump force yang ditala
- **Optimization**: Object pooling untuk Obstacle & Particle
- **Characters**: 6 premium selectable runners (procedural high-end drawing)
- **Features**:
  - Parallax multi-layer background
  - Dynamic difficulty ramp
  - Particle system (dust + impact)
  - Persistent high score
  - Character select screen
  - Clean Material 3 UI

## Cara Jalankan

1. Buka folder `AetherRun` dalam **Android Studio** (Ladybug atau lebih baru disyorkan)
2. Sync Gradle
3. Pilih device / emulator (API 26+)
4. Run

## Struktur Folder

```
app/src/main/java/com/premium/aetherrun/
├── game/          → Core engine (Player, Obstacle, Particle, GameManager, GameView...)
├── model/         → CharacterType enum
├── ui/            → Activities + Adapter
└── utils/         → PrefsManager
```

## Character Roster

1. **Aether Phantom** — Ungu bayang
2. **Nova Striker** — Cyan cyber athlete
3. **Ember Ronin** — Api samurai
4. **Void Runner** — Gelap glitch
5. **Solarix** — Emas bercahaya
6. **Kairos** — Realistik parkour

---

Dibina untuk pengalaman premium.
