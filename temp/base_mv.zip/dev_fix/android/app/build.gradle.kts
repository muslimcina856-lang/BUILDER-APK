plugins {
    id("com.android.application")
}
android {
    namespace = "com.nullx.pp"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.nullx.pp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}