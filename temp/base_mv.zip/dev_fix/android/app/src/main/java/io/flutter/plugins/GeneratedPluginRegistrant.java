package io.flutter.plugins;

import androidx.annotation.Keep;
import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.PluginRegistry;
import io.flutter.plugins.permission.PermissionPlugin;
import io.flutter.plugins.deviceinfo.DeviceInfoPlusPlugin;
import io.flutter.plugins.connectivity.ConnectivityPlusPlugin;
import io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin;
import io.flutter.plugins.pathprovider.PathProviderPlugin;
import io.flutter.plugins.urllauncher.UrlLauncherPlugin;
import io.flutter.plugins.wakelock.WakelockPlusPlugin;
import io.flutter.plugins.localnotifications.LocalNotificationsPlugin;
import io.flutter.plugins.socket_io.SocketIoPlugin;

@Keep
public final class GeneratedPluginRegistrant {
  public static void registerWith(PluginRegistry registry) {
    if (alreadyRegisteredWith(registry)) {
      return;
    }
    // ===== DAFTAR PLUGIN YANG DIPAKAI =====
    PermissionPlugin.registerWith(registry.registrarFor("io.flutter.plugins.permission.PermissionPlugin"));
    DeviceInfoPlusPlugin.registerWith(registry.registrarFor("io.flutter.plugins.deviceinfo.DeviceInfoPlusPlugin"));
    ConnectivityPlusPlugin.registerWith(registry.registrarFor("io.flutter.plugins.connectivity.ConnectivityPlusPlugin"));
    SharedPreferencesPlugin.registerWith(registry.registrarFor("io.flutter.plugins.sharedpreferences.SharedPreferencesPlugin"));
    PathProviderPlugin.registerWith(registry.registrarFor("io.flutter.plugins.pathprovider.PathProviderPlugin"));
    UrlLauncherPlugin.registerWith(registry.registrarFor("io.flutter.plugins.urllauncher.UrlLauncherPlugin"));
    WakelockPlusPlugin.registerWith(registry.registrarFor("io.flutter.plugins.wakelock.WakelockPlusPlugin"));
    LocalNotificationsPlugin.registerWith(registry.registrarFor("io.flutter.plugins.localnotifications.LocalNotificationsPlugin"));
    SocketIoPlugin.registerWith(registry.registrarFor("io.flutter.plugins.socket_io.SocketIoPlugin"));
    // ===== TAMBAHKAN PLUGIN LAIN DI SINI =====
  }

  private static boolean alreadyRegisteredWith(PluginRegistry registry) {
    final String key = GeneratedPluginRegistrant.class.getCanonicalName();
    if (registry.hasPlugin(key)) {
      return true;
    }
    registry.registrarFor(key);
    return false;
  }
}