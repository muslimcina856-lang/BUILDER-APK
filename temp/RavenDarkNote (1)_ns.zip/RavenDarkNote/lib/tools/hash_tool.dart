import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class HashToolPage extends StatefulWidget {
  const HashToolPage({super.key});

  @override
  State<HashToolPage> createState() => _HashToolPageState();
}

class _HashToolPageState extends State<HashToolPage> {
  final _ctrl = TextEditingController();
  String _md5 = '';
  String _sha1 = '';
  String _sha256 = '';

  void _generate() {
    final bytes = utf8.encode(_ctrl.text);
    setState(() {
      _md5 = md5.convert(bytes).toString();
      _sha1 = sha1.convert(bytes).toString();
      _sha256 = sha256.convert(bytes).toString();
    });
  }

  Widget _hashCard(String label, String value) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(height: 6),
          SelectableText(
            value.isEmpty ? '—' : value,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
          ),
          if (value.isNotEmpty)
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                icon: const Icon(Icons.copy, size: 18),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: value));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('$label disalin')),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hash Generator')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: _ctrl,
            maxLines: 3,
            decoration: InputDecoration(
              labelText: 'Input Teks',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
            onChanged: (_) => _generate(),
          ),
          const SizedBox(height: 20),
          _hashCard('MD5', _md5),
          _hashCard('SHA-1', _sha1),
          _hashCard('SHA-256', _sha256),
        ],
      ),
    );
  }
}
