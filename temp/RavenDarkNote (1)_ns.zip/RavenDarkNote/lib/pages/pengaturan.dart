import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../widgets/theme_button.dart';

class PengaturanPage extends StatefulWidget {
  final void Function(String theme, String color)? onThemeChanged;

  const PengaturanPage({super.key, this.onThemeChanged});

  @override
  State<PengaturanPage> createState() => _PengaturanPageState();
}

class _PengaturanPageState extends State<PengaturanPage> {
  String _theme = 'dark';
  String _color = 'purple';
  String _version = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final info = await PackageInfo.fromPlatform();
    setState(() {
      _theme = prefs.getString('theme') ?? 'dark';
      _color = prefs.getString('seed_color') ?? 'purple';
      _version = '${info.version}+${info.buildNumber}';
    });
  }

  Future<void> _setTheme(String theme) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme', theme);
    setState(() => _theme = theme);
    widget.onThemeChanged?.call(theme, _color);
  }

  Future<void> _setColor(String color) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('seed_color', color);
    setState(() => _color = color);
    widget.onThemeChanged?.call(_theme, color);
  }

  void _showDonate() {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: Image.asset(
                'assets/donate.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 200,
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                  child: Center(
                    child: Icon(
                      Icons.favorite,
                      size: 64,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Text(
                    'Dukung Pengembangan',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Terima kasih atas dukungan Anda!\nScan QR atau transfer untuk donasi.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Tutup'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showCaraPakai() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cara Pakai'),
        content: const SingleChildScrollView(
          child: Text(
            '1. Tabungan\n'
            'Tambah target tabungan, isi nama, target uang, dan saldo. Progress otomatis terhitung.\n\n'
            '2. Catatan\n'
            'Buat catatan dengan judul dan isi. Gunakan pencarian untuk menemukan catatan.\n\n'
            '3. Tools\n'
            'Kumpulan utilitas: kalkulator, password generator, QR, hash, dan lainnya.\n\n'
            '4. Pengaturan\n'
            'Ubah tema (System/Dark/Light) dan warna (Purple/Blue/Red).\n\n'
            'Semua data disimpan offline di perangkat Anda.',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Mengerti')),
        ],
      ),
    );
  }

  void _showTentang() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tentang'),
        content: const Text(
          'Raven DarkNote\n\n'
          'Aplikasi catatan dan tabungan offline dengan desain dark premium.\n\n'
          'Dikembangkan dengan Flutter.\n'
          'Tidak menggunakan Firebase.\n'
          'Semua data tersimpan lokal.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tutup')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pengaturan'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Tema',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ThemeButton(
                label: 'System',
                isSelected: _theme == 'system',
                onTap: () => _setTheme('system'),
              ),
              ThemeButton(
                label: 'Dark',
                isSelected: _theme == 'dark',
                onTap: () => _setTheme('dark'),
              ),
              ThemeButton(
                label: 'Light',
                isSelected: _theme == 'light',
                onTap: () => _setTheme('light'),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            'Warna',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ThemeButton(
                label: 'Purple',
                isSelected: _color == 'purple',
                onTap: () => _setColor('purple'),
                color: const Color(0xFF7C3AED),
              ),
              ThemeButton(
                label: 'Blue',
                isSelected: _color == 'blue',
                onTap: () => _setColor('blue'),
                color: const Color(0xFF3B82F6),
              ),
              ThemeButton(
                label: 'Red',
                isSelected: _color == 'red',
                onTap: () => _setColor('red'),
                color: const Color(0xFFEF4444),
              ),
            ],
          ),
          const SizedBox(height: 32),
          const Divider(),
          const SizedBox(height: 8),
          ListTile(
            leading: Icon(Icons.favorite, color: Theme.of(context).colorScheme.primary),
            title: const Text('Donate'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _showDonate,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          ListTile(
            leading: Icon(Icons.help_outline, color: Theme.of(context).colorScheme.primary),
            title: const Text('Cara Pakai'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _showCaraPakai,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          ListTile(
            leading: Icon(Icons.info_outline, color: Theme.of(context).colorScheme.primary),
            title: const Text('Tentang'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _showTentang,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          ListTile(
            leading: Icon(Icons.apk_install, color: Theme.of(context).colorScheme.primary),
            title: const Text('Versi APK'),
            subtitle: Text(_version.isEmpty ? 'Memuat...' : _version),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ],
      ),
    );
  }
}
