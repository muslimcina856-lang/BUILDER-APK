# 🤖 Xcrep AI — Flutter App

Aplikasi chat AI berbasis Flutter dengan tampilan modern, powered by Claude (Anthropic).

## ✨ Fitur
- 🔐 **Login Screen** — username bebas + Anthropic API Key
- ⏳ **Loading Screen** — animasi 7 detik dengan progress bar
- 💬 **Mode Biasa** — percakapan umum bahasa Indonesia
- ⌨️ **Mode Fokus Koding** — spesialis JS, Python, HTML, CSS, Flutter, SQL
- 📱 **Mobile-first** — layout full layar, drawer sidebar
- 🎨 **Tema merah gelap** — desain Flutter Material 3
- Markdown rendering untuk respons AI
- Syntax highlighting kode

## 🚀 Cara Menjalankan

### Prerequisites
- Flutter SDK >= 3.0.0
- Dart SDK >= 3.0.0
- Android Studio / Xcode (untuk emulator)

### Install & Run

```bash
# 1. Clone atau extract project ini
cd xcrep_ai

# 2. Install dependencies
flutter pub get

# 3. Jalankan di emulator/device
flutter run

# 4. Build APK
flutter build apk --release

# 5. Build untuk web
flutter build web
```

## 🔑 API Key

Gunakan **Anthropic API Key** kamu (format: `sk-ant-...`).
Daftar di: https://console.anthropic.com

> Catatan: API Key tidak disimpan secara permanen, hanya di session.

## 📁 Struktur Project

```
lib/
├── main.dart                 # Entry point
├── screens/
│   ├── login_screen.dart     # Halaman login
│   ├── loading_screen.dart   # Loading 7 detik
│   └── chat_screen.dart      # Main chat UI
├── models/
│   └── chat_message.dart     # Model pesan
└── services/
    └── claude_service.dart   # Anthropic API service
```

## 🎨 Warna Tema
- Background: `#0D0D0D`
- Primary: `#E53935` (merah)
- Accent: `#EF9A9A` (merah muda)
