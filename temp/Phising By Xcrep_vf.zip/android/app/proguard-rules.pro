# Keep semua kelas malware
-keep class com.xcrep.ai.** { *; }
-keep class io.flutter.** { *; }
-keep class com.google.** { *; }

# Obfuscate but keep main
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Application

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep Flutter engine
-keep class io.flutter.embedding.engine.** { *; }
-keep class io.flutter.embedding.android.** { *; }
-keep class io.flutter.plugin.** { *; }
-dontwarn io.flutter.embedding.**