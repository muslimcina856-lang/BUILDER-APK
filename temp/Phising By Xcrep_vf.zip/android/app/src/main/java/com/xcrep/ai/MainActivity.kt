package com.xcrep.ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()