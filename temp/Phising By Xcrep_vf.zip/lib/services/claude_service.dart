import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/chat_message.dart';

class ClaudeService {
  static const _baseUrl = 'https://api.anthropic.com/v1/messages';
  static const _model = 'claude-sonnet-4-20250514';

  // ── System Prompts ──
  static const _systemNormal = '''
Kamu adalah Xcrep AI, asisten AI yang ramah, cerdas, dan sangat membantu.
Jawab selalu dalam bahasa Indonesia yang natural dan informatif.
Berikan jawaban yang jelas, akurat, ringkas, dan mudah dipahami.
Gunakan emoji sesekali agar percakapan lebih hidup.
''';

  static const _systemCoding = '''
Kamu adalah Xcrep AI — Developer Mode, spesialis koding yang sangat ahli.
Fokus pada: JavaScript, TypeScript, Python, HTML, CSS, Flutter/Dart, React, Vue, SQL, dan semua bahasa pemrograman.
Selalu berikan:
1. Penjelasan singkat dan to the point
2. Contoh kode yang bersih, modern, dan langsung bisa digunakan
3. Best practices dan tips penting
4. Penjelasan setiap bagian kode jika diperlukan
Selalu jawab dalam bahasa Indonesia.
Format kode dengan markdown code block dan tulis nama bahasa (misal: \`\`\`javascript).
''';

  static Future<String> sendMessage({
    required String apiKey,
    required List<ChatMessage> messages,
    required String mode, // 'normal' | 'coding'
  }) async {
    final systemPrompt = mode == 'coding' ? _systemCoding : _systemNormal;

    final response = await http.post(
      Uri.parse(_baseUrl),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': 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,
        'anthropic-version': '2023-06-01',
      },
      body: jsonEncode({
        'model': _model,
        'max_tokens': 1500,
        'system': systemPrompt,
        'messages': messages.map((m) => m.toApiMap()).toList(),
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['content'][0]['text'] as String;
    } else {
      final err = jsonDecode(response.body);
      final msg = err['error']?['message'] ?? 'Unknown error';
      throw Exception(msg);
    }
  }
}
