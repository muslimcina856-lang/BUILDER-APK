class ChatMessage {
  final String role; // 'user' | 'assistant'
  final String content;
  final DateTime time;

  ChatMessage({
    required this.role,
    required this.content,
    required this.time,
  });

  Map<String, dynamic> toApiMap() => {
    'role': role == 'assistant' ? 'assistant' : 'user',
    'content': content,
  };
}
