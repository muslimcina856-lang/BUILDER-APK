package com.marnommk.app

import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.app.Activity
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.marnommk.app/vpn"
    private val VPN_REQUEST_CODE = 101
    private var pendingResult: MethodChannel.Result? = null
    
    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "checkInstalledGames" -> {
                    val packages = call.argument<List<String>>("packages") ?: listOf()
                    val installed = mutableListOf<String>()
                    val pm = context.packageManager
                    for (pkg in packages) {
                        try {
                            pm.getPackageInfo(pkg, 0)
                            installed.add(pkg)
                        } catch (e: PackageManager.NameNotFoundException) {
                            // Not installed
                        }
                    }
                    result.success(installed)
                }
                "startVpn" -> {
                    val intent = VpnService.prepare(context)
                    if (intent != null) {
                        pendingResult = result
                        startActivityForResult(intent, VPN_REQUEST_CODE)
                    } else {
                        startMarnoService()
                        result.success(true)
                    }
                }
                "stopVpn" -> {
                    stopMarnoService()
                    result.success(true)
                }
                "isServiceRunning" -> {
                    result.success(MarnoVpnService.isRunning)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == VPN_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                startMarnoService()
                pendingResult?.success(true)
            } else {
                pendingResult?.success(false)
            }
            pendingResult = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun startMarnoService() {
        val serviceIntent = Intent(this, MarnoVpnService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun stopMarnoService() {
        val serviceIntent = Intent(this, MarnoVpnService::class.java)
        serviceIntent.action = "STOP_SERVICE"
        startService(serviceIntent)
    }
}
