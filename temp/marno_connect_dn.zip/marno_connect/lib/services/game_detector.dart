import 'package:flutter/services.dart';
import '../utils/config.dart';

class GameDetector {
  static const MethodChannel _channel = MethodChannel('com.marnommk.app/vpn');

  static Future<List<Map<String, String>>> getInstalledGames() async {
    try {
      final List<dynamic> result = await _channel.invokeMethod('checkInstalledGames', {
        'packages': [AppConfig.ffPackage, AppConfig.ffMaxPackage]
      });
      
      List<Map<String, String>> installed = [];
      for (var p in result) {
        if (p == AppConfig.ffPackage) {
          installed.add({'name': 'Free Fire', 'package': p});
        } else if (p == AppConfig.ffMaxPackage) {
          installed.add({'name': 'Free Fire MAX', 'package': p});
        }
      }
      return installed;
    } on PlatformException {
      return [];
    }
  }
}
