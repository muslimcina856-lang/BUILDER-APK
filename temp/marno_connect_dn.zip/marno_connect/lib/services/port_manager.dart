import 'dart:io';
import '../utils/config.dart';

class PortManager {
  static Future<int?> findAvailablePort() async {
    for (int p = AppConfig.defaultPort; p < AppConfig.defaultPort + AppConfig.maxPortTries; p++) {
      try {
        var socket = await ServerSocket.bind(InternetAddress.loopbackIPv4, p);
        await socket.close();
        return p;
      } catch (e) {
        continue;
      }
    }
    return null;
  }
}
