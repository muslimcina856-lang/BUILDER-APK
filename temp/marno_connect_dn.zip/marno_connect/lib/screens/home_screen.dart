import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/app_state.dart';
import '../services/game_detector.dart';
import '../services/file_manager.dart';
import '../widgets/support_dialog.dart';
import 'log_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      context.read<AppState>().syncStatus();
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _handleConnect() async {
    final appState = context.read<AppState>();
    
    appState.logger.info("Checking installed games...");
    final games = await GameDetector.getInstalledGames();
    
    if (games.isEmpty) {
      appState.logger.error("Free Fire tidak ditemukan");
      _showError("Free Fire tidak ditemukan. Silakan install game terlebih dahulu.");
      return;
    }

    Map<String, String>? selectedGame;

    if (games.length == 1) {
      selectedGame = games.first;
      appState.logger.info("Free Fire detected: ${selectedGame['name']}");
    } else {
      selectedGame = await showDialog<Map<String, String>>(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: const Text("Pilih Free Fire yang ingin digunakan"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: games.map((g) => ListTile(
              title: Text(g['name']!),
              trailing: const Icon(Icons.computer),
              onTap: () => Navigator.pop(context, g),
            )).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, null),
              child: const Text("Batal"),
            )
          ],
        ),
      );
    }

    if (selectedGame == null) {
      appState.logger.info("User cancelled game selection");
      return;
    }

    // Config Check
    appState.logger.info("Checking localconfig.json");
    bool configExists = await FileManager.checkConfigExists();
    if (configExists) {
      bool? proceed = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          title: const Text("localconfig.json sudah ada"),
          content: const Text("File localconfig.json sudah ditemukan. Apakah kamu ingin menggantinya?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("TIDAK / MATIKAN", style: TextStyle(color: Colors.red)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text("TIMPA / LANJUTKAN"),
            ),
          ],
        ),
      );
      
      if (proceed != true) {
        appState.logger.info("User cancelled connection at config check");
        return;
      }
    }

    await FileManager.createBackupAndWriteNew(appState.logger);

    bool success = await appState.connect(context, selectedGame['name']!, selectedGame['package']!);
    if (success) {
      final prefs = await SharedPreferences.getInstance();
      bool popupShown = prefs.getBool('supportShown') ?? false;
      if (!popupShown) {
        if (!mounted) return;
        showDialog(context: context, builder: (_) => const SupportDialog());
        await prefs.setBool('supportShown', true);
      }
    } else {
      _showError("Gagal memulai koneksi. Periksa log.");
    }
  }

  Future<void> _handleDisconnect() async {
    final appState = context.read<AppState>();
    bool? confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Konfirmasi"),
        content: const Text("Putuskan koneksi?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Tidak"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Ya"),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await appState.disconnect();
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Marno Connect"),
        actions: [
          IconButton(
            icon: const Icon(Icons.bug_report),
            onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const LogScreen())
            ),
          )
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: BorderRadius.circular(20),
                image: const DecorationImage(
                  image: AssetImage('assets/logo.png'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              "MARNO CONNECT",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 1.5),
            ),
            const SizedBox(height: 16),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.circle,
                  size: 16,
                  color: appState.isConnected ? Colors.greenAccent : Colors.redAccent,
                ),
                const SizedBox(width: 8),
                Text(
                  appState.isConnected ? "CONNECTED" : "DISCONNECTED",
                  style: TextStyle(
                    fontSize: 18,
                    color: appState.isConnected ? Colors.greenAccent : Colors.redAccent,
                    fontWeight: FontWeight.w500
                  ),
                ),
              ],
            ),
            
            if (appState.isConnected && appState.activePort != null) ...[
              const SizedBox(height: 16),
              Text("Port: ${appState.activePort}", style: const TextStyle(fontSize: 16, color: Colors.white70)),
              const SizedBox(height: 4),
              Text("Game: ${appState.selectedGameName ?? '-'}", style: const TextStyle(fontSize: 16, color: Colors.white70)),
            ],

            const SizedBox(height: 48),

            if (!appState.isConnected)
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                  backgroundColor: Colors.blueAccent,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                onPressed: _handleConnect,
                child: const Text("CONNECT", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              )
            else
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                  backgroundColor: Colors.redAccent,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                onPressed: _handleDisconnect,
                child: const Text("EXIT", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
          ],
        ),
      ),
    );
  }
}
