import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/logger_service.dart';
import '../services/game_detector.dart';
import '../services/port_manager.dart';
import '../services/file_manager.dart';

class AppState extends ChangeNotifier {
  static const MethodChannel _channel = MethodChannel('com.marnommk.app/vpn');
  
  bool isConnected = false;
  int? activePort;
  String? selectedGameName;
  String? selectedGamePackage;
  
  final LoggerService logger;
  
  AppState(this.logger) {
    _init();
  }

  Future<void> _init() async {
    logger.info("App started");
    await syncStatus();
  }

  Future<void> syncStatus() async {
    try {
      final bool status = await _channel.invokeMethod('isServiceRunning');
      isConnected = status;
      
      final prefs = await SharedPreferences.getInstance();
      if (isConnected) {
        activePort = prefs.getInt('activePort');
        selectedGameName = prefs.getString('selectedGameName');
      } else {
        activePort = null;
        selectedGameName = null;
      }
      notifyListeners();
    } catch (e) {
      logger.error("Failed to sync status: $e");
    }
  }

  Future<bool> connect(BuildContext context, String gameName, String gamePackage) async {
    logger.info("Checking port...");
    final port = await PortManager.findAvailablePort();
    if (port == null) {
      logger.error("No available port found.");
      return false;
    }
    logger.info("Port $port available");

    final prefs = await SharedPreferences.getInstance();

    logger.info("Starting VPN service...");
    try {
      final bool success = await _channel.invokeMethod('startVpn', {
        'port': port,
        'game': gamePackage
      });

      if (success) {
        isConnected = true;
        activePort = port;
        selectedGameName = gameName;
        selectedGamePackage = gamePackage;
        
        await prefs.setInt('activePort', port);
        await prefs.setString('selectedGameName', gameName);
        
        logger.info("Connection established");
        notifyListeners();
        return true;
      } else {
        logger.error("Failed to start service or permission denied.");
        return false;
      }
    } catch (e) {
      logger.error("Error starting connection: $e");
      return false;
    }
  }

  Future<void> disconnect() async {
    logger.info("Stopping connection...");
    try {
      await _channel.invokeMethod('stopVpn');
      await FileManager.restoreBackup(logger);
      
      isConnected = false;
      activePort = null;
      selectedGameName = null;
      selectedGamePackage = null;
      
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('activePort');
      await prefs.remove('selectedGameName');
      
      logger.info("Connection stopped");
      notifyListeners();
    } catch (e) {
      logger.error("Error stopping connection: $e");
    }
  }
}
