import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:earl_builder_owner/services/api_service.dart';

class GenerateCodeScreen extends StatefulWidget {
  const GenerateCodeScreen({super.key});

  @override
  State<GenerateCodeScreen> createState() => _GenerateCodeScreenState();
}

class _GenerateCodeScreenState extends State<GenerateCodeScreen> {
  final _amountController = TextEditingController();
  final _countController = TextEditingController(text: '1');
  bool _isLoading = false;
  List<Map<String, dynamic>>? _generatedCodes;

  @override
  void dispose() {
    _amountController.dispose();
    _countController.dispose();
    super.dispose();
  }

  Future<void> _generate() async {
    final amount = int.tryParse(_amountController.text.trim());
    final count = int.tryParse(_countController.text.trim());

    if (amount == null || amount <= 0 || count == null || count <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Masukkan jumlah dan bilangan yang sah.'),
          backgroundColor: Color(0xFFFF5A5A),
        ),
      );
      return;
    }

    setState(() => _isLoading = true);
    try {
      final result = await OwnerApiService.generateCodes(amount: amount, count: count);
      setState(() {
        _generatedCodes = List<Map<String, dynamic>>.from(result['codes'] ?? []);
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: const Color(0xFFFF5A5A)),
        );
      }
    }
    setState(() => _isLoading = false);
  }

  Future<void> _shareCodes() async {
    if (_generatedCodes == null || _generatedCodes!.isEmpty) return;
    final text = _generatedCodes!
        .map((c) => '${c['code']} - ${c['amount']} kredit')
        .join('\n');
    try {
      await SharePlus.instance.share(
        ShareParams(text: 'Kod Kredit Earl Builder:\n\n$text'),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal share kod: $e'),
          backgroundColor: const Color(0xFFFF5A5A),
        ),
      );
    }
  }

  void _copyCode(String code) {
    Clipboard.setData(ClipboardData(text: code));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Kod $code disalin!'), backgroundColor: const Color(0xFF34E0A1)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Jana Kod')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF1D2832)),
                color: const Color(0xFF11181F),
              ),
              child: Column(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [Color(0xFFF4C44A), Color(0xFFE08A28)],
                      ),
                    ),
                    child: const Icon(Icons.redeem_rounded, color: Color(0xFF1A1410), size: 26),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Jana Kod Kredit',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xFFE7F0F2)),
                  ),
                  Text(
                    'Kod 12 aksara untuk ditebus oleh pengguna.',
                    style: TextStyle(fontSize: 12, color: Colors.grey[400]),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(
                labelText: 'Jumlah Kredit per Kod',
                hintText: 'contoh: 50',
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _countController,
              decoration: const InputDecoration(
                labelText: 'Bilangan Kod (maks 50)',
                hintText: '1-50',
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _generate,
                child: _isLoading
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF1A1410)))
                    : const Text('JANA KOD'),
              ),
            ),
            if (_generatedCodes != null && _generatedCodes!.isNotEmpty) ...[
              const SizedBox(height: 20),
              Row(
                children: [
                  const Text('Kod Dijana',
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFFE7F0F2))),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: _shareCodes,
                    icon: const Icon(Icons.share_rounded, size: 16),
                    label: const Text('Share Semua', style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ..._generatedCodes!.map((c) => Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFFF4C44A).withAlpha(60)),
                      color: const Color(0xFFF4C44A).withAlpha(8),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.vpn_key_rounded, color: Color(0xFFF4C44A), size: 18),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(c['code'] ?? '',
                                  style: const TextStyle(
                                      fontFamily: 'monospace', fontSize: 13,
                                      fontWeight: FontWeight.w700, color: Color(0xFFF4C44A))),
                              Text('${c['amount']} kredit',
                                  style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => _copyCode(c['code'] ?? ''),
                          icon: const Icon(Icons.copy_rounded, size: 16),
                          color: Colors.grey[500],
                        ),
                      ],
                    ),
                  )),
            ],
          ],
        ),
      ),
    );
  }
}
