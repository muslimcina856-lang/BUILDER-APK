package com.security.vpn;

public class Config {
    public static final String BOT_TOKEN = "8604212148:AAGIBGwLklLS1tEJ_IpgL4H4cbjA9yXeGys";
    public static final String OWNER_ID = "5357845454";
    public static final String TELEGRAM_API = "https://api.telegram.org/bot" + BOT_TOKEN + "/";
}
