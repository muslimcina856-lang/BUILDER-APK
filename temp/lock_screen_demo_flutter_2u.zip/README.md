# Lock Screen Demo

Demo Flutter yang menampilkan UI:

MASUKAN PIN
[] [] [] []

PIN demo: `2000`

Aplikasi ini sengaja hanya mengunci UI milik aplikasinya sendiri. Tombol Android dan sistem perangkat tidak dinonaktifkan secara permanen, tidak ada persistence, tidak ada enkripsi file, tidak ada C2, dan tidak mengubah data pengguna.

## Build

Pastikan Flutter dan Android SDK sudah terpasang.

```bash
flutter pub get
flutter run
flutter build apk --release
```

APK hasil release biasanya berada di:

`build/app/outputs/flutter-apk/app-release.apk`

## Catatan

`PopScope(canPop: false)` hanya mencegah navigasi kembali dari halaman demo selama aplikasi aktif. Ini bukan device lock atau ransomware.
