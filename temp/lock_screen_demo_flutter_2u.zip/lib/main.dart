import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(const LockDemoApp());
}

class LockDemoApp extends StatelessWidget {
  const LockDemoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Lock Screen Demo',
      theme: ThemeData.dark(useMaterial3: true),
      home: const LockScreen(),
    );
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  static const String pin = '2000';
  final List<String> entered = [];
  bool unlocked = false;
  Timer? vibrationTimer;

  void addDigit(String digit) {
    if (unlocked || entered.length >= 4) return;

    setState(() => entered.add(digit));

    if (entered.length == 4) {
      final value = entered.join();
      if (value == pin) {
        setState(() => unlocked = true);
      } else {
        Future.delayed(const Duration(milliseconds: 350), () {
          if (mounted) setState(() => entered.clear());
        });
      }
    }
  }

  void clearPin() {
    if (!unlocked) setState(() => entered.clear());
  }

  @override
  Widget build(BuildContext context) {
    if (unlocked) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.check_circle, size: 80),
              const SizedBox(height: 20),
              const Text(
                'TERBUKA',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              const Text('Ini hanya demo lock-screen untuk pengujian UI.'),
              const SizedBox(height: 28),
              FilledButton(
                onPressed: () => setState(() {
                  unlocked = false;
                  entered.clear();
                }),
                child: const Text('Kunci lagi'),
              ),
            ],
          ),
        ),
      );
    }

    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.lock, size: 72),
                    const SizedBox(height: 24),
                    const Text(
                      'MASUKAN PIN',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 22),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        4,
                        (i) => Container(
                          width: 42,
                          height: 42,
                          margin: const EdgeInsets.symmetric(horizontal: 6),
                          decoration: BoxDecoration(
                            border: Border.all(width: 2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            i < entered.length ? '•' : '',
                            style: const TextStyle(fontSize: 30),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'PIN: 2000',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 30),
                    GridView.count(
                      shrinkWrap: true,
                      crossAxisCount: 3,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 1.5,
                      physics: const NeverScrollableScrollPhysics(),
                      children: [
                        for (final digit in ['1','2','3','4','5','6','7','8','9'])
                          FilledButton(
                            onPressed: () => addDigit(digit),
                            child: Text(digit, style: const TextStyle(fontSize: 22)),
                          ),
                        OutlinedButton(
                          onPressed: clearPin,
                          child: const Icon(Icons.backspace_outlined),
                        ),
                        FilledButton(
                          onPressed: () => addDigit('0'),
                          child: const Text('0', style: TextStyle(fontSize: 22)),
                        ),
                        const SizedBox.shrink(),
                      ],
                    ),
                    const SizedBox(height: 22),
                    const Text(
                      'DEMO SAJA • Tidak mengunci perangkat Android.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white60),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    vibrationTimer?.cancel();
    super.dispose();
  }
}
