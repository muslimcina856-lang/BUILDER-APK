import com.filemanagerpro.app.search.*
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import java.io.File
import kotlin.io.path.createTempDirectory
import java.util.Random
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private fun storedEntry(z: ZipOutputStream, name: String, bytes: ByteArray) {
    val crc = CRC32().apply { update(bytes) }
    val e = ZipEntry(name).apply {
        method = ZipEntry.STORED
        size = bytes.size.toLong()
        compressedSize = bytes.size.toLong()
        this.crc = crc.value
    }
    z.putNextEntry(e); z.write(bytes); z.closeEntry()
}

fun main() = runBlocking {
    val root = createTempDirectory("fmp-nested-large-").toFile()
    try {
        val payload = ByteArray(9 * 1024 * 1024)
        Random(7).nextBytes(payload)
        val needle = "NESTED-LARGE-NEEDLE".toByteArray()
        System.arraycopy(needle, 0, payload, payload.size - needle.size - 8, needle.size)
        val inner = File(root, "inner.zip")
        ZipOutputStream(inner.outputStream().buffered()).use { z -> storedEntry(z, "deep.bin", payload) }
        check(inner.length() > 8L * 1024 * 1024) { "inner archive unexpectedly small" }
        val outer = File(root, "outer.zip")
        ZipOutputStream(outer.outputStream().buffered()).use { z -> storedEntry(z, "inner.zip", inner.readBytes()) }
        val req = DeepSearchRequest(
            roots = listOf(outer), query = "NESTED-LARGE-NEEDLE", searchNames = false,
            searchContents = true, scanArchives = true, scanBinaryStrings = true,
            maxArchiveDepth = 4, maxExpandedBytes = 64L * 1024 * 1024
        )
        val hits = DeepSearchEngine().search(req).toList()
        check(hits.any { it.displayPath.contains("outer.zip") && it.displayPath.contains("inner.zip") && it.displayPath.contains("deep.bin") }) { hits.toString() }
        println("LARGE NESTED ARCHIVE REGRESSION: PASS hits=${hits.size} inner=${inner.length()}")
    } finally { root.deleteRecursively() }
}
