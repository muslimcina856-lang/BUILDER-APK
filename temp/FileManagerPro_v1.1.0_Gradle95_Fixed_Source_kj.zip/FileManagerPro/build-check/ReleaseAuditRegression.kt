import com.filemanagerpro.app.search.*
import com.filemanagerpro.app.storage.LocalFileRepository
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.runBlocking
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.io.path.createTempDirectory

fun main() = runBlocking {
    val root = createTempDirectory("fmp-audit-").toFile()
    val repo = LocalFileRepository()
    try {
        val src = File(root, "src").apply { mkdirs() }
        val dst = File(root, "dst").apply { mkdirs() }
        val big = File(src, "big.txt")
        big.outputStream().use { out ->
            val block = ByteArray(1024 * 1024) { 'A'.code.toByte() }
            repeat(9) { out.write(block) }
            out.write("\nneedle-at-end\n".toByteArray())
        }

        val bigZip = File(root, "big.zip")
        ZipOutputStream(bigZip.outputStream().buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("huge.txt"))
            val block = ByteArray(1024 * 1024) { 'B'.code.toByte() }
            repeat(9) { zip.write(block) }
            zip.write("\nneedle-at-end\n".toByteArray())
            zip.closeEntry()
        }

        val hits = mutableListOf<SearchHit>()
        DeepSearchEngine().search(DeepSearchRequest(listOf(root), "needle-at-end")).collect { hits += it }
        check(hits.any { it.displayPath.endsWith("big.txt") && it.type == SearchHitType.FILE_CONTENT })
        check(hits.any { it.displayPath.contains("big.zip") && it.displayPath.contains("huge.txt") && it.type == SearchHitType.ARCHIVE_CONTENT })

        val sourceName = File(src, "same.txt").apply { writeText("SOURCE") }
        File(dst, "same.txt").writeText("EXISTING")
        val copied = repo.copy(sourceName, dst).getOrThrow()
        check(File(dst, "same.txt").readText() == "EXISTING")
        check(copied.name != "same.txt" && copied.readText() == "SOURCE")

        val moving = File(src, "move.txt").apply { writeText("MOVE") }
        File(dst, "move.txt").writeText("KEEP")
        val moved = repo.move(moving, dst).getOrThrow()
        check(File(dst, "move.txt").readText() == "KEEP")
        check(moved.name != "move.txt" && moved.readText() == "MOVE")
        check(!moving.exists())

        val corrupt = File(root, "corrupt.zip").apply { writeBytes(byteArrayOf(1,2,3,4,5,6,7)) }
        check(repo.unzip(corrupt, root).isFailure)
        check(root.listFiles().orEmpty().none { it.name.startsWith(".fmp_extract_") })

        val unsafe = File(root, "unsafe.zip")
        ZipOutputStream(unsafe.outputStream()).use { zip ->
            zip.putNextEntry(ZipEntry("safe.txt")); zip.write("safe".toByteArray()); zip.closeEntry()
            zip.putNextEntry(ZipEntry("../evil.txt")); zip.write("evil".toByteArray()); zip.closeEntry()
        }
        check(repo.unzip(unsafe, root).isFailure)
        check(!File(root.parentFile, "evil.txt").exists())
        check(root.listFiles().orEmpty().none { it.name.startsWith(".fmp_extract_") })

        println("RELEASE AUDIT REGRESSION: PASS")
        println("large-search hits=${hits.size}, copy=${copied.name}, move=${moved.name}")
    } finally {
        root.deleteRecursively()
    }
}
