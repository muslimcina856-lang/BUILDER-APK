import com.filemanagerpro.app.signing.SigningMaterialLoader
import java.io.File
fun main() {
  val l=SigningMaterialLoader(); val d=File("/mnt/data/signfmt")
  val rsa=l.load(File(d,"rsa.jwk"), certificateFile=File(d,"cert.pem")).getOrThrow()
  check(rsa.privateKey.algorithm.equals("RSA",true)); println("PASS JWK RSA -> ${rsa.format}")
  val ec=l.load(File(d,"ec.jwk"), certificateFile=File(d,"ec-cert.pem")).getOrThrow()
  check(ec.privateKey.algorithm.equals("EC",true)||ec.privateKey.algorithm.equals("ECDSA",true)); println("PASS JWK EC -> ${ec.format}")
  val enc=l.load(File(d,"encrypted-pk8.der"), keyPassword="changeit".toCharArray(), certificateFile=File(d,"cert.pem")).getOrThrow()
  check(enc.privateKey.algorithm.equals("RSA",true)); println("PASS encrypted PKCS8 DER -> ${enc.format}")
  println("JWK/DER REGRESSION: PASS")
}
