import com.filemanagerpro.app.storage.LocalFileRepository
import com.filemanagerpro.app.search.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.collect
import java.io.File
import kotlin.io.path.createTempDirectory

fun main() = runBlocking {
    val root = createTempDirectory("fmp-release-").toFile()
    val repo = LocalFileRepository()
    try {
        val a = repo.createFolder(root, "A").getOrThrow()
        val b = repo.createFolder(root, "B").getOrThrow()
        val note = repo.createFile(a, "note.txt").getOrThrow()
        note.writeText("needle release candidate\nhello")

        check(repo.hash(note, "SHA-256").getOrThrow().length == 64)
        check(repo.hash(note, "MD5").getOrThrow().length == 32)
        val dup = repo.duplicate(note).getOrThrow()
        check(dup.readText().contains("needle"))
        val copied = repo.copy(note, b).getOrThrow()
        check(copied.exists())
        val renamed = repo.rename(copied, "renamed.txt").getOrThrow()
        check(renamed.name == "renamed.txt")

        val multiZip = repo.zipMany(listOf(a, renamed), root, "Selection.zip").getOrThrow()
        check(repo.listZipEntries(multiZip).getOrThrow().isNotEmpty())

        val zip = repo.zip(a, root).getOrThrow()
        val entries = repo.listZipEntries(zip).getOrThrow()
        check(entries.any { it.endsWith("note.txt") })
        val extracted = repo.unzip(zip, root).getOrThrow()
        check(extracted.walkTopDown().any { it.isFile && it.name == "note.txt" })

        val props = repo.properties(a).getOrThrow()
        check(props.fileCount >= 2)
        check(props.size > 0)

        val engine = DeepSearchEngine()
        val hits = mutableListOf<SearchHit>()
        engine.search(
            DeepSearchRequest(roots = listOf(root), query = "needle", scanArchives = true, scanBinaryStrings = true),
            onProgress = {}
        ).collect { hits += it }
        check(hits.any { it.type == SearchHitType.FILE_CONTENT })
        check(hits.any { it.type == SearchHitType.ARCHIVE_CONTENT })

        repo.move(renamed, a).getOrThrow()
        check(File(a, "renamed.txt").exists())
        repo.delete(File(a, "renamed.txt")).getOrThrow()
        check(!File(a, "renamed.txt").exists())

        println("RELEASE CORE REGRESSION: PASS")
        println("search hits=${hits.size}, zip entries=${entries.size}, files=${props.fileCount}, bytes=${props.size}")
    } finally {
        root.deleteRecursively()
    }
}
