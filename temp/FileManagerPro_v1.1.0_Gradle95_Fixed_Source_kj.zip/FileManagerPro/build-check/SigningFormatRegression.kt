import com.filemanagerpro.app.signing.SigningMaterialLoader
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.File
import java.security.KeyStore

fun main() {
    val dir = File("/mnt/data/signfmt")
    val loader = SigningMaterialLoader()
    val storePass = "changeit".toCharArray()
    val keyPass = "keypass1".toCharArray()

    fun checkStore(name: String, store: CharArray, key: CharArray = store) {
        val f = File(dir, name)
        val i = loader.inspect(f, store).getOrThrow()
        val m = loader.load(f, store, key).getOrThrow()
        check(i.privateKeyDetected)
        check(m.certificates.isNotEmpty())
        println("PASS store $name -> ${i.format}, alias=${m.alias}, alg=${m.privateKey.algorithm}")
    }

    checkStore("release.jks", storePass, keyPass)
    checkStore("release.jceks", storePass, keyPass)
    checkStore("release.p12", storePass)
    checkStore("release.pfx", storePass)

    val p12 = KeyStore.getInstance("PKCS12").apply { File(dir, "release.p12").inputStream().use { load(it, storePass) } }
    val alias = p12.aliases().toList().first { p12.isKeyEntry(it) }
    val key = p12.getKey(alias, storePass)
    val chain = p12.getCertificateChain(alias)
    val bc = BouncyCastleProvider()
    for (type in listOf("BKS", "BCFKS", "UBER")) {
        val out = File(dir, "release.${type.lowercase()}")
        val ks = KeyStore.getInstance(type, bc)
        ks.load(null, storePass)
        ks.setKeyEntry("release", key, storePass, chain)
        out.outputStream().use { ks.store(it, storePass) }
        checkStore(out.name, storePass)
    }

    fun checkRaw(name: String, pass: CharArray = charArrayOf()) {
        val f = File(dir, name)
        val cert = File(dir, "cert.pem")
        val m = loader.load(f, charArrayOf(), pass, certificateFile = cert).getOrThrow()
        check(m.certificates.isNotEmpty())
        println("PASS raw $name -> ${m.format}, alg=${m.privateKey.algorithm}")
    }

    checkRaw("raw.pem")
    checkRaw("raw.pk8")
    checkRaw("encrypted-pk8.pem", keyPass)
    checkRaw("rsa-pkcs1.pem")

    for (certName in listOf("cert.pem", "cert.der", "cert.p7b")) {
        val info = loader.inspect(File(dir, certName)).getOrThrow()
        check(info.certificateCount >= 1)
        println("PASS cert $certName -> ${info.format}, count=${info.certificateCount}")
    }

    println("SIGNING FORMAT REGRESSION: PASS")
}
