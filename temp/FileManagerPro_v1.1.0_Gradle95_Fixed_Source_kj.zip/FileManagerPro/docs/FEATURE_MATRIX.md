# Feature Matrix - File Manager Pro 1.1.0

Legend: **LIVE** = a real v1.1 handler exists. **MODULE** = deliberately disabled/staged. **PRIV** = future privileged backend.

## File management
- LIVE local browse and parent navigation
- LIVE hidden-file toggle
- LIVE sort by name, size, date and type
- LIVE Pane A / Pane B state
- LIVE phone pane switch and adaptive true dual-pane on wide screens
- LIVE create folder and empty file
- LIVE copy / move / rename / duplicate / recursive delete
- LIVE collision-safe Keep Both default for copy/move; no silent overwrite
- LIVE copy/move directly to the opposite pane
- LIVE long-press contextual tool sheet
- LIVE per-file three-dot contextual tools
- LIVE per-pane three-dot overflow
- LIVE swipe right to select and swipe left to open tools
- LIVE multi-select batch copy / move / one combined ZIP / delete
- LIVE delete confirmation
- LIVE open-with / share / APK installer
- LIVE file properties and copy path
- MODULE clipboard queue, drag/drop, tabs, bookmarks and history
- MODULE collision resolver UI: skip/replace/rename/merge/compare
- MODULE operation journal + undo/trash
- PRIV symlink/chmod/chown/system-data navigation where backend allows

## Deep Search
- LIVE recursive subdirectory traversal
- LIVE filename search
- LIVE streaming text/binary content search without the former fixed 8 MiB per-file cap
- LIVE regex + case-sensitive options
- LIVE ZIP/APK/JAR/AAR/APKS/XAPK entry search
- LIVE nested ZIP-family traversal, including nested archives larger than 8 MiB via bounded temporary streaming
- LIVE printable binary-string extraction
- LIVE streaming results, progress and cancellation
- LIVE archive-entry quota + global expanded-byte quota + canonical directory visit guard
- MODULE extension/MIME/date/size/hash filter UI
- MODULE inode-aware loop table across VFS backends + parallel workers
- MODULE PDF/Office/SQLite/EXIF/ELF extractors
- MODULE decoded AndroidManifest/resources.arsc and indexed DEX search

## Archive
- LIVE create standard ZIP
- LIVE list ZIP-family entries
- LIVE transactional ZIP-family extraction with path-traversal guard and rollback on failure
- LIVE Deep Search through nested ZIP-family archives
- MODULE add/delete/rename archive entries
- MODULE encrypted ZIP creation
- MODULE 7z/RAR/TAR/GZ/XZ/Zstd/Brotli codecs
- MODULE archive repair/password helpers

## Inspection and developer tools
- LIVE bounded text preview
- LIVE SHA-256
- LIVE MD5
- MODULE text/code editor
- MODULE hex editor
- MODULE JSON/XML/YAML formatter
- MODULE text/binary/folder diff
- MODULE SHA-1/SHA-512/BLAKE3
- MODULE SQLite/ELF/media/image inspectors

## APK workspace
- LIVE APK treated as ZIP-family for entry listing and Deep Search
- LIVE explicit Install APK action through Android package installer
- LIVE APK signature verifier reporting v1/v2/v3/v3.1/v4 and signer SHA-256
- LIVE APK signing v1/v2/v3 with optional v4 `.idsig`, using staging -> verify -> commit
- LIVE Signing Key Manager: JKS/JCEKS/PKCS12-PFX/BKS/BCFKS/UBER/PEM-DER/PKCS#8/PKCS#1/SEC1/JWK + X.509/PKCS#7 inputs
- MODULE manifest/package metadata viewer
- MODULE split APK installer
- MODULE installed-app inventory
- MODULE DEX viewer/decompiler/resources workspace
- MODULE full APK rebuild/decompile/resources pipeline; signing itself is LIVE

## Network / remote
- MODULE SMB / CIFS
- MODULE SFTP / SCP
- MODULE WebDAV
- MODULE FTP / FTPS
- MODULE S3 compatible
- MODULE HTTP file server
- MODULE nearby LAN transfer
- MODULE SSH terminal

v1.1.0 does not declare network permissions because no network backend is live.

## Storage intelligence
- MODULE treemap/heatmap
- MODULE largest/oldest/recent files
- MODULE duplicate finder
- MODULE empty/orphan/stale-file analysis
- MODULE snapshots + folder comparison

## Security and release behavior
- LIVE FileProvider-based content sharing
- LIVE transactional ZIP extraction path-traversal + rollback guard
- LIVE bounded text preview
- LIVE Deep Search streaming with global resource quotas
- LIVE no direct-delete swipe gesture
- LIVE destructive-operation confirmation
- LIVE minimal release permission surface
- MODULE app lock / biometric vault
- MODULE encrypted vault
- MODULE signed plugin sandbox
