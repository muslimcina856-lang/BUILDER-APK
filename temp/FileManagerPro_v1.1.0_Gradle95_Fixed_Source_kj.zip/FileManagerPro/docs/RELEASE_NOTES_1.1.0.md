# File Manager Pro 1.1.0 - Repair & Signing Release

## Fixed
- Deep Search no longer skips ordinary files larger than the former 8 MiB content cap; content is scanned in streaming chunks.
- Large ZIP-family entries are scanned without loading the entire entry into RAM.
- Nested ZIP-family archives larger than 8 MiB are streamed to bounded temporary storage and recursively searched.
- Copy/move no longer silently overwrites a same-name destination; the default is Keep Both (`name (2).ext`).
- ZIP extraction is transactional: extract to staging, reject path traversal/corruption, then commit. Failed extraction rolls back staging data.
- Strict keystore alias handling prevents silently selecting a different key when an explicit alias is wrong.
- Certificate ordering now places the certificate matching the private key first, and the key/certificate pair is cryptographically checked.

## Added - Signing Key Manager
- Portable JKS private-key reader.
- Portable JCEKS private-key reader; Java-serialized SecretKey entries are intentionally not deserialized.
- PKCS12/PFX/P12, BKS, BCFKS and UBER stores.
- PEM/DER PKCS#8, encrypted PKCS#8, PKCS#1 RSA, SEC1 EC and OpenSSH parser path.
- JWK RSA/EC plus OKP parsing.
- X.509 PEM/DER and PKCS#7/P7B/P7C certificate bundles.
- Inspect Signing Key and Use as Signing Key contextual actions.
- APK Sign and Verify Signature actions.

## Added - APK signing safety
- v1/v2/v3 signing switches and optional v4 `.idsig`.
- Verification reports v1/v2/v3/v3.1/v4 and signer SHA-256 fingerprints.
- Signed APK uses staging -> verify -> commit; failures do not replace the intended output.
- Same-name signed output uses Keep Both naming.

## Regression status
- Release core: PASS
- Large ordinary/ZIP content search: PASS
- Collision + ZIP rollback: PASS
- Large nested archive (>9 MiB inner ZIP): PASS
- Signing keystore/raw-key/certificate matrix: PASS for tested fixtures
- JWK RSA/EC + encrypted PKCS#8 DER: PASS

## Build metadata
- versionName: 1.1.0
- versionCode: 10100
- compileSdk/targetSdk: 37
- minSdk: 26
- Java: 17
- bundled Bouncy Castle dependency: 1.85

## Environment limitation
This runtime has no Android SDK/Gradle Android toolchain, so the Android UI module and real `apksig` APK signing path cannot be fully built/executed here. The pure Kotlin core and signing material loaders were compiled and regression-tested. A final publish build still requires Android Studio/Gradle + SDK 37 and device/instrumentation verification.
