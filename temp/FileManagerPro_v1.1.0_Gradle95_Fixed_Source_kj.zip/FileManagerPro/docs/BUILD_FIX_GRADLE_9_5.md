# Build fix: Gradle 9.5.0

The project uses Android Gradle Plugin 9.3.0 and compileSdk/targetSdk 37.
AGP 9.3.0 requires Gradle 9.5.0 or newer and JDK 17 or newer.

The project now pins the wrapper distribution in:

`gradle/wrapper/gradle-wrapper.properties`

with:

`distributionUrl=https\://services.gradle.org/distributions/gradle-9.5.0-bin.zip`

The Gradle 9.5.0 binary distribution SHA-256 is pinned with
`distributionSha256Sum=553c78f50dafcd54d65b9a444649057857469edf836431389695608536d6b746`.

If a CI/builder overwrites `gradle/wrapper/gradle-wrapper.properties` after extracting the project, configure that builder to preserve the project's wrapper properties or set its Gradle version to 9.5.0+.
