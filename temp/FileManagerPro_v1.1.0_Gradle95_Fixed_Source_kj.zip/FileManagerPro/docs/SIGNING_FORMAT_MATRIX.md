# Signing Format Matrix - File Manager Pro 1.1.0

Status definitions: **FULL/TESTED** = loader was exercised with a fixture in this environment. **IMPLEMENTED** = parser path exists but no matching fixture/tool was available here. **CERT ONLY** = usable as certificate material, not a private signing key by itself. **NOT DIRECT APK KEY** = intentionally not treated as an APK signing private-key input.

## KeyStore / key containers
| Format | Common extensions | Status | Notes |
|---|---|---|---|
| JKS | `.jks`, `.keystore`, `.ks` | FULL/TESTED | Portable JKS reader; private key + X.509 chain. Does not depend on Android exposing a JKS provider. |
| JCEKS private-key entry | `.jceks` | FULL/TESTED | Portable private-key reader. Serialized SecretKey entries are deliberately not deserialized and are not APK signing keys. |
| PKCS#12 | `.p12`, `.pfx`, `.pkcs12` | FULL/TESTED | Private key + certificate chain. |
| BKS | `.bks` | FULL/TESTED | Uses bundled Bouncy Castle provider instance. |
| BCFKS | `.bcfks` | FULL/TESTED | Uses bundled Bouncy Castle provider instance. |
| UBER | `.uber` | FULL/TESTED | Uses bundled Bouncy Castle provider instance. |

## Raw private keys
| Format | Common extensions | Status | Notes |
|---|---|---|---|
| PKCS#8 PEM | `.pem`, `.key`, `.pk8`, `.p8`, `.pkcs8` | FULL/TESTED | RSA/EC/DSA and algorithms available to the provider. |
| Encrypted PKCS#8 PEM | `.pem`, `.key` | FULL/TESTED | Password required. |
| PKCS#8 DER | `.pk8`, `.p8`, `.pkcs8`, `.der` | FULL/TESTED | Raw DER private key. |
| Encrypted PKCS#8 DER | `.der`, `.pk8`, `.p8` | FULL/TESTED | Password required. |
| PKCS#1 RSA PEM/DER | `.pem`, `.rsa`, `.pkcs1`, `.der` | FULL/TESTED | Converted internally to a Java `PrivateKey`. |
| SEC1 EC PEM/DER | `.pem`, `.ec`, `.sec1`, `.der` | FULL/TESTED | Requires curve parameters. |
| OpenSSH private key | `.openssh`, `.key`, `id_rsa`, `id_dsa`, `id_ecdsa`, `id_ed25519`, `id_ed448` | IMPLEMENTED | Unencrypted inputs that Bouncy Castle can decode; no OpenSSH fixture generator was available in this runtime. |
| JWK RSA | `.jwk`, `.json` | FULL/TESTED | Private members required; `x5c` accepted when supplied. |
| JWK EC P-256/P-384/P-521 | `.jwk`, `.json` | FULL/TESTED | Private member `d` required; `x5c` accepted when supplied. |
| JWK OKP Ed25519/Ed448 | `.jwk`, `.json` | IMPLEMENTED | Can be parsed as key material, but File Manager Pro does not claim these algorithms are accepted by Android APK signing. |

## Certificate material
| Format | Common extensions | Status | Notes |
|---|---|---|---|
| X.509 PEM | `.pem`, `.crt`, `.cer`, `.cert`, `.x509` | FULL/TESTED / CERT ONLY | Can provide leaf/chain certificate for raw private keys. |
| X.509 DER | `.der`, `.crt`, `.cer` | FULL/TESTED / CERT ONLY | Same purpose as PEM. |
| PKCS#7 certificate bundle | `.p7b`, `.p7c`, `.pkcs7`, `.spc` | FULL/TESTED / CERT ONLY | Certificate bundle; does not itself contain the APK private signing key. |

## APK signing behavior
- Supported File Manager Pro signing switches: v1, v2, v3; optional v4 creates a sibling `.idsig`.
- Verification reports v1, v2, v3, v3.1 and v4 when available.
- Signing output is written to a staging file, verified, then committed. Failed signing/verification deletes staging artifacts.
- Existing output names are preserved with Keep Both naming instead of being overwritten silently.
- Raw private-key inputs must be paired with a matching X.509 certificate/chain unless the container/JWK already includes it.
- Explicit aliases are strict: a requested alias must exist and must be a private-key entry.
- The loader cryptographically checks that the private key matches the first/leaf certificate before signing.

## Intentionally not labeled as direct APK signing keys
Public-key-only files, CSR/PKCS#10, PGP/OpenPGP keyrings, SSH public keys, PuTTY PPK, certificate-only files and arbitrary secret-key stores are not mislabeled as direct Android APK signing inputs. They may become separate inspection/conversion tools later, but they are not private-key + X.509 signing material in the form this APK signer consumes.

“Support semua format” in this project means the major practical formats relevant to Android APK signing and certificate inspection, not every cryptographic container ever created.
