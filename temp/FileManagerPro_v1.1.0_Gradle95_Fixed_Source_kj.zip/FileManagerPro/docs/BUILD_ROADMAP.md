# Build Roadmap — File Manager Pro

Matlamat projek bukan meniru menu MT Manager satu-persatu. Sasaran ialah sebuah platform file-management dengan VFS bersama, enjin operasi berjournal, dan Deep Search yang boleh menyeberangi backend serta container.

## Fasa 0 — Foundation (source semasa)
- Compose shell: Files / Deep Search / Tools / Network / Settings.
- Pane A/B; phone switch dan true dual-pane pada skrin lebar.
- Local repository: browse, copy, move, delete, rename, mkdir, SHA-256.
- Deep Search recursive: nama + content + ZIP-family nested + binary printable strings.
- Regex/case, streaming progress, cancel, depth/byte/archive quotas dan canonical visit guard.
- Android 17 local-network permission flow.

## Fasa 1 — Operation Engine
- Queue operasi global dan background foreground-service handoff.
- Collision resolver: overwrite, skip, rename, merge, compare.
- Copy-verify-delete untuk cross-filesystem move.
- Trash / undo journal, retry, pause/resume, checksums selepas copy.
- Tabs, bookmark, history, clipboard shelf, drag/drop.

## Fasa 2 — Unified VFS
- LocalBackend dan SAF backend stabil.
- Capability contract per lokasi.
- ShizukuBackend dan RootBackend dengan badge capability sebenar.
- Virtual collections: recent, favorites, tags, duplicates, search results.
- Semua operasi/search menggunakan URI VFS, bukan bergantung terus pada java.io.File.

## Fasa 3 — Search Index & Extractors
- Persistent SQLite/FTS index incremental.
- Search filter UI: MIME/ext/date/size/hash/owner/mode.
- Saved searches, scope profiles, exclusion rules.
- Extractor plugins: PDF/Office, SQLite, EXIF, media metadata, ELF symbols.
- APK extractors: manifest/resources.arsc/DEX string & symbol index.
- Search merentas Local/SAF/root/network/archive dalam satu query.

## Fasa 4 — Archive Workspace
- Archive browser/edit-in-place untuk ZIP/APK/JAR.
- 7z/RAR/TAR/GZ/XZ/Zstd/Brotli/LZ4 codec modules.
- Create/encrypt/test/extract, password helper, multi-volume, nested virtual folders.
- Archive bomb policies dan resource quotas per task.

## Fasa 5 — Developer + APK Workspace
- Huge-file text/code editor, encoding/EOL, regex replace, diff.
- Hex editor dengan mmap/paged access dan structure bookmarks.
- JSON/XML/YAML, SQLite browser, ELF/SO inspector.
- APK/APKS/XAPK inspector, package inventory, signature viewer, split installer.
- DEX/resources/manifest plugins dan rebuild/sign pipeline dengan user-owned keys.

## Fasa 6 — Storage Intelligence
- Treemap/heatmap, largest/oldest/recent files.
- Duplicate finder: size -> quick hash -> full hash.
- Empty/orphan/stale detector, snapshots, folder diff.
- Storage health dashboard tanpa mendakwa "cleaner" yang memadam secara automatik.

## Fasa 7 — Network & Sync
- SMB, SFTP/SCP, WebDAV, FTP/FTPS, S3 backends.
- HTTP file server, LAN peer transfer, resumable transfers.
- Sync profiles one-way/two-way, conflict policy, dry-run, verify.
- Android 17 ACCESS_LOCAL_NETWORK permission dan discovery flow.

## Fasa 8 — Plugin SDK & Hardening
- Signed plugin bundles + capability manifest.
- Sandboxed process untuk parser berisiko apabila sesuai.
- Fuzz tests untuk archive/parser, malicious path traversal tests, low-storage tests.
- Benchmarks pada storage besar, network lambat dan nested archives.
- Accessibility, keyboard/mouse, tablet/foldable/desktop polish.

## Definition of "lebih lengkap daripada MT"
Jangan ukur dengan jumlah menu sahaja. Release hanya layak menggunakan positioning tersebut apabila matriks feature teras, search depth, VFS backend coverage, operation safety, archive/APK tooling, network protocols dan editor/developer tools sudah dibandingkan semula terhadap versi MT semasa dan lulus ujian fungsi/performance yang ditetapkan.
