# Interaction Guide

## Basic navigation
**Tap folder** -> open folder.

**Tap file** -> open file through Android.

When multi-select is already active, a normal tap toggles selection instead of opening.

## Long press
Long press a row to get haptic feedback and open the contextual tool sheet. This is the fastest route to the full action set and is intended to feel familiar to MT Manager power users without copying its interface exactly.

## Swipe
**Swipe right** -> SELECT. The row returns to its original position.

**Swipe left** -> TOOLS. The contextual tool sheet opens and the row returns.

There is intentionally no direct delete gesture.

## Three-dot menus
### Item three-dot
Opens the same contextual tool sheet as long press.

### Pane three-dot
- New folder
- New file
- Select all
- Sort by name
- Sort by size
- Sort by date
- Sort by type
- Show/hide hidden files

## Multi-select
Selection can begin by swipe-right or by selecting items while selection mode is active.

The bottom action bar provides:
- COPY -> opposite pane
- MOVE -> opposite pane
- ZIP -> one combined `Selection.zip`
- DELETE -> confirmation required

## Context tool examples
### APK
Open, Open With, Install APK, archive listing, extract, share, hashes, copy/move, rename, duplicate, ZIP, path, properties, delete.

### ZIP/APKS/XAPK/JAR/AAR
Open, Open With, archive listing, extract, share, hashes, copy/move, rename, duplicate, ZIP, path, properties, delete.

### Text/JSON/XML/YAML/source files
Open, Open With, text preview, share, hashes, copy/move, rename, duplicate, ZIP, path, properties, delete.
