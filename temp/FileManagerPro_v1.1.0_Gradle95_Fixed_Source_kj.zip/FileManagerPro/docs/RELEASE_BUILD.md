# Release Build Guide

## Toolchain expected
- Android Studio with Android SDK 37
- JDK 17
- Gradle compatible with AGP 9.3.0

## Build from Android Studio
1. Open the `FileManagerPro` directory as a Gradle project.
2. Install Android SDK Platform 37 if Android Studio requests it.
3. Let Gradle sync resolve AndroidX/Compose dependencies.
4. Run the app on an Android 8.0+ device/emulator for UI verification.
5. Grant All Files Access from the in-app Storage Access card when testing full file-manager behavior.
6. For APK installation tests, Android will require the normal per-app permission to install unknown apps.

## Release signing
Create/use your own signing key. Do not commit private keystore files or passwords into this source archive.

In Android Studio use the signed app bundle/APK flow, choose the release variant, then protect the keystore outside the project repository.

## Command-line note
This archive intentionally does not bundle an Android SDK, Gradle distribution or private signing key. Generate/use your local Gradle wrapper/toolchain in your trusted build environment.

## Current environment limitation
The environment used to prepare this source has no Android SDK, `android.jar`, Gradle distribution, `sdkmanager`, `apksigner`, or network path to fetch those binaries. Therefore the provided release artifact is source + regression verification, not a falsely labelled signed APK.
