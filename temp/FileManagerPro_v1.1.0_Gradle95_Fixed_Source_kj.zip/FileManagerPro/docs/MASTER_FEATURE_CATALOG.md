# File Manager Pro — Master Feature Catalog

Status:
- **LIVE** — sudah ada dalam source starter ini.
- **CORE** — modul teras yang direka untuk dibina terus dalam aplikasi.
- **PLUGIN** — modul tambahan supaya core kekal stabil dan ringan.
- **PRIV** — perlukan Shizuku/root/system capability tertentu.

> Prinsip produk: core offline-first dan **tanpa AI**. Semua fungsi analisis/search dibuat secara deterministik pada peranti.

## 1. Explorer & navigasi
- LIVE browse local storage
- LIVE show/hide hidden files
- LIVE parent-path navigation
- LIVE file selection
- LIVE delete API
- LIVE recursive copy API
- LIVE move API dengan fallback copy-verify-delete architecture
- LIVE rename API
- LIVE create folder API
- LIVE SHA-256 repository API + action UI
- LIVE true dual-pane pada tablet/foldable/landscape
- LIVE pane switch pantas pada phone
- CORE multi-tab per pane
- CORE breadcrumb editable
- CORE direct path jump
- CORE back/forward history setiap pane
- CORE pane sync
- CORE bookmarks/favorites
- CORE recent locations
- CORE pinned files/folders
- CORE tree view
- CORE list/grid/gallery modes
- CORE compact/detailed columns
- CORE sort by name/type/size/date/extension
- CORE sort folders separately
- CORE per-folder sort memory
- CORE filter literal/regex/negative match
- CORE multi-select range
- CORE select same extension/type
- CORE invert selection
- CORE select by regex
- CORE selection summary size/count
- CORE clipboard queue
- LIVE copy/move to other pane
- CORE drag & drop
- CORE keyboard shortcuts
- CORE mouse context menu
- CORE operation conflict resolver
- CORE preserve timestamps
- CORE preserve attributes when backend allows
- CORE trash/recycle bin
- CORE undo operation journal
- CORE file tags
- CORE notes/labels for files
- CORE virtual collections
- PRIV chmod/chown
- PRIV symlink create/edit
- PRIV system partition browse when allowed

## 2. Deep Search & indexing
- LIVE recursive subdirectory traversal
- LIVE filename search
- LIVE file-content search
- LIVE regex search
- LIVE case-sensitive toggle
- LIVE ZIP/APK/JAR/AAR/APKS/XAPK entry search
- LIVE nested ZIP-family traversal
- LIVE archive container path in result
- LIVE printable binary-string extraction
- LIVE streaming result emission
- LIVE running progress
- LIVE cancellation
- LIVE canonical directory loop guard
- LIVE max directory depth
- LIVE max archive depth
- LIVE max bytes per file/entry
- LIVE max archive entries quota
- LIVE max expanded archive bytes quota
- CORE include/exclude extensions UI
- CORE MIME filter
- CORE size range filter
- CORE modified/created date filter
- CORE owner/group/mode filter where available
- CORE path include/exclude filter
- CORE hidden/system filter
- CORE exact/contains/prefix/suffix/fuzzy name modes
- CORE hex-byte pattern search
- CORE UTF-8/UTF-16/legacy encoding strategy
- CORE hash search
- CORE duplicate-by-content search
- CORE saved searches
- CORE search history
- CORE search result sorting/grouping
- CORE result export CSV/JSON
- CORE result as virtual folder
- CORE persistent SQLite/FTS index
- CORE incremental index update
- CORE filesystem watcher where available
- CORE index only selected roots
- CORE battery/thermal aware background indexing
- CORE pause/resume indexer
- CORE scan statistics
- PLUGIN 7z/RAR/TAR/GZ/XZ/Zstd archive content search
- PLUGIN PDF text extractor
- PLUGIN DOCX/XLSX/PPTX text extractor
- PLUGIN SQLite table/value search
- PLUGIN EXIF field search
- PLUGIN media metadata search
- PLUGIN AndroidManifest decoded search
- PLUGIN resources.arsc string/index search
- PLUGIN DEX class/method/field/string search
- PLUGIN ELF symbol/string search

## 3. Archive workspace
- LIVE ZIP-family search reader
- CORE ZIP browse like folder
- CORE add/update/delete/rename ZIP entries
- CORE in-place update strategy where safe
- CORE create ZIP
- CORE encrypted ZIP creation
- CORE archive integrity test
- CORE archive password retry list
- CORE parallel extraction
- CORE resumable extraction for supported formats
- CORE split archive helper
- CORE nested archive open without manual extraction
- CORE preview files inside archive
- CORE archive diff
- CORE extract selected entries
- CORE extract with path traversal protection
- PLUGIN 7z
- PLUGIN RAR
- PLUGIN TAR
- PLUGIN TAR.GZ / TGZ
- PLUGIN BZip2
- PLUGIN XZ
- PLUGIN Zstandard
- PLUGIN Brotli
- PLUGIN LZ4/LZ5/Lizard where codec is available
- PLUGIN ISO read-only browser

## 4. APK / Android package workspace
- LIVE APK/APKS/XAPK treated as searchable containers
- CORE installed-app inventory
- CORE extract installed APK/splits
- CORE APK metadata viewer
- CORE minSdk/targetSdk viewer
- CORE manifest permissions/components viewer
- CORE signature certificate viewer
- CORE public-key/fingerprint viewer
- CORE icon/resource preview
- CORE split APK set viewer
- CORE APKS/XAPK package browser
- CORE PackageInstaller single APK install
- CORE PackageInstaller split install
- CORE choose split packages to install
- CORE APK compare
- CORE package permission diff
- CORE resource diff
- CORE native library inventory
- CORE ABI inventory
- PLUGIN decoded binary XML editor
- PLUGIN resources.arsc inspector/editor
- PLUGIN DEX class/method/field/string browser
- PLUGIN DEX diff
- PLUGIN JASM/class workspace
- PLUGIN native ELF/SO inspector
- PLUGIN rebuild pipeline
- PLUGIN user-owned keystore signing
- PRIV app data jump/browse where platform/root permits

## 5. Text, code & binary tools
- CORE multi-file text editor
- CORE huge-file paged viewer
- CORE encoding detection/selection
- CORE EOL conversion
- CORE syntax highlighting
- CORE custom syntax packs
- CORE regex find/replace
- CORE replace in files
- CORE bookmarks/line jump
- CORE code folding
- CORE whitespace/control-character display
- CORE text statistics
- CORE compare/diff
- CORE hex viewer
- CORE writable hex editor
- CORE hex/text dual cursor
- CORE byte-pattern search/replace
- CORE integer/float endian inspector
- CORE binary strings viewer
- CORE base64 encode/decode
- CORE URL encode/decode
- CORE checksum manifest generator/verifier
- CORE JSON formatter/validator
- CORE XML formatter/validator
- CORE YAML/TOML viewer
- CORE CSV viewer
- PLUGIN SQLite browser/editor
- PLUGIN ELF inspector
- PLUGIN protobuf/raw structure inspector

## 6. File intelligence & storage analyzer
- CORE storage overview
- CORE treemap/heatmap
- CORE largest files
- CORE largest folders
- CORE oldest files
- CORE recently modified files
- CORE recently created files
- CORE duplicate finder: size -> quick hash -> full hash
- CORE similar-name finder
- CORE empty folders
- CORE zero-byte files
- CORE stale downloads
- CORE orphan temp files
- CORE extension distribution
- CORE MIME distribution
- CORE per-folder growth snapshot
- CORE folder size cache
- CORE before/after storage snapshot
- CORE folder tree diff
- CORE export analyzer report

## 7. Batch & automation tools
- CORE batch rename templates
- CORE regex rename
- CORE sequence numbering
- CORE date-based rename
- CORE EXIF-based rename
- CORE bulk extension change
- CORE bulk chmod where allowed
- CORE split file by size
- CORE split text by delimiter/length
- CORE merge files
- CORE bulk hash
- CORE bulk compress/extract
- CORE bulk convert line endings/encoding
- CORE folder pair sync
- CORE one-way sync
- CORE mirror sync
- CORE checksum-verified sync
- CORE dry-run preview
- CORE operation presets
- CORE WorkManager scheduled jobs where platform policy allows
- CORE rule engine based on path/type/date/size

## 8. Network & remote spaces
- CORE Android 17 local-network permission flow
- CORE network credential vault backed by Android Keystore
- CORE connection test
- CORE remote mount abstraction through VFS
- CORE per-host bookmarks
- CORE upload/download queue
- CORE pause/retry/resume where protocol supports it
- CORE checksum verify after transfer
- CORE bandwidth limit
- CORE concurrent transfer limit
- CORE HTTP file server
- CORE QR address for browser access
- CORE browser upload/download UI
- PLUGIN SMB/CIFS
- PLUGIN SFTP/SCP
- PLUGIN FTP/FTPS
- PLUGIN WebDAV
- PLUGIN S3-compatible storage
- PLUGIN NFS where practical
- PLUGIN LAN discovery
- PLUGIN peer-to-peer nearby transfer
- PLUGIN remote SSH terminal

## 9. Backup & synchronization
- CORE backup selected files/folders
- CORE incremental backup manifest
- CORE versioned snapshots
- CORE retention policy
- CORE restore preview
- CORE checksum verification
- CORE local-to-SD/USB backup
- PLUGIN local-to-network backup
- PLUGIN encrypted backup container
- PRIV installed-app APK + permitted app-data backup

## 10. Security & privacy
- CORE offline-first core build
- CORE no analytics by default
- CORE explicit capability indicators
- CORE destructive-action confirmation policy
- CORE operation audit/journal
- CORE secure credential storage
- CORE biometric app/vault gate
- CORE plugin signature verification
- CORE plugin capability manifest
- CORE scoped plugin access
- CORE path traversal protection during extraction
- CORE archive bomb quotas
- CORE suspicious symlink warning
- PLUGIN encrypted vault using authenticated encryption
- PLUGIN secure erase best-effort with storage-medium warning

## 11. Media & document tools
- CORE image viewer
- CORE EXIF viewer
- CORE image dimensions/color metadata
- CORE basic rotate/crop/resize/compress
- CORE audio metadata viewer
- CORE video metadata viewer
- CORE subtitle file viewer/editor
- CORE M3U8 playlist inspector/player handoff
- CORE PDF metadata viewer
- PLUGIN media transcoding helpers
- PLUGIN document text extraction for search

## 12. System & device tools
- CORE mounted volume list
- CORE SD card / USB OTG roots
- CORE storage capacity/free-space details
- CORE filesystem information when exposed
- CORE installed applications list
- CORE package sort/filter
- CORE APK extraction
- CORE launch app/details/uninstall intent
- CORE app storage-management activity handoff when available
- PRIV root filesystem properties
- PRIV app-specific data access when device policy permits
- PRIV shell/root terminal

## 13. Operation engine
- CORE unified queue for copy/move/delete/archive/network
- CORE foreground progress UI
- CORE pause/cancel
- CORE retry failed item
- CORE per-item error detail
- CORE conflict policy: replace/skip/rename/merge/compare
- CORE atomic rename when possible
- CORE cross-filesystem copy-verify-delete
- CORE checksum verification option
- CORE transaction journal
- CORE undo where technically possible
- CORE operation history
- CORE export operation log

## 14. UI / productivity
- LIVE dark power-user visual direction
- LIVE bottom navigation shell
- CORE adaptive phone/tablet/foldable UI
- CORE edge-to-edge Android UI
- CORE command palette
- CORE quick actions
- CORE customizable toolbar
- CORE customizable long-press menu
- CORE per-filetype default action
- CORE configurable gestures
- CORE hardware keyboard navigation
- CORE desktop/windowed mode optimization
- CORE accessibility labels and scalable type
- CORE theme presets
- CORE AMOLED theme
- CORE dynamic color optional

## 15. Plugin SDK
- CORE versioned plugin API
- CORE plugin manifest
- CORE capability permissions
- CORE isolated plugin execution boundaries where possible
- CORE plugin update compatibility checks
- CORE local plugin install
- CORE plugin disable/rollback
- PLUGIN archive codecs
- PLUGIN document extractors
- PLUGIN APK/DEX/resource analyzers
- PLUGIN network providers
- PLUGIN custom viewers/editors

## Target yang benar-benar membezakan produk
1. **Search graph merentas backend dan container**, bukan search folder biasa.
2. **Result path kekal tepat** walaupun padanan berada beberapa lapis dalam archive/APK.
3. **VFS yang sama** untuk local, SAF, root/Shizuku, network dan archive.
4. **Operation journal + undo** untuk keselamatan operasi besar.
5. **Plugin capability model** supaya app boleh jadi sangat besar tanpa menjadikan core tidak stabil.
6. **Index optional**, jadi pengguna boleh pilih instant recursive scan atau carian pantas daripada indeks tempatan.
