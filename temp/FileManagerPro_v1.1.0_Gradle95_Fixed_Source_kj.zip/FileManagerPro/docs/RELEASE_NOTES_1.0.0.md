# File Manager Pro 1.0.0 - Release Notes

## Main release changes
This release converts the earlier foundation into an interaction-complete local file-manager release candidate.

### New power-user interactions
- Long press a file/folder to open a contextual tool sheet.
- Haptic feedback on long press.
- Swipe right for SELECT.
- Swipe left for TOOLS.
- Swipe actions snap back and do not silently remove a row.
- Three-dot button on every item opens contextual tools.
- Three-dot button on each pane opens create/sort/select/hidden controls.
- Multi-select mode exposes a bottom batch-action bar.

### Context-aware tools
The tool sheet changes according to the selected item:
- Directories: open, copy, move, rename, duplicate, ZIP, path, properties, delete.
- Text-like files: text preview plus normal file actions.
- ZIP-family files: entry listing and extract plus normal file actions.
- APK files: archive tools plus explicit Install APK.
- Regular files: Open With, Share, hashes and file operations.

### File operation engine
- Create folder/file.
- Copy/move/rename/duplicate/delete.
- Batch copy/move/delete.
- Batch ZIP creates one `Selection.zip` instead of one archive per item.
- SHA-256 and MD5.
- Recursive properties.
- ZIP creation/list/extract.
- FileProvider open/share intents.

### Safety
- Delete requires confirmation.
- Swipe never deletes directly.
- Copy/move guards prevent placing a directory inside itself.
- ZIP extraction validates canonical paths to block Zip-Slip style traversal.
- Deep Search keeps directory/archive/resource quotas and cancellation.
- Staged modules are disabled instead of exposing no-op buttons.
- Unused future permissions were removed from the release manifest.

### Build metadata
- versionName: 1.0.0
- versionCode: 10000
- compileSdk / targetSdk: 37
- minSdk: 26
- Java: 17

## Verification
`build-check/ReleaseCoreRegression.kt` passes against the pure Kotlin core in this environment. A signed Android APK is not included because this runtime has no Android SDK/Gradle/signing toolchain.
