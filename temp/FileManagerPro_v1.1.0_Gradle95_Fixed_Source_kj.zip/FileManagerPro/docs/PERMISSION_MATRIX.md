# Permission Matrix - v1.1.0

## Declared
### MANAGE_EXTERNAL_STORAGE
Used by the local file-manager storage flow so the user can explicitly grant broad shared-storage access.

### REQUEST_INSTALL_PACKAGES
Used only when the user explicitly chooses the Install APK contextual tool.

## Not declared in v1.1.0
- INTERNET
- ACCESS_NETWORK_STATE
- ACCESS_WIFI_STATE
- ACCESS_LOCAL_NETWORK
- POST_NOTIFICATIONS
- FOREGROUND_SERVICE
- FOREGROUND_SERVICE_DATA_SYNC
- QUERY_ALL_PACKAGES
- READ_MEDIA_IMAGES / VIDEO / AUDIO

These are intentionally absent until a live module needs them.
