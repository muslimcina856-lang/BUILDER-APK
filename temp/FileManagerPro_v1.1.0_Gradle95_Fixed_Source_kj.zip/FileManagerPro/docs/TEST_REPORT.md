# Test Report - File Manager Pro 1.1.0

## Release core regression
Source: `build-check/ReleaseCoreRegression.kt`

```text
RELEASE CORE REGRESSION: PASS
search hits=10, zip entries=3, files=2, bytes=60
```

Covered: create/read/hash/duplicate/copy/rename, multi-source ZIP, ZIP list/extract, recursive properties, ordinary and nested-archive Deep Search, move and delete.

## Release audit regression
Source: `build-check/ReleaseAuditRegression.kt`

```text
RELEASE AUDIT REGRESSION: PASS
large-search hits=2, copy=same (2).txt, move=move (2).txt
```

Covered:
- ordinary file >9 MiB with a match near the end
- ZIP entry >9 MiB with a match near the end
- copy/move name collision defaults to Keep Both
- corrupt ZIP rollback
- Zip-Slip/path-traversal rollback

## Large nested archive regression
Source: `build-check/LargeNestedArchiveRegression.kt`

```text
LARGE NESTED ARCHIVE REGRESSION: PASS hits=1 inner=9437298
```

Covered `outer.zip -> inner.zip (>9 MiB) -> deep.bin`, with the match close to the end of the large inner entry.

## Signing format regression
Source: `build-check/SigningFormatRegression.kt`

```text
PASS store release.jks -> JKS, alias=release, alg=RSA
PASS store release.jceks -> JCEKS, alias=release, alg=RSA
PASS store release.p12 -> PKCS12, alias=release, alg=RSA
PASS store release.pfx -> PKCS12, alias=release, alg=RSA
PASS store release.bks -> BKS, alias=release, alg=RSA
PASS store release.bcfks -> BCFKS, alias=release, alg=RSA
PASS store release.uber -> UBER, alias=release, alg=RSA
PASS raw raw.pem -> PEM private key, alg=RSA
PASS raw raw.pk8 -> PKCS#8, alg=RSA
PASS raw encrypted-pk8.pem -> PEM private key, alg=RSA
PASS raw rsa-pkcs1.pem -> PEM private key, alg=RSA
PASS cert cert.pem -> PEM, count=1
PASS cert cert.der -> X.509/PKCS#7 certificate, count=1
PASS cert cert.p7b -> X.509/PKCS#7 certificate, count=1
SIGNING FORMAT REGRESSION: PASS
```

JKS and JCEKS are read by portable code in the app instead of assuming an Android system provider exposes those store types. BKS/BCFKS/UBER use the bundled Bouncy Castle provider instance.

## JWK / encrypted DER regression
Source: `build-check/JwkRegression.kt`

```text
PASS JWK RSA -> JWK (RSA)
PASS JWK EC -> JWK (EC)
PASS encrypted PKCS8 DER -> DER private key
JWK/DER REGRESSION: PASS
```

Additional EC SEC1/PKCS#8 fixtures were exercised against the same loader during development.

## Verification limits
The pure Kotlin core and signing-material parser compile and run in this environment. Full Android/Compose compilation, APK signing through the Android `apksig` dependency, instrumentation tests and production APK/AAB generation cannot be executed here because this runtime does not contain an Android SDK/Gradle Android toolchain. Those remain required before publishing the app binary.
