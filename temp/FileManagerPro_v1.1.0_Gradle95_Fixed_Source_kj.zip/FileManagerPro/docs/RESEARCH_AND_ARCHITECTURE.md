# File Manager Pro — Research & Architecture

## Product objective
Build a native Android power file manager that competes on **depth**, not menu count. The core differentiator is a virtual filesystem + deep-search engine that can operate consistently across local storage, SAF roots, privileged backends, network storage and archive containers.

## Research snapshot — 9 Aug 2026
- MT Manager current release observed during research: v2.26.8 (2026-08-04). Its public site/manual/release history shows dual-window file operations, root/Shizuku-related access, archive support, network storage, remote HTTP/FTP management, APK/Dex/ARSC/XML/JASM tooling, diff/editor/media/terminal/plugin functions.
- MT also already supports file-content search with regular expressions, and Dex Editor++ supports recursive/subdirectory searching. File Manager Pro therefore treats cross-container, cross-backend traversal and persistent container paths as the differentiator rather than claiming ordinary content search is unique.
- Android officially lists file managers and on-device file search as valid use cases for `MANAGE_EXTERNAL_STORAGE`, but even all-files access does **not** grant normal direct access to other apps' app-specific directories under Android/data.
- Android 17 is API 37. Apps targeting 37 need to handle the new local-network runtime permission for direct LAN communication.
- Shizuku can expose operations with shell/ADB or root identity. ADB identity is not equivalent to root and varies by Android version/SELinux/device.

## Architecture

### 1. Virtual filesystem (VFS)
Every location implements one contract:
- `list(uri)`
- `stat(uri)`
- `openRead(uri)` / `openWrite(uri)`
- `copy/move/delete/rename/mkdir`
- `capabilities(uri)`
- `watch(uri)` when supported

Backends planned:
1. `LocalBackend` — direct paths / all-files access
2. `SafBackend` — persisted tree URI
3. `ShizukuBackend` — shell-level operations
4. `RootBackend` — root process / native bridge
5. `ArchiveBackend` — ZIP/APK/JAR first, 7z/RAR/TAR via native codecs
6. `SmbBackend`, `SftpBackend`, `WebDavBackend`, `S3Backend`
7. `VirtualCollectionBackend` — recent, tagged, duplicate sets, search results

### 2. Deep Search Engine
Search scope is expressed as a traversal graph, not just `File.walk()`.

Search dimensions:
- file/folder name
- path
- extension / MIME
- size range
- created/modified date
- owner/group/mode where available
- hash / checksum
- text content
- binary printable strings
- archive entry names and contents
- nested archive containers
- APK ZIP entries; later: decoded manifest/resources, DEX symbol/string index, native ELF symbols
- optional SQLite table/value index and document text extractors as plugins

Safety/performance controls:
- coroutine cancellation
- max directory depth
- max archive depth
- max bytes scanned per entry
- archive bomb guard (expanded-size and entry-count quotas)
- symlink loop detection
- duplicate inode/path guard
- per-backend concurrency limits
- streaming result emission
- foreground operation notification for long-running user-initiated scans where platform rules require it

### 3. Operation engine
All destructive operations should become journaled transactions:
- preflight + collision policy
- progress
- pause/cancel where possible
- atomic rename/move when same filesystem
- copy-verify-delete fallback across filesystems
- optional checksum verification
- trash / undo journal
- retry queue

### 4. Tool plugin system
Tools declare a capability manifest, e.g. `READ_FILE`, `WRITE_FILE`, `NETWORK`, `PACKAGE_QUERY`, `PRIVILEGED_SHELL`. Core app can keep dangerous capabilities opt-in and visible.

## UX model
- Phone: one active pane + instant pane switch.
- Tablet/foldable/desktop mode: true dual-pane.
- Bottom navigation: Files / Deep Search / Tools / Network / Settings.
- Path chips + command palette planned.
- Search results keep both physical path and container chain, e.g. `backup.zip › app.apk › classes.dex`.

## Rujukan research awam
- MT Manager: https://mt2.cn/
- MT Manager release history: https://mt2.cn/releases/
- MT archive guide: https://mt2.cn/guide/file/archive-file.html
- MT Dex guide: https://mt2.cn/guide/reverse/dex.html
- Android all-files access: https://developer.android.com/training/data-storage/manage-all-files
- Android Storage Access Framework: https://developer.android.com/guide/topics/providers/document-provider
- Android 17 behavior changes: https://developer.android.com/about/versions/17/behavior-changes-17
- Shizuku: https://shizuku.rikka.app/
