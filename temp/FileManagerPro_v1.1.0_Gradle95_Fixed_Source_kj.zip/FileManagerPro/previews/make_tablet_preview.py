from pathlib import Path
import html
import cairosvg
OUT=Path('/mnt/data/FileManagerPro/previews')
W,H=2160,1350
BG='#0B0E12'; PANEL='#11161D'; PANEL2='#171D26'; TEXT='#F2F6F8'; MUTED='#98A6B7'; ACCENT='#63F2B1'; ACCENT_DIM='#132A22'; ACCENT_BORDER='#34795E'; WARN='#FFC76B'; LINE='#25303C'
def esc(s): return html.escape(str(s))
def txt(x,y,s,size=26,fill=TEXT,weight=400,anchor='start'):
    return f'<text x="{x}" y="{y}" font-family="DejaVu Sans,Arial,sans-serif" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>'
def rect(x,y,w,h,r=20,fill=PANEL,stroke='none',sw=1): return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def line(x1,y1,x2,y2,stroke=LINE,sw=2): return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}"/>'
def file_row(x,y,w,name,meta,ico,folder=False,selected=False):
    p=[]
    if selected: p.append(rect(x,y,w,78,14,ACCENT_DIM))
    p.append(rect(x+12,y+9,60,60,14,PANEL2))
    p.append(txt(x+42,y+49,ico,24,ACCENT if folder else MUTED,700,'middle'))
    p.append(txt(x+88,y+34,name,23,TEXT,650)); p.append(txt(x+88,y+61,meta,16,MUTED,450))
    p.append(txt(x+w-24,y+47,'›',27,MUTED,500,'middle'))
    return ''.join(p)
p=[]
p.append(rect(0,0,W,H,0,BG)); p.append(txt(44,53,'FILE MANAGER PRO',28,TEXT,900)); p.append(txt(44,86,'Files • wide layout',18,ACCENT,700)); p.append(rect(1900,31,200,52,26,PANEL2)); p.append(txt(2000,65,'LOCAL',18,ACCENT,800,'middle')); p.append(line(0,110,W,110))
# access
p.append(rect(30,132,2100,76,18,ACCENT_DIM)); p.append(txt(58,178,'✓',26,ACCENT,900)); p.append(txt(100,176,'All-files access aktif',22,TEXT,700)); p.append(txt(357,176,'Shared storage recursive scan ready',17,MUTED,450))
# panes
pane_y=230; pane_h=900; pane_w=1018
for x,title,path,active in [(30,'PANE A','/storage/emulated/0',True),(1112,'PANE B','/storage/emulated/0/Download',False)]:
    p.append(rect(x,pane_y,pane_w,pane_h,24,PANEL,ACCENT_BORDER if active else LINE,2))
    p.append(txt(x+26,pane_y+38,title,16,ACCENT if active else MUTED,850))
    p.append(txt(x+26,pane_y+78,path.split('/')[-1] or path,28,TEXT,750)); p.append(txt(x+26,pane_y+106,path,16,MUTED,450)); p.append(txt(x+pane_w-116,pane_y+73,'↑  ◉  ↻',22,MUTED,600))
    p.append(line(x+18,pane_y+128,x+pane_w-18,pane_y+128))
rowsA=[('Download','Folder • Today','▰',True,False),('Android','Folder • Today','▰',True,False),('DCIM','Folder • Today','▰',True,False),('release-v7.apk','48.2 MB • Today','A',False,True),('backup.zip','1.7 GB • Yesterday','Z',False,False),('movie.mkv','3.4 GB • 06 Aug','▶',False,False),('payload.bin','2.1 GB • 02 Aug','01',False,False),('notes.json','38 KB • 08 Aug','{}',False,False)]
rowsB=[('Builds','Folder • Today','▰',True,False),('Share','Folder • Today','▰',True,False),('base.apk','31.6 MB • Today','A',False,False),('patch.zip','104 MB • Today','Z',False,False),('config.yaml','12 KB • Today','{}',False,False),('report.pdf','6.8 MB • 08 Aug','P',False,False),('archive.7z','2.3 GB • 07 Aug','7',False,False),('sample.dex','5.1 MB • 05 Aug','D',False,False)]
y=pane_y+148
for r in rowsA:
    p.append(file_row(48,y,pane_w-36,*r)); y+=88
y=pane_y+148
for r in rowsB:
    p.append(file_row(1130,y,pane_w-36,*r)); y+=88
# action bar
p.append(rect(30,1152,2100,106,22,PANEL2)); p.append(txt(62,1194,'release-v7.apk',21,TEXT,700)); p.append(txt(62,1222,'Target: Pane B • /storage/emulated/0/Download',16,MUTED,450))
acts=[('HASH','#'),('COPY','□'),('MOVE','→'),('DELETE','×')]
for i,(lab,ico) in enumerate(acts):
    x=1260+i*205; p.append(txt(x,1193,ico,25,ACCENT if lab!='DELETE' else WARN,700,'middle')); p.append(txt(x,1224,lab,15,MUTED,700,'middle'))
# bottom
p.append(rect(0,1280,W,70,0,PANEL)); labels=['FILES','SEARCH','TOOLS','NETWORK','SETTINGS'];
for i,lab in enumerate(labels):
    x=500+i*285; p.append(txt(x,1323,lab,16,ACCENT if i==0 else MUTED,750,'middle'))
svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">{"".join(p)}</svg>'
sp=OUT/'screen_06_dual_pane_tablet.svg'; sp.write_text(svg,encoding='utf-8')
cairosvg.svg2png(url=str(sp),write_to=str(sp.with_suffix('.png')),output_width=W,output_height=H)
print(sp.with_suffix('.png'))
