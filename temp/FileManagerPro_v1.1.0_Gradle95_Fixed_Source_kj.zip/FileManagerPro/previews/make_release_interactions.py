from pathlib import Path
import html
import cairosvg

OUT=Path('/mnt/data/FileManagerPro/previews')
W,H=1080,2160
BG='#0B0E12'; PANEL='#11161D'; PANEL2='#171D26'; TEXT='#F2F6F8'; MUTED='#98A6B7'; ACCENT='#63F2B1'; ACCENT_DIM='#132A22'; ACCENT_DIM2='#1A3A2E'; ACCENT_BORDER='#34795E'; WARN='#FFC76B'; DANGER='#FF8B7A'; LINE='#25303C'

def esc(s): return html.escape(str(s))
def txt(x,y,s,size=30,fill=TEXT,weight=400,anchor='start'):
    return f'<text x="{x}" y="{y}" font-family="DejaVu Sans,Arial,sans-serif" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>'
def rect(x,y,w,h,r=24,fill=PANEL,stroke='none',sw=1):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def line(x1,y1,x2,y2,stroke=LINE,sw=2): return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}"/>'
def header(sub):
    return ''.join([
        rect(0,0,W,176,0,BG), txt(56,70,'FILE MANAGER PRO',34,TEXT,900), txt(56,112,sub,24,ACCENT,700),
        rect(825,46,195,58,29,PANEL2), txt(922,84,'v1.0',20,ACCENT,800,'middle'), line(0,175,W,175)
    ])
def bottom():
    p=[rect(0,1960,W,200,0,PANEL)]
    labels=[('FILES','▰'),('SEARCH','⌕'),('TOOLS','⚙'),('NETWORK','◎'),('SETTINGS','≡')]
    for i,(lab,ico) in enumerate(labels):
        x=108+i*216
        if i==0: p.append(rect(x-82,1984,164,74,38,ACCENT_DIM2))
        p.append(txt(x,2033,ico,34,ACCENT if i==0 else MUTED,700,'middle'))
        p.append(txt(x,2090,lab,19,ACCENT if i==0 else MUTED,700,'middle'))
    return ''.join(p)
def file_row(y,name,meta,ico='□',folder=False,selected=False,more=True):
    p=[]
    if selected: p.append(rect(36,y,1008,100,18,ACCENT_DIM))
    p.append(rect(52,y+11,74,74,18,PANEL2)); p.append(txt(89,y+59,ico,27,ACCENT if folder else MUTED,700,'middle'))
    p.append(txt(150,y+42,name,27,TEXT,650)); p.append(txt(150,y+74,meta,18,MUTED,450))
    if more: p.append(txt(990,y+59,'⋮',34,MUTED,800,'middle'))
    return ''.join(p)
def write(name,body):
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="{BG}"/>{body}</svg>'
    sp=OUT/name.replace('.png','.svg'); sp.write_text(svg,encoding='utf-8')
    pp=OUT/name; cairosvg.svg2png(bytestring=svg.encode(),write_to=str(pp),output_width=W,output_height=H)

# 07 Long press quick tools sheet
p=[header('Files • Long-press tools')]
p.append(rect(36,210,1008,106,24,ACCENT_DIM)); p.append(txt(68,254,'PANE A',18,ACCENT,800)); p.append(txt(68,290,'/storage/emulated/0/Download',22,TEXT,650)); p.append(txt(980,270,'⋮',32,MUTED,800,'middle'))
rows=[('Projects','Folder • Today','▰',True),('release-v7.apk','48.2 MB • Today','A',False),('backup.zip','1.7 GB • Yesterday','Z',False),('notes.json','38 KB • 08 Aug','{}',False),('movie.mkv','3.4 GB • 06 Aug','▶',False)]
y=350
for r in rows:
    p.append(file_row(y,*r)); y+=110
# dim overlay
p.append(rect(0,0,W,1960,0,'#000000',sw=0));
# redraw with translucent simulation using opacity tags
# add bottom sheet
p.append(f'<rect x="0" y="840" width="1080" height="1120" rx="40" fill="{PANEL}"/>')
p.append(rect(466,866,148,8,4,LINE)); p.append(rect(48,914,82,82,18,PANEL2)); p.append(txt(89,966,'A',30,ACCENT,800,'middle'))
p.append(txt(154,948,'release-v7.apk',30,TEXT,800)); p.append(txt(154,982,'/storage/emulated/0/Download/release-v7.apk',17,MUTED,450))
p.append(txt(52,1040,'QUICK TOOLS',19,ACCENT,850))
actions=[('Buka','↗'),('Buka dengan','▦'),('Lihat arkib','Z'),('Pasang APK','A'),('Salin ke B','□'),('Pindah ke B','→'),('Rename','✎'),('Duplikasi','⧉'),('Kongsi','↗'),('Jadikan ZIP','Z'),('SHA-256','#'),('MD5','#'),('Salin path','⎘'),('Properties','i'),('Padam','×')]
y=1070
for row in range(5):
    for col in range(3):
        i=row*3+col
        x=48+col*332
        lab,ico=actions[i]
        danger=lab=='Padam'
        p.append(rect(x,y,310,132,20,'#2A1717' if danger else PANEL2))
        p.append(txt(x+155,y+50,ico,28,DANGER if danger else ACCENT,750,'middle'))
        p.append(txt(x+155,y+94,lab,18,TEXT,600,'middle'))
    y+=148
p.append(bottom()); write('screen_07_longpress_tools.png',''.join(p))

# 08 Swipe preview
p=[header('Files • Swipe actions')]
p.append(rect(36,210,1008,92,24,PANEL)); p.append(txt(64,248,'GESTURE MODE',17,ACCENT,850)); p.append(txt(64,280,'Swipe kanan = SELECT   •   Swipe kiri = TOOLS',20,MUTED,550))
p.append(file_row(340,'notes.json','38 KB • 08 Aug','{}'))
# start-to-end reveal
p.append(rect(36,470,1008,104,18,ACCENT_DIM2)); p.append(txt(68,532,'✓  SELECT',22,ACCENT,850)); p.append(rect(330,470,714,104,18,BG)); p.append(rect(348,485,70,70,16,PANEL2)); p.append(txt(383,531,'Z',26,MUTED,800,'middle')); p.append(txt(438,516,'backup.zip',26,TEXT,650)); p.append(txt(438,548,'1.7 GB • Yesterday',18,MUTED)); p.append(txt(998,532,'⋮',32,MUTED,800,'middle'))
# end-to-start reveal
p.append(rect(36,604,1008,104,18,PANEL2)); p.append(txt(865,666,'TOOLS  ⚙',22,ACCENT,850)); p.append(rect(36,604,714,104,18,BG)); p.append(rect(52,619,70,70,16,PANEL2)); p.append(txt(87,665,'A',26,MUTED,800,'middle')); p.append(txt(142,650,'release-v7.apk',26,TEXT,650)); p.append(txt(142,682,'48.2 MB • Today',18,MUTED))
p.append(txt(48,770,'Kenapa delete tak diletak pada swipe?',22,TEXT,750)); p.append(txt(48,810,'Aksi swipe sengaja tidak destruktif. Delete kekal perlu confirmation.',20,MUTED,450))
y=880
for r in [('DCIM','Folder • Today','▰',True),('movie.mkv','3.4 GB • 06 Aug','▶',False),('payload.bin','2.1 GB • 02 Aug','01',False),('config.yaml','12 KB • Today','{}',False)]: p.append(file_row(y,*r)); y+=110
p.append(bottom()); write('screen_08_swipe_actions.png',''.join(p))

# 09 overflow menu
p=[header('Files • ⋮ overflow')]
p.append(rect(36,210,1008,116,24,ACCENT_DIM,ACCENT_BORDER,2)); p.append(txt(66,253,'PANE A',17,ACCENT,850)); p.append(txt(66,292,'Download',27,TEXT,750)); p.append(txt(235,292,'/storage/emulated/0/Download',18,MUTED)); p.append(txt(970,275,'⋮',36,ACCENT,850,'middle'))
y=350
for r in [('Builds','Folder • Today','▰',True),('base.apk','31.6 MB • Today','A',False),('patch.zip','104 MB • Today','Z',False),('config.yaml','12 KB • Today','{}',False),('report.pdf','6.8 MB • 08 Aug','P',False)]: p.append(file_row(y,*r)); y+=110
# dropdown
p.append(rect(520,322,512,900,24,PANEL2,LINE,2));
items=[('Folder baharu','▰'),('Fail baharu','＋'),('Pilih semua','✓'),('—',''),('Susun: Nama','✓'),('Susun: Saiz','↕'),('Susun: Tarikh','↕'),('Susun: Jenis','↕'),('—',''),('Tunjuk hidden','◉')]
y=382
for lab,ico in items:
    if lab=='—': p.append(line(546,y,1004,y)); y+=34; continue
    p.append(txt(558,y,ico,22,ACCENT if ico=='✓' else MUTED,700)); p.append(txt(610,y,lab,23,TEXT,600)); y+=78
p.append(bottom()); write('screen_09_overflow_menu.png',''.join(p))

# 10 multi select
p=[header('Files • Multi-select')]
p.append(rect(36,210,1008,104,24,PANEL)); p.append(txt(66,250,'PANE A',17,ACCENT,850)); p.append(txt(66,286,'3 item dipilih',25,TEXT,750)); p.append(txt(980,266,'×',29,MUTED,600,'middle'))
rows=[('release-v7.apk','48.2 MB • Today','A',False,True),('backup.zip','1.7 GB • Yesterday','Z',False,True),('notes.json','38 KB • 08 Aug','{}',False,True),('movie.mkv','3.4 GB • 06 Aug','▶',False,False),('DCIM','Folder • Today','▰',True,False)]
y=346
for name,meta,ico,folder,sel in rows:
    p.append(file_row(y,name,meta,ico,folder,sel));
    if sel: p.append(txt(78,y+62,'✓',23,ACCENT,900,'middle'))
    y+=112
p.append(rect(36,1060,1008,244,28,PANEL2)); p.append(txt(68,1108,'3 item dipilih',26,TEXT,750)); p.append(txt(68,1142,'Target: Pane B • /storage/emulated/0/Download',18,MUTED))
acts=[('COPY','□'),('MOVE','→'),('ZIP','Z'),('DELETE','×')]
for i,(lab,ico) in enumerate(acts):
    x=78+i*244; p.append(txt(x+60,1210,ico,31,DANGER if lab=='DELETE' else ACCENT,750,'middle')); p.append(txt(x+60,1250,lab,17,DANGER if lab=='DELETE' else MUTED,750,'middle'))
p.append(rect(36,1340,1008,128,24,ACCENT_DIM)); p.append(txt(64,1388,'MULTI-ZIP',18,ACCENT,850)); p.append(txt(64,1428,'ZIP menghasilkan satu Selection.zip, bukan ZIP berasingan.',20,TEXT,550))
p.append(bottom()); write('screen_10_multiselect.png',''.join(p))

print('release interaction previews generated')
