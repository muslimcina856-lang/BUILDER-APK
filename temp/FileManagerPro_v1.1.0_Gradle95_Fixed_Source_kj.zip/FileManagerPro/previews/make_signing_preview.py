from pathlib import Path
import html
import cairosvg

OUT=Path(__file__).resolve().parent
W,H=1080,2160
BG='#0B0E12'; PANEL='#11161D'; PANEL2='#171D26'; TEXT='#F2F6F8'; MUTED='#98A6B7'; ACCENT='#63F2B1'; ACCENT_DIM='#132A22'; BORDER='#25303C'; WARN='#FFC76B'

def esc(s): return html.escape(str(s))
def txt(x,y,s,size=30,fill=TEXT,weight=400,anchor='start'):
    return f'<text x="{x}" y="{y}" font-family="DejaVu Sans,Arial,sans-serif" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>'
def rect(x,y,w,h,r=24,fill=PANEL,stroke='none',sw=1):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def line(x1,y1,x2,y2,stroke=BORDER,sw=2): return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}"/>'

p=[]
p += [rect(0,0,W,176,0,BG), txt(56,70,'FILE MANAGER PRO',34,TEXT,900), txt(56,112,'Tools • Key & APK Signing Manager',24,ACCENT,700), rect(825,46,195,58,29,PANEL2), txt(922,84,'v1.1',20,ACCENT,800,'middle'), line(0,175,W,175)]

# Key card
p += [rect(36,212,1008,286,28,PANEL), txt(66,258,'SIGNING KEY',17,ACCENT,850), txt(66,304,'release.jks',31,TEXT,800), txt(66,342,'JKS • RSA 2048 • alias: release',20,MUTED,550),
      rect(66,376,210,66,18,ACCENT_DIM), txt(171,418,'INSPECT',19,ACCENT,800,'middle'), rect(294,376,270,66,18,PANEL2,BORDER,2), txt(429,418,'CHANGE KEY',19,TEXT,750,'middle'),
      txt(620,394,'✓ key ↔ certificate match',18,ACCENT,700), txt(620,428,'SHA-256 fingerprint ready',17,MUTED,500)]

# Formats
p += [txt(48,556,'FORMAT KEY YANG DISOKONG',19,ACCENT,850)]
chips=['JKS','JCEKS','P12 / PFX','BKS','BCFKS','UBER','PEM / DER','PKCS#8','PKCS#1','SEC1 EC','JWK','X.509 / P7B']
x,y=48,586
for chip in chips:
    w=max(120, 26*len(chip)+42)
    if x+w>1032:
        x=48; y+=72
    p.append(rect(x,y,w,54,16,PANEL2,BORDER,1)); p.append(txt(x+w/2,y+35,chip,16,TEXT,700,'middle')); x+=w+14

# APK card
apk_y=y+104
p += [rect(36,apk_y,1008,344,28,PANEL), txt(66,apk_y+48,'APK TARGET',17,ACCENT,850), txt(66,apk_y+94,'MyApp-release.apk',30,TEXT,800), txt(66,apk_y+130,'86.4 MB • /Download/builds',19,MUTED,500)]
# schemes
labels=[('v1',True),('v2',True),('v3',True),('v4 .idsig',False)]
xx=66
for lab,on in labels:
    w=190 if 'idsig' in lab else 128
    p.append(rect(xx,apk_y+168,w,62,18,ACCENT_DIM if on else PANEL2, '#34795E' if on else BORDER,2))
    p.append(txt(xx+30,apk_y+208,'✓' if on else '○',20,ACCENT if on else MUTED,800))
    p.append(txt(xx+62,apk_y+208,lab,18,TEXT,700))
    xx += w+16
p += [rect(66,apk_y+258,310,66,18,PANEL2,BORDER,2), txt(221,apk_y+300,'VERIFY APK',19,TEXT,800,'middle'), rect(394,apk_y+258,430,66,18,ACCENT_DIM,'#34795E',2), txt(609,apk_y+300,'SIGN + VERIFY',19,ACCENT,850,'middle')]

# Safety pipeline
safe_y=apk_y+390
p += [rect(36,safe_y,1008,226,28,ACCENT_DIM), txt(66,safe_y+48,'SAFE SIGNING PIPELINE',17,ACCENT,850), txt(66,safe_y+98,'1  Staging APK',22,TEXT,700), txt(330,safe_y+98,'→',26,ACCENT,800), txt(390,safe_y+98,'2  Sign',22,TEXT,700), txt(560,safe_y+98,'→',26,ACCENT,800), txt(620,safe_y+98,'3  Verify',22,TEXT,700), txt(820,safe_y+98,'→',26,ACCENT,800), txt(880,safe_y+98,'4  Commit',22,TEXT,700),
      txt(66,safe_y+144,'Gagal sign/verify = staging dibuang. Output lama tidak disentuh.',19,MUTED,550), txt(66,safe_y+184,'Nama bertembung = Keep Both, bukan overwrite senyap.',19,MUTED,550)]

# Verify result
res_y=safe_y+270
p += [rect(36,res_y,1008,276,28,PANEL), txt(66,res_y+50,'LAST VERIFICATION',17,ACCENT,850), txt(66,res_y+96,'VERIFIED',30,ACCENT,900), txt(66,res_y+136,'v1 ✓    v2 ✓    v3 ✓    v3.1 —    v4 —',20,TEXT,650), txt(66,res_y+182,'Signer SHA-256',17,MUTED,600), txt(66,res_y+220,'3A:91:7F:2C:80:...:D4:22',20,TEXT,650), txt(882,res_y+104,'✓',56,ACCENT,900,'middle')]

# Note
note_y=res_y+320
p += [rect(36,note_y,1008,130,24,PANEL2), txt(66,note_y+44,'CATATAN',16,WARN,850), txt(66,note_y+82,'Raw private key mesti dipadankan dengan sijil X.509 yang sepadan.',18,TEXT,550), txt(66,note_y+110,'Ed25519/Ed448 boleh di-parse sebagai key material tetapi bukan didakwa sebagai APK signer.',16,MUTED,500)]

# Bottom nav
p.append(rect(0,1960,W,200,0,PANEL))
labels=[('FILES','▰'),('SEARCH','⌕'),('TOOLS','⚙'),('NETWORK','◎'),('SETTINGS','≡')]
for i,(lab,ico) in enumerate(labels):
    x=108+i*216
    if i==2: p.append(rect(x-82,1984,164,74,38,ACCENT_DIM))
    p.append(txt(x,2033,ico,34,ACCENT if i==2 else MUTED,700,'middle'))
    p.append(txt(x,2090,lab,19,ACCENT if i==2 else MUTED,700,'middle'))

svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="{BG}"/>{"".join(p)}</svg>'
(OUT/'screen_11_signing_manager.svg').write_text(svg,encoding='utf-8')
cairosvg.svg2png(bytestring=svg.encode(), write_to=str(OUT/'screen_11_signing_manager.png'), output_width=W, output_height=H)
print(OUT/'screen_11_signing_manager.png')
