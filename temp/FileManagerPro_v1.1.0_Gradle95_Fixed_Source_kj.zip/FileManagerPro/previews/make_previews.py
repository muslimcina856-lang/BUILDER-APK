from pathlib import Path
import html

OUT=Path('/mnt/data/FileManagerPro/previews')
W,H=1080,2160
BG='#0B0E12'; PANEL='#11161D'; PANEL2='#171D26'; TEXT='#F2F6F8'; MUTED='#98A6B7'; ACCENT='#63F2B1'; ACCENT_DIM='#132A22'; ACCENT_DIM2='#1A3A2E'; ACCENT_BORDER='#34795E'; WARN='#FFC76B'; LINE='#25303C'

def esc(s): return html.escape(str(s))

def txt(x,y,s,size=32,fill=TEXT,weight=400,anchor='start'):
    return f'<text x="{x}" y="{y}" font-family="DejaVu Sans,Arial,sans-serif" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>'

def rect(x,y,w,h,r=24,fill=PANEL,stroke='none',sw=1):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'

def line(x1,y1,x2,y2,stroke=LINE,sw=2): return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}"/>'

def circle(cx,cy,r,fill): return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}"/>'

def icon_box(x,y,label,accent=False):
    c=ACCENT if accent else MUTED
    return rect(x,y,78,78,20,PANEL2)+txt(x+39,y+51,label,31,c,700,'middle')

def header(sub):
    p=[]
    p.append(rect(0,0,W,178,0,BG))
    p.append(txt(56,70,'FILE MANAGER PRO',34,TEXT,900))
    p.append(txt(56,112,sub,24,ACCENT,700))
    p.append(rect(830,48,190,58,29,PANEL2)); p.append(txt(925,86,'LOCAL',22,ACCENT,800,'middle'))
    p.append(line(0,176,W,176))
    return ''.join(p)

def bottom(active):
    labels=[('FILES','▰'),('SEARCH','⌕'),('TOOLS','⚙'),('NETWORK','◎'),('SETTINGS','≡')]
    p=[rect(0,1960,W,200,0,PANEL)]
    for i,(lab,ico) in enumerate(labels):
        x=108+i*216
        isact=lab==active
        if isact: p.append(rect(x-82,1984,164,74,38,ACCENT_DIM2))
        p.append(txt(x,2033,ico,34,ACCENT if isact else MUTED,700,'middle'))
        p.append(txt(x,2090,lab,19,ACCENT if isact else MUTED,700,'middle'))
    return ''.join(p)

def svg(body):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="{BG}"/>{body}</svg>'''

def save(name, body): (OUT/name).write_text(svg(body),encoding='utf-8')

# 1 Files (phone dual-pane workflow)
p=[header('Files')]
p.append(rect(36,210,1008,118,26,ACCENT_DIM)); p.append(txt(76,258,'✓',34,ACCENT,900)); p.append(txt(130,258,'All-files access aktif',30,TEXT,700)); p.append(txt(130,296,'Shared storage boleh diimbas secara rekursif.',21,MUTED,400))
# Pane switcher mirrors phone UI: both locations stay alive, one is active.
p.append(rect(36,350,494,104,22,ACCENT_DIM2,ACCENT_BORDER,2)); p.append(txt(62,385,'PANE A',17,ACCENT,850)); p.append(txt(62,426,'Internal storage',25,TEXT,700))
p.append(rect(550,350,494,104,22,PANEL)); p.append(txt(576,385,'PANE B',17,MUTED,850)); p.append(txt(576,426,'Download',25,TEXT,700))
p.append(rect(36,474,1008,124,26,ACCENT_DIM,ACCENT_BORDER,2)); p.append(txt(75,525,'↑',36,MUTED,600)); p.append(txt(134,521,'Internal storage',29,TEXT,700)); p.append(txt(134,560,'/storage/emulated/0',20,MUTED)); p.append(txt(895,534,'◉  ↻',30,MUTED,600))
p.append(txt(52,632,'A  •  12 ITEMS',19,ACCENT,800))
rows=[('Download','Folder','—','18:31','▰',True),('Android','Folder','—','17:02','▰',True),('DCIM','Folder','—','12:44','▰',True),('release-v7.apk','APK','48.2 MB','Today','A',False),('backup.zip','Archive','1.7 GB','Yesterday','Z',False),('notes.json','JSON','38 KB','08 Aug','{ }',False),('movie.mkv','Video','3.4 GB','06 Aug','▶',False)]
y=660
for name,kind,size,date,ico,isdir in rows:
    p.append(icon_box(50,y,ico,isdir)); p.append(txt(150,y+34,name,28,TEXT,650)); p.append(txt(150,y+70,f'{kind}  •  {size}  •  {date}',19,MUTED)); p.append(txt(990,y+48,'›',36,MUTED,500,'middle')); y+=120
# Selected file action bar explicitly targets the opposite pane.
p.append(rect(36,1530,1008,250,28,PANEL2)); p.append(txt(68,1577,'release-v7.apk',25,TEXT,700)); p.append(txt(68,1610,'Target: /storage/emulated/0/Download',18,MUTED,500));
for i,(lab,ico) in enumerate([('HASH','#'),('COPY','□'),('MOVE','→'),('DELETE','×')]):
    x=92+i*238; p.append(txt(x+55,1682,ico,31,ACCENT if lab!='DELETE' else WARN,700,'middle')); p.append(txt(x+55,1724,lab,18,MUTED,700,'middle'))
p.append(rect(36,1810,1008,74,20,ACCENT_DIM)); p.append(txt(62,1858,'Copy / Move terus ke Pane B tanpa hilangkan lokasi Pane A',19,ACCENT,650))
p.append(bottom('FILES')); save('screen_01_files.svg',''.join(p))

# 2 Search
p=[header('Deep Search')]
p.append(txt(48,242,'Search beyond folders',44,TEXT,900)); p.append(txt(48,286,'Nama + kandungan + nested archive + binary strings',23,MUTED))
p.append(rect(36,330,1008,104,24,PANEL,LINE,2)); p.append(txt(72,378,'⌕',34,ACCENT,700)); p.append(txt(128,382,'api_key',30,TEXT,600)); p.append(txt(960,382,'×',31,MUTED,500))
p.append(rect(36,456,1008,92,22,PANEL)); p.append(txt(66,494,'ROOT',18,MUTED,800)); p.append(txt(150,505,'/storage/emulated/0',25,TEXT,600))
chips=[('REGEX',False),('CASE',False),('ARCHIVES',True),('BINARY STRINGS',True)]
x=36
for lab,on in chips:
    w=150 if len(lab)<8 else 230
    p.append(rect(x,574,w,66,33,ACCENT_DIM2 if on else PANEL2,ACCENT if on else 'none',2)); p.append(txt(x+w/2,616,lab,18,ACCENT if on else MUTED,800,'middle')); x+=w+16
p.append(rect(36,672,740,90,26,ACCENT)); p.append(txt(406,728,'DEEP SCAN RUNNING',23,BG,900,'middle')); p.append(rect(796,672,248,90,26,PANEL2)); p.append(txt(920,728,'STOP',23,WARN,900,'middle'))
p.append(rect(36,790,1008,8,4,PANEL2)); p.append(rect(36,790,615,8,4,ACCENT)); p.append(txt(42,838,'18,492 files  •  3,106 folders  •  684 archive entries',21,MUTED,600)); p.append(txt(42,875,'/Download/backup.zip › app.apk › classes.dex',20,MUTED))
p.append(txt(42,932,'7 MATCHES',20,MUTED,800))
results=[('ARCHIVE CONTENT','backup.zip › app.apk › classes.dex','...const-string v0, "api_key"...'),('FILE CONTENT','projects/demo/.env','API_KEY=sk_live_example_redacted'),('INSIDE ARCHIVE','old_build.apks › base.apk › assets/config.json','"api_key": "production"'),('FILE CONTENT','Download/config.yaml','api_key: ${APP_KEY}')]
y=968
for typ,path,snip in results:
    p.append(rect(36,y,1008,190,24,PANEL)); p.append(txt(64,y+40,typ,18,ACCENT,800)); p.append(txt(64,y+82,path,24,TEXT,650)); p.append(rect(62,y+106,956,58,14,PANEL2)); p.append(txt(78,y+144,snip,19,MUTED,500)); y+=212
p.append(rect(36,1824,1008,82,22,ACCENT_DIM)); p.append(txt(64,1875,'Depth 64  •  archive depth 4  •  cancellable  •  streaming results',20,ACCENT,650))
p.append(bottom('SEARCH')); save('screen_02_deep_search.svg',''.join(p))

# 3 Tools
p=[header('Tools')]
p.append(txt(48,242,'Tool Deck',44,TEXT,900)); p.append(txt(48,286,'Core tools + sandboxed plugins',23,MUTED))
groups=[('FILE INTELLIGENCE',['Hash & checksum','Duplicate finder','Storage heatmap','Batch rename','Folder diff']),('DEVELOPER',['Text / code editor','Hex editor','Regex lab','SQLite browser','ELF / SO inspector']),('APK WORKSPACE',['APK / APKS / XAPK explorer','Manifest inspector','DEX strings & symbols','Signature viewer','Package diff']),('ARCHIVE',['ZIP / 7z / RAR / TAR','Nested archive explorer','Archive test','Parallel extract'])]
y=330
for gi,(title,items) in enumerate(groups):
    h=118+len(items)*62
    p.append(rect(36,y,1008,h,26,PANEL)); p.append(txt(62,y+44,title,20,ACCENT,850)); yy=y+92
    for item in items:
        p.append(txt(66,yy,'⚡',22,MUTED,600)); p.append(txt(108,yy,item,23,TEXT,560)); p.append(txt(990,yy,'›',28,MUTED,500,'middle')); yy+=62
    y+=h+18
p.append(bottom('TOOLS')); save('screen_03_tools.svg',''.join(p))

# 4 Network (matches current shell: permission flow + protocol module list)
p=[header('Network')]
p.append(txt(48,242,'Network Spaces',44,TEXT,900)); p.append(txt(48,286,'Mount remote storage as first-class folders',23,MUTED))
p.append(rect(36,324,1008,132,26,ACCENT_DIM)); p.append(txt(70,380,'◎',34,ACCENT,800)); p.append(txt(126,371,'Local network permission',28,TEXT,700)); p.append(txt(126,413,'Required on Android 17 when targeting API 37',21,MUTED)); p.append(rect(840,354,164,64,30,PANEL2)); p.append(txt(922,395,'ALLOW',19,ACCENT,850,'middle'))
p.append(txt(48,520,'REMOTE BACKENDS',20,MUTED,800))
protocols=[('SMB / CIFS','LAN / NAS','PLUGIN'),('SFTP / SCP','SSH servers','PLUGIN'),('WebDAV','Nextcloud / web storage','PLUGIN'),('FTP / FTPS','Classic file servers','PLUGIN'),('S3 compatible','Object storage','PLUGIN'),('HTTP file server','Browser access','CORE'),('Nearby LAN transfer','Peer-to-peer','PLUGIN'),('SSH terminal','Remote shell module','PLUGIN')]
y=556
for name,sub,status in protocols:
    p.append(rect(36,y,1008,128,22,PANEL)); p.append(txt(70,y+55,'＋',30,ACCENT,700)); p.append(txt(126,y+48,name,25,TEXT,650)); p.append(txt(126,y+82,sub,19,MUTED)); p.append(rect(828,y+35,142,48,24,PANEL2)); p.append(txt(899,y+66,status,15,MUTED,800,'middle')); p.append(txt(1000,y+69,'›',29,MUTED,500,'middle')); y+=142
p.append(rect(36,1748,1008,112,24,ACCENT_DIM)); p.append(txt(64,1792,'CURRENT BUILD',17,ACCENT,850)); p.append(txt(64,1830,'Permission flow LIVE • remote protocol backends are module slots',19,MUTED,550))
p.append(bottom('NETWORK')); save('screen_04_network.svg',''.join(p))

# 5 Settings (matches current control-center cards)
p=[header('Settings')]
p.append(txt(48,242,'Control Center',44,TEXT,900)); p.append(txt(48,286,'Access, search limits, performance and safety',23,MUTED))
settings=[('STORAGE ACCESS','All-files access, SAF roots, media permissions','▰','LIVE'),('PRIVILEGED ACCESS','Shizuku / root backend with explicit capability checks','#','MODULE'),('DEEP SEARCH LIMITS','Archive depth 4 • max 8 MiB per content scan • cancellable','⌕','LIVE'),('OPERATION JOURNAL','Undo-ready transaction log for copy/move/rename/delete','↶','CORE'),('PRIVACY','Offline-first; no analytics in core build','◉','POLICY'),('PLUGIN SANDBOX','Signed plugins, scoped permissions, capability manifest','□','CORE')]
y=340
for title,desc,ico,status in settings:
    p.append(rect(36,y,1008,154,24,PANEL)); p.append(icon_box(58,y+38,ico,True)); p.append(txt(160,y+59,title,21,TEXT,800)); p.append(txt(160,y+99,desc,19,MUTED,450)); p.append(rect(832,y+52,136,48,24,PANEL2)); p.append(txt(900,y+83,status,15,ACCENT if status=='LIVE' else MUTED,800,'middle')); p.append(txt(1000,y+83,'›',29,MUTED,500,'middle')); y+=172
p.append(rect(36,1410,1008,238,26,ACCENT_DIM)); p.append(txt(64,1464,'SAFETY DEFAULTS',19,ACCENT,850));
items=['Directory depth 64','Archive depth 4','100,000 archive-entry quota','512 MiB expanded-byte quota','Canonical directory visit guard']
yy=1510
for item in items:
    p.append(txt(70,yy,'•',21,ACCENT,700)); p.append(txt(100,yy,item,19,TEXT,550)); yy+=34
p.append(rect(36,1680,1008,154,24,PANEL2)); p.append(txt(64,1727,'ACCESS BACKENDS',18,MUTED,850)); p.append(txt(64,1768,'Local  •  SAF  •  All Files  •  Shizuku  •  Root  •  Remote VFS',20,TEXT,600)); p.append(txt(64,1805,'Setiap backend akan lapor capability sebenar, bukan andaian.',18,MUTED,450))
p.append(bottom('SETTINGS')); save('screen_05_settings.svg',''.join(p))

print('SVG previews created')
