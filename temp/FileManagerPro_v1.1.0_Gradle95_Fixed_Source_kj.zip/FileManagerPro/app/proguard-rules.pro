# File Manager Pro release rules
-keepattributes *Annotation*
-dontwarn java.nio.file.**

# Signing/crypto modules
-keep class com.android.apksig.** { *; }
-dontwarn org.bouncycastle.**
-keep class org.bouncycastle.** { *; }
