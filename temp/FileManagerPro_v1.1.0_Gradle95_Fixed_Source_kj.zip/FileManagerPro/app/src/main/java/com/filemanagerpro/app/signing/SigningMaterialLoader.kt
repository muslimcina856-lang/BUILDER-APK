package com.filemanagerpro.app.signing

import org.bouncycastle.asn1.pkcs.PrivateKeyInfo
import org.bouncycastle.asn1.pkcs.PBEParameter
import org.bouncycastle.cert.X509CertificateHolder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.crypto.util.OpenSSHPrivateKeyUtil
import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.params.Ed448PrivateKeyParameters
import org.bouncycastle.crypto.util.PrivateKeyInfoFactory
import org.bouncycastle.openssl.PEMEncryptedKeyPair
import org.bouncycastle.openssl.PEMKeyPair
import org.bouncycastle.openssl.PEMParser
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter
import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder
import org.bouncycastle.openssl.jcajce.JceOpenSSLPKCS8DecryptorProviderBuilder
import org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.ByteArrayInputStream
import java.io.DataInputStream
import java.io.File
import java.io.StringReader
import java.math.BigInteger
import java.security.AlgorithmParameters
import java.security.KeyFactory
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPrivateKeySpec
import java.security.spec.RSAPrivateCrtKeySpec
import java.security.spec.RSAPrivateKeySpec
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.EncryptedPrivateKeyInfo
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Portable signing material loader for Android.
 *
 * Supported signing inputs:
 * - JKS (portable parser, does not depend on Android exposing a JKS provider)
 * - PKCS12 / PFX / P12
 * - BKS / BCFKS / UBER through a bundled Bouncy Castle provider instance
 * - JCEKS private-key entries through a portable parser (no Android JCEKS provider required)
 * - PKCS#8 PEM/DER, encrypted PKCS#8 PEM, PKCS#1 RSA PEM/DER,
 *   SEC1 EC PEM, OpenSSH private-key PEM where Bouncy Castle can decode it
 * - X.509 certificate chains in PEM/DER; PKCS#7/P7B/P7C certificate bundles
 */
class SigningMaterialLoader {
    private val bc = BouncyCastleProvider()
    private val pemConverter = JcaPEMKeyConverter().setProvider(bc)
    private val certConverter = JcaX509CertificateConverter().setProvider(bc)

    data class Material(
        val alias: String,
        val privateKey: PrivateKey,
        val certificates: List<X509Certificate>,
        val format: String
    )

    data class Inspection(
        val format: String,
        val aliases: List<String>,
        val keyAliases: List<String>,
        val certificateCount: Int,
        val privateKeyDetected: Boolean,
        val notes: List<String> = emptyList()
    )

    fun inspect(file: File, password: CharArray = charArrayOf()): Result<Inspection> = runCatching {
        require(file.isFile) { "Fail tidak wujud" }
        if (looksLikeJks(file)) return@runCatching PortableJks.inspect(file, password)
        if (looksLikeJceks(file)) return@runCatching PortableJceks.inspect(file, password)

        val candidates = keyStoreCandidates(file)
        for ((type, provider) in candidates) {
            val result = runCatching { loadKeyStore(type, provider, file, password) }.getOrNull() ?: continue
            val aliases = result.aliases().toList()
            val keyAliases = aliases.filter { runCatching { result.isKeyEntry(it) }.getOrDefault(false) }
            return@runCatching Inspection(type, aliases, keyAliases, aliases.count { result.isCertificateEntry(it) } + keyAliases.size, keyAliases.isNotEmpty())
        }

        val bytes = file.readBytes()
        val textCandidate = bytes.toString(Charsets.UTF_8)
        if (looksLikeJwk(textCandidate)) {
            val jwkKey = parseJwkPrivateKey(textCandidate)
            val certs = parseJwkCertificates(textCandidate)
            return@runCatching Inspection(
                format = "JWK (${jwkKey.algorithm})",
                aliases = emptyList(),
                keyAliases = listOf("raw-key"),
                certificateCount = certs.size,
                privateKeyDetected = true,
                notes = if (certs.isEmpty()) listOf("JWK private key perlukan X.509 certificate berasingan jika tiada x5c") else emptyList()
            )
        }
        runCatching { PKCS8EncryptedPrivateKeyInfo(bytes) }.getOrNull()?.let {
            return@runCatching Inspection("Encrypted PKCS#8 DER", emptyList(), listOf("raw-key"), 0, true,
                if (password.isEmpty()) listOf("Password diperlukan untuk decrypt") else emptyList())
        }
        val pem = textCandidate
        val pemInspection = inspectPem(pem, password)
        if (pemInspection != null) return@runCatching pemInspection

        parsePrivateKeyDer(bytes)?.let {
            return@runCatching Inspection("DER private key", emptyList(), listOf("raw-key"), 0, true)
        }
        parseCertificates(bytes).takeIf { it.isNotEmpty() }?.let {
            return@runCatching Inspection("X.509/PKCS#7 certificate", emptyList(), emptyList(), it.size, false)
        }
        throw IllegalArgumentException("Format key/certificate tidak dikenali")
    }

    fun load(
        keyFile: File,
        storePassword: CharArray = charArrayOf(),
        keyPassword: CharArray = storePassword,
        alias: String? = null,
        certificateFile: File? = null
    ): Result<Material> = runCatching {
        require(keyFile.isFile) { "Fail key tidak wujud" }
        if (looksLikeJks(keyFile)) {
            return@runCatching PortableJks.load(keyFile, storePassword, keyPassword, alias)
        }
        if (looksLikeJceks(keyFile)) {
            return@runCatching PortableJceks.load(keyFile, storePassword, keyPassword, alias)
        }
        val rawText = runCatching { keyFile.readText(Charsets.UTF_8) }.getOrNull()
        if (rawText != null && looksLikeJwk(rawText)) {
            val key = parseJwkPrivateKey(rawText)
            val certs = buildList {
                addAll(parseJwkCertificates(rawText))
                if (certificateFile != null) addAll(parseCertificates(certificateFile.readBytes()))
            }.distinctBy { it.serialNumber to it.issuerX500Principal.name }
            require(certs.isNotEmpty()) { "JWK private key perlukan certificate X.509 atau field x5c" }
            val ordered = orderCertificatesForKey(key, certs)
            require(keyMatchesCertificate(key, ordered.first())) { "JWK private key tidak sepadan dengan certificate" }
            return@runCatching Material(alias ?: "raw-key", key, ordered, "JWK (${key.algorithm})")
        }

        for ((type, provider) in keyStoreCandidates(keyFile)) {
            val ks = runCatching { loadKeyStore(type, provider, keyFile, storePassword) }.getOrNull() ?: continue
            val selected = selectAlias(ks, alias)
            val key = runCatching { ks.getKey(selected, keyPassword) as? PrivateKey }.getOrNull()
                ?: runCatching { ks.getKey(selected, storePassword) as? PrivateKey }.getOrNull()
                ?: continue
            val chain = (ks.getCertificateChain(selected)?.mapNotNull { it as? X509Certificate }
                ?: listOfNotNull(ks.getCertificate(selected) as? X509Certificate))
            require(chain.isNotEmpty()) { "Alias '$selected' tiada sijil X.509" }
            val ordered = orderCertificatesForKey(key, chain)
            require(keyMatchesCertificate(key, ordered.first())) { "Private key tidak sepadan dengan certificate" }
            return@runCatching Material(selected, key, ordered, type)
        }

        val key = parsePrivateKey(keyFile, keyPassword)
            ?: throw IllegalArgumentException("Private key tidak dapat dibaca")
        val certs = buildList {
            addAll(parseCertificates(keyFile.readBytes()))
            if (certificateFile != null) addAll(parseCertificates(certificateFile.readBytes()))
        }.distinctBy { it.serialNumber to it.issuerX500Principal.name }
        require(certs.isNotEmpty()) { "Raw private key perlukan certificate X.509 PEM/DER/PKCS#7" }
        val ordered = orderCertificatesForKey(key, certs)
        require(keyMatchesCertificate(key, ordered.first())) { "Private key tidak sepadan dengan certificate" }
        Material(alias ?: "raw-key", key, ordered, rawFormatName(keyFile))
    }

    fun supportedExtensions(): Set<String> = setOf(
        "jks", "keystore", "ks", "jceks", "p12", "pfx", "pkcs12", "bks", "bcfks", "uber",
        "pem", "key", "pk8", "p8", "pkcs8", "pkcs1", "sec1", "der", "rsa", "ec", "openssh", "jwk", "json",
        "crt", "cer", "cert", "x509", "p7b", "p7c", "pkcs7", "spc"
    )

    private fun keyStoreCandidates(file: File): List<Pair<String, BouncyCastleProvider?>> {
        val ext = file.extension.lowercase()
        val preferred = when (ext) {
            "p12", "pfx", "pkcs12" -> listOf("PKCS12" to null, "PKCS12" to bc)
            "bks" -> listOf("BKS" to bc)
            "bcfks" -> listOf("BCFKS" to bc)
            "uber" -> listOf("UBER" to bc)
            "jceks" -> emptyList()
            "jks", "keystore" -> emptyList()
            else -> emptyList()
        }
        val fallback = listOf("PKCS12" to null, "PKCS12" to bc, "BCFKS" to bc, "BKS" to bc, "UBER" to bc)
        return (preferred + fallback).distinctBy { it.first + ":" + (it.second?.name ?: "system") }
    }

    private fun loadKeyStore(type: String, provider: BouncyCastleProvider?, file: File, password: CharArray): KeyStore {
        val ks = if (provider != null) KeyStore.getInstance(type, provider) else KeyStore.getInstance(type)
        file.inputStream().buffered().use { ks.load(it, password) }
        return ks
    }

    private fun selectAlias(ks: KeyStore, requested: String?): String {
        if (!requested.isNullOrBlank()) {
            require(ks.containsAlias(requested)) { "Alias '$requested' tidak wujud" }
            require(ks.isKeyEntry(requested)) { "Alias '$requested' bukan private-key entry" }
            return requested
        }
        return ks.aliases().toList().firstOrNull { ks.isKeyEntry(it) }
            ?: throw IllegalArgumentException("Keystore tiada private-key entry")
    }

    private fun inspectPem(text: String, password: CharArray): Inspection? {
        if (!text.contains("-----BEGIN ")) return null
        var keys = 0
        var certs = 0
        var encrypted = false
        PEMParser(StringReader(text)).use { parser ->
            while (true) {
                when (parser.readObject() ?: break) {
                    is PrivateKeyInfo, is PEMKeyPair -> keys++
                    is PKCS8EncryptedPrivateKeyInfo, is PEMEncryptedKeyPair -> { keys++; encrypted = true }
                    is X509CertificateHolder -> certs++
                }
            }
        }
        return Inspection("PEM", emptyList(), if (keys > 0) listOf("raw-key") else emptyList(), certs, keys > 0,
            if (encrypted && password.isEmpty()) listOf("Private key encrypted; password diperlukan untuk load") else emptyList())
    }

    private fun parsePrivateKey(file: File, password: CharArray): PrivateKey? {
        val bytes = file.readBytes()
        val text = bytes.toString(Charsets.UTF_8)
        if (looksLikeJwk(text)) return runCatching { parseJwkPrivateKey(text) }.getOrNull()
        if (text.contains("-----BEGIN ")) {
            parsePemPrivateKey(text, password)?.let { return it }
            if (text.contains("BEGIN OPENSSH PRIVATE KEY")) parseOpenSshPem(text)?.let { return it }
        }
        return parsePrivateKeyDer(bytes, password)
    }

    private fun parsePemPrivateKey(text: String, password: CharArray): PrivateKey? {
        PEMParser(StringReader(text)).use { parser ->
            while (true) {
                when (val obj = parser.readObject() ?: break) {
                    is PrivateKeyInfo -> return pemConverter.getPrivateKey(obj)
                    is PEMKeyPair -> return pemConverter.getKeyPair(obj).private
                    is PKCS8EncryptedPrivateKeyInfo -> {
                        val decryptor = JceOpenSSLPKCS8DecryptorProviderBuilder().setProvider(bc).build(password)
                        return pemConverter.getPrivateKey(obj.decryptPrivateKeyInfo(decryptor))
                    }
                    is PEMEncryptedKeyPair -> {
                        val decryptor = JcePEMDecryptorProviderBuilder().setProvider(bc).build(password)
                        return pemConverter.getKeyPair(obj.decryptKeyPair(decryptor)).private
                    }
                }
            }
        }
        return null
    }

    private fun parseOpenSshPem(text: String): PrivateKey? = runCatching {
        val body = text.lineSequence()
            .filterNot { it.startsWith("-----") }
            .joinToString("") { it.trim() }
        val params = OpenSSHPrivateKeyUtil.parsePrivateKeyBlob(Base64.getDecoder().decode(body))
        val info = org.bouncycastle.crypto.util.PrivateKeyInfoFactory.createPrivateKeyInfo(params)
        pemConverter.getPrivateKey(info)
    }.getOrNull()

    private fun parsePrivateKeyDer(bytes: ByteArray, password: CharArray = charArrayOf()): PrivateKey? {
        runCatching {
            val encrypted = PKCS8EncryptedPrivateKeyInfo(bytes)
            val decryptor = JceOpenSSLPKCS8DecryptorProviderBuilder().setProvider(bc).build(password)
            pemConverter.getPrivateKey(encrypted.decryptPrivateKeyInfo(decryptor))
        }.getOrNull()?.let { return it }
        parsePkcs8(bytes)?.let { return it }
        return runCatching {
            val rsa = org.bouncycastle.asn1.pkcs.RSAPrivateKey.getInstance(bytes)
            val info = PrivateKeyInfo(
                org.bouncycastle.asn1.x509.AlgorithmIdentifier(org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers.rsaEncryption, org.bouncycastle.asn1.DERNull.INSTANCE),
                rsa
            )
            pemConverter.getPrivateKey(info)
        }.getOrNull() ?: runCatching {
            val ec = org.bouncycastle.asn1.sec.ECPrivateKey.getInstance(bytes)
            val params = ec.parametersObject ?: throw IllegalArgumentException("SEC1 EC key tiada curve parameters")
            val info = PrivateKeyInfo(
                org.bouncycastle.asn1.x509.AlgorithmIdentifier(org.bouncycastle.asn1.x9.X9ObjectIdentifiers.id_ecPublicKey, params),
                ec
            )
            pemConverter.getPrivateKey(info)
        }.getOrNull()
    }

    private fun parsePkcs8(bytes: ByteArray): PrivateKey? {
        val spec = PKCS8EncodedKeySpec(bytes)
        for (algo in listOf("RSA", "EC", "DSA", "Ed25519", "Ed448")) {
            runCatching { KeyFactory.getInstance(algo).generatePrivate(spec) }.getOrNull()?.let { return it }
            runCatching { KeyFactory.getInstance(algo, bc).generatePrivate(spec) }.getOrNull()?.let { return it }
        }
        return runCatching { pemConverter.getPrivateKey(PrivateKeyInfo.getInstance(bytes)) }.getOrNull()
    }

    private fun looksLikeJwk(text: String): Boolean =
        text.trimStart().startsWith("{") && Regex("\"kty\"\\s*:").containsMatchIn(text)

    private fun parseJwkPrivateKey(text: String): PrivateKey {
        val kty = jwkString(text, "kty") ?: throw IllegalArgumentException("JWK tiada kty")
        return when (kty.uppercase()) {
            "RSA" -> {
                val n = jwkBigInt(text, "n")
                val d = jwkBigInt(text, "d")
                val e = jwkString(text, "e")?.let { base64UrlBigInt(it) }
                val p = jwkString(text, "p")?.let { base64UrlBigInt(it) }
                val q = jwkString(text, "q")?.let { base64UrlBigInt(it) }
                val dp = jwkString(text, "dp")?.let { base64UrlBigInt(it) }
                val dq = jwkString(text, "dq")?.let { base64UrlBigInt(it) }
                val qi = jwkString(text, "qi")?.let { base64UrlBigInt(it) }
                val factory = KeyFactory.getInstance("RSA")
                if (e != null && p != null && q != null && dp != null && dq != null && qi != null)
                    factory.generatePrivate(RSAPrivateCrtKeySpec(n, e, d, p, q, dp, dq, qi))
                else factory.generatePrivate(RSAPrivateKeySpec(n, d))
            }
            "EC" -> {
                val curve = when (jwkString(text, "crv")) {
                    "P-256" -> "secp256r1"
                    "P-384" -> "secp384r1"
                    "P-521" -> "secp521r1"
                    else -> throw IllegalArgumentException("Curve EC JWK tidak disokong")
                }
                val d = jwkBigInt(text, "d")
                val params = AlgorithmParameters.getInstance("EC")
                params.init(ECGenParameterSpec(curve))
                KeyFactory.getInstance("EC").generatePrivate(
                    ECPrivateKeySpec(d, params.getParameterSpec(ECParameterSpec::class.java))
                )
            }
            "OKP" -> {
                val seed = decodeBase64Url(jwkString(text, "d") ?: throw IllegalArgumentException("JWK OKP tiada d"))
                val info = when (jwkString(text, "crv")) {
                    "Ed25519" -> PrivateKeyInfoFactory.createPrivateKeyInfo(Ed25519PrivateKeyParameters(seed, 0))
                    "Ed448" -> PrivateKeyInfoFactory.createPrivateKeyInfo(Ed448PrivateKeyParameters(seed, 0))
                    else -> throw IllegalArgumentException("Curve OKP JWK tidak disokong")
                }
                pemConverter.getPrivateKey(info)
            }
            else -> throw IllegalArgumentException("kty JWK tidak disokong: $kty")
        }
    }

    private fun parseJwkCertificates(text: String): List<X509Certificate> {
        val match = Regex("\"x5c\"\\s*:\\s*\\[(.*?)]", setOf(RegexOption.DOT_MATCHES_ALL)).find(text)
            ?: return emptyList()
        val cf = CertificateFactory.getInstance("X.509")
        return Regex("\"([^\"]+)\"").findAll(match.groupValues[1]).mapNotNull { m ->
            runCatching {
                val bytes = Base64.getDecoder().decode(m.groupValues[1].replace("\\s".toRegex(), ""))
                cf.generateCertificate(ByteArrayInputStream(bytes)) as X509Certificate
            }.getOrNull()
        }.toList()
    }

    private fun jwkString(text: String, name: String): String? =
        Regex("\"" + Regex.escape(name) + "\"\\s*:\\s*\"([^\"]*)\"").find(text)?.groupValues?.get(1)

    private fun jwkBigInt(text: String, name: String): BigInteger =
        base64UrlBigInt(jwkString(text, name) ?: throw IllegalArgumentException("JWK tiada $name"))

    private fun base64UrlBigInt(value: String): BigInteger = BigInteger(1, decodeBase64Url(value))

    private fun decodeBase64Url(value: String): ByteArray {
        val clean = value.trim()
        val padded = clean + "=".repeat((4 - clean.length % 4) % 4)
        return Base64.getUrlDecoder().decode(padded)
    }

    private fun parseCertificates(bytes: ByteArray): List<X509Certificate> {
        val results = ArrayList<X509Certificate>()
        val text = bytes.toString(Charsets.UTF_8)
        if (text.contains("-----BEGIN ")) {
            runCatching {
                PEMParser(StringReader(text)).use { parser ->
                    while (true) {
                        val obj = parser.readObject() ?: break
                        if (obj is X509CertificateHolder) results += certConverter.getCertificate(obj)
                    }
                }
            }
        }
        if (results.isNotEmpty()) return results
        runCatching {
            val cf = CertificateFactory.getInstance("X.509")
            cf.generateCertificates(ByteArrayInputStream(bytes)).forEach { cert ->
                if (cert is X509Certificate) results += cert
            }
        }
        return results
    }

    private fun orderCertificatesForKey(key: PrivateKey, certs: List<X509Certificate>): List<X509Certificate> {
        val leaf = certs.firstOrNull { keyMatchesCertificate(key, it) }
            ?: throw IllegalArgumentException("Tiada certificate yang sepadan dengan private key")
        if (certs.size == 1) return listOf(leaf)
        val ordered = mutableListOf(leaf)
        val remaining = certs.toMutableList().apply { remove(leaf) }
        while (remaining.isNotEmpty()) {
            val next = remaining.firstOrNull { ordered.last().issuerX500Principal == it.subjectX500Principal } ?: break
            ordered += next
            remaining.remove(next)
        }
        ordered += remaining
        return ordered
    }

    private fun keyMatchesCertificate(key: PrivateKey, cert: X509Certificate): Boolean {
        val algorithm = when (key.algorithm.uppercase()) {
            "RSA" -> "SHA256withRSA"
            "EC", "ECDSA" -> "SHA256withECDSA"
            "DSA" -> "SHA256withDSA"
            "ED25519" -> "Ed25519"
            "ED448" -> "Ed448"
            else -> return false
        }
        val data = "FileManagerPro-key-match".toByteArray()
        fun attempt(useBc: Boolean): Boolean = runCatching {
            val signer = if (useBc) Signature.getInstance(algorithm, bc) else Signature.getInstance(algorithm)
            signer.initSign(key); signer.update(data)
            val sig = signer.sign()
            val verifier = if (useBc) Signature.getInstance(algorithm, bc) else Signature.getInstance(algorithm)
            verifier.initVerify(cert.publicKey); verifier.update(data); verifier.verify(sig)
        }.getOrDefault(false)
        return attempt(false) || attempt(true)
    }

    private fun looksLikeJks(file: File): Boolean = runCatching {
        DataInputStream(file.inputStream().buffered()).use { it.readInt() == PortableJks.MAGIC }
    }.getOrDefault(false)

    private fun looksLikeJceks(file: File): Boolean = runCatching {
        DataInputStream(file.inputStream().buffered()).use { it.readInt() == PortableJceks.MAGIC }
    }.getOrDefault(false)

    private fun rawFormatName(file: File): String = when (file.extension.lowercase()) {
        "pem", "key" -> "PEM private key"
        "pk8", "p8", "pkcs8" -> "PKCS#8"
        "pkcs1" -> "PKCS#1 RSA"
        "sec1" -> "SEC1 EC"
        "jwk", "json" -> "JWK"
        "der" -> "DER private key"
        else -> "Raw private key"
    }


    /**
     * Portable JCEKS reader for private-key entries used by APK signing.
     * It deliberately never deserializes JCEKS SecretKey entries.
     */
    private object PortableJceks {
        const val MAGIC = 0xCECECECE.toInt()
        private const val PRIVATE_KEY = 1
        private const val TRUSTED_CERT = 2
        private const val SECRET_KEY = 3
        private const val DIGEST_LEN = 20
        private const val PBE_MD5_3DES_OID = "1.3.6.1.4.1.42.2.19.1"
        private const val LEGACY_JKS_OID = "1.3.6.1.4.1.42.2.17.1.1"
        private val phrase = "Mighty Aphrodite".toByteArray(Charsets.UTF_8)

        data class Entry(val alias: String, val protectedKey: ByteArray?, val chain: List<X509Certificate>)
        data class Parsed(val entries: List<Entry>, val secretAliases: List<String>, val truncatedAfterSecret: Boolean)

        fun inspect(file: File, password: CharArray): Inspection {
            val parsed = parse(file, password, allowStopAtSecret = true)
            val notes = buildList {
                if (parsed.secretAliases.isNotEmpty()) add("SecretKey JCEKS dikesan tetapi tidak dideserialize; SecretKey bukan input APK signing")
                if (parsed.truncatedAfterSecret) add("Inspection berhenti pada SecretKey serialized entry untuk elak deserialization berisiko")
            }
            val aliases = parsed.entries.map { it.alias } + parsed.secretAliases
            val keyAliases = parsed.entries.filter { it.protectedKey != null }.map { it.alias }
            return Inspection("JCEKS", aliases, keyAliases, parsed.entries.sumOf { it.chain.size }, keyAliases.isNotEmpty(), notes)
        }

        fun load(file: File, storePassword: CharArray, keyPassword: CharArray, requestedAlias: String?): Material {
            val parsed = parse(file, storePassword, allowStopAtSecret = true)
            val entry = if (!requestedAlias.isNullOrBlank()) {
                parsed.entries.firstOrNull { it.alias.equals(requestedAlias, ignoreCase = true) }
                    ?: throw IllegalArgumentException(
                        if (parsed.secretAliases.any { it.equals(requestedAlias, true) })
                            "Alias '$requestedAlias' ialah SecretKey, bukan private signing key"
                        else "Alias '$requestedAlias' tidak ditemui sebagai private-key entry JCEKS"
                    )
            } else parsed.entries.firstOrNull { it.protectedKey != null }
                ?: throw IllegalArgumentException("JCEKS tiada private-key entry yang boleh digunakan untuk APK signing")
            val protected = entry.protectedKey ?: throw IllegalArgumentException("Alias '${entry.alias}' bukan private-key entry")
            val pkcs8 = decryptProtectedPrivateKey(protected, keyPassword)
            val key = decodePkcs8(pkcs8)
            require(entry.chain.isNotEmpty()) { "JCEKS private key tiada certificate chain" }
            return Material(entry.alias, key, entry.chain, "JCEKS")
        }

        private fun parse(file: File, password: CharArray, allowStopAtSecret: Boolean): Parsed {
            val all = file.readBytes()
            require(all.size >= 12 + DIGEST_LEN) { "JCEKS terlalu pendek" }
            if (password.isNotEmpty()) verifyIntegrity(all, password)
            val body = all.copyOfRange(0, all.size - DIGEST_LEN)
            val entries = ArrayList<Entry>()
            val secrets = ArrayList<String>()
            var stopped = false
            DataInputStream(ByteArrayInputStream(body)).use { input ->
                require(input.readInt() == MAGIC) { "Bukan JCEKS" }
                val version = input.readInt()
                require(version == 1 || version == 2) { "Versi JCEKS tidak disokong: $version" }
                val count = input.readInt()
                require(count in 0..1_000_000) { "Bilangan entry JCEKS tidak munasabah" }
                repeat(count) {
                    if (stopped) return@repeat
                    when (val tag = input.readInt()) {
                        PRIVATE_KEY -> {
                            val alias = input.readUTF()
                            input.readLong()
                            val keyLen = input.readInt()
                            require(keyLen in 1..(64 * 1024 * 1024)) { "Saiz protected key JCEKS tidak sah" }
                            val protected = ByteArray(keyLen).also { input.readFully(it) }
                            val chainLen = input.readInt()
                            require(chainLen in 0..10000) { "Certificate chain JCEKS terlalu besar" }
                            val chain = ArrayList<X509Certificate>(chainLen)
                            repeat(chainLen) {
                                if (version == 2) input.readUTF()
                                val len = input.readInt()
                                require(len in 1..(64 * 1024 * 1024)) { "Saiz certificate JCEKS tidak sah" }
                                val certBytes = ByteArray(len).also { input.readFully(it) }
                                val cf = CertificateFactory.getInstance("X.509")
                                chain += cf.generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
                            }
                            entries += Entry(alias, protected, chain)
                        }
                        TRUSTED_CERT -> {
                            val alias = input.readUTF()
                            input.readLong()
                            if (version == 2) input.readUTF()
                            val len = input.readInt()
                            require(len in 1..(64 * 1024 * 1024)) { "Saiz certificate JCEKS tidak sah" }
                            val certBytes = ByteArray(len).also { input.readFully(it) }
                            val cert = CertificateFactory.getInstance("X.509")
                                .generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
                            entries += Entry(alias, null, listOf(cert))
                        }
                        SECRET_KEY -> {
                            val alias = input.readUTF()
                            input.readLong()
                            secrets += alias
                            if (allowStopAtSecret) stopped = true
                            else throw IllegalArgumentException("JCEKS SecretKey serialized entry tidak disokong untuk APK signing")
                        }
                        else -> throw IllegalArgumentException("Tag JCEKS tidak dikenali: $tag")
                    }
                }
            }
            return Parsed(entries, secrets, stopped)
        }

        private fun verifyIntegrity(all: ByteArray, password: CharArray) {
            val bodyLen = all.size - DIGEST_LEN
            val expected = all.copyOfRange(bodyLen, all.size)
            val md = MessageDigest.getInstance("SHA-1")
            md.update(passwordBytes16(password))
            md.update(phrase)
            md.update(all, 0, bodyLen)
            require(MessageDigest.isEqual(expected, md.digest())) { "Password JCEKS salah atau fail rosak" }
        }

        private fun decryptProtectedPrivateKey(encoded: ByteArray, password: CharArray): ByteArray {
            val info = org.bouncycastle.asn1.pkcs.EncryptedPrivateKeyInfo.getInstance(encoded)
            val oid = info.encryptionAlgorithm.algorithm.id
            if (oid == LEGACY_JKS_OID) {
                return recoverLegacyJks(info.encryptedData, password)
            }
            require(oid == PBE_MD5_3DES_OID) { "Algoritma protection JCEKS tidak dikenali: $oid" }
            val params = PBEParameter.getInstance(info.encryptionAlgorithm.parameters)
            val salt = params.salt.copyOf()
            val iterations = params.iterationCount.intValueExact()
            require(salt.size == 8) { "Salt JCEKS mesti 8 byte" }
            require(iterations in 1..5_000_000) { "Iteration count JCEKS tidak munasabah" }
            val derived = deriveMd5TripleDes(password, salt, iterations)
            val cipher = Cipher.getInstance("DESede/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(derived.copyOfRange(0, 24), "DESede"), IvParameterSpec(derived.copyOfRange(24, 32)))
            return cipher.doFinal(info.encryptedData)
        }

        private fun deriveMd5TripleDes(password: CharArray, originalSalt: ByteArray, iterations: Int): ByteArray {
            val salt = originalSalt.copyOf()
            if (salt.copyOfRange(0, 4).contentEquals(salt.copyOfRange(4, 8))) {
                for (i in 0 until 2) {
                    val tmp = salt[i]
                    salt[i] = salt[3 - i]
                    salt[3 - i] = tmp
                }
            }
            val pwd = ByteArray(password.size) { i -> (password[i].code and 0x7f).toByte() }
            val result = ByteArray(32)
            for (half in 0..1) {
                var digestInput = salt.copyOfRange(half * 4, half * 4 + 4)
                repeat(iterations) {
                    val md = MessageDigest.getInstance("MD5")
                    md.update(digestInput)
                    md.update(pwd)
                    digestInput = md.digest()
                }
                System.arraycopy(digestInput, 0, result, half * 16, 16)
            }
            pwd.fill(0)
            return result
        }

        private fun recoverLegacyJks(encryptedData: ByteArray, password: CharArray): ByteArray {
            require(encryptedData.size >= 40) { "Protected legacy key rosak" }
            val seed = encryptedData.copyOfRange(0, 20)
            val keyLen = encryptedData.size - 40
            val encrypted = encryptedData.copyOfRange(20, 20 + keyLen)
            val checksum = encryptedData.copyOfRange(20 + keyLen, encryptedData.size)
            val pwd = passwordBytes16(password)
            val plain = ByteArray(keyLen)
            var previous = seed
            var offset = 0
            while (offset < keyLen) {
                val md = MessageDigest.getInstance("SHA-1")
                md.update(pwd); md.update(previous); previous = md.digest()
                val n = minOf(previous.size, keyLen - offset)
                for (i in 0 until n) plain[offset + i] = (encrypted[offset + i].toInt() xor previous[i].toInt()).toByte()
                offset += n
            }
            val md = MessageDigest.getInstance("SHA-1")
            md.update(pwd); md.update(plain)
            require(MessageDigest.isEqual(checksum, md.digest())) { "Password private key JCEKS salah" }
            return plain
        }

        private fun passwordBytes16(password: CharArray): ByteArray {
            val out = ByteArray(password.size * 2)
            password.forEachIndexed { i, c ->
                out[i * 2] = (c.code ushr 8).toByte()
                out[i * 2 + 1] = c.code.toByte()
            }
            return out
        }

        private fun decodePkcs8(bytes: ByteArray): PrivateKey {
            val spec = PKCS8EncodedKeySpec(bytes)
            for (algo in listOf("RSA", "EC", "DSA", "Ed25519", "Ed448")) {
                runCatching { KeyFactory.getInstance(algo).generatePrivate(spec) }.getOrNull()?.let { return it }
                runCatching { KeyFactory.getInstance(algo, BouncyCastleProvider()).generatePrivate(spec) }.getOrNull()?.let { return it }
            }
            throw IllegalArgumentException("Algoritma private key JCEKS tidak dikenali")
        }
    }

    private object PortableJks {
        const val MAGIC = 0xFEEDFEED.toInt()
        private const val PRIVATE_KEY = 1
        private const val TRUSTED_CERT = 2
        private const val DIGEST_LEN = 20
        private val phrase = "Mighty Aphrodite".toByteArray(Charsets.UTF_8)

        data class Entry(val alias: String, val protectedKey: ByteArray?, val chain: List<X509Certificate>)

        fun inspect(file: File, password: CharArray): Inspection {
            val entries = parse(file, password)
            return Inspection("JKS", entries.map { it.alias }, entries.filter { it.protectedKey != null }.map { it.alias }, entries.sumOf { it.chain.size }, entries.any { it.protectedKey != null })
        }

        fun load(file: File, storePassword: CharArray, keyPassword: CharArray, requestedAlias: String?): Material {
            val entries = parse(file, storePassword)
            val entry = if (!requestedAlias.isNullOrBlank()) {
                entries.firstOrNull { it.alias == requestedAlias }
                    ?: throw IllegalArgumentException("Alias '$requestedAlias' tidak wujud")
            } else entries.firstOrNull { it.protectedKey != null }
                ?: throw IllegalArgumentException("JKS tiada private-key entry")
            val protected = entry.protectedKey ?: throw IllegalArgumentException("Alias '${entry.alias}' bukan private-key entry")
            val encrypted = EncryptedPrivateKeyInfo(protected).encryptedData
            val pkcs8 = recoverKey(encrypted, keyPassword)
            val key = decodePkcs8(pkcs8)
            require(entry.chain.isNotEmpty()) { "JKS private key tiada certificate chain" }
            return Material(entry.alias, key, entry.chain, "JKS")
        }

        private fun parse(file: File, password: CharArray): List<Entry> {
            val all = file.readBytes()
            require(all.size >= 12 + DIGEST_LEN) { "JKS terlalu pendek" }
            if (password.isNotEmpty()) verifyIntegrity(all, password)
            val body = all.copyOfRange(0, all.size - DIGEST_LEN)
            val certFactory = CertificateFactory.getInstance("X.509")
            DataInputStream(ByteArrayInputStream(body)).use { input ->
                require(input.readInt() == MAGIC) { "Bukan JKS" }
                val version = input.readInt()
                require(version == 1 || version == 2) { "Versi JKS tidak disokong: $version" }
                val count = input.readInt()
                require(count in 0..1_000_000) { "Bilangan entry JKS tidak munasabah" }
                val entries = ArrayList<Entry>(count)
                repeat(count) {
                    when (val tag = input.readInt()) {
                        PRIVATE_KEY -> {
                            val alias = input.readUTF()
                            input.readLong()
                            val keyLen = input.readInt()
                            require(keyLen in 1..(64 * 1024 * 1024)) { "Saiz protected key tidak sah" }
                            val protected = ByteArray(keyLen).also { input.readFully(it) }
                            val chainLen = input.readInt()
                            require(chainLen in 0..10000) { "Certificate chain terlalu besar" }
                            val chain = ArrayList<X509Certificate>(chainLen)
                            repeat(chainLen) {
                                if (version == 2) input.readUTF()
                                val len = input.readInt()
                                require(len in 1..(64 * 1024 * 1024)) { "Saiz certificate tidak sah" }
                                val certBytes = ByteArray(len).also { input.readFully(it) }
                                chain += certFactory.generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
                            }
                            entries += Entry(alias, protected, chain)
                        }
                        TRUSTED_CERT -> {
                            val alias = input.readUTF()
                            input.readLong()
                            if (version == 2) input.readUTF()
                            val len = input.readInt()
                            require(len in 1..(64 * 1024 * 1024)) { "Saiz certificate tidak sah" }
                            val certBytes = ByteArray(len).also { input.readFully(it) }
                            val cert = certFactory.generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
                            entries += Entry(alias, null, listOf(cert))
                        }
                        else -> throw IllegalArgumentException("Tag JKS tidak dikenali: $tag")
                    }
                }
                return entries
            }
        }

        private fun verifyIntegrity(all: ByteArray, password: CharArray) {
            val bodyLen = all.size - DIGEST_LEN
            val expected = all.copyOfRange(bodyLen, all.size)
            val digest = MessageDigest.getInstance("SHA-1")
            digest.update(passwordBytes(password))
            digest.update(phrase)
            digest.update(all, 0, bodyLen)
            require(MessageDigest.isEqual(expected, digest.digest())) { "Password JKS salah atau fail rosak" }
        }

        private fun recoverKey(encryptedData: ByteArray, password: CharArray): ByteArray {
            require(encryptedData.size >= 40) { "Protected JKS key rosak" }
            val seed = encryptedData.copyOfRange(0, 20)
            val keyLen = encryptedData.size - 40
            val encrypted = encryptedData.copyOfRange(20, 20 + keyLen)
            val checksum = encryptedData.copyOfRange(20 + keyLen, encryptedData.size)
            val pwd = passwordBytes(password)
            val plain = ByteArray(keyLen)
            var previous = seed
            var offset = 0
            while (offset < keyLen) {
                val md = MessageDigest.getInstance("SHA-1")
                md.update(pwd)
                md.update(previous)
                previous = md.digest()
                val n = minOf(previous.size, keyLen - offset)
                for (i in 0 until n) plain[offset + i] = (encrypted[offset + i].toInt() xor previous[i].toInt()).toByte()
                offset += n
            }
            val md = MessageDigest.getInstance("SHA-1")
            md.update(pwd)
            md.update(plain)
            require(MessageDigest.isEqual(checksum, md.digest())) { "Password private key JKS salah" }
            return plain
        }

        private fun passwordBytes(password: CharArray): ByteArray {
            val out = ByteArray(password.size * 2)
            password.forEachIndexed { i, c ->
                out[i * 2] = (c.code ushr 8).toByte()
                out[i * 2 + 1] = c.code.toByte()
            }
            return out
        }

        private fun decodePkcs8(bytes: ByteArray): PrivateKey {
            val spec = PKCS8EncodedKeySpec(bytes)
            for (algo in listOf("RSA", "EC", "DSA", "Ed25519", "Ed448")) {
                runCatching { KeyFactory.getInstance(algo).generatePrivate(spec) }.getOrNull()?.let { return it }
            }
            throw IllegalArgumentException("Algoritma private key JKS tidak dikenali")
        }
    }
}
