package com.filemanagerpro.app.search

import android.os.Environment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class DeepSearchUiState(
    val query: String = "",
    val running: Boolean = false,
    val regex: Boolean = false,
    val caseSensitive: Boolean = false,
    val scanArchives: Boolean = true,
    val scanBinaryStrings: Boolean = true,
    val results: List<SearchHit> = emptyList(),
    val progress: SearchProgress? = null,
    val error: String? = null,
    val rootPath: String = Environment.getExternalStorageDirectory().path
)

class DeepSearchViewModel : ViewModel() {
    private val engine = DeepSearchEngine()
    private val _state = MutableStateFlow(DeepSearchUiState())
    val state = _state.asStateFlow()
    private var job: Job? = null

    fun setQuery(value: String) { _state.value = _state.value.copy(query = value) }
    fun setRoot(value: String) { _state.value = _state.value.copy(rootPath = value) }
    fun toggleRegex() { _state.value = _state.value.copy(regex = !_state.value.regex) }
    fun toggleCase() { _state.value = _state.value.copy(caseSensitive = !_state.value.caseSensitive) }
    fun toggleArchives() { _state.value = _state.value.copy(scanArchives = !_state.value.scanArchives) }
    fun toggleBinary() { _state.value = _state.value.copy(scanBinaryStrings = !_state.value.scanBinaryStrings) }

    fun cancel() {
        job?.cancel()
        _state.value = _state.value.copy(running = false)
    }

    fun start() {
        val snapshot = _state.value
        if (snapshot.query.isBlank()) return
        job?.cancel()
        _state.value = snapshot.copy(running = true, results = emptyList(), error = null, progress = null)
        job = viewModelScope.launch {
            try {
                val request = DeepSearchRequest(
                    roots = listOf(File(snapshot.rootPath)),
                    query = snapshot.query,
                    regex = snapshot.regex,
                    caseSensitive = snapshot.caseSensitive,
                    scanArchives = snapshot.scanArchives,
                    scanBinaryStrings = snapshot.scanBinaryStrings
                )
                engine.search(request) { progress ->
                    _state.value = _state.value.copy(progress = progress)
                }.collect { hit ->
                    _state.value = _state.value.copy(results = _state.value.results + hit)
                }
                _state.value = _state.value.copy(running = false)
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) return@launch
                _state.value = _state.value.copy(running = false, error = t.message ?: t::class.java.simpleName)
            }
        }
    }
}
