package com.filemanagerpro.app.search

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import java.io.InputStream
import java.nio.charset.Charset
import java.util.Locale
import java.util.zip.ZipFile
import kotlin.math.min

class DeepSearchEngine {
    fun search(request: DeepSearchRequest, onProgress: (SearchProgress) -> Unit = {}): Flow<SearchHit> = flow {
        require(request.query.isNotBlank()) { "Query tidak boleh kosong" }
        val matcher = Matcher(request.query, request.regex, request.caseSensitive)
        var files = 0L
        var dirs = 0L
        var archiveEntries = 0L
        var expandedBytes = 0L
        val visitedDirectories = HashSet<String>()

        fun allowedByExtension(name: String): Boolean {
            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (request.includeExtensions.isNotEmpty() && ext !in request.includeExtensions) return false
            if (ext in request.excludeExtensions) return false
            return true
        }

        suspend fun scanBytes(
            bytes: ByteArray,
            logicalPath: String,
            physicalFile: File,
            type: SearchHitType,
            archiveDepth: Int
        ): Boolean {
            currentCoroutineContext().ensureActive()
            if (!request.searchContents || bytes.isEmpty()) return false
            val text = decodeForSearch(bytes, request.scanBinaryStrings)
            val match = matcher.find(text) ?: return false
            emit(SearchHit(type, logicalPath, physicalFile, bytes.size.toLong(), makeSnippet(text, match.first, match.last + 1), archiveDepth))
            return true
        }

        suspend fun scanStream(
            input: InputStream,
            logicalPath: String,
            physicalFile: File,
            type: SearchHitType,
            archiveDepth: Int,
            declaredSize: Long,
            maxRead: Long = Long.MAX_VALUE
        ): Long {
            if (!request.searchContents || maxRead <= 0) return 0
            val chunkSize = 256 * 1024
            val overlapSize = 64 * 1024
            val buffer = ByteArray(chunkSize)
            var tail = ByteArray(0)
            var total = 0L
            while (total < maxRead) {
                currentCoroutineContext().ensureActive()
                val want = min(buffer.size.toLong(), maxRead - total).toInt()
                val count = input.read(buffer, 0, want)
                if (count <= 0) break
                total += count
                val merged = ByteArray(tail.size + count)
                if (tail.isNotEmpty()) System.arraycopy(tail, 0, merged, 0, tail.size)
                System.arraycopy(buffer, 0, merged, tail.size, count)
                val text = decodeForSearch(merged, request.scanBinaryStrings)
                val match = matcher.find(text)
                if (match != null) {
                    emit(SearchHit(type, logicalPath, physicalFile, declaredSize.coerceAtLeast(total), makeSnippet(text, match.first, match.last + 1), archiveDepth))
                    return total
                }
                val keep = min(overlapSize, merged.size)
                tail = merged.copyOfRange(merged.size - keep, merged.size)
            }
            return total
        }

        suspend fun scanArchive(
            archiveFile: File,
            logicalPrefix: String,
            archiveDepth: Int,
            physicalOwner: File = archiveFile
        ) {
            if (!request.scanArchives || archiveDepth > request.maxArchiveDepth) return
            runCatching {
                ZipFile(archiveFile).use { zip ->
                    val e = zip.entries()
                    while (e.hasMoreElements()) {
                        currentCoroutineContext().ensureActive()
                        val entry = e.nextElement()
                        if (archiveEntries >= request.maxArchiveEntries || expandedBytes >= request.maxExpandedBytes) break
                        archiveEntries++
                        val path = "$logicalPrefix › ${entry.name}"
                        onProgress(SearchProgress(files, dirs, archiveEntries, path))
                        if (entry.isDirectory) continue
                        if (request.searchNames && matcher.contains(entry.name)) {
                            emit(SearchHit(SearchHitType.ARCHIVE_ENTRY_NAME, path, physicalOwner, entry.size.coerceAtLeast(0), archiveDepth = archiveDepth))
                        }
                        val remaining = (request.maxExpandedBytes - expandedBytes).coerceAtLeast(0L)
                        if (remaining <= 0) continue
                        zip.getInputStream(entry).use entryStream@ { input ->
                            if (isZipLike(entry.name) && archiveDepth < request.maxArchiveDepth) {
                                if (entry.size >= 0 && entry.size > remaining) return@entryStream
                                val temp = File.createTempFile("fmp-deep-search-", ".zip")
                                try {
                                    val copied = copyEntryToTemp(input, temp, remaining)
                                    expandedBytes += copied.bytes
                                    if (copied.complete) {
                                        scanArchive(temp, path, archiveDepth + 1, physicalOwner)
                                    }
                                } finally {
                                    temp.delete()
                                }
                            } else if (allowedByExtension(entry.name)) {
                                val read = scanStream(input, path, physicalOwner, SearchHitType.ARCHIVE_CONTENT, archiveDepth, entry.size.coerceAtLeast(0), remaining)
                                expandedBytes += read
                            }
                        }
                    }
                }
            }
        }

        suspend fun scanFs(node: File, directoryDepth: Int) {
            currentCoroutineContext().ensureActive()
            if (directoryDepth > request.maxDirectoryDepth) return
            if (!request.includeHidden && node.isHidden) return
            if (node.isDirectory) {
                val canonical = runCatching { node.canonicalPath }.getOrElse { node.absolutePath }
                if (!visitedDirectories.add(canonical)) return
                dirs++
                onProgress(SearchProgress(files, dirs, archiveEntries, node.path))
                node.listFiles()?.forEach { scanFs(it, directoryDepth + 1) }
                return
            }
            if (!node.isFile || !allowedByExtension(node.name)) return
            files++
            onProgress(SearchProgress(files, dirs, archiveEntries, node.path))
            if (request.searchNames && matcher.contains(node.name)) {
                emit(SearchHit(SearchHitType.FILE_NAME, node.path, node, node.length()))
            }
            if (isZipLike(node.name)) {
                scanArchive(node, node.path, 1)
            } else if (request.searchContents) {
                runCatching { node.inputStream().buffered().use { scanStream(it, node.path, node, SearchHitType.FILE_CONTENT, 0, node.length()) } }
            }
        }

        request.roots.filter { it.exists() }.forEach { scanFs(it, 0) }
    }.flowOn(Dispatchers.IO)

    private class Matcher(query: String, regex: Boolean, caseSensitive: Boolean) {
        private val regexValue: Regex? = if (regex) {
            val opts = if (caseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)
            Regex(query, opts)
        } else null
        private val needle = if (caseSensitive) query else query.lowercase(Locale.ROOT)
        private val caseSensitiveValue = caseSensitive

        fun contains(value: String): Boolean = find(value) != null

        fun find(value: String): IntRange? {
            regexValue?.find(value)?.range?.let { return it }
            val hay = if (caseSensitiveValue) value else value.lowercase(Locale.ROOT)
            val index = hay.indexOf(needle)
            return if (index >= 0) index until (index + needle.length) else null
        }
    }

    companion object {
        private val zipExtensions = setOf("zip", "apk", "jar", "aar", "apks", "xapk")

        private fun isZipLike(name: String): Boolean =
            name.substringAfterLast('.', "").lowercase(Locale.ROOT) in zipExtensions

        private data class TempCopyResult(val bytes: Long, val complete: Boolean)

        private fun copyEntryToTemp(input: InputStream, target: File, maxBytes: Long): TempCopyResult {
            var total = 0L
            val buffer = ByteArray(256 * 1024)
            target.outputStream().buffered().use { out ->
                while (total < maxBytes) {
                    val want = min(buffer.size.toLong(), maxBytes - total).toInt()
                    val read = input.read(buffer, 0, want)
                    if (read <= 0) return TempCopyResult(total, true)
                    out.write(buffer, 0, read)
                    total += read
                }
                return TempCopyResult(total, input.read() == -1)
            }
        }

        private fun readBounded(input: InputStream, maxBytes: Long): ByteArray {
            val cap = min(maxBytes, Int.MAX_VALUE.toLong()).toInt()
            val out = java.io.ByteArrayOutputStream(min(cap, 64 * 1024))
            val buffer = ByteArray(32 * 1024)
            var total = 0
            while (total < cap) {
                val read = input.read(buffer, 0, min(buffer.size, cap - total))
                if (read <= 0) break
                out.write(buffer, 0, read)
                total += read
            }
            return out.toByteArray()
        }

        private fun decodeForSearch(bytes: ByteArray, binaryStrings: Boolean): String {
            val sample = bytes.take(min(bytes.size, 4096))
            val zeros = sample.count { it == 0.toByte() }
            return when {
                zeros > sample.size / 4 -> {
                    val le = runCatching { String(bytes, Charset.forName("UTF-16LE")) }.getOrDefault("")
                    val be = runCatching { String(bytes, Charset.forName("UTF-16BE")) }.getOrDefault("")
                    "$le\n$be"
                }
                looksMostlyText(sample) -> String(bytes, Charsets.UTF_8)
                binaryStrings -> extractPrintableStrings(bytes)
                else -> ""
            }
        }

        private fun looksMostlyText(sample: List<Byte>): Boolean {
            if (sample.isEmpty()) return true
            val printable = sample.count {
                val v = it.toInt() and 0xff
                v == 9 || v == 10 || v == 13 || v in 32..126 || v >= 0xC2
            }
            return printable.toDouble() / sample.size >= 0.82
        }

        private fun extractPrintableStrings(bytes: ByteArray): String {
            val out = StringBuilder()
            val current = StringBuilder()
            for (b in bytes) {
                val c = (b.toInt() and 0xff).toChar()
                if (c.code in 32..126) {
                    current.append(c)
                } else {
                    if (current.length >= 4) out.append(current).append('\n')
                    current.clear()
                }
            }
            if (current.length >= 4) out.append(current)
            return out.toString()
        }

        private fun makeSnippet(text: String, start: Int, end: Int): String {
            val from = (start - 72).coerceAtLeast(0)
            val to = (end + 96).coerceAtMost(text.length)
            return text.substring(from, to).replace('\n', ' ').replace('\r', ' ').trim()
        }
    }
}
