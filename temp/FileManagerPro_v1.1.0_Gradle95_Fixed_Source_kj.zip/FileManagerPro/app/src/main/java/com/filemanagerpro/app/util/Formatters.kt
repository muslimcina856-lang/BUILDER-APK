package com.filemanagerpro.app.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.pow

fun formatBytes(value: Long): String {
    if (value < 1024) return "$value B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    val exp = (log10(value.toDouble()) / log10(1024.0)).toInt().coerceIn(1, 4)
    return String.format(Locale.US, "%.1f %s", value / 1024.0.pow(exp.toDouble()), units[exp - 1])
}

fun formatDate(epoch: Long): String =
    SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(epoch))
