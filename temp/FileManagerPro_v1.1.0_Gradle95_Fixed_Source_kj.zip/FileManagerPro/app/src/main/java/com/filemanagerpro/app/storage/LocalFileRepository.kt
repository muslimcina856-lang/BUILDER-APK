package com.filemanagerpro.app.storage

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class FileEntry(
    val file: File,
    val isDirectory: Boolean,
    val size: Long,
    val modified: Long
)

data class FileProperties(
    val path: String,
    val size: Long,
    val fileCount: Long,
    val directoryCount: Long,
    val modified: Long,
    val readable: Boolean,
    val writable: Boolean,
    val executable: Boolean
)

class LocalFileRepository {
    suspend fun list(path: File, showHidden: Boolean = false): List<FileEntry> = withContext(Dispatchers.IO) {
        path.listFiles()
            ?.asSequence()
            ?.filter { showHidden || !it.isHidden }
            ?.map { FileEntry(it, it.isDirectory, if (it.isFile) it.length() else 0L, it.lastModified()) }
            ?.sortedWith(compareBy<FileEntry> { !it.isDirectory }.thenBy { it.file.name.lowercase() })
            ?.toList()
            ?: emptyList()
    }

    suspend fun createFolder(parent: File, name: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(name.isNotBlank()) { "Nama folder kosong" }
            val out = File(parent, name.trim())
            check(!out.exists()) { "Nama sudah wujud" }
            check(out.mkdirs()) { "Gagal mencipta folder" }
            out
        }
    }

    suspend fun createFile(parent: File, name: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(name.isNotBlank()) { "Nama fail kosong" }
            val out = File(parent, name.trim())
            check(!out.exists()) { "Nama sudah wujud" }
            out.parentFile?.mkdirs()
            check(out.createNewFile()) { "Gagal mencipta fail" }
            out
        }
    }

    suspend fun rename(source: File, newName: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(newName.isNotBlank()) { "Nama kosong" }
            val parent = requireNotNull(source.parentFile) { "Tiada parent directory" }
            val target = File(parent, newName.trim())
            check(!target.exists() || target.canonicalPath == source.canonicalPath) { "Nama sudah wujud" }
            check(source.renameTo(target)) { "Gagal menamakan semula" }
            target
        }
    }

    suspend fun delete(target: File): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (target.isDirectory) {
                target.walkBottomUp().forEach { check(it.delete()) { "Gagal memadam ${it.path}" } }
            } else {
                check(target.delete()) { "Gagal memadam ${target.path}" }
            }
        }
    }

    suspend fun copy(source: File, destinationDirectory: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching { copyInternal(source, destinationDirectory) }
    }

    private fun copyInternal(source: File, destinationDirectory: File): File {
        check(destinationDirectory.isDirectory) { "Destination bukan folder" }
        val requestedTarget = File(destinationDirectory, source.name)
        val target = keepBothTarget(requestedTarget, source.isDirectory)
        val sourcePath = source.canonicalFile.toPath()
        val targetPath = target.canonicalFile.toPath()
        check(sourcePath != targetPath) { "Source dan destination sama" }
        if (source.isDirectory) {
            check(!targetPath.startsWith(sourcePath)) { "Tidak boleh copy folder ke dalam dirinya sendiri" }
            source.walkTopDown().forEach { child ->
                val relative = child.relativeTo(source)
                val out = File(target, relative.path)
                if (child.isDirectory) out.mkdirs()
                else {
                    out.parentFile?.mkdirs()
                    Files.copy(child.toPath(), out.toPath(), StandardCopyOption.COPY_ATTRIBUTES)
                }
            }
        } else {
            Files.copy(source.toPath(), target.toPath(), StandardCopyOption.COPY_ATTRIBUTES)
        }
        return target
    }

    suspend fun duplicate(source: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val parent = requireNotNull(source.parentFile)
            val base = source.nameWithoutExtension
            val ext = source.extension.takeIf { it.isNotEmpty() }?.let { ".$it" } ?: ""
            var index = 1
            var target: File
            do {
                target = File(parent, "$base copy${if (index == 1) "" else " $index"}$ext")
                index++
            } while (target.exists())
            if (source.isDirectory) {
                target.mkdirs()
                source.listFiles()?.forEach { child -> copyInternal(child, target) }
            } else {
                Files.copy(source.toPath(), target.toPath(), StandardCopyOption.COPY_ATTRIBUTES)
            }
            target
        }
    }

    suspend fun move(source: File, destinationDirectory: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val requestedTarget = File(destinationDirectory, source.name)
            val target = keepBothTarget(requestedTarget, source.isDirectory)
            val sourcePath = source.canonicalFile.toPath()
            val targetPath = target.canonicalFile.toPath()
            check(sourcePath != targetPath) { "Source dan destination sama" }
            if (source.isDirectory) check(!targetPath.startsWith(sourcePath)) { "Tidak boleh move folder ke dalam dirinya sendiri" }
            try {
                Files.move(source.toPath(), target.toPath())
            } catch (_: Exception) {
                copyExact(source, target)
                if (source.isDirectory) source.walkBottomUp().forEach { check(it.delete()) { "Gagal buang source selepas move" } }
                else check(source.delete()) { "Gagal buang source selepas move" }
            }
            target
        }
    }

    suspend fun hash(file: File, algorithm: String = "SHA-256"): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            check(file.isFile) { "Hash hanya untuk fail" }
            val digest = MessageDigest.getInstance(algorithm)
            file.inputStream().buffered().use { input ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 4)
                while (true) {
                    val count = input.read(buffer)
                    if (count <= 0) break
                    digest.update(buffer, 0, count)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        }
    }

    suspend fun readTextPreview(file: File, maxBytes: Int = 512 * 1024): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            check(file.isFile) { "Bukan fail" }
            file.inputStream().buffered().use { input ->
                val out = ByteArray(maxBytes)
                val count = input.read(out)
                if (count <= 0) "" else out.copyOf(count).toString(Charsets.UTF_8)
            }
        }
    }

    suspend fun properties(target: File): Result<FileProperties> = withContext(Dispatchers.IO) {
        runCatching {
            if (!target.isDirectory) {
                FileProperties(target.path, target.length(), 1, 0, target.lastModified(), target.canRead(), target.canWrite(), target.canExecute())
            } else {
                var bytes = 0L
                var files = 0L
                var dirs = 0L
                target.walkTopDown().forEach { f ->
                    if (f.isDirectory) dirs++ else { files++; bytes += f.length() }
                }
                FileProperties(target.path, bytes, files, dirs, target.lastModified(), target.canRead(), target.canWrite(), target.canExecute())
            }
        }
    }

    suspend fun zip(source: File, outputDirectory: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val output = uniqueFile(outputDirectory, "${source.nameWithoutExtension.ifBlank { source.name }}.zip")
            ZipOutputStream(BufferedOutputStream(FileOutputStream(output))).use { zip ->
                if (source.isDirectory) {
                    val base = source.parentFile ?: source
                    source.walkTopDown().forEach { child ->
                        val rel = child.relativeTo(base).invariantSeparatorsPath
                        if (child.isDirectory) {
                            if (rel.isNotEmpty()) {
                                zip.putNextEntry(ZipEntry(if (rel.endsWith('/')) rel else "$rel/"))
                                zip.closeEntry()
                            }
                        } else {
                            zip.putNextEntry(ZipEntry(rel))
                            BufferedInputStream(FileInputStream(child)).use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                    }
                } else {
                    zip.putNextEntry(ZipEntry(source.name))
                    BufferedInputStream(FileInputStream(source)).use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
            output
        }
    }

    suspend fun unzip(source: File, outputDirectory: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            check(source.isFile) { "Bukan fail arkib" }
            val folderName = source.nameWithoutExtension.ifBlank { "extracted" }
            val output = uniqueDirectory(outputDirectory, folderName)
            val staging = File(outputDirectory, ".fmp_extract_${System.nanoTime()}")
            check(staging.mkdirs()) { "Gagal cipta staging extract" }
            try {
                val canonicalRoot = staging.canonicalFile
                ZipFile(source).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        val out = File(staging, entry.name).canonicalFile
                        check(out.path == canonicalRoot.path || out.path.startsWith(canonicalRoot.path + File.separator)) { "Archive entry tidak selamat: ${entry.name}" }
                        if (entry.isDirectory) {
                            check(out.mkdirs() || out.isDirectory) { "Gagal cipta folder ${entry.name}" }
                        } else {
                            check(out.parentFile?.mkdirs() != false || out.parentFile?.isDirectory == true) { "Gagal cipta parent ${entry.name}" }
                            zip.getInputStream(entry).use { input ->
                                BufferedOutputStream(FileOutputStream(out)).use { outputStream -> input.copyTo(outputStream) }
                            }
                        }
                    }
                }
                check(staging.renameTo(output)) { "Gagal commit hasil extract" }
                output
            } catch (t: Throwable) {
                staging.walkBottomUp().forEach { it.delete() }
                throw t
            }
        }
    }

    suspend fun zipMany(sources: List<File>, outputDirectory: File, preferredName: String = "Selection.zip"): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(sources.isNotEmpty()) { "Tiada item dipilih" }
            val output = uniqueFile(outputDirectory, preferredName)
            ZipOutputStream(BufferedOutputStream(FileOutputStream(output))).use { zip ->
                val used = HashSet<String>()
                sources.forEach { source ->
                    val rootName = uniqueEntryName(source.name, used)
                    if (source.isDirectory) {
                        val base = source.parentFile ?: source
                        source.walkTopDown().forEach { child ->
                            val rel0 = child.relativeTo(base).invariantSeparatorsPath
                            val rel = if (rel0.startsWith(source.name)) rootName + rel0.removePrefix(source.name) else "$rootName/$rel0"
                            if (child.isDirectory) {
                                zip.putNextEntry(ZipEntry(if (rel.endsWith('/')) rel else "$rel/"))
                                zip.closeEntry()
                            } else {
                                zip.putNextEntry(ZipEntry(rel))
                                BufferedInputStream(FileInputStream(child)).use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                        }
                    } else {
                        zip.putNextEntry(ZipEntry(rootName))
                        BufferedInputStream(FileInputStream(source)).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
            output
        }
    }

    private fun keepBothTarget(requested: File, isDirectory: Boolean): File {
        if (!requested.exists()) return requested
        return if (isDirectory) uniqueDirectory(requested.parentFile ?: return requested, requested.name)
        else uniqueFile(requested.parentFile ?: return requested, requested.name)
    }

    private fun copyExact(source: File, target: File) {
        if (source.isDirectory) {
            check(target.mkdirs() || target.isDirectory) { "Gagal cipta ${target.path}" }
            source.listFiles()?.forEach { child -> copyExact(child, File(target, child.name)) }
        } else {
            target.parentFile?.mkdirs()
            Files.copy(source.toPath(), target.toPath(), StandardCopyOption.COPY_ATTRIBUTES)
        }
    }

    private fun uniqueEntryName(name: String, used: MutableSet<String>): String {
        if (used.add(name)) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 2
        while (true) {
            val candidate = "$base ($n)$ext"
            if (used.add(candidate)) return candidate
            n++
        }
    }

    suspend fun listZipEntries(source: File, limit: Int = 5000): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            val entries = ArrayList<String>()
            ZipInputStream(BufferedInputStream(FileInputStream(source))).use { zip ->
                while (entries.size < limit) {
                    val entry = zip.nextEntry ?: break
                    entries += entry.name + if (entry.isDirectory) "/" else ""
                    zip.closeEntry()
                }
            }
            entries
        }
    }

    private fun uniqueFile(parent: File, preferred: String): File {
        val initial = File(parent, preferred)
        if (!initial.exists()) return initial
        val base = initial.nameWithoutExtension
        val ext = initial.extension.takeIf { it.isNotEmpty() }?.let { ".$it" } ?: ""
        var n = 2
        while (true) {
            val candidate = File(parent, "$base ($n)$ext")
            if (!candidate.exists()) return candidate
            n++
        }
    }

    private fun uniqueDirectory(parent: File, preferred: String): File {
        val initial = File(parent, preferred)
        if (!initial.exists()) return initial
        var n = 2
        while (true) {
            val candidate = File(parent, "$preferred ($n)")
            if (!candidate.exists()) return candidate
            n++
        }
    }
}
