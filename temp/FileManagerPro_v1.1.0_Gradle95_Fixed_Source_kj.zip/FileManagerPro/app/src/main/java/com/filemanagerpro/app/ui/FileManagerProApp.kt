package com.filemanagerpro.app.ui

import android.os.Environment
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.filemanagerpro.app.search.DeepSearchViewModel
import com.filemanagerpro.app.search.SearchHitType
import com.filemanagerpro.app.storage.FileEntry
import com.filemanagerpro.app.storage.LocalFileRepository
import com.filemanagerpro.app.storage.StorageAccessManager
import com.filemanagerpro.app.signing.ApkSigningService
import com.filemanagerpro.app.signing.SigningMaterialLoader
import com.filemanagerpro.app.util.FileIntents
import com.filemanagerpro.app.util.formatBytes
import com.filemanagerpro.app.util.formatDate
import kotlinx.coroutines.launch
import java.io.File

private val Bg = Color(0xFF0B0E12)
private val Panel = Color(0xFF11161D)
private val Panel2 = Color(0xFF171D26)
private val Accent = Color(0xFF63F2B1)
private val Muted = Color(0xFF98A6B7)

enum class AppTab(val label: String) { FILES("Files"), SEARCH("Deep Search"), TOOLS("Tools"), NETWORK("Network"), SETTINGS("Settings") }

@Composable
fun FileManagerProApp() {
    var tab by remember { mutableStateOf(AppTab.FILES) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel,
            surfaceVariant = Panel2,
            onBackground = Color(0xFFF2F6F8),
            onSurface = Color(0xFFF2F6F8),
            onSurfaceVariant = Muted
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = { AppHeader(tab) },
            bottomBar = { BottomTabs(tab) { tab = it } }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    AppTab.FILES -> FilesScreen()
                    AppTab.SEARCH -> SearchScreen()
                    AppTab.TOOLS -> ToolsScreen()
                    AppTab.NETWORK -> NetworkScreen()
                    AppTab.SETTINGS -> SettingsScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppHeader(tab: AppTab) {
    TopAppBar(
        title = {
            Column {
                Text("FILE MANAGER PRO", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Text(tab.label, style = MaterialTheme.typography.labelSmall, color = Accent)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg),
        actions = {
            Surface(shape = RoundedCornerShape(99.dp), color = Panel2) {
                Text("LOCAL", Modifier.padding(horizontal = 12.dp, vertical = 6.dp), color = Accent, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.width(12.dp))
        }
    )
}

@Composable
private fun BottomTabs(selected: AppTab, onSelect: (AppTab) -> Unit) {
    NavigationBar(containerColor = Panel) {
        AppTab.entries.forEach { tab ->
            val icon = when (tab) {
                AppTab.FILES -> Icons.Default.Folder
                AppTab.SEARCH -> Icons.Default.ManageSearch
                AppTab.TOOLS -> Icons.Default.Build
                AppTab.NETWORK -> Icons.Default.Dns
                AppTab.SETTINGS -> Icons.Default.Tune
            }
            NavigationBarItem(
                selected = tab == selected,
                onClick = { onSelect(tab) },
                icon = { Icon(icon, null) },
                label = { Text(tab.label.substringBefore(' ')) },
                colors = NavigationBarItemDefaults.colors(indicatorColor = Accent.copy(alpha = 0.14f), selectedIconColor = Accent, selectedTextColor = Accent)
            )
        }
    }
}

private enum class PaneSide { LEFT, RIGHT }
private enum class SortMode(val label: String) { NAME("Nama"), SIZE("Saiz"), DATE("Tarikh"), TYPE("Jenis") }
private data class FileSelection(val file: File, val pane: PaneSide)

private enum class FileToolAction(val label: String) {
    OPEN("Buka"), OPEN_WITH("Buka dengan"), TEXT_PREVIEW("Lihat teks"), ARCHIVE_LIST("Lihat arkib"), INSTALL_APK("Pasang APK"),
    VERIFY_APK("Verify signature APK"), SIGN_APK("Sign APK"), INSPECT_KEY("Inspect signing key"), USE_SIGNING_KEY("Guna sebagai signing key"),
    COPY("Salin ke pane sebelah"), MOVE("Pindah ke pane sebelah"), RENAME("Namakan semula"), DUPLICATE("Duplikasi"),
    SHARE("Kongsi"), ZIP("Jadikan ZIP"), EXTRACT("Extract di sini"), SHA256("SHA-256"), MD5("MD5"), COPY_PATH("Salin path"),
    PROPERTIES("Properties"), DELETE("Padam")
}

@Composable
private fun FilesScreen() {
    val repository = remember { LocalFileRepository() }
    val signingLoader = remember { SigningMaterialLoader() }
    val signingService = remember { ApkSigningService(signingLoader) }
    val context = LocalContext.current
    var leftPath by remember { mutableStateOf(Environment.getExternalStorageDirectory()) }
    var rightPath by remember { mutableStateOf(File(Environment.getExternalStorageDirectory(), "Download").takeIf { it.exists() } ?: Environment.getExternalStorageDirectory()) }
    var activePane by remember { mutableStateOf(PaneSide.LEFT) }
    var showHidden by remember { mutableStateOf(false) }
    var sortMode by remember { mutableStateOf(SortMode.NAME) }
    var refresh by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Set<FileSelection>>(emptySet()) }
    var contextTarget by remember { mutableStateOf<FileSelection?>(null) }
    var hashResult by remember { mutableStateOf<Triple<String, String, String>?>(null) }
    var operationMessage by remember { mutableStateOf<String?>(null) }
    var renameTarget by remember { mutableStateOf<FileSelection?>(null) }
    var deleteTargets by remember { mutableStateOf<List<FileSelection>>(emptyList()) }
    var createKind by remember { mutableStateOf<String?>(null) }
    var propertiesText by remember { mutableStateOf<Pair<String, String>?>(null) }
    var previewText by remember { mutableStateOf<Pair<String, String>?>(null) }
    var inspectKeyTarget by remember { mutableStateOf<FileSelection?>(null) }
    var signApkTarget by remember { mutableStateOf<FileSelection?>(null) }
    var preferredSigningKey by remember { mutableStateOf<File?>(null) }
    val scope = rememberCoroutineScope()

    fun currentPath(side: PaneSide) = if (side == PaneSide.LEFT) leftPath else rightPath
    fun oppositePath(side: PaneSide) = if (side == PaneSide.LEFT) rightPath else leftPath
    fun toggleSelection(item: FileSelection) {
        selected = if (selected.isNotEmpty() && selected.first().pane != item.pane) {
            setOf(item)
        } else if (selected.contains(item)) {
            selected - item
        } else {
            selected + item
        }
        activePane = item.pane
    }
    fun afterOperation(message: String, clearSelection: Boolean = false) {
        operationMessage = message
        refresh++
        if (clearSelection) selected = emptySet()
    }

    fun runAction(target: FileSelection, action: FileToolAction) {
        contextTarget = null
        when (action) {
            FileToolAction.OPEN -> {
                if (target.file.isDirectory) {
                    if (target.pane == PaneSide.LEFT) leftPath = target.file else rightPath = target.file
                } else FileIntents.openWith(context, target.file).onFailure { operationMessage = "Tak dapat buka: ${it.message}" }
            }
            FileToolAction.OPEN_WITH -> FileIntents.openWith(context, target.file).onFailure { operationMessage = "Tak dapat buka: ${it.message}" }
            FileToolAction.INSTALL_APK -> FileIntents.installApk(context, target.file).onFailure { operationMessage = "Installer gagal: ${it.message}" }
            FileToolAction.VERIFY_APK -> scope.launch {
                signingService.verify(target.file).fold(
                    onSuccess = { previewText = "APK signature • ${target.file.name}" to it.summary() },
                    onFailure = { operationMessage = "Verify APK gagal: ${it.message}" }
                )
            }
            FileToolAction.SIGN_APK -> {
                if (preferredSigningKey == null) operationMessage = "Pilih fail key dahulu: tap lama key > Guna sebagai signing key"
                else signApkTarget = target
            }
            FileToolAction.INSPECT_KEY -> inspectKeyTarget = target
            FileToolAction.USE_SIGNING_KEY -> { preferredSigningKey = target.file; operationMessage = "Signing key dipilih: ${target.file.name}" }
            FileToolAction.SHARE -> FileIntents.share(context, target.file).onFailure { operationMessage = "Share gagal: ${it.message}" }
            FileToolAction.COPY_PATH -> { FileIntents.copyPath(context, target.file); operationMessage = "Path disalin" }
            FileToolAction.RENAME -> renameTarget = target
            FileToolAction.DELETE -> deleteTargets = listOf(target)
            FileToolAction.TEXT_PREVIEW -> scope.launch {
                repository.readTextPreview(target.file).fold(
                    onSuccess = { previewText = target.file.name to it },
                    onFailure = { operationMessage = "Preview gagal: ${it.message}" }
                )
            }
            FileToolAction.ARCHIVE_LIST -> scope.launch {
                repository.listZipEntries(target.file).fold(
                    onSuccess = { previewText = "Isi ${target.file.name}" to it.joinToString("\n") },
                    onFailure = { operationMessage = "Arkib tak dapat dibaca: ${it.message}" }
                )
            }
            FileToolAction.PROPERTIES -> scope.launch {
                repository.properties(target.file).fold(
                    onSuccess = { p ->
                        propertiesText = target.file.name to buildString {
                            appendLine(p.path)
                            appendLine()
                            appendLine("Saiz: ${formatBytes(p.size)}")
                            appendLine("Fail: ${p.fileCount}")
                            appendLine("Folder: ${p.directoryCount}")
                            appendLine("Diubah: ${formatDate(p.modified)}")
                            appendLine("Read: ${p.readable}   Write: ${p.writable}   Execute: ${p.executable}")
                        }
                    },
                    onFailure = { operationMessage = "Properties gagal: ${it.message}" }
                )
            }
            FileToolAction.SHA256, FileToolAction.MD5 -> scope.launch {
                val algo = if (action == FileToolAction.MD5) "MD5" else "SHA-256"
                repository.hash(target.file, algo).fold(
                    onSuccess = { hashResult = Triple(target.file.name, algo, it) },
                    onFailure = { operationMessage = "Hash gagal: ${it.message}" }
                )
            }
            FileToolAction.COPY -> scope.launch {
                repository.copy(target.file, oppositePath(target.pane)).fold(
                    onSuccess = { afterOperation("Disalin ke ${oppositePath(target.pane).path}") },
                    onFailure = { operationMessage = "Copy gagal: ${it.message}" }
                )
            }
            FileToolAction.MOVE -> scope.launch {
                repository.move(target.file, oppositePath(target.pane)).fold(
                    onSuccess = { afterOperation("Dipindah ke ${oppositePath(target.pane).path}", true) },
                    onFailure = { operationMessage = "Move gagal: ${it.message}" }
                )
            }
            FileToolAction.DUPLICATE -> scope.launch {
                repository.duplicate(target.file).fold(
                    onSuccess = { afterOperation("Duplikasi dibuat: ${it.name}") },
                    onFailure = { operationMessage = "Duplikasi gagal: ${it.message}" }
                )
            }
            FileToolAction.ZIP -> scope.launch {
                repository.zip(target.file, target.file.parentFile ?: currentPath(target.pane)).fold(
                    onSuccess = { afterOperation("ZIP dibuat: ${it.name}") },
                    onFailure = { operationMessage = "ZIP gagal: ${it.message}" }
                )
            }
            FileToolAction.EXTRACT -> scope.launch {
                repository.unzip(target.file, target.file.parentFile ?: currentPath(target.pane)).fold(
                    onSuccess = { afterOperation("Extract siap: ${it.name}") },
                    onFailure = { operationMessage = "Extract gagal: ${it.message}" }
                )
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        AccessBanner()
        Spacer(Modifier.height(8.dp))
        BoxWithConstraints(Modifier.weight(1f)) {
            val wide = maxWidth >= 840.dp
            if (wide) {
                Row(Modifier.fillMaxSize()) {
                    FilePane(
                        modifier = Modifier.weight(1f), side = PaneSide.LEFT, path = leftPath, active = activePane == PaneSide.LEFT,
                        showHidden = showHidden, sortMode = sortMode, refresh = refresh, repository = repository, selected = selected,
                        onActivate = { activePane = PaneSide.LEFT }, onPathChange = { leftPath = it; activePane = PaneSide.LEFT },
                        onToggleSelect = { toggleSelection(FileSelection(it, PaneSide.LEFT)) }, onContext = { contextTarget = FileSelection(it, PaneSide.LEFT); activePane = PaneSide.LEFT },
                        onOpen = { if (it.isDirectory) leftPath = it else FileIntents.openWith(context, it).onFailure { e -> operationMessage = e.message } },
                        onToggleHidden = { showHidden = !showHidden }, onRefresh = { refresh++ }, onSort = { sortMode = it },
                        onNewFolder = { activePane = PaneSide.LEFT; createKind = "folder" }, onNewFile = { activePane = PaneSide.LEFT; createKind = "file" },
                        onSelectAll = { files -> selected = files.map { FileSelection(it, PaneSide.LEFT) }.toSet(); activePane = PaneSide.LEFT }
                    )
                    VerticalDivider(Modifier.padding(horizontal = 6.dp), color = Panel2)
                    FilePane(
                        modifier = Modifier.weight(1f), side = PaneSide.RIGHT, path = rightPath, active = activePane == PaneSide.RIGHT,
                        showHidden = showHidden, sortMode = sortMode, refresh = refresh, repository = repository, selected = selected,
                        onActivate = { activePane = PaneSide.RIGHT }, onPathChange = { rightPath = it; activePane = PaneSide.RIGHT },
                        onToggleSelect = { toggleSelection(FileSelection(it, PaneSide.RIGHT)) }, onContext = { contextTarget = FileSelection(it, PaneSide.RIGHT); activePane = PaneSide.RIGHT },
                        onOpen = { if (it.isDirectory) rightPath = it else FileIntents.openWith(context, it).onFailure { e -> operationMessage = e.message } },
                        onToggleHidden = { showHidden = !showHidden }, onRefresh = { refresh++ }, onSort = { sortMode = it },
                        onNewFolder = { activePane = PaneSide.RIGHT; createKind = "folder" }, onNewFile = { activePane = PaneSide.RIGHT; createKind = "file" },
                        onSelectAll = { files -> selected = files.map { FileSelection(it, PaneSide.RIGHT) }.toSet(); activePane = PaneSide.RIGHT }
                    )
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    PaneSwitcher(activePane, leftPath, rightPath) { activePane = it; selected = emptySet() }
                    Spacer(Modifier.height(6.dp))
                    val side = activePane
                    val path = currentPath(side)
                    FilePane(
                        modifier = Modifier.weight(1f), side = side, path = path, active = true,
                        showHidden = showHidden, sortMode = sortMode, refresh = refresh, repository = repository, selected = selected,
                        onActivate = {}, onPathChange = { if (side == PaneSide.LEFT) leftPath = it else rightPath = it },
                        onToggleSelect = { toggleSelection(FileSelection(it, side)) }, onContext = { contextTarget = FileSelection(it, side) },
                        onOpen = { file -> if (file.isDirectory) { if (side == PaneSide.LEFT) leftPath = file else rightPath = file } else FileIntents.openWith(context, file).onFailure { e -> operationMessage = e.message } },
                        onToggleHidden = { showHidden = !showHidden }, onRefresh = { refresh++ }, onSort = { sortMode = it },
                        onNewFolder = { createKind = "folder" }, onNewFile = { createKind = "file" },
                        onSelectAll = { files -> selected = files.map { FileSelection(it, side) }.toSet() }
                    )
                }
            }
        }

        operationMessage?.let {
            Text(it, color = Accent, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
        }

        if (selected.isNotEmpty()) {
            MultiActionBar(
                count = selected.size,
                destination = oppositePath(selected.first().pane),
                onClose = { selected = emptySet() },
                onCopy = {
                    val batch = selected.toList(); scope.launch {
                        var ok = 0
                        batch.forEach { if (repository.copy(it.file, oppositePath(it.pane)).isSuccess) ok++ }
                        afterOperation("$ok/${batch.size} item disalin", true)
                    }
                },
                onMove = {
                    val batch = selected.toList(); scope.launch {
                        var ok = 0
                        batch.forEach { if (repository.move(it.file, oppositePath(it.pane)).isSuccess) ok++ }
                        afterOperation("$ok/${batch.size} item dipindah", true)
                    }
                },
                onZip = {
                    val batch = selected.toList(); scope.launch {
                        val parent = currentPath(batch.first().pane)
                        repository.zipMany(batch.map { it.file }, parent).fold(
                            onSuccess = { afterOperation("ZIP pilihan dibuat: ${it.name}", true) },
                            onFailure = { operationMessage = "ZIP pilihan gagal: ${it.message}" }
                        )
                    }
                },
                onDelete = { deleteTargets = selected.toList() }
            )
        }
    }

    contextTarget?.let { target ->
        FileToolsSheet(target, onDismiss = { contextTarget = null }, onAction = { runAction(target, it) })
    }

    renameTarget?.let { target ->
        NameDialog(
            title = "Namakan semula", initial = target.file.name, confirmLabel = "RENAME", onDismiss = { renameTarget = null },
            onConfirm = { name ->
                renameTarget = null
                scope.launch {
                    repository.rename(target.file, name).fold(
                        onSuccess = { afterOperation("Dinamakan semula: ${it.name}", true) },
                        onFailure = { operationMessage = "Rename gagal: ${it.message}" }
                    )
                }
            }
        )
    }

    createKind?.let { kind ->
        NameDialog(
            title = if (kind == "folder") "Folder baharu" else "Fail baharu", initial = "", confirmLabel = "CREATE", onDismiss = { createKind = null },
            onConfirm = { name ->
                val parent = currentPath(activePane)
                createKind = null
                scope.launch {
                    val result = if (kind == "folder") repository.createFolder(parent, name) else repository.createFile(parent, name)
                    result.fold(
                        onSuccess = { afterOperation("Dicipta: ${it.name}") },
                        onFailure = { operationMessage = "Create gagal: ${it.message}" }
                    )
                }
            }
        )
    }

    if (deleteTargets.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { deleteTargets = emptyList() },
            icon = { Icon(Icons.Default.WarningAmber, null, tint = Color(0xFFFFC76B)) },
            title = { Text("Padam ${deleteTargets.size} item?") },
            text = { Text("Operasi ini memadam terus dari storage. Semak pilihan sebelum teruskan.") },
            confirmButton = {
                TextButton(onClick = {
                    val batch = deleteTargets; deleteTargets = emptyList()
                    scope.launch {
                        var ok = 0
                        batch.forEach { if (repository.delete(it.file).isSuccess) ok++ }
                        afterOperation("$ok/${batch.size} item dipadam", true)
                    }
                }) { Text("PADAM", color = Color(0xFFFF8B7A)) }
            },
            dismissButton = { TextButton(onClick = { deleteTargets = emptyList() }) { Text("BATAL") } }
        )
    }

    inspectKeyTarget?.let { target ->
        KeyInspectDialog(
            file = target.file,
            onDismiss = { inspectKeyTarget = null },
            onInspect = { password ->
                inspectKeyTarget = null
                scope.launch {
                    signingLoader.inspect(target.file, password.toCharArray()).fold(
                        onSuccess = { info ->
                            previewText = "Signing key • ${target.file.name}" to buildString {
                                appendLine("Format: ${info.format}")
                                appendLine("Private key: ${info.privateKeyDetected}")
                                appendLine("Certificates: ${info.certificateCount}")
                                if (info.aliases.isNotEmpty()) appendLine("Aliases: ${info.aliases.joinToString()}")
                                if (info.keyAliases.isNotEmpty()) appendLine("Key aliases: ${info.keyAliases.joinToString()}")
                                info.notes.forEach { appendLine(it) }
                            }
                        },
                        onFailure = { operationMessage = "Inspect key gagal: ${it.message}" }
                    )
                }
            }
        )
    }

    signApkTarget?.let { target ->
        val key = preferredSigningKey
        if (key != null) {
            ApkSignDialog(
                apk = target.file, keyFile = key,
                onDismiss = { signApkTarget = null },
                onSign = { storePassword, keyPassword, alias, certPath, v4 ->
                    signApkTarget = null
                    scope.launch {
                        signingService.sign(
                            inputApk = target.file, keyFile = key,
                            storePassword = storePassword.toCharArray(),
                            keyPassword = (keyPassword.ifBlank { storePassword }).toCharArray(),
                            alias = alias.ifBlank { null },
                            certificateFile = certPath.takeIf { it.isNotBlank() }?.let(::File),
                            options = ApkSigningService.SignOptions(v1 = true, v2 = true, v3 = true, v4 = v4)
                        ).fold(
                            onSuccess = { (out, report) -> afterOperation("Signed + verified: ${out.name}"); previewText = "Signing result" to report.summary() },
                            onFailure = { operationMessage = "Sign APK gagal: ${it.message}" }
                        )
                    }
                }
            )
        }
    }

    hashResult?.let { (name, algo, hash) ->
        AlertDialog(
            onDismissRequest = { hashResult = null }, confirmButton = { TextButton(onClick = { hashResult = null }) { Text("OK") } },
            title = { Text("$algo • $name") }, text = { SelectionContainer { Text(hash) } }
        )
    }

    propertiesText?.let { (name, text) ->
        AlertDialog(
            onDismissRequest = { propertiesText = null }, confirmButton = { TextButton(onClick = { propertiesText = null }) { Text("OK") } },
            title = { Text(name) }, text = { SelectionContainer { Text(text) } }
        )
    }

    previewText?.let { (name, text) ->
        AlertDialog(
            onDismissRequest = { previewText = null }, confirmButton = { TextButton(onClick = { previewText = null }) { Text("TUTUP") } },
            title = { Text(name) },
            text = { SelectionContainer { Box(Modifier.heightIn(max = 480.dp)) { LazyColumn { item { Text(text, style = MaterialTheme.typography.bodySmall) } } } } }
        )
    }
}

@Composable
private fun PaneSwitcher(active: PaneSide, left: File, right: File, onSelect: (PaneSide) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(PaneSide.LEFT to left, PaneSide.RIGHT to right).forEach { (side, path) ->
            val isSelected = active == side
            Surface(
                color = if (isSelected) Accent.copy(alpha = 0.12f) else Panel,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f).clickable { onSelect(side) }
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                    Text(if (side == PaneSide.LEFT) "PANE A" else "PANE B", color = if (isSelected) Accent else Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Text(path.name.ifBlank { path.path }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun FilePane(
    modifier: Modifier,
    side: PaneSide,
    path: File,
    active: Boolean,
    showHidden: Boolean,
    sortMode: SortMode,
    refresh: Int,
    repository: LocalFileRepository,
    selected: Set<FileSelection>,
    onActivate: () -> Unit,
    onPathChange: (File) -> Unit,
    onToggleSelect: (File) -> Unit,
    onContext: (File) -> Unit,
    onOpen: (File) -> Unit,
    onToggleHidden: () -> Unit,
    onRefresh: () -> Unit,
    onSort: (SortMode) -> Unit,
    onNewFolder: () -> Unit,
    onNewFile: () -> Unit,
    onSelectAll: (List<File>) -> Unit
) {
    val entries by produceState<List<FileEntry>>(initialValue = emptyList(), path, showHidden, refresh, sortMode) {
        val raw = repository.list(path, showHidden)
        value = when (sortMode) {
            SortMode.NAME -> raw.sortedWith(compareBy<FileEntry> { !it.isDirectory }.thenBy { it.file.name.lowercase() })
            SortMode.SIZE -> raw.sortedWith(compareBy<FileEntry> { !it.isDirectory }.thenByDescending { it.size }.thenBy { it.file.name.lowercase() })
            SortMode.DATE -> raw.sortedWith(compareBy<FileEntry> { !it.isDirectory }.thenByDescending { it.modified })
            SortMode.TYPE -> raw.sortedWith(compareBy<FileEntry> { !it.isDirectory }.thenBy { it.file.extension.lowercase() }.thenBy { it.file.name.lowercase() })
        }
    }
    var menuOpen by remember { mutableStateOf(false) }

    Column(modifier.clickable(onClick = onActivate)) {
        Surface(
            color = if (active) Accent.copy(alpha = 0.06f) else Panel,
            border = if (active) androidx.compose.foundation.BorderStroke(1.dp, Accent.copy(alpha = 0.36f)) else null,
            shape = RoundedCornerShape(18.dp)
        ) {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { path.parentFile?.let(onPathChange) }, enabled = path.parentFile != null) { Icon(Icons.Default.ArrowUpward, "Naik") }
                Column(Modifier.weight(1f)) {
                    Text(path.name.ifBlank { path.path }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(path.path, color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh") }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menu folder") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text("Folder baharu") }, leadingIcon = { Icon(Icons.Default.CreateNewFolder, null) }, onClick = { menuOpen = false; onNewFolder() })
                        DropdownMenuItem(text = { Text("Fail baharu") }, leadingIcon = { Icon(Icons.Default.NoteAdd, null) }, onClick = { menuOpen = false; onNewFile() })
                        DropdownMenuItem(text = { Text("Pilih semua") }, leadingIcon = { Icon(Icons.Default.SelectAll, null) }, onClick = { menuOpen = false; onSelectAll(entries.map { it.file }) })
                        HorizontalDivider()
                        SortMode.entries.forEach { mode ->
                            DropdownMenuItem(
                                text = { Text("Susun: ${mode.label}") },
                                leadingIcon = { if (sortMode == mode) Icon(Icons.Default.Check, null) else Icon(Icons.Default.Sort, null) },
                                onClick = { menuOpen = false; onSort(mode) }
                            )
                        }
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text(if (showHidden) "Sembunyikan hidden" else "Tunjuk hidden") },
                            leadingIcon = { Icon(if (showHidden) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) },
                            onClick = { menuOpen = false; onToggleHidden() }
                        )
                    }
                }
            }
        }
        Text(
            "${if (side == PaneSide.LEFT) "A" else "B"} • ${entries.size} item • ${sortMode.label}",
            style = MaterialTheme.typography.labelMedium, color = if (active) Accent else Muted,
            modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 4.dp)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
            items(entries, key = { it.file.path }) { entry ->
                FileRow(
                    file = entry.file, dir = entry.isDirectory, size = entry.size, modified = entry.modified,
                    selected = selected.contains(FileSelection(entry.file, side)), selectionMode = selected.isNotEmpty(),
                    onClick = { if (selected.isNotEmpty()) onToggleSelect(entry.file) else onOpen(entry.file) },
                    onLongClick = { onContext(entry.file) }, onMore = { onContext(entry.file) },
                    onSwipeSelect = { onToggleSelect(entry.file) }, onSwipeTools = { onContext(entry.file) }
                )
            }
        }
    }
}

@Composable
private fun AccessBanner() {
    val context = LocalContext.current
    val allFiles = StorageAccessManager.hasAllFilesAccess()
    Surface(color = if (allFiles) Accent.copy(alpha = 0.10f) else Color(0xFF332516), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (allFiles) Icons.Default.Verified else Icons.Default.Security, null, tint = if (allFiles) Accent else Color(0xFFFFC76B))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (allFiles) "All-files access aktif" else "Akses storage belum penuh", fontWeight = FontWeight.SemiBold)
                Text(if (allFiles) "Shared storage boleh diimbas secara rekursif." else "Aktifkan untuk file manager & deep search.", color = Muted, style = MaterialTheme.typography.labelSmall)
            }
            if (!allFiles) TextButton(onClick = { context.startActivity(StorageAccessManager.allFilesSettingsIntent(context)) }) { Text("ENABLE") }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun FileRow(
    file: File,
    dir: Boolean,
    size: Long,
    modified: Long,
    selected: Boolean,
    selectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onMore: () -> Unit,
    onSwipeSelect: () -> Unit,
    onSwipeTools: () -> Unit
) {
    val haptics = androidx.compose.ui.platform.LocalHapticFeedback.current
    val swipeState = rememberSwipeToDismissBoxState(confirmValueChange = { value ->
        when (value) {
            SwipeToDismissBoxValue.StartToEnd -> onSwipeSelect()
            SwipeToDismissBoxValue.EndToStart -> onSwipeTools()
            SwipeToDismissBoxValue.Settled -> Unit
        }
        false
    })
    SwipeToDismissBox(
        state = swipeState,
        backgroundContent = {
            val direction = swipeState.dismissDirection
            Row(
                Modifier.fillMaxSize().background(if (direction == SwipeToDismissBoxValue.StartToEnd) Accent.copy(alpha = 0.16f) else Panel2).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (direction == SwipeToDismissBoxValue.StartToEnd) Arrangement.Start else Arrangement.End
            ) {
                Icon(if (direction == SwipeToDismissBoxValue.StartToEnd) Icons.Default.DoneAll else Icons.Default.Build, null, tint = Accent)
                Spacer(Modifier.width(8.dp))
                Text(if (direction == SwipeToDismissBoxValue.StartToEnd) "SELECT" else "TOOLS", color = Accent, fontWeight = FontWeight.Bold)
            }
        },
        enableDismissFromStartToEnd = true,
        enableDismissFromEndToStart = true
    ) {
        Surface(color = if (selected) Accent.copy(alpha = 0.10f) else Bg, shape = RoundedCornerShape(12.dp)) {
            Row(
                Modifier.fillMaxWidth().combinedClickable(
                    onClick = onClick,
                    onLongClick = {
                        haptics.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                        onLongClick()
                    },
                    onLongClickLabel = "Buka tools"
                ).padding(horizontal = 10.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selectionMode) {
                    Checkbox(checked = selected, onCheckedChange = { onClick() })
                } else {
                    Surface(shape = RoundedCornerShape(10.dp), color = Panel2) {
                        Icon(if (dir) Icons.Default.Folder else fileIcon(file.name), null, modifier = Modifier.padding(10.dp), tint = if (dir) Accent else Color(0xFFD7DFE8))
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(if (dir) "Folder • ${formatDate(modified)}" else "${formatBytes(size)} • ${formatDate(modified)}", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
                IconButton(onClick = onMore) { Icon(Icons.Default.MoreVert, "Tools") }
            }
        }
    }
}

private fun fileIcon(name: String) = when (name.substringAfterLast('.', "").lowercase()) {
    "apk", "apks", "xapk" -> Icons.Default.Android
    "zip", "7z", "rar", "tar", "gz", "jar", "aar" -> Icons.Default.Inventory2
    "jpg", "jpeg", "png", "webp", "gif", "svg" -> Icons.Default.Image
    "mp4", "mkv", "avi", "mov" -> Icons.Default.Movie
    "mp3", "flac", "wav", "aac" -> Icons.Default.AudioFile
    "kt", "java", "xml", "json", "js", "ts", "py", "sh", "md", "txt", "log", "yaml", "yml" -> Icons.Default.Code
    else -> Icons.Default.InsertDriveFile
}

private fun isTextLike(file: File): Boolean = file.extension.lowercase() in setOf("txt", "md", "log", "json", "xml", "yaml", "yml", "csv", "kt", "java", "js", "ts", "py", "sh", "gradle", "properties", "ini", "conf")
private fun isZipLike(file: File): Boolean = file.extension.lowercase() in setOf("zip", "apk", "jar", "aar", "apks", "xapk")
private fun isSigningFile(file: File): Boolean {
    val ext = file.extension.lowercase()
    if (ext in setOf(
            "jks", "keystore", "ks", "jceks", "p12", "pfx", "pkcs12", "bks", "bcfks", "uber",
            "pem", "key", "pk8", "p8", "pkcs8", "pkcs1", "sec1", "der", "rsa", "ec", "openssh", "jwk", "json",
            "crt", "cer", "cert", "x509", "p7b", "p7c", "pkcs7", "spc"
        )
    ) return true
    return file.name.lowercase() in setOf("id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", "id_ed448")
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FileToolsSheet(target: FileSelection, onDismiss: () -> Unit, onAction: (FileToolAction) -> Unit) {
    val file = target.file
    val actions = buildList {
        add(FileToolAction.OPEN)
        if (!file.isDirectory) add(FileToolAction.OPEN_WITH)
        if (isTextLike(file) && file.isFile) add(FileToolAction.TEXT_PREVIEW)
        if (isZipLike(file) && file.isFile) { add(FileToolAction.ARCHIVE_LIST); add(FileToolAction.EXTRACT) }
        if (file.extension.equals("apk", true)) { add(FileToolAction.INSTALL_APK); add(FileToolAction.VERIFY_APK); add(FileToolAction.SIGN_APK) }
        if (isSigningFile(file) && file.isFile) { add(FileToolAction.INSPECT_KEY); add(FileToolAction.USE_SIGNING_KEY) }
        add(FileToolAction.COPY); add(FileToolAction.MOVE); add(FileToolAction.RENAME); add(FileToolAction.DUPLICATE)
        if (file.isFile) add(FileToolAction.SHARE)
        add(FileToolAction.ZIP)
        if (file.isFile) { add(FileToolAction.SHA256); add(FileToolAction.MD5) }
        add(FileToolAction.COPY_PATH); add(FileToolAction.PROPERTIES); add(FileToolAction.DELETE)
    }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Panel) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(12.dp), color = Panel2) {
                    Icon(if (file.isDirectory) Icons.Default.Folder else fileIcon(file.name), null, Modifier.padding(12.dp), tint = Accent)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(file.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(file.path, color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("QUICK TOOLS", color = Accent, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            actions.chunked(3).forEach { rowActions ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowActions.forEach { action ->
                        Surface(
                            color = if (action == FileToolAction.DELETE) Color(0xFF2A1717) else Panel2,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(1f).clickable { onAction(action) }
                        ) {
                            Column(Modifier.padding(horizontal = 8.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(actionIcon(action), null, tint = if (action == FileToolAction.DELETE) Color(0xFFFF8B7A) else Accent)
                                Spacer(Modifier.height(5.dp))
                                Text(action.label, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                    repeat(3 - rowActions.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

private fun actionIcon(action: FileToolAction) = when (action) {
    FileToolAction.OPEN -> Icons.Default.OpenInNew
    FileToolAction.OPEN_WITH -> Icons.Default.Apps
    FileToolAction.TEXT_PREVIEW -> Icons.Default.Article
    FileToolAction.ARCHIVE_LIST -> Icons.Default.Inventory2
    FileToolAction.INSTALL_APK -> Icons.Default.Android
    FileToolAction.VERIFY_APK -> Icons.Default.VerifiedUser
    FileToolAction.SIGN_APK -> Icons.Default.Draw
    FileToolAction.INSPECT_KEY -> Icons.Default.Key
    FileToolAction.USE_SIGNING_KEY -> Icons.Default.VpnKey
    FileToolAction.COPY -> Icons.Default.ContentCopy
    FileToolAction.MOVE -> Icons.Default.DriveFileMove
    FileToolAction.RENAME -> Icons.Default.DriveFileRenameOutline
    FileToolAction.DUPLICATE -> Icons.Default.FileCopy
    FileToolAction.SHARE -> Icons.Default.Share
    FileToolAction.ZIP -> Icons.Default.Archive
    FileToolAction.EXTRACT -> Icons.Default.Unarchive
    FileToolAction.SHA256, FileToolAction.MD5 -> Icons.Default.Tag
    FileToolAction.COPY_PATH -> Icons.Default.ContentPaste
    FileToolAction.PROPERTIES -> Icons.Default.Info
    FileToolAction.DELETE -> Icons.Default.Delete
}

@Composable
private fun MultiActionBar(
    count: Int,
    destination: File,
    onClose: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onZip: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(color = Panel2, shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text("$count item dipilih", fontWeight = FontWeight.SemiBold)
                    Text("Target: ${destination.path}", color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, null) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                SmallAction(Icons.Default.ContentCopy, "COPY", onCopy)
                SmallAction(Icons.Default.DriveFileMove, "MOVE", onMove)
                SmallAction(Icons.Default.Archive, "ZIP", onZip)
                SmallAction(Icons.Default.Delete, "DELETE", onDelete, warning = true)
            }
        }
    }
}

@Composable
private fun SmallAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, warning: Boolean = false) {
    TextButton(onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = if (warning) Color(0xFFFF8B7A) else Accent)
            Text(label, style = MaterialTheme.typography.labelSmall, color = if (warning) Color(0xFFFF8B7A) else Muted)
        }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = value, onValueChange = { value = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { if (value.isNotBlank()) onConfirm(value) }, enabled = value.isNotBlank()) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("BATAL") } }
    )
}


@Composable
private fun KeyInspectDialog(file: File, onDismiss: () -> Unit, onInspect: (String) -> Unit) {
    var password by remember(file.path) { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Inspect signing key") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(file.name, color = Muted)
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    label = { Text("Store password (jika ada)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { TextButton(onClick = { onInspect(password) }) { Text("INSPECT") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("BATAL") } }
    )
}

@Composable
private fun ApkSignDialog(
    apk: File,
    keyFile: File,
    onDismiss: () -> Unit,
    onSign: (storePassword: String, keyPassword: String, alias: String, certPath: String, v4: Boolean) -> Unit
) {
    var storePassword by remember(apk.path, keyFile.path) { mutableStateOf("") }
    var keyPassword by remember(apk.path, keyFile.path) { mutableStateOf("") }
    var alias by remember(apk.path, keyFile.path) { mutableStateOf("") }
    var certPath by remember(apk.path, keyFile.path) { mutableStateOf("") }
    var v4 by remember(apk.path) { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sign APK") },
        text = {
            LazyColumn(Modifier.heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("APK: ${apk.name}", color = Muted) }
                item { Text("Key: ${keyFile.path}", color = Accent, style = MaterialTheme.typography.bodySmall) }
                item { OutlinedTextField(storePassword, { storePassword = it }, label = { Text("Store password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(keyPassword, { keyPassword = it }, label = { Text("Key password (kosong = sama)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(alias, { alias = it }, label = { Text("Alias (kosong = auto)") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(certPath, { certPath = it }, label = { Text("Cert path untuk raw key (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = v4, onCheckedChange = { v4 = it })
                        Text("Generate APK Signature Scheme v4 (.idsig)")
                    }
                }
                item { Text("v1 + v2 + v3 sentiasa diaktifkan. Output ditulis ke staging, diverify, kemudian baru commit.", color = Muted, style = MaterialTheme.typography.labelSmall) }
            }
        },
        confirmButton = { TextButton(onClick = { onSign(storePassword, keyPassword, alias, certPath, v4) }) { Text("SIGN + VERIFY") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("BATAL") } }
    )
}


@Composable
private fun SearchScreen(vm: DeepSearchViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Search beyond folders", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
        Text("Nama + kandungan + nested ZIP/APK/JAR + binary strings", color = Muted)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(state.query, vm::setQuery, modifier = Modifier.fillMaxWidth(), label = { Text("Query / regex") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(state.rootPath, vm::setRoot, modifier = Modifier.fillMaxWidth(), label = { Text("Root path") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        FlowOptions(
            listOf(
                Triple("Regex", state.regex, vm::toggleRegex),
                Triple("Case", state.caseSensitive, vm::toggleCase),
                Triple("Archives", state.scanArchives, vm::toggleArchives),
                Triple("Binary strings", state.scanBinaryStrings, vm::toggleBinary)
            )
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.start() }, enabled = !state.running && state.query.isNotBlank(), modifier = Modifier.weight(1f)) { Icon(Icons.Default.Radar, null); Spacer(Modifier.width(8.dp)); Text("DEEP SCAN") }
            if (state.running) OutlinedButton(onClick = vm::cancel) { Text("STOP") }
        }
        state.progress?.let { p ->
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text("${p.scannedFiles} files • ${p.scannedDirectories} folders • ${p.scannedArchiveEntries} archive entries", color = Muted, style = MaterialTheme.typography.labelSmall)
            Text(p.currentPath, color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(10.dp))
        Text("${state.results.size} matches", fontWeight = FontWeight.SemiBold)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(state.results) { hit ->
                Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(hit.type.label(), color = Accent, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Text(hit.displayPath, fontWeight = FontWeight.Medium)
                        hit.snippet?.let { SelectionContainer { Text(it, color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis) } }
                    }
                }
            }
        }
    }
}

private fun SearchHitType.label() = when (this) {
    SearchHitType.FILE_NAME -> "FILE NAME"
    SearchHitType.FILE_CONTENT -> "FILE CONTENT"
    SearchHitType.ARCHIVE_ENTRY_NAME -> "INSIDE ARCHIVE"
    SearchHitType.ARCHIVE_CONTENT -> "ARCHIVE CONTENT"
}

@Composable
private fun FlowOptions(options: List<Triple<String, Boolean, () -> Unit>>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (label, enabled, action) ->
            FilterChip(selected = enabled, onClick = action, label = { Text(label) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Accent.copy(alpha = 0.16f), selectedLabelColor = Accent))
        }
    }
}

@Composable
private fun ToolsScreen() {
    val liveGroups = listOf(
        "File operations" to listOf(
            "Copy / move / rename / duplicate / delete",
            "Create folder / file",
            "Multi-select batch copy / move / ZIP / delete",
            "Properties + copy path",
            "Open with + share + APK installer",
            "APK sign + verify v1/v2/v3/v3.1 detect/v4 idsig",
            "Signing key inspect + select (JKS/PKCS12/BKS/BCFKS/PEM/DER...)"
        ),
        "Archive" to listOf(
            "Create ZIP",
            "Extract ZIP-family with path traversal guard",
            "List ZIP / APK / JAR / AAR / APKS / XAPK entries"
        ),
        "Inspection" to listOf(
            "Text preview",
            "SHA-256 + MD5",
            "Deep Search through folders and nested ZIP-family archives"
        ),
        "Power navigation" to listOf(
            "Pane A / Pane B",
            "Long-press contextual tool sheet",
            "Swipe SELECT / TOOLS",
            "Per-pane three-dot overflow + sorting"
        )
    )
    val planned = listOf(
        "SMB / SFTP / WebDAV / S3 remote VFS",
        "7z / RAR / TAR writable archive workspace",
        "Hex + code editor",
        "APK DEX/resources rebuild workspace",
        "Shizuku / root VFS",
        "Operation journal + undo / trash",
        "Storage heatmap + duplicate finder"
    )

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Tool Deck", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text("v1.1 release tools. LIVE means the action has a real handler.", color = Muted)
        }
        liveGroups.forEach { (title, tools) ->
            item {
                Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(title.uppercase(), color = Accent, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            StatusPill("LIVE", true)
                        }
                        Spacer(Modifier.height(8.dp))
                        tools.forEach { tool ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, null, tint = Accent, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(tool, Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("NEXT MODULES", color = Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        StatusPill("MODULE", false)
                    }
                    Spacer(Modifier.height(8.dp))
                    planned.forEach { tool ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, null, tint = Muted, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(tool, Modifier.weight(1f), color = Muted)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("These entries are intentionally non-clickable until their backend exists.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun NetworkScreen() {
    val protocols = listOf("SMB / CIFS", "SFTP / SCP", "WebDAV", "FTP / FTPS", "S3 compatible", "HTTP file server", "Nearby LAN transfer", "SSH terminal")
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Network Spaces", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text("Remote backends are staged modules and do not request network permissions in v1.0.", color = Muted)
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, null, tint = Accent)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Minimal permission release")
                        Text("Network permissions stay out until a protocol backend is actually enabled.", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                    StatusPill("LIVE", true)
                }
            }
        }
        items(protocols) { protocol ->
            Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storage, null, tint = Muted)
                    Spacer(Modifier.width(12.dp))
                    Text(protocol, Modifier.weight(1f), color = Muted)
                    StatusPill("MODULE", false)
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    val context = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Control Center", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text("Release v1.0.0 - local-first power file manager", color = Muted)
        }
        item { SettingsCard("Storage access", "Open Android all-files access settings", Icons.Default.FolderShared, status = "LIVE", enabled = true) { context.startActivity(StorageAccessManager.allFilesSettingsIntent(context)) } }
        item { SettingsCard("Deep Search safety", "Depth 64 - archive depth 4 - content scan 8 MiB per entry", Icons.Default.ManageSearch, status = "LIVE") {} }
        item { SettingsCard("Archive safety", "Entry/expanded-byte quotas and path traversal protection", Icons.Default.Security, status = "LIVE") {} }
        item { SettingsCard("Release privacy", "Offline core; no analytics or account required", Icons.Default.PrivacyTip, status = "LIVE") {} }
        item { SettingsCard("Privileged access", "Shizuku / root backend", Icons.Default.AdminPanelSettings, status = "MODULE") {} }
        item { SettingsCard("Operation journal", "Undo / trash / rollback transactions", Icons.Default.History, status = "MODULE") {} }
        item { SettingsCard("Plugin sandbox", "Signed plugins and scoped capability manifest", Icons.Default.Extension, status = "MODULE") {} }
    }
}

@Composable
private fun StatusPill(label: String, live: Boolean) {
    Surface(shape = RoundedCornerShape(99.dp), color = if (live) Accent.copy(alpha = 0.14f) else Panel2) {
        Text(label, Modifier.padding(horizontal = 9.dp, vertical = 4.dp), color = if (live) Accent else Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SettingsCard(
    title: String,
    detail: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    status: String,
    enabled: Boolean = false,
    onClick: () -> Unit
) {
    val modifier = if (enabled) Modifier.fillMaxWidth().clickable(onClick = onClick) else Modifier.fillMaxWidth()
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) {
                Icon(icon, null, Modifier.padding(10.dp), tint = if (enabled) Accent else Muted)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = if (status == "LIVE") MaterialTheme.colorScheme.onSurface else Muted)
                Text(detail, color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            StatusPill(status, status == "LIVE")
        }
    }
}
