package com.filemanagerpro.app.storage

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings

enum class AccessTier(val title: String, val detail: String) {
    APP("App", "Akses direktori aplikasi sahaja"),
    SAF("SAF", "Folder yang pengguna pilih melalui Storage Access Framework"),
    ALL_FILES("All files", "Shared storage melalui MANAGE_EXTERNAL_STORAGE"),
    SHIZUKU("Shizuku", "Identiti shell/ADB jika servis tersedia"),
    ROOT("Root", "Akses su/root jika peranti membenarkan")
}

object StorageAccessManager {
    fun hasAllFilesAccess(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()

    fun allFilesSettingsIntent(context: Context): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        }
    }
}
