package com.filemanagerpro.app.signing

import com.android.apksig.ApkSigner
import com.android.apksig.ApkVerifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ApkSigningService(
    private val loader: SigningMaterialLoader = SigningMaterialLoader()
) {
    data class SignOptions(
        val v1: Boolean = true,
        val v2: Boolean = true,
        val v3: Boolean = true,
        val v4: Boolean = false
    )

    data class VerifyReport(
        val verified: Boolean,
        val v1: Boolean,
        val v2: Boolean,
        val v3: Boolean,
        val v31: Boolean,
        val v4: Boolean,
        val signerSha256: List<String>,
        val errors: List<String>,
        val warnings: List<String>
    ) {
        fun summary(): String = buildString {
            appendLine(if (verified) "VERIFIED" else "NOT VERIFIED")
            appendLine("v1=$v1  v2=$v2  v3=$v3  v3.1=$v31  v4=$v4")
            if (signerSha256.isNotEmpty()) {
                appendLine()
                appendLine("Signer SHA-256:")
                signerSha256.forEach { appendLine(it) }
            }
            if (errors.isNotEmpty()) {
                appendLine()
                appendLine("Errors:")
                errors.forEach { appendLine("- $it") }
            }
            if (warnings.isNotEmpty()) {
                appendLine()
                appendLine("Warnings:")
                warnings.forEach { appendLine("- $it") }
            }
        }
    }

    suspend fun sign(
        inputApk: File,
        keyFile: File,
        outputDirectory: File = inputApk.parentFile ?: File("."),
        storePassword: CharArray = charArrayOf(),
        keyPassword: CharArray = storePassword,
        alias: String? = null,
        certificateFile: File? = null,
        options: SignOptions = SignOptions()
    ): Result<Pair<File, VerifyReport>> = withContext(Dispatchers.IO) {
        runCatching {
            require(inputApk.isFile && inputApk.extension.equals("apk", true)) { "Input bukan APK" }
            require(options.v1 || options.v2 || options.v3) { "Aktifkan sekurang-kurangnya v1/v2/v3" }
            if (options.v4) require(options.v2 || options.v3) { "APK Signature Scheme v4 memerlukan v2 atau v3" }

            val material = loader.load(keyFile, storePassword, keyPassword, alias, certificateFile).getOrThrow()
            val apkKeyAlgorithm = material.privateKey.algorithm.uppercase()
            require(apkKeyAlgorithm in setOf("RSA", "EC", "ECDSA", "DSA")) {
                "Format key berjaya dibaca (${material.privateKey.algorithm}), tetapi algoritma ini bukan algoritma APK signing Android yang disokong oleh apksig"
            }
            val output = keepBoth(File(outputDirectory, "${inputApk.nameWithoutExtension}-signed.apk"))
            val staging = File(outputDirectory, ".${output.name}.fmp-sign-${System.nanoTime()}")
            val stagingIdsig = File(staging.path + ".idsig")
            try {
                val signer = ApkSigner.SignerConfig.Builder(material.alias, material.privateKey, material.certificates).build()
                val builder = ApkSigner.Builder(listOf(signer))
                    .setInputApk(inputApk)
                    .setOutputApk(staging)
                    .setV1SigningEnabled(options.v1)
                    .setV2SigningEnabled(options.v2)
                    .setV3SigningEnabled(options.v3)
                    .setV4SigningEnabled(options.v4)
                if (options.v4) builder.setV4SignatureOutputFile(stagingIdsig)
                builder.build().sign()

                val report = verifyInternal(staging, stagingIdsig.takeIf { options.v4 && it.isFile })
                require(report.verified) { "APK siap ditandatangani tetapi verification gagal: ${report.errors.joinToString()}" }
                require(staging.renameTo(output)) { "Gagal commit signed APK" }
                if (options.v4 && stagingIdsig.exists()) {
                    val finalIdsig = File(output.path + ".idsig")
                    if (finalIdsig.exists()) finalIdsig.delete()
                    require(stagingIdsig.renameTo(finalIdsig)) { "APK siap tetapi gagal commit .idsig" }
                }
                output to report
            } catch (t: Throwable) {
                staging.delete()
                stagingIdsig.delete()
                throw t
            }
        }
    }

    suspend fun verify(apk: File): Result<VerifyReport> = withContext(Dispatchers.IO) {
        runCatching {
            require(apk.isFile) { "APK tidak wujud" }
            val idsig = File(apk.path + ".idsig").takeIf { it.isFile }
            verifyInternal(apk, idsig)
        }
    }

    private fun verifyInternal(apk: File, idsig: File?): VerifyReport {
        val builder = ApkVerifier.Builder(apk)
        if (idsig != null) builder.setV4SignatureFile(idsig)
        val result = builder.build().verify()
        val digests = result.signerCertificates.map { cert ->
            java.security.MessageDigest.getInstance("SHA-256").digest(cert.encoded)
                .joinToString(":") { "%02X".format(it) }
        }
        return VerifyReport(
            verified = result.isVerified,
            v1 = result.isVerifiedUsingV1Scheme,
            v2 = result.isVerifiedUsingV2Scheme,
            v3 = result.isVerifiedUsingV3Scheme,
            v31 = result.isVerifiedUsingV31Scheme,
            v4 = result.isVerifiedUsingV4Scheme,
            signerSha256 = digests,
            errors = result.errors.map { it.toString() },
            warnings = result.warnings.map { it.toString() }
        )
    }

    private fun keepBoth(requested: File): File {
        if (!requested.exists()) return requested
        val base = requested.nameWithoutExtension
        val ext = requested.extension.takeIf { it.isNotBlank() }?.let { ".$it" } ?: ""
        var i = 2
        while (true) {
            val candidate = File(requested.parentFile, "$base ($i)$ext")
            if (!candidate.exists()) return candidate
            i++
        }
    }
}
