package com.filemanagerpro.app.search

import java.io.File

enum class SearchHitType { FILE_NAME, FILE_CONTENT, ARCHIVE_ENTRY_NAME, ARCHIVE_CONTENT }

data class DeepSearchRequest(
    val roots: List<File>,
    val query: String,
    val searchNames: Boolean = true,
    val searchContents: Boolean = true,
    val regex: Boolean = false,
    val caseSensitive: Boolean = false,
    val includeHidden: Boolean = false,
    val scanArchives: Boolean = true,
    val scanBinaryStrings: Boolean = true,
    val maxDirectoryDepth: Int = 64,
    val maxArchiveDepth: Int = 4,
    val maxArchiveEntries: Long = 100_000,
    val maxExpandedBytes: Long = 512L * 1024 * 1024,
    val includeExtensions: Set<String> = emptySet(),
    val excludeExtensions: Set<String> = emptySet()
)

data class SearchHit(
    val type: SearchHitType,
    val displayPath: String,
    val physicalFile: File,
    val size: Long,
    val snippet: String? = null,
    val archiveDepth: Int = 0
)

data class SearchProgress(
    val scannedFiles: Long,
    val scannedDirectories: Long,
    val scannedArchiveEntries: Long,
    val currentPath: String
)
