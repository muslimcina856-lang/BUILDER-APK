package com.filemanagerpro.app.search

import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class DeepSearchEngineTest {
    @Test
    fun findsTextInsideNestedArchive() = runBlocking {
        val root = createTempDir(prefix = "fmp-search-")
        try {
            File(root, "plain.txt").writeText("alpha needle omega")
            val inner = zipBytes("deep.txt", "deep needle value".toByteArray())
            ZipOutputStream(File(root, "outer.zip").outputStream()).use { zip ->
                zip.putNextEntry(ZipEntry("inner.zip"))
                zip.write(inner)
                zip.closeEntry()
            }

            val hits = DeepSearchEngine()
                .search(DeepSearchRequest(listOf(root), "needle"))
                .toList()

            assertTrue(hits.any { it.displayPath.endsWith("plain.txt") })
            assertTrue(hits.any { it.displayPath.contains("outer.zip › inner.zip › deep.txt") })
        } finally {
            root.deleteRecursively()
        }
    }

    private fun zipBytes(name: String, content: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            zip.putNextEntry(ZipEntry(name))
            zip.write(content)
            zip.closeEntry()
        }
        return out.toByteArray()
    }
}
