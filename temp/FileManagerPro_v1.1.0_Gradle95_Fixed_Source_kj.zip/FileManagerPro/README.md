# File Manager Pro 1.1.0

Native Android/Kotlin release-candidate source for a local-first power file manager.

## Release interaction model
- Tap a folder: open it.
- Tap a file: open it with Android unless multi-select is active.
- Long press any row: haptic feedback + contextual tool sheet.
- Swipe right: select/unselect the item.
- Swipe left: open contextual tools. The row snaps back; swipe never deletes directly.
- Per-file three-dot menu: opens the same contextual tool sheet.
- Per-pane three-dot menu: create folder/file, select all, sort, show/hide hidden files.
- Multi-select action bar: batch copy, move, create one Selection.zip, or delete with confirmation.

## LIVE in v1.1.0
- Pane A / Pane B workflow. Phones switch panes; wide screens show both panes.
- Local file browse, parent navigation, hidden-file toggle and sorting by name/size/date/type.
- Create folder and empty file.
- Copy, move, rename, duplicate and recursive delete. Name collisions default to Keep Both instead of silent overwrite.
- Multi-select batch copy/move/ZIP/delete.
- Open with Android, share through FileProvider, install APK through Android package installer.
- File properties and copy absolute path.
- SHA-256 and MD5.
- Text preview with a bounded read size.
- Create ZIP, list ZIP-family entries and transactionally extract with path-traversal/rollback guards.
- Deep recursive search through subdirectories.
- Name and streaming content search in ordinary files, including files larger than the former 8 MiB scan cap.
- ZIP/APK/JAR/AAR/APKS/XAPK traversal, including large nested ZIP-family containers streamed through temporary files.
- Printable binary-string search.
- Regex, case sensitivity, archive/binary toggles, streaming progress and cancellation.
- APK signature verification and signing with staged sign -> verify -> commit behavior.
- APK Signature Scheme v1/v2/v3 signing with optional v4 `.idsig`; verification reports v1/v2/v3/v3.1/v4.
- Signing Key Manager with portable JKS/JCEKS handling plus PKCS12/PFX, BKS, BCFKS, UBER, PEM/DER, PKCS#8, PKCS#1, SEC1, JWK and X.509/PKCS#7 certificate inputs.
- Archive-entry, global expanded-byte and depth quotas.

## Staged modules, intentionally disabled
Network VFS, 7z/RAR/TAR writable workspace, hex/code editor, full APK DEX/resources rebuild pipeline, Shizuku/root VFS, operation journal/undo, storage heatmap and duplicate finder remain modules. The release UI labels them MODULE and does not expose fake clickable actions.

## Permission surface
v1.1.0 declares only:
- `MANAGE_EXTERNAL_STORAGE` for the file-manager storage use case.
- `REQUEST_INSTALL_PACKAGES` for the explicit Install APK tool.

Network, notification, background-service, media and package-query permissions are not declared until a live feature requires them.

## Build target
- Android API 37
- minSdk 26
- AGP 9.3.0
- Kotlin 2.3.21
- Compose BOM 2026.06.00
- Java 17
- versionCode 10100
- versionName 1.1.0

Open the project in Android Studio with Android SDK 37 installed. This source archive does not bundle an Android SDK or Gradle distribution.

## Deep Search defaults
- Directory depth: 64
- Archive depth: 4
- Ordinary-file content scan: streaming; no fixed per-file 8 MiB cap
- Nested ZIP-family scan: streamed to bounded temporary storage
- Max archive entries: 100,000
- Max expanded archive bytes: 512 MiB

## Verification performed in this environment
The Android UI module could not be Gradle/SDK-built here because no Android SDK, Gradle distribution, `android.jar`, `sdkmanager`, or `apksigner` is installed and this runtime cannot fetch a toolchain.

The pure Kotlin release core and signing-material loader were compiled with the available Kotlin compiler. Core, large-file, large-nested-archive, collision/rollback and signing-format regressions passed. The signing loader was exercised against JKS, JCEKS, PKCS12/PFX, BKS, BCFKS, UBER, PEM/DER, encrypted and unencrypted PKCS#8, PKCS#1, X.509/PKCS#7 and JWK RSA/EC fixtures.

See:
- `docs/RELEASE_NOTES_1.1.0.md`
- `docs/SIGNING_FORMAT_MATRIX.md`
- `docs/INTERACTION_GUIDE.md`
- `docs/RELEASE_BUILD.md`
- `docs/FEATURE_MATRIX.md`
- `docs/TEST_REPORT.md`
