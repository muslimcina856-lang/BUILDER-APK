import 'dart:async';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  List<CameraDescription> cameras = [];
  try {
    cameras = await availableCameras();
  } catch (e) {
    debugPrint("No camera hardware detected in Flutter driver initialization environment.");
  }

  runApp(const VoidCameraProApp());
}

class VoidCameraProApp extends StatelessWidget {
  const VoidCameraProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Void Camera Pro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFFE9B824),
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFE9B824),
          secondary: Color(0xFFE9B824),
        ),
      ),
      home: const CameraPortalScreen(),
    );
  }
}

class CameraPortalScreen extends StatefulWidget {
  const CameraPortalScreen({super.key});

  @override
  State<CameraPortalScreen> createState() => _CameraPortalScreenState();
}

class _CameraPortalScreenState extends State<CameraPortalScreen> {
  // Mode selection: NIGHT, VIDEO, PHOTO, PORTRAIT
  String selectedMode = 'PHOTO';

  // Flash mode: 0 = Off, 1 = On, 2 = Auto
  int flashState = 2; 

  // Aspect ratio state: '16:9' or '4:3'
  String activeAspectRatio = '16:9';

  // Toggle flags for system grid and AI Processing HDR
  bool isGridEnabled = false;
  bool isHdrEnabled = true;

  // Zoom management range
  double zoomRatio = 1.0;

  // Portrait mode: Simulated Bokeh/Blur Intensity
  double portraitBlurIntensity = 10.0;

  // Filters
  final List<String> filtersList = ['Normal', 'Cosmic', 'Warm Noir', 'Vaporwave', 'Cyberpunk', 'Opal'];
  String activeFilter = 'Normal';

  // Thumbnail registry list
  final List<String> capturedImages = [];
  String? lastCapturedUri;

  // Video recording states and duration counter
  bool isRecordingVideo = false;
  int recordingSeconds = 0;
  Timer? videoTimer;

  // Screen darkening shutter effect flag (0.5 seconds)
  bool isShutterEffectActive = false;

  // AI motion de-blur scanning HUD overlay triggers
  bool isAiDeblurring = false;
  String? processingMessage;

  void toggleFlash() {
    setState(() {
      flashState = (flashState + 1) % 3;
      String status = flashState == 0 ? "Off" : (flashState == 1 ? "On" : "Auto");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Flash set to $status'), duration: const Duration(milliseconds: 600)),
      );
    });
  }

  void captureMedia() {
    if (selectedMode == 'VIDEO') {
      if (isRecordingVideo) {
        // Stop recording
        setState(() {
          isRecordingVideo = false;
          videoTimer?.cancel();
          lastCapturedUri = 'assets/simulated_video.jpg';
          capturedImages.add(lastCapturedUri!);
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Video saved successfully!')),
        );
      } else {
        // Start recording
        setState(() {
          isRecordingVideo = true;
          recordingSeconds = 0;
        });
        videoTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
          setState(() {
            recordingSeconds++;
          });
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Video recording started...')),
        );
      }
      return;
    }

    // Image capture process
    setState(() {
      isShutterEffectActive = true;
    });

    // Exact premium 0.5s screen darkening transition
    Future.delayed(const Duration(milliseconds: 500), () {
      setState(() {
        isShutterEffectActive = false;
        
        if (selectedMode == 'NIGHT') {
          processingMessage = 'Exposing Night sight, hold steady...';
        } else if (selectedMode == 'PORTRAIT') {
          processingMessage = 'Rendering Depth & Aperture blur...';
        } else if (activeFilter != 'Normal') {
          processingMessage = 'Applying filter: $activeFilter...';
        }
      });

      // Simulated exposure completion latency
      int latency = selectedMode == 'NIGHT' ? 1500 : (selectedMode == 'PORTRAIT' ? 1000 : 300);

      Future.delayed(Duration(milliseconds: latency), () {
        setState(() {
          processingMessage = null;
          lastCapturedUri = 'assets/captured_image_${DateTime.now().millisecondsSinceEpoch}.jpg';
          capturedImages.add(lastCapturedUri!);
          
          // Trigger automated AI motion de-blur scanning
          isAiDeblurring = true;
        });

        Future.delayed(const Duration(milliseconds: 1200), () {
          setState(() {
            isAiDeblurring = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('[AI] Photo motion de-blurred and sharpened successfully!'),
              backgroundColor: Color(0xFF00FFCC),
            ),
          );
        });
      });
    });
  }

  @override
  void dispose() {
    videoTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // 1. MAIN SYSTEM RUNTIME VIEWPORT (Full preview or 16:9 / 4:3)
          Positioned.fill(
            child: Container(color: Colors.black),
          ),
          
          Center(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12.0),
              child: AspectRatio(
                aspectRatio: activeAspectRatio == '16:9' ? 9 / 16 : 3 / 4,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.grey[900],
                    border: Border.all(color: const Color(0xFFE9B824).withOpacity(0.3), width: 1.0),
                  ),
                  child: Stack(
                    children: [
                      // Simulated Live Camera Viewport
                      const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.camera_enhance, size: 48, color: Colors.white24),
                            SizedBox(height: 8),
                            Text("VOID COHERENT ENGINE ACTIVE", style: TextStyle(color: Colors.white24, fontSize: 11, letterSpacing: 1.5)),
                          ],
                        ),
                      ),
                      
                      // Composition lines grid overlay
                      if (isGridEnabled)
                        Positioned.fill(
                          child: CustomPaint(
                            painter: CameraGridPainter(),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // 2. GRADIENT TOP COVER
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 140,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black.withOpacity(0.8), Colors.transparent],
                ),
              ),
            ),
          ),

          // 3. TOP BAR INTERACTIVE SYSTEM BUTTON CONTROLS
          Positioned(
            top: 50,
            left: 16,
            right: 16,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Top Left: Flash & Aspect ratio
                Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        flashState == 0
                            ? Icons.flash_off
                            : (flashState == 1 ? Icons.flash_on : Icons.flash_auto),
                        color: flashState == 0 ? Colors.white : const Color(0xFFE9B824),
                      ),
                      onPressed: toggleFlash,
                    ),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          activeAspectRatio = activeAspectRatio == '16:9' ? '4:3' : '16:9';
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(
                          activeAspectRatio,
                          style: const TextStyle(color: Color(0xFFE9B824), fontWeight: FontWeight.bold, fontSize: 11),
                        ),
                      ),
                    ),
                  ],
                ),

                // Top Middle: AI Scene Optimizer Toggle
                GestureDetector(
                  onTap: () {
                    setState(() {
                      isHdrEnabled = !isHdrEnabled;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: isHdrEnabled ? const Color(0xFFE9B824).withOpacity(0.2) : Colors.white10,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isHdrEnabled ? const Color(0xFFE9B824) : Colors.white24,
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: isHdrEnabled ? const Color(0xFFE9B824) : Colors.grey,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          isHdrEnabled ? "AI HDR" : "RAW",
                          style: TextStyle(color: isHdrEnabled ? const Color(0xFFE9B824) : Colors.white, fontSize: 10),
                        ),
                      ],
                    ),
                  ),
                ),

                // Top Right: Front/Back Camera Trigger & Grid
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.grid_on, color: isGridEnabled ? const Color(0xFFE9B824) : Colors.white),
                      onPressed: () {
                        setState(() {
                          isGridEnabled = !isGridEnabled;
                        });
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.flip_camera_android, color: Colors.white),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Switched facing direction'), duration: Duration(milliseconds: 500)),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),

          // 4. VIDEO RUNTIME TIMER OVERLAY
          if (isRecordingVideo)
            Positioned(
              top: 110,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red, width: 1.0),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.fiber_manual_record, color: Colors.red, size: 12),
                      const SizedBox(width: 6),
                      Text(
                        "REC ${recordingSeconds ~/ 60}:${(recordingSeconds % 60).toString().padLeft(2, '0')}",
                        style: const TextStyle(color: Colors.white, fontSize: 12, letterSpacing: 1.5, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // 5. SHUTTER PREMIUM DARK FLASH EFFECT OVERLAY
          if (isShutterEffectActive)
            Positioned.fill(
              child: Container(color: Colors.black),
            ),

          // 6. PROCESSING ON-SCREEN DIALOG
          if (processingMessage != null)
            Positioned.fill(
              child: Container(
                color: Colors.black45,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white10),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const CircularProgressIndicator(color: Color(0xFFE9B824)),
                        const SizedBox(height: 16),
                        Text(processingMessage!, style: const TextStyle(color: Colors.white, fontSize: 13)),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          // 7. HIGH-FIDELITY AI DE-BLUR SWEEPER OVERLAY
          if (isAiDeblurring)
            Positioned.fill(
              child: Stack(
                children: [
                  Container(color: Colors.black38),
                  
                  // Sweeping laser animation
                  const Positioned.fill(
                    child: LaserDeBlurSweeper(),
                  ),
                  
                  // Central status panel
                  Center(
                    child: Container(
                      width: 280,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0D1B1E).withOpacity(0.95),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFF00FFCC), width: 1.5),
                      ),
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.auto_awesome, color: Color(0xFF00FFCC), size: 36),
                          SizedBox(height: 12),
                          Text("AI DE-BLUR RUNNING", style: TextStyle(color: Color(0xFF00FFCC), fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 2.0)),
                          SizedBox(height: 4),
                          Text(
                            "Eliminating camera hand wobble motion vectors...",
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white70, fontSize: 11),
                          ),
                          SizedBox(height: 16),
                          LinearProgressIndicator(
                            color: Color(0xFF00FFCC),
                            backgroundColor: Colors.white10,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

          // 8. SOVEREIGN BOTTOM PANEL CONTROLS
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black, Colors.black.withOpacity(0.8), Colors.transparent],
                ),
              ),
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // LENS FILTERS SELECTOR ROW
                  Container(
                    height: 38,
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: filtersList.length,
                      itemBuilder: (context, idx) {
                        final filter = filtersList[idx];
                        final isSelected = activeFilter == filter;
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              activeFilter = filter;
                            });
                          },
                          child: Container(
                            alignment: Alignment.center,
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: isSelected ? const Color(0xFFE9B824) : Colors.black54,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: isSelected ? const Color(0xFFE9B824) : Colors.white10),
                            ),
                            child: Text(
                              filter.toUpperCase(),
                              style: TextStyle(color: isSelected ? Colors.black : Colors.white, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.0),
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  // PORTRAIT BOKEH ACCENT SLIDER
                  if (selectedMode == 'PORTRAIT')
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text("PORTRAIT BOKEH ACCENT", style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                              Text("f/${(22.0 - portraitBlurIntensity).toStringAsFixed(1)} (Blur ${(portraitBlurIntensity * 5).toInt()}%)", style: const TextStyle(color: Color(0xFFE9B824), fontSize: 10, fontWeight: FontWeight.bold)),
                            ],
                          ),
                          Slider(
                            value: portraitBlurIntensity,
                            min: 2,
                            max: 20,
                            activeColor: const Color(0xFFE9B824),
                            inactiveColor: Colors.white24,
                            onChanged: (newValue) {
                              setState(() {
                                portraitBlurIntensity = newValue;
                              });
                            },
                          ),
                        ],
                      ),
                    ),

                  // CONTINUOUS ZOOM RANGE CONTROL SLIDER
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("CONTINUOUS ZOOM RANGE", style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.0)),
                            Text("${zoomRatio.toStringAsFixed(1)}x ratio", style: const TextStyle(color: Color(0xFFE9B824), fontSize: 10, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        Slider(
                          value: zoomRatio,
                          min: 1.0,
                          max: 20.0,
                          activeColor: const Color(0xFFE9B824),
                          inactiveColor: Colors.white24,
                          onChanged: (val) {
                            setState(() {
                              zoomRatio = val;
                            });
                          },
                        ),
                      ],
                    ),
                  ),

                  // 1x | 5x | 10x | 20x SHORTCUT ZOOM DIALS
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [1.0, 5.0, 10.0, 20.0].map((step) {
                      final isSelected = (zoomRatio - step).abs() < 2.0;
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            zoomRatio = step;
                          });
                        },
                        child: Container(
                          width: 38,
                          height: 38,
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: isSelected ? const Color(0xFFE9B824) : Colors.black45,
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            "${step.toInt()}x",
                            style: TextStyle(color: isSelected ? Colors.black : Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ),
                      );
                    }).toList(),
                  ),

                  const SizedBox(height: 12),

                  // HORIZONTAL MODE SWIPE BAR: NIGHT • VIDEO • PHOTO • PORTRAIT
                  Container(
                    height: 40,
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: ['NIGHT', 'VIDEO', 'PHOTO', 'PORTRAIT'].map((mode) {
                        final isCurrent = mode == selectedMode;
                        return GestureDetector(
                          onTap: () {
                            if (isRecordingVideo) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Please stop video recording first.')),
                              );
                              return;
                            }
                            setState(() {
                              selectedMode = mode;
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            child: Text(
                              mode,
                              style: TextStyle(
                                color: isCurrent ? const Color(0xFFE9B824) : Colors.white30,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),

                  // SHUTTER CONTROLS ROW (Gallery, Shutter, AI Mode Indicator)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        // Left: Gallery Thumbnail Indicator
                        GestureDetector(
                          onTap: () {
                            showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                backgroundColor: const Color(0xFF141416),
                                title: const Text("VOID GALLERY", style: TextStyle(letterSpacing: 1.5)),
                                content: Text(capturedImages.isEmpty 
                                    ? "No media frames cached yet in Void Camera Pro." 
                                    : "You have captured ${capturedImages.length} premium images! Viewable under standard device gallery storage."),
                                actions: [
                                  TextButton(
                                    child: const Text("DISMISS"),
                                    onPressed: () => Navigator.pop(context),
                                  )
                                ],
                              ),
                            );
                          },
                          child: Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              color: Colors.white12,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white24, width: 2),
                            ),
                            alignment: Alignment.center,
                            child: capturedImages.isNotEmpty
                                ? const Icon(Icons.photo, color: Color(0xFFE9B824))
                                : const Icon(Icons.collections, color: Colors.white38),
                          ),
                        ),

                        // Center: Main Capturing Bulky Rounded Trigger Button
                        GestureDetector(
                          onTap: captureMedia,
                          child: Container(
                            width: 82,
                            height: 82,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 4),
                            ),
                            padding: const EdgeInsets.all(4),
                            child: Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: selectedMode == 'VIDEO' ? Colors.red : Colors.white,
                              ),
                            ),
                          ),
                        ),

                        // Right: AI status indication badge
                        GestureDetector(
                          onTap: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('AI Motion De-blur & Smart HDR Coherent Optimizer active!')),
                            );
                          },
                          child: Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              color: Colors.white12,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white10),
                            ),
                            alignment: Alignment.center,
                            child: const Icon(Icons.auto_awesome, color: Color(0xFF00FFCC)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CameraGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white24
      ..strokeWidth = 1.0;

    canvas.drawLine(Offset(size.width / 3, 0), Offset(size.width / 3, size.height), paint);
    canvas.drawLine(Offset(2 * size.width / 3, 0), Offset(2 * size.width / 3, size.height), paint);

    canvas.drawLine(Offset(0, size.height / 3), Offset(size.width, size.height / 3), paint);
    canvas.drawLine(Offset(0, 2 * size.height / 3), Offset(size.width, 2 * size.height / 3), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class LaserDeBlurSweeper extends StatefulWidget {
  const LaserDeBlurSweeper({super.key});

  @override
  State<LaserDeBlurSweeper> createState() => _LaserDeBlurSweeperState();
}

class _LaserDeBlurSweeperState extends State<LaserDeBlurSweeper> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          painter: LaserLinePainter(_controller.value),
        );
      },
    );
  }
}

class LaserLinePainter extends CustomPainter {
  final double progress;
  LaserLinePainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF00FFCC)
      ..strokeWidth = 3.0;

    final yPos = progress * size.height;
    canvas.drawLine(Offset(0, yPos), Offset(size.width, yPos), paint);

    // Glow brush
    final glowPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Colors.transparent, const Color(0xFF00FFCC).withOpacity(0.15), Colors.transparent],
      ).createShader(Rect.fromLTWH(0, yPos - 40, size.width, 80));

    canvas.drawRect(Rect.fromLTWH(0, yPos - 40, size.width, 80), glowPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
