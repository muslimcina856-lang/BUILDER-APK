# 🤖 Dafa Ferdion AI

App chat AI pribadi berbasis Flutter, terintegrasi dengan Anthropic Claude API.

## ✨ Fitur

- 💬 Chat dengan Claude AI (mendukung beberapa model)
- 📝 Render Markdown + Code Block dengan tombol salin
- 🕒 Riwayat percakapan (tersimpan otomatis di perangkat)
- 🤖 Pilihan model: Sonnet 4.6, Haiku 4.5, Opus 4.6
- 🎨 Tema Ice Blue Dark yang elegan
- 🔑 Pengaturan API Key tersimpan aman secara lokal

---

## 🛠 Cara Build APK

### Opsi 1: Pakai Flutter SDK (lokal)

1. Pastikan Flutter SDK sudah terinstall: https://docs.flutter.dev/get-started/install
2. Extract ZIP project ini
3. Buka terminal di folder project, jalankan:

```bash
flutter pub get
flutter build apk --release
```

4. APK hasil build ada di:
```
build/app/outputs/flutter-apk/app-release.apk
```

### Opsi 2: Pakai APK Builder Online (tanpa coding)

Jika menggunakan APK builder online seperti **Codemagic**, **AppCircle**, atau sejenisnya:

1. Upload ZIP project ini ke platform builder
2. Pastikan platform tersebut mendukung **Flutter project**
3. Set entry point: `lib/main.dart`
4. Jalankan proses build APK

---

## ⚙️ Setup Awal (Wajib!)

Setelah install APK, buka app lalu:

1. Tap ikon **⚙️ Settings** di pojok kanan atas
2. Masukkan **API Key Anthropic** kamu (dapatkan di https://console.anthropic.com)
3. Pilih model AI yang diinginkan
4. Tap **Simpan Pengaturan**
5. Mulai chat! 🎉

> ⚠️ API Key disimpan secara lokal di perangkat menggunakan SharedPreferences — tidak dikirim ke server manapun selain Anthropic API langsung.

---

## 📁 Struktur Project

```
lib/
├── main.dart                  # Entry point
├── theme/
│   └── app_theme.dart         # Ice Blue dark theme
├── models/
│   └── chat_message.dart      # Model data chat & session
├── services/
│   ├── api_service.dart       # Integrasi Anthropic API
│   └── storage_service.dart   # Local storage (SharedPreferences)
├── widgets/
│   └── chat_bubble.dart       # Bubble chat + markdown renderer
└── screens/
    ├── chat_screen.dart        # Halaman chat utama
    ├── settings_screen.dart    # Halaman pengaturan
    └── history_screen.dart     # Halaman riwayat chat
```

---

## 📦 Dependencies

- `http` — koneksi ke Anthropic API
- `shared_preferences` — simpan data lokal
- `flutter_markdown` — render markdown
- `google_fonts` — font Inter & JetBrains Mono
- `flutter_spinkit` — animasi loading
- `intl` — format tanggal/waktu
- `uuid` — generate ID unik

---

## 📌 Catatan

- Package name: `com.dafa.ferdion`
- App name: **Dafa Ferdion AI**
- Min SDK: 21 (Android 5.0+)
- Target SDK: 34
