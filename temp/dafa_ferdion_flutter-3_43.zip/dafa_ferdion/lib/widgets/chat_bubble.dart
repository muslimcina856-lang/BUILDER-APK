import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/chat_message.dart';
import '../theme/app_theme.dart';

class ChatBubble extends StatelessWidget {
  final ChatMessage message;
  const ChatBubble({super.key, required this.message});

  bool get isUser => message.role == MessageRole.user;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser) _avatar(),
          if (!isUser) const SizedBox(width: 8),
          Flexible(child: _bubble(context)),
          if (isUser) const SizedBox(width: 8),
          if (isUser) _avatar(),
        ],
      ),
    );
  }

  Widget _avatar() {
    return Container(
      width: 32, height: 32,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: isUser
            ? const LinearGradient(
                colors: [AppTheme.accentBlue, AppTheme.accentPurple],
                begin: Alignment.topLeft, end: Alignment.bottomRight)
            : null,
        color: isUser ? null : AppTheme.surfaceDark,
        border: isUser ? null : Border.all(color: AppTheme.borderDark),
      ),
      child: Center(
        child: Text(isUser ? '👤' : '🤖', style: const TextStyle(fontSize: 15)),
      ),
    );
  }

  Widget _bubble(BuildContext context) {
    if (message.isError) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTheme.danger.withOpacity(0.1),
          border: Border.all(color: AppTheme.danger.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(children: [
          const Icon(Icons.warning_amber_rounded, color: AppTheme.danger, size: 16),
          const SizedBox(width: 8),
          Flexible(child: Text(message.content,
              style: GoogleFonts.inter(color: AppTheme.danger, fontSize: 13))),
        ]),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: isUser ? AppTheme.userBubble : AppTheme.aiBubble,
        border: Border.all(
          color: isUser ? const Color(0xFF2D5A8A) : AppTheme.borderDark),
        borderRadius: BorderRadius.only(
          topLeft:     Radius.circular(isUser ? 16 : 4),
          topRight:    Radius.circular(isUser ? 4 : 16),
          bottomLeft:  const Radius.circular(16),
          bottomRight: const Radius.circular(16),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (isUser)
            Text(message.content,
                style: GoogleFonts.inter(color: AppTheme.textPrimary, fontSize: 14, height: 1.6))
          else
            MarkdownBody(
              data: message.content,
              styleSheet: _markdownStyle(),
              builders: {'code': _CodeElementBuilder()},
              selectable: true,
            ),
          const SizedBox(height: 4),
          Text(
            DateFormat('HH:mm').format(message.timestamp),
            style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 10),
          ),
        ],
      ),
    );
  }

  MarkdownStyleSheet _markdownStyle() => MarkdownStyleSheet(
    p:          GoogleFonts.inter(color: AppTheme.textPrimary, fontSize: 14, height: 1.65),
    strong:     GoogleFonts.inter(color: AppTheme.accentBlue, fontWeight: FontWeight.w600, fontSize: 14),
    em:         GoogleFonts.inter(color: const Color(0xFFC4B5FD), fontStyle: FontStyle.italic, fontSize: 14),
    h1:         GoogleFonts.inter(color: AppTheme.accentBlue, fontWeight: FontWeight.w700, fontSize: 18),
    h2:         GoogleFonts.inter(color: AppTheme.accentBlue, fontWeight: FontWeight.w700, fontSize: 16),
    h3:         GoogleFonts.inter(color: AppTheme.accentBlue, fontWeight: FontWeight.w600, fontSize: 15),
    listBullet: GoogleFonts.inter(color: AppTheme.textPrimary, fontSize: 14),
    code:       GoogleFonts.jetBrainsMono(color: const Color(0xFFA5F3FC), fontSize: 13, backgroundColor: AppTheme.codeBg),
    codeblockDecoration: BoxDecoration(
      color: AppTheme.codeBg,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: AppTheme.borderDark),
    ),
    blockquoteDecoration: BoxDecoration(
      color: AppTheme.surfaceDark,
      border: Border(left: BorderSide(color: AppTheme.accentBlue, width: 3)),
    ),
    blockquote: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 13),
  );
}

// Custom code block with copy button
class _CodeElementBuilder extends MarkdownElementBuilder {
  @override
  Widget? visitElementAfter(element, TextStyle? preferredStyle) {
    final code = element.textContent;
    final lang  = element.attributes['class']?.replaceFirst('language-', '') ?? '';

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: AppTheme.codeBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.borderDark),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: const BoxDecoration(
              color: Color(0x0AFFFFFF),
              border: Border(bottom: BorderSide(color: AppTheme.borderDark)),
              borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(lang.toUpperCase(),
                    style: GoogleFonts.inter(
                        color: AppTheme.accentBlue, fontSize: 11, fontWeight: FontWeight.w600)),
                _CopyBtn(code: code),
              ],
            ),
          ),
          // Code content
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(14),
            child: Text(code,
                style: GoogleFonts.jetBrainsMono(
                    color: const Color(0xFFA5F3FC), fontSize: 13, height: 1.6)),
          ),
        ],
      ),
    );
  }
}

class _CopyBtn extends StatefulWidget {
  final String code;
  const _CopyBtn({required this.code});
  @override
  State<_CopyBtn> createState() => _CopyBtnState();
}

class _CopyBtnState extends State<_CopyBtn> {
  bool _copied = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        await Clipboard.setData(ClipboardData(text: widget.code));
        setState(() => _copied = true);
        await Future.delayed(const Duration(seconds: 2));
        if (mounted) setState(() => _copied = false);
      },
      child: Text(
        _copied ? '✅ Tersalin' : '📋 Salin',
        style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 12),
      ),
    );
  }
}
