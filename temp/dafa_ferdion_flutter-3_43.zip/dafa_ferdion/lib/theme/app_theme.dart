import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Ice Blue Dark Palette
  static const Color bgDark       = Color(0xFF0B0F1A);
  static const Color panelDark    = Color(0xFF111827);
  static const Color surfaceDark  = Color(0xFF1A2235);
  static const Color borderDark   = Color(0xFF1E2D45);
  static const Color accentBlue   = Color(0xFF38BDF8);
  static const Color accentBlue2  = Color(0xFF0EA5E9);
  static const Color accentPurple = Color(0xFF818CF8);
  static const Color userBubble   = Color(0xFF1D3A5A);
  static const Color aiBubble     = Color(0xFF141E2E);
  static const Color textPrimary  = Color(0xFFE2E8F0);
  static const Color textMuted    = Color(0xFF64748B);
  static const Color codeBg       = Color(0xFF0D1520);
  static const Color danger       = Color(0xFFF87171);
  static const Color success      = Color(0xFF34D399);

  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bgDark,
    colorScheme: ColorScheme.dark(
      primary: accentBlue,
      secondary: accentPurple,
      surface: surfaceDark,
      error: danger,
    ),
    textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme).copyWith(
      bodyMedium: GoogleFonts.inter(color: textPrimary, fontSize: 14),
      bodySmall:  GoogleFonts.inter(color: textMuted,   fontSize: 12),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: panelDark,
      elevation: 0,
      titleTextStyle: GoogleFonts.inter(
        color: textPrimary, fontSize: 18, fontWeight: FontWeight.w700,
      ),
      iconTheme: IconThemeData(color: textPrimary),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surfaceDark,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: borderDark),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: borderDark),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: accentBlue, width: 1.5),
      ),
      hintStyle: GoogleFonts.inter(color: textMuted, fontSize: 14),
    ),
    dividerColor: borderDark,
  );
}
