import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/chat_message.dart';

class ApiService {
  static const String _baseUrl = 'https://api.anthropic.com/v1/messages';
  static const String _anthropicVersion = '2023-06-01';

  static const Map<String, String> availableModels = {
    'claude-sonnet-4-6': 'Claude Sonnet 4.6 (Cepat & Pintar)',
    'claude-haiku-4-5-20251001': 'Claude Haiku 4.5 (Paling Cepat)',
    'claude-opus-4-6': 'Claude Opus 4.6 (Paling Pintar)',
  };

  static const String systemPrompt = '''Kamu adalah Dafa Ferdion AI, asisten AI pribadi yang cerdas dan ramah.
Kamu membantu pengguna dengan berbagai kebutuhan: coding, analisis, penulisan, pertanyaan umum, dan diskusi kreatif.
Jawab dalam Bahasa Indonesia yang santai namun informatif dan tepat sasaran.
Untuk kode program, selalu gunakan format markdown code block dengan nama bahasa yang sesuai.
Berikan jawaban yang jelas, terstruktur, dan mudah dipahami.''';

  Future<String> sendMessage({
    required String apiKey,
    required List<ChatMessage> messages,
    required String model,
    int maxTokens = 2048,
  }) async {
    // Filter out error messages for API
    final apiMessages = messages
        .where((m) => !m.isError)
        .map((m) => m.toApiMessage())
        .toList();

    final response = await http.post(
      Uri.parse(_baseUrl),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': _anthropicVersion,
      },
      body: jsonEncode({
        'model': model,
        'max_tokens': maxTokens,
        'system': systemPrompt,
        'messages': apiMessages,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final content = data['content'] as List;
      return content
          .where((b) => b['type'] == 'text')
          .map((b) => b['text'] as String)
          .join('');
    } else {
      final err = jsonDecode(response.body);
      final errMsg = err['error']?['message'] ?? 'Terjadi kesalahan API';
      throw Exception(errMsg);
    }
  }
}
