import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/chat_message.dart';

class StorageService {
  static const String _apiKeyKey      = 'api_key';
  static const String _modelKey       = 'selected_model';
  static const String _sessionsKey    = 'chat_sessions';
  static const String _activeSession  = 'active_session_id';

  // ── API Key ──────────────────────────────────────────
  Future<void> saveApiKey(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_apiKeyKey, key);
  }

  Future<String?> getApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_apiKeyKey);
  }

  // ── Model ────────────────────────────────────────────
  Future<void> saveModel(String model) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_modelKey, model);
  }

  Future<String> getModel() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_modelKey) ?? 'claude-sonnet-4-6';
  }

  // ── Sessions ─────────────────────────────────────────
  Future<List<ChatSession>> getSessions() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_sessionsKey);
    if (raw == null) return [];
    final list = jsonDecode(raw) as List;
    return list.map((s) => ChatSession.fromJson(s)).toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  Future<void> saveSession(ChatSession session) async {
    final sessions = await getSessions();
    final idx = sessions.indexWhere((s) => s.id == session.id);
    if (idx >= 0) {
      sessions[idx] = session;
    } else {
      sessions.insert(0, session);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _sessionsKey, jsonEncode(sessions.map((s) => s.toJson()).toList()));
  }

  Future<void> deleteSession(String sessionId) async {
    final sessions = await getSessions();
    sessions.removeWhere((s) => s.id == sessionId);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _sessionsKey, jsonEncode(sessions.map((s) => s.toJson()).toList()));
  }

  Future<void> clearAllSessions() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_sessionsKey);
    await prefs.remove(_activeSession);
  }

  Future<void> saveActiveSession(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_activeSession, id);
  }

  Future<String?> getActiveSession() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_activeSession);
  }
}
