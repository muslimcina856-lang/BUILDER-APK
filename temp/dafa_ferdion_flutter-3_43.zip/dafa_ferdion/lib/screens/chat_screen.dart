import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/chat_message.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/chat_bubble.dart';
import 'settings_screen.dart';
import 'history_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _inputCtrl  = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _focusNode  = FocusNode();
  final _api        = ApiService();
  final _storage    = StorageService();

  late ChatSession _session;
  String _apiKey  = '';
  String _model   = 'claude-sonnet-4-6';
  bool   _loading = false;
  bool   _initialized = false;

  static const List<String> _suggestions = [
    '💡 Bantu debug Flutter error',
    '📝 Tulis fungsi Dart async/await',
    '🎨 Ide desain UI app mobile',
    '⚡ Cara optimasi ukuran APK',
    '🔒 Cara pakai SharedPreferences',
    '📦 Rekomendasi package Flutter',
  ];

  @override
  void initState() {
    super.initState();
    _newSession();
    _loadSettings();
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _newSession() {
    _session = ChatSession(title: 'Chat Baru');
  }

  Future<void> _loadSettings() async {
    final key   = await _storage.getApiKey();
    final model = await _storage.getModel();
    setState(() {
      _apiKey       = key ?? '';
      _model        = model;
      _initialized  = true;
    });
  }

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || _loading) return;
    if (_apiKey.isEmpty) {
      _openSettings();
      return;
    }

    _inputCtrl.clear();
    final userMsg = ChatMessage(role: MessageRole.user, content: text);
    setState(() {
      _session.messages.add(userMsg);
      _loading = true;
      if (_session.messages.length == 1) _session.title = text.length > 40 ? '${text.substring(0, 40)}…' : text;
    });
    _scrollToBottom();

    try {
      final reply = await _api.sendMessage(
        apiKey: _apiKey,
        messages: _session.messages,
        model: _model,
      );
      setState(() {
        _session.messages.add(ChatMessage(role: MessageRole.assistant, content: reply));
        _session.updatedAt = DateTime.now();
        _loading = false;
      });
      await _storage.saveSession(_session);
    } catch (e) {
      setState(() {
        _session.messages.add(ChatMessage(
          role: MessageRole.assistant,
          content: e.toString().replaceFirst('Exception: ', ''),
          isError: true,
        ));
        _loading = false;
      });
    }
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _openSettings() {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => SettingsScreen(
        currentApiKey: _apiKey,
        currentModel:  _model,
        onSave: (key, model) => setState(() { _apiKey = key; _model = model; }),
      ),
    ));
  }

  void _openHistory() {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => HistoryScreen(
        onLoad: (session) {
          setState(() => _session = session);
          _scrollToBottom();
        },
      ),
    ));
  }

  void _newChat() {
    setState(() {
      _newSession();
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) {
      return const Scaffold(
        backgroundColor: AppTheme.bgDark,
        body: Center(child: SpinKitThreeBounce(color: AppTheme.accentBlue, size: 24)),
      );
    }

    final hasMessages = _session.messages.isNotEmpty;

    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          if (_apiKey.isEmpty) _apiKeyBanner(),
          Expanded(
            child: hasMessages ? _chatList() : _welcome(),
          ),
          _inputArea(),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() => AppBar(
    backgroundColor: AppTheme.panelDark,
    title: Row(children: [
      Container(
        width: 32, height: 32,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [AppTheme.accentBlue, AppTheme.accentPurple]),
          borderRadius: BorderRadius.circular(9),
        ),
        child: const Center(child: Text('🤖', style: TextStyle(fontSize: 16))),
      ),
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Dafa Ferdion AI',
            style: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
        Text(ApiService.availableModels[_model]?.split(' (')[0] ?? _model,
            style: GoogleFonts.inter(fontSize: 10, color: AppTheme.accentBlue)),
      ]),
    ]),
    bottom: PreferredSize(
      preferredSize: const Size.fromHeight(1),
      child: Container(height: 1, color: AppTheme.borderDark),
    ),
    actions: [
      IconButton(icon: const Icon(Icons.add_comment_outlined), onPressed: _newChat,
          tooltip: 'Chat Baru', color: AppTheme.textMuted),
      IconButton(icon: const Icon(Icons.history), onPressed: _openHistory,
          tooltip: 'Riwayat', color: AppTheme.textMuted),
      IconButton(icon: const Icon(Icons.settings_outlined), onPressed: _openSettings,
          tooltip: 'Pengaturan', color: AppTheme.textMuted),
    ],
  );

  Widget _apiKeyBanner() => Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
    color: AppTheme.danger.withOpacity(0.1),
    child: GestureDetector(
      onTap: _openSettings,
      child: Row(children: [
        const Icon(Icons.warning_amber_rounded, color: AppTheme.danger, size: 16),
        const SizedBox(width: 8),
        Expanded(child: Text('API Key belum diatur. Tap di sini untuk mengaturnya.',
            style: GoogleFonts.inter(color: AppTheme.danger, fontSize: 12))),
        const Icon(Icons.arrow_forward_ios, color: AppTheme.danger, size: 12),
      ]),
    ),
  );

  Widget _welcome() => SingleChildScrollView(
    padding: const EdgeInsets.all(24),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(height: 40),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(
            colors: [AppTheme.accentBlue, AppTheme.accentPurple]).createShader(b),
          child: const Text('✨', style: TextStyle(fontSize: 56)),
        ),
        const SizedBox(height: 16),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(
            colors: [AppTheme.accentBlue, AppTheme.accentPurple]).createShader(b),
          child: Text('Halo! Saya Dafa Ferdion AI',
              style: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white),
              textAlign: TextAlign.center),
        ),
        const SizedBox(height: 10),
        Text('Asisten AI pribadi kamu. Tanyakan apa saja!',
            style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 14),
            textAlign: TextAlign.center),
        const SizedBox(height: 32),
        Wrap(
          spacing: 8, runSpacing: 8,
          alignment: WrapAlignment.center,
          children: _suggestions.map((s) => GestureDetector(
            onTap: () {
              _inputCtrl.text = s.replaceAll(RegExp(r'^[^\w]+'), '');
              _send();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: AppTheme.surfaceDark,
                border: Border.all(color: AppTheme.borderDark),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(s, style: GoogleFonts.inter(color: AppTheme.textPrimary, fontSize: 13)),
            ),
          )).toList(),
        ),
      ],
    ),
  );

  Widget _chatList() => ListView.builder(
    controller: _scrollCtrl,
    padding: const EdgeInsets.symmetric(vertical: 12),
    itemCount: _session.messages.length + (_loading ? 1 : 0),
    itemBuilder: (ctx, i) {
      if (i == _session.messages.length) return _typingIndicator();
      return ChatBubble(message: _session.messages[i]);
    },
  );

  Widget _typingIndicator() => Padding(
    padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
    child: Row(children: [
      Container(
        width: 32, height: 32,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppTheme.surfaceDark,
          border: Border.all(color: AppTheme.borderDark),
        ),
        child: const Center(child: Text('🤖', style: TextStyle(fontSize: 15))),
      ),
      const SizedBox(width: 8),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppTheme.aiBubble,
          border: Border.all(color: AppTheme.borderDark),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(4), topRight: Radius.circular(16),
            bottomLeft: Radius.circular(16), bottomRight: Radius.circular(16),
          ),
        ),
        child: const SpinKitThreeBounce(color: AppTheme.accentBlue, size: 16),
      ),
    ]),
  );

  Widget _inputArea() => Container(
    padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
    decoration: BoxDecoration(
      color: AppTheme.panelDark,
      border: const Border(top: BorderSide(color: AppTheme.borderDark)),
    ),
    child: Column(children: [
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: AppTheme.surfaceDark,
              border: Border.all(color: _focusNode.hasFocus ? AppTheme.accentBlue : AppTheme.borderDark),
              borderRadius: BorderRadius.circular(14),
            ),
            child: TextField(
              controller: _inputCtrl,
              focusNode: _focusNode,
              maxLines: 5,
              minLines: 1,
              style: GoogleFonts.inter(color: AppTheme.textPrimary, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Ketik pesan kamu...',
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
              onSubmitted: (_) => _send(),
              textInputAction: TextInputAction.newline,
              onChanged: (_) => setState(() {}),
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: _send,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 46, height: 46,
            decoration: BoxDecoration(
              gradient: _inputCtrl.text.isNotEmpty && !_loading
                  ? const LinearGradient(colors: [AppTheme.accentBlue, AppTheme.accentBlue2])
                  : null,
              color: _inputCtrl.text.isEmpty || _loading ? AppTheme.surfaceDark : null,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.borderDark),
            ),
            child: Icon(
              Icons.send_rounded,
              color: _inputCtrl.text.isNotEmpty && !_loading
                  ? const Color(0xFF0B1422) : AppTheme.textMuted,
              size: 20,
            ),
          ),
        ),
      ]),
      const SizedBox(height: 6),
      Text('Enter untuk baris baru · Tap ➤ untuk kirim',
          style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 10)),
    ]),
  );
}
