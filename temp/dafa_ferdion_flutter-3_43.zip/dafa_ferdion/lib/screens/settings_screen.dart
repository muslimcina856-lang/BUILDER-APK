import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  final String currentApiKey;
  final String currentModel;
  final Function(String apiKey, String model) onSave;

  const SettingsScreen({
    super.key,
    required this.currentApiKey,
    required this.currentModel,
    required this.onSave,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _apiKeyCtrl;
  late String _selectedModel;
  bool _obscure = true;
  bool _saving = false;
  final _storage = StorageService();

  @override
  void initState() {
    super.initState();
    _apiKeyCtrl = TextEditingController(text: widget.currentApiKey);
    _selectedModel = widget.currentModel;
  }

  @override
  void dispose() {
    _apiKeyCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_apiKeyCtrl.text.trim().isEmpty) {
      _showSnack('Masukkan API Key terlebih dahulu!', isError: true);
      return;
    }
    setState(() => _saving = true);
    await _storage.saveApiKey(_apiKeyCtrl.text.trim());
    await _storage.saveModel(_selectedModel);
    widget.onSave(_apiKeyCtrl.text.trim(), _selectedModel);
    setState(() => _saving = false);
    if (mounted) {
      _showSnack('Pengaturan tersimpan!');
      Navigator.pop(context);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: GoogleFonts.inter(color: Colors.white)),
      backgroundColor: isError ? AppTheme.danger : AppTheme.success,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        backgroundColor: AppTheme.panelDark,
        title: const Text('⚙️ Pengaturan'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: AppTheme.borderDark),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionTitle('🔑 API Key Anthropic'),
            const SizedBox(height: 8),
            TextField(
              controller: _apiKeyCtrl,
              obscureText: _obscure,
              style: GoogleFonts.jetBrainsMono(color: AppTheme.textPrimary, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'sk-ant-api03-...',
                suffixIcon: IconButton(
                  icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility,
                      color: AppTheme.textMuted),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
              ),
            ),
            const SizedBox(height: 6),
            _hint('Dapatkan API Key di console.anthropic.com'),
            const SizedBox(height: 24),

            _sectionTitle('🤖 Pilih Model AI'),
            const SizedBox(height: 12),
            ...ApiService.availableModels.entries.map((e) => _modelCard(e.key, e.value)),
            const SizedBox(height: 24),

            _infoCard(),
            const SizedBox(height: 32),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _saving ? null : _save,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.accentBlue,
                  foregroundColor: const Color(0xFF0B1422),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: _saving
                    ? const SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text('Simpan Pengaturan',
                        style: GoogleFonts.inter(fontWeight: FontWeight.w700, fontSize: 15)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String t) => Text(t,
      style: GoogleFonts.inter(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w600));

  Widget _hint(String t) => Text(t,
      style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 12));

  Widget _modelCard(String modelId, String label) {
    final selected = _selectedModel == modelId;
    return GestureDetector(
      onTap: () => setState(() => _selectedModel = modelId),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? AppTheme.accentBlue.withOpacity(0.12) : AppTheme.surfaceDark,
          border: Border.all(color: selected ? AppTheme.accentBlue : AppTheme.borderDark, width: selected ? 1.5 : 1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(children: [
          Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: selected ? AppTheme.accentBlue : AppTheme.textMuted, size: 18),
          const SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label.split(' (')[0],
                  style: GoogleFonts.inter(
                      color: selected ? AppTheme.accentBlue : AppTheme.textPrimary,
                      fontWeight: FontWeight.w600, fontSize: 13)),
              Text(label.contains('(') ? label.split('(')[1].replaceAll(')', '') : '',
                  style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 11)),
            ],
          )),
        ]),
      ),
    );
  }

  Widget _infoCard() => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: AppTheme.accentBlue.withOpacity(0.08),
      border: Border.all(color: AppTheme.accentBlue.withOpacity(0.2)),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('💡 Info', style: GoogleFonts.inter(color: AppTheme.accentBlue, fontWeight: FontWeight.w600, fontSize: 13)),
      const SizedBox(height: 6),
      Text('API Key disimpan hanya di perangkat kamu dan tidak dikirim ke server lain.',
          style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 12, height: 1.5)),
    ]),
  );
}
