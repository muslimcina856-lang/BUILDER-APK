import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/chat_message.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

class HistoryScreen extends StatefulWidget {
  final Function(ChatSession) onLoad;
  const HistoryScreen({super.key, required this.onLoad});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _storage = StorageService();
  List<ChatSession> _sessions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sessions = await _storage.getSessions();
    setState(() {
      _sessions = sessions;
      _loading = false;
    });
  }

  Future<void> _delete(String id) async {
    await _storage.deleteSession(id);
    _load();
  }

  Future<void> _confirmClearAll() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.panelDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('Hapus Semua Riwayat?', style: GoogleFonts.inter(color: AppTheme.textPrimary, fontWeight: FontWeight.w700)),
        content: Text('Semua percakapan akan dihapus permanen. Tindakan ini tidak bisa dibatalkan.',
            style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 13)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: Text('Batal', style: GoogleFonts.inter(color: AppTheme.textMuted))),
          TextButton(onPressed: () => Navigator.pop(ctx, true),
              child: Text('Hapus', style: GoogleFonts.inter(color: AppTheme.danger, fontWeight: FontWeight.w700))),
        ],
      ),
    );
    if (confirm == true) {
      await _storage.clearAllSessions();
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDark,
      appBar: AppBar(
        backgroundColor: AppTheme.panelDark,
        title: const Text('🕒 Riwayat Chat'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: AppTheme.borderDark),
        ),
        actions: [
          if (_sessions.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined, color: AppTheme.danger),
              tooltip: 'Hapus Semua',
              onPressed: _confirmClearAll,
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.accentBlue))
          : _sessions.isEmpty
              ? _emptyState()
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _sessions.length,
                  itemBuilder: (ctx, i) => _sessionCard(_sessions[i]),
                ),
    );
  }

  Widget _emptyState() => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('💬', style: TextStyle(fontSize: 48)),
        const SizedBox(height: 12),
        Text('Belum ada riwayat chat',
            style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 14)),
      ],
    ),
  );

  Widget _sessionCard(ChatSession session) {
    final lastMsg = session.messages.isNotEmpty ? session.messages.last.content : '';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        border: Border.all(color: AppTheme.borderDark),
        borderRadius: BorderRadius.circular(14),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        leading: Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [AppTheme.accentBlue, AppTheme.accentPurple]),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Center(child: Text('💬', style: TextStyle(fontSize: 16))),
        ),
        title: Text(session.title,
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: GoogleFonts.inter(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(lastMsg, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 12)),
            const SizedBox(height: 4),
            Text(DateFormat('dd MMM yyyy, HH:mm').format(session.updatedAt),
                style: GoogleFonts.inter(color: AppTheme.textMuted, fontSize: 10)),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, color: AppTheme.danger, size: 20),
          onPressed: () => _delete(session.id),
        ),
        onTap: () {
          widget.onLoad(session);
          Navigator.pop(context);
        },
      ),
    );
  }
}
