package com.dafa.ferdion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
