# Third-party notices

Multi Device uses Android/Kotlin/AndroidX/Jetpack Compose dependencies declared in Gradle. Their
respective upstream licenses apply.

Android rootfs systems are not bundled with this project. Users or distributors are responsible for
ensuring they have the rights to package and distribute any AOSP-derived or other Android rootfs used
with Multi Device.

The user-supplied VMOS package was inspected only to understand externally observable architecture
and behaviour. No VMOS proprietary APK code, native library, rootfs, artwork, key or binary is
redistributed or incorporated in this repository.

No QEMU runtime, firmware, native binary or QEMU-derived source is included in this branch.
