#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

def need(path, text=None):
    p = ROOT / path
    if not p.is_file():
        errors.append(f"missing: {path}")
        return ""
    data = p.read_text(errors="replace")
    if text is not None and text not in data:
        errors.append(f"{path}: missing required text {text!r}")
    return data

def absent(path):
    if (ROOT / path).exists():
        errors.append(f"legacy path must be absent: {path}")

models = need("app/src/main/java/com/virtual/devicelization/core/model/Models.kt", "object VirtualPhoneSpec")
need("app/src/main/java/com/virtual/devicelization/core/vm/RootfsEngineService.kt", "class RootfsEngineService")
need("app/src/main/java/com/virtual/devicelization/core/vm/RootfsVmBackend.kt", "class RootfsVmBackend")
need("app/src/main/java/com/virtual/devicelization/ui/components/RootfsGuestView.kt", "fun RootfsGuestView")
image_store = need("app/src/main/java/com/virtual/devicelization/core/image/GuestImageStore.kt", 'ENGINE_NATIVE_ROOTFS = "native-rootfs"')
create = need("app/src/main/java/com/virtual/devicelization/ui/screens/CreateProfileScreen.kt")
build = need("app/build.gradle.kts", "isMinifyEnabled = true")
manifest = need("app/src/main/AndroidManifest.xml", 'android:process=":rootfs_engine"')
proguard = need("app/proguard-rules.pro", "com.google.errorprone.annotations.RestrictedApi")
need("rootfs-sdk/protocol.md", "rootfs protocol v2")
need("tools/make_rootfs_bundle.py", "rootfsProtocol")

for legacy in [
    "app/src/main/java/com/virtual/devicelization/core/vm/LocalQemuVmBackend.kt",
    "app/src/main/java/com/virtual/devicelization/core/vm/QemuCommandBuilder.kt",
    "app/src/main/java/com/virtual/devicelization/core/vm/QmpClient.kt",
    "app/src/main/java/com/virtual/devicelization/ui/components/QmpGuestView.kt",
    "app/src/main/java/com/virtual/devicelization/ui/components/VncGuestView.kt",
    "app/src/main/java/com/virtual/devicelization/core/image/RemoteImageCatalog.kt",
    "app/src/main/java/com/virtual/devicelization/core/image/UtmConfigParser.kt",
    "native-engine",
    "app/src/main/assets/qemu",
    "app/src/main/res/raw/edk2_aarch64_code_fd.gz",
]:
    absent(legacy)

if "data class DeviceConfig" in models:
    errors.append("DeviceConfig must be removed; phone geometry is not profile-configurable")
for forbidden in ["DeviceStep(", "devicePresets", "ConfigNumberField(", "ConfigSlider("]:
    if forbidden in create:
        errors.append(f"CreateProfileScreen still exposes device/display configuration: {forbidden}")
for forbidden_text in ["Tablet", "Desktop", "Foldable", "Device Configuration", "Custom Resolution"]:
    if f'"{forbidden_text}"' in create:
        errors.append(f"CreateProfileScreen exposes removed device/display choice: {forbidden_text}")
for geometry_label in ["Width", "Height", "DPI", "Refresh rate", "Refresh Rate"]:
    if re.search(rf'Text\(\s*"{re.escape(geometry_label)}', create):
        errors.append(f"CreateProfileScreen exposes removed display control: {geometry_label}")
if "RootfsVmBackend" not in need("app/src/main/java/com/virtual/devicelization/core/vm/LocalEngineRegistry.kt"):
    errors.append("LocalEngineRegistry is not rootfs-only")
if re.search(r"\b(device|width|height|dpi|refreshHz)\s*:", models, re.IGNORECASE):
    errors.append("Profile/model still exposes configurable device geometry")
if re.search(r"qemu|qmp|vnc|utm", build, re.IGNORECASE):
    errors.append("app build still contains legacy emulator build logic")
if 'val labels = listOf("Basic", "Android", "Network", "Review")' not in create:
    errors.append("create wizard is not the four-step phone-only flow")
if "FRAMEBUFFER_PROTOCOL = 2" not in models or "const val WIDTH = 720" not in models or "const val HEIGHT = 1560" not in models:
    errors.append("fixed portrait phone contract is missing")
if "rootfsProtocol == VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL" not in image_store:
    errors.append("rootfs protocol validation is missing")
if "isShrinkResources = true" not in build:
    errors.append("release resource shrinking is not enabled")
if "RootfsEngineService" not in manifest:
    errors.append("rootfs service missing from manifest")

if errors:
    print("PROJECT VERIFICATION FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("PROJECT VERIFICATION PASSED")
print("Engine: native rootfs only")
print("Legacy emulator fallback: absent")
print("Device format: one fixed portrait phone")
print("Display size controls: absent")
print("Rootfs protocol: 2 / shared double framebuffer")
print("Release R8 minify: enabled")
