#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def collect_rootfs(root: Path):
    files = []
    symlinks = {}
    for current, dirs, names in os.walk(root, followlinks=False):
        current_path = Path(current)
        kept_dirs = []
        for name in dirs:
            p = current_path / name
            rel = p.relative_to(root).as_posix()
            if p.is_symlink():
                target = os.readlink(p)
                if os.path.isabs(target):
                    raise SystemExit(f'absolute symlink is not allowed: {rel} -> {target}')
                symlinks[rel] = target
            else:
                kept_dirs.append(name)
        dirs[:] = kept_dirs
        for name in names:
            p = current_path / name
            rel = p.relative_to(root).as_posix()
            if p.is_symlink():
                target = os.readlink(p)
                if os.path.isabs(target):
                    raise SystemExit(f'absolute symlink is not allowed: {rel} -> {target}')
                symlinks[rel] = target
            elif p.is_file():
                files.append((p, rel))
    return files, symlinks


def main():
    ap = argparse.ArgumentParser(description='Build a Multi Device native-rootfs protocol 2 bundle')
    ap.add_argument('--rootfs', required=True, type=Path)
    ap.add_argument('--bootstrap', required=True, type=Path)
    ap.add_argument('--bootstrap-lib-dir', type=Path)
    ap.add_argument('--id', required=True)
    ap.add_argument('--name', required=True)
    ap.add_argument('--android-version', required=True, type=int)
    ap.add_argument('--api-level', required=True, type=int)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()

    rootfs = args.rootfs.resolve()
    bootstrap = args.bootstrap.resolve()
    if not rootfs.is_dir():
        raise SystemExit('rootfs directory is missing')
    if not bootstrap.is_file():
        raise SystemExit('bootstrap ELF is missing')

    files, symlinks = collect_rootfs(rootfs)
    manifest = {
        'id': args.id,
        'name': args.name,
        'androidVersion': args.android_version,
        'apiLevel': args.api_level,
        'architecture': 'ARM64',
        'engine': 'native-rootfs',
        'rootfsProtocol': 2,
        'rootfsDir': 'rootfs',
        'bootstrap': 'bridge/md-container-init',
        'symlinks': symlinks,
        'sha256': sha256(bootstrap),
    }
    if args.bootstrap_lib_dir:
        libdir = args.bootstrap_lib_dir.resolve()
        if not libdir.is_dir():
            raise SystemExit('bootstrap library directory is missing')
        manifest['bootstrapLibraryPath'] = 'bridge/lib'

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, 'w', compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        z.writestr('manifest.json', json.dumps(manifest, indent=2, sort_keys=True))
        z.write(bootstrap, 'bridge/md-container-init')
        if args.bootstrap_lib_dir:
            for p in sorted(args.bootstrap_lib_dir.rglob('*')):
                if p.is_file() and not p.is_symlink():
                    z.write(p, 'bridge/lib/' + p.relative_to(args.bootstrap_lib_dir).as_posix())
        for p, rel in files:
            z.write(p, 'rootfs/' + rel)
    print(args.output)


if __name__ == '__main__':
    main()
