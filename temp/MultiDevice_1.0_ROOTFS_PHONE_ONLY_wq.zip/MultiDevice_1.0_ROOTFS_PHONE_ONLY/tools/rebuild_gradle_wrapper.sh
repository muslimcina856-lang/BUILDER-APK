#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SRC="$ROOT/tools/wrapper-src/org/gradle/wrapper/GradleWrapperMain.java"
OUT="$ROOT/tools/wrapper-classes"
JAR="$ROOT/gradle/wrapper/gradle-wrapper.jar"
rm -rf "$OUT"
mkdir -p "$OUT"
javac --release 17 -d "$OUT" "$SRC"
printf 'Manifest-Version: 1.0\nCreated-By: Multi Device Java 17 wrapper build\n\n' > "$OUT/MANIFEST.MF"
jar cfm "$JAR" "$OUT/MANIFEST.MF" -C "$OUT" org
rm -f "$OUT/MANIFEST.MF"
echo "Rebuilt $JAR for Java 17"
