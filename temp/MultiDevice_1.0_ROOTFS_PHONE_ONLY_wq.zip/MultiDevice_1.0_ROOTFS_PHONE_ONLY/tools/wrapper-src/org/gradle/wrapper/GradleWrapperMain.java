package org.gradle.wrapper;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Properties;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Minimal Java-17-compatible Gradle bootstrapper for Multi Device.
 * It reads gradle-wrapper.properties, downloads the configured distribution,
 * verifies distributionSha256Sum when present, extracts it safely, then
 * delegates to the real Gradle launcher.
 */
public final class GradleWrapperMain {
    private static final int CONNECT_TIMEOUT_MS = 20_000;
    private static final int READ_TIMEOUT_MS = 120_000;
    private static final int MAX_REDIRECTS = 10;

    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path appHome = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        Path propertiesPath = appHome.resolve("gradle/wrapper/gradle-wrapper.properties");

        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(propertiesPath)) {
            properties.load(in);
        }

        String distributionUrl = Objects.requireNonNull(
                properties.getProperty("distributionUrl"), "distributionUrl missing")
                .replace("\\:", ":");
        String expectedSha256 = trimToNull(properties.getProperty("distributionSha256Sum"));

        String archiveName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String distributionName = archiveName.endsWith(".zip")
                ? archiveName.substring(0, archiveName.length() - 4)
                : archiveName;

        Path gradleHome = resolveGradleUserHome();
        Path installRoot = gradleHome.resolve("wrapper/dists/multi-device").resolve(distributionName);
        Path archive = installRoot.resolve(archiveName);
        Path readyMarker = installRoot.resolve(".ready");
        Files.createDirectories(installRoot);

        Path gradleExecutable = findGradleOrNull(installRoot);
        if (gradleExecutable == null || !Files.exists(readyMarker)) {
            Files.deleteIfExists(readyMarker);

            if (!Files.exists(archive) || Files.size(archive) == 0L || !checksumMatches(archive, expectedSha256)) {
                Files.deleteIfExists(archive);
                download(distributionUrl, archive);
            }

            verifyChecksumOrThrow(archive, expectedSha256);
            cleanExtractedDistribution(installRoot, archive.getFileName().toString());
            unzip(archive, installRoot);
            gradleExecutable = findGradle(installRoot);
            Files.writeString(readyMarker, "ready\n");
        }

        if (!isWindows()) {
            gradleExecutable.toFile().setExecutable(true, false);
        }

        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe");
            command.add("/d");
            command.add("/c");
        }
        command.add(gradleExecutable.toString());
        command.addAll(Arrays.asList(args));

        Process process = new ProcessBuilder(command)
                .directory(appHome.toFile())
                .inheritIO()
                .start();
        System.exit(process.waitFor());
    }

    private static Path resolveGradleUserHome() {
        String configured = System.getenv("GRADLE_USER_HOME");
        if (configured != null && !configured.trim().isEmpty()) {
            return Paths.get(configured);
        }
        return Paths.get(System.getProperty("user.home"), ".gradle");
    }

    private static void download(String sourceUrl, Path destination) throws IOException {
        System.out.println("Downloading " + sourceUrl);
        Path temp = destination.resolveSibling(destination.getFileName() + ".part");
        Files.deleteIfExists(temp);

        URL current = URI.create(sourceUrl).toURL();
        HttpURLConnection connection = null;
        for (int redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
            connection = (HttpURLConnection) current.openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("User-Agent", "MultiDevice-GradleBootstrap/1.0");

            int code = connection.getResponseCode();
            if (code >= 300 && code < 400) {
                String location = connection.getHeaderField("Location");
                connection.disconnect();
                if (location == null) {
                    throw new IOException("Gradle download redirect without Location header");
                }
                current = new URL(current, location);
                continue;
            }
            if (code < 200 || code >= 300) {
                connection.disconnect();
                throw new IOException("Gradle download failed with HTTP " + code + " from " + current);
            }
            break;
        }

        if (connection == null) {
            throw new IOException("Unable to open Gradle distribution connection");
        }

        try (InputStream in = new BufferedInputStream(connection.getInputStream());
             OutputStream out = new BufferedOutputStream(new FileOutputStream(temp.toFile()))) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) >= 0) {
                if (read > 0) out.write(buffer, 0, read);
            }
        } finally {
            connection.disconnect();
        }

        try {
            Files.move(temp, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException atomicMoveFailure) {
            Files.move(temp, destination, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void unzip(Path zipFile, Path destinationRoot) throws IOException {
        Path normalizedRoot = destinationRoot.toAbsolutePath().normalize();
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile.toFile())))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                Path output = normalizedRoot.resolve(entry.getName()).normalize();
                if (!output.startsWith(normalizedRoot)) {
                    throw new IOException("Unsafe path in Gradle ZIP: " + entry.getName());
                }

                if (entry.isDirectory()) {
                    Files.createDirectories(output);
                } else {
                    Path parent = output.getParent();
                    if (parent != null) Files.createDirectories(parent);
                    try (OutputStream out = new BufferedOutputStream(new FileOutputStream(output.toFile()))) {
                        byte[] buffer = new byte[64 * 1024];
                        int read;
                        while ((read = zip.read(buffer)) >= 0) {
                            if (read > 0) out.write(buffer, 0, read);
                        }
                    }
                    String fileName = output.getFileName().toString();
                    if ("gradle".equals(fileName)) {
                        output.toFile().setExecutable(true, false);
                    }
                }
                zip.closeEntry();
            }
        }
    }

    private static void cleanExtractedDistribution(Path installRoot, String archiveName) throws IOException {
        if (!Files.exists(installRoot)) return;
        try (Stream<Path> stream = Files.list(installRoot)) {
            for (Path child : (Iterable<Path>) stream::iterator) {
                String name = child.getFileName().toString();
                if (archiveName.equals(name) || (archiveName + ".part").equals(name)) continue;
                deleteRecursively(child);
            }
        }
    }

    private static void deleteRecursively(Path path) throws IOException {
        if (!Files.exists(path)) return;
        if (Files.isDirectory(path)) {
            try (Stream<Path> walk = Files.walk(path)) {
                Path[] paths = walk.sorted(Comparator.reverseOrder()).toArray(Path[]::new);
                for (Path p : paths) Files.deleteIfExists(p);
            }
        } else {
            Files.deleteIfExists(path);
        }
    }

    private static Path findGradle(Path root) throws IOException {
        Path result = findGradleOrNull(root);
        if (result == null) throw new FileNotFoundException("Gradle launcher not found under " + root);
        return result;
    }

    private static Path findGradleOrNull(Path root) throws IOException {
        if (!Files.exists(root)) return null;
        String launcher = isWindows() ? "gradle.bat" : "gradle";
        try (Stream<Path> paths = Files.walk(root, 6)) {
            return paths
                    .filter(path -> path.getFileName() != null && launcher.equals(path.getFileName().toString()))
                    .filter(path -> path.getParent() != null && "bin".equals(path.getParent().getFileName().toString()))
                    .findFirst()
                    .orElse(null);
        }
    }

    private static boolean checksumMatches(Path file, String expectedSha256) throws IOException {
        if (expectedSha256 == null) return true;
        return expectedSha256.equalsIgnoreCase(sha256(file));
    }

    private static void verifyChecksumOrThrow(Path file, String expectedSha256) throws IOException {
        if (expectedSha256 == null) return;
        String actual = sha256(file);
        if (!expectedSha256.equalsIgnoreCase(actual)) {
            Files.deleteIfExists(file);
            throw new IOException("Gradle distribution checksum mismatch. Expected " + expectedSha256 + " but got " + actual);
        }
    }

    private static String sha256(Path file) throws IOException {
        final MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IOException("SHA-256 unavailable", e);
        }
        try (InputStream in = new BufferedInputStream(Files.newInputStream(file))) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) >= 0) {
                if (read > 0) digest.update(buffer, 0, read);
            }
        }
        StringBuilder hex = new StringBuilder(64);
        for (byte b : digest.digest()) hex.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return hex.toString();
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private static String trimToNull(String value) {
        if (value == null) return null;
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
