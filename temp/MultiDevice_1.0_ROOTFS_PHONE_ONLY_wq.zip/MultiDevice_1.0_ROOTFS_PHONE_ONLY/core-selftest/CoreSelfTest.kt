import com.virtual.devicelization.core.model.*
import com.virtual.devicelization.core.network.MacAddressGenerator
import com.virtual.devicelization.core.vm.SingleVmPolicy

fun main() {
    check(VirtualPhoneSpec.WIDTH == 720)
    check(VirtualPhoneSpec.HEIGHT == 1560)
    check(VirtualPhoneSpec.DPI == 320)
    check(VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL == 2)
    check(VirtualPhoneSpec.aspectRatio < 0.5f)

    repeat(100) {
        val mac = MacAddressGenerator.generate()
        check(MacAddressGenerator.isLocallyAdministeredUnicast(mac))
    }

    fun profile(id: String, status: VmStatus) = Profile(
        id = id,
        name = id,
        androidVersion = 9,
        apiLevel = 28,
        imageId = "aosp-rootfs",
        network = NetworkConfig(MacAddressGenerator.generate()),
        status = status,
    )

    val stopped = profile("one", VmStatus.STOPPED)
    val running = profile("two", VmStatus.RUNNING)
    check(SingleVmPolicy.canStart(listOf(stopped), stopped.id))
    check(!SingleVmPolicy.canStart(listOf(running, stopped), stopped.id))
    SingleVmPolicy.assertInvariant(listOf(running, stopped))

    println("CORE SELFTEST PASSED")
}
