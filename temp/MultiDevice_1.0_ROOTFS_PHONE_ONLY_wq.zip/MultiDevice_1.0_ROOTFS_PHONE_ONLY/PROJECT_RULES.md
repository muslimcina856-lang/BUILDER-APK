# Multi Device project rules

1. Multi Device represents one device class only: an Android portrait phone.
2. Do not add tablet, desktop, foldable, custom resolution or display-size choices.
3. Display geometry is an internal engine contract, never a profile setting.
4. Native ARM64 rootfs is the only runtime path. Do not add an emulator fallback.
5. Only one phone session may be active at a time.
6. The engine must remain separate from Activity/UI lifecycle and run through `:rootfs_engine`.
7. A phone may enter `RUNNING` only after a live bootstrap, Android framework readiness and a real guest frame.
8. Profiles stay pinned to their exact Android rootfs image ID.
9. Rootfs imports must reject path traversal, absolute symlink targets and unsupported protocols.
10. Do not copy proprietary VMOS code, rootfs, libraries, assets or keys. VMOS inspection is clean-room behavioural/architectural research only.
11. Preserve unrelated UI/design unless a requested change requires it.
12. Project application version remains `versionCode=1`, `versionName=1.0` unless explicitly changed.
