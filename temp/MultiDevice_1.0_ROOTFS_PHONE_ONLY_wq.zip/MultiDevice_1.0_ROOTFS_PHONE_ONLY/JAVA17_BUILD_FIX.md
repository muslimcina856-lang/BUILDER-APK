# Java 17 Gradle Wrapper Fix

The project wrapper bootstrap JAR is compiled with `javac --release 17` (class-file major 61).
It then downloads Gradle 8.7 from the configured distribution URL and verifies the official
Gradle 8.7 binary ZIP SHA-256 before extraction.

Project application version remains user-managed:
- versionCode = 1
- versionName = 1.0

There is no version lock/guard.

To regenerate the bootstrap JAR after editing its source:

    ./tools/rebuild_gradle_wrapper.sh
