# VMOS 2.0.0-alpha13 clean-room audit

Source inspected: the user-supplied `VMOS_2.0.0-alpha13.apks`. It is not redistributed.

Static inspection found an Android 9 ARM64 rootfs package, a YLINKER-labelled engine, native
filesystem/linker/tooling components, dedicated render Activity/View classes, EGL/GLES paths,
keep-alive services, foreground execution and battery-optimization permissions.

The useful architectural lesson for Multi Device is separation of the Android engine from the UI and
direct phone-oriented rendering. This project implements that direction independently with its own
rootfs protocol, process service, authenticated sockets and shared framebuffer.

No VMOS code, rootfs, native libraries, artwork, signing material or proprietary assets are included.
