# Multi Device rootfs protocol v2

The Android host launches the bundle bootstrap through `/system/bin/linker64` and exports:

- `MD_ROOTFS` — installed rootfs directory
- `MD_DATA` — private profile data directory
- `MD_FRAMEBUFFER` — shared double framebuffer file
- `MD_GUEST_SOCKET` — abstract Unix socket name owned by `:rootfs_engine`
- `MD_SESSION_TOKEN` — per-start random authentication token
- `MD_PHONE_WIDTH`, `MD_PHONE_HEIGHT`, `MD_PHONE_DPI`, `MD_PHONE_REFRESH` — fixed phone contract
- `MD_PROTOCOL=2`

The device geometry is **not configurable** by profiles.

## Guest socket

Connect to the abstract socket and send:

```text
AUTH <MD_SESSION_TOKEN>\n
```

The service replies `OK`. Guest -> host messages:

```text
ANDROID_FRAMEWORK_READY
FRAME <sequence> <slot>
SUSPENDED
RESUMED
ERROR <message>
```

The host does not mark the session RUNNING until Android framework readiness and at least one real
frame have both been observed.

Host -> guest messages include:

```text
TOUCH DOWN|MOVE|UP <x> <y>
KEY DOWN|UP <android-keycode>
TEXT <escaped-utf8>
SUSPEND
RESUME
SHUTDOWN
```

## Shared framebuffer

`MD_FRAMEBUFFER` uses a 64-byte little-endian header followed by two fixed phone-size pixel slots.
Pixels use Android native ARGB_8888 memory layout.

Header offsets:

```text
0   u32 magic      0x4D444652 (MDFR)
4   u32 version    2
8   u32 width
12  u32 height
16  u32 stride
20  u32 format     1 = Android ARGB_8888
24  u32 activeSlot 0 or 1
28  u32 reserved
32  u64 sequence
40  u32 flags
64  slot 0 pixels
64 + frameBytes  slot 1 pixels
```

Write the inactive slot completely, publish its slot/sequence in the header, then send
`FRAME <sequence> <slot>` on the guest socket. This keeps pixel transfer out of the socket path.

This SDK defines the host/guest boundary only. A production Android rootfs still needs a
container-aware init/property/Binder/HAL/graphics integration; stock AOSP `/init` is intentionally
not treated as a valid bootstrap.
