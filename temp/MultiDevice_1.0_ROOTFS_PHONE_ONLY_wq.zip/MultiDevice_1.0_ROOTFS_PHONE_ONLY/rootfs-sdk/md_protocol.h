#ifndef MULTIDEVICE_MD_PROTOCOL_H
#define MULTIDEVICE_MD_PROTOCOL_H

#include <stdint.h>

#define MD_FRAME_MAGIC 0x4D444652u
#define MD_FRAME_VERSION 2u
#define MD_FRAME_HEADER_SIZE 64u
#define MD_FRAME_SLOT_COUNT 2u
#define MD_PIXEL_FORMAT_ANDROID_ARGB8888 1u

#pragma pack(push, 1)
typedef struct md_frame_header {
    uint32_t magic;
    uint32_t version;
    uint32_t width;
    uint32_t height;
    uint32_t stride;
    uint32_t format;
    uint32_t active_slot;
    uint32_t reserved0;
    uint64_t sequence;
    uint32_t flags;
    uint8_t reserved1[20];
} md_frame_header;
#pragma pack(pop)

#endif
