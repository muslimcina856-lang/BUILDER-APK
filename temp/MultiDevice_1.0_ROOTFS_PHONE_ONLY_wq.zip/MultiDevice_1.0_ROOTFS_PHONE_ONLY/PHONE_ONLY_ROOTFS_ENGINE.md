# Phone-only native rootfs engine change

## Requested product change

Multi Device now exposes one device form only: the tall portrait Android phone used by the Running
Phone screen. Device-type and display-size configuration have been removed rather than hidden.

## Removed

- QEMU backend and command builder
- QMP client and screenshot renderer
- VNC guest renderer
- QEMU runtime assets/JNI binaries
- EDK2/UEFI firmware assets and packaging tasks
- UTM parser and remote legacy image catalog
- Phone/Tablet/Foldable/Desktop device presets
- Device Configuration wizard step
- Width, height, DPI and refresh-rate profile fields/controls
- CPU/RAM/storage device configuration controls

## Current flow

`Phone -> Android System -> Network -> Review`

The renderer uses a single internal phone contract. Users do not configure its dimensions.

## Native engine host path

`RootfsVmBackend -> RootfsEngineService(:rootfs_engine) -> compatible rootfs bootstrap`

Frames are published through a protocol-2 shared double framebuffer. Control uses authenticated
abstract Unix sockets. The Activity only attaches/detaches a Surface, so rotation is independent of
the guest engine lifecycle.

## Runtime readiness gate

`RUNNING` requires all of:

1. bootstrap process still alive;
2. `ANDROID_FRAMEWORK_READY` received over the authenticated guest socket;
3. at least one valid shared-framebuffer frame received.

## Important current limitation

The host architecture is rootfs-only now, but a generic stock AOSP filesystem cannot yet boot by
itself. A compatible guest bundle needs the container-aware init/property/Binder/HAL/graphics bridge.
The app deliberately fails clearly rather than silently falling back to another engine.
