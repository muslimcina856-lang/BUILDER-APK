package com.virtual.devicelization.ui.theme

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface as MaterialSurface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF020817)
val Surface = Color(0xFF07172B)
val Surface2 = Color(0xFF0C2139)
val Surface3 = Color(0xFF102A46)
val Cyan = Color(0xFF2DE2FF)
val Blue = Color(0xFF3A86FF)
val Purple = Color(0xFFA66CFF)
val Green = Color(0xFF18E2A0)
val Warning = Color(0xFFFFC857)
val Danger = Color(0xFFFF6685)
val TextPrimary = Color(0xFFF7F9FF)
val TextMuted = Color(0xFFC4CEE3)
val TextSubtle = Color(0xFF98A7C4)
val Outline = Color(0xFF49607D)

private val Scheme = darkColorScheme(
    primary = Cyan,
    secondary = Blue,
    tertiary = Purple,
    background = Bg,
    surface = Surface,
    surfaceVariant = Surface2,
    onPrimary = Color(0xFF001018),
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextMuted,
    outline = Outline,
    error = Danger,
    onError = Color.White,
)

@Composable
fun MultiDeviceTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = MaterialTheme.typography) {
        // MaterialTheme provides the scheme, but a root Surface is what supplies both the actual
        // background and LocalContentColor to routes that are not inside a Scaffold/Surface.
        // This keeps Create/Edit/VM routes consistently dark and prevents default black text.
        MaterialSurface(
            modifier = Modifier.fillMaxSize(),
            color = Bg,
            contentColor = TextPrimary,
        ) {
            content()
        }
    }
}
