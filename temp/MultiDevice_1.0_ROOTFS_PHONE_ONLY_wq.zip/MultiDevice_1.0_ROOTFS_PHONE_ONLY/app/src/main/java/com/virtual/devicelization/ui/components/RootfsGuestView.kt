package com.virtual.devicelization.ui.components

import android.content.Context
import android.graphics.*
import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.os.SystemClock
import android.view.*
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.virtual.devicelization.core.model.VirtualPhoneSpec
import com.virtual.devicelization.core.vm.RootfsFrameBuffer
import java.io.BufferedWriter
import java.io.FileInputStream
import java.io.OutputStreamWriter
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.nio.ByteOrder
import kotlin.math.roundToInt

private class RootfsPhoneView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    private val stateFile = java.io.File(context.filesDir, "rootfs_runtime/engine_state.json")
    private var profileId: String = ""
    @Volatile private var running = false
    private var renderThread: Thread? = null
    private var mapped: MappedByteBuffer? = null
    private var mappedProfileId: String? = null
    private var bitmap: Bitmap? = null
    private var lastSequence = -1L
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(130, 150, 165)
        textSize = 34f
        textAlign = Paint.Align.CENTER
    }
    private var controlSocket: LocalSocket? = null
    private var controlWriter: BufferedWriter? = null
    private var controlIdentity: String? = null
    private var keyboardRequestSeen = 0
    private var cachedUiState = UiState(null, null, null, "Waiting for phone engine…")
    private var lastStateReadUptime = 0L
    private var touchActive = false

    init {
        holder.addCallback(this)
        isFocusable = true
        isFocusableInTouchMode = true
    }

    fun bindProfile(id: String, keyboardRequest: Int) {
        if (profileId != id) {
            profileId = id
            closeMapping()
            closeControl()
            cachedUiState = UiState(null, null, null, "Waiting for phone engine…")
            lastStateReadUptime = 0L
            touchActive = false
        }
        if (keyboardRequest != keyboardRequestSeen) {
            keyboardRequestSeen = keyboardRequest
            requestFocus()
            (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        renderThread = Thread({ renderLoop() }, "MD-Rootfs-Surface").apply { isDaemon = true; start() }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        renderThread?.interrupt()
        renderThread = null
        closeMapping()
        closeControl()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

    private fun renderLoop() {
        while (running) {
            val state = readRuntimeState()
            ensureControl(state)
            val sequence = drawFrameIfAvailable(state)
            if (sequence == null) drawStatus(state.statusText)
            SystemClock.sleep(if (sequence != null && sequence != lastSequence) 8L else 16L)
            if (sequence != null) lastSequence = sequence
        }
    }

    private data class UiState(val profileId: String?, val token: String?, val uiSocket: String?, val statusText: String)

    private fun readRuntimeState(): UiState {
        val now = SystemClock.uptimeMillis()
        if (now - lastStateReadUptime < 200L) return cachedUiState
        lastStateReadUptime = now
        cachedUiState = runCatching {
            if (!stateFile.isFile) return@runCatching UiState(null, null, null, "Waiting for phone engine…")
            val o = org.json.JSONObject(stateFile.readText())
            UiState(
                profileId = o.optString("profileId").takeIf { it.isNotBlank() },
                token = o.optString("sessionToken").takeIf { it.isNotBlank() },
                uiSocket = o.optString("uiSocketName").takeIf { it.isNotBlank() },
                statusText = when (o.optString("status")) {
                    "STARTING" -> "Starting Android…"
                    "SUSPENDED" -> "Phone suspended"
                    "ERROR" -> o.optString("message", "Engine error")
                    else -> "Waiting for Android frame…"
                },
            )
        }.getOrElse { UiState(null, null, null, "Waiting for phone engine…") }
        return cachedUiState
    }

    private fun drawFrameIfAvailable(state: UiState): Long? {
        if (state.profileId != profileId || profileId.isBlank()) return null
        val buffer = ensureMapping(profileId) ?: return null
        return runCatching {
            val header = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            if (header.getInt(0) != RootfsFrameBuffer.MAGIC || header.getInt(4) != RootfsFrameBuffer.VERSION) return@runCatching null
            val width = header.getInt(8)
            val height = header.getInt(12)
            val slot = header.getInt(24)
            val sequence = header.getLong(32)
            if (width != VirtualPhoneSpec.WIDTH || height != VirtualPhoneSpec.HEIGHT || slot !in 0 until RootfsFrameBuffer.SLOT_COUNT || sequence <= 0L) {
                return@runCatching null
            }
            val targetBitmap = bitmap?.takeIf { it.width == width && it.height == height }
                ?: Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap = it }
            val pixels = buffer.duplicate().order(ByteOrder.nativeOrder())
            val offset = RootfsFrameBuffer.slotOffset(slot)
            pixels.position(offset)
            pixels.limit(offset + RootfsFrameBuffer.frameBytes)
            targetBitmap.copyPixelsFromBuffer(pixels.slice())
            drawBitmap(targetBitmap)
            sequence
        }.getOrNull()
    }

    private fun ensureMapping(id: String): MappedByteBuffer? {
        if (mapped != null && mappedProfileId == id) return mapped
        closeMapping()
        val file = java.io.File(context.filesDir, "rootfs_runtime/${sanitize(id)}.framebuffer")
        if (!file.isFile || file.length() < RootfsFrameBuffer.totalBytes) return null
        return runCatching {
            FileInputStream(file).channel.use { channel ->
                channel.map(FileChannel.MapMode.READ_ONLY, 0, RootfsFrameBuffer.totalBytes).also {
                    mapped = it
                    mappedProfileId = id
                }
            }
        }.getOrNull()
    }

    private fun phoneRect(): RectF {
        if (width <= 0 || height <= 0) return RectF()
        val scale = minOf(width.toFloat() / VirtualPhoneSpec.WIDTH, height.toFloat() / VirtualPhoneSpec.HEIGHT)
        val drawW = VirtualPhoneSpec.WIDTH * scale
        val drawH = VirtualPhoneSpec.HEIGHT * scale
        return RectF(
            (width - drawW) / 2f,
            (height - drawH) / 2f,
            (width + drawW) / 2f,
            (height + drawH) / 2f,
        )
    }

    private fun drawBitmap(frame: Bitmap) {
        val canvas = holder.lockCanvas() ?: return
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(frame, null, phoneRect(), paint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    private fun drawStatus(text: String) {
        val canvas = holder.lockCanvas() ?: return
        try {
            canvas.drawColor(Color.rgb(7, 12, 18))
            canvas.drawText(text.take(80), width / 2f, height / 2f, textPaint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    private fun ensureControl(state: UiState) {
        if (state.profileId != profileId || state.token == null || state.uiSocket == null) {
            closeControl()
            return
        }
        val identity = "${state.uiSocket}:${state.token}"
        if (identity == controlIdentity && controlWriter != null) return
        closeControl()
        runCatching {
            val socket = LocalSocket()
            socket.connect(LocalSocketAddress(state.uiSocket, LocalSocketAddress.Namespace.ABSTRACT))
            val writer = BufferedWriter(OutputStreamWriter(socket.outputStream))
            val reader = socket.inputStream.bufferedReader()
            writer.write("AUTH ${state.token}\n")
            writer.flush()
            require(reader.readLine() == "OK") { "Rootfs control authentication failed." }
            controlSocket = socket
            controlWriter = writer
            controlIdentity = identity
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val rect = phoneRect()
        if (rect.isEmpty) return true
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            if (!rect.contains(event.x, event.y)) return true
            touchActive = true
            requestFocus()
        } else if (!touchActive) {
            return true
        }

        val nx = ((event.x - rect.left) / rect.width()).coerceIn(0f, 1f)
        val ny = ((event.y - rect.top) / rect.height()).coerceIn(0f, 1f)
        val x = (nx * (VirtualPhoneSpec.WIDTH - 1)).roundToInt()
        val y = (ny * (VirtualPhoneSpec.HEIGHT - 1)).roundToInt()
        val action = when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> "DOWN"
            MotionEvent.ACTION_MOVE -> "MOVE"
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> "UP"
            else -> return true
        }
        send("TOUCH $action $x $y")
        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            touchActive = false
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        send("KEY DOWN $keyCode")
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        send("KEY UP $keyCode")
        return true
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = android.text.InputType.TYPE_CLASS_TEXT
        outAttrs.imeOptions = EditorInfo.IME_ACTION_NONE
        return object : BaseInputConnection(this, false) {
            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val safe = text?.toString()?.replace("\\", "\\\\")?.replace("\n", "\\n")?.take(512).orEmpty()
                if (safe.isNotEmpty()) send("TEXT $safe")
                return true
            }
        }
    }

    private fun send(line: String) {
        val writer = controlWriter ?: return
        runCatching {
            synchronized(writer) {
                writer.write(line)
                writer.write("\n")
                writer.flush()
            }
        }.onFailure { closeControl() }
    }

    private fun closeControl() {
        runCatching { controlWriter?.close() }
        runCatching { controlSocket?.close() }
        controlWriter = null
        controlSocket = null
        controlIdentity = null
    }

    private fun closeMapping() {
        mapped = null
        mappedProfileId = null
        bitmap?.recycle()
        bitmap = null
        lastSequence = -1L
    }

    private fun sanitize(value: String) = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96)
}

@Composable
fun RootfsGuestView(profileId: String, modifier: Modifier = Modifier, keyboardRequest: Int = 0) {
    AndroidView(
        modifier = modifier,
        factory = { RootfsPhoneView(it).apply { bindProfile(profileId, keyboardRequest) } },
        update = { it.bindProfile(profileId, keyboardRequest) },
    )
}
