package com.virtual.devicelization.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.core.model.VirtualPhoneSpec
import com.virtual.devicelization.core.model.VmStatus
import com.virtual.devicelization.ui.components.*
import com.virtual.devicelization.ui.theme.*

@Composable
fun RunningVmScreen(
    profile: Profile,
    onBack: () -> Unit,
    onStop: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onSuspendAndBack: () -> Unit,
    onRestart: () -> Unit,
    onSnapshot: () -> Unit,
    onResetMac: () -> Unit,
) {
    var fullscreen by remember { mutableStateOf(false) }
    var keyboardRequest by remember { mutableIntStateOf(0) }
    var showNetworkInfo by remember { mutableStateOf(false) }

    if (showNetworkInfo) {
        AlertDialog(
            onDismissRequest = { showNetworkInfo = false },
            title = { Text("Virtual Network") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Mode: ${profile.network.mode.name.replace('_', ' ')}")
                    Text("Virtual MAC: ${profile.network.virtualMac}")
                    Text("DNS protection: ${if (profile.network.dnsProtection) "On" else "Off"}")
                    Text("Kill switch: ${if (profile.network.killSwitch) "On" else "Off"}")
                }
            },
            confirmButton = { TextButton(onClick = { showNetworkInfo = false }) { Text("OK") } },
        )
    }

    if (fullscreen) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            RootfsGuestView(profile.id, Modifier.fillMaxSize(), keyboardRequest)
            IconButton(
                onClick = { keyboardRequest++ },
                modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
            ) { Icon(Icons.Outlined.Keyboard, contentDescription = "Keyboard", tint = Cyan) }
            IconButton(
                onClick = { fullscreen = false },
                modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
            ) { Icon(Icons.Outlined.FullscreenExit, contentDescription = "Exit fullscreen", tint = Cyan) }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Back", tint = TextPrimary) }
                Column(Modifier.weight(1f)) {
                    Text(
                        profile.name,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(4.dp))
                    StatusPill(profile.status)
                }
            }
        }

        item {
            NeonCard(
                modifier = Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                borderColor = Cyan,
                contentPadding = PaddingValues(12.dp),
            ) {
                Box(
                    Modifier.fillMaxWidth()
                        .aspectRatio(VirtualPhoneSpec.aspectRatio, matchHeightConstraintsFirst = false)
                        .background(Brush.verticalGradient(listOf(Surface2, Bg)), RoundedCornerShape(20.dp)),
                ) {
                    RootfsGuestView(profile.id, Modifier.fillMaxSize(), keyboardRequest)
                    IconButton(
                        onClick = { keyboardRequest++ },
                        modifier = Modifier.align(Alignment.BottomStart).padding(6.dp),
                    ) { Icon(Icons.Outlined.Keyboard, contentDescription = "Keyboard", tint = Cyan) }
                    IconButton(
                        onClick = { fullscreen = true },
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                    ) { Icon(Icons.Outlined.Fullscreen, contentDescription = "Fullscreen", tint = Cyan) }
                }

                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth()) {
                    if (profile.status == VmStatus.SUSPENDED) {
                        VmAction(Icons.Outlined.PlayArrow, "Resume", onResume, Modifier.weight(1f))
                    } else {
                        VmAction(Icons.Outlined.Pause, "Pause", onPause, Modifier.weight(1f))
                    }
                    VmAction(Icons.Outlined.Bedtime, "Suspend", onSuspendAndBack, Modifier.weight(1f))
                    VmAction(Icons.Outlined.RestartAlt, "Restart", onRestart, Modifier.weight(1f))
                    VmAction(Icons.Outlined.Stop, "Stop", onStop, Modifier.weight(1f), tint = Danger)
                    VmAction(Icons.Outlined.Fullscreen, "Full", { fullscreen = true }, Modifier.weight(1f))
                }
            }
        }

        item {
            NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Purple) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Smartphone, null, tint = Cyan, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Android ${profile.androidVersion} Virtual Phone", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Native rootfs session • fixed portrait phone", color = TextMuted)
                    }
                }
            }
        }

        item {
            Text(
                "Session Controls",
                modifier = Modifier.padding(horizontal = 20.dp),
                color = TextPrimary,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
        }
        item {
            NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth()) {
                Row(Modifier.fillMaxWidth()) {
                    VmAction(Icons.Outlined.CameraAlt, "Snapshot", onSnapshot, Modifier.weight(1f))
                    VmAction(Icons.Outlined.Shuffle, "Reset MAC", onResetMac, Modifier.weight(1f))
                    VmAction(Icons.Outlined.Public, "Network", { showNetworkInfo = true }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "${profile.network.mode.name.replace('_', ' ')}  •  ${profile.network.virtualMac}",
                    color = TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun VmAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: androidx.compose.ui.graphics.Color = Cyan,
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick, modifier = Modifier.size(42.dp)) { Icon(icon, contentDescription = label, tint = tint) }
        Text(
            label,
            color = TextMuted,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
