package com.virtual.devicelization.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.R
import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.core.model.VmStatus
import com.virtual.devicelization.ui.components.*
import com.virtual.devicelization.ui.theme.*

@Composable
fun HomeScreen(
    profiles: List<Profile>,
    hasImages: Boolean,
    onProfile: (Profile) -> Unit,
    onCreate: () -> Unit,
    onLibrary: () -> Unit,
) {
    val active = profiles.firstOrNull {
        it.status in setOf(
            VmStatus.STARTING, VmStatus.RUNNING, VmStatus.SUSPENDING, VmStatus.SUSPENDED,
            VmStatus.RESUMING, VmStatus.STOPPING,
        )
    }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Header(
                "Multi Device",
                when {
                    active != null -> "1 active virtual phone"
                    profiles.isEmpty() -> "Create your first virtual Android phone"
                    else -> "${profiles.size} saved phone profile${if (profiles.size == 1) "" else "s"}"
                },
            )
        }

        if (profiles.isEmpty()) {
            item {
                NeonCard(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    borderColor = Cyan,
                    contentPadding = PaddingValues(22.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.app_logo), null, Modifier.size(86.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("No phones yet", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (hasImages) "An Android rootfs is ready. Create your first virtual phone."
                                else "Import an Android rootfs from Android Systems first.",
                                color = TextMuted,
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    if (!hasImages) GradientButton("Open Android Systems", onLibrary, Modifier.fillMaxWidth())
                    else GradientButton("Create First Phone", onCreate, Modifier.fillMaxWidth())
                }
            }
            item {
                NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Purple) {
                    Text("How Multi Device works", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    InfoRow(Icons.Outlined.FolderZip, "1. Import a native Android rootfs")
                    InfoRow(Icons.Outlined.AddCircleOutline, "2. Create a phone profile and choose network privacy")
                    InfoRow(Icons.Outlined.PlayCircleOutline, "3. Start one virtual phone at a time")
                }
            }
        } else {
            item {
                NeonCard(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                    borderColor = if (active != null) Cyan else Blue,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Active Phone", color = Cyan, fontWeight = FontWeight.Medium)
                            Text(
                                active?.name ?: "No Phone Active",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Spacer(Modifier.height(10.dp))
                            StatusPill(active?.status ?: VmStatus.STOPPED)
                        }
                        Image(painterResource(R.drawable.app_logo), null, Modifier.size(92.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = .12f))
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Metric("Android", active?.let { "${it.androidVersion}" } ?: "—", Icons.Outlined.Android, Modifier.weight(1f))
                        Metric("Format", "Phone", Icons.Outlined.Smartphone, Modifier.weight(1f))
                        Metric("Network", active?.network?.mode?.name?.substringBefore('_') ?: "—", Icons.Outlined.Public, Modifier.weight(1f))
                    }
                }
            }
            item {
                Row(
                    Modifier.padding(horizontal = 20.dp, vertical = 4.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("Phones", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${profiles.size} total", color = TextMuted)
                }
            }
            items(profiles.take(3), key = { it.id }) { p -> ProfileCard(p, onClick = { onProfile(p) }) }
            item { GradientButton("＋  Create Phone", onCreate, Modifier.padding(horizontal = 18.dp).fillMaxWidth()) }
        }
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, color = TextMuted, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun Metric(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = TextMuted, style = MaterialTheme.typography.labelMedium)
        Text(value, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun ProfileCard(
    profile: Profile,
    onClick: () -> Unit,
    actions: (@Composable RowScope.() -> Unit)? = null,
) {
    val border = when (profile.status) {
        VmStatus.RUNNING -> Green
        VmStatus.SUSPENDED -> Purple
        VmStatus.ERROR -> Danger
        else -> Blue
    }
    NeonCard(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth().clickable(onClick = onClick),
        borderColor = border,
        contentPadding = PaddingValues(16.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = Cyan.copy(alpha = .08f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(alpha = .45f)),
            ) {
                Box(Modifier.size(50.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Smartphone, null, tint = Cyan, modifier = Modifier.size(30.dp))
                }
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    profile.name,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Android ${profile.androidVersion}  •  Virtual Phone",
                    color = TextMuted,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    profile.network.virtualMac,
                    color = TextSubtle,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    maxLines = 1,
                )
            }
            Spacer(Modifier.width(8.dp))
            StatusPill(profile.status)
        }
        actions?.let { actionContent ->
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = Color.White.copy(alpha = .10f))
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
                content = actionContent,
            )
        }
    }
}
