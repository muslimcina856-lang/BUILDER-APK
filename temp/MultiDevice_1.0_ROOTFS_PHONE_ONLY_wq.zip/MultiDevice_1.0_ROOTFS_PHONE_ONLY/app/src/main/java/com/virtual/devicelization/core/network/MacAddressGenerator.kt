package com.virtual.devicelization.core.network

import java.security.SecureRandom

object MacAddressGenerator {
    private val random = SecureRandom()

    /** Generates a locally-administered, unicast virtual MAC address. */
    fun generate(): String {
        val bytes = ByteArray(6).also(random::nextBytes)
        val first = bytes[0].toInt() and 0xFF
        bytes[0] = ((first or 0x02) and 0xFE).toByte()
        return bytes.joinToString(":") { "%02X".format(it.toInt() and 0xFF) }
    }

    fun isLocallyAdministeredUnicast(mac: String): Boolean {
        val parts = mac.split(":")
        if (parts.size != 6 || parts.any { it.length != 2 }) return false
        val first = parts.first().toIntOrNull(16) ?: return false
        return (first and 0x02) != 0 && (first and 0x01) == 0
    }
}
