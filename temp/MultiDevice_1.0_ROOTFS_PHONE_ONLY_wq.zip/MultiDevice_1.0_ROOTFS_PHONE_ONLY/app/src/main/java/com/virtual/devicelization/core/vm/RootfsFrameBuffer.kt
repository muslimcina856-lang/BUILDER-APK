package com.virtual.devicelization.core.vm

import com.virtual.devicelization.core.model.VirtualPhoneSpec
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Shared double-buffer contract between the guest bridge and the Android Surface renderer. */
object RootfsFrameBuffer {
    const val MAGIC = 0x4D444652 // MDFR
    const val VERSION = 2
    const val HEADER_SIZE = 64
    const val SLOT_COUNT = 2
    const val BYTES_PER_PIXEL = 4
    const val FORMAT_ANDROID_ARGB8888 = 1
    val frameBytes: Int get() = VirtualPhoneSpec.WIDTH * VirtualPhoneSpec.HEIGHT * BYTES_PER_PIXEL
    val totalBytes: Long get() = HEADER_SIZE.toLong() + SLOT_COUNT.toLong() * frameBytes.toLong()

    fun create(file: File) {
        file.parentFile?.mkdirs()
        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(totalBytes)
            val header = ByteBuffer.allocate(HEADER_SIZE).order(ByteOrder.LITTLE_ENDIAN)
            header.putInt(MAGIC)
            header.putInt(VERSION)
            header.putInt(VirtualPhoneSpec.WIDTH)
            header.putInt(VirtualPhoneSpec.HEIGHT)
            header.putInt(VirtualPhoneSpec.WIDTH * BYTES_PER_PIXEL)
            header.putInt(FORMAT_ANDROID_ARGB8888)
            header.putInt(0) // active slot
            header.putInt(0)
            header.putLong(0L) // sequence
            header.putInt(0) // flags
            header.position(0)
            raf.channel.write(header, 0)
            raf.channel.force(true)
        }
    }

    fun slotOffset(slot: Int): Int = HEADER_SIZE + slot.coerceIn(0, SLOT_COUNT - 1) * frameBytes
}
