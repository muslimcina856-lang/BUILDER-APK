package com.virtual.devicelization.core.vm

import android.content.Context
import com.virtual.devicelization.core.image.GuestImageStore

/** Process-wide accessors for the rootfs-only runtime. */
object LocalEngineRegistry {
    @Volatile private var imageStoreInstance: GuestImageStore? = null
    @Volatile private var backendInstance: RootfsVmBackend? = null

    fun imageStore(context: Context): GuestImageStore {
        return imageStoreInstance ?: synchronized(this) {
            imageStoreInstance ?: GuestImageStore(context.applicationContext).also { imageStoreInstance = it }
        }
    }

    fun backend(context: Context): RootfsVmBackend {
        return backendInstance ?: synchronized(this) {
            backendInstance ?: RootfsVmBackend(
                context.applicationContext,
                imageStore(context),
            ).also { backendInstance = it }
        }
    }
}
