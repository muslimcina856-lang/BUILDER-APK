package com.virtual.devicelization.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.ui.screens.*
import kotlinx.coroutines.delay

private sealed interface Route {
    data object Main : Route
    data object Create : Route
    data class Edit(val profileId: String) : Route
    data class Vm(val profileId: String) : Route
}

private val RouteSaver = Saver<Route, String>(
    save = { route ->
        when (route) {
            Route.Main -> "main"
            Route.Create -> "create"
            is Route.Edit -> "edit:${route.profileId}"
            is Route.Vm -> "vm:${route.profileId}"
        }
    },
    restore = { saved ->
        when {
            saved == "main" -> Route.Main
            saved == "create" -> Route.Create
            saved.startsWith("edit:") -> Route.Edit(saved.removePrefix("edit:"))
            saved.startsWith("vm:") -> Route.Vm(saved.removePrefix("vm:"))
            else -> Route.Main
        }
    },
)

@Composable
fun MultiDeviceApp(vm: MainViewModel = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var route by rememberSaveable(stateSaver = RouteSaver) { mutableStateOf<Route>(Route.Main) }
    var pendingSwitch by remember { mutableStateOf<Profile?>(null) }
    var pendingDelete by remember { mutableStateOf<Profile?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1500)
            vm.reconcileBackendState()
        }
    }

    LaunchedEffect(vm.operationMessage) {
        val message = vm.operationMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        vm.consumeMessage()
    }

    pendingSwitch?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingSwitch = null },
            title = { Text("Another phone is active") },
            text = { Text("Multi Device allows only one active virtual phone. Shut down the current phone and switch to ${target.name}?") },
            confirmButton = {
                TextButton(onClick = {
                    pendingSwitch = null
                    vm.startProfile(target.id, forceSwitch = true) { result ->
                        if (result == StartResult.STARTED) route = Route.Vm(target.id)
                    }
                }) { Text("Shutdown & Switch") }
            },
            dismissButton = { TextButton(onClick = { pendingSwitch = null }) { Text("Cancel") } },
        )
    }

    pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete phone?") },
            text = { Text("Delete ${target.name} and its private data? This action cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteProfile(target.id)
                    pendingDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } },
        )
    }

    when (val r = route) {
        Route.Create -> CreateProfileScreen(
            onCancel = { route = Route.Main },
            onOpenLibrary = { route = Route.Main; tab = MainTab.IMAGES },
            availableImages = vm.guestImages,
            onCreate = { name, imageId, network ->
                if (vm.createProfile(name, imageId, network) != null) {
                    route = Route.Main
                    tab = MainTab.PROFILES
                }
            },
        )

        is Route.Edit -> vm.profiles.firstOrNull { it.id == r.profileId }?.let { original ->
            CreateProfileScreen(
                onCancel = { route = Route.Main },
                onOpenLibrary = { route = Route.Main; tab = MainTab.IMAGES },
                availableImages = vm.guestImages,
                initialProfile = original,
                onCreate = { name, imageId, network ->
                    val image = vm.guestImages.firstOrNull { it.id == imageId }
                    if (image != null) {
                        val changed = original.copy(
                            name = name.ifBlank { original.name },
                            androidVersion = image.androidVersion,
                            apiLevel = image.apiLevel,
                            architecture = image.architecture,
                            imageId = image.id,
                            network = network,
                        )
                        if (vm.updateProfile(changed)) {
                            route = Route.Main
                            tab = MainTab.PROFILES
                        }
                    }
                },
            )
        } ?: run { route = Route.Main }

        is Route.Vm -> vm.profiles.firstOrNull { it.id == r.profileId }?.let { p ->
            RunningVmScreen(
                profile = p,
                onBack = { route = Route.Main },
                onStop = { vm.stopProfile(p.id) { route = Route.Main } },
                onPause = { vm.suspendProfile(p.id) },
                onResume = { vm.resumeProfile(p.id) },
                onSuspendAndBack = { vm.suspendProfile(p.id) { route = Route.Main } },
                onRestart = { vm.restartProfile(p.id) },
                onSnapshot = { vm.createSnapshot(p.id) },
                onResetMac = { vm.resetMac(p.id) },
            )
        } ?: run { route = Route.Main }

        Route.Main -> Scaffold(
            snackbarHost = {
                SnackbarHost(snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = com.virtual.devicelization.ui.theme.Surface2,
                        contentColor = com.virtual.devicelization.ui.theme.TextPrimary,
                        actionColor = com.virtual.devicelization.ui.theme.Cyan,
                    )
                }
            },
            bottomBar = { BottomNav(tab) { tab = it } },
        ) { pad ->
            Surface(Modifier.padding(pad)) {
                when (tab) {
                    MainTab.HOME -> HomeScreen(
                        profiles = vm.profiles,
                        hasImages = vm.guestImages.isNotEmpty(),
                        onProfile = { p ->
                            if (p.status == com.virtual.devicelization.core.model.VmStatus.RUNNING ||
                                p.status == com.virtual.devicelization.core.model.VmStatus.SUSPENDED
                            ) route = Route.Vm(p.id)
                        },
                        onCreate = { route = Route.Create },
                        onLibrary = { tab = MainTab.IMAGES },
                    )
                    MainTab.PROFILES -> ProfilesScreen(
                        profiles = vm.profiles,
                        hasImages = vm.guestImages.isNotEmpty(),
                        onOpen = { p ->
                            if (p.status == com.virtual.devicelization.core.model.VmStatus.RUNNING ||
                                p.status == com.virtual.devicelization.core.model.VmStatus.SUSPENDED
                            ) route = Route.Vm(p.id)
                        },
                        onStart = { p ->
                            vm.startProfile(p.id) { result ->
                                when (result) {
                                    StartResult.STARTED -> route = Route.Vm(p.id)
                                    StartResult.CONFLICT -> pendingSwitch = p
                                    StartResult.FAILED -> Unit
                                }
                            }
                        },
                        onClone = { vm.cloneProfile(it.id) },
                        onEdit = { route = Route.Edit(it.id) },
                        onSnapshot = { vm.createSnapshot(it.id) },
                        onRestoreSnapshot = { vm.restoreLatestSnapshot(it.id) },
                        onDelete = { pendingDelete = it },
                        onCreate = { route = Route.Create },
                        onLibrary = { tab = MainTab.IMAGES },
                    )
                    MainTab.IMAGES -> ImagesScreen(
                        images = vm.guestImages,
                        onImport = vm::importGuestImage,
                        onDelete = vm::deleteGuestImage,
                    )
                    MainTab.SETTINGS -> SettingsScreen(vm.backendStatus)
                }
            }
        }
    }
}
