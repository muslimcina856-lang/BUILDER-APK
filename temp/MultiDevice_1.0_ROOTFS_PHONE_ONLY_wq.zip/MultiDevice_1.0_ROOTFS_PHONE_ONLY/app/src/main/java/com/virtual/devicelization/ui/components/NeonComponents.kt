package com.virtual.devicelization.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.core.model.VmStatus
import com.virtual.devicelization.ui.theme.*

@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    borderColor: Color = Blue,
    contentPadding: PaddingValues = PaddingValues(18.dp),
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.border(1.dp, borderColor.copy(alpha = .78f), RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = Surface.copy(alpha = .985f),
            contentColor = TextPrimary,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun StatusPill(status: VmStatus) {
    val color = when (status) {
        VmStatus.RUNNING, VmStatus.STARTING, VmStatus.RESUMING -> Green
        VmStatus.SUSPENDED, VmStatus.SUSPENDING -> Purple
        VmStatus.ERROR -> Danger
        VmStatus.CREATING, VmStatus.STOPPING -> Warning
        else -> TextMuted
    }
    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = .13f),
        border = BorderStroke(1.dp, color.copy(alpha = .8f)),
    ) {
        Text(
            status.name,
            color = color,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
            maxLines = 1,
        )
    }
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val brush = if (enabled) {
        Brush.horizontalGradient(listOf(Cyan, Blue, Purple))
    } else {
        Brush.horizontalGradient(listOf(Surface3, Surface3))
    }
    Box(
        modifier = modifier
            .heightIn(min = 54.dp)
            .background(brush, RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (enabled) Color.White else TextSubtle,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
        )
    }
}
