package com.virtual.devicelization.core.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/**
 * Checks the default network Android currently exposes to Multi Device itself.
 *
 * If the app is excluded from a host VPN, the app-visible default network is not accepted as an
 * encrypted-tunnel path. DNS protection means the VPN network must also publish at least one DNS
 * resolver in its LinkProperties; Multi Device does not claim to identify the provider's cipher or
 * exit country from Android's generic VPN API.
 */
class HostVpnInspector(context: Context) {
    private val connectivity = context.getSystemService(ConnectivityManager::class.java)

    fun isVpnActiveForThisApp(): Boolean = runCatching {
        val active = connectivity.activeNetwork ?: return@runCatching false
        val caps = connectivity.getNetworkCapabilities(active) ?: return@runCatching false
        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }.getOrDefault(false)

    fun hasVpnDnsServers(): Boolean = runCatching {
        val active = connectivity.activeNetwork ?: return@runCatching false
        val caps = connectivity.getNetworkCapabilities(active) ?: return@runCatching false
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return@runCatching false
        connectivity.getLinkProperties(active)?.dnsServers?.isNotEmpty() == true
    }.getOrDefault(false)

    fun isVpnReady(requireDns: Boolean): Boolean =
        isVpnActiveForThisApp() && (!requireDns || hasVpnDnsServers())
}
