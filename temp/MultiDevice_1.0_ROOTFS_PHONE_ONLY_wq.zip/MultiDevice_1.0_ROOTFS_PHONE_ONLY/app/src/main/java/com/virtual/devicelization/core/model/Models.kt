package com.virtual.devicelization.core.model

enum class VmStatus {
    CREATING, READY, STARTING, RUNNING, SUSPENDING, SUSPENDED,
    RESUMING, STOPPING, STOPPED, ERROR, DELETING
}

enum class MacMode { KEEP_CURRENT, RANDOM_EVERY_BOOT, MANUAL_RESET_ONLY }
enum class NetworkMode { DIRECT_NAT, ENCRYPTED_TUNNEL, OFFLINE }

/**
 * Multi Device now has one device identity only: a portrait Android phone.
 * Display geometry is an engine contract, not a profile/user setting.
 */
object VirtualPhoneSpec {
    const val WIDTH = 720
    const val HEIGHT = 1560
    const val DPI = 320
    const val REFRESH_HZ = 60
    const val FRAMEBUFFER_PROTOCOL = 2
    val aspectRatio: Float get() = WIDTH.toFloat() / HEIGHT.toFloat()
}

data class NetworkConfig(
    val virtualMac: String,
    val macMode: MacMode = MacMode.MANUAL_RESET_ONLY,
    val mode: NetworkMode = NetworkMode.DIRECT_NAT,
    val exitRegion: String = "Singapore",
    val dnsProtection: Boolean = true,
    val killSwitch: Boolean = true,
)

data class Profile(
    val id: String,
    val name: String,
    val androidVersion: Int,
    val apiLevel: Int,
    val architecture: String = "ARM64",
    val imageId: String? = null,
    val network: NetworkConfig,
    val status: VmStatus = VmStatus.STOPPED,
    val createdAtEpochMs: Long = System.currentTimeMillis(),
)
