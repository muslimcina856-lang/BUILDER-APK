package com.virtual.devicelization.ui.screens

import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.core.image.GuestImageManifest
import com.virtual.devicelization.ui.components.GradientButton
import com.virtual.devicelization.ui.components.NeonCard
import com.virtual.devicelization.ui.theme.*

@Composable
fun ImagesScreen(
    images: List<GuestImageManifest>,
    onImport: (Uri) -> Unit,
    onDelete: (String) -> Unit,
) {
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(onImport) }
    val free = Formatter.formatFileSize(context, context.filesDir.usableSpace)
    val total = Formatter.formatFileSize(context, context.filesDir.totalSpace)

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Header(
                "Android Systems",
                "Android rootfs systems for your virtual phones",
                trailing = {
                    IconButton(onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) {
                        Icon(Icons.Outlined.FileOpen, "Import Android rootfs", tint = Cyan)
                    }
                },
            )
        }
        item {
            NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("App storage free", color = TextMuted)
                        Text(free, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("of $total", color = TextSubtle)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Icon(Icons.Outlined.Smartphone, null, tint = Purple)
                        Text("Installed", color = TextMuted)
                        Text(images.size.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Cyan) {
                Text("AOSP / Native RootFS", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Import an ARM64 bundle built for the Multi Device rootfs protocol. The bundle supplies the Android system and container-aware bootstrap.",
                    color = TextMuted,
                )
                Spacer(Modifier.height(14.dp))
                GradientButton(
                    text = "Import Android RootFS",
                    onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item {
            Text(
                "Installed Android Systems",
                modifier = Modifier.padding(horizontal = 20.dp),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
        }
        if (images.isEmpty()) {
            item {
                NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Purple) {
                    Icon(Icons.Outlined.Android, null, tint = Purple, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Nothing installed yet", fontWeight = FontWeight.Bold)
                    Text("Import a compatible Android rootfs bundle to create a phone.", color = TextMuted)
                }
            }
        } else {
            items(images, key = { it.id }) { image -> ImageRow(image, onDelete = { onDelete(image.id) }) }
        }
    }
}

@Composable
private fun ImageRow(image: GuestImageManifest, onDelete: () -> Unit) {
    NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Cyan) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Android, null, tint = Green, modifier = Modifier.size(46.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(image.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("Android ${image.androidVersion} • API ${image.apiLevel}", color = TextMuted)
                Text("${image.architecture} • Native rootfs v${image.rootfsProtocol}", color = TextSubtle, style = MaterialTheme.typography.bodySmall)
                Text(image.id, color = Cyan, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = Surface3.copy(alpha = .45f),
                    border = BorderStroke(1.dp, Green.copy(alpha = .7f)),
                ) {
                    Text("INSTALLED", color = Green, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                }
                IconButton(onClick = onDelete) { Icon(Icons.Outlined.DeleteOutline, "Delete image", tint = Danger) }
            }
        }
    }
}
