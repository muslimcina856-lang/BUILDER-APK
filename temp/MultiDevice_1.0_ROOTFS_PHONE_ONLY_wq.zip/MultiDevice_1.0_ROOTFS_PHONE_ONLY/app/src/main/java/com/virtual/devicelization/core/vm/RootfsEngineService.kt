package com.virtual.devicelization.core.vm

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.LocalServerSocket
import android.net.LocalSocket
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.virtual.devicelization.MainActivity
import com.virtual.devicelization.R
import com.virtual.devicelization.core.image.GuestImageStore
import com.virtual.devicelization.core.model.VmStatus
import com.virtual.devicelization.core.model.VirtualPhoneSpec
import java.io.BufferedWriter
import java.io.File
import java.io.OutputStreamWriter
import java.security.SecureRandom
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground owner for the rootfs-only Android phone engine.
 *
 * The service intentionally runs in :rootfs_engine. UI rotation/recreation therefore cannot own or
 * destroy the guest. The guest bridge writes to a shared double framebuffer and talks to this
 * service through authenticated abstract Unix sockets.
 */
class RootfsEngineService : Service() {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "MD-Rootfs-Control") }
    private val runtimeStore by lazy { RootfsRuntimeStore(this) }
    private val imageStore by lazy { GuestImageStore(this) }

    private val lock = Any()
    @Volatile private var child: Process? = null
    @Volatile private var guestWriter: BufferedWriter? = null
    @Volatile private var guestServer: LocalServerSocket? = null
    @Volatile private var uiServer: LocalServerSocket? = null
    @Volatile private var sessionToken: String? = null
    @Volatile private var sessionGeneration: Long = 0L
    @Volatile private var guestReady: Boolean = false
    @Volatile private var lastFrameSequence: Long = 0L
    private val stopping = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        startForeground(NOTIFICATION_ID, notification("Android phone engine is starting"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val profileId = intent.getStringExtra(EXTRA_PROFILE_ID).orEmpty()
                val profileName = intent.getStringExtra(EXTRA_PROFILE_NAME).orEmpty()
                val imageId = intent.getStringExtra(EXTRA_IMAGE_ID).orEmpty()
                if (profileId.isBlank() || imageId.isBlank()) {
                    updateState(RootfsRuntimeState(status = VmStatus.ERROR, message = "Missing profile/image id."))
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else {
                    worker.execute { startSession(profileId, profileName.ifBlank { "Virtual Phone" }, imageId) }
                }
            }
            ACTION_SUSPEND -> worker.execute { sendLifecycleCommand(intent, "SUSPEND", VmStatus.SUSPENDING) }
            ACTION_RESUME -> worker.execute { sendLifecycleCommand(intent, "RESUME", VmStatus.RESUMING) }
            ACTION_STOP -> worker.execute { stopSession(intent?.getStringExtra(EXTRA_PROFILE_ID), force = false) }
            ACTION_FORCE_STOP -> worker.execute { stopSession(intent?.getStringExtra(EXTRA_PROFILE_ID), force = true) }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        worker.execute {
            val state = runtimeStore.read()
            if (state.status in ACTIVE_STATES) {
                runCatching { child?.destroyForcibly() }
                updateState(state.copy(status = VmStatus.ERROR, message = "Rootfs engine process stopped unexpectedly."))
            }
            closeSessionResources()
        }
        worker.shutdown()
        super.onDestroy()
    }

    private fun startSession(profileId: String, profileName: String, imageId: String) {
        synchronized(lock) {
            val current = runtimeStore.read()
            if (current.profileId == profileId && current.status in ACTIVE_STATES && child?.isAlive == true) {
                touchState(current)
                updateNotification("$profileName is running")
                return
            }
            if (current.status in ACTIVE_STATES || child?.isAlive == true) {
                // SingleVmPolicy must stop the current phone before another profile is started.
                // Never kill an existing session here: a duplicate/racing START must not destroy it.
                updateNotification("${current.profileName ?: "Virtual Phone"} is already active")
                return
            }

            stopping.set(false)
            guestReady = false
            lastFrameSequence = 0L
            sessionGeneration++
            val generation = sessionGeneration
            val token = randomToken()
            sessionToken = token
            val suffix = token.take(12)
            val guestSocketName = "md_guest_$suffix"
            val uiSocketName = "md_ui_$suffix"
            val image = imageStore.get(imageId) ?: run {
                failStart(
                    RootfsRuntimeState(
                        profileId = profileId,
                        profileName = profileName,
                        status = VmStatus.ERROR,
                        message = "Selected Android rootfs is missing or incompatible.",
                    )
                )
                return
            }
            imageStore.validate(image)?.let { error ->
                failStart(
                    RootfsRuntimeState(
                        profileId = profileId,
                        profileName = profileName,
                        status = VmStatus.ERROR,
                        message = error,
                    )
                )
                return
            }

            val profileDir = imageStore.profileDirectory(profileId).apply { mkdirs() }
            val dataDir = imageStore.profileDataDirectory(profileId).apply { mkdirs() }
            val frameFile = runtimeStore.framebufferFile(profileId)
            RootfsFrameBuffer.create(frameFile)

            runCatching {
                guestServer = LocalServerSocket(guestSocketName)
                uiServer = LocalServerSocket(uiSocketName)
            }.onFailure { error ->
                failStart(
                    RootfsRuntimeState(
                        profileId = profileId,
                        profileName = profileName,
                        status = VmStatus.ERROR,
                        message = "Unable to create local engine sockets: ${error.message}",
                    )
                )
                return
            }

            val startingState = RootfsRuntimeState(
                profileId = profileId,
                profileName = profileName,
                status = VmStatus.STARTING,
                sessionToken = token,
                uiSocketName = uiSocketName,
                guestSocketName = guestSocketName,
                frameSequence = 0L,
                message = "Waiting for Android framework and first guest frame…",
            )
            updateState(startingState)
            updateNotification("$profileName is starting")

            startGuestAcceptLoop(generation, token)
            startUiAcceptLoop(generation, token)
            startHeartbeatLoop(generation)

            val linker = File("/system/bin/linker64")
            if (!linker.isFile) {
                failStart(startingState.copy(status = VmStatus.ERROR, message = "Android linker64 is unavailable on this host."))
                return
            }

            runCatching {
                val command = listOf(linker.absolutePath, image.bootstrapFile.absolutePath)
                val processBuilder = ProcessBuilder(command)
                    .directory(image.directory)
                    .redirectErrorStream(true)
                processBuilder.environment().apply {
                    put("MD_ENGINE", "multidevice-rootfs")
                    put("MD_PROTOCOL", VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL.toString())
                    put("MD_PROFILE_ID", profileId)
                    put("MD_ROOTFS", image.rootfsDirectory.absolutePath)
                    put("MD_DATA", dataDir.absolutePath)
                    put("MD_PROFILE_DIR", profileDir.absolutePath)
                    put("MD_FRAMEBUFFER", frameFile.absolutePath)
                    put("MD_GUEST_SOCKET", guestSocketName)
                    put("MD_SESSION_TOKEN", token)
                    put("MD_PHONE_WIDTH", VirtualPhoneSpec.WIDTH.toString())
                    put("MD_PHONE_HEIGHT", VirtualPhoneSpec.HEIGHT.toString())
                    put("MD_PHONE_DPI", VirtualPhoneSpec.DPI.toString())
                    put("MD_PHONE_REFRESH", VirtualPhoneSpec.REFRESH_HZ.toString())
                    image.bootstrapLibraries?.let { put("LD_LIBRARY_PATH", it.absolutePath) }
                }
                child = processBuilder.start()
                streamGuestLog(profileId, child!!, generation)
                watchChild(profileId, profileName, generation)
            }.onFailure { error ->
                failStart(
                    startingState.copy(
                        status = VmStatus.ERROR,
                        message = "Unable to launch rootfs bootstrap: ${error.message ?: error.javaClass.simpleName}",
                    )
                )
            }
        }
    }

    private fun startGuestAcceptLoop(generation: Long, token: String) {
        Thread({
            while (generation == sessionGeneration && !stopping.get()) {
                val socket = runCatching { guestServer?.accept() }.getOrNull() ?: break
                handleGuestSocket(socket, generation, token)
            }
        }, "MD-Rootfs-GuestSocket").apply { isDaemon = true; start() }
    }

    private fun handleGuestSocket(socket: LocalSocket, generation: Long, token: String) {
        Thread({
            socket.use { client ->
                val reader = client.inputStream.bufferedReader()
                val writer = BufferedWriter(OutputStreamWriter(client.outputStream))
                val auth = reader.readLine().orEmpty()
                if (auth != "AUTH $token") {
                    runCatching { writer.write("DENY\n"); writer.flush() }
                    return@use
                }
                runCatching { writer.write("OK\n"); writer.flush() }
                guestWriter = writer
                while (generation == sessionGeneration && !stopping.get()) {
                    val line = reader.readLine() ?: break
                    handleGuestLine(line)
                }
                if (guestWriter === writer) guestWriter = null
            }
        }, "MD-Rootfs-GuestClient").apply { isDaemon = true; start() }
    }

    private fun handleGuestLine(raw: String) {
        val line = raw.trim()
        val state = runtimeStore.read()
        when {
            line == "ANDROID_FRAMEWORK_READY" -> {
                guestReady = true
                maybePromoteRunning(state)
            }
            line.startsWith("FRAME ") -> {
                val parts = line.split(' ')
                val seq = parts.getOrNull(1)?.toLongOrNull() ?: return
                val slot = parts.getOrNull(2)?.toIntOrNull() ?: return
                if (slot !in 0 until RootfsFrameBuffer.SLOT_COUNT || seq <= lastFrameSequence) return
                lastFrameSequence = seq
                val next = state.copy(frameSequence = seq, message = null)
                updateState(next)
                maybePromoteRunning(next)
            }
            line == "SUSPENDED" -> updateState(state.copy(status = VmStatus.SUSPENDED, message = null))
            line == "RESUMED" -> {
                guestReady = true
                maybePromoteRunning(state)
            }
            line.startsWith("ERROR ") -> {
                stopping.set(true)
                updateState(state.copy(status = VmStatus.ERROR, message = line.removePrefix("ERROR ").take(500)))
                runCatching { child?.destroyForcibly() }
                closeSessionResources()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun maybePromoteRunning(state: RootfsRuntimeState) {
        if (guestReady && lastFrameSequence > 0L && child?.isAlive == true) {
            val current = runtimeStore.read()
            if (current.status == VmStatus.STARTING || current.status == VmStatus.RESUMING) {
                updateState(current.copy(status = VmStatus.RUNNING, frameSequence = lastFrameSequence, message = null))
                updateNotification("${current.profileName ?: "Virtual Phone"} is running")
            }
        }
    }

    private fun startUiAcceptLoop(generation: Long, token: String) {
        Thread({
            while (generation == sessionGeneration && !stopping.get()) {
                val socket = runCatching { uiServer?.accept() }.getOrNull() ?: break
                Thread({
                    socket.use { client ->
                        val reader = client.inputStream.bufferedReader()
                        val writer = BufferedWriter(OutputStreamWriter(client.outputStream))
                        if (reader.readLine().orEmpty() != "AUTH $token") {
                            runCatching { writer.write("DENY\n"); writer.flush() }
                            return@use
                        }
                        runCatching { writer.write("OK\n"); writer.flush() }
                        while (generation == sessionGeneration && !stopping.get()) {
                            val line = reader.readLine() ?: break
                            if (line.length > MAX_UI_COMMAND_CHARS) continue
                            forwardToGuest(line)
                        }
                    }
                }, "MD-Rootfs-UIClient").apply { isDaemon = true; start() }
            }
        }, "MD-Rootfs-UISocket").apply { isDaemon = true; start() }
    }

    private fun sendLifecycleCommand(intent: Intent?, command: String, transition: VmStatus) {
        val profileId = intent?.getStringExtra(EXTRA_PROFILE_ID).orEmpty()
        val state = runtimeStore.read()
        if (profileId.isBlank() || state.profileId != profileId || !runtimeStore.isAlive(profileId)) {
            if (state.status !in ACTIVE_STATES && child?.isAlive != true) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return
        }
        updateState(state.copy(status = transition, message = null))
        if (!forwardToGuest(command)) {
            updateState(state.copy(status = VmStatus.ERROR, message = "Guest control channel is not connected."))
        }
    }

    private fun forwardToGuest(command: String): Boolean {
        val writer = guestWriter ?: return false
        return runCatching {
            synchronized(writer) {
                writer.write(command)
                writer.write("\n")
                writer.flush()
            }
        }.isSuccess
    }

    private fun stopSession(requestedProfileId: String?, force: Boolean) {
        synchronized(lock) {
            val state = runtimeStore.read()
            if (requestedProfileId != null && requestedProfileId.isNotBlank() && state.profileId != requestedProfileId) {
                // Ignore a stale stop for another profile; never tear down the active phone.
                if (state.status !in ACTIVE_STATES && child?.isAlive != true) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                return
            }
            if (state.status !in ACTIVE_STATES && child?.isAlive != true) {
                updateState(RootfsRuntimeState(status = VmStatus.STOPPED, message = null))
                closeSessionResources()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return
            }
            stopping.set(true)
            if (state.profileId != null) updateState(state.copy(status = VmStatus.STOPPING, message = null))
            if (!force) {
                forwardToGuest("SHUTDOWN")
                val deadline = System.currentTimeMillis() + 1800L
                while (child?.isAlive == true && System.currentTimeMillis() < deadline) Thread.sleep(50)
            }
            runCatching { if (child?.isAlive == true) child?.destroy() }
            val gracefulDeadline = System.currentTimeMillis() + 700L
            while (child?.isAlive == true && System.currentTimeMillis() < gracefulDeadline) Thread.sleep(40)
            runCatching { if (child?.isAlive == true) child?.destroyForcibly() }
            val stopped = RootfsRuntimeState(status = VmStatus.STOPPED, message = null)
            updateState(stopped)
            closeSessionResources()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun streamGuestLog(profileId: String, process: Process, generation: Long) {
        Thread({
            val log = runtimeStore.logFile(profileId)
            runCatching {
                log.outputStream().buffered().use { out ->
                    process.inputStream.buffered().use { input ->
                        val buffer = ByteArray(16 * 1024)
                        while (generation == sessionGeneration) {
                            val count = input.read(buffer)
                            if (count <= 0) break
                            out.write(buffer, 0, count)
                            out.flush()
                        }
                    }
                }
            }
        }, "MD-Rootfs-GuestLog").apply { isDaemon = true; start() }
    }

    private fun watchChild(profileId: String, profileName: String, generation: Long) {
        Thread({
            val process = child ?: return@Thread
            val exitCode = runCatching { process.waitFor() }.getOrNull() ?: return@Thread
            if (generation != sessionGeneration || stopping.get()) return@Thread
            val state = runtimeStore.read()
            if (state.profileId == profileId && state.status in ACTIVE_STATES) {
                updateState(
                    state.copy(
                        status = VmStatus.ERROR,
                        message = "Android rootfs bootstrap exited with code $exitCode. Check the engine log.",
                    )
                )
                closeSessionResources()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }, "MD-Rootfs-ChildWatch").apply { isDaemon = true; start() }
    }

    private fun startHeartbeatLoop(generation: Long) {
        Thread({
            while (generation == sessionGeneration && !stopping.get()) {
                Thread.sleep(1000)
                val state = runtimeStore.read()
                if (state.status !in ACTIVE_STATES) break
                touchState(state)
            }
        }, "MD-Rootfs-Heartbeat").apply { isDaemon = true; start() }
    }

    private fun failStart(state: RootfsRuntimeState) {
        updateState(state)
        closeSessionResources()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun touchState(state: RootfsRuntimeState) {
        updateState(state.copy(updatedAtEpochMs = System.currentTimeMillis()))
    }

    private fun updateState(state: RootfsRuntimeState) {
        runtimeStore.write(state.copy(updatedAtEpochMs = System.currentTimeMillis()))
    }

    private fun closeSessionResources() {
        sessionGeneration++
        runCatching { guestServer?.close() }
        runCatching { uiServer?.close() }
        runCatching { guestWriter?.close() }
        guestServer = null
        uiServer = null
        guestWriter = null
        child = null
        sessionToken = null
        guestReady = false
        lastFrameSequence = 0L
    }

    private fun notification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_vm_notification)
            .setContentTitle("Multi Device")
            .setContentText(text)
            .setContentIntent(pending)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Virtual phone session", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the native Android rootfs phone active in the background"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun randomToken(): String {
        val bytes = ByteArray(24)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    companion object {
        private const val CHANNEL_ID = "multidevice_rootfs"
        private const val NOTIFICATION_ID = 101
        private const val MAX_UI_COMMAND_CHARS = 2048
        private const val ACTION_START = "com.virtual.devicelization.rootfs.START"
        private const val ACTION_SUSPEND = "com.virtual.devicelization.rootfs.SUSPEND"
        private const val ACTION_RESUME = "com.virtual.devicelization.rootfs.RESUME"
        private const val ACTION_STOP = "com.virtual.devicelization.rootfs.STOP"
        private const val ACTION_FORCE_STOP = "com.virtual.devicelization.rootfs.FORCE_STOP"
        private const val EXTRA_PROFILE_ID = "profile_id"
        private const val EXTRA_PROFILE_NAME = "profile_name"
        private const val EXTRA_IMAGE_ID = "image_id"
        private val ACTIVE_STATES = setOf(
            VmStatus.STARTING, VmStatus.RUNNING, VmStatus.SUSPENDING, VmStatus.SUSPENDED,
            VmStatus.RESUMING, VmStatus.STOPPING,
        )

        private fun dispatch(context: Context, intent: Intent) {
            ContextCompat.startForegroundService(context, intent)
        }

        fun start(context: Context, profileId: String, profileName: String, imageId: String) {
            dispatch(
                context,
                Intent(context, RootfsEngineService::class.java)
                    .setAction(ACTION_START)
                    .putExtra(EXTRA_PROFILE_ID, profileId)
                    .putExtra(EXTRA_PROFILE_NAME, profileName)
                    .putExtra(EXTRA_IMAGE_ID, imageId),
            )
        }

        fun suspend(context: Context, profileId: String) {
            dispatch(context, Intent(context, RootfsEngineService::class.java).setAction(ACTION_SUSPEND).putExtra(EXTRA_PROFILE_ID, profileId))
        }

        fun resume(context: Context, profileId: String) {
            dispatch(context, Intent(context, RootfsEngineService::class.java).setAction(ACTION_RESUME).putExtra(EXTRA_PROFILE_ID, profileId))
        }

        fun stop(context: Context, profileId: String, force: Boolean) {
            dispatch(
                context,
                Intent(context, RootfsEngineService::class.java)
                    .setAction(if (force) ACTION_FORCE_STOP else ACTION_STOP)
                    .putExtra(EXTRA_PROFILE_ID, profileId),
            )
        }
    }
}
