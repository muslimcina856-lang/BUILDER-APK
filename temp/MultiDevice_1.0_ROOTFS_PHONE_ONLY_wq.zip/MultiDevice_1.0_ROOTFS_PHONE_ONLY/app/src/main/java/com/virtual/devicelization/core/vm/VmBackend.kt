package com.virtual.devicelization.core.vm

import android.content.Context
import android.os.Build
import com.virtual.devicelization.core.model.Profile
import java.io.File

/** UI/profile code depends on this boundary, never on an emulator implementation. */
interface VmBackend {
    fun status(): VmBackendStatus
    suspend fun prepare(profile: Profile): Result<Unit>
    suspend fun start(profile: Profile): Result<Unit>
    suspend fun suspendVm(profile: Profile): Result<Unit>
    suspend fun resume(profile: Profile): Result<Unit>
    suspend fun shutdown(profile: Profile): Result<Unit>
    suspend fun forceStop(profile: Profile): Result<Unit>
    fun isRunning(profileId: String): Boolean = false
}

data class VmBackendStatus(
    val backendName: String,
    val available: Boolean,
    val arm64: Boolean,
    val linker64Present: Boolean,
    val rootfsProtocol: Int,
    val message: String,
)

class StockAndroidCapabilityScanner(private val context: Context) {
    fun scan(): VmBackendStatus {
        val arm64 = Build.SUPPORTED_64_BIT_ABIS.any { it.contains("arm64", ignoreCase = true) }
        val linker64 = File("/system/bin/linker64").isFile
        val ready = arm64 && linker64
        return VmBackendStatus(
            backendName = "Native Android RootFS Engine",
            available = ready,
            arm64 = arm64,
            linker64Present = linker64,
            rootfsProtocol = com.virtual.devicelization.core.model.VirtualPhoneSpec.FRAMEBUFFER_PROTOCOL,
            message = when {
                !arm64 -> "This build requires an ARM64 Android host."
                !linker64 -> "Android linker64 is unavailable on this host, so native rootfs sessions cannot start."
                else -> "Host runtime is ready for a compatible Multi Device Android rootfs bundle."
            },
        )
    }
}
