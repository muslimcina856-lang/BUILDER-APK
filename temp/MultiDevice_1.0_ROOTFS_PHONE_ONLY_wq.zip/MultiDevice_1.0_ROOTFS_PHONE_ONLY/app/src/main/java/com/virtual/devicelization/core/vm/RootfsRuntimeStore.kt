package com.virtual.devicelization.core.vm

import android.content.Context
import android.util.AtomicFile
import com.virtual.devicelization.core.model.VmStatus
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

internal data class RootfsRuntimeState(
    val profileId: String? = null,
    val profileName: String? = null,
    val status: VmStatus = VmStatus.STOPPED,
    val sessionToken: String? = null,
    val uiSocketName: String? = null,
    val guestSocketName: String? = null,
    val frameSequence: Long = 0L,
    val message: String? = null,
    val updatedAtEpochMs: Long = System.currentTimeMillis(),
)

internal class RootfsRuntimeStore(context: Context) {
    private val runtimeRoot = File(context.filesDir, "rootfs_runtime").apply { mkdirs() }
    private val atomic = AtomicFile(File(runtimeRoot, "engine_state.json"))

    @Synchronized
    fun read(): RootfsRuntimeState {
        if (!atomic.baseFile.isFile) return RootfsRuntimeState()
        return runCatching {
            val json = atomic.openRead().bufferedReader().use { it.readText() }
            val o = JSONObject(json)
            RootfsRuntimeState(
                profileId = o.optString("profileId").takeIf { it.isNotBlank() },
                profileName = o.optString("profileName").takeIf { it.isNotBlank() },
                status = runCatching { VmStatus.valueOf(o.optString("status")) }.getOrDefault(VmStatus.STOPPED),
                sessionToken = o.optString("sessionToken").takeIf { it.isNotBlank() },
                uiSocketName = o.optString("uiSocketName").takeIf { it.isNotBlank() },
                guestSocketName = o.optString("guestSocketName").takeIf { it.isNotBlank() },
                frameSequence = o.optLong("frameSequence", 0L),
                message = o.optString("message").takeIf { it.isNotBlank() },
                updatedAtEpochMs = o.optLong("updatedAt", 0L),
            )
        }.getOrElse { RootfsRuntimeState(status = VmStatus.ERROR, message = "Runtime state is unreadable.") }
    }

    @Synchronized
    fun write(state: RootfsRuntimeState) {
        val o = JSONObject().apply {
            put("profileId", state.profileId ?: "")
            put("profileName", state.profileName ?: "")
            put("status", state.status.name)
            put("sessionToken", state.sessionToken ?: "")
            put("uiSocketName", state.uiSocketName ?: "")
            put("guestSocketName", state.guestSocketName ?: "")
            put("frameSequence", state.frameSequence)
            put("message", state.message ?: "")
            put("updatedAt", state.updatedAtEpochMs)
        }
        var stream: FileOutputStream? = null
        try {
            stream = atomic.startWrite()
            stream.write(o.toString().toByteArray(Charsets.UTF_8))
            atomic.finishWrite(stream)
        } catch (t: Throwable) {
            stream?.let { atomic.failWrite(it) }
            throw t
        }
    }

    fun isAlive(profileId: String): Boolean {
        val state = read()
        if (state.profileId != profileId) return false
        if (state.status !in ACTIVE_STATES) return false
        return System.currentTimeMillis() - state.updatedAtEpochMs <= HEARTBEAT_GRACE_MS
    }

    fun framebufferFile(profileId: String): File = File(runtimeRoot, sanitize(profileId) + ".framebuffer")
    fun logFile(profileId: String): File = File(runtimeRoot, sanitize(profileId) + ".log")

    companion object {
        private const val HEARTBEAT_GRACE_MS = 5_000L
        private val ACTIVE_STATES = setOf(
            VmStatus.STARTING, VmStatus.RUNNING, VmStatus.SUSPENDING, VmStatus.SUSPENDED,
            VmStatus.RESUMING, VmStatus.STOPPING,
        )
        private fun sanitize(value: String) = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96)
    }
}
