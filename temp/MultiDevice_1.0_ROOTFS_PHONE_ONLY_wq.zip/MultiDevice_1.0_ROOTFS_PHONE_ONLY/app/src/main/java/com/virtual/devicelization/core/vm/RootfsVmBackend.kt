package com.virtual.devicelization.core.vm

import android.content.Context
import com.virtual.devicelization.core.image.GuestImageStore
import com.virtual.devicelization.core.model.NetworkMode
import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.core.model.VmStatus
import com.virtual.devicelization.core.network.HostVpnInspector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class RootfsVmBackend(
    private val context: Context,
    private val imageStore: GuestImageStore,
) : VmBackend {
    private val runtimeStore = RootfsRuntimeStore(context)
    private val vpn = HostVpnInspector(context)

    override fun status(): VmBackendStatus = StockAndroidCapabilityScanner(context).scan()

    override suspend fun prepare(profile: Profile): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val capabilities = status()
            require(capabilities.available) { capabilities.message }
            val image = imageStore.findFor(profile)
                ?: error("This phone does not have a compatible native rootfs image.")
            imageStore.validate(image)?.let { error(it) }
            if (profile.network.mode == NetworkMode.ENCRYPTED_TUNNEL && profile.network.killSwitch) {
                require(vpn.isVpnReady(profile.network.dnsProtection)) {
                    "Encrypted Tunnel is required but the Android host VPN path is not ready."
                }
            }
            imageStore.prepareProfileData(profile, image, reset = false)
            Unit
        }
    }

    override suspend fun start(profile: Profile): Result<Unit> = runCatching {
        val imageId = profile.imageId ?: error("Android rootfs image is not selected.")
        RootfsEngineService.start(context, profile.id, profile.name, imageId)
        await(profile.id, setOf(VmStatus.RUNNING), START_TIMEOUT_MS)
    }

    override suspend fun suspendVm(profile: Profile): Result<Unit> = runCatching {
        require(isRunning(profile.id)) { "Virtual phone is not running." }
        RootfsEngineService.suspend(context, profile.id)
        await(profile.id, setOf(VmStatus.SUSPENDED), CONTROL_TIMEOUT_MS)
    }

    override suspend fun resume(profile: Profile): Result<Unit> = runCatching {
        RootfsEngineService.resume(context, profile.id)
        await(profile.id, setOf(VmStatus.RUNNING), CONTROL_TIMEOUT_MS)
    }

    override suspend fun shutdown(profile: Profile): Result<Unit> = runCatching {
        RootfsEngineService.stop(context, profile.id, force = false)
        await(profile.id, setOf(VmStatus.STOPPED), STOP_TIMEOUT_MS, allowNoProfile = true)
    }

    override suspend fun forceStop(profile: Profile): Result<Unit> = runCatching {
        RootfsEngineService.stop(context, profile.id, force = true)
        await(profile.id, setOf(VmStatus.STOPPED), STOP_TIMEOUT_MS, allowNoProfile = true)
    }

    override fun isRunning(profileId: String): Boolean = runtimeStore.isAlive(profileId)

    private suspend fun await(
        profileId: String,
        accepted: Set<VmStatus>,
        timeoutMs: Long,
        allowNoProfile: Boolean = false,
    ) {
        val result = withTimeoutOrNull(timeoutMs) {
            while (true) {
                val state = runtimeStore.read()
                if (allowNoProfile && state.profileId == null && state.status == VmStatus.STOPPED) return@withTimeoutOrNull Unit
                if (state.profileId == profileId) {
                    if (state.status in accepted) return@withTimeoutOrNull Unit
                    if (state.status == VmStatus.ERROR) error(state.message ?: "Native rootfs engine failed.")
                }
                delay(100)
            }
        }
        if (result == null) {
            val state = runtimeStore.read()
            error(state.message ?: "Timed out waiting for native rootfs engine (${state.status}).")
        }
    }

    private companion object {
        const val START_TIMEOUT_MS = 45_000L
        const val CONTROL_TIMEOUT_MS = 8_000L
        const val STOP_TIMEOUT_MS = 6_000L
    }
}
