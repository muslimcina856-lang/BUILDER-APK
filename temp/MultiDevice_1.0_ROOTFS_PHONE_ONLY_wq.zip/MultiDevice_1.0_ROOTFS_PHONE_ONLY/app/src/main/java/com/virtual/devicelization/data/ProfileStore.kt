package com.virtual.devicelization.data

import android.content.Context
import com.virtual.devicelization.core.model.*
import org.json.JSONArray
import org.json.JSONObject

/** Persistent profile store. Fresh installs intentionally start empty. */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("multi_device_profiles", Context.MODE_PRIVATE)

    fun load(): List<Profile> {
        val raw = prefs.getString(KEY_PROFILES, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) add(fromJson(arr.getJSONObject(i)))
            }
        }.getOrElse { emptyList() }
    }

    fun save(profiles: List<Profile>) {
        val arr = JSONArray()
        profiles.forEach { arr.put(toJson(it)) }
        prefs.edit().putString(KEY_PROFILES, arr.toString()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_PROFILES).apply()
    }

    private fun toJson(p: Profile) = JSONObject().apply {
        put("schema", 2)
        put("id", p.id)
        put("name", p.name)
        put("androidVersion", p.androidVersion)
        put("apiLevel", p.apiLevel)
        put("architecture", p.architecture)
        put("imageId", p.imageId ?: JSONObject.NULL)
        put("status", p.status.name)
        put("createdAt", p.createdAtEpochMs)
        put("network", JSONObject().apply {
            put("mac", p.network.virtualMac)
            put("macMode", p.network.macMode.name)
            put("mode", p.network.mode.name)
            put("region", p.network.exitRegion)
            put("dns", p.network.dnsProtection)
            put("kill", p.network.killSwitch)
        })
    }

    private fun fromJson(o: JSONObject): Profile {
        val n = o.optJSONObject("network") ?: JSONObject()
        val status = runCatching { VmStatus.valueOf(o.optString("status", VmStatus.STOPPED.name)) }
            .getOrDefault(VmStatus.STOPPED)
        val macMode = runCatching { MacMode.valueOf(n.optString("macMode", MacMode.MANUAL_RESET_ONLY.name)) }
            .getOrDefault(MacMode.MANUAL_RESET_ONLY)
        val networkMode = runCatching { NetworkMode.valueOf(n.optString("mode", NetworkMode.DIRECT_NAT.name)) }
            .getOrDefault(NetworkMode.DIRECT_NAT)
        return Profile(
            id = o.getString("id"),
            name = o.optString("name", "Virtual Phone"),
            androidVersion = o.optInt("androidVersion", 9),
            apiLevel = o.optInt("apiLevel", 28),
            architecture = o.optString("architecture", "ARM64"),
            imageId = if (o.isNull("imageId")) null else o.optString("imageId", null),
            network = NetworkConfig(
                virtualMac = n.optString("mac", "02:00:00:00:00:01"),
                macMode = macMode,
                mode = networkMode,
                exitRegion = n.optString("region", "Singapore"),
                dnsProtection = n.optBoolean("dns", true),
                killSwitch = n.optBoolean("kill", true),
            ),
            status = status,
            createdAtEpochMs = o.optLong("createdAt", System.currentTimeMillis()),
        )
    }

    private companion object {
        const val KEY_PROFILES = "profiles"
    }
}
