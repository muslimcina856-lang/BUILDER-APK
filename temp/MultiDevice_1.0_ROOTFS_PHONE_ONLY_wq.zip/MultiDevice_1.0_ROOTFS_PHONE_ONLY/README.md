# Multi Device 1.0

Multi Device is an Android app for running one isolated virtual Android **phone** at a time.

This branch is phone-only and native-rootfs-only:

- one portrait phone presentation;
- no Phone/Tablet/Desktop/Foldable presets;
- no user-facing width, height, DPI, refresh-rate, CPU, RAM or storage geometry controls;
- no QEMU, QMP, VNC, UEFI/EDK2 or UTM runtime/fallback in the project;
- Android systems are imported as ARM64 `native-rootfs` protocol 2 bundles;
- the engine runs in the separate Android process `:rootfs_engine`;
- the UI attaches to a shared double framebuffer and authenticated local control socket;
- rotation or Activity recreation does not own the engine process;
- one active virtual phone is enforced by `SingleVmPolicy`.

## Phone engine

The host engine is implemented by:

- `RootfsEngineService` — foreground owner in `:rootfs_engine`;
- `RootfsVmBackend` — lifecycle boundary used by the app;
- `RootfsRuntimeStore` — cross-process heartbeat/state;
- `RootfsFrameBuffer` — protocol 2 shared double framebuffer;
- `RootfsGuestView` — SurfaceView renderer and touch/keyboard forwarding;
- `GuestImageStore` — safe rootfs bundle import, symlink restoration and per-phone data/snapshots.

A session is not marked `RUNNING` until the container bootstrap is alive, reports
`ANDROID_FRAMEWORK_READY`, and publishes at least one real guest frame.

## Android rootfs bundles

Use `tools/make_rootfs_bundle.py` to package a compatible ARM64 rootfs. See:

- `rootfs-template/README.md`
- `rootfs-sdk/protocol.md`

A normal stock AOSP filesystem dump is **not automatically a compatible bundle**. The bundle still
needs a container-aware bootstrap plus the guest-side property/Binder/HAL/graphics integration
required to run Android userspace inside an ordinary app sandbox. The host-side engine foundation is
present; that guest bridge is the remaining major runtime work before generic AOSP can boot end-to-end.

No VMOS rootfs, APK code, native libraries, artwork or other proprietary assets are included.

## Build

Requirements:

- Java 17+
- Android SDK 34
- Gradle 8.7 (wrapper configuration)

Debug:

```bash
./gradlew assembleDebug
```

Release:

```bash
./gradlew assembleRelease
```

Release minification and resource shrinking are enabled. `app/proguard-rules.pro` contains the
specific Error Prone annotation guards needed for the previously reported Google Tink R8 failure.

## Verification

```bash
python3 tools/verify_project.py
```

The repository also contains `core-selftest/CoreSelfTest.kt` for the platform-independent phone
contract and single-session policy.
