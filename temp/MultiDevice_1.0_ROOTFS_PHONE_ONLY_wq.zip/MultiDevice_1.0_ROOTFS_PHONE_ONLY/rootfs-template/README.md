# Multi Device native rootfs bundle

This build accepts only **native-rootfs protocol 2** bundles. It does not accept QEMU/UTM disk
images and it does not cold-boot firmware.

Bundle layout:

```text
manifest.json
rootfs/                 extracted Android root filesystem
bridge/md-container-init  container-aware ARM64 bootstrap ELF
bridge/lib/              optional bootstrap libraries
```

`md-container-init` is not stock Android `/init`. It must be built for the Multi Device host
contract in `rootfs-sdk/protocol.md`, virtualize the Android userspace pieces it needs, connect to
the authenticated guest socket, and publish frames to the shared framebuffer. The host marks a
phone RUNNING only after it receives both `ANDROID_FRAMEWORK_READY` and a real `FRAME` event.

Use `tools/make_rootfs_bundle.py` to package a prepared rootfs. The packer records rootfs symlinks
in `manifest.json`; the Android importer restores only relative symlinks that remain inside the
rootfs tree.
