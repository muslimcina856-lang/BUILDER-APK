# R8 release compatibility fix

The reported release failure was caused by R8 seeing Google Tink references to Error Prone
annotations that were not on the shrinker classpath:

- `com.google.errorprone.annotations.CanIgnoreReturnValue`
- `com.google.errorprone.annotations.CheckReturnValue`
- `com.google.errorprone.annotations.Immutable`
- `com.google.errorprone.annotations.RestrictedApi`

Multi Device now ships `app/proguard-rules.pro` with targeted `-dontwarn` rules for those four
compile-time annotation classes, and the release build type references that rules file.

The supplied failure log itself names a different project/package (`RailwayDeck`,
`com.railway.deck`). That source project was not supplied, so this repository cannot honestly claim
to have modified RailwayDeck. The same four rules are the drop-in fix for that project's
`app/proguard-rules.pro` when its source is available.

The long Kotlin Analysis API warnings in that log were warnings; the fatal task was
`:app:minifyReleaseWithR8` and the four missing Error Prone annotation classes above.
