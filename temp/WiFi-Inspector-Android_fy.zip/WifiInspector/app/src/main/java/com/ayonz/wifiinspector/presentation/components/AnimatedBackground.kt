package com.ayonz.wifiinspector.presentation.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.ayonz.wifiinspector.presentation.theme.NeonCyan
import com.ayonz.wifiinspector.presentation.theme.NeonPink
import com.ayonz.wifiinspector.presentation.theme.NeonPurple
import com.ayonz.wifiinspector.presentation.theme.backgroundGradient

/**
 * Latar animasi lembut berupa "orb" cahaya neon yang melayang perlahan,
 * memberi kesan futuristik tanpa membebani performa (murni Canvas, tanpa bitmap berat).
 */
@Composable
fun AnimatedBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val transition = rememberInfiniteTransition(label = "bg")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse),
        label = "orbMove"
    )

    Box(modifier = modifier.fillMaxSize().background(backgroundGradient(dark))) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val alpha = if (dark) 0.22f else 0.14f

            drawCircle(
                brush = Brush.radialGradient(listOf(NeonCyan.copy(alpha = alpha), Color.Transparent)),
                radius = w * 0.55f,
                center = Offset(w * (0.15f + 0.1f * t), h * 0.18f)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(NeonPurple.copy(alpha = alpha), Color.Transparent)),
                radius = w * 0.6f,
                center = Offset(w * (0.85f - 0.15f * t), h * 0.4f)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(NeonPink.copy(alpha = alpha * 0.8f), Color.Transparent)),
                radius = w * 0.5f,
                center = Offset(w * (0.3f + 0.2f * t), h * (0.85f - 0.1f * t))
            )
        }
        content()
    }
}
