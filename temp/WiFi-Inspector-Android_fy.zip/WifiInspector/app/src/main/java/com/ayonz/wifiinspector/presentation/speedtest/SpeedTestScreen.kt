package com.ayonz.wifiinspector.presentation.speedtest

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.presentation.components.AnimatedBackground
import com.ayonz.wifiinspector.presentation.components.GlassCard

@Composable
fun SpeedTestScreen(viewModel: SpeedTestViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    AnimatedBackground {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "Speed Test",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Uji kecepatan unduh internet Anda saat ini",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(28.dp))

            SpeedDial(isRunning = uiState.isRunning, mbps = uiState.result?.downloadMbps)

            Spacer(Modifier.height(28.dp))

            if (uiState.result != null) {
                GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 18.dp) {
                    Column {
                        ResultRow("Ping", "${uiState.result!!.pingMs} ms")
                        ResultRow("Jitter", "${uiState.result!!.jitterMs} ms")
                        ResultRow("Download", "%.1f Mbps".format(uiState.result!!.downloadMbps))
                    }
                }
                Spacer(Modifier.height(20.dp))
            }

            if (uiState.errorMessage != null) {
                Text(
                    uiState.errorMessage.orEmpty(),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(bottom = 14.dp)
                )
            }

            Button(
                onClick = { viewModel.runTest() },
                enabled = !uiState.isRunning,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(if (uiState.isRunning) "Mengukur..." else "Mulai Speed Test")
            }
        }
    }
}

@Composable
private fun SpeedDial(isRunning: Boolean, mbps: Double?) {
    val transition = rememberInfiniteTransition(label = "speedSpin")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "rotate"
    )

    Box(contentAlignment = Alignment.Center) {
        GlassCard(modifier = Modifier.size(200.dp), cornerRadius = 100.dp) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    androidx.compose.material3.Icon(
                        Icons.Filled.Speed,
                        contentDescription = null,
                        modifier = Modifier
                            .size(36.dp)
                            .rotate(if (isRunning) rotation else 0f),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (mbps != null) "%.1f".format(mbps) else "--",
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text("Mbps", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun ResultRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
