package com.ayonz.wifiinspector.domain.model

data class SpeedTestResult(
    val downloadMbps: Double,
    val pingMs: Long,
    val jitterMs: Long,
    val timestampMillis: Long
)

data class PingResult(
    val host: String,
    val successCount: Int,
    val failCount: Int,
    val minMs: Long,
    val maxMs: Long,
    val avgMs: Double,
    val packetLossPercent: Double,
    val samples: List<Long>
)

data class ScanHistoryEntry(
    val id: Long = 0,
    val timestampMillis: Long,
    val networkCount: Int,
    val strongestSsid: String?,
    val strongestDbm: Int?
)

data class UserLocation(
    val latitude: Double,
    val longitude: Double
)
