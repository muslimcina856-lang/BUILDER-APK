package com.ayonz.wifiinspector.data.source

import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

/**
 * Speed test sederhana & ringan: mengunduh berkas uji berukuran tetap dari endpoint publik
 * yang memang disediakan untuk pengujian kecepatan (Cloudflare speed test), lalu menghitung
 * throughput. Tidak menyentuh jaringan atau perangkat lain milik pengguna.
 */
class SpeedTestDataSource {

    // Endpoint resmi Cloudflare yang memang disediakan untuk speed testing.
    private val downloadTestUrl = "https://speed.cloudflare.com/__down?bytes=15000000"
    private val latencyTestUrl = "https://speed.cloudflare.com/__down?bytes=1000"

    suspend fun runSpeedTest(): Result<SpeedTestResult> = withContext(Dispatchers.IO) {
        try {
            // 1. Ukur latensi (beberapa sample kecil untuk ping + jitter)
            val samples = mutableListOf<Long>()
            repeat(4) {
                val t = measureLatencyOnce()
                if (t >= 0) samples.add(t)
            }
            val avgPing = if (samples.isNotEmpty()) samples.average().toLong() else -1L
            val jitter = if (samples.size > 1) {
                val diffs = samples.zipWithNext { a, b -> abs(a - b) }
                diffs.average().toLong()
            } else 0L

            // 2. Ukur throughput download
            val connection = (URL(downloadTestUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 15000
                requestMethod = "GET"
            }
            connection.connect()

            val startTime = System.nanoTime()
            var totalBytes = 0L
            connection.inputStream.use { input ->
                val buffer = ByteArray(32 * 1024)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    totalBytes += read
                }
            }
            val elapsedSeconds = (System.nanoTime() - startTime) / 1_000_000_000.0
            connection.disconnect()

            val mbps = if (elapsedSeconds > 0) {
                (totalBytes * 8.0) / elapsedSeconds / 1_000_000.0
            } else 0.0

            Result.success(
                SpeedTestResult(
                    downloadMbps = mbps,
                    pingMs = avgPing,
                    jitterMs = jitter,
                    timestampMillis = System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun measureLatencyOnce(): Long {
        return try {
            val connection = (URL(latencyTestUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                requestMethod = "GET"
            }
            val start = System.nanoTime()
            connection.connect()
            connection.responseCode
            val elapsed = (System.nanoTime() - start) / 1_000_000
            connection.disconnect()
            elapsed
        } catch (e: Exception) {
            -1L
        }
    }
}
