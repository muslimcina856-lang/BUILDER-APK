package com.ayonz.wifiinspector.presentation.speedtest

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ayonz.wifiinspector.di.AppContainer
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import com.ayonz.wifiinspector.domain.usecase.RunSpeedTestUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SpeedTestUiState(
    val isRunning: Boolean = false,
    val result: SpeedTestResult? = null,
    val errorMessage: String? = null
)

class SpeedTestViewModel(
    private val runSpeedTestUseCase: RunSpeedTestUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SpeedTestUiState())
    val uiState: StateFlow<SpeedTestUiState> = _uiState.asStateFlow()

    fun runTest() {
        if (_uiState.value.isRunning) return
        viewModelScope.launch {
            _uiState.update { it.copy(isRunning = true, errorMessage = null) }
            runSpeedTestUseCase()
                .onSuccess { result -> _uiState.update { it.copy(isRunning = false, result = result) } }
                .onFailure { e ->
                    _uiState.update {
                        it.copy(isRunning = false, errorMessage = e.message ?: "Speed test gagal dijalankan.")
                    }
                }
        }
    }

    companion object {
        fun factory(container: AppContainer) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return SpeedTestViewModel(container.runSpeedTestUseCase) as T
            }
        }
    }
}
