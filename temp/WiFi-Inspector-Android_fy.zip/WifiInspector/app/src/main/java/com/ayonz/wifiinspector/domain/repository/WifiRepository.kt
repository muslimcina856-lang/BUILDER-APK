package com.ayonz.wifiinspector.domain.repository

import com.ayonz.wifiinspector.domain.model.ConnectedNetworkInfo
import com.ayonz.wifiinspector.domain.model.PingResult
import com.ayonz.wifiinspector.domain.model.ScanHistoryEntry
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import com.ayonz.wifiinspector.domain.model.UserLocation
import com.ayonz.wifiinspector.domain.model.WifiNetworkInfo
import kotlinx.coroutines.flow.Flow

/**
 * Kontrak utama akses data WiFi. Diimplementasikan di layer data.
 * Layer presentation/domain tidak pernah bergantung langsung pada Android WifiManager.
 */
interface WifiRepository {

    /** Memicu satu kali scan WiFi dan mengembalikan daftar jaringan yang ditemukan. */
    suspend fun scanNetworks(): Result<List<WifiNetworkInfo>>

    /** Observasi hasil scan sebagai stream (dipakai untuk auto-refresh berkala). */
    fun observeScanResults(): Flow<List<WifiNetworkInfo>>

    /** Informasi jaringan yang sedang tersambung saat ini. */
    fun observeConnectedNetwork(): Flow<ConnectedNetworkInfo>

    /** Lokasi pengguna saat ini (butuh izin lokasi). */
    suspend fun getUserLocation(): Result<UserLocation>

    /** Menjalankan speed test download sederhana. */
    suspend fun runSpeedTest(): Result<SpeedTestResult>

    /** Menjalankan ping test ke host tertentu. */
    suspend fun runPingTest(host: String, count: Int): Result<PingResult>

    /** Riwayat hasil scan tersimpan (local database). */
    fun observeScanHistory(): Flow<List<ScanHistoryEntry>>

    suspend fun saveScanToHistory(networks: List<WifiNetworkInfo>)

    suspend fun clearHistory()
}
