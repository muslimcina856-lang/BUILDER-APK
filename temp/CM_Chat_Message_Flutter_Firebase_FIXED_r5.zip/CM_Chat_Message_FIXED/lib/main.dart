import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Configure Firebase using `flutterfire configure` and generated firebase_options.dart.
  await Firebase.initializeApp();
  runApp(Provider(create: (_) => AuthService(), child: const CMApp()));
}
class CMApp extends StatelessWidget {
  const CMApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'CM Chat Message', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF075E54))),
    home: StreamBuilder(
      stream: context.read<AuthService>().authStateChanges,
      builder: (_, s) => s.connectionState == ConnectionState.waiting
        ? const Scaffold(body: Center(child: CircularProgressIndicator()))
        : s.data == null ? const AuthScreen() : const HomeScreen(),
    ),
  );
}
