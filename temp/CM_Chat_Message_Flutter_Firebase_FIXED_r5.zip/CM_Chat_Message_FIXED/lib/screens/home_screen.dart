import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../services/chat_service.dart';
import 'chat_screen.dart';
import 'status_screen.dart';
import 'calls_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
 int index=0; final chat=ChatService();
 @override Widget build(BuildContext context) {
  final uid=context.read<AuthService>().currentUser!.uid;
  final pages=[contacts(uid),const StatusScreen(),const CallsScreen(),const SettingsScreen()];
  return Scaffold(appBar:AppBar(title:const Text('CM Chat Message')),body:pages[index],
   bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const [
    NavigationDestination(icon:Icon(Icons.chat),label:'Chat'),NavigationDestination(icon:Icon(Icons.circle_outlined),label:'Status'),
    NavigationDestination(icon:Icon(Icons.call),label:'Telepon'),NavigationDestination(icon:Icon(Icons.settings),label:'Pengaturan')]));
 }
 Widget contacts(String uid)=>StreamBuilder(stream:chat.users(),builder:(context,s){
  if(s.hasError)return Center(child:Text('Error: ${s.error}')); if(!s.hasData)return const Center(child:CircularProgressIndicator());
  final docs=s.data!.docs.where((d)=>d.id!=uid).toList(); if(docs.isEmpty)return const Center(child:Text('Belum ada kontak.'));
  return ListView(children:docs.map((d){final data=d.data();final name=data['displayName']??'Pengguna';return ListTile(
   leading:const CircleAvatar(child:Icon(Icons.person)),title:Row(children:[Flexible(child:Text(name)),if(data['verified']==true)const Icon(Icons.verified,color:Colors.blue,size:17)]),
   subtitle:Text(data['phoneNumber']??''),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ChatScreen(
    chatId:chat.chatId(uid,d.id),peerName:name,uid:uid,service:chat))));
  }).toList());
 });
}
