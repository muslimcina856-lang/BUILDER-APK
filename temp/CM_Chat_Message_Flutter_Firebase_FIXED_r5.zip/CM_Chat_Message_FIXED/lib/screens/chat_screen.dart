import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import '../services/chat_service.dart';
class ChatScreen extends StatefulWidget {
 const ChatScreen({super.key,required this.chatId,required this.peerName,required this.uid,required this.service});
 final String chatId,peerName,uid; final ChatService service;
 @override State<ChatScreen> createState()=>_ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen>{
 final text=TextEditingController(); bool uploading=false;
 Future<void> upload(String type)async{
  File? f; String name='';
  if(type=='file'){final r=await FilePicker.platform.pickFiles();if(r?.files.single.path==null)return;f=File(r!.files.single.path!);name=r.files.single.name;}
  else {final p=ImagePicker();final x=type=='video'?await p.pickVideo(source:ImageSource.gallery):await p.pickImage(source:ImageSource.gallery);if(x==null)return;f=File(x.path);name=x.name;}
  setState(()=>uploading=true);try{await widget.service.sendFile(widget.chatId,widget.uid,f!,type,name);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}finally{if(mounted)setState(()=>uploading=false);}
 }
 @override void dispose(){text.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.peerName)),body:Column(children:[
  Expanded(child:StreamBuilder(stream:widget.service.messages(widget.chatId),builder:(context,s){
   if(!s.hasData)return const Center(child:CircularProgressIndicator());final docs=s.data!.docs;
   return ListView(reverse:true,children:docs.map((d){final m=d.data();final mine=m['senderId']==widget.uid;final t=(m['createdAt'] as Timestamp?)?.toDate();
    return Align(alignment:mine?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.all(5),padding:const EdgeInsets.all(10),
     decoration:BoxDecoration(color:mine?const Color(0xFFD9FDD3):Colors.white,borderRadius:BorderRadius.circular(12)),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
      if((m['type']??'text')=='text')Text(m['text']??'') else Text('${m['type']}: ${m['fileName']??m['mediaUrl']??''}'),
      Text(t==null?'...':DateFormat.Hm().format(t),style:const TextStyle(fontSize:10))])));}).toList());
  })),
  if(uploading)const LinearProgressIndicator(),
  SafeArea(child:Row(children:[
   IconButton(onPressed:()=>upload('image'),icon:const Icon(Icons.image)),IconButton(onPressed:()=>upload('video'),icon:const Icon(Icons.video_library)),
   IconButton(onPressed:()=>upload('file'),icon:const Icon(Icons.attach_file)),
   Expanded(child:TextField(controller:text,decoration:const InputDecoration(hintText:'Pesan...'))),
   IconButton(icon:const Icon(Icons.send),onPressed:(){widget.service.sendText(widget.chatId,widget.uid,text.text);text.clear();})
  ]))
 ]));
}
