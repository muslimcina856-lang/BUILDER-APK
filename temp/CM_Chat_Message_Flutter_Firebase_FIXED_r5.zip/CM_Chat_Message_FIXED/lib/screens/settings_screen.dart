import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
class SettingsScreen extends StatelessWidget {const SettingsScreen({super.key});
 @override Widget build(BuildContext c){final u=c.read<AuthService>().currentUser;return ListView(children:[
 const SizedBox(height:20),const CircleAvatar(radius:36,child:Icon(Icons.person,size:40)),
 Center(child:Text(u?.phoneNumber??'Akun')),const ListTile(leading:Icon(Icons.security),title:Text('Keamanan'),
 subtitle:Text('Role owner dan badge verified wajib diatur server-side.')),
 ListTile(leading:const Icon(Icons.logout),title:const Text('Keluar'),onTap:()=>c.read<AuthService>().signOut())
 ]);}
}
