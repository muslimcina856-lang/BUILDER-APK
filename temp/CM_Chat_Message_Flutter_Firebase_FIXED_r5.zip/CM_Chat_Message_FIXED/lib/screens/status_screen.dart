import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../services/status_service.dart';
class StatusScreen extends StatelessWidget {
 const StatusScreen({super.key});
 Future<void> upload(BuildContext c,bool video)async{
  final p=ImagePicker();final x=video?await p.pickVideo(source:ImageSource.gallery):await p.pickImage(source:ImageSource.gallery);
  if(x==null)return;try{await StatusService().upload(c.read<AuthService>().currentUser!.uid,File(x.path),video);
   if(c.mounted)ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Status aktif selama 24 jam.')));
  }catch(e){if(c.mounted)ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$e')));}
 }
 @override Widget build(BuildContext context)=>ListView(children:[
  ListTile(leading:const CircleAvatar(child:Icon(Icons.add_a_photo)),title:const Text('Status saya'),subtitle:const Text('Foto/video · 24 jam'),
   trailing:PopupMenuButton<bool>(onSelected:(v)=>upload(context,v),itemBuilder:(_)=>const [PopupMenuItem(value:false,child:Text('Foto')),PopupMenuItem(value:true,child:Text('Video'))])),
  const Divider(),const Padding(padding:EdgeInsets.all(20),child:Text('Status kedaluwarsa difilter berdasarkan expiresAt.'))
 ]);
}
