import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final phone = TextEditingController(), code = TextEditingController();
  String? verificationId; bool waiting = false, busy = false;
  @override void dispose() { phone.dispose(); code.dispose(); super.dispose(); }
  void msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  Future<void> send() async {
    final p = phone.text.trim();
    if (!p.startsWith('+') || p.length < 8) { msg('Pakai format internasional, contoh +6281234567890'); return; }
    setState(() => busy = true);
    await context.read<AuthService>().requestOtp(p, codeSent: (id) {
      if (!mounted) return; setState(() { verificationId = id; waiting = true; busy = false; });
      msg('Kode verifikasi dikirim lewat SMS Firebase.');
    }, failed: (e) { if (mounted) { setState(() => busy = false); msg(e); }});
  }
  Future<void> verify() async {
    if (verificationId == null || code.text.trim().length != 6) { msg('Masukkan kode SMS 6 digit.'); return; }
    try { await context.read<AuthService>().verifyOtp(verificationId!, code.text.trim()); }
    catch (e) { msg('Verifikasi gagal: $e'); }
  }
  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(
    child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Image.asset('assets/images/cm_chat_message_icon.png', height: 150),
        const SizedBox(height: 18), const Text('CM Chat Message', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        TextField(controller: phone, keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'Nomor telepon (+62...)')),
        if (waiting) TextField(controller: code, maxLength: 6, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Kode SMS')),
        const SizedBox(height: 12),
        FilledButton(onPressed: busy ? null : (waiting ? verify : send),
          child: Text(busy ? 'Memproses...' : waiting ? 'Verifikasi' : 'Kirim kode SMS')),
        const SizedBox(height: 10),
        const Text('Verifikasi resmi Firebase SMS. Aplikasi tidak menyadap WhatsApp atau mengirim OTP palsu.',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
      ]))));
}
