import 'package:flutter/material.dart';
import '../services/call_service.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
class CallsScreen extends StatefulWidget {const CallsScreen({super.key});@override State<CallsScreen> createState()=>_CallsScreenState();}
class _CallsScreenState extends State<CallsScreen>{
 final service=CallService();MediaStream? stream;String status='Panggilan antar pengguna memerlukan signaling server.';
 Future<void> test(bool video)async{try{final s=await service.localMedia(video:video);setState(()=>stream=s);setState(()=>status=video?'Kamera/mikrofon lokal aktif':'Mikrofon lokal aktif');}catch(e){setState(()=>status='$e');}}
 @override void dispose(){stream?.dispose();super.dispose();}
 @override Widget build(BuildContext c)=>Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[
 const Icon(Icons.video_call,size:64),const Text('Telepon & Video Call',style:TextStyle(fontSize:22)),Text(status),
 FilledButton(onPressed:()=>test(false),child:const Text('Tes mikrofon')),OutlinedButton(onPressed:()=>test(true),child:const Text('Tes kamera')),
 TextButton(onPressed:(){stream?.dispose();setState(() { stream = null; status = 'Media dihentikan'; });},child:const Text('Hentikan'))
 ])));
}
