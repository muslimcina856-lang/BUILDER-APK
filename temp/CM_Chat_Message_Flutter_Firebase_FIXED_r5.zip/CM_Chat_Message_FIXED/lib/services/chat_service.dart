import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

class ChatService {
 final db=FirebaseFirestore.instance; final storage=FirebaseStorage.instance;
 Stream<QuerySnapshot<Map<String,dynamic>>> users()=>db.collection('users').orderBy('displayName').snapshots();
 String chatId(String a,String b){final ids=[a,b]..sort();return '${ids[0]}_${ids[1]}';}
 Stream<QuerySnapshot<Map<String,dynamic>>> messages(String id)=>db.collection('chats').doc(id).collection('messages').orderBy('createdAt',descending:true).snapshots();
 Future<void> sendText(String id,String uid,String text) async {
  if(text.trim().isEmpty)return;
  await db.collection('chats').doc(id).collection('messages').add({'senderId':uid,'type':'text','text':text.trim(),'createdAt':FieldValue.serverTimestamp(),'readBy':[uid]});
  await db.collection('chats').doc(id).set({'lastMessage':text.trim(),'lastMessageAt':FieldValue.serverTimestamp()},SetOptions(merge:true));
 }
 Future<void> sendFile(String id,String uid,File file,String type,String name) async {
  final ref=storage.ref('chat_uploads/$id/${const Uuid().v4()}-$name');
  final task=await ref.putFile(file); final url=await task.ref.getDownloadURL();
  await db.collection('chats').doc(id).collection('messages').add({'senderId':uid,'type':type,'mediaUrl':url,'fileName':name,'createdAt':FieldValue.serverTimestamp(),'readBy':[uid]});
 }
 Future<void> addContact(String uid,String phone)=>db.collection('users').doc(uid).collection('contacts').add({'phoneNumber':phone,'createdAt':FieldValue.serverTimestamp()});
}
