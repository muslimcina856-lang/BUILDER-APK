import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
class CallService {
 Future<MediaStream> localMedia({required bool video}) async {
  if(!(await Permission.microphone.request()).isGranted) throw Exception('Izin mikrofon ditolak');
  if(video && !(await Permission.camera.request()).isGranted) throw Exception('Izin kamera ditolak');
  return navigator.mediaDevices.getUserMedia({'audio':true,'video':video?{'facingMode':'user'}:false});
 }
}
// Untuk panggilan antar-user masih diperlukan signaling offer/answer/ICE dan STUN/TURN.
