import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;
  Stream<User?> get authStateChanges => _auth.authStateChanges();
  User? get currentUser => _auth.currentUser;

  Future<void> requestOtp(String phone, {
    required void Function(String id) codeSent,
    required void Function(String error) failed,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (e) => failed(e.message ?? e.code),
      codeSent: (id, _) => codeSent(id),
      codeAutoRetrievalTimeout: (id) => codeSent(id),
    );
  }

  Future<void> verifyOtp(String id, String code) async {
    final result = await _auth.signInWithCredential(
      PhoneAuthProvider.credential(verificationId: id, smsCode: code));
    final user = result.user;
    if (user == null) return;
    final ref = _db.collection('users').doc(user.uid);
    final old = await ref.get();
    await ref.set({
      'uid': user.uid, 'phoneNumber': user.phoneNumber ?? '',
      'displayName': old.data()?['displayName'] ?? 'Pengguna',
      'role': old.data()?['role'] ?? 'user',
      'verified': old.data()?['verified'] ?? false,
      'createdAt': old.data()?['createdAt'] ?? FieldValue.serverTimestamp(),
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
  Future<void> signOut() => _auth.signOut();
}
