import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';
class StatusService {
 final db=FirebaseFirestore.instance; final storage=FirebaseStorage.instance;
 Future<void> upload(String uid,File file,bool video) async {
  final ref=storage.ref('statuses/$uid/${const Uuid().v4()}');
  final task=await ref.putFile(file); final url=await task.ref.getDownloadURL(); final now=DateTime.now();
  await db.collection('statuses').add({'uid':uid,'mediaUrl':url,'type':video?'video':'image','createdAt':Timestamp.fromDate(now),'expiresAt':Timestamp.fromDate(now.add(const Duration(hours:24)))});
 }
 Stream<QuerySnapshot<Map<String,dynamic>>> active()=>db.collection('statuses').where('expiresAt',isGreaterThan:Timestamp.now()).orderBy('expiresAt').snapshots();
}
