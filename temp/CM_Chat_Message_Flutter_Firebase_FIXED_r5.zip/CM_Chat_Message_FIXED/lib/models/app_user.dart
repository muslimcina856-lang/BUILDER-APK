class AppUser {
  const AppUser({required this.uid, required this.phoneNumber, required this.displayName, this.role='user', this.verified=false});
  final String uid, phoneNumber, displayName, role;
  final bool verified;
  factory AppUser.fromMap(String uid, Map<String,dynamic> d) => AppUser(
    uid: uid, phoneNumber: d['phoneNumber'] ?? '', displayName: d['displayName'] ?? 'Pengguna',
    role: d['role'] ?? 'user', verified: d['verified'] ?? false);
  Map<String,dynamic> toMap() => {'uid':uid,'phoneNumber':phoneNumber,'displayName':displayName,'role':role,'verified':verified};
}
