import 'package:cloud_firestore/cloud_firestore.dart';
class ChatMessage {
  const ChatMessage({required this.id,required this.senderId,required this.type,required this.createdAt,this.text='',this.mediaUrl});
  final String id,senderId,type,text; final DateTime createdAt; final String? mediaUrl;
  factory ChatMessage.fromMap(String id,Map<String,dynamic> d)=>ChatMessage(
    id:id,senderId:d['senderId']??'',type:d['type']??'text',text:d['text']??'',
    mediaUrl:d['mediaUrl'],createdAt:(d['createdAt'] as Timestamp?)?.toDate()??DateTime.now());
}
