package com.cmchatmessage.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
