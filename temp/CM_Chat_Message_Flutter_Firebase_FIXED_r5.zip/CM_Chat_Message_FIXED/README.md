# CM Chat Message — Flutter/Firebase project

Project includes `lib/`, `assets/`, Android app scaffold, launcher icon generated from the supplied image, Firebase services, and example rules.

## Setup (required before running)
1. Install Flutter stable and Android Studio/Android SDK.
2. Create a Firebase project.
3. In Firebase Console, add an Android app with package name `com.cmchatmessage.app`.
4. Enable Authentication → Phone, Cloud Firestore, and Storage.
5. Install FlutterFire CLI and configure this project:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
6. `flutterfire configure` creates `lib/firebase_options.dart`. Update `lib/main.dart`:
   ```dart
   import 'firebase_options.dart';
   // Replace await Firebase.initializeApp();
   await Firebase.initializeApp(
     options: DefaultFirebaseOptions.currentPlatform,
   );
   ```
   Alternatively, use the Android `google-services.json` flow and initialize Firebase with native configuration. Do not commit service-account credentials.
7. Apply and review `firestore.rules` and `storage.rules`.
8. From the project root:
   ```bash
   flutter pub get
   flutter run
   ```

## Included starter features
- Phone-number sign-in through Firebase Phone Authentication (Firebase SMS OTP).
- Firestore user list and realtime text chat.
- Firebase Storage upload flow for images, videos, and files.
- Status records with 24-hour expiration timestamps.
- Bottom navigation: Chat, Status, Telepon, Pengaturan.
- Camera/microphone permission requests and local WebRTC media test.
- Launcher/app icon based on the image supplied by the user.

## Important limitations
- This ZIP is a source project, not a prebuilt APK. Firebase configuration is project-specific and cannot be fabricated.
- Firebase Phone Auth uses the official SMS verification flow; this app does not intercept WhatsApp messages or simulate access to someone else's OTP.
- The included WebRTC screen tests local camera/microphone only. Actual user-to-user calls require signaling (offer/answer/ICE), STUN/TURN servers, call invitation handling, and push notifications.
- Role `owner` and verified badges must be granted server-side after authorization; do not trust a hard-coded phone number in client code.
- Firestore rules are starter examples and must be tightened for chat participant membership before production.
- I cannot claim a successful Flutter/Gradle build here because Flutter SDK/build tooling is not installed in this environment. ZIP integrity and required file presence have been checked.
