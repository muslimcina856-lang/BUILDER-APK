package com.example.webapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import android.util.Base64;
import android.os.Build;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.content.pm.PackageManager;
import android.Manifest;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import android.location.LocationManager;
import android.provider.Settings;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.content.IntentSender;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.common.api.ResolvableApiException;

public class MainActivity extends Activity {
    
    private WebView myWebView;
    private ValueCallback<Uri[]> mFilePathCallback;
    private GeolocationPermissions.Callback mGeoCallback;
    private String mGeoOrigin;
    private PermissionRequest mPendingRequest;
    private ConnectivityManager mConnectivityManager;
    private ConnectivityManager.NetworkCallback mNetworkCallback;
    
    private static final int REQ_STORAGE = 100;
    private static final int REQ_LOCATION = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_GPS_SETTINGS = 103;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            FrameLayout root = new FrameLayout(this);
            root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            setContentView(root); 

            myWebView = new WebView(this);
            myWebView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            root.addView(myWebView);

            if (Build.VERSION.SDK_INT >= 23) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                }
            }

            WebSettings settings = myWebView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setDatabaseEnabled(true);
            settings.setGeolocationEnabled(true);
            settings.setSupportZoom(true);
            settings.setBuiltInZoomControls(true);
            settings.setDisplayZoomControls(false);
            

            myWebView.setWebChromeClient(new WebChromeClient() {
                public void onPermissionRequest(final PermissionRequest request) { 
                    mPendingRequest = request;
                    List<String> missingPermissions = new ArrayList<>();
                    for (String res : request.getResources()) {
                        if (res.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) { if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) missingPermissions.add(Manifest.permission.CAMERA); }
                        if (res.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missingPermissions.add(Manifest.permission.RECORD_AUDIO); }
                    }
                    if (!missingPermissions.isEmpty()) {
                        if (Build.VERSION.SDK_INT >= 23) requestPermissions(missingPermissions.toArray(new String[0]), REQ_MEDIA);
                    } else {
                        request.grant(request.getResources());
                    }
                }
                
                public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback callback) { 
                    mGeoCallback = callback; mGeoOrigin = origin;
                    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
                    } else {
                        promptForLocation();
                    }
                }
                public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> f, FileChooserParams p) {
                    if(mFilePathCallback != null) mFilePathCallback.onReceiveValue(null);
                    mFilePathCallback = f;
                    try { startActivityForResult(p.createIntent(), 100); } catch(Exception e) { mFilePathCallback = null; return false; }
                    return true;
                }
            });

            myWebView.setWebViewClient(new WebViewClient() {
                @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) { view.loadUrl("file:///android_asset/offline.html"); }
                @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) { if (request.isForMainFrame()) view.loadUrl("file:///android_asset/offline.html"); }
                @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    if(url == null || url.startsWith("file:///android_asset/")) return false;
                    if(url.startsWith("http") || url.startsWith("file")) return false;
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception e) {} return true;
                }
            });
            
            myWebView.setDownloadListener(new DownloadListener() {
                public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                    try { Intent i = new Intent(Intent.ACTION_VIEW); i.setData(Uri.parse(url)); startActivity(i); } catch (Exception e) {}
                }
            });

            mConnectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= 24) {
                mNetworkCallback = new ConnectivityManager.NetworkCallback() {
                    @Override public void onLost(Network network) { runOnUiThread(new Runnable() { public void run() { if (myWebView != null) myWebView.loadUrl("file:///android_asset/offline.html"); } }); }
                    @Override public void onAvailable(Network network) {}
                };
                mConnectivityManager.registerDefaultNetworkCallback(mNetworkCallback);
            }

            if (savedInstanceState != null) myWebView.restoreState(savedInstanceState);
            else { 
                myWebView.loadUrl("https://www.google.com"); 
            }
        } catch (Throwable t) {}
    }

    private void promptForLocation() {
        new AlertDialog.Builder(MainActivity.this)
            .setTitle("Kebenaran Lokasi")
            .setMessage("Aplikasi ini mahu menggunakan lokasi peranti anda.")
            .setPositiveButton("Benarkan", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, true, true);
                    createLocationRequest();
                }
            })
            .setNegativeButton("Jangan", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, false, false);
                }
            })
            .setCancelable(false)
            .show();
    }

    private void createLocationRequest() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() { @Override public void onSuccess(LocationSettingsResponse locationSettingsResponse) {} });
        task.addOnFailureListener(this, new OnFailureListener() {
            @Override public void onFailure(Exception e) {
                if (e instanceof ResolvableApiException) {
                    try { ((ResolvableApiException) e).startResolutionForResult(MainActivity.this, REQ_GPS_SETTINGS); } catch (IntentSender.SendIntentException sendEx) {}
                }
            }
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) { promptForLocation(); } 
            else { if(mGeoCallback != null) mGeoCallback.invoke(mGeoOrigin, false, false); }
        } else if (requestCode == REQ_MEDIA) {
            if (mPendingRequest != null) {
                boolean allGranted = true;
                for(int res : grantResults) { if (res != PackageManager.PERMISSION_GRANTED) allGranted = false; }
                if (allGranted) mPendingRequest.grant(mPendingRequest.getResources()); else mPendingRequest.deny();
                mPendingRequest = null;
            }
        }
    }
    @Override protected void onDestroy() { 
        if (myWebView != null) try { myWebView.destroy(); } catch (Exception e) {}; 
        if (mConnectivityManager != null && mNetworkCallback != null && Build.VERSION.SDK_INT >= 24) { try { mConnectivityManager.unregisterNetworkCallback(mNetworkCallback); } catch(Exception e) {} }
        super.onDestroy(); 
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) { if(requestCode == 100 && mFilePathCallback != null) { mFilePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); mFilePathCallback = null; } }
    @Override public void onBackPressed() { if (myWebView != null && myWebView.canGoBack()) myWebView.goBack(); else super.onBackPressed(); }
}
