import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:ui';
import 'dashboard_page.dart';
import 'splash_video_page.dart';
import 'widgets/custom_popup.dart';

const String baseUrl = "http://console.jhonaleystore.id:2523";

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideUpAnim;

  // ─── PALETTE WARNA (SESUAI FOTO) ───
  static const Color bgMain = Color(0xFF0A0A0A);
  static const Color bgSurface = Color(0xFF141414);
  static const Color bgInput = Color(0xFF1A1A1A);
  static const Color primaryText = Colors.white;
  static const Color secondaryText = Colors.white70;
  static const Color accentColor = Color(0xFF4FC3F7);
  static const Color errorColor = Color(0xFFFF5252);

  @override
  void initState() {
    super.initState();
    _initAnimations();
    initLogin();
  }

  void _initAnimations() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _slideUpAnim = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );

    _controller.forward();
  }

  // ─── LOGIN LOGIC ───
  Future<void> initLogin() async {
    androidId = await getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => SplashVideoPage(
                  nextPage: DashboardPage(
                    username: savedUser,
                    password: savedPass,
                    role: data['role'],
                    sessionKey: data['key'],
                    expiredDate: data['expiredDate'],
                    listBug: (data['listBug'] as List? ?? [])
                        .map((e) => Map<String, dynamic>.from(e as Map))
                        .toList(),
                    listDoos: (data['listDDoS'] as List? ?? [])
                        .map((e) => Map<String, dynamic>.from(e as Map))
                        .toList(),
                    news: (data['news'] as List? ?? [])
                        .map((e) => Map<String, dynamic>.from(e as Map))
                        .toList(),
                    uid: data['uid'],
                  ),
                ),
              ),
            );
          }
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "Access Expired",
          message: "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();
        if (errorMsg.contains("perangkat") ||
            errorMsg.contains("device") ||
            errorMsg.contains("another")) {
          _showPopup(
            title: "Sesi Aktif",
            message:
                "Akun ini sedang login di perangkat lain.\nSilakan logout di perangkat lama.",
          );
        } else {
          _showPopup(
            title: "Login Gagal",
            message: "Username atau password salah.",
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashVideoPage(
                nextPage: DashboardPage(
                  username: username,
                  password: password,
                  role: validData['role'],
                  sessionKey: validData['key'],
                  expiredDate: validData['expiredDate'],
                  listBug: (validData['listBug'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  listDoos: (validData['listDDoS'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  news: (validData['news'] as List? ?? [])
                      .map((e) => Map<String, dynamic>.from(e as Map))
                      .toList(),
                  uid: validData['uid'],
                ),
              ),
            ),
          );
        }
      }
    } catch (e) {
      _showPopup(
        title: "Connection Error",
        message: "Gagal terhubung ke server.",
      );
    }

    setState(() => isLoading = false);
  }

  void _showPopup({
    required String title,
    required String message,
    bool showContact = false,
  }) {
    final bool isError = title.toLowerCase().contains("gagal") ||
        title.toLowerCase().contains("expired") ||
        title.toLowerCase().contains("error");

    CustomPopup.show(
      context,
      title: title,
      message: message,
      icon: isError ? Icons.error_outline : Icons.info_outline,
      iconColor: isError ? errorColor : accentColor,
      cancelText: showContact ? "Contact Admin" : null,
      onCancel: showContact
          ? () async {
              await launchUrl(Uri.parse("https://t.me/hann_xd"),
                  mode: LaunchMode.externalApplication);
            }
          : null,
      confirmText: "Close",
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
        ),
        child: Stack(
          children: [
            // ─── BACKGROUND GLOW ───
            _buildBackgroundGlow(),

            // ─── SCANLINE DECORATIVE ───
            _buildScanLines(),

            // ─── MAIN CONTENT ───
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 28.0, vertical: 20.0),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 400),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // ─── HEADER "HOLOW EXECUTION" ───
                        FadeTransition(
                          opacity: _fadeAnim,
                          child: _buildHeader(),
                        ),

                        const SizedBox(height: 8),

                        // ─── SUBTITLE "Premium Digital Access" ───
                        FadeTransition(
                          opacity: _fadeAnim,
                          child: _buildSubtitle(),
                        ),

                        const SizedBox(height: 40),

                        // ─── FORM LOGIN ───
                        SlideTransition(
                          position: _slideUpAnim,
                          child: _buildLoginForm(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BACKGROUND GLOW ───
  Widget _buildBackgroundGlow() {
    return Positioned(
      top: -150,
      right: -100,
      child: Container(
        width: 350,
        height: 350,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              accentColor.withOpacity(0.06),
              Colors.transparent,
            ],
          ),
        ),
      ),
    );
  }

  // ─── SCAN LINES ───
  Widget _buildScanLines() {
    return Positioned.fill(
      child: IgnorePointer(
        child: CustomPaint(painter: _ScanLinePainter()),
      ),
    );
  }

  // ─── HEADER "HOLOW EXECUTION" ───
  Widget _buildHeader() {
    return Column(
      children: [
        // Icon kecil di atas
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: accentColor.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(
              color: accentColor.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Icon(
            Icons.flash_on_rounded,
            color: accentColor,
            size: 28,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          "WELCOME TO Apps",
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            letterSpacing: 3.0,
            fontFamily: 'Orbitron',
          ),
        ),
      ],
    );
  }

  // ─── SUBTITLE ───
  Widget _buildSubtitle() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      decoration: BoxDecoration(
        color: accentColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: accentColor.withOpacity(0.1),
          width: 0.5,
        ),
      ),
      child: Text(
        "Premium Digital Access",
        style: TextStyle(
          fontSize: 13,
          color: Colors.white.withOpacity(0.5),
          fontWeight: FontWeight.w400,
          letterSpacing: 1.5,
        ),
      ),
    );
  }

  // ─── FORM LOGIN ───
  Widget _buildLoginForm() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.02),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.05),
              width: 1,
            ),
          ),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                // ─── USERNAME ───
                _buildTextField(
                  controller: userController,
                  label: "Username",
                  icon: Icons.person_outline_rounded,
                ),
                const SizedBox(height: 14),

                // ─── PASSWORD ───
                _buildTextField(
                  controller: passController,
                  label: "Password",
                  icon: Icons.lock_outline_rounded,
                  isPassword: true,
                ),
                const SizedBox(height: 24),

                // ─── LOGIN BUTTON ───
                _buildLoginButton(),

                const SizedBox(height: 20),

                // ─── FOOTER TEXT ───
                _buildFooterText(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── TEXTFIELD ───
  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isPassword = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: bgInput,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.04),
          width: 1,
        ),
      ),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword ? _obscurePassword : false,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 15,
          fontWeight: FontWeight.w400,
        ),
        cursorColor: accentColor,
        cursorWidth: 1.5,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            color: Colors.white.withOpacity(0.3),
            fontSize: 13,
            fontWeight: FontWeight.w400,
          ),
          floatingLabelBehavior: FloatingLabelBehavior.auto,
          prefixIcon: Container(
            margin: const EdgeInsets.only(left: 2),
            child: Icon(icon, color: Colors.white.withOpacity(0.2), size: 20),
          ),
          suffixIcon: isPassword
              ? IconButton(
                  padding: EdgeInsets.zero,
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: Colors.white.withOpacity(0.15),
                    size: 18,
                  ),
                  onPressed: () {
                    setState(() => _obscurePassword = !_obscurePassword);
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your $label';
          }
          return null;
        },
      ),
    );
  }

  // ─── LOGIN BUTTON ───
  Widget _buildLoginButton() {
    return Container(
      width: double.infinity,
      height: 50,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            accentColor,
            accentColor.withOpacity(0.7),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: accentColor.withOpacity(0.2),
            blurRadius: 20,
            spreadRadius: 0,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : login,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          shadowColor: Colors.transparent,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        child: isLoading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            : const Text(
                "LOGIN",
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2.5,
                  color: Colors.white,
                ),
              ),
      ),
    );
  }

  // ─── FOOTER TEXT ───
  Widget _buildFooterText() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          Icons.shield_outlined,
          size: 12,
          color: Colors.white.withOpacity(0.15),
        ),
        const SizedBox(width: 6),
        Text(
          "Secure Login · Encrypted Connection",
          style: TextStyle(
            color: Colors.white.withOpacity(0.15),
            fontSize: 11,
            fontWeight: FontWeight.w300,
            letterSpacing: 0.3,
          ),
        ),
      ],
    );
  }
}

// ─── SCANLINE PAINTER ───
class _ScanLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.008)
      ..strokeWidth = 1;

    for (double y = 0; y < size.height; y += 4) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_ScanLinePainter old) => false;
}