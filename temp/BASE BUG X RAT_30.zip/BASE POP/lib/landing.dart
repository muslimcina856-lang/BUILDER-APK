//landing page by @hann_xd pop projek 
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'login_page.dart';
import 'widgets/custom_popup.dart';

void main() {
  runApp(const MaterialApp(
    home: LandingPage(),
    debugShowCheckedModeBanner: false,
  ));
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _videoController;

  // ─── WARNA ────────────────────────────────────────────────────────────────
  static const Color _darkBg = Color(0xFF090C10);
  static const Color _accentTeal = Color(0xFF00E5FF);
  static const Color _cardBg = Color(0xFF12181F);
  static const Color _innerCardBg = Color(0xFF1A222B);
  static const Color _telegramBlue = Color(0xFF24A1DE);

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.asset('assets/videos/landingvidio.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  Future<void> _launchSocialUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    try {
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        debugPrint("Could not launch $urlString");
      }
    } catch (e) {
      debugPrint("Error launching URL: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _darkBg,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildLogoSection(),
              _buildHeaderTitle(),
              const SizedBox(height: 40),
              _buildFeatureCard(),
              const SizedBox(height: 35),
              _buildActionButtons(context),
              const SizedBox(height: 25),
              _buildSocialSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogoSection() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _accentTeal.withOpacity(0.2)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: AspectRatio(
          aspectRatio: 16 / 9,
          child: _videoController.value.isInitialized
              ? VideoPlayer(_videoController)
              : const Center(
                  child: CircularProgressIndicator(color: _accentTeal),
                ),
        ),
      ),
    );
  }

  Widget _buildHeaderTitle() {
    return Column(
      children: [
        // ✅ TULISAN NEBULA WARNA PUTIH (tanpa gradient)
        const Text(
          "WELCOME TO Apps",
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontSize: 38,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            color: Colors.white, // ✅ PUTIH
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "GACOR  •  TERUPDATE  •  STABIL",
          style: TextStyle(
            color: _accentTeal.withOpacity(0.5),
            fontSize: 10,
            letterSpacing: 4,
            fontWeight: FontWeight.w300,
          ),
        ),
      ],
    );
  }

  Widget _buildFeatureCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: _accentTeal.withOpacity(0.1)),
        boxShadow: [
          BoxShadow(
            color: _accentTeal.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 10),
          )
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _innerCardBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _accentTeal.withOpacity(0.2)),
            ),
            child: const Icon(Icons.shield_outlined, color: _accentTeal, size: 30),
          ),
          const SizedBox(height: 20),
          const Text(
            "POP PROJECT BUG X RAT",
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              letterSpacing: 1.5,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(height: 12),
          Text(
            "Aplikasi dengan desain elegan dan fitur terbaru.\nPengembangan langsung oleh POP PROJECT.",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white.withOpacity(0.5),
              fontSize: 12,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Column(
      children: [
        _customButton(
          title: "LOGIN TO SYSTEM",
          icon: FontAwesomeIcons.rocket,
          isPrimary: true,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const LoginPage()),
          ),
        ),
        const SizedBox(height: 16),
        _customButton(
          title: "CONTACT SUPPORT",
          icon: Icons.support_agent,
          isPrimary: false,
          onTap: () => _launchSocialUrl("https://t.me/hann_xd"),
        ),
      ],
    );
  }

  Widget _buildSocialSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withOpacity(0.03)),
      ),
      child: Column(
        children: [
          Text(
            "HUBUNGI KAMI",
            style: TextStyle(
              fontFamily: 'Orbitron',
              color: Colors.white.withOpacity(0.3),
              fontSize: 10,
              letterSpacing: 3,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _socialIconItem(FontAwesomeIcons.telegram, "Telegram", "https://t.me/KawakunChan", _telegramBlue),
              _socialIconItem(FontAwesomeIcons.telegram, "Channel", "https://t.me/MyKawakunChan", _telegramBlue),
              _socialIconItem(FontAwesomeIcons.tiktok, "TikTok", "https://tiktok.com/@KawakunChan", _accentTeal),
            ],
          ),
        ],
      ),
    );
  }

  Widget _customButton({
    required String title,
    required IconData icon,
    required bool isPrimary,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          width: double.infinity,
          height: 55,
          decoration: BoxDecoration(
            color: isPrimary ? _accentTeal.withOpacity(0.1) : Colors.white.withOpacity(0.02),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: isPrimary ? _accentTeal : Colors.white.withOpacity(0.1),
              width: 1.2,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isPrimary ? _accentTeal : Colors.white54, size: 16),
              const SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: isPrimary ? _accentTeal : Colors.white60,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _socialIconItem(IconData icon, String label, String url, Color color) {
    return InkWell(
      onTap: () => _launchSocialUrl(url),
      borderRadius: BorderRadius.circular(15),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          children: [
            Container(
              width: 45,
              height: 45,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _innerCardBg,
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: Colors.white.withOpacity(0.6),
                fontSize: 9,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
