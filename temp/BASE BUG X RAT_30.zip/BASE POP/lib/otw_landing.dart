// otw_landing.dart - HALAMAN ONBOARDING SEBELUM LANDING
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'landing.dart';
import 'widgets/custom_popup.dart';

class OtwLandingPage extends StatefulWidget {
  const OtwLandingPage({super.key});

  @override
  State<OtwLandingPage> createState() => _OtwLandingPageState();
}

class _OtwLandingPageState extends State<OtwLandingPage> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;

  final List<Map<String, dynamic>> _pages = [
    {
      'title': 'BERGAYA',
      'subtitle': 'STYLE WITH ATTITUDE',
      'desc': 'Tampil dengan gaya khasmu\nJadilah dirimu sendiri\nTanpa batasan!',
      'icon': Icons.code_rounded,
      'color1': 0xFF0D47A1,
      'color2': 0xFF1565C0,
    },
    {
      'title': 'GACOR',
      'subtitle': 'ALWAYS ON FIRE',
      'desc': 'Selalu gacor setiap saat\nBersama POP APPS\nTak terkalahkan!',
      'icon': FontAwesomeIcons.whatsapp,
      'color1': 0xFF075E54,
      'color2': 0xFF128C7E,
    },
    {
      'title': 'POP PROJECT',
      'subtitle': 'BEYOND THE STARS',
      'desc': 'Jelajahi teknologi terbaru\nBersama POP TEAM\nMasa depan dimulai sekarang!',
      'icon': Icons.android_rounded,
      'color1': 0xFF1A237E,
      'color2': 0xFF283593,
    },
    {
      'title': 'TEAM',
      'subtitle': 'TOGETHER WE RISE',
      'desc': 'Bersama kita kuat\nPOP TEAM\nSolidaritas tanpa batas!',
      'icon': Icons.groups_rounded,
      'color1': 0xFF4A148C,
      'color2': 0xFF6A1B9A,
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  void _initializeVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/otwlanding.mp4')
      ..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
        });
        _videoController.play();
        _videoController.setVolume(1.0);
        _videoController.setLooping(true);
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _openTelegram() async {
    final url = Uri.parse('https://t.me/popcomity');
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        await launchUrl(url, mode: LaunchMode.platformDefault);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gagal membuka Telegram')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // ─── VIDEO BACKGROUND ──────────────────────────────
          if (_isVideoInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFF0A1929),
                    const Color(0xFF0D47A1).withOpacity(0.3),
                    const Color(0xFF0A1929),
                  ],
                ),
              ),
            ),

          // ─── OVERLAY ────────────────────────────────────────
          Container(color: Colors.black.withOpacity(0.4)),

          // ─── PAGE VIEW ──────────────────────────────────────
          PageView.builder(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() => _currentPage = index);
            },
            itemCount: _pages.length,
            itemBuilder: (context, index) {
              final data = _pages[index];
              return _buildPage(data, index);
            },
          ),

          // ─── BOTTOM: DOTS + BUTTON + PAGE NUMBER ──────────
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // ─── DOTS ────────────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    _pages.length,
                    (index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: _currentPage == index ? 28 : 8,
                      height: 8,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: _currentPage == index
                            ? Colors.white
                            : Colors.white.withOpacity(0.3),
                        boxShadow: _currentPage == index
                            ? [
                                BoxShadow(
                                  color: Colors.white.withOpacity(0.3),
                                  blurRadius: 8,
                                ),
                              ]
                            : [],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // ─── BUTTON TAP LANDING ─────────────────────
                GestureDetector(
                  onTap: () {
                    if (_currentPage == _pages.length - 1) {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const LandingPage(),
                        ),
                      );
                    } else {
                      _pageController.nextPage(
                        duration: const Duration(milliseconds: 400),
                        curve: Curves.easeInOut,
                      );
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(_pages[_currentPage]['color1']),
                          Color(_pages[_currentPage]['color2']),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: [
                        BoxShadow(
                          color: Color(_pages[_currentPage]['color1'])
                              .withOpacity(0.4),
                          blurRadius: 16,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Text(
                          'TAP LANDING',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            letterSpacing: 1.5,
                          ),
                        ),
                        SizedBox(width: 8),
                        Icon(
                          Icons.arrow_forward_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                // ─── PAGE NUMBER ─────────────────────────────
                Text(
                  '${_currentPage + 1} / ${_pages.length}',
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BUILD PAGE ──────────────────────────────────────────────────
  Widget _buildPage(Map<String, dynamic> data, int index) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // ─── ICON ──────────────────────────────────────────
          Container(
            width: 140,
            height: 140,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  Color(data['color1']),
                  Color(data['color2']),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Color(data['color1']).withOpacity(0.5),
                  blurRadius: 40,
                  spreadRadius: 10,
                ),
              ],
            ),
            child: Icon(
              data['icon'],
              size: 70,
              color: Colors.white,
            ),
          ),

          const SizedBox(height: 50),

          // ─── TITLE ─────────────────────────────────────────
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [
                Colors.white,
                Color(data['color2']).withOpacity(0.8),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: Text(
              data['title'],
              style: const TextStyle(
                color: Colors.white,
                fontSize: 34,
                fontWeight: FontWeight.w900,
                letterSpacing: 4,
              ),
              textAlign: TextAlign.center,
            ),
          ),

          const SizedBox(height: 12),

          // ─── SUBTITLE ──────────────────────────────────────
          Text(
            data['subtitle'],
            style: TextStyle(
              color: Colors.white.withOpacity(0.8),
              fontSize: 14,
              fontWeight: FontWeight.w600,
              letterSpacing: 2,
            ),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 20),

          // ─── DESCRIPTION ────────────────────────────────────
          Text(
            data['desc'],
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 14,
              height: 1.8,
              letterSpacing: 0.5,
            ),
            textAlign: TextAlign.center,
          ),

          // ─── JOIN TELEGRAM (HANYA DI HALAMAN TERAKHIR) ────
          if (index == _pages.length - 1) ...[
            const SizedBox(height: 30),
            GestureDetector(
              onTap: _openTelegram,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E88E5).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: const Color(0xFF1E88E5).withOpacity(0.4),
                    width: 1.5,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(
                      FontAwesomeIcons.telegram,
                      color: Color(0xFF42A5F5),
                      size: 22,
                    ),
                    SizedBox(width: 12),
                    Text(
                      'JOIN TELEGRAM CHANNEL',
                      style: TextStyle(
                        color: Color(0xFF42A5F5),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        letterSpacing: 1.2,
                      ),
                    ),
                    SizedBox(width: 8),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Color(0xFF42A5F5),
                      size: 16,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}