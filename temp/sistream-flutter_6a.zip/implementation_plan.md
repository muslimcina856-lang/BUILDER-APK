# Pengembangan Aplikasi Flutter SiStream (Khusus Nonton)

Dokumen ini adalah rencana awal untuk membangun aplikasi native **SiStream** menggunakan Flutter di dalam folder `sistream-flutter`. Aplikasi ini akan difokuskan khusus sebagai *client-app* untuk menonton (tidak ada fitur admin yang kompleks), dan terhubung langsung dengan backend yang sudah ada di proyek React (Supabase & Firebase).

## Latar Belakang
Anda memiliki web app/PWA SiStream yang dibangun menggunakan React (Vite) + Tailwind CSS, dengan backend menggunakan Supabase dan Firebase. Untuk memberikan pengalaman native yang lebih optimal tanpa mengandalkan PWA, kita akan membangun aplikasi Flutter yang ringan, cepat, dan fokus pada fitur utama: **Menonton Anime, Drama, & Film**.

> [!NOTE]
> Karena aplikasi ini difokuskan "hanya untuk nonton saja", kita akan menyederhanakan arsitekturnya. Fitur admin atau manajemen konten tetap akan dikelola melalui web app yang sudah ada.

## Open Questions (Pertanyaan Diskusi)
Sebelum kita mulai *coding* dan men-generate project Flutter-nya, mari diskusikan beberapa hal berikut:

> [!IMPORTANT]
> 1. **Target Platform**: Apakah aplikasi Flutter ini akan di-build untuk Android saja, atau juga iOS, Windows, dan platform lainnya?
> 2. **State Management**: Untuk Flutter, apakah Anda punya preferensi state management? (Misalnya: `Provider`, `Riverpod`, `GetX`, atau `BLoC`). Jika tidak ada, saya sarankan menggunakan `Riverpod` atau `GetX` untuk kemudahan dan performa.
> 3. **Video Player**: Web Anda sepertinya mendukung streaming HLS (menggunakan `hls.js`). Di Flutter, kita bisa menggunakan `better_player` atau `video_player` + `chewie`. Apakah ada format video khusus selain HLS/MP4 yang perlu didukung?
> 4. **Autentikasi**: Karena web menggunakan Firebase dan Supabase, apakah user diwajibkan untuk login/register sebelum bisa menonton, atau bisa akses sebagai *Guest*?

## Rencana Arsitektur & Paket (Packages) Utama

Untuk memastikan aplikasi ini berjalan mulus dan sinkron dengan database web, berikut adalah beberapa *package* Flutter yang akan kita gunakan:

### 1. Konektivitas Backend
- `supabase_flutter`: Untuk mengambil data film, drama, anime, riwayat tontonan, dan bookmark langsung dari database Supabase Anda.
- `firebase_core` & `firebase_auth` (jika menggunakan Firebase untuk auth/analytics): Untuk sinkronisasi login/register jika autentikasi di-handle oleh Firebase.

### 2. Video Streaming
- `better_player` atau `media_kit`: Sangat direkomendasikan untuk memutar video HLS (m3u8) dan MP4 dengan fitur kontrol kualitas, subtitle, dan fullscreen yang lengkap.

### 3. UI & Desain
- `cached_network_image`: Untuk memuat poster film dan thumbnail dengan cepat (caching).
- `google_fonts`: Untuk menggunakan font yang sama dengan web (Inter/Space Grotesk).
- `go_router`: Untuk navigasi antar halaman (Home, Detail, Player, Profile) yang rapi.

## Rencana Tahapan Eksekusi

### Tahap 1: Inisialisasi Project (Setup)
- Menjalankan `flutter create .` di dalam folder `sistream-flutter`.
- Mengkonfigurasi `pubspec.yaml` dan menambahkan dependencies utama.
- Setup environment variables (`.env`) untuk kunci Supabase dan Firebase agar sama dengan web.

### Tahap 2: UI Foundation & Theming
- Menerapkan tema gelap (Dark Theme) ala SiStream.
- Membuat komponen UI modular (Card Film, Carousel, dll).

### Tahap 3: Integrasi Backend & Data Fetching
- Menghubungkan aplikasi dengan Supabase.
- Membuat *Repository/Service layer* untuk mengambil data Homepage, Detail Film, dan Link Streaming.

### Tahap 4: Integrasi Video Player
- Membuat halaman khusus Player.
- Mengintegrasikan subtitle dan resolusi video.

## Bagaimana Selanjutnya?
Silakan berikan feedback Anda mengenai **Open Questions** di atas. Setelah kita sepakat, saya akan langsung mengeksekusi Tahap 1 untuk men-generate project Flutter-nya!
