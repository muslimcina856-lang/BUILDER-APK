import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import '../models/content_model.dart';

final contentServiceProvider = Provider((ref) => ContentService());

final featuredContentProvider = FutureProvider<List<ContentModel>>((ref) {
  final service = ref.watch(contentServiceProvider);
  return service.getFeaturedContent();
});

final latestContentProvider = FutureProvider<List<ContentModel>>((ref) {
  final service = ref.watch(contentServiceProvider);
  return service.getLatestContent();
});

class ContentService {
  final _supabase = Supabase.instance.client;
  final String baseUrl = dotenv.env['APP_URL'] ?? 'https://sistream.web.id';

  Future<List<ContentModel>> getFeaturedContent() async {
    try {
      // Mengambil film-film internal dari database Supabase
      final response = await _supabase
          .from('movies')
          .select('id, title, thumbnail_url, rating, year, type')
          .or('is_hidden.is.null,is_hidden.eq.false')
          .order('created_at', ascending: false) 
          .limit(5);

      return (response as List).map((json) => ContentModel.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching featured content: $e');
      return [];
    }
  }

  Future<List<ContentModel>> getLatestContent() async {
    try {
      // Mengambil data scraper dari API Backend Web Anda (MovieKu API dsb)
      final response = await http.get(Uri.parse('$baseUrl/api/v1/mk?action=latest'));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final results = data['results'] as List;
        return results.map((json) => ContentModel.fromJson(json)).toList();
      }
      return [];
    } catch (e) {
      print('Error fetching external API content: $e');
      return [];
    }
  }

  Future<ContentModel?> getDetail(String slug, {String type = 'movie'}) async {
    try {
      // Endpoint API berbeda tergantung tipe (misalnya mk untuk movie, am untuk anime)
      String actionPrefix = type == 'anime' || type == 'donghua' ? 'am' : 'mk';
      // Menarik data detail
      final response = await http.get(Uri.parse('$baseUrl/api/v1/$actionPrefix?action=detail&slug=$slug'));
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return ContentModel.fromJson(data);
      }
      return null;
    } catch (e) {
      print('Error fetching detail: $e');
      return null;
    }
  }
}


