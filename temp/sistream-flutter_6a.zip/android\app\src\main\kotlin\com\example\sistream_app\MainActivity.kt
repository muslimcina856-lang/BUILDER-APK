package com.example.sistream_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
