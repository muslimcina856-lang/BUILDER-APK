class EpisodeModel {
  final String title;
  final String? url; // Streaming iframe URL

  EpisodeModel({required this.title, this.url});

  factory EpisodeModel.fromJson(Map<String, dynamic> json) {
    return EpisodeModel(
      title: json['title'] ?? 'Unknown Episode',
      url: json['url'] ?? json['link'],
    );
  }
}

class ContentModel {
  final String id;
  final String title;
  final String slug;
  final String? description;
  final String? posterUrl;
  final String? backdropUrl;
  final String? type; // movie, anime, drama
  final String? videoUrl;
  final String? score;
  final String? episode;
  final String? year;
  final List<EpisodeModel>? episodes;

  ContentModel({
    required this.id,
    required this.title,
    required this.slug,
    this.description,
    this.posterUrl,
    this.backdropUrl,
    this.type,
    this.videoUrl,
    this.score,
    this.episode,
    this.year,
    this.episodes,
  });

  factory ContentModel.fromJson(Map<String, dynamic> json) {
    List<EpisodeModel>? parsedEpisodes;
    if (json['episodes'] != null) {
      parsedEpisodes = (json['episodes'] as List).map((e) => EpisodeModel.fromJson(e)).toList();
    }

    return ContentModel(
      id: json['id']?.toString() ?? '',
      title: json['title'] ?? 'Unknown Title',
      slug: json['slug'] ?? json['id']?.toString() ?? '',
      description: json['description'] ?? json['synopsis'],
      // Support various keys from React / Supabase
      posterUrl: json['thumbnail_url'] ?? json['poster_url'] ?? json['image'] ?? json['image_poster'] ?? json['cover'] ?? json['thumbnail'],
      backdropUrl: json['backdrop_url'] ?? json['thumbnail_url'] ?? json['image'],
      type: json['type'] ?? json['typeBadge'] ?? 'movie',
      videoUrl: json['video_url'] ?? json['url'],
      score: json['rating']?.toString() ?? json['score']?.toString(),
      episode: json['episode']?.toString(),
      year: json['year']?.toString(),
      episodes: parsedEpisodes,
    );
  }
}

