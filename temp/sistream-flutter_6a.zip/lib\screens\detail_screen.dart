import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/content_model.dart';
import '../services/content_service.dart';
import 'player_screen.dart';

final detailProvider = FutureProvider.family<ContentModel?, Map<String, String>>((ref, args) {
  final service = ref.watch(contentServiceProvider);
  return service.getDetail(args['slug']!, type: args['type'] ?? 'movie');
});

class DetailScreen extends ConsumerWidget {
  final ContentModel content; // Basic info passed from Home

  const DetailScreen({super.key, required this.content});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final detailAsync = ref.watch(detailProvider({'slug': content.slug, 'type': content.type ?? 'movie'}));

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0C),
      body: CustomScrollView(
        slivers: [
          // AppBar & Backdrop
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            backgroundColor: const Color(0xFF0A0A0C),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  if (content.backdropUrl != null || content.posterUrl != null)
                    CachedNetworkImage(
                      imageUrl: content.backdropUrl ?? content.posterUrl!,
                      fit: BoxFit.cover,
                    ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [
                          const Color(0xFF0A0A0C),
                          const Color(0xFF0A0A0C).withOpacity(0.5),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            leading: IconButton(
              icon: const Icon(LucideIcons.arrowLeft, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ),

          // Content Details
          SliverToBoxAdapter(
            child: detailAsync.when(
              loading: () => const SizedBox(
                height: 300,
                child: Center(child: CircularProgressIndicator(color: Color(0xFFF6CF80))),
              ),
              error: (err, stack) => Padding(
                padding: const EdgeInsets.all(24.0),
                child: Center(child: Text('Error: $err', style: const TextStyle(color: Colors.white))),
              ),
              data: (detailedContent) {
                final displayContent = detailedContent ?? content;
                final hasEpisodes = displayContent.episodes != null && displayContent.episodes!.isNotEmpty;

                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title & Badges
                      Text(
                        displayContent.title.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          if (displayContent.score != null)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: const Color(0xFFF6CF80),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.star, size: 14, color: Colors.black),
                                  const SizedBox(width: 4),
                                  Text(
                                    displayContent.score!,
                                    style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                          const SizedBox(width: 12),
                          if (displayContent.year != null)
                            Text(
                              displayContent.year!,
                              style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold),
                            ),
                        ],
                      ),
                      
                      const SizedBox(height: 24),

                      // Synopsis
                      if (displayContent.description != null) ...[
                        const Text(
                          'SINOPSIS',
                          style: TextStyle(color: Color(0xFFF6CF80), fontWeight: FontWeight.bold, letterSpacing: 1),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          displayContent.description!,
                          style: TextStyle(color: Colors.white.withOpacity(0.7), height: 1.5),
                        ),
                        const SizedBox(height: 32),
                      ],

                      // Play Action or Episodes
                      if (hasEpisodes) ...[
                        const Text(
                          'PILIH EPISODE',
                          style: TextStyle(color: Color(0xFFF6CF80), fontWeight: FontWeight.bold, letterSpacing: 1, fontSize: 16),
                        ),
                        const SizedBox(height: 16),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: displayContent.episodes!.length,
                          itemBuilder: (context, index) {
                            final ep = displayContent.episodes![index];
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.05),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(LucideIcons.playCircle, color: Colors.white70),
                              ),
                              title: Text(ep.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                              onTap: () {
                                if (ep.url != null) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => PlayerScreen(videoUrl: ep.url!, title: '${displayContent.title} - ${ep.title}'),
                                    ),
                                  );
                                }
                              },
                            );
                          },
                        ),
                      ] else if (displayContent.videoUrl != null) ...[
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => PlayerScreen(videoUrl: displayContent.videoUrl!, title: displayContent.title),
                                ),
                              );
                            },
                            icon: const Icon(LucideIcons.playCircle, color: Colors.black),
                            label: const Text('TONTON SEKARANG', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, letterSpacing: 1)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFF6CF80),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                      ] else ...[
                        const Center(
                          child: Text('Video belum tersedia', style: TextStyle(color: Colors.white54)),
                        )
                      ]
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
