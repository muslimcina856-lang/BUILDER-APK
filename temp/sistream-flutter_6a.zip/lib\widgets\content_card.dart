import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/content_model.dart';
import '../screens/detail_screen.dart';

class ContentCard extends StatelessWidget {
  final ContentModel content;
  final double width;

  const ContentCard({
    super.key,
    required this.content,
    this.width = 155, // Matched from React min-w-[155px]
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailScreen(content: content),
          ),
        );
      },
      child: Container(
        width: width,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Poster area (aspect ratio 3/4.5)
            AspectRatio(
              aspectRatio: 3 / 4.5,
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF18181B), // zinc-900
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFF27272A)), // zinc-800
                ),
                clipBehavior: Clip.antiAlias,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (content.posterUrl != null)
                      CachedNetworkImage(
                        imageUrl: content.posterUrl!,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(color: Colors.white10),
                        errorWidget: (context, url, error) => const Center(child: Text('No Image', style: TextStyle(color: Colors.white54, fontSize: 10))),
                      ),
                    
                    // Gradient overlay (subtle at bottom)
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [
                            Colors.black.withOpacity(0.4),
                            Colors.transparent,
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                    
                    // Episode Badge
                    if (content.episode != null)
                      Positioned(
                        top: 8,
                        left: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFBBF24), // amber-400
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            content.episode!.toUpperCase().startsWith('EP') ? content.episode! : 'EP ${content.episode}',
                            style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Color(0xFF09090B)), // zinc-950
                          ),
                        ),
                      ),
                    
                    // Score Badge
                    if (content.score != null)
                      Positioned(
                        top: 8,
                        right: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFF09090B).withOpacity(0.9), // zinc-950/90
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.star, size: 10, color: Color(0xFFFBBF24)), // amber-400
                              const SizedBox(width: 4),
                              Text(
                                content.score!,
                                style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Color(0xFFFBBF24)),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 8),
            
            // Title
            Text(
              content.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: Color(0xFFD4D4D8), // zinc-300
                height: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
