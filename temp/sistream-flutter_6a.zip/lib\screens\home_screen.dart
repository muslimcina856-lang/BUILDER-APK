import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../services/content_service.dart';
import '../widgets/featured_carousel.dart';
import '../widgets/content_card.dart';
import '../widgets/section_header.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final featuredAsyncValue = ref.watch(featuredContentProvider);
    final latestAsyncValue = ref.watch(latestContentProvider);

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0C), // Matching React body bg
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text(
          'SiStream',
          style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFF6CF80), letterSpacing: -1, fontSize: 24),
        ),
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.search, color: Colors.white),
            onPressed: () {
              // TODO: Implement search
            },
          ),
          IconButton(
            icon: const Icon(LucideIcons.user, color: Colors.white),
            onPressed: () {
              // TODO: Implement profile/login
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Featured Carousel
            featuredAsyncValue.when(
              data: (contents) => FeaturedCarousel(contents: contents),
              loading: () => const SizedBox(
                height: 400,
                child: Center(child: CircularProgressIndicator(color: Color(0xFFF6CF80))),
              ),
              error: (err, stack) => SizedBox(
                height: 400,
                child: Center(child: Text('Error loading featured: $err', style: const TextStyle(color: Colors.white))),
              ),
            ),
            
            const SizedBox(height: 32),
            
            // Latest Content Section
            const SectionHeader(
              title: 'Terbaru',
              subtitle: 'Update Hari Ini',
              icon: LucideIcons.popcorn,
            ),

            // Horizontal List
            SizedBox(
              height: 270, // Adjusted height for 3/4.5 aspect ratio + title space below
              child: latestAsyncValue.when(
                data: (contents) => ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  itemCount: contents.length,
                  itemBuilder: (context, index) {
                    return ContentCard(content: contents[index]);
                  },
                ),
                loading: () => const Center(child: CircularProgressIndicator(color: Color(0xFFF6CF80))),
                error: (err, stack) => Center(child: Text('Error loading latest: $err', style: const TextStyle(color: Colors.white))),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

