import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../models/content_model.dart';
import '../screens/detail_screen.dart';

class FeaturedCarousel extends StatefulWidget {
  final List<ContentModel> contents;
  const FeaturedCarousel({super.key, required this.contents});

  @override
  State<FeaturedCarousel> createState() => _FeaturedCarouselState();
}

class _FeaturedCarouselState extends State<FeaturedCarousel> {
  int _currentIndex = 0;
  final PageController _pageController = PageController();

  @override
  Widget build(BuildContext context) {
    if (widget.contents.isEmpty) return const SizedBox();
    
    final maxItems = widget.contents.length;

    return SizedBox(
      height: 400, // Taller hero section to match web
      width: double.infinity,
      child: Stack(
        children: [
          PageView.builder(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            itemCount: maxItems,
            itemBuilder: (context, index) {
              final content = widget.contents[index];
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DetailScreen(content: content),
                    ),
                  );
                },
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // Background Image (Cinematic zoomed, 40% opacity)
                    if (content.backdropUrl != null || content.posterUrl != null)
                      Opacity(
                        opacity: 0.4,
                        child: Transform.scale(
                          scale: 1.05,
                          child: CachedNetworkImage(
                            imageUrl: content.backdropUrl ?? content.posterUrl!,
                            fit: BoxFit.cover,
                            placeholder: (context, url) => Container(color: Colors.black),
                            errorWidget: (context, url, error) => Container(color: Colors.black),
                          ),
                        ),
                      ),
                    
                    // Gradients
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          colors: [
                            const Color(0xFF050505).withOpacity(1.0),
                            const Color(0xFF050505).withOpacity(0.7),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [
                            const Color(0xFF0A0A0C).withOpacity(1.0), // Match Scaffold bg at bottom
                            const Color(0xFF050505).withOpacity(0.8),
                            Colors.transparent,
                          ],
                          stops: const [0.0, 0.3, 1.0],
                        ),
                      ),
                    ),
                    
                    // Content
                    Positioned(
                      top: 40, // padding top
                      bottom: 40, // padding bottom
                      left: 16, // padding left
                      right: 16,
                      child: Row(
                        children: [
                          // Poster Thumbnail (Desktop/Tablet style, hidden on small screens if we wanted, but let's keep it responsive)
                          if (MediaQuery.of(context).size.width > 600)
                            Container(
                              width: 140,
                              margin: const EdgeInsets.only(right: 24),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Colors.white.withOpacity(0.05)),
                                image: DecorationImage(
                                  image: CachedNetworkImageProvider(content.posterUrl ?? content.backdropUrl ?? ''),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          
                          // Info Section
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // Badges
                                Row(
                                  children: [
                                    if (content.score != null) ...[
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFF6CF80), // Amber from React
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Icon(Icons.star, size: 12, color: Colors.black),
                                            const SizedBox(width: 4),
                                            Text(
                                              content.score!,
                                              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.black, letterSpacing: 1),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                    ],
                                    if (content.type != null)
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: Colors.white.withOpacity(0.05),
                                          border: Border.all(color: Colors.white.withOpacity(0.1)),
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Icon(LucideIcons.monitor, size: 12, color: Colors.white70),
                                            const SizedBox(width: 4),
                                            Text(
                                              content.type!.toUpperCase(),
                                              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white70, letterSpacing: 1),
                                            ),
                                          ],
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                
                                // Title
                                Text(
                                  content.title.toUpperCase(),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 28, // Using a large font, ideally mapping to Display Font
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white,
                                    letterSpacing: -1,
                                    height: 1.1,
                                  ),
                                ),
                                
                                // Synopsis
                                if (content.description != null) ...[
                                  const SizedBox(height: 8),
                                  Text(
                                    content.description!,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.white.withOpacity(0.7),
                                      fontWeight: FontWeight.w500,
                                      height: 1.5,
                                    ),
                                  ),
                                ],
                                
                                const SizedBox(height: 16),
                                
                                // Buttons
                                Row(
                                  children: [
                                    ElevatedButton.icon(
                                      onPressed: () {
                                        Navigator.push(context, MaterialPageRoute(builder: (_) => DetailScreen(content: content)));
                                      },
                                      icon: const Icon(LucideIcons.playCircle, color: Colors.black, size: 18),
                                      label: const Text('TONTON', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, letterSpacing: 1, fontSize: 12)),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: const Color(0xFFF59E0B), // amber-500
                                        foregroundColor: Colors.amberAccent,
                                        elevation: 0,
                                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    if (MediaQuery.of(context).size.width > 400) // Show on slightly larger screens
                                      OutlinedButton(
                                        onPressed: () {},
                                        style: OutlinedButton.styleFrom(
                                          backgroundColor: const Color(0xFF27272A).withOpacity(0.9), // zinc-800
                                          side: BorderSide(color: const Color(0xFF3F3F46).withOpacity(0.8)), // border-zinc-700
                                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                        ),
                                        child: const Text('INFO LENGKAP', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1, fontSize: 12)),
                                      ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          
          // Custom Navigation Controls (Bottom Right)
          Positioned(
            bottom: 24,
            right: 16,
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    if (_currentIndex > 0) {
                      _pageController.previousPage(duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
                    } else {
                      _pageController.animateToPage(maxItems - 1, duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
                    }
                  },
                  child: const Padding(padding: EdgeInsets.all(4.0), child: Icon(LucideIcons.arrowLeft, color: Colors.white54, size: 18)),
                ),
                const SizedBox(width: 8),
                Text(
                  '${_currentIndex + 1} / $maxItems',
                  style: const TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 40,
                  height: 2,
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), borderRadius: BorderRadius.circular(2)),
                  alignment: Alignment.centerLeft,
                  child: FractionallySizedBox(
                    widthFactor: (_currentIndex + 1) / maxItems,
                    child: Container(
                      decoration: BoxDecoration(color: const Color(0xFFF6CF80), borderRadius: BorderRadius.circular(2)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () {
                    if (_currentIndex < maxItems - 1) {
                      _pageController.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
                    } else {
                      _pageController.animateToPage(0, duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
                    }
                  },
                  child: const Padding(padding: EdgeInsets.all(4.0), child: Icon(LucideIcons.arrowRight, color: Colors.white54, size: 18)),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
