import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/screens/user_list_screen.dart';
import 'package:earl_builder_owner/screens/add_credit_screen.dart';
import 'package:earl_builder_owner/screens/generate_code_screen.dart';
import 'package:earl_builder_owner/screens/code_list_screen.dart';
import 'package:earl_builder_owner/screens/create_ad_screen.dart';
import 'package:earl_builder_owner/screens/ads_list_screen.dart';
import 'package:earl_builder_owner/screens/server_toggle_screen.dart';
import 'package:earl_builder_owner/screens/about_screen.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class DashboardScreen extends StatefulWidget {
  final Future<void> Function() onLogout;
  const DashboardScreen({super.key, required this.onLogout});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _totalUsers = 0;
  int _activeCodes = 0;
  String _serverMode = 'off';
  String _serverTitle = '';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final adsCleanup = OwnerApiService.getAds().catchError(
        (_) => <String, dynamic>{},
      );
      final results = await Future.wait([
        OwnerApiService.getUsers(),
        OwnerApiService.getCodes(),
        OwnerApiService.getServerStatus(),
      ]);
      await adsCleanup;
      if (!mounted) return;
      setState(() {
        _totalUsers = (results[0]['total'] as num?)?.toInt() ?? 0;
        _activeCodes = (results[1]['total'] as num?)?.toInt() ?? 0;
        _serverMode = (results[2]['maintenance_mode'] ?? 'off').toString();
        _serverTitle = (results[2]['maintenance_title'] ?? '').toString();
      });
    } catch (_) {}
    if (!mounted) return;
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.accent,
          backgroundColor: AppColors.bgElevated,
          onRefresh: _loadData,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
              AppSpacing.xxl,
              AppSpacing.xl,
              AppSpacing.xxl,
              AppSpacing.huge,
            ),
            children: [
              _Header(onRefresh: _loadData, onLogout: widget.onLogout),
              const SizedBox(height: AppSpacing.xxxl),
              if (_isLoading)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: AppSpacing.huge),
                  child: Center(
                    child: SizedBox(
                      width: 28,
                      height: 28,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        valueColor: AlwaysStoppedAnimation(AppColors.accent),
                      ),
                    ),
                  ),
                )
              else ...[
                _StatsRow(
                  totalUsers: _totalUsers,
                  activeCodes: _activeCodes,
                ),
                const SizedBox(height: AppSpacing.xl),
                _ServerBanner(
                  mode: _serverMode,
                  title: _serverTitle,
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ServerToggleScreen(onChanged: _loadData),
                      ),
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.xxxl),
                _SectionLabel('MANAGEMENT'),
                const SizedBox(height: AppSpacing.md),
                _ActionTile(
                  icon: Icons.people_rounded,
                  title: 'User List',
                  subtitle: 'Browse all registered users',
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const UserListScreen(),
                      ),
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.sm),
                _ActionTile(
                  icon: Icons.add_circle_rounded,
                  title: 'Add Credits',
                  subtitle: 'Grant credits to a user',
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AddCreditScreen(onDone: _loadData),
                      ),
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.sm),
                _ActionTile(
                  icon: Icons.redeem_rounded,
                  title: 'Generate Codes',
                  subtitle: 'Create redeem codes to share',
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const GenerateCodeScreen(),
                      ),
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.sm),
                _ActionTile(
                  icon: Icons.list_alt_rounded,
                  title: 'Active Codes',
                  subtitle: 'Codes that have not been claimed',
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const CodeListScreen(),
                      ),
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.xxxl),
                _SectionLabel('ADS'),
                const SizedBox(height: AppSpacing.md),
                _ActionTile(
                  icon: Icons.ondemand_video_rounded,
                  title: 'Create Ad',
                  subtitle: 'Target one user with an image/video ad',
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const CreateAdScreen(),
                      ),
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.sm),
                _ActionTile(
                  icon: Icons.video_library_rounded,
                  title: 'Manage Ads',
                  subtitle: 'View, search, and delete existing ads',
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AdsListScreen(),
                      ),
                    );
                  },
                ),
                const SizedBox(height: AppSpacing.xxxl),
                _SectionLabel('OTHER'),
                const SizedBox(height: AppSpacing.md),
                _ActionTile(
                  icon: Icons.info_outline_rounded,
                  title: 'About',
                  subtitle: 'About this panel',
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AboutScreen(),
                      ),
                    );
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Header
// ──────────────────────────────────────────────────────────────────
class _Header extends StatelessWidget {
  final VoidCallback onRefresh;
  final Future<void> Function() onLogout;
  const _Header({required this.onRefresh, required this.onLogout});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: AppColors.accent,
            borderRadius: BorderRadius.circular(AppRadius.input),
          ),
          alignment: Alignment.center,
          child: const Icon(
            Icons.admin_panel_settings_rounded,
            color: AppColors.onAccent,
            size: AppIcons.lg,
          ),
        ),
        const SizedBox(width: AppSpacing.md),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Owner Panel',
                style: AppText.title.copyWith(fontSize: 19),
              ),
              const SizedBox(height: 2),
              Text('Earl Builder', style: AppText.caption),
            ],
          ),
        ),
        IconButton(
          onPressed: onRefresh,
          icon: const Icon(Icons.refresh_rounded, size: AppIcons.md),
          color: AppColors.textMuted,
          splashRadius: 22,
        ),
        IconButton(
          onPressed: onLogout,
          icon: const Icon(Icons.logout_rounded, size: AppIcons.md),
          tooltip: 'Logout',
          color: AppColors.textMuted,
          splashRadius: 22,
        ),
      ],
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Stats row
// ──────────────────────────────────────────────────────────────────
class _StatsRow extends StatelessWidget {
  final int totalUsers;
  final int activeCodes;

  const _StatsRow({required this.totalUsers, required this.activeCodes});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _StatTile(
            value: '$totalUsers',
            label: 'USERS',
          ),
        ),
        const SizedBox(width: AppSpacing.md),
        Expanded(
          child: _StatTile(
            value: '$activeCodes',
            label: 'CODES',
          ),
        ),
      ],
    );
  }
}

class _StatTile extends StatelessWidget {
  final String value;
  final String label;

  const _StatTile({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: AppText.statNumber),
          const SizedBox(height: AppSpacing.xs),
          Text(label, style: AppText.sectionLabel),
        ],
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Server status banner
// ──────────────────────────────────────────────────────────────────
class _ServerBanner extends StatelessWidget {
  final String mode;
  final String title;
  final VoidCallback onTap;

  const _ServerBanner({
    required this.mode,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isOffline = mode == 'on';
    final color = isOffline ? AppColors.error : AppColors.success;
    final label = isOffline ? 'SERVER OFFLINE' : 'SERVER ONLINE';
    final subtitle = isOffline
        ? (title.isNotEmpty ? title : 'Users cannot upload projects')
        : 'All services running normally';

    return Material(
      color: color.withAlpha(15),
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Container(
          padding: const EdgeInsets.all(AppSpacing.lg),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadius.card),
            border: Border.all(color: color.withAlpha(60)),
          ),
          child: Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: AppText.heading.copyWith(
                        color: color,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(subtitle, style: AppText.caption),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                size: AppIcons.lg,
                color: AppColors.textMuted,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────────────────────────
// Section label
// ──────────────────────────────────────────────────────────────────
class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel(this.label);

  @override
  Widget build(BuildContext context) {
    return Text(label, style: AppText.sectionLabel);
  }
}

// ──────────────────────────────────────────────────────────────────
// Action tile
// ──────────────────────────────────────────────────────────────────
class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.bgElevated,
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg,
            vertical: AppSpacing.lg,
          ),
          child: Row(
            children: [
              Icon(icon, size: AppIcons.lg, color: AppColors.textPrimary),
              const SizedBox(width: AppSpacing.lg),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: AppText.heading.copyWith(fontSize: 16)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: AppText.subtitle),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                size: AppIcons.lg,
                color: AppColors.textMuted,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
