import 'package:equatable/equatable.dart';

/// Sumber dari mana sampel audio rujukan diperoleh.
enum VoiceProfileSource {
  /// Direkod terus dalam aplikasi menggunakan mikrofon peranti.
  recorded,

  /// Dimuat naik daripada fail audio sedia ada (.mp3 / .wav).
  upload,
}

/// Satu profil suara yang disimpan pengguna untuk tujuan klon suara.
///
/// Profil menyimpan LALUAN FAIL sampel audio rujukan (bukan kandungan
/// audio itu sendiri) — sampel audio yang sebenar disimpan sebagai fail
/// biasa dalam storan peranti, bukan sebagai teks base64 dalam pangkalan
/// data. Ini kerana SQLite Android mempunyai had "CursorWindow" sekitar
/// 2MB bagi satu baris (row); menyimpan audio sebagai base64 terus dalam
/// pangkalan data akan menyebabkan ralat "Row too big to fit into
/// CursorWindow" apabila sampel audio melebihi kira-kira 1.5MB mentah.
/// Base64 hanya dijana secara sementara (on-demand) daripada fail apabila
/// perlu dihantar ke API MiMo AI.
class VoiceProfile extends Equatable {
  final String id;
  final String name;

  /// Laluan fail audio rujukan yang disimpan pada peranti.
  final String audioFilePath;

  /// MIME type sampel audio, cth `audio/mpeg` (mp3) atau `audio/wav`.
  final String mimeType;

  final VoiceProfileSource source;

  final DateTime createdAt;

  const VoiceProfile({
    required this.id,
    required this.name,
    required this.audioFilePath,
    required this.mimeType,
    required this.source,
    required this.createdAt,
  });

  factory VoiceProfile.fromJson(Map<String, dynamic> json) {
    return VoiceProfile(
      id: json['id'] as String,
      name: json['name'] as String,
      audioFilePath: json['audioFilePath'] as String,
      mimeType: json['mimeType'] as String,
      source: VoiceProfileSource.values.firstWhere(
        (s) => s.name == json['source'],
        orElse: () => VoiceProfileSource.upload,
      ),
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'audioFilePath': audioFilePath,
      'mimeType': mimeType,
      'source': source.name,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [id, name, audioFilePath, mimeType, source, createdAt];

  @override
  bool get stringify => true;
}

/// Satu hasil penjanaan suara klon (output audio yang telah disintesis).
class VoiceCloneResult extends Equatable {
  final String id;
  final String voiceProfileId;
  final String text;

  /// Laluan fail audio output yang telah disimpan pada peranti.
  final String outputFilePath;

  final DateTime createdAt;

  const VoiceCloneResult({
    required this.id,
    required this.voiceProfileId,
    required this.text,
    required this.outputFilePath,
    required this.createdAt,
  });

  factory VoiceCloneResult.fromJson(Map<String, dynamic> json) {
    return VoiceCloneResult(
      id: json['id'] as String,
      voiceProfileId: json['voiceProfileId'] as String,
      text: json['text'] as String,
      outputFilePath: json['outputFilePath'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'voiceProfileId': voiceProfileId,
      'text': text,
      'outputFilePath': outputFilePath,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [id, voiceProfileId, text, outputFilePath, createdAt];

  @override
  bool get stringify => true;
}
