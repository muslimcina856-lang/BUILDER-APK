import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:share_plus/share_plus.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/voice_profile.dart';
import '../bloc/voice_profile_bloc.dart';

/// Skrin penjanaan pertuturan menggunakan satu profil suara klon terpilih.
class GenerateVoicePage extends StatefulWidget {
  final VoiceProfile profile;

  const GenerateVoicePage({super.key, required this.profile});

  @override
  State<GenerateVoicePage> createState() => _GenerateVoicePageState();
}

class _GenerateVoicePageState extends State<GenerateVoicePage> {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _styleController = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();

  bool _isPlaying = false;
  String? _currentlyPlayingPath;

  /// Ayat cadangan dalam Bahasa Melayu untuk memudahkan pengguna menguji
  /// suara klon dengan cepat tanpa perlu menaip sendiri. Dipilih untuk
  /// merangkumi pelbagai bunyi dan panjang ayat yang berbeza, supaya
  /// pengguna dapat gambaran lebih jelas tentang kualiti sebutan suara
  /// klon mereka dalam Bahasa Melayu.
  static const List<String> _suggestedPhrases = [
    'Selamat pagi, apa khabar hari ini?',
    'Saya sedang menguji suara klon saya sendiri.',
    'Terima kasih kerana menggunakan aplikasi ini.',
    'Cuaca hari ini agak panas dan berangin.',
    'Boleh awak tolong saya dengan sesuatu?',
  ];

  @override
  void initState() {
    super.initState();
    context.read<VoiceProfileBloc>().add(LoadVoiceProfiles());

    _audioPlayer.playerStateStream.listen((playerState) {
      if (!mounted) return;
      setState(() {
        _isPlaying = playerState.playing && playerState.processingState != ProcessingState.completed;
      });
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    _styleController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _handleGenerate() {
    final String text = _textController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sila masukkan teks yang mahu disebut.')),
      );
      return;
    }

    context.read<VoiceProfileBloc>().add(
          GenerateVoiceClone(
            profileId: widget.profile.id,
            text: text,
            styleInstruction: _styleController.text.trim(),
          ),
        );
  }

  Future<void> _playAudio(String filePath) async {
    try {
      if (_currentlyPlayingPath == filePath && _isPlaying) {
        await _audioPlayer.pause();
        return;
      }

      if (_currentlyPlayingPath != filePath) {
        await _audioPlayer.setFilePath(filePath);
        _currentlyPlayingPath = filePath;
      }

      await _audioPlayer.play();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memainkan audio: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  /// Berkongsi/memuat turun fail audio hasil menggunakan dialog kongsi
  /// sistem (Share Sheet), yang membolehkan pengguna menyimpan fail ke
  /// storan peranti, menghantar melalui aplikasi lain, atau memuat
  /// naik ke perkhidmatan awan pilihan mereka. Fail audio disimpan
  /// dalam direktori dokumen aplikasi yang tidak boleh diakses terus
  /// melalui pengurus fail biasa, jadi ini satu-satunya cara pengguna
  /// boleh "mengeluarkan" hasil daripada aplikasi.
  Future<void> _shareResult(VoiceCloneResult result) async {
    try {
      final XFile file = XFile(result.outputFilePath);
      await SharePlus.instance.share(
        ShareParams(
          files: [file],
          text: 'Suara klon: "${result.text}"',
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal berkongsi fail audio: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  void _confirmDeleteResult(VoiceCloneResult result) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Padam Hasil Ini?'),
          content: const Text('Fail audio yang dijana akan dipadam secara kekal.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<VoiceProfileBloc>().add(
                      DeleteVoiceCloneResult(
                        resultId: result.id,
                        outputFilePath: result.outputFilePath,
                      ),
                    );
                Navigator.pop(dialogContext);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Padam'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          widget.profile.name,
          style: GoogleFonts.inter(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.scaffold.withOpacity(0.9),
                AppColors.scaffold.withOpacity(0.0),
              ],
            ),
          ),
        ),
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: BlocConsumer<VoiceProfileBloc, VoiceProfileState>(
            listener: (context, state) {
              if (state is VoiceProfileError) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(state.message), backgroundColor: AppColors.error),
                );
              } else if (state is VoiceCloneGenerated) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Suara klon berjaya dijana!'),
                    backgroundColor: AppColors.success,
                  ),
                );
              }
            },
            builder: (context, state) {
              bool isGenerating = false;
              List<VoiceCloneResult> results = [];

              if (state is VoiceProfilesLoaded) {
                isGenerating = state.isGenerating;
                results = state.results.where((r) => r.voiceProfileId == widget.profile.id).toList();
              }

              return ListView(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                children: [
                  TextField(
                    controller: _textController,
                    maxLines: 4,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: AppStrings.labelTextToSpeak,
                      hintText: AppStrings.hintTextToSpeak,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Cadangan ayat (tekan untuk isi):',
                    style: GoogleFonts.inter(fontSize: 12, color: AppColors.textMuted),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _suggestedPhrases.map((phrase) {
                      return ActionChip(
                        label: Text(
                          phrase,
                          style: const TextStyle(color: Colors.white, fontSize: 12),
                        ),
                        backgroundColor: AppColors.card,
                        side: const BorderSide(color: AppColors.cardBorder),
                        onPressed: () {
                          setState(() => _textController.text = phrase);
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _styleController,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: AppStrings.labelStyleInstruction,
                      hintText: AppStrings.hintStyleInstruction,
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: isGenerating ? null : _handleGenerate,
                      icon: isGenerating
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.auto_awesome_rounded),
                      label: Text(isGenerating ? AppStrings.buttonGenerating : AppStrings.buttonGenerate),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  if (results.isNotEmpty) ...[
                    Text(
                      'Hasil Terdahulu',
                      style: GoogleFonts.inter(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
                    ),
                    const SizedBox(height: 12),
                    ...results.map((result) => _buildResultCard(result)),
                  ],
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildResultCard(VoiceCloneResult result) {
    final bool isCurrentlyPlaying = _currentlyPlayingPath == result.outputFilePath && _isPlaying;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _playAudio(result.outputFilePath),
            child: Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                gradient: AppColors.accentGradient,
                shape: BoxShape.circle,
              ),
              child: Icon(
                isCurrentlyPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              result.text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 13),
            ),
          ),
          TextButton(
            onPressed: () => _shareResult(result),
            style: TextButton.styleFrom(
              foregroundColor: AppColors.accent,
              padding: const EdgeInsets.symmetric(horizontal: 10),
            ),
            child: const Text('Share', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.textMuted, size: 20),
            onPressed: () => _confirmDeleteResult(result),
          ),
        ],
      ),
    );
  }
}
