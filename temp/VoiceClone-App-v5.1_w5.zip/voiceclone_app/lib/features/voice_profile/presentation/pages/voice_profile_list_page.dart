import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/voice_profile.dart';
import '../bloc/voice_profile_bloc.dart';
import 'add_voice_profile_sheet.dart';
import 'generate_voice_page.dart';
import 'settings_page.dart';

/// Skrin utama: senarai profil suara tersimpan, dengan pilihan menambah
/// profil baharu dan navigasi ke Tetapan. Aplikasi ini fokus tunggal
/// kepada Klon Suara (voice cloning) menggunakan sampel suara pengguna
/// sendiri.
class VoiceProfileListPage extends StatefulWidget {
  const VoiceProfileListPage({super.key});

  @override
  State<VoiceProfileListPage> createState() => _VoiceProfileListPageState();
}

class _VoiceProfileListPageState extends State<VoiceProfileListPage> {
  @override
  void initState() {
    super.initState();
    context.read<VoiceProfileBloc>().add(LoadVoiceProfiles());
  }

  void _showAddProfileSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return BlocProvider.value(
          value: context.read<VoiceProfileBloc>(),
          child: const AddVoiceProfileSheet(),
        );
      },
    );
  }

  void _confirmDeleteProfile(BuildContext context, VoiceProfile profile) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Padam Profil Suara?'),
          content: Text(
            'Adakah anda pasti mahu memadam "${profile.name}"? '
            'Semua hasil penjanaan menggunakan profil ini turut akan dipadam.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<VoiceProfileBloc>().add(DeleteVoiceProfile(profile.id));
                Navigator.pop(dialogContext);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Padam'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          AppStrings.titleVoiceProfiles,
          style: GoogleFonts.inter(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.scaffold.withOpacity(0.9),
                AppColors.scaffold.withOpacity(0.0),
              ],
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined, color: Colors.white),
            tooltip: 'Tetapan',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute<void>(builder: (context) => const SettingsPage()),
              );
            },
          ),
        ],
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: BlocConsumer<VoiceProfileBloc, VoiceProfileState>(
            listener: (context, state) {
              if (state is VoiceProfileError) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(state.message), backgroundColor: AppColors.error),
                );
              }
            },
            builder: (context, state) {
              List<VoiceProfile> profiles = [];
              if (state is VoiceProfilesLoaded) {
                profiles = state.profiles;
              }

              if (profiles.isEmpty) {
                return _buildEmptyState();
              }

              return ListView(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
                children: [
                  Text(
                    'Profil suara yang disimpan boleh digunakan berulang kali '
                    'untuk menjana pertuturan baharu.',
                    style: GoogleFonts.inter(color: AppColors.textMuted, fontSize: 13),
                  ),
                  const SizedBox(height: 20),
                  ...profiles.map((profile) => _buildProfileCard(context, profile)),
                ],
              );
            },
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddProfileSheet(context),
        backgroundColor: AppColors.accent,
        icon: const Icon(Icons.add, color: AppColors.textOnAccent),
        label: Text(
          AppStrings.buttonAddProfile,
          style: const TextStyle(color: AppColors.textOnAccent, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.card,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.cardBorder),
              ),
              child: const Icon(Icons.record_voice_over_rounded, color: AppColors.accent, size: 48),
            ),
            const SizedBox(height: 24),
            Text(
              AppStrings.emptyProfilesTitle,
              style: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 8),
            Text(
              AppStrings.emptyProfilesSubtitle,
              style: GoogleFonts.inter(color: AppColors.textMuted, fontSize: 13),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    ).animate().fadeIn(duration: 400.ms);
  }

  Widget _buildProfileCard(BuildContext context, VoiceProfile profile) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: AppColors.accentGradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              profile.source == VoiceProfileSource.recorded
                  ? Icons.mic_rounded
                  : Icons.upload_file_rounded,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  profile.name,
                  style: GoogleFonts.inter(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
                ),
                const SizedBox(height: 2),
                Text(
                  profile.source == VoiceProfileSource.recorded ? 'Direkod dalam app' : 'Dimuat naik',
                  style: GoogleFonts.inter(color: AppColors.textMuted, fontSize: 12),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.textMuted),
            tooltip: 'Padam',
            onPressed: () => _confirmDeleteProfile(context, profile),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (routeContext) => BlocProvider.value(
                    value: context.read<VoiceProfileBloc>(),
                    child: GenerateVoicePage(profile: profile),
                  ),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accent.withOpacity(0.15),
              foregroundColor: AppColors.accent,
              elevation: 0,
            ),
            child: const Text('Jana'),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 300.ms).slideY(begin: 0.05, end: 0);
  }
}
