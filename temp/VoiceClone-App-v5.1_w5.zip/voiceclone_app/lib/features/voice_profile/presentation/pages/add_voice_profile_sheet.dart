import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/voice_profile.dart';
import '../bloc/voice_profile_bloc.dart';

/// Bottom sheet untuk mencipta profil suara baharu, sama ada dengan
/// merekod terus dalam app atau memuat naik fail audio sedia ada.
class AddVoiceProfileSheet extends StatefulWidget {
  const AddVoiceProfileSheet({super.key});

  @override
  State<AddVoiceProfileSheet> createState() => _AddVoiceProfileSheetState();
}

enum _InputMode { none, record, upload }

class _AddVoiceProfileSheetState extends State<AddVoiceProfileSheet> {
  final TextEditingController _nameController = TextEditingController();
  final AudioRecorder _recorder = AudioRecorder();

  _InputMode _mode = _InputMode.none;
  bool _isRecording = false;
  bool _isProcessing = false;
  int _recordSeconds = 0;

  /// Had maksimum durasi rekod dalam saat. Dikira berdasarkan tetapan
  /// WAV lalai pakej `record` (44.1kHz, 16-bit, mono ≈ 88.2KB/saat),
  /// supaya fail yang dihasilkan kekal di bawah had 7MB yang
  /// dikuatkuasakan semasa simpan (rujuk [maxRawBytesForBase64Limit] di
  /// [_handleSave]). Nilai 75 saat memberi margin keselamatan berbanding
  /// had teori ~83 saat.
  static const int _maxRecordSeconds = 75;

  String? _selectedFilePath;
  String? _selectedMimeType;

  @override
  void dispose() {
    _nameController.dispose();
    if (_isRecording) {
      _recorder.stop();
    }
    _recorder.dispose();
    super.dispose();
  }

  Future<void> _startRecording() async {
    final PermissionStatus micStatus = await Permission.microphone.request();
    if (!micStatus.isGranted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Kebenaran mikrofon diperlukan untuk merekod suara.'),
            backgroundColor: AppColors.error,
          ),
        );
      }
      return;
    }

    final bool hasPermission = await _recorder.hasPermission();
    if (!hasPermission) return;

    final Directory tempDir = await getTemporaryDirectory();
    final String path = '${tempDir.path}/voice_recording_${DateTime.now().millisecondsSinceEpoch}.wav';

    await _recorder.start(
      const RecordConfig(encoder: AudioEncoder.wav),
      path: path,
    );

    setState(() {
      _isRecording = true;
      _recordSeconds = 0;
    });

    _tickRecordTimer();
  }

  void _tickRecordTimer() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted || !_isRecording) return;

      final int nextSeconds = _recordSeconds + 1;

      if (nextSeconds >= _maxRecordSeconds) {
        // Had maksimum tercapai — henti rekod secara automatik supaya
        // pengguna tidak perlu risau mengira masa sendiri, dan fail
        // yang dihasilkan sentiasa kekal di bawah had saiz 7MB.
        setState(() => _recordSeconds = nextSeconds);
        _stopRecording();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Rakaman dihentikan secara automatik — had maksimum tercapai.'),
              backgroundColor: AppColors.accent,
            ),
          );
        }
        return;
      }

      setState(() => _recordSeconds = nextSeconds);
      _tickRecordTimer();
    });
  }

  Future<void> _stopRecording() async {
    final String? path = await _recorder.stop();
    setState(() => _isRecording = false);

    if (path == null) return;

    setState(() {
      _selectedFilePath = path;
      _selectedMimeType = 'audio/wav';
    });
  }

  Future<void> _pickAudioFile() async {
    final FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3', 'wav'],
    );

    if (result == null || result.files.single.path == null) return;

    final String path = result.files.single.path!;
    final String extension = path.split('.').last.toLowerCase();
    final String mimeType = extension == 'mp3' ? 'audio/mpeg' : 'audio/wav';

    setState(() {
      _selectedFilePath = path;
      _selectedMimeType = mimeType;
    });
  }

  Future<void> _handleSave() async {
    final String name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sila masukkan nama untuk profil suara ini.')),
      );
      return;
    }

    if (_selectedFilePath == null || _selectedMimeType == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sila rekod atau muat naik sampel suara dahulu.')),
      );
      return;
    }

    setState(() => _isProcessing = true);

    try {
      final File file = File(_selectedFilePath!);
      final int fileSize = await file.length();

      // Had saiz mentah — hasil enkod base64 (~33% lebih besar) mesti
      // kekal di bawah had 10MB API MiMo AI. Enkod base64 sebenar
      // dijana kemudian secara sementara (on-the-fly) oleh bloc apabila
      // profil ini digunakan untuk menjana suara, bukan di sini.
      const int maxRawBytesForBase64Limit = 7 * 1024 * 1024; // ~7MB mentah ≈ ~9.3MB base64
      if (fileSize > maxRawBytesForBase64Limit) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Fail audio terlalu besar. Sila guna sampel di bawah 7MB.'),
              backgroundColor: AppColors.error,
            ),
          );
          setState(() => _isProcessing = false);
        }
        return;
      }

      if (!mounted) return;

      context.read<VoiceProfileBloc>().add(
            SaveVoiceProfile(
              name: name,
              audioFilePath: _selectedFilePath!,
              mimeType: _selectedMimeType!,
              source: _mode == _InputMode.record
                  ? VoiceProfileSource.recorded
                  : VoiceProfileSource.upload,
            ),
          );

      Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memproses fail audio: $e'), backgroundColor: AppColors.error),
        );
        setState(() => _isProcessing = false);
      }
    }
  }

  String _formatDuration(int seconds) {
    final int minutes = seconds ~/ 60;
    final int secs = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.6,
      minChildSize: 0.4,
      maxChildSize: 0.9,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: SingleChildScrollView(
            controller: scrollController,
            padding: EdgeInsets.only(
              left: 20,
              right: 20,
              top: 20,
              bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppColors.cardBorder,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'Profil Suara Baharu',
                  style: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _nameController,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    labelText: 'Nama Profil',
                    hintText: 'cth: Suara Saya, Suara Podcast...',
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: _buildModeButton(
                        icon: Icons.mic_rounded,
                        label: 'Rekod',
                        mode: _InputMode.record,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildModeButton(
                        icon: Icons.upload_file_rounded,
                        label: 'Muat Naik',
                        mode: _InputMode.upload,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                if (_mode == _InputMode.record) _buildRecordPanel(),
                if (_mode == _InputMode.upload) _buildUploadPanel(),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isProcessing ? null : _handleSave,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: _isProcessing
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Text('Simpan Profil Suara'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildModeButton({required IconData icon, required String label, required _InputMode mode}) {
    final bool selected = _mode == mode;
    return GestureDetector(
      onTap: () {
        setState(() {
          _mode = mode;
          _selectedFilePath = null;
          _selectedMimeType = null;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: selected ? AppColors.accent.withOpacity(0.15) : AppColors.card,
          borderRadius: BorderRadius.circular(AppTheme.radiusSm),
          border: Border.all(color: selected ? AppColors.accent : AppColors.cardBorder),
        ),
        child: Column(
          children: [
            Icon(icon, color: selected ? AppColors.accent : AppColors.textMuted),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(color: selected ? Colors.white : AppColors.textMuted, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecordPanel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        children: [
          if (_isRecording) ...[
            Text(
              _formatDuration(_recordSeconds),
              style: GoogleFonts.inter(fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.error),
            ),
            const SizedBox(height: 4),
            Text(
              _recordSeconds >= _maxRecordSeconds
                  ? 'Had maksimum tercapai — sila henti rekod sekarang.'
                  : 'Sedang merekod... (maksimum $_maxRecordSeconds saat)',
              style: TextStyle(
                color: _recordSeconds >= _maxRecordSeconds ? AppColors.error : AppColors.textMuted,
                fontSize: 12,
                fontWeight: _recordSeconds >= _maxRecordSeconds ? FontWeight.bold : FontWeight.normal,
              ),
            ),
            const SizedBox(height: 16),
            _buildRecordingScript(),
          ] else if (_selectedFilePath != null) ...[
            const Icon(Icons.check_circle, color: AppColors.success, size: 32),
            const SizedBox(height: 8),
            const Text('Rakaman sedia digunakan', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
          ] else ...[
            const Icon(Icons.mic_none_rounded, color: AppColors.textMuted, size: 32),
            const SizedBox(height: 8),
            Text(
              'Rekod sekurang-kurangnya 10 saat, maksimum $_maxRecordSeconds saat, suara jelas untuk hasil klon terbaik.',
              style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _isRecording ? _stopRecording : _startRecording,
            icon: Icon(_isRecording ? Icons.stop_rounded : Icons.mic_rounded),
            label: Text(_isRecording ? 'Henti Rekod' : (_selectedFilePath != null ? 'Rekod Semula' : 'Mula Rekod')),
            style: ElevatedButton.styleFrom(
              backgroundColor: _isRecording ? AppColors.error : AppColors.accent,
              foregroundColor: _isRecording ? Colors.white : AppColors.textOnAccent,
            ),
          ),
        ],
      ),
    );
  }

  /// Skrip panduan yang dipaparkan SEMASA rakaman berlangsung, supaya
  /// pengguna tahu apa hendak disebut untuk sampel suara rujukan.
  ///
  /// PENTING: ini BERBEZA daripada ayat cadangan di skrin Jana Suara —
  /// skrip di sini adalah untuk direktori BACA semasa merekod sampel
  /// suara asal (fasa cipta profil), manakala ayat cadangan di skrin
  /// Jana Suara adalah teks yang akan DISEBUT OLEH suara klon selepas
  /// profil siap (fasa penjanaan). Dua konteks yang berlainan.
  Widget _buildRecordingScript() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.scaffold,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Baca ayat di bawah semasa merekod:',
            style: GoogleFonts.inter(fontSize: 11, color: AppColors.textMuted, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            _recordingScript,
            style: const TextStyle(color: Colors.white, fontSize: 13, height: 1.5),
          ),
        ],
      ),
    );
  }

  /// Skrip panduan untuk dibaca semasa merekod sampel suara — dipilih
  /// supaya merangkumi pelbagai bunyi vokal dan konsonan Bahasa Melayu
  /// bagi menghasilkan sampel yang lebih kaya untuk model klon suara.
  static const String _recordingScript =
      'Nama saya sedang merekod sampel suara untuk aplikasi ini. '
      'Hari ini cuaca sangat cerah dan udara terasa segar di pagi hari. '
      'Saya suka membaca buku, mendengar muzik, dan berjalan-jalan pada waktu petang. '
      'Terima kasih kerana mendengar rakaman suara saya ini.';

  Widget _buildUploadPanel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        children: [
          if (_selectedFilePath != null) ...[
            const Icon(Icons.check_circle, color: AppColors.success, size: 32),
            const SizedBox(height: 8),
            Text(
              _selectedFilePath!.split('/').last,
              style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
              overflow: TextOverflow.ellipsis,
            ),
          ] else ...[
            const Icon(Icons.upload_file_rounded, color: AppColors.textMuted, size: 32),
            const SizedBox(height: 8),
            const Text(
              'Muat naik fail .mp3 atau .wav (di bawah 7MB) sebagai sampel suara.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _pickAudioFile,
            icon: const Icon(Icons.folder_open_rounded),
            label: Text(_selectedFilePath != null ? 'Pilih Fail Lain' : 'Pilih Fail Audio'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accent,
              foregroundColor: AppColors.textOnAccent,
            ),
          ),
        ],
      ),
    );
  }
}
