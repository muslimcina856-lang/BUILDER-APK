import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Singleton SQLite database service untuk aplikasi Klon Suara.
///
/// Menguruskan jadual: voice_profiles, voice_clone_results.
class DatabaseService {
  static const int _dbVersion = 2;

  // Singleton
  DatabaseService._internal();
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;

  Database? _db;

  Future<Database> get database async {
    if (_db != null && _db!.isOpen) return _db!;
    _db = await _initDatabase();
    return _db!;
  }

  Future<Database> _initDatabase() async {
    final String dbPath = await getDatabasesPath();
    final String path = join(dbPath, 'voiceclone_app.db');

    return openDatabase(
      path,
      version: _dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
      onConfigure: (Database db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    final Batch batch = db.batch();

    batch.execute('''
      CREATE TABLE voice_profiles (
        id               TEXT PRIMARY KEY,
        name             TEXT NOT NULL,
        audio_file_path  TEXT NOT NULL,
        mime_type        TEXT NOT NULL,
        source           TEXT NOT NULL DEFAULT 'upload',
        created_at       TEXT NOT NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE voice_clone_results (
        id                TEXT PRIMARY KEY,
        voice_profile_id  TEXT NOT NULL,
        text              TEXT NOT NULL,
        output_file_path  TEXT NOT NULL,
        created_at        TEXT NOT NULL,
        FOREIGN KEY (voice_profile_id) REFERENCES voice_profiles(id) ON DELETE CASCADE
      )
    ''');

    batch.execute(
        'CREATE INDEX idx_voice_results_profile ON voice_clone_results(voice_profile_id)');

    await batch.commit(noResult: true);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      // Versi 1 menyimpan sampel audio sebagai teks base64 terus dalam
      // lajur audio_base64, yang menyebabkan ralat "Row too big to fit
      // into CursorWindow" pada Android apabila sampel audio melebihi
      // kira-kira 1.5MB (had CursorWindow ialah ~2MB seluruh baris).
      //
      // Data lama dalam format ini tidak lagi boleh dibaca dengan selamat
      // (itulah punca ralat yang menyebabkan migrasi ini diperlukan), dan
      // base64 lama tidak serasi dengan lajur audio_file_path yang baharu
      // (yang menyimpan LALUAN FAIL, bukan kandungan audio). Oleh itu,
      // jadual dibina semula dari kosong — profil suara lama perlu
      // didaftarkan semula oleh pengguna selepas kemas kini ini.
      await db.execute('DROP TABLE IF EXISTS voice_clone_results');
      await db.execute('DROP TABLE IF EXISTS voice_profiles');

      await db.execute('''
        CREATE TABLE voice_profiles (
          id               TEXT PRIMARY KEY,
          name             TEXT NOT NULL,
          audio_file_path  TEXT NOT NULL,
          mime_type        TEXT NOT NULL,
          source           TEXT NOT NULL DEFAULT 'upload',
          created_at       TEXT NOT NULL
        )
      ''');

      await db.execute('''
        CREATE TABLE voice_clone_results (
          id                TEXT PRIMARY KEY,
          voice_profile_id  TEXT NOT NULL,
          text              TEXT NOT NULL,
          output_file_path  TEXT NOT NULL,
          created_at        TEXT NOT NULL,
          FOREIGN KEY (voice_profile_id) REFERENCES voice_profiles(id) ON DELETE CASCADE
        )
      ''');

      await db.execute(
          'CREATE INDEX idx_voice_results_profile ON voice_clone_results(voice_profile_id)');
    }
  }

  // ---------------------------------------------------------------------------
  // Voice Profiles – CRUD
  // ---------------------------------------------------------------------------

  Future<void> saveVoiceProfile(Map<String, dynamic> profileMap) async {
    final Database db = await database;
    await db.insert(
      'voice_profiles',
      profileMap,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getAllVoiceProfiles() async {
    final Database db = await database;
    return db.query('voice_profiles', orderBy: 'created_at DESC');
  }

  /// Memadam satu profil suara mengikut id. Turut memadam semua hasil
  /// penjanaan yang berkaitan (ON DELETE CASCADE).
  Future<int> deleteVoiceProfile(String id) async {
    final Database db = await database;
    return db.delete('voice_profiles', where: 'id = ?', whereArgs: <dynamic>[id]);
  }

  // ---------------------------------------------------------------------------
  // Voice Clone Results – CRUD
  // ---------------------------------------------------------------------------

  Future<void> saveVoiceCloneResult(Map<String, dynamic> resultMap) async {
    final Database db = await database;
    await db.insert(
      'voice_clone_results',
      resultMap,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getAllVoiceCloneResults() async {
    final Database db = await database;
    return db.query('voice_clone_results', orderBy: 'created_at DESC');
  }

  Future<int> deleteVoiceCloneResult(String id) async {
    final Database db = await database;
    return db.delete(
      'voice_clone_results',
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  /// Memadam semua data (digunakan oleh fungsi "Padam Semua Data").
  Future<void> clearAllData() async {
    final Database db = await database;
    await db.delete('voice_clone_results');
    await db.delete('voice_profiles');
  }

  Future<void> close() async {
    final Database? db = _db;
    if (db != null && db.isOpen) {
      await db.close();
      _db = null;
    }
  }
}
