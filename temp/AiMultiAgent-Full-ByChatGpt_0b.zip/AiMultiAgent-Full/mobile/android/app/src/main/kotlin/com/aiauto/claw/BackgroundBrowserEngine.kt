package com.aiauto.claw

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

class BackgroundBrowserEngine(
    private val activity: Activity,
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val tabs = linkedMapOf<Int, BrowserTab>()
    private var nextTabId = 1
    private var activeTabId = 0
    private val maxTabs = 5
    private var pendingResult: MethodChannel.Result? = null
    private var pendingDone = AtomicBoolean(true)
    private var pendingGen: Int = 0
    private var timeoutRunnable: Runnable? = null
    private var desktopMode: Boolean = true

    private data class BrowserTab(
        val id: Int,
        val webView: WebView,
        var title: String = "",
        var url: String = "",
    )

    fun handle(call: MethodCall, result: MethodChannel.Result) {
        activity.runOnUiThread {
            try {
                when (call.method) {
                    "open" -> open(
                        url = call.argument<String>("url").orEmpty(),
                        desktop = call.argument<Boolean>("desktopMode") ?: true,
                        newTab = call.argument<Boolean>("newTab") ?: false,
                        result = result,
                    )
                    "read", "snapshot" -> snapshot(result)
                    "click" -> click(
                        selector = call.argument<String>("selector").orEmpty(),
                        text = call.argument<String>("text").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        result = result,
                    )
                    "fill" -> fill(
                        selector = call.argument<String>("selector").orEmpty(),
                        value = call.argument<String>("value").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        typeMode = call.argument<Boolean>("type_mode") ?: false,
                        result = result,
                    )
                    "selectOption" -> selectOption(
                        selector = call.argument<String>("selector").orEmpty(),
                        optionText = call.argument<String>("option_text").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        label = call.argument<String>("label").orEmpty(),
                        result = result,
                    )
                    "pressKey" -> pressKey(
                        selector = call.argument<String>("selector").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        key = call.argument<String>("key").orEmpty(),
                        text = call.argument<String>("text").orEmpty(),
                        repeat = (call.argument<Number>("repeat"))?.toInt() ?: 1,
                        result = result,
                    )
                    "submit" -> submit(
                        selector = call.argument<String>("selector").orEmpty(),
                        index = (call.argument<Number>("index"))?.toInt(),
                        result = result,
                    )
                    "back" -> navigate("back", result)
                    "forward" -> navigate("forward", result)
                    "reload" -> navigate("reload", result)
                    "clearCookies" -> clearCookies(result)
                    "screenshot" -> screenshot(result)
                    "tabs" -> listTabs(result)
                    "switchTab" -> switchTab(
                        tabId = (call.argument<Number>("tabId"))?.toInt(),
                        result = result,
                    )
                    "closeTab" -> closeTab(
                        tabId = (call.argument<Number>("tabId"))?.toInt(),
                        result = result,
                    )
                    "cancel" -> cancelPendingWork(result)
                    else -> result.notImplemented()
                }
            } catch (error: Throwable) {
                result.error("browser_error", error.message ?: error.javaClass.simpleName, null)
            }
        }
    }

    private fun tabSummaryList(): List<Map<String, Any?>> =
        tabs.values.map { tab ->
            mapOf(
                "id" to tab.id,
                "url" to (tab.webView.url ?: tab.url),
                "title" to (tab.webView.title ?: tab.title),
                "active" to (tab.id == activeTabId),
            )
        }

    private fun listTabs(result: MethodChannel.Result) {
        result.success(
            mapOf(
                "success" to true,
                "activeTabId" to activeTabId,
                "maxTabs" to maxTabs,
                "count" to tabs.size,
                "tabs" to tabSummaryList(),
            ),
        )
    }

    private fun switchTab(tabId: Int?, result: MethodChannel.Result) {
        val id = tabId ?: run {
            result.error("invalid_tab", "tabId diperlukan.", null)
            return
        }
        var tab = tabs[id]
        var recovered = false
        // Tab lama sering di-evict (max 5) — jangan gagal keras; guna tab aktif.
        if (tab == null) {
            tab = tabs[activeTabId] ?: tabs.values.lastOrNull()
            recovered = true
            if (tab == null) {
                result.success(
                    mapOf(
                        "success" to false,
                        "recovered" to false,
                        "message" to
                            "Tab $id tidak wujud dan tiada tab lain. Buka URL baru dengan browser_open.",
                        "requestedTabId" to id,
                        "activeTabId" to activeTabId,
                        "tabs" to tabSummaryList(),
                        "maxTabs" to maxTabs,
                    ),
                )
                return
            }
        }
        activeTabId = tab.id
        try {
            tab.webView.requestFocus()
            silenceMedia(tab.webView)
        } catch (_: Throwable) {
        }
        result.success(
            mapOf(
                "success" to true,
                "recovered" to recovered,
                "message" to if (recovered) {
                    "Tab $id sudah ditutup/evict (max $maxTabs). Beralih ke tab aktif ${tab.id}."
                } else {
                    "Tab ${tab.id} aktif."
                },
                "requestedTabId" to id,
                "activeTabId" to activeTabId,
                "url" to (tab.webView.url ?: tab.url),
                "title" to (tab.webView.title ?: tab.title),
                "tabs" to tabSummaryList(),
                "maxTabs" to maxTabs,
            ),
        )
    }

    private fun closeTab(tabId: Int?, result: MethodChannel.Result) {
        val id = tabId ?: activeTabId
        val tab = tabs.remove(id)
        if (tab == null) {
            result.error("invalid_tab", "Tab $id tidak wujud.", null)
            return
        }
        destroyWebView(tab.webView)
        if (activeTabId == id) {
            activeTabId = tabs.keys.lastOrNull() ?: 0
        }
        result.success(
            mapOf(
                "success" to true,
                "closedTabId" to id,
                "activeTabId" to activeTabId,
                "tabs" to tabSummaryList(),
            ),
        )
    }

    private fun destroyWebView(view: WebView) {
        try {
            (view.parent as? ViewGroup)?.removeView(view)
        } catch (_: Throwable) {
        }
        try {
            view.stopLoading()
            view.loadUrl("about:blank")
            view.webChromeClient = null
            view.destroy()
        } catch (_: Throwable) {
        }
    }

    private fun activeWebView(): WebView = ensureActiveTab().webView

    private fun ensureActiveTab(): BrowserTab {
        tabs[activeTabId]?.let { return it }
        return createTab(makeActive = true)
    }

    /** Tutup tab tertua yang bukan aktif (atau mana-mana jika terpaksa). */
    private fun evictOldestInactiveTab(): Boolean {
        val victim = tabs.entries.firstOrNull { it.key != activeTabId }
            ?: tabs.entries.firstOrNull()
            ?: return false
        tabs.remove(victim.key)
        destroyWebView(victim.value.webView)
        if (activeTabId == victim.key) {
            activeTabId = tabs.keys.lastOrNull() ?: 0
        }
        return true
    }

    private fun createTab(makeActive: Boolean = true): BrowserTab {
        if (tabs.size >= maxTabs) {
            if (!evictOldestInactiveTab()) {
                throw IllegalStateException(
                    "Had $maxTabs tab dicapai. Tutup satu tab (browser_close_tab) dahulu.",
                )
            }
        }
        val id = nextTabId++
        val view = buildWebView(id)
        val tab = BrowserTab(id = id, webView = view)
        tabs[id] = tab
        if (makeActive || activeTabId == 0) {
            activeTabId = id
        }
        return tab
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView(tabId: Int): WebView {
        val created = WebView(activity)
        created.setBackgroundColor(Color.TRANSPARENT)
        created.alpha = 0.01f
        created.translationX = -10000f
        created.translationY = -10000f
        created.layoutParams = ViewGroup.LayoutParams(1080, 1920)
        created.settings.apply {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            blockNetworkImage = false
            allowContentAccess = false
            allowFileAccess = false
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = if (desktopMode) desktopUserAgent() else mobileUserAgent()
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                offscreenPreRaster = true
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                safeBrowsingEnabled = true
            }
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(created, true)
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                created,
                MUTE_MEDIA_SCRIPT,
                setOf("*"),
            )
        }
        created.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?,
            ): Boolean {
                if (resultMsg == null) return false
                return try {
                    // createTab auto-evict jika had 5 penuh.
                    val tab = createTab(makeActive = true)
                    val transport = resultMsg.obj as? WebView.WebViewTransport
                        ?: return false
                    transport.webView = tab.webView
                    resultMsg.sendToTarget()
                    true
                } catch (_: Throwable) {
                    false
                }
            }

            override fun onCloseWindow(window: WebView?) {
                if (window == null) return
                val entry = tabs.entries.firstOrNull { it.value.webView === window } ?: return
                tabs.remove(entry.key)
                destroyWebView(window)
                if (activeTabId == entry.key) {
                    activeTabId = tabs.keys.lastOrNull() ?: 0
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (view == null) return
                tabs.entries.firstOrNull { it.value.webView === view }?.value?.title =
                    title.orEmpty()
            }
        }
        created.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                silenceMedia(view)
                tabs[tabId]?.let {
                    it.url = url.orEmpty()
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?,
            ): Boolean = false

            override fun onPageFinished(view: WebView, url: String) {
                silenceMedia(view)
                tabs[tabId]?.let {
                    it.url = url
                    it.title = view.title.orEmpty()
                }
                // Snapshot pending hanya untuk tab aktif
                if (tabId == activeTabId && pendingResult != null && !pendingDone.get()) {
                    // SPA (GitHub dsb.): tunggu render sebelum snapshot untuk AI
                    val gen = pendingGen
                    mainHandler.postDelayed({ snapshotPending(gen) }, 1200L)
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: android.webkit.WebResourceError,
            ) {
                if (request.isForMainFrame && tabId == activeTabId) {
                    finishError("load_error", error.description?.toString() ?: "Gagal memuat halaman")
                }
            }
        }
        val root = activity.window.decorView as? ViewGroup
        root?.addView(created)
        return created
    }

    private fun open(
        url: String,
        desktop: Boolean,
        newTab: Boolean,
        result: MethodChannel.Result,
    ) {
        var normalized = url.trim()
        if (normalized.startsWith("//")) {
            normalized = "https:$normalized"
        } else if (!normalized.startsWith("http://") &&
            !normalized.startsWith("https://")
        ) {
            // domain.com/path → https://domain.com/path
            if (normalized.contains(".") && !normalized.contains(" ")) {
                normalized = "https://$normalized"
            } else {
                result.error(
                    "invalid_url",
                    "URL HTTP/HTTPS tidak sah: ${url.take(120)}",
                    null,
                )
                return
            }
        }
        desktopMode = desktop
        val tab = try {
            when {
                tabs.isEmpty() -> ensureActiveTab()
                newTab -> {
                    // new_tab eksplisit: evict auto dalam createTab jika penuh
                    createTab(makeActive = true)
                }
                else -> ensureActiveTab()
            }
        } catch (error: Throwable) {
            result.error(
                "tab_limit",
                error.message,
                mapOf("tabs" to tabSummaryList(), "maxTabs" to maxTabs),
            )
            return
        }
        val view = tab.webView
        view.settings.userAgentString = if (desktopMode) desktopUserAgent() else mobileUserAgent()
        silenceMedia(view)
        if (!beginPending(result, 120_000L)) return
        view.loadUrl(normalized)
    }

    private fun snapshot(result: MethodChannel.Result) {
        val view = activeWebView()
        if (view.url.isNullOrBlank()) {
            result.error("empty_page", "Tiada halaman aktif dalam browser latar belakang.", null)
            return
        }
        if (!beginPending(result, 60_000L)) return
        snapshotPending(pendingGen)
    }

    private fun click(selector: String, text: String, index: Int?, result: MethodChannel.Result) {
        val selectorJson = JSONObject.quote(selector)
        val textJson = JSONObject.quote(text)
        val indexJs = index?.toString() ?: "null"
        // Self-heal: cuba index → text → selector dalam satu tindakan.
        val script = """
            (() => {
              $CLAW_PRELUDE
              const found = CLAW.resolve($indexJs, $textJson, $selectorJson);
              if (!found.el) {
                return JSON.stringify({
                  success:false,
                  error:'Elemen tidak ditemui. Panggil browser_read semula untuk index terkini.',
                  self_heal_hint: true,
                  available_count: found.total
                });
              }
              const el = found.el;
              const before = document.activeElement;
              CLAW.realClick(el);
              const expanded = el.getAttribute('aria-expanded');
              return JSON.stringify({
                success:true,
                action:'click',
                strategy:found.strategy,
                index: $indexJs,
                tag: (el.tagName || '').toLowerCase(),
                role: el.getAttribute('role') || '',
                aria_expanded: expanded === null ? '' : expanded,
                opened_popup: expanded === 'true',
                focus_moved: before !== document.activeElement
              });
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 700L)
    }

    private fun fill(
        selector: String,
        value: String,
        index: Int?,
        typeMode: Boolean,
        result: MethodChannel.Result,
    ) {
        if (selector.isBlank() && index == null) {
            result.error("missing_target", "Index atau CSS selector diperlukan.", null)
            return
        }
        val selectorJson = JSONObject.quote(selector)
        val valueJson = JSONObject.quote(value)
        val indexJs = index?.toString() ?: "null"
        val typeJs = if (typeMode) "true" else "false"
        val script = """
            (() => {
              $CLAW_PRELUDE
              const found = CLAW.resolve($indexJs, '', $selectorJson);
              if (!found.el) {
                return JSON.stringify({
                  success:false,
                  error:'Input tidak ditemui. Panggil browser_read semula untuk index terkini.',
                  self_heal_hint: true,
                  available_count: found.total
                });
              }
              const el = found.el;
              const value = $valueJson;
              const tag = (el.tagName || '').toLowerCase();
              const role = el.getAttribute('role') || '';
              const popup = el.getAttribute('aria-haspopup') || '';

              // Dropdown tersuai bukan medan teks — set value tidak akan berkesan.
              const isCustomSelect = tag !== 'select' && tag !== 'input' && tag !== 'textarea' &&
                !el.isContentEditable &&
                (role === 'combobox' || role === 'listbox' || popup === 'listbox' || popup === 'menu' || popup === 'true');
              if (isCustomSelect) {
                return JSON.stringify({
                  success:false,
                  error:'Elemen ini dropdown tersuai (role=' + (role || popup) + '), bukan input teks. Guna browser_select_option dengan option_text.',
                  use_tool:'browser_select_option'
                });
              }

              try { el.scrollIntoView({block:'center',inline:'center'}); } catch (e) { }

              if (el.isContentEditable) {
                try { el.focus(); } catch (e) { }
                el.textContent = value;
                CLAW.notify(el);
                return JSON.stringify({success:true,action:'fill',strategy:found.strategy,mode:'contenteditable'});
              }

              if (tag === 'select') {
                const opts = Array.from(el.options || []);
                const target = CLAW.clean(value).toLowerCase();
                let opt = opts.find(function (o) { return o.value === value; });
                if (!opt) opt = opts.find(function (o) { return CLAW.clean(o.text).toLowerCase() === target; });
                if (!opt) opt = opts.find(function (o) { return CLAW.clean(o.text).toLowerCase().indexOf(target) === 0; });
                if (!opt) {
                  return JSON.stringify({
                    success:false,
                    error:'Pilihan tidak wujud dalam select.',
                    available: opts.slice(0, 40).map(function (o) { return CLAW.clean(o.text); })
                  });
                }
                CLAW.setNativeValue(el, opt.value);
                CLAW.notify(el);
                return JSON.stringify({success:true,action:'fill',strategy:found.strategy,mode:'select',selected:CLAW.clean(opt.text)});
              }

              // Input bertopeng (DD/MM/YYYY, nombor kad) menolak set value terus.
              if ($typeJs) {
                CLAW.setNativeValue(el, '');
                CLAW.typeText(el, value);
                return JSON.stringify({success:true,action:'fill',strategy:found.strategy,mode:'type',value_now:el.value || ''});
              }

              try { el.focus({preventScroll:true}); } catch (e) { try { el.focus(); } catch (e2) { } }
              CLAW.setNativeValue(el, value);
              CLAW.notify(el);
              return JSON.stringify({
                success:true,
                action:'fill',
                strategy:found.strategy,
                mode:'value',
                value_now: el.value || '',
                accepted: (el.value || '') === value
              });
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 200L)
    }

    /**
     * Pilih satu nilai daripada dropdown — native `<select>` ATAU komponen
     * tersuai React (Radix, Headless UI, MUI, react-select).
     *
     * Dropdown tersuai tidak boleh diselesaikan dalam satu skrip: senarai
     * pilihan hanya wujud dalam DOM SELEPAS pencetus dibuka, dan selalunya
     * dirender ke portal di hujung <body>. Jadi ia dijalankan dua fasa dengan
     * jeda sebenar di antaranya supaya React sempat render.
     *
     *   Fasa 1 — buka pencetus (atau selesai terus jika <select> native).
     *   Fasa 2 — cari pilihan yang baru muncul, klik dengan urutan pointer.
     */
    private fun selectOption(
        selector: String,
        optionText: String,
        index: Int?,
        label: String,
        result: MethodChannel.Result,
    ) {
        if (optionText.isBlank()) {
            result.error("missing_option", "option_text diperlukan.", null)
            return
        }
        val selectorJson = JSONObject.quote(selector)
        val optionJson = JSONObject.quote(optionText)
        val labelJson = JSONObject.quote(label)
        val indexJs = index?.toString() ?: "null"

        val openScript = """
            (() => {
              $CLAW_PRELUDE
              const found = CLAW.resolve($indexJs, $labelJson, $selectorJson);
              if (!found.el) {
                return JSON.stringify({
                  success:false,
                  error:'Dropdown tidak ditemui. Panggil browser_read untuk index terkini.',
                  self_heal_hint: true,
                  available_count: found.total
                });
              }
              const el = found.el;
              const wanted = $optionJson;

              // Native <select>: selesai terus, tiada fasa kedua.
              if ((el.tagName || '').toLowerCase() === 'select') {
                const opts = Array.from(el.options || []);
                const target = CLAW.clean(wanted).toLowerCase();
                let opt = opts.find(function (o) { return o.value === wanted; });
                if (!opt) opt = opts.find(function (o) { return CLAW.clean(o.text).toLowerCase() === target; });
                if (!opt) opt = opts.find(function (o) { return CLAW.clean(o.text).toLowerCase().indexOf(target) === 0; });
                if (!opt) {
                  return JSON.stringify({
                    success:false,
                    error:'Pilihan tidak wujud.',
                    available: opts.slice(0, 60).map(function (o) { return CLAW.clean(o.text); })
                  });
                }
                CLAW.setNativeValue(el, opt.value);
                CLAW.notify(el);
                return JSON.stringify({success:true,done:true,mode:'native-select',selected:CLAW.clean(opt.text)});
              }

              // Rekod pilihan sedia ada supaya fasa 2 tahu mana yang BARU muncul.
              window.__clawBefore = CLAW.deepAll(CLAW_OPTION_SELECTOR).filter(CLAW.isVisible).length;
              window.__clawTrigger = el;
              CLAW.realClick(el);
              return JSON.stringify({
                success:true,
                done:false,
                mode:'custom',
                strategy:found.strategy,
                role: el.getAttribute('role') || '',
                options_before: window.__clawBefore
              });
            })();
        """.trimIndent()

        val pickScript = """
            (() => {
              $CLAW_PRELUDE
              const wanted = $optionJson;
              const trigger = window.__clawTrigger || null;

              // Utamakan listbox yang dikawal pencetus (aria-controls / aria-owns).
              let scope = null;
              if (trigger) {
                const owns = trigger.getAttribute('aria-controls') || trigger.getAttribute('aria-owns');
                if (owns) {
                  try { scope = document.getElementById(owns); } catch (e) { scope = null; }
                }
              }

              let nodes = [];
              if (scope) {
                nodes = Array.from(scope.querySelectorAll(CLAW_OPTION_SELECTOR)).filter(CLAW.isVisible);
              }
              if (!nodes.length) {
                nodes = CLAW.deepAll(CLAW_OPTION_SELECTOR).filter(CLAW.isVisible);
              }
              if (!nodes.length) {
                return JSON.stringify({
                  success:false,
                  error:'Dropdown tidak membuka sebarang pilihan. Cuba browser_press_key(key="ArrowDown") pada pencetus, atau browser_screenshot untuk lihat keadaan.',
                  options_before: window.__clawBefore || 0
                });
              }

              const hit = CLAW.matchOption(nodes, wanted);
              if (!hit) {
                return JSON.stringify({
                  success:false,
                  error:'Pilihan "' + wanted + '" tidak ditemui dalam senarai yang terbuka.',
                  available: nodes.slice(0, 60).map(function (n) { return CLAW.clean(n.innerText || n.textContent || ''); }).filter(function (t) { return t; })
                });
              }

              CLAW.realClick(hit);
              const chosen = CLAW.clean(hit.innerText || hit.textContent || '');
              window.__clawTrigger = null;
              return JSON.stringify({
                success:true,
                done:true,
                mode:'custom',
                selected: chosen,
                option_count: nodes.length,
                scoped: !!scope
              });
            })();
        """.trimIndent()

        val view = activeWebView()
        view.evaluateJavascript(openScript) { rawOpen ->
            try {
                val openResult = decodeJavascriptObject(rawOpen)
                if (!openResult.optBoolean("success", false)) {
                    result.success(jsonObjectToMap(openResult))
                    return@evaluateJavascript
                }
                if (!beginPending(result, 60_000L)) return@evaluateJavascript
                val gen = pendingGen
                if (openResult.optBoolean("done", false)) {
                    mainHandler.postDelayed({ snapshotPending(gen) }, 250L)
                    return@evaluateJavascript
                }
                // Beri React masa render portal sebelum mencari pilihan.
                mainHandler.postDelayed({
                    if (gen != pendingGen) return@postDelayed
                    activeWebView().evaluateJavascript(pickScript) { rawPick ->
                        try {
                            val pickResult = decodeJavascriptObject(rawPick)
                            if (pickResult.optBoolean("success", false)) {
                                mainHandler.postDelayed({ snapshotPending(gen) }, 300L)
                            } else {
                                finishError(
                                    "option_not_found",
                                    pickResult.optString("error", "Pilihan tidak ditemui.") +
                                        (pickResult.optJSONArray("available")?.let {
                                            " Pilihan tersedia: $it"
                                        } ?: ""),
                                    gen,
                                )
                            }
                        } catch (error: Throwable) {
                            finishError("javascript_error", error.message ?: "pick gagal", gen)
                        }
                    }
                }, 450L)
            } catch (error: Throwable) {
                result.error("javascript_error", error.message, null)
            }
        }
    }

    /**
     * Hantar kekunci sebenar ke elemen. Perlu untuk combobox yang hanya
     * bertindak balas kepada papan kekunci (ArrowDown/Enter) dan untuk input
     * bertopeng yang menolak set value terus.
     */
    private fun pressKey(
        selector: String,
        index: Int?,
        key: String,
        text: String,
        repeat: Int,
        result: MethodChannel.Result,
    ) {
        val selectorJson = JSONObject.quote(selector)
        val keyJson = JSONObject.quote(key)
        val textJson = JSONObject.quote(text)
        val indexJs = index?.toString() ?: "null"
        val repeatJs = repeat.coerceIn(1, 40).toString()
        val script = """
            (() => {
              $CLAW_PRELUDE
              let el = null;
              const found = CLAW.resolve($indexJs, '', $selectorJson);
              el = found.el || document.activeElement || document.body;
              if (!el) {
                return JSON.stringify({success:false,error:'Tiada elemen sasaran.'});
              }
              try { el.focus({preventScroll:true}); } catch (e) { try { el.focus(); } catch (e2) { } }
              const text = $textJson;
              const key = $keyJson;
              if (text) {
                CLAW.typeText(el, text);
                return JSON.stringify({success:true,action:'type',typed:text,value_now:el.value || ''});
              }
              if (!key) {
                return JSON.stringify({success:false,error:'Perlu key atau text.'});
              }
              for (let i = 0; i < $repeatJs; i++) { CLAW.pressKey(el, key); }
              return JSON.stringify({
                success:true,
                action:'key',
                key:key,
                repeat:$repeatJs,
                strategy:found.strategy,
                value_now: el.value || ''
              });
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 350L)
    }

    private fun submit(selector: String, index: Int?, result: MethodChannel.Result) {
        val selectorJson = JSONObject.quote(selector)
        val indexJs = index?.toString() ?: "null"
        val script = """
            (() => {
              const collect = () => Array.from(document.querySelectorAll(
                'a[href],button,input,textarea,select,[role="button"],[role="link"],[role="textbox"],[role="checkbox"],[role="radio"],[role="menuitem"],[contenteditable="true"]'
              )).filter((node) => {
                const style = window.getComputedStyle(node);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                const rect = node.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
              });
              const index = $indexJs;
              const selector = $selectorJson;
              let form = null;
              if (index !== null && index !== undefined && !Number.isNaN(index)) {
                const el = collect()[index];
                if (el) form = el.tagName === 'FORM' ? el : el.closest('form');
              }
              if (!form && selector) {
                const el = document.querySelector(selector);
                form = el && el.tagName === 'FORM' ? el : (el ? el.closest('form') : null);
              }
              if (!form) form = document.querySelector('form');
              if (!form) return JSON.stringify({success:false,error:'Borang tidak ditemui'});
              if (form.requestSubmit) form.requestSubmit(); else form.submit();
              return JSON.stringify({success:true,action:'submit'});
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 900L)
    }

    private fun navigate(action: String, result: MethodChannel.Result) {
        val view = activeWebView()
        if (!beginPending(result, 60_000L)) return
        when (action) {
            "back" -> if (view.canGoBack()) view.goBack() else snapshotPending(pendingGen)
            "forward" -> if (view.canGoForward()) view.goForward() else snapshotPending(pendingGen)
            else -> view.reload()
        }
    }

    private fun clearCookies(result: MethodChannel.Result) {
        CookieManager.getInstance().removeAllCookies {
            CookieManager.getInstance().flush()
            result.success(mapOf("success" to true))
        }
    }

    private fun screenshot(result: MethodChannel.Result) {
        val view = activeWebView()
        if (view.url.isNullOrBlank()) {
            result.error("empty_page", "Tiada halaman aktif untuk screenshot.", null)
            return
        }
        silenceMedia(view)
        // Tunggu page stabil (JS/SPA render) sebelum ambil screenshot —
        // elak pratonton putih (GitHub dsb. siap shell dulu, kandungan kemudian).
        waitForPageRenderStable(view, attempt = 0, lastHeight = -1, stableCount = 0) {
            view.evaluateJavascript(FULL_PAGE_SIZE_SCRIPT) { raw ->
                try {
                    val dimensions = decodeJavascriptObject(raw)
                    captureFullPageScreenshot(view, dimensions, result)
                } catch (error: Throwable) {
                    result.error("screenshot_dimensions_error", error.message, null)
                }
            }
        }
    }

    /**
     * Poll readyState + scrollHeight + text length sampai stabil ~2x,
     * atau timeout ~6.5s. Elak snapshot terlalu awal pada SPA.
     */
    private fun waitForPageRenderStable(
        view: WebView,
        attempt: Int,
        lastHeight: Int,
        stableCount: Int,
        onReady: () -> Unit,
    ) {
        val maxAttempts = 16 // ~16 * 400ms = 6.4s
        if (attempt >= maxAttempts) {
            onReady()
            return
        }
        val script = """
            (function(){
              var body = document.body;
              var doc = document.documentElement;
              var h = Math.max(
                body ? body.scrollHeight : 0,
                doc ? doc.scrollHeight : 0,
                body ? body.offsetHeight : 0
              );
              var text = (body && body.innerText) ? body.innerText.replace(/\s+/g,' ').trim() : '';
              return JSON.stringify({
                h: h,
                textLen: text.length,
                ready: document.readyState,
                hasContent: text.length > 40 || document.querySelectorAll('img,article,main,[role=main]').length > 0
              });
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { raw ->
            try {
                val obj = decodeJavascriptObject(raw)
                val h = obj.optInt("h", 0)
                val textLen = obj.optInt("textLen", 0)
                val ready = obj.optString("ready", "") == "complete"
                val hasContent = obj.optBoolean("hasContent", false)
                val heightStable = lastHeight > 0 && kotlin.math.abs(h - lastHeight) < 12
                val nextStable = if (ready && heightStable && (hasContent || textLen > 40)) {
                    stableCount + 1
                } else {
                    0
                }
                // Min 2 cubaan (~800ms) + 2 bacaan stabil, atau kandungan jelas selepas 1s
                if (nextStable >= 2 && attempt >= 2) {
                    onReady()
                    return@evaluateJavascript
                }
                if (attempt >= 3 && ready && hasContent && textLen > 120 && heightStable) {
                    onReady()
                    return@evaluateJavascript
                }
                mainHandler.postDelayed({
                    waitForPageRenderStable(
                        view = view,
                        attempt = attempt + 1,
                        lastHeight = h,
                        stableCount = nextStable,
                        onReady = onReady,
                    )
                }, 400L)
            } catch (_: Throwable) {
                mainHandler.postDelayed({
                    waitForPageRenderStable(
                        view = view,
                        attempt = attempt + 1,
                        lastHeight = lastHeight,
                        stableCount = 0,
                        onReady = onReady,
                    )
                }, 400L)
            }
        }
    }

    private fun captureFullPageScreenshot(
        view: WebView,
        dimensions: JSONObject,
        result: MethodChannel.Result,
    ) {
        val originalScrollX = view.scrollX
        val originalScrollY = view.scrollY
        val viewportWidth = max(1, view.width)
        val viewportHeight = max(1, view.height)
        val documentWidthCss = max(1, dimensions.optInt("width", viewportWidth))
        val documentHeightCss = max(1, dimensions.optInt("height", viewportHeight))
        val viewportWidthCss = max(
            1,
            dimensions.optInt("viewportWidth", documentWidthCss),
        )
        val heightFromWebView = max(
            viewportHeight,
            ceil(view.contentHeight.toDouble() * view.scale.toDouble()).toInt(),
        )
        val heightFromJavascript = max(
            viewportHeight,
            ceil(
                documentHeightCss.toDouble() * viewportWidth.toDouble() /
                    viewportWidthCss.toDouble(),
            ).toInt(),
        )
        val contentHeightPx = max(heightFromWebView, heightFromJavascript)
        val preferredWidth = 1080
        val maxOutputHeight = 16_000
        val maxOutputPixels = 16_000_000L

        var outputScale = min(1.0, preferredWidth.toDouble() / viewportWidth.toDouble())
        outputScale = min(
            outputScale,
            maxOutputHeight.toDouble() / contentHeightPx.toDouble(),
        )
        outputScale = min(
            outputScale,
            sqrt(
                maxOutputPixels.toDouble() /
                    (viewportWidth.toDouble() * contentHeightPx.toDouble()),
            ),
        )
        val outputWidth = max(1, (viewportWidth * outputScale).roundToInt())
        val outputHeight = max(1, (contentHeightPx * outputScale).roundToInt())

        val outputBitmap = try {
            Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
        } catch (error: Throwable) {
            result.error("screenshot_memory_error", error.message, null)
            return
        }
        val outputCanvas = Canvas(outputBitmap).apply { drawColor(Color.WHITE) }
        val scrollPositions = mutableListOf<Int>()
        var offset = 0
        while (offset < contentHeightPx) {
            scrollPositions.add(offset)
            if (offset + viewportHeight >= contentHeightPx) break
            offset = min(offset + viewportHeight, max(0, contentHeightPx - viewportHeight))
            if (scrollPositions.last() == offset) break
        }

        captureScreenshotTile(
            view = view,
            outputBitmap = outputBitmap,
            outputCanvas = outputCanvas,
            outputScale = outputScale,
            scrollPositions = scrollPositions,
            index = 0,
            originalScrollX = originalScrollX,
            originalScrollY = originalScrollY,
            documentWidthCss = documentWidthCss,
            documentHeightCss = documentHeightCss,
            result = result,
        )
    }

    private fun captureScreenshotTile(
        view: WebView,
        outputBitmap: Bitmap,
        outputCanvas: Canvas,
        outputScale: Double,
        scrollPositions: List<Int>,
        index: Int,
        originalScrollX: Int,
        originalScrollY: Int,
        documentWidthCss: Int,
        documentHeightCss: Int,
        result: MethodChannel.Result,
    ) {
        if (index >= scrollPositions.size) {
            finishFullPageScreenshot(
                view = view,
                bitmap = outputBitmap,
                originalScrollX = originalScrollX,
                originalScrollY = originalScrollY,
                documentWidthCss = documentWidthCss,
                documentHeightCss = documentHeightCss,
                result = result,
            )
            return
        }

        val scrollY = scrollPositions[index]
        view.scrollTo(0, scrollY)
        silenceMedia(view)
        mainHandler.postDelayed({
            try {
                val tileWidth = max(1, view.width)
                val tileHeight = max(1, view.height)
                val tile = Bitmap.createBitmap(
                    tileWidth,
                    tileHeight,
                    Bitmap.Config.ARGB_8888,
                )
                val tileCanvas = Canvas(tile).apply { drawColor(Color.WHITE) }
                view.draw(tileCanvas)

                val destinationTop = (scrollY * outputScale).roundToInt()
                    .coerceIn(0, outputBitmap.height)
                val destinationBottom = ((scrollY + tileHeight) * outputScale)
                    .roundToInt()
                    .coerceIn(destinationTop, outputBitmap.height)
                if (destinationBottom > destinationTop) {
                    val sourceHeight = min(
                        tileHeight,
                        ceil(
                            (destinationBottom - destinationTop).toDouble() /
                                outputScale,
                        ).toInt(),
                    )
                    outputCanvas.drawBitmap(
                        tile,
                        android.graphics.Rect(0, 0, tileWidth, sourceHeight),
                        android.graphics.Rect(
                            0,
                            destinationTop,
                            outputBitmap.width,
                            destinationBottom,
                        ),
                        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG),
                    )
                }
                tile.recycle()
                captureScreenshotTile(
                    view = view,
                    outputBitmap = outputBitmap,
                    outputCanvas = outputCanvas,
                    outputScale = outputScale,
                    scrollPositions = scrollPositions,
                    index = index + 1,
                    originalScrollX = originalScrollX,
                    originalScrollY = originalScrollY,
                    documentWidthCss = documentWidthCss,
                    documentHeightCss = documentHeightCss,
                    result = result,
                )
            } catch (error: Throwable) {
                outputBitmap.recycle()
                restoreBrowserViewport(view, originalScrollX, originalScrollY)
                result.error("screenshot_error", error.message, null)
            }
        }, 280L) // lebih lama supaya tile sempat paint selepas scroll
    }

    private fun finishFullPageScreenshot(
        view: WebView,
        bitmap: Bitmap,
        originalScrollX: Int,
        originalScrollY: Int,
        documentWidthCss: Int,
        documentHeightCss: Int,
        result: MethodChannel.Result,
    ) {
        // Screenshot untuk user = BERSIH (tiada kotak index).
        // Index + bbox hanya untuk AI melalui browser_read → interactive_elements.
        try {
            saveScreenshotFile(
                view = view,
                bitmap = bitmap,
                originalScrollX = originalScrollX,
                originalScrollY = originalScrollY,
                documentWidthCss = documentWidthCss,
                documentHeightCss = documentHeightCss,
                result = result,
                annotated = false,
            )
        } catch (error: Throwable) {
            bitmap.recycle()
            restoreBrowserViewport(view, originalScrollX, originalScrollY)
            result.error("screenshot_error", error.message, null)
        }
    }

    private fun drawElementBoxes(
        bitmap: Bitmap,
        boxes: JSONArray,
        documentWidthCss: Int,
        documentHeightCss: Int,
    ) {
        val canvas = Canvas(bitmap)
        val scaleX = bitmap.width.toFloat() / documentWidthCss.toFloat()
        val scaleY = bitmap.height.toFloat() / documentHeightCss.toFloat()
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = max(2f, 2f * scaleX)
            color = Color.argb(220, 124, 58, 237) // ungu
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(200, 124, 58, 237)
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = max(12f, 11f * scaleX)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val maxDraw = min(boxes.length(), 40)
        for (i in 0 until maxDraw) {
            val item = boxes.optJSONObject(i) ?: continue
            val x = (item.optDouble("x", 0.0) * scaleX).toFloat()
            val y = (item.optDouble("y", 0.0) * scaleY).toFloat()
            val w = (item.optDouble("w", 0.0) * scaleX).toFloat()
            val h = (item.optDouble("h", 0.0) * scaleY).toFloat()
            if (w < 2f || h < 2f) continue
            canvas.drawRect(x, y, x + w, y + h, stroke)
            val label = item.optInt("index", i).toString()
            val tw = textPaint.measureText(label)
            val th = textPaint.textSize
            val pad = 3f * scaleX
            val lx = x
            val ly = max(0f, y - th - pad)
            canvas.drawRect(lx, ly, lx + tw + pad * 2, ly + th + pad, fill)
            canvas.drawText(label, lx + pad, ly + th, textPaint)
        }
    }

    private fun saveScreenshotFile(
        view: WebView,
        bitmap: Bitmap,
        originalScrollX: Int,
        originalScrollY: Int,
        documentWidthCss: Int,
        documentHeightCss: Int,
        result: MethodChannel.Result,
        annotated: Boolean,
    ) {
        try {
            val directory = File(activity.filesDir, "browser-captures")
            if (!directory.exists() && !directory.mkdirs()) {
                throw IllegalStateException("Folder screenshot tidak dapat dibuat.")
            }
            val file = File(directory, "web-${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                    throw IllegalStateException("Gagal mengekod screenshot browser.")
                }
            }
            result.success(
                mapOf(
                    "success" to true,
                    "path" to file.absolutePath,
                    "mime" to "image/png",
                    "width" to bitmap.width,
                    "height" to bitmap.height,
                    "documentWidth" to documentWidthCss,
                    "documentHeight" to documentHeightCss,
                    "fullPage" to true,
                    "annotated" to annotated,
                    "scaled" to (
                        bitmap.width != view.width ||
                            bitmap.height != max(view.height, documentHeightCss)
                        ),
                    "url" to (view.url ?: ""),
                    "title" to view.title.orEmpty(),
                ),
            )
        } catch (error: Throwable) {
            result.error("screenshot_error", error.message, null)
        } finally {
            bitmap.recycle()
            restoreBrowserViewport(view, originalScrollX, originalScrollY)
        }
    }

    /** Hentikan kerja browser yang sedang pending (bila agent dibatalkan). */
    private fun cancelPendingWork(result: MethodChannel.Result) {
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = null
        if (pendingResult != null && pendingDone.compareAndSet(false, true)) {
            safeError(pendingResult, "cancelled", "Browser dihentikan kerana agent dibatalkan.")
        }
        pendingResult = null
        pendingDone.set(true)
        pendingGen += 1
        for (tab in tabs.values) {
            try {
                tab.webView.stopLoading()
                silenceMedia(tab.webView)
            } catch (_: Throwable) {
            }
        }
        result.success(mapOf("success" to true, "cancelled" to true))
    }

    private fun restoreBrowserViewport(view: WebView, scrollX: Int, scrollY: Int) {
        view.scrollTo(scrollX, scrollY)
        silenceMedia(view)
    }

    private fun evaluateAction(
        script: String,
        result: MethodChannel.Result,
        waitAfterMs: Long,
    ) {
        val view = activeWebView()
        view.evaluateJavascript(script) { raw ->
            try {
                val actionResult = decodeJavascriptObject(raw)
                if (actionResult.optBoolean("success", false)) {
                    if (!beginPending(result, 60_000L)) return@evaluateJavascript
                    val gen = pendingGen
                    mainHandler.postDelayed({ snapshotPending(gen) }, waitAfterMs)
                } else {
                    result.success(jsonObjectToMap(actionResult))
                }
            } catch (error: Throwable) {
                result.error("javascript_error", error.message, null)
            }
        }
    }

    /**
     * Mula operasi async tunggal. Jika masih ada pending:
     * **tolak request BARU sahaja** — jangan finishError pending lama (bug lama).
     * @return false jika sibuk (caller mesti return terus).
     */
    private fun beginPending(result: MethodChannel.Result, timeoutMs: Long): Boolean {
        // pendingResult ialah sumber kebenaran. Walaupun callback lama sudah
        // menukar pendingDone, jangan benarkan result baharu mengambil slot
        // sebelum clearPending benar-benar selesai.
        if (pendingResult != null) {
            result.error(
                "browser_busy",
                "Browser sedang menyelesaikan tindakan sebelumnya. Tunggu, atau jangan parallel browser tools.",
                null,
            )
            return false
        }
        pendingGen += 1
        pendingResult = result
        pendingDone.set(false)
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        val gen = pendingGen
        timeoutRunnable = Runnable {
            finishError("browser_timeout", "Browser latar belakang melebihi had masa.", gen)
        }.also { mainHandler.postDelayed(it, timeoutMs) }
        return true
    }

    private fun snapshotPending(expectedGen: Int = pendingGen) {
        if (expectedGen != pendingGen) return
        val result = pendingResult ?: return
        val view = try {
            activeWebView()
        } catch (_: Throwable) {
            finishError("browser_missing", "Enjin browser belum tersedia.", expectedGen)
            return
        }
        silenceMedia(view)
        view.evaluateJavascript(SNAPSHOT_SCRIPT) { raw ->
            if (expectedGen != pendingGen) return@evaluateJavascript
            if (!pendingDone.compareAndSet(false, true)) return@evaluateJavascript
            try {
                val objectValue = decodeJavascriptObject(raw)
                val map = jsonObjectToMap(objectValue).toMutableMap()
                map["success"] = true
                map["engine"] = "android-system-webview-chromium"
                map["canGoBack"] = view.canGoBack()
                map["canGoForward"] = view.canGoForward()
                map["desktopMode"] = desktopMode
                map["activeTabId"] = activeTabId
                map["tabCount"] = tabs.size
                map["maxTabs"] = maxTabs
                map["tabs"] = tabSummaryList()
                clearPending()
                safeSuccess(result, map)
            } catch (error: Throwable) {
                clearPending()
                safeError(result, "snapshot_error", error.message)
            }
        }
    }

    private fun finishError(code: String, message: String, expectedGen: Int = pendingGen) {
        if (expectedGen != pendingGen) return
        val result = pendingResult ?: return
        if (!pendingDone.compareAndSet(false, true)) return
        clearPending()
        safeError(result, code, message)
    }

    private fun clearPending() {
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = null
        pendingResult = null
        pendingDone.set(true)
    }

    private fun safeSuccess(result: MethodChannel.Result?, payload: Any?) {
        if (result == null) return
        try {
            result.success(payload)
        } catch (_: Throwable) {
        }
    }

    private fun safeError(result: MethodChannel.Result?, code: String, message: String?) {
        if (result == null) return
        try {
            result.error(code, message, null)
        } catch (_: Throwable) {
        }
    }

    private fun decodeJavascriptObject(raw: String?): JSONObject {
        if (raw.isNullOrBlank() || raw == "null") return JSONObject()
        val first = JSONTokener(raw).nextValue()
        val jsonText = when (first) {
            is String -> first
            is JSONObject -> return first
            else -> first.toString()
        }
        return JSONObject(jsonText)
    }

    private fun jsonObjectToMap(value: JSONObject): Map<String, Any?> {
        val output = mutableMapOf<String, Any?>()
        val keys = value.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            output[key] = jsonValue(value.opt(key))
        }
        return output
    }

    private fun jsonValue(value: Any?): Any? = when (value) {
        null, JSONObject.NULL -> null
        is JSONObject -> jsonObjectToMap(value)
        is JSONArray -> (0 until value.length()).map { jsonValue(value.opt(it)) }
        else -> value
    }

    fun silenceMedia() {
        activity.runOnUiThread {
            for (tab in tabs.values) {
                silenceMedia(tab.webView)
            }
        }
    }

    private fun silenceMedia(view: WebView) {
        try {
            view.evaluateJavascript(MUTE_MEDIA_SCRIPT, null)
        } catch (_: Throwable) {
            // Halaman mungkin belum mempunyai konteks JavaScript. Percubaan seterusnya
            // dibuat pada onPageFinished dan sebelum setiap snapshot/screenshot.
        }
    }

    fun destroy() {
        cancelPendingWork(
            object : MethodChannel.Result {
                override fun success(result: Any?) {}
                override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {}
                override fun notImplemented() {}
            },
        )
        val all = tabs.values.toList()
        tabs.clear()
        activeTabId = 0
        for (tab in all) {
            destroyWebView(tab.webView)
        }
    }

    private fun desktopUserAgent(): String =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/138 Safari/537.36 AiMultiAgent/1.0.0"

    private fun mobileUserAgent(): String =
        "Mozilla/5.0 (Linux; Android ${android.os.Build.VERSION.RELEASE}; ${android.os.Build.MODEL}) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138 Mobile Safari/537.36 AiMultiAgent/1.0.0"

    companion object {
        private val MUTE_MEDIA_SCRIPT = """
            (() => {
              const silence = (node) => {
                if (!node) return;
                try { node.muted = true; } catch (_) {}
                try { node.volume = 0; } catch (_) {}
                try { node.autoplay = false; } catch (_) {}
                try { node.removeAttribute('autoplay'); } catch (_) {}
              };

              const mediaPrototype = window.HTMLMediaElement && window.HTMLMediaElement.prototype;
              if (mediaPrototype && !mediaPrototype.__aiMultiAgentSilentPlay) {
                const originalPlay = mediaPrototype.play;
                Object.defineProperty(mediaPrototype, '__aiMultiAgentSilentPlay', {value:true});
                mediaPrototype.play = function(...args) {
                  silence(this);
                  return originalPlay.apply(this, args);
                };
              }

              if (!window.__aiMultiAgentAudioContexts) {
                window.__aiMultiAgentAudioContexts = [];
                for (const key of ['AudioContext', 'webkitAudioContext']) {
                  const NativeContext = window[key];
                  if (!NativeContext || NativeContext.__aiMultiAgentWrapped) continue;
                  const SilentContext = function(...args) {
                    const context = new NativeContext(...args);
                    window.__aiMultiAgentAudioContexts.push(context);
                    try { context.suspend(); } catch (_) {}
                    if (context.resume) {
                      context.resume = () => Promise.resolve(context.suspend()).then(() => context);
                    }
                    return context;
                  };
                  SilentContext.prototype = NativeContext.prototype;
                  Object.setPrototypeOf(SilentContext, NativeContext);
                  Object.defineProperty(SilentContext, '__aiMultiAgentWrapped', {value:true});
                  try { window[key] = SilentContext; } catch (_) {}
                }
              }

              const silenceAll = () => {
                document.querySelectorAll('video,audio').forEach(silence);
                for (const context of window.__aiMultiAgentAudioContexts || []) {
                  try { context.suspend(); } catch (_) {}
                }
              };
              silenceAll();

              if (!window.__aiMultiAgentMediaSilencer && document.documentElement) {
                window.__aiMultiAgentMediaSilencer = new MutationObserver((records) => {
                  for (const record of records) {
                    for (const node of record.addedNodes || []) {
                      if (!node || node.nodeType !== 1) continue;
                      if (node.matches && node.matches('video,audio')) silence(node);
                      if (node.querySelectorAll) node.querySelectorAll('video,audio').forEach(silence);
                    }
                  }
                });
                window.__aiMultiAgentMediaSilencer.observe(
                  document.documentElement,
                  {childList:true,subtree:true}
                );
                document.addEventListener('play', (event) => silence(event.target), true);
                document.addEventListener('volumechange', (event) => silence(event.target), true);
              }
              return true;
            })();
        """.trimIndent()

        private val FULL_PAGE_SIZE_SCRIPT = """
            (() => {
              const root = document.documentElement;
              const body = document.body;
              const width = Math.max(
                root ? root.scrollWidth : 0,
                root ? root.offsetWidth : 0,
                body ? body.scrollWidth : 0,
                body ? body.offsetWidth : 0,
                window.innerWidth || 0
              );
              const height = Math.max(
                root ? root.scrollHeight : 0,
                root ? root.offsetHeight : 0,
                body ? body.scrollHeight : 0,
                body ? body.offsetHeight : 0,
                window.innerHeight || 0
              );
              return JSON.stringify({
                width,
                height,
                viewportWidth: window.innerWidth || width,
                viewportHeight: window.innerHeight || height
              });
            })();
        """.trimIndent()

        /**
         * Selector elemen interaktif.
         *
         * Versi lama hanya melihat elemen native + beberapa role. Komponen React
         * tersuai (Radix, Headless UI, MUI, react-select) merender dropdown
         * sebagai div dengan role="combobox"/"listbox" dan bukan <select>, jadi
         * ia langsung tidak dikumpul — sebab itu "elemen tidak ditemui".
         */
        private const val INTERACTIVE_SELECTOR =
            "a[href],button,input,textarea,select,summary,label[for]," +
                "[role=\"button\"],[role=\"link\"],[role=\"textbox\"],[role=\"searchbox\"]," +
                "[role=\"checkbox\"],[role=\"radio\"],[role=\"switch\"]," +
                "[role=\"menuitem\"],[role=\"menuitemradio\"],[role=\"menuitemcheckbox\"]," +
                "[role=\"combobox\"],[role=\"listbox\"],[role=\"tab\"]," +
                "[role=\"spinbutton\"],[role=\"slider\"],[role=\"treeitem\"]," +
                "[contenteditable=\"true\"],[aria-haspopup],[tabindex]:not([tabindex=\"-1\"])"

        /** Selector khusus pilihan dropdown (dipisahkan supaya tidak membanjiri snapshot). */
        private const val OPTION_SELECTOR =
            "[role=\"option\"],[role=\"menuitem\"],[role=\"menuitemradio\"]," +
                "[role=\"treeitem\"],[role=\"tab\"],option,li"

        /**
         * Pustaka JS kongsi yang disuntik sebelum setiap skrip tindakan.
         *
         * Menyelesaikan tiga sebab utama komponen React tak boleh diinteraksi:
         *   1. element.click() sahaja — banyak widget bertindak pada
         *      pointerdown/mousedown, bukan click. realClick() hantar
         *      keseluruhan urutan pointer + mouse dengan koordinat sebenar.
         *   2. element.value = x — React controlled input mengabaikannya.
         *      setNativeValue() guna setter prototaip supaya React nampak.
         *   3. querySelectorAll tidak menembusi shadow DOM. deepAll() menyusur
         *      setiap shadowRoot terbuka.
         */
        private const val CLAW_JS = """
            const CLAW = (function () {
              const clean = function (v) { return (v || '').replace(/\s+/g, ' ').trim(); };

              const deepAll = function (sel) {
                const out = [];
                const seen = [];
                const walk = function (root) {
                  if (!root || seen.indexOf(root) !== -1) return;
                  seen.push(root);
                  let list = [];
                  try { list = root.querySelectorAll(sel); } catch (e) { list = []; }
                  for (let i = 0; i < list.length; i++) out.push(list[i]);
                  let all = [];
                  try { all = root.querySelectorAll('*'); } catch (e) { all = []; }
                  for (let j = 0; j < all.length; j++) {
                    if (all[j].shadowRoot) walk(all[j].shadowRoot);
                  }
                };
                walk(document);
                return out;
              };

              const isVisible = function (node) {
                if (!node || !node.getBoundingClientRect) return false;
                let style;
                try { style = window.getComputedStyle(node); } catch (e) { return false; }
                if (!style) return false;
                if (style.display === 'none') return false;
                if (style.visibility === 'hidden') return false;
                if (style.opacity === '0') return false;
                const rect = node.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
              };

              const labelOf = function (node) {
                let text = '';
                try {
                  text = node.getAttribute('aria-label') ||
                    (node.labels && node.labels[0] ? node.labels[0].innerText : '') ||
                    node.innerText || node.value ||
                    node.getAttribute('placeholder') || node.getAttribute('title') ||
                    node.getAttribute('name') || node.id || '';
                } catch (e) { text = ''; }
                return clean(text).toLowerCase();
              };

              const collect = function () { return deepAll(CLAW_SELECTOR).filter(isVisible); };

              const fire = function (el, type, init) {
                let ev = null;
                const Pointer = window.PointerEvent;
                try {
                  if (Pointer && type.indexOf('pointer') === 0) {
                    ev = new Pointer(type, init);
                  } else {
                    ev = new MouseEvent(type, init);
                  }
                } catch (e) {
                  try { ev = new MouseEvent(type, init); } catch (e2) { return; }
                }
                try { el.dispatchEvent(ev); } catch (e) { }
              };

              /* Urutan penuh seperti jari sebenar. Radix/MUI buka pada
                 pointerdown, react-select pada mousedown. */
              const realClick = function (el) {
                try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { }
                const r = el.getBoundingClientRect();
                const cx = Math.round(r.left + r.width / 2);
                const cy = Math.round(r.top + r.height / 2);
                const base = {
                  bubbles: true, cancelable: true, composed: true, view: window,
                  clientX: cx, clientY: cy, screenX: cx, screenY: cy,
                  detail: 1, button: 0
                };
                const hover = Object.assign({}, base, {
                  buttons: 0, pointerId: 1, pointerType: 'mouse', isPrimary: true
                });
                const down = Object.assign({}, base, {
                  buttons: 1, pointerId: 1, pointerType: 'mouse', isPrimary: true
                });
                fire(el, 'pointerover', hover);
                fire(el, 'pointerenter', hover);
                fire(el, 'mouseover', Object.assign({}, base, { buttons: 0 }));
                fire(el, 'mousemove', Object.assign({}, base, { buttons: 0 }));
                fire(el, 'pointerdown', down);
                fire(el, 'mousedown', Object.assign({}, base, { buttons: 1 }));
                try { el.focus({ preventScroll: true }); } catch (e) {
                  try { el.focus(); } catch (e2) { }
                }
                fire(el, 'pointerup', hover);
                fire(el, 'mouseup', Object.assign({}, base, { buttons: 0 }));
                fire(el, 'click', Object.assign({}, base, { buttons: 0 }));
                return true;
              };

              /* React memintas setter value. Guna setter prototaip supaya
                 state React benar-benar dikemas kini. */
              const setNativeValue = function (el, value) {
                let proto = null;
                if (window.HTMLTextAreaElement && el instanceof window.HTMLTextAreaElement) {
                  proto = window.HTMLTextAreaElement.prototype;
                } else if (window.HTMLSelectElement && el instanceof window.HTMLSelectElement) {
                  proto = window.HTMLSelectElement.prototype;
                } else if (window.HTMLInputElement) {
                  proto = window.HTMLInputElement.prototype;
                }
                let desc = null;
                if (proto) {
                  try { desc = Object.getOwnPropertyDescriptor(proto, 'value'); } catch (e) { }
                }
                if (desc && desc.set) { desc.set.call(el, value); } else { el.value = value; }
              };

              const notify = function (el) {
                try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { }
                try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) { }
              };

              const KEYMAP = {
                Enter: 13, Tab: 9, Escape: 27, Backspace: 8, Delete: 46, ' ': 32,
                ArrowDown: 40, ArrowUp: 38, ArrowLeft: 37, ArrowRight: 39,
                Home: 36, End: 35, PageUp: 33, PageDown: 34
              };

              const pressKey = function (el, k) {
                const code = KEYMAP[k] || (k.length === 1 ? k.toUpperCase().charCodeAt(0) : 0);
                const name = k.length === 1
                  ? (/[a-z]/i.test(k) ? 'Key' + k.toUpperCase() : 'Digit' + k)
                  : k;
                const init = {
                  bubbles: true, cancelable: true, composed: true,
                  key: k, code: name, keyCode: code, which: code
                };
                try { el.dispatchEvent(new KeyboardEvent('keydown', init)); } catch (e) { }
                if (k.length === 1) {
                  try { el.dispatchEvent(new KeyboardEvent('keypress', init)); } catch (e) { }
                }
                try { el.dispatchEvent(new KeyboardEvent('keyup', init)); } catch (e) { }
              };

              /* Menaip aksara demi aksara. Wajib untuk input bertopeng
                 (cth. DD/MM/YYYY) yang menolak set value terus. */
              const typeText = function (el, text) {
                try { el.focus({ preventScroll: true }); } catch (e) {
                  try { el.focus(); } catch (e2) { }
                }
                for (let i = 0; i < text.length; i++) {
                  const ch = text[i];
                  const current = (el.value || '') + ch;
                  setNativeValue(el, current);
                  pressKey(el, ch);
                  try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { }
                }
                notify(el);
              };

              const matchOption = function (nodes, wanted) {
                const target = clean(wanted).toLowerCase();
                if (!target) return null;
                let exact = null;
                let starts = null;
                let loose = null;
                for (let i = 0; i < nodes.length; i++) {
                  const t = clean(nodes[i].innerText || nodes[i].textContent || '').toLowerCase();
                  const v = clean(nodes[i].getAttribute ? (nodes[i].getAttribute('data-value') || nodes[i].value || '') : '').toLowerCase();
                  if (t === target || v === target) { exact = nodes[i]; break; }
                  if (!starts && (t.indexOf(target) === 0 || v.indexOf(target) === 0)) starts = nodes[i];
                  if (!loose && t.indexOf(target) !== -1) loose = nodes[i];
                }
                return exact || starts || loose;
              };

              /* Cari elemen mengikut keutamaan: index → label teks → selector. */
              const resolve = function (index, text, selector) {
                const nodes = collect();
                if (index !== null && index !== undefined && !Number.isNaN(index) && nodes[index]) {
                  return { el: nodes[index], strategy: 'index', total: nodes.length };
                }
                const wanted = clean(text || '').toLowerCase();
                if (wanted) {
                  for (let i = 0; i < nodes.length; i++) {
                    if (labelOf(nodes[i]).indexOf(wanted) !== -1) {
                      return { el: nodes[i], strategy: 'text', total: nodes.length };
                    }
                  }
                }
                if (selector) {
                  const hit = deepAll(selector)[0];
                  if (hit) return { el: hit, strategy: 'selector', total: nodes.length };
                }
                return { el: null, strategy: '', total: nodes.length };
              };

              return {
                clean: clean, deepAll: deepAll, isVisible: isVisible, labelOf: labelOf,
                collect: collect, realClick: realClick, setNativeValue: setNativeValue,
                notify: notify, pressKey: pressKey, typeText: typeText,
                matchOption: matchOption, resolve: resolve
              };
            })();
        """

        /** Prelude lengkap: pemalar selector + pustaka CLAW. */
        private val CLAW_PRELUDE: String =
            "const CLAW_SELECTOR = " + JSONObject.quote(INTERACTIVE_SELECTOR) + ";\n" +
                "const CLAW_OPTION_SELECTOR = " + JSONObject.quote(OPTION_SELECTOR) + ";\n" +
                CLAW_JS

        /** Koordinat absolut page untuk lukisan kotak pada full-page screenshot. */
        private val ANNOTATE_ELEMENTS_SCRIPT = """
            (() => {
              const isVisible = (node) => {
                const style = window.getComputedStyle(node);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                const rect = node.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
              };
              const sel = 'a[href],button,input,textarea,select,[role="button"],[role="link"],[role="textbox"],[role="checkbox"],[role="radio"],[role="menuitem"],[contenteditable="true"]';
              const sx = window.scrollX || window.pageXOffset || 0;
              const sy = window.scrollY || window.pageYOffset || 0;
              const elements = Array.from(document.querySelectorAll(sel))
                .filter(isVisible)
                .slice(0, 40)
                .map((node, index) => {
                  const r = node.getBoundingClientRect();
                  return {
                    index,
                    x: r.left + sx,
                    y: r.top + sy,
                    w: r.width,
                    h: r.height
                  };
                });
              return JSON.stringify({ elements });
            })();
        """.trimIndent()

        private val SNAPSHOT_SCRIPT = """
            (() => {
              $CLAW_PRELUDE
              const clean = (value) => (value || '').replace(/\s+/g, ' ').trim();
              const isVisible = (node) => {
                const style = window.getComputedStyle(node);
                if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
                const rect = node.getBoundingClientRect();
                return rect.width > 0 && rect.height > 0;
              };
              const interactiveSelector = CLAW_SELECTOR;
              const interactive = CLAW.deepAll(interactiveSelector)
                .filter(isVisible)
                .slice(0, 150)
                .map((node, index) => {
                  const tag = (node.tagName || '').toLowerCase();
                  const type = (node.getAttribute('type') || node.type || '').toLowerCase();
                  const role = node.getAttribute('role') || '';
                  const popup = node.getAttribute('aria-haspopup') || '';
                  const expanded = node.getAttribute('aria-expanded');
                  const rect = node.getBoundingClientRect();
                  const label = clean(
                    node.getAttribute('aria-label') ||
                    node.getAttribute('title') ||
                    (node.labels && node.labels[0] ? node.labels[0].innerText : '') ||
                    node.innerText ||
                    node.value ||
                    node.getAttribute('placeholder') ||
                    node.getAttribute('name') ||
                    node.id ||
                    ''
                  ).slice(0, 120);
                  const item = {
                    index,
                    tag,
                    type: type || role || tag,
                    text: label,
                    name: node.getAttribute('name') || '',
                    id: node.id || '',
                    placeholder: node.getAttribute('placeholder') || '',
                    href: node.href || '',
                    value: type === 'password' ? '[REDACTED]' : clean(node.value || '').slice(0, 80),
                    checked: !!(node.checked),
                    disabled: !!(node.disabled),
                    role: role,
                    haspopup: popup,
                    expanded: expanded === null ? '' : expanded,
                    /* widget=true bermakna komponen tersuai (bukan <select>) —
                       guna browser_select_option, bukan browser_fill. */
                    widget: tag !== 'select' && tag !== 'input' && tag !== 'textarea' &&
                      (role === 'combobox' || role === 'listbox' ||
                       popup === 'listbox' || popup === 'menu' || popup === 'true'),
                    bbox: {
                      x: Math.round(rect.x),
                      y: Math.round(rect.y),
                      width: Math.round(rect.width),
                      height: Math.round(rect.height)
                    }
                  };
                  return item;
                });
              const links = Array.from(document.querySelectorAll('a[href]')).slice(0, 80).map((node, index) => ({
                index,
                text: clean(node.innerText || node.getAttribute('aria-label') || ''),
                url: node.href || ''
              })).filter((item) => item.url);
              const forms = Array.from(document.forms).slice(0, 15).map((form, index) => ({
                index,
                id: form.id || '',
                name: form.name || '',
                action: form.action || location.href,
                method: (form.method || 'get').toUpperCase(),
                fields: Array.from(form.elements).slice(0, 30).map((field) => ({
                  tag: field.tagName ? field.tagName.toLowerCase() : '',
                  type: field.type || '',
                  name: field.name || '',
                  id: field.id || '',
                  placeholder: field.placeholder || '',
                  value: field.type === 'password' ? '[REDACTED]' : (field.value || '')
                }))
              }));
              const text = clean(document.body ? document.body.innerText : '').slice(0, 32000);
              const html = (document.documentElement ? document.documentElement.outerHTML : '').slice(0, 80000);
              return JSON.stringify({
                url: location.href,
                title: document.title || '',
                text,
                html,
                interactive_elements: interactive,
                links,
                forms
              });
            })();
        """.trimIndent()
    }
}
