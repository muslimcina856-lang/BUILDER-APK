import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../config/app_config.dart';
import 'linux_workspace_service.dart';

class WindowsRuntimeStatus {
  const WindowsRuntimeStatus({
    required this.rootPath,
    required this.rootfsReady,
    required this.box64Ready,
    required this.wineReady,
    required this.prefixReady,
    required this.manifestValid,
    required this.usedBytes,
    required this.runtimeVersion,
    required this.box64Version,
    required this.wineVersion,
    required this.healthStatus,
  });

  final String rootPath;
  final bool rootfsReady;
  final bool box64Ready;
  final bool wineReady;
  final bool prefixReady;
  final bool manifestValid;
  final int usedBytes;
  final String runtimeVersion;
  final String box64Version;
  final String wineVersion;
  final String healthStatus;

  bool get ready =>
      rootfsReady && box64Ready && wineReady && prefixReady && manifestValid;
}

class WindowsExecutablePath {
  const WindowsExecutablePath({required this.hostPath, required this.guestPath});

  final String hostPath;
  final String guestPath;
}

/// Kemajuan pemasangan PC Windows (untuk progress bar sebenar di UI).
class WindowsInstallProgress {
  const WindowsInstallProgress({
    required this.stage,
    required this.progress,
    this.detail = '',
    this.bytesReceived,
    this.bytesTotal,
  });

  /// 0.0 – 1.0 keseluruhan.
  final double progress;
  final String stage;
  final String detail;
  final int? bytesReceived;
  final int? bytesTotal;

  String get percentLabel {
    final pct = (progress.clamp(0.0, 1.0) * 100).round();
    return '$pct%';
  }

  String get bytesLabel {
    if (bytesReceived == null) return '';
    final recv = _fmtBytes(bytesReceived!);
    if (bytesTotal != null && bytesTotal! > 0) {
      return '$recv / ${_fmtBytes(bytesTotal!)}';
    }
    return recv;
  }

  static String _fmtBytes(int bytes) {
    if (bytes >= 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    return '$bytes B';
  }
}

/// Runtime Windows-compatible tempatan untuk Ai MultiAgent Full.
///
/// Ini bukan VM/kernel Windows penuh. Ia menggunakan Ubuntu ARM64 sebagai
/// userspace, Box64 untuk x86_64 dan Wine WoW64 untuk aplikasi Windows x86/x64.
/// Runtime dimuat turun sekali pada penggunaan pertama dan disimpan berasingan
/// daripada Shell Alpine supaya reset Shell tidak memadam PC Windows.
class WindowsRuntimeService {
  factory WindowsRuntimeService() => _instance;
  WindowsRuntimeService._();

  static final WindowsRuntimeService _instance = WindowsRuntimeService._();

  static const String expectedRuntimeVersion =
      '1.1.0-ubuntu-24.04.4-box64-0.4.4-wine-11.11-wow64';
  static const String expectedDistribution = 'Ubuntu Base';
  static const String expectedDistributionVersion = '24.04.4';
  static const String expectedArchitecture = 'aarch64';
  static const String expectedWineVersion = '11.11';
  static const String expectedBox64Version = '0.4.4';
  static const String _box64Commit =
      '2f130fab1d6e1a4ee8a71dc60cfdfcc839ad192a';
  static const String displayName = ':99';
  static const int desktopWidth = 1280;
  static const int desktopHeight = 720;

  static const String _ubuntuBaseUrl =
      'https://cdimage.ubuntu.com/ubuntu-base/releases/noble/release/ubuntu-base-24.04.4-base-arm64.tar.gz';
  static const String _ubuntuBaseSha256 =
      '04207713ece899c3740823d33690441ad3a7f0ded1101aca744e2b0f37ac7ff2';
  static const String _wineUrl =
      'https://github.com/Kron4ek/Wine-Builds/releases/download/11.11/wine-11.11-staging-tkg-amd64-wow64.tar.xz';
  static const String _wineSha256 =
      '44f5330be22424c51d2b48ddc60dc4e1fca686628cedd9e76cd2b041a4aeb3d9';
  static const int _maxUbuntuBaseDownloadBytes = 96 * 1024 * 1024;
  static const int _maxWineDownloadBytes = 200 * 1024 * 1024;

  static Future<WindowsRuntimeStatus>? _installInFlight;

  /// UI boleh listen untuk progress bar sebenar semasa install.
  final ValueNotifier<WindowsInstallProgress?> installProgress =
      ValueNotifier<WindowsInstallProgress?>(null);

  void _reportProgress({
    required String stage,
    required double progress,
    String detail = '',
    int? bytesReceived,
    int? bytesTotal,
  }) {
    installProgress.value = WindowsInstallProgress(
      stage: stage,
      progress: progress.clamp(0.0, 1.0),
      detail: detail,
      bytesReceived: bytesReceived,
      bytesTotal: bytesTotal,
    );
  }

  Future<Directory> ensurePrivateRoot() async {
    if (!AppConfig.isFullEdition) {
      throw const FileSystemException(
        'PC Windows local hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    final support = await getApplicationSupportDirectory();
    _assertPrivateAppPath(support.path);
    final root = Directory(p.join(support.path, 'windows'));
    await root.create(recursive: true);
    for (final child in <String>['home', 'tmp', 'runtime', 'cache']) {
      await Directory(p.join(root.path, child)).create(recursive: true);
    }
    return root;
  }

  Future<WindowsRuntimeStatus> status({bool includeSize = true}) async {
    if (!AppConfig.isFullEdition) {
      return const WindowsRuntimeStatus(
        rootPath: '',
        rootfsReady: false,
        box64Ready: false,
        wineReady: false,
        prefixReady: false,
        manifestValid: false,
        usedBytes: 0,
        runtimeVersion: '',
        box64Version: '',
        wineVersion: '',
        healthStatus: 'unavailable_in_standard',
      );
    }
    final root = await ensurePrivateRoot();
    final rootfs = Directory(p.join(root.path, 'rootfs'));
    final rootfsReady = _isFileOrLink(p.join(rootfs.path, 'bin/sh'));
    final box64Ready =
        _isFileOrLink(p.join(rootfs.path, 'usr/local/bin/box64')) ||
            _isFileOrLink(p.join(rootfs.path, 'usr/bin/box64'));
    final wineReady = _isFileOrLink(p.join(rootfs.path, 'opt/wine/bin/wine'));
    final prefixReady =
        _isFileOrLink(p.join(root.path, 'home/.wine/system.reg'));
    final manifest = await _readManifest(root);
    final manifestValid = _manifestIsValid(manifest);
    return WindowsRuntimeStatus(
      rootPath: root.path,
      rootfsReady: rootfsReady,
      box64Ready: box64Ready,
      wineReady: wineReady,
      prefixReady: prefixReady,
      manifestValid: manifestValid,
      usedBytes: includeSize
          ? await _directorySize(root).catchError((_) => 0)
          : 0,
      runtimeVersion: manifest?['runtime_version']?.toString() ?? '',
      box64Version: manifest?['box64_version']?.toString() ?? '',
      wineVersion: manifest?['wine_version']?.toString() ?? '',
      healthStatus: manifest?['health_status']?.toString() ?? 'not_installed',
    );
  }

  Future<WindowsRuntimeStatus> ensureReady() {
    if (!AppConfig.isFullEdition) return status();
    final existing = _installInFlight;
    if (existing != null) return existing;
    final operation = _ensureReadyInternal();
    _installInFlight = operation;
    return operation.whenComplete(() {
      if (identical(_installInFlight, operation)) _installInFlight = null;
      // Biarkan UI nampak 100% sekejap, kemudian clear.
      Future<void>.delayed(const Duration(milliseconds: 600), () {
        if (_installInFlight == null) installProgress.value = null;
      });
    });
  }

  Future<WindowsRuntimeStatus> _ensureReadyInternal() async {
    var current = await status();
    if (current.ready && current.runtimeVersion == expectedRuntimeVersion) {
      _reportProgress(stage: 'Sedia', progress: 1.0, detail: 'Runtime Windows siap');
      return current;
    }

    _reportProgress(
      stage: 'Menyemak Shell',
      progress: 0.02,
      detail: 'Memastikan Alpine + PRoot sedia…',
    );
    final linux = await LinuxWorkspaceService().ensureBundledRuntimeReady();
    if (!linux.ready) {
      throw const FileSystemException(
        'Shell Alpine perlu tersedia sebelum PC Windows boleh disediakan.',
      );
    }

    final root = await ensurePrivateRoot();
    final manifest = await _readManifest(root);
    final rootfs = Directory(p.join(root.path, 'rootfs'));
    final structuralRootfs = _isFileOrLink(p.join(rootfs.path, 'bin/sh'));
    final versionMatches = _manifestIsValid(manifest);

    if (!structuralRootfs || !versionMatches) {
      await _bootstrapUbuntuRootfs(root, linux.rootPath);
    } else {
      _reportProgress(
        stage: 'Rootfs sedia',
        progress: 0.42,
        detail: 'Ubuntu Base sudah wujud, melangkau muat turun…',
      );
    }

    await _configureCompatibilityLayer(root, linux.rootPath);
    _reportProgress(
      stage: 'Pemeriksaan kesihatan',
      progress: 0.92,
      detail: 'Mengesahkan Wine + Box64…',
    );
    current = await status();
    if (!current.ready) {
      throw const FileSystemException(
        'PC Windows belum melepasi pemeriksaan kesihatan selepas pemasangan.',
      );
    }
    _reportProgress(
      stage: 'Selesai',
      progress: 1.0,
      detail: 'PC Windows sedia digunakan',
    );
    return current;
  }

  Future<void> _bootstrapUbuntuRootfs(
    Directory windowsRoot,
    String linuxRootPath,
  ) async {
    final linux = LinuxWorkspaceService();
    final bootstrapHost = Directory(
      p.join(linuxRootPath, 'home', '.ai-windows-bootstrap'),
    );
    if (await bootstrapHost.exists()) {
      await bootstrapHost.delete(recursive: true);
    }
    await bootstrapHost.create(recursive: true);

    final ubuntuArchive = File(
      p.join(bootstrapHost.path, 'ubuntu-base.tar.gz'),
    );
    _reportProgress(
      stage: 'Muat turun Ubuntu Base',
      progress: 0.05,
      detail: 'Memulakan muat turun rootfs…',
    );
    await _downloadFile(
      Uri.parse(_ubuntuBaseUrl),
      ubuntuArchive,
      maxBytes: _maxUbuntuBaseDownloadBytes,
      failureLabel: 'Muat turun Ubuntu Base gagal',
      progressStart: 0.05,
      progressEnd: 0.32,
      stageLabel: 'Muat turun Ubuntu Base',
    );
    _reportProgress(
      stage: 'Ekstrak Ubuntu Base',
      progress: 0.34,
      detail: 'Mengesahkan SHA-256 dan mengekstrak rootfs…',
    );

    // Jangan jalankan `apk add` untuk bootstrap Windows. Pada sesetengah
    // kernel Android/PRoot, trigger BusyBox semasa pemasangan pakej boleh
    // gagal dengan `fchdir: Function not implemented`. Runtime Alpine asal
    // sudah mempunyai /bin/busybox; guna applet terus untuk checksum/ekstrak.
    final command = '''
set -eu
BUSYBOX=/bin/busybox
"\$BUSYBOX" test -x "\$BUSYBOX"
"\$BUSYBOX" rm -rf /root/.ai-windows-bootstrap/rootfs
"\$BUSYBOX" mkdir -p /root/.ai-windows-bootstrap/rootfs
printf '%s  %s\\n' '${_ubuntuBaseSha256}' '/root/.ai-windows-bootstrap/ubuntu-base.tar.gz' \\
  | "\$BUSYBOX" sha256sum -c -
"\$BUSYBOX" tar -xzf /root/.ai-windows-bootstrap/ubuntu-base.tar.gz \\
  -C /root/.ai-windows-bootstrap/rootfs
"\$BUSYBOX" test -e /root/.ai-windows-bootstrap/rootfs/bin/sh
''';
    final spec = await linux.commandSpec(
      command: command,
      relativeWorkingDirectory: '.',
      autoInstallBundledRuntime: true,
    );
    if (spec == null) {
      throw const FileSystemException('Shell Alpine tidak tersedia.');
    }
    await _runChecked(
      spec,
      timeout: const Duration(minutes: 20),
      failureLabel: 'Muat turun Ubuntu Base gagal',
    );

    final stagedRootfs = Directory(p.join(bootstrapHost.path, 'rootfs'));
    if (!_isFileOrLink(p.join(stagedRootfs.path, 'bin/sh'))) {
      throw const FileSystemException(
        'Arkib Ubuntu Base tidak menghasilkan rootfs yang sah.',
      );
    }
    final target = Directory(p.join(windowsRoot.path, 'rootfs'));
    final previous = Directory(p.join(windowsRoot.path, 'rootfs.previous'));
    if (await previous.exists()) await previous.delete(recursive: true);
    if (await target.exists()) await target.rename(previous.path);
    try {
      await stagedRootfs.rename(target.path);
      if (await previous.exists()) await previous.delete(recursive: true);
    } catch (_) {
      if (await target.exists()) await target.delete(recursive: true);
      if (await previous.exists()) await previous.rename(target.path);
      rethrow;
    } finally {
      if (await bootstrapHost.exists()) {
        await bootstrapHost.delete(recursive: true);
      }
    }
    _reportProgress(
      stage: 'Ubuntu Base siap',
      progress: 0.42,
      detail: 'Rootfs dipasang. Seterusnya: Box64 + Wine…',
    );
  }

  Future<void> _configureCompatibilityLayer(
    Directory root,
    String linuxRootPath,
  ) async {
    _reportProgress(
      stage: 'Pasang pakej & Wine',
      progress: 0.45,
      detail:
          'apt + Box64 + Wine (boleh ambil beberapa minit, jangan tutup app)…',
    );
    // Tulis DNS IPv4 pada host supaya bind PRoot /etc/resolv.conf stabil.
    try {
      final dns = File(p.join(linuxRootPath, 'runtime/android-resolv.conf'));
      await dns.parent.create(recursive: true);
      await dns.writeAsString(
        'nameserver 1.1.1.1\n'
        'nameserver 8.8.8.8\n'
        'nameserver 9.9.9.9\n'
        'options timeout:2 attempts:3 single-request-reopen\n',
        flush: true,
      );
    } on Object {
      // Teruskan; skrip guest juga menulis resolv.conf.
    }
    // Progress lembut — jangan tulis semula detail live dari guest.
    var creep = 0.45;
    final creepTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      creep = (creep + 0.012).clamp(0.45, 0.86);
      final current = installProgress.value;
      final live = current?.detail ?? '';
      final keepLive = live.isNotEmpty &&
          !live.startsWith('Masih memasang') &&
          live != 'Pasang pakej & Wine';
      _reportProgress(
        stage: current?.stage ?? 'Pasang pakej & Wine',
        progress: creep,
        detail: keepLive
            ? live
            : 'Masih memasang… ${((creep - 0.45) / (0.86 - 0.45) * 100).round()}% fasa ini',
      );
    });
    final installCommand = '''
set +e
export DEBIAN_FRONTEND=noninteractive
export TZ=UTC
export NEEDRESTART_MODE=a
fail() { echo "FAIL: \$1"; exit 1; }


cat >/etc/resolv.conf <<'RESOLV'
nameserver 1.1.1.1
nameserver 8.8.8.8
nameserver 9.9.9.9
options timeout:2 attempts:3 single-request-reopen
RESOLV

mkdir -p /etc/apt/apt.conf.d
cat >/etc/apt/apt.conf.d/99ai-network <<'APTNET'
Acquire::ForceIPv4 "true";
Acquire::Retries "5";
Acquire::http::Timeout "30";
Acquire::https::Timeout "30";
DPkg::Options {
  "--force-confdef";
  "--force-confold";
};
APTNET

cat >/etc/apt/sources.list <<'SOURCES'
deb http://ports.ubuntu.com/ubuntu-ports noble main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports noble-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports noble-security main restricted universe multiverse
SOURCES
rm -f /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources 2>/dev/null || true

cat >/usr/sbin/policy-rc.d <<'POLICY'
#!/bin/sh
exit 101
POLICY
chmod 755 /usr/sbin/policy-rc.d

seed_timezone() {
  mkdir -p /etc
  echo 'UTC' >/etc/timezone
  if [ -e /usr/share/zoneinfo/Etc/UTC ]; then
    ln -sfn /usr/share/zoneinfo/Etc/UTC /etc/localtime
  elif [ -e /usr/share/zoneinfo/UTC ]; then
    ln -sfn /usr/share/zoneinfo/UTC /etc/localtime
  fi
}

# Satu kali sahaja — elak berulang "Purging tzdata" / "Unpacking tzdata".
fix_dpkg_once() {
  seed_timezone
  if DEBIAN_FRONTEND=noninteractive dpkg --configure -a; then
    return 0
  fi
  echo "dpkg configure gagal — baiki tzdata sekali…"
  seed_timezone
  DEBIAN_FRONTEND=noninteractive dpkg --configure -a --force-confdef --force-confold 2>/dev/null || true
  if ! DEBIAN_FRONTEND=noninteractive dpkg --configure -a 2>/dev/null; then
    DEBIAN_FRONTEND=noninteractive dpkg --remove --force-depends tzdata 2>/dev/null || true
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \\
      -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \\
      tzdata 2>/dev/null || true
    seed_timezone
    DEBIAN_FRONTEND=noninteractive dpkg --configure -a 2>/dev/null || true
  fi
  return 0
}

apt_retry() {
  n=0
  until "\$@"; do
    n=\$((n + 1))
    if [ "\$n" -ge 4 ]; then
      return 1
    fi
    echo "apt retry \$n/3…"
    seed_timezone
    DEBIAN_FRONTEND=noninteractive dpkg --configure -a 2>/dev/null || true
    sleep \$((n * 2))
  done
}

echo ">> fix dpkg sekali"
fix_dpkg_once
echo ">> apt update"
apt_retry apt-get update -o Acquire::ForceIPv4=true

echo ">> bersihkan apt lock / dpkg rosak"
rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive dpkg --configure -a 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive apt-get -y -f install \
  -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold || true
seed_timezone

echo ">> pasang tools asas (tanpa X dulu)"
if ! apt_retry apt-get install -y --no-install-recommends \
  -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \
  ca-certificates curl wget gnupg xz-utils tar procps; then
  echo "tools apt gagal — cuba fix + ulang"
  DEBIAN_FRONTEND=noninteractive apt-get -y -f install \
    -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold || true
  DEBIAN_FRONTEND=noninteractive dpkg --configure -a 2>/dev/null || true
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \
    ca-certificates curl wget gnupg xz-utils tar procps \
    || fail "apt install tools asas gagal"
fi
command -v curl >/dev/null || fail "curl tiada selepas apt"
command -v wget >/dev/null || fail "wget tiada selepas apt"
command -v gpg >/dev/null || command -v gpgv >/dev/null || fail "gpg/gnupg tiada selepas apt"

echo ">> pasang font X minimum"
DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
  -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \
  xfonts-encodings xfonts-utils 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive dpkg --configure -a --force-depends 2>/dev/null || true

echo ">> pasang Xvfb + scrot + xdotool"
if ! DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
  -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \
  xvfb scrot xdotool; then
  echo "Xvfb gagal — force fix broken + configure"
  DEBIAN_FRONTEND=noninteractive apt-get -y -f install \
    -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold || true
  DEBIAN_FRONTEND=noninteractive dpkg --configure -a --force-depends 2>/dev/null || true
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \
    xvfb scrot xdotool || true
fi
command -v Xvfb >/dev/null || echo "WARN: Xvfb tiada (screenshot mungkin gagal)"
command -v scrot >/dev/null || echo "WARN: scrot tiada"
command -v xdotool >/dev/null || echo "WARN: xdotool tiada"

echo ">> pasang Box64"
rm -f /etc/apt/sources.list.d/box64.list /etc/apt/sources.list.d/box64.sources
mkdir -p /usr/share/keyrings
if command -v gpg >/dev/null 2>&1; then
  wget -4 -qO- 'https://pi-apps-coders.github.io/box64-debs/KEY.gpg' \\
    | gpg --dearmor --batch --yes -o /usr/share/keyrings/box64-archive-keyring.gpg
else
  wget -4 -qO /usr/share/keyrings/box64-archive-keyring.gpg \\
    'https://pi-apps-coders.github.io/box64-debs/KEY.gpg'
fi
cat >/etc/apt/sources.list.d/box64.sources <<'BOX64'
Types: deb
URIs: https://Pi-Apps-Coders.github.io/box64-debs/debian
Suites: ./
Signed-By: /usr/share/keyrings/box64-archive-keyring.gpg
BOX64
apt_retry apt-get update -o Acquire::ForceIPv4=true
if ! apt_retry apt-get install -y --no-install-recommends \\
  -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \\
  box64-generic-arm; then
  DEBIAN_FRONTEND=noninteractive apt-get -y -f install || true
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends box64-generic-arm \
    || fail "apt install box64 gagal"
fi
command -v box64 >/dev/null || fail "box64 binary tiada"

echo ">> muat turun Wine Kron4ek"
rm -rf /opt/wine /opt/wine.staging
mkdir -p /opt/wine.staging /tmp/ai-windows
# Jangan padam wine.tar.xz.part — curl -C - akan resume (gaya Termux)
curl -4 -fL --retry 8 --retry-delay 2 --retry-all-errors \\
  --connect-timeout 30 --max-time 0 -C - \\
  -A 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36' \\
  --progress-bar \\
  -o /tmp/ai-windows/wine.tar.xz \\
  ${_shellQuote(_wineUrl)}
echo '${_wineSha256}  /tmp/ai-windows/wine.tar.xz' | sha256sum -c -
tar -xJf /tmp/ai-windows/wine.tar.xz -C /opt/wine.staging
WINE_BIN="\$(find /opt/wine.staging -type f -path '*/bin/wine' -print -quit)"
if [ -z "\$WINE_BIN" ]; then
  WINE_BIN="\$(find /opt/wine.staging -type l -path '*/bin/wine' -print -quit)"
fi
test -n "\$WINE_BIN"
WINE_HOME="\$(dirname "\$(dirname "\$WINE_BIN")")"
mv "\$WINE_HOME" /opt/wine
rm -rf /opt/wine.staging /tmp/ai-windows
command -v box64 >/dev/null || fail "box64 tiada selepas Wine"
test -x /opt/wine/bin/wine || fail "wine binary tiada di /opt/wine/bin/wine"
echo ">> Box64 + Wine OK"
''';
    try {
      await _runChecked(
        await commandSpec(
          command: installCommand,
          relativeWorkingDirectory: '.',
          requireReady: false,
          linuxRootPath: linuxRootPath,
        ),
        timeout: const Duration(minutes: 45),
        failureLabel: 'Pemasangan Box64/Wine gagal',
        liveProgress: true,
      );
    } finally {
      creepTimer.cancel();
    }
    _reportProgress(
      stage: 'Sahkan Box64 / Wine',
      progress: 0.88,
      detail: 'Menjalankan probe keserasian…',
    );

    // Pakej Debian generik dicuba dahulu kerana pemasangannya lebih cepat.
    // Pada kernel Android + PRoot, dokumentasi Box64 mengesyorkan BAD_SIGNAL=ON.
    // Jika probe Wine gagal, bina versi PRoot-specific yang dipin ke commit rasmi.
    try {
      await _runChecked(
        await commandSpec(
          command:
              'BOX64_NOBANNER=1 box64 /opt/wine/bin/wine --version',
          relativeWorkingDirectory: '.',
          requireReady: false,
          linuxRootPath: linuxRootPath,
        ),
        timeout: const Duration(seconds: 45),
        failureLabel: 'Probe Box64 generik gagal',
      );
    } on FileSystemException {
      await _installProotBox64Fallback(linuxRootPath);
    }

    late _ProcessOutput result;
    try {
      result = await _windowsHealthCheck(linuxRootPath);
    } on FileSystemException {
      final fallbackMarker = File(
        p.join(root.path, 'rootfs/opt/ai-windows/box64-proot-build'),
      );
      if (await fallbackMarker.exists()) rethrow;
      await _installProotBox64Fallback(linuxRootPath);
      result = await _windowsHealthCheck(linuxRootPath);
    }
    final lines = result.stdout
        .split('\n')
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty)
        .toList(growable: false);
    final wineVersion = lines.firstWhere(
      (line) => line.toLowerCase().contains('wine-'),
      orElse: () => 'wine-$expectedWineVersion',
    );
    final box64Version = await _box64Version(linuxRootPath);
    await _writeManifest(
      root,
      box64Version: box64Version,
      wineVersion: wineVersion,
    );
  }

  Future<void> _installProotBox64Fallback(String linuxRootPath) async {
    final command = '''
set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends build-essential cmake git
rm -rf /tmp/ai-box64-src /tmp/ai-box64-build
git clone -q --depth 1 --branch v0.4.4 https://github.com/ptitSeb/box64.git /tmp/ai-box64-src
cd /tmp/ai-box64-src
git checkout -q --detach ${_shellQuote(_box64Commit)}
test "\$(git rev-parse HEAD)" = ${_shellQuote(_box64Commit)}
cmake -S . -B /tmp/ai-box64-build -DARM64=1 -DCMAKE_C_COMPILER=gcc -DBAD_SIGNAL=ON -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build /tmp/ai-box64-build --parallel 2
cmake --install /tmp/ai-box64-build
strip /usr/local/bin/box64 2>/dev/null || true
mkdir -p /opt/ai-windows
printf '%s\\n' ${_shellQuote(_box64Commit)} >/opt/ai-windows/box64-proot-build
rm -rf /tmp/ai-box64-src /tmp/ai-box64-build
BOX64_NOBANNER=1 /usr/local/bin/box64 /opt/wine/bin/wine --version
apt-get purge -y build-essential cmake git || true
apt-get autoremove -y || true
apt-get clean
''';
    await _runChecked(
      await commandSpec(
        command: command,
        relativeWorkingDirectory: '.',
        requireReady: false,
        linuxRootPath: linuxRootPath,
      ),
      timeout: const Duration(minutes: 35),
      failureLabel:
          'Fallback Box64 $expectedBox64Version untuk Android/PRoot gagal',
    );
  }

  Future<_ProcessOutput> _windowsHealthCheck(String linuxRootPath) async {
    final healthCommand = '''
set -eu
${_xvfbBootstrap()}
BOX64_BIN="\$(command -v box64)"
"\$BOX64_BIN" /opt/wine/bin/wine --version
"\$BOX64_BIN" /opt/wine/bin/wine cmd.exe /d /s /c "ver"
test -f /root/.wine/system.reg
''';
    return _runChecked(
      await commandSpec(
        command: healthCommand,
        relativeWorkingDirectory: '.',
        requireReady: false,
        linuxRootPath: linuxRootPath,
      ),
      timeout: const Duration(minutes: 8),
      failureLabel: 'Pemeriksaan Wine/Box64 gagal',
    );
  }

  Future<String> _box64Version(String linuxRootPath) async {
    final result = await _runChecked(
      await commandSpec(
        command: 'box64 --version 2>&1 || box64 -v 2>&1 || true',
        relativeWorkingDirectory: '.',
        requireReady: false,
        linuxRootPath: linuxRootPath,
      ),
      timeout: const Duration(seconds: 30),
      failureLabel: 'Semakan versi Box64 gagal',
      allowNonZero: true,
    );
    final text = '${result.stdout}\n${result.stderr}'.trim();
    return text.isEmpty ? 'box64' : text.split('\n').first.trim();
  }

  Future<LinuxCommandSpec> commandSpec({
    required String command,
    String relativeWorkingDirectory = '.',
    bool requireReady = true,
    String? linuxRootPath,
  }) async {
    if (!AppConfig.isFullEdition) {
      throw const FileSystemException(
        'PC Windows local hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    if (requireReady) {
      final quickStatus = await status(includeSize: false);
      if (!quickStatus.ready ||
          quickStatus.runtimeVersion != expectedRuntimeVersion) {
        await ensureReady();
      }
    }
    final root = await ensurePrivateRoot();
    final linuxStatus = await LinuxWorkspaceService().status();
    final linuxRoot = linuxRootPath ?? linuxStatus.rootPath;
    if (linuxRoot.isEmpty) {
      throw const FileSystemException('Runtime PRoot Shell tidak tersedia.');
    }
    final proot = File(p.join(linuxRoot, 'runtime/bin/proot'));
    final dns = File(p.join(linuxRoot, 'runtime/android-resolv.conf'));
    final workspace = Directory(p.join(linuxRoot, 'workspace'));
    final rootfs = Directory(p.join(root.path, 'rootfs'));
    final home = Directory(p.join(root.path, 'home'));
    final tmp = Directory(p.join(root.path, 'tmp'));
    final attachments = Directory(
      p.join((await getApplicationDocumentsDirectory()).path, 'chat_attachments'),
    );
    await workspace.create(recursive: true);
    await home.create(recursive: true);
    await tmp.create(recursive: true);
    final safeRelative = p.normalize(relativeWorkingDirectory);
    if (p.isAbsolute(safeRelative) ||
        safeRelative == '..' ||
        safeRelative.startsWith('../')) {
      throw const FileSystemException('Working directory Windows tidak selamat.');
    }
    final guestCwd = safeRelative == '.' || safeRelative.isEmpty
        ? '/workspace'
        : '/workspace/${safeRelative.replaceAll('\\', '/')}';

    return LinuxCommandSpec(
      executable: proot.path,
      arguments: <String>[
        '--kill-on-exit',
        '--link2symlink',
        '-0',
        '-r',
        rootfs.path,
        ..._safeSystemBinds(),
        '-b',
        '${workspace.path}:/workspace',
        '-b',
        '${home.path}:/root',
        '-b',
        '${tmp.path}:/tmp',
        if (await attachments.exists()) ...<String>[
          '-b',
          '${attachments.path}:/attachments',
        ],
        if (await dns.exists()) ...<String>[
          '-b',
          '${dns.path}:/etc/resolv.conf',
        ],
        '-w',
        guestCwd,
        '/usr/bin/env',
        '-i',
        'HOME=/root',
        'USER=root',
        'LOGNAME=root',
        'TERM=xterm-256color',
        'LANG=C.UTF-8',
        'DISPLAY=$displayName',
        'WINEPREFIX=/root/.wine',
        'WINEARCH=win64',
        'WINEDEBUG=-all',
        'WINEDLLOVERRIDES=mscoree,mshtml=',
        'BOX64_NOBANNER=1',
        'PATH=/opt/wine/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        '/bin/sh',
        '-lc',
        command,
      ],
      hostWorkingDirectory: workspace.path,
      environment: <String, String>{
        'HOME': home.path,
        'TMPDIR': tmp.path,
        'PROOT_TMP_DIR': tmp.path,
      },
    );
  }

  String wrapWindowsCommand(String command) => '''
set -eu
${_xvfbBootstrap()}
BOX64_BIN="\$(command -v box64)"
exec "\$BOX64_BIN" /opt/wine/bin/wine cmd.exe /d /s /c ${_shellQuote(command)}
''';

  String wrapWindowsExecutable(
    String guestPath,
    List<String> arguments,
  ) {
    final args = arguments.map(_shellQuote).join(' ');
    return '''
set -eu
${_xvfbBootstrap()}
BOX64_BIN="\$(command -v box64)"
exec "\$BOX64_BIN" /opt/wine/bin/wine ${_shellQuote(guestPath)}${args.isEmpty ? '' : ' $args'}
''';
  }

  Future<WindowsExecutablePath> resolveExecutablePath(String rawPath) async {
    final value = rawPath.trim();
    final slashPath = value.replaceAll('\\', '/');
    if (value.isEmpty || p.posix.extension(slashPath).toLowerCase() != '.exe') {
      throw const FileSystemException('Fail Windows mesti mempunyai sambungan .exe.');
    }
    final linux = await LinuxWorkspaceService().status();
    if (linux.rootPath.isEmpty) {
      throw const FileSystemException('Workspace Shell tidak tersedia.');
    }
    final workspace = Directory(p.join(linux.rootPath, 'workspace'));
    final attachments = Directory(
      p.join((await getApplicationDocumentsDirectory()).path, 'chat_attachments'),
    );
    final windowsRoot = await ensurePrivateRoot();
    final driveC = Directory(
      p.join(windowsRoot.path, 'home', '.wine', 'drive_c'),
    );

    if (slashPath.startsWith('/workspace/')) {
      final relative = slashPath.substring('/workspace/'.length);
      return _validatedGuestFile(workspace, relative, '/workspace');
    }
    if (slashPath.startsWith('/attachments/')) {
      final relative = slashPath.substring('/attachments/'.length);
      return _validatedGuestFile(attachments, relative, '/attachments');
    }
    if (RegExp(r'^[zZ]:/workspace/').hasMatch(slashPath)) {
      final relative = slashPath.substring('Z:/workspace/'.length);
      return _validatedGuestFile(workspace, relative, '/workspace');
    }
    if (RegExp(r'^[zZ]:/attachments/').hasMatch(slashPath)) {
      final relative = slashPath.substring('Z:/attachments/'.length);
      return _validatedGuestFile(attachments, relative, '/attachments');
    }
    if (RegExp(r'^[cC]:/').hasMatch(slashPath)) {
      final relative = slashPath.substring(3);
      return _validatedGuestFile(
        driveC,
        relative,
        '/root/.wine/drive_c',
      );
    }
    if (p.isAbsolute(value)) {
      final normalized = p.normalize(value);
      if (normalized == workspace.path || p.isWithin(workspace.path, normalized)) {
        final relative = p.relative(normalized, from: workspace.path);
        return _validatedGuestFile(workspace, relative, '/workspace');
      }
      if (normalized == attachments.path ||
          p.isWithin(attachments.path, normalized)) {
        final relative = p.relative(normalized, from: attachments.path);
        return _validatedGuestFile(attachments, relative, '/attachments');
      }
      if (normalized == driveC.path || p.isWithin(driveC.path, normalized)) {
        final relative = p.relative(normalized, from: driveC.path);
        return _validatedGuestFile(
          driveC,
          relative,
          '/root/.wine/drive_c',
        );
      }
      throw const FileSystemException(
        'EXE mesti berada dalam /workspace, lampiran chat atau drive C: Wine.',
      );
    }
    return _validatedGuestFile(workspace, slashPath, '/workspace');
  }

  Future<WindowsExecutablePath> _validatedGuestFile(
    Directory root,
    String relative,
    String guestRoot,
  ) async {
    final normalizedRelative = p.normalize(relative);
    if (p.isAbsolute(normalizedRelative) ||
        normalizedRelative == '..' ||
        normalizedRelative.startsWith('../')) {
      throw const FileSystemException('Laluan EXE tidak selamat.');
    }
    final host = p.normalize(p.join(root.path, normalizedRelative));
    if (host != root.path && !p.isWithin(root.path, host)) {
      throw const FileSystemException('Laluan EXE keluar daripada ruang dibenarkan.');
    }
    final file = File(host);
    if (!await file.exists()) {
      throw FileSystemException('Fail EXE tidak ditemui.', host);
    }
    final guestRelative = normalizedRelative.replaceAll('\\', '/');
    return WindowsExecutablePath(
      hostPath: host,
      guestPath: '$guestRoot/$guestRelative',
    );
  }

  Future<String> screenshotHostPath() async {
    final linux = await LinuxWorkspaceService().status();
    if (linux.rootPath.isEmpty) {
      throw const FileSystemException('Workspace Shell tidak tersedia.');
    }
    final directory = Directory(
      p.join(linux.rootPath, 'workspace', 'windows', 'screenshots'),
    );
    await directory.create(recursive: true);
    final stamp = DateTime.now().toUtc().millisecondsSinceEpoch;
    return p.join(directory.path, 'windows-$stamp.png');
  }

  /// Path tetap untuk frame live stream (overwrite berterusan).
  Future<String> liveFrameHostPath() async {
    final linux = await LinuxWorkspaceService().status();
    if (linux.rootPath.isEmpty) {
      throw const FileSystemException('Workspace Shell tidak tersedia.');
    }
    final directory = Directory(
      p.join(linux.rootPath, 'workspace', 'windows', 'screenshots'),
    );
    await directory.create(recursive: true);
    return p.join(directory.path, 'live.jpg');
  }

  Future<void> reset() async {
    if (!AppConfig.isFullEdition) return;
    final root = await ensurePrivateRoot();
    if (await root.exists()) await root.delete(recursive: true);
    await ensurePrivateRoot();
  }

  String _xvfbBootstrap() => '''
mkdir -p /tmp/.X11-unix
if [ ! -S /tmp/.X11-unix/X99 ]; then
  rm -f /tmp/.X99-lock
  Xvfb $displayName -screen 0 ${desktopWidth}x${desktopHeight}x24 -nolisten tcp >/tmp/ai-windows-xvfb.log 2>&1 &
  i=0
  while [ ! -S /tmp/.X11-unix/X99 ] && [ "\$i" -lt 50 ]; do
    i=\$((i + 1))
    sleep 0.1
  done
fi
test -S /tmp/.X11-unix/X99
if [ ! -f /tmp/ai-windows-openbox.pid ] || ! kill -0 "\$(cat /tmp/ai-windows-openbox.pid 2>/dev/null || true)" 2>/dev/null; then
  DISPLAY=$displayName openbox --sm-disable >/tmp/ai-windows-openbox.log 2>&1 &
  echo \$! >/tmp/ai-windows-openbox.pid
  sleep 0.2
fi
''';

  Future<void> _downloadFile(
    Uri uri,
    File destination, {
    required int maxBytes,
    required String failureLabel,
    double progressStart = 0,
    double progressEnd = 0,
    String stageLabel = 'Muat turun',
  }) async {
    final partial = File('${destination.path}.part');
    Object? lastError;
    final hasProgressRange = progressEnd > progressStart;
    final host = uri.host;

    // Gaya Termux/Box64Droid: resume, UA browser Android, timeout longgar.
    const ua =
        'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

    for (var attempt = 0; attempt < 5; attempt += 1) {
      final client = HttpClient()
        ..connectionTimeout = const Duration(seconds: 45)
        ..idleTimeout = const Duration(seconds: 120)
        ..userAgent = ua
        ..autoUncompress = true;
      IOSink? sink;
      var existing = 0;
      try {
        await destination.parent.create(recursive: true);
        if (await partial.exists()) {
          existing = await partial.length();
          if (existing > maxBytes) {
            await partial.delete();
            existing = 0;
          }
        }

        _reportProgress(
          stage: stageLabel,
          progress: progressStart,
          detail: existing > 0
              ? 'Resume $host · ${WindowsInstallProgress._fmtBytes(existing)} sedia · cubaan ${attempt + 1}/5'
              : 'Sambung $host · cubaan ${attempt + 1}/5',
          bytesReceived: existing > 0 ? existing : null,
        );

        final request = await client
            .getUrl(uri)
            .timeout(const Duration(seconds: 60));
        request.followRedirects = true;
        request.maxRedirects = 8;
        request.headers.set(HttpHeaders.userAgentHeader, ua);
        request.headers.set(HttpHeaders.acceptHeader, '*/*');
        request.headers.set(HttpHeaders.acceptEncodingHeader, 'identity');
        if (existing > 0) {
          request.headers.set(HttpHeaders.rangeHeader, 'bytes=$existing-');
        }

        final response = await request
            .close()
            .timeout(const Duration(seconds: 90));
        final code = response.statusCode;
        // 200 = full, 206 = partial resume
        if (code != 200 && code != 206) {
          throw HttpException('HTTP $code dari $host', uri: uri);
        }
        if (code == 200 && existing > 0) {
          // Server tak support Range — mula semula.
          await partial.delete();
          existing = 0;
        }

        final contentLength = response.contentLength; // -1 if unknown
        final totalExpected = contentLength > 0
            ? (code == 206 ? existing + contentLength : contentLength)
            : null;
        if (totalExpected != null && totalExpected > maxBytes) {
          throw const FileSystemException('Fail muat turun melebihi had.');
        }

        sink = partial.openWrite(mode: FileMode.append);
        var total = existing;
        var lastReportAt = total;
        final started = DateTime.now();
        var lastTick = started;

        await for (final chunk in response) {
          total += chunk.length;
          if (total > maxBytes) {
            throw const FileSystemException('Fail muat turun melebihi had.');
          }
          sink.add(chunk);

          final now = DateTime.now();
          final sinceTick = now.difference(lastTick).inMilliseconds;
          // Update setiap 128KB atau 500ms — log penuh untuk fon perlahan.
          if (hasProgressRange &&
              (total - lastReportAt >= 128 * 1024 || sinceTick >= 500)) {
            lastReportAt = total;
            lastTick = now;
            final elapsed = now.difference(started).inMilliseconds.clamp(1, 1 << 30);
            final delta = total - existing;
            final speed = delta * 1000 / elapsed; // bytes/s
            final speedLabel = speed >= 1024 * 1024
                ? '${(speed / (1024 * 1024)).toStringAsFixed(1)} MB/s'
                : '${(speed / 1024).toStringAsFixed(0)} KB/s';
            final fraction = totalExpected != null && totalExpected > 0
                ? (total / totalExpected).clamp(0.0, 1.0)
                : (total / maxBytes).clamp(0.0, 0.95);
            final overall =
                progressStart + (progressEnd - progressStart) * fraction;
            final pct = totalExpected != null && totalExpected > 0
                ? '${((total / totalExpected) * 100).toStringAsFixed(0)}%'
                : '';
            _reportProgress(
              stage: stageLabel,
              progress: overall,
              detail:
                  '$host · ${WindowsInstallProgress._fmtBytes(total)}'
                  '${totalExpected != null ? ' / ${WindowsInstallProgress._fmtBytes(totalExpected)}' : ''}'
                  '${pct.isNotEmpty ? ' · $pct' : ''} · $speedLabel'
                  '${attempt > 0 ? ' · retry ${attempt + 1}' : ''}',
              bytesReceived: total,
              bytesTotal: totalExpected,
            );
          }
        }
        await sink.flush();
        await sink.close();
        sink = null;

        if (total <= 0) {
          throw const FileSystemException('Fail muat turun kosong.');
        }
        if (await destination.exists()) await destination.delete();
        await partial.rename(destination.path);
        if (hasProgressRange) {
          _reportProgress(
            stage: stageLabel,
            progress: progressEnd,
            detail:
                'Selesai $host · ${WindowsInstallProgress._fmtBytes(total)}',
            bytesReceived: total,
            bytesTotal: total,
          );
        }
        return;
      } on Object catch (error) {
        lastError = error;
        try {
          await sink?.close();
        } on Object {
          // ignore
        }
        // JANGAN padam .part — resume cubaan seterusnya (gaya wget -c).
        _reportProgress(
          stage: stageLabel,
          progress: progressStart,
          detail:
              'Ralat $host: ${error.toString().split('\\n').first} · simpan partial, retry…',
        );
        if (attempt < 4) {
          await Future<void>.delayed(Duration(seconds: 2 + attempt * 2));
        }
      } finally {
        client.close(force: true);
      }
    }

    throw FileSystemException(
      '$failureLabel ($host): ${lastError ?? 'ralat rangkaian'}',
      destination.path,
    );
  }


  Future<_ProcessOutput> _runChecked(
    LinuxCommandSpec spec, {
    required Duration timeout,
    required String failureLabel,
    bool allowNonZero = false,
    bool liveProgress = false,
  }) async {
    final process = await Process.start(
      spec.executable,
      spec.arguments,
      workingDirectory: spec.hostWorkingDirectory,
      environment: spec.environment,
      includeParentEnvironment: false,
      runInShell: false,
    );
    final outBuf = StringBuffer();
    final errBuf = StringBuffer();
    var lastLine = '';

    void handleLine(String line, {required bool isErr}) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) return;
      if (isErr) {
        errBuf.writeln(line);
      } else {
        outBuf.writeln(line);
      }
      lastLine = trimmed.length > 220 ? '${trimmed.substring(0, 220)}…' : trimmed;
      if (liveProgress) {
        // Kemas kini detail supaya UI nampak di mana dia tertunggu.
        final current = installProgress.value;
        final p = (current?.progress ?? 0.5).clamp(0.45, 0.86);
        _reportProgress(
          stage: current?.stage ?? 'Pasang pakej & Wine',
          progress: p,
          detail: lastLine,
        );
      }
    }

    final stdoutDone = process.stdout
        .transform(const Utf8Decoder(allowMalformed: true))
        .transform(const LineSplitter())
        .listen(
          (line) => handleLine(line, isErr: false),
          onError: (_) {},
          cancelOnError: false,
        )
        .asFuture<void>();
    final stderrDone = process.stderr
        .transform(const Utf8Decoder(allowMalformed: true))
        .transform(const LineSplitter())
        .listen(
          (line) => handleLine(line, isErr: true),
          onError: (_) {},
          cancelOnError: false,
        )
        .asFuture<void>();

    int exitCode;
    try {
      exitCode = await process.exitCode.timeout(timeout);
    } on TimeoutException {
      process.kill(ProcessSignal.sigkill);
      throw FileSystemException(
        '$failureLabel: tamat masa.'
        '${lastLine.isEmpty ? '' : ' Terakhir: $lastLine'}',
      );
    }
    await Future.wait(<Future<void>>[stdoutDone, stderrDone]);
    final stdout = outBuf.toString();
    final stderr = errBuf.toString();
    if (exitCode != 0 && !allowNonZero) {
      throw FileSystemException(
        '$failureLabel (exit $exitCode): ${_clip('$stdout\n$stderr')}',
      );
    }
    return _ProcessOutput(exitCode: exitCode, stdout: stdout, stderr: stderr);
  }

  Future<Map<String, dynamic>?> _readManifest(Directory root) async {
    final file = File(p.join(root.path, 'runtime/manifest.json'));
    if (!await file.exists()) return null;
    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } on Object {
      return null;
    }
    return null;
  }

  bool _manifestIsValid(Map<String, dynamic>? manifest) =>
      manifest?['runtime_version'] == expectedRuntimeVersion &&
      manifest?['distribution'] == expectedDistribution &&
      manifest?['distribution_version'] == expectedDistributionVersion &&
      manifest?['architecture'] == expectedArchitecture &&
      manifest?['health_status'] == 'verified';

  Future<void> _writeManifest(
    Directory root, {
    required String box64Version,
    required String wineVersion,
  }) async {
    final file = File(p.join(root.path, 'runtime/manifest.json'));
    await file.parent.create(recursive: true);
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(<String, dynamic>{
        'schema': 1,
        'runtime_version': expectedRuntimeVersion,
        'distribution': expectedDistribution,
        'distribution_version': expectedDistributionVersion,
        'architecture': expectedArchitecture,
        'box64_version': box64Version,
        'wine_version': wineVersion,
        'wine_mode': 'wow64',
        'desktop': '$desktopWidth x $desktopHeight',
        'health_status': 'verified',
        'installed_at': DateTime.now().toUtc().toIso8601String(),
      }),
      flush: true,
    );
  }

  List<String> _safeSystemBinds() {
    final arguments = <String>[];
    for (final path in <String>[
      '/proc',
      '/dev/null',
      '/dev/zero',
      '/dev/random',
      '/dev/urandom',
      '/dev/tty',
      '/dev/pts',
    ]) {
      if (FileSystemEntity.typeSync(path, followLinks: false) !=
          FileSystemEntityType.notFound) {
        arguments.addAll(<String>['-b', path]);
      }
    }
    return arguments;
  }

  Future<int> _directorySize(Directory root) async {
    if (!await root.exists()) return 0;
    var total = 0;
    // Jangan guna list(recursive: true): pada Android, rootfs/dev/pts boleh
    // throw PathAccessException dan meranapkan status PC Windows di UI.
    final queue = <Directory>[root];
    while (queue.isNotEmpty) {
      final dir = queue.removeLast();
      final lower = dir.path.replaceAll('\\', '/').toLowerCase();
      if (_shouldSkipSizePath(lower)) continue;
      try {
        await for (final entity in dir.list(followLinks: false)) {
          if (entity is Directory) {
            final child = entity.path.replaceAll('\\', '/').toLowerCase();
            if (!_shouldSkipSizePath(child)) queue.add(entity);
          } else if (entity is File) {
            try {
              total += await entity.length();
            } on FileSystemException {
              // Fail boleh berubah semasa proses Wine aktif.
            }
          }
        }
      } on FileSystemException {
        // Folder tanpa kebenaran (cth. rootfs/dev/pts) — abaikan.
      }
    }
    return total;
  }

  bool _shouldSkipSizePath(String lowerPath) {
    return lowerPath.endsWith('/dev') ||
        lowerPath.contains('/dev/') ||
        lowerPath.endsWith('/proc') ||
        lowerPath.contains('/proc/') ||
        lowerPath.endsWith('/sys') ||
        lowerPath.contains('/sys/') ||
        lowerPath.endsWith('/tmp') ||
        lowerPath.contains('/tmp/') ||
        lowerPath.contains('/run/');
  }

  bool _isFileOrLink(String path) {
    final type = FileSystemEntity.typeSync(path, followLinks: false);
    return type == FileSystemEntityType.file || type == FileSystemEntityType.link;
  }

  void _assertPrivateAppPath(String path) {
    if (!Platform.isAndroid) return;
    final normalized = p.normalize(path);
    if (!normalized.startsWith('/data/user/') &&
        !normalized.startsWith('/data/data/')) {
      throw FileSystemException(
        'PC Windows mesti berada dalam storan internal private aplikasi.',
        normalized,
      );
    }
  }

  static String _shellQuote(String value) =>
      "'${value.replaceAll("'", "'\\''").replaceAll('\u0000', '')}'";

  static String _clip(String value) {
    const max = 1800;
    final text = value.trim();
    if (text.isEmpty) return '(tiada log)';
    final lines = text.split('\n');
    final interesting = lines.where((line) {
      final l = line.toLowerCase();
      return l.contains('error') ||
          l.contains('fail') ||
          l.contains('e:') ||
          l.contains('w:') ||
          l.contains('cannot') ||
          l.contains('unable') ||
          l.contains('dependency') ||
          l.contains('not found') ||
          l.contains('exit') ||
          l.contains('no such') ||
          l.contains('dpkg:') ||
          l.contains('apt') ||
          l.startsWith('>>') ||
          l.startsWith('fail:');
    }).toList();
    final picked = interesting.isNotEmpty
        ? interesting.reversed.take(25).toList().reversed.join('\n')
        : (text.length <= max
            ? text
            : '…${text.substring(text.length - max)}');
    return picked.length <= max
        ? picked
        : '…${picked.substring(picked.length - max)}';
  }
}

class _ProcessOutput {
  const _ProcessOutput({
    required this.exitCode,
    required this.stdout,
    required this.stderr,
  });

  final int exitCode;
  final String stdout;
  final String stderr;
}
