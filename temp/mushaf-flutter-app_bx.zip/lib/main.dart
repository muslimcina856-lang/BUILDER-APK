import 'dart:async';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MushafApp());
}

class MushafApp extends StatelessWidget {
  const MushafApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mushaf',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF0B3D2E),
        useMaterial3: true,
      ),
      home: const MushafWebView(),
    );
  }
}

class MushafWebView extends StatefulWidget {
  const MushafWebView({super.key});

  @override
  State<MushafWebView> createState() => _MushafWebViewState();
}

class _MushafWebViewState extends State<MushafWebView> {
  late final WebViewController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _initController();
  }

  // Lokasi dipakai buat jadwal sholat & adzan reminder.
  // Notifikasi (Android 13+) dipakai buat push reminder adzan.
  Future<void> _requestPermissions() async {
    await [
      Permission.location,
      Permission.notification,
    ].request();
  }

  void _initController() {
    late final PlatformWebViewControllerCreationParams params;
    params = const PlatformWebViewControllerCreationParams();

    final controller = WebViewController.fromPlatformCreationParams(params);

    controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0B3D2E))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _loading = false);
          },
        ),
      );

    // Aktifkan geolocation (dipakai buat deteksi lokasi jadwal sholat).
    // Izin OS-level tetap wajib lewat permission_handler di atas.
    if (controller.platform is AndroidWebViewController) {
      final androidController = controller.platform as AndroidWebViewController;
      androidController.setGeolocationEnabled(true);
      androidController.setMediaPlaybackRequiresUserGesture(false);
    }

    controller.loadFlutterAsset('assets/www/index.html');
    _controller = controller;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B3D2E),
      body: SafeArea(
        child: Stack(
          children: [
            WebViewWidget(controller: _controller),
            if (_loading)
              const Center(
                child: CircularProgressIndicator(color: Color(0xFFC9A227)),
              ),
          ],
        ),
      ),
    );
  }
}
