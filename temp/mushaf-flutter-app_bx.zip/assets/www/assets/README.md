# Taruh file adzan.mp3 di sini

Aplikasi mencari file dengan nama persis: `adhan.mp3` di folder ini
(path lengkap: `assets/adhan.mp3`).

## Rekaman gratis & legal (CC0 — bebas dipakai, tanpa atribusi)
Download dari Wikimedia Commons:
https://commons.wikimedia.org/wiki/File:Beautiful_adhan.ogg

Cara pakai:
1. Buka link di atas → klik file audio-nya → klik kanan / tombol "Download" → simpan.
2. File aslinya format .ogg — kalau mau tetap .mp3, convert dulu (bisa pakai
   https://cloudconvert.com/ogg-to-mp3, gratis), atau ganti nama filenya jadi
   `adhan.ogg` dan sesuaikan path di index.html (cari `adhan.mp3`, ganti ke `.ogg`).
3. Taruh hasilnya di folder `assets/` ini dengan nama `adhan.mp3`.
4. Commit & push — Vercel otomatis redeploy.

## Alternatif
Kalau mau pakai rekaman qari favorit kamu sendiri, pastikan kamu punya izin
pakai (banyak aplikasi adzan resmi kasih opsi export/share audio-nya), lalu
taruh di sini dengan nama yang sama.
