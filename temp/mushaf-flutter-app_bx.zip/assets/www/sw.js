const CACHE_NAME = 'mushaf-cache-v2';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-512-maskable.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      // Cache each file individually so one failed asset doesn't
      // abort the whole precache (cache.addAll fails atomically).
      Promise.all(
        APP_SHELL.map((url) =>
          cache.add(url).catch((err) => console.warn('Precache skip:', url, err))
        )
      )
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Quran text API + Prayer times API: network-first, fall back to cache,
  // and cache successful responses so previously-fetched data works offline.
  if (url.hostname === 'equran.id' || url.hostname === 'api.aladhan.com' || url.hostname === 'api.bigdatacloud.net') {
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          return res;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  // App shell + static assets: cache-first, network fallback,
  // and if BOTH fail (offline + not cached yet), fall back to the
  // cached index.html so the installed icon never hits a raw
  // browser "site can't be reached" error.
  if (event.request.method === 'GET' && url.origin === self.location.origin) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        if (cached) return cached;
        return fetch(event.request).catch(() =>
          caches.match('./index.html').then((shell) => shell || Response.error())
        );
      })
    );
    return;
  }

  // Everything else (fonts, google auth, audio streams): just pass through to network.
});

// ---------------------------------------------------------------------
// Push notifications (adzan reminders sent from the server, see
// /api/send-reminders.js). This fires even when the app is fully closed,
// as long as the OS/browser hasn't force-stopped background services.
// ---------------------------------------------------------------------
self.addEventListener('push', (event) => {
  let data = { title: 'Waktunya Sholat', body: 'Sudah masuk waktu sholat. Yuk tunaikan 🤲', tag: 'adzan' };
  try{ if(event.data) data = { ...data, ...event.data.json() }; }catch(e){}

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: './icons/icon-192.png',
      badge: './icons/icon-192.png',
      vibrate: [200, 100, 200],
      tag: data.tag || 'adzan'
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow('./index.html');
    })
  );
});
