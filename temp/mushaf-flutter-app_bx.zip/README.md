# Mushaf — Flutter (Android WebView wrapper)

Project Flutter yang bungkus website Mushaf lu jadi APK, format yang diminta bot build lu (ada `pubspec.yaml` di root).

## Cara pakai

Tinggal kirim/upload file zip ini langsung ke bot build APK lu. `pubspec.yaml` ada di root zip, jadi harusnya langsung kebaca.

Kalau mau build manual sendiri (butuh Flutter SDK terinstall):
```
flutter pub get
flutter build apk --debug
```
APK hasil ada di `build/app/outputs/flutter-apk/app-debug.apk`.

## ⚠️ Penting: gw belum bisa compile-test project ini di sini

Beda sama versi Capacitor kemarin (yang sempet gw `npm install` + build beneran buat mastiin jalan), sandbox gw **gak ada Flutter SDK & gak bisa akses pub.dev**, jadi project ini gw susun manual berdasarkan struktur standar `flutter create` + dependency `webview_flutter`. Kemungkinan besar langsung jalan, tapi kalau bot build lu balikin error saat compile, kirim aja pesan errornya ke sini, gw perbaiki.

## Cara kerja

`lib/main.dart` — buka `assets/www/index.html` (isi PWA Mushaf lu, sudah termasuk bug fix qari-selector & tombol audio) lewat `WebView`, offline-first sama kayak versi Capacitor kemarin. Izin lokasi & notifikasi diminta otomatis pas app dibuka (dipakai buat fitur jadwal sholat & adzan reminder).

## ⚠️ Sama kayak versi Capacitor: Login Google kemungkinan gak jalan

Karena app-nya load dari asset lokal (origin `https://appassets.androidplatform.net`, bukan domain Vercel lu), Login Google kemungkinan besar gak berfungsi di dalam APK ini — Google WebView memang blokir Sign-In dari dalam app non-browser, dan origin-nya juga gak match sama "Authorized JavaScript origins" di OAuth Client ID lu. Fitur lain (baca Qur'an, bookmark, offline, adzan reminder) tetap jalan normal buat user tanpa login.

## Ganti nama app / package / icon

- Nama app: edit `android/app/src/main/AndroidManifest.xml` → `android:label`
- Package ID: cari-ganti `com.dim.mushaf` di `android/app/build.gradle`, `AndroidManifest.xml`, dan path folder `android/app/src/main/kotlin/com/dim/mushaf/`
- Icon: ganti file di `android/app/src/main/res/mipmap-*/ic_launcher.png` (ukuran: mdpi 48px, hdpi 72px, xhdpi 96px, xxhdpi 144px, xxxhdpi 192px)
