package com.dim.mushaf

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
