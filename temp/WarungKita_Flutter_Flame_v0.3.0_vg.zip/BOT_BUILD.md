# Tetapan Bot Binaan

Pilih jenis projek **Flutter**. Flame ialah dependency Dart di dalam projek Flutter dan tidak mengubah jenis projek.

## Arahan

```bash
flutter pub get
flutter build apk --release
```

## Keperluan minimum

- Flutter yang mengandungi Dart 3.4 atau lebih baharu
- Java 17 untuk konfigurasi Android semasa
- Android SDK yang disediakan oleh persekitaran Flutter

## Maklumat aplikasi

- Package: `com.earlxz.warungkita`
- Nama: `Warung Kita`
- Versi: `0.3.0+3`
- Orientasi: portrait
- Rangkaian/pelayan: tidak diperlukan ketika bermain
