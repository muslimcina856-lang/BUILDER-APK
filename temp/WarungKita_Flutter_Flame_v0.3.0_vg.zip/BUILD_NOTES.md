# Nota Binaan v0.3.0

Projek telah ditukar daripada paparan Flutter berasaskan widget sahaja kepada Flutter + Flame.

Perubahan utama:

1. Dependency `flame: 1.23.0` ditambah.
2. `WarungKitaGame` menyediakan game loop dan scene world.
3. Pelanggan ialah `SpriteComponent` yang bergerak melalui beberapa fasa.
4. Jualan kini dipicu oleh pelanggan yang sampai ke kaunter dalam game loop Flame.
5. Sistem stok, menu, naik taraf, laporan dan simpanan lama dikekalkan.
6. Navigasi dikunci semasa operasi supaya game loop tidak terhenti di tengah hari.

Persekitaran penyediaan fail ini tidak mempunyai Flutter SDK, jadi APK tidak dibina di sini. Semakan yang dilakukan ialah semakan struktur, aset, rujukan fail, keseimbangan sintaks asas dan konfigurasi projek.
