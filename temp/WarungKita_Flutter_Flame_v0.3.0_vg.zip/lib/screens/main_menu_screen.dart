import 'package:flutter/material.dart';

import '../app_theme.dart';

class MainMenuScreen extends StatelessWidget {
  const MainMenuScreen({
    super.key,
    required this.canContinue,
    required this.onContinue,
    required this.onNewGame,
  });

  final bool canContinue;
  final Future<void> Function() onContinue;
  final Future<void> Function() onNewGame;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBrown,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF4A2412),
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: AppColors.orange, width: 3),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: AspectRatio(
                        aspectRatio: 1,
                        child: Image.asset(
                          'assets/images/menu_hero.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'WARUNG KITA',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 38,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                      shadows: [Shadow(color: Colors.black, offset: Offset(2, 2))],
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Simulator warung offline',
                    style: TextStyle(
                      color: AppColors.gold,
                      fontSize: 19,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: canContinue ? onContinue : null,
                    icon: const Icon(Icons.play_arrow_rounded),
                    label: const Text('Sambung Permainan'),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.green,
                      disabledBackgroundColor: const Color(0xFF7F766C),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: onNewGame,
                    icon: const Icon(Icons.add_circle_outline),
                    label: const Text('Permainan Baharu'),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () => _showAbout(context),
                    icon: const Icon(Icons.info_outline),
                    label: const Text('Tentang Prototaip'),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                      foregroundColor: AppColors.cream,
                      side: const BorderSide(color: AppColors.gold),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Versi 0.3.0 • Flutter + Flame • Android Offline',
                    style: TextStyle(color: Color(0xFFCBBDA8), fontSize: 13),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showAbout(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Warung Kita'),
        content: const Text(
          'Prototaip Flutter + Flame ini merangkumi pelanggan bergerak, '
          'jualan harian, stok, menu, naik taraf, laporan, auto-simpan dan '
          'pendapatan offline sehingga empat jam.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Baik'),
          ),
        ],
      ),
    );
  }
}
