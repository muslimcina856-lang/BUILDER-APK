package com.aiuhdhub.app.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Palette - Neon Blue/Cyan
val PrimaryDark = Color(0xFF0A0E1A)
val SurfaceDark = Color(0xFF0F1524)
val SurfaceVariantDark = Color(0xFF151D30)
val CardDark = Color(0xFF1A2340)
val CardHighlightDark = Color(0xFF1E2A4A)

val AccentBlue = Color(0xFF4FC3F7)
val AccentCyan = Color(0xFF00E5FF)
val AccentPurple = Color(0xFFBB86FC)
val AccentGreen = Color(0xFF69F0AE)
val AccentOrange = Color(0xFFFFAB40)
val AccentPink = Color(0xFFFF80AB)
val AccentRed = Color(0xFFFF5252)

val GradientStart = Color(0xFF4FC3F7)
val GradientEnd = Color(0xFFBB86FC)
val GradientGreen = Color(0xFF69F0AE)
val GradientCyan = Color(0xFF00E5FF)

val TextPrimary = Color(0xFFE8EAF6)
val TextSecondary = Color(0xFFB0BEC5)
val TextMuted = Color(0xFF78909C)

val StatusActive = Color(0xFF69F0AE)
val StatusInactive = Color(0xFFFF5252)
val StatusPending = Color(0xFFFFAB40)

val DividerColor = Color(0xFF1E2A4A)
val ShimmerBase = Color(0xFF1A2340)
val ShimmerHighlight = Color(0xFF2A3660)
