package com.aiuhdhub.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aiuhdhub.app.ui.theme.*

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    glowColor: Color = AccentBlue,
    cornerRadius: Dp = 20.dp,
    showGlow: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)

    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.08f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    val gradientBorder = Brush.linearGradient(
        colors = listOf(
            glowColor.copy(alpha = 0.5f),
            AccentPurple.copy(alpha = 0.3f),
            glowColor.copy(alpha = 0.1f)
        )
    )

    Card(
        modifier = modifier
            .then(
                if (showGlow) {
                    Modifier.drawBehind {
                        drawCircle(
                            color = glowColor.copy(alpha = glowAlpha),
                            radius = size.maxDimension * 0.6f,
                            center = Offset(size.width * 0.5f, size.height * 0.5f)
                        )
                    }
                } else Modifier
            )
            .border(
                width = 1.dp,
                brush = gradientBorder,
                shape = shape
            ),
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = CardDark.copy(alpha = 0.85f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        content()
    }
}

@Composable
fun GradientButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    gradientColors: List<Color> = listOf(AccentBlue, AccentPurple),
    cornerRadius: Dp = 14.dp,
    content: @Composable RowScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)

    androidx.compose.material3.Button(
        onClick = onClick,
        modifier = modifier,
        shape = shape,
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
            containerColor = Color.Transparent
        ),
        contentPadding = PaddingValues(0.dp)
    ) {
        Row(
            modifier = Modifier
                .background(
                    brush = Brush.horizontalGradient(gradientColors),
                    shape = shape
                )
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            content = content
        )
    }
}

@Composable
fun StatusChip(
    text: String,
    color: Color = AccentGreen,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .border(
                width = 1.dp,
                color = color.copy(alpha = 0.3f),
                shape = RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        androidx.compose.material3.Text(
            text = text,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}
