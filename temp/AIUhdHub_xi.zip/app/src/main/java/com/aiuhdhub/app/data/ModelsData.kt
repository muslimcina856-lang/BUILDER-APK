package com.aiuhdhub.app.data

data class DownloadableModel(
    val id: String,
    val name: String,
    val type: String,
    val size: String,
    val description: String,
    val downloadUrl: String,
    val filename: String,
    val engineType: String = "NCNN/Vulkan",
    val compatibility: String = "Sangat Baik (GPU)"
)

object ModelsRepository {
    fun getDownloadableModels(): List<DownloadableModel> = listOf(
        DownloadableModel(
            id = "realesrgan_photo",
            name = "Real-ESRGAN UHD Photo",
            type = "Super Resolution (Foto)",
            size = "7.8 MB",
            description = "Model terbaik untuk memulihkan foto realistik, tekstur, dan pemandangan ke kualiti UHD. Menggunakan rangkaian baki padat (residual dense networks).",
            downloadUrl = "https://github.com/tensorflow/examples/raw/master/lite/examples/super_resolution/android/app/src/main/assets/esrgan.tflite",
            filename = "realesrgan_photo.tflite",
            engineType = "TFLite / GPU"
        ),
        DownloadableModel(
            id = "waifu2x_anime",
            name = "Waifu2x Anime Ultra",
            type = "Super Resolution (Anime)",
            size = "4.2 MB",
            description = "Model khusus untuk imej 2D, ilustrasi, dan seni digital. Mengurangkan hingar JPEG dan mengekalkan kejelasan garisan lakaran.",
            downloadUrl = "https://github.com/nihui/realcugan-ncnn-vulkan/releases/download/v0.1.0/realcugan-v0.1.0.zip", // URL hiasan/nyata
            filename = "waifu2x_anime.bin",
            engineType = "NCNN / GPU"
        ),
        DownloadableModel(
            id = "realcugan_restoration",
            name = "RealCUGAN restoration",
            type = "Super Resolution (Ilustrasi)",
            size = "5.1 MB",
            description = "Model pemulihan anime berkualiti ultra-tinggi dengan sokongan denoising pelbagai peringkat. Menghasilkan warna yang sangat tajam dan terang.",
            downloadUrl = "https://github.com/xinntao/Real-ESRGAN-ncnn-vulkan/releases/download/v0.2.0/realesrgan-ncnn-vulkan-v0.2.0.zip",
            filename = "realcugan_model.param",
            engineType = "NCNN / GPU"
        ),
        DownloadableModel(
            id = "anime4k_fast",
            name = "Anime4K Fast Scaling",
            type = "UHD Scaling Pantas",
            size = "250 KB",
            description = "Model scaling shader yang sangat ringan dan pantas. Sesuai untuk peranti berspesifikasi rendah atau pemprosesan masa nyata.",
            downloadUrl = "https://github.com/bloc97/Anime4K/releases/download/v4.0.1/Anime4K_v4.0.1.zip",
            filename = "anime4k_shaders.glsl",
            engineType = "GLSL Shader / GPU"
        )
    )
}
