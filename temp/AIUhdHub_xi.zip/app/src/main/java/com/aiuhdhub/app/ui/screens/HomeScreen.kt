package com.aiuhdhub.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiuhdhub.app.data.ToolCategory
import com.aiuhdhub.app.data.ToolsRepository
import com.aiuhdhub.app.ui.components.GlassCard
import com.aiuhdhub.app.ui.theme.*

@Composable
fun HomeScreen(
    onNavigateToTools: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val scrollState = rememberScrollState()
    val tools = ToolsRepository.getAllTools()

    val infiniteTransition = rememberInfiniteTransition(label = "hero")
    val gradientOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "gradientShift"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PrimaryDark)
            .verticalScroll(scrollState)
            .padding(bottom = 100.dp)
    ) {
        // Hero Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(320.dp)
                .drawBehind {
                    // Animated gradient background
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                AccentBlue.copy(alpha = 0.15f),
                                AccentPurple.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = Offset(
                                size.width * (0.3f + gradientOffset * 0.4f),
                                size.height * 0.4f
                            ),
                            radius = size.maxDimension * 0.8f
                        )
                    )
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                AccentCyan.copy(alpha = 0.1f),
                                Color.Transparent
                            ),
                            center = Offset(
                                size.width * (0.7f - gradientOffset * 0.3f),
                                size.height * 0.6f
                            ),
                            radius = size.maxDimension * 0.5f
                        )
                    )
                }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp)
                    .padding(top = 60.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // App icon glow effect
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        AccentBlue.copy(alpha = 0.4f),
                                        Color.Transparent
                                    )
                                ),
                                radius = size.maxDimension * 0.8f
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(AccentBlue, AccentPurple)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "AI UHD Hub",
                    style = MaterialTheme.typography.displayLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Pusat AI Upscaling Open-Source Terbaik",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Percuma • Offline • Dikuasakan Vulkan GPU",
                    style = MaterialTheme.typography.bodySmall,
                    color = AccentCyan,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Quick Stats
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            QuickStatCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Filled.Apps,
                value = "${tools.size}",
                label = "Tools",
                color = AccentBlue
            )
            QuickStatCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Filled.Image,
                value = "${tools.count { it.supportsImage }}",
                label = "Image AI",
                color = AccentGreen
            )
            QuickStatCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Filled.VideoLibrary,
                value = "${tools.count { it.supportsVideo }}",
                label = "Video AI",
                color = AccentPurple
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Categories Section
        Text(
            text = "Kategori",
            style = MaterialTheme.typography.headlineSmall,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        Column(
            modifier = Modifier.padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CategoryRow(
                icon = Icons.Filled.PhotoSizeSelectLarge,
                title = "Image Upscaler",
                subtitle = "Tingkatkan resolusi gambar ke UHD",
                count = ToolsRepository.getToolsByCategory(ToolCategory.IMAGE_UPSCALER).size,
                color = AccentBlue,
                onClick = onNavigateToTools
            )
            CategoryRow(
                icon = Icons.Filled.OndemandVideo,
                title = "Video Upscaler",
                subtitle = "Upscale video secara real-time",
                count = ToolsRepository.getToolsByCategory(ToolCategory.VIDEO_UPSCALER).size,
                color = AccentPurple,
                onClick = onNavigateToTools
            )
            CategoryRow(
                icon = Icons.Filled.AutoAwesome,
                title = "All-in-One",
                subtitle = "Suite lengkap AI enhancement",
                count = ToolsRepository.getToolsByCategory(ToolCategory.ALL_IN_ONE).size,
                color = AccentGreen,
                onClick = onNavigateToTools
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Info Section
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            glowColor = AccentCyan,
            showGlow = false
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = null,
                        tint = AccentCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Mengenai Peranti Anda",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Semua tool di sini menggunakan pecutan Vulkan GPU untuk pemprosesan AI secara lokal. " +
                            "Peranti dengan GPU Immortalis-G925 (Dimensity 9500s) sangat sesuai untuk menjalankan model-model ini " +
                            "dengan kelajuan tinggi tanpa memerlukan internet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
private fun QuickStatCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    value: String,
    label: String,
    color: Color
) {
    GlassCard(
        modifier = modifier,
        glowColor = color,
        showGlow = false,
        cornerRadius = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }
    }
}

@Composable
private fun CategoryRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    count: Int,
    color: Color,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = color,
        showGlow = false,
        cornerRadius = 16.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.15f))
                    .border(1.dp, color.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "$count",
                    style = MaterialTheme.typography.labelLarge,
                    color = color,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(onClick = onClick) {
                Icon(
                    imageVector = Icons.Filled.ArrowForwardIos,
                    contentDescription = "Lihat",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
