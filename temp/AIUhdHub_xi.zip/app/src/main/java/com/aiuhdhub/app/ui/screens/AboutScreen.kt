package com.aiuhdhub.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiuhdhub.app.ui.components.GlassCard
import com.aiuhdhub.app.ui.theme.*

@Composable
fun AboutScreen(
    onOpenUrl: (String) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PrimaryDark)
            .verticalScroll(scrollState)
            .padding(bottom = 100.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 50.dp, start = 24.dp, end = 24.dp, bottom = 20.dp)
        ) {
            Text(
                text = "Mengenai",
                style = MaterialTheme.typography.headlineLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Maklumat & panduan aplikasi",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        // App Info Card
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            glowColor = AccentBlue
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(AccentBlue, AccentPurple)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "AI UHD Hub",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Versi 1.0.0",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Pusat lengkap untuk menemui, memuat turun, dan mengurus " +
                            "tool AI upscaling open-source terbaik yang berjalan secara " +
                            "lokal di peranti Android anda.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // What is AI UHD
        SectionTitle("Apa itu AI UHD?")

        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            glowColor = AccentCyan,
            showGlow = false
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "AI UHD (Ultra High Definition) merujuk kepada penggunaan model kecerdasan " +
                            "buatan (AI) untuk meningkatkan resolusi imej atau video daripada kualiti rendah " +
                            "kepada kualiti tinggi (4K/UHD dan ke atas).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                InfoPoint(
                    icon = Icons.Filled.Memory,
                    title = "Bagaimana Ia Berfungsi?",
                    description = "Model AI seperti Real-ESRGAN, Waifu2x, dan RealCUGAN telah dilatih " +
                            "dengan jutaan imej untuk mempelajari cara 'mencipta' butiran tambahan yang realistik " +
                            "apabila resolusi ditingkatkan.",
                    color = AccentBlue
                )

                InfoPoint(
                    icon = Icons.Filled.PhoneAndroid,
                    title = "Pemprosesan Lokal",
                    description = "Semua tool dalam app ini memproses imej/video terus di peranti anda " +
                            "menggunakan GPU (melalui API Vulkan). Tiada data dihantar ke pelayan luar — " +
                            "privasi anda terjamin 100%.",
                    color = AccentGreen
                )

                InfoPoint(
                    icon = Icons.Filled.Speed,
                    title = "Prestasi GPU Anda",
                    description = "Peranti dengan GPU moden (seperti Immortalis-G925, Adreno 750) " +
                            "boleh menjalankan model AI ini dengan pantas. Dimensity 9500s sangat " +
                            "sesuai untuk tugas ini.",
                    color = AccentPurple
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // How to Use Guide
        SectionTitle("Cara Penggunaan")

        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            glowColor = AccentGreen,
            showGlow = false
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                StepItem(
                    step = 1,
                    title = "Pilih Tool",
                    description = "Pergi ke tab 'Tools' dan layari senarai tool AI yang tersedia. " +
                            "Baca penerangan dan ciri-ciri setiap tool.",
                    color = AccentBlue
                )
                StepItem(
                    step = 2,
                    title = "Muat Turun",
                    description = "Tekan butang 'Download' untuk memuat turun APK dari GitHub Releases " +
                            "atau Google Play Store. Pasang APK tersebut.",
                    color = AccentCyan
                )
                StepItem(
                    step = 3,
                    title = "Buka & Upload",
                    description = "Buka tool yang dipasang, pilih gambar atau video yang ingin " +
                            "diupscale, tetapkan faktor (2x/4x) dan mula proses.",
                    color = AccentGreen
                )
                StepItem(
                    step = 4,
                    title = "Nikmati Hasil UHD!",
                    description = "Gambar/video anda kini dalam resolusi UHD! Simpan dan kongsi " +
                            "hasil kerja anda.",
                    color = AccentPurple
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Recommended Tools
        SectionTitle("Cadangan Terbaik")

        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            glowColor = AccentOrange,
            showGlow = false
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                RecommendationItem(
                    rank = "🥇",
                    title = "Gambar Sebenar (Foto)",
                    recommendation = "RealSR-NCNN-Android atau Real-ESRGAN-NCNN-Vulkan",
                    reason = "Model Real-ESRGAN x4plus memberikan hasil terbaik untuk foto sebenar."
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 10.dp),
                    color = DividerColor
                )
                RecommendationItem(
                    rank = "🥇",
                    title = "Anime & Ilustrasi",
                    recommendation = "Waifu2x NCNN atau RealCUGAN",
                    reason = "Model RealCUGAN dan Waifu2x-CUNet direka khas untuk anime dengan garisan yang bersih."
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 10.dp),
                    color = DividerColor
                )
                RecommendationItem(
                    rank = "🥇",
                    title = "All-in-One Terbaik",
                    recommendation = "Image Toolbox oleh T8RIN",
                    reason = "Menawarkan upscaling + 310 filter + denoising + banyak lagi dalam satu aplikasi."
                )
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 10.dp),
                    color = DividerColor
                )
                RecommendationItem(
                    rank = "🥇",
                    title = "Video Upscaling",
                    recommendation = "Anime4K (dengan mpv player)",
                    reason = "Satu-satunya pilihan untuk upscale video secara real-time menggunakan GPU shader."
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Credits
        SectionTitle("Kredit & Sumber")

        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            glowColor = AccentPurple,
            showGlow = false
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                CreditItem(
                    name = "Tencent NCNN",
                    description = "Framework inferens neural network berprestasi tinggi untuk mobile",
                    url = "https://github.com/Tencent/ncnn",
                    onOpenUrl = onOpenUrl
                )
                CreditItem(
                    name = "nihui",
                    description = "Penyumbang utama ekosistem ncnn-vulkan",
                    url = "https://github.com/nihui",
                    onOpenUrl = onOpenUrl
                )
                CreditItem(
                    name = "xinntao",
                    description = "Pencipta Real-ESRGAN & GFPGAN",
                    url = "https://github.com/xinntao",
                    onOpenUrl = onOpenUrl
                )
                CreditItem(
                    name = "OpenModelDB",
                    description = "Pangkalan data komuniti untuk model AI upscaling",
                    url = "https://openmodeldb.info",
                    onOpenUrl = onOpenUrl
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Disclaimer
        Text(
            text = "App ini adalah agregator maklumat. Semua tool yang disenaraikan " +
                    "adalah projek pihak ketiga yang berlesen open-source masing-masing. " +
                    "Pastikan anda membaca lesen setiap projek sebelum penggunaan komersial.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp),
            lineHeight = 16.sp
        )
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.headlineSmall,
        color = TextPrimary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 24.dp, bottom = 12.dp)
    )
}

@Composable
private fun InfoPoint(
    icon: ImageVector,
    title: String,
    description: String,
    color: Color
) {
    Row(
        modifier = Modifier.padding(bottom = 14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun StepItem(
    step: Int,
    title: String,
    description: String,
    color: Color
) {
    Row(
        modifier = Modifier.padding(bottom = 16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(color, color.copy(alpha = 0.6f))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$step",
                style = MaterialTheme.typography.labelLarge,
                color = PrimaryDark,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun RecommendationItem(
    rank: String,
    title: String,
    recommendation: String,
    reason: String
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = rank, fontSize = 20.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = recommendation,
            style = MaterialTheme.typography.bodyMedium,
            color = AccentCyan,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = reason,
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            lineHeight = 16.sp
        )
    }
}

@Composable
private fun CreditItem(
    name: String,
    description: String,
    url: String,
    onOpenUrl: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = name,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
        }
        IconButton(onClick = { onOpenUrl(url) }) {
            Icon(
                imageVector = Icons.Filled.OpenInNew,
                contentDescription = "Buka",
                tint = AccentBlue,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
