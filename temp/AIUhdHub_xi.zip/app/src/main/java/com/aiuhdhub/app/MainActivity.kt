package com.aiuhdhub.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aiuhdhub.app.ui.screens.AboutScreen
import com.aiuhdhub.app.ui.screens.HomeScreen
import com.aiuhdhub.app.ui.screens.ToolsScreen
import com.aiuhdhub.app.ui.screens.AiStudioScreen
import com.aiuhdhub.app.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AIUhdHubTheme {
                MainApp()
            }
        }
    }
}

enum class Screen {
    HOME, TOOLS, STUDIO, ABOUT
}

data class NavItem(
    val screen: Screen,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun MainApp() {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf(Screen.HOME) }

    val navItems = listOf(
        NavItem(Screen.HOME, "Utama", Icons.Filled.Home, Icons.Outlined.Home),
        NavItem(Screen.TOOLS, "Model Hub", Icons.Filled.Apps, Icons.Outlined.Apps),
        NavItem(Screen.STUDIO, "Studio", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome),
        NavItem(Screen.ABOUT, "Info", Icons.Filled.Info, Icons.Outlined.Info)
    )

    val openUrl: (String) -> Unit = { url ->
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (_: Exception) {
            // URL tidak dapat dibuka
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Content
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                fadeIn(animationSpec = tween(300)) togetherWith
                        fadeOut(animationSpec = tween(200))
            },
            label = "screenTransition"
        ) { screen ->
            when (screen) {
                Screen.HOME -> HomeScreen(
                    onNavigateToTools = { currentScreen = Screen.TOOLS },
                    onNavigateToAbout = { currentScreen = Screen.ABOUT }
                )
                Screen.TOOLS -> ToolsScreen()
                Screen.STUDIO -> AiStudioScreen()
                Screen.ABOUT -> AboutScreen(
                    onOpenUrl = openUrl
                )
            }
        }

        // Bottom Navigation Bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                CardDark.copy(alpha = 0.95f),
                                SurfaceDark.copy(alpha = 0.98f)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                AccentBlue.copy(alpha = 0.2f),
                                AccentPurple.copy(alpha = 0.1f),
                                AccentCyan.copy(alpha = 0.15f)
                            )
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    navItems.forEach { item ->
                        val isSelected = currentScreen == item.screen

                        val animatedColor by animateColorAsState(
                            targetValue = if (isSelected) AccentBlue else TextMuted,
                            animationSpec = tween(300),
                            label = "navColor"
                        )

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentScreen = item.screen },
                            icon = {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label,
                                        tint = animatedColor,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    if (isSelected) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Box(
                                            modifier = Modifier
                                                .width(16.dp)
                                                .height(2.dp)
                                                .clip(RoundedCornerShape(1.dp))
                                                .background(
                                                    Brush.horizontalGradient(
                                                        listOf(AccentBlue, AccentCyan)
                                                    )
                                                )
                                        )
                                    }
                                }
                            },
                            label = {
                                Text(
                                    text = item.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = animatedColor,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color.Transparent
                            )
                        )
                    }
                }
            }
        }
    }
}
