package com.aiuhdhub.app.data

import com.aiuhdhub.app.R

data class AiTool(
    val id: String,
    val name: String,
    val developer: String,
    val description: String,
    val features: List<String>,
    val downloadUrl: String,
    val githubUrl: String,
    val sourceType: SourceType,
    val category: ToolCategory,
    val supportsImage: Boolean = true,
    val supportsVideo: Boolean = false,
    val aiModels: List<String> = emptyList(),
    val engineType: String = "NCNN/Vulkan",
    val rating: Float = 4.5f,
    val isOffline: Boolean = true
)

enum class SourceType {
    GITHUB_RELEASE,
    PLAY_STORE,
    FDROID
}

enum class ToolCategory {
    IMAGE_UPSCALER,
    VIDEO_UPSCALER,
    ALL_IN_ONE,
    ENHANCEMENT
}

object ToolsRepository {

    fun getAllTools(): List<AiTool> = listOf(
        AiTool(
            id = "realsr_ncnn",
            name = "RealSR-NCNN-Android",
            developer = "tumuyan",
            description = "GUI shell untuk pelbagai model NCNN super-resolution. Menyokong RealSR, Real-ESRGAN, Waifu2x, RealCUGAN, SRMD, dan Anime4K. Sangat fleksibel dengan sokongan import model tersuai.",
            features = listOf(
                "Multi-model: RealSR, Real-ESRGAN, Waifu2x, RealCUGAN, SRMD, Anime4K",
                "Import model tersuai dari SD Card",
                "CLI & GUI mode",
                "Pecutan Vulkan GPU",
                "Upscale sehingga 4x",
                "Sokongan batch processing",
                "Optimized untuk Dimensity/Snapdragon"
            ),
            downloadUrl = "https://github.com/tumuyan/RealSR-NCNN-Android/releases",
            githubUrl = "https://github.com/tumuyan/RealSR-NCNN-Android",
            sourceType = SourceType.GITHUB_RELEASE,
            category = ToolCategory.IMAGE_UPSCALER,
            supportsImage = true,
            supportsVideo = false,
            aiModels = listOf("RealSR", "Real-ESRGAN", "Waifu2x", "RealCUGAN", "SRMD", "Anime4K"),
            engineType = "NCNN + Vulkan",
            rating = 4.7f
        ),
        AiTool(
            id = "image_toolbox",
            name = "Image Toolbox",
            developer = "T8RIN",
            description = "Aplikasi penyuntingan imej all-in-one open-source yang sangat lengkap. Termasuk AI Toolkit dengan upscaling, denoising, colorization, dan banyak lagi. 310+ filter tersedia.",
            features = listOf(
                "AI Upscaling (Real-ESRGAN)",
                "AI Denoising & Colorization",
                "310+ filter imej",
                "Background removal (AI & manual)",
                "OCR (text extraction)",
                "Batch processing",
                "Format: HEIF, AVIF, WEBP, JPEG, PNG",
                "EXIF data editing",
                "PDF creation",
                "File encryption/decryption"
            ),
            downloadUrl = "https://github.com/T8RIN/ImageToolbox/releases",
            githubUrl = "https://github.com/T8RIN/ImageToolbox",
            sourceType = SourceType.GITHUB_RELEASE,
            category = ToolCategory.ALL_IN_ONE,
            supportsImage = true,
            supportsVideo = false,
            aiModels = listOf("Real-ESRGAN", "Custom AI Models"),
            engineType = "Android ML",
            rating = 4.8f
        ),
        AiTool(
            id = "upscaler_egeoz",
            name = "Upscaler",
            developer = "egeoz",
            description = "Fork SuperImage yang aktif dikekalkan. Menggunakan MNN deep learning framework dan Real-ESRGAN untuk upscale imej secara lokal menggunakan GPU peranti.",
            features = listOf(
                "Real-ESRGAN model",
                "GPU acceleration via MNN",
                "2x dan 4x upscaling",
                "100% offline processing",
                "Material Design UI",
                "Ringan dan pantas"
            ),
            downloadUrl = "https://github.com/egeoz/Upscaler/releases",
            githubUrl = "https://github.com/egeoz/Upscaler",
            sourceType = SourceType.GITHUB_RELEASE,
            category = ToolCategory.IMAGE_UPSCALER,
            supportsImage = true,
            supportsVideo = false,
            aiModels = listOf("Real-ESRGAN"),
            engineType = "MNN (Alibaba)",
            rating = 4.4f
        ),
        AiTool(
            id = "waifu2x_ncnn",
            name = "Waifu2x NCNN",
            developer = "Archie Meng",
            description = "Image upscaler menggunakan pecutan GPU lokal. Menyokong pelbagai model termasuk CUNet, UpConv-Photo, UpConv-Anime, dan RealCUGAN. Tiada data keluar dari peranti.",
            features = listOf(
                "Multi-model: CUNet, UpConv-Photo, UpConv-Anime, RealCUGAN",
                "GPU-accelerated (Vulkan)",
                "100% private - tiada upload",
                "Fallback ke CPU mode",
                "Advanced settings tersembunyi",
                "Denoise + Upscale serentak"
            ),
            downloadUrl = "https://play.google.com/store/apps/details?id=net.chikami.waifu2xncnn",
            githubUrl = "",
            sourceType = SourceType.PLAY_STORE,
            category = ToolCategory.IMAGE_UPSCALER,
            supportsImage = true,
            supportsVideo = false,
            aiModels = listOf("Waifu2x-CUNet", "UpConv-Photo", "UpConv-Anime", "RealCUGAN"),
            engineType = "NCNN + Vulkan",
            rating = 4.5f
        ),
        AiTool(
            id = "realcugan_ncnn",
            name = "RealCUGAN-NCNN-Android",
            developer = "nihui",
            description = "Implementasi Android bagi RealCUGAN menggunakan ncnn dan Vulkan. Khas untuk upscaling imej anime/ilustrasi dengan kualiti UHD yang sangat tinggi.",
            features = listOf(
                "RealCUGAN model khusus anime",
                "Vulkan GPU acceleration",
                "Multiple denoise level",
                "2x, 3x, 4x upscaling",
                "Optimized untuk mobile GPU",
                "Hasil UHD berkualiti tinggi"
            ),
            downloadUrl = "https://github.com/nihui/realcugan-ncnn-vulkan/releases",
            githubUrl = "https://github.com/nihui/realcugan-ncnn-vulkan",
            sourceType = SourceType.GITHUB_RELEASE,
            category = ToolCategory.IMAGE_UPSCALER,
            supportsImage = true,
            supportsVideo = false,
            aiModels = listOf("RealCUGAN"),
            engineType = "NCNN + Vulkan",
            rating = 4.6f
        ),
        AiTool(
            id = "realesrgan_ncnn",
            name = "Real-ESRGAN-NCNN-Vulkan",
            developer = "nihui",
            description = "Implementasi portable Real-ESRGAN menggunakan ncnn. Model terbaik untuk upscaling foto sebenar ke kualiti UHD. Boleh digunakan via Termux CLI.",
            features = listOf(
                "Real-ESRGAN x4plus model",
                "AnimeVideo model tersedia",
                "Vulkan GPU acceleration",
                "CLI-based (sesuai Termux)",
                "Cross-platform binary",
                "Upscale sehingga 4x UHD"
            ),
            downloadUrl = "https://github.com/xinntao/Real-ESRGAN-ncnn-vulkan/releases",
            githubUrl = "https://github.com/xinntao/Real-ESRGAN-ncnn-vulkan",
            sourceType = SourceType.GITHUB_RELEASE,
            category = ToolCategory.IMAGE_UPSCALER,
            supportsImage = true,
            supportsVideo = true,
            aiModels = listOf("Real-ESRGAN x4plus", "RealESRGAN-AnimeVideo"),
            engineType = "NCNN + Vulkan",
            rating = 4.8f
        ),
        AiTool(
            id = "anime4k",
            name = "Anime4K",
            developer = "bloc97",
            description = "Algoritma upscaling real-time yang sangat pantas. Direka untuk anime/video dengan GPU shader. Boleh digunakan dalam mpv player untuk upscale video secara real-time.",
            features = listOf(
                "Real-time upscaling",
                "GPU shader-based",
                "Sangat ringan dan pantas",
                "Sesuai untuk video anime",
                "Integrasi mpv player",
                "Mode: A, B, C (berbeza kualiti)"
            ),
            downloadUrl = "https://github.com/bloc97/Anime4K/releases",
            githubUrl = "https://github.com/bloc97/Anime4K",
            sourceType = SourceType.GITHUB_RELEASE,
            category = ToolCategory.VIDEO_UPSCALER,
            supportsImage = false,
            supportsVideo = true,
            aiModels = listOf("Anime4K Mode A", "Anime4K Mode B", "Anime4K Mode C"),
            engineType = "GLSL Shader",
            rating = 4.6f
        )
    )

    fun getToolsByCategory(category: ToolCategory): List<AiTool> =
        getAllTools().filter { it.category == category }

    fun getImageTools(): List<AiTool> =
        getAllTools().filter { it.supportsImage }

    fun getVideoTools(): List<AiTool> =
        getAllTools().filter { it.supportsVideo }
}
