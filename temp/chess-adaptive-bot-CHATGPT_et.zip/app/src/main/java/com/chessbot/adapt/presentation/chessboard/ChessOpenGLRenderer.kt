package com.chessbot.adapt.presentation.chessboard

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.chessbot.adapt.domain.model.Board
import com.chessbot.adapt.domain.model.Color
import com.chessbot.adapt.domain.model.Move
import com.chessbot.adapt.domain.model.Piece
import com.chessbot.adapt.domain.model.PieceType
import com.chessbot.adapt.domain.model.Square
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt

internal data class ChessOpenGLScene(
    val board: Board? = null,
    val selectedSquare: Square? = null,
    val validMoves: List<Move> = emptyList(),
    val lastMove: Move? = null,
    val isCheck: Boolean = false,
    val checkColor: Color? = null,
    val playerColor: Color = Color.WHITE,
    val selectedLift: Float = 0f,
    val animatedMove: Move? = null,
    val animationProgress: Float = 1f
)

/**
 * Renderer OpenGL ES sebenar. Papan dan semua bidak ialah mesh berindeks dengan normal,
 * depth buffer, pencahayaan diffuse/specular dan perspektif kamera.
 */
internal class ChessOpenGLRenderer : GLSurfaceView.Renderer {
    @Volatile private var cameraTheta = PI.toFloat() * 1.2f
    @Volatile private var cameraPhi = DEFAULT_CAMERA_PHI
    @Volatile private var viewportWidth = 1
    @Volatile private var viewportHeight = 1

    private var scene = ChessOpenGLScene()
    private var lastPlayerColor = Color.WHITE

    private var program = 0
    private var positionLocation = -1
    private var normalLocation = -1
    private var mvpLocation = -1
    private var modelLocation = -1
    private var colorLocation = -1
    private var lightLocation = -1
    private var cameraLocation = -1
    private var shininessLocation = -1

    private lateinit var cube: GlMesh
    private lateinit var disc: GlMesh
    private lateinit var ring: GlMesh
    private val pieceMeshes = mutableMapOf<PieceType, GlMesh>()

    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val viewProjection = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    fun updateScene(updated: ChessOpenGLScene) {
        scene = updated
        if (updated.playerColor != lastPlayerColor) {
            lastPlayerColor = updated.playerColor
            cameraTheta = initialTheta(updated.playerColor)
            cameraPhi = DEFAULT_CAMERA_PHI
        }
    }

    fun orbit(deltaX: Float, deltaY: Float) {
        cameraTheta -= deltaX * 0.0062f
        cameraPhi = (cameraPhi - deltaY * 0.0021f).coerceIn(0.76f, 1.02f)
    }

    fun pickSquare(touchX: Float, touchY: Float): Square? {
        val width = viewportWidth.toFloat().coerceAtLeast(1f)
        val height = viewportHeight.toFloat().coerceAtLeast(1f)
        val eye = cameraPosition(cameraTheta, cameraPhi)
        val forward = (GlVec3.ZERO - eye).normalized()
        val right = forward.cross(GlVec3.UP).normalized()
        val cameraUp = right.cross(forward).normalized()
        val tanHalfFov = kotlin.math.tan(FIELD_OF_VIEW * PI.toFloat() / 360f)
        val ndcX = touchX / width * 2f - 1f
        val ndcY = 1f - touchY / height * 2f
        val aspect = width / height
        val ray = (
            forward +
                right * (ndcX * tanHalfFov * aspect) +
                cameraUp * (ndcY * tanHalfFov)
            ).normalized()

        if (kotlin.math.abs(ray.y) < 0.0001f) return null
        val distance = (BOARD_TOP - eye.y) / ray.y
        if (distance <= 0f) return null
        val hit = eye + ray * distance
        val file = floor(hit.x + 4f).toInt()
        val rank = floor(hit.z + 4f).toInt()
        return if (file in 0..7 && rank in 0..7) Square(file, rank) else null
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.035f, 0.043f, 0.052f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDisable(GLES20.GL_CULL_FACE)

        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        if (program == 0) return
        positionLocation = GLES20.glGetAttribLocation(program, "aPosition")
        normalLocation = GLES20.glGetAttribLocation(program, "aNormal")
        mvpLocation = GLES20.glGetUniformLocation(program, "uMvp")
        modelLocation = GLES20.glGetUniformLocation(program, "uModel")
        colorLocation = GLES20.glGetUniformLocation(program, "uColor")
        lightLocation = GLES20.glGetUniformLocation(program, "uLightPosition")
        cameraLocation = GLES20.glGetUniformLocation(program, "uCameraPosition")
        shininessLocation = GLES20.glGetUniformLocation(program, "uShininess")

        cube = GlMesh(ChessOpenGLMeshFactory.cube())
        disc = GlMesh(ChessOpenGLMeshFactory.disc())
        ring = GlMesh(ChessOpenGLMeshFactory.ring())
        PieceType.entries.forEach { pieceMeshes[it] = GlMesh(ChessOpenGLMeshFactory.piece(it)) }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width.coerceAtLeast(1)
        viewportHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, viewportWidth, viewportHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (program == 0) return

        val eye = cameraPosition(cameraTheta, cameraPhi)
        Matrix.setLookAtM(
            view, 0,
            eye.x, eye.y, eye.z,
            0f, 0.20f, 0f,
            0f, 1f, 0f
        )
        Matrix.perspectiveM(
            projection,
            0,
            FIELD_OF_VIEW,
            viewportWidth.toFloat() / viewportHeight.toFloat().coerceAtLeast(1f),
            0.5f,
            40f
        )
        Matrix.multiplyMM(viewProjection, 0, projection, 0, view, 0)

        GLES20.glUseProgram(program)
        GLES20.glUniform3f(lightLocation, -4.8f, 9.5f, -3.5f)
        GLES20.glUniform3f(cameraLocation, eye.x, eye.y, eye.z)
        drawBoard()
        drawPieces()
    }

    private fun drawBoard() {
        drawCube(0f, -0.055f, 0f, 9.45f, 0.34f, 9.45f, WALNUT_DARK, 28f)
        drawCube(0f, 0.10f, -4.28f, 9.20f, 0.22f, 0.45f, WALNUT_LIGHT, 38f)
        drawCube(0f, 0.10f, 4.28f, 9.20f, 0.22f, 0.45f, WALNUT_LIGHT, 38f)
        drawCube(-4.28f, 0.10f, 0f, 0.45f, 0.22f, 8.76f, WALNUT_LIGHT, 38f)
        drawCube(4.28f, 0.10f, 0f, 0.45f, 0.22f, 8.76f, WALNUT_LIGHT, 38f)

        for (rank in 0..7) for (file in 0..7) {
            val color = if ((file + rank) % 2 == 0) MAPLE else MAHOGANY
            drawCube(squareX(file), 0.14f, squareZ(rank), 0.98f, 0.16f, 0.98f, color, 24f)
        }

        GLES20.glDepthMask(false)
        scene.lastMove?.let { move ->
            drawSquareOverlay(move.fromSquare, LAST_MOVE)
            drawSquareOverlay(move.toSquare, LAST_MOVE)
        }
        scene.selectedSquare?.let { drawSquareOverlay(it, SELECTED) }

        val checkedColor = scene.checkColor
        if (scene.isCheck && checkedColor != null) {
            findKingSquare(scene.board, checkedColor)?.let { drawSquareOverlay(it, CHECK) }
        }

        val validTargets = scene.validMoves.groupBy { it.toSquare }
        validTargets.forEach { (square, moves) ->
            val capture = moves.any { it.isCapture }
            if (capture) {
                drawFlatMesh(ring, squareX(square.file), BOARD_TOP + 0.025f, squareZ(square.rank), 0.34f, CAPTURE)
            } else {
                drawFlatMesh(disc, squareX(square.file), BOARD_TOP + 0.025f, squareZ(square.rank), 0.11f, VALID)
            }
        }
        GLES20.glDepthMask(true)
    }

    private fun drawPieces() {
        val board = scene.board ?: return
        val renderPieces = ArrayList<PiecePlacement>(32)
        val animated = scene.animatedMove?.takeIf { scene.animationProgress < 1f }
        val animatedDestination = animated?.toSquare
        val castleRank = animated?.let { if (it.piece.color == Color.WHITE) 0 else 7 }
        val castleRookDestination = when {
            animated?.isCastleKingSide == true -> Square(5, castleRank ?: 0)
            animated?.isCastleQueenSide == true -> Square(3, castleRank ?: 0)
            else -> null
        }

        for (rank in 0..7) for (file in 0..7) {
            val square = Square(file, rank)
            val piece = board.squares[rank][file] ?: continue
            if (square == animatedDestination || square == castleRookDestination) continue
            val lift = if (square == scene.selectedSquare) scene.selectedLift else 0f
            renderPieces += PiecePlacement(piece, squareX(file), squareZ(rank), lift)
        }

        if (animated != null) {
            val progress = scene.animationProgress.coerceIn(0f, 1f)
            val movingPiece = board.squares[animated.toSquare.rank][animated.toSquare.file]
                ?: animated.piece
            val fromX = squareX(animated.fromSquare.file)
            val fromZ = squareZ(animated.fromSquare.rank)
            val toX = squareX(animated.toSquare.file)
            val toZ = squareZ(animated.toSquare.rank)
            renderPieces += PiecePlacement(
                movingPiece,
                fromX + (toX - fromX) * progress,
                fromZ + (toZ - fromZ) * progress,
                sin(progress * PI.toFloat()) * 0.56f
            )

            if (animated.isCastling && castleRank != null && castleRookDestination != null) {
                val rook = board.squares[castleRank][castleRookDestination.file]
                if (rook?.type == PieceType.ROOK) {
                    val rookFromFile = if (animated.isCastleKingSide) 7 else 0
                    val rookProgress = ((progress - 0.42f) / 0.58f).coerceIn(0f, 1f)
                    renderPieces += PiecePlacement(
                        rook,
                        squareX(rookFromFile) +
                            (squareX(castleRookDestination.file) - squareX(rookFromFile)) * rookProgress,
                        squareZ(castleRank),
                        sin(rookProgress * PI.toFloat()) * 0.24f
                    )
                }
            }
        }

        GLES20.glDepthMask(false)
        renderPieces.forEach { placement ->
            val shadowScale = (0.33f - placement.lift * 0.07f).coerceAtLeast(0.20f)
            drawFlatMesh(
                disc,
                placement.x + 0.055f,
                BOARD_TOP + 0.012f,
                placement.z + 0.075f,
                shadowScale,
                SHADOW
            )
        }
        GLES20.glDepthMask(true)

        renderPieces.sortedByDescending { cameraDistanceSquared(it.x, it.z) }.forEach { placement ->
            drawPiece(placement)
        }
    }

    private fun drawPiece(placement: PiecePlacement) {
        val mesh = pieceMeshes[placement.piece.type] ?: return
        val rotation = if (placement.piece.color == Color.BLACK) 180f else 0f
        val color = if (placement.piece.color == Color.WHITE) IVORY else EBONY
        setModel(
            placement.x,
            BOARD_TOP + placement.lift,
            placement.z,
            0.90f,
            0.90f,
            0.90f,
            rotation
        )
        draw(mesh, color, if (placement.piece.color == Color.WHITE) 72f else 54f)
    }

    private fun drawSquareOverlay(square: Square, color: FloatArray) {
        drawCube(
            squareX(square.file),
            BOARD_TOP + 0.014f,
            squareZ(square.rank),
            0.93f,
            0.022f,
            0.93f,
            color,
            10f
        )
    }

    private fun drawFlatMesh(
        mesh: GlMesh,
        x: Float,
        y: Float,
        z: Float,
        scale: Float,
        color: FloatArray
    ) {
        setModel(x, y, z, scale, 1f, scale, 0f)
        draw(mesh, color, 4f)
    }

    private fun drawCube(
        x: Float,
        y: Float,
        z: Float,
        scaleX: Float,
        scaleY: Float,
        scaleZ: Float,
        color: FloatArray,
        shininess: Float
    ) {
        setModel(x, y, z, scaleX, scaleY, scaleZ, 0f)
        draw(cube, color, shininess)
    }

    private fun setModel(
        x: Float,
        y: Float,
        z: Float,
        scaleX: Float,
        scaleY: Float,
        scaleZ: Float,
        rotationY: Float
    ) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        if (rotationY != 0f) Matrix.rotateM(model, 0, rotationY, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, scaleX, scaleY, scaleZ)
    }

    private fun draw(mesh: GlMesh, color: FloatArray, shininess: Float) {
        Matrix.multiplyMM(mvp, 0, viewProjection, 0, model, 0)
        GLES20.glUniformMatrix4fv(mvpLocation, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(modelLocation, 1, false, model, 0)
        GLES20.glUniform4fv(colorLocation, 1, color, 0)
        GLES20.glUniform1f(shininessLocation, shininess)
        mesh.draw(positionLocation, normalLocation)
    }

    private fun cameraDistanceSquared(x: Float, z: Float): Float {
        val eye = cameraPosition(cameraTheta, cameraPhi)
        val dx = eye.x - x
        val dz = eye.z - z
        return dx * dx + dz * dz
    }

    private fun findKingSquare(board: Board?, color: Color): Square? {
        board ?: return null
        for (rank in 0..7) for (file in 0..7) {
            val piece = board.squares[rank][file]
            if (piece?.type == PieceType.KING && piece.color == color) return Square(file, rank)
        }
        return null
    }

    private fun createProgram(vertexSource: String, fragmentSource: String): Int {
        val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        if (vertexShader == 0 || fragmentShader == 0) return 0
        val result = GLES20.glCreateProgram()
        GLES20.glAttachShader(result, vertexShader)
        GLES20.glAttachShader(result, fragmentShader)
        GLES20.glLinkProgram(result)
        val linked = IntArray(1)
        GLES20.glGetProgramiv(result, GLES20.GL_LINK_STATUS, linked, 0)
        if (linked[0] == 0) {
            Log.e(TAG, "OpenGL program link failed: ${GLES20.glGetProgramInfoLog(result)}")
            GLES20.glDeleteProgram(result)
            return 0
        }
        GLES20.glDeleteShader(vertexShader)
        GLES20.glDeleteShader(fragmentShader)
        return result
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            Log.e(TAG, "OpenGL shader compile failed: ${GLES20.glGetShaderInfoLog(shader)}")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    private data class PiecePlacement(
        val piece: Piece,
        val x: Float,
        val z: Float,
        val lift: Float
    )

    private class GlMesh(data: GlMeshData) {
        private val vertexBuffer: FloatBuffer = ByteBuffer
            .allocateDirect(data.vertices.size * Float.SIZE_BYTES)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply { put(data.vertices); position(0) }
        private val indexBuffer: ShortBuffer = ByteBuffer
            .allocateDirect(data.indices.size * Short.SIZE_BYTES)
            .order(ByteOrder.nativeOrder())
            .asShortBuffer()
            .apply { put(data.indices); position(0) }
        private val indexCount = data.indices.size

        fun draw(positionLocation: Int, normalLocation: Int) {
            vertexBuffer.position(0)
            GLES20.glVertexAttribPointer(
                positionLocation,
                3,
                GLES20.GL_FLOAT,
                false,
                STRIDE_BYTES,
                vertexBuffer
            )
            GLES20.glEnableVertexAttribArray(positionLocation)
            vertexBuffer.position(3)
            GLES20.glVertexAttribPointer(
                normalLocation,
                3,
                GLES20.GL_FLOAT,
                false,
                STRIDE_BYTES,
                vertexBuffer
            )
            GLES20.glEnableVertexAttribArray(normalLocation)
            indexBuffer.position(0)
            GLES20.glDrawElements(
                GLES20.GL_TRIANGLES,
                indexCount,
                GLES20.GL_UNSIGNED_SHORT,
                indexBuffer
            )
        }

        companion object {
            private const val STRIDE_BYTES = 6 * Float.SIZE_BYTES
        }
    }

    companion object {
        private const val TAG = "ChessOpenGL"
        private const val FIELD_OF_VIEW = 45f
        private const val CAMERA_RADIUS = 12.8f
        private const val DEFAULT_CAMERA_PHI = 0.90f
        private const val BOARD_TOP = 0.23f

        private val MAPLE = color(0xE5, 0xC3, 0x8E, 0xFF)
        private val MAHOGANY = color(0x8F, 0x56, 0x28, 0xFF)
        private val WALNUT_DARK = color(0x25, 0x12, 0x08, 0xFF)
        private val WALNUT_LIGHT = color(0x4B, 0x28, 0x0D, 0xFF)
        private val IVORY = color(0xF0, 0xE5, 0xCB, 0xFF)
        private val EBONY = color(0x24, 0x23, 0x21, 0xFF)
        private val LAST_MOVE = color(0xE2, 0xC0, 0x78, 0x72)
        private val SELECTED = color(0x76, 0xC8, 0xA5, 0xA0)
        private val CHECK = color(0xE0, 0x71, 0x71, 0xA8)
        private val VALID = color(0xE3, 0xC7, 0x8F, 0xD8)
        private val CAPTURE = color(0xE0, 0x71, 0x71, 0xE8)
        private val SHADOW = color(0x00, 0x00, 0x00, 0x48)

        private fun color(r: Int, g: Int, b: Int, a: Int) = floatArrayOf(
            r / 255f,
            g / 255f,
            b / 255f,
            a / 255f
        )

        private fun squareX(file: Int) = file - 3.5f
        private fun squareZ(rank: Int) = rank - 3.5f

        private fun initialTheta(playerColor: Color) = if (playerColor == Color.WHITE) {
            PI.toFloat() * 1.2f
        } else {
            PI.toFloat() * 0.2f
        }

        private fun cameraPosition(theta: Float, phi: Float) = GlVec3(
            CAMERA_RADIUS * sin(phi) * sin(theta),
            CAMERA_RADIUS * cos(phi),
            CAMERA_RADIUS * sin(phi) * cos(theta)
        )

        private const val VERTEX_SHADER = """
            uniform mat4 uMvp;
            uniform mat4 uModel;
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            varying vec3 vWorldPosition;
            varying vec3 vNormal;

            void main() {
                vec4 worldPosition = uModel * vec4(aPosition, 1.0);
                vWorldPosition = worldPosition.xyz;
                vNormal = normalize(mat3(uModel) * aNormal);
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec4 uColor;
            uniform vec3 uLightPosition;
            uniform vec3 uCameraPosition;
            uniform float uShininess;
            varying vec3 vWorldPosition;
            varying vec3 vNormal;

            void main() {
                vec3 normal = normalize(vNormal);
                vec3 lightDirection = normalize(uLightPosition - vWorldPosition);
                vec3 viewDirection = normalize(uCameraPosition - vWorldPosition);
                vec3 halfDirection = normalize(lightDirection + viewDirection);
                float diffuse = max(dot(normal, lightDirection), 0.0);
                float specular = pow(max(dot(normal, halfDirection), 0.0), uShininess);
                float rim = pow(1.0 - max(dot(normal, viewDirection), 0.0), 2.0);
                float light = 0.30 + diffuse * 0.68;
                vec3 litColor = uColor.rgb * light + vec3(specular * 0.42) + uColor.rgb * rim * 0.10;
                gl_FragColor = vec4(litColor, uColor.a);
            }
        """
    }
}

private data class GlVec3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(other: GlVec3) = GlVec3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: GlVec3) = GlVec3(x - other.x, y - other.y, z - other.z)
    operator fun times(scale: Float) = GlVec3(x * scale, y * scale, z * scale)
    fun cross(other: GlVec3) = GlVec3(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x
    )
    fun normalized(): GlVec3 {
        val length = sqrt(x * x + y * y + z * z).coerceAtLeast(0.0001f)
        return GlVec3(x / length, y / length, z / length)
    }

    companion object {
        val ZERO = GlVec3(0f, 0f, 0f)
        val UP = GlVec3(0f, 1f, 0f)
    }
}
