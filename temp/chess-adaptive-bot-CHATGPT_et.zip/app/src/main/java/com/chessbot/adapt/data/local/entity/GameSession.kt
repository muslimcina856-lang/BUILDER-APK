package com.chessbot.adapt.data.local.entity

import androidx.room.*

@Entity(
    tableName = "game_sessions",
    foreignKeys = [ForeignKey(
        entity    = PlayerProfile::class,
        parentColumns = ["id"],
        childColumns  = ["player_id"],
        onDelete  = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["player_id"])]
)
data class GameSession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    @ColumnInfo(name = "player_id")       val playerId: Long,
    @ColumnInfo(name = "player_color")    val playerColor: String,
    val result: String,
    @ColumnInfo(name = "bot_level_start") val botLevelStart: Int,
    @ColumnInfo(name = "bot_level_end")   val botLevelEnd: Int,
    @ColumnInfo(name = "total_moves")     val totalMoves: Int = 0,
    @ColumnInfo(name = "opening_used")    val openingUsed: String? = null,
    @ColumnInfo(name = "started_at")      val startedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "ended_at")        val endedAt: Long? = null
)
