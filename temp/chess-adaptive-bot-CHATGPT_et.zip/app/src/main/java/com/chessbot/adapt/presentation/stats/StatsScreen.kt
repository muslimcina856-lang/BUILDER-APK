package com.chessbot.adapt.presentation.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chessbot.adapt.data.local.entity.PlayerProfile

@Composable
fun StatsScreen(
    player: PlayerProfile?,
    botLevel: Int,
    learnedPatterns: Int,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize().background(Color(0xFF0D0F12))
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(22.dp))
        Text("Prestasi", color = Color(0xFFF3EEE4), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Kemajuan kamu menentang bot adaptif.", color = Color(0xFFA6A39C), fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))

        if (player == null) {
            CircularProgressIndicator(color = Color(0xFFD8B477))
            return@Column
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Permainan", player.totalGames.toString(), Modifier.weight(1f))
            StatCard("Kadar menang", "${winRate(player)}%", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Level bot", botLevel.toString(), Modifier.weight(1f), Color(0xFFD8B477))
            StatCard("Corak dipelajari", learnedPatterns.toString(), Modifier.weight(1f), Color(0xFF76C8A5))
        }
        Spacer(Modifier.height(18.dp))

        Surface(color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("RINGKASAN", color = Color(0xFFD8B477), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                SummaryRow("Menang", player.wins, Color(0xFF76C8A5))
                SummaryRow("Kalah", player.losses, Color(0xFFE07171))
                SummaryRow("Seri", player.draws, Color(0xFFD8B477))
                HorizontalDivider(color = Color(0xFF292D33))
                Text(
                    "Rentak semasa: ${player.currentStreak} ${streakLabel(player.streakType)}",
                    color = Color(0xFFA6A39C),
                    fontSize = 12.sp
                )
                Text(
                    "Masa bermain: ${formatDuration(player.totalPlayTimeMs)}",
                    color = Color(0xFFA6A39C),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, accent: Color = Color(0xFFF3EEE4)) {
    Surface(modifier = modifier, color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(label, color = Color(0xFF858681), fontSize = 10.sp)
            Text(value, color = accent, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: Int, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xFFF3EEE4), fontSize = 13.sp)
        Text(value.toString(), color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

private fun winRate(player: PlayerProfile): Int =
    if (player.totalGames == 0) 0 else player.wins * 100 / player.totalGames

private fun streakLabel(type: String): String = when (type) {
    "WIN" -> "kemenangan"
    "LOSS" -> "kekalahan"
    "DRAW" -> "seri"
    else -> "permainan"
}

private fun formatDuration(milliseconds: Long): String {
    val minutes = milliseconds / 60_000
    return if (minutes < 60) "$minutes minit" else "${minutes / 60}j ${minutes % 60}m"
}
