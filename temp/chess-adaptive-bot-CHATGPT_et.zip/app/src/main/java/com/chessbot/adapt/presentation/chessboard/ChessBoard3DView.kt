package com.chessbot.adapt.presentation.chessboard

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.chessbot.adapt.domain.model.Board
import com.chessbot.adapt.domain.model.Color
import com.chessbot.adapt.domain.model.Move
import com.chessbot.adapt.domain.model.Square

@Composable
fun ChessBoard3DView(
    board: Board?,
    selectedSquare: Square?,
    validMoves: List<Move>,
    lastMove: Move?,
    isCheck: Boolean,
    checkColor: Color?,
    playerColor: Color,
    boardSize: Dp = 360.dp,
    onSquareTap: (Square) -> Unit,
    onMoveAnimationFinished: () -> Unit
) {
    val context = LocalContext.current
    val soundManager = remember(context) { ChessSoundManager(context) }
    val surfaceView = remember(context) { ChessOpenGLSurfaceView(context) }
    val latestSquareTap by rememberUpdatedState(onSquareTap)
    val latestAnimationFinished by rememberUpdatedState(onMoveAnimationFinished)

    DisposableEffect(surfaceView, soundManager) {
        surfaceView.onResume()
        onDispose {
            surfaceView.onPause()
            soundManager.release()
        }
    }

    val selectedLift by animateFloatAsState(
        targetValue = if (selectedSquare != null) 0.30f else 0f,
        animationSpec = spring(Spring.DampingRatioNoBouncy, Spring.StiffnessLow),
        label = "selectedPieceLift"
    )

    var animatedMove by remember { mutableStateOf<Move?>(null) }
    var animationProgress by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(lastMove) {
        lastMove ?: return@LaunchedEffect
        animatedMove = lastMove
        animationProgress = 0f
        soundManager.playLift()
        if (lastMove.isCapture) soundManager.playCapture()
        animate(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = MOVE_ANIMATION_DURATION_MS,
                easing = CubicBezierEasing(0.22f, 0.61f, 0.36f, 1f)
            )
        ) { value, _ -> animationProgress = value }
        soundManager.playPlace()
        animatedMove = null
        animationProgress = 1f
        latestAnimationFinished()
    }

    AndroidView(
        factory = { surfaceView },
        update = { view ->
            view.onSquareTap = { square -> latestSquareTap(square) }
            view.updateScene(
                board = board,
                selectedSquare = selectedSquare,
                validMoves = validMoves,
                lastMove = lastMove,
                isCheck = isCheck,
                checkColor = checkColor,
                playerColor = playerColor,
                selectedLift = selectedLift,
                animatedMove = animatedMove,
                animationProgress = animationProgress
            )
        },
        modifier = Modifier.size(boardSize)
    )
}

private const val MOVE_ANIMATION_DURATION_MS = 1_150
