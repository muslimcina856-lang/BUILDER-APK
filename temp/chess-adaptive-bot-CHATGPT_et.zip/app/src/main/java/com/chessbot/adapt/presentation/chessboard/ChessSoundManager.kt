package com.chessbot.adapt.presentation.chessboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Bunyi kayu ringkas yang diselaraskan dengan saat bidak diangkat dan mendarat. */
class ChessSoundManager(@Suppress("UNUSED_PARAMETER") context: Context) {

    private val sampleRate = 44_100
    private var liftTrack: AudioTrack? = null
    private var placeTrack: AudioTrack? = null
    private var captureTrack: AudioTrack? = null

    init {
        runCatching {
            liftTrack = buildTrack(generateLift())
            placeTrack = buildTrack(generatePlace())
            captureTrack = buildTrack(generateCapture())
        }
    }

    fun playLift() = play(liftTrack)
    fun playPlace() = play(placeTrack)
    fun playCapture() = play(captureTrack)

    fun release() {
        runCatching { liftTrack?.release() }
        runCatching { placeTrack?.release() }
        runCatching { captureTrack?.release() }
    }

    private fun play(track: AudioTrack?) = runCatching {
        track?.takeIf { it.state == AudioTrack.STATE_INITIALIZED }?.also {
            if (it.playState == AudioTrack.PLAYSTATE_PLAYING) it.stop()
            it.reloadStaticData()
            it.play()
        }
    }

    private fun buildTrack(samples: ShortArray): AudioTrack = AudioTrack.Builder()
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .setAudioFormat(
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
        )
        .setBufferSizeInBytes(samples.size * 2)
        .setTransferMode(AudioTrack.MODE_STATIC)
        .build()
        .also { it.write(samples, 0, samples.size) }

    private fun generateLift(): ShortArray = synthesize(durationMs = 70, seed = 41) { t, noise ->
        val touch = noise * exp(-85.0 * t) * 0.16
        val wood = sin(2.0 * PI * 470.0 * t) * exp(-48.0 * t) * 0.11
        touch + wood
    }

    private fun generatePlace(): ShortArray = synthesize(durationMs = 210, seed = 73) { t, noise ->
        val contact = if (t < 0.012) noise * exp(-210.0 * t) * 0.34 else 0.0
        val body = exp(-18.0 * t) * (
            sin(2.0 * PI * 235.0 * t) * 0.40 +
                sin(2.0 * PI * 410.0 * t) * 0.18 +
                sin(2.0 * PI * 690.0 * t) * 0.07
            )
        contact + body
    }

    private fun generateCapture(): ShortArray = synthesize(durationMs = 135, seed = 97) { t, noise ->
        val removal = noise * exp(-65.0 * t) * 0.25
        val lightWood = exp(-24.0 * t) * (
            sin(2.0 * PI * 290.0 * t) * 0.27 +
                sin(2.0 * PI * 520.0 * t) * 0.10
            )
        removal + lightWood
    }

    private fun synthesize(
        durationMs: Int,
        seed: Int,
        signal: (timeSeconds: Double, noise: Double) -> Double
    ): ShortArray {
        val random = Random(seed)
        return ShortArray(sampleRate * durationMs / 1_000) { index ->
            val time = index.toDouble() / sampleRate
            val noise = random.nextDouble() * 2.0 - 1.0
            (signal(time, noise) * 22_000.0).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()
        }
    }
}
