package com.chessbot.adapt.presentation.history

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chessbot.adapt.data.local.entity.GameSession
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    games: List<GameSession>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize().background(Color(0xFF0D0F12))
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(22.dp))
        Text("Sejarah Permainan", color = Color(0xFFF3EEE4), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Lihat bagaimana lawan kamu berkembang.", color = Color(0xFFA6A39C), fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))

        if (games.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada permainan direkodkan.", color = Color(0xFFA6A39C))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(games, key = { it.id }) { game -> GameHistoryCard(game) }
                item { Spacer(Modifier.height(12.dp)) }
            }
        }
    }
}

@Composable
private fun GameHistoryCard(game: GameSession) {
    val dateFormat = SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault())
    val resultColor = when (game.result) {
        "WIN" -> Color(0xFF76C8A5)
        "LOSS" -> Color(0xFFE07171)
        "DRAW" -> Color(0xFFD8B477)
        else -> Color(0xFF8E9AA8)
    }
    val resultLabel = when (game.result) {
        "WIN" -> "MENANG"
        "LOSS" -> "KALAH"
        "DRAW" -> "SERI"
        else -> "SEDANG MAIN"
    }

    Surface(color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(42.dp).clip(CircleShape)
                    .background(resultColor.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Text(resultLabel.first().toString(), color = resultColor, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(resultLabel, color = resultColor, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    game.openingUsed ?: "Corak sedang dianalisis",
                    color = Color(0xFFF3EEE4),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(dateFormat.format(Date(game.startedAt)), color = Color(0xFF858681), fontSize = 10.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Lv ${game.botLevelStart} → ${game.botLevelEnd}", color = Color(0xFFD8B477), fontSize = 11.sp)
                Text("${game.totalMoves} langkah", color = Color(0xFF858681), fontSize = 10.sp)
            }
        }
    }
}
