# ⚡ Gaming Tweaker (Flutter + Shizuku)

Aplikasi tweak Android **no-root** untuk gaming, menggunakan [Shizuku API](https://shizuku.rikka.app/). Build APK otomatis via GitHub Actions — tidak perlu install Flutter/Android Studio sendiri.

## ✨ 5 Fitur Inti

1. **Refresh Rate Switcher** — paksa layar ke 60/90/120/144 Hz
2. **Performance Mode Switcher** — Performa Maksimal / Seimbang / Hemat Baterai (via `cmd power set-fixed-performance-mode-enabled`, command resmi Android untuk ADPF)
3. **CPU & Thermal Monitor** — suhu baterai & beban CPU real-time
4. **Force-Stop Aplikasi** — bebasin RAM sebelum main game
5. **Bersihkan Cache Massal** — hapus cache banyak aplikasi sekaligus

Tema UI: dark premium dengan aksen biru elektrik & ungu, terinspirasi Samsung.com.

## ⚠️ WAJIB: Aplikasi Ini Butuh Shizuku

Aplikasi ini **tidak berfungsi tanpa Shizuku**. Shizuku memberi akses level ADB (Android Debug Bridge) ke aplikasi lain tanpa perlu root perangkat.

### Cara Setup Shizuku (sekali saja):

1. Install aplikasi **Shizuku** dari [Play Store](https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api) atau [GitHub](https://github.com/RikkaApps/Shizuku/releases).
2. Buka aplikasi Shizuku, ikuti salah satu metode aktivasi:
   - **Wireless debugging** (Android 11+, paling praktis): Settings → Developer Options → Wireless debugging → aktifkan, lalu ikuti instruksi pairing di aplikasi Shizuku.
   - **Via komputer (ADB)**: hubungkan HP ke PC, jalankan perintah `adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh` (instruksi lengkap ada di aplikasi Shizuku).
3. Setelah Shizuku berstatus **"Running"**, buka aplikasi **Gaming Tweaker** ini — banner status di atas akan berubah jadi hijau ("Shizuku Aktif") setelah kamu tap "Izinkan".
4. Shizuku **perlu diaktifkan ulang setiap restart HP** (kecuali di beberapa custom ROM yang mendukung auto-start). Ini adalah keterbatasan Shizuku sendiri, bukan aplikasi ini.

## 🚀 Cara Build APK via GitHub Actions (Tanpa Coding)

1. Buat repository baru di GitHub.
2. Upload semua file project ini ke repo:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Gaming Tweaker"
   git branch -M main
   git remote add origin https://github.com/USERNAME/NAMA-REPO.git
   git push -u origin main
   ```
3. Buka tab **Actions** — workflow **"Build APK"** otomatis jalan (~5-10 menit).
4. Ambil APK dari tab **Artifacts** (di run yang selesai) atau tab **Releases**.
5. Install `gaming-tweaker-arm64-v8a.apk` di HP (aktifkan "Install dari sumber tidak dikenal" jika diminta).

> Trigger manual: tab **Actions** → **"Build APK"** → **"Run workflow"**.

## 🛠️ Build Manual (Opsional)

```bash
flutter pub get
flutter pub run flutter_launcher_icons
flutter build apk --release
```

## 📂 Struktur Project

```
lib/
├── main.dart
├── theme/
│   └── app_theme.dart              # Warna & tema dark premium
├── services/
│   ├── shizuku_service.dart        # Wrapper inti komunikasi Shizuku
│   ├── refresh_rate_service.dart   # Fitur 1: refresh rate
│   ├── performance_mode_service.dart # Fitur 2: performance mode
│   ├── thermal_monitor_service.dart  # Fitur 3: CPU/thermal monitor
│   ├── app_management_service.dart   # Fitur 4 & 5: force-stop & clear cache
│   └── prefs_service.dart          # Simpan preferensi lokal
├── screens/
│   ├── home_screen.dart            # Layar utama (5 kartu fitur)
│   └── app_selection_screen.dart   # Pilih aplikasi untuk force-stop/clear cache
└── widgets/
    ├── shizuku_status_banner.dart  # Banner status Shizuku
    └── feature_card.dart           # Kartu fitur reusable
```

## ⚠️ Catatan Penting

- **Efek tiap fitur bisa berbeda-beda tergantung merk & versi Android HP kamu.** Command seperti `peak_refresh_rate` dan `cmd power set-fixed-performance-mode-enabled` adalah command level-AOSP yang didukung luas, tapi beberapa pabrikan (Samsung One UI, MIUI, ColorOS, dll) punya lapisan kontrol tambahan yang kadang meng-override setting ini.
- Fixed performance mode bisa membuat perangkat lebih cepat panas karena clock CPU/GPU dikunci di level tinggi — ini bukan bug, tapi konsekuensi yang memang diketahui dari mode ini (didokumentasikan resmi oleh Android Developers).
- Force-stop dan clear-cache **tidak bisa** dijalankan ke aplikasi sistem inti (Settings, System UI, Play Services, dll) — ini sengaja dibatasi di kode supaya HP tetap stabil.
- `applicationId` masih `com.farik.deczz` — ganti sebelum publish resmi.
- Package `shizuku_api` yang dipakai bersifat community-maintained (bukan dari tim Shizuku resmi) — cukup matang dan dipakai aplikasi Play Store lain, tapi tetap pantau update-nya secara berkala.

## 📦 Dependencies Utama

| Package | Kegunaan |
|---|---|
| `shizuku_api` | Komunikasi dengan Shizuku (cek izin, jalankan shell command) |
| `shared_preferences` | Simpan preferensi lokal (mode terakhir dipilih) |
| `google_fonts` & `animate_do` | Styling & animasi UI |
| `url_launcher` | Buka link panduan setup Shizuku |

---

Dibuat dengan Flutter 💙
