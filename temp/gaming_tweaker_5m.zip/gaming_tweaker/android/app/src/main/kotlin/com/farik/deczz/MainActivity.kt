package com.farik.deczz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
