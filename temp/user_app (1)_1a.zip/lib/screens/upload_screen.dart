import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:earl_builder/config.dart';
import 'package:earl_builder/i18n/app_strings.dart';
import 'package:earl_builder/services/api_service.dart';
import 'package:earl_builder/services/project_validator.dart';
import 'package:earl_builder/services/storage_service.dart';
import 'package:earl_builder/models/upload_history.dart';
import 'package:earl_builder/theme/app_theme.dart';

class UploadScreen extends StatefulWidget {
  final String deviceId;
  const UploadScreen({super.key, required this.deviceId});

  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  File? _selectedFile;
  String? _projectUrl;
  String? _detectedProjectType;
  String? _fileName;
  int _fileSize = 0;

  bool _isUploading = false;
  bool _isProcessing = false;
  double _uploadProgress = 0;

  // Status is tracked as a key + optional params, translated only at
  // display time in build() — this way changing the app language updates
  // in-progress status text too, not just the static labels.
  String _statusKey = 'upload_ready';
  String? _statusParam;
  bool _isDone = false;

  Future<void> _pickFile() async {
    if (_isUploading || _isProcessing) return;
    try {
      final result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['zip'],
        allowMultiple: false,
      );
      if (result == null || result.files.isEmpty) return;

      final path = result.files.single.path;
      if (path == null) return;
      final file = File(path);
      final size = await file.length();
      final name = result.files.single.name;

      if (size > AppConfig.maxDirectUploadBytes) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(tr(context, 'upload_link_required')),
            backgroundColor: AppColors.warning,
          ),
        );
        await _askForProjectLink(name, size);
        return;
      }

      setState(() {
        _selectedFile = file;
        _projectUrl = null;
        _detectedProjectType = null;
        _fileName = name;
        _fileSize = size;
        _uploadProgress = 0;
        _isUploading = false;
        _isProcessing = true;
        _statusKey = 'upload_validating';
        _statusParam = null;
        _isDone = false;
      });

      final projectType = await ProjectValidator.validateLocalZip(file);
      if (!mounted) return;
      setState(() {
        _detectedProjectType = projectType;
        _isProcessing = false;
        _statusKey = 'upload_ready_named';
        _statusParam = name;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _selectedFile = null;
        _projectUrl = null;
        _detectedProjectType = null;
        _fileName = null;
        _fileSize = 0;
        _isProcessing = false;
        _statusKey = 'upload_ready';
        _statusParam = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            e is ProjectValidationException
                ? tr(context, e.messageKey)
                : '${tr(context, 'upload_pick_failed')}: $e',
          ),
          backgroundColor: AppColors.error,
        ),
      );
    }
  }

  Future<void> _askForProjectLink(String originalName, int originalSize) async {
    final controller = TextEditingController();
    final link = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: Text(tr(dialogContext, 'upload_enter_project_link')),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.url,
          autocorrect: false,
          enableSuggestions: false,
          decoration: InputDecoration(
            labelText: tr(dialogContext, 'upload_link_label'),
            hintText: 'https://...',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(tr(dialogContext, 'common_cancel')),
          ),
          FilledButton(
            onPressed: () {
              final value = controller.text.trim();
              final uri = Uri.tryParse(value);
              if (uri == null ||
                  !const {'http', 'https'}.contains(uri.scheme.toLowerCase()) ||
                  uri.host.isEmpty) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  SnackBar(content: Text(tr(dialogContext, 'upload_invalid_link'))),
                );
                return;
              }
              Navigator.pop(dialogContext, value);
            },
            child: Text(tr(dialogContext, 'common_continue')),
          ),
        ],
      ),
    );
    controller.dispose();

    if (link == null || !mounted) return;
    setState(() {
      _selectedFile = null;
      _projectUrl = link;
      _detectedProjectType = null;
      _fileName = originalName;
      _fileSize = originalSize;
      _uploadProgress = 0;
      _isUploading = false;
      _isProcessing = false;
      _statusKey = 'upload_link_ready';
      _statusParam = null;
      _isDone = false;
    });
  }

  void _resetSelection() {
    setState(() {
      _selectedFile = null;
      _projectUrl = null;
      _detectedProjectType = null;
      _fileName = null;
      _fileSize = 0;
      _uploadProgress = 0;
      _isUploading = false;
      _isProcessing = false;
      _statusKey = 'upload_ready';
      _statusParam = null;
      _isDone = false;
    });
  }

  Future<void> _startUpload() async {
    if ((_selectedFile == null && _projectUrl == null) || _fileName == null) return;

    setState(() {
      _isUploading = true;
      _statusKey = 'upload_starting';
      _statusParam = null;
    });

    try {
      Map<String, dynamic> completeResult;
      if (_projectUrl != null) {
        setState(() {
          _statusKey = 'upload_validating_link';
          _uploadProgress = 0;
        });
        final projectType = await ProjectValidator.downloadAndValidateLink(
          _projectUrl!,
          onProgress: (received, total) {
            if (!mounted) return;
            setState(() {
              _uploadProgress = total != null && total > 0
                  ? (received / total).clamp(0, 1).toDouble()
                  : 0;
              _statusKey = 'upload_validating_link';
              _statusParam = total == null
                  ? _formatBytes(received)
                  : '${(_uploadProgress * 100).toStringAsFixed(0)}%';
            });
          },
        );
        _detectedProjectType = projectType;
        if (!mounted) return;
        setState(() {
          _isProcessing = true;
          _statusKey = 'upload_processing';
          _statusParam = null;
        });
        completeResult = await ApiService.submitProjectLink(
          deviceId: widget.deviceId,
          projectUrl: _projectUrl!,
          projectType: projectType,
        );
      } else {
        final file = _selectedFile!;
        _detectedProjectType ??= await ProjectValidator.validateLocalZip(file);
        completeResult = await ApiService.submitProjectFile(
          deviceId: widget.deviceId,
          filePath: file.path,
          filename: _fileName!,
          onSendProgress: (sent, total) {
            if (!mounted) return;
            setState(() {
              final uploadFinished = total > 0 && sent >= total;
              _uploadProgress = total > 0 ? sent / total : 0;
              _isProcessing = uploadFinished;
              _statusKey = uploadFinished
                  ? 'upload_processing'
                  : 'upload_uploading';
              _statusParam = uploadFinished
                  ? null
                  : '${(_uploadProgress * 100).toStringAsFixed(0)}%';
            });
          },
        );
      }

      await StorageService.addHistory(UploadHistory(
        fileName: _fileName!,
        fileSize: _fileSize,
        status: 'building',
        uniqueName: completeResult['unique_name']?.toString() ?? '',
        timestamp: DateTime.now().toIso8601String(),
        creditsUsed: 1,
        frameworkType: completeResult['detected_project_type']?.toString() ??
            _detectedProjectType ??
            '',
      ));

      if (!mounted) return;
      setState(() {
        _isUploading = false;
        _isProcessing = false;
        _statusKey = 'upload_success_queued';
        _statusParam = null;
        _isDone = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${tr(context, 'upload_success')}: ${completeResult['unique_name']}',
          ),
          backgroundColor: AppColors.success,
        ),
      );
    } catch (e) {
      String errorMsg = e is ProjectValidationException
          ? trStatic(context, e.messageKey)
          : e.toString();
      var creditsCharged = false;
      if (e is DioException) {
        final data = e.response?.data;
        if (data is Map) {
          creditsCharged = data['charged'] == true;
          if (data['error'] != null) errorMsg = data['error'].toString();
        } else if (e.type == DioExceptionType.connectionError ||
            e.type == DioExceptionType.connectionTimeout ||
            e.type == DioExceptionType.receiveTimeout) {
          errorMsg = trStatic(context, 'common_server_error');
        }
      }

      if (_fileName != null) {
        await StorageService.addHistory(UploadHistory(
          fileName: _fileName!,
          fileSize: _fileSize,
          status: 'failed',
          uniqueName: '',
          timestamp: DateTime.now().toIso8601String(),
          creditsUsed: creditsCharged ? 1 : 0,
        ));
      }

      if (!mounted) return;
      setState(() {
        _isUploading = false;
        _isProcessing = false;
        _statusKey = 'upload_failed_colon';
        _statusParam = errorMsg;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${tr(context, 'upload_failed_colon')} $errorMsg'),
          backgroundColor: AppColors.error,
        ),
      );
    }
  }

  String get _fileSizeFormatted {
    if (_fileSize < 1024) return '$_fileSize B';
    if (_fileSize < 1024 * 1024) return '${(_fileSize / 1024).toStringAsFixed(1)} KB';
    return '${(_fileSize / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    final hasSubmission = _selectedFile != null || _projectUrl != null;
    final statusText = _statusParam != null
        ? '${tr(context, _statusKey)} $_statusParam'
        : tr(context, _statusKey);

    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'upload_title'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            const SizedBox(height: AppSpacing.md),
            _DropZone(
              hasFile: hasSubmission,
              fileName: _fileName,
              disabled: _isUploading || _isProcessing,
              onTap: _pickFile,
            ),
            const SizedBox(height: AppSpacing.xl),
            if (hasSubmission) ...[
              _FileInfoCard(
                fileName: _fileName ?? '',
                fileSizeFormatted: _projectUrl == null
                    ? _fileSizeFormatted
                    : tr(context, 'upload_link_label'),
              ),
              const SizedBox(height: AppSpacing.lg),
            ],
            if (_isUploading || _isProcessing)
              _ProgressSection(
                isProcessing: _isProcessing,
                progress: _uploadProgress,
                statusText: statusText,
              ),
            if (_isUploading || _isProcessing)
              const SizedBox(height: AppSpacing.xl),
            _ActionButton(
              hasFile: hasSubmission,
              isUploading: _isUploading,
              isProcessing: _isProcessing,
              isDone: _isDone,
              onUpload: _startUpload,
              onReset: _resetSelection,
            ),
          ],
        ),
      ),
    );
  }
}

class _DropZone extends StatelessWidget {
  final bool hasFile;
  final String? fileName;
  final bool disabled;
  final VoidCallback onTap;

  const _DropZone({
    required this.hasFile,
    required this.fileName,
    required this.disabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: BorderRadius.circular(AppRadius.hero),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(
            vertical: AppSpacing.huge,
            horizontal: AppSpacing.xxl,
          ),
          decoration: BoxDecoration(
            color: AppColors.bgElevated,
            borderRadius: BorderRadius.circular(AppRadius.hero),
            border: Border.all(
              color: hasFile
                  ? AppColors.accent.withAlpha(80)
                  : AppColors.bgOverlay,
              width: hasFile ? 1.5 : 1,
            ),
          ),
          child: Column(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: hasFile
                      ? AppColors.accent.withAlpha(20)
                      : AppColors.bgRaised,
                  borderRadius: BorderRadius.circular(AppRadius.input),
                ),
                alignment: Alignment.center,
                child: Icon(
                  hasFile
                      ? Icons.check_rounded
                      : Icons.upload_file_rounded,
                  size: AppIcons.hero,
                  color: hasFile ? AppColors.accent : AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              Text(
                hasFile ? tr(context, 'upload_file_selected') : tr(context, 'upload_select_zip'),
                style: AppText.heading,
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                hasFile
                    ? (fileName ?? '')
                    : tr(context, 'upload_supports'),
                style: AppText.subtitle,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FileInfoCard extends StatelessWidget {
  final String fileName;
  final String fileSizeFormatted;

  const _FileInfoCard({
    required this.fileName,
    required this.fileSizeFormatted,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.accent.withAlpha(15),
              borderRadius: BorderRadius.circular(AppRadius.input),
            ),
            alignment: Alignment.center,
            child: const Icon(
              Icons.archive_rounded,
              size: AppIcons.md,
              color: AppColors.accent,
            ),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  fileName,
                  style: AppText.body.copyWith(fontWeight: FontWeight.w500),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 3),
                Text(
                  fileSizeFormatted,
                  style: AppText.caption,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProgressSection extends StatelessWidget {
  final bool isProcessing;
  final double progress;
  final String statusText;

  const _ProgressSection({
    required this.isProcessing,
    required this.progress,
    required this.statusText,
  });

  @override
  Widget build(BuildContext context) {
    final percent = (progress * 100).toStringAsFixed(0);
    return Container(
      padding: const EdgeInsets.all(AppSpacing.xl),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Column(
        children: [
          SizedBox(
            width: 64,
            height: 64,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 64,
                  height: 64,
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                    value: isProcessing ? null : progress,
                    strokeCap: StrokeCap.round,
                    valueColor: const AlwaysStoppedAnimation(
                      AppColors.accent,
                    ),
                    backgroundColor: AppColors.bgRaised,
                  ),
                ),
                if (!isProcessing)
                  Text(
                    '$percent%',
                    style: AppText.body.copyWith(
                      fontWeight: FontWeight.w700,
                      color: AppColors.accent,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          Text(
            statusText,
            style: AppText.heading.copyWith(fontSize: 15),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            isProcessing
                ? tr(context, 'upload_processing')
                : tr(context, 'upload_uploading'),
            style: AppText.caption,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final bool hasFile;
  final bool isUploading;
  final bool isProcessing;
  final bool isDone;
  final VoidCallback onUpload;
  final VoidCallback onReset;

  const _ActionButton({
    required this.hasFile,
    required this.isUploading,
    required this.isProcessing,
    required this.isDone,
    required this.onUpload,
    required this.onReset,
  });

  @override
  Widget build(BuildContext context) {
    if (isDone) {
      return Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(tr(context, 'upload_back')),
            ),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: ElevatedButton(
              onPressed: onReset,
              child: Text(tr(context, 'upload_submit_another')),
            ),
          ),
        ],
      );
    }
    final disabled = !hasFile || isUploading || isProcessing;
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: disabled ? null : onUpload,
        icon: isUploading || isProcessing
            ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: AppColors.onAccent,
                ),
              )
            : const Icon(Icons.cloud_upload_rounded, size: AppIcons.md),
        label: Text(
          hasFile ? tr(context, 'upload_submit_project') : tr(context, 'upload_select_file_first'),
        ),
      ),
    );
  }
}
