import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:dio/dio.dart';
import 'package:earl_builder/config.dart';
import 'package:path_provider/path_provider.dart';

class ProjectValidationException implements Exception {
  final String messageKey;
  const ProjectValidationException(this.messageKey);

  @override
  String toString() => messageKey;
}

class ProjectValidator {
  ProjectValidator._();

  static const _temporaryPrefix = 'earl_builder_link_';
  static const _temporarySuffix = '.part';
  static const _packageJsonLimit = 1024 * 1024;

  static final Dio _downloadClient = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(minutes: 10),
      followRedirects: true,
      maxRedirects: 5,
      validateStatus: (status) => status != null && status >= 200 && status < 300,
    ),
  );

  static Future<void> cleanupTemporaryDownloads() async {
    try {
      final directory = await getTemporaryDirectory();
      await for (final entity in directory.list(followLinks: false)) {
        if (entity is! File) continue;
        final name = entity.uri.pathSegments.last;
        if (name.startsWith(_temporaryPrefix) && name.endsWith(_temporarySuffix)) {
          try {
            await entity.delete();
          } catch (_) {}
        }
      }
    } catch (_) {
      // Cleanup is best-effort; every active download also has a finally block.
    }
  }

  static Future<String> validateLocalZip(File file) async {
    if (!await file.exists()) {
      throw const ProjectValidationException('upload_project_missing');
    }
    return _detectProjectType(file);
  }

  static Future<String> downloadAndValidateLink(
    String projectUrl, {
    void Function(int received, int? total)? onProgress,
  }) async {
    final uri = Uri.tryParse(projectUrl.trim());
    if (uri == null ||
        !const {'http', 'https'}.contains(uri.scheme.toLowerCase()) ||
        uri.host.isEmpty) {
      throw const ProjectValidationException('upload_invalid_link');
    }

    final temporaryDirectory = await getTemporaryDirectory();
    final temporaryFile = File(
      '${temporaryDirectory.path}/$_temporaryPrefix${DateTime.now().microsecondsSinceEpoch}$_temporarySuffix',
    );
    IOSink? sink;

    try {
      final method = uri.host.toLowerCase() == 'temp.sh' ? 'POST' : 'GET';
      final response = await _downloadClient.request<ResponseBody>(
        uri.toString(),
        options: Options(
          method: method,
          responseType: ResponseType.stream,
          headers: const {'Accept': 'application/zip, application/octet-stream, */*'},
        ),
      );

      final body = response.data;
      if (body == null) {
        throw const ProjectValidationException('upload_invalid_link');
      }

      final totalHeader = response.headers.value(Headers.contentLengthHeader);
      final total = totalHeader == null ? null : int.tryParse(totalHeader);
      if (total != null && total > AppConfig.maxValidationDownloadBytes) {
        throw const ProjectValidationException('upload_link_too_large');
      }

      sink = temporaryFile.openWrite(mode: FileMode.writeOnly);
      var received = 0;
      await for (final chunk in body.stream) {
        received += chunk.length;
        if (received > AppConfig.maxValidationDownloadBytes) {
          throw const ProjectValidationException('upload_link_too_large');
        }
        sink.add(chunk);
        onProgress?.call(received, total);
      }
      await sink.flush();
      await sink.close();
      sink = null;

      if (received == 0) {
        throw const ProjectValidationException('upload_invalid_project');
      }

      return await _detectProjectType(temporaryFile);
    } finally {
      if (sink != null) {
        try {
          await sink.close();
        } catch (_) {}
      }
      if (await temporaryFile.exists()) {
        try {
          await temporaryFile.delete();
        } catch (_) {}
      }
    }
  }

  static Future<String> _detectProjectType(File file) async {
    final input = InputFileStream(file.path);
    Archive? archive;
    try {
      archive = ZipDecoder().decodeStream(input);
      if (archive.isEmpty) {
        throw const ProjectValidationException('upload_invalid_project');
      }

      final entries = <String, ArchiveFile>{};
      for (final entry in archive) {
        final normalized = entry.name
            .replaceAll('\\', '/')
            .replaceFirst(RegExp(r'^\./+'), '')
            .replaceAll(RegExp(r'/+'), '/')
            .toLowerCase();
        if (normalized.isEmpty || normalized.startsWith('__macosx/')) continue;
        entries[normalized] = entry;
      }

      if (entries.isEmpty) {
        throw const ProjectValidationException('upload_invalid_project');
      }

      final roots = <String>{''};
      for (final path in entries.keys) {
        final parts = path.split('/');
        if (parts.length > 1) roots.add('${parts[0]}/');
        if (parts.length > 2) roots.add('${parts[0]}/${parts[1]}/');
      }

      final sortedRoots = roots.toList()
        ..sort((a, b) {
          final depthA = a.isEmpty ? 0 : a.split('/').length - 1;
          final depthB = b.isEmpty ? 0 : b.split('/').length - 1;
          final depthResult = depthA.compareTo(depthB);
          return depthResult != 0 ? depthResult : a.compareTo(b);
        });

      const markers = {
        'pubspec.yaml',
        'build.gradle',
        'build.gradle.kts',
        'settings.gradle',
        'settings.gradle.kts',
        'apktool.yml',
        'package.json',
        'config.xml',
        'capacitor.config.json',
        'capacitor.config.ts',
        'androidmanifest.xml',
      };

      String? projectRoot;
      for (final root in sortedRoots) {
        final hasMarker = markers.any((marker) => entries.containsKey('$root$marker'));
        final hasSmali = _hasDirectory(entries.keys, root, 'smali') ||
            _hasDirectory(entries.keys, root, 'smali_classes2') ||
            _hasDirectory(entries.keys, root, 'smali_classes3');
        if (hasMarker ||
            (entries.containsKey('${root}androidmanifest.xml') && hasSmali)) {
          projectRoot = root;
          break;
        }
      }

      if (projectRoot == null) {
        throw const ProjectValidationException('upload_invalid_project');
      }
      final root = projectRoot;

      bool exists(String name) => entries.containsKey('$root$name');
      final hasSmali = _hasDirectory(entries.keys, root, 'smali') ||
          _hasDirectory(entries.keys, root, 'smali_classes2') ||
          _hasDirectory(entries.keys, root, 'smali_classes3');

      if (exists('apktool.yml') || (exists('androidmanifest.xml') && hasSmali)) {
        return 'Smali';
      }
      if (exists('pubspec.yaml')) return 'Flutter';

      final packageEntry = entries['${root}package.json'];
      if (packageEntry != null && packageEntry.size <= _packageJsonLimit) {
        try {
          final bytes = packageEntry.readBytes();
          if (bytes != null) {
            final decoded = jsonDecode(utf8.decode(bytes, allowMalformed: true));
            if (decoded is Map) {
              final dependencies = <String>{};
              for (final key in const ['dependencies', 'devDependencies']) {
                final values = decoded[key];
                if (values is Map) {
                  dependencies.addAll(values.keys.map((item) => item.toString().toLowerCase()));
                }
              }
              final packageName = (decoded['name'] ?? '').toString().toLowerCase();
              final hasCapacitor = dependencies.contains('@capacitor/core') ||
                  dependencies.contains('@capacitor/android');
              final hasIonic = dependencies.any((name) => name.startsWith('@ionic')) ||
                  packageName.contains('ionic');

              if (hasIonic) return 'Ionic';
              if (hasCapacitor) return 'Capacitor';
              if (dependencies.contains('react-native')) return 'ReactNative';
              if (exists('config.xml')) return 'Cordova';
            }
          }
        } catch (_) {
          // Continue with structural markers when package.json is malformed.
        }
      }

      if (exists('capacitor.config.json') || exists('capacitor.config.ts')) {
        return 'Capacitor';
      }
      if (exists('config.xml')) return 'Cordova';
      if (exists('settings.gradle') ||
          exists('settings.gradle.kts') ||
          exists('build.gradle') ||
          exists('build.gradle.kts')) {
        return 'Native';
      }

      throw const ProjectValidationException('upload_invalid_project');
    } on ProjectValidationException {
      rethrow;
    } on ArchiveException {
      throw const ProjectValidationException('upload_invalid_project');
    } catch (_) {
      throw const ProjectValidationException('upload_invalid_project');
    } finally {
      for (final entry in archive ?? const <ArchiveFile>[]) {
        try {
          await entry.close();
        } catch (_) {}
      }
      try {
        input.closeSync();
      } catch (_) {}
    }
  }

  static bool _hasDirectory(Iterable<String> paths, String root, String directory) {
    final prefix = '$root$directory/';
    return paths.any((path) => path.startsWith(prefix));
  }
}
