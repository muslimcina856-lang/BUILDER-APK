package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditLogEntity
import com.example.data.model.UserEntity
import com.example.data.repository.XerazRepository
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.XerazEmerald
import com.example.ui.theme.XerazGold
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminPanelScreen(
    user: UserEntity?,
    auditLogs: List<AuditLogEntity>,
    onBack: () -> Unit,
    onAdminUpdateBalance: (Double) -> Unit
) {
    var newBalanceInput by remember { mutableStateOf(user?.balance?.toInt()?.toString() ?: "5000000") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("admin_panel_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = XerazGold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Admin Executive Panel",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = XerazGold
                        )
                    }
                    Text(
                        text = "Pengelolaan Saldo Pengguna, Keamanan & Log Audit",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Analytics summary
        item {
            GlassmorphicCard(cornerRadius = 20.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Statistik Sistem Enterprise", fontWeight = FontWeight.Bold)
                    Text(text = "Total Pengguna Aktif: 124.890 Users", fontSize = 12.sp)
                    Text(text = "Total Transaksi Hari Ini: Rp 4.280.000.000", fontSize = 12.sp)
                    Text(text = "Status Server & Sandbox Security: GREEN (All Systems Nominal)", fontSize = 12.sp, color = XerazEmerald)
                }
            }
        }

        // Adjust User Balance
        item {
            GlassmorphicCard(cornerRadius = 20.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(text = "Pengaturan Saldo Pengguna (Demo Admin)", fontWeight = FontWeight.Bold)
                    Text(text = "Pengguna: ${user?.fullName ?: ""} (${user?.email ?: ""})", fontSize = 12.sp)

                    OutlinedTextField(
                        value = newBalanceInput,
                        onValueChange = { newBalanceInput = it },
                        label = { Text("Set Saldo Utama Baru (Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val nb = newBalanceInput.toDoubleOrNull() ?: 0.0
                            onAdminUpdateBalance(nb)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = XerazEmerald),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simpan Perubahan Saldo", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Audit Logs List Header
        item {
            Text(
                text = "Stream Audit Log Keamanan & Transaksi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(auditLogs) { log ->
            val dateStr = SimpleDateFormat("dd/MM/yy HH:mm:ss", Locale("id", "ID")).format(Date(log.timestamp))
            GlassmorphicCard(cornerRadius = 12.dp, gradientBorder = false) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = log.action, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = XerazEmerald)
                        Text(text = dateStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = log.details, fontSize = 11.sp)
                    Text(text = "${log.deviceModel} • IP: ${log.ipAddress}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
