package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.data.model.TransactionType
import com.example.ui.components.AiSupportDrawer
import com.example.ui.components.BottomNavBar
import com.example.ui.components.PinEntryModal
import com.example.ui.components.TransactionDetailDialog
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.PayBillScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.screens.PromoRewardScreen
import com.example.ui.screens.QrCenterScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.TopUpScreen
import com.example.ui.screens.TransferScreen
import com.example.ui.screens.WithdrawScreen
import com.example.ui.theme.XerazTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.XerazViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: XerazViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val user by viewModel.currentUser.collectAsState()
            val transactions by viewModel.transactions.collectAsState()
            val promos by viewModel.promos.collectAsState()
            val notifications by viewModel.notifications.collectAsState()
            val auditLogs by viewModel.auditLogs.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val selectedTab by viewModel.selectedTab.collectAsState()
            val pendingPinAction by viewModel.pinVerificationPending.collectAsState()
            val selectedTx by viewModel.selectedTransaction.collectAsState()
            val aiChatMessages by viewModel.aiChatMessages.collectAsState()

            var showAiDrawer by remember { mutableStateOf(false) }
            var activeBillType by remember { mutableStateOf(TransactionType.PAY_PLN) }

            val context = LocalContext.current
            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(key1 = true) {
                viewModel.toastMessage.collect { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }

            XerazTheme(themePreference = user?.themePreference ?: "DARK") {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        if (currentScreen == AppScreen.MAIN_DASHBOARD) {
                            BottomNavBar(
                                selectedTab = selectedTab,
                                onTabSelected = { tabIndex -> viewModel.selectTab(tabIndex) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentScreen) {
                            AppScreen.SPLASH -> {
                                SplashScreen(
                                    onSplashFinished = {
                                        viewModel.navigateTo(AppScreen.MAIN_DASHBOARD)
                                    }
                                )
                            }

                            AppScreen.AUTH_LOGIN, AppScreen.AUTH_REGISTER, AppScreen.AUTH_OTP -> {
                                AuthScreen(
                                    onLoginSuccess = { email, pass ->
                                        viewModel.loginWithEmailPhone(email, pass)
                                    }
                                )
                            }

                            AppScreen.PIN_ENTRY -> {
                                PinEntryModal(
                                    onPinSubmitted = { pin ->
                                        viewModel.executePendingPinAction(pin)
                                    },
                                    onCancel = {
                                        viewModel.cancelPinVerification()
                                    }
                                )
                            }

                            AppScreen.MAIN_DASHBOARD -> {
                                when (selectedTab) {
                                    0 -> DashboardScreen(
                                        user = user,
                                        recentTransactions = transactions,
                                        unreadNotificationsCount = notifications.count { !it.isRead },
                                        onNavigateTransfer = { viewModel.navigateTo(AppScreen.TRANSFER_FLOW) },
                                        onNavigateTopUp = { viewModel.navigateTo(AppScreen.TOPUP_FLOW) },
                                        onNavigatePayBill = { type ->
                                            activeBillType = type
                                            viewModel.navigateTo(AppScreen.PAY_BILL_FLOW)
                                        },
                                        onNavigateWithdraw = { viewModel.navigateTo(AppScreen.WITHDRAW_FLOW) },
                                        onNotificationClick = {
                                            viewModel.markNotificationsRead()
                                            Toast.makeText(context, "Notifikasi ditandai dibaca", Toast.LENGTH_SHORT).show()
                                        },
                                        onAiBotClick = { showAiDrawer = true },
                                        onProfileClick = { viewModel.selectTab(4) },
                                        onTransactionClick = { tx -> viewModel.selectTransactionForDetail(tx) },
                                        onSeeAllHistory = { viewModel.selectTab(1) }
                                    )

                                    1 -> HistoryScreen(
                                        transactions = transactions,
                                        searchQuery = viewModel.historySearchQuery.collectAsState().value,
                                        selectedCategory = viewModel.historyCategoryFilter.collectAsState().value,
                                        onSearchQueryChange = { viewModel.setHistorySearchQuery(it) },
                                        onCategoryChange = { viewModel.setHistoryCategoryFilter(it) },
                                        onTransactionClick = { tx -> viewModel.selectTransactionForDetail(tx) },
                                        onExportReport = { format ->
                                            Toast.makeText(context, "Laporan $format Berhasil Diunduh!", Toast.LENGTH_SHORT).show()
                                        }
                                    )

                                    2 -> QrCenterScreen(
                                        user = user,
                                        onQrPaySimulated = { merchant, amt, payload ->
                                            viewModel.payQr(merchant, amt, payload)
                                        },
                                        onShowToast = { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                                    )

                                    3 -> PromoRewardScreen(
                                        user = user,
                                        promos = promos,
                                        onClaimPromo = { id -> viewModel.claimPromo(id) },
                                        onRedeemPoints = { pts -> viewModel.redeemCashbackToBalance(pts) }
                                    )

                                    4 -> ProfileSettingsScreen(
                                        user = user,
                                        onThemeChanged = { th -> viewModel.updateTheme(th) },
                                        onToggleBiometrics = { en -> viewModel.toggleBiometrics(en) },
                                        onToggleFaceUnlock = { en -> viewModel.toggleFaceUnlock(en) },
                                        onNavigateAdminPanel = { viewModel.navigateTo(AppScreen.ADMIN_PANEL) },
                                        onLogout = { viewModel.logout() },
                                        onShowToast = { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() },
                                        onOpenAiSupport = { showAiDrawer = true }
                                    )
                                }
                            }

                            AppScreen.TRANSFER_FLOW -> {
                                TransferScreen(
                                    onBack = { viewModel.navigateTo(AppScreen.MAIN_DASHBOARD) },
                                    onTransferUser = { target, amt, notes ->
                                        viewModel.transferUser(target, amt, notes)
                                    },
                                    onTransferBank = { bank, acc, name, amt, notes ->
                                        viewModel.transferBank(bank, acc, name, amt, notes)
                                    }
                                )
                            }

                            AppScreen.TOPUP_FLOW -> {
                                TopUpScreen(
                                    onBack = { viewModel.navigateTo(AppScreen.MAIN_DASHBOARD) },
                                    onTopUpSubmitted = { method, amt ->
                                        viewModel.topUp(method, amt)
                                    }
                                )
                            }

                            AppScreen.PAY_BILL_FLOW -> {
                                PayBillScreen(
                                    initialType = activeBillType,
                                    onBack = { viewModel.navigateTo(AppScreen.MAIN_DASHBOARD) },
                                    onPaySubmitted = { type, biller, custId, amt, promo ->
                                        viewModel.payBill(type, biller, custId, amt, promo)
                                    }
                                )
                            }

                            AppScreen.WITHDRAW_FLOW -> {
                                WithdrawScreen(
                                    onBack = { viewModel.navigateTo(AppScreen.MAIN_DASHBOARD) },
                                    onWithdrawSubmitted = { dest, acc, amt ->
                                        viewModel.withdraw(dest, acc, amt)
                                    }
                                )
                            }

                            AppScreen.ADMIN_PANEL -> {
                                AdminPanelScreen(
                                    user = user,
                                    auditLogs = auditLogs,
                                    onBack = { viewModel.navigateTo(AppScreen.MAIN_DASHBOARD) },
                                    onAdminUpdateBalance = { nb -> viewModel.adminSetBalance(nb) }
                                )
                            }

                            else -> {
                                viewModel.navigateTo(AppScreen.MAIN_DASHBOARD)
                            }
                        }

                        // Transaction Detail Dialog
                        selectedTx?.let { tx ->
                            TransactionDetailDialog(
                                transaction = tx,
                                onDismiss = { viewModel.selectTransactionForDetail(null) },
                                onExportReport = { format ->
                                    Toast.makeText(context, "Struk PDF/Excel Format: $format Berhasil!", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }

                        // AI Support Chatbot Drawer
                        if (showAiDrawer) {
                            AiSupportDrawer(
                                chatMessages = aiChatMessages,
                                onSendMessage = { prompt -> viewModel.sendAiMessage(prompt) },
                                onDismiss = { showAiDrawer = false }
                            )
                        }
                    }
                }
            }
        }
    }
}
