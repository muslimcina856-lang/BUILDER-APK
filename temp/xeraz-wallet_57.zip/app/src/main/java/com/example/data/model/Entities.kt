package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MemberLevel {
    BRONZE, SILVER, GOLD, PLATINUM, DIAMOND
}

enum class TransactionType {
    TRANSFER_USER,
    TRANSFER_BANK,
    TOPUP_VA,
    TOPUP_QRIS,
    TOPUP_CARD,
    PAY_PULSA,
    PAY_PLN,
    PAY_PDAM,
    PAY_INTERNET,
    PAY_GAME,
    PAY_STREAMING,
    PAY_BPJS,
    WITHDRAW_BANK,
    QR_PAYMENT,
    CASHBACK_REWARD
}

enum class TransactionStatus {
    SUCCESS, PENDING, FAILED
}

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String = "USR_1001",
    val fullName: String = "Rizky Xeraz",
    val username: String = "rizkyxeraz",
    val email: String = "rizky@xeraz.wallet",
    val phoneNumber: String = "081234567890",
    val passwordHash: String = "password123",
    val profileImageUri: String = "",
    val balance: Double = 2850000.0,
    val bonusBalance: Double = 150000.0,
    val cashbackPoints: Double = 42500.0,
    val rewardCoins: Int = 1250,
    val memberLevel: MemberLevel = MemberLevel.GOLD,
    val pinCode: String = "123456",
    val isKycVerified: Boolean = true,
    val kycKtpNumber: String = "3171012304950002",
    val isBiometricEnabled: Boolean = true,
    val isFaceUnlockEnabled: Boolean = true,
    val autoLogoutMinutes: Int = 15,
    val themePreference: String = "DARK", // DARK, LIGHT, AMOLED
    val language: String = "ID", // ID, EN
    val currency: String = "IDR",
    val activeDevicesCount: Int = 2,
    val registeredAt: Long = System.currentTimeMillis() - 864000000L
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: TransactionType,
    val amount: Double,
    val adminFee: Double = 0.0,
    val cashbackEarned: Double = 0.0,
    val recipientName: String = "",
    val recipientDetail: String = "",
    val category: String = "General",
    val status: TransactionStatus = TransactionStatus.SUCCESS,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val referenceCode: String,
    val paymentMethod: String = "Xeraz Balance"
)

@Entity(tableName = "promos")
data class PromoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val code: String,
    val discountDescription: String,
    val minTransaction: Double,
    val cashbackPercent: Double,
    val maxCashback: Double,
    val expiryDate: String,
    val isClaimed: Boolean = false,
    val category: String = "All"
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val category: String, // PROMO, SECURITY, TRANSACTION, SYSTEM
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "support_tickets")
data class SupportTicketEntity(
    @PrimaryKey val id: String,
    val subject: String,
    val message: String,
    val reply: String = "",
    val status: String = "OPEN", // OPEN, IN_PROGRESS, RESOLVED
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val details: String,
    val deviceModel: String = "Android Device (Simulated)",
    val ipAddress: String = "192.168.1.100",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "merchants")
data class MerchantEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val qrisCode: String,
    val address: String,
    val rating: Double = 4.8
)
