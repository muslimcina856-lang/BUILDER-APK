package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionType
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.XerazEmerald

@Composable
fun PayBillScreen(
    initialType: TransactionType,
    onBack: () -> Unit,
    onPaySubmitted: (TransactionType, String, String, Double, String) -> Unit
) {
    val billerTitle = when (initialType) {
        TransactionType.PAY_PLN -> "Token & Tagihan Listrik PLN"
        TransactionType.PAY_PULSA -> "Pulsa & Paket Data HP"
        TransactionType.PAY_PDAM -> "Air PDAM Kas Daerah"
        TransactionType.PAY_INTERNET -> "Internet & TV Kabel"
        TransactionType.PAY_BPJS -> "BPJS Kesehatan & Ketenagakerjaan"
        TransactionType.PAY_GAME -> "Voucher Game & Diamond"
        TransactionType.PAY_STREAMING -> "Langganan Digital Streaming"
        else -> "Pembayaran Tagihan Routine"
    }

    var customerId by remember { mutableStateOf("539102938102") }
    var amountText by remember { mutableStateOf("101500") }
    var promoCode by remember { mutableStateOf("XRZQR30") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("pay_bill_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = billerTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Proses Otomatis & Terverifikasi Realtime",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        GlassmorphicCard(cornerRadius = 24.dp) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                OutlinedTextField(
                    value = customerId,
                    onValueChange = { customerId = it },
                    label = { Text("Nomor ID Pelanggan / Nomor HP") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_customer_id")
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Nominal Tagihan (Rp)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_bill_amount")
                )

                OutlinedTextField(
                    value = promoCode,
                    onValueChange = { promoCode = it },
                    label = { Text("Kode Promo / Voucher Cashback") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        val amt = amountText.toDoubleOrNull() ?: 0.0
                        onPaySubmitted(initialType, billerTitle, customerId, amt, promoCode)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = XerazEmerald),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_submit_pay_bill")
                ) {
                    Icon(Icons.Default.Receipt, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Bayar Sekarang", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
