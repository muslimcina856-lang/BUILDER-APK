package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HelpCenter
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhonelinkSetup
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.XerazEmerald
import com.example.ui.theme.XerazGold
import com.example.ui.theme.XerazPurple
import com.example.ui.theme.XerazRed

@Composable
fun ProfileSettingsScreen(
    user: UserEntity?,
    onThemeChanged: (String) -> Unit,
    onToggleBiometrics: (Boolean) -> Unit,
    onToggleFaceUnlock: (Boolean) -> Unit,
    onNavigateAdminPanel: () -> Unit,
    onLogout: () -> Unit,
    onShowToast: (String) -> Unit,
    onOpenAiSupport: () -> Unit
) {
    var isScreenCaptureGuarded by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("profile_settings_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Profil & Pengaturan Akun",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        // Profile Card
        item {
            GlassmorphicCard(
                cornerRadius = 24.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Avatar",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = user?.fullName ?: "Rizky Xeraz",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "@${user?.username ?: "rizkyxeraz"} • ${user?.phoneNumber ?: ""}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Email: ${user?.email ?: ""}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(XerazEmerald.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Akun KTP Terverifikasi (KYC L3)",
                                color = XerazEmerald,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Security Center Section
        item {
            Text(
                text = "Pusat Keamanan Akun",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            GlassmorphicCard(cornerRadius = 20.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SettingToggleRow(
                        title = "Login Biometrik Sidik Jari",
                        subtitle = "Gunakan sensor sidik jari perangkat",
                        icon = Icons.Default.Fingerprint,
                        checked = user?.isBiometricEnabled == true,
                        onCheckedChange = onToggleBiometrics
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    SettingToggleRow(
                        title = "Login Face Unlock AI",
                        subtitle = "Pengenalan wajah terenkripsi",
                        icon = Icons.Default.Face,
                        checked = user?.isFaceUnlockEnabled == true,
                        onCheckedChange = onToggleFaceUnlock
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    SettingToggleRow(
                        title = "Proteksi Tangkapan Layar (FLAG_SECURE)",
                        subtitle = "Cegah screenshot & rekaman layar",
                        icon = Icons.Default.Shield,
                        checked = isScreenCaptureGuarded,
                        onCheckedChange = {
                            isScreenCaptureGuarded = it
                            onShowToast("Flag Screen Guard: $it")
                        }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    SettingClickRow(
                        title = "Ubah 6-Digit PIN Transaksi",
                        subtitle = "Terakhir diubah 30 hari lalu",
                        icon = Icons.Default.Lock,
                        onClick = { onShowToast("Navigasi ke Ubah PIN") }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    SettingClickRow(
                        title = "Perangkat Terhubung (${user?.activeDevicesCount ?: 2})",
                        subtitle = "Kelola sesi login aktif di HP lain",
                        icon = Icons.Default.PhonelinkSetup,
                        onClick = { onShowToast("2 Perangkat Aktif: Pixel 8 Pro & Galaxy Tab S9") }
                    )
                }
            }
        }

        // Appearance & Settings
        item {
            Text(
                text = "Pengaturan Aplikasi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            GlassmorphicCard(cornerRadius = 20.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ColorLens, contentDescription = null, tint = XerazEmerald)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Tema Tampilan", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Pilih mode warna aplikasi", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            ThemeChip("DARK", user?.themePreference == "DARK", onThemeChanged)
                            ThemeChip("LIGHT", user?.themePreference == "LIGHT", onThemeChanged)
                            ThemeChip("AMOLED", user?.themePreference == "AMOLED", onThemeChanged)
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    SettingClickRow(
                        title = "Bahasa / Language",
                        subtitle = "Bahasa Indonesia (ID)",
                        icon = Icons.Default.Language,
                        onClick = { onShowToast("Bahasa Indonesia aktif") }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    SettingClickRow(
                        title = "Cadangkan & Pulihkan Data",
                        subtitle = "Backup encrypted data to cloud",
                        icon = Icons.Default.Backup,
                        onClick = { onShowToast("Data lokal berhasil dicadangkan") }
                    )
                }
            }
        }

        // Support & Admin Panel
        item {
            Text(
                text = "Bantuan & Mode Pengembang",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            GlassmorphicCard(cornerRadius = 20.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SettingClickRow(
                        title = "Pusat Bantuan & Chatbot AI 24/7",
                        subtitle = "Tanya jawab otomatis & tiket support",
                        icon = Icons.Default.HelpCenter,
                        onClick = onOpenAiSupport
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    SettingClickRow(
                        title = "Panel Admin & Dashboard Keuangan",
                        subtitle = "Akses fitur manajemen saldo & audit log",
                        icon = Icons.Default.AdminPanelSettings,
                        onClick = onNavigateAdminPanel
                    )
                }
            }
        }

        // Logout Button
        item {
            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_logout")
            ) {
                Icon(Icons.Default.Logout, contentDescription = "Logout", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Keluar Dari Akun", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun ThemeChip(theme: String, isSelected: Boolean, onClick: (String) -> Unit) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) XerazEmerald else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.clickable { onClick(theme) }
    ) {
        Text(
            text = theme,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(imageVector = icon, contentDescription = null, tint = XerazEmerald)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = XerazEmerald)
        )
    }
}

@Composable
private fun SettingClickRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(imageVector = icon, contentDescription = null, tint = XerazEmerald)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
