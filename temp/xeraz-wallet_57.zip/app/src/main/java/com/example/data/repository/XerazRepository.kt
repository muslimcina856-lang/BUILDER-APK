package com.example.data.repository

import com.example.data.db.XerazDatabase
import com.example.data.model.AuditLogEntity
import com.example.data.model.MerchantEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.PromoEntity
import com.example.data.model.SupportTicketEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionStatus
import com.example.data.model.TransactionType
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

class XerazRepository(private val database: XerazDatabase) {

    val userDao = database.userDao()
    val txDao = database.transactionDao()
    val promoDao = database.promoDao()
    val notifDao = database.notificationDao()
    val ticketDao = database.supportTicketDao()
    val auditDao = database.auditLogDao()
    val merchantDao = database.merchantDao()

    val currentUserFlow: Flow<UserEntity?> = userDao.getUserFlow("USR_1001")
    val allTransactionsFlow: Flow<List<TransactionEntity>> = txDao.getAllTransactionsFlow()
    val allPromosFlow: Flow<List<PromoEntity>> = promoDao.getAllPromosFlow()
    val allNotificationsFlow: Flow<List<NotificationEntity>> = notifDao.getAllNotificationsFlow()
    val allTicketsFlow: Flow<List<SupportTicketEntity>> = ticketDao.getAllTicketsFlow()
    val allAuditLogsFlow: Flow<List<AuditLogEntity>> = auditDao.getAuditLogsFlow()
    val allMerchantsFlow: Flow<List<MerchantEntity>> = merchantDao.getAllMerchantsFlow()

    suspend fun getCurrentUser(): UserEntity {
        return userDao.getUserSync("USR_1001") ?: UserEntity()
    }

    suspend fun updateUser(user: UserEntity) {
        userDao.updateUser(user)
        logAudit("USER_PROFILE_UPDATE", "Updated profile details for ${user.fullName}")
    }

    suspend fun updateThemePreference(theme: String) {
        val user = getCurrentUser()
        userDao.updateUser(user.copy(themePreference = theme))
        logAudit("THEME_CHANGE", "Theme updated to $theme")
    }

    suspend fun verifyPin(pinInput: String): Boolean {
        val user = getCurrentUser()
        return user.pinCode == pinInput
    }

    suspend fun updatePin(oldPin: String, newPin: String): Boolean {
        val user = getCurrentUser()
        if (user.pinCode == oldPin) {
            userDao.updateUser(user.copy(pinCode = newPin))
            logAudit("SECURITY_PIN_CHANGE", "PIN changed successfully")
            return true
        }
        return false
    }

    suspend fun toggleBiometrics(enabled: Boolean) {
        val user = getCurrentUser()
        userDao.updateUser(user.copy(isBiometricEnabled = enabled))
        logAudit("SECURITY_BIOMETRIC_TOGGLE", "Biometric state set to $enabled")
    }

    suspend fun toggleFaceUnlock(enabled: Boolean) {
        val user = getCurrentUser()
        userDao.updateUser(user.copy(isFaceUnlockEnabled = enabled))
        logAudit("SECURITY_FACE_UNLOCK_TOGGLE", "Face unlock state set to $enabled")
    }

    // --- TRANSACTIONS ---

    suspend fun performTransferUser(
        recipientUsernameOrPhone: String,
        amount: Double,
        notes: String
    ): Result<TransactionEntity> {
        val user = getCurrentUser()
        if (amount <= 0) return Result.failure(Exception("Jumlah transfer harus lebih dari Rp 0"))
        if (user.balance < amount) return Result.failure(Exception("Saldo utama tidak mencukupi"))

        val ref = "XRZ-TRU-" + UUID.randomUUID().toString().take(8).uppercase()
        val newBalance = user.balance - amount
        val cashbackEarned = (amount * 0.01).coerceAtMost(10000.0)
        val newCashback = user.cashbackPoints + cashbackEarned
        val newCoins = user.rewardCoins + (amount / 10000).toInt()

        userDao.updateUser(
            user.copy(
                balance = newBalance,
                cashbackPoints = newCashback,
                rewardCoins = newCoins
            )
        )

        val tx = TransactionEntity(
            id = "TX" + (System.currentTimeMillis() % 1000000),
            title = "Transfer ke $recipientUsernameOrPhone",
            type = TransactionType.TRANSFER_USER,
            amount = amount,
            adminFee = 0.0,
            cashbackEarned = cashbackEarned,
            recipientName = recipientUsernameOrPhone,
            recipientDetail = recipientUsernameOrPhone,
            category = "Transfer",
            status = TransactionStatus.SUCCESS,
            notes = notes.ifEmpty { "Transfer antar Xeraz Wallet" },
            timestamp = System.currentTimeMillis(),
            referenceCode = ref
        )
        txDao.insertTransaction(tx)

        notifDao.insertNotification(
            NotificationEntity(
                title = "Transfer Berhasil",
                message = "Transfer ${formatRupiah(amount)} ke $recipientUsernameOrPhone berhasil. Sisa saldo ${formatRupiah(newBalance)}.",
                category = "TRANSACTION"
            )
        )

        logAudit("TRANSFER_USER", "Sent ${formatRupiah(amount)} to $recipientUsernameOrPhone (Ref: $ref)")
        return Result.success(tx)
    }

    suspend fun performTransferBank(
        bankName: String,
        accountNumber: String,
        recipientName: String,
        amount: Double,
        notes: String
    ): Result<TransactionEntity> {
        val user = getCurrentUser()
        val adminFee = 2500.0
        val totalDebit = amount + adminFee

        if (amount < 10000) return Result.failure(Exception("Minimal transfer bank Rp 10.000"))
        if (user.balance < totalDebit) return Result.failure(Exception("Saldo tidak cukup untuk nominal + biaya admin ${formatRupiah(adminFee)}"))

        val ref = "XRZ-BANK-" + UUID.randomUUID().toString().take(8).uppercase()
        val newBalance = user.balance - totalDebit
        val newCoins = user.rewardCoins + (amount / 10000).toInt()

        userDao.updateUser(user.copy(balance = newBalance, rewardCoins = newCoins))

        val tx = TransactionEntity(
            id = "TX" + (System.currentTimeMillis() % 1000000),
            title = "Transfer Bank $bankName",
            type = TransactionType.TRANSFER_BANK,
            amount = amount,
            adminFee = adminFee,
            cashbackEarned = 0.0,
            recipientName = recipientName,
            recipientDetail = "$bankName - $accountNumber",
            category = "Transfer",
            status = TransactionStatus.SUCCESS,
            notes = notes.ifEmpty { "Transfer BI-FAST Realtime" },
            timestamp = System.currentTimeMillis(),
            referenceCode = ref
        )
        txDao.insertTransaction(tx)

        notifDao.insertNotification(
            NotificationEntity(
                title = "Transfer Bank Berhasil",
                message = "Transfer ${formatRupiah(amount)} ke $recipientName ($bankName) sukses via BI-FAST.",
                category = "TRANSACTION"
            )
        )

        logAudit("TRANSFER_BANK", "Transfer $bankName $accountNumber ($recipientName) - ${formatRupiah(amount)}")
        return Result.success(tx)
    }

    suspend fun performTopUp(
        method: String,
        amount: Double
    ): Result<TransactionEntity> {
        if (amount < 10000) return Result.failure(Exception("Minimal Top Up Rp 10.000"))
        val user = getCurrentUser()

        val ref = "XRZ-TPU-" + UUID.randomUUID().toString().take(8).uppercase()
        val bonusCashback = (amount * 0.02).coerceAtMost(20000.0)
        val newBalance = user.balance + amount
        val newBonus = user.bonusBalance + bonusCashback

        userDao.updateUser(user.copy(balance = newBalance, bonusBalance = newBonus))

        val tx = TransactionEntity(
            id = "TX" + (System.currentTimeMillis() % 1000000),
            title = "Top Up via $method",
            type = TransactionType.TOPUP_VA,
            amount = amount,
            adminFee = 0.0,
            cashbackEarned = bonusCashback,
            recipientName = user.fullName,
            recipientDetail = "Xeraz Saldo Utama",
            category = "TopUp",
            status = TransactionStatus.SUCCESS,
            notes = "Top Up berhasil & mendapat bonus ${formatRupiah(bonusCashback)}",
            timestamp = System.currentTimeMillis(),
            referenceCode = ref
        )
        txDao.insertTransaction(tx)

        notifDao.insertNotification(
            NotificationEntity(
                title = "Top Up Berhasil!",
                message = "Isi saldo ${formatRupiah(amount)} via $method sukses. Saldo sekarang ${formatRupiah(newBalance)}.",
                category = "PROMO"
            )
        )

        logAudit("TOPUP", "Top Up $method ${formatRupiah(amount)}")
        return Result.success(tx)
    }

    suspend fun performBillPayment(
        billType: TransactionType,
        billerName: String,
        customerId: String,
        amount: Double,
        promoCode: String = ""
    ): Result<TransactionEntity> {
        val user = getCurrentUser()
        val adminFee = if (billType == TransactionType.PAY_PLN) 1500.0 else 2500.0
        val totalDebit = amount + adminFee

        if (user.balance < totalDebit) return Result.failure(Exception("Saldo tidak mencukupi untuk tagihan + fee ${formatRupiah(adminFee)}"))

        val ref = "XRZ-BILL-" + UUID.randomUUID().toString().take(8).uppercase()
        val cashbackEarned = if (promoCode.isNotEmpty()) (amount * 0.05).coerceAtMost(15000.0) else (amount * 0.01).coerceAtMost(5000.0)
        val newBalance = user.balance - totalDebit
        val newCashback = user.cashbackPoints + cashbackEarned

        userDao.updateUser(user.copy(balance = newBalance, cashbackPoints = newCashback))

        val tx = TransactionEntity(
            id = "TX" + (System.currentTimeMillis() % 1000000),
            title = "Bayar $billerName",
            type = billType,
            amount = amount,
            adminFee = adminFee,
            cashbackEarned = cashbackEarned,
            recipientName = billerName,
            recipientDetail = "ID Pelanggan: $customerId",
            category = "Bill",
            status = TransactionStatus.SUCCESS,
            notes = "Lunas. No. Ref Struk: $ref",
            timestamp = System.currentTimeMillis(),
            referenceCode = ref
        )
        txDao.insertTransaction(tx)

        notifDao.insertNotification(
            NotificationEntity(
                title = "Pembayaran $billerName Berhasil",
                message = "Tagihan $customerId sebesar ${formatRupiah(amount)} lunas. Cashback +${formatRupiah(cashbackEarned)}.",
                category = "TRANSACTION"
            )
        )

        logAudit("PAY_BILL", "Paid $billerName ($customerId) - ${formatRupiah(amount)}")
        return Result.success(tx)
    }

    suspend fun performQrPayment(
        merchantName: String,
        amount: Double,
        qrisPayload: String
    ): Result<TransactionEntity> {
        val user = getCurrentUser()
        if (amount <= 0) return Result.failure(Exception("Nominal QRIS tidak valid"))
        if (user.balance < amount) return Result.failure(Exception("Saldo utama tidak mencukupi"))

        val ref = "XRZ-QRIS-" + UUID.randomUUID().toString().take(8).uppercase()
        val cashbackEarned = (amount * 0.03).coerceAtMost(15000.0)
        val newBalance = user.balance - amount
        val newCashback = user.cashbackPoints + cashbackEarned

        userDao.updateUser(user.copy(balance = newBalance, cashbackPoints = newCashback))

        val tx = TransactionEntity(
            id = "TX" + (System.currentTimeMillis() % 1000000),
            title = "QRIS $merchantName",
            type = TransactionType.QR_PAYMENT,
            amount = amount,
            adminFee = 0.0,
            cashbackEarned = cashbackEarned,
            recipientName = merchantName,
            recipientDetail = "Merchant QRIS Standards",
            category = "Food & Merchant",
            status = TransactionStatus.SUCCESS,
            notes = "Scan & Pay QRIS Nasional",
            timestamp = System.currentTimeMillis(),
            referenceCode = ref
        )
        txDao.insertTransaction(tx)

        notifDao.insertNotification(
            NotificationEntity(
                title = "Pembayaran QRIS Berhasil",
                message = "Pembayaran di $merchantName sebesar ${formatRupiah(amount)} sukses. Cashback +${formatRupiah(cashbackEarned)}.",
                category = "TRANSACTION"
            )
        )

        logAudit("QRIS_PAY", "Paid QRIS $merchantName ${formatRupiah(amount)}")
        return Result.success(tx)
    }

    suspend fun performWithdraw(
        destinationBankOrAgent: String,
        accountOrAgentNo: String,
        amount: Double
    ): Result<TransactionEntity> {
        val user = getCurrentUser()
        val fee = 4500.0
        val totalDebit = amount + fee

        if (amount < 50000) return Result.failure(Exception("Minimal penarikan saldo Rp 50.000"))
        if (user.balance < totalDebit) return Result.failure(Exception("Saldo tidak mencukupi untuk biaya admin tarik ${formatRupiah(fee)}"))

        val ref = "XRZ-WDR-" + UUID.randomUUID().toString().take(8).uppercase()
        val newBalance = user.balance - totalDebit

        userDao.updateUser(user.copy(balance = newBalance))

        val tx = TransactionEntity(
            id = "TX" + (System.currentTimeMillis() % 1000000),
            title = "Tarik Saldo - $destinationBankOrAgent",
            type = TransactionType.WITHDRAW_BANK,
            amount = amount,
            adminFee = fee,
            cashbackEarned = 0.0,
            recipientName = user.fullName,
            recipientDetail = "$destinationBankOrAgent ($accountOrAgentNo)",
            category = "Withdraw",
            status = TransactionStatus.SUCCESS,
            notes = "Pencairan dana siap ditarik dalam 1-5 menit",
            timestamp = System.currentTimeMillis(),
            referenceCode = ref
        )
        txDao.insertTransaction(tx)

        notifDao.insertNotification(
            NotificationEntity(
                title = "Tarik Saldo Berhasil",
                message = "Penarikan ${formatRupiah(amount)} ke $destinationBankOrAgent diproses.",
                category = "TRANSACTION"
            )
        )

        logAudit("WITHDRAW", "Withdraw ${formatRupiah(amount)} to $destinationBankOrAgent")
        return Result.success(tx)
    }

    suspend fun claimPromo(promoId: String): Boolean {
        promoDao.markClaimed(promoId)
        val user = getCurrentUser()
        val newBonus = user.bonusBalance + 10000.0
        userDao.updateUser(user.copy(bonusBalance = newBonus))
        notifDao.insertNotification(
            NotificationEntity(
                title = "Voucher Diklaim!",
                message = "Selamat! Bonus saldo Rp 10.000 ditambahkan ke saldo bonus Anda.",
                category = "PROMO"
            )
        )
        logAudit("PROMO_CLAIM", "Claimed promo voucher $promoId")
        return true
    }

    suspend fun convertPointsToBalance(pointsToConvert: Double): Result<Boolean> {
        val user = getCurrentUser()
        if (user.cashbackPoints < pointsToConvert) return Result.failure(Exception("Poin cashback tidak mencukupi"))
        val newCashback = user.cashbackPoints - pointsToConvert
        val newBalance = user.balance + pointsToConvert

        userDao.updateUser(user.copy(balance = newBalance, cashbackPoints = newCashback))

        val tx = TransactionEntity(
            id = "TX" + (System.currentTimeMillis() % 1000000),
            title = "Tukar Poin Cashback",
            type = TransactionType.CASHBACK_REWARD,
            amount = pointsToConvert,
            adminFee = 0.0,
            cashbackEarned = 0.0,
            recipientName = user.fullName,
            recipientDetail = "Xeraz Wallet Main Balance",
            category = "Rewards",
            status = TransactionStatus.SUCCESS,
            notes = "Penukaran Poin Cashback menjadi Saldo Utama",
            timestamp = System.currentTimeMillis(),
            referenceCode = "XRZ-REWARD-" + UUID.randomUUID().toString().take(8).uppercase()
        )
        txDao.insertTransaction(tx)

        logAudit("REWARD_CONVERT", "Converted $pointsToConvert points to main balance")
        return Result.success(true)
    }

    suspend fun submitSupportTicket(subject: String, message: String) {
        val ticket = SupportTicketEntity(
            id = "TCK-" + (System.currentTimeMillis() % 100000),
            subject = subject,
            message = message,
            reply = "Pesan Anda telah diterima oleh Tim CS Xeraz. Kami akan membalas segera.",
            status = "IN_PROGRESS"
        )
        ticketDao.insertTicket(ticket)
        logAudit("SUPPORT_TICKET", "Created ticket $subject")
    }

    suspend fun adminUpdateBalance(newBalance: Double) {
        val user = getCurrentUser()
        userDao.updateUser(user.copy(balance = newBalance))
        logAudit("ADMIN_BALANCE_EDIT", "Admin set user balance to ${formatRupiah(newBalance)}")
    }

    suspend fun markAllNotificationsRead() {
        notifDao.markAllAsRead()
    }

    private suspend fun logAudit(action: String, details: String) {
        auditDao.insertLog(AuditLogEntity(action = action, details = details))
    }

    companion object {
        fun formatRupiah(amount: Double): String {
            val format = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
            format.maximumFractionDigits = 0
            return format.format(amount).replace("Rp", "Rp ")
        }
    }
}
