package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.XerazEmerald

@Composable
fun TransferScreen(
    onBack: () -> Unit,
    onTransferUser: (String, Double, String) -> Unit,
    onTransferBank: (String, String, String, Double, String) -> Unit
) {
    var activeTab by remember { mutableStateOf(0) } // 0: Antar Pengguna, 1: Antar Bank
    var recipientTarget by remember { mutableStateOf("081987654321") }
    var recipientName by remember { mutableStateOf("Ahmad Fauzi") }
    var selectedBank by remember { mutableStateOf("Bank BCA") }
    var accountNumber by remember { mutableStateOf("880192837491") }
    var amountText by remember { mutableStateOf("150000") }
    var notesText by remember { mutableStateOf("Transfer uang saku & keperluan") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("transfer_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Transfer Saldo",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Kirim Uang Realtime Ke Mana Saja",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        TabRow(
            selectedTabIndex = activeTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(16.dp))
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Antar Xeraz (Gratis)", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("tab_transfer_user")
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Antar Bank BI-FAST", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("tab_transfer_bank")
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        GlassmorphicCard(cornerRadius = 24.dp) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (activeTab == 0) {
                    OutlinedTextField(
                        value = recipientTarget,
                        onValueChange = { recipientTarget = it },
                        label = { Text("No. HP / Username Penerima") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_transfer_target")
                    )
                } else {
                    OutlinedTextField(
                        value = selectedBank,
                        onValueChange = { selectedBank = it },
                        label = { Text("Pilih Bank Tujuan") },
                        leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = accountNumber,
                        onValueChange = { accountNumber = it },
                        label = { Text("Nomor Rekening Bank") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = recipientName,
                        onValueChange = { recipientName = it },
                        label = { Text("Nama Pemilik Rekening") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Nominal Transfer (Rp)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_transfer_amount")
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Catatan / Pesan (Opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val amt = amountText.toDoubleOrNull() ?: 0.0
                        if (activeTab == 0) {
                            onTransferUser(recipientTarget, amt, notesText)
                        } else {
                            onTransferBank(selectedBank, accountNumber, recipientName, amt, notesText)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = XerazEmerald),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_submit_transfer")
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Konfirmasi & Transfer", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
