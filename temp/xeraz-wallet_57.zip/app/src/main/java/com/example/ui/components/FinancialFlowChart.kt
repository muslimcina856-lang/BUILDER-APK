package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.XerazCyan
import com.example.ui.theme.XerazEmerald
import com.example.ui.theme.XerazPurple
import com.example.ui.theme.XerazRed

@Composable
fun FinancialFlowChart(
    incomeAmount: Double = 4250000.0,
    expenseAmount: Double = 1400000.0
) {
    GlassmorphicCard(
        cornerRadius = 20.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Arus Keuangan Bulanan",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Agustus 2026 • Realtime Analytic",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    LegendItem("Pemasukan", XerazEmerald)
                    LegendItem("Pengeluaran", XerazRed)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Canvas Chart
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            ) {
                val width = size.width
                val height = size.height

                // Draw grid lines
                for (i in 1..3) {
                    val y = height * (i / 4f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.1f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                // Sample data points for Income line (Green)
                val incomePoints = listOf(0.8f, 0.5f, 0.7f, 0.3f, 0.9f, 0.4f, 0.85f)
                val incomePath = Path()
                incomePoints.forEachIndexed { index, ratio ->
                    val x = width * (index / (incomePoints.size - 1).toFloat())
                    val y = height * (1f - ratio * 0.8f)
                    if (index == 0) incomePath.moveTo(x, y) else incomePath.lineTo(x, y)
                }

                // Sample data points for Expense line (Red)
                val expensePoints = listOf(0.3f, 0.4f, 0.25f, 0.6f, 0.35f, 0.5f, 0.3f)
                val expensePath = Path()
                expensePoints.forEachIndexed { index, ratio ->
                    val x = width * (index / (expensePoints.size - 1).toFloat())
                    val y = height * (1f - ratio * 0.8f)
                    if (index == 0) expensePath.moveTo(x, y) else expensePath.lineTo(x, y)
                }

                drawPath(
                    path = incomePath,
                    color = XerazEmerald,
                    style = Stroke(width = 3.dp.toPx())
                )

                drawPath(
                    path = expensePath,
                    color = XerazRed,
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Days legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min").forEach { day ->
                    Text(
                        text = day,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
