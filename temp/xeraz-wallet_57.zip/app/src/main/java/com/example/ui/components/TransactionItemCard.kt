package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.LocalActivity
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.XerazRepository
import com.example.ui.theme.XerazEmerald
import com.example.ui.theme.XerazRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TransactionItemCard(
    transaction: TransactionEntity,
    onClick: () -> Unit
) {
    val isCredit = transaction.type == TransactionType.TOPUP_VA ||
            transaction.type == TransactionType.TOPUP_QRIS ||
            transaction.type == TransactionType.TOPUP_CARD ||
            transaction.type == TransactionType.CASHBACK_REWARD

    val iconVector = when (transaction.type) {
        TransactionType.TRANSFER_USER, TransactionType.TRANSFER_BANK -> Icons.Default.SwapHoriz
        TransactionType.TOPUP_VA, TransactionType.TOPUP_QRIS, TransactionType.TOPUP_CARD -> Icons.Default.ArrowDownward
        TransactionType.PAY_PLN -> Icons.Default.ElectricBolt
        TransactionType.PAY_PULSA -> Icons.Default.PhoneAndroid
        TransactionType.QR_PAYMENT -> Icons.Default.QrCode
        TransactionType.WITHDRAW_BANK -> Icons.Default.AccountBalance
        TransactionType.CASHBACK_REWARD -> Icons.Default.LocalActivity
        else -> Icons.Default.Receipt
    }

    val dateFormatted = SimpleDateFormat("dd MMM, HH:mm", Locale("id", "ID")).format(Date(transaction.timestamp))

    GlassmorphicCard(
        onClick = onClick,
        gradientBorder = false,
        cornerRadius = 16.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("tx_item_${transaction.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCredit) XerazEmerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        )
                ) {
                    Icon(
                        imageVector = iconVector,
                        contentDescription = transaction.title,
                        tint = if (isCredit) XerazEmerald else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = transaction.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = dateFormatted,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = (if (isCredit) "+ " else "- ") + XerazRepository.formatRupiah(transaction.amount),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isCredit) XerazEmerald else XerazRed
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(XerazEmerald.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = transaction.status.name,
                        color = XerazEmerald,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
