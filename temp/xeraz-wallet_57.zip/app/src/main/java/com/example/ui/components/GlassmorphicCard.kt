package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.XerazCyan
import com.example.ui.theme.XerazEmerald
import com.example.ui.theme.XerazGlassBorderDark
import com.example.ui.theme.XerazPurple

@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    borderWidth: Dp = 1.dp,
    onClick: (() -> Unit)? = null,
    gradientBorder: Boolean = true,
    backgroundColor: Color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val borderBrush = if (gradientBorder) {
        Brush.horizontalGradient(
            colors = listOf(
                XerazEmerald.copy(alpha = 0.6f),
                XerazCyan.copy(alpha = 0.4f),
                XerazPurple.copy(alpha = 0.6f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                XerazGlassBorderDark,
                XerazGlassBorderDark.copy(alpha = 0.1f)
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(backgroundColor, shape = shape)
            .border(width = borderWidth, brush = borderBrush, shape = shape)
            .then(
                if (onClick != null) Modifier.clickable { onClick() } else Modifier
            )
            .padding(16.dp),
        content = content
    )
}
