package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = XerazEmerald,
    onPrimary = Color.Black,
    primaryContainer = XerazEmeraldDark,
    onPrimaryContainer = Color.White,
    secondary = XerazCyan,
    onSecondary = Color.Black,
    tertiary = XerazPurple,
    background = XerazDarkBg,
    onBackground = XerazTextDarkPrimary,
    surface = XerazNavy,
    onSurface = XerazTextDarkPrimary,
    surfaceVariant = XerazGlassCardDark,
    onSurfaceVariant = XerazTextDarkSecondary
)

private val AmoledColorScheme = darkColorScheme(
    primary = XerazEmerald,
    onPrimary = Color.Black,
    primaryContainer = XerazEmeraldDark,
    onPrimaryContainer = Color.White,
    secondary = XerazCyan,
    onSecondary = Color.Black,
    tertiary = XerazPurple,
    background = XerazAmoledBg,
    onBackground = Color.White,
    surface = Color(0xFF0F0F0F),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF181818),
    onSurfaceVariant = Color.LightGray
)

private val LightColorScheme = lightColorScheme(
    primary = XerazEmeraldDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1FAE5),
    onPrimaryContainer = Color(0xFF065F46),
    secondary = XerazCyan,
    onSecondary = Color.White,
    tertiary = XerazPurple,
    background = XerazSurfaceLight,
    onBackground = XerazTextLightPrimary,
    surface = XerazCardLight,
    onSurface = XerazTextLightPrimary,
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = XerazTextLightSecondary
)

@Composable
fun XerazTheme(
    themePreference: String = "DARK", // DARK, LIGHT, AMOLED
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (themePreference == "LIGHT") dynamicLightColorScheme(context) else dynamicDarkColorScheme(context)
        }
        themePreference == "AMOLED" -> AmoledColorScheme
        themePreference == "LIGHT" -> LightColorScheme
        else -> DarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
