package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.ui.components.GlassmorphicCard
import com.example.ui.theme.XerazCyan
import com.example.ui.theme.XerazEmerald

@Composable
fun QrCenterScreen(
    user: UserEntity?,
    onQrPaySimulated: (String, Double, String) -> Unit,
    onShowToast: (String) -> Unit
) {
    var activeTab by remember { mutableStateOf(0) } // 0: Scan QRIS, 1: QR Saya
    var flashEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("qr_center_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Pusat QRIS Nasional",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Standar Pembayaran QRIS Resmi Bank Indonesia",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        TabRow(
            selectedTabIndex = activeTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(16.dp))
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Scan QR Merchant", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("tab_scan_qr")
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("QRIS Saya", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("tab_my_qr")
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (activeTab == 0) {
            // Camera Scan Viewfinder Simulation
            GlassmorphicCard(
                cornerRadius = 24.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    // Viewfinder corners
                    Canvas(modifier = Modifier.size(220.dp)) {
                        val stroke = 4.dp.toPx()
                        val len = 30.dp.toPx()

                        // Top Left
                        drawLine(XerazEmerald, Offset(0f, 0f), Offset(len, 0f), stroke)
                        drawLine(XerazEmerald, Offset(0f, 0f), Offset(0f, len), stroke)

                        // Top Right
                        drawLine(XerazEmerald, Offset(size.width, 0f), Offset(size.width - len, 0f), stroke)
                        drawLine(XerazEmerald, Offset(size.width, 0f), Offset(size.width, len), stroke)

                        // Bottom Left
                        drawLine(XerazEmerald, Offset(0f, size.height), Offset(len, size.height), stroke)
                        drawLine(XerazEmerald, Offset(0f, size.height), Offset(0f, size.height - len), stroke)

                        // Bottom Right
                        drawLine(XerazEmerald, Offset(size.width, size.height), Offset(size.width - len, size.height), stroke)
                        drawLine(XerazEmerald, Offset(size.width, size.height), Offset(size.width, size.height - len), stroke)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Scan",
                            tint = if (flashEnabled) XerazCyan else XerazEmerald,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Arahkan kamera ke QRIS Merchant",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Row (Flash, Gallery, Quick Payment Simulation)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                OutlinedButton(onClick = { flashEnabled = !flashEnabled }) {
                    Icon(imageVector = Icons.Default.FlashOn, contentDescription = "Flash")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (flashEnabled) "Flash ON" else "Flash OFF")
                }

                OutlinedButton(onClick = { onShowToast("Pilih gambar QRIS dari Galeri Galeri HP") }) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = "Galeri")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Galeri")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Preset Quick Demo Payments
            Text(text = "Simulasi Pembayaran QRIS Instant:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onQrPaySimulated("Starbucks GI", 78000.0, "QRIS_SBX_101") },
                    colors = ButtonDefaults.buttonColors(containerColor = XerazEmerald),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Starbucks Rp 78k", color = Color.Black, fontSize = 11.sp)
                }

                Button(
                    onClick = { onQrPaySimulated("Indomaret Point", 32500.0, "QRIS_IDM_202") },
                    colors = ButtonDefaults.buttonColors(containerColor = XerazCyan),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Indomaret Rp 32.5k", color = Color.Black, fontSize = 11.sp)
                }
            }
        } else {
            // My QR Code Generator
            GlassmorphicCard(
                cornerRadius = 24.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = user?.fullName ?: "Rizky Xeraz",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ID: ${user?.phoneNumber ?: "081234567890"}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // QR Block Canvas Simulation
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(200.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .padding(16.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val cellSize = size.width / 8f
                            for (r in 0..7) {
                                for (c in 0..7) {
                                    if ((r + c) % 2 == 0 || (r == 0 && c == 0) || (r == 0 && c == 7) || (r == 7 && c == 0)) {
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(c * cellSize, r * cellSize),
                                            size = Size(cellSize, cellSize)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Tunjukkan QR ini untuk menerima transfer saldo instant",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { onShowToast("QR Code Berhasil Diunduh ke Galeri") }) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Download", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { onShowToast("Tautan QR Kode Disalin!") },
                            colors = ButtonDefaults.buttonColors(containerColor = XerazEmerald)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Bagikan QR", color = Color.Black, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
