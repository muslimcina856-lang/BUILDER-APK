package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.LocalActivity
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShieldMoon
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.model.UserEntity
import com.example.data.repository.XerazRepository
import com.example.ui.components.FinancialFlowChart
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.TopHeaderBar
import com.example.ui.components.TransactionItemCard
import com.example.ui.theme.XerazCyan
import com.example.ui.theme.XerazEmerald
import com.example.ui.theme.XerazGold
import com.example.ui.theme.XerazPurple

@Composable
fun DashboardScreen(
    user: UserEntity?,
    recentTransactions: List<TransactionEntity>,
    unreadNotificationsCount: Int,
    onNavigateTransfer: () -> Unit,
    onNavigateTopUp: () -> Unit,
    onNavigatePayBill: (TransactionType) -> Unit,
    onNavigateWithdraw: () -> Unit,
    onNotificationClick: () -> Unit,
    onAiBotClick: () -> Unit,
    onProfileClick: () -> Unit,
    onTransactionClick: (TransactionEntity) -> Unit,
    onSeeAllHistory: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            TopHeaderBar(
                user = user,
                unreadNotificationsCount = unreadNotificationsCount,
                onNotificationClick = onNotificationClick,
                onAiBotClick = onAiBotClick,
                onProfileClick = onProfileClick
            )
        }

        // Main Balance Card
        item {
            GlassmorphicCard(
                cornerRadius = 24.dp,
                gradientBorder = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("main_balance_card")
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Saldo Utama Xeraz",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = XerazRepository.formatRupiah(user?.balance ?: 0.0),
                                style = MaterialTheme.typography.displayLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(XerazEmerald.copy(alpha = 0.2f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "KYC Terverifikasi",
                                color = XerazEmerald,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Secondary Sub-balances (Bonus, Cashback, Points)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        SubBalanceItem(
                            label = "Saldo Bonus",
                            value = XerazRepository.formatRupiah(user?.bonusBalance ?: 0.0)
                        )
                        SubBalanceItem(
                            label = "Poin Cashback",
                            value = XerazRepository.formatRupiah(user?.cashbackPoints ?: 0.0)
                        )
                        SubBalanceItem(
                            label = "Reward Coins",
                            value = "${user?.rewardCoins ?: 0} Coins"
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Main Action Quick Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        ActionButton(
                            label = "Transfer",
                            icon = Icons.Default.Send,
                            color = XerazEmerald,
                            testTag = "btn_quick_transfer",
                            onClick = onNavigateTransfer
                        )
                        ActionButton(
                            label = "Top Up",
                            icon = Icons.Default.Add,
                            color = XerazCyan,
                            testTag = "btn_quick_topup",
                            onClick = onNavigateTopUp
                        )
                        ActionButton(
                            label = "Bayar",
                            icon = Icons.Default.Receipt,
                            color = XerazPurple,
                            testTag = "btn_quick_pay",
                            onClick = { onNavigatePayBill(TransactionType.PAY_PLN) }
                        )
                        ActionButton(
                            label = "Tarik Saldo",
                            icon = Icons.Default.ArrowUpward,
                            color = XerazGold,
                            testTag = "btn_quick_withdraw",
                            onClick = onNavigateWithdraw
                        )
                    }
                }
            }
        }

        // Services Menu Grid
        item {
            Text(
                text = "Layanan Dompet Digital",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ServiceMenuItem("Pulsa & Data", Icons.Default.PhoneAndroid) { onNavigatePayBill(TransactionType.PAY_PULSA) }
                ServiceMenuItem("Listrik PLN", Icons.Default.ElectricBolt) { onNavigatePayBill(TransactionType.PAY_PLN) }
                ServiceMenuItem("Air PDAM", Icons.Default.WaterDrop) { onNavigatePayBill(TransactionType.PAY_PDAM) }
                ServiceMenuItem("Internet & TV", Icons.Default.LiveTv) { onNavigatePayBill(TransactionType.PAY_INTERNET) }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ServiceMenuItem("BPJS Kesehatan", Icons.Default.ShieldMoon) { onNavigatePayBill(TransactionType.PAY_BPJS) }
                ServiceMenuItem("Voucher Game", Icons.Default.SportsEsports) { onNavigatePayBill(TransactionType.PAY_GAME) }
                ServiceMenuItem("Streaming", Icons.Default.LocalActivity) { onNavigatePayBill(TransactionType.PAY_STREAMING) }
                ServiceMenuItem("Transfer Massal", Icons.Default.Groups) { onNavigateTransfer() }
            }
        }

        // Banner Promo
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.xeraz_banner_1785896244911),
                        contentDescription = "Promo Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        // Financial Chart
        item {
            FinancialFlowChart()
        }

        // Recent Transactions Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Riwayat Transaksi Terbaru",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = onSeeAllHistory) {
                    Text("Lihat Semua", color = XerazEmerald)
                }
            }
        }

        // Recent Transactions
        items(recentTransactions.take(5)) { tx ->
            TransactionItemCard(
                transaction = tx,
                onClick = { onTransactionClick(tx) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun SubBalanceItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun ActionButton(
    label: String,
    icon: ImageVector,
    color: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.2f))
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun ServiceMenuItem(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(80.dp)
            .clickable { onClick() }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = XerazEmerald,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
