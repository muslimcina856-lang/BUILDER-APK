package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AuditLogDao
import com.example.data.dao.MerchantDao
import com.example.data.dao.NotificationDao
import com.example.data.dao.PromoDao
import com.example.data.dao.SupportTicketDao
import com.example.data.dao.TransactionDao
import com.example.data.dao.UserDao
import com.example.data.model.AuditLogEntity
import com.example.data.model.MemberLevel
import com.example.data.model.MerchantEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.PromoEntity
import com.example.data.model.SupportTicketEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionStatus
import com.example.data.model.TransactionType
import com.example.data.model.UserEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        TransactionEntity::class,
        PromoEntity::class,
        NotificationEntity::class,
        SupportTicketEntity::class,
        AuditLogEntity::class,
        MerchantEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class XerazDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun transactionDao(): TransactionDao
    abstract fun promoDao(): PromoDao
    abstract fun notificationDao(): NotificationDao
    abstract fun supportTicketDao(): SupportTicketDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun merchantDao(): MerchantDao

    companion object {
        @Volatile
        private var INSTANCE: XerazDatabase? = null

        fun getDatabase(context: Context): XerazDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    XerazDatabase::class.java,
                    "xeraz_wallet.db"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateDatabase(database)
                    }
                }
            }
        }

        private suspend fun populateDatabase(db: XerazDatabase) {
            val userDao = db.userDao()
            val txDao = db.transactionDao()
            val promoDao = db.promoDao()
            val notifDao = db.notificationDao()
            val merchantDao = db.merchantDao()
            val auditDao = db.auditLogDao()
            val ticketDao = db.supportTicketDao()

            // Seed User
            val initialUser = UserEntity(
                id = "USR_1001",
                fullName = "Rizky Xeraz",
                username = "rizkyxeraz",
                email = "rizky@xeraz.wallet",
                phoneNumber = "081234567890",
                passwordHash = "password123",
                profileImageUri = "",
                balance = 3850000.0,
                bonusBalance = 250000.0,
                cashbackPoints = 68500.0,
                rewardCoins = 1850,
                memberLevel = MemberLevel.GOLD,
                pinCode = "123456",
                isKycVerified = true,
                kycKtpNumber = "3171012304950002"
            )
            userDao.insertOrUpdate(initialUser)

            // Seed Transactions
            val now = System.currentTimeMillis()
            val sampleTransactions = listOf(
                TransactionEntity(
                    id = "TX982301",
                    title = "Top Up Virtual Account BCA",
                    type = TransactionType.TOPUP_VA,
                    amount = 1500000.0,
                    adminFee = 0.0,
                    cashbackEarned = 15000.0,
                    recipientName = "Virtual Account BCA",
                    recipientDetail = "880192837491",
                    category = "TopUp",
                    status = TransactionStatus.SUCCESS,
                    notes = "Gaji Tambahan & Deposit",
                    timestamp = now - 3600000L * 2,
                    referenceCode = "XRZ-VA-982301"
                ),
                TransactionEntity(
                    id = "TX982302",
                    title = "Pembayaran QRIS Starbucks Reserve",
                    type = TransactionType.QR_PAYMENT,
                    amount = 78000.0,
                    adminFee = 0.0,
                    cashbackEarned = 7800.0,
                    recipientName = "Starbucks Grand Indonesia",
                    recipientDetail = "ID2023910293102",
                    category = "Food & Drink",
                    status = TransactionStatus.SUCCESS,
                    notes = "Iced Velvet Latte",
                    timestamp = now - 3600000L * 18,
                    referenceCode = "XRZ-QR-982302"
                ),
                TransactionEntity(
                    id = "TX982303",
                    title = "Transfer ke BNI - Ahmad Fauzi",
                    type = TransactionType.TRANSFER_BANK,
                    amount = 350000.0,
                    adminFee = 2500.0,
                    cashbackEarned = 0.0,
                    recipientName = "Ahmad Fauzi",
                    recipientDetail = "Bank BNI - 098123746",
                    category = "Transfer",
                    status = TransactionStatus.SUCCESS,
                    notes = "Bayar sewa studio",
                    timestamp = now - 3600000L * 30,
                    referenceCode = "XRZ-TR-982303"
                ),
                TransactionEntity(
                    id = "TX982304",
                    title = "Token Listrik PLN 100K",
                    type = TransactionType.PAY_PLN,
                    amount = 101500.0,
                    adminFee = 1500.0,
                    cashbackEarned = 3000.0,
                    recipientName = "PLN Prepaid",
                    recipientDetail = "IDEL 539102938102",
                    category = "Bill",
                    status = TransactionStatus.SUCCESS,
                    notes = "Token Listrik Rumah",
                    timestamp = now - 3600000L * 52,
                    referenceCode = "XRZ-PLN-982304"
                ),
                TransactionEntity(
                    id = "TX982305",
                    title = "Transfer Antar Xeraz - Maya Putri",
                    type = TransactionType.TRANSFER_USER,
                    amount = 200000.0,
                    adminFee = 0.0,
                    cashbackEarned = 2000.0,
                    recipientName = "Maya Putri",
                    recipientDetail = "@mayaputri / 081987654321",
                    category = "Transfer",
                    status = TransactionStatus.SUCCESS,
                    notes = "Patungan Makan Siang",
                    timestamp = now - 3600000L * 70,
                    referenceCode = "XRZ-TRU-982305"
                )
            )
            sampleTransactions.forEach { txDao.insertTransaction(it) }

            // Seed Promos
            val samplePromos = listOf(
                PromoEntity(
                    id = "PRM_01",
                    title = "Mega Cashback QRIS 30%",
                    code = "XRZQR30",
                    discountDescription = "Cashback hingga Rp 25.000 untuk transaksi QRIS pertama minggu ini",
                    minTransaction = 50000.0,
                    cashbackPercent = 30.0,
                    maxCashback = 25000.0,
                    expiryDate = "31 Aug 2026",
                    category = "QRIS"
                ),
                PromoEntity(
                    id = "PRM_02",
                    title = "Bebas Biaya Admin Transfer Bank",
                    code = "FREEADMIN",
                    discountDescription = "Gratis biaya admin transfer ke seluruh bank Indonesia 10x per bulan",
                    minTransaction = 100000.0,
                    cashbackPercent = 100.0,
                    maxCashback = 2500.0,
                    expiryDate = "15 Sep 2026",
                    category = "Transfer"
                ),
                PromoEntity(
                    id = "PRM_03",
                    title = "Diskon Tagihan PLN & PDAM 20%",
                    code = "TAGIHANHEMAT",
                    discountDescription = "Potongan langsung tagihan rutin bulanan",
                    minTransaction = 75000.0,
                    cashbackPercent = 20.0,
                    maxCashback = 15000.0,
                    expiryDate = "30 Sep 2026",
                    category = "Bill"
                )
            )
            promoDao.insertPromos(samplePromos)

            // Seed Notifications
            val sampleNotifs = listOf(
                NotificationEntity(
                    title = "Bonus Top Up Berhasil!",
                    message = "Selamat! Anda mendapatkan cashback Rp 15.000 dari Top Up BCA Virtual Account.",
                    category = "PROMO",
                    timestamp = now - 3600000L * 2
                ),
                NotificationEntity(
                    title = "Keamanan Akun Terjaga",
                    message = "Pemeriksaan integritas perangkat: Bebas Root, Bebas Emulator, SSL Pinning Aktif.",
                    category = "SECURITY",
                    timestamp = now - 3600000L * 5
                ),
                NotificationEntity(
                    title = "Transfer Berhasil Sent",
                    message = "Transfer Rp 350.000 ke Ahmad Fauzi (BNI) telah diproses secara real-time BI-FAST.",
                    category = "TRANSACTION",
                    timestamp = now - 3600000L * 30
                )
            )
            sampleNotifs.forEach { notifDao.insertNotification(it) }

            // Seed Merchants
            val sampleMerchants = listOf(
                MerchantEntity(
                    id = "MCH_101",
                    name = "Starbucks Coffee",
                    category = "Coffee & Bakery",
                    qrisCode = "00020101021126620016ID.CO.XERAZ.WWW01189360001800000000015204581253033605802ID5916Starbucks Coffee6007Jakarta61051011063041A9B",
                    address = "Grand Indonesia Mall, Ground Floor, Jakarta Pusat",
                    rating = 4.9
                ),
                MerchantEntity(
                    id = "MCH_102",
                    name = "Indomaret Point",
                    category = "Retail & Minimarket",
                    qrisCode = "00020101021126620016ID.CO.XERAZ.WWW01189360001800000000025204581253033605802ID5916Indomaret Point6007Jakarta61051011063042C8D",
                    address = "Jl. Sudirman No. 45, Jakarta Selatan",
                    rating = 4.7
                ),
                MerchantEntity(
                    id = "MCH_103",
                    name = "Kopi Kenangan",
                    category = "Beverages",
                    qrisCode = "00020101021126620016ID.CO.XERAZ.WWW01189360001800000000035204581253033605802ID5913Kopi Kenangan6007Jakarta61051011063043E9F",
                    address = "Pacific Place Mall Lt. 3, Jakarta Pusat",
                    rating = 4.8
                )
            )
            merchantDao.insertMerchants(sampleMerchants)

            // Seed Audit Log
            auditDao.insertLog(
                AuditLogEntity(
                    action = "INITIAL_SYSTEM_BOOT",
                    details = "Xeraz Wallet Engine v2.5.0 launched. Security sandbox active.",
                    deviceModel = "Pixel 8 Pro (Simulated)",
                    ipAddress = "10.0.2.15"
                )
            )

            // Seed Support Ticket
            ticketDao.insertTicket(
                SupportTicketEntity(
                    id = "TCK-88219",
                    subject = "Pertanyaan Mengenai Level Gold Rewards",
                    message = "Halo Tim Xeraz, bagaimana cara meningkatkan poin multiplier di level Gold?",
                    reply = "Halo Rizky! Pada level Gold, setiap transaksi bernilai Rp 10.000 akan secara otomatis memberikan 2x Reward Coins dan bonus cashback 5%. Terima kasih!",
                    status = "RESOLVED",
                    createdAt = now - 86400000L * 3
                )
            )
        }
    }
}
