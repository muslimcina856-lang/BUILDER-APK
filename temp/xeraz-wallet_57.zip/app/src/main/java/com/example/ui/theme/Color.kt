package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val XerazNavy = Color(0xFF0F172A)
val XerazDarkBg = Color(0xFF0B0F19)
val XerazAmoledBg = Color(0xFF000000)

val XerazEmerald = Color(0xFF10B981)
val XerazEmeraldLight = Color(0xFF34D399)
val XerazEmeraldDark = Color(0xFF059669)

val XerazCyan = Color(0xFF06B6D4)
val XerazPurple = Color(0xFF8B5CF6)
val XerazGold = Color(0xFFF59E0B)
val XerazRed = Color(0xFFEF4444)

val XerazGlassBgDark = Color(0x2B1E293B)
val XerazGlassBorderDark = Color(0x33FFFFFF)
val XerazGlassCardDark = Color(0x1AFFFFFF)

val XerazSurfaceLight = Color(0xFFF8FAFC)
val XerazCardLight = Color(0xFFFFFFFF)
val XerazTextLightPrimary = Color(0xFF0F172A)
val XerazTextLightSecondary = Color(0xFF64748B)

val XerazTextDarkPrimary = Color(0xFFF8FAFC)
val XerazTextDarkSecondary = Color(0xFF94A3B8)
