package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.XerazDatabase
import com.example.data.model.AuditLogEntity
import com.example.data.model.MerchantEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.PromoEntity
import com.example.data.model.SupportTicketEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.model.UserEntity
import com.example.data.repository.XerazRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    SPLASH,
    AUTH_LOGIN,
    AUTH_REGISTER,
    AUTH_OTP,
    PIN_ENTRY,
    MAIN_DASHBOARD,
    HISTORY,
    QR_CENTER,
    PROMO_REWARDS,
    PROFILE_SETTINGS,
    TRANSFER_FLOW,
    TOPUP_FLOW,
    PAY_BILL_FLOW,
    WITHDRAW_FLOW,
    ADMIN_PANEL
}

class XerazViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = XerazRepository(XerazDatabase.getDatabase(application))

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val transactions: StateFlow<List<TransactionEntity>> = repository.allTransactionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val promos: StateFlow<List<PromoEntity>> = repository.allPromosFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = repository.allNotificationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<SupportTicketEntity>> = repository.allTicketsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.allAuditLogsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val merchants: StateFlow<List<MerchantEntity>> = repository.allMerchantsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Navigation State
    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: Home, 1: History, 2: Pay/QR, 3: Promos, 4: Profile
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    // Auth & Security state
    private val _isLoggedIn = MutableStateFlow(true) // Auto-login enabled for smooth demo
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _pinVerificationPending = MutableStateFlow<(() -> Unit)?>(null)
    val pinVerificationPending: StateFlow<(() -> Unit)?> = _pinVerificationPending.asStateFlow()

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage

    private val _aiChatMessages = MutableStateFlow(
        listOf(
            "Xeraz Bot" to "Halo! Saya Asisten AI Xeraz Wallet. Ada yang bisa saya bantu terkait transaksi, promo cashback, atau keamanan akun Anda?"
        )
    )
    val aiChatMessages: StateFlow<List<Pair<String, String>>> = _aiChatMessages.asStateFlow()

    // Filters for History
    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    private val _historyCategoryFilter = MutableStateFlow("ALL")
    val historyCategoryFilter: StateFlow<String> = _historyCategoryFilter.asStateFlow()

    // Selected Transaction for Detail Modal
    private val _selectedTransaction = MutableStateFlow<TransactionEntity?>(null)
    val selectedTransaction: StateFlow<TransactionEntity?> = _selectedTransaction.asStateFlow()

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun selectTab(index: Int) {
        _selectedTab.value = index
        _currentScreen.value = AppScreen.MAIN_DASHBOARD
    }

    fun setHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    fun setHistoryCategoryFilter(category: String) {
        _historyCategoryFilter.value = category
    }

    fun selectTransactionForDetail(tx: TransactionEntity?) {
        _selectedTransaction.value = tx
    }

    fun requirePinVerification(onSuccess: () -> Unit) {
        _pinVerificationPending.value = onSuccess
        _currentScreen.value = AppScreen.PIN_ENTRY
    }

    fun executePendingPinAction(pinInput: String) {
        viewModelScope.launch {
            if (repository.verifyPin(pinInput)) {
                val action = _pinVerificationPending.value
                _pinVerificationPending.value = null
                _currentScreen.value = AppScreen.MAIN_DASHBOARD
                action?.invoke()
            } else {
                _toastMessage.emit("PIN Salah! Silakan coba lagi.")
            }
        }
    }

    fun cancelPinVerification() {
        _pinVerificationPending.value = null
        _currentScreen.value = AppScreen.MAIN_DASHBOARD
    }

    // --- ACTIONS ---

    fun transferUser(phoneOrUsername: String, amount: Double, notes: String) {
        requirePinVerification {
            viewModelScope.launch {
                val res = repository.performTransferUser(phoneOrUsername, amount, notes)
                res.onSuccess { tx ->
                    _toastMessage.emit("Transfer ${XerazRepository.formatRupiah(amount)} ke $phoneOrUsername Berhasil!")
                    _selectedTransaction.value = tx
                }.onFailure { err ->
                    _toastMessage.emit("Gagal: ${err.message}")
                }
            }
        }
    }

    fun transferBank(bankName: String, accountNumber: String, recipientName: String, amount: Double, notes: String) {
        requirePinVerification {
            viewModelScope.launch {
                val res = repository.performTransferBank(bankName, accountNumber, recipientName, amount, notes)
                res.onSuccess { tx ->
                    _toastMessage.emit("Transfer Bank $bankName Sukses!")
                    _selectedTransaction.value = tx
                }.onFailure { err ->
                    _toastMessage.emit("Gagal: ${err.message}")
                }
            }
        }
    }

    fun topUp(method: String, amount: Double) {
        viewModelScope.launch {
            val res = repository.performTopUp(method, amount)
            res.onSuccess { tx ->
                _toastMessage.emit("Top Up ${XerazRepository.formatRupiah(amount)} Sukses!")
                _selectedTransaction.value = tx
            }.onFailure { err ->
                _toastMessage.emit("Gagal: ${err.message}")
            }
        }
    }

    fun payBill(type: TransactionType, billerName: String, customerId: String, amount: Double, promoCode: String) {
        requirePinVerification {
            viewModelScope.launch {
                val res = repository.performBillPayment(type, billerName, customerId, amount, promoCode)
                res.onSuccess { tx ->
                    _toastMessage.emit("Pembayaran $billerName Berhasil!")
                    _selectedTransaction.value = tx
                }.onFailure { err ->
                    _toastMessage.emit("Gagal: ${err.message}")
                }
            }
        }
    }

    fun payQr(merchantName: String, amount: Double, qrisPayload: String) {
        requirePinVerification {
            viewModelScope.launch {
                val res = repository.performQrPayment(merchantName, amount, qrisPayload)
                res.onSuccess { tx ->
                    _toastMessage.emit("Pembayaran QRIS $merchantName Sukses!")
                    _selectedTransaction.value = tx
                }.onFailure { err ->
                    _toastMessage.emit("Gagal: ${err.message}")
                }
            }
        }
    }

    fun withdraw(destination: String, accountNo: String, amount: Double) {
        requirePinVerification {
            viewModelScope.launch {
                val res = repository.performWithdraw(destination, accountNo, amount)
                res.onSuccess { tx ->
                    _toastMessage.emit("Tarik Saldo ${XerazRepository.formatRupiah(amount)} Sukses!")
                    _selectedTransaction.value = tx
                }.onFailure { err ->
                    _toastMessage.emit("Gagal: ${err.message}")
                }
            }
        }
    }

    fun claimPromo(promoId: String) {
        viewModelScope.launch {
            repository.claimPromo(promoId)
            _toastMessage.emit("Promo Voucher Berhasil Diklaim!")
        }
    }

    fun redeemCashbackToBalance(points: Double) {
        viewModelScope.launch {
            val res = repository.convertPointsToBalance(points)
            res.onSuccess {
                _toastMessage.emit("Penukaran Poin ke Saldo Utama Berhasil!")
            }.onFailure { err ->
                _toastMessage.emit("Gagal: ${err.message}")
            }
        }
    }

    fun updateTheme(themeName: String) {
        viewModelScope.launch {
            repository.updateThemePreference(themeName)
            _toastMessage.emit("Tema diubah ke $themeName")
        }
    }

    fun toggleBiometrics(enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleBiometrics(enabled)
            _toastMessage.emit(if (enabled) "Sidik Jari Diaktifkan" else "Sidik Jari Dinonaktifkan")
        }
    }

    fun toggleFaceUnlock(enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleFaceUnlock(enabled)
            _toastMessage.emit(if (enabled) "Face Unlock Diaktifkan" else "Face Unlock Dinonaktifkan")
        }
    }

    fun sendAiMessage(userPrompt: String) {
        if (userPrompt.isBlank()) return
        val current = _aiChatMessages.value.toMutableList()
        current.add("Anda" to userPrompt)
        _aiChatMessages.value = current

        viewModelScope.launch {
            val lower = userPrompt.lowercase()
            val reply = when {
                lower.contains("saldo") || lower.contains("balance") -> "Saldo utama Anda dapat dilihat di Dashboard. Anda juga memiliki Saldo Bonus & Poin Cashback yang dapat ditukarkan kapan saja!"
                lower.contains("topup") || lower.contains("isi") -> "Untuk Top Up, silakan tekan tombol 'Top Up' di Dashboard. Pilih metode Virtual Account, Debit Card, atau Minimarket."
                lower.contains("transfer") || lower.contains("kirim") -> "Transfer gratis antar sesama pengguna Xeraz Wallet, atau gunakan BI-FAST untuk transfer bank dengan biaya admin hanya Rp 2.500."
                lower.contains("qris") || lower.contains("scan") -> "Xeraz Wallet mendukung Standar QRIS Nasional. Buka tab 'QRIS' untuk memindai merchant atau menampilkan QR Code pribadi Anda."
                lower.contains("promo") || lower.contains("cashback") -> "Cek menu 'Promo & Rewards' untuk mengklaim voucher cashback hingga 30% dan misi harian!"
                else -> "Terima kasih atas pertanyaannya! Tim CS Xeraz dan Sistem AI kami siap membantu kebutuhan transaksi digital Anda 24/7."
            }
            val updated = _aiChatMessages.value.toMutableList()
            updated.add("Xeraz Bot" to reply)
            _aiChatMessages.value = updated
        }
    }

    fun submitSupportTicket(subject: String, message: String) {
        viewModelScope.launch {
            repository.submitSupportTicket(subject, message)
            _toastMessage.emit("Tiket Bantuan Terkirim!")
        }
    }

    fun adminSetBalance(newBalance: Double) {
        viewModelScope.launch {
            repository.adminUpdateBalance(newBalance)
            _toastMessage.emit("Saldo berhasil diubah oleh Admin!")
        }
    }

    fun markNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    fun logout() {
        _isLoggedIn.value = false
        _currentScreen.value = AppScreen.AUTH_LOGIN
    }

    fun loginWithEmailPhone(input: String, pass: String) {
        viewModelScope.launch {
            _isLoggedIn.value = true
            _currentScreen.value = AppScreen.MAIN_DASHBOARD
            _toastMessage.emit("Selamat datang kembali di Xeraz Wallet!")
        }
    }
}
