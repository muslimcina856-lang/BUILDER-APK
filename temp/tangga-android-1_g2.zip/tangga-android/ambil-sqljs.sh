#!/usr/bin/env bash
# Memuat turun SQL.js (SQLite dikompil ke WebAssembly) ke dalam assets.
# Jalankan sekali sebelum binaan pertama. APK bertambah kira-kira 1.5 MB.
set -euo pipefail
VERSI="${1:-1.13.0}"
DEST="app/src/main/assets/sqljs"
mkdir -p "$DEST"
URL="https://github.com/sql-js/sql.js/releases/download/v${VERSI}/sqljs-wasm.zip"
echo "Memuat turun SQL.js ${VERSI}..."
curl -fL "$URL" -o /tmp/sqljs.zip
unzip -qo /tmp/sqljs.zip -d /tmp/sqljs
find /tmp/sqljs -name 'sql-wasm.js' -exec cp {} "$DEST/" \;
find /tmp/sqljs -name 'sql-wasm.wasm' -exec cp {} "$DEST/" \;
rm -rf /tmp/sqljs /tmp/sqljs.zip
echo "Siap. Saiz aset:"
du -sh "$DEST"
