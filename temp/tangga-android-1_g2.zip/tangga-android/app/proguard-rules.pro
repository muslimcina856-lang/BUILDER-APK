# Antara muka JavaScript dipanggil melalui pantulan oleh WebView.
# Tanpa peraturan ini, binaan release mengaburkan nama kaedah dan jambatan
# gagal secara senyap — ujian tergantung, kemajuan tidak pernah dilaporkan.
-keepclassmembers class my.tangga.enjin.EnjinJs$Jambatan {
    public *;
}
-keepclassmembers class my.tangga.enjin.EnjinJs$JambatanKemajuan {
    public *;
}
-keepattributes JavascriptInterface
