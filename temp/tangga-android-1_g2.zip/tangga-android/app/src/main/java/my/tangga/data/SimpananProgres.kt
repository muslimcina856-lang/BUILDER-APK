package my.tangga.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import my.tangga.SemuaProgres

private val Context.simpanan: DataStore<Preferences> by preferencesDataStore(name = "tangga")
private val KUNCI = stringPreferencesKey("progres_v2")
private val json = Json { ignoreUnknownKeys = true }

/** Progres disimpan sebagai satu blob JSON. Semuanya kekal pada peranti. */
class SimpananProgres(private val konteks: Context) {

    val aliran: Flow<SemuaProgres> = konteks.simpanan.data.map { p ->
        val mentah = p[KUNCI] ?: return@map SemuaProgres()
        runCatching { json.decodeFromString<SemuaProgres>(mentah) }.getOrElse { SemuaProgres() }
    }

    suspend fun simpan(progres: SemuaProgres) {
        konteks.simpanan.edit { it[KUNCI] = json.encodeToString(progres) }
    }
}
