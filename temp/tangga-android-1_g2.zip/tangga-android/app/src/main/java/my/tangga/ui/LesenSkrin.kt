package my.tangga.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import my.tangga.Keadaan

/**
 * Atribusi sumber terbuka.
 *
 * Ini bukan hiasan. Apache-2.0 mewajibkan salinan lesen dihantar bersama
 * binari, dan MIT mewajibkan notis hak cipta dikekalkan. Membundel runtime
 * tanpa menunjukkan lesennya ialah pelanggaran, bukan sekadar tabiat buruk.
 */
@Composable
fun LesenSkrin(k: Keadaan, padaKembali: () -> Unit) {
    Column(Modifier.fillMaxSize()) {

        KacaChrome(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Butang("\u2190 Kembali", padaKlik = padaKembali)
                Spacer(Modifier.weight(1f))
                Eyebrow("Lesen")
            }
        }

        if (k.lesen.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Nota(
                    "Tiada fail lesen dijumpai dalam aset. Jika kau membundel runtime, " +
                        "jalankan skrip ambil-*.sh supaya lesennya disalin masuk.",
                    merah = true,
                    modifier = Modifier.padding(20.dp),
                )
            }
            return@Column
        }

        LazyColumn(
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            itemsIndexed(k.lesen) { _, (nama, isi) ->
                Kaca(Modifier.fillMaxWidth(), bentuk = Bentuk.KadKecil) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            nama,
                            color = Warna.Oker,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            letterSpacing = 0.8.sp,
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            isi.trim(),
                            color = Warna.Senyap,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.5.sp,
                            lineHeight = 16.sp,
                        )
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
