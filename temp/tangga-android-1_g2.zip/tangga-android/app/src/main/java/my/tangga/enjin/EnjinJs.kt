package my.tangga.enjin

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import my.tangga.Bahasa
import my.tangga.Kemajuan
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Runtime bersandbox untuk satu laluan bahasa.
 *
 * JavaScript berjalan terus dalam enjin JS WebView. Python berjalan pada Pyodide
 * (CPython dikompil ke WebAssembly) yang dibundel dalam aset — aplikasi tiada
 * kebenaran internet, jadi tiada apa yang dimuat turun semasa jalanan.
 *
 * WebView ini tidak pernah dipaparkan dan tidak pernah memuatkan URL luar. Aset
 * dihidangkan melalui WebViewAssetLoader kerana Pyodide memerlukan URL asas
 * sebenar untuk mencari fail `.wasm` dan `.zip` di sebelahnya.
 */
class EnjinJs(
    private val konteks: Context,
    private val bahasa: Bahasa,
) {

    private var web: WebView? = null
    private var siap: CompletableDeferred<Boolean> = CompletableDeferred()
    private val menunggu = ConcurrentHashMap<String, CompletableDeferred<String>>()
    private val kaunter = AtomicLong(0)

    /**
     * Hanya satu permintaan pada satu masa.
     *
     * Tanpa ini, dua ketukan pantas menghantar dua permintaan serentak. Bila satu
     * tamat masa ia memusnahkan WebView, yang membatalkan permintaan satu lagi —
     * dan ketukan itu kelihatan seperti langsung tidak berfungsi.
     */
    private val kunci = Mutex()

    /** Benar bila runtime berat sudah sedia. Untuk JavaScript ia sentiasa benar. */
    @Volatile
    var panas: Boolean = false
        private set

    private val _kemajuan = MutableStateFlow<Kemajuan?>(null)
    /** Peringkat semasa permulaan runtime. Null bermakna melahu atau sudah sedia. */
    val kemajuan: StateFlow<Kemajuan?> = _kemajuan.asStateFlow()

    private fun lapor(peringkat: String, pecahan: Float?) {
        _kemajuan.value = Kemajuan(peringkat, pecahan)
    }

    inner class JambatanKemajuan {
        @JavascriptInterface
        fun lapor(peringkat: String, pecahan: Float) {
            _kemajuan.value = Kemajuan(peringkat, if (pecahan < 0f) null else pecahan)
        }
    }

    private val pemuatAset by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(konteks))
            .build()
    }

    private fun bacaAset(nama: String): String =
        konteks.assets.open(nama).bufferedReader().use { it.readText() }

    inner class Jambatan {
        @JavascriptInterface
        fun balas(id: String, json: String) {
            menunggu.remove(id)?.complete(json)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun bina() = withContext(Dispatchers.Main) {
        web?.destroy()
        menunggu.values.forEach {
            it.completeExceptionally(IllegalStateException("enjin dimulakan semula"))
        }
        menunggu.clear()
        siap = CompletableDeferred()
        panas = false
        lapor("Membuka runtime", 0f) // WebView baharu bermakna Pyodide perlu dimuat semula

        val w = WebView(konteks)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            blockNetworkLoads = true
        }
        w.addJavascriptInterface(Jambatan(), "AndroidJambatan")
        w.addJavascriptInterface(JambatanKemajuan(), "AndroidKemajuan")
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                v: WebView,
                r: WebResourceRequest,
            ): WebResourceResponse? = pemuatAset.shouldInterceptRequest(r.url)

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = true

            override fun onPageFinished(v: WebView, url: String) {
                // Skrip disuntik selepas halaman siap, bukan ditanam dalam HTML.
                // Bank tugasan mengandungi rentetan seperti "<script>" yang akan
                // memecahkan dokumen kalau ia ditulis sebagai teks HTML.
                suntikBerturut(v, bahasa.aset.toMutableList(), siap)
            }
        }
        w.loadUrl(ASAS + "kosong.html")
        web = w
    }

    /** Aset mesti dinilai mengikut susunan: pyodide.js dahulu, kemudian python.js. */
    private fun suntikBerturut(
        v: WebView,
        baki: MutableList<String>,
        selesai: CompletableDeferred<Boolean>,
        jumlah: Int = baki.size,
    ) {
        if (baki.isEmpty()) {
            selesai.complete(true)
            return
        }
        val nama = baki.removeAt(0)
        val sumber = runCatching { bacaAset(nama) }.getOrNull()
        if (sumber != null) {
            val siapKira = jumlah - baki.size
            lapor(
                "Memuat ${nama.substringAfterLast('/')} (${sumber.length / 1024} KB)",
                siapKira.toFloat() / jumlah,
            )
        }
        if (sumber == null) {
            // Aset hilang (contohnya Pyodide belum dipasang). Lapor kegagalan
            // dan jangan tergantung menunggu sesuatu yang takkan tiba.
            selesai.complete(false)
            return
        }
        v.evaluateJavascript(sumber) { suntikBerturut(v, baki, selesai, jumlah) }
    }

    private suspend fun sediakan() {
        if (web == null) bina()
        siap.await()
    }

    suspend fun mula() = kunci.withLock { sediakan() }

    /** Mesti dipanggil sambil memegang [kunci]. */
    private suspend fun laksanaDalam(js: String, id: String, hadMs: Long): String? {
        val d = CompletableDeferred<String>()
        menunggu[id] = d
        withContext(Dispatchers.Main) { web?.evaluateJavascript(js, null) }
        val hasil = withTimeoutOrNull(hadMs) { runCatching { d.await() }.getOrNull() }
        menunggu.remove(id)
        if (hasil == null) bina() // JS tergantung — buang dan bina semula
        return hasil
    }

    private suspend fun laksana(js: String, id: String, hadMs: Long): String? = kunci.withLock {
        sediakan()
        laksanaDalam(js, id, hadMs)
    }

    private fun idBaharu() = "p" + kaunter.incrementAndGet()

    /** Panggilan segerak: nilai ekspresi dihantar terus ke jambatan. */
    private suspend fun tanya(ekspresi: String, hadMs: Long = 8_000): String? {
        val id = idBaharu()
        return laksana("AndroidJambatan.balas('$id', ${bahasa.global}.$ekspresi);", id, hadMs)
    }

    suspend fun jumlahLevel(): Int =
        tanya("jumlah()")?.filter { it.isDigit() }?.toIntOrNull() ?: 0

    suspend fun bab(): String? = tanya("bab()")

    suspend fun level(n: Int): String? = tanya("level($n)")

    suspend fun semakRamal(n: Int, teks: String): String? =
        tanya("semakRamal($n, ${petik(teks)})")

    /**
     * Menjalankan kod pengguna. Kedua-dua enjin memulangkan Promise, jadi satu
     * bentuk panggilan memadai.
     */
    suspend fun jalan(n: Int, kod: String, hadMs: Long = hadJalan()): String {
        val id = idBaharu()
        val js = "Promise.resolve(${bahasa.global}.jalan($n, ${petik(kod)})).then(" +
            "function (r) { AndroidJambatan.balas('$id', r); }, " +
            "function (e) { AndroidJambatan.balas('$id', JSON.stringify({ fatal: String(e && e.message || e) })); });"
        return laksana(js, id, hadMs)
            ?: "{\"fatal\":\"Masa tamat selepas ${hadMs / 1000} saat \\u2014 kemungkinan besar ada gelung yang tak berhenti.\"}"
    }

    /**
     * Memuatkan runtime berat. Untuk Python ini bermakna mengkompil Pyodide,
     * yang mengambil masa beberapa saat. Panggil di latar — jangan sekat UI.
     */
    suspend fun panaskan(): Boolean = kunci.withLock {
        sediakan()
        if (panas) return@withLock true

        if (bahasa.asetPanas.isNotEmpty()) {
            val siapPanas = CompletableDeferred<Boolean>()
            withContext(Dispatchers.Main) {
                val v = web
                if (v == null) siapPanas.complete(false)
                else suntikBerturut(v, bahasa.asetPanas.toMutableList(), siapPanas)
            }
            val dimuat = withTimeoutOrNull(30_000) { runCatching { siapPanas.await() }.getOrNull() }
            if (dimuat != true) return@withLock false
        }

        // Kedua-duanya menggunakan enjin WebView sendiri — tiada apa nak dipanaskan.
        if (bahasa == Bahasa.JAVASCRIPT || bahasa == Bahasa.HTML) {
            panas = true
            _kemajuan.value = null
            return@withLock true
        }

        lapor(
            when (bahasa) {
                Bahasa.PYTHON -> "Mengkompil CPython"
                Bahasa.SQL -> "Memulakan SQLite"
                Bahasa.TYPESCRIPT -> "Memuat pengkompil TypeScript"
                Bahasa.LUA -> "Memulakan Lua"
                Bahasa.JAVASCRIPT, Bahasa.HTML -> "Menyedia"
            },
            null,
        )
        val id = idBaharu()
        val js = "Promise.resolve(${bahasa.global}.sedia()).then(" +
            "function () { AndroidJambatan.balas('$id', '{\"ok\":true}'); }, " +
            "function (e) { AndroidJambatan.balas('$id', JSON.stringify({ ok: false, ralat: String(e) })); });"
        val ok = laksanaDalam(js, id, 90_000)?.contains("\"ok\":true") == true
        panas = ok
        _kemajuan.value = if (ok) null else Kemajuan("Gagal dimuat", null)
        ok
    }

    private fun hadJalan() = when {
        bahasa == Bahasa.JAVASCRIPT -> 4_000L
        bahasa == Bahasa.HTML -> 8_000L
        bahasa == Bahasa.SQL -> if (panas) 8_000L else 20_000L
        bahasa == Bahasa.LUA -> if (panas) 8_000L else 20_000L
        bahasa == Bahasa.TYPESCRIPT -> if (panas) 25_000L else 60_000L
        panas -> 8_000L      // runtime sedia; ini benar-benar gelung tak berhenti
        else -> 45_000L      // termasuk permulaan Pyodide kali pertama
    }

    fun lepaskan() {
        web?.destroy()
        web = null
    }

    /** Melarikan rentetan Kotlin dengan selamat menjadi literal JavaScript. */
    private fun petik(s: String): String = JSONObject.quote(s)

    private companion object {
        const val ASAS = "https://appassets.androidplatform.net/assets/"
    }
}
