package my.tangga.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Brief tugasan datang dari bank JS dengan penanda ringan: `kod` dan **tebal**.
 * Ini menghuraikannya menjadi AnnotatedString.
 */
fun huraiPenanda(teks: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < teks.length) {
        val c = teks[i]
        if (c == '`') {
            val tutup = teks.indexOf('`', i + 1)
            if (tutup > i) {
                withStyle(
                    SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        color = Warna.Oker,
                        fontSize = 13.sp,
                    )
                ) { append(teks.substring(i + 1, tutup)) }
                i = tutup + 1
                continue
            }
        }
        if (c == '*' && i + 1 < teks.length && teks[i + 1] == '*') {
            val tutup = teks.indexOf("**", i + 2)
            if (tutup > i) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                    append(teks.substring(i + 2, tutup))
                }
                i = tutup + 2
                continue
            }
        }
        append(c)
        i++
    }
}

@Composable
fun Eyebrow(teks: String, modifier: Modifier = Modifier, warna: Color = Warna.Senyap) {
    Text(
        teks.uppercase(),
        modifier = modifier,
        color = warna,
        fontSize = 10.sp,
        letterSpacing = 1.8.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

/**
 * Butang.
 *
 * Tekanan mengecilkannya sedikit dengan spring, bukan tween — supaya ia
 * bertindak balas walaupun ketukan tiba pertengahan animasi. Butang utama
 * mendapat isian oker pejal; yang lain mendapat kaca.
 */
@Composable
fun Butang(
    teks: String,
    modifier: Modifier = Modifier,
    utama: Boolean = false,
    hidup: Boolean = true,
    padaKlik: () -> Unit,
) {
    val interaksi = remember { MutableInteractionSource() }
    val ditekan by interaksi.collectIsPressedAsState()
    val skala by animateFloatAsState(
        targetValue = if (ditekan && hidup) 0.955f else 1f,
        animationSpec = Gerak.pantas(),
        label = "tekan",
    )
    val kelegapan by animateFloatAsState(
        targetValue = if (hidup) 1f else 0.42f,
        animationSpec = Gerak.biasa(),
        label = "hidup",
    )

    val isi: Modifier = if (utama) {
        Modifier.background(
            Brush.linearGradient(
                listOf(Warna.Oker, Color(0xFFD99A16)),
                Offset(0f, 0f),
                Offset(0f, 120f),
            ),
            Bentuk.Butang,
        )
    } else {
        Modifier
            .background(Warna.KacaIsiPekat, Bentuk.Butang)
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(Warna.KacaTepiTerang, Warna.KacaTepiGelap),
                    Offset(0f, 0f),
                    Offset(200f, 60f),
                ),
                Bentuk.Butang,
            )
    }

    Box(
        modifier
            .graphicsLayer(scaleX = skala, scaleY = skala, alpha = kelegapan)
            .clip(Bentuk.Butang)
            .then(isi)
            .heightIn(min = 48.dp)
            .clickable(enabled = hidup, onClickLabel = teks) { padaKlik() }
            .padding(horizontal = 18.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            teks,
            color = if (utama) Warna.DasarDalam else Warna.Dakwat,
            fontSize = 12.sp,
            letterSpacing = 0.9.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
        )
    }
}

@Composable
fun Nota(teks: AnnotatedString, merah: Boolean = false, modifier: Modifier = Modifier) {
    val aksen = if (merah) Warna.Bata else Warna.Oker
    val latar = if (merah) Warna.BataRedup else Warna.OkerRedup
    Row(
        modifier
            .fillMaxWidth()
            .clip(Bentuk.KadKecil)
            .background(latar, Bentuk.KadKecil)
            .height(IntrinsicSize.Min)
    ) {
        Box(Modifier.width(3.dp).fillMaxHeight().background(aksen))
        Text(
            teks,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            color = Warna.Dakwat,
            fontSize = 13.5.sp,
            lineHeight = 21.sp,
        )
    }
}

@Composable
fun Nota(teks: String, merah: Boolean = false, modifier: Modifier = Modifier) =
    Nota(huraiPenanda(teks), merah, modifier)

/**
 * Kod dipaparkan pada permukaan pekat, bukan kaca.
 * Monospace di atas latar lutsinar yang bergerak sukar dibaca, dan kebolehbacaan
 * mengalahkan konsistensi visual di sini.
 */
@Composable
fun BlokKod(kod: String, modifier: Modifier = Modifier) {
    Text(
        kod,
        modifier = modifier
            .fillMaxWidth()
            .clip(Bentuk.KadKecil)
            .background(Warna.Editor, Bentuk.KadKecil)
            .border(1.dp, Warna.KacaTepiGelap, Bentuk.KadKecil)
            .padding(14.dp),
        color = Warna.Dakwat,
        fontFamily = FontFamily.Monospace,
        fontSize = 13.sp,
        lineHeight = 21.sp,
    )
}

/** Editor kod. Papan kekunci telefon tiada simbol pengaturcaraan, jadi kita bekalkan sendiri. */
@Composable
fun EditorKod(
    nilai: TextFieldValue,
    padaUbah: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier) {
        BasicTextField(
            value = nilai,
            onValueChange = padaUbah,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 200.dp)
                .clip(Bentuk.Medan)
                .background(Warna.Editor, Bentuk.Medan)
                .border(1.dp, Warna.KacaTepiGelap, Bentuk.Medan)
                .padding(14.dp),
            textStyle = LocalTextStyle.current.copy(
                color = Warna.Dakwat,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.5.sp,
                lineHeight = 22.sp,
            ),
            cursorBrush = SolidColor(Warna.Oker),
        )
        Spacer(Modifier.height(9.dp))
        BarSimbol { simbol ->
            val a = nilai.selection.min
            val b = nilai.selection.max
            val teksBaharu = nilai.text.substring(0, a) + simbol + nilai.text.substring(b)
            padaUbah(
                nilai.copy(
                    text = teksBaharu,
                    selection = androidx.compose.ui.text.TextRange(a + simbol.length),
                )
            )
        }
    }
}

private val SIMBOL = listOf(
    "{", "}", "(", ")", "[", "]", ";", "=", "=>", "<", ">", "!", "&&", "||",
    "'", "\"", "`", "+", "-", "*", "/", "%", ".", ",", "_", "  ",
)

@Composable
private fun BarSimbol(padaSisip: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(SIMBOL) { s ->
            CipSimbol(s) { padaSisip(s) }
        }
    }
}

@Composable
private fun CipSimbol(simbol: String, padaKlik: () -> Unit) {
    val interaksi = remember { MutableInteractionSource() }
    val ditekan by interaksi.collectIsPressedAsState()
    val skala by animateFloatAsState(
        targetValue = if (ditekan) 0.88f else 1f,
        animationSpec = Gerak.pantas(),
        label = "cip",
    )
    // Sasaran sentuh mesti sekurang-kurangnya 48dp walaupun latar kelihatan
    // lebih kecil. Padding menyerap bakinya supaya rupa kekal padat.
    Box(
        Modifier
            .graphicsLayer(scaleX = skala, scaleY = skala)
            .heightIn(min = 48.dp)
            .widthIn(min = 48.dp)
            .clickable(onClickLabel = "Sisip $simbol") { padaKlik() }
            .padding(vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) {
      Box(
        Modifier
            .widthIn(min = 40.dp)
            .height(38.dp)
            .clip(Bentuk.Butang)
            .background(Warna.KacaIsiPekat, Bentuk.Butang)
            .border(1.dp, Warna.KacaTepiGelap, Bentuk.Butang),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (simbol == "  ") "\u2192" else simbol,
            color = Warna.Dakwat,
            fontFamily = FontFamily.Monospace,
            fontSize = 14.sp,
        )
      }
    }
}

/**
 * Papan kemajuan permulaan runtime.
 *
 * Peringkat yang boleh diukur mendapat bar yang beranimasi ke nilainya. Peringkat
 * yang tidak boleh diukur — mengkompil WebAssembly — mendapat jalur bergerak dan
 * pembilang saat, supaya jelas ia masih berjalan dan bukannya tergantung.
 */
@Composable
fun PapanKemajuan(kemajuan: my.tangga.Kemajuan, modifier: Modifier = Modifier) {
    val pecahan by animateFloatAsState(
        targetValue = kemajuan.pecahan ?: 0f,
        animationSpec = Gerak.biasa(),
        label = "kemajuan",
    )
    Kaca(modifier.fillMaxWidth(), bentuk = Bentuk.KadKecil, aksen = Warna.Oker) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    kemajuan.peringkat,
                    color = Warna.Dakwat,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    when {
                        kemajuan.pecahan != null -> "${(kemajuan.pecahan * 100).toInt()}%"
                        kemajuan.saat > 0 -> "${kemajuan.saat}s"
                        else -> ""
                    },
                    color = Warna.Oker,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                )
            }
            Spacer(Modifier.height(11.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(Bentuk.Cip)
                    .background(Warna.KacaTepiGelap, Bentuk.Cip)
            ) {
                if (kemajuan.pecahan != null) {
                    Box(
                        Modifier
                            .fillMaxWidth(pecahan.coerceIn(0f, 1f))
                            .fillMaxHeight()
                            .background(Warna.Oker, Bentuk.Cip)
                    )
                } else {
                    JalurBergerak()
                }
            }
        }
    }
}

@Composable
private fun JalurBergerak() {
    val peralihan = rememberInfiniteTransition(label = "jalur")
    val kedudukan by peralihan.animateFloat(
        initialValue = -0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "kedudukan",
    )
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val lebar = maxWidth
        Box(
            Modifier
                .offset(x = lebar * kedudukan)
                .width(lebar * 0.35f)
                .fillMaxHeight()
                .background(Warna.Oker, Bentuk.Cip)
        )
    }
}

/** Menunjukkan sama ada runtime berat sudah sedia. Diam bila tiada apa nak dilapor. */
@Composable
fun StatusEnjin(memanaskan: Boolean, panas: Boolean, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = memanaskan || !panas,
        enter = fadeIn(Gerak.biasa()) + expandVertically(Gerak.biasa()),
        exit = fadeOut(Gerak.biasa()) + shrinkVertically(Gerak.biasa()),
        modifier = modifier,
    ) {
        Text(
            if (memanaskan) "\u25cf menyedia\u2026" else "\u25cb belum sedia",
            color = if (memanaskan) Warna.Oker else Warna.SenyapGelap,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
        )
    }
}

/** Pengesahan bahawa progres telah ditulis ke cakera. */
@Composable
fun PengesahanSimpan(modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(Bentuk.Cip)
            .background(Warna.HijauRedup, Bentuk.Cip)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "\u2713 PROGRES DISIMPAN",
            color = Warna.Hijau,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.5.sp,
            letterSpacing = 1.2.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
