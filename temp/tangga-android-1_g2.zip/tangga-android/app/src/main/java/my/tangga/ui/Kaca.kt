package my.tangga.ui

import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Blur sebenar memerlukan RenderEffect, iaitu API 31. minSdk kita 24. */
private val blurDisokong: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

/**
 * Latar aurora.
 *
 * Tiga blob berwarna bergerak perlahan di belakang segalanya. Inilah yang
 * menjadikan panel kaca kelihatan seperti kaca — tanpa warna yang berubah di
 * belakangnya, permukaan lutsinar hanya kelihatan kelabu dan mati.
 *
 * Blob dilukis besar dan kabur, dan bergerak dalam kitaran panjang, jadi ia
 * tidak pernah menarik perhatian daripada kandungan.
 */
@Composable
fun LatarAurora(modifier: Modifier = Modifier, kandungan: @Composable BoxScope.() -> Unit) {
    val peralihan = rememberInfiniteTransition(label = "aurora")

    val a by peralihan.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(38_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "a",
    )
    val b by peralihan.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(52_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "b",
    )

    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Warna.Dasar, Warna.DasarDalam),
                    Offset(0f, 0f),
                    Offset(0f, 2400f),
                )
            )
    ) {
        Blob(Warna.AuroraOker, 0.30f, (-90 + a * 70).dp, (-40 + b * 90).dp, 380.dp)
        Blob(Warna.AuroraTeal, 0.26f, (150 - b * 60).dp, (320 + a * 120).dp, 420.dp)
        Blob(Warna.AuroraIndigo, 0.34f, (-30 + b * 50).dp, (640 - a * 90).dp, 460.dp)
        kandungan()
    }
}

@Composable
private fun Blob(warna: Color, kelegapan: Float, x: Dp, y: Dp, saiz: Dp) {
    Box(
        Modifier
            .offset(x = x, y = y)
            .size(saiz)
            .background(
                // Biarkan lalai: berpusat, jejari separuh dimensi terkecil.
                // Menghantar radius 0 membaling IllegalArgumentException pada Android.
                Brush.radialGradient(
                    listOf(warna.copy(alpha = kelegapan), Warna.Lut),
                ),
                Bentuk.Cip,
            )
    )
}

/**
 * Permukaan kaca.
 *
 * Tiga lapisan yang menjadikannya kelihatan seperti kaca dan bukan sekadar
 * kotak lutsinar:
 *
 * 1. Isian lutsinar yang membenarkan aurora menembusi
 * 2. Blur sebenar pada API 31+, atau isian lebih pekat di bawahnya, supaya teks
 *    kekal boleh dibaca pada peranti lama
 * 3. Sempadan kecerunan — terang di kiri atas, hampir hilang di kanan bawah.
 *    Pinggir spekular inilah yang menjual kesan itu; tanpanya ia rata.
 */
@Composable
fun Kaca(
    modifier: Modifier = Modifier,
    bentuk: Shape = Bentuk.Kad,
    pekat: Boolean = false,
    aksen: Color? = null,
    kandungan: @Composable BoxScope.() -> Unit,
) {
    val isian = when {
        pekat || !blurDisokong -> Warna.KacaIsiPekat
        else -> Warna.KacaIsi
    }
    val tepiAtas = aksen?.copy(alpha = 0.55f) ?: Warna.KacaTepiTerang

    Box(
        modifier
            .clip(bentuk)
            .background(isian, bentuk)
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(tepiAtas, Warna.KacaTepiGelap),
                    Offset(0f, 0f),
                    Offset(600f, 600f),
                ),
                bentuk,
            ),
        content = kandungan,
    )
}

/**
 * Kaca untuk chrome yang melapisi kandungan menatal — bar tajuk dan bar bawah.
 * Di sinilah blur sebenar berbaloi, kerana ada sesuatu yang bergerak di
 * belakangnya untuk dikaburkan.
 */
@Composable
fun KacaChrome(
    modifier: Modifier = Modifier,
    kandungan: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier.background(
            Brush.linearGradient(
                listOf(Warna.Dasar.copy(alpha = 0.92f), Warna.Dasar.copy(alpha = 0.78f)),
                Offset(0f, 0f),
                Offset(0f, 200f),
            )
        ),
        content = kandungan,
    )
}

/** Modifier pembantu untuk mengaburkan sesuatu di belakang kaca, bila disokong. */
fun Modifier.kaburJikaBoleh(jejari: Dp): Modifier =
    if (blurDisokong) this.blur(jejari) else this
