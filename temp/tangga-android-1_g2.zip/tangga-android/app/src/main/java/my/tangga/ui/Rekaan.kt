package my.tangga.ui

import androidx.compose.animation.core.EaseOutCubic
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * Palet.
 *
 * Asasnya kekal biru pelan juruukur dari versi pertama — itulah identiti
 * aplikasi ini. Yang baharu ialah lapisan aurora di belakang segalanya, kerana
 * kaca yang tiada apa-apa berwarna di belakangnya hanya kelihatan kelabu.
 *
 * Aksen oker dikekalkan. Ia hangat terhadap asas sejuk, dan ia bukan biru atau
 * ungu yang setiap aplikasi lain guna.
 */
object Warna {
    // Asas
    val Dasar = Color(0xFF0A1424)
    val DasarDalam = Color(0xFF060D18)

    // Blob aurora di belakang kaca
    val AuroraOker = Color(0xFFF0B429)
    val AuroraTeal = Color(0xFF2A7B7B)
    val AuroraIndigo = Color(0xFF2B3F7A)

    // Permukaan kaca
    val KacaIsi = Color(0x14FFFFFF)
    val KacaIsiPekat = Color(0x24FFFFFF)
    val KacaTepiTerang = Color(0x4DFFFFFF)
    val KacaTepiGelap = Color(0x0DFFFFFF)

    // Permukaan pekat — kod mesti kekal boleh dibaca
    val Editor = Color(0xFF060E1A)
    val Panel = Color(0xE60B1626)

    // Dakwat
    val Dakwat = Color(0xFFE3EBF8)
    val Senyap = Color(0xFF8AA2C4)
    val SenyapGelap = Color(0xFF5A6E8C)

    // Isyarat
    val Oker = Color(0xFFF0B429)
    val OkerRedup = Color(0x33F0B429)
    val Bata = Color(0xFFE4695B)
    val BataRedup = Color(0x2BE4695B)
    val Hijau = Color(0xFF6ECF97)
    val HijauRedup = Color(0x2B6ECF97)

    val Lut = Color(0x00000000)
}

/**
 * Bentuk.
 *
 * Versi pertama bersudut tajam sepenuhnya. Kaca memerlukan lengkung — cahaya
 * pinggir hanya kelihatan betul pada sudut membulat, dan tanpa lengkung ia
 * kelihatan seperti kotak lutsinar biasa.
 */
object Bentuk {
    val Kad: Shape = RoundedCornerShape(20.dp)
    val KadKecil: Shape = RoundedCornerShape(14.dp)
    val Butang: Shape = RoundedCornerShape(12.dp)
    val Cip: Shape = RoundedCornerShape(999.dp)
    val Medan: Shape = RoundedCornerShape(14.dp)
}

/**
 * Gerakan.
 *
 * Semuanya berasaskan spring kecuali di mana masa tetap benar-benar diperlukan.
 * Spring bertindak balas terhadap gangguan pertengahan animasi; tween tidak, dan
 * itu ketara apabila pengguna mengetuk pantas.
 */
object Gerak {
    /** Untuk apa-apa yang mengikut jari — tekanan, tarik. */
    fun <T> pantas(): FiniteAnimationSpec<T> =
        spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessHigh)

    /** Lalai untuk kebanyakan peralihan keadaan. */
    fun <T> biasa(): FiniteAnimationSpec<T> =
        spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow)

    /** Untuk kejayaan dan kemasukan — sedikit lantunan diberi ganjaran. */
    fun <T> lantun(): FiniteAnimationSpec<T> =
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)

    /** Bila masa tetap benar-benar diperlukan, atau bila lengah diperlukan. */
    fun <T> masa(ms: Int, lengah: Int = 0): FiniteAnimationSpec<T> = tween(ms, lengah, EaseOutCubic)

    /** Kemasukan berperingkat: item ke-n bermula selepas n selang. */
    fun <T> peringkat(indeks: Int): FiniteAnimationSpec<T> =
        tween(MASUK_MS, indeks * PERINGKAT_MS, EaseOutCubic)

    const val MASUK_MS = 260
    const val KELUAR_MS = 180
    /** Selang antara item dalam kemasukan berperingkat. */
    const val PERINGKAT_MS = 45
}
