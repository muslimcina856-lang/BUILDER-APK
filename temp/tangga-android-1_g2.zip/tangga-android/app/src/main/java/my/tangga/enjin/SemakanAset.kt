package my.tangga.enjin

import android.content.Context
import my.tangga.Bahasa

/**
 * Menyemak runtime bahasa mana yang benar-benar dipasang.
 *
 * Runtime berat diambil pada masa binaan oleh skrip `ambil-*.sh` dan tidak
 * disimpan dalam repositori. Tanpa semakan ini, pengguna memilih satu bahasa,
 * menunggu, kemudian mendapat kegagalan. Lebih baik menandakannya pada skrin
 * pemilihan supaya mereka tahu sebelum melabur masa.
 */
object SemakanAset {

    /** Bahasa yang direktori runtimenya hilang atau kosong. */
    fun runtimeHilang(konteks: Context): Set<Bahasa> =
        Bahasa.entries.filter { b ->
            val dir = b.direktoriRuntime ?: return@filter false
            val isi = runCatching { konteks.assets.list(dir) }.getOrNull()
            isi.isNullOrEmpty()
        }.toSet()
}
