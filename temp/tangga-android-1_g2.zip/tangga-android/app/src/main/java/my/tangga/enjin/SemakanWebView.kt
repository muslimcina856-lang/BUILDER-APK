package my.tangga.enjin

import android.content.Context
import androidx.webkit.WebViewCompat
import my.tangga.Bahasa

/**
 * Menyemak versi penyedia WebView peranti.
 *
 * Setiap laluan bahasa berjalan di dalam WebView, jadi versi penyedia itu
 * menentukan apa yang berfungsi. Ia komponen yang dikemas kini melalui Play
 * Store, jadi kebanyakan telefon terkini — tetapi peranti lama, ROM tersuai
 * dan peranti tanpa Play Services boleh terperangkap pada versi lama.
 *
 * Tanpa semakan ini, WebView yang terlalu lama menyebabkan Pyodide gagal
 * dengan ralat wasm yang tidak bermakna kepada pengguna. Lebih baik memberitahu
 * mereka apa yang sebenarnya salah.
 *
 * Ambang di bawah datang daripada mengimbas aset yang sebenarnya dihantar,
 * bukan tekaan. Ia tetap anggaran: ia memberi amaran, tidak menyekat. Kalau
 * anggaran saya salah pada peranti tertentu, pengguna masih boleh mencuba.
 */
object SemakanWebView {

    /**
     * Aset enjin sendiri menggunakan rantaian pilihan (`?.`) dan penggabungan
     * nullish (`??`), kedua-duanya Chrome 80. Di bawah ini, tiada apa berjalan.
     */
    const val MIN_ASAS = 80

    /**
     * Pyodide memerlukan wasm SIMD, iaitu Chrome 91. Angka ini terikat pada
     * binaan Pyodide yang diambil oleh `ambil-pyodide.sh` — kemas kini ia jika
     * kau menukar versi itu.
     */
    const val MIN_PYTHON = 91

    data class Keputusan(
        /** Versi major, atau null jika tiada penyedia atau tidak dapat dihurai. */
        val versi: Int?,
        val pakej: String?,
        val versiPenuh: String?,
    ) {
        val adaPenyedia: Boolean get() = pakej != null

        /**
         * Bahasa yang mungkin tidak berjalan. Kosong bermakna semuanya sepatutnya
         * berfungsi, atau kita tidak dapat menentukan versi dan tidak akan meneka.
         */
        val bahasaBermasalah: List<Bahasa>
            get() {
                val v = versi ?: return emptyList()
                if (v < MIN_ASAS) return Bahasa.entries.toList()
                if (v < MIN_PYTHON) return listOf(Bahasa.PYTHON)
                return emptyList()
            }

        fun sokong(b: Bahasa): Boolean = b !in bahasaBermasalah

        /** Ayat jujur untuk ditunjukkan kepada pengguna, atau null jika tiada masalah. */
        val amaran: String?
            get() = when {
                !adaPenyedia ->
                    "Tiada penyedia WebView dijumpai pada peranti ini. Setiap laluan " +
                        "memerlukan WebView untuk menjalankan kod, jadi tiada apa akan berfungsi " +
                        "sehingga Android System WebView dipasang."
                versi == null -> null // Kita ada penyedia tetapi tidak dapat membaca versinya; jangan meneka.
                versi < MIN_ASAS ->
                    "WebView peranti ini versi $versi. Aplikasi memerlukan sekurang-kurangnya " +
                        "$MIN_ASAS. Kemas kini Android System WebView melalui Play Store, " +
                        "atau kemas kini Chrome jika ia penyedia kau."
                versi < MIN_PYTHON ->
                    "WebView peranti ini versi $versi. Laluan Python memerlukan $MIN_PYTHON " +
                        "ke atas kerana Pyodide menggunakan wasm SIMD. Laluan lain sepatutnya " +
                        "berfungsi seperti biasa."
                else -> null
            }
    }

    fun semak(konteks: Context): Keputusan {
        val pakej = runCatching { WebViewCompat.getCurrentWebViewPackage(konteks) }.getOrNull()
            ?: return Keputusan(null, null, null)
        val penuh = pakej.versionName
        // Nama versi kelihatan seperti "120.0.6099.43"; kita hanya perlukan major.
        val major = penuh?.substringBefore('.')?.toIntOrNull()
        return Keputusan(major, pakej.packageName, penuh)
    }
}
