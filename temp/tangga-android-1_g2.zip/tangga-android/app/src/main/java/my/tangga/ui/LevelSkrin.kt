package my.tangga.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import my.tangga.Keadaan
import my.tangga.KeputusanKes
import my.tangga.Level

@Composable
fun LevelSkrin(
    k: Keadaan,
    padaKembali: () -> Unit,
    padaKodUbah: (String) -> Unit,
    padaTeksUbah: (String) -> Unit,
    padaJalan: () -> Unit,
    padaSemakRamal: () -> Unit,
    padaPilih: (Int) -> Unit,
    padaPetunjuk: () -> Unit,
    padaJawapan: () -> Unit,
    padaSetSemula: () -> Unit,
    padaSebelum: () -> Unit,
    padaSeterusnya: () -> Unit,
) {
    val level = k.level ?: return
    var medan by remember { mutableStateOf(TextFieldValue(k.kod)) }

    // Hanya selaraskan bila kod benar-benar diganti dari luar — tukar level atau
    // butang "Set semula". Mengikut k.kod akan melompatkan kursor semasa menaip.
    LaunchedEffect(k.kodVersi) { medan = TextFieldValue(k.kod) }

    Column(Modifier.fillMaxSize()) {

        KacaChrome(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Butang("\u2190 Peta", hidup = !k.memuatLevel, padaKlik = padaKembali)
                Spacer(Modifier.width(12.dp))
                StatusEnjin(k.memanaskan, k.enjinPanas)
                Spacer(Modifier.weight(1f))
                Text(
                    "${k.progres.xp} XP",
                    color = Warna.Oker,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp),
        ) {
            item { KepalaLevel(level, k.progres.sudahSiap(level.n)) }

            item {
                AnimatedVisibility(
                    visible = k.ralatEnjin != null,
                    enter = fadeIn(Gerak.biasa()) + expandVertically(Gerak.biasa()),
                    exit = fadeOut(Gerak.biasa()) + shrinkVertically(Gerak.biasa()),
                ) { Nota(k.ralatEnjin.orEmpty(), merah = true) }
            }

            item {
                AnimatedVisibility(
                    visible = k.kemajuan != null,
                    enter = fadeIn(Gerak.biasa()) + expandVertically(Gerak.biasa()),
                    exit = fadeOut(Gerak.biasa()) + shrinkVertically(Gerak.biasa()),
                ) { k.kemajuan?.let { PapanKemajuan(it) } }
            }

            item {
                Text(
                    huraiPenanda(level.brief),
                    color = Warna.Dakwat,
                    fontSize = 14.5.sp,
                    lineHeight = 24.sp,
                )
            }

            level.skema?.let { skema ->
                item {
                    Column {
                        Eyebrow("Jadual")
                        Spacer(Modifier.height(7.dp))
                        BlokKod(skema)
                    }
                }
            }

            when (level.jenis) {
                "ramal" -> {
                    item { BlokKod(level.kod.orEmpty()) }
                    item {
                        BasicTextField(
                            value = k.jawapanTeks,
                            onValueChange = padaTeksUbah,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(Bentuk.Medan)
                                .background(Warna.Editor, Bentuk.Medan)
                                .padding(15.dp),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(
                                color = Warna.Dakwat,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 15.sp,
                            ),
                            cursorBrush = SolidColor(Warna.Oker),
                            decorationBox = { medanDalam ->
                                if (k.jawapanTeks.isEmpty()) {
                                    Text(
                                        "Taip jawapan",
                                        color = Warna.SenyapGelap,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 15.sp,
                                    )
                                }
                                medanDalam()
                            },
                        )
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            Butang("Semak", utama = true, padaKlik = padaSemakRamal)
                            if (k.petunjukDibuka < level.petunjuk.size) {
                                Butang("Petunjuk", padaKlik = padaPetunjuk)
                            }
                        }
                    }
                    item {
                        AnimatedVisibility(
                            visible = k.hasilRamal != null,
                            enter = fadeIn(Gerak.lantun()) + scaleIn(Gerak.lantun(), 0.94f),
                            exit = fadeOut(Gerak.biasa()),
                        ) {
                            k.hasilRamal?.let { h ->
                                Column {
                                    Nota(
                                        when {
                                            h.lulus -> "Betul."
                                            k.cuba >= 3 -> "Belum betul. Jawapannya: ${h.jangka}"
                                            else -> "Belum betul. Cuba lagi."
                                        },
                                        merah = !h.lulus,
                                    )
                                    if (h.lulus) {
                                        Spacer(Modifier.height(10.dp))
                                        PengesahanSimpan()
                                    }
                                }
                            }
                        }
                    }
                }

                "pilih" -> {
                    item {
                        Text(
                            huraiPenanda(level.soalan.orEmpty()),
                            color = Warna.Dakwat,
                            fontSize = 14.5.sp,
                            lineHeight = 24.sp,
                        )
                    }
                    itemsIndexed(level.pilihan) { i, teks ->
                        PilihanBaris(
                            teks = teks,
                            dipilih = k.pilihanDipilih,
                            indeks = i,
                            betul = level.betul,
                        ) { padaPilih(i) }
                    }
                    item {
                        AnimatedVisibility(
                            visible = k.pilihanDipilih != null,
                            enter = fadeIn(Gerak.biasa()) + expandVertically(Gerak.biasa()),
                            exit = fadeOut(Gerak.biasa()),
                        ) {
                            Column {
                                Nota(
                                    level.huraian.orEmpty(),
                                    merah = k.pilihanDipilih != level.betul,
                                )
                                if (k.pilihanDipilih == level.betul) {
                                    Spacer(Modifier.height(10.dp))
                                    PengesahanSimpan()
                                }
                            }
                        }
                    }
                }

                else -> {
                    item {
                        EditorKod(
                            nilai = medan,
                            padaUbah = { baharu ->
                                medan = baharu
                                padaKodUbah(baharu.text)
                            },
                        )
                    }
                    item {
                        FlowBaris {
                            Butang(
                                when {
                                    k.berjalan && !k.enjinPanas -> "Memulakan runtime\u2026"
                                    k.berjalan -> "Menjalankan\u2026"
                                    else -> "Jalankan ujian"
                                },
                                utama = true,
                                hidup = !k.berjalan,
                                padaKlik = padaJalan,
                            )
                            if (k.petunjukDibuka < level.petunjuk.size) {
                                Butang("Petunjuk", padaKlik = padaPetunjuk)
                            }
                            Butang("Set semula", padaKlik = padaSetSemula)
                            if (k.cuba >= 3 && !k.jawapanDibuka && level.jawapan.isNotEmpty()) {
                                Butang("Buka jawapan", padaKlik = padaJawapan)
                            }
                        }
                    }
                    item {
                        AnimatedVisibility(
                            visible = k.keputusan?.fatal != null,
                            enter = fadeIn(Gerak.biasa()) + expandVertically(Gerak.biasa()),
                            exit = fadeOut(Gerak.biasa()),
                        ) { Nota(k.keputusan?.fatal.orEmpty(), merah = true) }
                    }
                    item {
                        AnimatedVisibility(
                            visible = k.keputusan?.results != null,
                            enter = fadeIn(Gerak.lantun()) + slideInVertically(Gerak.lantun()) { it / 6 },
                            exit = fadeOut(Gerak.biasa()),
                        ) {
                            k.keputusan?.results?.let { JadualKeputusan(level, it) }
                        }
                    }
                }
            }

            itemsIndexed(level.petunjuk.take(k.petunjukDibuka)) { i, h ->
                Nota(
                    buildAnnotatedString {
                        withStyle(
                            SpanStyle(
                                color = Warna.Senyap,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                            )
                        ) { append("PETUNJUK ${i + 1} \u00b7 ") }
                        append(huraiPenanda(h))
                    }
                )
            }

            if (k.jawapanDibuka && level.jawapan.isNotEmpty()) {
                item {
                    Column {
                        Eyebrow("Satu jawapan yang berfungsi")
                        Spacer(Modifier.height(7.dp))
                        BlokKod(level.jawapan)
                    }
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }

        KacaChrome(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(horizontal = 18.dp, vertical = 13.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            ) {
                val sibuk = k.memuatLevel || k.berjalan
                Butang(
                    "\u2190 Sebelum",
                    hidup = level.n > 1 && !sibuk,
                ) { padaSebelum() }
                Butang(
                    when {
                        k.memuatLevel -> "Memuat\u2026"
                        !k.bolehKeSeterusnya -> "\ud83d\udd12 Jawab dahulu"
                        else -> "Seterusnya \u2192"
                    },
                    utama = k.bolehKeSeterusnya,
                    hidup = !sibuk && k.bolehKeSeterusnya,
                ) { padaSeterusnya() }
            }
        }
    }
}

@Composable
private fun KepalaLevel(level: Level, siap: Boolean) {
    Kaca(Modifier.fillMaxWidth(), aksen = if (siap) Warna.Hijau else Warna.Oker) {
        Row(Modifier.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(96.dp)
                    .fillMaxHeight()
                    .background(if (siap) Warna.HijauRedup else Warna.OkerRedup),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "${level.n}",
                    color = if (siap) Warna.Hijau else Warna.Oker,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 28.sp,
                )
            }
            Column(Modifier.weight(1f).padding(horizontal = 15.dp, vertical = 16.dp)) {
                Eyebrow(
                    "%02d \u00b7 %s \u00b7 %s".format(level.bab, level.namaBab, level.labelJenis),
                    warna = if (siap) Warna.Hijau else Warna.Senyap,
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    level.tajuk,
                    color = Warna.Dakwat,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    lineHeight = 22.sp,
                )
            }
        }
    }
}

@Composable
private fun PilihanBaris(
    teks: String,
    dipilih: Int?,
    indeks: Int,
    betul: Int,
    padaKlik: () -> Unit,
) {
    val aksen = when {
        dipilih == null -> null
        indeks == betul -> Warna.Hijau
        indeks == dipilih -> Warna.Bata
        else -> null
    }
    val latar = when {
        dipilih == null -> Warna.Lut
        indeks == betul -> Warna.HijauRedup
        indeks == dipilih -> Warna.BataRedup
        else -> Warna.Lut
    }
    val skala by animateFloatAsState(
        targetValue = if (dipilih != null && indeks == betul) 1.015f else 1f,
        animationSpec = Gerak.lantun(),
        label = "pilihan",
    )

    Kaca(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = dipilih == null, onClickLabel = "Pilih jawapan ini") { padaKlik() },
        bentuk = Bentuk.KadKecil,
        aksen = aksen,
    ) {
        Box(Modifier.fillMaxWidth().background(latar)) {
            Text(
                huraiPenanda(teks),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 15.dp),
                color = Warna.Dakwat,
                fontSize = 14.sp,
                lineHeight = 22.sp,
            )
        }
    }
}

@Composable
private fun JadualKeputusan(level: Level, hasil: List<KeputusanKes>) {
    val semua = hasil.all { it.lulus }
    Kaca(
        Modifier.fillMaxWidth(),
        bentuk = Bentuk.KadKecil,
        aksen = if (semua) Warna.Hijau else Warna.Bata,
    ) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(if (semua) Warna.HijauRedup else Warna.BataRedup)
                    .padding(horizontal = 15.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "${hasil.count { it.lulus }} / ${hasil.size} LULUS",
                    color = if (semua) Warna.Hijau else Warna.Bata,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.5.sp,
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                if (semua) {
                    Spacer(Modifier.weight(1f))
                    PengesahanSimpan()
                }
            }
            hasil.forEachIndexed { i, r ->
                val kes = level.kes.getOrNull(i)
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 11.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        if (r.lulus) "\u2713" else "\u2715",
                        color = if (r.lulus) Warna.Hijau else Warna.Bata,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                    )
                    Text(
                        buildAnnotatedString {
                            withStyle(SpanStyle(color = Warna.SenyapGelap)) { append("masuk ") }
                            append(kes?.hujah.orEmpty())
                            withStyle(SpanStyle(color = Warna.SenyapGelap)) { append("  jangka ") }
                            append(kes?.jangka.orEmpty())
                            if (!r.lulus) {
                                append("\n")
                                withStyle(SpanStyle(color = Warna.SenyapGelap)) { append("dapat ") }
                                append(r.papar)
                            }
                        },
                        color = Warna.Dakwat.copy(alpha = 0.9f),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 19.sp,
                    )
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun FlowBaris(kandungan: @Composable () -> Unit) {
    androidx.compose.foundation.layout.FlowRow(
        horizontalArrangement = Arrangement.spacedBy(9.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp),
    ) { kandungan() }
}
