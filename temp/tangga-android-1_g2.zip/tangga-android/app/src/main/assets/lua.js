/* Dijana daripada bank Lua Tangga. Jangan sunting terus.
   Setiap jawapan rujukan disahkan dengan runtime Lua sebenar. */
(function () {
  const LUA_BAB = [{"n": 1, "nama": "Asas Lua", "dari": 1, "hingga": 120}, {"n": 2, "nama": "Aliran Kawalan", "dari": 121, "hingga": 250}, {"n": 3, "nama": "Jadual sebagai Senarai", "dari": 251, "hingga": 400}, {"n": 4, "nama": "Jadual sebagai Peta", "dari": 401, "hingga": 530}, {"n": 5, "nama": "Fungsi", "dari": 531, "hingga": 670}, {"n": 6, "nama": "String & Corak", "dari": 671, "hingga": 790}, {"n": 7, "nama": "Metatable & OOP", "dari": 791, "hingga": 890}, {"n": 8, "nama": "Ralat", "dari": 891, "hingga": 970}, {"n": 9, "nama": "Cabaran Campur", "dari": 971, "hingga": 1100}];
  const LUA_TUGAS = [{"bab": 1, "jenis": "tulis", "tajuk": "Fungsi pertama", "brief": "Tulis `luas(p, l)` yang pulangkan luas segi empat tepat.\n\nLua guna `function ... end`, bukan kurungan.", "petunjuk": ["Blok Lua ditutup dengan `end`, bukan kurungan kerinting.", "`return p * l`"], "fn": "luas", "starter": "function luas(p, l)\n  -- tulis di sini\nend", "jawapan": "function luas(p, l)\n  return p * l\nend", "kes": [{"args": [3, 4], "jangka": 12}, {"args": [0, 9], "jangka": 0}, {"args": [2.5, 4], "jangka": 10}]}, {"bab": 1, "jenis": "tulis", "tajuk": "Sambung dengan dua titik", "brief": "Tulis `sapa(nama, umur)` yang pulangkan `\"<nama> berumur <umur> tahun\"`.\n\nLua menyambung dengan `..`, bukan `+`. `+` pada string ialah ralat.", "petunjuk": ["Nombor ditukar kepada string secara automatik semasa disambung.", "`return nama .. \" berumur \" .. umur .. \" tahun\"`"], "fn": "sapa", "starter": "function sapa(nama, umur)\n\nend", "jawapan": "function sapa(nama, umur)\n  return nama .. \" berumur \" .. umur .. \" tahun\"\nend", "kes": [{"args": ["Aina", 9], "jangka": "Aina berumur 9 tahun"}, {"args": ["Kumar", 40], "jangka": "Kumar berumur 40 tahun"}], "syarat": [{"corak": "\\.\\.", "mesej": "Guna operator sambung `..`."}]}, {"bab": 1, "jenis": "baiki", "tajuk": "Global secara tidak sengaja", "brief": "Fungsi ini mencipta pembolehubah global kerana `local` tertinggal. Dalam Lua, pembolehubah adalah global melainkan kau isytiharkan sebaliknya — punca pepijat yang sukar dijejak.\n\nBaiki supaya `jumlah` bersifat tempatan. Tingkah laku kekal sama.", "petunjuk": ["Tanpa `local`, `jumlah` menjadi global dan dikongsi merentas setiap panggilan.", "Letak `local` di hadapan penetapan pertama sahaja."], "fn": "kira", "starter": "function kira(n)\n  jumlah = 0\n  for i = 1, n do\n    jumlah = jumlah + i\n  end\n  return jumlah\nend", "jawapan": "function kira(n)\n  local jumlah = 0\n  for i = 1, n do\n    jumlah = jumlah + i\n  end\n  return jumlah\nend", "kes": [{"args": [5], "jangka": 15}, {"args": [1], "jangka": 1}, {"args": [0], "jangka": 0}], "syarat": [{"corak": "local\\s+jumlah", "mesej": "Isytiharkan `jumlah` sebagai `local`."}]}, {"bab": 1, "jenis": "ramal", "tajuk": "nil dan false", "brief": "Apa yang dicetak?", "petunjuk": ["Dalam Lua hanya `nil` dan `false` adalah palsu. `0` dan `\"\"` adalah benar.", "Ini berbeza daripada JavaScript dan Python, di mana 0 adalah falsy."], "kod": "print(0 and \"benar\" or \"palsu\")", "output": "benar"}, {"bab": 2, "jenis": "tulis", "tajuk": "elseif", "brief": "Tulis `gred(markah)`:\n80 ke atas → `\"A\"`, 65-79 → `\"B\"`, 50-64 → `\"C\"`, bawah 50 → `\"G\"`.\n\nLua mengeja `elseif` sebagai satu perkataan.", "petunjuk": ["`if ... then ... elseif ... then ... else ... end`", "Setiap `if` memerlukan `then` dan satu `end` menutup keseluruhan rantaian."], "fn": "gred", "starter": "function gred(markah)\n\nend", "jawapan": "function gred(markah)\n  if markah >= 80 then\n    return \"A\"\n  elseif markah >= 65 then\n    return \"B\"\n  elseif markah >= 50 then\n    return \"C\"\n  end\n  return \"G\"\nend", "kes": [{"args": [95], "jangka": "A"}, {"args": [80], "jangka": "A"}, {"args": [79], "jangka": "B"}, {"args": [65], "jangka": "B"}, {"args": [50], "jangka": "C"}, {"args": [49], "jangka": "G"}]}, {"bab": 2, "jenis": "tulis", "tajuk": "Gelung for bernombor", "brief": "Tulis `sifir(n)` yang pulangkan jadual `{n*1, n*2, ..., n*10}`.\n\nGelung `for` Lua mengambil mula, tamat, dan langkah pilihan — dan hujungnya **termasuk**.", "petunjuk": ["`for i = 1, 10 do` berjalan sepuluh kali, termasuk 10.", "Jadual dicipta dengan `{}` dan diisi `t[i] = ...`."], "fn": "sifir", "starter": "function sifir(n)\n\nend", "jawapan": "function sifir(n)\n  local t = {}\n  for i = 1, 10 do\n    t[i] = n * i\n  end\n  return t\nend", "kes": [{"args": [3], "jangka": [3, 6, 9, 12, 15, 18, 21, 24, 27, 30]}, {"args": [1], "jangka": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}]}, {"bab": 2, "jenis": "tulis", "tajuk": "Langkah negatif", "brief": "Tulis `kiraTurun(n)` yang pulangkan jadual dari `n` menurun ke 1. `n` sifar atau negatif → jadual kosong.", "petunjuk": ["Langkah ketiga menjadikannya menurun: `for i = n, 1, -1 do`.", "Guna kaunter berasingan untuk indeks jadual, kerana `i` sedang menurun."], "fn": "kiraTurun", "starter": "function kiraTurun(n)\n\nend", "jawapan": "function kiraTurun(n)\n  local t = {}\n  for i = n, 1, -1 do\n    t[#t + 1] = i\n  end\n  return t\nend", "kes": [{"args": [3], "jangka": [3, 2, 1]}, {"args": [0], "jangka": []}, {"args": [1], "jangka": [1]}]}, {"bab": 2, "jenis": "ramal", "tajuk": "repeat until", "brief": "Apa yang dicetak?", "petunjuk": ["`repeat` sentiasa berjalan sekurang-kurangnya sekali — syarat diperiksa di hujung.", "Ia berhenti apabila syarat menjadi benar, bukan selagi ia benar."], "kod": "local n = 0\nrepeat\n  n = n + 1\nuntil n >= 3\nprint(n)", "output": "3"}, {"bab": 3, "jenis": "tulis", "tajuk": "Indeks bermula pada satu", "brief": "Tulis `pertama(t)` yang pulangkan elemen pertama jadual, atau `nil` bila kosong.\n\nIni perbezaan paling besar Lua: senarai bermula pada indeks **1**, bukan 0.", "petunjuk": ["`t[1]` ialah elemen pertama. `t[0]` biasanya `nil`.", "Mengakses indeks yang tiada memberi `nil`, bukan ralat."], "fn": "pertama", "starter": "function pertama(t)\n\nend", "jawapan": "function pertama(t)\n  return t[1]\nend", "kes": [{"args": [[5, 6]], "jangka": 5}, {"args": [["a"]], "jangka": "a"}, {"args": [[]], "jangka": null}]}, {"bab": 3, "jenis": "tulis", "tajuk": "ipairs", "brief": "Tulis `jumlah(t)` yang jumlahkan semua nombor dalam jadual senarai. Kosong → 0.", "petunjuk": ["`for i, v in ipairs(t) do` melelar bahagian senarai mengikut susunan.", "`ipairs` berhenti pada `nil` pertama; `pairs` melelar semua kunci."], "fn": "jumlah", "starter": "function jumlah(t)\n\nend", "jawapan": "function jumlah(t)\n  local j = 0\n  for _, v in ipairs(t) do\n    j = j + v\n  end\n  return j\nend", "kes": [{"args": [[1, 2, 3]], "jangka": 6}, {"args": [[]], "jangka": 0}, {"args": [[-1, 1]], "jangka": 0}]}, {"bab": 3, "jenis": "tulis", "tajuk": "Bina jadual baharu", "brief": "Tulis `tapisGenap(t)` yang pulangkan jadual baharu berisi nombor genap sahaja, mengekalkan susunan.", "petunjuk": ["`t[#t + 1] = v` menambah ke hujung — `#t` ialah panjang semasa.", "`v % 2 == 0` bermaksud genap."], "fn": "tapisGenap", "starter": "function tapisGenap(t)\n\nend", "jawapan": "function tapisGenap(t)\n  local hasil = {}\n  for _, v in ipairs(t) do\n    if v % 2 == 0 then\n      hasil[#hasil + 1] = v\n    end\n  end\n  return hasil\nend", "kes": [{"args": [[1, 2, 3, 4]], "jangka": [2, 4]}, {"args": [[]], "jangka": []}, {"args": [[1, 3]], "jangka": []}]}, {"bab": 3, "jenis": "tulis", "tajuk": "Terbalikkan jadual", "brief": "Tulis `terbalik(t)` yang pulangkan jadual baharu dengan susunan terbalik. Jangan ubah input.", "petunjuk": ["Lelar dari `#t` menurun ke 1.", "Simpan kaunter berasingan untuk indeks jadual baharu."], "fn": "terbalik", "starter": "function terbalik(t)\n\nend", "jawapan": "function terbalik(t)\n  local hasil = {}\n  for i = #t, 1, -1 do\n    hasil[#hasil + 1] = t[i]\n  end\n  return hasil\nend", "kes": [{"args": [[1, 2, 3]], "jangka": [3, 2, 1]}, {"args": [[]], "jangka": []}, {"args": [["a"]], "jangka": ["a"]}]}, {"bab": 3, "jenis": "pilih", "tajuk": "Operator panjang dan lubang", "brief": "", "petunjuk": [], "soalan": "Kau tetapkan `t = {1, 2, 3}` kemudian `t[2] = nil`. Apa yang `#t` beri?", "pilihan": ["Tidak ditakrifkan — ia boleh 1 atau 3, Lua tidak menjamin", "Sentiasa 2", "Sentiasa 3", "Sentiasa 1"], "betul": 0, "huraian": "`#` hanya ditakrifkan untuk jujukan tanpa lubang. Menetapkan nilai tengah kepada `nil` mencipta lubang, dan hasilnya bergantung pada perwakilan dalaman. Untuk membuang dari senarai guna `table.remove`, yang mengalihkan elemen dan mengekalkan jujukan utuh."}, {"bab": 4, "jenis": "tulis", "tajuk": "Jadual sebagai kamus", "brief": "Tulis `kiraKekerapan(t)` yang pulangkan jadual yang memetakan setiap nilai kepada bilangan kemunculannya.", "petunjuk": ["Kunci yang tiada memberi `nil`, jadi guna `(kira[v] or 0) + 1`.", "Jadual yang sama menyimpan senarai dan peta — tiada jenis berasingan."], "fn": "kiraKekerapan", "starter": "function kiraKekerapan(t)\n\nend", "jawapan": "function kiraKekerapan(t)\n  local kira = {}\n  for _, v in ipairs(t) do\n    kira[v] = (kira[v] or 0) + 1\n  end\n  return kira\nend", "kes": [{"args": [["a", "b", "a"]], "jangka": {"a": 2, "b": 1}}, {"args": [[]], "jangka": {}}]}, {"bab": 4, "jenis": "tulis", "tajuk": "pairs tidak tersusun", "brief": "Tulis `kunciTersusun(t)` yang pulangkan jadual berisi semua kunci, tersusun menaik.\n\n`pairs` melawat kunci dalam susunan yang tidak ditentukan — kalau kau perlukan susunan, kau mesti isih sendiri.", "petunjuk": ["Kumpul kunci dahulu dengan `for k in pairs(t) do`.", "`table.sort(kunci)` mengisih di tempatnya."], "fn": "kunciTersusun", "starter": "function kunciTersusun(t)\n\nend", "jawapan": "function kunciTersusun(t)\n  local kunci = {}\n  for k in pairs(t) do\n    kunci[#kunci + 1] = k\n  end\n  table.sort(kunci)\n  return kunci\nend", "kes": [{"args": [{"b": 1, "a": 2, "c": 3}], "jangka": ["a", "b", "c"]}, {"args": [{}], "jangka": []}], "syarat": [{"corak": "table\\.sort", "mesej": "Guna `table.sort` — `pairs` tidak menjamin susunan."}]}, {"bab": 4, "jenis": "tulis", "tajuk": "Gabung dua jadual", "brief": "Tulis `gabung(a, b)` yang pulangkan jadual baharu dengan semua kunci dari kedua-duanya. Nilai dari `b` mengatasi `a`. Input tidak boleh berubah.", "petunjuk": ["Salin `a` dahulu, kemudian tulis atasnya dengan `b`.", "Lua tiada operator spread — kau mesti melelar."], "fn": "gabung", "starter": "function gabung(a, b)\n\nend", "jawapan": "function gabung(a, b)\n  local hasil = {}\n  for k, v in pairs(a) do\n    hasil[k] = v\n  end\n  for k, v in pairs(b) do\n    hasil[k] = v\n  end\n  return hasil\nend", "kes": [{"args": [{"x": 1}, {"y": 2}], "jangka": {"x": 1, "y": 2}}, {"args": [{"x": 1}, {"x": 9}], "jangka": {"x": 9}}, {"args": [{}, {}], "jangka": {}}]}, {"bab": 4, "jenis": "ramal", "tajuk": "nil memadam kunci", "brief": "Apa yang dicetak?", "petunjuk": ["Menetapkan kunci kepada `nil` membuangnya sepenuhnya daripada jadual.", "Tiada operator `delete` berasingan dalam Lua."], "kod": "local t = { a = 1, b = 2 }\nt.a = nil\nlocal n = 0\nfor _ in pairs(t) do n = n + 1 end\nprint(n)", "output": "1"}, {"bab": 5, "jenis": "tulis", "tajuk": "Pulangan berbilang", "brief": "Tulis `minMaks(t)` yang pulangkan **dua** nilai: minimum dan maksimum. Jadual kosong → pulangkan `nil, nil`.\n\nPulangan berbilang ialah ciri terbina Lua, bukan tuple yang dibungkus.", "petunjuk": ["`return a, b` memulangkan dua nilai, bukan satu jadual.", "Mulakan kedua-dua dengan `t[1]`, bukan 0 — jika tidak nombor negatif akan rosak."], "fn": "minMaks", "starter": "function minMaks(t)\n\nend", "jawapan": "function minMaks(t)\n  if #t == 0 then return nil, nil end\n  local kecil, besar = t[1], t[1]\n  for _, v in ipairs(t) do\n    if v < kecil then kecil = v end\n    if v > besar then besar = v end\n  end\n  return kecil, besar\nend", "kes": [{"args": [[3, 1, 4]], "jangka": [1, 4], "berbilang": true}, {"args": [[5]], "jangka": [5, 5], "berbilang": true}, {"args": [[]], "jangka": [null, null], "berbilang": true}]}, {"bab": 5, "jenis": "tulis", "tajuk": "Hujah berubah", "brief": "Tulis `jumlahSemua(...)` yang menerima sebarang bilangan nombor dan pulangkan jumlahnya. Tanpa hujah → 0.", "petunjuk": ["`{...}` mengumpul hujah menjadi jadual.", "`select(\"#\", ...)` memberi kiraan, termasuk `nil` di tengah."], "fn": "jumlahSemua", "starter": "function jumlahSemua(...)\n\nend", "jawapan": "function jumlahSemua(...)\n  local j = 0\n  for _, v in ipairs({...}) do\n    j = j + v\n  end\n  return j\nend", "kes": [{"args": [1, 2, 3], "jangka": 6}, {"args": [], "jangka": 0}, {"args": [5], "jangka": 5}]}, {"bab": 5, "jenis": "tulis", "tajuk": "Closure", "brief": "Tulis `buatKaunter(kali)` yang mencipta fungsi kaunter dalaman menggunakan closure, memanggilnya `kali` kali, dan pulangkan nilai akhir.", "petunjuk": ["Fungsi dalaman menangkap pembolehubah `local` di sekelilingnya secara automatik.", "Tiada kata kunci diperlukan — itu berbeza daripada `nonlocal` Python."], "fn": "buatKaunter", "starter": "function buatKaunter(kali)\n\nend", "jawapan": "function buatKaunter(kali)\n  local n = 0\n  local function tambah()\n    n = n + 1\n    return n\n  end\n  local akhir = 0\n  for _ = 1, kali do\n    akhir = tambah()\n  end\n  return akhir\nend", "kes": [{"args": [3], "jangka": 3}, {"args": [0], "jangka": 0}, {"args": [10], "jangka": 10}]}, {"bab": 5, "jenis": "tulis", "tajuk": "Fungsi sebagai nilai", "brief": "Tulis `guna(fn, kali)` yang panggil `fn(i)` untuk `i` dari 1 hingga `kali`, dan pulangkan jadual hasilnya.", "petunjuk": ["Fungsi ialah nilai kelas pertama — boleh disimpan, dihantar dan dipulangkan.", "Perhatikan gelung bermula pada 1, bukan 0."], "fn": "guna", "starter": "function guna(fn, kali)\n\nend", "jawapan": "function guna(fn, kali)\n  local hasil = {}\n  for i = 1, kali do\n    hasil[i] = fn(i)\n  end\n  return hasil\nend", "kes": [{"args": ["__FN__:function(i) return i * 2 end", 3], "jangka": [2, 4, 6]}, {"args": ["__FN__:function(i) return i end", 0], "jangka": []}]}, {"bab": 6, "jenis": "tulis", "tajuk": "Pustaka string", "brief": "Tulis `besarkan(s)` yang besarkan huruf pertama dan kecilkan yang lain. String kosong → string kosong.\n\nIngat: `string.sub` bermula pada indeks 1.", "petunjuk": ["`s:sub(1, 1)` ialah aksara pertama; `s:sub(2)` ialah selebihnya.", "Sintaks titik bertindih `s:upper()` ialah singkatan untuk `string.upper(s)`."], "fn": "besarkan", "starter": "function besarkan(s)\n\nend", "jawapan": "function besarkan(s)\n  if s == \"\" then return \"\" end\n  return s:sub(1, 1):upper() .. s:sub(2):lower()\nend", "kes": [{"args": ["ali"], "jangka": "Ali"}, {"args": [""], "jangka": ""}, {"args": ["aBC"], "jangka": "Abc"}]}, {"bab": 6, "jenis": "tulis", "tajuk": "Corak Lua", "brief": "Tulis `kiraPerkataan(s)` yang kira perkataan. Ruang berlebihan tidak dikira.\n\nCorak Lua **bukan** regex — `%w` bermaksud aksara alfanumerik, `+` bermaksud satu atau lebih.", "petunjuk": ["`for w in s:gmatch(\"%S+\") do` melelar setiap jujukan bukan ruang.", "`%S` ialah songsang kepada `%s`, sama seperti regex tetapi dengan `%` bukan `\\`."], "fn": "kiraPerkataan", "starter": "function kiraPerkataan(s)\n\nend", "jawapan": "function kiraPerkataan(s)\n  local n = 0\n  for _ in s:gmatch(\"%S+\") do\n    n = n + 1\n  end\n  return n\nend", "kes": [{"args": ["satu dua tiga"], "jangka": 3}, {"args": ["  ruang  banyak  "], "jangka": 2}, {"args": [""], "jangka": 0}, {"args": ["   "], "jangka": 0}]}, {"bab": 6, "jenis": "tulis", "tajuk": "gsub", "brief": "Tulis `gantiSemua(s)` yang buang semua ruang daripada string.\n\n`gsub` pulangkan **dua** nilai: string baharu dan bilangan gantian. Pulangkan string sahaja.", "petunjuk": ["`s:gsub(\"%s\", \"\")` pulangkan dua nilai — bungkus dalam kurungan untuk mengambil satu.", "`return (s:gsub(\"%s\", \"\"))` — kurungan itu penting."], "fn": "gantiSemua", "starter": "function gantiSemua(s)\n\nend", "jawapan": "function gantiSemua(s)\n  return (s:gsub(\"%s\", \"\"))\nend", "kes": [{"args": ["a b c"], "jangka": "abc"}, {"args": ["  x  "], "jangka": "x"}, {"args": [""], "jangka": ""}]}, {"bab": 6, "jenis": "pilih", "tajuk": "Corak bukan regex", "brief": "", "petunjuk": [], "soalan": "Kau cuba `s:match(\"a|b\")` untuk memadankan \"a\" atau \"b\". Apa yang berlaku?", "pilihan": ["Ia memadankan tiga aksara literal `a|b` — corak Lua tiada alternasi", "Ia berfungsi seperti regex", "Ia membaling ralat sintaks", "Ia memadankan mana-mana aksara"], "betul": 0, "huraian": "Corak Lua sengaja minimal — tiada alternasi, tiada kuantifier `{n,m}`, tiada lookahead. Ia lebih pantas dan lebih kecil daripada enjin regex penuh, yang penting untuk bahasa yang dibenamkan dalam permainan dan peranti. Untuk alternasi, kau tulis dua padanan atau guna kelas aksara `[ab]`."}, {"bab": 7, "jenis": "tulis", "tajuk": "Kelas dengan metatable", "brief": "Lua tiada kelas. Kau bina dengan jadual dan `__index`.\n\nCipta `Akaun` dengan `Akaun.baharu()`, kaedah `deposit(n)` dan `baki()`. Kemudian tulis `gunaAkaun(jumlah)` yang cipta satu akaun, deposit `jumlah`, dan pulangkan bakinya.", "petunjuk": ["`setmetatable({}, Akaun)` menjadikan carian yang gagal jatuh kembali kepada `Akaun`.", "`function Akaun:deposit(n)` mentakrifkan kaedah dengan `self` tersirat."], "fn": "gunaAkaun", "starter": "Akaun = {}\nAkaun.__index = Akaun\n\nfunction Akaun.baharu()\n\nend\n\nfunction gunaAkaun(jumlah)\n\nend", "jawapan": "Akaun = {}\nAkaun.__index = Akaun\n\nfunction Akaun.baharu()\n  return setmetatable({ jumlah = 0 }, Akaun)\nend\n\nfunction Akaun:deposit(n)\n  self.jumlah = self.jumlah + n\nend\n\nfunction Akaun:baki()\n  return self.jumlah\nend\n\nfunction gunaAkaun(jumlah)\n  local a = Akaun.baharu()\n  a:deposit(jumlah)\n  return a:baki()\nend", "kes": [{"args": [100], "jangka": 100}, {"args": [0], "jangka": 0}, {"args": [50], "jangka": 50}], "syarat": [{"corak": "setmetatable", "mesej": "Guna `setmetatable` untuk memautkan contoh kepada kelas."}]}, {"bab": 7, "jenis": "tulis", "tajuk": "__index sebagai fungsi", "brief": "Tulis `lalaiJadual(lalai, kunci)` yang cipta jadual di mana **mana-mana** kunci yang hilang pulangkan `lalai`, kemudian pulangkan nilai pada `kunci`.", "petunjuk": ["`__index` boleh berupa fungsi, bukan hanya jadual.", "`setmetatable({}, { __index = function() return lalai end })`"], "fn": "lalaiJadual", "starter": "function lalaiJadual(lalai, kunci)\n\nend", "jawapan": "function lalaiJadual(lalai, kunci)\n  local t = setmetatable({}, { __index = function() return lalai end })\n  return t[kunci]\nend", "kes": [{"args": [0, "apa-apa"], "jangka": 0}, {"args": ["kosong", "x"], "jangka": "kosong"}]}, {"bab": 7, "jenis": "pilih", "tajuk": "Titik berbanding titik bertindih", "brief": "", "petunjuk": [], "soalan": "Apa beza `a.deposit(5)` dan `a:deposit(5)`?", "pilihan": ["Titik bertindih menghantar `a` sebagai `self` secara automatik; titik tidak", "Tiada beza", "Titik bertindih lebih pantas", "Titik hanya untuk medan, bukan fungsi"], "betul": 0, "huraian": "`a:deposit(5)` ialah singkatan tepat untuk `a.deposit(a, 5)`. Terlupa titik bertindih ialah pepijat Lua paling biasa — kaedah menerima `5` sebagai `self` dan gagal secara pelik, bukan dengan ralat yang jelas."}, {"bab": 8, "jenis": "tulis", "tajuk": "pcall", "brief": "Tulis `cubaJalan(fn)` yang jalankan `fn` dengan selamat. Berjaya → pulangkan `true` dan hasilnya. Gagal → pulangkan `false` dan mesej ralat.\n\nLua tiada `try`. Ia ada `pcall`, yang memulangkan status sebagai nilai.", "petunjuk": ["`pcall(fn)` sudah memulangkan `ok, hasil` — itulah bentuk yang kau perlukan.", "`return pcall(fn)` memulangkan kedua-duanya terus."], "fn": "cubaJalan", "starter": "function cubaJalan(fn)\n\nend", "jawapan": "function cubaJalan(fn)\n  return pcall(fn)\nend", "kes": [{"args": ["__FN__:function() return 5 end"], "jangka": [true, 5], "berbilang": true}, {"args": ["__FN__:function() error(\"pecah\") end"], "jangka": [false, "__ADA_PECAH__"], "berbilang": true}]}, {"bab": 8, "jenis": "kukuh", "tajuk": "Baling ralat sendiri", "brief": "`bahagi(a, b)` mesti membaling ralat yang mengandungi `\"sifar\"` bila `b` ialah 0, dan mengandungi `\"nombor\"` bila mana-mana input bukan nombor. Kalau tidak pulangkan hasil bahagi.", "petunjuk": ["`type(x) ~= \"number\"` menyemak jenis. Lua guna `~=` bukan `!=`.", "`error(\"mesej\")` membaling. Semak jenis sebelum semak sifar."], "fn": "bahagi", "starter": "function bahagi(a, b)\n  return a / b\nend", "jawapan": "function bahagi(a, b)\n  if type(a) ~= \"number\" or type(b) ~= \"number\" then\n    error(\"input mesti nombor\")\n  end\n  if b == 0 then\n    error(\"tidak boleh bahagi dengan sifar\")\n  end\n  return a / b\nend", "kes": [{"args": [10, 2], "jangka": 5}, {"args": [-9, 3], "jangka": -3}, {"args": [1, 0], "baling": "sifar"}, {"args": ["5", 1], "baling": "nombor"}]}, {"bab": 8, "jenis": "ramal", "tajuk": "Bahagi dengan sifar", "brief": "Apa yang dicetak? Taip `true` atau `false`.", "petunjuk": ["Bahagi nombor terapung dengan sifar dalam Lua memberi infiniti, bukan ralat.", "Itulah sebabnya kau mesti menyemaknya sendiri — tiada pengecualian akan menghalang kau."], "kod": "print(1 / 0 == math.huge)", "output": "true"}, {"bab": 9, "jenis": "tulis", "tajuk": "Kumpul mengikut kunci", "brief": "Tulis `kumpulIkut(senarai, kunci)` di mana `senarai` ialah jadual berisi jadual. Kumpulkan mengikut nilai medan `kunci`.\n\nContoh: `{{j=\"a\"},{j=\"b\"},{j=\"a\"}}` dengan `\"j\"` → `{a={...,...}, b={...}}`", "petunjuk": ["Cipta jadual dalaman apabila kunci dilihat kali pertama.", "`hasil[k] = hasil[k] or {}` ialah simpulan bahasa Lua untuk itu."], "fn": "kumpulIkut", "starter": "function kumpulIkut(senarai, kunci)\n\nend", "jawapan": "function kumpulIkut(senarai, kunci)\n  local hasil = {}\n  for _, item in ipairs(senarai) do\n    local k = item[kunci]\n    hasil[k] = hasil[k] or {}\n    hasil[k][#hasil[k] + 1] = item\n  end\n  return hasil\nend", "kes": [{"args": [[{"j": "a", "n": 1}, {"j": "b", "n": 2}, {"j": "a", "n": 3}], "j"], "jangka": {"a": [{"j": "a", "n": 1}, {"j": "a", "n": 3}], "b": [{"j": "b", "n": 2}]}}, {"args": [[], "j"], "jangka": {}}]}, {"bab": 9, "jenis": "tulis", "tajuk": "Ringkasan statistik", "brief": "Tulis `statistik(t)` yang pulangkan jadual dengan medan `min`, `maks`, `purata` dan `median`.\n\nMedian untuk bilangan genap ialah purata dua nilai tengah. Jadual kosong → baling ralat mengandungi `\"kosong\"`.", "petunjuk": ["Salin sebelum mengisih — `table.sort` mengubah di tempatnya.", "`math.floor` untuk indeks tengah; ingat indeks bermula pada 1."], "fn": "statistik", "starter": "function statistik(t)\n\nend", "jawapan": "function statistik(t)\n  if #t == 0 then error(\"jadual kosong\") end\n  local s = {}\n  for i, v in ipairs(t) do s[i] = v end\n  table.sort(s)\n  local n = #s\n  local j = 0\n  for _, v in ipairs(s) do j = j + v end\n  local tengah = math.floor(n / 2)\n  local median\n  if n % 2 == 1 then\n    median = s[tengah + 1]\n  else\n    median = (s[tengah] + s[tengah + 1]) / 2\n  end\n  return { min = s[1], maks = s[n], purata = j / n, median = median }\nend", "kes": [{"args": [[1, 2, 3, 4]], "jangka": {"min": 1, "maks": 4, "purata": 2.5, "median": 2.5}}, {"args": [[5]], "jangka": {"min": 5, "maks": 5, "purata": 5, "median": 5}}, {"args": [[3, 1, 2]], "jangka": {"min": 1, "maks": 3, "purata": 2, "median": 2}}, {"args": [[]], "baling": "kosong"}]}, {"bab": 9, "jenis": "tulis", "tajuk": "Kurungan seimbang", "brief": "Tulis `kurunganSeimbang(s)` yang semak sama ada `()`, `[]` dan `{}` berpasangan dan bersarang dengan betul. Abaikan aksara lain.", "petunjuk": ["Guna jadual sebagai tindanan: `t[#t + 1] = c` untuk tolak, `table.remove(t)` untuk keluarkan.", "Jadual pasangan memetakan setiap kurungan tutup kepada bukanya."], "fn": "kurunganSeimbang", "starter": "function kurunganSeimbang(s)\n\nend", "jawapan": "function kurunganSeimbang(s)\n  local pasangan = { [\")\"] = \"(\", [\"]\"] = \"[\", [\"}\"] = \"{\" }\n  local tindanan = {}\n  for c in s:gmatch(\".\") do\n    if c == \"(\" or c == \"[\" or c == \"{\" then\n      tindanan[#tindanan + 1] = c\n    elseif pasangan[c] then\n      if table.remove(tindanan) ~= pasangan[c] then return false end\n    end\n  end\n  return #tindanan == 0\nend", "kes": [{"args": ["({[]})"], "jangka": true}, {"args": ["(]"], "jangka": false}, {"args": ["("], "jangka": false}, {"args": [""], "jangka": true}, {"args": ["a(b)c"], "jangka": true}, {"args": [")("], "jangka": false}]}];
  const LUA_JUMLAH = 1100;

  let kilang = null;

  function lapor(p, f) {
    if (typeof AndroidKemajuan !== "undefined") AndroidKemajuan.lapor(p, f === null ? -1 : f);
  }


  /* Pengkompil dimuat melalui tag skrip supaya WebView menstrimnya secara asli.
     Menghantar 8.7 MB melalui evaluateJavascript akan menggandakannya dalam memori. */
  function muatSkrip(src) {
    return new Promise(function (resolve, reject) {
      const s = document.createElement("script");
      s.src = src;
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error("gagal memuat " + src)); };
      document.head.appendChild(s);
    });
  }

  function babUntuk(n) { return LUA_BAB.find((b) => n >= b.dari && n <= b.hingga) || LUA_BAB[0]; }

  function tugasUntuk(n) {
    const bab = babUntuk(n);
    const bank = LUA_TUGAS.filter((t) => t.bab === bab.n);
    if (!bank.length) return { bab: bab, tugas: LUA_TUGAS[n % LUA_TUGAS.length] };
    return { bab: bab, tugas: bank[(n - bab.dari) % bank.length] };
  }

  function papar(v) {
    if (v === undefined || v === null) return "nil";
    try { return JSON.stringify(v); } catch (e) { return String(v); }
  }

  /* JSON.stringify sensitif kepada susunan kunci, dan Lua tidak menjamin
     susunan sebarang jadual. Bandingkan struktur, bukan teks. */
  function eq(a, b) {
    if (a === b) return true;
    if (a === undefined && b === null) return true;
    if (a === null && b === undefined) return true;
    if (typeof a === "number" && typeof b === "number") return Math.abs(a - b) < 1e-9;
    if (a === null || b === null || typeof a !== "object" || typeof b !== "object") return false;
    const ka = Object.keys(a), kb = Object.keys(b);
    /* Jadual Lua kosong tiada kunci, jadi senarai kosong dan peta kosong
       tidak boleh dibezakan. Anggap kedua-duanya sepadan. */
    if (ka.length === 0 && kb.length === 0) return true;
    if (ka.length !== kb.length) return false;
    return ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && eq(a[k], b[k]));
  }

  /* Nilai JS -> literal Lua, supaya hujah boleh dibina dalam sumber Lua. */
  function keLua(v) {
    if (v === null || v === undefined) return "nil";
    if (typeof v === "number" || typeof v === "boolean") return String(v);
    if (typeof v === "string") {
      if (v.indexOf("__FN__:") === 0) return v.slice(7);
      return JSON.stringify(v);
    }
    if (Array.isArray(v)) return "{" + v.map(keLua).join(", ") + "}";
    return "{" + Object.keys(v).map((k) => "[" + JSON.stringify(k) + "]=" + keLua(v[k])).join(", ") + "}";
  }

  const TanggaLua = {
    jumlah: () => LUA_JUMLAH,
    bab: () => JSON.stringify(LUA_BAB),

    level: function (n) {
      const info = tugasUntuk(n), t = info.tugas;
      const k = { n: n, bab: info.bab.n, namaBab: info.bab.nama, jenis: t.jenis,
                  tajuk: t.tajuk, brief: t.brief, petunjuk: t.petunjuk || [] };
      if (t.jenis === "pilih") {
        k.soalan = t.soalan; k.pilihan = t.pilihan; k.betul = t.betul; k.huraian = t.huraian;
      } else if (t.jenis === "ramal") {
        k.kod = t.kod;
      } else {
        k.fn = t.fn; k.starter = t.starter; k.jawapan = t.jawapan || "";
        k.kes = (t.kes || []).map((c) => ({
          hujah: "(" + c.args.map(papar).join(", ") + ")",
          jangka: "baling" in c ? 'baling "' + c.baling + '"' : papar(c.jangka),
        }));
      }
      return JSON.stringify(k);
    },

    semakRamal: function (n, teks) {
      const t = tugasUntuk(n).tugas;
      const j = String(t.output || "").trim();
      return JSON.stringify({ lulus: String(teks).trim() === j, jangka: j });
    },

    sedia: async function () {
      if (kilang) return true;
      if (typeof wasmoon === "undefined") {
        lapor("Memuat enjin Lua", null);
        await muatSkrip("wasmoon/wasmoon.js");
      }
      lapor("Memulakan Lua", null);
      const { LuaFactory } = wasmoon;
      kilang = new LuaFactory("wasmoon/glue.wasm");
      /* Cipta satu enjin sekarang supaya modul wasm dikompil dan dicache
         semasa pemanasan, bukan pada ujian pertama pengguna. */
      const panas = await kilang.createEngine();
      panas.global.close();
      lapor("Sedia", 1);
      return true;
    },

    jalan: async function (n, kod) {
      const t = tugasUntuk(n).tugas;

      for (const s of t.syarat || []) {
        const ada = new RegExp(s.corak).test(kod);
        if (!!s.negatif === ada) return JSON.stringify({ fatal: s.mesej });
      }

      try { await TanggaLua.sedia(); }
      catch (e) {
        return JSON.stringify({
          fatal: "Enjin Lua tidak dapat dimuatkan. Jalankan ./ambil-lua.sh sebelum membina. — " +
            String(e && e.message ? e.message : e).slice(0, 200),
        });
      }

      const keluar = [];
      for (const c of t.kes || []) {
        /* Setiap kes mendapat enjin baharu. Ini penting atas dua sebab:
           global Lua akan bocor antara ujian dan membenarkan penyelesaian palsu,
           dan ralat yang tidak ditangkap merosakkan keadaan supaya setiap ujian
           selepasnya gagal dengan _ENV nil. Kilang mencache modul wasm yang
           dikompil, jadi cipta enjin adalah murah. */
        let enjin = null, hasil, err = null;
        try {
          enjin = await kilang.createEngine();
          const panggil = t.fn + "(" + c.args.map(keLua).join(", ") + ")";
          /* table.pack memelihara pulangan berbilang termasuk nil di tengah,
             yang senarai biasa akan hilang. */
          const skrip = c.berbilang
            ? kod + "\nlocal __r = table.pack(" + panggil + ")\nreturn __r"
            : kod + "\nreturn " + panggil;
          hasil = await enjin.doString(skrip);
          if (c.berbilang) {
            const n = hasil && typeof hasil.n === "number" ? hasil.n : 0;
            const senarai = [];
            for (let i = 1; i <= n; i++) {
              senarai.push(hasil[i] === undefined ? null : hasil[i]);
            }
            hasil = senarai;
          }
        } catch (e) {
          err = String(e && e.message ? e.message : e);
        } finally {
          if (enjin) { try { enjin.global.close(); } catch (e2) {} }
        }

        if ("baling" in c) {
          const lulus = err !== null && err.toLowerCase().indexOf(String(c.baling).toLowerCase()) >= 0;
          keluar.push({ lulus: lulus, papar: err === null ? "tiada ralat \u2014 dapat " + papar(hasil) : err });
        } else {
          let lulus = err === null;
          if (lulus && c.berbilang) {
            const j = c.jangka;
            lulus = Array.isArray(hasil) && hasil.length === j.length &&
              j.every(function (jn, i) {
                /* "__ADA_X__" bermaksud: mesej ralat mesti mengandungi X. */
                if (typeof jn === "string" && jn.indexOf("__ADA_") === 0) {
                  return String(hasil[i]).toLowerCase()
                    .indexOf(jn.slice(6, -2).toLowerCase()) >= 0;
                }
                return eq(hasil[i], jn);
              });
          } else if (lulus) {
            lulus = eq(hasil, c.jangka);
          }
          keluar.push({ lulus: lulus, papar: err !== null ? "RALAT: " + err : papar(hasil) });
        }
      }
      return JSON.stringify({ results: keluar });
    },
  };

  window.TanggaLua = TanggaLua;
})();
