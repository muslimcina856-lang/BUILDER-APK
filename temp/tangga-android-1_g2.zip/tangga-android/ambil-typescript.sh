#!/usr/bin/env bash
# Memuat turun pengkompil TypeScript dan fail lib jenis ke dalam assets.
# APK bertambah kira-kira 9 MB.
#
# Versi PENTING: TypeScript 7 ialah pengkompil native Go dan tidak boleh
# berjalan dalam WebView. Kita memerlukan siri 5.x yang ditulis dalam JavaScript.
set -euo pipefail
VERSI="${1:-5.9.3}"
DEST="app/src/main/assets/tslib"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

echo "Memuat turun TypeScript ${VERSI}..."
npm pack "typescript@${VERSI}" --pack-destination "$TMP" --silent >/dev/null
tar -xzf "$TMP"/typescript-*.tgz -C "$TMP"

mkdir -p "$DEST"
cp "$TMP/package/lib/typescript.js" "$DEST/"
# Hanya fail lib yang diperlukan oleh sasaran es2020. lib.dom tidak diperlukan.
for f in "$TMP"/package/lib/lib.es5.d.ts \
         "$TMP"/package/lib/lib.es201[5-9]*.d.ts \
         "$TMP"/package/lib/lib.es2020*.d.ts; do
  [ -f "$f" ] && cp "$f" "$DEST/"
done

mkdir -p app/src/main/assets/lesen
# Apache-2.0 mewajibkan salinan lesen dihantar bersama binari.
cp "$TMP/package/LICENSE.txt" app/src/main/assets/lesen/typescript-APACHE-2.0.txt 2>/dev/null || \
  cp "$TMP"/package/LICENSE* app/src/main/assets/lesen/typescript-APACHE-2.0.txt

echo "Siap. $(ls "$DEST" | wc -l) fail, $(du -sh "$DEST" | cut -f1)"
