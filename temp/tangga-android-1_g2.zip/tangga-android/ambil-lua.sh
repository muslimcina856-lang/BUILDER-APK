#!/usr/bin/env bash
# Memuat turun wasmoon (Lua 5.4 dikompil ke WebAssembly) ke dalam assets.
# APK bertambah kira-kira 450 KB.
set -euo pipefail
VERSI="${1:-1.16.0}"
DEST="app/src/main/assets/wasmoon"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

echo "Memuat turun wasmoon ${VERSI}..."
npm pack "wasmoon@${VERSI}" --pack-destination "$TMP" --silent >/dev/null
tar -xzf "$TMP"/wasmoon-*.tgz -C "$TMP"

mkdir -p "$DEST"
# Binaan UMD mendedahkan `window.wasmoon` bila dimuat melalui tag skrip.
cp "$TMP/package/dist/index.js" "$DEST/wasmoon.js"
cp "$TMP/package/dist/glue.wasm" "$DEST/"

mkdir -p app/src/main/assets/lesen
# MIT mewajibkan notis hak cipta dikekalkan.
cp "$TMP"/package/LICENSE* app/src/main/assets/lesen/wasmoon-MIT.txt 2>/dev/null || true

echo "Siap. $(du -sh "$DEST" | cut -f1)"
