# Tangga — Android native

Aplikasi belajar coding. 26 bab, 3,500 level, 212 template tugasan.
Kod yang kau tulis dijalankan sungguh-sungguh terhadap kes ujian.

## Enam laluan

| Laluan | Level | Bab | Templat | Enjin | Aset |
|---|---|---|---|---|---|
| JavaScript | 3,500 | 26 | 212 | WebView JS terbina | — |
| Python | 1,800 | 12 | 69 | Pyodide (CPython ke wasm) | ~12 MB |
| SQL | 1,300 | 11 | 53 | SQL.js (SQLite ke wasm) | ~1.5 MB |
| TypeScript | 1,400 | 11 | 39 | tsc 5.9 (semakan jenis penuh) | ~9 MB |
| Lua | 1,100 | 9 | 34 | wasmoon (Lua 5.4 ke wasm) | ~450 KB |
| HTML & CSS | 1,000 | 9 | 30 | DOM WebView sendiri | **0 MB** |

Laluan HTML/CSS tidak memerlukan runtime tambahan langsung. Kod pengguna
dihuraikan oleh DOM WebView sendiri dalam iframe berkotak pasir tanpa
`allow-scripts`, dan penegasan berjalan terhadap pokok yang terhasil serta gaya
yang dikira — termasuk cascade CSS penuh.

Laluan TypeScript menjalankan pengkompil sebenar pada mod `strict`, bukan sekadar
menanggalkan anotasi. Setiap tugasan juga membawa senarai `mestiTolak` — petikan
yang MESTI gagal semakan jenis. Tanpanya seseorang boleh menganotasi
segala-galanya `any` dan lulus setiap ujian masa jalan.

Setiap tugasan SQL dijalankan terhadap **dua set data berbeza**, jadi kueri yang
menulis jawapan secara mati akan lulus set pertama dan gagal set kedua.

Setiap jawapan rujukan Python disahkan dengan CPython 3.12 sebelum penjanaan:
218 penegasan, sifar kegagalan. Setiap tugasan "baiki" juga disahkan benar-benar
bermula dalam keadaan rosak.

## Memasang runtime bahasa

Aplikasi tiada kebenaran internet, jadi Python mesti dibundel, bukan dimuat turun
semasa jalanan. Jalankan sekali sebelum binaan pertama:

```bash
./ambil-pyodide.sh     # Python, ~12 MB
./ambil-sqljs.sh       # SQL, ~1.5 MB
./ambil-typescript.sh  # TypeScript, ~9 MB
./ambil-lua.sh         # Lua, ~450 KB
```

Runtime ini tidak disimpan dalam repositori kerana saiznya. **JavaScript dan
HTML/CSS berfungsi tanpa pemasangan** — kedua-duanya menggunakan enjin WebView
terbina.

Aplikasi mengesan runtime yang hilang semasa mula dan menandakan laluan
berkenaan pada skrin pemilihan bahasa, dengan nama skrip yang betul untuk setiap
satu. Pengguna tahu sebelum memilih, bukan selepas menunggu.

Ini menambah kira-kira 12 MB kepada APK. Tanpanya laluan JavaScript tetap
berfungsi sepenuhnya; laluan Python akan melaporkan enjin tidak dapat dimuatkan.

## Timbunan

| Lapisan | Teknologi |
|---|---|
| UI | Jetpack Compose (Material 3), Kotlin |
| Reka bentuk | Permukaan kaca di atas latar aurora bergerak |
| Gerakan | Animasi spring Compose — bukan Framer Motion, yang React sahaja |
| Keadaan | `ViewModel` + `StateFlow` |
| Simpanan | DataStore Preferences (satu blob JSON, semuanya pada peranti) |
| Enjin ujian | `WebView` tanpa skrin sebagai runtime JavaScript bersandbox |
| Bank tugasan | `assets/enjin.js` |

Tiada kebenaran diminta. Tiada rangkaian. Tiada analitis. Tiada iklan.

## Kenapa ada WebView dalam aplikasi "native"

Aplikasi ini mengajar JavaScript, jadi ia mesti **menjalankan** JavaScript yang
ditulis pengguna. Android tiada jurubahasa JS yang boleh dicapai dari Kotlin, dan
tiada jurubahasa Kotlin di atas peranti — jadi tidak ada jalan untuk "menjadikan
semuanya Kotlin" tanpa menukar bahasa yang diajar.

`EnjinJs` mencipta satu `WebView` yang **tidak pernah dipaparkan**, tidak pernah
memuatkan URL, dan mempunyai `blockNetworkLoads = true`. Ia semata-mata runtime.
Semua UI, navigasi, tema, simpanan dan logik aplikasi adalah Kotlin/Compose tulen.

Alternatif kalau kau mahu membuang WebView sepenuhnya: benamkan QuickJS atau
Rhino sebagai perpustakaan native. Ia berfungsi, tetapi menambah beban binaan
tanpa faedah keselamatan yang bermakna berbanding pendekatan ini.

### Sandbox

Kod pengguna dinilai dalam `new Function(...)` yang **membayangi**
`AndroidJambatan`, `window`, `document`, `fetch`, `XMLHttpRequest`, `WebSocket`,
`localStorage`, `indexedDB` dan `importScripts` sebagai parameter kosong. Ia tidak
boleh mencapai jambatan Android mahupun rangkaian.

### Gelung tak berhenti

`evaluateJavascript` tidak menyekat urutan UI, tetapi gelung tak berhenti akan
menggantung urutan JS WebView selamanya. Selepas 4 saat tanpa balasan, `EnjinJs`
memusnahkan WebView itu dan membina yang baharu. Pengguna nampak mesej masa tamat
dan aplikasi kekal responsif. Level 244 sengaja mengandungi gelung sebegini
sebagai pengajaran.

## Semakan penyedia WebView

Setiap laluan berjalan di dalam WebView, jadi versi penyedia peranti menentukan
apa yang berfungsi. `SemakanWebView` membacanya semasa mula dan memberi amaran
bila ia terlalu lama, dan bukannya membiarkan Pyodide gagal dengan ralat wasm
yang tidak bermakna kepada pengguna.

| Ambang | Sebab |
|---|---|
| Chrome 80 | Aset enjin guna rantaian pilihan dan nullish |
| Chrome 91 | Pyodide memerlukan wasm SIMD |

Kedua-dua angka datang daripada mengimbas aset yang sebenarnya dihantar, bukan
tekaan. Ia tetap anggaran, jadi semakan itu **memberi amaran tetapi tidak
menyekat** — kalau anggaran salah pada peranti tertentu, pengguna masih boleh
mencuba. Angka Python terikat pada binaan Pyodide yang diambil oleh
`ambil-pyodide.sh`; kemas kini `MIN_PYTHON` jika kau menukar versi itu.

## Nota reka bentuk

Kaca dikenakan pada **chrome sahaja** — kepala, kad, bar bawah, pemilih bahasa.
Permukaan kod kekal pekat dan berkontras tinggi, kerana monospace di atas latar
lutsinar yang bergerak sukar dibaca, dan kebolehbacaan mengalahkan konsistensi
visual dalam aplikasi belajar kod.

Blur sebenar memerlukan `RenderEffect`, iaitu API 31. minSdk kita 24, jadi
`Kaca` menggunakan isian lebih pekat pada peranti lama. Ia masih kelihatan
disengajakan di sana — cuma kurang kabur.

Latar aurora hidup di `MainActivity` dan tidak pernah dibina semula semasa
navigasi, jadi gerakannya berterusan merentas peralihan skrin.

## Menyemak sebelum membina

```bash
./semak/semak-kotlin.sh      # semakan jenis, beberapa saat
python3 semak/semak-api36.py      # perubahan tingkah laku API 36
python3 semak/semak-nilai-jalan.py # nilai yang lulus jenis tetapi menghempas
python3 semak-import.py      # import Compose menunjuk pakej betul
python3 semak-panggilan.py   # hujah composable sepadan tandatangan
```

Skrip pertama mengkompil semua kod Kotlin terhadap stub API Android dan Compose
dalam `semak/stub/`. Ia menangkap nama hujah salah, `when` tidak lengkap, simbol
tidak wujud dan ketidakpadanan jenis tanpa memerlukan Android SDK, Gradle atau
repositori Maven.

Stub mesti memadankan **bentuk pengisytiharan dan nilai lalai** API sebenar,
bukan sekadar namanya. Nilai lalai penting sama seperti tandatangan: stub yang
mengisytiharkan `radius: Float = 0f` untuk `radialGradient` menggalakkan
pemanggil menghantar `0f` secara eksplisit, dan Android membaling
`IllegalArgumentException: radius must be > 0` pada bingkai pertama. Compose
sebenar menggunakan `Float.POSITIVE_INFINITY`. `semak/semak-nilai-jalan.py`
wujud khusus kerana pepijat itu. `Brush.linearGradient` ialah ahli `Brush.Companion`; memodelkannya
sebagai sambungan peringkat atas membenarkan import yang tidak sah lulus di sini
dan gagal pada Gradle.

Ia bukan pengganti binaan sebenar — ia tidak menjalankan pemalam pengkompil
Compose dan tidak menyentuh sumber XML — tetapi ia menangkap hampir semua ralat
kompil dalam beberapa saat dan bukan beberapa minit.

## Sebelum menghantar ke Play Store

### Perubahan tingkah laku API 36

`targetSdk = 36` menghidupkan perubahan yang **tidak** muncul sebagai ralat
kompil — ia gagal secara senyap semasa jalan. `semak/semak-api36.py` menyemak apa
yang boleh disemak daripada sumber:

- Edge-to-edge dikuatkuasakan sejak targetSdk 35. `android:statusBarColor` dan
  `android:navigationBarColor` diabaikan secara senyap, jadi ia dibuang daripada
  tema. `enableEdgeToEdge()` mengendalikan bar sistem, aurora melukis di
  belakangnya, dan kandungan diinset dengan `systemBarsPadding()`.
- Back ramalan hidup secara lalai pada targetSdk 36.
  `android:enableOnBackInvokedCallback="true"` diisytiharkan supaya niat itu
  jelas dan bukan bergantung pada lalai senyap.
- Android 16 mengabaikan sekatan orientasi dan `resizeableActivity` pada skrin
  melebihi 600dp. Kita tidak menetapkan kedua-duanya, jadi tiada apa berubah.
- Penjajaran halaman 16 KB hanya terpakai kepada aplikasi yang menghantar
  pustaka native. Projek ini tiada, dan tiada kebergantungannya membawa `.so`.

Sudah disediakan dalam repo:

- Ikon pelancar untuk 5 densiti PNG **dan** adaptif v26. Adaptif sahaja tidak
  memadai kerana minSdk ialah 24 — API 24-25 tidak dapat menyelesaikan
  `@mipmap/ic_launcher` daripada `mipmap-anydpi-v26` dan akan gagal dilancarkan.
- `android:roundIcon` diisytiharkan supaya pelancar bulat menggunakannya.
- Atribusi lesen dalam `assets/lesen/`, boleh dilihat melalui skrin Lesen.
  Apache-2.0 (TypeScript) mewajibkan salinan lesen dihantar bersama binari, dan
  MIT (wasmoon, sql.js) mewajibkan notis hak cipta dikekalkan. Skrip `ambil-*.sh`
  menyalin lesen bersama runtime, jadi apa yang tidak diambil tidak perlu
  atribusi.
- Sasaran sentuh minimum 48dp dan `onClickLabel` pada setiap kawasan interaktif,
  supaya laporan pra-pelancaran tidak menandakannya.
- `play/ikon-kedai-512.png` untuk penyenaraian kedai.

Masih perlu kau sediakan:

- Dasar privasi. Play mewajibkannya walaupun tiada data dikumpul.
- Tangkapan skrin dan grafik ciri.
- 12 penguji selama 14 hari jika ini akaun peribadi yang didaftarkan selepas
  November 2023.
- Kunci penandatanganan, atau gunakan Play App Signing.

## Membina

```bash
# Perlukan Android Studio (Ladybug ke atas) atau Android SDK + JDK 17
./gradlew assembleDebug          # APG nyahpepijat
./gradlew bundleRelease          # AAB untuk Play Store
```

Buka folder ini dalam Android Studio dan biarkan ia menjana pembalut Gradle
(`gradlew`) — ia tidak disertakan di sini.

**Versi dalam `gradle/libs.versions.toml` mungkin sudah lapuk.** Jalankan AGP
Upgrade Assistant dan terima cadangan kemas kini kebergantungan sebelum kau
membazir masa menyahpepijat ralat binaan.

## Apa yang belum siap

- Tiada pembalut Gradle (`gradlew`) — Android Studio akan menjananya
- Tiada ujian berinstrumen atau ujian unit
- Editor kod ialah `BasicTextField`, tiada penyerlahan sintaks. Untuk itu,
  pertimbangkan `compose-code-editor` atau tulis `VisualTransformation` sendiri
- Tiada carian level atau penanda buku
- Tiada sokongan tablet khusus (susun atur satu lajur pada semua saiz)
