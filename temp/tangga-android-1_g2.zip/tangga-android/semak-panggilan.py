#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Menyemak setiap hujah bernama yang dihantar kepada composable benar-benar wujud."""
import pathlib, re, sys

def blok_panggilan(src, nama):
    """Petik isi setiap panggilan `nama(...)` dengan mengira kurungan."""
    for m in re.finditer(rf'\b{nama}\(', src):
        i = m.end(); dalam = 1; mula = i
        while i < len(src) and dalam:
            if src[i] == '(': dalam += 1
            elif src[i] == ')': dalam -= 1
            i += 1
        yield src[mula:i - 1]

def semak(akar):
    masalah = 0
    ui = akar / "app/src/main/java/my/tangga/ui"
    main = (akar / "app/src/main/java/my/tangga/MainActivity.kt").read_text()
    for fail in sorted(ui.glob("*Skrin.kt")):
        nama = fail.stem
        src = fail.read_text()
        t = src[src.index(f"fun {nama}("):]
        t = t[t.index("(") + 1:t.index(") {")]
        param = set(re.findall(r'(\w+):\s', t))
        for blok in blok_panggilan(main, nama):
            for arg in re.findall(r'(\w+)\s*=[^=]', blok):
                if arg not in param:
                    print(f"  X MainActivity: {nama}({arg} = ...) bukan parameter")
                    masalah += 1
        # setiap parameter tanpa nilai lalai mesti dibekalkan
        wajib = [x for x in re.split(r',(?![^(]*\))', t) if x.strip() and "=" not in x.split(":")[-1]]
        for blok in blok_panggilan(main, nama):
            if "=" not in blok:
                continue  # panggilan kedudukan, langkau
            for w in wajib:
                kunci = w.split(":")[0].strip()
                if f"{kunci} =" not in blok:
                    print(f"  X MainActivity: {nama} kehilangan hujah `{kunci}`")
                    masalah += 1
    print(f"Panggilan composable disemak. Masalah: {masalah}")
    return masalah

if __name__ == "__main__":
    sys.exit(1 if semak(pathlib.Path(".")) else 0)
