# -*- coding: utf-8 -*-
"""
Mencari nilai yang lulus semakan jenis tetapi menghempas semasa jalan.

Ini wujud kerana satu pepijat sebenar: `Brush.radialGradient(..., radius = 0f)`
lulus setiap semakan statik dan kemudian membaling
`IllegalArgumentException: radius must be > 0` pada bingkai pertama. Pengkompil
tidak boleh menangkapnya. Stub pun tidak. Hanya semakan nilai boleh.
"""
import pathlib
import re
import sys

AKAR = pathlib.Path(__file__).resolve().parent.parent
SUMBER = AKAR / "app/src/main/java"


def badan_panggilan(teks, mula):
    """Pulangkan teks di dalam kurungan yang bermula pada `mula`."""
    dalam, i = 1, mula
    while i < len(teks) and dalam:
        if teks[i] == "(":
            dalam += 1
        elif teks[i] == ")":
            dalam -= 1
        i += 1
    return teks[mula:i - 1]


def semak_fail(p):
    teks = p.read_text(encoding="utf-8")
    masalah = []

    for m in re.finditer(r"Brush\.(radialGradient|linearGradient|verticalGradient|"
                         r"horizontalGradient)\s*\(", teks):
        badan = badan_panggilan(teks, m.end())
        baris = teks[:m.start()].count("\n") + 1
        jenis = m.group(1)

        if jenis == "radialGradient" and re.search(r",\s*0(\.0)?f\s*,?\s*$", badan.rstrip()):
            masalah.append((baris, "radialGradient dengan radius 0 membaling pada Android; "
                                  "abaikan hujah itu untuk guna lalai"))

        offset = [o.replace(" ", "") for o in re.findall(r"Offset\(([^)]*)\)", badan)]
        if len(offset) == 2 and offset[0] == offset[1]:
            masalah.append((baris, f"{jenis} dengan start sama dengan end merosot"))

        if not badan.strip():
            masalah.append((baris, f"{jenis} tanpa warna"))

    # fillMaxWidth/Height dengan pecahan dikira mesti dikepit
    for m in re.finditer(r"fillMax(?:Width|Height)\(\s*([^)]+?)\s*\)", teks):
        hujah = m.group(1)
        baris = teks[:m.start()].count("\n") + 1
        kira = not re.fullmatch(r"[\d.]+f?", hujah)
        if kira and "coerceIn" not in hujah:
            masalah.append((baris, f"pecahan fillMax dikira tanpa coerceIn: {hujah}"))

    # Pembahagi yang mungkin sifar dalam pengiraan peratus
    for m in re.finditer(r"\*\s*100\s*/\s*(\w+(?:\.\w+)*)", teks):
        baris = teks[:m.start()].count("\n") + 1
        konteks = teks[max(0, m.start() - 400):m.start()]
        pembahagi = m.group(1)
        if f"{pembahagi} == 0" not in konteks and f"{pembahagi} > 0" not in konteks:
            masalah.append((baris, f"bahagi dengan {pembahagi} tanpa pengawal sifar"))

    return masalah


def utama():
    jumlah = 0
    for p in sorted(SUMBER.rglob("*.kt")):
        for baris, mesej in semak_fail(p):
            print(f"  \u2717 {p.name}:{baris} {mesej}")
            jumlah += 1
    if jumlah:
        print(f"\nNilai berisiko masa jalan: {jumlah}")
        return 1
    print("Semakan nilai masa jalan lulus.")
    return 0


if __name__ == "__main__":
    sys.exit(utama())
