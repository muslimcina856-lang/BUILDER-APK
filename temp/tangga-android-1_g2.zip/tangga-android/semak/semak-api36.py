# -*- coding: utf-8 -*-
"""
Semakan perubahan tingkah laku API 36 daripada sumber.

`targetSdk = 36` menghidupkan perubahan tingkah laku yang tidak muncul sebagai
ralat kompil. Ia gagal secara senyap semasa jalan, atau ditolak oleh Play.
Skrip ini menyemak apa yang boleh disemak daripada kod.

Ia BUKAN pengganti ujian pada Android 16 sebenar.
"""
import pathlib
import re
import sys

AKAR = pathlib.Path(__file__).resolve().parent.parent


def tanpa_komen(teks):
    return re.sub(r"<!--.*?-->", "", teks, flags=re.S)


def utama():
    man = tanpa_komen((AKAR / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8"))
    tema_mentah = (AKAR / "app/src/main/res/values/themes.xml").read_text(encoding="utf-8")
    item_tema = re.findall(r'<item name="([^"]+)"', tanpa_komen(tema_mentah))
    kt = " ".join(p.read_text(encoding="utf-8")
                  for p in (AKAR / "app/src/main/java").rglob("*.kt"))
    gr = (AKAR / "app/build.gradle.kts").read_text(encoding="utf-8")

    semakan = [
        (
            "Edge-to-edge dikendalikan",
            "enableEdgeToEdge" in kt and "systemBarsPadding" in kt,
            "targetSdk 35+ menguatkuasakan edge-to-edge; kandungan mesti diinset sendiri",
        ),
        (
            "Tiada atribut warna bar sistem yang mati",
            not any("statusBarColor" in i or "navigationBarColor" in i for i in item_tema),
            "diabaikan secara senyap pada 35+; menyimpannya mengelirukan penyelenggara",
        ),
        (
            "Back ramalan diisytiharkan eksplisit",
            'enableOnBackInvokedCallback="true"' in man,
            "lalai hidup pada targetSdk 36; isytiharkan supaya niat jelas",
        ),
        (
            "Orientasi tidak dikunci",
            "screenOrientation" not in man,
            "36 mengabaikan sekatan orientasi pada skrin lebih 600dp",
        ),
        (
            "Perubahan konfigurasi dikendalikan",
            "orientation|screenSize" in man,
            "mengelakkan penciptaan semula aktiviti semasa putaran",
        ),
        (
            "Aktiviti boleh diubah saiz",
            'resizeableActivity="false"' not in man,
            "36 memaksa boleh ubah saiz pada skrin besar",
        ),
        (
            "compileSdk sepadan targetSdk 36",
            "compileSdk = 36" in gr and "targetSdk = 36" in gr,
            "Play menuntut targetSdk 36 untuk penghantaran baharu",
        ),
        (
            "Desugaring aktif untuk minSdk bawah 26",
            "isCoreLibraryDesugaringEnabled = true" in gr,
            "java.time memerlukan API 26; tanpanya aplikasi terhempas pada Android 7",
        ),
    ]

    gagal = []
    for nama, lulus, sebab in semakan:
        print(f"  {'\u2713' if lulus else '\u2717'} {nama}")
        if not lulus:
            gagal.append((nama, sebab))

    print()
    if gagal:
        print(f"MASALAH API 36: {len(gagal)}")
        for nama, sebab in gagal:
            print(f"  - {nama}\n    {sebab}")
        return 1
    print("Semakan API 36 lulus.")
    return 0


if __name__ == "__main__":
    sys.exit(utama())
