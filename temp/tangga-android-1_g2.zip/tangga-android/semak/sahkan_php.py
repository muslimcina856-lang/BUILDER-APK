# -*- coding: utf-8 -*-
"""Mengesahkan setiap jawapan rujukan PHP terhadap PHP 8.3 CLI."""
import json, math, re, subprocess, sys, tempfile, os
from bank_php import BANK_PHP

# Kod pengguna berjalan dengan strict_types, sama seperti dalam aplikasi.
HARNESS = r'''<?php
declare(strict_types=1);
%s

$__args = json_decode(file_get_contents('php://stdin'), true);
$__hidup = function ($v) {
    if (is_string($v) && str_starts_with($v, '__FN__:')) {
        return eval('return ' . substr($v, 7) . ';');
    }
    return $v;
};
try {
    $__h = %s(...array_map($__hidup, $__args));
    echo json_encode(["ok" => true, "nilai" => $__h], JSON_UNESCAPED_UNICODE);
} catch (\Throwable $e) {
    echo json_encode(["ok" => false, "ralat" => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
'''

RAMAL_HARNESS = "%s"


def jalankan_php(kod, fn, args):
    src = HARNESS % (kod, fn)
    with tempfile.NamedTemporaryFile("w", suffix=".php", delete=False, encoding="utf-8") as f:
        f.write(src)
        laluan = f.name
    try:
        p = subprocess.run(["php", "-d", "error_reporting=E_ALL", laluan],
                           input=json.dumps(args), capture_output=True, text=True, timeout=15)
        keluar = p.stdout.strip()
        if not keluar:
            return {"ok": False, "ralat": (p.stderr.strip() or "tiada output")[:200]}
        try:
            return json.loads(keluar)
        except json.JSONDecodeError:
            return {"ok": False, "ralat": f"output bukan JSON: {keluar[:200]}"}
    finally:
        os.unlink(laluan)


def sama(a, b):
    # json_encode PHP menukar array kosong kepada [], jadi senarai kosong dan
    # peta kosong tidak boleh dibezakan — sama seperti Lua.
    if isinstance(a, (list, dict)) and isinstance(b, (list, dict)):
        if len(a) == 0 and len(b) == 0:
            return True
    if isinstance(a, bool) or isinstance(b, bool):
        return a is b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-9)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(sama(x, y) for x, y in zip(a, b))
    if isinstance(a, dict) and isinstance(b, dict):
        return set(a) == set(b) and all(sama(a[k], b[k]) for k in a)
    return a == b


def jalankan_kes(kod, fn, kes):
    masalah = []
    for i, c in enumerate(kes):
        r = jalankan_php(kod, fn, c["args"])
        if "baling" in c:
            if r.get("ok"):
                masalah.append(f"kes {i}: sepatutnya membaling, dapat {r.get('nilai')!r}")
            elif c["baling"].lower() not in str(r.get("ralat", "")).lower():
                masalah.append(f"kes {i}: ralat {r.get('ralat')!r} tiada {c['baling']!r}")
            continue
        if not r.get("ok"):
            masalah.append(f"kes {i}: membaling: {r.get('ralat')}")
            continue
        if not sama(r.get("nilai"), c["jangka"]):
            masalah.append(f"kes {i}: jangka {c['jangka']!r}, dapat {r.get('nilai')!r}")
    return masalah


def sahkan(t):
    masalah = []
    if t["jenis"] == "pilih":
        if len(t.get("pilihan", [])) < 2:
            masalah.append("pilihan kurang 2")
        b = t.get("betul", -1)
        if not isinstance(b, int) or not (0 <= b < len(t.get("pilihan", []))):
            masalah.append("indeks betul tidak sah")
        if not t.get("huraian"):
            masalah.append("tiada huraian")
        return masalah

    if t["jenis"] == "ramal":
        with tempfile.NamedTemporaryFile("w", suffix=".php", delete=False, encoding="utf-8") as f:
            f.write(t["kod"])
            laluan = f.name
        try:
            p = subprocess.run(["php", laluan], capture_output=True, text=True, timeout=15)
            sebenar = p.stdout.strip()
            if sebenar != str(t["output"]).strip():
                masalah.append(f"output: jangka {t['output']!r}, dapat {sebenar!r} {p.stderr.strip()[:120]}")
        finally:
            os.unlink(laluan)
        return masalah

    for s in t.get("syarat", []):
        ada = re.search(s["corak"], t["jawapan"]) is not None
        if bool(s.get("negatif")) == ada:
            masalah.append(f"jawapan gagal syarat: {s['mesej']}")

    masalah += jalankan_kes(t["jawapan"], t["fn"], t["kes"])

    if t["jenis"] in ("baiki", "kukuh"):
        gagal_syarat = any(
            bool(s.get("negatif")) == (re.search(s["corak"], t["starter"]) is not None)
            for s in t.get("syarat", []))
        if not jalankan_kes(t["starter"], t["fn"], t["kes"]) and not gagal_syarat:
            masalah.append("kod permulaan sudah lulus — latihan palsu")
    return masalah


if __name__ == "__main__":
    jumlah, penegasan = 0, 0
    for t in BANK_PHP:
        m = sahkan(t)
        penegasan += len(t.get("kes", []))
        if m:
            jumlah += len(m)
            print(f"  X P{t['bab']:02d} {t.get('tajuk','?')}")
            for x in m:
                print(f"      {x}")
    print(f"{len(BANK_PHP)} templat | {penegasan} penegasan | masalah: {jumlah}")
    sys.exit(1 if jumlah else 0)
