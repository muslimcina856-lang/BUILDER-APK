#!/usr/bin/env bash
# Semakan jenis penuh tanpa Android SDK atau Gradle.
#
# Stub dalam semak/stub/ menyerupai API Android dan Compose cukup rapat untuk
# menangkap nama hujah salah, kiraan hujah salah, cabang `when` tidak lengkap,
# simbol tidak wujud dan ketidakpadanan jenis — dalam beberapa saat, bukan minit.
#
# Ketepatan stub itu penting. Contoh sebenar: `Brush.linearGradient` ialah AHLI
# `Brush.Companion`, bukan sambungan peringkat atas. Ahli tidak boleh diimport.
# Stub yang memodelkannya sebagai sambungan membenarkan
# `import androidx.compose.ui.graphics.linearGradient` lulus di sini tetapi gagal
# pada binaan sebenar. Bila kau menambah stub, padankan bentuk pengisytiharan
# sebenar, bukan sekadar namanya.
#
# Ia TIDAK menggantikan `./gradlew assembleDebug`. Ia tidak menjalankan pemalam
# pengkompil Compose dan tidak menyemak sumber XML. Anggap ia sebagai lulusan
# pertama yang pantas.
#
# Perlukan kotlinc pada PATH, atau tetapkan KOTLINC.
set -euo pipefail
cd "$(dirname "$0")/.."

KOTLINC="${KOTLINC:-kotlinc}"
if ! command -v "$KOTLINC" >/dev/null 2>&1; then
    echo "kotlinc tidak dijumpai. Pasang Kotlin, atau tetapkan KOTLINC=/laluan/ke/kotlinc"
    exit 127
fi

COROUTINES=$(dirname "$(readlink -f "$(command -v "$KOTLINC")")")/../lib/kotlinx-coroutines-core-jvm.jar

echo "Menyemak jenis kod projek terhadap stub..."
KELUARAN=$("$KOTLINC" semak/stub/*.kt \
    $(find app/src/main/java -name '*.kt') \
    -cp "$COROUTINES" -d /tmp/tangga-semak 2>&1 || true)

RALAT=$(echo "$KELUARAN" | grep "error:" | grep "my/tangga" || true)
AMARAN=$(echo "$KELUARAN" | grep "warning:" | grep "my/tangga" || true)

[ -n "$AMARAN" ] && { echo "AMARAN:"; echo "$AMARAN" | sed 's|.*/my/tangga/||'; echo; }

if [ -n "$RALAT" ]; then
    echo "RALAT:"
    echo "$RALAT" | sed 's|.*/my/tangga/||'
    echo
    echo "Jumlah: $(echo "$RALAT" | wc -l)"
    exit 1
fi

echo "Semakan jenis lulus. $(find app/src/main/java -name '*.kt' | wc -l) fail, $(cat $(find app/src/main/java -name '*.kt') | wc -l) baris."
