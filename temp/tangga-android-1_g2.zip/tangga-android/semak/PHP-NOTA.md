# Bank PHP: disahkan tetapi belum disambungkan

`bank_php.py` mengandungi 34 templat merentas 9 bab, disahkan sepenuhnya
terhadap PHP 8.3.6 CLI — 83 penegasan, sifar kegagalan. Jalankan
`python3 sahkan_php.py` untuk mengesahkan semula.

Ia **tidak** disambungkan ke aplikasi. Sebabnya jujur: saya tidak boleh
mengujinya.

## Apa yang menghalang

Satu-satunya PHP WebAssembly yang diselenggara ialah keluarga `@php-wasm/*`
daripada WordPress Playground:

- Memerlukan `@php-wasm/web` bersama `@php-wasm/universal` — API tersebar
  merentas beberapa pakej
- Direka sekitar worker thread dan pemuatan wasm berketul, bukan panggilan
  `initSqlJs()` atau `loadPyodide()` satu baris seperti runtime lain
- 18 MB untuk `php_8_3.wasm` sahaja, 31 MB untuk pakej penuh
- Memerlukan persekitaran pelayar sebenar, jadi ia tidak boleh diuji dalam
  bekas pembangunan ini langsung
- Imbasan simbol tidak menemui `mb_strlen` dalam wasm itu, jadi ketersediaan
  mbstring tidak pasti — bank ini mengelakkannya sepenuhnya

Menulis kira-kira 200 baris kod integrasi terhadap API yang hanya boleh saya
baca daripada takrifan jenis, tanpa satu pun ujian, akan menjadi tekaan yang
dibungkus sebagai ciri.

## Untuk menyambungkannya

Kau perlukan peranti atau emulator untuk mengesahkan. Langkahnya:

1. Pasang `@php-wasm/web` dan `@php-wasm/universal`, salin `php_8_3.wasm`
   dan pemuatnya ke `app/src/main/assets/phpwasm/`
2. Tulis `app/src/main/assets/php.js` mengikut corak `lua.js` — API yang sama
   (`jumlah`, `bab`, `level`, `sedia`, `jalan`), keadaan bersih setiap kes ujian
3. Tambah `PHP` pada enum `Bahasa` dalam `Model.kt` dengan
   `global = "TanggaPhp"`, dan satu slot dalam `SemuaProgres`
4. Sahkan `function_exists('mb_strlen')` pada peranti sebelum menambah
   sebarang tugasan multibait

Enjin Lua ialah rujukan terdekat: ia juga memerlukan keadaan bersih setiap kes
ujian, dan komen di dalamnya menerangkan sebabnya.
