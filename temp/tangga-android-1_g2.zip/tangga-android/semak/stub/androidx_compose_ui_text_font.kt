@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.text.font


class FontFamily {
    companion object {
        val Monospace = FontFamily()
        val Default = FontFamily()
    }
}

class FontWeight {
    companion object {
        val Bold = FontWeight()
        val SemiBold = FontWeight()
        val Normal = FontWeight()
    }
}

// ---------------------------------------------------------------------
