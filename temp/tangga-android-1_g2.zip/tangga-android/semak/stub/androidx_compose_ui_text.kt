@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.text

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit



class TextRange(mula: Int)

class SpanStyle(
    val color: Color? = null,
    val fontSize: TextUnit? = null,
    val fontWeight: FontWeight? = null,
    val fontFamily: FontFamily? = null,
)

class TextStyle(
    val color: Color? = null,
    val fontSize: TextUnit? = null,
    val fontFamily: FontFamily? = null,
    val lineHeight: TextUnit? = null,
) {
    fun copy(
        color: Color? = this.color,
        fontSize: TextUnit? = this.fontSize,
        fontFamily: FontFamily? = this.fontFamily,
        lineHeight: TextUnit? = this.lineHeight,
    ): TextStyle = this
}

open class AnnotatedString(val text: String) {
    class Builder {
        fun append(t: String) {}
        fun append(t: Char) {}
        fun append(t: AnnotatedString) {}
    }
}

fun buildAnnotatedString(builder: AnnotatedString.Builder.() -> Unit): AnnotatedString {
    AnnotatedString.Builder().builder()
    return AnnotatedString("")
}

fun AnnotatedString.Builder.withStyle(style: SpanStyle, block: AnnotatedString.Builder.() -> Unit) {
    this.block()
}

// ---------------------------------------------------------------------
