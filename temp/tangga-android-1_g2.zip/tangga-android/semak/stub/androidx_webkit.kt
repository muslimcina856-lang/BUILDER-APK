@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.webkit

import android.content.Context
import android.content.pm.PackageInfo
import android.net.Uri
import android.webkit.WebResourceResponse



class WebViewAssetLoader {
    fun shouldInterceptRequest(url: Uri): WebResourceResponse? = null

    class AssetsPathHandler(konteks: Context)

    class Builder {
        fun addPathHandler(path: String, handler: AssetsPathHandler): Builder = this
        fun build(): WebViewAssetLoader = WebViewAssetLoader()
    }
}

// ============================== kotlinx.serialization ==============================



object WebViewCompat {
    @JvmStatic
    fun getCurrentWebViewPackage(konteks: Context): PackageInfo? = null
}


// ---------------------------------------------------------------------
