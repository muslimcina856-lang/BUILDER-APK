@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.draw

import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp



fun Modifier.blur(radius: Dp): Modifier = this
fun Modifier.clip(shape: Shape): Modifier = this
fun Modifier.alpha(alpha: Float): Modifier = this
fun Modifier.scale(scale: Float): Modifier = this

// ---------------------------------------------------------------------
