@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.lifecycle


open class ViewModel {
    protected open fun onCleared() {}
}

open class AndroidViewModel(app: android.app.Application) : ViewModel()

val ViewModel.viewModelScope: kotlinx.coroutines.CoroutineScope
    get() = kotlinx.coroutines.MainScope()

// ---------------------------------------------------------------------
