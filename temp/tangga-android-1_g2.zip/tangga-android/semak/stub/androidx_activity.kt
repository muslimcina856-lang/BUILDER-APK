@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.activity


open class ComponentActivity {
    open fun onCreate(savedInstanceState: android.os.Bundle?) {}
}

fun ComponentActivity.enableEdgeToEdge() {}

// ---------------------------------------------------------------------
