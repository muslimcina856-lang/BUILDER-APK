@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.activity.compose


fun androidx.activity.ComponentActivity.setContent(
    content: @androidx.compose.runtime.Composable () -> Unit,
) {}

@androidx.compose.runtime.Composable
fun BackHandler(enabled: Boolean = true, onBack: () -> Unit) {}

// ============================== compose runtime ==============================
