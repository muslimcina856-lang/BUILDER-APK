@file:Suppress("UNUSED_PARAMETER", "unused")

package kotlinx.serialization

import kotlinx.serialization.json.Json


@Retention(AnnotationRetention.RUNTIME)
annotation class Serializable

// ---------------------------------------------------------------------



inline fun <reified T> Json.encodeToString(nilai: T): String = ""

inline fun <reified T> Json.decodeFromString(teks: String): T =
    throw UnsupportedOperationException("stub")


// ============================== tambahan untuk UI kaca ==============================
