@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.animation

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color



interface EnterTransition {
    operator fun plus(o: EnterTransition): EnterTransition = this
}

interface ExitTransition {
    operator fun plus(o: ExitTransition): ExitTransition = this
}

class ContentTransform

infix fun EnterTransition.togetherWith(exit: ExitTransition): ContentTransform = ContentTransform()

fun fadeIn(animationSpec: FiniteAnimationSpec<Float>? = null): EnterTransition = object : EnterTransition {}
fun fadeOut(animationSpec: FiniteAnimationSpec<Float>? = null): ExitTransition = object : ExitTransition {}
fun scaleIn(animationSpec: FiniteAnimationSpec<Float>? = null, initialScale: Float = 0f): EnterTransition = object : EnterTransition {}
fun scaleOut(animationSpec: FiniteAnimationSpec<Float>? = null, targetScale: Float = 0f): ExitTransition = object : ExitTransition {}
fun slideInVertically(
    animationSpec: FiniteAnimationSpec<Int>? = null,
    initialOffsetY: (Int) -> Int = { it },
): EnterTransition = object : EnterTransition {}
fun slideOutVertically(
    animationSpec: FiniteAnimationSpec<Int>? = null,
    targetOffsetY: (Int) -> Int = { it },
): ExitTransition = object : ExitTransition {}
fun expandVertically(animationSpec: FiniteAnimationSpec<Int>? = null): EnterTransition = object : EnterTransition {}
fun shrinkVertically(animationSpec: FiniteAnimationSpec<Int>? = null): ExitTransition = object : ExitTransition {}

interface AnimatedVisibilityScope

@Composable
fun AnimatedVisibility(
    visible: Boolean,
    modifier: Modifier = Modifier,
    enter: EnterTransition = fadeIn(),
    exit: ExitTransition = fadeOut(),
    content: @Composable AnimatedVisibilityScope.() -> Unit,
) {}

interface AnimatedContentScope : AnimatedVisibilityScope

@Composable
fun <S> AnimatedContent(
    targetState: S,
    modifier: Modifier = Modifier,
    transitionSpec: AnimatedContentTransitionScope<S>.() -> ContentTransform = { fadeIn() togetherWith fadeOut() },
    label: String = "",
    content: @Composable AnimatedContentScope.(S) -> Unit,
) {}

interface AnimatedContentTransitionScope<S> {
    val initialState: S
    val targetState: S
}

@Composable
fun animateColorAsState(
    targetValue: Color,
    animationSpec: AnimationSpec<Color>? = null,
    label: String = "",
): State<Color> = object : State<Color> { override val value = targetValue }

fun Modifier.animateContentSize(): Modifier = this

// ---------------------------------------------------------------------
