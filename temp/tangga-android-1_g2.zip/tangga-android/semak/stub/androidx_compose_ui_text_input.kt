@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.text.input

import androidx.compose.ui.text.TextRange



class TextFieldValue(
    val text: String = "",
    val selection: Selection = Selection(),
) {
    class Selection(val min: Int = 0, val max: Int = 0)
    fun copy(text: String = this.text, selection: TextRange? = null): TextFieldValue = this
}

class KeyboardType {
    companion object {
        val Number = KeyboardType()
        val Text = KeyboardType()
    }
}

// ============================== compose foundation ==============================
