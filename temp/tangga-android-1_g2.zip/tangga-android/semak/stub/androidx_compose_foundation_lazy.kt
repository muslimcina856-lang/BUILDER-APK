@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.foundation.lazy

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier



interface LazyItemScope

interface LazyListScope {
    fun item(key: Any? = null, content: @Composable LazyItemScope.() -> Unit)
}

fun <T> LazyListScope.items(
    items: List<T>,
    itemContent: @Composable LazyItemScope.(T) -> Unit,
) {}

fun <T> LazyListScope.itemsIndexed(
    items: List<T>,
    itemContent: @Composable LazyItemScope.(Int, T) -> Unit,
) {}

@Composable
fun LazyColumn(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues? = null,
    verticalArrangement: Arrangement.Horizontal? = null,
    content: LazyListScope.() -> Unit,
) {}

@Composable
fun LazyRow(
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues? = null,
    horizontalArrangement: Arrangement.Horizontal? = null,
    content: LazyListScope.() -> Unit,
) {}

// ---------------------------------------------------------------------
