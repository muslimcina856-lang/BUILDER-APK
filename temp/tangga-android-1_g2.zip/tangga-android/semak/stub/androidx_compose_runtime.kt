@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.runtime


@Target(
    AnnotationTarget.FUNCTION,
    AnnotationTarget.TYPE,
    AnnotationTarget.PROPERTY_GETTER,
    AnnotationTarget.TYPE_PARAMETER,
)
@Retention(AnnotationRetention.BINARY)
annotation class Composable

interface State<out T> {
    val value: T
}

interface MutableState<T> : State<T> {
    override var value: T
}

operator fun <T> State<T>.getValue(thisObj: Any?, property: Any?): T = value
operator fun <T> MutableState<T>.setValue(thisObj: Any?, property: Any?, v: T) { value = v }

fun <T> mutableStateOf(nilai: T): MutableState<T> = object : MutableState<T> {
    override var value: T = nilai
}

@Composable
fun <T> remember(calculation: () -> T): T = calculation()

@Composable
fun <T> remember(key1: Any?, calculation: () -> T): T = calculation()

@Composable
fun <T> kotlinx.coroutines.flow.StateFlow<T>.collectAsState(): State<T> =
    object : State<T> { override val value: T = this@collectAsState.value }

@Composable
fun LaunchedEffect(key1: Any?, block: suspend kotlinx.coroutines.CoroutineScope.() -> Unit) {}

// ============================== compose ui ==============================
