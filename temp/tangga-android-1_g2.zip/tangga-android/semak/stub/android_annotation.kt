@file:Suppress("UNUSED_PARAMETER", "unused")

package android.annotation


@Retention(AnnotationRetention.SOURCE)
annotation class SuppressLint(vararg val value: String)

// ---------------------------------------------------------------------
