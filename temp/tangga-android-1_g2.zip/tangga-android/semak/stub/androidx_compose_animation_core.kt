@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.animation.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.unit.Dp



interface Easing
val LinearEasing: Easing = object : Easing {}

class RepeatMode {
    companion object {
        val Restart = RepeatMode()
        val Reverse = RepeatMode()
    }
}

open class AnimationSpec<T>
class InfiniteRepeatableSpec<T> : AnimationSpec<T>()

fun <T> tween(durationMillis: Int, delayMillis: Int = 0, easing: Easing? = null): FiniteAnimationSpec<T> = FiniteAnimationSpec()

fun <T> infiniteRepeatable(
    animation: AnimationSpec<T>,
    repeatMode: RepeatMode = RepeatMode.Restart,
): InfiniteRepeatableSpec<T> = InfiniteRepeatableSpec()

class InfiniteTransition

@Composable
fun InfiniteTransition.animateFloat(
    initialValue: Float,
    targetValue: Float,
    animationSpec: InfiniteRepeatableSpec<Float>,
    label: String = "",
): State<Float> = object : State<Float> { override val value: Float = initialValue }

@Composable
fun rememberInfiniteTransition(label: String = ""): InfiniteTransition = InfiniteTransition()

// ---------------------------------------------------------------------



open class FiniteAnimationSpec<T> : AnimationSpec<T>()

val FastOutSlowInEasing: Easing = object : Easing {}
val LinearOutSlowInEasing: Easing = object : Easing {}
val EaseOutCubic: Easing = object : Easing {}
val EaseInOutCubic: Easing = object : Easing {}

object Spring {
    const val DampingRatioNoBouncy: Float = 1f
    const val DampingRatioLowBouncy: Float = 0.75f
    const val DampingRatioMediumBouncy: Float = 0.5f
    const val StiffnessLow: Float = 200f
    const val StiffnessMedium: Float = 400f
    const val StiffnessMediumLow: Float = 600f
    const val StiffnessHigh: Float = 1500f
}

fun <T> spring(
    dampingRatio: Float = Spring.DampingRatioNoBouncy,
    stiffness: Float = Spring.StiffnessMedium,
): FiniteAnimationSpec<T> = FiniteAnimationSpec()


@Composable
fun animateFloatAsState(
    targetValue: Float,
    animationSpec: AnimationSpec<Float>? = null,
    label: String = "",
): State<Float> = object : State<Float> { override val value = targetValue }

@Composable
fun animateDpAsState(
    targetValue: Dp,
    animationSpec: AnimationSpec<Dp>? = null,
    label: String = "",
): State<Dp> = object : State<Dp> { override val value = targetValue }


// ============================== semakan penyedia WebView ==============================
