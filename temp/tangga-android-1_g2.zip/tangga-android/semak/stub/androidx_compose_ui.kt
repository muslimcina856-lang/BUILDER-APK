@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui


interface Modifier {
    fun then(other: Modifier): Modifier = this
    companion object : Modifier
}

class Alignment {
    companion object {
        val Center = Alignment()
        val CenterVertically = Alignment()
        val CenterHorizontally = Alignment()
        val Top = Alignment()
    }
}

// ---------------------------------------------------------------------
