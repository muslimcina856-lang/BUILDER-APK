@file:Suppress("UNUSED_PARAMETER", "unused")

package android.os


open class Bundle

// ---------------------------------------------------------------------


object Build {
    object VERSION { @JvmStatic val SDK_INT: Int = 34 }
    object VERSION_CODES { const val S: Int = 31 }
}

// ---------------------------------------------------------------------
