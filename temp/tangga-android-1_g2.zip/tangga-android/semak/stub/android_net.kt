@file:Suppress("UNUSED_PARAMETER", "unused")

package android.net


class Uri

// ---------------------------------------------------------------------
