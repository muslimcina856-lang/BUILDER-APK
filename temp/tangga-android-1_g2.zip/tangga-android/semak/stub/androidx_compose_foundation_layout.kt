@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.foundation.layout

import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp



class PaddingValues(all: Dp = 0.dp)

class IntrinsicSize {
    companion object {
        val Min = IntrinsicSize()
        val Max = IntrinsicSize()
    }
}

object Arrangement {
    class Horizontal
    class Vertical
    fun spacedBy(space: Dp): Horizontal = Horizontal()
    fun spacedBy(space: Dp, alignment: Alignment): Horizontal = Horizontal()
    val Center = Horizontal()
}

@RequiresOptIn
@Retention(AnnotationRetention.BINARY)
annotation class ExperimentalLayoutApi

fun Modifier.fillMaxSize(): Modifier = this
fun Modifier.fillMaxWidth(fraction: Float = 1f): Modifier = this
fun Modifier.fillMaxHeight(fraction: Float = 1f): Modifier = this
fun Modifier.padding(all: Dp): Modifier = this
fun Modifier.padding(horizontal: Dp = 0.dp, vertical: Dp = 0.dp): Modifier = this
fun Modifier.padding(start: Dp = 0.dp, top: Dp = 0.dp, end: Dp = 0.dp, bottom: Dp = 0.dp): Modifier = this
fun Modifier.height(h: Dp): Modifier = this
fun Modifier.height(h: IntrinsicSize): Modifier = this
fun Modifier.width(w: Dp): Modifier = this
fun Modifier.size(s: Dp): Modifier = this
fun Modifier.heightIn(min: Dp = 0.dp, max: Dp = 0.dp): Modifier = this
fun Modifier.widthIn(min: Dp = 0.dp, max: Dp = 0.dp): Modifier = this
fun Modifier.offset(x: Dp = 0.dp, y: Dp = 0.dp): Modifier = this
fun Modifier.systemBarsPadding(): Modifier = this

interface ColumnScope {
    fun Modifier.weight(w: Float): Modifier = this
}

interface RowScope {
    fun Modifier.weight(w: Float): Modifier = this
}

interface BoxScope

interface BoxWithConstraintsScope : BoxScope {
    val maxWidth: Dp
    val maxHeight: Dp
}

@Composable
fun Column(
    modifier: Modifier = Modifier,
    verticalArrangement: Arrangement.Horizontal? = null,
    horizontalAlignment: Alignment? = null,
    content: @Composable ColumnScope.() -> Unit,
) {}

@Composable
fun Row(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal? = null,
    verticalAlignment: Alignment? = null,
    content: @Composable RowScope.() -> Unit,
) {}

@Composable
fun Box(
    modifier: Modifier = Modifier,
    contentAlignment: Alignment? = null,
    content: @Composable BoxScope.() -> Unit = {},
) {}

@Composable
fun BoxWithConstraints(
    modifier: Modifier = Modifier,
    content: @Composable BoxWithConstraintsScope.() -> Unit,
) {}

@Composable
fun Spacer(modifier: Modifier) {}

@ExperimentalLayoutApi
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal? = null,
    verticalArrangement: Arrangement.Horizontal? = null,
    content: @Composable RowScope.() -> Unit,
) {}

// ---------------------------------------------------------------------
