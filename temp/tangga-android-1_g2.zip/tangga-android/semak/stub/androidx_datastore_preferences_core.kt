@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.datastore.preferences.core


class Preferences {
    operator fun <T> get(kunci: Kunci<T>): T? = null
}

class Kunci<T>(val nama: String)

class MutablePreferences {
    operator fun <T> set(kunci: Kunci<T>, nilai: T) {}
}

fun stringPreferencesKey(nama: String): Kunci<String> = Kunci(nama)

suspend fun androidx.datastore.core.DataStore<Preferences>.edit(
    transform: suspend (MutablePreferences) -> Unit,
): Preferences {
    transform(MutablePreferences())
    return Preferences()
}

// ---------------------------------------------------------------------
