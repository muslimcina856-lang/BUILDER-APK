@file:Suppress("UNUSED_PARAMETER", "unused")

package android.content.pm


class PackageInfo {
    var packageName: String = ""
    var versionName: String? = null
}

// ---------------------------------------------------------------------
