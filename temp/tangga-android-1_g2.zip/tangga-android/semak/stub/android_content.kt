@file:Suppress("UNUSED_PARAMETER", "unused")

package android.content


open class Context {
    val assets: AssetManager = AssetManager()
}

class AssetManager {
    fun open(nama: String): java.io.InputStream = java.io.ByteArrayInputStream(ByteArray(0))
    // Android sebenar: list(String): Array<String>? — null bila laluan bukan direktori.
    fun list(laluan: String): Array<String>? = emptyArray()
}

// ---------------------------------------------------------------------
