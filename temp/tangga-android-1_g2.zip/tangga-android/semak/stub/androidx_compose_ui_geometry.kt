@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.geometry


class Offset(val x: Float, val y: Float) {
    companion object {
        val Zero = Offset(0f, 0f)
        val Infinite = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
        val Unspecified = Offset(Float.NaN, Float.NaN)
    }
}

class Size(val width: Float, val height: Float)

// ---------------------------------------------------------------------
