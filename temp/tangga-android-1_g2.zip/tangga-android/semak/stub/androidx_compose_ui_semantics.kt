@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.semantics


class Role {
    companion object {
        val Button = Role()
        val Checkbox = Role()
        val Tab = Role()
    }
}

fun androidx.compose.ui.Modifier.semantics(
    mergeDescendants: Boolean = false,
    properties: Any.() -> Unit,
): androidx.compose.ui.Modifier = this

