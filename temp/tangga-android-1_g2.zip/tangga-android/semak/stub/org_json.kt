@file:Suppress("UNUSED_PARAMETER", "unused")

package org.json


class JSONObject {
    companion object {
        fun quote(s: String): String = "\"" + s + "\""
    }
}

// ============================== androidx.activity ==============================
