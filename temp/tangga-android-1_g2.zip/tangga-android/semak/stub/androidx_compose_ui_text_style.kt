@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.text.style


class TextOverflow {
    companion object {
        val Ellipsis = TextOverflow()
        val Clip = TextOverflow()
    }
}

// ---------------------------------------------------------------------
