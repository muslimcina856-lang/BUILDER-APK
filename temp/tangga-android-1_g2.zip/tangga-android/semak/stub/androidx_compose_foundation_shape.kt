@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.foundation.shape

import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp



class RoundedCornerShapeImpl : Shape

fun RoundedCornerShape(size: Dp): Shape = RoundedCornerShapeImpl()
fun RoundedCornerShape(percent: Int): Shape = RoundedCornerShapeImpl()
fun RoundedCornerShape(
    topStart: Dp = 0.dp,
    topEnd: Dp = 0.dp,
    bottomEnd: Dp = 0.dp,
    bottomStart: Dp = 0.dp,
): Shape = RoundedCornerShapeImpl()

val CircleShape: Shape = RoundedCornerShapeImpl()

// ---------------------------------------------------------------------
