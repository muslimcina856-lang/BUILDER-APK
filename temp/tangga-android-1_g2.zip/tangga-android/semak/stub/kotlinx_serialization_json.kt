@file:Suppress("UNUSED_PARAMETER", "unused")

package kotlinx.serialization.json


class Json {
    companion object
}

fun Json(builder: JsonBuilder.() -> Unit = {}): Json {
    JsonBuilder().builder()
    return Json()
}

class JsonBuilder {
    var ignoreUnknownKeys: Boolean = false
}

// ---------------------------------------------------------------------
