@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.material3

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp



class ColorScheme

fun darkColorScheme(
    primary: Color? = null,
    background: Color? = null,
    surface: Color? = null,
    onBackground: Color? = null,
    onSurface: Color? = null,
    error: Color? = null,
): ColorScheme = ColorScheme()

object MaterialTheme

class CompositionLocalTextStyle {
    val current: TextStyle get() = TextStyle()
}

val LocalTextStyle = CompositionLocalTextStyle()

@Composable
fun MaterialTheme(colorScheme: ColorScheme, content: @Composable () -> Unit) {}

@Composable
fun Surface(
    modifier: Modifier = Modifier,
    color: Color? = null,
    content: @Composable () -> Unit,
) {}

@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color? = null,
    fontSize: TextUnit? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit? = null,
    lineHeight: TextUnit? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow? = null,
) {}

@Composable
fun Text(
    text: AnnotatedString,
    modifier: Modifier = Modifier,
    color: Color? = null,
    fontSize: TextUnit? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit? = null,
    lineHeight: TextUnit? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow? = null,
) {}

// ============================== androidx.lifecycle ==============================
