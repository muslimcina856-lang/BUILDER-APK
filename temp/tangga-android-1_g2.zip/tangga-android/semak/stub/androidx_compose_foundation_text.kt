@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.foundation.text

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue



class KeyboardOptions(val keyboardType: KeyboardType? = null)

@Composable
fun BasicTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    singleLine: Boolean = false,
    keyboardOptions: KeyboardOptions? = null,
    textStyle: TextStyle = TextStyle(),
    cursorBrush: Brush? = null,
    decorationBox: @Composable (@Composable () -> Unit) -> Unit = { it() },
) {}

@Composable
fun BasicTextField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier,
    singleLine: Boolean = false,
    keyboardOptions: KeyboardOptions? = null,
    textStyle: TextStyle = TextStyle(),
    cursorBrush: Brush? = null,
    decorationBox: @Composable (@Composable () -> Unit) -> Unit = { it() },
) {}

// ---------------------------------------------------------------------
