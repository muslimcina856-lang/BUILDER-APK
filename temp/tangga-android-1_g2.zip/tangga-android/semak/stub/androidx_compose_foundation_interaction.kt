@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.foundation.interaction

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State



interface Interaction
interface InteractionSource
interface MutableInteractionSource : InteractionSource

fun MutableInteractionSource(): MutableInteractionSource = object : MutableInteractionSource {}

@Composable
fun InteractionSource.collectIsPressedAsState(): State<Boolean> =
    object : State<Boolean> { override val value = false }

// ---------------------------------------------------------------------
