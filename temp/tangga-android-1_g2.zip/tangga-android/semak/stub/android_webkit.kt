@file:Suppress("UNUSED_PARAMETER", "unused")

package android.webkit


@Retention(AnnotationRetention.RUNTIME)
annotation class JavascriptInterface

class WebSettings {
    var javaScriptEnabled: Boolean = false
    var domStorageEnabled: Boolean = false
    var allowFileAccess: Boolean = true
    var allowContentAccess: Boolean = true
    var cacheMode: Int = 0
    var blockNetworkLoads: Boolean = false

    companion object {
        const val LOAD_NO_CACHE: Int = 2
    }
}

class WebResourceRequest {
    val url: android.net.Uri = android.net.Uri()
}

class WebResourceResponse

open class WebViewClient {
    open fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? = null
    open fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean = false
    open fun onPageFinished(v: WebView, url: String) {}
}

class WebView(konteks: android.content.Context) {
    val settings: WebSettings = WebSettings()
    var webViewClient: WebViewClient = WebViewClient()
    fun addJavascriptInterface(objek: Any, nama: String) {}
    fun evaluateJavascript(skrip: String, balasan: ((String) -> Unit)?) {}
    fun loadUrl(url: String) {}
    fun loadDataWithBaseURL(
        baseUrl: String?, data: String, mimeType: String?,
        encoding: String?, historyUrl: String?,
    ) {}
    fun destroy() {}
}

// ============================== org.json ==============================
