@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.compose.ui.unit


class Dp(val nilai: Float) {
    operator fun times(f: Float): Dp = Dp(nilai * f)
    operator fun div(f: Float): Dp = Dp(nilai / f)
    operator fun plus(o: Dp): Dp = Dp(nilai + o.nilai)
}

class TextUnit(val nilai: Float)

val Int.dp: Dp get() = Dp(this.toFloat())
val Double.dp: Dp get() = Dp(this.toFloat())
val Float.dp: Dp get() = Dp(this)
val Int.sp: TextUnit get() = TextUnit(this.toFloat())
val Double.sp: TextUnit get() = TextUnit(this.toFloat())
val Float.sp: TextUnit get() = TextUnit(this)

// ---------------------------------------------------------------------
