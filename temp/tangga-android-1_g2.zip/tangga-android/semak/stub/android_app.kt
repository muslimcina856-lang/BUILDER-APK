@file:Suppress("UNUSED_PARAMETER", "unused")

package android.app


open class Application : android.content.Context()

// ---------------------------------------------------------------------
