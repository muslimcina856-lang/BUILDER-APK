@file:Suppress("UNUSED_PARAMETER", "unused")

package androidx.lifecycle.viewmodel.compose


@androidx.compose.runtime.Composable
inline fun <reified T : androidx.lifecycle.ViewModel> viewModel(): T =
    throw UnsupportedOperationException("stub")

// ============================== androidx.datastore ==============================
