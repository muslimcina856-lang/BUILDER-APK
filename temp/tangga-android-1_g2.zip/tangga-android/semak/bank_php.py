# -*- coding: utf-8 -*-
"""
Bank tugasan PHP untuk Tangga.

Disahkan dengan PHP 8.3 CLI, versi major.minor yang sama dengan php_8_3.wasm
yang dihantar dalam APK.

Semua kod berjalan dengan `declare(strict_types=1)`. PHP moden hampir tidak
serupa dengan PHP yang diajar dalam kebanyakan tutorial lama, dan penukaran
jenis longgar ialah punca sebahagian besar pepijat pengeluaran.
"""

BANK_PHP = [

    # ==================== P1 — ASAS PHP ====================
    {
        "bab": 1, "jenis": "tulis", "fn": "luas",
        "tajuk": "Fungsi pertama",
        "brief": "Tulis `luas(float $p, float $l): float` yang pulangkan luas segi empat tepat.\n\nPembolehubah PHP bermula dengan `$`. Pengisytiharan jenis dikuatkuasakan kerana kita jalankan dengan `strict_types=1`.",
        "starter": "function luas(float $p, float $l): float {\n    // tulis di sini\n}",
        "kes": [{"args": [3, 4], "jangka": 12}, {"args": [0, 9], "jangka": 0}, {"args": [2.5, 4], "jangka": 10}],
        "petunjuk": ["Jenis ditulis sebelum nama parameter: `float $p`.",
                     "`return $p * $l;`"],
        "jawapan": "function luas(float $p, float $l): float {\n    return $p * $l;\n}",
    },
    {
        "bab": 1, "jenis": "tulis", "fn": "sapa",
        "tajuk": "Interpolasi string",
        "brief": "Tulis `sapa(string $nama, int $umur): string` yang pulangkan `\"<nama> berumur <umur> tahun\"`.\n\nPetikan berganda menginterpolasi pembolehubah; petikan tunggal tidak.",
        "starter": "function sapa(string $nama, int $umur): string {\n\n}",
        "kes": [{"args": ["Aina", 9], "jangka": "Aina berumur 9 tahun"},
                {"args": ["Kumar", 40], "jangka": "Kumar berumur 40 tahun"}],
        "petunjuk": ["`\"$nama berumur $umur tahun\"` berfungsi terus.",
                     "Guna `{$nama}` bila sempadan pembolehubah tidak jelas."],
        "jawapan": "function sapa(string $nama, int $umur): string {\n    return \"$nama berumur $umur tahun\";\n}",
    },
    {
        "bab": 1, "jenis": "baiki", "fn": "keSen",
        "tajuk": "Jenis pulangan yang salah",
        "brief": "`keSen` mengisytiharkan `: int` tetapi memulangkan float. Dengan `strict_types=1` PHP membaling TypeError. Baiki supaya ia benar-benar pulangkan integer sen.",
        "starter": "function keSen(float $ringgit): int {\n    return $ringgit * 100;\n}",
        "kes": [{"args": [19.99], "jangka": 1999}, {"args": [0], "jangka": 0}, {"args": [5.5], "jangka": 550}],
        "petunjuk": ["`$ringgit * 100` menghasilkan float walaupun hasilnya bulat.",
                     "`(int) round($ringgit * 100)` menukarnya dengan betul."],
        "jawapan": "function keSen(float $ringgit): int {\n    return (int) round($ringgit * 100);\n}",
    },
    {
        "bab": 1, "jenis": "pilih",
        "tajuk": "Dua muka kesamaan",
        "soalan": "Dalam PHP, apa yang `0 == \"abc\"` hasilkan pada PHP 8?",
        "pilihan": ["false — PHP 8 menukar nombor kepada string, bukan sebaliknya",
                    "true — string ditukar kepada 0",
                    "Ralat jenis",
                    "null"],
        "betul": 0,
        "huraian": "Sebelum PHP 8, `0 == \"abc\"` adalah `true` kerana `\"abc\"` ditukar kepada `0`. Itu menyebabkan pepijat pengesahan sebenar selama bertahun-tahun. PHP 8 membalikkan arah penukaran. Walaupun begitu, guna `===` melainkan kau benar-benar mahu penukaran jenis.",
    },

    # ==================== P2 — ARRAY ====================
    {
        "bab": 2, "jenis": "tulis", "fn": "jumlah",
        "tajuk": "Array berindeks",
        "brief": "Tulis `jumlah(array $nombor): float` yang jumlahkan array. Kosong pulangkan 0.",
        "starter": "function jumlah(array $nombor): float {\n\n}",
        "kes": [{"args": [[1, 2, 3]], "jangka": 6}, {"args": [[]], "jangka": 0}, {"args": [[-1, 1]], "jangka": 0}],
        "petunjuk": ["`array_sum` melakukannya dalam satu panggilan.",
                     "Jenis pulangan `float` bermakna kau perlu hantar `(float)` pada hasil integer."],
        "jawapan": "function jumlah(array $nombor): float {\n    return (float) array_sum($nombor);\n}",
    },
    {
        "bab": 2, "jenis": "tulis", "fn": "tapisGenap",
        "tajuk": "array_values selepas menapis",
        "brief": "Tulis `tapisGenap(array $t): array` yang pulangkan nombor genap sahaja.\n\nPenting: `array_filter` **mengekalkan kunci asal**, jadi kau akan dapat lubang. Indeks mesti dinomborkan semula 0, 1, 2.",
        "starter": "function tapisGenap(array $t): array {\n\n}",
        "kes": [{"args": [[1, 2, 3, 4]], "jangka": [2, 4]}, {"args": [[]], "jangka": []},
                {"args": [[1, 3]], "jangka": []}, {"args": [[2, 4, 6]], "jangka": [2, 4, 6]}],
        "syarat": [{"corak": r"array_values", "mesej": "Guna `array_values` untuk menomborkan semula kunci."}],
        "petunjuk": ["Tanpa `array_values`, `[1,2,3,4]` menghasilkan `[1=>2, 3=>4]` bukan `[2,4]`.",
                     "`array_values(array_filter($t, fn($v) => $v % 2 === 0))`"],
        "jawapan": "function tapisGenap(array $t): array {\n    return array_values(array_filter($t, fn($v) => $v % 2 === 0));\n}",
    },
    {
        "bab": 2, "jenis": "tulis", "fn": "kiraKekerapan",
        "tajuk": "Array bersekutu",
        "brief": "Tulis `kiraKekerapan(array $t): array` yang pulangkan peta nilai kepada bilangan kemunculannya.\n\nArray PHP ialah peta hash tersusun — satu jenis untuk senarai dan kamus.",
        "starter": "function kiraKekerapan(array $t): array {\n\n}",
        "kes": [{"args": [["a", "b", "a"]], "jangka": {"a": 2, "b": 1}},
                {"args": [[]], "jangka": {}}],
        "petunjuk": ["`array_count_values` melakukannya, tetapi cuba tulis gelung dahulu.",
                     "`$kira[$v] = ($kira[$v] ?? 0) + 1;` mengendalikan kunci yang belum wujud."],
        "jawapan": ("function kiraKekerapan(array $t): array {\n    $kira = [];\n"
                    "    foreach ($t as $v) {\n        $kira[$v] = ($kira[$v] ?? 0) + 1;\n    }\n    return $kira;\n}"),
    },
    {
        "bab": 2, "jenis": "tulis", "fn": "kunciTersusun",
        "tajuk": "Isih mengekalkan kunci",
        "brief": "Tulis `kunciTersusun(array $peta): array` yang pulangkan kunci array bersekutu, tersusun menaik.",
        "starter": "function kunciTersusun(array $peta): array {\n\n}",
        "kes": [{"args": [{"b": 1, "a": 2, "c": 3}], "jangka": ["a", "b", "c"]},
                {"args": [{}], "jangka": []}],
        "petunjuk": ["`array_keys` memberi kunci sebagai array berindeks.",
                     "`sort` mengubah di tempatnya dan pulangkan bool, bukan array."],
        "jawapan": ("function kunciTersusun(array $peta): array {\n    $k = array_keys($peta);\n"
                    "    sort($k);\n    return $k;\n}"),
    },
    {
        "bab": 2, "jenis": "ramal",
        "tajuk": "Array dihantar mengikut nilai",
        "kod": "<?php\nfunction ubah(array $a): void { $a[] = 99; }\n$x = [1, 2];\nubah($x);\necho count($x);",
        "output": "2",
        "brief": "Apa yang dicetak?",
        "petunjuk": ["Array PHP dihantar mengikut nilai, bukan rujukan — berbeza daripada objek.",
                     "Untuk mengubah pemanggil, kau perlu `&$a` secara eksplisit."],
    },

    # ==================== P3 — STRING ====================
    {
        "bab": 3, "jenis": "tulis", "fn": "besarkan",
        "tajuk": "Fungsi string",
        "brief": "Tulis `besarkan(string $s): string` yang besarkan huruf pertama dan kecilkan yang lain. Kosong → kosong.",
        "starter": "function besarkan(string $s): string {\n\n}",
        "kes": [{"args": ["ali"], "jangka": "Ali"}, {"args": [""], "jangka": ""},
                {"args": ["aBC"], "jangka": "Abc"}],
        "petunjuk": ["`ucfirst(strtolower($s))` melakukan kedua-duanya.",
                     "`ucfirst` pada string kosong pulangkan string kosong dengan selamat."],
        "jawapan": "function besarkan(string $s): string {\n    return ucfirst(strtolower($s));\n}",
    },
    {
        "bab": 3, "jenis": "tulis", "fn": "potong",
        "tajuk": "Potong dengan elipsis",
        "brief": "Tulis `potong(string $s, int $had): string`. Jika panjang melebihi `$had`, potong kepada `$had` aksara dan tambah `\"...\"`. Kalau tidak pulangkan seadanya.\n\nGuna `strlen` dan `substr` — bab ini kekal ASCII dengan sengaja. Soalan seterusnya menerangkan sebabnya itu penting.",
        "starter": "function potong(string $s, int $had): string {\n\n}",
        "kes": [{"args": ["selamat pagi", 7], "jangka": "selamat..."},
                {"args": ["pendek", 10], "jangka": "pendek"},
                {"args": ["tepat", 5], "jangka": "tepat"},
                {"args": ["", 3], "jangka": ""}],
        "petunjuk": ["`strlen($s)` memberi panjang; bandingkan dengan `$had` dahulu.",
                     "`substr($s, 0, $had) . \"...\"` memotong dan menambah elipsis."],
        "jawapan": ("function potong(string $s, int $had): string {\n"
                    "    if (strlen($s) <= $had) {\n        return $s;\n    }\n"
                    "    return substr($s, 0, $had) . \"...\";\n}"),
    },
    {
        "bab": 3, "jenis": "tulis", "fn": "kiraPerkataan",
        "tajuk": "Pecah dan tapis",
        "brief": "Tulis `kiraPerkataan(string $s): int` yang kira perkataan. Ruang berlebihan tidak dikira.",
        "starter": "function kiraPerkataan(string $s): int {\n\n}",
        "kes": [{"args": ["satu dua tiga"], "jangka": 3}, {"args": ["  ruang  banyak  "], "jangka": 2},
                {"args": [""], "jangka": 0}, {"args": ["   "], "jangka": 0}],
        "petunjuk": ["`preg_split('/\\s+/', trim($s))` memecah pada mana-mana kumpulan ruang.",
                     "String kosong selepas trim masih menghasilkan satu elemen kosong — tapis ia."],
        "jawapan": ("function kiraPerkataan(string $s): int {\n    $s = trim($s);\n"
                    "    if ($s === \"\") {\n        return 0;\n    }\n"
                    "    return count(preg_split('/\\s+/', $s));\n}"),
    },
    {
        "bab": 3, "jenis": "pilih",
        "tajuk": "Bait bukan aksara",
        "soalan": "`strlen(\"café\")` memberi 5, bukan 4. Kenapa, dan apa akibatnya jika kau memotong pada aksara ke-4?",
        "pilihan": ["`strlen` mengira bait, dan é ialah dua bait dalam UTF-8 \u2014 memotong di tengahnya menghasilkan aksara rosak",
                    "PHP mengira ruang tersembunyi",
                    "`strlen` sentiasa menambah satu",
                    "Ia pepijat dalam PHP 8"],
        "betul": 0,
        "huraian": "Fungsi string PHP beroperasi pada bait secara lalai. Untuk teks yang mengandungi tanda aksen, aksara Cina atau emoji, kau memerlukan keluarga `mb_*` daripada sambungan mbstring, yang mengira aksara sebenar. Semak `function_exists(\'mb_strlen\')` \u2014 mbstring tidak dipasang di setiap tempat, termasuk sesetengah binaan WebAssembly.",
    },
    {
        "bab": 3, "jenis": "pilih",
        "tajuk": "Sambung dengan titik",
        "soalan": "Kenapa PHP guna `.` untuk menyambung string dan bukan `+`?",
        "pilihan": ["Kerana `+` sudah bermaksud tambah nombor, dan PHP menukar string kepada nombor",
                    "Kerana `.` lebih pantas",
                    "Sejarah sahaja, tiada sebab teknikal",
                    "Kerana `+` untuk array"],
        "betul": 0,
        "huraian": "Dalam bahasa dengan penukaran jenis longgar, `\"5\" + \"5\"` mesti memberi `10` bukan `\"55\"`. Pengendali berasingan menghilangkan kekaburan itu. Nota sampingan: `+` pada dua array dalam PHP melakukan kesatuan, bukan gabungan — perangkap yang berasingan.",
    },

    # ==================== P4 — ALIRAN KAWALAN ====================
    {
        "bab": 4, "jenis": "tulis", "fn": "gred",
        "tajuk": "match",
        "brief": "Tulis `gred(int $markah): string`:\n80 ke atas → `\"A\"`, 65-79 → `\"B\"`, 50-64 → `\"C\"`, bawah 50 → `\"G\"`.\n\nCuba guna `match(true)` — ia lebih ketat daripada `switch` dan tiada fall-through.",
        "starter": "function gred(int $markah): string {\n\n}",
        "kes": [{"args": [95], "jangka": "A"}, {"args": [80], "jangka": "A"}, {"args": [79], "jangka": "B"},
                {"args": [65], "jangka": "B"}, {"args": [50], "jangka": "C"}, {"args": [49], "jangka": "G"}],
        "petunjuk": ["`match(true) { $markah >= 80 => \"A\", ... }` menilai setiap syarat.",
                     "`match` membandingkan dengan `===` dan membaling jika tiada padanan — jadi sertakan `default`."],
        "jawapan": ("function gred(int $markah): string {\n    return match (true) {\n"
                    "        $markah >= 80 => \"A\",\n        $markah >= 65 => \"B\",\n"
                    "        $markah >= 50 => \"C\",\n        default => \"G\",\n    };\n}"),
    },
    {
        "bab": 4, "jenis": "tulis", "fn": "sifir",
        "tajuk": "Gelung for",
        "brief": "Tulis `sifir(int $n): array` yang pulangkan `[n*1, n*2, ..., n*10]`.",
        "starter": "function sifir(int $n): array {\n\n}",
        "kes": [{"args": [3], "jangka": [3, 6, 9, 12, 15, 18, 21, 24, 27, 30]},
                {"args": [1], "jangka": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}],
        "petunjuk": ["`for ($i = 1; $i <= 10; $i++)`",
                     "`$hasil[] = $n * $i;` menambah ke hujung array."],
        "jawapan": ("function sifir(int $n): array {\n    $hasil = [];\n"
                    "    for ($i = 1; $i <= 10; $i++) {\n        $hasil[] = $n * $i;\n    }\n    return $hasil;\n}"),
    },
    {
        "bab": 4, "jenis": "tulis", "fn": "kumpulIkut",
        "tajuk": "foreach dengan kunci",
        "brief": "Tulis `kumpulIkut(array $senarai, string $kunci): array` yang kumpulkan array bersekutu mengikut nilai medan `$kunci`.",
        "starter": "function kumpulIkut(array $senarai, string $kunci): array {\n\n}",
        "kes": [{"args": [[{"j": "a", "n": 1}, {"j": "b", "n": 2}, {"j": "a", "n": 3}], "j"],
                 "jangka": {"a": [{"j": "a", "n": 1}, {"j": "a", "n": 3}], "b": [{"j": "b", "n": 2}]}},
                {"args": [[], "j"], "jangka": {}}],
        "petunjuk": ["`foreach ($senarai as $item)` melelar nilai.",
                     "`$hasil[$k][] = $item;` mencipta array dalaman secara automatik jika belum wujud."],
        "jawapan": ("function kumpulIkut(array $senarai, string $kunci): array {\n    $hasil = [];\n"
                    "    foreach ($senarai as $item) {\n        $hasil[$item[$kunci]][] = $item;\n    }\n"
                    "    return $hasil;\n}"),
    },
    {
        "bab": 4, "jenis": "ramal",
        "tajuk": "foreach mengikut rujukan",
        "kod": "<?php\n$a = [1, 2, 3];\nforeach ($a as &$v) { $v *= 2; }\nunset($v);\necho implode(\",\", $a);",
        "output": "2,4,6",
        "brief": "Apa yang dicetak?",
        "petunjuk": ["`&$v` menjadikan gelung mengubah array asal.",
                     "`unset($v)` selepas gelung adalah wajib — tanpanya gelung seterusnya akan merosakkan elemen terakhir."],
    },

    # ==================== P5 — FUNGSI ====================
    {
        "bab": 5, "jenis": "tulis", "fn": "sapaLalai",
        "tajuk": "Parameter lalai dan nullable",
        "brief": "Tulis `sapaLalai(string $nama, ?string $salam = null): string`. Jika `$salam` null, guna `\"Hai\"`. Pulangkan `\"<salam>, <nama>!\"`.",
        "starter": "function sapaLalai(string $nama, ?string $salam = null): string {\n\n}",
        "kes": [{"args": ["Ali"], "jangka": "Hai, Ali!"},
                {"args": ["Ali", "Selamat pagi"], "jangka": "Selamat pagi, Ali!"}],
        "petunjuk": ["`?string` bermaksud string atau null.",
                     "`$salam ?? \"Hai\"` menggantikan hanya null, bukan string kosong."],
        "jawapan": ("function sapaLalai(string $nama, ?string $salam = null): string {\n"
                    "    $s = $salam ?? \"Hai\";\n    return \"$s, $nama!\";\n}"),
    },
    {
        "bab": 5, "jenis": "tulis", "fn": "jumlahSemua",
        "tajuk": "Parameter variadic",
        "brief": "Tulis `jumlahSemua(float ...$nombor): float` yang jumlahkan sebarang bilangan hujah. Tanpa hujah → 0.",
        "starter": "function jumlahSemua(float ...$nombor): float {\n\n}",
        "kes": [{"args": [1, 2, 3], "jangka": 6}, {"args": [], "jangka": 0}, {"args": [5], "jangka": 5}],
        "petunjuk": ["`...$nombor` mengumpul semua hujah menjadi array.",
                     "Jenis sebelum `...` menguatkuasakan jenis setiap hujah."],
        "jawapan": "function jumlahSemua(float ...$nombor): float {\n    return (float) array_sum($nombor);\n}",
    },
    {
        "bab": 5, "jenis": "tulis", "fn": "guna",
        "tajuk": "Fungsi sebagai nilai",
        "brief": "Tulis `guna(callable $fn, int $kali): array` yang panggil `$fn($i)` untuk `$i` dari 0 hingga `$kali-1`.",
        "starter": "function guna(callable $fn, int $kali): array {\n\n}",
        "kes": [{"args": ["__FN__:fn($i) => $i * 2", 3], "jangka": [0, 2, 4]},
                {"args": ["__FN__:fn($i) => $i", 0], "jangka": []}],
        "petunjuk": ["`callable` menerima fungsi anak panah, closure dan nama fungsi.",
                     "`fn($x) => ...` ialah singkatan; ia menangkap skop luar secara automatik."],
        "jawapan": ("function guna(callable $fn, int $kali): array {\n    $hasil = [];\n"
                    "    for ($i = 0; $i < $kali; $i++) {\n        $hasil[] = $fn($i);\n    }\n    return $hasil;\n}"),
    },
    {
        "bab": 5, "jenis": "pilih",
        "tajuk": "fn berbanding function",
        "soalan": "Apa beza `fn($x) => $x + $luar` dan `function($x) { return $x + $luar; }`?",
        "pilihan": ["`fn` menangkap `$luar` secara automatik; `function` memerlukan `use ($luar)`",
                    "Tiada beza",
                    "`fn` lebih pantas",
                    "`fn` tidak boleh menerima parameter"],
        "betul": 0,
        "huraian": "Closure PHP tidak menangkap skop sekeliling secara automatik seperti JavaScript — kau mesti menyenaraikan apa yang kau mahu dengan `use`. Fungsi anak panah yang diperkenalkan dalam PHP 7.4 menangkap mengikut nilai secara automatik, itulah sebabnya ia jauh lebih ringkas untuk callback satu baris.",
    },

    # ==================== P6 — OBJEK & KELAS ====================
    {
        "bab": 6, "jenis": "tulis", "fn": "gunaAkaun",
        "tajuk": "Kelas dengan promosi pembina",
        "brief": "Cipta kelas `Akaun` dengan sifat peribadi `float $baki` yang dimulakan 0, kaedah `deposit(float $n): void` dan `baki(): float`.\n\nKemudian tulis `gunaAkaun(float $jumlah): float` yang cipta akaun, deposit, dan pulangkan baki.",
        "starter": "class Akaun {\n\n}\n\nfunction gunaAkaun(float $jumlah): float {\n\n}",
        "kes": [{"args": [100], "jangka": 100}, {"args": [0], "jangka": 0}, {"args": [50], "jangka": 50}],
        "petunjuk": ["`private float $baki = 0;` mengisytiharkan sifat bertaip dengan lalai.",
                     "`$a = new Akaun(); $a->deposit($jumlah); return $a->baki();`"],
        "jawapan": ("class Akaun {\n    private float $baki = 0;\n\n"
                    "    public function deposit(float $n): void {\n        $this->baki += $n;\n    }\n\n"
                    "    public function baki(): float {\n        return $this->baki;\n    }\n}\n\n"
                    "function gunaAkaun(float $jumlah): float {\n    $a = new Akaun();\n"
                    "    $a->deposit($jumlah);\n    return $a->baki();\n}"),
    },
    {
        "bab": 6, "jenis": "tulis", "fn": "namaPenuh",
        "tajuk": "Promosi sifat pembina",
        "brief": "Cipta kelas `Orang` yang menggunakan **promosi sifat pembina** untuk `string $depan` dan `string $belakang`, dengan kaedah `penuh(): string`.\n\nTulis `namaPenuh(string $d, string $b): string` yang gunakannya.",
        "starter": "class Orang {\n\n}\n\nfunction namaPenuh(string $d, string $b): string {\n\n}",
        "kes": [{"args": ["Nur", "Aina"], "jangka": "Nur Aina"}, {"args": ["A", "B"], "jangka": "A B"}],
        "syarat": [{"corak": r"__construct\s*\(\s*(public|private|protected)",
                    "mesej": "Guna promosi sifat pembina: `__construct(public string $depan, ...)`."}],
        "petunjuk": ["Promosi mengisytiharkan dan menetapkan sifat dalam satu langkah.",
                     "`public function __construct(public string $depan, public string $belakang) {}`"],
        "jawapan": ("class Orang {\n"
                    "    public function __construct(\n        public string $depan,\n"
                    "        public string $belakang,\n    ) {}\n\n"
                    "    public function penuh(): string {\n        return \"$this->depan $this->belakang\";\n    }\n}\n\n"
                    "function namaPenuh(string $d, string $b): string {\n"
                    "    return (new Orang($d, $b))->penuh();\n}"),
    },
    {
        "bab": 6, "jenis": "tulis", "fn": "labelStatus",
        "tajuk": "Enum",
        "brief": "Cipta enum bersandar `Status: string` dengan kes `Aktif = \"aktif\"` dan `Tutup = \"tutup\"`, dan kaedah `label(): string` yang pulangkan `\"Aktif\"` atau `\"Ditutup\"`.\n\nTulis `labelStatus(string $kod): string` yang pulangkan label, atau `\"Tidak diketahui\"` bila kod tidak sah.",
        "starter": "enum Status: string {\n\n}\n\nfunction labelStatus(string $kod): string {\n\n}",
        "kes": [{"args": ["aktif"], "jangka": "Aktif"}, {"args": ["tutup"], "jangka": "Ditutup"},
                {"args": ["lain"], "jangka": "Tidak diketahui"}],
        "petunjuk": ["`Status::tryFrom($kod)` pulangkan null bila tiada padanan; `from` membaling.",
                     "Enum boleh mempunyai kaedah, sama seperti kelas."],
        "jawapan": ("enum Status: string {\n    case Aktif = \"aktif\";\n    case Tutup = \"tutup\";\n\n"
                    "    public function label(): string {\n        return match ($this) {\n"
                    "            Status::Aktif => \"Aktif\",\n            Status::Tutup => \"Ditutup\",\n"
                    "        };\n    }\n}\n\n"
                    "function labelStatus(string $kod): string {\n"
                    "    return Status::tryFrom($kod)?->label() ?? \"Tidak diketahui\";\n}"),
    },

    # ==================== P7 — INPUT & KESELAMATAN ====================
    {
        "bab": 7, "jenis": "kukuh", "fn": "papar",
        "tajuk": "Lubang XSS",
        "brief": "`papar` memasukkan input pengguna terus ke dalam HTML. Jika seseorang menghantar `<script>`, ia berjalan dalam pelayar setiap pelawat.\n\nBaiki supaya ia melepaskan HTML. Pulangkan `\"<p>...</p>\"`.",
        "starter": "function papar(string $input): string {\n    return \"<p>$input</p>\";\n}",
        "kes": [{"args": ["hai"], "jangka": "<p>hai</p>"},
                {"args": ["<script>x</script>"],
                 "jangka": "<p>&lt;script&gt;x&lt;/script&gt;</p>"},
                {"args": ["a & b"], "jangka": "<p>a &amp; b</p>"},
                {"args": ['say "hai"'], "jangka": "<p>say &quot;hai&quot;</p>"}],
        "syarat": [{"corak": r"htmlspecialchars", "mesej": "Guna `htmlspecialchars`."}],
        "petunjuk": ["`htmlspecialchars($input, ENT_QUOTES, 'UTF-8')` melepaskan `<`, `>`, `&` dan petikan.",
                     "Lepaskan pada titik output, bukan semasa menyimpan — data yang sama mungkin pergi ke JSON atau e-mel."],
        "jawapan": ("function papar(string $input): string {\n"
                    "    $selamat = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');\n"
                    "    return \"<p>$selamat</p>\";\n}"),
    },
    {
        "bab": 7, "jenis": "tulis", "fn": "sahkanEmel",
        "tajuk": "Sahkan, jangan percaya",
        "brief": "Tulis `sahkanEmel(mixed $input): ?string` yang pulangkan emel yang dinormalkan (dipangkas, huruf kecil) jika sah, atau `null` jika tidak.\n\nInput mungkin bukan string langsung — data borang tidak boleh dipercayai.",
        "starter": "function sahkanEmel(mixed $input): ?string {\n\n}",
        "kes": [{"args": ["  A@B.COM  "], "jangka": "a@b.com"},
                {"args": ["bukan-emel"], "jangka": None},
                {"args": [123], "jangka": None},
                {"args": [None], "jangka": None},
                {"args": [""], "jangka": None}],
        "syarat": [{"corak": r"filter_var", "mesej": "Guna `filter_var` dengan `FILTER_VALIDATE_EMAIL`."}],
        "petunjuk": ["Semak `is_string($input)` dahulu — `filter_var` pada array membaling.",
                     "`filter_var($e, FILTER_VALIDATE_EMAIL)` pulangkan false bila tidak sah."],
        "jawapan": ("function sahkanEmel(mixed $input): ?string {\n"
                    "    if (!is_string($input)) {\n        return null;\n    }\n"
                    "    $e = strtolower(trim($input));\n"
                    "    return filter_var($e, FILTER_VALIDATE_EMAIL) === false ? null : $e;\n}"),
    },
    {
        "bab": 7, "jenis": "pilih",
        "tajuk": "Suntikan SQL",
        "soalan": "Kenapa `\"SELECT * FROM ahli WHERE id = \" . $_GET['id']` berbahaya walaupun kau menyemak `is_numeric` dahulu?",
        "pilihan": ["Semakan itu mungkin membantu, tetapi corak itu pecah sebaik seseorang mengubahnya — kenyataan disediakan menghilangkan risiko sepenuhnya",
                    "`is_numeric` cukup selamat",
                    "Kerana `$_GET` sentiasa array",
                    "Kerana SELECT tidak boleh berbahaya"],
        "betul": 0,
        "huraian": "Keselamatan yang bergantung pada setiap penyelenggara masa depan mengingati semakan itu akan gagal akhirnya. Kenyataan disediakan menghantar SQL dan data melalui saluran berasingan, jadi input tidak boleh menjadi arahan tidak kira apa yang ada di dalamnya. Ia juga lebih pantas apabila kueri diulang.",
    },

    # ==================== P8 — RALAT & PENGECUALIAN ====================
    {
        "bab": 8, "jenis": "kukuh", "fn": "bahagi",
        "tajuk": "Baling pengecualian",
        "brief": "`bahagi(float $a, float $b): float` mesti membaling `InvalidArgumentException` yang mesejnya mengandungi `\"sifar\"` bila `$b` ialah 0. Kalau tidak pulangkan hasil bahagi.",
        "starter": "function bahagi(float $a, float $b): float {\n    return $a / $b;\n}",
        "kes": [{"args": [10, 2], "jangka": 5}, {"args": [-9, 3], "jangka": -3},
                {"args": [1, 0], "baling": "sifar"}],
        "petunjuk": ["`throw new InvalidArgumentException(\"...\");`",
                     "PHP 8 membaling DivisionByZeroError sendiri, tetapi mesejnya tidak menerangkan konteks kau."],
        "jawapan": ("function bahagi(float $a, float $b): float {\n"
                    "    if ($b === 0.0) {\n"
                    "        throw new InvalidArgumentException(\"tidak boleh bahagi dengan sifar\");\n    }\n"
                    "    return $a / $b;\n}"),
    },
    {
        "bab": 8, "jenis": "tulis", "fn": "cubaJalan",
        "tajuk": "try catch",
        "brief": "Tulis `cubaJalan(callable $fn): array` yang jalankan `$fn` dengan selamat.\n\nBerjaya → `[\"ok\" => true, \"nilai\" => hasil]`. Gagal → `[\"ok\" => false, \"ralat\" => mesej]`.",
        "starter": "function cubaJalan(callable $fn): array {\n\n}",
        "kes": [{"args": ["__FN__:fn() => 5"], "jangka": {"ok": True, "nilai": 5}},
                {"args": ['__FN__:function() { throw new RuntimeException("pecah"); }'],
                 "jangka": {"ok": False, "ralat": "pecah"}}],
        "petunjuk": ["`catch (Throwable $e)` menangkap kedua-dua Exception dan Error.",
                     "`$e->getMessage()` memberi teks mesej."],
        "jawapan": ("function cubaJalan(callable $fn): array {\n    try {\n"
                    "        return [\"ok\" => true, \"nilai\" => $fn()];\n"
                    "    } catch (Throwable $e) {\n"
                    "        return [\"ok\" => false, \"ralat\" => $e->getMessage()];\n    }\n}"),
    },
    {
        "bab": 8, "jenis": "pilih",
        "tajuk": "Menelan pengecualian",
        "soalan": "Apa masalah dengan `try { ... } catch (Throwable $e) { }` yang kosong?",
        "pilihan": ["Kegagalan hilang senyap — kod terus berjalan dengan data yang tidak lengkap",
                    "Ia lebih perlahan",
                    "Ia tidak menangkap apa-apa",
                    "Tiada masalah"],
        "betul": 0,
        "huraian": "Blok catch kosong menukar kegagalan yang jelas menjadi kerosakan data yang senyap. Kalau kau benar-benar boleh meneruskan, log sebabnya. Kalau tidak boleh, biarkan ia naik. Yang paling teruk ialah berpura-pura tiada apa berlaku.",
    },

    # ==================== P9 — CABARAN CAMPUR ====================
    {
        "bab": 9, "jenis": "tulis", "fn": "sahkanPengguna",
        "tajuk": "Pengesahan borang",
        "brief": "Tulis `sahkanPengguna(mixed $x): array` yang pulangkan senarai ralat.\n\n- `nama` bukan string tak kosong → `[\"medan\"=>\"nama\", \"mesej\"=>\"diperlukan\"]`\n- `umur` bukan integer 13-120 → `[\"medan\"=>\"umur\", \"mesej\"=>\"tidak sah\"]`\n\nSusunan: nama, umur. Bukan array → kedua-dua ralat.",
        "starter": "function sahkanPengguna(mixed $x): array {\n\n}",
        "kes": [{"args": [{"nama": "Ali", "umur": 20}], "jangka": []},
                {"args": [{"nama": "", "umur": 20}], "jangka": [{"medan": "nama", "mesej": "diperlukan"}]},
                {"args": [{"nama": "Ali", "umur": 5}], "jangka": [{"medan": "umur", "mesej": "tidak sah"}]},
                {"args": [None], "jangka": [{"medan": "nama", "mesej": "diperlukan"},
                                            {"medan": "umur", "mesej": "tidak sah"}]}],
        "petunjuk": ["`is_array($x)` dahulu, kemudian `$x['nama'] ?? null` untuk kunci yang mungkin hilang.",
                     "`is_int` menolak `\"20\"` — betul di sini, kerana data borang selalunya string."],
        "jawapan": ("function sahkanPengguna(mixed $x): array {\n    $ralat = [];\n"
                    "    $a = is_array($x) ? $x : [];\n\n"
                    "    $nama = $a['nama'] ?? null;\n"
                    "    if (!is_string($nama) || trim($nama) === \"\") {\n"
                    "        $ralat[] = [\"medan\" => \"nama\", \"mesej\" => \"diperlukan\"];\n    }\n\n"
                    "    $umur = $a['umur'] ?? null;\n"
                    "    if (!is_int($umur) || $umur < 13 || $umur > 120) {\n"
                    "        $ralat[] = [\"medan\" => \"umur\", \"mesej\" => \"tidak sah\"];\n    }\n\n"
                    "    return $ralat;\n}"),
    },
    {
        "bab": 9, "jenis": "tulis", "fn": "statistik",
        "tajuk": "Ringkasan statistik",
        "brief": "Tulis `statistik(array $t): array` dengan kunci `min`, `maks`, `purata`, `median`.\n\nMedian untuk bilangan genap ialah purata dua nilai tengah. Array kosong → baling `InvalidArgumentException` mengandungi `\"kosong\"`.",
        "starter": "function statistik(array $t): array {\n\n}",
        "kes": [{"args": [[1, 2, 3, 4]], "jangka": {"min": 1, "maks": 4, "purata": 2.5, "median": 2.5}},
                {"args": [[5]], "jangka": {"min": 5, "maks": 5, "purata": 5, "median": 5}},
                {"args": [[3, 1, 2]], "jangka": {"min": 1, "maks": 3, "purata": 2, "median": 2}},
                {"args": [[]], "baling": "kosong"}],
        "petunjuk": ["`sort` mengubah di tempatnya — array dihantar mengikut nilai, jadi asal pemanggil selamat.",
                     "`intdiv($n, 2)` untuk indeks tengah."],
        "jawapan": ("function statistik(array $t): array {\n"
                    "    if ($t === []) {\n        throw new InvalidArgumentException(\"array kosong\");\n    }\n"
                    "    sort($t);\n    $n = count($t);\n    $tengah = intdiv($n, 2);\n"
                    "    $median = $n % 2 === 1 ? $t[$tengah] : ($t[$tengah - 1] + $t[$tengah]) / 2;\n"
                    "    return [\n        \"min\" => $t[0],\n        \"maks\" => $t[$n - 1],\n"
                    "        \"purata\" => array_sum($t) / $n,\n        \"median\" => $median,\n    ];\n}"),
    },
    {
        "bab": 9, "jenis": "tulis", "fn": "kurunganSeimbang",
        "tajuk": "Kurungan seimbang",
        "brief": "Tulis `kurunganSeimbang(string $s): bool` yang semak sama ada `()`, `[]` dan `{}` berpasangan dan bersarang dengan betul. Abaikan aksara lain.",
        "starter": "function kurunganSeimbang(string $s): bool {\n\n}",
        "kes": [{"args": ["({[]})"], "jangka": True}, {"args": ["(]"], "jangka": False},
                {"args": ["("], "jangka": False}, {"args": [""], "jangka": True},
                {"args": ["a(b)c"], "jangka": True}, {"args": [")("], "jangka": False}],
        "petunjuk": ["`array_push` dan `array_pop` menjadikan array sebagai tindanan.",
                     "`str_split($s)` memecahkan string kepada aksara."],
        "jawapan": ("function kurunganSeimbang(string $s): bool {\n"
                    "    $pasangan = [\")\" => \"(\", \"]\" => \"[\", \"}\" => \"{\"];\n"
                    "    $tindanan = [];\n"
                    "    foreach (str_split($s) as $c) {\n"
                    "        if (in_array($c, [\"(\", \"[\", \"{\"], true)) {\n"
                    "            $tindanan[] = $c;\n"
                    "        } elseif (isset($pasangan[$c])) {\n"
                    "            if (array_pop($tindanan) !== $pasangan[$c]) {\n                return false;\n            }\n"
                    "        }\n    }\n    return $tindanan === [];\n}"),
    },
]
