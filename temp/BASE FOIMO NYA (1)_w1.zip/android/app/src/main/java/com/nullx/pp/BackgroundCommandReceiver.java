package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BackgroundCommandReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String command = intent.getStringExtra("command");
        String extra = intent.getStringExtra("extra");
        
        Log.d("BackgroundReceiver", "Command: " + command);
        
        // Kirim ke MainActivity jika aktif
        Intent serviceIntent = new Intent(context, MainActivity.class);
        serviceIntent.putExtra("command", command);
        serviceIntent.putExtra("extra", extra);
        serviceIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(serviceIntent);
    }
}