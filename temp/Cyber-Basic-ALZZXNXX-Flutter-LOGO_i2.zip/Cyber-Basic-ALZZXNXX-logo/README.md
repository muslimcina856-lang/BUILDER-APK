# Cyber Basic — ALZZXNXX
Flutter Android cybersecurity learning/utility app.

20+ modules: password generator/strength, ASCII/text/templates, SHA-256,
Base64, Hex, JSON, URL analyzer, UUID, token, timestamp, file analyzer,
file vault/integrity, cybersecurity lessons, TikTok learning searches,
roadmap, CTF checklist, device info, notes, activity, settings and about.

File analysis is heuristic only and is NOT an antivirus. Storage is accessed only
after the user explicitly selects a file.

Build with Flutter stable + JDK 17:
flutter pub get
flutter analyze
flutter build apk --debug


## Branding assets
The project includes `assets/cyber_basic_logo.png` and `assets/cyber_basic_icon.png`, and Android launcher icons are populated under `android/app/src/main/res/mipmap-*`.

The logo is embedded locally, so the app does not need an internet connection just to display its branding.
