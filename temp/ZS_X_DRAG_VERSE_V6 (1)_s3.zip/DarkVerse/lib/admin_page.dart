import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart'; <-- HAPUS INI

class AdminPage extends StatefulWidget {
  final String sessionKey;
  const AdminPage({super.key, required this.sessionKey});
  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  final List<String> roleOptions = ['owner', 'reseller', 'member'];
  String selectedRole = 'owner';
  int currentPage = 1;
  int itemsPerPage = 25;
  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;
  final Color bgDark = const Color(0xFF1A1A1A);
  final Color primarySilver = const Color(0xFF757575);
  final Color accentSilver = const Color(0xFFBDBDBD); // UDAH FIX 8 DIGIT
  final Color primaryWhite = Colors.white;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://akiraxilusia.kennhosting.my.id:1117/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("⚠️ Error", data['message'] ?? 'Tidak diizinkan melihat daftar user.');
      }
    } catch (_) {
      _alert("🌐 Error", "Gagal memuat user list.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) return _alert("⚠️ Error", "Masukkan username yang ingin dihapus.");
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://akiraxilusia.kennhosting.my.id:1117/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("✅ Berhasil", "User '${data['user']['username']}' telah dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("❌ Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("🌐 Error", "Tidak dapat menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();
    if (username.isEmpty || password.isEmpty || day.isEmpty) return _alert("⚠️ Error", "Semua field wajib diisi.");
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('http://akiraxilusia.kennhosting.my.id:1117/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$newUserRole');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("✅ Sukses", "Akun '${data['user']['username']}' role $newUserRole berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("❌ Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("🌐 Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: bgDark, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), title: Text(title, style: TextStyle(color: primaryWhite)), content: Text(message, style: TextStyle(color: Colors.white70)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text("OK", style: TextStyle(color: accentSilver)))]));
  }

  Widget _buildInput({required String label, required TextEditingController controller, required IconData icon, TextInputType type = TextInputType.text}) {
    return Padding(padding: const EdgeInsets.only(bottom: 20), child: TextField(controller: controller, keyboardType: type, style: TextStyle(color: primaryWhite), decoration: InputDecoration(labelText: label, labelStyle: TextStyle(color: accentSilver), prefixIcon: Icon(icon, color: accentSilver), filled: true, fillColor: cardGlass, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))));
  }

  Widget _buildGlassCard({required String title, required IconData icon, required List<Widget> children}) {
    return Container(margin: EdgeInsets.only(bottom: 30), padding: EdgeInsets.all(24), decoration: BoxDecoration(color: cardGlass, borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Row(children: [Icon(icon, color: accentSilver), SizedBox(width: 12), Text(title, style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold))]), SizedBox(height: 24), ...children]));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: bgDark, body: SafeArea(child: SingleChildScrollView(padding: EdgeInsets.all(20), child: Column(children: [
      Text("ZS X DRAG VERSER V6", style: TextStyle(color: primaryWhite, fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 30),

      _buildGlassCard(title: "DELETE USER", icon: Icons.person_remove, children: [ // GANTI
        _buildInput(label: "Username Target", controller: deleteController, icon: Icons.person), // GANTI
        ElevatedButton(onPressed: isLoading ? null : _deleteUser, child: Text("DELETE ACCOUNT")),
      ]),

      _buildGlassCard(title: "CREATE ACCOUNT", icon: Icons.person_add, children: [ // GANTI
        _buildInput(label: "Username", controller: createUsernameController, icon: Icons.person), // GANTI
        _buildInput(label: "Password", controller: createPasswordController, icon: Icons.lock), // GANTI
        _buildInput(label: "Durasi (Hari)", controller: createDayController, icon: Icons.calendar_today, type: TextInputType.number), // GANTI
        
        DropdownButtonFormField<String>(
          value: newUserRole,
          dropdownColor: bgDark,
          style: TextStyle(color: primaryWhite),
          decoration: InputDecoration(labelText: "Role", prefixIcon: Icon(Icons.admin_panel_settings, color: accentSilver), filled: true, fillColor: cardGlass, border: OutlineInputBorder()), // GANTI
          items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
          onChanged: (value) => setState(() => newUserRole = value!),
        ),
        SizedBox(height: 20),
        ElevatedButton(onPressed: isLoading ? null : _createAccount, child: Text("CREATE ACCOUNT")),
      ]),
    ]))));
  }
}