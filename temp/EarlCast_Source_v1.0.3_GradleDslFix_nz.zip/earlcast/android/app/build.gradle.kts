import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

val projectRootDir = rootProject.projectDir.parentFile
val nodeProjectSourceDir = File(projectRootDir, "nodejs-project")
val nodeStageDir = layout.buildDirectory.dir("earlcast/nodejs-project-stage").get().asFile
val generatedNodeAssetsRoot = layout.buildDirectory.dir("generated/earlcastNodeAssets").get().asFile
val generatedNodeProjectDir = File(generatedNodeAssetsRoot, "nodejs-project")

fun sha256File(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input ->
        val buffer = ByteArray(1024 * 1024)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            if (read > 0) digest.update(buffer, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

fun projectFingerprint(root: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    root.walkTopDown()
        .filter { it.isFile }
        .filterNot { it.name == "earlcast_assets.sha256" || it.name == "file.list" || it.name == "dir.list" }
        .sortedBy { it.relativeTo(root).invariantSeparatorsPath }
        .forEach { file ->
            val relative = file.relativeTo(root).invariantSeparatorsPath
            digest.update(relative.toByteArray(Charsets.UTF_8))
            digest.update(0.toByte())
            digest.update(sha256File(file).toByteArray(Charsets.UTF_8))
            digest.update(0.toByte())
        }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

val prepareEarlCastNodeProject = tasks.register("prepareEarlCastNodeProject") {
    group = "earlcast"
    description = "Stages EarlCast Node assets, installs pinned runtime dependencies, and verifies the Baileys security backport."

    inputs.dir(nodeProjectSourceDir)
    outputs.dir(generatedNodeAssetsRoot)

    doLast {
        if (!File(nodeProjectSourceDir, "main.js").isFile || !File(nodeProjectSourceDir, "package.json").isFile) {
            throw GradleException("nodejs-project/main.js or package.json is missing from the EarlCast source tree.")
        }

        project.delete(nodeStageDir)
        nodeStageDir.mkdirs()
        project.copy {
            from(nodeProjectSourceDir)
            into(nodeStageDir)
            exclude("node_modules/**")
        }

        val isWindows = System.getProperty("os.name").lowercase().contains("windows")
        val npm = if (isWindows) "npm.cmd" else "npm"
        val node = if (isWindows) "node.exe" else "node"
        val lockFile = File(nodeStageDir, "package-lock.json")

        val nodeVersionOutput = ByteArrayOutputStream()
        val hostNodeVersion = try {
            project.exec {
                commandLine(node, "-p", "process.versions.node")
                standardOutput = nodeVersionOutput
            }
            nodeVersionOutput.toString(Charsets.UTF_8.name()).trim()
        } catch (error: Throwable) {
            throw GradleException(
                "Node.js >=18 is required on the build host to prepare EarlCast's embedded dependencies.",
                error,
            )
        }
        val hostNodeMajor = hostNodeVersion.substringBefore('.').toIntOrNull() ?: 0
        if (hostNodeMajor < 18) {
            throw GradleException(
                "Node.js >=18 is required on the build host; detected '$hostNodeVersion'."
            )
        }
        logger.lifecycle("Host Node.js $hostNodeVersion detected for EarlCast asset staging")

        val installCommand = mutableListOf(npm)
        installCommand += if (lockFile.isFile) "ci" else "install"
        installCommand += listOf(
            "--omit=dev",
            "--omit=optional",
            "--ignore-scripts",
            "--no-audit",
            "--no-fund",
            "--registry=https://registry.npmjs.org/",
        )
        if (!lockFile.isFile) installCommand += "--package-lock=false"

        logger.lifecycle("Preparing embedded EarlCast Node dependencies (${if (lockFile.isFile) "npm ci" else "npm install"})...")
        try {
            project.exec {
                workingDir = nodeStageDir
                commandLine(installCommand)
                environment("npm_config_update_notifier", "false")
            }
        } catch (error: Throwable) {
            throw GradleException(
                "Unable to prepare EarlCast Node dependencies. Ensure Node.js/npm are installed and registry.npmjs.org is reachable.",
                error,
            )
        }

        val verifier = File(nodeStageDir, "scripts/apply_security_backport.cjs")
        if (!verifier.isFile) {
            throw GradleException("Security verifier is missing: ${verifier.absolutePath}")
        }
        // Third-party lifecycle scripts stay disabled. Apply only EarlCast's
        // reviewed security backport, then verify it independently.
        project.exec {
            workingDir = nodeStageDir
            commandLine(node, verifier.absolutePath)
        }
        project.exec {
            workingDir = nodeStageDir
            commandLine(node, verifier.absolutePath, "--verify")
        }

        val baileysEntry = File(nodeStageDir, "node_modules/baileys/lib/index.js")
        if (!baileysEntry.isFile) {
            throw GradleException("Baileys was not installed into the embedded Node project: ${baileysEntry.absolutePath}")
        }

        // Android assets do not need npm executable shims. AAPT also ignores
        // dot-prefixed files/directories by default; remove them before the
        // manifest is generated so file.list never references an asset that
        // was silently omitted from the APK (for example .package-lock.json).
        project.delete(File(nodeStageDir, "node_modules/.bin"))
        nodeStageDir.walkBottomUp()
            .filter { it != nodeStageDir }
            .filter { file ->
                file.relativeTo(nodeStageDir).invariantSeparatorsPath
                    .split('/')
                    .any { part -> part.startsWith('.') }
            }
            .forEach { hidden -> project.delete(hidden) }

        // The marker is part of the file list so Android copies it into private
        // storage. It prevents re-copying thousands of Node files every launch.
        File(nodeStageDir, "earlcast_assets.sha256").writeText(projectFingerprint(nodeStageDir) + "\n")

        val fileList = nodeStageDir.walkTopDown()
            .filter { it.isFile }
            .filterNot { it.name == "file.list" || it.name == "dir.list" }
            .map { it.relativeTo(nodeStageDir).invariantSeparatorsPath }
            .sorted()
            .toList()
        File(nodeStageDir, "file.list").writeText(fileList.joinToString("\n", postfix = "\n"))

        val dirList = nodeStageDir.walkTopDown()
            .filter { it.isDirectory && it != nodeStageDir }
            .map { it.relativeTo(nodeStageDir).invariantSeparatorsPath }
            .filter { it.isNotBlank() }
            .sorted()
            .toList()
        File(nodeStageDir, "dir.list").writeText(dirList.joinToString("\n", postfix = "\n"))

        project.delete(generatedNodeProjectDir)
        generatedNodeProjectDir.parentFile.mkdirs()
        project.copy {
            from(nodeStageDir)
            into(generatedNodeProjectDir)
        }
        logger.lifecycle("Embedded EarlCast Node project prepared: ${fileList.size} files")
    }
}

android {
    namespace = "com.earlxz.earlcast"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = "28.2.13676358"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.earlxz.earlcast"
        minSdk = 24
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    sourceSets.getByName("main").assets.srcDir(generatedNodeAssetsRoot)

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn(prepareEarlCastNodeProject)
}

// AGP may schedule asset tasks independently of preBuild. Make the producer
// dependency explicit so generated Node assets can never race merge/compress.
tasks.configureEach {
    if ((name.startsWith("merge") || name.startsWith("compress")) && name.endsWith("Assets")) {
        dependsOn(prepareEarlCastNodeProject)
    }
}

flutter {
    source = "../.."
}
