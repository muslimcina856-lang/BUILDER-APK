@echo off
setlocal enabledelayedexpansion
set "GRADLE_VERSION=8.14.5"
set "GRADLE_SHA256=6f74b601422d6d6fc4e1f9a1ab6522f642c2fdcbc15ae33ebd30ba3d7198e854"
set "APP_HOME=%~dp0"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "DIST_ROOT=%GRADLE_USER_HOME%\earlcast-gradle"
set "DIST_DIR=%DIST_ROOT%\gradle-%GRADLE_VERSION%"
set "ZIP_FILE=%DIST_ROOT%\gradle-%GRADLE_VERSION%-bin.zip"
set "GRADLE_BIN=%DIST_DIR%\bin\gradle.bat"

if not exist "%GRADLE_BIN%" (
  if not exist "%DIST_ROOT%" mkdir "%DIST_ROOT%"
  if not exist "%ZIP_FILE%" (
    echo Downloading Gradle %GRADLE_VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%.tmp'"
    if errorlevel 1 exit /b 1
    move /Y "%ZIP_FILE%.tmp" "%ZIP_FILE%" >nul
  )
  for /f %%H in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 -LiteralPath '%ZIP_FILE%').Hash.ToLower()"') do set "ACTUAL_SHA=%%H"
  if /I not "!ACTUAL_SHA!"=="%GRADLE_SHA256%" (
    echo Gradle checksum mismatch. Expected %GRADLE_SHA256%, got !ACTUAL_SHA!
    del /Q "%ZIP_FILE%" >nul 2>&1
    exit /b 1
  )
  if exist "%DIST_DIR%" rmdir /S /Q "%DIST_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP_FILE%' -DestinationPath '%DIST_ROOT%' -Force"
  if errorlevel 1 exit /b 1
)

pushd "%APP_HOME%"
call "%GRADLE_BIN%" %*
set "EXIT_CODE=%ERRORLEVEL%"
popd
exit /b %EXIT_CODE%
