# EarlCast 1.0.3 — Root-fixed Android source

EarlCast ialah aplikasi Flutter Android yang menjalankan Node.js + Baileys secara lokal dalam proses aplikasi. Tiada VPS, panel Telegram atau backend luar. Socket WhatsApp digunakan hanya ketika app berada di foreground; apabila app masuk background, queue dihentikan dan socket ditutup.

> **Status:** Android proof-of-concept untuk sideload/testing. Baileys menggunakan protokol WhatsApp Web tidak rasmi. Gunakan nombor ujian/sekunder dan group yang anda urus atau mempunyai izin.

## Apa yang diperbaiki dalam 1.0.3

### Gradle Kotlin DSL fix (1.0.3)

Jika builder sebelum ini gagal pada `android/app/build.gradle.kts` dengan `Unresolved reference: io` di `java.io.ByteArrayOutputStream()`, 1.0.3 membetulkannya dengan import kelas Java secara terus. Semua diagnostic `unreachable code` selepas baris itu ialah kesan domino compiler dan bukan bug pada queue/Node engine.


Build tidak lagi bergantung pada `node_flutter` dari `.pub-cache`. Projek kini mempunyai fork Android lokal di `packages/node_flutter` dan build pipeline sendiri:

- Gradle `8.14.5` launcher dengan checksum distribution.
- Android Gradle Plugin `8.11.1`.
- Kotlin `2.2.20`.
- App NDK `28.2.13676358`.
- Fork `node_flutter` lokal; tiada foreground service.
- Gradle plugin memuat turun Node.js Mobile Android `18.20.4` rasmi sebelum CMake jika `libnode` belum ada.
- Runtime diverifikasi mempunyai `node.h` serta `libnode.so` untuk `armeabi-v7a`, `arm64-v8a` dan `x86_64`, kemudian dipaksa masuk APK melalui `jniLibs`.
- Bridge native menggunakan `c++_shared` dan NDK `28.2.13676358` secara konsisten untuk mengelakkan load/link mismatch.
- `Nodejs.start()` kini kembali selepas thread native dilancarkan; Flutter menunggu event `engine.booted` dan `engine.ready`.
- Event native dibuffer sehingga EventChannel Flutter attach, jadi `engine.booted` tidak hilang akibat startup race.
- `System.loadLibrary(...)` dipindahkan ke startup thread yang ditangkap; native load failure kini menjadi `engine.error`, bukan crash awal plugin.
- `flutter_bridge` didaftarkan secara eksplisit sebagai linked Node-API module sebelum `node::Start()`; ini mengelakkan kegagalan `_linkedBinding` pada Node 18.
- Native channel handle diselaraskan dengan mutex untuk menghapus race command pertama semasa JS bridge sedang register.
- Builtin JS bridge disegarkan pada setiap process start supaya app upgrade tidak guna salinan private lama.
- Protokol bridge Flutter → Node dibetulkan menggunakan channel `_EVENTS_` + envelope `tag/message`.
- Semua command Node diserialkan supaya `init/connect/pair/logout/campaign` tidak berlumba.
- `libsignal` transitif Baileys 6.7.8 dipin kepada commit yang direkodkan dalam lockfile rasmi release tersebut, melalui URL codeload HTTPS.
- `nodejs-project/` ialah satu-satunya source of truth. Tiada lagi salinan statik di `android/app/src/main/assets/nodejs-project`.
- Gradle app sendiri staging Node project, menjalankan npm, mengesahkan security backport dan menjana `file.list` untuk first-launch copy.
- Node asset fingerprint mengelakkan salinan ribuan fail pada setiap launch.
- Error native semasa startup dihantar terus ke Flutter dan tidak lagi hanya timeout senyap.
- Error `getGroups` tidak lagi meninggalkan loading spinner selama-lamanya.
- Resource splash `android:drawable` telah dibetulkan menggunakan `@color/launch_background`.

Lihat `ROOT_FIX_AUDIT.md` untuk matriks masalah → pembaikan.

## Fungsi

- Pair WhatsApp menggunakan nombor telefon + pairing code.
- Sesi WhatsApp di private app storage.
- Reconnect apabila app dibuka/foreground semula.
- Senarai/search/pilih group.
- Had keras 50 group; default 30.
- Teks, gambar, video, audio dan dokumen lokal.
- Maksimum 10 media, 64 MB setiap fail.
- Queue satu demi satu, delay, retry, pause/resume/stop.
- Progress dan history lokal.
- Auto-reply private sekali bagi setiap nombor dalam satu sesi app.
- Logout + padam sesi lokal.

Sengaja tidak disediakan: scrape ahli/nombor, hidden mention, autojoin massal, DM pukal kepada ahli, concurrency agresif, anti-ban/bypass, atau background service kekal hidup.

## Keperluan build

- Flutter stable + Dart `>=3.7.2`.
- JDK 17 atau lebih baharu yang serasi dengan Flutter/AGP.
- Android SDK.
- Node.js + npm pada mesin build.
- Python 3 untuk validator/setup helper.
- Internet semasa clean build untuk Gradle distribution, Maven/Flutter packages, npm registry dan Node.js Mobile release.

Android minimum: API 24 (Android 7.0).

## Build

Prasyarat host: Flutter stable, Java 17, Android SDK, Node.js 18 atau lebih baharu, npm, dan internet untuk first clean build.

Windows:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\build_apk.ps1
```

Linux/macOS:

```bash
chmod +x scripts/*.sh scripts/*.py android/gradlew
./scripts/build_apk.sh
```

Atau terus:

```bash
flutter pub get
flutter build apk --debug
```

Untuk release lokal:

```bash
flutter build apk --release
```

APK:

```text
build/app/outputs/flutter-apk/
```

> Release configuration masih menggunakan debug signing untuk ujian peribadi. Ganti dengan release keystore sendiri sebelum pengedaran.

## Apa berlaku semasa build

1. Flutter resolve dependency; `node_flutter` datang daripada `packages/node_flutter` lokal.
2. Local plugin task `prepareEarlCastNodeRuntime` memastikan Node.js Mobile `18.20.4` lengkap sebelum CMake.
3. App task `prepareEarlCastNodeProject` copy `nodejs-project/` ke build staging directory.
4. Task menjalankan `npm install` (atau `npm ci` jika `package-lock.json` disediakan) dengan direct dependency yang dipin tepat, optional/dev dependency dibuang dan lifecycle script pihak ketiga dimatikan.
5. Gradle menjalankan backport keselamatan EarlCast secara eksplisit, kemudian menjalankan verifier berasingan. `postinstall` kekal untuk pemasangan manual di luar Gradle.
6. `.bin` npm dibuang, fingerprint + `file.list` dijana, kemudian staged project dimasukkan sebagai Android generated assets.
7. CMake compile bridge lokal dan link terhadap `libnode.so` yang telah disediakan.

Jadi CI yang hanya menjalankan `flutter pub get` + `flutter build apk` tidak perlu menulis ke `.pub-cache` atau menjalankan setup manual untuk Node assets.

## Runtime

```text
Flutter UI
   │ MethodChannel/EventChannel
   ▼
packages/node_flutter (fork lokal)
   │ JNI / Node-API bridge
   ▼
Node.js Mobile 18.20.4
   │
   ▼
Baileys engine
   │ WebSocket
   ▼
WhatsApp
```

Startup mempunyai dua readiness gate:

```text
native thread launched → engine.booted → init command → engine.ready → UI ready
```

Command JavaScript diproses satu demi satu melalui `commandChain`.

## Data lokal

Sesi Baileys disimpan di private app directory dalam `earlcast/wa-session`. Android backup dimatikan. History hanya menyimpan preview/statistik, bukan credential WhatsApp.

## Baileys yang digunakan

Build standard ini sengaja dipin kepada `baileys@6.7.8` kerana runtime Node.js Mobile rasmi yang tersedia sebagai release Android ialah Node 18.20.4. Projek menerapkan backport khusus advisory yang didokumentasikan dalam `SECURITY_PATCH.md`, mematikan history sync dan menolak event `requestId` daripada auto-reply.

`package.baileys7.json` hanya disimpan sebagai rujukan eksperimen. Skrip `use_baileys7.*` kini sengaja **refuse/fail** supaya manifest Baileys 7 tidak boleh teraktif secara tidak sengaja pada runtime Node 18.

## Batas penting: Google Play / 16 KB page size

Node.js Mobile `18.20.4` release rasmi yang digunakan di sini dibina sebelum pembaikan alignment 16 KB. Ini tidak menghalang sideload/debug pada peranti biasa, tetapi merupakan limit untuk penerbitan Play Store moden pada sasaran yang mewajibkan native library 16 KB. Lihat `BUILD_NOTES.md`.

## Troubleshooting

### `libnode.so ... missing and no known rule to make it`

Versi 1.0.3 sepatutnya menjalankan `:node_flutter:prepareEarlCastNodeRuntime` sebelum CMake. Cari log:

```text
Downloading Node.js Mobile 18.20.4 for Android...
EarlCast Node runtime 18.20.4: ready
```

Jika download gagal, semak akses GitHub dari runner.

### `Unable to prepare EarlCast Node dependencies`

Pastikan `node` dan `npm` tersedia dalam PATH runner serta `registry.npmjs.org` boleh dicapai.

### `Cannot find module 'baileys'`

Ini menandakan generated Node assets tidak disediakan. Jalankan build dari root projek; jangan copy `nodejs-project` secara manual ke Android assets.

### Engine timeout / pairing tidak muncul

Semak Logcat tag:

```text
EARLCAST-NODE
EarlCastNode
```

Native startup error kini juga dihantar ke UI sebagai `engine.error`/`engine.nativeExit`.

### APK besar

Embedded Node + npm dependencies memang besar. Untuk ujian per ABI:

```bash
flutter build apk --release --split-per-abi
```

## Semakan source

```bash
python3 scripts/validate_source.py
```

Validator memeriksa JavaScript tests, resource XML, local plugin wiring, bridge protocol, runtime bootstrap, Gradle/Kotlin versions, security configuration, icons dan secret asas.

## Keselamatan ZIP asal

Token Telegram yang terdapat dalam ZIP rujukan asal tidak dimasukkan dalam projek ini. Token lama tetap perlu direvoke/regenerate melalui BotFather jika belum dibuat.

## Lesen

Kod EarlCast: MIT. Fork bridge lokal berasal daripada komponen MIT `node_flutter`; dependency pihak ketiga mempunyai lesen masing-masing. Lihat `THIRD_PARTY.md`.
