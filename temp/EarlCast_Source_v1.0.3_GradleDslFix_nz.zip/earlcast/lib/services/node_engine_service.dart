import 'dart:async';
import 'dart:convert';

import 'package:node_flutter/node_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../models/engine_event.dart';

class NodeEngineService {
  final StreamController<EngineEvent> _events =
      StreamController<EngineEvent>.broadcast();
  final Uuid _uuid = const Uuid();

  StreamSubscription<Map<String, dynamic>>? _subscription;
  Completer<void>? _bootCompleter;
  Completer<void>? _readyCompleter;
  bool _started = false;

  Stream<EngineEvent> get events => _events.stream;
  bool get isStarted => _started;

  Future<void> start() async {
    if (_started) return;

    await _subscription?.cancel();
    _bootCompleter = Completer<void>();
    _readyCompleter = Completer<void>();
    _subscription = Nodejs.onMessageReceived.listen(
      _handleNativeMessage,
      onError: (Object error, StackTrace stackTrace) {
        final exception = StateError(error.toString());
        _failPendingStart(exception, stackTrace);
        _events.add(EngineEvent(
          type: 'engine.error',
          payload: {'message': error.toString()},
          timestamp: DateTime.now(),
        ));
      },
    );

    try {
      await Nodejs.start();
      await _bootCompleter!.future.timeout(
        const Duration(seconds: 120),
        onTimeout: () => throw TimeoutException(
          'Node engine tidak memberi isyarat boot dalam 120 saat. Semak log EARLCAST-NODE untuk punca native/JavaScript.',
        ),
      );

      final supportDirectory = await getApplicationSupportDirectory();
      final cacheDirectory = await getTemporaryDirectory();

      // `init` is the only command permitted before _started becomes true.
      // The JavaScript command queue serializes it before later commands.
      await send(
        'init',
        {
          'dataDir': supportDirectory.path,
          'cacheDir': cacheDirectory.path,
          'clientName': 'EarlCast',
        },
      );

      await _readyCompleter!.future.timeout(
        const Duration(seconds: 60),
        onTimeout: () => throw TimeoutException(
          'Node engine booted tetapi init WhatsApp tidak siap dalam 60 saat.',
        ),
      );
      _started = true;
    } catch (_) {
      _started = false;
      await _subscription?.cancel();
      _subscription = null;
      _bootCompleter = null;
      _readyCompleter = null;
      rethrow;
    }
  }

  Future<void> send(String action, [Map<String, dynamic>? payload]) async {
    if (!_started && action != 'init') {
      throw StateError('Node engine belum dimulakan.');
    }

    final command = <String, dynamic>{
      'id': _uuid.v4(),
      'action': action,
      'payload': payload ?? <String, dynamic>{},
      'timestamp': DateTime.now().toIso8601String(),
    };

    await Nodejs.sendMessage('command', jsonEncode(command));
  }

  void _handleNativeMessage(Map<String, dynamic> nativeMessage) {
    final channel = nativeMessage['channelName'] ?? nativeMessage['tag'];
    if (channel != 'event') return;

    dynamic raw = nativeMessage['message'];
    if (raw is Map<String, dynamic>) {
      _addEvent(EngineEvent.fromJson(raw));
      return;
    }

    if (raw is Map) {
      _addEvent(EngineEvent.fromJson(raw.cast<String, dynamic>()));
      return;
    }

    if (raw is! String || raw.isEmpty) return;

    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        _addEvent(EngineEvent.fromJson(decoded));
      } else if (decoded is Map) {
        _addEvent(EngineEvent.fromJson(decoded.cast<String, dynamic>()));
      }
    } on FormatException {
      _events.add(EngineEvent(
        type: 'engine.log',
        payload: {'level': 'info', 'message': raw},
        timestamp: DateTime.now(),
      ));
    }
  }

  void _addEvent(EngineEvent event) {
    if (event.type == 'engine.booted' &&
        _bootCompleter != null &&
        !_bootCompleter!.isCompleted) {
      _bootCompleter!.complete();
    }
    if (event.type == 'engine.ready' &&
        _readyCompleter != null &&
        !_readyCompleter!.isCompleted) {
      _readyCompleter!.complete();
    }

    if (event.type == 'engine.error' || event.type == 'engine.nativeExit') {
      final message = event.payload['message']?.toString() ??
          (event.type == 'engine.nativeExit'
              ? 'Embedded Node.js runtime telah berhenti.'
              : 'Embedded Node.js runtime gagal.');
      _failPendingStart(StateError(message));
    }
    if (event.type == 'command.error' &&
        event.payload['action']?.toString() == 'init') {
      _failPendingStart(StateError(
        event.payload['message']?.toString() ?? 'Init Node engine gagal.',
      ));
    }

    _events.add(event);
  }

  void _failPendingStart(Object error, [StackTrace? stackTrace]) {
    if (_bootCompleter != null && !_bootCompleter!.isCompleted) {
      _bootCompleter!.completeError(error, stackTrace);
    }
    if (_readyCompleter != null && !_readyCompleter!.isCompleted) {
      _readyCompleter!.completeError(error, stackTrace);
    }
  }

  Future<void> shutdown() async {
    if (!_started) return;
    try {
      await send('shutdown');
    } catch (_) {
      // Proses Android akan menamatkan runtime apabila aplikasi ditutup.
    }
    _started = false;
  }

  Future<void> dispose() async {
    await shutdown();
    await _subscription?.cancel();
    await _events.close();
  }
}
