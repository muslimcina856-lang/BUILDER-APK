#!/usr/bin/env python3
"""Prepare EarlCast for a deterministic Android build.

The Android Gradle build now owns both embedded runtimes:
- packages/node_flutter downloads/validates Node.js Mobile before CMake.
- app/build.gradle.kts stages nodejs-project, installs dependencies, verifies
  the Baileys security backport, and generates Android asset file lists.

This script therefore only validates prerequisites, refreshes Flutter packages
and icons, and preserves Android resource fixes. It never copies node_modules
into the source tree.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "android"


def run(command: list[str], cwd: Path = ROOT) -> None:
    print(f"\n> {' '.join(command)}")
    subprocess.run(command, cwd=cwd, check=True)


def executable(name: str) -> str:
    located = shutil.which(name)
    if not located:
        raise SystemExit(f"Perintah '{name}' tidak dijumpai dalam PATH.")
    return located


def validate_scaffold() -> None:
    required = [
        ANDROID / "settings.gradle.kts",
        ANDROID / "app" / "build.gradle.kts",
        ANDROID / "gradle" / "wrapper" / "gradle-wrapper.properties",
        ROOT / "packages" / "node_flutter" / "android" / "build.gradle",
        ROOT / "nodejs-project" / "main.js",
        ROOT / "nodejs-project" / "package.json",
    ]
    if not ((ANDROID / "gradlew").is_file() or (ANDROID / "gradlew.bat").is_file()):
        required.append(ANDROID / "gradlew")
    missing = [item.relative_to(ROOT).as_posix() for item in required if not item.is_file()]
    if missing:
        raise SystemExit(
            "Android scaffold EarlCast tidak lengkap; source tidak akan dijana semula "
            "secara automatik kerana flutter create boleh menimpa root fixes:\n- "
            + "\n- ".join(missing)
        )


def patch_launch_background() -> None:
    values = ANDROID / "app" / "src" / "main" / "res" / "values"
    colors = values / "colors.xml"
    values.mkdir(parents=True, exist_ok=True)

    if colors.exists():
        colors_text = colors.read_text(encoding="utf-8")
        if 'name="launch_background"' not in colors_text:
            colors_text = colors_text.replace(
                "</resources>",
                '    <color name="launch_background">#071812</color>\n</resources>',
            )
    else:
        colors_text = (
            '<?xml version="1.0" encoding="utf-8"?>\n'
            '<resources>\n'
            '    <color name="launch_background">#071812</color>\n'
            '</resources>\n'
        )
    colors.write_text(colors_text, encoding="utf-8")

    launch_xml = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<layer-list xmlns:android="http://schemas.android.com/apk/res/android">\n'
        '    <item android:drawable="@color/launch_background" />\n'
        '</layer-list>\n'
    )
    for folder in ("drawable", "drawable-v21"):
        target_dir = ANDROID / "app" / "src" / "main" / "res" / folder
        target_dir.mkdir(parents=True, exist_ok=True)
        (target_dir / "launch_background.xml").write_text(launch_xml, encoding="utf-8")


def patch_manifest() -> None:
    manifest = ANDROID / "app" / "src" / "main" / "AndroidManifest.xml"
    text = manifest.read_text(encoding="utf-8")

    if "android.permission.INTERNET" not in text:
        insert_at = text.find(">") + 1
        text = (
            text[:insert_at]
            + '\n    <uses-permission android:name="android.permission.INTERNET" />'
            + '\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />'
            + text[insert_at:]
        )

    text = re.sub(r'android:label="[^"]*"', 'android:label="EarlCast"', text)
    text = re.sub(r'android:icon="[^"]*"', 'android:icon="@mipmap/ic_launcher"', text)
    if "android:allowBackup=" not in text:
        text = text.replace("<application", '<application\n        android:allowBackup="false"', 1)
    if "android:fullBackupContent=" not in text:
        text = text.replace(
            'android:allowBackup="false"',
            'android:allowBackup="false"\n        android:fullBackupContent="false"',
            1,
        )
    if "android:usesCleartextTraffic=" not in text:
        text = text.replace(
            'android:fullBackupContent="false"',
            'android:fullBackupContent="false"\n        android:usesCleartextTraffic="false"',
            1,
        )
    if "android:roundIcon=" not in text:
        text = text.replace(
            'android:icon="@mipmap/ic_launcher"',
            'android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"',
            1,
        )
    manifest.write_text(text, encoding="utf-8")


def main() -> None:
    flutter = executable("flutter")
    dart = executable("dart")
    node = executable("node")
    executable("npm")
    node_version = subprocess.check_output(
        [node, "-p", "process.versions.node"],
        text=True,
    ).strip()
    try:
        node_major = int(node_version.split(".", 1)[0])
    except ValueError as exc:
        raise SystemExit(f"Versi Node.js tidak dapat dibaca: {node_version}") from exc
    if node_major < 18:
        raise SystemExit(f"Node.js >=18 diperlukan; dijumpai {node_version}.")
    validate_scaffold()
    patch_launch_background()
    patch_manifest()

    run([flutter, "pub", "get"])
    run([dart, "run", "flutter_launcher_icons"])
    # Icon generation can rewrite values/colors.xml on some versions.
    patch_launch_background()
    run([sys.executable, "scripts/validate_source.py"])

    print("\nPersediaan source selesai.")
    print("Node Mobile + Baileys assets akan disediakan oleh Gradle semasa build.")
    print("Build APK: flutter build apk --release")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as exc:
        raise SystemExit(exc.returncode) from exc
