#!/usr/bin/env sh
set -eu
printf '%s\n' 'Baileys 7 TIDAK diaktifkan.' >&2
printf '%s\n' 'Build standard EarlCast menggunakan Node.js Mobile 18.20.4; Baileys 7 memerlukan runtime Node yang lebih baharu.' >&2
printf '%s\n' 'Naik taraf packages/node_flutter/android runtime kepada Node 20+ dan audit native compatibility dahulu.' >&2
exit 2
