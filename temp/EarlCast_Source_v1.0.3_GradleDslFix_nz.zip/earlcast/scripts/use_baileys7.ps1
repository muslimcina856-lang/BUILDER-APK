$ErrorActionPreference = "Stop"
throw "Baileys 7 tidak diaktifkan: build standard EarlCast menggunakan Node.js Mobile 18.20.4. Naik taraf runtime embedded kepada Node 20+ dan audit native compatibility dahulu."
