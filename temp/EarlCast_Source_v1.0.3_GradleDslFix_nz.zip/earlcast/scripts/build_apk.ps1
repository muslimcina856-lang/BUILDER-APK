$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) { throw "Flutter tidak dijumpai dalam PATH." }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Node.js >=18 tidak dijumpai dalam PATH." }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw "npm tidak dijumpai dalam PATH." }

$NodeVersion = (& node -p "process.versions.node").Trim()
$NodeMajor = [int]($NodeVersion.Split('.')[0])
if ($NodeMajor -lt 18) { throw "Node.js >=18 diperlukan; dijumpai $NodeVersion." }

flutter pub get
flutter build apk --release
Write-Host "`nAPK: build\app\outputs\flutter-apk\app-release.apk" -ForegroundColor Green
