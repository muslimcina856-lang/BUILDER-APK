#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

command -v flutter >/dev/null 2>&1 || {
  echo "Flutter tidak dijumpai dalam PATH." >&2
  exit 1
}
command -v node >/dev/null 2>&1 || {
  echo "Node.js >=18 tidak dijumpai dalam PATH." >&2
  exit 1
}
command -v npm >/dev/null 2>&1 || {
  echo "npm tidak dijumpai dalam PATH." >&2
  exit 1
}

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "Node.js >=18 diperlukan; dijumpai $(node -v)." >&2
  exit 1
fi

flutter pub get
flutter build apk --release
printf '\nAPK: build/app/outputs/flutter-apk/app-release.apk\n'
