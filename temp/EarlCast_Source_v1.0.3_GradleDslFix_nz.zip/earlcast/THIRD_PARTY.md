# Third-party components

Komponen utama:

- Flutter SDK — BSD-style license.
- EarlCast local `node_flutter` fork — derived from MIT-licensed `binbard/node_flutter`; perubahan didokumentasikan dalam `packages/node_flutter/README_EARLCAST_FORK.md`.
- Node.js Mobile 18.20.4 — downloaded at build time from the official `nodejs-mobile/nodejs-mobile` GitHub release; Node.js/V8 and bundled components retain their respective licenses.
- Baileys — MIT.
- `libsignal` commit yang digunakan oleh Baileys 6.7.8 — GPL-3.0; pengedaran APK perlu mematuhi obligasi lesen komponen ini.
- `@hapi/boom`, `pino`, `mime-types` and transitive npm dependencies — respective licenses.

`node_modules` dan Node Mobile binaries tidak disertakan sebagai committed source dalam ZIP; ia dijana/dimuat turun ke build/plugin cache semasa build. Sebelum mengedar APK, audit generated dependency licenses (`npm ls` dan fail LICENSE dalam staged `node_modules`).
