'use strict';

const bridge = require('flutter-bridge');
const { WhatsAppEngine } = require('./engine/whatsapp_engine.cjs');
const { normalizeError } = require('./engine/utils.cjs');

function emit(type, payload = {}) {
  const event = {
    type,
    payload,
    timestamp: new Date().toISOString(),
  };
  bridge.send('event', JSON.stringify(event));
}

const engine = new WhatsAppEngine({ emit });
let commandChain = Promise.resolve();

async function handleRawCommand(rawMessage) {
  let command;
  try {
    command = typeof rawMessage === 'string'
      ? JSON.parse(rawMessage)
      : rawMessage;
    await engine.handleCommand(command);
    emit('command.ack', { id: command?.id || '', action: command?.action || '' });
  } catch (error) {
    emit('command.error', {
      id: command?.id || '',
      action: command?.action || '',
      message: normalizeError(error),
    });
  }
}

// EventEmitter does not await async listeners. Chain commands explicitly so
// init/connect/pair/logout/campaign state transitions cannot overlap.
bridge.on('command', (rawMessage) => {
  commandChain = commandChain
    .then(() => handleRawCommand(rawMessage))
    .catch((error) => {
      emit('engine.error', { message: `Command queue failure: ${normalizeError(error)}` });
    });
});

process.on('unhandledRejection', (error) => {
  emit('engine.error', { message: `Unhandled rejection: ${normalizeError(error)}` });
});

process.on('uncaughtException', (error) => {
  emit('engine.error', { message: `Uncaught exception: ${normalizeError(error)}` });
});

emit('engine.booted', { nodeVersion: process.version });
