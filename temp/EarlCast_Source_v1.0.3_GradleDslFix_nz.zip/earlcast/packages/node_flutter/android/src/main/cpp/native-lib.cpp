#include <jni.h>
#include <android/log.h>
#include <pthread.h>
#include <unistd.h>

#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "node.h"
#include "flutter-bridge.h"

namespace {

JNIEnv* g_node_env = nullptr;
const char* kLogTag = "EARLCAST-NODE";
int stdout_pipe[2];
int stderr_pipe[2];
pthread_t stdout_thread;
pthread_t stderr_thread;

void SendToFlutter(const char* channel_name, const char* message) {
  JNIEnv* env = g_node_env;
  if (!env || !channel_name || !message) return;
  jclass clazz = env->FindClass("org/binbard/node_flutter/NodeFlutterPlugin");
  if (!clazz) return;
  jmethodID method = env->GetStaticMethodID(
      clazz, "sendMessageToApplication", "(Ljava/lang/String;Ljava/lang/String;)V");
  if (method) {
    jstring channel = env->NewStringUTF(channel_name);
    jstring payload = env->NewStringUTF(message);
    env->CallStaticVoidMethod(clazz, method, channel, payload);
    env->DeleteLocalRef(channel);
    env->DeleteLocalRef(payload);
  }
  env->DeleteLocalRef(clazz);
}

void* StderrThread(void*) {
  char buffer[2048];
  ssize_t size;
  while ((size = read(stderr_pipe[0], buffer, sizeof(buffer) - 1)) > 0) {
    if (buffer[size - 1] == '\n') --size;
    buffer[size] = '\0';
    __android_log_write(ANDROID_LOG_ERROR, kLogTag, buffer);
  }
  return nullptr;
}

void* StdoutThread(void*) {
  char buffer[2048];
  ssize_t size;
  while ((size = read(stdout_pipe[0], buffer, sizeof(buffer) - 1)) > 0) {
    if (buffer[size - 1] == '\n') --size;
    buffer[size] = '\0';
    __android_log_write(ANDROID_LOG_INFO, kLogTag, buffer);
  }
  return nullptr;
}

int StartLogRedirect() {
  setvbuf(stdout, nullptr, _IONBF, 0);
  setvbuf(stderr, nullptr, _IONBF, 0);
  if (pipe(stdout_pipe) != 0 || pipe(stderr_pipe) != 0) return -1;
  dup2(stdout_pipe[1], STDOUT_FILENO);
  dup2(stderr_pipe[1], STDERR_FILENO);
  if (pthread_create(&stdout_thread, nullptr, StdoutThread, nullptr) != 0) return -1;
  pthread_detach(stdout_thread);
  if (pthread_create(&stderr_thread, nullptr, StderrThread, nullptr) != 0) return -1;
  pthread_detach(stderr_thread);
  return 0;
}

}  // namespace

extern "C" JNIEXPORT void JNICALL
Java_org_binbard_node_1flutter_NodeFlutterPlugin_sendMessageToNodeChannel(
    JNIEnv* env, jobject, jstring channel_name, jstring message) {
  const char* channel = env->GetStringUTFChars(channel_name, nullptr);
  const char* payload = env->GetStringUTFChars(message, nullptr);
  flutter_bridge_notify(channel, payload);
  env->ReleaseStringUTFChars(channel_name, channel);
  env->ReleaseStringUTFChars(message, payload);
}

extern "C" JNIEXPORT void JNICALL
Java_org_binbard_node_1flutter_NodeFlutterPlugin_registerNodeDataDirPath(
    JNIEnv* env, jobject, jstring data_dir) {
  const char* path = env->GetStringUTFChars(data_dir, nullptr);
  flutter_register_node_data_dir_path(path);
  env->ReleaseStringUTFChars(data_dir, path);
}

extern "C" JNIEXPORT jint JNICALL
Java_org_binbard_node_1flutter_NodeFlutterPlugin_startNodeWithArguments(
    JNIEnv* env,
    jobject,
    jobjectArray arguments,
    jstring modules_path,
    jboolean redirect_output) {
  const char* node_path = env->GetStringUTFChars(modules_path, nullptr);
  setenv("NODE_PATH", node_path, 1);
  env->ReleaseStringUTFChars(modules_path, node_path);

  const jsize count = env->GetArrayLength(arguments);
  std::vector<std::string> values;
  values.reserve(count);
  size_t total_size = 0;
  for (jsize i = 0; i < count; ++i) {
    auto value = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
    const char* chars = env->GetStringUTFChars(value, nullptr);
    values.emplace_back(chars ? chars : "");
    total_size += values.back().size() + 1;
    if (chars) env->ReleaseStringUTFChars(value, chars);
    env->DeleteLocalRef(value);
  }

  std::vector<char> contiguous(total_size, '\0');
  std::vector<char*> argv(count);
  char* cursor = contiguous.data();
  for (jsize i = 0; i < count; ++i) {
    std::memcpy(cursor, values[i].c_str(), values[i].size());
    argv[i] = cursor;
    cursor += values[i].size() + 1;
  }

  // This must run before node::Start(). Node treats modules registered while
  // node_is_initialized == false as linked modules.
  flutter_register_linked_module();
  flutter_register_bridge_cb(&SendToFlutter);
  g_node_env = env;
  if (redirect_output && StartLogRedirect() != 0) {
    __android_log_write(ANDROID_LOG_WARN, kLogTag, "stdout/stderr redirect unavailable");
  }

  return static_cast<jint>(node::Start(static_cast<int>(count), argv.data()));
}
