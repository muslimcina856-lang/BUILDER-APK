package org.binbard.node_flutter

import android.content.Context
import android.content.res.AssetManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class NodeFlutterPlugin : FlutterPlugin, MethodChannel.MethodCallHandler, EventChannel.StreamHandler {
    private lateinit var context: Context
    private lateinit var methodChannel: MethodChannel
    private lateinit var eventChannel: EventChannel

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        methodChannel = MethodChannel(binding.binaryMessenger, METHOD_CHANNEL)
        eventChannel = EventChannel(binding.binaryMessenger, EVENT_CHANNEL)
        methodChannel.setMethodCallHandler(this)
        eventChannel.setStreamHandler(this)
        instance = this
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        methodChannel.setMethodCallHandler(null)
        eventChannel.setStreamHandler(null)
        if (instance === this) instance = null
        sink = null
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events
        if (events != null) {
            val buffered = synchronized(pendingMessages) {
                val copy = pendingMessages.toList()
                pendingMessages.clear()
                copy
            }
            for (message in buffered) events.success(message)
        }
    }

    override fun onCancel(arguments: Any?) {
        sink = null
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "startNodeProject" -> startNodeProject(result)
            "sendMessage" -> {
                val channel = call.argument<String>("channel") ?: "_EVENTS_"
                val message = call.argument<String>("message") ?: ""
                if (!nodeStarted.get()) {
                    result.error("NODE_NOT_STARTED", "Embedded Node.js runtime has not started", null)
                    return
                }
                try {
                    sendMessageToNodeChannel(channel, message)
                    result.success(null)
                } catch (error: Throwable) {
                    result.error("NODE_SEND_FAILED", error.message, null)
                }
            }
            else -> result.notImplemented()
        }
    }

    private fun startNodeProject(result: MethodChannel.Result) {
        if (!nodeStarting.compareAndSet(false, true)) {
            result.success(null)
            return
        }
        if (nodeStarted.get()) {
            nodeStarting.set(false)
            result.success(null)
            return
        }

        // Return immediately: Node's event loop intentionally stays alive.
        // EarlCast waits for the JavaScript-side `engine.booted` event instead.
        result.success(null)

        Thread({
            try {
                ensureNativeLibrariesLoaded()
                val nodeProject = prepareNodeProject()
                val builtinModules = prepareBuiltinModules()
                registerNodeDataDirPath(context.filesDir.absolutePath)
                nodeStarted.set(true)
                nodeStarting.set(false)

                val exitCode = startNodeWithArguments(
                    arrayOf("node", File(nodeProject, "main.js").absolutePath),
                    "${nodeProject.absolutePath}:${builtinModules.absolutePath}",
                    true,
                )
                Log.i(TAG, "Embedded Node.js exited with code $exitCode")
                emitNativeExit(exitCode)
            } catch (error: Throwable) {
                Log.e(TAG, "Unable to start embedded Node.js", error)
                emitEngineError(error.message ?: error.javaClass.simpleName)
            } finally {
                nodeStarted.set(false)
                nodeStarting.set(false)
            }
        }, "EarlCast-Node").start()
    }

    private fun prepareNodeProject(): File {
        val target = File(context.filesDir, "nodejs-project")
        val assetMarker = readAssetText("nodejs-project/earlcast_assets.sha256")?.trim().orEmpty()
        val localMarker = File(target, "earlcast_assets.sha256")
            .takeIf { it.isFile }
            ?.readText()
            ?.trim()
            .orEmpty()

        if (assetMarker.isNotEmpty() && assetMarker == localMarker && File(target, "main.js").isFile) {
            return target
        }

        if (target.exists()) target.deleteRecursively()
        target.mkdirs()

        val fileList = readAssetText("nodejs-project/file.list")
            ?.lineSequence()
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() && !it.contains("..") && it != "file.list" }
            ?.toList()

        if (!fileList.isNullOrEmpty()) {
            for (relative in fileList) {
                copyAssetFile("nodejs-project/$relative", File(target, relative))
            }
        } else {
            copyAssetTree(context.assets, "nodejs-project", target)
        }

        check(File(target, "main.js").isFile) { "nodejs-project/main.js is missing from APK assets" }
        return target
    }

    private fun prepareBuiltinModules(): File {
        val root = File(context.filesDir, "builtin_modules")
        val bridgeTarget = File(root, "flutter-bridge")
        // The bridge is tiny. Refresh it on every process start so app upgrades
        // cannot keep an older private copy that disagrees with the native ABI.
        bridgeTarget.deleteRecursively()
        bridgeTarget.mkdirs()
        copyAssetTree(context.assets, "builtin_modules/flutter-bridge", bridgeTarget)
        check(File(bridgeTarget, "index.js").isFile) {
            "builtin_modules/flutter-bridge/index.js is missing from APK assets"
        }
        return root
    }

    private fun readAssetText(path: String): String? = try {
        context.assets.open(path).bufferedReader().use { it.readText() }
    } catch (_: Throwable) {
        null
    }

    private fun copyAssetFile(assetPath: String, output: File) {
        output.parentFile?.mkdirs()
        context.assets.open(assetPath, AssetManager.ACCESS_STREAMING).use { input ->
            FileOutputStream(output).use { outputStream -> input.copyTo(outputStream) }
        }
    }

    private fun copyAssetTree(assets: AssetManager, assetPath: String, output: File) {
        val children = assets.list(assetPath).orEmpty()
        if (children.isEmpty()) {
            copyAssetFile(assetPath, output)
            return
        }
        output.mkdirs()
        for (child in children) {
            val childAsset = if (assetPath.isEmpty()) child else "$assetPath/$child"
            copyAssetTree(assets, childAsset, File(output, child))
        }
    }


    private fun emitNativeExit(exitCode: Int) {
        sendMessageToApplication(
            "event",
            "{\"type\":\"engine.nativeExit\",\"payload\":{\"message\":\"Embedded Node.js exited with code $exitCode\",\"exitCode\":$exitCode}}",
        )
    }

    private fun emitEngineError(message: String) {
        val escaped = message.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ")
        sendMessageToApplication(
            "event",
            "{\"type\":\"engine.error\",\"payload\":{\"message\":\"$escaped\"}}",
        )
    }


    private fun ensureNativeLibrariesLoaded() {
        if (nativeLibrariesLoaded.get()) return
        synchronized(nativeLibrariesLoaded) {
            if (nativeLibrariesLoaded.get()) return
            System.loadLibrary("node")
            System.loadLibrary("nodejs-mobile-flutter-native-lib")
            nativeLibrariesLoaded.set(true)
        }
    }

    private external fun startNodeWithArguments(
        arguments: Array<String>,
        modulesPath: String,
        redirectOutputToLogcat: Boolean,
    ): Int
    private external fun sendMessageToNodeChannel(channelName: String, message: String)
    private external fun registerNodeDataDirPath(path: String)

    companion object {
        private const val TAG = "EarlCastNode"
        private const val METHOD_CHANNEL = "node_flutter"
        private const val EVENT_CHANNEL = "node_flutter/events"

        private val nodeStarted = AtomicBoolean(false)
        private val nodeStarting = AtomicBoolean(false)
        private val nativeLibrariesLoaded = AtomicBoolean(false)
        private val mainHandler = Handler(Looper.getMainLooper())

        @Volatile private var instance: NodeFlutterPlugin? = null
        @Volatile private var sink: EventChannel.EventSink? = null
        private const val MAX_PENDING_MESSAGES = 128
        private val pendingMessages = ArrayDeque<Map<String, String>>()

        @JvmStatic
        fun sendMessageToApplication(channelName: String, message: String) {
            mainHandler.post {
                val payload = mapOf("channelName" to channelName, "message" to message)
                val currentSink = sink
                if (currentSink != null) {
                    currentSink.success(payload)
                } else {
                    synchronized(pendingMessages) {
                        while (pendingMessages.size >= MAX_PENDING_MESSAGES) {
                            pendingMessages.removeFirst()
                        }
                        pendingMessages.add(payload)
                    }
                }
            }
        }
    }
}
