'use strict';

const { EventEmitter } = require('events');
const NativeBridge = process._linkedBinding('flutter_bridge');
const EVENT_CHANNEL = '_EVENTS_';

class FlutterBridge extends EventEmitter {
  constructor() {
    super();
    this.registeredChannels = new Set();
  }

  register(channelName, callback) {
    if (this.registeredChannels.has(channelName)) return;

    NativeBridge.registerChannel(channelName, (_, data) => {
      try {
        const parsed = this._tryParseJson(data);
        if (callback) callback(parsed);

        if (parsed && typeof parsed === 'object') {
          const tag = parsed.tag;
          const message = parsed.message;
          if (typeof tag === 'string') this.emit(tag, message);
          if (tag !== EVENT_CHANNEL) this.emit(EVENT_CHANNEL, parsed);
        } else {
          this.emit(EVENT_CHANNEL, parsed);
        }
      } catch (error) {
        this.emit('error', error);
      }
    });

    this.registeredChannels.add(channelName);
  }

  send(channelName, message) {
    const payload = typeof message === 'string' ? message : JSON.stringify(message);
    NativeBridge.sendMessage(channelName, payload);
  }

  getDataDir() {
    return NativeBridge.getDataDir();
  }

  _tryParseJson(message) {
    try {
      return JSON.parse(message);
    } catch (_) {
      return message;
    }
  }
}

const bridge = new FlutterBridge();
bridge.register(EVENT_CHANNEL);
bridge.register = undefined;
module.exports = bridge;
