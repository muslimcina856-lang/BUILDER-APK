#ifndef EARLCAST_FLUTTER_BRIDGE_H_
#define EARLCAST_FLUTTER_BRIDGE_H_

typedef void (*flutter_bridge_cb)(const char* channel_name, const char* message);
void flutter_register_bridge_cb(flutter_bridge_cb callback);
void flutter_bridge_notify(const char* channel_name, const char* message);
void flutter_register_node_data_dir_path(const char* path);
void flutter_register_linked_module();

#endif
