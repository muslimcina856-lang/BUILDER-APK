#define NAPI_VERSION 3
#include "node_api.h"
#include "uv.h"
#include "flutter-bridge.h"

#include <cstdlib>
#include <cstring>
#include <map>
#include <memory>
#include <mutex>
#include <queue>
#include <string>

#define NM_F_LINKED 0x2
#define NAPI_RETVAL_NOTHING
#define GET_AND_THROW_LAST_ERROR(env)                                      \
  do {                                                                     \
    const napi_extended_error_info* info;                                  \
    napi_get_last_error_info((env), &info);                                \
    bool pending = false;                                                   \
    napi_is_exception_pending((env), &pending);                            \
    if (!pending) {                                                         \
      const char* msg = info && info->error_message                        \
          ? info->error_message : "Node-API bridge error";                \
      napi_throw_error((env), nullptr, msg);                               \
    }                                                                       \
  } while (0)
#define NAPI_CALL_BASE(env, call, ret)                                     \
  do {                                                                     \
    if ((call) != napi_ok) {                                                \
      GET_AND_THROW_LAST_ERROR((env));                                     \
      return ret;                                                           \
    }                                                                       \
  } while (0)
#define NAPI_CALL(env, call) NAPI_CALL_BASE(env, call, nullptr)
#define NAPI_ASSERT(env, assertion, message)                               \
  do {                                                                     \
    if (!(assertion)) {                                                     \
      napi_throw_error((env), nullptr, (message));                         \
      return nullptr;                                                       \
    }                                                                       \
  } while (0)

namespace {

class Channel;
void FlushMessageQueue(uv_async_t* handle);

std::mutex g_channels_mutex;
std::map<std::string, std::unique_ptr<Channel>> g_channels;
flutter_bridge_cb g_embedder_callback = nullptr;
std::string g_data_dir;

class Channel {
 public:
  explicit Channel(std::string name) : name_(std::move(name)) {}

  void SetNapiRefs(napi_env env, napi_ref function_ref) {
    std::lock_guard<std::mutex> lock(handle_mutex_);
    if (async_handle_ != nullptr) {
      napi_throw_error(env, nullptr, "Channel already registered");
      return;
    }
    env_ = env;
    function_ref_ = function_ref;
    async_handle_ = static_cast<uv_async_t*>(std::calloc(1, sizeof(uv_async_t)));
    if (!async_handle_) {
      napi_throw_error(env, nullptr, "Unable to allocate bridge async handle");
      return;
    }
    if (uv_async_init(uv_default_loop(), async_handle_, FlushMessageQueue) != 0) {
      std::free(async_handle_);
      async_handle_ = nullptr;
      napi_throw_error(env, nullptr, "Unable to initialize bridge async handle");
      return;
    }
    async_handle_->data = this;
    initialized_ = true;
    uv_async_send(async_handle_);
  }

  void QueueMessage(const char* message) {
    if (!message) return;
    {
      std::lock_guard<std::mutex> lock(queue_mutex_);
      messages_.emplace(message);
    }

    // Flutter may send the first command while JavaScript is still registering
    // the channel. Publish/read the libuv handle under the same mutex used by
    // SetNapiRefs so there is no cross-thread data race. Queued messages are
    // flushed by SetNapiRefs once registration completes.
    uv_async_t* handle = nullptr;
    {
      std::lock_guard<std::mutex> lock(handle_mutex_);
      if (initialized_) handle = async_handle_;
    }
    if (handle) uv_async_send(handle);
  }

  void FlushQueue() {
    std::string message;
    bool has_more = false;
    {
      std::lock_guard<std::mutex> lock(queue_mutex_);
      if (messages_.empty()) return;
      message = std::move(messages_.front());
      messages_.pop();
      has_more = !messages_.empty();
    }
    InvokeNodeListener(message);
    if (has_more && async_handle_) uv_async_send(async_handle_);
  }

 private:
  void InvokeNodeListener(const std::string& message) {
    if (!env_ || !function_ref_) return;
    napi_handle_scope scope;
    if (napi_open_handle_scope(env_, &scope) != napi_ok) return;

    napi_value callback;
    napi_value global;
    napi_value channel;
    napi_value payload;
    napi_value result;
    if (napi_get_reference_value(env_, function_ref_, &callback) == napi_ok &&
        napi_get_global(env_, &global) == napi_ok &&
        napi_create_string_utf8(env_, name_.c_str(), name_.size(), &channel) == napi_ok &&
        napi_create_string_utf8(env_, message.c_str(), message.size(), &payload) == napi_ok) {
      napi_value argv[2] = {channel, payload};
      napi_call_function(env_, global, callback, 2, argv, &result);
    }
    napi_close_handle_scope(env_, scope);
  }

  std::string name_;
  napi_env env_ = nullptr;
  napi_ref function_ref_ = nullptr;
  uv_async_t* async_handle_ = nullptr;
  bool initialized_ = false;
  std::mutex handle_mutex_;
  std::mutex queue_mutex_;
  std::queue<std::string> messages_;
};

Channel* GetOrCreateChannel(const std::string& name) {
  std::lock_guard<std::mutex> lock(g_channels_mutex);
  auto it = g_channels.find(name);
  if (it != g_channels.end()) return it->second.get();
  auto channel = std::make_unique<Channel>(name);
  Channel* raw = channel.get();
  g_channels.emplace(name, std::move(channel));
  return raw;
}

void FlushMessageQueue(uv_async_t* handle) {
  if (handle && handle->data) {
    static_cast<Channel*>(handle->data)->FlushQueue();
  }
}

napi_value RegisterChannel(napi_env env, napi_callback_info info) {
  size_t argc = 2;
  napi_value args[2];
  NAPI_CALL(env, napi_get_cb_info(env, info, &argc, args, nullptr, nullptr));
  NAPI_ASSERT(env, argc == 2, "registerChannel requires name and callback");

  napi_valuetype type;
  NAPI_CALL(env, napi_typeof(env, args[0], &type));
  NAPI_ASSERT(env, type == napi_string, "Channel name must be a string");
  NAPI_CALL(env, napi_typeof(env, args[1], &type));
  NAPI_ASSERT(env, type == napi_function, "Channel listener must be a function");

  size_t length = 0;
  NAPI_CALL(env, napi_get_value_string_utf8(env, args[0], nullptr, 0, &length));
  std::string name(length + 1, '\0');
  size_t copied = 0;
  NAPI_CALL(env, napi_get_value_string_utf8(env, args[0], name.data(), name.size(), &copied));
  name.resize(copied);

  napi_ref callback_ref;
  NAPI_CALL(env, napi_create_reference(env, args[1], 1, &callback_ref));
  GetOrCreateChannel(name)->SetNapiRefs(env, callback_ref);
  return nullptr;
}

napi_value SendMessage(napi_env env, napi_callback_info info) {
  size_t argc = 2;
  napi_value args[2];
  NAPI_CALL(env, napi_get_cb_info(env, info, &argc, args, nullptr, nullptr));
  NAPI_ASSERT(env, argc == 2, "sendMessage requires channel and payload");
  NAPI_ASSERT(env, g_embedder_callback != nullptr, "Flutter bridge callback is not registered");

  auto to_string = [&](napi_value value, std::string* output) -> bool {
    napi_valuetype type;
    if (napi_typeof(env, value, &type) != napi_ok) return false;
    if (type != napi_string && napi_coerce_to_string(env, value, &value) != napi_ok) return false;
    size_t length = 0;
    if (napi_get_value_string_utf8(env, value, nullptr, 0, &length) != napi_ok) return false;
    output->assign(length + 1, '\0');
    size_t copied = 0;
    if (napi_get_value_string_utf8(env, value, output->data(), output->size(), &copied) != napi_ok) return false;
    output->resize(copied);
    return true;
  };

  std::string channel;
  std::string payload;
  NAPI_ASSERT(env, to_string(args[0], &channel), "Unable to read channel name");
  NAPI_ASSERT(env, to_string(args[1], &payload), "Unable to read bridge payload");
  g_embedder_callback(channel.c_str(), payload.c_str());
  return nullptr;
}

napi_value GetDataDir(napi_env env, napi_callback_info) {
  NAPI_ASSERT(env, !g_data_dir.empty(), "Data directory has not been registered");
  napi_value result;
  NAPI_CALL(env, napi_create_string_utf8(env, g_data_dir.c_str(), g_data_dir.size(), &result));
  return result;
}

napi_value Init(napi_env env, napi_value exports) {
  napi_property_descriptor properties[] = {
      {"sendMessage", nullptr, SendMessage, nullptr, nullptr, nullptr, napi_default, nullptr},
      {"registerChannel", nullptr, RegisterChannel, nullptr, nullptr, nullptr, napi_default, nullptr},
      {"getDataDir", nullptr, GetDataDir, nullptr, nullptr, nullptr, napi_default, nullptr},
  };
  NAPI_CALL(env, napi_define_properties(env, exports,
      sizeof(properties) / sizeof(properties[0]), properties));
  return exports;
}

}  // namespace

void flutter_register_bridge_cb(flutter_bridge_cb callback) {
  g_embedder_callback = callback;
}

void flutter_bridge_notify(const char* channel_name, const char* message) {
  if (!channel_name || !message) return;
  GetOrCreateChannel(channel_name)->QueueMessage(message);
}

void flutter_register_node_data_dir_path(const char* path) {
  g_data_dir = path ? path : "";
}

void flutter_register_linked_module() {
  static std::once_flag once;
  std::call_once(once, []() {
    // Node 18's NAPI_MODULE_X macro discards the flags argument. Register the
    // bridge explicitly so Node records it in the pre-init linked-module list
    // and process._linkedBinding("flutter_bridge") can resolve it.
    static napi_module module = {
        NAPI_MODULE_VERSION,
        NM_F_LINKED,
        __FILE__,
        Init,
        "flutter_bridge",
        nullptr,
        {nullptr, nullptr, nullptr, nullptr},
    };
    napi_module_register(&module);
  });
}
