# EarlCast local Node bridge

Android-only local fork/reduction derived from the MIT-licensed `binbard/node_flutter` 0.0.4 bridge.

EarlCast only needs:

- `Nodejs.start()`
- `Nodejs.sendMessage(tag, message)`
- `Nodejs.onMessageReceived`

Changes from upstream behavior:

- No foreground/background service surface.
- `startNodeProject` returns to Flutter immediately after launching the Node thread instead of waiting for `node::Start()` to exit.
- JavaScript readiness is explicit (`engine.booted` / `engine.ready`).
- Flutter → Node follows the upstream `_EVENTS_` envelope protocol (`{tag,message}`).
- Native exit/start errors are forwarded to Flutter.
- Startup events are buffered until Flutter attaches the EventChannel.
- Native libraries are lazy-loaded inside the Node startup thread so load errors are reportable.
- `libnode.so` is explicitly packaged as `jniLibs`; bridge ABI/STL is pinned to NDK 28.2.13676358 + `c++_shared`.
- Node assets are copied only when `earlcast_assets.sha256` changes and can use generated `file.list`.
- Gradle downloads and validates official Node.js Mobile Android 18.20.4 if `android/libnode` is absent.

The native C++ bridge retains the Node-API/Node Mobile embedding pattern but is reduced to the EarlCast foreground-only use case.
