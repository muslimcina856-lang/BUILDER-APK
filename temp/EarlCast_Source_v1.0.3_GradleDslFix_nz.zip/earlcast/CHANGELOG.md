# Changelog

## 1.0.3+3 — Gradle Kotlin DSL root fix

- Fixed `android/app/build.gradle.kts` script compilation on Gradle 8.14.x / AGP 8.11.x.
- `java.io.ByteArrayOutputStream()` was being resolved through Gradle's Android `java` extension instead of the Java package; the class is now imported directly and referenced as `ByteArrayOutputStream()`.
- `settings.gradle.kts` now imports `java.util.Properties` directly for the same shadow-safe pattern.
- Added a validator regression check that rejects the problematic fully-qualified `java.io.ByteArrayOutputStream()` form in the app Kotlin DSL.
- No messaging, media, queue, WhatsApp session, or UI behavior changed in this patch.

## 1.0.2 — Root fix — 2026-08-07

- Vendor/fork `node_flutter` secara lokal di `packages/node_flutter`.
- Auto-download + validate Node.js Mobile 18.20.4 sebelum CMake.
- Package `libnode.so` secara eksplisit melalui `jniLibs` dan gunakan `c++_shared` untuk semua ABI yang disokong.
- Selaraskan local bridge kepada NDK 28.2.13676358.
- Buffer native events sehingga EventChannel attach untuk tutup race `engine.booted`.
- Lazy-load native libraries dalam startup thread supaya load failure boleh dilapor sebagai `engine.error`.
- Register `flutter_bridge` explicitly as a pre-init linked Node-API module; Node 18 ignores the flags argument of `NAPI_MODULE_X`.
- Refresh the tiny builtin JS bridge on every app process start so upgrades cannot reuse an incompatible private copy.
- Synchronize native channel-handle publication to remove the Flutter-thread/Node-thread startup data race.
- Make native/JNI packaging tasks explicitly depend on Node Mobile runtime preparation.
- Extend root validator to reject a regression back to `NAPI_MODULE_X` and require linked-module registration before `node::Start()`.
- Pin `libsignal` transitif kepada commit release Baileys 6.7.8 yang direkodkan upstream.
- `use_baileys7.*` kini menolak aktivasi pada runtime Node 18.
- Betulkan startup deadlock upstream: method call kembali selepas Node thread dilancarkan.
- Betulkan bridge Flutter → Node kepada `_EVENTS_` envelope.
- Serialize command Node melalui `commandChain`.
- Flutter kini menunggu `engine.booted` dan `engine.ready`.
- Native exit/start failure dihantar ke Flutter.
- `nodejs-project/` dijadikan satu source of truth; Android assets dijana oleh Gradle.
- Android asset merge/compress tasks explicitly depend on `prepareEarlCastNodeProject`, removing a generated-assets race on parallel Gradle builds.
- Startup-event buffer uses Kotlin `ArrayDeque.add(...)` for Kotlin stdlib compatibility.
- npm install/CI staging + security verify dipindahkan ke Gradle task.
- Disable lifecycle scripts pihak ketiga semasa npm staging; Gradle hanya menjalankan security backport EarlCast yang diaudit kemudian verify.
- Fail-fast pada host Node.js <18 dalam Gradle dan build scripts.
- Buang dot-prefixed npm files/directories sebelum Android asset manifest dijana untuk elak `file.list` merujuk asset yang AAPT abaikan.
- Build scripts standard tidak lagi memerlukan Python/bootstrap; `flutter pub get` + Gradle build mengurus runtime/dependencies sendiri.
- Tambah Node asset fingerprint + file list untuk copy runtime.
- Upgrade pin toolchain kepada Gradle 8.14.5, AGP 8.11.1, Kotlin 2.2.20.
- Pin direct Flutter/Node dependencies.
- Betulkan `groupsLoading` pada command failure.
- Bootstrap tidak lagi menjalankan `flutter create` yang boleh menimpa fix.
- Kekalkan fix splash `@color/launch_background`.

## 1.0.1 — Build resource fix — 2026-08-07

- Betulkan `launch_background.xml` daripada literal hex kepada color resource.
- Selaraskan app NDK kepada `28.2.13676358`.

## 1.0.0

- Flutter Android foreground-only POC.
- Pairing, session, group selection, media composer, controlled queue, history dan auto-reply.
