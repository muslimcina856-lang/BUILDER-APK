# Backport Keselamatan Baileys Legacy

Manifest lalai EarlCast menggunakan `baileys@6.7.8` sebagai laluan keserasian Node 18.

Versi Baileys sebelum 6.7.22 terjejas oleh advisory kritikal:

```text
GHSA-qvv5-jq5g-4cgg
CVE-2026-48063
```

Kesan advisory termasuk event mesej palsu, history sync palsu dan manipulasi app-state melalui `protocolMessage` yang direka khas.

## Mekanisme projek

Semasa `npm install`, npm menjalankan:

```text
node scripts/apply_security_backport.cjs
```

Skrip tersebut:

1. Mencari `lib/Utils/process-message.js` dalam package Baileys yang dipasang.
2. Menyisipkan guard self-only berdasarkan patch rasmi WhiskeySockets commit `3beb08eecfcb4e65722e674034bd84fb11a9de35`.
3. Menambah marker `EARLCAST_CVE_2026_48063_BACKPORT`.
4. Menghentikan pemasangan jika struktur source tidak dikenali.
5. Membenarkan `npm run check` mengesahkan marker selepas pemasangan.

Kod socket EarlCast turut:

- Menetapkan `shouldSyncHistoryMessage: () => false`.
- Menetapkan `syncFullHistory: false`.
- Menolak `messages.upsert` yang mempunyai `requestId` daripada laluan auto-reply.

## Pengesahan

Selepas setup:

```powershell
cd nodejs-project
npm install
npm run check
```

Build mesti gagal jika backport tiada.

## Had jaminan

Backport ini mengadaptasi pembaikan rasmi bagi isu tertentu sahaja. Ia tidak membawa semua perubahan keselamatan, kestabilan atau protokol daripada Baileys 6.7.22/7.x. EarlCast kekal proof-of-concept dan tidak patut dianggap production-grade.

Baileys 6.7.22 dan versi terkini memerlukan Node 20, sedangkan runtime mobile stock yang digunakan projek ini berada pada Node 18. Migrasi penuh perlu menggunakan runtime Node.js Mobile 20/22 custom dan pengujian semula dependency Android.
