package com.example.reportmail_ekik

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
