package com.fatezou.da1scraper;
import io.flutter.embedding.android.FlutterActivity;
public class MainActivity extends FlutterActivity {}
