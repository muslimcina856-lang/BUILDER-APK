Letakkan runtime-pack.zip ARM64 di folder ini sebelum build edisi Full jika mahu pemasangan automatik pada pelancaran pertama.
Fail runtime sebenar tidak disertakan dalam arkib sumber ini.
