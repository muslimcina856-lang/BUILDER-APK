#!/usr/bin/env bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
MOBILE="$ROOT/mobile"
DIST="$ROOT/dist/full"
command -v flutter >/dev/null 2>&1 || { echo "Flutter SDK tidak ditemui." >&2; exit 1; }
"$ROOT/scripts/check_project.sh"
if [[ ! -f "$MOBILE/assets/linux/full/runtime-pack.zip" ]]; then
  echo "Amaran: runtime-pack.zip belum dibundel. APK tetap dibina tetapi Linux Workspace perlukan runtime pack." >&2
fi
mkdir -p "$DIST"
cd "$MOBILE"
flutter pub get
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk "$DIST/AiMultiAgent-Full-1.0.0.apk"
(cd "$DIST" && sha256sum ./* > SHA256SUMS.txt)
echo "Edisi Full siap: $DIST"
