#!/usr/bin/env python3
from pathlib import Path
import sys, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []
def require(cond, msg):
    if not cond: errors.append(msg)

pubspec = (ROOT / "mobile/pubspec.yaml").read_text(encoding="utf-8")
build = (ROOT / "mobile/android/app/build.gradle.kts").read_text(encoding="utf-8")
manifest_path = ROOT / "mobile/android/app/src/main/AndroidManifest.xml"
manifest = manifest_path.read_text(encoding="utf-8")

require("version: 1.0.0+1" in pubspec, "Versi mesti 1.0.0+1")
require("compileSdk = 36" in build, "compileSdk mesti 36")
require('applicationId = "com.aiauto.claw.full"' in build, "applicationId tidak tepat")
require("targetSdk = 28" in build, "targetSdk tidak tepat")
require('FULL_LINUX_EDITION", "true"' in build, "Flag edisi tidak tepat")
require("MANAGE_EXTERNAL_STORAGE" not in manifest, "MANAGE_EXTERNAL_STORAGE tidak dibenarkan")
require("READ_EXTERNAL_STORAGE" not in manifest, "READ_EXTERNAL_STORAGE tidak dibenarkan")
require("WRITE_EXTERNAL_STORAGE" not in manifest, "WRITE_EXTERNAL_STORAGE tidak dibenarkan")
require((ROOT / "mobile/lib/main.dart").exists(), "main.dart tiada")
require((ROOT / "mobile/lib/src/services/provider_service.dart").exists(), "Provider service tiada")
require((ROOT / "mobile/lib/src/services/tool_engine.dart").exists(), "Tool engine tiada")
require((ROOT / "mobile/lib/src/services/duckduckgo_search_service.dart").exists(), "DuckDuckGo service tiada")
require("AppEdition.full" in (ROOT / "mobile/lib/main.dart").read_text(), "main.dart bukan Full")
require(not (ROOT / "mobile/android/app/src/play").exists(), "Resource Play masih ada")
require("android:extractNativeLibs=\"true\"" in manifest, "extractNativeLibs Full tiada")
try:
    ET.parse(manifest_path)
except Exception as exc:
    errors.append(f"AndroidManifest.xml tidak sah: {exc}")

if errors:
    print("SEMAKAN GAGAL")
    for item in errors: print("-", item)
    sys.exit(1)
print("SEMAKAN LULUS: Ai MultiAgent Full")
