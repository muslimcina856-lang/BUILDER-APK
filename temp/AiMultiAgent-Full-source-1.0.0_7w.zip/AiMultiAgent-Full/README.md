# Ai MultiAgent Full

Aplikasi Android BYOK dengan Linux Workspace private. Package ID `com.aiauto.claw.full`, versi `1.0.0+1`, `compileSdk 36`, `targetSdk 28`.

## Build

```bash
./scripts/build_debug.sh
./scripts/build_full.sh
```

Semua rootfs, pakej, browser, projek dan cache Linux disimpan dalam storan dalaman private aplikasi. Tiada akses pukal ke storan luaran. Letakkan `runtime-pack.zip` dalam `mobile/assets/linux/full/` untuk membundel runtime PRoot/Debian.
