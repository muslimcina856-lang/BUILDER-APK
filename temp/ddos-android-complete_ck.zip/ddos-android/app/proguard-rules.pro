# OkHttp
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
-dontwarn okhttp3.**

# Kotlin
-keep class kotlin.** { *; }
-keep interface kotlin.** { *; }
-dontwarn kotlin.**

# Coroutines
-keep class kotlinx.coroutines.** { *; }
-keep interface kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**

# Android Support
-keep class androidx.** { *; }
-keep interface androidx.** { *; }

# Keep our classes
-keep class com.security.ddos.** { *; }
-keep interface com.security.ddos.** { *; }

# Prevent renaming
-keepnames class com.security.ddos.**

# Keep line numbers for debugging
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
