import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/storage/native_bridge.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/github_branch.dart';
import '../../models/github_repo.dart';
import '../../state/app_scope.dart';
import '../widgets/panel.dart';
import '../widgets/status_pill.dart';
import 'force_push_screen.dart';
import 'repo_actions_screen.dart';
import 'repo_code_screen.dart';
import 'repo_issues_screen.dart';

class RepoDetailScreen extends StatefulWidget {
  const RepoDetailScreen({required this.repo, super.key});

  final GitHubRepo repo;

  @override
  State<RepoDetailScreen> createState() => _RepoDetailScreenState();
}

class _RepoDetailScreenState extends State<RepoDetailScreen> {
  late GitHubRepo _repo;
  List<GitHubBranch> _branches = const [];
  String _branch = '';
  bool _loading = true;
  bool _downloading = false;
  int _downloadPercent = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _repo = widget.repo;
    _branch = widget.repo.defaultBranch;
    _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    try {
      final api = AppScope.of(context, listen: false).api;
      final results = await Future.wait<dynamic>(<Future<dynamic>>[
        api.getRepository(_repo.owner, _repo.name),
        api.listBranches(_repo.owner, _repo.name),
      ]);
      if (!mounted) return;
      final updatedRepo = results[0] as GitHubRepo;
      final branches = results[1] as List<GitHubBranch>;
      setState(() {
        _repo = updatedRepo;
        _branches = branches;
        if (branches.isNotEmpty && !branches.any((item) => item.name == _branch)) {
          _branch = branches.any((item) => item.name == updatedRepo.defaultBranch)
              ? updatedRepo.defaultBranch
              : branches.first.name;
        }
        _error = null;
      });
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _editRepository() async {
    final updated = await showModalBottomSheet<GitHubRepo>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _EditRepositorySheet(repo: _repo),
    );
    if (updated != null && mounted) {
      setState(() => _repo = updated);
      await AppScope.of(context, listen: false).refreshRepositories();
    }
  }

  Future<void> _deleteRepository() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => _DeleteRepositoryDialog(fullName: _repo.fullName),
    );
    if (confirmed != true || !mounted) return;
    try {
      final app = AppScope.of(context, listen: false);
      await app.api.deleteRepository(_repo.owner, _repo.name);
      await app.refreshRepositories();
      if (mounted) Navigator.pop(context);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    }
  }

  Future<void> _downloadRepository() async {
    if (_downloading) return;
    final ref = _branch.isEmpty ? _repo.defaultBranch : _branch;
    if (ref.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Repository ini belum mempunyai branch.')),
      );
      return;
    }

    setState(() {
      _downloading = true;
      _downloadPercent = 0;
    });
    File? temporaryFile;
    try {
      final safeRepo = _repo.name.replaceAll(RegExp(r'[^A-Za-z0-9._-]+'), '-');
      final safeRef = ref.replaceAll(RegExp(r'[^A-Za-z0-9._-]+'), '-');
      final fileName = '$safeRepo-$safeRef.zip';
      temporaryFile = File(
        '${Directory.systemTemp.path}/forgedeck-'
        '${DateTime.now().microsecondsSinceEpoch}-$fileName',
      );

      await AppScope.of(context, listen: false).api.downloadRepositoryArchive(
            _repo.owner,
            _repo.name,
            ref: ref,
            destinationPath: temporaryFile.path,
            onReceiveProgress: (received, total) {
              if (!mounted || total <= 0) return;
              final percent = ((received / total) * 100).clamp(0, 100).round();
              if (percent != _downloadPercent) {
                setState(() => _downloadPercent = percent);
              }
            },
          );
      final savedName = await NativeBridge.saveFile(
        path: temporaryFile.path,
        name: fileName,
        mimeType: 'application/zip',
      );
      if (!mounted || savedName == null) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$savedName telah disimpan.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    } finally {
      try {
        if (temporaryFile?.existsSync() == true) {
          temporaryFile!.deleteSync();
        }
      } catch (_) {
        // Fail sementara akan dibersihkan oleh sistem jika ia masih digunakan.
      }
      if (mounted) {
        setState(() {
          _downloading = false;
          _downloadPercent = 0;
        });
      }
    }
  }

  Future<void> _openForcePush() async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(
        builder: (_) => ForcePushScreen(
          repo: _repo,
          branches: _branches,
          initialBranch: _branch,
        ),
      ),
    );
    if (result == true) await _load();
  }

  Future<void> _manageBranches() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _BranchManagerSheet(
        repo: _repo,
        branches: _branches,
        selectedBranch: _branch,
      ),
    );
    if (!mounted) return;
    await _load();
    if (selected != null && mounted) setState(() => _branch = selected);
  }

  Future<void> _manageReleases() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _ReleaseManagerSheet(repo: _repo, branch: _branch),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        body: NestedScrollView(
          headerSliverBuilder: (context, innerScrolled) => <Widget>[
            SliverAppBar(
              pinned: true,
              titleSpacing: 0,
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    _repo.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  Text(
                    _repo.owner,
                    style: const TextStyle(color: AppColors.muted, fontSize: 11),
                  ),
                ],
              ),
              actions: <Widget>[
                IconButton(
                  onPressed: _downloading ? null : _downloadRepository,
                  tooltip: 'Muat turun ZIP',
                  icon: _downloading
                      ? SizedBox(
                          width: 30,
                          height: 30,
                          child: Stack(
                            alignment: Alignment.center,
                            children: <Widget>[
                              CircularProgressIndicator(
                                value: _downloadPercent / 100,
                                strokeWidth: 2.4,
                              ),
                              Text(
                                '$_downloadPercent%',
                                style: const TextStyle(
                                  fontSize: 7,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ],
                          ),
                        )
                      : const Icon(Icons.download_rounded),
                ),
                IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
                PopupMenuButton<String>(
                  onSelected: (value) {
                    switch (value) {
                      case 'force':
                        _openForcePush();
                        break;
                      case 'branches':
                        _manageBranches();
                        break;
                      case 'releases':
                        _manageReleases();
                        break;
                      case 'edit':
                        _editRepository();
                        break;
                      case 'delete':
                        _deleteRepository();
                        break;
                    }
                  },
                  itemBuilder: (_) => const <PopupMenuEntry<String>>[
                    PopupMenuItem(value: 'force', child: Text('Force push ZIP')),
                    PopupMenuItem(value: 'branches', child: Text('Urus branch')),
                    PopupMenuItem(value: 'releases', child: Text('Urus release')),
                    PopupMenuItem(value: 'edit', child: Text('Tetapan repository')),
                    PopupMenuDivider(),
                    PopupMenuItem(value: 'delete', child: Text('Padam repository')),
                  ],
                ),
              ],
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: <Widget>[
                        StatusPill(
                          label: _repo.isPrivate ? 'Private' : 'Public',
                          color: _repo.isPrivate
                              ? const Color(0xFFB79CFF)
                              : AppColors.accent,
                          icon: _repo.isPrivate
                              ? Icons.lock_outline_rounded
                              : Icons.public_rounded,
                        ),
                        if (_repo.isArchived)
                          const StatusPill(
                            label: 'Arkib',
                            color: AppColors.warning,
                            icon: Icons.inventory_2_outlined,
                          ),
                        if (_repo.canPush)
                          const StatusPill(
                            label: 'Write access',
                            icon: Icons.edit_outlined,
                          ),
                      ],
                    ),
                    if (_repo.description.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 14),
                      Text(
                        _repo.description,
                        style: const TextStyle(color: AppColors.muted, height: 1.45),
                      ),
                    ],
                    const SizedBox(height: 15),
                    InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: _branches.isEmpty ? null : _manageBranches,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.line),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            const Icon(Icons.call_split_rounded, size: 18),
                            const SizedBox(width: 8),
                            Text(_branch.isEmpty ? 'Tiada branch' : _branch),
                            const SizedBox(width: 8),
                            const Icon(Icons.expand_more_rounded, color: AppColors.muted),
                          ],
                        ),
                      ),
                    ),
                    if (_error != null) ...<Widget>[
                      const SizedBox(height: 12),
                      Text(_error!, style: const TextStyle(color: AppColors.danger)),
                    ],
                  ],
                ),
              ),
            ),
            SliverPersistentHeader(
              pinned: true,
              delegate: _TabHeaderDelegate(
                const TabBar(
                  isScrollable: true,
                  tabAlignment: TabAlignment.start,
                  tabs: <Widget>[
                    Tab(text: 'Ringkasan'),
                    Tab(text: 'Kod'),
                    Tab(text: 'Isu dan PR'),
                    Tab(text: 'Actions'),
                  ],
                ),
              ),
            ),
          ],
          body: _loading && _branches.isEmpty
              ? const Center(child: CircularProgressIndicator())
              : TabBarView(
                  children: <Widget>[
                    _OverviewTab(
                      repo: _repo,
                      branches: _branches,
                      onBranches: _manageBranches,
                      onReleases: _manageReleases,
                      onForcePush: _openForcePush,
                    ),
                    RepoCodeScreen(repo: _repo, branch: _branch),
                    RepoIssuesScreen(
                      repo: _repo,
                      branch: _branch,
                      branches: _branches,
                    ),
                    RepoActionsScreen(repo: _repo, branch: _branch),
                  ],
                ),
        ),
      ),
    );
  }
}

class _DeleteRepositoryDialog extends StatefulWidget {
  const _DeleteRepositoryDialog({required this.fullName});

  final String fullName;

  @override
  State<_DeleteRepositoryDialog> createState() => _DeleteRepositoryDialogState();
}

class _DeleteRepositoryDialogState extends State<_DeleteRepositoryDialog> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _copyName() async {
    await Clipboard.setData(ClipboardData(text: widget.fullName));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Nama repository disalin.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Padam repository?'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Text(
                  'Tindakan ini kekal. Taip ${widget.fullName} untuk sahkan.',
                ),
              ),
              const SizedBox(width: 4),
              IconButton(
                onPressed: _copyName,
                tooltip: 'Salin nama repository',
                visualDensity: VisualDensity.compact,
                constraints: const BoxConstraints.tightFor(width: 36, height: 36),
                icon: const Icon(Icons.copy_rounded, size: 18),
              ),
            ],
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _controller,
            autofocus: true,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(labelText: 'Nama penuh repository'),
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            FocusManager.instance.primaryFocus?.unfocus();
            Navigator.pop(context, false);
          },
          child: const Text('Batal'),
        ),
        FilledButton(
          onPressed: _controller.text.trim() == widget.fullName
              ? () {
                  FocusManager.instance.primaryFocus?.unfocus();
                  Navigator.pop(context, true);
                }
              : null,
          style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
          child: const Text('Padam kekal'),
        ),
      ],
    );
  }
}

class _OverviewTab extends StatelessWidget {
  const _OverviewTab({
    required this.repo,
    required this.branches,
    required this.onBranches,
    required this.onReleases,
    required this.onForcePush,
  });

  final GitHubRepo repo;
  final List<GitHubBranch> branches;
  final VoidCallback onBranches;
  final VoidCallback onReleases;
  final VoidCallback onForcePush;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 90),
      children: <Widget>[
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.5,
          children: <Widget>[
            _Stat(icon: Icons.star_border_rounded, label: 'Bintang', value: compactNumber(repo.stargazersCount)),
            _Stat(icon: Icons.call_split_rounded, label: 'Fork', value: compactNumber(repo.forksCount)),
            _Stat(icon: Icons.adjust_rounded, label: 'Isu terbuka', value: compactNumber(repo.openIssuesCount)),
            _Stat(icon: Icons.account_tree_outlined, label: 'Branch', value: branches.length.toString()),
          ],
        ),
        const SizedBox(height: 14),
        Panel(
          child: Column(
            children: <Widget>[
              _ActionRow(
                icon: Icons.account_tree_outlined,
                title: 'Branch',
                subtitle: '${branches.length} branch tersedia',
                onTap: onBranches,
              ),
              const Divider(height: 1),
              _ActionRow(
                icon: Icons.sell_outlined,
                title: 'Release',
                subtitle: 'Lihat atau cipta release',
                onTap: onReleases,
              ),
              const Divider(height: 1),
              _ActionRow(
                icon: Icons.upload_file_outlined,
                title: 'Force push daripada ZIP',
                subtitle: 'Ganti keseluruhan kandungan branch',
                color: AppColors.warning,
                onTap: onForcePush,
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Maklumat', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 14),
              _Info(label: 'Default branch', value: repo.defaultBranch),
              _Info(label: 'Bahasa utama', value: repo.language.isEmpty ? 'Tidak dikesan' : repo.language),
              _Info(label: 'Kemas kini', value: timeAgo(repo.updatedAt)),
              _Info(label: 'Akses push', value: repo.canPush ? 'Dibenarkan' : 'Tiada'),
              _Info(label: 'Akses admin', value: repo.canAdmin ? 'Dibenarkan' : 'Tiada'),
            ],
          ),
        ),
      ],
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Panel(
      padding: const EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Icon(icon, color: AppColors.accent, size: 20),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(value, style: Theme.of(context).textTheme.titleLarge),
              Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.color = AppColors.accent,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: color),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: onTap,
    );
  }
}

class _Info extends StatelessWidget {
  const _Info({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 11),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.muted))),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _TabHeaderDelegate extends SliverPersistentHeaderDelegate {
  _TabHeaderDelegate(this.tabBar);

  final TabBar tabBar;

  @override
  double get minExtent => tabBar.preferredSize.height;

  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: AppColors.background,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: tabBar,
    );
  }

  @override
  bool shouldRebuild(covariant _TabHeaderDelegate oldDelegate) => false;
}

class _EditRepositorySheet extends StatefulWidget {
  const _EditRepositorySheet({required this.repo});

  final GitHubRepo repo;

  @override
  State<_EditRepositorySheet> createState() => _EditRepositorySheetState();
}

class _EditRepositorySheetState extends State<_EditRepositorySheet> {
  late final TextEditingController _name;
  late final TextEditingController _description;
  late bool _private;
  late bool _archived;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.repo.name);
    _description = TextEditingController(text: widget.repo.description);
    _private = widget.repo.isPrivate;
    _archived = widget.repo.isArchived;
  }

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      final updated = await AppScope.of(context, listen: false).api.updateRepository(
            widget.repo.owner,
            widget.repo.name,
            name: _name.text.trim(),
            description: _description.text.trim(),
            isPrivate: _private,
            archived: _archived,
          );
      if (mounted) Navigator.pop(context, updated);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString())),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        8,
        20,
        MediaQuery.viewInsetsOf(context).bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Tetapan repository', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 18),
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Nama')),
          const SizedBox(height: 12),
          TextField(
            controller: _description,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'Penerangan'),
          ),
          SwitchListTile.adaptive(
            contentPadding: EdgeInsets.zero,
            title: const Text('Private'),
            value: _private,
            onChanged: (value) => setState(() => _private = value),
          ),
          SwitchListTile.adaptive(
            contentPadding: EdgeInsets.zero,
            title: const Text('Arkibkan repository'),
            value: _archived,
            onChanged: (value) => setState(() => _archived = value),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: const Icon(Icons.save_outlined),
            label: const Text('Simpan perubahan'),
          ),
        ],
      ),
    );
  }
}

class _BranchManagerSheet extends StatefulWidget {
  const _BranchManagerSheet({
    required this.repo,
    required this.branches,
    required this.selectedBranch,
  });

  final GitHubRepo repo;
  final List<GitHubBranch> branches;
  final String selectedBranch;

  @override
  State<_BranchManagerSheet> createState() => _BranchManagerSheetState();
}

class _BranchManagerSheetState extends State<_BranchManagerSheet> {
  late List<GitHubBranch> _branches;
  late String _selected;
  late String _defaultBranch;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _branches = List<GitHubBranch>.from(widget.branches);
    _selected = widget.selectedBranch;
    _defaultBranch = widget.repo.defaultBranch;
  }

  Future<void> _create() async {
    if (_branches.isEmpty) return;
    final name = await _prompt('Branch baharu', 'Nama branch');
    if (name == null || name.trim().isEmpty) return;
    setState(() => _busy = true);
    try {
      final source = _branches.firstWhere(
        (item) => item.name == _selected,
        orElse: () => _branches.first,
      );
      final api = AppScope.of(context, listen: false).api;
      await api.createBranch(
        widget.repo.owner,
        widget.repo.name,
        name: name.trim(),
        sourceSha: source.sha,
      );
      _branches = await api.listBranches(widget.repo.owner, widget.repo.name);
      if (mounted) setState(() {});
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<String?> _prompt(String title, String label) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: TextField(controller: controller, autofocus: true, decoration: InputDecoration(labelText: label)),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text), child: const Text('Cipta')),
        ],
      ),
    );
    controller.dispose();
    return value;
  }

  Future<void> _setDefault(GitHubBranch branch) async {
    setState(() => _busy = true);
    try {
      await AppScope.of(context, listen: false).api.updateRepository(
            widget.repo.owner,
            widget.repo.name,
            defaultBranch: branch.name,
          );
      if (mounted) setState(() => _defaultBranch = branch.name);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString())),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete(GitHubBranch branch) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Padam branch ${branch.name}?'),
        content: const Text('Ref branch akan dipadam dari GitHub.'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _busy = true);
    try {
      final api = AppScope.of(context, listen: false).api;
      await api.deleteBranch(widget.repo.owner, widget.repo.name, branch.name);
      _branches = await api.listBranches(widget.repo.owner, widget.repo.name);
      if (_selected == branch.name && _branches.isNotEmpty) {
        _selected = _branches.first.name;
      }
      if (mounted) setState(() {});
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(child: Text('Branch', style: Theme.of(context).textTheme.titleLarge)),
                IconButton(onPressed: _busy ? null : _create, icon: const Icon(Icons.add_rounded)),
              ],
            ),
            const SizedBox(height: 8),
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 420),
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: _branches.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final branch = _branches[index];
                  final isDefault = branch.name == _defaultBranch;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      branch.name == _selected ? Icons.radio_button_checked : Icons.radio_button_off,
                      color: branch.name == _selected ? AppColors.accent : AppColors.muted,
                    ),
                    title: Text(branch.name),
                    subtitle: Text(branch.protected ? 'Protected' : isDefault ? 'Default branch' : branch.sha.length > 7 ? branch.sha.substring(0, 7) : branch.sha),
                    onTap: () {
                      setState(() => _selected = branch.name);
                      Navigator.pop(context, branch.name);
                    },
                    trailing: isDefault
                        ? null
                        : PopupMenuButton<String>(
                            enabled: !_busy,
                            onSelected: (value) {
                              if (value == 'default') _setDefault(branch);
                              if (value == 'delete') _delete(branch);
                            },
                            itemBuilder: (_) => const <PopupMenuEntry<String>>[
                              PopupMenuItem(
                                value: 'default',
                                child: Text('Jadikan default'),
                              ),
                              PopupMenuItem(
                                value: 'delete',
                                child: Text('Padam branch'),
                              ),
                            ],
                          ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReleaseManagerSheet extends StatefulWidget {
  const _ReleaseManagerSheet({required this.repo, required this.branch});

  final GitHubRepo repo;
  final String branch;

  @override
  State<_ReleaseManagerSheet> createState() => _ReleaseManagerSheetState();
}

class _ReleaseManagerSheetState extends State<_ReleaseManagerSheet> {
  List<Map<String, dynamic>> _releases = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      _releases = await AppScope.of(context, listen: false).api.listReleases(
            widget.repo.owner,
            widget.repo.name,
          );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _delete(Map<String, dynamic> release) async {
    final releaseId = release['id'] as int?;
    if (releaseId == null) return;
    final label = release['name'] as String? ??
        release['tag_name'] as String? ??
        'release ini';
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Padam release?'),
        content: Text('$label akan dipadam. Tag Git tidak dipadam secara automatik.'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await AppScope.of(context, listen: false).api.deleteRelease(
            widget.repo.owner,
            widget.repo.name,
            releaseId,
          );
      await _load();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString())),
        );
      }
    }
  }

  Future<void> _create() async {
    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (_) => const _CreateReleaseDialog(),
    );
    if (result == null || !mounted) return;
    try {
      await AppScope.of(context, listen: false).api.createRelease(
            widget.repo.owner,
            widget.repo.name,
            tagName: result['tag']!,
            name: result['name']!,
            body: result['body']!,
            targetCommitish: widget.branch,
          );
      await _load();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(child: Text('Release', style: Theme.of(context).textTheme.titleLarge)),
                IconButton(onPressed: _create, icon: const Icon(Icons.add_rounded)),
              ],
            ),
            const SizedBox(height: 8),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_releases.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: Text('Belum ada release.', style: TextStyle(color: AppColors.muted))),
              )
            else
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 420),
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: _releases.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final release = _releases[index];
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.sell_outlined, color: AppColors.accent),
                      title: Text(release['name'] as String? ?? release['tag_name'] as String? ?? 'Release'),
                      subtitle: Text(release['tag_name'] as String? ?? ''),
                      trailing: IconButton(
                        onPressed: () => _delete(release),
                        icon: const Icon(
                          Icons.delete_outline_rounded,
                          color: AppColors.danger,
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _CreateReleaseDialog extends StatefulWidget {
  const _CreateReleaseDialog();

  @override
  State<_CreateReleaseDialog> createState() => _CreateReleaseDialogState();
}

class _CreateReleaseDialogState extends State<_CreateReleaseDialog> {
  final _tag = TextEditingController();
  final _name = TextEditingController();
  final _body = TextEditingController();

  @override
  void dispose() {
    _tag.dispose();
    _name.dispose();
    _body.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Cipta release'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextField(controller: _tag, decoration: const InputDecoration(labelText: 'Tag, contoh v1.0.0')),
            const SizedBox(height: 10),
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Nama release')),
            const SizedBox(height: 10),
            TextField(controller: _body, maxLines: 4, decoration: const InputDecoration(labelText: 'Nota release')),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
        FilledButton(
          onPressed: () {
            if (_tag.text.trim().isEmpty) return;
            Navigator.pop(context, <String, String>{
              'tag': _tag.text.trim(),
              'name': _name.text.trim(),
              'body': _body.text.trim(),
            });
          },
          child: const Text('Cipta'),
        ),
      ],
    );
  }
}
