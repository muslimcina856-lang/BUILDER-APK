class DeviceModel {
  final String deviceName;
  final String manufacturer;
  final String androidVersion;
  final int batteryLevel;
  final String batteryStatus;
  final bool isCharging;
  final String uid;
  final String username;
  final DateTime timestamp;
  
  DeviceModel({
    required this.deviceName,
    required this.manufacturer,
    required this.androidVersion,
    required this.batteryLevel,
    required this.batteryStatus,
    required this.isCharging,
    required this.uid,
    required this.username,
    required this.timestamp,
  });
}