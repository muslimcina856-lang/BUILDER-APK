import 'package:flutter/material.dart';

class AppTheme {
  static final darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: const Color(0xFF1A237E),
    scaffoldBackgroundColor: const Color(0xFF1A1A2E),
    fontFamily: 'Poppins',
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.w600,
      ),
    ),
    colorScheme: const ColorScheme.dark(
      primary: Color(0xFF1A237E),
      secondary: Color(0xFF3949AB),
      surface: Color(0xFF2A2A3E),
      background: Color(0xFF1A1A2E),
    ),
  );
}