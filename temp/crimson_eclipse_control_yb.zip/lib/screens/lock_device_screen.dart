import 'package:flutter/material.dart';

class LockDeviceScreen extends StatefulWidget {
  const LockDeviceScreen({super.key});

  @override
  State<LockDeviceScreen> createState() => _LockDeviceScreenState();
}

class _LockDeviceScreenState extends State<LockDeviceScreen> {
  final TextEditingController _pinController = TextEditingController();
  String _selectedLocker = 'custom_locker';
  bool _isChatChecked = false;
  bool _isDeviceLocked = false;
  String _lockMessage = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      appBar: AppBar(
        title: Text(_isDeviceLocked ? 'DEVICE TERKUNCI' : 'LOCK DEVICE'),
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
        actions: [_isDeviceLocked ? TextButton.icon(onPressed: () => _showUnlockDialog(), icon: const Icon(Icons.lock_open, color: Colors.green), label: const Text('UNLOCK', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))) : const SizedBox()],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          if (!_isDeviceLocked)
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(16)),
              child: Column(children: [
                const Icon(Icons.lock, color: Color(0xFF3949AB), size: 60),
                const SizedBox(height: 16),
                const Text('LOCKER TYPE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Row(children: [Expanded(child: _buildLockerOption('CUSTOM LOCKER', 'custom_locker')), const SizedBox(width: 12), Expanded(child: _buildLockerOption('CUSTOM PIN', 'custom_pin'))]),
                const SizedBox(height: 20),
                if (_selectedLocker == 'custom_pin')
                  Container(decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(12)), child: TextField(controller: _pinController, keyboardType: TextInputType.number, obscureText: true, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(hintText: 'Masukkan PIN (4-6 digit)', hintStyle: TextStyle(color: Colors.white54), border: InputBorder.none, contentPadding: EdgeInsets.all(16)))),
                const SizedBox(height: 20),
                Row(children: [Checkbox(value: _isChatChecked, onChanged: (value) => setState(() => _isChatChecked = value ?? false), activeColor: const Color(0xFF3949AB)), const Text('CHAT DENGAN TARGET', style: TextStyle(color: Colors.white))]),
                const SizedBox(height: 20),
                ElevatedButton(onPressed: () => _lockDevice(), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF3949AB), padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), minimumSize: const Size(double.infinity, 50)), child: const Text('KUNCI DEVICE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
              ]),
            ),
          if (_isDeviceLocked)
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.red.withOpacity(0.5))),
              child: Column(children: [
                const Icon(Icons.lock, color: Colors.red, size: 70),
                const SizedBox(height: 16),
                const Text('DEVICE TELAH DIKUNCI!', style: TextStyle(color: Colors.red, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), borderRadius: BorderRadius.circular(12)), child: Column(children: [const Text('🛡️', style: TextStyle(fontSize: 40)), const SizedBox(height: 8), Text(_lockMessage, style: const TextStyle(color: Colors.white, fontSize: 14), textAlign: TextAlign.center)])),
                const SizedBox(height: 24),
                ElevatedButton.icon(onPressed: () => _showUnlockDialog(), icon: const Icon(Icons.lock_open), label: const Text('UNLOCK DEVICE'), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), minimumSize: const Size(double.infinity, 50))),
              ]),
            ),
        ]),
      ),
    );
  }

  Widget _buildLockerOption(String title, String value) {
    return GestureDetector(
      onTap: () => setState(() => _selectedLocker = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(color: _selectedLocker == value ? const Color(0xFF3949AB) : const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3))),
        child: Center(child: Text(title, style: TextStyle(color: _selectedLocker == value ? Colors.white : Colors.white70, fontWeight: FontWeight.bold))),
      ),
    );
  }

  void _lockDevice() {
    String pin = _pinController.text.trim();
    if (_selectedLocker == 'custom_pin' && pin.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Masukkan PIN terlebih dahulu!'), backgroundColor: Colors.red));
      return;
    }
    String lockTypeText = _selectedLocker == 'custom_locker' ? 'CUSTOM LOCKER' : 'CUSTOM PIN ($pin)';
    String chatText = _isChatChecked ? '\n\n💬 Chat dengan target telah diaktifkan' : '';
    setState(() { _isDeviceLocked = true; _lockMessage = '🔒 Device dikunci menggunakan $lockTypeText$chatText\n\n🛡️ Silahkan hubungi administrator untuk membuka kunci!'; });
    _showLockNotification(lockTypeText);
  }

  void _showLockNotification(String lockType) {
    showDialog(context: context, barrierDismissible: false, builder: (context) => Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A1A2E), Color(0xFF2A2A3E)]), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.red.withOpacity(0.5), width: 1.5)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.lock, color: Colors.red, size: 60),
          const SizedBox(height: 16),
          const Text('🔒 DEVICE TERKUNCI', style: TextStyle(color: Colors.red, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Column(children: [const Text('🛡️', style: TextStyle(fontSize: 40)), const SizedBox(height: 8), Text('Device telah dikunci menggunakan $lockType', style: const TextStyle(color: Colors.white, fontSize: 14), textAlign: TextAlign.center), const SizedBox(height: 8), const Text('Silahkan hubungi administrator untuk membuka kunci!', style: TextStyle(color: Colors.white70, fontSize: 12), textAlign: TextAlign.center)])),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: Colors.red, padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('OK')),
        ]),
      ),
    ));
  }

  void _showUnlockDialog() {
    final TextEditingController unlockPinController = TextEditingController();
    bool isPinRequired = _selectedLocker == 'custom_pin';
    showDialog(context: context, barrierDismissible: false, builder: (context) => AlertDialog(
      backgroundColor: const Color(0xFF2A2A3E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('UNLOCK DEVICE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.lock_open, color: Colors.green, size: 50),
        const SizedBox(height: 16),
        const Text('Masukkan kredensial untuk membuka kunci device', style: TextStyle(color: Colors.white70), textAlign: TextAlign.center),
        if (isPinRequired) ...[const SizedBox(height: 16), Container(decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(12)), child: TextField(controller: unlockPinController, keyboardType: TextInputType.number, obscureText: true, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(hintText: 'Masukkan PIN untuk unlock', hintStyle: TextStyle(color: Colors.white54), border: InputBorder.none, contentPadding: EdgeInsets.all(16))))],
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('BATAL', style: TextStyle(color: Colors.white54))),
        ElevatedButton(onPressed: () {
          if (isPinRequired && unlockPinController.text.trim() != _pinController.text.trim()) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN salah!'), backgroundColor: Colors.red));
            return;
          }
          setState(() { _isDeviceLocked = false; _lockMessage = ''; });
          Navigator.pop(context);
          _showUnlockSuccessNotification();
        }, style: ElevatedButton.styleFrom(backgroundColor: Colors.green, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))), child: const Text('UNLOCK')),
      ],
    ));
  }

  void _showUnlockSuccessNotification() {
    showDialog(context: context, builder: (context) => Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A1A2E), Color(0xFF2A2A3E)]), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.green.withOpacity(0.5), width: 1.5)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.check_circle, color: Colors.green, size: 60),
          const SizedBox(height: 16),
          const Text('🔓 DEVICE TELAH DIBUKA', style: TextStyle(color: Colors.green, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          const Text('Device sudah dapat digunakan kembali', style: TextStyle(color: Colors.white, fontSize: 14), textAlign: TextAlign.center),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('OK')),
        ]),
      ),
    ));
  }
}