import 'package:flutter/material.dart';

class BlockedAppsScreen extends StatefulWidget {
  const BlockedAppsScreen({super.key});

  @override
  State<BlockedAppsScreen> createState() => _BlockedAppsScreenState();
}

class _BlockedAppsScreenState extends State<BlockedAppsScreen> {
  final List<Map<String, dynamic>> _apps = [
    {'name': 'FreeFire', 'package': 'com.dts.freefireth', 'blocked': false, 'icon': Icons.gamepad},
    {'name': 'Mobile Legends', 'package': 'com.mobile.legends', 'blocked': false, 'icon': Icons.games},
    {'name': 'WhatsApp', 'package': 'com.whatsapp', 'blocked': false, 'icon': Icons.chat},
    {'name': 'Instagram', 'package': 'com.instagram.android', 'blocked': false, 'icon': Icons.camera_alt},
    {'name': 'TikTok', 'package': 'com.zhiliaoapp.musically', 'blocked': false, 'icon': Icons.music_note},
    {'name': 'YouTube', 'package': 'com.google.android.youtube', 'blocked': false, 'icon': Icons.play_circle},
    {'name': 'Facebook', 'package': 'com.facebook.katana', 'blocked': false, 'icon': Icons.facebook},
    {'name': 'Telegram', 'package': 'org.telegram.messenger', 'blocked': false, 'icon': Icons.telegram},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      appBar: AppBar(
        title: const Text('BLOKIR APP TARGET'),
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
        actions: [
          TextButton(onPressed: () => _showBlockAllDialog(), child: const Text('BLOKIR SEMUA', style: TextStyle(color: Color(0xFF3949AB), fontWeight: FontWeight.bold))),
          TextButton(onPressed: () => _showUnblockAllDialog(), child: const Text('BUKA SEMUA', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
        ],
      ),
      body: Column(children: [
        Container(margin: const EdgeInsets.all(16), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3))), child: Row(children: [const Icon(Icons.info_outline, color: Color(0xFF3949AB), size: 20), const SizedBox(width: 12), Expanded(child: Text('Aktifkan switch untuk memblokir aplikasi di perangkat target', style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12)))])),
        Expanded(child: ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 16), itemCount: _apps.length, itemBuilder: (context, index) {
          final app = _apps[index];
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(16), border: Border.all(color: app['blocked'] ? Colors.red.withOpacity(0.5) : const Color(0xFF3949AB).withOpacity(0.3))),
            child: Row(children: [
              Container(width: 45, height: 45, decoration: BoxDecoration(color: app['blocked'] ? Colors.red.withOpacity(0.2) : const Color(0xFF1A237E).withOpacity(0.3), borderRadius: BorderRadius.circular(12)), child: Icon(app['icon'], color: app['blocked'] ? Colors.red : const Color(0xFF3949AB), size: 24)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(app['name'], style: TextStyle(color: app['blocked'] ? Colors.red : Colors.white, fontWeight: FontWeight.bold)), Text(app['package'], style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10))])),
              Switch(value: app['blocked'], onChanged: (value) { setState(() { app['blocked'] = value; }); if (value) { _showBlockNotification(app['name']); } else { _showUnblockNotification(app['name']); } }, activeColor: Colors.red, inactiveThumbColor: const Color(0xFF3949AB)),
            ]),
          );
        })),
      ]),
    );
  }

  void _showBlockNotification(String appName) {
    showDialog(context: context, barrierDismissible: false, builder: (context) => Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A1A2E), Color(0xFF2A2A3E)]), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.red.withOpacity(0.5), width: 1.5)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 70, height: 70, decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), shape: BoxShape.circle), child: const Icon(Icons.shield, color: Colors.red, size: 40)),
          const SizedBox(height: 16),
          const Text('BLOKIR AKTIF', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const SizedBox(height: 16),
          Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Column(children: [const Text('🛡️', style: TextStyle(fontSize: 40)), const SizedBox(height: 8), Text('Aplikasi $appName sudah di blokir!', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold), textAlign: TextAlign.center), const SizedBox(height: 8), const Text('Silahkan hubungi administrator untuk membuka blokir!', style: TextStyle(color: Colors.white70, fontSize: 14), textAlign: TextAlign.center)])),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: Colors.red, padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('OK')),
        ]),
      ),
    ));
  }

  void _showUnblockNotification(String appName) {
    showDialog(context: context, barrierDismissible: false, builder: (context) => Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A1A2E), Color(0xFF2A2A3E)]), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.green.withOpacity(0.5), width: 1.5)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 70, height: 70, decoration: BoxDecoration(color: Colors.green.withOpacity(0.2), shape: BoxShape.circle), child: const Icon(Icons.check_circle, color: Colors.green, size: 40)),
          const SizedBox(height: 16),
          const Text('BLOKIR DIBUKA', style: TextStyle(color: Colors.green, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const SizedBox(height: 16),
          Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.green.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Text('✅ Aplikasi $appName sudah tidak diblokir', style: const TextStyle(color: Colors.white, fontSize: 16), textAlign: TextAlign.center)),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('OK')),
        ]),
      ),
    ));
  }

  void _showBlockAllDialog() {
    showDialog(context: context, builder: (context) => AlertDialog(
      backgroundColor: const Color(0xFF2A2A3E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Blokir Semua Aplikasi?', style: TextStyle(color: Colors.white)),
      content: Text('Anda akan memblokir semua ${_apps.length} aplikasi. Lanjutkan?', style: TextStyle(color: Colors.white.withOpacity(0.7))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('BATAL', style: TextStyle(color: Colors.white54))),
        ElevatedButton(onPressed: () { setState(() { for (var app in _apps) { app['blocked'] = true; } }); Navigator.pop(context); _showBlockAllNotification(); }, style: ElevatedButton.styleFrom(backgroundColor: Colors.red, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))), child: const Text('BLOKIR SEMUA')),
      ],
    ));
  }

  void _showBlockAllNotification() {
    showDialog(context: context, barrierDismissible: false, builder: (context) => Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A1A2E), Color(0xFF2A2A3E)]), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.red.withOpacity(0.5), width: 1.5)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.shield, color: Colors.red, size: 60),
          const SizedBox(height: 16),
          const Text('🛡️', style: TextStyle(fontSize: 50)),
          const SizedBox(height: 8),
          const Text('SEMUA APLIKASI TELAH DIBLOKIR!', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          const SizedBox(height: 12),
          const Text('Silahkan hubungi administrator untuk membuka blokir!', style: TextStyle(color: Colors.white70, fontSize: 14), textAlign: TextAlign.center),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: Colors.red, padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('OK')),
        ]),
      ),
    ));
  }

  void _showUnblockAllDialog() {
    showDialog(context: context, builder: (context) => AlertDialog(
      backgroundColor: const Color(0xFF2A2A3E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Buka Blokir Semua Aplikasi?', style: TextStyle(color: Colors.white)),
      content: Text('Anda akan membuka blokir semua ${_apps.length} aplikasi. Lanjutkan?', style: TextStyle(color: Colors.white.withOpacity(0.7))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('BATAL', style: TextStyle(color: Colors.white54))),
        ElevatedButton(onPressed: () { setState(() { for (var app in _apps) { app['blocked'] = false; } }); Navigator.pop(context); _showUnblockAllNotification(); }, style: ElevatedButton.styleFrom(backgroundColor: Colors.green, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))), child: const Text('BUKA SEMUA')),
      ],
    ));
  }

  void _showUnblockAllNotification() {
    showDialog(context: context, barrierDismissible: false, builder: (context) => Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A1A2E), Color(0xFF2A2A3E)]), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.green.withOpacity(0.5), width: 1.5)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.check_circle, color: Colors.green, size: 60),
          const SizedBox(height: 16),
          const Text('SEMUA APLIKASI TELAH DIBUKA!', style: TextStyle(color: Colors.green, fontSize: 18, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          const SizedBox(height: 12),
          const Text('Semua aplikasi sudah dapat digunakan kembali', style: TextStyle(color: Colors.white70, fontSize: 14), textAlign: TextAlign.center),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: () => Navigator.pop(context), style: ElevatedButton.styleFrom(backgroundColor: Colors.green, padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('OK')),
        ]),
      ),
    ));
  }
}