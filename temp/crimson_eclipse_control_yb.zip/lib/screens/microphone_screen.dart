import 'package:flutter/material.dart';

class MicrophoneScreen extends StatefulWidget {
  const MicrophoneScreen({super.key});

  @override
  State<MicrophoneScreen> createState() => _MicrophoneScreenState();
}

class _MicrophoneScreenState extends State<MicrophoneScreen> with SingleTickerProviderStateMixin {
  bool _isListening = false;
  late AnimationController _waveController;
  late Animation<double> _waveAnimation;
  double _soundLevel = 0.0;
  
  final List<Map<String, dynamic>> _audioMessages = [
    {'text': 'Halo, ini pesan suara dari target', 'duration': '00:12', 'time': '10:30', 'isMe': false},
    {'text': 'Test microphone', 'duration': '00:08', 'time': '09:15', 'isMe': false},
  ];

  @override
  void initState() {
    super.initState();
    _waveController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    )..repeat(reverse: true);
    
    _waveAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _waveController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _waveController.dispose();
    super.dispose();
  }

  void _startListening() {
    setState(() {
      _isListening = true;
    });
    _simulateSoundLevel();
  }

  void _stopListening() {
    setState(() {
      _isListening = false;
      _soundLevel = 0.0;
    });
  }

  void _simulateSoundLevel() {
    if (!_isListening) return;
    setState(() {
      _soundLevel = 20 + (DateTime.now().millisecondsSinceEpoch % 80).toDouble();
    });
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_isListening) {
        _simulateSoundLevel();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      appBar: AppBar(
        title: const Text('MICROPHONE'),
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _isListening ? Icons.mic_off : Icons.mic,
              color: _isListening ? Colors.red : const Color(0xFF3949AB),
            ),
            onPressed: () {
              if (_isListening) {
                _stopListening();
              } else {
                _startListening();
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A3E),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  AnimatedBuilder(
                    animation: _waveAnimation,
                    builder: (context, child) {
                      return Transform.scale(
                        scale: _isListening ? _waveAnimation.value : 1.0,
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: _isListening ? Colors.red.withOpacity(0.2) : const Color(0xFF3949AB).withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.mic,
                            color: _isListening ? Colors.red : const Color(0xFF3949AB),
                            size: 40,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  Text(
                    _isListening ? 'MENDENGARKAN...' : 'TIDAK AKTIF',
                    style: TextStyle(
                      color: _isListening ? Colors.red : Colors.white54,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    height: 80,
                    width: double.infinity,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(20, (index) {
                        final height = _isListening ? (_soundLevel / 100) * 60 * (0.5 + (index % 5) / 5) : 5.0;
                        return Container(
                          width: 6,
                          height: height,
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          decoration: BoxDecoration(
                            color: _isListening ? Colors.red.withOpacity(0.5 + (height / 100)) : Colors.white.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(3),
                          ),
                        );
                      }),
                    ),
                  ),
                  const SizedBox(height: 20),
                  LinearProgressIndicator(
                    value: _soundLevel / 100,
                    backgroundColor: Colors.white.withOpacity(0.2),
                    valueColor: AlwaysStoppedAnimation<Color>(
                      _soundLevel > 70 ? Colors.red : _soundLevel > 40 ? Colors.orange : const Color(0xFF3949AB),
                    ),
                    borderRadius: BorderRadius.circular(10),
                    minHeight: 8,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Level Suara', style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12)),
                      Text('${_soundLevel.toInt()}%', style: TextStyle(color: _soundLevel > 70 ? Colors.red : Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: _isListening ? null : _startListening,
                    icon: const Icon(Icons.fiber_manual_record, color: Colors.red),
                    label: const Text('MULAI REKAM'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF3949AB),
                      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A3E),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.history, color: Color(0xFF3949AB), size: 20),
                      const SizedBox(width: 8),
                      const Text('RIWAYAT SUARA', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  if (_audioMessages.isEmpty)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.all(32),
                        child: Text('Belum ada pesan suara', style: TextStyle(color: Colors.white.withOpacity(0.5))),
                      ),
                    )
                  else
                    ..._audioMessages.map((message) => _buildAudioMessage(message)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAudioMessage(Map<String, dynamic> message) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFF3949AB).withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.play_arrow, color: Color(0xFF3949AB), size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(message['text'], style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(message['duration'], style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10)),
                    const SizedBox(width: 8),
                    Text(message['time'], style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10)),
                  ],
                ),
              ],
            ),
          ),
          Row(
            children: List.generate(8, (index) {
              return Container(
                width: 3,
                height: 8 + (index % 4) * 2,
                margin: const EdgeInsets.symmetric(horizontal: 1),
                decoration: BoxDecoration(
                  color: const Color(0xFF3949AB).withOpacity(0.5),
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            }),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.download, color: Color(0xFF3949AB), size: 20),
            onPressed: () {},
          ),
        ],
      ),
    );
  }
}