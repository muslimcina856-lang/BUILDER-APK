import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/config_service.dart';

class InfoScreen extends StatelessWidget {
  const InfoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFF2A2A3E),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: ConfigService.logoUrl.isNotEmpty
                        ? DecorationImage(
                            image: CachedNetworkImageProvider(ConfigService.logoUrl),
                            fit: BoxFit.cover,
                          )
                        : null,
                    gradient: ConfigService.logoUrl.isEmpty
                        ? const LinearGradient(
                            colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
                          )
                        : null,
                  ),
                  child: ConfigService.logoUrl.isEmpty
                      ? const Center(child: Text('CE', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)))
                      : null,
                ),
                const SizedBox(height: 16),
                Text(
                  ConfigService.appName,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                const SizedBox(height: 8),
                Text(
                  'Version ${ConfigService.version}',
                  style: TextStyle(color: Colors.white.withOpacity(0.5)),
                ),
                const SizedBox(height: 24),
                _buildInfoRow('Username', ConfigService.username),
                _buildInfoRow('Target UID', ConfigService.targetUid),
                _buildInfoRow('Target Username', ConfigService.targetUsername),
                _buildInfoRow('WebView URL', ConfigService.webviewUrl),
                _buildInfoRow('Developer', 'Crimson Team'),
                _buildInfoRow('License', 'Private Use Only'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF2A2A3E),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'About This App',
                  style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),
                Text(
                  '${ConfigService.appName} adalah Remote Administration Tool untuk monitoring dan kontrol perangkat jarak jauh. Gunakan dengan bijak dan hanya untuk perangkat yang Anda miliki.',
                  style: TextStyle(color: Colors.white.withOpacity(0.7), height: 1.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 14),
            ),
          ),
          Text(':', style: TextStyle(color: Colors.white.withOpacity(0.5))),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              value.isEmpty ? '-' : value,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}