import 'package:flutter/material.dart';

class GpsTrackerScreen extends StatefulWidget {
  const GpsTrackerScreen({super.key});

  @override
  State<GpsTrackerScreen> createState() => _GpsTrackerScreenState();
}

class _GpsTrackerScreenState extends State<GpsTrackerScreen> {
  bool _isLoading = true;
  bool _isTracking = false;
  
  // Simulasi data lokasi
  final Map<String, dynamic> _currentLocation = {
    'latitude': -6.2088,
    'longitude': 106.8456,
    'address': 'Jl. Sudirman No. 123, Jakarta Pusat',
    'timestamp': DateTime.now(),
    'speed': 5.2,
    'accuracy': 10.0,
  };
  
  final List<Map<String, dynamic>> _locationHistory = [
    {'address': 'Jl. Sudirman No. 120', 'time': '10:30', 'speed': '4.5 km/h'},
    {'address': 'Jl. Sudirman No. 121', 'time': '10:25', 'speed': '5.0 km/h'},
    {'address': 'Jl. Sudirman No. 122', 'time': '10:20', 'speed': '4.8 km/h'},
  ];

  @override
  void initState() {
    super.initState();
    _loadLocationData();
  }

  Future<void> _loadLocationData() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(seconds: 1));
    setState(() => _isLoading = false);
  }

  void _toggleTracking() {
    setState(() => _isTracking = !_isTracking);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isTracking ? '📍 Live tracking dimulai' : '📍 Live tracking dihentikan'),
        backgroundColor: _isTracking ? Colors.green : Colors.orange,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _refreshLocation() {
    _loadLocationData();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Memperbarui lokasi...'), backgroundColor: Color(0xFF3949AB), behavior: SnackBarBehavior.floating),
    );
  }

  void _showLocationHistory() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A2E),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => Container(
        height: 400,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('RIWAYAT LOKASI', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const Divider(color: Colors.white24),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: _locationHistory.length,
                itemBuilder: (context, index) {
                  final location = _locationHistory[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF2A2A3E),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.location_on, color: Color(0xFF3949AB), size: 16),
                            const SizedBox(width: 8),
                            Text(location['address'], style: const TextStyle(color: Colors.white, fontSize: 12)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text(location['time'], style: const TextStyle(color: Colors.white54, fontSize: 10)),
                            const SizedBox(width: 16),
                            Text('Speed: ${location['speed']}', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      appBar: AppBar(
        title: const Text('GPS TRACKER'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF3949AB)),
            onPressed: _refreshLocation,
          ),
          IconButton(
            icon: const Icon(Icons.history, color: Color(0xFF3949AB)),
            onPressed: _showLocationHistory,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Color(0xFF3949AB)),
                  SizedBox(height: 16),
                  Text('Mengambil lokasi target...', style: TextStyle(color: Colors.white54)),
                ],
              ),
            )
          : Column(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height * 0.5,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage('https://maps.googleapis.com/maps/api/staticmap?center=${_currentLocation['latitude']},${_currentLocation['longitude']}&zoom=15&size=400x400&markers=color:red%7C${_currentLocation['latitude']},${_currentLocation['longitude']}'),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.transparent, Colors.black.withOpacity(0.5)],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A3E),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF3949AB).withOpacity(0.3)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A237E).withOpacity(0.3),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.gps_fixed, color: Color(0xFF3949AB), size: 30),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(_currentLocation['address'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    const Icon(Icons.access_time, size: 12, color: Colors.white54),
                                    const SizedBox(width: 4),
                                    Text('${_currentLocation['timestamp'].hour}:${_currentLocation['timestamp'].minute}', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                                    const SizedBox(width: 16),
                                    const Icon(Icons.speed, size: 12, color: Colors.white54),
                                    const SizedBox(width: 4),
                                    Text('${_currentLocation['speed']} km/h', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                                    const SizedBox(width: 16),
                                    const Icon(Icons.gps_not_fixed, size: 12, color: Colors.white54),
                                    const SizedBox(width: 4),
                                    Text('±${_currentLocation['accuracy']}m', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: _refreshLocation,
                              icon: const Icon(Icons.refresh, size: 18),
                              label: const Text('REFRESH'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF3949AB),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () {
                                final url = 'https://www.google.com/maps/search/?api=1&query=${_currentLocation['latitude']},${_currentLocation['longitude']}';
                                // launchUrlString(url);
                              },
                              icon: const Icon(Icons.map, size: 18),
                              label: const Text('STREET MAP'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF1A237E),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _toggleTracking,
                              icon: Icon(_isTracking ? Icons.pause : Icons.play_arrow, size: 18),
                              label: Text(_isTracking ? 'STOP TRACKING' : 'START TRACKING'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: _isTracking ? Colors.red : const Color(0xFF3949AB),
                                side: BorderSide(color: _isTracking ? Colors.red : const Color(0xFF3949AB)),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _showLocationHistory,
                              icon: const Icon(Icons.history, size: 18),
                              label: const Text('HISTORY'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: const Color(0xFF3949AB),
                                side: const BorderSide(color: Color(0xFF3949AB)),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                if (_isTracking)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.green.withOpacity(0.5)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: const BoxDecoration(
                            color: Colors.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Text(
                          'Live tracking aktif - lokasi diperbarui setiap 5 detik',
                          style: TextStyle(color: Colors.green, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }
}