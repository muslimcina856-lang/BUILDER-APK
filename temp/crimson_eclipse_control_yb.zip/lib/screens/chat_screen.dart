import 'package:flutter/material.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [
    {'text': 'Halo, ada yang bisa dibantu?', 'isMe': false, 'time': '10:00'},
    {'text': 'Test pesan dari target', 'isMe': false, 'time': '10:01'},
  ];

  void _sendMessage() {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _messages.add({'text': text, 'isMe': true, 'time': _getCurrentTime()});
      _messageController.clear();
    });
  }

  String _getCurrentTime() {
    final now = DateTime.now();
    return '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      appBar: AppBar(title: const Text('CHAT DENGAN TARGET'), leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context))),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _messages.length,
            itemBuilder: (context, index) {
              final message = _messages[index];
              final isMe = message['isMe'] as bool;
              return Align(
                alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(color: isMe ? const Color(0xFF3949AB) : const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(20)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(message['text'], style: const TextStyle(color: Colors.white)), const SizedBox(height: 4), Text(message['time'], style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10))]),
                ),
              );
            },
          ),
        ),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: const BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20))),
          child: Row(children: [
            IconButton(icon: const Icon(Icons.mic, color: Color(0xFF3949AB)), onPressed: () {}),
            IconButton(icon: const Icon(Icons.image, color: Color(0xFF3949AB)), onPressed: () {}),
            Expanded(child: Container(padding: const EdgeInsets.symmetric(horizontal: 16), decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(25)), child: TextField(controller: _messageController, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(hintText: 'Ketik pesan...', hintStyle: TextStyle(color: Colors.white54), border: InputBorder.none), onSubmitted: (_) => _sendMessage()))),
            IconButton(icon: const Icon(Icons.send, color: Color(0xFF3949AB)), onPressed: _sendMessage),
          ]),
        ),
      ]),
    );
  }
}