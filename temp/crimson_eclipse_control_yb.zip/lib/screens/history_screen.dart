import 'package:flutter/material.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> history = [
      {'action': 'Lock Device', 'date': '15/06/2024 10:30', 'status': 'Success'},
      {'action': 'Flashlight ON', 'date': '15/06/2024 09:15', 'status': 'Success'},
      {'action': 'Screenshot', 'date': '14/06/2024 22:00', 'status': 'Success'},
      {'action': 'Live Stream', 'date': '14/06/2024 20:45', 'status': 'Failed'},
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      appBar: AppBar(title: const Text('RIWAYAT'), leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context))),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: history.length,
        itemBuilder: (context, index) {
          final item = history[index];
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: const Color(0xFF2A2A3E), borderRadius: BorderRadius.circular(16)),
            child: Row(children: [
              Container(width: 40, height: 40, decoration: BoxDecoration(color: item['status'] == 'Success' ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(10)), child: Icon(item['status'] == 'Success' ? Icons.check : Icons.close, color: item['status'] == 'Success' ? Colors.green : Colors.red)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item['action'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), Text(item['date'], style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12))])),
              Text(item['status'], style: TextStyle(color: item['status'] == 'Success' ? Colors.green : Colors.red, fontSize: 12)),
            ]),
          );
        },
      ),
    );
  }
}