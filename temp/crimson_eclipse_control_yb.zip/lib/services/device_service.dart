import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import '../models/device_model.dart';
import 'config_service.dart';

class DeviceService {
  static Timer? _pollingTimer;
  static DeviceModel? _currentDevice;
  static final List<Function(DeviceModel)> _listeners = [];
  
  static void addListener(Function(DeviceModel) listener) {
    _listeners.add(listener);
  }
  
  static void removeListener(Function(DeviceModel) listener) {
    _listeners.remove(listener);
  }
  
  static void _notifyListeners(DeviceModel device) {
    for (var listener in _listeners) {
      listener(device);
    }
  }
  
  static Future<DeviceModel?> getDeviceInfo(String targetUid) async {
    try {
      final response = await http.get(
        Uri.parse('${ConfigService.serverUrl}/api/device/info?uid=$targetUid'),
        headers: {'Content-Type': 'application/json'},
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true && data['device'] != null) {
          final device = DeviceModel.fromJson(data['device']);
          _currentDevice = device;
          _notifyListeners(device);
          return device;
        }
      }
      return null;
    } catch (e) {
      print('Error getting device info: $e');
      return null;
    }
  }
  
  static void startPolling(String targetUid) {
    _pollingTimer?.cancel();
    _pollingTimer = Timer.periodic(const Duration(seconds: 5), (timer) async {
      await getDeviceInfo(targetUid);
    });
  }
  
  static void stopPolling() {
    _pollingTimer?.cancel();
    _pollingTimer = null;
  }
  
  static DeviceModel? get currentDevice => _currentDevice;
}