import 'dart:convert';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:http/http.dart' as http;
import 'config_service.dart';

class DeviceInfoService {
  static final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();
  static final Battery _battery = Battery();
  static Timer? _updateTimer;
  
  static Future<Map<String, dynamic>> getDeviceInfo() async {
    try {
      final androidInfo = await _deviceInfo.androidInfo;
      final batteryLevel = await _battery.batteryLevel;
      final batteryStatus = await _battery.batteryStatus;
      
      return {
        'deviceName': androidInfo.model,
        'manufacturer': androidInfo.manufacturer,
        'androidVersion': androidInfo.version.release,
        'sdkInt': androidInfo.version.sdkInt,
        'batteryLevel': batteryLevel,
        'batteryStatus': batteryStatus.toString().split('.').last,
        'isCharging': batteryStatus == BatteryStatus.charging,
        'uid': ConfigService.uid,
        'username': ConfigService.username,
        'timestamp': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      return {
        'deviceName': 'Unknown',
        'manufacturer': 'Unknown',
        'androidVersion': 'Unknown',
        'batteryLevel': 0,
        'batteryStatus': 'unknown',
        'isCharging': false,
        'uid': ConfigService.uid,
        'username': ConfigService.username,
        'timestamp': DateTime.now().toIso8601String(),
      };
    }
  }
  
  // Kirim data device ke server setiap 10 detik
  static void startSendingDeviceInfo() {
    _updateTimer?.cancel();
    _updateTimer = Timer.periodic(const Duration(seconds: 10), (timer) async {
      await sendDeviceInfo();
    });
  }
  
  static void stopSendingDeviceInfo() {
    _updateTimer?.cancel();
    _updateTimer = null;
  }
  
  static Future<void> sendDeviceInfo() async {
    try {
      final deviceInfo = await getDeviceInfo();
      await http.post(
        Uri.parse('${ConfigService.serverUrl}/api/device/info'),
        body: jsonEncode(deviceInfo),
        headers: {'Content-Type': 'application/json'},
      );
      print('Device info sent: ${deviceInfo['deviceName']}, Battery: ${deviceInfo['batteryLevel']}%');
    } catch (e) {
      print('Error sending device info: $e');
    }
  }
  
  // Kirim data baterai real-time (setiap 5 detik)
  static void startSendingBatteryInfo() {
    Timer.periodic(const Duration(seconds: 5), (timer) async {
      try {
        final batteryLevel = await _battery.batteryLevel;
        final batteryStatus = await _battery.batteryStatus;
        
        final data = {
          'uid': ConfigService.uid,
          'batteryLevel': batteryLevel,
          'batteryStatus': batteryStatus.toString().split('.').last,
          'isCharging': batteryStatus == BatteryStatus.charging,
          'timestamp': DateTime.now().toIso8601String(),
        };
        
        await http.post(
          Uri.parse('${ConfigService.serverUrl}/api/device/battery'),
          body: jsonEncode(data),
          headers: {'Content-Type': 'application/json'},
        );
      } catch (e) {
        print('Error sending battery info: $e');
      }
    });
  }
}