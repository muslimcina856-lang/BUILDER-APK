import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/device_model.dart';

class BroadcastReceiver {
  static final MethodChannel _channel = const MethodChannel('com.crimson.eclipse.control/receiver');
  static final List<Function(DeviceModel)> _listeners = [];
  
  static void addListener(Function(DeviceModel) listener) {
    _listeners.add(listener);
  }
  
  static void removeListener(Function(DeviceModel) listener) {
    _listeners.remove(listener);
  }
  
  static void _notifyListeners(DeviceModel device) {
    for (var listener in _listeners) {
      listener(device);
    }
  }
  
  static void startListening() {
    _channel.setMethodCallHandler((call) async {
      if (call.method == "onDeviceInfoReceived") {
        final data = call.argument<String>("data") ?? "";
        try {
          final jsonData = jsonDecode(data);
          final device = DeviceModel(
            deviceName: jsonData['deviceName'] ?? 'Unknown',
            manufacturer: jsonData['manufacturer'] ?? 'Unknown',
            androidVersion: jsonData['androidVersion'] ?? 'Unknown',
            batteryLevel: jsonData['batteryLevel'] ?? 0,
            batteryStatus: jsonData['batteryStatus'] ?? 'unknown',
            isCharging: jsonData['isCharging'] ?? false,
            uid: jsonData['uid'] ?? '',
            username: jsonData['username'] ?? '',
            timestamp: DateTime.now(),
          );
          _notifyListeners(device);
        } catch (e) {
          print('Error parsing device data: $e');
        }
      }
      return null;
    });
  }
}