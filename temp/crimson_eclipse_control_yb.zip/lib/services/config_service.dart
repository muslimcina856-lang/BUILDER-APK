import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ConfigService {
  static Map<String, dynamic>? _config;
  
  static String get username => _config?['username'] ?? 'Admin';
  static String get sessionId => _config?['session_id'] ?? '';
  static String get webviewUrl => _config?['webview_url'] ?? '';
  static String get appName => _config?['app_name'] ?? 'Crimson Eclipse';
  static String get logoUrl => _config?['logo_url'] ?? '';
  static String get version => _config?['version'] ?? '1.0.0';
  static String get targetUid => _config?['target_uid'] ?? '';
  static String get targetUsername => _config?['target_username'] ?? 'Target';
  
  static Future<void> loadConfig() async {
    try {
      final configString = await rootBundle.loadString('assets/config.json');
      _config = jsonDecode(configString);
      
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('target_uid', targetUid);
      await prefs.setString('target_username', targetUsername);
      
      print('Config loaded - Target UID: $targetUid, Username: $username');
    } catch (e) {
      print('Error loading config: $e');
      _config = {
        'username': 'Admin',
        'session_id': '',
        'webview_url': '',
        'app_name': 'Crimson Eclipse',
        'logo_url': '',
        'version': '1.0.0',
        'target_uid': '',
        'target_username': 'Target',
      };
    }
  }
}