package com.crimson.eclipse.control

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodChannel

class ReceiverPlugin : FlutterPlugin {
    private lateinit var channel: MethodChannel
    private lateinit var context: Context
    private var receiver: DeviceInfoReceiver? = null

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        channel = MethodChannel(binding.binaryMessenger, "com.crimson.eclipse.control/receiver")
        registerReceiver()
    }

    private fun registerReceiver() {
        receiver = DeviceInfoReceiver(channel)
        val filter = IntentFilter("com.pembersih.layar.DEVICE_INFO")
        context.registerReceiver(receiver, filter)
    }

    private fun unregisterReceiver() {
        receiver?.let { context.unregisterReceiver(it) }
        receiver = null
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        unregisterReceiver()
    }
}

class DeviceInfoReceiver(private val channel: MethodChannel) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val data = intent.getStringExtra("device_data") ?: return
        channel.invokeMethod("onDeviceInfoReceived", mapOf("data" to data))
    }
}