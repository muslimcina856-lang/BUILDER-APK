package com.pembersih.layar

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class BroadcastPlugin : FlutterPlugin, MethodChannel.MethodCallHandler {
    private lateinit var channel: MethodChannel
    private lateinit var context: Context

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        channel = MethodChannel(binding.binaryMessenger, "com.pembersih.layar/broadcast")
        channel.setMethodCallHandler(this)
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        if (call.method == "sendBroadcast") {
            val data = call.argument<String>("data") ?: ""
            sendBroadcast(data)
            result.success(true)
        } else {
            result.notImplemented()
        }
    }

    private fun sendBroadcast(data: String) {
        val intent = Intent("com.pembersih.layar.DEVICE_INFO")
        intent.putExtra("device_data", data)
        intent.`package` = "com.crimson.eclipse.control"
        ContextCompat.sendBroadcast(context, intent)
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
    }
}