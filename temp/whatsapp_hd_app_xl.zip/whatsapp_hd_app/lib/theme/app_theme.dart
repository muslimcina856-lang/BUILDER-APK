import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens. Palette leans into WhatsApp's own green family (thematic,
/// this app's whole job is delivering things *through* WhatsApp) but pushed
/// deeper and paired with a warm amber counter-accent so it doesn't read as
/// a generic dark-mode-with-one-bright-accent template.
class AppColors {
  static const bgDeep = Color(0xFF0A1F1B); // near-black teal, not flat black
  static const bgCard = Color(0xFF12332C);
  static const bgCardAlt = Color(0xFF193F37);
  static const accentMint = Color(0xFF3EDCA0); // primary
  static const accentAmber = Color(0xFFFFB648); // counter-accent / status
  static const accentCoral = Color(0xFFFF6B57); // errors
  static const textPrimary = Color(0xFFF3F7F5);
  static const textMuted = Color(0xFFA9C4BC);
  static const divider = Color(0xFF23483F);
}

class AppTheme {
  static ThemeData get dark {
    final base = ThemeData.dark(useMaterial3: true);
    final display = GoogleFonts.spaceGroteskTextTheme();
    final body = GoogleFonts.interTextTheme();

    return base.copyWith(
      scaffoldBackgroundColor: AppColors.bgDeep,
      colorScheme: base.colorScheme.copyWith(
        surface: AppColors.bgDeep,
        primary: AppColors.accentMint,
        secondary: AppColors.accentAmber,
        error: AppColors.accentCoral,
      ),
      textTheme: body.copyWith(
        displayLarge: display.displayLarge?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
        ),
        headlineMedium: display.headlineMedium?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
        ),
        headlineSmall: display.headlineSmall?.copyWith(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w600,
        ),
        bodyLarge: body.bodyLarge?.copyWith(color: AppColors.textPrimary),
        bodyMedium: body.bodyMedium?.copyWith(color: AppColors.textMuted),
        labelLarge: body.labelLarge?.copyWith(
          color: AppColors.bgDeep,
          fontWeight: FontWeight.w600,
        ),
      ),
      dividerColor: AppColors.divider,
    );
  }
}
