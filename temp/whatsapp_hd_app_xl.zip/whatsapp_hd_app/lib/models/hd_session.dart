import 'dart:async';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

enum FlowStatus {
  idle, // belum start
  generating, // call POST /api/session
  waitingActivation, // kod dah ada, tunggu user hantar dalam WhatsApp
  activated, // linked & active — boleh convert
  uploading, // sedang proses + hantar
  success, // dah sampai WhatsApp
  error,
}

class HdSession extends ChangeNotifier {
  final ApiService _api = ApiService();
  Timer? _pollTimer;
  int _pollAttempts = 0;
  static const _maxPollAttempts = 120; // ~5 min at 2.5s interval

  FlowStatus status = FlowStatus.idle;
  String? code;
  String? waLink;
  int sessionTtlHours = 24;
  String? errorMessage;
  String? lastFileName;

  static const _prefsCodeKey = 'hd_session_code';

  /// On app launch: if we saved a code before and it's still active on the
  /// server, jump straight back to the "activated" screen instead of making
  /// the user activate again every time they reopen the app.
  Future<void> restore() async {
    final prefs = await SharedPreferences.getInstance();
    final savedCode = prefs.getString(_prefsCodeKey);
    if (savedCode == null) return;

    try {
      final data = await _api.checkStatus(savedCode);
      if (data['active'] == true) {
        code = savedCode;
        status = FlowStatus.activated;
        notifyListeners();
      } else {
        await prefs.remove(_prefsCodeKey);
      }
    } catch (_) {
      // backend belum on / unreachable — biar user start manually
    }
  }

  Future<void> start() async {
    status = FlowStatus.generating;
    errorMessage = null;
    notifyListeners();

    try {
      final data = await _api.createSession();
      code = data['code'] as String;
      waLink = data['waLink'] as String;
      sessionTtlHours = (data['sessionTtlHours'] as num?)?.toInt() ?? 24;

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsCodeKey, code!);

      status = FlowStatus.waitingActivation;
      notifyListeners();
      _beginPolling();
    } catch (e) {
      status = FlowStatus.error;
      errorMessage = e.toString();
      notifyListeners();
    }
  }

  void _beginPolling() {
    _pollAttempts = 0;
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(milliseconds: 2500), (timer) async {
      _pollAttempts++;
      if (_pollAttempts > _maxPollAttempts) {
        timer.cancel();
        if (status == FlowStatus.waitingActivation) {
          status = FlowStatus.error;
          errorMessage = 'Lama sangat tunggu — cuba \'Mula Semula\'.';
          notifyListeners();
        }
        return;
      }

      try {
        final data = await _api.checkStatus(code!);
        if (data['linked'] == true && data['active'] == true) {
          timer.cancel();
          status = FlowStatus.activated;
          notifyListeners();
        }
      } catch (_) {
        // network blip — just try again next tick
      }
    });
  }

  Future<void> pickAndUpload() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.media,
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;

    final file = result.files.first;
    lastFileName = file.name;
    status = FlowStatus.uploading;
    errorMessage = null;
    notifyListeners();

    try {
      await _api.uploadFile(code!, file);
      status = FlowStatus.success;
    } catch (e) {
      status = FlowStatus.error;
      errorMessage = e.toString();
    }
    notifyListeners();
  }

  void convertAnother() {
    status = FlowStatus.activated;
    lastFileName = null;
    notifyListeners();
  }

  Future<void> reset() async {
    _pollTimer?.cancel();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefsCodeKey);
    code = null;
    waLink = null;
    errorMessage = null;
    status = FlowStatus.idle;
    notifyListeners();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }
}
