import 'dart:math';
import 'package:flutter/material.dart';

/// Signature visual for the app: a ring of ticks like a camera focus dial.
/// `intensity` controls how many ticks are "lit" (0 = scattered/waiting,
/// 1 = fully resolved), and `spinning` adds a rotating glow sweep for busy
/// states — the whole thing reads as "resolving into focus," which is the
/// app's actual job.
class FocusRing extends StatefulWidget {
  final double size;
  final double intensity;
  final bool spinning;
  final Color color;
  final Widget? child;

  const FocusRing({
    super.key,
    this.size = 180,
    this.intensity = 1.0,
    this.spinning = false,
    required this.color,
    this.child,
  });

  @override
  State<FocusRing> createState() => _FocusRingState();
}

class _FocusRingState extends State<FocusRing>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return CustomPaint(
          size: Size.square(widget.size),
          painter: _FocusRingPainter(
            sweepAngle: _controller.value * 2 * pi,
            intensity: widget.intensity,
            spinning: widget.spinning,
            color: widget.color,
          ),
          child: SizedBox.square(
            dimension: widget.size,
            child: Center(child: widget.child),
          ),
        );
      },
    );
  }
}

class _FocusRingPainter extends CustomPainter {
  final double sweepAngle;
  final double intensity;
  final bool spinning;
  final Color color;

  _FocusRingPainter({
    required this.sweepAngle,
    required this.intensity,
    required this.spinning,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2;
    const tickCount = 36;
    final litCount = (tickCount * intensity.clamp(0.0, 1.0)).round();

    for (int i = 0; i < tickCount; i++) {
      final angle = (i / tickCount) * 2 * pi - pi / 2;
      final isLit = i < litCount;

      double opacity = isLit ? 0.85 : 0.12;
      if (spinning) {
        final diff = (angle - sweepAngle) % (2 * pi);
        final normDiff = diff < 0 ? diff + 2 * pi : diff;
        final sweepGlow = (1 - (normDiff / (pi / 2))).clamp(0.0, 1.0).toDouble();
        opacity = (opacity + sweepGlow * 0.9).clamp(0.0, 1.0).toDouble();
      }

      final tickLength = isLit ? radius * 0.16 : radius * 0.09;
      final outer = radius - 2;
      final inner = outer - tickLength;

      final p1 = center + Offset(cos(angle), sin(angle)) * inner;
      final p2 = center + Offset(cos(angle), sin(angle)) * outer;

      final paint = Paint()
        ..color = color.withOpacity(opacity)
        ..strokeWidth = 2.6
        ..strokeCap = StrokeCap.round;

      canvas.drawLine(p1, p2, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _FocusRingPainter oldDelegate) {
    return oldDelegate.sweepAngle != sweepAngle ||
        oldDelegate.intensity != intensity ||
        oldDelegate.spinning != spinning ||
        oldDelegate.color != color;
  }
}
