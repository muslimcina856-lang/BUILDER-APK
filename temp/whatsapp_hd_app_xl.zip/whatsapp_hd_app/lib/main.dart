import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models/hd_session.dart';
import 'screens/home_screen.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const WhatsAppHdApp());
}

class WhatsAppHdApp extends StatelessWidget {
  const WhatsAppHdApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => HdSession()..restore(),
      child: MaterialApp(
        title: 'HD via WhatsApp',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        home: const HomeScreen(),
      ),
    );
  }
}
