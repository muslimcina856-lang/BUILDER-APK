/// Semua setting untuk semak update APK dari GitHub Releases.
/// Ni SATU-SATUNYA tempat kena tukar bila nak pointkan ke account/repo lain.
class UpdateConfig {
  static const String githubOwner = 'your-github-username';
  static const String githubRepo = 'your-repo-name';

  /// Personal Access Token — HANYA isi kalau repo tu PRIVATE.
  ///
  /// Kalau repo/release public, biar kosong (''). Tu lagi selamat, sebab
  /// apa-apa string yang dibenam dalam APK (termasuk token ni) boleh
  /// diextract oleh sesiapa saja yang decompile APK — unzip + baca
  /// strings.xml/smali, dalam 5 minit boleh jumpa. Kalau memang repo
  /// kena private dan terpaksa guna token:
  ///   - Guna Fine-grained PAT (bukan classic), scope kat repo NI SAHAJA
  ///   - Permission: "Contents: Read-only" je, tak payah lain
  ///   - Set expiry (jangan "No expiration") dan refresh dari semasa ke semasa
  /// Supaya kalau ia bocor pun, kerosakan terhad kepada baca 1 repo je.
  static const String githubToken = '';
}
