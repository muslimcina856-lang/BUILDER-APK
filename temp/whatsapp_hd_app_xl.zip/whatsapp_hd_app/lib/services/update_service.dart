import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import '../config/update_config.dart';

class UpdateInfo {
  final String version;
  final String downloadUrl;
  final String? notes;

  UpdateInfo({required this.version, required this.downloadUrl, this.notes});
}

class UpdateService {
  /// Returns null kalau tak boleh check (offline, repo/token invalid) atau
  /// kalau app dah versi terkini — so caller cuma perlu handle 1 kes je
  /// (ada update -> papar dialog).
  Future<UpdateInfo?> checkForUpdate() async {
    final uri = Uri.https(
      'api.github.com',
      '/repos/${UpdateConfig.githubOwner}/${UpdateConfig.githubRepo}/releases/latest',
    );

    final headers = {
      'Accept': 'application/vnd.github+json',
      if (UpdateConfig.githubToken.isNotEmpty)
        'Authorization': 'Bearer ${UpdateConfig.githubToken}',
    };

    try {
      final res = await http.get(uri, headers: headers).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return null;

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final tag = (data['tag_name'] as String? ?? '').replaceFirst(RegExp(r'^v'), '');
      if (tag.isEmpty) return null;

      final assets = (data['assets'] as List?) ?? [];
      final apkAsset = assets.cast<Map<String, dynamic>>().firstWhere(
            (a) => (a['name'] as String? ?? '').toLowerCase().endsWith('.apk'),
            orElse: () => <String, dynamic>{},
          );
      final downloadUrl =
          apkAsset['browser_download_url'] as String? ?? data['html_url'] as String?;
      if (downloadUrl == null) return null;

      final current = await PackageInfo.fromPlatform();
      if (!_isNewer(tag, current.version)) return null;

      return UpdateInfo(version: tag, downloadUrl: downloadUrl, notes: data['body'] as String?);
    } catch (_) {
      return null; // network error dsb — senyap sahaja, jangan ganggu user
    }
  }

  bool _isNewer(String remoteVersion, String localVersion) {
    List<int> parse(String v) => v
        .split('+')
        .first
        .split('.')
        .map((p) => int.tryParse(p.trim()) ?? 0)
        .toList();

    final remote = parse(remoteVersion);
    final local = parse(localVersion);

    for (var i = 0; i < 3; i++) {
      final r = i < remote.length ? remote[i] : 0;
      final l = i < local.length ? local[i] : 0;
      if (r != l) return r > l;
    }
    return false;
  }
}
