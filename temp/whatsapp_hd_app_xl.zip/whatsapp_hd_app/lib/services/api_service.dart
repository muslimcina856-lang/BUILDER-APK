import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class ApiService {
  /// ⚠️ Tukar ni ikut di mana backend kau run:
  ///  - Android emulator -> backend kat host laptop: http://10.0.2.2:3000
  ///  - iOS simulator -> backend kat host laptop:    http://localhost:3000
  ///  - Phone betul (USB/WiFi sama) -> IP LAN laptop: http://192.168.x.x:3000
  ///  - Dah deploy -> https://your-domain.com
  static const String baseUrl = 'http://10.0.2.2:3000';

  Future<Map<String, dynamic>> createSession() async {
    final res = await http
        .post(Uri.parse('$baseUrl/api/session'))
        .timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) {
      throw ApiException('Tak dapat mula session (${res.statusCode})');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> checkStatus(String code) async {
    final res = await http
        .get(Uri.parse('$baseUrl/api/session/$code'))
        .timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) {
      throw ApiException('Tak jumpa session ($code)');
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// Determines (isVideo, mimeType) from the picked file's extension.
  (bool, String) _mimeFor(String? ext) {
    switch ((ext ?? '').toLowerCase()) {
      case 'mp4':
        return (true, 'video/mp4');
      case 'mov':
        return (true, 'video/quicktime');
      case '3gp':
        return (true, 'video/3gpp');
      case 'png':
        return (false, 'image/png');
      case 'webp':
        return (false, 'image/webp');
      default:
        return (false, 'image/jpeg');
    }
  }

  Future<void> uploadFile(String code, PlatformFile file) async {
    if (file.bytes == null) {
      throw ApiException('Fail tak dapat dibaca, cuba pilih semula');
    }
    final (_, mime) = _mimeFor(file.extension);
    final type = mime.split('/');

    final req = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/api/session/$code/upload'),
    );
    req.files.add(
      http.MultipartFile.fromBytes(
        'file',
        file.bytes!,
        filename: file.name,
        contentType: MediaType(type[0], type[1]),
      ),
    );

    final streamed = await req.send().timeout(const Duration(minutes: 3));
    final res = await http.Response.fromStream(streamed);

    if (res.statusCode != 200) {
      final body = _tryDecode(res.body);
      throw ApiException(body?['error']?.toString() ?? 'Gagal upload fail');
    }
  }

  Map<String, dynamic>? _tryDecode(String body) {
    try {
      return jsonDecode(body) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }
}
