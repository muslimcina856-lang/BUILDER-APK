import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/hd_session.dart';
import '../services/update_service.dart';
import '../theme/app_theme.dart';
import '../widgets/focus_ring.dart';
import '../widgets/primary_button.dart';
import '../widgets/update_dialog.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Sekali sahaja bila screen ni load — senyap kalau tiada update / offline.
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final info = await UpdateService().checkForUpdate();
      if (info != null && mounted) {
        showUpdateDialog(context, info);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Consumer<HdSession>(
            builder: (context, session, _) {
              return Column(
                children: [
                  const Spacer(),
                  _RingForStatus(session: session),
                  const SizedBox(height: 36),
                  _BodyForStatus(session: session),
                  const Spacer(),
                  _ActionsForStatus(session: session),
                  const SizedBox(height: 24),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _RingForStatus extends StatelessWidget {
  final HdSession session;
  const _RingForStatus({required this.session});

  @override
  Widget build(BuildContext context) {
    final (double intensity, bool spinning, IconData icon, Color color) =
        switch (session.status) {
      FlowStatus.idle => (0.15, false, Icons.auto_awesome_outlined, AppColors.accentMint),
      FlowStatus.generating => (0.3, true, Icons.auto_awesome_outlined, AppColors.accentMint),
      FlowStatus.waitingActivation => (0.55, true, Icons.qr_code_2_rounded, AppColors.accentAmber),
      FlowStatus.activated => (1.0, false, Icons.check_circle_outline_rounded, AppColors.accentMint),
      FlowStatus.uploading => (1.0, true, Icons.cloud_upload_outlined, AppColors.accentMint),
      FlowStatus.success => (1.0, false, Icons.task_alt_rounded, AppColors.accentMint),
      FlowStatus.error => (0.25, false, Icons.error_outline_rounded, AppColors.accentCoral),
    };

    return FocusRing(
      size: 176,
      intensity: intensity,
      spinning: spinning,
      color: color,
      child: Icon(icon, size: 52, color: color),
    );
  }
}

class _BodyForStatus extends StatelessWidget {
  final HdSession session;
  const _BodyForStatus({required this.session});

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return switch (session.status) {
      FlowStatus.idle || FlowStatus.generating => Column(
          children: [
            Text('Jadikan gambar & video HD', style: text.headlineSmall, textAlign: TextAlign.center),
            const SizedBox(height: 10),
            Text(
              'Activate sekali guna WhatsApp, lepas tu hantar apa-apa sahaja fail — kami balikkan versi HD terus ke WhatsApp kau.',
              style: text.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      FlowStatus.waitingActivation => Column(
          children: [
            Text('Hantar kod ni dalam WhatsApp', style: text.headlineSmall, textAlign: TextAlign.center),
            const SizedBox(height: 18),
            _CodeChip(code: session.code ?? ''),
            const SizedBox(height: 18),
            Text(
              'Tekan butang di bawah untuk buka WhatsApp — kod dah auto-isi, tinggal hantar.',
              style: text.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      FlowStatus.activated => Column(
          children: [
            Text('Sedia!', style: text.headlineSmall, textAlign: TextAlign.center),
            const SizedBox(height: 10),
            Text(
              'Pilih gambar atau video. Hasil HD akan dihantar terus ke WhatsApp kau — sah untuk ${session.sessionTtlHours} jam.',
              style: text.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      FlowStatus.uploading => Column(
          children: [
            Text('Memproses...', style: text.headlineSmall, textAlign: TextAlign.center),
            const SizedBox(height: 10),
            Text(
              session.lastFileName ?? '',
              style: text.bodyMedium,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      FlowStatus.success => Column(
          children: [
            Text('Sedang diproses', style: text.headlineSmall, textAlign: TextAlign.center),
            const SizedBox(height: 10),
            Text(
              'Fail dah dihantar untuk diproses — hasil HD akan sampai ke chat WhatsApp kau sekejap lagi.',
              style: text.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      FlowStatus.error => Column(
          children: [
            Text('Ada masalah', style: text.headlineSmall, textAlign: TextAlign.center),
            const SizedBox(height: 10),
            Text(
              session.errorMessage ?? 'Sila cuba lagi.',
              style: text.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
    };
  }
}

class _ActionsForStatus extends StatelessWidget {
  final HdSession session;
  const _ActionsForStatus({required this.session});

  @override
  Widget build(BuildContext context) {
    return switch (session.status) {
      FlowStatus.idle => PrimaryButton(label: 'Mula', onPressed: session.start),
      FlowStatus.generating =>
        const PrimaryButton(label: 'Mula', onPressed: null, loading: true),
      FlowStatus.waitingActivation => Column(
          children: [
            PrimaryButton(
              label: 'Buka WhatsApp & Hantar Kod',
              icon: Icons.chat_bubble_outline_rounded,
              onPressed: () async {
                final uri = Uri.parse(session.waLink ?? '');
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                }
              },
            ),
            const SizedBox(height: 4),
            SecondaryButton(label: 'Mula semula', onPressed: session.reset),
          ],
        ),
      FlowStatus.activated => PrimaryButton(
          label: 'Pilih Fail',
          icon: Icons.add_photo_alternate_outlined,
          onPressed: session.pickAndUpload,
        ),
      FlowStatus.uploading =>
        const PrimaryButton(label: 'Memproses', onPressed: null, loading: true),
      FlowStatus.success => PrimaryButton(
          label: 'Convert Lagi',
          icon: Icons.refresh_rounded,
          onPressed: session.convertAnother,
        ),
      FlowStatus.error => PrimaryButton(
          label: 'Mula Semula',
          color: AppColors.accentCoral,
          onPressed: session.reset,
        ),
    };
  }
}

class _CodeChip extends StatelessWidget {
  final String code;
  const _CodeChip({required this.code});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.divider),
      ),
      child: Text(
        code,
        style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              letterSpacing: 4,
              color: AppColors.accentAmber,
            ),
      ),
    );
  }
}
