# WhatsApp HD App (Flutter, starter)

Front-end untuk backend `whatsapp-hd-bot`: generate kod, buka WhatsApp untuk
activate, lepas tu pilih gambar/video — hasil HD terus masuk WhatsApp kau.

## Ni 1 daripada 3 bahagian

1. **`whatsapp-hd-bot`** — server yang pegang session WhatsApp (kena
   jalan & configured dulu sebelum app ni berguna)
2. **`github-repo-files`** — workflow yang proses media, letak dalam
   repo GitHub
3. **`whatsapp_hd_app`** (zip ni) — app Flutter untuk end-user

App ni bergantung 100% kepada `whatsapp-hd-bot` dah jalan (`baseUrl`
dalam `lib/services/api_service.dart` kena tunjuk ke bot tu). Setup bot +
repo GitHub dulu (ikut README masing-masing) sebelum test app ni.

## Keperluan

- Flutter SDK terkini (stable channel) — projek ni target Dart >=3.3.0
- Android Studio (untuk build Android) dan/atau Xcode (untuk iOS, kalau
  perlu)
- `whatsapp-hd-bot` dah jalan dan reachable (localhost untuk testing di
  emulator, atau URL Cloudflare untuk phone betul)

## Setup

Fail-fail dalam zip ni cuma `pubspec.yaml` + `lib/` (source code sahaja,
bukan full Flutter project — folder `android/` `ios/` dia generated locally,
tak masuk akal nak hantar dalam zip sebab ia specific kat machine korang).

```bash
flutter create whatsapp_hd_app        # buat project baru, generate android/ios/
cd whatsapp_hd_app
# replace pubspec.yaml + lib/ yang baru generate dengan yang dalam zip ni
flutter pub get
```

Kemudian **wajib** edit `lib/services/api_service.dart` → `baseUrl`, ikut
macam mana kau run backend (komen dalam fail tu dah explain 4 kes biasa:
emulator Android, simulator iOS, phone betul dalam WiFi sama, atau dah deploy).
Ni punca #1 app "tak connect" untuk first-timer Flutter.

```bash
flutter run
```

## Struktur

```
pubspec.yaml
upload-keystore.jks               keystore signing (pindah ke project root)
key.properties                    password/alias untuk keystore (pindah sekali)
proguard-rules.pro                R8 rules (copy ke android/app/)
lib/main.dart                     entry point, theme + provider
lib/theme/app_theme.dart          warna & typography
lib/config/update_config.dart     SATU tempat config GitHub (owner/repo/token)
lib/models/hd_session.dart        state machine (idle → activated → upload → done)
lib/services/api_service.dart     panggil backend (createSession/checkStatus/upload)
lib/services/update_service.dart  semak GitHub Releases untuk version baru
lib/widgets/focus_ring.dart       animasi ring "resolving into focus" (signature UI)
lib/widgets/primary_button.dart   button component
lib/widgets/update_dialog.dart    dialog "update tersedia"
lib/screens/home_screen.dart      1 skrin, UI tukar ikut state
```

## Flow

1. Tap "Mula" → app minta kod dari backend
2. Tap "Buka WhatsApp & Hantar Kod" → WhatsApp terbuka dengan kod dah auto-isi
3. App poll setiap 2.5s sampai backend confirm kod tu dah diterima → skrin tukar "Sedia!"
4. Tap "Pilih Fail" → pilih gambar/video dari phone → upload terus ke backend
   (bukan lalu WhatsApp — ni yang jaga kualiti asal, sebab tak lalu compression WhatsApp pun)
5. Backend proses & hantar balik ke WhatsApp kau → app papar "Sedang diproses"
   (hasil sampai ke WhatsApp async, bukan serta-merta lepas upload)

Kod yang disimpan (`SharedPreferences`) so kalau tutup app dalam tempoh 24 jam
tu, buka balik terus ke skrin "Sedia!" tanpa kena activate semula.

## Semak update APK (GitHub Releases)

App ni auto-check GitHub Releases sekali setiap kali dibuka — kalau ada
version baru, papar dialog "Muat Turun". **Satu-satunya** tempat perlu
edit untuk set/tukar account atau repo:

```
lib/config/update_config.dart
```

```dart
static const String githubOwner = 'your-github-username';
static const String githubRepo = 'your-repo-name';
static const String githubToken = ''; // isi HANYA kalau repo private
```

Cara kerja: app panggil
`api.github.com/repos/{owner}/{repo}/releases/latest`, ambil `.apk` dalam
release assets, banding version tag dengan version app semasa
(`pubspec.yaml` → `version:`) — kalau GitHub punya lagi baru, papar dialog.
Publish release baru dengan tag macam `v1.0.1` + attach fail `.apk`, app
lama automatik detect.

⚠️ **Pasal token**: apa-apa string yang dibenam dalam APK (termasuk
`githubToken`) boleh diextract oleh sesiapa yang decompile APK tu — bukan
sesuatu yang susah nak buat. Kalau repo release boleh jadi **public**,
biar `githubToken` kosong — lagi selamat, tak payah risau pasal bocor
langsung. Kalau terpaksa private, guna Fine-grained PAT khusus repo tu
sahaja dengan permission "Contents: Read-only", dan set expiry — supaya
kalau bocor pun kerosakan terhad.

## Build APK yang di-obfuscate & signed

**0. Keystore — dah di-generate untuk kau** (`upload-keystore.jks` +
`key.properties`, both included dalam zip ni, root folder). Value rawak
(bukan nama/organisasi sebenar kau) — Android tak kisah pasal ketepatan
field tu untuk self-signed app key, so ni dah "bind" terus ke APK kau:

```
keyAlias=upload
storePassword=ZMbCTbyzV3bonwsT2612
keyPassword=ZMbCTbyzV3bonwsT2612
```

**⚠️ PENTING — baca ni dulu sebelum build:**
- **Backup fail `upload-keystore.jks` + password ni sekarang**, tempat
  lain (password manager / cloud storage peribadi) — BUKAN dalam repo git.
  Kalau fail ni hilang atau password lupa, kau **TAK BOLEH** update app ni
  lagi selama-lamanya dengan identity signing yang sama (Play Store
  especially — wajib signing key yang sama untuk setiap update, tiada
  cara reset senang).
- Pindah 2 fail ni (`upload-keystore.jks`, `key.properties`) ke root
  project (sebaris dengan `pubspec.yaml`) lepas `flutter create`.
- Tambah dalam `.gitignore` (yang `flutter create` generate tu):
  ```
  key.properties
  *.jks
  ```

**1. Wire keystore dalam `android/app/build.gradle`** (atau `.kts`):

```groovy
// build.gradle (Groovy) — letak ni di ATAS "android {" block
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('../key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```
```kotlin
// build.gradle.kts (Kotlin DSL) — letak ni di ATAS "android {" block
import java.util.Properties
import java.io.FileInputStream

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("../key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String?
            keyPassword = keystoreProperties["keyPassword"] as String?
            storeFile = keystoreProperties["storeFile"]?.let { file(it as String) }
            storePassword = keystoreProperties["storePassword"] as String?
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
```

Note: `rootProject.file('../key.properties')` sebab `key.properties` letak
kat project root, dan build.gradle ni baca dari `android/app/` — dua
level ke atas. Kalau kau letak `key.properties` terus dalam `android/`
(convention Flutter rasmi), tukar jadi `rootProject.file('key.properties')`
(satu `../` je, atau `file('key.properties')` bergantung struktur — try
both kalau error "file not found").

Copy `proguard-rules.pro` (included, root folder zip ni) ke
`android/app/proguard-rules.pro`.

**2. Build dengan Dart obfuscation** (lapisan paling penting sebab app ni
100% logic Dart):

```bash
flutter build apk --release --obfuscate --split-debug-info=./debug-info
```

⚠️ **Simpan folder `debug-info/` tu elok-elok** (jangan letak dalam APK/repo
public, tapi jangan delete/hilang jugak) — kalau app crash lepas ni, fail
tu yang boleh "translate" balik crash report yang dah di-obfuscate jadi
boleh baca. Hilang fail ni = crash report obfuscated build takkan boleh
di-debug selama-lamanya.

⚠️ **Kena jujur pasal limit obfuscate**: teknik ni obfuscate STRUKTUR kod
(nama class/method/variable jadi meaningless) — BUKAN encrypt string
literal. Kalau `update_config.dart` ada real token terbenam, string tu
*tetap* boleh dibaca terus guna `strings` command atas APK, tak kira
obfuscate ke tak. Sebab tu cadangan awal tadi still berdiri: biar repo
release tu public & `githubToken` kosong — obfuscation tak solve masalah
"secret dalam APK" punya risk, cuma buat logic app lain susah sikit nak
reverse-engineer.

## Kalau nak sesuaikan look

`lib/theme/app_theme.dart` je perlu ubah untuk tukar warna/font — semua
skrin rujuk token dari situ, tak hardcode warna kat mana-mana widget lain.
