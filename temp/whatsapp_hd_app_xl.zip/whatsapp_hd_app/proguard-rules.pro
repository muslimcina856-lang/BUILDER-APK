# Copy fail ni ke android/app/proguard-rules.pro lepas `flutter create`,
# dan rujuk dia dari android/app/build.gradle (tengok README, bahagian
# "Build APK yang di-obfuscate").

# Flutter engine reference Play Core (deferred components / split install)
# classes yang TAK masuk by default dalam projek fresh — tanpa rule ni, R8
# boleh warn/fail sebab class tu "missing" walaupun kita tak guna feature
# tu langsung.
-dontwarn com.google.android.play.core.**
-keep class com.google.android.play.core.** { *; }

# Defensive keep untuk Flutter framework sendiri — Flutter punya AAR dah
# bawa consumer-rules sendiri untuk ni, tapi explicit pun tak rugi apa.
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.** { *; }
-keep class io.flutter.util.** { *; }
-keep class io.flutter.view.** { *; }
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }

# Kalau lepas ni R8 masih complain pasal class lain yang "missing" (biasanya
# dari satu plugin tertentu), tampal error tu — boleh tambah -dontwarn atau
# -keep khusus untuk class tu. Kebanyakan plugin (file_picker, url_launcher,
# shared_preferences, package_info_plus, google_fonts, http) dah bawa
# consumer rules sendiri, so jarang perlu tambah apa-apa lagi.
