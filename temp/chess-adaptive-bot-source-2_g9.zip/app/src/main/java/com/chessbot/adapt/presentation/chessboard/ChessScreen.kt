package com.chessbot.adapt.presentation.chessboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.chessbot.adapt.domain.model.Color as ChessColor

@Composable
fun ChessScreen(viewModel: ChessBoardViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(state.isReady) {
        if (state.isReady && state.board == null) {
            viewModel.startNewGame(ChessColor.WHITE)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080818))
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        // ── Top Bar ────────────────────────────────────────────────────────
        TopBar(state)

        // ── Board — isi semua ruang yang tinggal ──────────────────────────
        BoxWithConstraints(
            modifier            = Modifier.fillMaxWidth().weight(1f),
            contentAlignment    = Alignment.Center
        ) {
            val boardSize = min(maxWidth, maxHeight * 0.98f)

            when {
                !state.isReady -> CircularProgressIndicator(
                    modifier    = Modifier.size(48.dp),
                    color       = Color(0xFF00E676),
                    strokeWidth = 3.dp
                )
                else -> ChessBoard3DView(
                    board          = state.board,
                    selectedSquare = state.selectedSquare,
                    validMoves     = state.validMoves,
                    lastMove       = state.lastMove,
                    isCheck        = state.isCheck,
                    checkColor     = if (state.isCheck) {
                        if (state.currentTurn == state.playerColor) state.playerColor
                        else state.botColor
                    } else null,
                    playerColor    = state.playerColor,
                    boardSize      = boardSize,
                    onSquareTap    = viewModel::onSquareTapped
                )
            }
        }

        // ── Bottom Panel ──────────────────────────────────────────────────
        BottomPanel(state, viewModel)
    }
}

// ─── Top Bar ──────────────────────────────────────────────────────────────────

@Composable
private fun TopBar(state: ChessBoardUiState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        // Title + Level badge
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Level badge
            Box(
                modifier         = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF00E676).copy(alpha = 0.15f))
                    .padding(horizontal = 12.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text       = "Lv ${state.currentLevel}",
                    color      = Color(0xFF00E676),
                    fontSize   = 13.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Column {
                Text("Chess Bot",
                    color      = Color(0xFFE8E8F8),
                    fontSize   = 17.sp,
                    fontWeight = FontWeight.Bold)
                Text(
                    if (state.currentTurn == state.playerColor) "Giliran kamu"
                    else "Giliran bot",
                    color    = if (state.currentTurn == state.playerColor)
                        Color(0xFF00E676) else Color(0xFF8888AA),
                    fontSize = 12.sp
                )
            }
        }

        // CHECK badge / Move count
        Column(horizontalAlignment = Alignment.End) {
            if (state.isCheck && state.gameResult == null) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFFF1744).copy(alpha = 0.18f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("⚠ CHECK",
                        color      = Color(0xFFFF1744),
                        fontSize   = 13.sp,
                        fontWeight = FontWeight.ExtraBold)
                }
            }
            if (state.moveHistory.isNotEmpty()) {
                Text("Langkah ${state.moveHistory.size}",
                    color    = Color(0xFF4A4A6A),
                    fontSize = 11.sp)
            }
        }
    }
}

// ─── Bottom Panel ─────────────────────────────────────────────────────────────

@Composable
private fun BottomPanel(state: ChessBoardUiState, viewModel: ChessBoardViewModel) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF0D0D20)))
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        when (state.gameResult) {
            null -> GameStatusRow(state)
            else -> GameResultCard(state.gameResult!!, state.currentLevel, viewModel::resetGame)
        }
    }
}

@Composable
private fun GameStatusRow(state: ChessBoardUiState) {
    Column(
        modifier            = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Bot thinking indicator OR status text
        if (state.isBotThinking) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CircularProgressIndicator(
                    modifier    = Modifier.size(18.dp),
                    color       = Color(0xFF00BCD4),
                    strokeWidth = 2.dp
                )
                Text("Bot sedang berfikir…",
                    color    = Color(0xFF00BCD4),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium)
            }
        }

        // Drag hint
        Text(
            "↻  Drag untuk putar papan",
            color    = Color(0xFF2E2E50),
            fontSize = 11.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun GameResultCard(result: String, level: Int, onPlayAgain: () -> Unit) {
    val (emoji, title, sub) = when (result) {
        "WIN"  -> Triple("🏆", "Kamu Menang!", "Bot dinaikkan ke Level $level")
        "LOSS" -> Triple("♟", "Bot Menang",   "Teruskan berlatih!")
        "DRAW" -> Triple("🤝", "Seri!",        "Permainan yang seimbang")
        else   -> Triple("🎯", result, "")
    }

    Column(
        modifier            = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(emoji, fontSize = 36.sp)
        Text(title,
            color      = Color(0xFFE8E8F8),
            fontSize   = 22.sp,
            fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty())
            Text(sub, color = Color(0xFF8888AA), fontSize = 13.sp)

        Spacer(Modifier.height(4.dp))
        Button(
            onClick = onPlayAgain,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
            shape    = RoundedCornerShape(12.dp)
        ) {
            Text("Main Lagi",
                color      = Color(0xFF002810),
                fontSize   = 16.sp,
                fontWeight = FontWeight.ExtraBold)
        }
    }
}
