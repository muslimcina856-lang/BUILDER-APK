package com.chessbot.adapt.presentation.chessboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.*
import kotlin.random.Random

/**
 * Jana bunyi catur kayu secara programatik.
 * Dua bunyi: letak bidak (click tajam) dan tangkap bidak (impact berganda).
 */
class ChessSoundManager(context: Context) {

    private val rate = 44100
    private var placeTrack:   AudioTrack? = null
    private var captureTrack: AudioTrack? = null

    init {
        runCatching {
            placeTrack   = buildTrack(genPlace())
            captureTrack = buildTrack(genCapture())
        }
    }

    fun playPlace()   = play(placeTrack)
    fun playCapture() = play(captureTrack)

    fun release() {
        runCatching { placeTrack?.release()   }
        runCatching { captureTrack?.release() }
    }

    // ─── private ─────────────────────────────────────────────────────────────

    private fun play(track: AudioTrack?) = runCatching {
        track?.takeIf { it.state == AudioTrack.STATE_INITIALIZED }?.let {
            it.stop(); it.reloadStaticData(); it.play()
        }
    }

    private fun buildTrack(buf: ShortArray): AudioTrack =
        AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build())
            .setBufferSizeInBytes(buf.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
            .also { it.write(buf, 0, buf.size) }

    /**
     * Bunyi letak bidak: transien tajam (0-5ms) + resonan badan kayu (5-140ms).
     * Seperti bidak kayu keras diletakkan di papan catur.
     */
    private fun genPlace(): ShortArray {
        val n   = rate * 140 / 1000
        val buf = ShortArray(n)
        val rng = Random(1337)

        for (i in buf.indices) {
            val t = i.toFloat() / rate

            // Transien impak: click singkat frekuensi tinggi
            val click = if (t < 0.006f)
                exp(-220f * t) * sin(2f * PI.toFloat() * 1800f * t) * 0.85f
            else 0f

            // Resonan badan kayu: harmonik perlahan
            val wood = if (t > 0.002f) {
                val tW = t - 0.002f
                exp(-18f * tW) * (
                    sin(2f * PI.toFloat() * 340f * tW) * 0.38f +
                    sin(2f * PI.toFloat() * 560f * tW) * 0.22f +
                    sin(2f * PI.toFloat() * 780f * tW) * 0.12f +
                    sin(2f * PI.toFloat() * 1020f * tW)* 0.06f
                )
            } else 0f

            // Tekstur bunyi impak (noise burst)
            val noise = if (t < 0.018f)
                exp(-90f * t) * (rng.nextFloat() * 2f - 1f) * 0.28f
            else 0f

            buf[i] = ((click + wood + noise) * 28_000f)
                .toInt().coerceIn(-32_767, 32_767).toShort()
        }
        return buf
    }

    /**
     * Bunyi tangkap bidak: impak pertama (bidak musuh jatuh/disingkir, 0ms)
     * + impak kedua (bidak kita diletakkan, ~70ms). Lebih berat dan dalam.
     */
    private fun genCapture(): ShortArray {
        val n   = rate * 210 / 1000
        val buf = ShortArray(n)
        val rng = Random(42)

        for (i in buf.indices) {
            val t = i.toFloat() / rate

            // Impak pertama: lebih dalam (bidak disingkir)
            val imp1Click = if (t < 0.008f)
                exp(-160f * t) * sin(2f * PI.toFloat() * 900f * t) * 0.60f
            else 0f
            val imp1Wood = if (t > 0.002f && t < 0.07f) {
                val tW = t - 0.002f
                exp(-22f * tW) * (
                    sin(2f * PI.toFloat() * 220f * tW) * 0.45f +
                    sin(2f * PI.toFloat() * 380f * tW) * 0.25f +
                    sin(2f * PI.toFloat() * 540f * tW) * 0.12f
                )
            } else 0f
            val imp1Noise = if (t < 0.022f)
                exp(-70f * t) * (rng.nextFloat() * 2f - 1f) * 0.32f
            else 0f

            // Impak kedua: ~70ms kemudian (letakkan bidak baru)
            val t2 = t - 0.068f
            val imp2 = if (t2 > 0f) {
                val click2 = if (t2 < 0.006f)
                    exp(-230f * t2) * sin(2f * PI.toFloat() * 1600f * t2) * 0.70f
                else 0f
                val wood2 = if (t2 > 0.002f) {
                    val tW = t2 - 0.002f
                    exp(-20f * tW) * (
                        sin(2f * PI.toFloat() * 320f * tW) * 0.34f +
                        sin(2f * PI.toFloat() * 520f * tW) * 0.18f +
                        sin(2f * PI.toFloat() * 730f * tW) * 0.09f
                    )
                } else 0f
                val noise2 = if (t2 < 0.016f)
                    exp(-85f * t2) * (rng.nextFloat() * 2f - 1f) * 0.24f
                else 0f
                click2 + wood2 + noise2
            } else 0f

            buf[i] = ((imp1Click + imp1Wood + imp1Noise + imp2) * 27_000f)
                .toInt().coerceIn(-32_767, 32_767).toShort()
        }
        return buf
    }
}
