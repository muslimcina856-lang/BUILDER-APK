# 🔴 EyeHawk OS

> **"Nothing Stays Hidden Forever"**

Open Source Intelligence (OSINT) Suite — built for professionals, researchers, and analysts. All-in-one reconnaissance toolkit packaged in a sleek Android application.

---

## 📖 Table of Contents

- [Features](#-features)
- [Architecture](#-architecture)
- [Tech Stack](#-tech-stack)
- [Installation](#-installation)
- [Modules](#-modules)
- [API Reference](#-api-reference)
- [Security](#-security)
- [About](#-about--credits)
- [Roadmap](#-roadmap)

---

## 🚀 Features

### 🔍 Full OSINT Toolkit
| Module | Description |
|--------|------------|
| **Vulture Target Builder** | Universal input parser, auto-detect email/phone/domain/username/IP/image |
| **Ghost Network Recon** | WHOIS, DNS, Subdomain, Port Scanner, SSL Inspector, Tech Fingerprint |
| **Phantom Social Dive** | 12+ social platforms — Facebook, Instagram, Twitter, LinkedIn, GitHub, TikTok, Telegram |
| **Shadow Email/Phone** | Email validator, breach check (HIBP), WhatsApp/Telegram/Signal checker |
| **Raven Image Forensics** | EXIF reader, reverse image search, QR/barcode, OCR, steganography detection |
| **Viper Breach Hunter** | Credential search, paste monitor, hash cracker, API key finder |
| **Orchestra** | Drag-and-drop chain builder, parallel execution, scheduled scans |
| **Report Generator** | PDF, JSON, CSV, HTML, Markdown export with full formatting |

### 🛡️ Security
- AES-256 encryption for all local data (SQLCipher)
- Biometric + PIN app lock
- Certificate pinning for network requests
- Screen capture blocking (FLAG_SECURE)
- Clipboard auto-clear (60 seconds)
- Kill switch with emergency data wipe gesture
- Anti-forensics: zero-fill on deletion

### 🔌 Standalone
- Full offline capabilities (EXIF, QR/Barcode, OCR, Hash tools)
- Local SQLite database with encryption
- No cloud dependency — user controls all data
- Plugin system for extendable modules

---

## 🏗️ Architecture

```
┌────────────────────────────────────────────┐
│              Flutter UI Layer              │
│  (Riverpod State, GoRouter Navigation)     │
├────────────────────────────────────────────┤
│              Core Engine (Dart)             │
│  ┌──────────┬──────────┬──────────────┐    │
│  │ Modules  │ Services │ API Layer    │    │
│  │ (8 mods) │(10 svcs) │ (15+ APIs)   │    │
│  └──────────┴──────────┴──────────────┘    │
├────────────────────────────────────────────┤
│              Data Layer                     │
│  ┌──────────┬──────────┬──────────────┐    │
│  │ Drift DB │ Hive KV  │ Secure Store │    │
│  │ (SQLite) │ (Cache)  │ (Encrypted)  │    │
│  └──────────┴──────────┴──────────────┘    │
├────────────────────────────────────────────┤
│         Native Android Bridge              │
│  (Background Services, Camera, Storage)     │
└────────────────────────────────────────────┘
```

---

## 💻 Tech Stack

| Technology | Version | Purpose |
|-----------|---------|---------|
| Flutter | 3.24+ | UI Framework |
| Dart | 3.5+ | Programming Language |
| Riverpod | 2.5+ | State Management |
| GoRouter | 14+ | Navigation & Deep Links |
| Drift | 2.20+ | SQLite Database |
| Hive | 2.2+ | Key-Value Cache |
| Dio | 5.7+ | HTTP Client |
| PointyCastle | 3.9+ | Encryption |
| Flutter Secure Storage | 9.2+ | Secure Key Storage |
| Share Plus | 10+ | Share Functionality |
| Path Provider | 2.1+ | File System |
| Image Picker | 1.1+ | Camera/Gallery |
| Mobile Scanner | 5.2+ | QR/Barcode |
| PDF | 3.11+ | Report Export |
| CSV | 6.0+ | Data Export |
| Flutter Map | 7.0+ | Geo Visualization |
| Local Auth | 2.3+ | Biometric Lock |
| URL Launcher | 6.3+ | Open External Links |
| Package Info Plus | 8.1+ | App Info |

---

## 📦 Installation

```bash
# Clone repository
git clone https://github.com/earlstore/eyehawk-os.git

# Navigate to project
cd eyehawk_os

# Get dependencies
flutter pub get

# Run code generation
dart run build_runner build --delete-conflicting-outputs

# Run on device
flutter run

# Build APK
flutter build apk --split-per-abi
```

**Requirements:**
- Flutter SDK >= 3.24.0
- Dart >= 3.5.0
- Android SDK 34+
- Java 17+

---

## 🧩 Modules

### Module 1: Vulture Target Builder
```dart
// Auto-detect input type
final result = await TargetBuilder.scan('@earlxz');
// Returns: InputType.username with linked social profiles
```

### Module 2: Ghost Network Recon
```dart
final dns = await NetworkRecon.dnsLookup('example.com');
final whois = await NetworkRecon.whois('example.com');
final subdomains = await NetworkRecon.subdomainEnum('example.com');
```

### Module 3: Phantom Social Deep Dive
```dart
final profiles = await SocialScanner.scan('username');
// Returns: Facebook, Instagram, Twitter, LinkedIn, GitHub, TikTok results
```

### Module 4: Shadow Email & Phone Hunter
```dart
final breach = await EmailHunter.checkBreach('user@example.com');
final wa = await PhoneHunter.checkWhatsApp('+60123456789');
```

### Module 5: Raven Image Forensics
```dart
final exif = await ImageForensics.readExif(imagePath);
final text = await ImageForensics.ocr(imagePath);
final qr = await ImageForensics.scanQR(imagePath);
```

### Module 6: Viper Breach Hunter
```dart
final leaks = await BreachHunter.search('username');
final hashType = await BreachHunter.identifyHash('5d414...');
```

### Module 7: Orchestra (Chain Builder)
```dart
final chain = OrchestraChain()
  ..add(TargetBuilder())
  ..add(NetworkRecon())
  ..add(SocialScanner());
final results = await chain.execute('target.com');
```

### Module 8: Report Generator
```dart
await ReportGenerator.export(
  format: ReportFormat.pdf,
  targets: targets,
  modules: modules,
  path: savePath,
);
```

---

## 🔧 API Reference

| Service | Free Tier | Docs |
|---------|-----------|------|
| Have I Been Pwned | API v3 | https://haveibeenpwned.com/API/v3 |
| ip-api.com | 45 req/min | https://ip-api.com/docs |
| crt.sh | Unlimited | https://crt.sh/ |
| Cloudflare DNS | Unlimited | https://developers.cloudflare.com/1.1.1.1 |
| AlienVault OTX | Unlimited | https://otx.alienvault.com/api |
| Google Images | Scraping | https://images.google.com |
| Yandex Images | Scraping | https://yandex.com/images |

---

## 🔒 Security

- **Database Encryption** — SQLCipher with AES-256
- **Secure Storage** — Android Keystore backed
- **Certificate Pinning** — All API calls pinned
- **Anti-Screenshot** — FLAG_SECURE on all windows
- **Biometric Lock** — Fingerprint + Face + PIN
- **Data Wipe** — Zero-fill secure deletion
- **Kill Switch** — Emergency gesture to wipe all data
- **Network Detection** — VPN/Proxy usage warning

---

## 📊 Database Schema

```sql
targets(id, input_type, input_value, display_name, risk_score, tags, last_scan_at, created_at)
scans(id, target_id, module, status, result_json, error_message, duration_ms, created_at)
alerts(id, target_id, change_type, old_value, new_value, is_read, created_at)
reports(id, title, target_ids, modules_used, format, file_path, created_at)
api_keys(service, api_key_encrypted, is_premium, created_at)
settings(key, value)
```

---

## 🛣️ Roadmap

- [x] v1.0 — Core modules (8), basic UI, report export
- [ ] v1.1 — Plugin system, dark web monitor, SMS spoof
- [ ] v1.2 — AI Profiler, Watchlist alerts, Chain builder UI
- [ ] v2.0 — Cloud sync, team sharing, web dashboard

---

## 👤 About & Credits

### 🔴 EyeHawk OS — by **Earl Store**

**Owner & Developer:** Earl Store

| Platform | Link |
|----------|------|
| 📢 **Telegram Channel** | [@earlstore2004](https://t.me/earlstore2004) |
| 👤 **Owner Account** | [@earlxz](https://t.me/earlxz) |
| 🌐 **Website** | Coming Soon |

> *"Built with precision. Delivered with quality. No compromises."* — **Earl Store**

---

## 📄 License

MIT License — See [LICENSE](LICENSE) for details.

```
Copyright (c) 2026 Earl Store

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  🔴 E Y E H A W K   O S
  "Nothing Stays Hidden Forever"
  Built by Earl Store • @earlstore2004
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
