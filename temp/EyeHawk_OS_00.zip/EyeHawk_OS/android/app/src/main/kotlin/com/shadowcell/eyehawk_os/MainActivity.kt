package com.shadowcell.eyehawk_os

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
