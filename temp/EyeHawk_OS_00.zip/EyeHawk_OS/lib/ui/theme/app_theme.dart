import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color background = Color(0xFF0D1117);
  static const Color surface = Color(0xFF161B22);
  static const Color card = Color(0xFF1C2333);
  static const Color primary = Color(0xFFE53935);
  static const Color secondary = Color(0xFF00E5FF);
  static const Color accent = Color(0xFFFFD600);
  static const Color text = Color(0xFFF5F5F5);
  static const Color subtext = Color(0xFF8B949E);
  static const Color success = Color(0xFF00C853);
  static const Color error = Color(0xFFFF1744);
  static const Color warning = Color(0xFFFF9100);
  static const Color border = Color(0xFF30363D);

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: background,
      colorScheme: const ColorScheme.dark(
        primary: primary,
        secondary: secondary,
        tertiary: accent,
        surface: surface,
        error: error,
      ),
      textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme).copyWith(
        displayLarge: GoogleFonts.jetBrainsMono(
          color: text, fontSize: 32, fontWeight: FontWeight.bold),
        displayMedium: GoogleFonts.jetBrainsMono(
          color: text, fontSize: 28, fontWeight: FontWeight.bold),
        headlineLarge: GoogleFonts.jetBrainsMono(
          color: text, fontSize: 24, fontWeight: FontWeight.w600),
        headlineMedium: GoogleFonts.inter(
          color: text, fontSize: 20, fontWeight: FontWeight.w600),
        titleLarge: GoogleFonts.inter(
          color: text, fontSize: 18, fontWeight: FontWeight.w600),
        titleMedium: GoogleFonts.inter(
          color: text, fontSize: 16, fontWeight: FontWeight.w500),
        bodyLarge: GoogleFonts.inter(color: text, fontSize: 16),
        bodyMedium: GoogleFonts.inter(color: subtext, fontSize: 14),
        bodySmall: GoogleFonts.inter(color: subtext, fontSize: 12),
        labelLarge: GoogleFonts.jetBrainsMono(
          color: text, fontSize: 14, fontWeight: FontWeight.w500),
      ),
      cardTheme: CardThemeData(
        color: card,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: border, width: 0.5),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: primary, width: 2),
        ),
        hintStyle: const TextStyle(color: subtext),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: background,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: text),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: primary,
        unselectedItemColor: subtext,
        type: BottomNavigationBarType.fixed,
      ),
      dividerTheme: const DividerThemeData(color: border, thickness: 0.5),
    );
  }
}
