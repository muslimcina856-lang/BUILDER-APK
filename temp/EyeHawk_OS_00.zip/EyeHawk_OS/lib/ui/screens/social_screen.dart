import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';
import '../../services/api_service.dart';

final socialUsernameProvider = StateProvider<String>((ref) => '');
final socialResultsProvider = StateProvider<Map<String, Map<String, dynamic>>>((ref) => {});
final socialScanningProvider = StateProvider<Set<String>>((ref) => {});

class SocialScreen extends ConsumerStatefulWidget {
  const SocialScreen({super.key});

  @override
  ConsumerState<SocialScreen> createState() => _SocialScreenState();
}

class _SocialScreenState extends ConsumerState<SocialScreen> {
  final _usernameController = TextEditingController();
  final _api = ApiService();

  @override
  void dispose() {
    _usernameController.dispose();
    super.dispose();
  }

  final _platforms = [
    ('GitHub', 'github', 0xFF333333, Icons.code),
    ('Twitter/X', 'twitter', 0xFF1DA1F2, Icons.alternate_email),
    ('Facebook', 'facebook', 0xFF1877F2, Icons.facebook),
    ('Instagram', 'instagram', 0xFFE4405F, Icons.camera_alt),
    ('Reddit', 'reddit', 0xFFFF4500, Icons.forum),
    ('TikTok', 'tiktok', 0xFF000000, Icons.music_note),
    ('YouTube', 'youtube', 0xFFFF0000, Icons.play_circle),
    ('Steam', 'steam', 0xFF171A21, Icons.sports_esports),
    ('VK', 'vk', 0xFF4C75A3, Icons.group),
    ('Snapchat', 'snapchat', 0xFFFFFC00, Icons.face),
    ('LinkedIn', 'linkedin', 0xFF0A66C2, Icons.business),
    ('Pinterest', 'pinterest', 0xFFBD081C, Icons.photo),
  ];

  Future<void> _scanAll() async {
    final username = _usernameController.text.trim();
    if (username.isEmpty) return;

    final cleanUsername = username.startsWith('@') ? username.substring(1) : username;
    ref.read(socialUsernameProvider.notifier).state = cleanUsername;
    ref.read(socialResultsProvider.notifier).state = {};
    ref.read(socialScanningProvider.notifier).state = _platforms.map((p) => p.$1).toSet();

    for (var (name, key, _, _) in _platforms) {
      final result = await _api.checkSocialProfile(key, cleanUsername);
      ref.read(socialResultsProvider.notifier).update((m) => {...m, name: result});
      ref.read(socialScanningProvider.notifier).update((s) => {...s}..remove(name));
    }
  }

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final results = ref.watch(socialResultsProvider);
    final scanning = ref.watch(socialScanningProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Phantom Social Dive')),
      body: Column(
        children: [
          // Input
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _usernameController,
                    style: const TextStyle(color: AppTheme.text),
                    decoration: InputDecoration(
                      hintText: 'Enter username (e.g., @earlxz)',
                      hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 14),
                      prefixIcon: const Icon(Icons.alternate_email, color: AppTheme.subtext),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                    onSubmitted: (_) => _scanAll(),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: scanning.isNotEmpty ? null : _scanAll,
                  icon: scanning.isNotEmpty
                      ? const SizedBox(
                          width: 16, height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.text),
                        )
                      : const Icon(Icons.search, size: 18),
                  label: Text(scanning.isNotEmpty ? 'Scanning...' : 'Scan All'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.secondary,
                    foregroundColor: AppTheme.background,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          ),

          // Results grid
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(12),
              children: _platforms.map((p) {
                final (name, key, color, icon) = p;
                final result = results[name];
                final isScanning = scanning.contains(name);
                final exists = result?['exists'] == true;

                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: exists ? Color(color).withAlpha(15) : AppTheme.card,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: exists ? Color(color).withAlpha(100) : AppTheme.border,
                      width: 0.5,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: Color(color).withAlpha(30),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(icon, color: Color(color), size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(name,
                              style: const TextStyle(color: AppTheme.text, fontWeight: FontWeight.w600)),
                            if (isScanning)
                              const Text('Scanning...', style: TextStyle(color: AppTheme.subtext, fontSize: 12))
                            else if (exists)
                              Text('Profile Found ✓',
                                style: TextStyle(color: AppTheme.success, fontSize: 12))
                            else if (result != null)
                              const Text('Not Found',
                                style: TextStyle(color: AppTheme.subtext, fontSize: 12)),
                          ],
                        ),
                      ),
                      if (isScanning)
                        const SizedBox(
                          width: 18, height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.subtext),
                        )
                      else if (exists && result!.containsKey('url'))
                        IconButton(
                          icon: const Icon(Icons.open_in_new, color: AppTheme.secondary, size: 18),
                          onPressed: () => _launchUrl(result['url'] as String),
                        )
                      else if (result != null && !exists)
                        const Icon(Icons.cancel, color: AppTheme.border, size: 18),
                    ],
                  ),
                ).animate().fadeIn(duration: 300.ms).slideX(begin: 0.03);
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
