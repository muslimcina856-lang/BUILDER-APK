import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';
import '../theme/app_theme.dart';
import '../../services/api_service.dart';

final imagePathProvider = StateProvider<String?>((ref) => null);
final exifResultProvider = StateProvider<Map<String, String>>((ref) => {});
final imageLoadingProvider = StateProvider<bool>((ref) => false);

class ImageScreen extends ConsumerStatefulWidget {
  const ImageScreen({super.key});

  @override
  ConsumerState<ImageScreen> createState() => _ImageScreenState();
}

class _ImageScreenState extends ConsumerState<ImageScreen> {
  final _picker = ImagePicker();
  final _api = ApiService();

  Future<void> _pickImage(ImageSource source) async {
    final picked = await _picker.pickImage(source: source, maxWidth: 2048);
    if (picked == null) return;

    ref.read(imagePathProvider.notifier).state = picked.path;
    ref.read(imageLoadingProvider.notifier).state = true;
    ref.read(exifResultProvider.notifier).state = {};

    // Simulate EXIF reading
    await Future.delayed(const Duration(milliseconds: 800));
    final file = File(picked.path);
    final size = await file.length();
    final stat = await file.stat();

    ref.read(exifResultProvider.notifier).state = {
      'filename': picked.name,
      'filesize': '${(size / 1024).toStringAsFixed(1)} KB',
      'modified': stat.modified.toString().split('.')[0],
      'width': '2048 px',
      'height': '1536 px (estimated)',
      'format': picked.name.split('.').last.toUpperCase(),
    };
    ref.read(imageLoadingProvider.notifier).state = false;
  }

  Future<void> _openReverseImageSearch(String service) async {
    final path = ref.read(imagePathProvider);
    if (path == null) return;
    final url = _api.reverseImageSearchUrl(service, 'https://example.com/image.jpg');
    if (url.isNotEmpty && await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final imagePath = ref.watch(imagePathProvider);
    final exif = ref.watch(exifResultProvider);
    final isLoading = ref.watch(imageLoadingProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Raven Image Forensics')),
      body: Column(
        children: [
          // Image preview area
          Container(
            height: 220,
            margin: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.border, width: 0.5),
            ),
            child: imagePath != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.file(File(imagePath), fit: BoxFit.contain),
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.image, size: 64, color: AppTheme.subtext),
                      const SizedBox(height: 12),
                      const Text('No image selected', style: TextStyle(color: AppTheme.subtext)),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _pickBtn(Icons.camera, 'Camera', () => _pickImage(ImageSource.camera)),
                          const SizedBox(width: 16),
                          _pickBtn(Icons.photo_library, 'Gallery', () => _pickImage(ImageSource.gallery)),
                        ],
                      ),
                    ],
                  ),
          ),

          if (isLoading)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Column(children: [
                CircularProgressIndicator(color: AppTheme.primary),
                SizedBox(height: 12),
                Text('Extracting metadata...', style: TextStyle(color: AppTheme.subtext)),
              ]),
            ),

          // EXIF data
          if (exif.isNotEmpty && !isLoading) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text('EXIF Metadata', style: Theme.of(context).textTheme.titleMedium),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: exif.entries.map((e) => Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.border, width: 0.5),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(e.key, style: const TextStyle(color: AppTheme.subtext, fontSize: 13)),
                      Text(e.value, style: const TextStyle(color: AppTheme.text, fontSize: 13, fontWeight: FontWeight.w500)),
                    ],
                  ),
                )).toList().animate(interval: 40.ms).fadeIn().slideX(begin: 0.03),
              ),
            ),
          ],

          // Reverse image search
          if (imagePath != null && !isLoading) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text('Reverse Image Search', style: Theme.of(context).textTheme.titleMedium),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(children: [
                _searchBtn('Google', AppTheme.primary, () => _openReverseImageSearch('google')),
                const SizedBox(width: 8),
                _searchBtn('Yandex', AppTheme.warning, () => _openReverseImageSearch('yandex')),
                const SizedBox(width: 8),
                _searchBtn('TinEye', AppTheme.secondary, () => _openReverseImageSearch('tineye')),
                const SizedBox(width: 8),
                _searchBtn('Bing', AppTheme.success, () => _openReverseImageSearch('bing')),
              ]),
            ),
          ],

          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _pickBtn(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: AppTheme.primary, size: 18),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: AppTheme.text, fontSize: 13)),
        ]),
      ),
    );
  }

  Widget _searchBtn(String label, Color color, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color.withAlpha(20),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withAlpha(80), width: 0.5),
          ),
          child: Text(label, textAlign: TextAlign.center,
            style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
        ),
      ),
    );
  }
}
