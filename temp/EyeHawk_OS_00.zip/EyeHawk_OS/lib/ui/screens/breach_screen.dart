import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:math';
import '../theme/app_theme.dart';

final breachInputProvider = StateProvider<String>((ref) => '');
final breachResultsProvider = StateProvider<List<Map<String, dynamic>>>((ref) => []);
final breachLoadingProvider = StateProvider<bool>((ref) => false);
final hashResultProvider = StateProvider<Map<String, String>>((ref) => {});

class BreachScreen extends ConsumerStatefulWidget {
  const BreachScreen({super.key});

  @override
  ConsumerState<BreachScreen> createState() => _BreachScreenState();
}

class _BreachScreenState extends ConsumerState<BreachScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchController = TextEditingController();
  final _hashController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _hashController.dispose();
    super.dispose();
  }

  void _searchLeaks() {
    final query = _searchController.text.trim();
    if (query.isEmpty) return;
    ref.read(breachLoadingProvider.notifier).state = true;
    ref.read(breachResultsProvider.notifier).state = [];

    // Simulate search with dummy data for demonstration
    Future.delayed(const Duration(seconds: 1), () {
      final dummyResults = _generateDummyLeaks(query);
      ref.read(breachResultsProvider.notifier).state = dummyResults;
      ref.read(breachLoadingProvider.notifier).state = false;
    });
  }

  void _identifyHash() {
    final hash = _hashController.text.trim();
    if (hash.isEmpty) return;
    ref.read(hashResultProvider.notifier).state = _identifyHashType(hash);
  }

  List<Map<String, dynamic>> _generateDummyLeaks(String query) {
    final sources = ['Pastebin', 'JustPaste', 'Rentry', 'Ghostbin', 'Darknet Forum'];
    final rng = Random(query.hashCode);
    final count = rng.nextInt(4) + 1;
    return List.generate(count, (i) => {
      'source': sources[rng.nextInt(sources.length)],
      'date': DateTime.now().subtract(Duration(days: rng.nextInt(365))).toIso8601String().split('T')[0],
      'snippet': '...${query}... found in leaked database dump',
      'severity': ['low', 'medium', 'high', 'critical'][rng.nextInt(4)],
      'url': 'https://example.com/leak/${rng.nextInt(9999)}',
    });
  }

  Map<String, String> _identifyHashType(String hash) {
    final len = hash.length;
    final hexOnly = RegExp(r'^[0-9a-fA-F]+$').hasMatch(hash);
    final base64 = RegExp(r'^[A-Za-z0-9+/=]+$').hasMatch(hash);

    if (!hexOnly && !base64) return {'type': 'Unknown', 'confidence': '0%', 'note': 'Not a recognized hash format'};

    if (len == 32 && hexOnly) return {'type': 'MD5', 'confidence': 'High', 'note': '32-char hex → Likely MD5'};
    if (len == 40 && hexOnly) return {'type': 'SHA-1', 'confidence': 'High', 'note': '40-char hex → Likely SHA-1'};
    if (len == 64 && hexOnly) return {'type': 'SHA-256', 'confidence': 'High', 'note': '64-char hex → Likely SHA-256'};
    if (len == 96 && hexOnly) return {'type': 'SHA-384', 'confidence': 'Medium', 'note': '96-char hex → Likely SHA-384'};
    if (len == 128 && hexOnly) return {'type': 'SHA-512', 'confidence': 'High', 'note': '128-char hex → Likely SHA-512'};
    if (len == 60 && base64 && hash.startsWith(r'$2')) return {'type': 'bcrypt', 'confidence': 'High', 'note': r'$2* prefix → bcrypt'};
    if (len == 34 && base64) return {'type': 'CRC32', 'confidence': 'Low', 'note': 'Short hash, could be CRC32'};

    return {'type': 'Unknown', 'confidence': 'Low', 'note': 'Hash format not recognized automatically'};
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Viper Breach Hunter'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.error,
          labelColor: AppTheme.error,
          unselectedLabelColor: AppTheme.subtext,
          tabs: const [
            Tab(text: 'Search', icon: Icon(Icons.search, size: 18)),
            Tab(text: 'Hash Cracker', icon: Icon(Icons.fingerprint, size: 18)),
            Tab(text: 'API Keys', icon: Icon(Icons.vpn_key, size: 18)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildSearchTab(),
          _buildHashTab(),
          _buildApiKeyTab(),
        ],
      ),
    );
  }

  Widget _buildSearchTab() {
    final isLoading = ref.watch(breachLoadingProvider);
    final results = ref.watch(breachResultsProvider);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _searchController,
                style: const TextStyle(color: AppTheme.text),
                decoration: InputDecoration(
                  hintText: 'Username, email, or keyword...',
                  hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 14),
                  prefixIcon: const Icon(Icons.search, color: AppTheme.subtext),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
                onSubmitted: (_) => _searchLeaks(),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: isLoading ? null : _searchLeaks,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.error,
                foregroundColor: AppTheme.text,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: isLoading
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.text))
                  : const Text('Hunt'),
            ),
          ]),
        ),
        Expanded(
          child: results.isEmpty && !isLoading
              ? _emptyTab('Enter search query to hunt for leaks')
              : ListView(
                  padding: const EdgeInsets.all(12),
                  children: results.asMap().entries.map((e) {
                    final res = e.value;
                    final severityColor = {
                      'low': AppTheme.success, 'medium': AppTheme.warning,
                      'high': AppTheme.error, 'critical': AppTheme.primary,
                    }[res['severity']] ?? AppTheme.subtext;

                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppTheme.card,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppTheme.border, width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: (severityColor as Color).withAlpha(20),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(res['severity'].toString().toUpperCase(),
                                style: TextStyle(color: severityColor, fontSize: 10, fontWeight: FontWeight.bold)),
                            ),
                            const SizedBox(width: 8),
                            Text(res['source'].toString(), style: const TextStyle(color: AppTheme.text, fontSize: 13, fontWeight: FontWeight.w600)),
                            const Spacer(),
                            Text(res['date'].toString(), style: const TextStyle(color: AppTheme.subtext, fontSize: 11)),
                          ]),
                          const SizedBox(height: 8),
                          Text(res['snippet'].toString(), style: const TextStyle(color: AppTheme.subtext, fontSize: 12)),
                        ],
                      ),
                    ).animate(delay: Duration(milliseconds: e.key * 80)).fadeIn().slideX(begin: 0.04);
                  }).toList(),
                ),
        ),
      ],
    );
  }

  Widget _buildHashTab() {
    final hashResult = ref.watch(hashResultProvider);

    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(
            controller: _hashController,
            style: const TextStyle(color: AppTheme.text, fontFamily: 'monospace'),
            decoration: InputDecoration(
              hintText: 'Paste hash here (e.g., 5d41402abc4b2a76b9719d911017c592)',
              hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 13),
              prefixIcon: const Icon(Icons.fingerprint, color: AppTheme.subtext),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
            onChanged: (_) => _identifyHash(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _identifyHash(),
              icon: const Icon(Icons.fingerprint, size: 18),
              label: const Text('Identify'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.error,
                foregroundColor: AppTheme.text,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ]),
      ),
      if (hashResult.isNotEmpty)
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 12),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.border, width: 0.5),
          ),
          child: Column(children: [
            Icon(
              hashResult['type'] != 'Unknown' ? Icons.check_circle : Icons.help_outline,
              color: hashResult['type'] != 'Unknown' ? AppTheme.success : AppTheme.warning, size: 48,
            ),
            const SizedBox(height: 12),
            Text('Hash Type: ${hashResult['type']}',
              style: const TextStyle(color: AppTheme.text, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('Confidence: ${hashResult['confidence']}',
              style: const TextStyle(color: AppTheme.subtext, fontSize: 13)),
            const SizedBox(height: 4),
            Text(hashResult['note'] ?? '', style: const TextStyle(color: AppTheme.subtext, fontSize: 12)),
          ]).animate().scale(duration: 300.ms),
        ),
    ]);
  }

  Widget _buildApiKeyTab() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.vpn_key, size: 64, color: AppTheme.subtext),
          const SizedBox(height: 16),
          const Text('API Key Scanner', style: TextStyle(color: AppTheme.text, fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text('Scans text/code for exposed API keys, tokens, and credentials', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.subtext)),
          const SizedBox(height: 24),
          _apiDemo('AWS Access Key', r'^AKIA[0-9A-Z]{16}$'),
          _apiDemo('GitHub Token', r'^ghp_[0-9a-zA-Z]{36}$'),
          _apiDemo('Google API', r'^AIza[0-9A-Za-z\-_]{35}$'),
          _apiDemo('Slack Token', r'^xox[baprs]-[0-9a-zA-Z\-]+$'),
          _apiDemo('Stripe Key', r'^sk_live_[0-9a-zA-Z]{24}$'),
        ]),
      ),
    );
  }

  Widget _apiDemo(String name, String pattern) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Row(children: [
        const Icon(Icons.code, color: AppTheme.warning, size: 16),
        const SizedBox(width: 10),
        Text(name, style: const TextStyle(color: AppTheme.text, fontSize: 13)),
        const Spacer(),
        Text(pattern, style: const TextStyle(color: AppTheme.subtext, fontSize: 10, fontFamily: 'monospace')),
      ]),
    );
  }

  Widget _emptyTab(String message) {
    return Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.warning_amber, size: 64, color: AppTheme.subtext),
        const SizedBox(height: 16),
        Text(message, style: const TextStyle(color: AppTheme.subtext)),
      ]),
    );
  }
}
