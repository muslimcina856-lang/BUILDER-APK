import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_theme.dart';

class ReportScreen extends ConsumerStatefulWidget {
  const ReportScreen({super.key});

  @override
  ConsumerState<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends ConsumerState<ReportScreen> {
  String _selectedFormat = 'PDF';
  final Set<String> _selectedModules = {};
  final _titleController = TextEditingController();

  @override
  void dispose() {
    _titleController.dispose();
    super.dispose();
  }

  final _formats = [
    ('PDF', Icons.picture_as_pdf, AppTheme.error),
    ('JSON', Icons.code, AppTheme.warning),
    ('CSV', Icons.table_chart, AppTheme.success),
    ('HTML', Icons.web, AppTheme.secondary),
    ('Markdown', Icons.article, AppTheme.accent),
  ];

  final _modules = [
    'WHOIS', 'DNS', 'Subdomain', 'IP Intel', 'SSL',
    'Social', 'Email', 'Image EXIF', 'Breach', 'Tech Stack',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Report Generator')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Title input
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.border, width: 0.5),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.description, color: const Color(0xFF7C4DFF), size: 36),
              const SizedBox(height: 12),
              const Text('Report Title', style: TextStyle(color: AppTheme.text, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              TextField(
                controller: _titleController,
                style: const TextStyle(color: AppTheme.text),
                decoration: InputDecoration(
                  hintText: 'e.g., OSINT Report - target.com',
                  hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 14),
                ),
              ),
            ]),
          ).animate().fadeIn(),

          const SizedBox(height: 16),

          // Format selector
          Text('Export Format', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Row(
            children: _formats.map((f) {
              final (label, icon, color) = f;
              final isSelected = _selectedFormat == label;
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: InkWell(
                    onTap: () => setState(() => _selectedFormat = label),
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: isSelected ? (color as Color).withAlpha(25) : AppTheme.card,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: isSelected ? color : AppTheme.border,
                          width: isSelected ? 2 : 0.5,
                        ),
                      ),
                      child: Column(children: [
                        Icon(icon, color: isSelected ? color : AppTheme.subtext, size: 22),
                        const SizedBox(height: 4),
                        Text(label, style: TextStyle(
                          color: isSelected ? color : AppTheme.subtext,
                          fontSize: 11, fontWeight: FontWeight.w600,
                        )),
                      ]),
                    ),
                  ),
                ),
              );
            }).toList(),
          ).animate().fadeIn(delay: 100.ms),

          const SizedBox(height: 16),

          // Module selector
          Text('Include Modules', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: _modules.map((m) {
              final isSelected = _selectedModules.contains(m);
              return FilterChip(
                label: Text(m, style: TextStyle(
                  color: isSelected ? AppTheme.text : AppTheme.subtext,
                  fontSize: 12,
                )),
                selected: isSelected,
                onSelected: (val) {
                  setState(() {
                    if (val) _selectedModules.add(m);
                    else _selectedModules.remove(m);
                  });
                },
                backgroundColor: AppTheme.card,
                selectedColor: const Color(0xFF7C4DFF).withAlpha(30),
                checkmarkColor: const Color(0xFF7C4DFF),
                side: BorderSide(
                  color: isSelected ? const Color(0xFF7C4DFF) : AppTheme.border,
                ),
              );
            }).toList(),
          ).animate().fadeIn(delay: 200.ms),

          const SizedBox(height: 24),

          // Generate button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _selectedModules.isEmpty
                  ? null
                  : () {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Generating $_selectedFormat report...'),
                        backgroundColor: const Color(0xFF7C4DFF),
                        duration: const Duration(seconds: 2),
                      ));
                    },
              icon: const Icon(Icons.download, size: 20),
              label: Text('Generate $_selectedFormat Report (${_selectedModules.length} modules)'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF7C4DFF),
                foregroundColor: AppTheme.text,
                disabledBackgroundColor: AppTheme.surface,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ).animate().fadeIn(delay: 300.ms),

          const SizedBox(height: 24),

          // Preview
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border, width: 0.5),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Preview Structure', style: TextStyle(color: AppTheme.subtext, fontSize: 12, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              _previewLine('📋 Title: ${_titleController.text.isNotEmpty ? _titleController.text : "[Enter title]"}'),
              _previewLine('📅 Date: ${DateTime.now().toIso8601String().split("T")[0]}'),
              _previewLine('📄 Format: $_selectedFormat'),
              _previewLine('🔧 Modules: ${_selectedModules.isEmpty ? "[Select modules]" : _selectedModules.join(", ")}'),
              _previewLine('👤 Generated by: EyeHawk OS v1.0.0'),
              _previewLine('💼 Owner: Earl Store • @earlstore2004'),
            ]),
          ).animate().fadeIn(delay: 400.ms),
        ],
      ),
    );
  }

  Widget _previewLine(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(text, style: const TextStyle(color: AppTheme.text, fontSize: 13, fontFamily: 'monospace')),
    );
  }
}
