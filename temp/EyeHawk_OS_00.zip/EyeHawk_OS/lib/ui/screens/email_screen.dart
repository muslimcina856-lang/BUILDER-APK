import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';
import '../../services/api_service.dart';

final emailInputProvider = StateProvider<String>((ref) => '');
final emailResultsProvider = StateProvider<Map<String, dynamic>>((ref) => {});
final emailLoadingProvider = StateProvider<bool>((ref) => false);

class EmailScreen extends ConsumerStatefulWidget {
  const EmailScreen({super.key});

  @override
  ConsumerState<EmailScreen> createState() => _EmailScreenState();
}

class _EmailScreenState extends ConsumerState<EmailScreen> {
  final _inputController = TextEditingController();
  final _api = ApiService();

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

  Future<void> _runEmailBreach(String email) async {
    ref.read(emailLoadingProvider.notifier).state = true;
    ref.read(emailResultsProvider.notifier).state = {};
    final result = await _api.checkBreach(email);
    ref.read(emailResultsProvider.notifier).state = result;
    ref.read(emailLoadingProvider.notifier).state = false;
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = ref.watch(emailLoadingProvider);
    final results = ref.watch(emailResultsProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Shadow Email & Phone')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _inputController,
                    style: const TextStyle(color: AppTheme.text),
                    decoration: InputDecoration(
                      hintText: 'Email or phone number...',
                      hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 14),
                      prefixIcon: const Icon(Icons.email, color: AppTheme.subtext),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                    onSubmitted: (v) => _runEmailBreach(v),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: isLoading ? null : () => _runEmailBreach(_inputController.text.trim()),
                  icon: isLoading
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.text))
                      : const Icon(Icons.search, size: 18),
                  label: Text(isLoading ? 'Checking...' : 'Check'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.warning,
                    foregroundColor: AppTheme.background,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: results.isEmpty && !isLoading
                ? _emptyState()
                : _buildResults(results),
          ),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.email, size: 64, color: AppTheme.subtext),
          const SizedBox(height: 16),
          const Text('Enter an email to check for breaches', style: TextStyle(color: AppTheme.subtext)),
          const SizedBox(height: 24),
          _buildDemoCards(),
        ],
      ),
    );
  }

  Widget _buildDemoCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Text('Supported Checks', style: TextStyle(color: AppTheme.text.withAlpha(178), fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          _demoCard(Icons.warning_amber, 'Breach Database (HIBP)', 'Check Have I Been Pwned'),
          _demoCard(Icons.phone, 'WhatsApp/Telegram', 'Check messenger presence'),
          _demoCard(Icons.verified, 'Email Validator', 'Validate email format & MX'),
          _demoCard(Icons.shield, 'Paste Monitor', 'Check paste sites for leaks'),
        ],
      ),
    );
  }

  Widget _demoCard(IconData icon, String title, String subtitle) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppTheme.warning, size: 20),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: AppTheme.text, fontSize: 13)),
            Text(subtitle, style: const TextStyle(color: AppTheme.subtext, fontSize: 11)),
          ]),
        ],
      ),
    ).animate().fadeIn(duration: 300.ms);
  }

  Widget _buildResults(Map<String, dynamic> results) {
    if (results.containsKey('error')) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, size: 64, color: AppTheme.error),
          const SizedBox(height: 16),
          Text(results['error'].toString(), style: const TextStyle(color: AppTheme.error), textAlign: TextAlign.center),
        ]),
      );
    }

    final breaches = (results['breaches'] as List<dynamic>?) ?? [];
    final count = results['breach_count'] ?? 0;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Summary card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: count == 0
                  ? [AppTheme.success.withAlpha(30), AppTheme.card]
                  : [AppTheme.error.withAlpha(30), AppTheme.card],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.border, width: 0.5),
          ),
          child: Column(
            children: [
              Icon(count == 0 ? Icons.shield : Icons.warning_amber,
                  color: count == 0 ? AppTheme.success : AppTheme.error, size: 48),
              const SizedBox(height: 12),
              Text(results['email']?.toString() ?? '', style: const TextStyle(color: AppTheme.text, fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Text(
                count == 0 ? 'No breaches found! 🎉' : 'Found in $count breach(es)!',
                style: TextStyle(
                  color: count == 0 ? AppTheme.success : AppTheme.error,
                  fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ).animate().scale(duration: 400.ms),
        const SizedBox(height: 16),

        // Breach list
        if (breaches.isNotEmpty) ...[
          _sectionHeader('Breach Details'),
          ...breaches.asMap().entries.map((e) {
            final b = e.value as Map<String, dynamic>;
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.border, width: 0.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppTheme.error.withAlpha(30),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(b['name']?.toString() ?? 'Unknown',
                          style: const TextStyle(color: AppTheme.error, fontSize: 12, fontWeight: FontWeight.bold)),
                    ),
                    const Spacer(),
                    Text(b['date']?.toString() ?? '', style: const TextStyle(color: AppTheme.subtext, fontSize: 11)),
                  ]),
                  const SizedBox(height: 8),
                  Text(b['description']?.toString() ?? '', style: const TextStyle(color: AppTheme.text, fontSize: 13), maxLines: 3),
                  if (b['data_classes'] != null && (b['data_classes'] as List).isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 4, runSpacing: 4,
                      children: (b['data_classes'] as List).map<Widget>((c) => Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppTheme.surface,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(c.toString(), style: const TextStyle(color: AppTheme.subtext, fontSize: 10)),
                      )).toList(),
                    ),
                  ],
                ],
              ),
            ).animate(delay: Duration(milliseconds: e.key * 100)).fadeIn().slideX(begin: 0.05);
          }),
        ],
      ],
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(title, style: const TextStyle(color: AppTheme.primary, fontSize: 14, fontWeight: FontWeight.w600)),
    );
  }
}
