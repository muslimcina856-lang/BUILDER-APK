import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_theme.dart';
import '../../services/api_service.dart';

final networkInputProvider = StateProvider<String>((ref) => '');
final networkResultsProvider = StateProvider<Map<String, dynamic>>((ref) => {});
final networkLoadingProvider = StateProvider<bool>((ref) => false);

class NetworkScreen extends ConsumerStatefulWidget {
  const NetworkScreen({super.key});

  @override
  ConsumerState<NetworkScreen> createState() => _NetworkScreenState();
}

class _NetworkScreenState extends ConsumerState<NetworkScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _inputController = TextEditingController();
  final _api = ApiService();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _inputController.dispose();
    super.dispose();
  }

  Future<void> _runWhois(String domain) async {
    ref.read(networkLoadingProvider.notifier).state = true;
    final result = await _api.whoisLookup(domain);
    ref.read(networkResultsProvider.notifier).update((s) => {...s, 'whois': result});
    ref.read(networkLoadingProvider.notifier).state = false;
  }

  Future<void> _runDns(String domain) async {
    ref.read(networkLoadingProvider.notifier).state = true;
    final result = await _api.dnsLookup(domain);
    ref.read(networkResultsProvider.notifier).update((s) => {...s, 'dns': result});
    ref.read(networkLoadingProvider.notifier).state = false;
  }

  Future<void> _runSubdomain(String domain) async {
    ref.read(networkLoadingProvider.notifier).state = true;
    final result = await _api.subdomainEnum(domain);
    ref.read(networkResultsProvider.notifier).update((s) => {...s, 'subdomains': result});
    ref.read(networkLoadingProvider.notifier).state = false;
  }

  Future<void> _runIpLookup(String ip) async {
    ref.read(networkLoadingProvider.notifier).state = true;
    final result = await _api.ipLookup(ip);
    ref.read(networkResultsProvider.notifier).update((s) => {...s, 'iplookup': result});
    ref.read(networkLoadingProvider.notifier).state = false;
  }

  Future<void> _runSsl(String domain) async {
    ref.read(networkLoadingProvider.notifier).state = true;
    final result = await _api.sslInspect(domain);
    ref.read(networkResultsProvider.notifier).update((s) => {...s, 'ssl': result});
    ref.read(networkLoadingProvider.notifier).state = false;
  }

  Future<void> _techFingerprint(String url) async {
    ref.read(networkLoadingProvider.notifier).state = true;
    final result = await _api.techFingerprint(url);
    ref.read(networkResultsProvider.notifier).update((s) => {...s, 'tech': result});
    ref.read(networkLoadingProvider.notifier).state = false;
  }

  void _runAll() {
    final input = _inputController.text.trim();
    if (input.isEmpty) return;
    ref.read(networkInputProvider.notifier).state = input;
    ref.read(networkResultsProvider.notifier).state = {};

    final isIp = RegExp(
        r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$')
        .hasMatch(input);

    if (isIp) {
      _runIpLookup(input);
    } else {
      _runWhois(input);
      _runDns(input);
      _runSubdomain(input);
      _runSsl(input);
      _techFingerprint(input);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = ref.watch(networkLoadingProvider);
    final results = ref.watch(networkResultsProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Ghost Network Recon'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: AppTheme.primary,
          labelColor: AppTheme.primary,
          unselectedLabelColor: AppTheme.subtext,
          tabs: const [
            Tab(text: 'WHOIS'),
            Tab(text: 'DNS'),
            Tab(text: 'Subdomains'),
            Tab(text: 'IP Intel'),
            Tab(text: 'SSL/Tech'),
          ],
        ),
      ),
      body: Column(
        children: [
          // Input bar
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _inputController,
                    style: const TextStyle(color: AppTheme.text),
                    decoration: InputDecoration(
                      hintText: 'Enter domain or IP...',
                      hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 14),
                      prefixIcon: const Icon(Icons.language, color: AppTheme.subtext),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                    onSubmitted: (_) => _runAll(),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: isLoading ? null : _runAll,
                  icon: isLoading
                      ? const SizedBox(
                          width: 16, height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.text),
                        )
                      : const Icon(Icons.radar, size: 18),
                  label: Text(isLoading ? 'Scanning...' : 'Scan'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primary,
                    foregroundColor: AppTheme.text,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          ),

          // Results
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildWhoisTab(results),
                _buildDnsTab(results),
                _buildSubdomainTab(results),
                _buildIpTab(results),
                _buildSslTechTab(results),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWhoisTab(Map<String, dynamic> results) {
    final data = results['whois'];
    if (data == null) return _emptyTab('Run WHOIS scan to see results');
    if (data.containsKey('error')) return _errorTab(data['error'].toString());

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _resultCard('Domain', data['domain']?.toString() ?? 'N/A', Icons.language),
        _resultCard('Registrar', data['registrar']?.toString() ?? 'N/A', Icons.business),
        _resultCard('Created', data['created_at']?.toString() ?? 'N/A', Icons.calendar_today),
        _resultCard('Expires', data['expires_at']?.toString() ?? 'N/A', Icons.timer),
      ].animate(interval: 50.ms).fadeIn().slideX(begin: 0.05),
    );
  }

  Widget _buildDnsTab(Map<String, dynamic> results) {
    final data = results['dns'];
    if (data == null) return _emptyTab('Run DNS lookup to see results');
    if (data.containsKey('error')) return _errorTab(data['error'].toString());

    final ips = (data['ip_addresses'] as List<dynamic>?) ?? [];
    final cn = (data['cname'] as List<dynamic>?) ?? [];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionHeader('A Records (${ips.length})'),
        ...ips.map((ip) => _resultCard('IP Address', ip.toString(), Icons.computer)),
        if (cn.isNotEmpty) ...[
          const SizedBox(height: 12),
          _sectionHeader('CNAME Records (${cn.length})'),
          ...cn.map((c) => _resultCard('CNAME', c.toString(), Icons.arrow_forward)),
        ],
      ].animate(interval: 50.ms).fadeIn().slideX(begin: 0.05),
    );
  }

  Widget _buildSubdomainTab(Map<String, dynamic> results) {
    final data = results['subdomains'];
    if (data == null) return _emptyTab('Run subdomain scan to see results');

    final subs = data as List<dynamic>;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionHeader('Subdomains Found: ${subs.length}'),
        ...subs.map((s) {
          final text = s.toString();
          final isError = text.startsWith('Error:');
          return Container(
            margin: const EdgeInsets.only(bottom: 4),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: isError ? AppTheme.error.withAlpha(15) : AppTheme.surface,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Icon(isError ? Icons.error : Icons.dns, color: isError ? AppTheme.error : AppTheme.success, size: 16),
                const SizedBox(width: 10),
                Expanded(child: Text(text, style: TextStyle(
                  color: isError ? AppTheme.error : AppTheme.text,
                  fontSize: 13,
                  fontFamily: 'monospace',
                ))),
              ],
            ),
          );
        }),
      ].animate(interval: 30.ms).fadeIn().slideX(begin: 0.05),
    );
  }

  Widget _buildIpTab(Map<String, dynamic> results) {
    final data = results['iplookup'];
    if (data == null) return _emptyTab('Run IP lookup to see results');
    if (data.containsKey('error')) return _errorTab(data['error'].toString());

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _resultCard('IP', data['ip']?.toString() ?? 'N/A', Icons.computer),
        _resultCard('Country', data['country']?.toString() ?? 'N/A', Icons.flag),
        _resultCard('City', data['city']?.toString() ?? 'N/A', Icons.location_city),
        _resultCard('ISP', data['isp']?.toString() ?? 'N/A', Icons.business),
        _resultCard('Organization', data['org']?.toString() ?? 'N/A', Icons.corporate_fare),
        _resultCard('Timezone', data['timezone']?.toString() ?? 'N/A', Icons.schedule),
        _boolCard('Mobile Network', data['mobile'] ?? false),
        _boolCard('Proxy/VPN', data['proxy'] ?? false),
        _boolCard('Hosting', data['hosting'] ?? false),
      ].animate(interval: 50.ms).fadeIn().slideX(begin: 0.05),
    );
  }

  Widget _buildSslTechTab(Map<String, dynamic> results) {
    final ssl = results['ssl'];
    final tech = results['tech'];

    final items = <Widget>[];
    if (ssl != null && !ssl.containsKey('error')) {
      final certs = (ssl['certificates'] as List<dynamic>?) ?? [];
      items.add(_sectionHeader('SSL Certificates (${certs.length})'));
      for (var cert in certs) {
        items.add(_resultCard('Issuer', cert['issuer']?.toString() ?? 'N/A', Icons.security));
        items.add(_resultCard('Valid From', cert['valid_from']?.toString() ?? 'N/A', Icons.calendar_today));
        items.add(_resultCard('Valid To', cert['valid_to']?.toString() ?? 'N/A', Icons.timer));
        items.add(const Divider(color: AppTheme.border));
      }
    }

    if (tech != null && !tech.containsKey('error')) {
      items.add(_sectionHeader('Technology Stack'));
      items.add(_resultCard('Server', tech['server']?.toString() ?? 'N/A', Icons.dns));
      items.add(_resultCard('Powered By', tech['powered_by']?.toString() ?? 'N/A', Icons.bolt));
      final techs = (tech['technologies'] as List<dynamic>?) ?? [];
      if (techs.isNotEmpty) {
        items.add(const SizedBox(height: 4));
        items.add(Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Wrap(
            spacing: 6, runSpacing: 6,
            children: techs.map((t) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: AppTheme.success.withAlpha(15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.success.withAlpha(80), width: 0.5),
              ),
              child: Text(t.toString(), style: const TextStyle(color: AppTheme.success, fontSize: 12)),
            )).toList(),
          ),
        ));
      }
    }

    if (items.isEmpty) {
      return _emptyTab('Run SSL/Tech scan to see results');
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: items.animate(interval: 50.ms).fadeIn().slideX(begin: 0.05),
    );
  }

  Widget _emptyTab(String message) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.radar, size: 64, color: AppTheme.subtext),
          const SizedBox(height: 16),
          Text(message, style: const TextStyle(color: AppTheme.subtext)),
        ],
      ),
    );
  }

  Widget _errorTab(String error) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline, size: 64, color: AppTheme.error),
          const SizedBox(height: 16),
          Text(error, style: const TextStyle(color: AppTheme.error), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 8),
      child: Text(title, style: const TextStyle(
        color: AppTheme.primary, fontSize: 14, fontWeight: FontWeight.w600,
      )),
    );
  }

  Widget _resultCard(String label, String value, IconData icon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppTheme.primary, size: 18),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(color: AppTheme.subtext, fontSize: 11)),
              const SizedBox(height: 2),
              Text(value, style: const TextStyle(color: AppTheme.text, fontSize: 14)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _boolCard(String label, bool value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppTheme.text, fontSize: 14)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: value ? AppTheme.error.withAlpha(20) : AppTheme.success.withAlpha(20),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(value ? 'YES' : 'NO', style: TextStyle(
              color: value ? AppTheme.error : AppTheme.success,
              fontSize: 12, fontWeight: FontWeight.bold,
            )),
          ),
        ],
      ),
    );
  }
}
