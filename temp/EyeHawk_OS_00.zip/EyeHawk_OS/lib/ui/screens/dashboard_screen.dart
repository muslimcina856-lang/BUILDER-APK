import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../../core/constants.dart';
import '../../models/app_models.dart';
import '../widgets/module_card.dart';

final targetInputProvider = StateProvider<String>((ref) => '');
final scanHistoryProvider = StateProvider<List<TargetModel>>((ref) => []);
final isScanningProvider = StateProvider<bool>((ref) => false);

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  final _inputController = TextEditingController();
  final _focusNode = FocusNode();

  @override
  void dispose() {
    _inputController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _parseInput() {
    final input = _inputController.text.trim();
    if (input.isEmpty) return;

    final type = InputParser.detect(input);
    final target = TargetModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      inputType: type.name,
      inputValue: input,
      displayName: input,
      tags: [InputParser.getTypeLabel(type)],
    );

    ref.read(scanHistoryProvider.notifier).update((state) => [target, ...state]);
    ref.read(targetInputProvider.notifier).state = '';

    final typeLabel = InputParser.getTypeLabel(type);
    final route = _getRouteForType(type, target.id);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Detected: $typeLabel — Starting scan...'),
        backgroundColor: AppTheme.primary,
        duration: const Duration(seconds: 2),
      ),
    );

    if (route != null) {
      context.push(route);
    }
  }

  String? _getRouteForType(InputType type, String targetId) {
    switch (type) {
      case InputType.domain:
      case InputType.ip:
      case InputType.url:
        return '/network';
      case InputType.email:
        return '/email';
      case InputType.phone:
        return '/email';
      case InputType.username:
        return '/social';
      case InputType.image:
        return '/image';
      default:
        return '/target/$targetId';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: AppTheme.primary.withAlpha(30),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.visibility, color: AppTheme.primary, size: 20),
            ),
            const SizedBox(width: 10),
            Text(
              AppConstants.appName,
              style: GoogleFonts.jetBrainsMono(
                color: AppTheme.text,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline, color: AppTheme.subtext),
            onPressed: () => context.push('/about'),
            tooltip: 'About',
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: AppTheme.subtext),
            onPressed: () => context.push('/settings'),
            tooltip: 'Settings',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // === TARGET INPUT ===
            _buildTargetInput(context).animate().fadeIn(duration: 300.ms).slideY(begin: -0.1),

            const SizedBox(height: 24),

            // === MODULE GRID ===
            Text(
              'OSINT Modules',
              style: Theme.of(context).textTheme.titleMedium,
            ).animate().fadeIn(duration: 400.ms, delay: 100.ms),
            const SizedBox(height: 12),
            _buildModuleGrid(context).animate().fadeIn(duration: 400.ms, delay: 200.ms),

            const SizedBox(height: 24),

            // === RECENT TARGETS ===
            _buildRecentTargets(context).animate().fadeIn(duration: 400.ms, delay: 300.ms),

            const SizedBox(height: 24),

            // === QUICK TOOLS ===
            _buildQuickTools(context).animate().fadeIn(duration: 400.ms, delay: 400.ms),

            const SizedBox(height: 16),

            // === EARL STORE BADGE ===
            _buildEarlStoreBadge(context).animate().fadeIn(duration: 500.ms, delay: 500.ms),
          ],
        ),
      ),
    );
  }

  Widget _buildTargetInput(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.primary.withAlpha(30), AppTheme.surface],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.search, color: AppTheme.primary, size: 22),
              const SizedBox(width: 8),
              Text(
                'Enter Target',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Email, phone, domain, IP, username, or paste image',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _inputController,
            focusNode: _focusNode,
            style: const TextStyle(color: AppTheme.text, fontSize: 16),
            decoration: InputDecoration(
              hintText: 'e.g., user@example.com, +60123456789, example.com',
              hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 14),
              suffixIcon: IconButton(
                icon: const Icon(Icons.arrow_forward, color: AppTheme.primary),
                onPressed: _parseInput,
              ),
              prefixIcon: const Icon(Icons.gps_fixed, color: AppTheme.subtext),
            ),
            onSubmitted: (_) => _parseInput(),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _buildChip(Icons.email, 'Email', () {
                _inputController.text = '';
                _focusNode.requestFocus();
              }),
              const SizedBox(width: 8),
              _buildChip(Icons.phone, 'Phone', () {}),
              const SizedBox(width: 8),
              _buildChip(Icons.language, 'Domain', () {}),
              const SizedBox(width: 8),
              _buildChip(Icons.person, 'Username', () {}),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildChip(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppTheme.secondary, size: 14),
            const SizedBox(width: 4),
            Text(label, style: const TextStyle(color: AppTheme.text, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _buildModuleGrid(BuildContext context) {
    final modules = [
      ('Network Recon', Icons.radar, '/network', AppTheme.primary),
      ('Social Dive', Icons.people, '/social', AppTheme.secondary),
      ('Email & Phone', Icons.email, '/email', AppTheme.warning),
      ('Image Forensics', Icons.image, '/image', AppTheme.success),
      ('Breach Hunter', Icons.warning_amber, '/breach', AppTheme.error),
      ('Orchestra', Icons.link, '/orchestra', AppTheme.accent),
      ('Report Gen', Icons.description, '/report', const Color(0xFF7C4DFF)),
      ('Utility Tools', Icons.build, '/tools', const Color(0xFF00BCD4)),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.35,
      ),
      itemCount: modules.length,
      itemBuilder: (context, index) {
        final (label, icon, route, color) = modules[index];
        return ModuleCard(
          icon: icon,
          label: label,
          color: color,
          onTap: () => context.push(route),
        );
      },
    );
  }

  Widget _buildRecentTargets(BuildContext context) {
    final history = ref.watch(scanHistoryProvider);
    if (history.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Recent Targets', style: Theme.of(context).textTheme.titleMedium),
            TextButton(
              onPressed: () => ref.read(scanHistoryProvider.notifier).state = [],
              child: const Text('Clear', style: TextStyle(color: AppTheme.subtext, fontSize: 13)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ...history.take(5).map((target) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.border, width: 0.5),
              ),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withAlpha(20),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.gps_fixed, color: AppTheme.primary, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          target.displayName ?? target.inputValue,
                          style: const TextStyle(color: AppTheme.text, fontSize: 14),
                        ),
                        Text(
                          InputParser.getTypeLabel(InputParser.detect(target.inputValue)),
                          style: const TextStyle(color: AppTheme.subtext, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: AppTheme.subtext, size: 18),
                ],
              ),
            ).animate().fadeIn(duration: 300.ms)),
      ],
    );
  }

  Widget _buildQuickTools(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Quick Tools', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Row(
          children: [
            _buildQuickToolIcon(Icons.fingerprint, 'Hash', () => context.push('/tools')),
            _buildQuickToolIcon(Icons.qr_code, 'QR Scan', () => context.push('/tools')),
            _buildQuickToolIcon(Icons.text_fields, 'Encode', () => context.push('/tools')),
            _buildQuickToolIcon(Icons.code, 'Base64', () => context.push('/tools')),
            _buildQuickToolIcon(Icons.key, 'Gen Pass', () => context.push('/tools')),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickToolIcon(IconData icon, String label, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Column(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppTheme.card,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppTheme.border, width: 0.5),
              ),
              child: Icon(icon, color: AppTheme.subtext, size: 20),
            ),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(color: AppTheme.subtext, fontSize: 10)),
          ],
        ),
      ),
    );
  }

  Widget _buildEarlStoreBadge(BuildContext context) {
    return InkWell(
      onTap: () => context.push('/about'),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [AppTheme.primary.withAlpha(25), AppTheme.card],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.border, width: 0.5),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppTheme.primary,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Center(
                child: Text('ES', style: TextStyle(
                  color: AppTheme.text, fontSize: 16, fontWeight: FontWeight.bold,
                )),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Earl Store',
                    style: TextStyle(color: AppTheme.text, fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(AppConstants.tagline,
                    style: const TextStyle(color: AppTheme.subtext, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: AppTheme.subtext),
          ],
        ),
      ),
    );
  }
}
