import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';

class TargetDetailScreen extends StatelessWidget {
  final String targetId;
  const TargetDetailScreen({super.key, required this.targetId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Target Detail'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share, color: AppTheme.subtext),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppTheme.error),
            onPressed: () => context.pop(),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Target header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.border, width: 0.5),
            ),
            child: Column(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withAlpha(20),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(Icons.gps_fixed, color: AppTheme.primary, size: 32),
                ),
                const SizedBox(height: 12),
                Text(targetId, style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 4),
                const Text('ID: #UNKNOWN', style: TextStyle(color: AppTheme.subtext, fontSize: 12)),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildActionBtn(context, Icons.radar, 'Rescan', () {}),
                    const SizedBox(width: 12),
                    _buildActionBtn(context, Icons.download, 'Export', () {}),
                    const SizedBox(width: 12),
                    _buildActionBtn(context, Icons.notifications, 'Watch', () {}),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Quick actions
          Text('Run Quick Scan', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _buildScanBtn(context, 'Network', Icons.radar, '/network', AppTheme.primary)),
              const SizedBox(width: 8),
              Expanded(child: _buildScanBtn(context, 'Social', Icons.people, '/social', AppTheme.secondary)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _buildScanBtn(context, 'Email', Icons.email, '/email', AppTheme.warning)),
              const SizedBox(width: 8),
              Expanded(child: _buildScanBtn(context, 'Image', Icons.image, '/image', AppTheme.success)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionBtn(BuildContext context, IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppTheme.primary, size: 18),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(color: AppTheme.text, fontSize: 13)),
          ],
        ),
      ),
    );
  }

  Widget _buildScanBtn(BuildContext context, String label, IconData icon, String route, Color color) {
    return InkWell(
      onTap: () => context.push(route),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.border, width: 0.5),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(label, style: const TextStyle(color: AppTheme.text, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
