import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';
import '../../core/constants.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _biometricLock = false;
  bool _antiScreenshot = true;
  bool _clipboardClear = true;
  bool _vpnWarning = true;
  bool _darkTheme = true;
  int _autoClearMinutes = 15;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // === SECURITY SECTION ===
          _sectionHeader('Security', Icons.shield),
          _switchTile('Biometric Lock', 'Require fingerprint/PIN to open app', _biometricLock, (v) => setState(() => _biometricLock = v)),
          _switchTile('Anti-Screenshot', 'Block screenshots & screen recording', _antiScreenshot, (v) => setState(() => _antiScreenshot = v)),
          _switchTile('Clear Clipboard', 'Auto-clear clipboard after 60s', _clipboardClear, (v) => setState(() => _clipboardClear = v)),
          _switchTile('VPN/Proxy Warning', 'Alert when VPN/proxy detected', _vpnWarning, (v) => setState(() => _vpnWarning = v)),

          const SizedBox(height: 16),

          // === DATA SECTION ===
          _sectionHeader('Data Management', Icons.storage),
          _listTile(Icons.delete_sweep, 'Auto-clear Data', 'After $_autoClearMinutes min', () {
            _showAutoClearPicker();
          }),
          _listTile(Icons.delete_forever, 'Wipe All Data', 'Zero-fill secure deletion', () {
            showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                backgroundColor: AppTheme.card,
                title: const Text('Wipe All Data?', style: TextStyle(color: AppTheme.text)),
                content: const Text('This will permanently delete ALL targets, scans, and reports. This cannot be undone.', style: TextStyle(color: AppTheme.subtext)),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('WIPE', style: TextStyle(color: AppTheme.error, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            );
          }),

          const SizedBox(height: 16),

          // === APPEARANCE ===
          _sectionHeader('Appearance', Icons.palette),
          _switchTile('Dark Theme', 'EyeHawk dark mode', _darkTheme, (v) => setState(() => _darkTheme = v)),

          const SizedBox(height: 16),

          // === API KEYS ===
          _sectionHeader('API Configuration', Icons.vpn_key),
          _listTile(Icons.key, 'HIBP API Key', 'Not configured', () {}),
          _listTile(Icons.key, 'Shodan API Key', 'Not configured', () {}),
          _listTile(Icons.key, 'AlienVault OTX Key', 'Not configured', () {}),

          const SizedBox(height: 16),

          // === EARL STORE ===
          _sectionHeader('Earl Store', Icons.store),
          Container(
            margin: const EdgeInsets.only(top: 4),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppTheme.primary.withAlpha(20), AppTheme.card],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border, width: 0.5),
            ),
            child: Column(children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: AppTheme.primary,
                child: const Text('ES', style: TextStyle(color: AppTheme.text, fontSize: 20, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 12),
              const Text('Earl Store', style: TextStyle(color: AppTheme.text, fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('Developer & Security Researcher', style: TextStyle(color: AppTheme.subtext, fontSize: 12)),
              const SizedBox(height: 12),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                _socialBtn(Icons.telegram, 'Channel', AppConstants.telegramChannel, const Color(0xFF0088CC)),
                const SizedBox(width: 12),
                _socialBtn(Icons.person, 'Owner', AppConstants.telegramOwner, AppTheme.primary),
              ]),
            ]),
          ),

          const SizedBox(height: 16),

          // === ABOUT ===
          _listTile(Icons.info_outline, 'About EyeHawk OS', AppConstants.version, () {
            context.push('/about');
          }),

          const SizedBox(height: 32),

          // Footer
          Center(
            child: Text(
              '© 2026 ${AppConstants.ownerName}\nEyeHawk OS ${AppConstants.version}',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.subtext, fontSize: 11),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  void _showAutoClearPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Auto-clear After', style: TextStyle(color: AppTheme.text, fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          ...[5, 15, 30, 60, 120].map((mins) => ListTile(
            title: Text('$mins minutes', style: const TextStyle(color: AppTheme.text)),
            trailing: _autoClearMinutes == mins ? const Icon(Icons.check, color: AppTheme.primary) : null,
            onTap: () {
              setState(() => _autoClearMinutes = mins);
              Navigator.pop(ctx);
            },
          )),
        ]),
      ),
    );
  }

  Widget _sectionHeader(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(children: [
        Icon(icon, color: AppTheme.primary, size: 18),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(color: AppTheme.primary, fontSize: 14, fontWeight: FontWeight.w600)),
      ]),
    );
  }

  Widget _switchTile(String title, String subtitle, bool value, ValueChanged<bool> onChanged) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: SwitchListTile(
        title: Text(title, style: const TextStyle(color: AppTheme.text, fontSize: 14)),
        subtitle: Text(subtitle, style: const TextStyle(color: AppTheme.subtext, fontSize: 11)),
        value: value,
        onChanged: onChanged,
        activeColor: AppTheme.primary,
        contentPadding: EdgeInsets.zero,
      ),
    );
  }

  Widget _listTile(IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: ListTile(
        leading: Icon(icon, color: AppTheme.subtext, size: 20),
        title: Text(title, style: const TextStyle(color: AppTheme.text, fontSize: 14)),
        subtitle: Text(subtitle, style: const TextStyle(color: AppTheme.subtext, fontSize: 11)),
        trailing: const Icon(Icons.chevron_right, color: AppTheme.subtext, size: 18),
        onTap: onTap,
      ),
    );
  }

  Widget _socialBtn(IconData icon, String label, String url, Color color) {
    return InkWell(
      onTap: () async {
        final uri = Uri.parse(url);
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      },
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: color.withAlpha(20),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withAlpha(80), width: 0.5),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}
