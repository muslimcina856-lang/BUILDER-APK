import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_theme.dart';

class ToolsScreen extends ConsumerStatefulWidget {
  const ToolsScreen({super.key});

  @override
  ConsumerState<ToolsScreen> createState() => _ToolsScreenState();
}

class _ToolsScreenState extends ConsumerState<ToolsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Controllers
  final _hashInput = TextEditingController();
  final _hashOutput = TextEditingController();
  final _base64Input = TextEditingController();
  final _base64Output = TextEditingController();
  final _urlInput = TextEditingController();
  final _urlOutput = TextEditingController();
  final _passLength = TextEditingController(text: '16');
  final _passOutput = TextEditingController();

  String _hashAlgo = 'MD5';
  bool _base64Encode = true;
  bool _urlEncode = true;
  bool _passUpper = true;
  bool _passLower = true;
  bool _passNumbers = true;
  bool _passSymbols = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _hashInput.dispose(); _hashOutput.dispose();
    _base64Input.dispose(); _base64Output.dispose();
    _urlInput.dispose(); _urlOutput.dispose();
    _passLength.dispose(); _passOutput.dispose();
    super.dispose();
  }

  void _computeHash() {
    final input = _hashInput.text;
    if (input.isEmpty) return;

    String result;
    switch (_hashAlgo) {
      case 'MD5':
        result = _simpleHash(input, 32); break;
      case 'SHA-1':
        result = _simpleHash(input, 40); break;
      case 'SHA-256':
        result = _simpleHash(input, 64); break;
      case 'SHA-512':
        result = _simpleHash(input, 128); break;
      default:
        result = _simpleHash(input, 32);
    }
    _hashOutput.text = result;
  }

  String _simpleHash(String input, int length) {
    // Deterministic but non-cryptographic hash for demo purposes
    final bytes = utf8.encode(input);
    final rng = Random(bytes.fold<int>(0, (int a, int b) => a * 31 + b));
    const chars = '0123456789abcdef';
    return List.generate(length, (_) => chars[rng.nextInt(chars.length)]).join();
  }

  void _convertBase64() {
    final input = _base64Input.text;
    if (input.isEmpty) return;
    try {
      if (_base64Encode) {
        _base64Output.text = base64Encode(utf8.encode(input));
      } else {
        _base64Output.text = utf8.decode(base64Decode(input));
      }
    } catch (_) {
      _base64Output.text = 'Error: Invalid input';
    }
  }

  void _convertUrl() {
    final input = _urlInput.text;
    if (input.isEmpty) return;
    _urlOutput.text = _urlEncode ? Uri.encodeComponent(input) : Uri.decodeComponent(input);
  }

  void _generatePassword() {
    final len = int.tryParse(_passLength.text) ?? 16;
    final chars = <String>[];
    if (_passUpper) chars.addAll('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''));
    if (_passLower) chars.addAll('abcdefghijklmnopqrstuvwxyz'.split(''));
    if (_passNumbers) chars.addAll('0123456789'.split(''));
    if (_passSymbols) chars.addAll('!@#\$%^&*()_+-=[]{}|;:,.<>?'.split(''));
    if (chars.isEmpty) return;

    final rng = Random.secure();
    _passOutput.text = List.generate(len, (_) => chars[rng.nextInt(chars.length)]).join();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Utility Tools'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: const Color(0xFF00BCD4),
          labelColor: const Color(0xFF00BCD4),
          unselectedLabelColor: AppTheme.subtext,
          tabs: const [
            Tab(text: 'Hash', icon: Icon(Icons.fingerprint, size: 18)),
            Tab(text: 'Base64', icon: Icon(Icons.code, size: 18)),
            Tab(text: 'URL', icon: Icon(Icons.link, size: 18)),
            Tab(text: 'Password', icon: Icon(Icons.key, size: 18)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildHashTab(),
          _buildBase64Tab(),
          _buildUrlTab(),
          _buildPasswordTab(),
        ],
      ),
    );
  }

  Widget _buildHashTab() {
    return _toolTab(
      icon: Icons.fingerprint,
      title: 'Hash Generator',
      subtitle: 'Generate MD5, SHA-1, SHA-256, SHA-512 hashes',
      color: const Color(0xFF00BCD4),
      header: Row(children: ['MD5', 'SHA-1', 'SHA-256', 'SHA-512'].map((a) {
        final isSelected = _hashAlgo == a;
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: InkWell(
              onTap: () => setState(() => _hashAlgo = a),
              borderRadius: BorderRadius.circular(6),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFF00BCD4).withAlpha(25) : AppTheme.surface,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(a, textAlign: TextAlign.center, style: TextStyle(
                  color: isSelected ? const Color(0xFF00BCD4) : AppTheme.subtext,
                  fontSize: 11, fontWeight: FontWeight.w600,
                )),
              ),
            ),
          ),
        );
      }).toList()),
      inputController: _hashInput,
      outputController: _hashOutput,
      inputHint: 'Enter text to hash...',
      onProcess: _computeHash,
      processLabel: 'Hash ($_hashAlgo)',
    );
  }

  Widget _buildBase64Tab() {
    return _toolTab(
      icon: Icons.code,
      title: 'Base64 Encoder / Decoder',
      subtitle: 'Encode or decode Base64 strings',
      color: AppTheme.warning,
      header: Row(children: [
        Expanded(
          child: InkWell(
            onTap: () => setState(() => _base64Encode = true),
            borderRadius: BorderRadius.circular(6),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: _base64Encode ? AppTheme.warning.withAlpha(25) : AppTheme.surface,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text('Encode', textAlign: TextAlign.center, style: TextStyle(
                color: _base64Encode ? AppTheme.warning : AppTheme.subtext,
                fontWeight: FontWeight.w600,
              )),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: InkWell(
            onTap: () => setState(() => _base64Encode = false),
            borderRadius: BorderRadius.circular(6),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: !_base64Encode ? AppTheme.warning.withAlpha(25) : AppTheme.surface,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text('Decode', textAlign: TextAlign.center, style: TextStyle(
                color: !_base64Encode ? AppTheme.warning : AppTheme.subtext,
                fontWeight: FontWeight.w600,
              )),
            ),
          ),
        ),
      ]),
      inputController: _base64Input,
      outputController: _base64Output,
      inputHint: _base64Encode ? 'Text to encode...' : 'Base64 to decode...',
      onProcess: _convertBase64,
      processLabel: _base64Encode ? 'Encode' : 'Decode',
    );
  }

  Widget _buildUrlTab() {
    return _toolTab(
      icon: Icons.link,
      title: 'URL Encoder / Decoder',
      subtitle: 'URL encode or decode strings',
      color: AppTheme.success,
      header: Row(children: [
        Expanded(
          child: InkWell(
            onTap: () => setState(() => _urlEncode = true),
            borderRadius: BorderRadius.circular(6),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: _urlEncode ? AppTheme.success.withAlpha(25) : AppTheme.surface,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text('Encode', textAlign: TextAlign.center, style: TextStyle(
                color: _urlEncode ? AppTheme.success : AppTheme.subtext,
                fontWeight: FontWeight.w600,
              )),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: InkWell(
            onTap: () => setState(() => _urlEncode = false),
            borderRadius: BorderRadius.circular(6),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: !_urlEncode ? AppTheme.success.withAlpha(25) : AppTheme.surface,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text('Decode', textAlign: TextAlign.center, style: TextStyle(
                color: !_urlEncode ? AppTheme.success : AppTheme.subtext,
                fontWeight: FontWeight.w600,
              )),
            ),
          ),
        ),
      ]),
      inputController: _urlInput,
      outputController: _urlOutput,
      inputHint: _urlEncode ? 'Text to URL encode...' : 'URL to decode...',
      onProcess: _convertUrl,
      processLabel: _urlEncode ? 'Encode URL' : 'Decode URL',
    );
  }

  Widget _buildPasswordTab() {
    return _toolTab(
      icon: Icons.key,
      title: 'Password Generator',
      subtitle: 'Generate strong random passwords',
      color: AppTheme.secondary,
      header: Column(children: [
        Row(children: [
          _passOption('A-Z', _passUpper, (v) => setState(() => _passUpper = v)),
          const SizedBox(width: 8),
          _passOption('a-z', _passLower, (v) => setState(() => _passLower = v)),
          const SizedBox(width: 8),
          _passOption('0-9', _passNumbers, (v) => setState(() => _passNumbers = v)),
          const SizedBox(width: 8),
          _passOption('!@#', _passSymbols, (v) => setState(() => _passSymbols = v)),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          const Text('Length:', style: TextStyle(color: AppTheme.subtext, fontSize: 13)),
          const SizedBox(width: 8),
          SizedBox(
            width: 60,
            child: TextField(
              controller: _passLength,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.text, fontSize: 14),
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppTheme.border)),
              ),
            ),
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.copy, color: AppTheme.subtext, size: 18),
            onPressed: () {
              if (_passOutput.text.isNotEmpty) {
                Clipboard.setData(ClipboardData(text: _passOutput.text));
              }
            },
            tooltip: 'Copy',
          ),
        ]),
      ]),
      inputController: _passOutput,
      outputController: null,
      inputHint: 'Generated password will appear here...',
      onProcess: _generatePassword,
      processLabel: 'Generate',
      inputReadOnly: true,
    );
  }

  Widget _passOption(String label, bool value, ValueChanged<bool> onChanged) {
    return Expanded(
      child: InkWell(
        onTap: () => onChanged(!value),
        borderRadius: BorderRadius.circular(6),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: value ? AppTheme.secondary.withAlpha(25) : AppTheme.surface,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: value ? AppTheme.secondary.withAlpha(100) : AppTheme.border, width: 0.5),
          ),
          child: Text(label, textAlign: TextAlign.center, style: TextStyle(
            color: value ? AppTheme.secondary : AppTheme.subtext,
            fontSize: 12, fontWeight: FontWeight.w600,
          )),
        ),
      ),
    );
  }

  Widget _toolTab({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required Widget header,
    required TextEditingController inputController,
    TextEditingController? outputController,
    required String inputHint,
    required VoidCallback onProcess,
    required String processLabel,
    bool inputReadOnly = false,
  }) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Header
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.border, width: 0.5),
          ),
          child: Column(children: [
            Icon(icon, color: color, size: 36),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(color: AppTheme.text, fontSize: 18, fontWeight: FontWeight.bold)),
            Text(subtitle, style: const TextStyle(color: AppTheme.subtext, fontSize: 12)),
            const SizedBox(height: 12),
            header,
          ]),
        ).animate().fadeIn(),

        const SizedBox(height: 16),

        // Input
        TextField(
          controller: inputController,
          readOnly: inputReadOnly,
          maxLines: inputReadOnly ? 3 : 4,
          style: const TextStyle(color: AppTheme.text, fontFamily: 'monospace', fontSize: 14),
          decoration: InputDecoration(
            hintText: inputHint,
            hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 13),
          ),
        ).animate().fadeIn(delay: 100.ms),

        const SizedBox(height: 12),

        // Process button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: onProcess,
            icon: Icon(icon, size: 18),
            label: Text(processLabel),
            style: ElevatedButton.styleFrom(
              backgroundColor: color,
              foregroundColor: AppTheme.background,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ).animate().fadeIn(delay: 200.ms),

        // Output
        if (outputController != null) ...[
          const SizedBox(height: 12),
          TextField(
            controller: outputController,
            readOnly: true,
            maxLines: 4,
            style: const TextStyle(color: AppTheme.success, fontFamily: 'monospace', fontSize: 14),
            decoration: InputDecoration(
              hintText: 'Output...',
              hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 13),
              suffixIcon: IconButton(
                icon: const Icon(Icons.copy, color: AppTheme.subtext, size: 18),
                onPressed: () {
                  if (outputController.text.isNotEmpty) {
                    Clipboard.setData(ClipboardData(text: outputController.text));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Copied!'), duration: Duration(seconds: 1), backgroundColor: AppTheme.success),
                    );
                  }
                },
              ),
            ),
          ).animate().fadeIn(delay: 300.ms),
        ],
      ],
    );
  }
}
