import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/constants.dart';
import '../theme/app_theme.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('About EyeHawk OS'),
        backgroundColor: AppTheme.background,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // === LOGO SECTION ===
            Container(
              padding: const EdgeInsets.symmetric(vertical: 40),
              decoration: const BoxDecoration(color: AppTheme.surface),
              child: Column(
                children: [
                  // Logo
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withAlpha(30),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: AppTheme.primary, width: 2),
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.visibility,
                        color: AppTheme.primary,
                        size: 50,
                      ),
                    ),
                  )
                      .animate(onPlay: (controller) => controller.repeat())
                      .shimmer(
                        duration: 2000.ms,
                        color: AppTheme.primary.withAlpha(20),
                      ),
                  const SizedBox(height: 20),
                  // App Name
                  Text(
                    AppConstants.appName,
                    style: Theme.of(context).textTheme.displayMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    AppConstants.tagline,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.secondary,
                          fontStyle: FontStyle.italic,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    AppConstants.version,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // === OWNER SECTION ===
            _buildSection(
              context,
              icon: Icons.shield,
              title: 'Owner & Developer',
              children: [
                const ListTile(
                  leading: CircleAvatar(
                    backgroundColor: AppTheme.primary,
                    child: Icon(Icons.person, color: AppTheme.text),
                  ),
                  title: Text('Earl Store',
                      style: TextStyle(color: AppTheme.text, fontWeight: FontWeight.bold)),
                  subtitle: Text('Developer & Security Researcher',
                      style: TextStyle(color: AppTheme.subtext)),
                ),
                const Divider(color: AppTheme.border),
                _buildLinkTile(
                  context,
                  icon: Icons.telegram,
                  title: 'Telegram Channel',
                  subtitle: '@earlstore2004',
                  url: AppConstants.telegramChannel,
                  color: const Color(0xFF0088CC),
                ),
                _buildLinkTile(
                  context,
                  icon: Icons.telegram,
                  title: 'Owner Account',
                  subtitle: AppConstants.telegramOwnerUsername,
                  url: AppConstants.telegramOwner,
                  color: const Color(0xFF0088CC),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // === APP INFO ===
            _buildSection(
              context,
              icon: Icons.info,
              title: 'Application Info',
              children: [
                _buildInfoTile(context, 'Version', AppConstants.version),
                _buildInfoTile(context, 'Package', AppConstants.packageName),
                _buildInfoTile(context, 'Framework', 'Flutter 3.24+ (Dart)'),
                _buildInfoTile(context, 'Database', 'SQLite (Encrypted)'),
                _buildInfoTile(context, 'Architecture', 'Clean Architecture + Riverpod'),
              ],
            ),

            const SizedBox(height: 16),

            // === FEATURES ===
            _buildSection(
              context,
              icon: Icons.stars,
              title: 'Features',
              children: [
                _buildFeatureTile(context, 'Target Builder', 'Auto-detect input: email, phone, domain, IP, username'),
                _buildFeatureTile(context, 'Network Recon', 'WHOIS, DNS, subdomain, IP intel, SSL, port scan'),
                _buildFeatureTile(context, 'Social Deep Dive', '12+ platforms including FB, IG, Twitter, GitHub, TikTok'),
                _buildFeatureTile(context, 'Email & Phone', 'Breach check (HIBP), WhatsApp/Telegram detection'),
                _buildFeatureTile(context, 'Image Forensics', 'EXIF reader, reverse image search, QR/barcode, OCR'),
                _buildFeatureTile(context, 'Breach Hunter', 'Credential search, paste monitor, hash cracker'),
                _buildFeatureTile(context, 'Orchestra', 'Chain builder, automated flows, scheduled scans'),
                _buildFeatureTile(context, 'Report Generator', 'PDF, JSON, CSV, HTML, Markdown export'),
              ],
            ),

            const SizedBox(height: 16),

            // === CREDITS ===
            _buildSection(
              context,
              icon: Icons.favorite,
              title: 'Credits',
              children: [
                const ListTile(
                  title: Text('Built by Earl Store',
                      style: TextStyle(color: AppTheme.text)),
                  subtitle: Text(
                    '"Built with precision. Delivered with quality. No compromises."',
                    style: TextStyle(color: AppTheme.subtext, fontStyle: FontStyle.italic),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 32),

            // === COPYRIGHT ===
            Text(
              '© 2026 ${AppConstants.ownerName}. All rights reserved.',
              style: Theme.of(context).textTheme.bodySmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'CodeName: Genesis',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.primary.withAlpha(128),
                  ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context,
      {required IconData icon, required String title, required List<Widget> children}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.border, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(icon, color: AppTheme.primary, size: 22),
                const SizedBox(width: 10),
                Text(title,
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(color: AppTheme.text)),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildLinkTile(BuildContext context,
      {required IconData icon, required String title, required String subtitle,
       required String url, required Color color}) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color.withAlpha(30),
        child: Icon(icon, color: color, size: 20),
      ),
      title: Text(title, style: const TextStyle(color: AppTheme.text)),
      subtitle: Text(subtitle, style: const TextStyle(color: AppTheme.subtext)),
      trailing: const Icon(Icons.open_in_new, color: AppTheme.subtext, size: 18),
      onTap: () => _launchUrl(url),
    );
  }

  Widget _buildInfoTile(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppTheme.subtext)),
          Text(value, style: const TextStyle(color: AppTheme.text, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildFeatureTile(BuildContext context, String title, String description) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.check_circle, color: AppTheme.success, size: 18),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: AppTheme.text, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(description, style: const TextStyle(color: AppTheme.subtext, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
