import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_theme.dart';

class OrchestraScreen extends StatefulWidget {
  const OrchestraScreen({super.key});

  @override
  State<OrchestraScreen> createState() => _OrchestraScreenState();
}

class _OrchestraScreenState extends State<OrchestraScreen> {
  final Set<String> _selectedModules = {};
  final _targetController = TextEditingController();

  @override
  void dispose() {
    _targetController.dispose();
    super.dispose();
  }

  final _availableModules = [
    ('target', 'Target Builder', Icons.gps_fixed, AppTheme.primary, 'Parse & classify input'),
    ('whois', 'WHOIS Lookup', Icons.language, AppTheme.secondary, 'Domain registration data'),
    ('dns', 'DNS Resolution', Icons.dns, AppTheme.warning, 'A/CNAME/MX records'),
    ('subdomain', 'Subdomain Enum', Icons.account_tree, AppTheme.success, 'Find subdomains via crt.sh'),
    ('social', 'Social Scan', Icons.people, AppTheme.accent, 'Check 12+ platforms'),
    ('email', 'Email Breach', Icons.email, AppTheme.error, 'HIBP breach check'),
    ('image', 'Image Forensics', Icons.image, const Color(0xFF7C4DFF), 'EXIF + reverse search'),
    ('ssl', 'SSL Inspector', Icons.security, AppTheme.warning, 'Certificate analysis'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Orchestra Chain Builder')),
      body: Column(
        children: [
          // Header
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppTheme.accent.withAlpha(25), AppTheme.card],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.border, width: 0.5),
            ),
            child: Column(children: [
              const Icon(Icons.link, color: AppTheme.accent, size: 40),
              const SizedBox(height: 12),
              const Text('Build Your Chain', style: TextStyle(color: AppTheme.text, fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('Select modules to run in sequence. Each output feeds the next.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.subtext, fontSize: 13)),
              const SizedBox(height: 16),
              TextField(
                controller: _targetController,
                style: const TextStyle(color: AppTheme.text),
                decoration: InputDecoration(
                  hintText: 'Enter target (domain, email, username...)',
                  hintStyle: const TextStyle(color: AppTheme.subtext, fontSize: 14),
                  prefixIcon: const Icon(Icons.gps_fixed, color: AppTheme.accent),
                ),
              ),
            ]),
          ),

          // Module selector
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Available Modules', style: Theme.of(context).textTheme.titleMedium),
              Text('${_selectedModules.length} selected', style: const TextStyle(color: AppTheme.subtext, fontSize: 12)),
            ]),
          ),
          const SizedBox(height: 8),

          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: _availableModules.map((m) {
                final (key, name, icon, color, desc) = m;
                final isSelected = _selectedModules.contains(key);
                return Container(
                  key: ValueKey(key),
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: isSelected ? (color as Color).withAlpha(15) : AppTheme.card,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isSelected ? color.withAlpha(100) : AppTheme.border,
                      width: isSelected ? 1.5 : 0.5,
                    ),
                  ),
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: color.withAlpha(25),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(icon, color: color, size: 20),
                    ),
                    title: Text(name, style: const TextStyle(color: AppTheme.text, fontSize: 14, fontWeight: FontWeight.w600)),
                    subtitle: Text(desc, style: const TextStyle(color: AppTheme.subtext, fontSize: 11)),
                    trailing: Checkbox(
                      value: isSelected,
                      onChanged: (val) {
                        setState(() {
                          if (val == true) _selectedModules.add(key);
                          else _selectedModules.remove(key);
                        });
                      },
                      activeColor: AppTheme.accent,
                      checkColor: AppTheme.background,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                    ),
                    onTap: () {
                      setState(() {
                        if (isSelected) _selectedModules.remove(key);
                        else _selectedModules.add(key);
                      });
                    },
                  ),
                ).animate().fadeIn(duration: 300.ms);
              }).toList(),
            ),
          ),

          // Execute button
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _selectedModules.isEmpty
                    ? null
                    : () {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('Chain started: ${_selectedModules.length} modules for ${_targetController.text}'),
                          backgroundColor: AppTheme.accent,
                          duration: const Duration(seconds: 2),
                        ));
                      },
                icon: const Icon(Icons.play_arrow, size: 20),
                label: Text('Execute Chain (${_selectedModules.length} modules)'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.accent,
                  foregroundColor: AppTheme.background,
                  disabledBackgroundColor: AppTheme.surface,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
