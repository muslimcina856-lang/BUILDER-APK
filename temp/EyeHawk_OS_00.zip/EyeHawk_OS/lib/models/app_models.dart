// 🎯 EyeHawk OS — Data Models

class TargetModel {
  final String id;
  final String inputType; // email, phone, domain, ip, username, image
  final String inputValue;
  String? displayName;
  int riskScore;
  String? notes;
  List<String> tags;
  DateTime? lastScanAt;
  final DateTime createdAt;
  bool isWatchlist;

  TargetModel({
    required this.id,
    required this.inputType,
    required this.inputValue,
    this.displayName,
    this.riskScore = 0,
    this.notes,
    List<String>? tags,
    this.lastScanAt,
    DateTime? createdAt,
    this.isWatchlist = false,
  })  : createdAt = createdAt ?? DateTime.now(),
        tags = tags ?? [];

  Map<String, dynamic> toJson() => {
        'id': id,
        'input_type': inputType,
        'input_value': inputValue,
        'display_name': displayName,
        'risk_score': riskScore,
        'notes': notes,
        'tags': tags,
        'last_scan_at': lastScanAt?.toIso8601String(),
        'created_at': createdAt.toIso8601String(),
        'is_watchlist': isWatchlist,
      };

  factory TargetModel.fromJson(Map<String, dynamic> json) => TargetModel(
        id: json['id'] as String,
        inputType: json['input_type'] as String,
        inputValue: json['input_value'] as String,
        displayName: json['display_name'] as String?,
        riskScore: json['risk_score'] as int? ?? 0,
        notes: json['notes'] as String?,
        tags: (json['tags'] as List<dynamic>?)?.cast<String>() ?? [],
        lastScanAt: json['last_scan_at'] != null
            ? DateTime.parse(json['last_scan_at'] as String)
            : null,
        createdAt: DateTime.parse(json['created_at'] as String),
        isWatchlist: json['is_watchlist'] as bool? ?? false,
      );
}

class ScanResult {
  final String id;
  final String targetId;
  final String module; // whois, dns, email, social, image, breach
  final String status; // pending, running, completed, failed
  final Map<String, dynamic>? resultJson;
  final String? errorMessage;
  final int? durationMs;
  final DateTime createdAt;

  ScanResult({
    required this.id,
    required this.targetId,
    required this.module,
    required this.status,
    this.resultJson,
    this.errorMessage,
    this.durationMs,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'target_id': targetId,
        'module': module,
        'status': status,
        'result_json': resultJson,
        'error_message': errorMessage,
        'duration_ms': durationMs,
        'created_at': createdAt.toIso8601String(),
      };

  factory ScanResult.fromJson(Map<String, dynamic> json) => ScanResult(
        id: json['id'] as String,
        targetId: json['target_id'] as String,
        module: json['module'] as String,
        status: json['status'] as String,
        resultJson: json['result_json'] as Map<String, dynamic>?,
        errorMessage: json['error_message'] as String?,
        durationMs: json['duration_ms'] as int?,
        createdAt: DateTime.parse(json['created_at'] as String),
      );
}

class AlertModel {
  final String id;
  final String targetId;
  final String changeType;
  final String? oldValue;
  final String? newValue;
  bool isRead;
  final DateTime createdAt;

  AlertModel({
    required this.id,
    required this.targetId,
    required this.changeType,
    this.oldValue,
    this.newValue,
    this.isRead = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'target_id': targetId,
        'change_type': changeType,
        'old_value': oldValue,
        'new_value': newValue,
        'is_read': isRead,
        'created_at': createdAt.toIso8601String(),
      };
}

class ReportModel {
  final String id;
  final String title;
  final List<String> targetIds;
  final List<String> modulesUsed;
  final String format; // pdf, json, csv, html, md
  final String? filePath;
  final DateTime createdAt;

  ReportModel({
    required this.id,
    required this.title,
    required this.targetIds,
    required this.modulesUsed,
    required this.format,
    this.filePath,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'target_ids': targetIds,
        'modules_used': modulesUsed,
        'format': format,
        'file_path': filePath,
        'created_at': createdAt.toIso8601String(),
      };
}

enum InputType {
  email, phone, domain, ip, username, image, url, unknown
}

class InputParser {
  static InputType detect(String input) {
    final trimmed = input.trim();
    
    // Email
    if (RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        .hasMatch(trimmed)) {
      return InputType.email;
    }
    
    // Phone
    if (RegExp(r'^\+?[\d\s\-()]{7,20}$').hasMatch(trimmed)) {
      return InputType.phone;
    }
    
    // IP
    if (RegExp(
            r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$')
        .hasMatch(trimmed)) {
      return InputType.ip;
    }
    
    // Domain
    if (RegExp(
            r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$')
        .hasMatch(trimmed)) {
      return InputType.domain;
    }
    
    // URL
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      return InputType.url;
    }
    
    // Username (starts with @)
    if (trimmed.startsWith('@')) {
      return InputType.username;
    }
    
    // Default fallback
    return InputType.unknown;
  }

  static String getTypeLabel(InputType type) {
    switch (type) {
      case InputType.email: return 'Email Address';
      case InputType.phone: return 'Phone Number';
      case InputType.domain: return 'Domain';
      case InputType.ip: return 'IP Address';
      case InputType.username: return 'Username';
      case InputType.image: return 'Image';
      case InputType.url: return 'URL';
      case InputType.unknown: return 'Unknown';
    }
  }
}
