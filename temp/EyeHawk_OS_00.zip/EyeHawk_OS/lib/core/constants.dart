class AppConstants {
  static const String appName = 'EyeHawk OS';
  static const String tagline = 'Nothing Stays Hidden Forever';
  static const String version = 'v1.0.0 (Genesis)';
  static const String packageName = 'com.shadowcell.eyehawk';
  static const String ownerName = 'Earl Store';
  static const String telegramChannel = 'https://t.me/earlstore2004';
  static const String telegramOwner = 'https://t.me/earlxz';
  static const String telegramOwnerUsername = '@earlxz';
}
