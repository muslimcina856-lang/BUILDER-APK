import 'package:go_router/go_router.dart';
import 'package:flutter/material.dart';
import '../ui/screens/dashboard_screen.dart';
import '../ui/screens/target_detail_screen.dart';
import '../ui/screens/network_screen.dart';
import '../ui/screens/social_screen.dart';
import '../ui/screens/email_screen.dart';
import '../ui/screens/image_screen.dart';
import '../ui/screens/breach_screen.dart';
import '../ui/screens/orchestra_screen.dart';
import '../ui/screens/report_screen.dart';
import '../ui/screens/about_screen.dart';
import '../ui/screens/settings_screen.dart';
import '../ui/screens/tools_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const DashboardScreen(),
    ),
    GoRoute(
      path: '/target/:id',
      builder: (context, state) => TargetDetailScreen(
        targetId: state.pathParameters['id']!,
      ),
    ),
    GoRoute(
      path: '/network',
      builder: (context, state) => const NetworkScreen(),
    ),
    GoRoute(
      path: '/social',
      builder: (context, state) => const SocialScreen(),
    ),
    GoRoute(
      path: '/email',
      builder: (context, state) => const EmailScreen(),
    ),
    GoRoute(
      path: '/image',
      builder: (context, state) => const ImageScreen(),
    ),
    GoRoute(
      path: '/breach',
      builder: (context, state) => const BreachScreen(),
    ),
    GoRoute(
      path: '/orchestra',
      builder: (context, state) => const OrchestraScreen(),
    ),
    GoRoute(
      path: '/report',
      builder: (context, state) => const ReportScreen(),
    ),
    GoRoute(
      path: '/about',
      builder: (context, state) => const AboutScreen(),
    ),
    GoRoute(
      path: '/settings',
      builder: (context, state) => const SettingsScreen(),
    ),
    GoRoute(
      path: '/tools',
      builder: (context, state) => const ToolsScreen(),
    ),
  ],
);
