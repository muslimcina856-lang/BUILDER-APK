import '../models/app_models.dart';

/// Simple in-memory cache for scan results
/// In production, uses Hive or SQLite for persistence
class CacheService {
  static final CacheService _instance = CacheService._internal();
  factory CacheService() => _instance;

  final Map<String, TargetModel> _targets = {};
  final Map<String, ScanResult> _scans = {};
  final Map<String, dynamic> _sessionData = {};

  CacheService._internal();

  // === Targets ===
  void saveTarget(TargetModel target) {
    _targets[target.id] = target;
  }

  TargetModel? getTarget(String id) {
    return _targets[id];
  }

  List<TargetModel> getAllTargets() {
    return _targets.values.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  void deleteTarget(String id) {
    _targets.remove(id);
  }

  void clearTargets() {
    _targets.clear();
  }

  // === Scans ===
  void saveScan(ScanResult scan) {
    _scans[scan.id] = scan;
  }

  ScanResult? getScan(String id) {
    return _scans[id];
  }

  List<ScanResult> getScansForTarget(String targetId) {
    return _scans.values
        .where((s) => s.targetId == targetId)
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  void clearScans() {
    _scans.clear();
  }

  // === Session Data (non-persistent) ===
  void setSessionData(String key, dynamic value) {
    _sessionData[key] = value;
  }

  dynamic getSessionData(String key) {
    return _sessionData[key];
  }

  void clearSession() {
    _sessionData.clear();
  }

  /// Wipe all cached data
  void wipeAll() {
    _targets.clear();
    _scans.clear();
    _sessionData.clear();
  }

  /// Get stats
  Map<String, int> getStats() {
    return {
      'targets': _targets.length,
      'scans': _scans.length,
      'session_keys': _sessionData.length,
    };
  }
}
