import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Core encryption service for EyeHawk OS
/// Uses Flutter Secure Storage backed by Android Keystore
class EncryptionService {
  static final EncryptionService _instance = EncryptionService._internal();
  factory EncryptionService() => _instance;
  late final FlutterSecureStorage _storage;

  EncryptionService._internal() {
    _storage = const FlutterSecureStorage(
      aOptions: AndroidOptions(encryptedSharedPreferences: true),
    );
  }

  /// Store API key securely
  Future<void> saveApiKey(String service, String key) async {
    await _storage.write(key: 'api_key_$service', value: key);
  }

  /// Read API key
  Future<String?> getApiKey(String service) async {
    return _storage.read(key: 'api_key_$service');
  }

  /// Delete API key
  Future<void> deleteApiKey(String service) async {
    await _storage.delete(key: 'api_key_$service');
  }

  /// Store biometric lock preference
  Future<void> setBiometricLock(bool enabled) async {
    await _storage.write(key: 'biometric_lock', value: enabled.toString());
  }

  /// Check if biometric lock is enabled
  Future<bool> isBiometricLockEnabled() async {
    final val = await _storage.read(key: 'biometric_lock');
    return val == 'true';
  }

  /// Clear all secure storage
  Future<void> wipeAll() async {
    await _storage.deleteAll();
  }
}
