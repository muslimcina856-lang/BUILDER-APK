import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  late final Dio _dio;
  
  ApiService._internal() {
    _dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      headers: {
        'User-Agent': 'EyeHawkOS/1.0',
        'Accept': 'application/json',
      },
    ));
  }

  // === WHOIS ===
  Future<Map<String, dynamic>> whoisLookup(String domain) async {
    try {
      final cleanDomain = domain.replaceAll(RegExp(r'^(https?://)?(www\.)?'), '')
          .replaceAll(RegExp(r'/.*$'), '');
      final response = await _dio.get(
        'https://rdap.verisign.com/com/v1/domain/$cleanDomain',
      );
      return {
        'domain': cleanDomain,
        'registrar': response.data['registrar'] ?? 'Unknown',
        'created_at': response.data['events']?[0]?['eventDate'] ?? 'Unknown',
        'expires_at': response.data['events']?[1]?['eventDate'] ?? 'Unknown',
        'raw': response.data,
      };
    } catch (e) {
      return {'error': e.toString(), 'domain': domain};
    }
  }

  // === DNS ===
  Future<Map<String, dynamic>> dnsLookup(String domain) async {
    try {
      final cleanDomain = domain.replaceAll(RegExp(r'^(https?://)?(www\.)?'), '')
          .replaceAll(RegExp(r'/.*$'), '');
      final response = await _dio.get(
        'https://dns.google/resolve',
        queryParameters: {'name': cleanDomain, 'type': 'A'},
      );
      final answers = response.data['Answer'] as List<dynamic>? ?? [];
      return {
        'domain': cleanDomain,
        'ip_addresses': answers
            .where((a) => a['type'] == 1)
            .map((a) => a['data'])
            .toList(),
        'cname': answers
            .where((a) => a['type'] == 5)
            .map((a) => a['data'])
            .toList(),
        'raw': response.data,
      };
    } catch (e) {
      return {'error': e.toString(), 'domain': domain};
    }
  }

  // === Subdomain Enumeration (crt.sh) ===
  Future<List<String>> subdomainEnum(String domain) async {
    try {
      final cleanDomain = domain.replaceAll(RegExp(r'^(https?://)?(www\.)?'), '')
          .replaceAll(RegExp(r'/.*$'), '');
      final response = await _dio.get(
        'https://crt.sh/',
        queryParameters: {'q': '%.$cleanDomain', 'output': 'json'},
      );
      final List<dynamic> data = response.data;
      final subdomains = <String>{};
      for (var entry in data) {
        final name = entry['name_value'] as String? ?? '';
        for (var sub in name.split('\n')) {
          sub = sub.trim().toLowerCase();
          if (sub.endsWith(cleanDomain) && sub != cleanDomain) {
            subdomains.add(sub);
          }
        }
      }
      return subdomains.toList()..sort();
    } catch (e) {
      return ['Error: ${e.toString()}'];
    }
  }

  // === IP Intelligence ===
  Future<Map<String, dynamic>> ipLookup(String ip) async {
    try {
      final response = await _dio.get('http://ip-api.com/json/$ip');
      return {
        'ip': response.data['query'] ?? ip,
        'country': response.data['country'] ?? 'Unknown',
        'city': response.data['city'] ?? 'Unknown',
        'isp': response.data['isp'] ?? 'Unknown',
        'org': response.data['org'] ?? 'Unknown',
        'lat': response.data['lat'] ?? 0.0,
        'lon': response.data['lon'] ?? 0.0,
        'timezone': response.data['timezone'] ?? 'Unknown',
        'mobile': response.data['mobile'] ?? false,
        'proxy': response.data['proxy'] ?? false,
        'hosting': response.data['hosting'] ?? false,
      };
    } catch (e) {
      return {'error': e.toString(), 'ip': ip};
    }
  }

  // === Have I Been Pwned ===
  Future<Map<String, dynamic>> checkBreach(String email) async {
    try {
      final response = await http.get(
        Uri.parse('https://haveibeenpwned.com/api/v3/breachedaccount/$email'),
        headers: {
          'hibp-api-key': '',
          'User-Agent': 'EyeHawkOS',
        },
      );
      if (response.statusCode == 200) {
        final List<dynamic> breaches = jsonDecode(response.body);
        final breachList = breaches.map((b) => {
          'name': b['Name'] ?? 'Unknown',
          'domain': b['Domain'] ?? 'Unknown',
          'date': b['BreachDate'] ?? 'Unknown',
          'description': b['Description'] ?? 'No description',
          'data_classes': b['DataClasses'] as List<dynamic>? ?? [],
        }).toList();
        return {'email': email, 'breach_count': breachList.length, 'breaches': breachList};
      } else if (response.statusCode == 404) {
        return {'email': email, 'breach_count': 0, 'breaches': []};
      }
      return {'email': email, 'error': 'API unavailable', 'breach_count': 0, 'breaches': []};
    } catch (e) {
      return {'email': email, 'error': e.toString(), 'breach_count': 0, 'breaches': []};
    }
  }

  // === SSL Certificate ===
  Future<Map<String, dynamic>> sslInspect(String domain) async {
    try {
      final cleanDomain = domain.replaceAll(RegExp(r'^(https?://)?(www\.)?'), '')
          .replaceAll(RegExp(r'/.*$'), '');
      final response = await _dio.get(
        'https://crt.sh/',
        queryParameters: {'q': cleanDomain, 'output': 'json', 'limit': 5},
      );
      final List<dynamic> data = response.data;
      final certs = data.map((c) => {
        'issuer': c['issuer_name'] ?? 'Unknown',
        'valid_from': c['not_before'] ?? 'Unknown',
        'valid_to': c['not_after'] ?? 'Unknown',
        'subject': c['name_value'] ?? cleanDomain,
      }).toList();
      return {'domain': cleanDomain, 'certificates': certs};
    } catch (e) {
      return {'error': e.toString(), 'domain': domain};
    }
  }

  // === Technology Fingerprint ===
  Future<Map<String, dynamic>> techFingerprint(String url) async {
    try {
      final targetUrl = url.startsWith('http') ? url : 'https://$url';
      final response = await _dio.get(targetUrl);
      final headers = response.headers.map ?? {};
      final server = headers['server']?.first ?? 'Unknown';
      final powered = headers['x-powered-by']?.first ?? 'Unknown';
      final body = response.data?.toString() ?? '';
      
      final tech = <String, bool>{
        'wordpress': body.contains('wp-content') || body.contains('wp-includes'),
        'react': body.contains('react') || body.contains('_reactRoot'),
        'vue': body.contains('vue') || body.contains('__vue__'),
        'angular': body.contains('ng-') || body.contains('angular'),
        'jquery': body.contains('jquery'),
        'bootstrap': body.contains('bootstrap'),
        'cloudflare': headers['cf-ray']?.first != null,
        'nginx': server.toLowerCase().contains('nginx'),
        'apache': server.toLowerCase().contains('apache'),
      };
      
      return {
        'url': url,
        'server': server,
        'powered_by': powered,
        'technologies': tech.entries.where((e) => e.value).map((e) => e.key).toList(),
      };
    } catch (e) {
      return {'error': e.toString(), 'url': url};
    }
  }

  // === Social Profile Check ===
  Future<Map<String, dynamic>> checkSocialProfile(String platform, String username) async {
    final urls = {
      'facebook': 'https://www.facebook.com/$username',
      'instagram': 'https://www.instagram.com/$username/',
      'twitter': 'https://twitter.com/$username',
      'github': 'https://api.github.com/users/$username',
      'reddit': 'https://www.reddit.com/user/$username/about.json',
      'tiktok': 'https://www.tiktok.com/@$username',
      'youtube': 'https://www.youtube.com/@$username',
      'steam': 'https://steamcommunity.com/id/$username',
    };
    
    try {
      final url = urls[platform];
      if (url == null) return {'platform': platform, 'exists': false, 'error': 'Unknown platform'};
      
      if (platform == 'github') {
        final response = await _dio.get(url);
        final data = response.data;
        return {
          'platform': platform,
          'exists': true,
          'username': data['login'] ?? username,
          'name': data['name'] ?? 'Unknown',
          'bio': data['bio'] ?? '',
          'followers': data['followers'] ?? 0,
          'following': data['following'] ?? 0,
          'repos': data['public_repos'] ?? 0,
        };
      } else if (platform == 'reddit') {
        final response = await _dio.get(url);
        final data = response.data['data'];
        return {
          'platform': platform,
          'exists': data != null,
          'username': data?['name'] ?? username,
          'karma': (data?['total_karma'] ?? data?['link_karma'] ?? 0),
        };
      } else {
        final response = await _dio.get(url);
        final exists = response.statusCode == 200;
        return {
          'platform': platform,
          'exists': exists,
          'url': url,
          'status_code': response.statusCode,
        };
      }
    } catch (e) {
      return {
        'platform': platform,
        'exists': false,
        'error': e.toString(),
      };
    }
  }

  // === WhatsApp Check ===
  Future<Map<String, dynamic>> checkWhatsApp(String phone) async {
    try {
      final cleanPhone = phone.replaceAll(RegExp(r'[^\d]'), '');
      return {
        'phone': cleanPhone,
        'registered': null, // Requires WhatsApp Business API
        'note': 'WhatsApp Business API requires registration. Use Frida or manual check.',
      };
    } catch (e) {
      return {'phone': phone, 'error': e.toString()};
    }
  }

  // === Reverse Image Search URL Generator ===
  String reverseImageSearchUrl(String service, String imageUrl) {
    switch (service) {
      case 'google':
        return 'https://lens.google.com/uploadbyurl?url=${Uri.encodeComponent(imageUrl)}';
      case 'yandex':
        return 'https://yandex.com/images/search?rpt=imageview&url=${Uri.encodeComponent(imageUrl)}';
      case 'tineye':
        return 'https://tineye.com/search?url=${Uri.encodeComponent(imageUrl)}';
      case 'bing':
        return 'https://www.bing.com/images/search?q=imgurl:${Uri.encodeComponent(imageUrl)}&view=detailv2';
      default:
        return '';
    }
  }

  // === Cloud Bucket Scanner ===
  Future<Map<String, dynamic>> checkS3Bucket(String bucketName) async {
    try {
      final response = await _dio.get(
        'https://$bucketName.s3.amazonaws.com/',
      );
      return {'bucket': bucketName, 'open': true, 'status': response.statusCode};
    } catch (e) {
      if (e is DioException && e.response?.statusCode == 403) {
        return {'bucket': bucketName, 'open': false, 'reason': 'Access Denied'};
      }
      return {'bucket': bucketName, 'open': false, 'error': e.toString()};
    }
  }
}
