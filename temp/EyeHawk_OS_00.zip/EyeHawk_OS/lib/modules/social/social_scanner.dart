import '../../services/api_service.dart';

/// Phantom Social Deep Dive — Module 3
/// Scan 12+ social media platforms for username presence
class SocialScanner {
  static final _api = ApiService();

  static const Map<String, String> platforms = {
    'GitHub': 'github',
    'Twitter/X': 'twitter',
    'Facebook': 'facebook',
    'Instagram': 'instagram',
    'Reddit': 'reddit',
    'TikTok': 'tiktok',
    'YouTube': 'youtube',
    'Steam': 'steam',
    'VK': 'vk',
    'Snapchat': 'snapchat',
    'LinkedIn': 'linkedin',
    'Pinterest': 'pinterest',
  };

  /// Scan all platforms for a username
  static Future<Map<String, Map<String, dynamic>>> scanAll(String username) async {
    final cleanUsername = username.startsWith('@') ? username.substring(1) : username;
    final results = <String, Map<String, dynamic>>{};

    final futures = platforms.entries.map((e) async {
      final result = await _api.checkSocialProfile(e.value, cleanUsername);
      results[e.key] = result;
    });

    await Future.wait(futures);
    return results;
  }

  /// Scan single platform
  static Future<Map<String, dynamic>> scanPlatform(String platform, String username) async {
    final platformKey = platforms[platform];
    if (platformKey == null) {
      return {'error': 'Unknown platform: $platform', 'exists': false};
    }
    return _api.checkSocialProfile(platformKey, username);
  }

  /// Get list of all supported platforms
  static List<String> getSupportedPlatforms() {
    return platforms.keys.toList();
  }

  /// Generate platform URLs for manual verification
  static Map<String, String> generateProfileUrls(String username) {
    final cleanUsername = username.startsWith('@') ? username.substring(1) : username;
    return {
      'GitHub': 'https://github.com/$cleanUsername',
      'Twitter': 'https://twitter.com/$cleanUsername',
      'Facebook': 'https://www.facebook.com/$cleanUsername',
      'Instagram': 'https://www.instagram.com/$cleanUsername/',
      'Reddit': 'https://www.reddit.com/user/$cleanUsername',
      'TikTok': 'https://www.tiktok.com/@$cleanUsername',
      'YouTube': 'https://www.youtube.com/@$cleanUsername',
      'Steam': 'https://steamcommunity.com/id/$cleanUsername',
      'LinkedIn': 'https://www.linkedin.com/in/$cleanUsername',
    };
  }
}
