import '../../services/api_service.dart';

/// Ghost Network Recon — Module 2
/// WHOIS, DNS, subdomain enumeration, IP intelligence, SSL inspection, tech fingerprint
class NetworkRecon {
  static final _api = ApiService();

  /// Run full network recon on a domain
  static Future<Map<String, dynamic>> fullRecon(String domain) async {
    final cleanDomain = domain
        .replaceAll(RegExp(r'^(https?://)?(www\.)?'), '')
        .replaceAll(RegExp(r'/.*$'), '');

    final results = <String, dynamic>{};

    final futures = await Future.wait([
      _api.whoisLookup(cleanDomain),
      _api.dnsLookup(cleanDomain),
      _api.subdomainEnum(cleanDomain),
      _api.sslInspect(cleanDomain),
      _api.techFingerprint(cleanDomain),
    ]);

    results['whois'] = futures[0];
    results['dns'] = futures[1];
    results['subdomains'] = futures[2];
    results['ssl'] = futures[3];
    results['tech'] = futures[4];
    results['domain'] = cleanDomain;
    results['scanned_at'] = DateTime.now().toIso8601String();

    return results;
  }

  /// WHOIS lookup only
  static Future<Map<String, dynamic>> whois(String domain) async {
    return _api.whoisLookup(domain);
  }

  /// DNS resolution only
  static Future<Map<String, dynamic>> dns(String domain) async {
    return _api.dnsLookup(domain);
  }

  /// Subdomain enumeration via crt.sh
  static Future<List<String>> subdomains(String domain) async {
    return _api.subdomainEnum(domain);
  }

  /// IP intelligence
  static Future<Map<String, dynamic>> ipIntel(String ip) async {
    return _api.ipLookup(ip);
  }

  /// SSL certificate inspection
  static Future<Map<String, dynamic>> ssl(String domain) async {
    return _api.sslInspect(domain);
  }

  /// Technology stack fingerprint
  static Future<Map<String, dynamic>> techStack(String url) async {
    return _api.techFingerprint(url);
  }

  /// Check if S3 bucket exists
  static Future<Map<String, dynamic>> s3Bucket(String bucketName) async {
    return _api.checkS3Bucket(bucketName);
  }
}
