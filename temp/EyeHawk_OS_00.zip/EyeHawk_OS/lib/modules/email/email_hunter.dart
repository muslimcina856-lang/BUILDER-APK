import '../../services/api_service.dart';

/// Shadow Email & Phone Hunter — Module 4
/// Email breach check, validation, WhatsApp/Telegram detection
class EmailHunter {
  static final _api = ApiService();

  /// Check Have I Been Pwned for email breaches
  static Future<Map<String, dynamic>> checkBreach(String email) async {
    return _api.checkBreach(email);
  }

  /// Validate email format
  static Map<String, dynamic> validateEmail(String email) {
    final hasValidFormat =
        RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$').hasMatch(email.trim());
    final parts = email.split('@');
    final domain = parts.length == 2 ? parts[1].toLowerCase() : '';

    return {
      'email': email,
      'valid_format': hasValidFormat,
      'domain': domain,
      'provider': _detectProvider(domain),
    };
  }

  /// Detect common email providers
  static String _detectProvider(String domain) {
    const providers = {
      'gmail.com': 'Google',
      'yahoo.com': 'Yahoo',
      'outlook.com': 'Microsoft',
      'hotmail.com': 'Microsoft',
      'protonmail.com': 'ProtonMail',
      'icloud.com': 'Apple',
      'mail.ru': 'Mail.ru',
      'yandex.ru': 'Yandex',
    };
    return providers[domain] ?? 'Custom';
  }

  /// Check phone number presence on WhatsApp
  static Future<Map<String, dynamic>> checkWhatsApp(String phone) async {
    return _api.checkWhatsApp(phone);
  }

  /// Format phone number to international
  static String formatPhone(String phone, {String countryCode = '+60'}) {
    final digits = phone.replaceAll(RegExp(r'[^\d]'), '');
    if (digits.startsWith('60') && digits.length >= 10) {
      return '+$digits';
    }
    if (digits.startsWith('0') && digits.length >= 10) {
      return '$countryCode${digits.substring(1)}';
    }
    return '$countryCode$digits';
  }

  /// Full email hunt: breach + validation
  static Future<Map<String, dynamic>> fullHunt(String email) async {
    final validation = validateEmail(email);
    final breach = await checkBreach(email);

    return {
      'email': email,
      'validation': validation,
      'breach': breach,
      'scanned_at': DateTime.now().toIso8601String(),
    };
  }
}
