import '../../models/app_models.dart';
import '../target/target_builder.dart';
import '../network/network_recon.dart';
import '../social/social_scanner.dart';
import '../email/email_hunter.dart';
import '../image/image_forensics.dart';
import '../breach/breach_hunter.dart';

/// Orchestra Chain Builder — Module 7
/// Chain multiple OSINT modules into automated scan flows
class Orchestra {
  final String _target;
  final List<String> _modules;
  final Map<String, dynamic> _results = {};
  final List<String> _errors = [];

  Orchestra({required String target, required List<String> modules})
      : _target = target,
        _modules = modules;

  /// Execute the chain in order
  Future<Map<String, dynamic>> execute() async {
    _results['target'] = _target;
    _results['chain'] = _modules;
    _results['started_at'] = DateTime.now().toIso8601String();
    _results['steps'] = <Map<String, dynamic>>[];

    for (var module in _modules) {
      final stepStart = DateTime.now();
      try {
        final result = await _runModule(module);
        (_results['steps'] as List).add({
          'module': module,
          'status': 'completed',
          'data': result,
          'duration_ms': DateTime.now().difference(stepStart).inMilliseconds,
        });
      } catch (e) {
        _errors.add('$module: $e');
        (_results['steps'] as List).add({
          'module': module,
          'status': 'failed',
          'error': e.toString(),
          'duration_ms': DateTime.now().difference(stepStart).inMilliseconds,
        });
      }
    }

    _results['completed_at'] = DateTime.now().toIso8601String();
    _results['errors'] = _errors;

    return _results;
  }

  Future<Map<String, dynamic>> _runModule(String module) async {
    switch (module) {
      case 'target':
        return TargetBuilder.analyze(_target);
      case 'whois':
        return NetworkRecon.whois(_target);
      case 'dns':
        return NetworkRecon.dns(_target);
      case 'subdomain':
        final subs = await NetworkRecon.subdomains(_target);
        return {'subdomains': subs, 'count': subs.length};
      case 'ip_intel':
        return NetworkRecon.ipIntel(_target);
      case 'ssl':
        return NetworkRecon.ssl(_target);
      case 'tech':
        return NetworkRecon.techStack(_target);
      case 'social':
        return SocialScanner.scanAll(_target);
      case 'email':
        if (_target.contains('@')) {
          return EmailHunter.fullHunt(_target);
        }
        return {'error': 'Not an email address'};
      case 'image':
        return {'note': 'Image forensics requires file input'};
      case 'breach':
        return BreachHunter.identifyHash(_target);
      case 'passwd':
        return BreachHunter.passwordStrength(_target);
      default:
        return {'error': 'Unknown module: $module'};
    }
  }

  /// Get available modules for chain building
  static List<Map<String, String>> getAvailableModules() {
    return [
      {'id': 'target', 'name': 'Target Builder', 'icon': 'crosshair'},
      {'id': 'whois', 'name': 'WHOIS Lookup', 'icon': 'language'},
      {'id': 'dns', 'name': 'DNS Resolution', 'icon': 'dns'},
      {'id': 'subdomain', 'name': 'Subdomain Enum', 'icon': 'account_tree'},
      {'id': 'ip_intel', 'name': 'IP Intelligence', 'icon': 'computer'},
      {'id': 'ssl', 'name': 'SSL Inspector', 'icon': 'security'},
      {'id': 'tech', 'name': 'Tech Stack', 'icon': 'bolt'},
      {'id': 'social', 'name': 'Social Scan', 'icon': 'people'},
      {'id': 'email', 'name': 'Email Breach', 'icon': 'email'},
      {'id': 'breach', 'name': 'Hash Identifier', 'icon': 'fingerprint'},
      {'id': 'passwd', 'name': 'Password Strength', 'icon': 'key'},
    ];
  }
}
