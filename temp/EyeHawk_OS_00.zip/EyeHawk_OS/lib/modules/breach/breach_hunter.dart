import 'dart:math';

/// Viper Breach Hunter — Module 6
/// Credential search, hash analyzer, API key scanner
class BreachHunter {
  /// Identify hash type from string characteristics
  static Map<String, String> identifyHash(String hash) {
    final len = hash.length;
    final isHex = RegExp(r'^[0-9a-fA-F]+$').hasMatch(hash);
    final isBase64 = RegExp(r'^[A-Za-z0-9+/=]+$').hasMatch(hash);

    if (len == 32 && isHex) {
      return {'type': 'MD5', 'confidence': 'High', 'bit_length': '128'};
    }
    if (len == 40 && isHex) {
      return {'type': 'SHA-1', 'confidence': 'High', 'bit_length': '160'};
    }
    if (len == 64 && isHex) {
      return {'type': 'SHA-256', 'confidence': 'High', 'bit_length': '256'};
    }
    if (len == 96 && isHex) {
      return {'type': 'SHA-384', 'confidence': 'Medium', 'bit_length': '384'};
    }
    if (len == 128 && isHex) {
      return {'type': 'SHA-512', 'confidence': 'High', 'bit_length': '512'};
    }
    if (len == 60 && hash.startsWith(RegExp(r'\$2[aby]\$'))) {
      return {'type': 'bcrypt', 'confidence': 'High', 'bit_length': '184'};
    }
    if (len == 32 && isHex && hash.toUpperCase() == hash) {
      return {'type': 'NTLM', 'confidence': 'Low', 'bit_length': '128'};
    }
    if (len == 8 && isHex) {
      return {'type': 'CRC32', 'confidence': 'Low', 'bit_length': '32'};
    }
    if (len == 16 && isHex && hash.toUpperCase() == hash) {
      return {'type': 'MySQL3', 'confidence': 'Low', 'bit_length': '64'};
    }

    return {'type': 'Unknown', 'confidence': 'N/A', 'bit_length': 'N/A'};
  }

  /// Scan text for exposed API keys using regex patterns
  static List<Map<String, String>> scanApiKeys(String text) {
    final patterns = {
      'AWS Access Key': r'AKIA[0-9A-Z]{16}',
      'GitHub Token': r'gh[pousr]_[0-9a-zA-Z]{36}',
      'GitHub OAuth': r'gho_[0-9a-zA-Z]{36}',
      'Google API Key': r'AIza[0-9A-Za-z\-_]{35}',
      'Google OAuth': r'ya29\.[0-9A-Za-z\-_]+',
      'Slack Token': r'xox[baprs]-[0-9a-zA-Z\-]{10,}',
      'Slack Webhook': r'https://hooks\.slack\.com/services/T[a-zA-Z0-9_]{8,}/B[a-zA-Z0-9_]{8,}/[a-zA-Z0-9_]{24}',
      'Stripe Live Key': r'sk_live_[0-9a-zA-Z]{24}',
      'Stripe Test Key': r'sk_test_[0-9a-zA-Z]{24}',
      'JWT Token': r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}',
    };

    final findings = <Map<String, String>>[];

    for (var entry in patterns.entries) {
      final regex = RegExp(entry.value);
      final matches = regex.allMatches(text);
      for (var match in matches) {
        final matched = match.group(0) ?? '';
        final masked = matched.length > 8
            ? '${matched.substring(0, 4)}...${matched.substring(matched.length - 4)}'
            : '****';
        findings.add({
          'type': entry.key,
          'found': masked,
          'location': 'offset ${match.start}',
        });
      }
    }

    return findings;
  }

  /// Generate secure random token
  static String generateSecureToken(int length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    final rng = Random.secure();
    return List.generate(length, (_) => chars[rng.nextInt(chars.length)]).join();
  }

  /// Check password strength
  static Map<String, dynamic> passwordStrength(String password) {
    int score = 0;
    final checks = <String, bool>{};

    checks['length_8'] = password.length >= 8;
    checks['length_12'] = password.length >= 12;
    checks['length_16'] = password.length >= 16;
    checks['has_upper'] = RegExp(r'[A-Z]').hasMatch(password);
    checks['has_lower'] = RegExp(r'[a-z]').hasMatch(password);
    checks['has_digit'] = RegExp(r'\d').hasMatch(password);
    checks['has_special'] = RegExp(r'[!@#$%^&*(),.?":{}|<>]').hasMatch(password);

    if (checks['length_8']!) score++;
    if (checks['length_12']!) score++;
    if (checks['length_16']!) score++;
    if (checks['has_upper']!) score++;
    if (checks['has_lower']!) score++;
    if (checks['has_digit']!) score++;
    if (checks['has_special']!) score++;

    String strength;
    if (score <= 2) {
      strength = 'Weak';
    } else if (score <= 4) {
      strength = 'Moderate';
    } else if (score <= 5) {
      strength = 'Strong';
    } else {
      strength = 'Very Strong';
    }

    return {'score': score, 'max_score': 7, 'strength': strength, 'checks': checks};
  }
}
