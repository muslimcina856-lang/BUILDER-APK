/// Raven Image Forensics — Module 5
/// EXIF reader, reverse image search, QR/barcode scanner, steganography detection
class ImageForensics {
  /// Image metadata extraction (simulated)
  /// In production, would use exifread or similar library
  static Map<String, String> extractMetadata({
    required String filename,
    required int fileSize,
    required DateTime modified,
  }) {
    final ext = filename.split('.').last.toUpperCase();
    return {
      'filename': filename,
      'filesize': '${(fileSize / 1024).toStringAsFixed(1)} KB',
      'modified': modified.toString().split('.')[0],
      'format': ext,
      'created_by': 'EyeHawk OS Image Forensics Module',
      'note': 'EXIF extraction requires native platform support',
    };
  }

  /// Reverse image search URL generators
  static Map<String, String> reverseImageSearchUrls(String imageUrl) {
    return {
      'google': 'https://lens.google.com/uploadbyurl?url=${Uri.encodeComponent(imageUrl)}',
      'yandex': 'https://yandex.com/images/search?rpt=imageview&url=${Uri.encodeComponent(imageUrl)}',
      'tineye': 'https://tineye.com/search?url=${Uri.encodeComponent(imageUrl)}',
      'bing': 'https://www.bing.com/images/search?q=imgurl:${Uri.encodeComponent(imageUrl)}&view=detailv2',
    };
  }

  /// Detect steganography indicators (basic heuristic)
  static Map<String, dynamic> detectSteganography(int fileSize) {
    final isLarge = fileSize > 1024 * 1024; // > 1MB suspicious
    return {
      'suspicious_size': isLarge,
      'recommendation': isLarge
          ? 'File is >1MB — could contain hidden data. Use steghide or zsteg for deeper analysis.'
          : 'No obvious steganography indicators.',
      'tools_suggested': ['steghide', 'zsteg', 'binwalk', 'foremost'],
    };
  }

  /// Generate EXIF report as formatted text
  static String formatExifReport(Map<String, String> exif) {
    final buffer = StringBuffer();
    buffer.writeln('╔══════════════════════════════════╗');
    buffer.writeln('║     IMAGE FORENSICS REPORT      ║');
    buffer.writeln('╠══════════════════════════════════╣');
    for (var entry in exif.entries) {
      buffer.writeln('║ ${entry.key.padRight(16)}: ${entry.value.padRight(14)} ║');
    }
    buffer.writeln('╚══════════════════════════════════╝');
    return buffer.toString();
  }

  /// Detect image tampering indicators
  static List<String> detectTampering(Map<String, String> exif) {
    final warnings = <String>[];
    if (!exif.containsKey('camera_model') || exif['camera_model'] == 'Unknown') {
      warnings.add('No camera model — possible screenshot or edited image');
    }
    if (!exif.containsKey('gps') || exif['gps'] == 'Unknown') {
      warnings.add('No GPS data — metadata may have been stripped');
    }
    return warnings;
  }
}
