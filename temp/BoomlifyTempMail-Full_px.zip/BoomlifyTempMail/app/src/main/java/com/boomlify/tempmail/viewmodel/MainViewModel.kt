package com.boomlify.tempmail.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.boomlify.tempmail.data.ApiClient
import com.boomlify.tempmail.data.model.*
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    var domains by mutableStateOf<List<Domain>>(emptyList())
        private set

    var savedEmails by mutableStateOf<List<SavedEmail>>(emptyList())
        private set

    var currentMessages by mutableStateOf<List<Message>>(emptyList())
        private set

    var isLoading by mutableStateOf(false)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var successMessage by mutableStateOf<String?>(null)
        private set

    var selectedDomain by mutableStateOf<String?>(null)
    var customUsername by mutableStateOf("")
    var selectedTime by mutableStateOf("10min")
    var useCustomName by mutableStateOf(false)

    val timeOptions = listOf(
        "10min" to "10 Minit",
        "1hour" to "1 Jam",
        "1day" to "1 Hari",
        "permanent" to "Permanent"
    )

    init {
        loadDomains()
    }

    fun loadDomains() {
        viewModelScope.launch {
            isLoading = true
            errorMessage = null
            try {
                domains = ApiClient.api.getPublicDomains().filter { it.isActive == 1 }
                if (selectedDomain == null && domains.isNotEmpty()) {
                    selectedDomain = domains.first().domain
                }
            } catch (e: Exception) {
                errorMessage = "Gagal load domain: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    fun createEmail() {
        viewModelScope.launch {
            isLoading = true
            errorMessage = null
            successMessage = null
            try {
                val username = if (useCustomName && customUsername.isNotBlank()) {
                    customUsername.trim()
                } else null

                val response = ApiClient.api.createEmail(
                    apiKey = ApiClient.API_KEY,
                    customUsername = username,
                    time = selectedTime,
                    domain = selectedDomain
                )

                if (response.success && response.email != null) {
                    val email = response.email
                    val saved = SavedEmail(
                        id = email.id,
                        address = email.address,
                        domain = email.domain ?: selectedDomain ?: "",
                        timeTier = email.timeTier ?: selectedTime,
                        expiresAt = email.expiresAt ?: "",
                        createdAt = email.createdAt ?: ""
                    )
                    savedEmails = listOf(saved) + savedEmails
                    successMessage = "Email berjaya dicipta: ${email.address}"
                    customUsername = ""
                } else {
                    errorMessage = response.error ?: response.message ?: "Gagal create email"
                }
            } catch (e: Exception) {
                errorMessage = "Error: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    fun loadMessages(emailId: String) {
        viewModelScope.launch {
            isLoading = true
            errorMessage = null
            try {
                val response = ApiClient.api.getMessages(
                    apiKey = ApiClient.API_KEY,
                    emailId = emailId
                )
                if (response.success) {
                    currentMessages = response.messages
                } else {
                    errorMessage = response.error ?: "Gagal load mesej"
                    currentMessages = emptyList()
                }
            } catch (e: Exception) {
                // Demo key kadang tak support messages endpoint dengan baik
                errorMessage = "Gagal load inbox: ${e.message}"
                currentMessages = emptyList()
            } finally {
                isLoading = false
            }
        }
    }

    fun deleteEmail(emailId: String) {
        viewModelScope.launch {
            isLoading = true
            try {
                ApiClient.api.deleteEmail(ApiClient.API_KEY, emailId)
                savedEmails = savedEmails.filter { it.id != emailId }
                successMessage = "Email berjaya dipadam"
            } catch (e: Exception) {
                // Masih padam dari list local
                savedEmails = savedEmails.filter { it.id != emailId }
                errorMessage = "Dipadam secara local (API delete mungkin terhad)"
            } finally {
                isLoading = false
            }
        }
    }

    fun clearMessages() {
        successMessage = null
        errorMessage = null
    }
}
