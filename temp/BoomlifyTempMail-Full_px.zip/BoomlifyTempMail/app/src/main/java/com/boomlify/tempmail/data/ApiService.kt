package com.boomlify.tempmail.data

import com.boomlify.tempmail.data.model.*
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.http.*
import java.util.concurrent.TimeUnit

interface BoomlifyApi {

    @GET("domains/public")
    suspend fun getPublicDomains(): List<Domain>

    @POST("api/v1/emails/create")
    suspend fun createEmail(
        @Header("X-API-Key") apiKey: String,
        @Query("custom_username") customUsername: String? = null,
        @Query("time") time: String = "10min",
        @Query("domain") domain: String? = null
    ): CreateEmailResponse

    @GET("api/v1/emails/{id}/messages")
    suspend fun getMessages(
        @Header("X-API-Key") apiKey: String,
        @Path("id") emailId: String,
        @Query("limit") limit: Int = 20
    ): MessagesResponse

    @GET("api/v1/emails")
    suspend fun listEmails(
        @Header("X-API-Key") apiKey: String,
        @Query("limit") limit: Int = 50
    ): EmailListResponse

    @DELETE("api/v1/emails/{id}")
    suspend fun deleteEmail(
        @Header("X-API-Key") apiKey: String,
        @Path("id") emailId: String
    ): CreateEmailResponse
}

object ApiClient {

    // Public demo key (terhad)
    const val API_KEY = "api_50900908bd13d4f960e2d7bf405b4a63dd7f9999192d31e0c8fae53985599949"

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(logging)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://v1.boomlify.com/")
        .client(client)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()

    val api: BoomlifyApi = retrofit.create(BoomlifyApi::class.java)
}
