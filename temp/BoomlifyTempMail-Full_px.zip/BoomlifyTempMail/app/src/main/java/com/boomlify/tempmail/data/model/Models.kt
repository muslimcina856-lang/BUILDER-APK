package com.boomlify.tempmail.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Domain(
    val id: String,
    val domain: String,
    @SerialName("is_premium") val isPremium: Int = 0,
    @SerialName("is_edu") val isEdu: Int = 0,
    @SerialName("is_active") val isActive: Int = 1
)

@Serializable
data class CreateEmailResponse(
    val success: Boolean = false,
    val email: EmailData? = null,
    val meta: MetaData? = null,
    val error: String? = null,
    val message: String? = null
)

@Serializable
data class EmailData(
    val id: String,
    val address: String,
    val domain: String? = null,
    @SerialName("time_tier") val timeTier: String? = null,
    val type: String? = null,
    @SerialName("expires_at") val expiresAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("is_custom_domain") val isCustomDomain: Boolean = false,
    @SerialName("time_remaining") val timeRemaining: TimeRemaining? = null
)

@Serializable
data class TimeRemaining(
    @SerialName("total_ms") val totalMs: Long = 0,
    val minutes: Int = 0,
    val seconds: Int = 0,
    @SerialName("human_readable") val humanReadable: String = ""
)

@Serializable
data class MetaData(
    @SerialName("user_id") val userId: String? = null,
    val tier: String? = null,
    @SerialName("request_time") val requestTime: String? = null
)

@Serializable
data class Message(
    val id: String,
    @SerialName("from_email") val fromEmail: String? = null,
    @SerialName("from_name") val fromName: String? = null,
    val subject: String? = null,
    @SerialName("body_html") val bodyHtml: String? = null,
    @SerialName("body_text") val bodyText: String? = null,
    @SerialName("received_at") val receivedAt: String? = null,
    @SerialName("temp_email_id") val tempEmailId: String? = null
)

@Serializable
data class MessagesResponse(
    val success: Boolean = false,
    val messages: List<Message> = emptyList(),
    val error: String? = null
)

@Serializable
data class EmailListResponse(
    val success: Boolean = false,
    val emails: List<EmailData> = emptyList(),
    val error: String? = null
)

// Local stored email
data class SavedEmail(
    val id: String,
    val address: String,
    val domain: String,
    val timeTier: String,
    val expiresAt: String,
    val createdAt: String
)
