package com.boomlify.tempmail

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.boomlify.tempmail.data.model.SavedEmail
import com.boomlify.tempmail.ui.screens.HomeScreen
import com.boomlify.tempmail.ui.screens.InboxScreen
import com.boomlify.tempmail.ui.theme.BoomlifyTheme
import com.boomlify.tempmail.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BoomlifyTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val viewModel: MainViewModel = viewModel()
                    var currentEmail by remember { mutableStateOf<SavedEmail?>(null) }

                    if (currentEmail == null) {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenInbox = { email -> currentEmail = email }
                        )
                    } else {
                        InboxScreen(
                            email = currentEmail!!,
                            viewModel = viewModel,
                            onBack = { currentEmail = null }
                        )
                    }
                }
            }
        }
    }
}
