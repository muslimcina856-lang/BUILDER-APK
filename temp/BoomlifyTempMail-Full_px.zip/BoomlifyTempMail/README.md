# Boomlify Temp Mail - Android App

Aplikasi Android native lengkap untuk Boomlify Temporary Email  
Dibina dengan **Kotlin + Jetpack Compose**.

## Ciri-ciri

- Senarai domain public
- Create email (Random atau Custom username)
- Pilih domain & tempoh (10min / 1jam / 1hari / permanent)
- Senarai email yang dicipta
- Copy email ke clipboard
- Lihat Inbox
- Padam email
- Dark theme modern
- Icon premium

## Cara Buka & Build

1. Download & extract folder ni
2. Buka **Android Studio**
3. Pilih **Open** → pilih folder `BoomlifyTempMail`
4. Tunggu Gradle sync (kali pertama mungkin ambil masa)
5. Tekan butang **Run** (▶) atau  
   `Build > Build Bundle(s) / APK(s) > Build APK(s)`

### Generate Signed APK (untuk install di telefon)
1. `Build > Generate Signed Bundle / APK`
2. Pilih **APK**
3. Create new keystore
4. Pilih release → Build

## Ganti API Key (opsyenal)

Buka fail:  
`app/src/main/java/com/boomlify/tempmail/data/ApiService.kt`

Cari baris:
```kotlin
const val API_KEY = "api_50900908bd13d4f960e2d7bf405b4a63dd7f9999192d31e0c8fae53985599949"
```

Ganti dengan API key sendiri dari boomlify.com (lebih stabil).

## Nota

- Public demo key ada rate limit.
- Kalau sync Gradle error, pastikan internet on & Android Studio versi terkini.
