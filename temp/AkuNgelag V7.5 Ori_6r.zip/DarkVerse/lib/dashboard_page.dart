import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as dart_ui;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'owner_page.dart';
import 'home_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'motivasi.dart';

// ─── PALETTE ─────────────────────────────────────────────────
class _C {
  static const bg      = Color(0xFF000000);
  static const surface = Color(0xFF070707);
  static const card    = Color(0xFF0C0C0C);
  static const line    = Color(0xFF181818);
  static const red     = Color(0xFFFF0040);
  static const redGlow = Color(0xFFFF2255);
  static const redDeep = Color(0xFF6A0020);
  static const muted   = Color(0xFF555555);
  static const dim     = Color(0xFF282828);
  static const white   = Color(0xFFFFFFFF);
  static const green   = Color(0xFF00E676);
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _orbitCtrl;
  late Animation<double> _fade;
  late Animation<double> _pulse;
  late Animation<double> _orbit;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  int onlineUsers       = 0;
  int activeConnections = 0;
  int _prevOnline       = 0;
  int _prevConnections  = 0;
  Timer? _statsTimer;
  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  late PageController _newsCtrl;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;

  // ─── INIT ─────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();

    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..forward();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _orbitCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 8))
      ..repeat();

    _fade  = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _pulse = Tween<double>(begin: 0.2, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _orbit = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _orbitCtrl, curve: Curves.linear));

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try { channel.sink.add(jsonEncode({"type": "stats"})); } catch (_) {}
    });

    _initNewsBanner();
    _selectedPage = _buildHomePage();
    _initAndroidIdAndConnect();
    _loadProfileImage();
  }

  void _initNewsBanner() {
    _newsCtrl = PageController(initialPage: 0, viewportFraction: 0.9);
    _newsCtrl.addListener(() {
      if (_newsCtrl.hasClients && _newsCtrl.page != null) {
        setState(() => _currentNewsPage = _newsCtrl.page!);
      }
    });
    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
        if (_newsCtrl.hasClients) {
          int next = (_currentNewsPage + 1).round() % newsList.length;
          _newsCtrl.animateToPage(next,
              duration: const Duration(milliseconds: 700),
              curve: Curves.easeInOutCubic);
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
        Uri.parse('http://irfangblk.surnxuesk.biz.id:10092/ping'));

    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.stream.listen(
      (event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo') {
          if (data['valid'] == false) {
            final msg = data['reason'] == 'androidIdMismatch'
                ? "Your account has logged on another device."
                : "Key is not valid. Please login again.";
            _handleInvalidSession(msg);
          } else {
            channel.sink.add(jsonEncode({"type": "stats"}));
          }
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            _prevOnline       = onlineUsers;
            _prevConnections  = activeConnections;
            onlineUsers       = data['onlineUsers']       ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      },
      onError: (e) => print('❌ WS Error: $e'),
      onDone:  () => print('🔌 WS Closed'),
    );
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withValues(alpha: 0.9),
      builder: (_) => _SessionDialog(
        message: message,
        onOk: () => Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()),
          (r) => false,
        ),
      ),
    );
  }

  // ─── NAV ──────────────────────────────────────────────────
  void _onNavTapped(int index) {
    if (index == 1) { _showWhatsAppSheet(); return; }
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0: _selectedPage = _buildHomePage(); break;
        case 2: _selectedPage = InfoPage(sessionKey: sessionKey); break;
        case 3: _selectedPage = MotivationPage(); break;
        case 4: _selectedPage = ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
            listDoos: listDoos); break;
      }
    });
  }

  void _handleQuickAction(String label) {
    switch (label) {
      case 'History':
        Navigator.push(context, MaterialPageRoute(
            builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
        break;
      case 'Profile':
        Navigator.push(context, MaterialPageRoute(
            builder: (_) => ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            )));
        break;
      case 'Support':
        Navigator.push(context, MaterialPageRoute(
            builder: (_) => const ContactPage()));
        break;
      case 'Owner':
        setState(() => _selectedPage = OwnerPage(
          sessionKey: sessionKey, username: username));
        break;
    }
  }

  // ─── WHATSAPP SHEET ───────────────────────────────────────
  void _showWhatsAppSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.75),
      builder: (_) => _WhatsAppSheet(
        onCrash: () {
          Navigator.pop(context);
          setState(() {
            _bottomNavIndex = 1;
            _selectedPage = HomePage(
              username: username,
              password: password,
              listBug: listBug,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            );
          });
        },
        onSender: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(
            builder: (_) => BugSenderPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            ),
          ));
        },
      ),
    );
  }

  // ─── HOME PAGE CONTENT ────────────────────────────────────
  Widget _buildHomePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 16),
          _buildHeroCard(),
          const SizedBox(height: 12),
          _buildLiveBar(),
          const SizedBox(height: 16),
          _buildQuickActions(),
          const SizedBox(height: 18),
          _buildNewsBanner(),
          const SizedBox(height: 16),
          _buildTelegramBtn(),
          const SizedBox(height: 28),
        ],
      ),
    );
  }

  // ─── HERO CARD (editorial + scanline) ─────────────────────
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          color: _C.card,
          border: Border.all(color: _C.line),
          boxShadow: [
            BoxShadow(
              color: _C.red.withValues(alpha: 0.05),
              blurRadius: 40,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            // ── Scanline sweep ─────────────────────────────
            AnimatedBuilder(
              animation: _orbit,
              builder: (ctx, _) {
                final w = MediaQuery.of(ctx).size.width;
                return Positioned(
                  left: -120 + (_orbit.value * (w + 240)),
                  top: 0, bottom: 0,
                  child: Container(
                    width: 100,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          Colors.transparent,
                          _C.red.withValues(alpha: 0.035),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
            // ── Left accent bar (animated) ─────────────────
            Positioned(
              left: 0, top: 0, bottom: 0,
              child: AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Container(
                  width: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        _C.red.withValues(alpha: _pulse.value * 0.6 + 0.4),
                        _C.red,
                        _C.red.withValues(alpha: _pulse.value * 0.6 + 0.4),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // ── Bottom accent line ─────────────────────────
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    Colors.transparent,
                    _C.red.withValues(alpha: 0.25),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
            // ── Content ───────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 22),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _Avatar(image: _profileImage, pulse: _pulse, size: 64),
                  const SizedBox(width: 18),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // label row with dash
                        Row(
                          children: [
                            Container(
                              width: 16, height: 1.5,
                              color: _C.red,
                              margin: const EdgeInsets.only(right: 8),
                            ),
                            Text(
                              "WELCOME BACK",
                              style: TextStyle(
                                color: _C.muted,
                                fontFamily: 'ShareTechMono',
                                fontSize: 9,
                                letterSpacing: 2.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 7),
                        Text(
                          username.toUpperCase(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _C.white,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 22,
                            letterSpacing: 0.8,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            _RoleBadge(role: role),
                            const SizedBox(width: 8),
                            _ExpBadge(date: expiredDate),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── LIVE STATS BAR (bento style) ─────────────────────────
  Widget _buildLiveBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          // Row 1: Online + Linked (big numbers)
          Row(
            children: [
              Expanded(
                child: _BigStatCard(
                  label: 'ONLINE',
                  numValue: onlineUsers,
                  prevValue: _prevOnline,
                  accent: _C.green,
                  icon: Icons.people_rounded,
                  pulse: _pulse,
                  showPulse: true,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _BigStatCard(
                  label: 'LINKED',
                  numValue: activeConnections,
                  prevValue: _prevConnections,
                  accent: _C.red,
                  icon: Icons.link_rounded,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Row 2: Tier (full width, flat)
          _TierCard(role: role),
        ],
      ),
    );
  }

  // ─── QUICK ACTIONS STRIP ──────────────────────────────────
  Widget _buildQuickActions() {
    final actions = <Map<String, dynamic>>[
      {'icon': Icons.history_rounded,           'label': 'History', 'color': _C.red},
      {'icon': Icons.person_rounded,            'label': 'Profile', 'color': _C.white},
      {'icon': Icons.headset_mic_rounded,       'label': 'Support', 'color': _C.white},
      if (role == 'owner')
        {'icon': Icons.workspace_premium_rounded, 'label': 'Owner', 'color': const Color(0xFFFFD700)},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Padding(
          padding: const EdgeInsets.only(left: 20, bottom: 12),
          child: Row(children: [
            Container(
              width: 3, height: 14,
              decoration: BoxDecoration(
                color: _C.red,
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: _C.red.withValues(alpha: 0.5), blurRadius: 8),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Text(
              "QUICK ACCESS",
              style: TextStyle(
                color: _C.muted,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
          ]),
        ),
        SizedBox(
          height: 82,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: actions.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) {
              final a = actions[i];
              final color = a['color'] as Color;
              return GestureDetector(
                onTap: () => _handleQuickAction(a['label'] as String),
                child: Container(
                  width: 86,
                  decoration: BoxDecoration(
                    color: _C.card,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _C.line),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 36, height: 36,
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: color.withValues(alpha: 0.15)),
                        ),
                        child: Icon(a['icon'] as IconData,
                            color: color, size: 18),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        a['label'] as String,
                        style: TextStyle(
                          color: _C.muted,
                          fontFamily: 'ShareTechMono',
                          fontSize: 9,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ─── NEWS BANNER ──────────────────────────────────────────
  Widget _buildNewsBanner() {
    if (newsList.isEmpty) return const SizedBox();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, bottom: 12),
          child: Row(children: [
            Container(
              width: 3, height: 14,
              decoration: BoxDecoration(
                color: _C.red,
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: _C.red.withValues(alpha: 0.5), blurRadius: 8),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Text(
              "LATEST NEWS",
              style: TextStyle(
                color: _C.muted,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
          ]),
        ),
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: _newsCtrl,
            itemCount: newsList.length,
            itemBuilder: (_, i) {
              final item = newsList[i];
              return AnimatedBuilder(
                animation: _newsCtrl,
                builder: (_, child) {
                  double diff = (_newsCtrl.hasClients && _newsCtrl.page != null)
                      ? (_newsCtrl.page! - i).abs()
                      : 0.0;
                  double scale = (1 - diff * 0.04).clamp(0.96, 1.0);
                  return Transform.scale(scale: scale, child: child);
                },
                child: _NewsCard(item: item),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        // Dot indicator
        AnimatedBuilder(
          animation: _newsCtrl,
          builder: (_, __) {
            double page = _newsCtrl.hasClients && _newsCtrl.page != null
                ? _newsCtrl.page!
                : _currentNewsPage;
            return Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(newsList.length, (i) {
                double diff = (i - page).abs();
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: diff < 0.5 ? 20 : 5,
                  height: 4,
                  decoration: BoxDecoration(
                    color: diff < 0.5
                        ? _C.red
                        : _C.muted.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(3),
                  ),
                );
              }),
            );
          },
        ),
      ],
    );
  }

  // ─── TELEGRAM BUTTON (redesigned) ─────────────────────────
  Widget _buildTelegramBtn() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: () => _openUrl("https://t.me/AkuNgelagOfficial"),
        child: Container(
          height: 64,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: _C.card,
            border: Border.all(color: _C.red.withValues(alpha: 0.18)),
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                _C.red.withValues(alpha: 0.13),
                _C.card,
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: _C.red.withValues(alpha: 0.07),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              const SizedBox(width: 18),
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: _C.red.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: _C.red.withValues(alpha: 0.2)),
                ),
                child: const Center(
                  child: Icon(FontAwesomeIcons.telegram,
                      color: _C.red, size: 17),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "AkuNgelag Channel",
                      style: TextStyle(
                        color: _C.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "Join the community",
                      style: TextStyle(
                        color: _C.muted,
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios_rounded,
                  color: _C.red, size: 13),
              const SizedBox(width: 18),
            ],
          ),
        ),
      ),
    );
  }

  // ─── DRAWER ───────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(30),
            bottomRight: Radius.circular(30),
          ),
          border: Border(
            right:  BorderSide(color: _C.line),
            top:    BorderSide(color: _C.line),
            bottom: BorderSide(color: _C.line),
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.fromLTRB(24, 52, 24, 28),
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: _C.line)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      _Avatar(image: _profileImage, pulse: _pulse,
                          size: 70, borderWidth: 2),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              username,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: _C.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 6),
                            _RoleBadge(role: role),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _C.dim.withValues(alpha: 0.5),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.close_rounded,
                              color: _C.muted, size: 16),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: _C.card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.line),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.schedule_rounded,
                            color: _C.muted, size: 14),
                        const SizedBox(width: 10),
                        Text(
                          "Expires $expiredDate",
                          style: TextStyle(
                            color: _C.muted,
                            fontSize: 12,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Menu items
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(
                    vertical: 16, horizontal: 16),
                children: [
                  if (role == "owner")
                    _DrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      iconColor: const Color(0xFFFFD700),
                      label: "Owner Panel",
                      badge: "OWNER",
                      onTap: () {
                        Navigator.pop(context);
                        setState(() => _selectedPage = OwnerPage(
                          sessionKey: sessionKey,
                          username: username,
                        ));
                      },
                    ),
                  _DrawerItem(
                    icon: Icons.history_rounded,
                    iconColor: _C.red,
                    label: "Activity History",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                              sessionKey: sessionKey, role: role)));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.person_rounded,
                    iconColor: _C.white,
                    label: "My Profile",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => ProfilePage(
                            username: username,
                            password: password,
                            role: role,
                            expiredDate: expiredDate,
                            sessionKey: sessionKey,
                          )));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.headset_mic_rounded,
                    iconColor: _C.white,
                    label: "Customer Service",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const ContactPage()));
                    },
                  ),
                  const SizedBox(height: 16),
                  _DrawerItem(
                    icon: Icons.logout_rounded,
                    iconColor: Colors.redAccent,
                    label: "Log Out",
                    isDestructive: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                            builder: (_) => const LoginPage()),
                        (r) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
            // Footer
            Container(
              padding: const EdgeInsets.fromLTRB(24, 14, 24, 32),
              decoration: BoxDecoration(
                border: Border(top: BorderSide(color: _C.line)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.shield_rounded, color: _C.dim, size: 13),
                  const SizedBox(width: 8),
                  Text(
                    "AkuNgelag v7.5",
                    style: TextStyle(
                      color: _C.dim,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BOTTOM NAV ───────────────────────────────────────────
  Widget _buildBottomNav() {
    final List<_NavItem> items = [
      _NavItem(Icons.home_rounded,          "Home"),
      _NavItem(FontAwesomeIcons.whatsapp,   "WA"),
      _NavItem(Icons.notifications_rounded, "Info"),
      _NavItem(Icons.music_note_rounded,    "Vibes"),
      _NavItem(Icons.grid_view_rounded,     "Tools"),
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      height: 68,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: _C.card.withValues(alpha: 0.9),
        border: Border.all(color: _C.line),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.6),
              blurRadius: 30,
              offset: const Offset(0, 10)),
          BoxShadow(
              color: _C.red.withValues(alpha: 0.03),
              blurRadius: 20),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: dart_ui.ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: Row(
            children: List.generate(items.length, (i) {
              final active = _bottomNavIndex == i;
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _onNavTapped(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 280),
                    curve: Curves.easeOutCubic,
                    margin: const EdgeInsets.symmetric(
                        vertical: 8, horizontal: 5),
                    decoration: BoxDecoration(
                      color: active
                          ? _C.red.withValues(alpha: 0.13)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(16),
                      border: active
                          ? Border.all(
                              color: _C.red.withValues(alpha: 0.28),
                              width: 1)
                          : null,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedScale(
                          scale: active ? 1.12 : 1.0,
                          duration: const Duration(milliseconds: 280),
                          child: Icon(
                            items[i].icon,
                            size: 20,
                            color: active
                                ? _C.red
                                : _C.muted.withValues(alpha: 0.6),
                          ),
                        ),
                        const SizedBox(height: 3),
                        AnimatedDefaultTextStyle(
                          duration: const Duration(milliseconds: 280),
                          style: TextStyle(
                            color: active
                                ? _C.red
                                : _C.muted.withValues(alpha: 0.6),
                            fontSize: active ? 9 : 8,
                            fontWeight: active
                                ? FontWeight.w800
                                : FontWeight.w500,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: active ? 0.8 : 0,
                          ),
                          child: Text(items[i].label),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      extendBody: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          const Positioned.fill(child: _DotGrid()),
          // Ambient red glow top
          Positioned(
            top: -80,
            left: MediaQuery.of(context).size.width * 0.5 - 100,
            child: Container(
              width: 200, height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  _C.red.withValues(alpha: 0.06),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 88),
              child: FadeTransition(
                opacity: _fade,
                child: _selectedPage,
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              Colors.transparent,
              _C.red.withValues(alpha: 0.18),
              Colors.transparent,
            ]),
          ),
        ),
      ),
      flexibleSpace: ClipRect(
        child: BackdropFilter(
          filter: dart_ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  _C.bg.withValues(alpha: 0.85),
                  _C.bg.withValues(alpha: 0.0),
                ],
              ),
            ),
          ),
        ),
      ),
      leading: IconButton(
        icon: Icon(Icons.tune_rounded, color: _C.red, size: 22),
        onPressed: () => _scaffoldKey.currentState?.openDrawer(),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Animated pulse dot in title
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Container(
              width: 6, height: 6,
              decoration: BoxDecoration(
                color: _C.red,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _C.red.withValues(alpha: _pulse.value * 0.7),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            "DARKVERSE",
            style: TextStyle(
              color: _C.white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 17,
              letterSpacing: 3,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.headset_mic_outlined,
              color: _C.white.withValues(alpha: 0.55), size: 20),
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const ContactPage())),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 6),
          child: IconButton(
            icon: Icon(FontAwesomeIcons.userCircle,
                color: _C.white.withValues(alpha: 0.55), size: 20),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(
                  builder: (_) => ProfilePage(
                    username: username,
                    password: password,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey,
                  ),
                )),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _newsTimer?.cancel();
    _newsCtrl.dispose();
    _statsTimer?.cancel();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    super.dispose();
  }
}

// ════════════════════════════════════════════════════════════
// REUSABLE WIDGETS
// ════════════════════════════════════════════════════════════

class _DotGrid extends StatelessWidget {
  const _DotGrid();
  @override
  Widget build(BuildContext context) =>
      CustomPaint(painter: _DotGridPainter());
}

class _DotGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = const Color(0xFF111111);
    const step = 28.0;
    for (double x = step; x < size.width; x += step) {
      for (double y = step; y < size.height; y += step) {
        canvas.drawCircle(Offset(x, y), 1, p);
      }
    }
  }
  @override
  bool shouldRepaint(_) => false;
}

// ─── AVATAR ──────────────────────────────────────────────────
class _Avatar extends StatelessWidget {
  final File? image;
  final Animation<double> pulse;
  final double size;
  final double borderWidth;
  const _Avatar({
    required this.image,
    required this.pulse,
    this.size = 60,
    this.borderWidth = 2.5,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: pulse,
      builder: (_, child) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: _C.red.withValues(alpha: pulse.value * 0.5 + 0.15),
            width: borderWidth,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.red.withValues(alpha: pulse.value * 0.18),
              blurRadius: 20,
            ),
          ],
        ),
        child: child,
      ),
      child: ClipOval(
        child: image != null
            ? Image.file(image!, fit: BoxFit.cover)
            : Container(
                color: _C.surface,
                child: Icon(FontAwesomeIcons.userAstronaut,
                    size: size * 0.38, color: _C.muted),
              ),
      ),
    );
  }
}

// ─── ROLE BADGE ──────────────────────────────────────────────
class _RoleBadge extends StatelessWidget {
  final String role;
  const _RoleBadge({required this.role});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(
          color: _C.red.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(7),
          border: Border.all(color: _C.red.withValues(alpha: 0.25)),
        ),
        child: Text(
          role.toUpperCase(),
          style: const TextStyle(
            color: _C.red,
            fontSize: 9,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
          ),
        ),
      );
}

// ─── EXP BADGE ───────────────────────────────────────────────
class _ExpBadge extends StatelessWidget {
  final String date;
  const _ExpBadge({required this.date});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(
          color: _C.dim.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(7),
          border: Border.all(color: _C.line),
        ),
        child: Text(
          date,
          style: TextStyle(
            color: _C.muted, fontSize: 9, fontFamily: 'ShareTechMono',
          ),
        ),
      );
}

// ─── ANIMATED COUNTER ────────────────────────────────────────
class _AnimatedCounter extends StatelessWidget {
  final int from;
  final int to;
  final TextStyle style;
  const _AnimatedCounter({
    required this.from,
    required this.to,
    required this.style,
  });
  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<int>(
      tween: IntTween(begin: from, end: to),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeOutCubic,
      builder: (_, val, __) =>
          Text('$val', style: style, maxLines: 1, overflow: TextOverflow.ellipsis),
    );
  }
}

// ─── BIG STAT CARD (new) ─────────────────────────────────────
class _BigStatCard extends StatelessWidget {
  final String label;
  final int numValue;
  final int prevValue;
  final Color accent;
  final IconData icon;
  final Animation<double>? pulse;
  final bool showPulse;

  const _BigStatCard({
    required this.label,
    required this.numValue,
    required this.prevValue,
    required this.accent,
    required this.icon,
    this.pulse,
    this.showPulse = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Label row
          Row(children: [
            if (showPulse && pulse != null)
              AnimatedBuilder(
                animation: pulse!,
                builder: (_, __) => Container(
                  width: 7, height: 7,
                  margin: const EdgeInsets.only(right: 7),
                  decoration: BoxDecoration(
                    color: accent,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: accent.withValues(alpha: pulse!.value * 0.8),
                        blurRadius: 10, spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.only(right: 7),
                child: Icon(icon, color: accent, size: 13),
              ),
            Text(
              label,
              style: const TextStyle(
                color: _C.muted,
                fontFamily: 'ShareTechMono',
                fontSize: 9,
                letterSpacing: 2,
              ),
            ),
          ]),
          const SizedBox(height: 8),
          // Big animated number
          _AnimatedCounter(
            from: prevValue,
            to: numValue,
            style: TextStyle(
              color: _C.white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 34,
              height: 1,
            ),
          ),
          const SizedBox(height: 10),
          // Accent underline
          Container(
            height: 2,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(1),
              gradient: LinearGradient(colors: [
                accent.withValues(alpha: 0.6),
                Colors.transparent,
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── TIER CARD (new) ─────────────────────────────────────────
class _TierCard extends StatelessWidget {
  final String role;
  const _TierCard({required this.role});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.line),
      ),
      child: Row(
        children: [
          Icon(Icons.shield_rounded, color: _C.red, size: 15),
          const SizedBox(width: 12),
          Text(
            "ACCESS TIER",
            style: TextStyle(
              color: _C.muted,
              fontFamily: 'ShareTechMono',
              fontSize: 9,
              letterSpacing: 2,
            ),
          ),
          const Spacer(),
          Text(
            role.toUpperCase(),
            style: const TextStyle(
              color: _C.white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 13,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: 8, height: 8,
            decoration: BoxDecoration(
              color: _C.red,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: _C.red.withValues(alpha: 0.5),
                  blurRadius: 8,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── NEWS CARD ───────────────────────────────────────────────
class _NewsCard extends StatelessWidget {
  final dynamic item;
  const _NewsCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: _C.card,
        border: Border.all(color: _C.line),
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (item['image'] != null && item['image'].toString().isNotEmpty)
            NewsMedia(url: item['image'])
          else
            Container(
                color: _C.card,
                child: Icon(Icons.newspaper_rounded,
                    color: _C.dim, size: 40)),
          // Gradient overlay (less dark)
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  Colors.black.withValues(alpha: 0.4),
                  Colors.black.withValues(alpha: 0.78),
                ],
                stops: const [0.3, 0.6, 1.0],
              ),
            ),
          ),
          // NEWS badge top-right
          Positioned(
            top: 14, right: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.red.withValues(alpha: 0.35)),
              ),
              child: const Text(
                "NEWS",
                style: TextStyle(
                  color: _C.red,
                  fontSize: 8,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
          // Bottom content
          Positioned(
            bottom: 18, left: 18, right: 18,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item['title'] ?? 'No Title',
                  style: const TextStyle(
                    color: _C.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    height: 1.3,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                if (item['desc'] != null &&
                    item['desc'].toString().isNotEmpty) ...[
                  const SizedBox(height: 5),
                  Text(
                    item['desc'],
                    style: TextStyle(
                      color: _C.muted,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── WHATSAPP SHEET ──────────────────────────────────────────
class _WhatsAppSheet extends StatelessWidget {
  final VoidCallback onCrash;
  final VoidCallback onSender;
  const _WhatsAppSheet({required this.onCrash, required this.onSender});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        border: Border(
          top:   BorderSide(color: _C.line),
          left:  BorderSide(color: _C.line),
          right: BorderSide(color: _C.line),
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 36, height: 3,
            margin: const EdgeInsets.only(bottom: 22),
            decoration: BoxDecoration(
                color: _C.dim, borderRadius: BorderRadius.circular(2)),
          ),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.red.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: _C.red.withValues(alpha: 0.2)),
                ),
                child: const Icon(FontAwesomeIcons.whatsapp,
                    color: _C.red, size: 20),
              ),
              const SizedBox(width: 14),
              const Text(
                "WHATSAPP TOOLS",
                style: TextStyle(
                  color: _C.red,
                  fontFamily: 'Orbitron',
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _SheetItem(
            icon: Icons.bug_report_rounded,
            iconColor: _C.red,
            title: "WhatsApp Crash",
            subtitle: "Send payloads & crash codes",
            onTap: onCrash,
          ),
          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(vertical: 8),
            color: _C.line,
          ),
          _SheetItem(
            icon: Icons.devices_rounded,
            iconColor: _C.green,
            title: "Manage Sender",
            subtitle: "Pair devices & manage sessions",
            onTap: onSender,
          ),
        ],
      ),
    );
  }
}

class _SheetItem extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _SheetItem({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: iconColor.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: iconColor.withValues(alpha: 0.15)),
                ),
                child: Icon(icon, color: iconColor, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            color: _C.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 15)),
                    const SizedBox(height: 3),
                    Text(subtitle,
                        style: TextStyle(
                            color: _C.muted,
                            fontSize: 12,
                            fontFamily: 'ShareTechMono')),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios_rounded,
                  color: _C.dim, size: 14),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── DRAWER ITEM ─────────────────────────────────────────────
class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String? badge;
  final bool isDestructive;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.iconColor,
    required this.label,
    this.badge,
    this.isDestructive = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = isDestructive ? Colors.redAccent : _C.white;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
            decoration: BoxDecoration(
              color: isDestructive
                  ? Colors.redAccent.withValues(alpha: 0.05)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
              border: isDestructive
                  ? Border.all(
                      color: Colors.redAccent.withValues(alpha: 0.12))
                  : null,
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: iconColor.withValues(alpha: 0.07),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: Icon(icon, color: iconColor, size: 18),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      color: color.withValues(alpha: 0.85),
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                ),
                if (badge != null)
                  Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFD700).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                          color: const Color(0xFFFFD700).withValues(alpha: 0.2)),
                    ),
                    child: Text(
                      badge!,
                      style: const TextStyle(
                        color: Color(0xFFFFD700),
                        fontSize: 8,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                Icon(Icons.chevron_right_rounded, color: _C.dim, size: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── SESSION DIALOG ──────────────────────────────────────────
class _SessionDialog extends StatelessWidget {
  final String message;
  final VoidCallback onOk;
  const _SessionDialog({required this.message, required this.onOk});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _C.red.withValues(alpha: 0.2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _C.red.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.warning_amber_rounded,
                  color: _C.red, size: 28),
            ),
            const SizedBox(height: 16),
            const Text(
              "SESSION EXPIRED",
              style: TextStyle(
                color: _C.red,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: 14,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              message,
              style: TextStyle(
                color: _C.muted,
                fontSize: 13,
                height: 1.5,
                fontFamily: 'ShareTechMono',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: onOk,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _C.red.withValues(alpha: 0.12),
                  foregroundColor: _C.red,
                  elevation: 0,
                  side: BorderSide(
                      color: _C.red.withValues(alpha: 0.3), width: 1.5),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text(
                  "OK",
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem(this.icon, this.label);
}

class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    if (url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov")) {
      return Container(
        color: Colors.black,
        child: const Center(
          child: Icon(Icons.videocam_off_rounded,
              color: Color(0xFF3D3D3D), size: 50),
        ),
      );
    }
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: _C.card,
        child: const Center(
          child: Icon(Icons.broken_image_rounded, color: Color(0xFF3D3D3D)),
        ),
      ),
    );
  }
}
