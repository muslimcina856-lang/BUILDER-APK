package com.fahri.akungelag;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
