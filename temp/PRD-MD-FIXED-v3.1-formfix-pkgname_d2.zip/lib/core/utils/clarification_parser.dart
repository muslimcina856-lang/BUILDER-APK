import 'dart:convert';

/// A single selectable option inside a clarification form.
class FormOption {
  final String label;
  final String value;

  const FormOption({
    required this.label,
    required this.value,
  });

  factory FormOption.fromJson(Map<String, dynamic> json) {
    return FormOption(
      label: (json['label'] as String?) ?? '',
      value: (json['value'] as String?) ?? '',
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'label': label,
        'value': value,
      };

  @override
  String toString() => 'FormOption(label: $label, value: $value)';
}

/// Structured data extracted from a `[CLARIFICATION_FORM]` block.
class ClarificationFormData {
  final String question;
  final String fieldName;

  /// Either `'single'` or `'multiple'`.
  final String selectionType;

  final List<FormOption> options;
  final bool allowCustom;
  final String customPlaceholder;

  const ClarificationFormData({
    required this.question,
    required this.fieldName,
    required this.selectionType,
    required this.options,
    this.allowCustom = false,
    this.customPlaceholder = '',
  });

  /// Whether the user may select more than one option.
  bool get isMultiSelect => selectionType == 'multiple';

  factory ClarificationFormData.fromJson(Map<String, dynamic> json) {
    final List<dynamic> rawOptions =
        (json['options'] as List<dynamic>?) ?? <dynamic>[];

    return ClarificationFormData(
      question: (json['question'] as String?) ?? '',
      fieldName: (json['field_name'] as String?) ?? '',
      selectionType: (json['selection_type'] as String?) ?? 'single',
      options: rawOptions
          .whereType<Map<String, dynamic>>()
          .map(FormOption.fromJson)
          .toList(),
      allowCustom: _parseAllowCustom(json['allow_custom']),
      customPlaceholder:
          (json['custom_placeholder'] as String?) ?? '',
    );
  }

  /// Parses `allow_custom` leniently. MiMo AI is instructed to send a
  /// real JSON bool, but occasionally a model may send it as a string
  /// (e.g. `"true"`) instead. Rather than silently defaulting to `false`
  /// on any type mismatch (which would hide the custom input field the
  /// user actually needs), this accepts bool or common string forms.
  static bool _parseAllowCustom(dynamic value) {
    if (value is bool) return value;
    if (value is String) {
      final String normalized = value.trim().toLowerCase();
      return normalized == 'true' || normalized == 'ya' || normalized == 'yes';
    }
    return false;
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'question': question,
        'field_name': fieldName,
        'selection_type': selectionType,
        'options': options
            .map((FormOption o) => o.toJson())
            .toList(),
        'allow_custom': allowCustom,
        'custom_placeholder': customPlaceholder,
      };

  @override
  String toString() =>
      'ClarificationFormData(question: $question, fieldName: $fieldName, '
      'selectionType: $selectionType, options: ${options.length})';
}

/// The result of parsing an AI response that may contain a clarification form.
class ClarificationResult {
  /// Text appearing before the `[CLARIFICATION_FORM]` tag (may be empty).
  final String beforeText;

  /// Parsed form data, or `null` if no valid form was found.
  final ClarificationFormData? formData;

  /// Text appearing after the `[/CLARIFICATION_FORM]` tag (may be empty).
  final String afterText;

  const ClarificationResult({
    required this.beforeText,
    required this.formData,
    required this.afterText,
  });

  /// Whether this result contains a parseable clarification form.
  bool get hasForm => formData != null;

  @override
  String toString() =>
      'ClarificationResult(hasForm: $hasForm, '
      'before: ${beforeText.length} chars, '
      'after: ${afterText.length} chars)';
}

/// Parses AI responses for embedded `[CLARIFICATION_FORM]` blocks
/// and produces structured [ClarificationResult]s.
class ClarificationParser {
  /// Regex to locate `[CLARIFICATION_FORM]{...}[/CLARIFICATION_FORM]` blocks.
  static final RegExp _formRegex = RegExp(
    r'\[CLARIFICATION_FORM\](.*?)\[/CLARIFICATION_FORM\]',
    dotAll: true,
  );

  /// Regex to locate a `[CLARIFICATION_FORM]` opening tag on its own,
  /// used as a fallback when the model omits the closing tag.
  static final RegExp _openingTagOnlyRegex = RegExp(r'\[CLARIFICATION_FORM\]');

  /// Regex used as a last-resort fallback to detect a bare JSON object
  /// (no tags at all) that structurally looks like a clarification form,
  /// i.e. starts with `{` and contains both a `"question"` and an
  /// `"options"` key. This catches cases where the model omits BOTH the
  /// opening and closing tags entirely and sends raw JSON instead.
  static final RegExp _bareJsonFormRegex = RegExp(
    r'^\s*\{.*?"question"\s*:.*?"options"\s*:\s*\[.*',
    dotAll: true,
  );

  const ClarificationParser();

  /// Parses [text] for a clarification form block.
  ///
  /// If a valid `[CLARIFICATION_FORM]...[/CLARIFICATION_FORM]` block is found,
  /// the returned [ClarificationResult] will have [hasForm] == `true` with
  /// the parsed [ClarificationFormData].
  ///
  /// If the closing tag `[/CLARIFICATION_FORM]` is missing (the model
  /// occasionally omits it, especially on repeated forms within the same
  /// conversation), this falls back to treating everything after the
  /// opening tag as the JSON candidate and attempts to parse it anyway —
  /// rather than giving up and showing the raw tag/JSON as plain text.
  ///
  /// As a last resort, if BOTH tags are missing but the response is a
  /// bare JSON object that structurally matches a clarification form
  /// (starts with `{` and has `"question"` + `"options"` keys), this is
  /// also parsed as a form. This handles cases where the model skips the
  /// tags entirely, which tends to happen more often on repeated forms
  /// later in a conversation.
  ///
  /// If the block exists but contains malformed JSON even after these
  /// fallbacks, the entire [text] is returned as [beforeText] with no
  /// form data (graceful degradation).
  ClarificationResult parse(String text) {
    if (text.isEmpty) {
      return const ClarificationResult(
        beforeText: '',
        formData: null,
        afterText: '',
      );
    }

    final RegExpMatch? match = _formRegex.firstMatch(text);

    if (match != null) {
      return _parseMatchedBlock(
        text: text,
        beforeText: text.substring(0, match.start).trim(),
        afterText: text.substring(match.end).trim(),
        jsonStr: (match.group(1) ?? '').trim(),
      );
    }

    // Tiada padanan lengkap (tag penutup hilang). Cuba fallback: cari tag
    // pembuka sahaja, dan anggap selebihnya teks selepas tag itu adalah
    // calon JSON — model kadang-kadang terlepas pandang tag penutup,
    // terutamanya pada soalan kedua/seterusnya dalam sesi yang sama.
    final RegExpMatch? openingOnly = _openingTagOnlyRegex.firstMatch(text);

    if (openingOnly != null) {
      final String beforeText = text.substring(0, openingOnly.start).trim();
      final String candidateJson = text.substring(openingOnly.end).trim();

      return _parseMatchedBlock(
        text: text,
        beforeText: beforeText,
        afterText: '',
        jsonStr: candidateJson,
      );
    }

    // Tiada sebarang tag langsung. Fallback terakhir: semak jika teks
    // ini sendiri adalah objek JSON mentah yang secara struktur nampak
    // seperti clarification form (bermula dengan "{" dan mengandungi
    // kedua-dua "question" dan "options"). Ini menangani kes di mana
    // model terlepas pandang KEDUA-DUA tag sepenuhnya.
    if (_bareJsonFormRegex.hasMatch(text)) {
      return _parseMatchedBlock(
        text: text,
        beforeText: '',
        afterText: '',
        jsonStr: text.trim(),
      );
    }

    return ClarificationResult(
      beforeText: text,
      formData: null,
      afterText: '',
    );
  }

  /// Attempts to decode [jsonStr] as a [ClarificationFormData]. On any
  /// failure, falls back to returning the full original [text] as plain
  /// text with no form (graceful degradation) — this keeps the
  /// success/failure handling identical whether the closing tag was
  /// present or had to be inferred via the fallback path.
  ClarificationResult _parseMatchedBlock({
    required String text,
    required String beforeText,
    required String afterText,
    required String jsonStr,
  }) {
    if (jsonStr.isEmpty) {
      return ClarificationResult(
        beforeText: text,
        formData: null,
        afterText: '',
      );
    }

    try {
      final dynamic decoded = jsonDecode(jsonStr);

      if (decoded is! Map<String, dynamic>) {
        // JSON parsed but is not an object – treat as plain text.
        return ClarificationResult(
          beforeText: text,
          formData: null,
          afterText: '',
        );
      }

      final ClarificationFormData formData =
          ClarificationFormData.fromJson(decoded);

      // Validate minimally: question and at least one option required.
      if (formData.question.isEmpty) {
        return ClarificationResult(
          beforeText: text,
          formData: null,
          afterText: '',
        );
      }

      return ClarificationResult(
        beforeText: beforeText,
        formData: formData,
        afterText: afterText,
      );
    } on FormatException {
      // Malformed JSON – return everything as plain text.
      return ClarificationResult(
        beforeText: text,
        formData: null,
        afterText: '',
      );
    } catch (_) {
      // Any other error – graceful degradation.
      return ClarificationResult(
        beforeText: text,
        formData: null,
        afterText: '',
      );
    }
  }

  /// Formats a user's form response into a natural-language string
  /// suitable for sending back into the chat.
  ///
  /// [fieldName] – the field being answered.
  /// [selectedValues] – the option values chosen by the user.
  /// [customValue] – optional freeform text from the user.
  String formatResponse(
    String fieldName,
    List<String> selectedValues, {
    String? customValue,
  }) {
    final StringBuffer sb = StringBuffer();

    sb.write('Jawapan untuk keperluan [$fieldName]: ');
    sb.write(selectedValues.join(', '));

    if (customValue != null && customValue.trim().isNotEmpty) {
      sb.write(' dengan maklum balas kustom: ');
      sb.write(customValue.trim());
    }

    return sb.toString();
  }
}
