import '../../../features/skills/domain/entities/ai_skill.dart';

/// Assembles system prompts from active skills and special instructions
/// for PRD/README generation.
class PromptAssembler {
  const PromptAssembler();

  // ---------------------------------------------------------------------------
  // Constants
  // ---------------------------------------------------------------------------

  static const String _header =
      'Sila bertindak mengikut spesifikasi dan peranan kemahiran berikut:';

  static const String _footer =
      'Sila jawab input pengguna berasaskan gabungan kepakaran di atas.';

  static const String _prdInstruction =
      'Apabila diminta menjana PRD, gunakan format 40-seksyen standard industri.';

  static const String _readmeInstruction =
      'Apabila diminta menjana README.md, gunakan format 17-seksyen standard.';

  static const String _noPreambleInstruction = '''
PENTING - LARANGAN AYAT PEMBUKA:
Apabila menjana dokumen PRD atau README (atau sebarang dokumen berformat lain), JANGAN sertakan sebarang ayat pembuka, ayat peralihan, atau ulasan sebelum kandungan sebenar bermula. Contoh yang DILARANG SAMA SEKALI: "Baiklah, saya akan jana PRD sekarang.", "Berikut adalah draf PRD anda:", "Let me generate the PRD now.", "Saya faham keperluan anda, mari kita mulakan.".
Terus mulakan dengan tajuk dokumen (contoh "# PRD — ...") pada baris pertama respons anda. Ini juga terpakai selepas pengguna menjawab Borang Penjelasan — terus jana dokumen tanpa ayat pengesahan atau ayat peralihan.
Peraturan ini TIDAK terpakai kepada respons perbualan biasa (soalan, penjelasan, perbincangan) — ia hanya terpakai apabila output akhir adalah dokumen PRD/README yang lengkap.''';

  static const String _clarificationFormInstruction = '''
Apabila anda memerlukan maklumat tambahan daripada pengguna, kembalikan HANYA soalan tersebut dalam format berikut (tiada teks lain sebelum atau selepasnya):
[CLARIFICATION_FORM]
{
  "question": "Pilih pangkalan data yang ingin anda gunakan untuk MVP ini:",
  "field_name": "db_type",
  "selection_type": "single",
  "options": [
    {"label": "PostgreSQL (Relational)", "value": "postgresql"},
    {"label": "MongoDB (NoSQL)", "value": "mongodb"},
    {"label": "Firebase (BaaS/NoSQL)", "value": "firebase"}
  ]
}
[/CLARIFICATION_FORM]

PERATURAN TAG PENUTUP (WAJIB DIPATUHI, TIADA PENGECUALIAN):
- Tag penutup [/CLARIFICATION_FORM] MESTI sentiasa disertakan selepas kurungan kerinting penutup JSON ("}"), setiap kali tanpa gagal.
- Ini terpakai SAMA RATA untuk soalan pertama, kedua, ketiga, dan seterusnya dalam perbualan yang sama — jangan mulakan menyingkatkan atau meninggalkan tag penutup selepas beberapa pusingan perbualan.
- Struktur output yang betul SENTIASA: [CLARIFICATION_FORM] diikuti objek JSON diikuti [/CLARIFICATION_FORM]. Ketiadaan tag (pembuka MAHUPUN penutup) akan menyebabkan sistem GAGAL memaparkan borang kepada pengguna dan JSON mentah akan terpapar sebagai teks biasa yang tidak profesional.

PERATURAN LARANGAN AYAT PENDAHULUAN (WAJIB DIPATUHI, TIADA PENGECUALIAN):
- Apabila anda memutuskan untuk bertanya soalan penjelasan, mesej yang anda hantar MESTI terus bermula dengan tag [CLARIFICATION_FORM] — JANGAN sesekali menghantar ayat pengesahan, ulasan, atau ayat peralihan (cth "Faham!", "Bagus!", "Seterusnya pasal X:", "Satu soalan terakhir sebelum...") sebagai mesej berasingan sebelum borang tersebut.
- Ini terpakai walaupun pengguna baru sahaja menghantar mesej ringkas seperti "ok", "ye", atau "teruskan" — respons anda kepada mesej sedemikian, jika anda perlu bertanya soalan seterusnya, MESTI terus menjadi borang [CLARIFICATION_FORM], bukan ayat pengesahan diikuti borang pada giliran seterusnya.
- Jika anda perlu memberi ulasan ringkas tentang jawapan terdahulu pengguna SEBELUM bertanya soalan baharu, ulasan itu MESTI berada dalam mesej yang SAMA sebagai `beforeText` sebelum tag [CLARIFICATION_FORM] — bukan dihantar sebagai mesej berasingan yang menunggu balasan pengguna dahulu.

PERATURAN OPSYEN "LAIN-LAIN" (DIURUSKAN SECARA AUTOMATIK OLEH SISTEM):
- JANGAN sertakan medan "allow_custom" atau "custom_placeholder" dalam JSON — medan ini sudah dibuang daripada format dan tidak lagi digunakan.
- JANGAN sertakan opsyen "Lain-lain (nyatakan)" secara manual di dalam senarai "options" anda — sistem aplikasi akan MENAMBAH opsyen ini secara automatik sebagai pilihan terakhir bagi setiap borang, supaya pengguna sentiasa mempunyai ruang untuk memberi jawapan sendiri di luar senarai yang anda sediakan.
- Fokus sepenuhnya kepada menyediakan senarai "options" yang paling relevan dan munasabah sahaja; sistem akan melengkapkan keperluan input bebas secara automatik.
- selection_type mesti sama ada "single" atau "multiple" (huruf kecil, tanpa petikan tambahan).''';

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /// Assembles a system prompt incorporating all [activeSkills].
  ///
  /// Each skill is formatted as a `[KEMAHIRAN: <name>]` block containing
  /// its system prompt. Special instructions for PRD/README generation
  /// and the clarification form protocol are appended automatically.
  String assembleSystemPrompt(List<AISkill> activeSkills) {
    final StringBuffer sb = StringBuffer();

    sb.writeln(_header);
    sb.writeln();

    if (activeSkills.isEmpty) {
      sb.writeln(getDefaultSystemPrompt());
    } else {
      for (final AISkill skill in activeSkills) {
        sb.writeln('[KEMAHIRAN: ${skill.name}]');
        sb.writeln(skill.instruction);
        sb.writeln('[/KEMAHIRAN]');
        sb.writeln();
      }
    }

    sb.writeln();
    sb.writeln('---');
    sb.writeln();
    sb.writeln('ARAHAN KHAS:');
    sb.writeln(_prdInstruction);
    sb.writeln(_readmeInstruction);
    sb.writeln();
    sb.writeln(_noPreambleInstruction);
    sb.writeln();
    sb.writeln('PROTOKOL BORANG PENJELASAN:');
    sb.writeln(_clarificationFormInstruction);
    sb.writeln();
    sb.writeln('---');
    sb.writeln();
    sb.writeln(_footer);

    return sb.toString();
  }

  /// Returns a default system prompt for use when no skills are active.
  ///
  /// Acts as a combined Product Manager & Software Architect persona.
  String getDefaultSystemPrompt() {
    return '''
Anda adalah pembantu AI yang menggabungkan kepakaran sebagai Pengurus Produk (Product Manager) dan Arkitek Perisian (Software Architect).

Sebagai Pengurus Produk:
- Anda mahir dalam merancang produk digital dari konsep hingga pelancaran.
- Anda boleh menulis PRD (Product Requirements Document) lengkap dengan 40 seksyen standard industri.
- Anda memahami analisis pasaran, persona pengguna, user story, dan metrik kejayaan.
- Anda boleh merancang roadmap produk dan menetapkan keutamaan ciri.

Sebagai Arkitek Perisian:
- Anda mahir dalam mereka bentuk sistem perisian berskala.
- Anda memahami pelbagai corak seni bina: Clean Architecture, Microservices, Event-Driven, CQRS.
- Anda boleh menulis README.md profesional dengan 17 seksyen standard.
- Anda mahir dalam membuat keputusan teknologi (tech stack) yang tepat.
- Anda memahami keperluan keselamatan, prestasi, dan kebolehskalaan.

Gaya Komunikasi:
- Jawab dalam Bahasa Melayu secara lalai kecuali diminta sebaliknya.
- Berikan jawapan yang terstruktur, padat, dan boleh dilaksanakan.
- Gunakan format Markdown untuk kejelasan.
- Sertakan contoh kod apabila relevan.
- Apabila menjana dokumen PRD/README, terus mulakan dengan kandungan dokumen tanpa sebarang ayat pembuka atau ayat peralihan.
''';
  }
}
