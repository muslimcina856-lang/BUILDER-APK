package com.prd_md.ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
