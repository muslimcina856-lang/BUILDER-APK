import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Chat App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFF0b0f14),
      ),
      home: const WebViewScreen(),
    );
  }
}

class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  WebViewController? _controller;
  bool _isLoading = true;

  // Halaman pertama yang dibuka saat app dijalankan.
  // Urutan halaman: login.html -> dashboard.html -> (verif.html / woun.html / verifikasi2.html)
  static const String startPage = 'login.html';

  @override
  void initState() {
    super.initState();
    _setupWebView();
  }

  /// Menyalin semua file di assets/web/ ke storage lokal device,
  /// supaya semua link relatif (dashboard.html, style.css, seting.js, dst)
  /// tetap berjalan normal persis seperti website aslinya.
  Future<void> _setupWebView() async {
    final docDir = await getApplicationDocumentsDirectory();
    final webDir = Directory('${docDir.path}/web');
    if (!await webDir.exists()) {
      await webDir.create(recursive: true);
    }

    final manifestJson = await rootBundle.loadString('AssetManifest.json');
    final Map<String, dynamic> manifestMap = json.decode(manifestJson);

    final webAssets =
        manifestMap.keys.where((k) => k.startsWith('assets/web/')).toList();

    for (final assetPath in webAssets) {
      final fileName = assetPath.replaceFirst('assets/web/', '');
      final byteData = await rootBundle.load(assetPath);
      final file = File('${webDir.path}/$fileName');
      await file.writeAsBytes(
        byteData.buffer.asUint8List(
          byteData.offsetInBytes,
          byteData.lengthInBytes,
        ),
      );
    }

    final entryFile = File('${webDir.path}/$startPage');

    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0b0f14))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _isLoading = false);
          },
        ),
      )
      ..loadFile(entryFile.path);

    setState(() {
      _controller = controller;
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // Tombol back HP akan kembali ke halaman web sebelumnya
      // (misal dari dashboard balik ke login, dst), bukan langsung keluar app.
      onWillPop: () async {
        if (_controller != null && await _controller!.canGoBack()) {
          _controller!.goBack();
          return false;
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0b0f14),
        body: SafeArea(
          child: Stack(
            children: [
              if (_controller != null) WebViewWidget(controller: _controller!),
              if (_isLoading)
                const Center(
                  child: CircularProgressIndicator(color: Color(0xFF00a884)),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
