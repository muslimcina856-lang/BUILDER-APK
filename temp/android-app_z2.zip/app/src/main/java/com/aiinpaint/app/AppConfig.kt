package com.aiinpaint.app

/**
 * ===== CONFIG YANG PERLU DIISI =====
 * Hanya dua nilai ni sahaja yang wajib.
 */
object AppConfig {
    const val GITHUB_TOKEN = "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"
    const val GITHUB_REPO = "earltiktokofficial04-jpg/AI-REMOVAL"   // contoh: ali/ai-inpaint
}
