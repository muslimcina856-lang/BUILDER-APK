# Metadata yang diperlukan oleh Room, Hilt, Compose dan coroutine semasa R8 full mode.
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations,AnnotationDefault,Signature,InnerClasses,EnclosingMethod

# Kekalkan nombor baris untuk retrace, tetapi sembunyikan nama fail sumber asal.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Room menggunakan kod jana terus. Hanya ahli beranotasi perlu selamat daripada dibuang;
# nama kelas dan ahli masih dibenarkan untuk dikaburkan.
-keepclassmembers,allowoptimization,allowobfuscation class * {
    @androidx.room.PrimaryKey <fields>;
    @androidx.room.ColumnInfo <fields>;
    @androidx.room.Query <methods>;
}

# Nilai enum disimpan sebagai teks di pangkalan data, jadi nama pemalar mesti stabil.
-keepclassmembers enum com.adaptez.pool.domain.model.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
    public static final ** *;
}

# Selamat untuk penambahan JNI pada masa depan tanpa membuka keseluruhan kod daripada obfuscation.
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# Peraturan pengguna tambahan sengaja minimum; Room, Hilt, Compose dan coroutine turut
# membekalkan consumer rules masing-masing kepada R8.
