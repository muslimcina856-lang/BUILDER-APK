package com.adaptez.pool.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [PlayerProfileEntity::class, MatchEntity::class, LearningProfileEntity::class],
    version = 1,
    exportSchema = true
)
abstract class PoolDatabase : RoomDatabase() {
    abstract fun poolDao(): PoolDao

    companion object {
        @Volatile private var instance: PoolDatabase? = null

        fun create(context: Context): PoolDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                PoolDatabase::class.java,
                "adapt_pool.db"
            ).build().also { instance = it }
        }
    }
}
