package com.adaptez.pool.presentation.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adaptez.pool.presentation.pool.PoolUiState

@Composable
fun StatsScreen(state: PoolUiState, modifier: Modifier = Modifier) {
    var about by remember { mutableStateOf(false) }
    if (about) AboutDialog { about = false }
    val player = state.player
    val history = state.history
    val winRate = if ((player?.totalMatches ?: 0) == 0) 0 else (player!!.wins * 100 / player.totalMatches)
    val avgAccuracy = if (history.isEmpty()) 0.0 else history.map { it.shotAccuracy }.average()
    val avgShots = if (history.isEmpty()) 0.0 else history.map { it.totalShots }.average()

    Column(
        modifier = modifier.fillMaxSize().background(Color(0xFF0D0F12)).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Prestasi", color = Color(0xFFF3EEE4), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Ringkasan kemajuan dan profil pembelajaran AI.", color = Color(0xFFA6A39C), fontSize = 12.sp)
            }
            OutlinedButton(
                onClick = { about = true },
                contentPadding = PaddingValues(horizontal = 11.dp, vertical = 7.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD8B477).copy(alpha = 0.42f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD8B477)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Rounded.Info, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("About", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(18.dp))

        if (player == null) {
            CircularProgressIndicator(color = Color(0xFFD8B477)); return@Column
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Perlawanan", player.totalMatches.toString(), Modifier.weight(1f))
            StatCard("Kadar menang", "$winRate%", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Level AI", "${player.currentLevel} / 999", Modifier.weight(1f), Color(0xFFD8B477))
            StatCard("Data dipelajari", state.learning.samples.toString(), Modifier.weight(1f), Color(0xFF76C8A5))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Ketepatan purata", "${"%.1f".format(avgAccuracy)}%", Modifier.weight(1f), Color(0xFF76C8A5))
            StatCard("Purata pukulan", "${"%.1f".format(avgShots)}", Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))

        Surface(color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("RINGKASAN", color = Color(0xFFD8B477), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                SummaryRow("Menang", player.wins, Color(0xFF76C8A5))
                SummaryRow("Kalah", player.losses, Color(0xFFE07171))
                SummaryRow("Rentak semasa", player.currentStreak, Color(0xFFD8B477))
                SummaryRow("Rentak terbaik", player.bestStreak, Color(0xFFD8B477))
                HorizontalDivider(color = Color(0xFF292D33))
                Text("Masa bermain: ${formatDuration(player.totalPlayTimeMs)}", color = Color(0xFFA6A39C), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))

        Surface(color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("PROFIL ADAPTIF AI", color = Color(0xFF76C8A5), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                LearningBar("Agresif", state.learning.aggression)
                LearningBar("Safety", state.learning.safety)
                LearningBar("Kuasa purata", state.learning.averagePower)
                LearningBar("Penggunaan spin", state.learning.spinUsage)
                LearningBar("Bank shot", state.learning.bankUsage)
                LearningBar("Kejayaan pot", state.learning.potSuccess)
            }
        }
        Spacer(Modifier.height(12.dp))

        Surface(color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("AI INSIGHTS", color = Color(0xFFD8B477), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                state.learningInsights.forEach { Text("• $it", color = Color(0xFFF3EEE4).copy(alpha = 0.88f), fontSize = 11.sp) }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, accent: Color = Color(0xFFF3EEE4)) {
    Surface(modifier = modifier, color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(label, color = Color(0xFF858681), fontSize = 10.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = accent, fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: Int, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xFFA6A39C), fontSize = 12.sp)
        Text(value.toString(), color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LearningBar(label: String, value: Double) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFA6A39C), fontSize = 10.sp)
            Text("${(value.coerceIn(0.0,1.0)*100).toInt()}%", color = Color(0xFFF3EEE4), fontSize = 10.sp)
        }
        LinearProgressIndicator(
            progress = value.toFloat().coerceIn(0f,1f),
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = Color(0xFF76C8A5), trackColor = Color(0xFF252930)
        )
    }
}

@Composable
private fun AboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color(0xFF171A1F), titleContentColor = Color(0xFFF3EEE4), textContentColor = Color(0xFFA6A39C),
        title = { Text("Tentang Adapt Pool", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Permainan 8-Ball 3D luar talian dengan lawan AI adaptif. AI mempelajari kuasa, spin, safety, bank shot dan kadar pot pemain, kemudian mengubah strategi tanpa membaca input tersembunyi atau memanipulasi fizik.", fontSize = 12.sp, lineHeight = 18.sp)
                Surface(color = Color(0xFFD8B477).copy(alpha = 0.10f), shape = RoundedCornerShape(13.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp)) {
                        Text("ADAPT POOL", color = Color(0xFFD8B477), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                        Text("com.adaptez.pool", color = Color(0xFFF3EEE4), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Level adaptif 1–999", color = Color(0xFFA6A39C), fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFFD8B477), fontWeight = FontWeight.Bold) } }
    )
}

private fun formatDuration(ms: Long): String {
    val totalMinutes = ms / 60_000
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (hours > 0) "${hours}j ${minutes}m" else "${minutes}m"
}
