package com.adaptez.pool.presentation.pool

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

/** Low-latency PCM pool sounds kept in static AudioTrack buffers. */
class PoolSoundManager(@Suppress("UNUSED_PARAMETER") context: Context) {
    private val sampleRate = 44_100
    private val cue = mutableListOf<AudioTrack>()
    private val ball = mutableListOf<AudioTrack>()
    private val pocket = mutableListOf<AudioTrack>()
    private var cueIndex = -1; private var ballIndex = -1; private var pocketIndex = -1

    init { runCatching {
        repeat(4) { i ->
            cue += track(impact(120, 31+i*17, 690.0+i*18, 0.68, 48.0))
            ball += track(impact(85, 73+i*23, 920.0+i*27, 0.50, 62.0))
            pocket += track(pocketSound(210, 101+i*29, i))
        }
    }}

    fun playCue(){ cueIndex=playNext(cue,cueIndex) }
    fun playCollision(){ ballIndex=playNext(ball,ballIndex) }
    fun playPocket(){ pocketIndex=playNext(pocket,pocketIndex) }
    fun release(){ (cue+ball+pocket).forEach{ runCatching{it.release()} } }

    private fun playNext(list:List<AudioTrack>,current:Int):Int{
        if(list.isEmpty()) return current
        val next=(current+1)%list.size
        runCatching { list[next].takeIf{it.state==AudioTrack.STATE_INITIALIZED}?.also{
            if(it.playState==AudioTrack.PLAYSTATE_PLAYING) it.stop(); it.reloadStaticData(); it.play()
        }}
        return next
    }

    private fun track(samples:ShortArray)=AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(samples.size*2).setTransferMode(AudioTrack.MODE_STATIC).build().also{it.write(samples,0,samples.size)}

    private fun impact(ms:Int,seed:Int,freq:Double,level:Double,decay:Double):ShortArray{
        val r=Random(seed); val phase=r.nextDouble(0.0,2*PI)
        return ShortArray(sampleRate*ms/1000){i->
            val t=i.toDouble()/sampleRate
            val transient=(r.nextDouble()*2-1)*exp(-220*t)*0.42
            val tone=(sin(2*PI*freq*t+phase)*0.62+sin(2*PI*freq*1.73*t)*0.25+sin(2*PI*freq*2.41*t)*0.13)*exp(-decay*t)
            sample((transient+tone)*level)
        }
    }

    private fun pocketSound(ms:Int,seed:Int,variant:Int):ShortArray{
        val r=Random(seed); var low=0.0
        return ShortArray(sampleRate*ms/1000){i->
            val t=i.toDouble()/sampleRate
            val white=r.nextDouble()*2-1; low += 0.08*(white-low)
            val drop=sin(2*PI*(165.0+variant*7)*t)*exp(-16*t)*0.40
            val leather=low*exp(-22*t)*0.42
            val click=white*exp(-180*t)*0.22
            sample(drop+leather+click)
        }
    }

    private fun sample(v:Double):Short=(tanh(v*2.0)*24500.0).toInt().coerceIn(-32768,32767).toShort()
}
