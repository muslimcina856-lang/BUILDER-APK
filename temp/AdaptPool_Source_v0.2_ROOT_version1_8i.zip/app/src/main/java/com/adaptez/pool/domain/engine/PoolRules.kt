package com.adaptez.pool.domain.engine

import com.adaptez.pool.domain.model.*

object PoolRules {
    fun evaluateShot(state: PoolGameState, result: ShotResult): RuleOutcome {
        if (state.gameOver) return RuleOutcome(state, false, message = "Perlawanan telah tamat")

        val shooter = state.turn
        val opponent = shooter.other()
        val shooterGroup = state.groupFor(shooter)
        val first = result.firstContact
        val pocketedNumbers = result.pocketedBalls.map { it.number }
        val cueScratch = result.cueBallPocketed || 0 in pocketedNumbers

        var foulReason: String? = null
        if (cueScratch) foulReason = "Cue ball masuk poket"
        if (first == null && foulReason == null) foulReason = "Tiada bola sasaran disentuh"

        if (state.isBreakShot) {
            val legalBreak = pocketedNumbers.any { it in 1..15 && it != 8 } || result.objectBallsToRail >= 4
            if (!legalBreak && foulReason == null) foulReason = "Break tidak sah: perlu pot bola atau 4 bola ke rail"
        } else if (first != null && foulReason == null) {
            val correctFirstContact = when (shooterGroup) {
                BallGroup.OPEN -> first != 8
                BallGroup.SOLIDS, BallGroup.STRIPES -> {
                    if (state.remaining(shooterGroup) == 0) first == 8
                    else state.ball(first)?.group == shooterGroup
                }
            }
            if (!correctFirstContact) foulReason = "Bola pertama yang disentuh bukan sasaran sah"
        }

        if (!state.isBreakShot && foulReason == null && pocketedNumbers.isEmpty() && !result.railAfterContact) {
            foulReason = "Selepas sentuhan, bola mesti masuk poket atau menyentuh rail"
        }

        val eightPocket = result.pocketedBalls.firstOrNull { it.number == 8 }
        if (eightPocket != null && !state.isBreakShot) {
            val cleared = shooterGroup != BallGroup.OPEN && state.remaining(shooterGroup) == 0
            val calledCorrectly = result.calledPocket == eightPocket.pocket
            val legalEight = foulReason == null && cleared && calledCorrectly
            val winner = if (legalEight) shooter else opponent
            val balls = applyPocketedBalls(state.balls, result.pocketedBalls)
            return RuleOutcome(
                state = state.copy(
                    balls = balls,
                    gameOver = true,
                    winner = winner,
                    isBreakShot = false,
                    shotNumber = state.shotNumber + 1,
                    ballInHand = false
                ),
                foul = !legalEight,
                foulReason = if (legalEight) null else foulReason ?: "8-ball dipot sebelum waktunya atau ke poket salah",
                message = if (legalEight) "8-ball sah. Menang." else "8-ball tidak sah. Kalah."
            )
        }

        val eightOnBreak = state.isBreakShot && eightPocket != null
        val filteredPocketed = if (eightOnBreak) result.pocketedBalls.filterNot { it.number == 8 } else result.pocketedBalls
        var balls = applyPocketedBalls(state.balls, filteredPocketed)
        if (eightOnBreak) {
            balls = balls.map { if (it.number == 8) it.copy(pocketed = false, velocity = Vec2.ZERO) else it }
        }

        var humanGroup = state.humanGroup
        var aiGroup = state.aiGroup
        if (!state.isBreakShot && shooterGroup == BallGroup.OPEN && foulReason == null) {
            val assigned = filteredPocketed.asSequence()
                .mapNotNull { state.ball(it.number)?.group }
                .firstOrNull { it == BallGroup.SOLIDS || it == BallGroup.STRIPES }
            if (assigned != null) {
                if (shooter == PlayerSeat.HUMAN) {
                    humanGroup = assigned
                    aiGroup = assigned.oppositeGroup()
                } else {
                    aiGroup = assigned
                    humanGroup = assigned.oppositeGroup()
                }
            }
        }

        val foul = foulReason != null
        val currentAssignedGroup = if (shooter == PlayerSeat.HUMAN) humanGroup else aiGroup
        val legallyPottedOwnBall = filteredPocketed.any { p ->
            val g = state.ball(p.number)?.group ?: BallGroup.OPEN
            when (currentAssignedGroup) {
                BallGroup.OPEN -> g == BallGroup.SOLIDS || g == BallGroup.STRIPES
                else -> g == currentAssignedGroup
            }
        }
        val nextTurn = if (!foul && legallyPottedOwnBall) shooter else opponent

        return RuleOutcome(
            state = state.copy(
                balls = balls,
                turn = nextTurn,
                humanGroup = humanGroup,
                aiGroup = aiGroup,
                isBreakShot = false,
                ballInHand = foul,
                shotNumber = state.shotNumber + 1,
                calledPocket = null
            ),
            foul = foul,
            foulReason = foulReason,
            message = when {
                eightOnBreak -> "8-ball pada break diletak semula."
                foul -> "Foul: $foulReason"
                nextTurn == shooter -> "Pot sah. Teruskan giliran."
                else -> "Giliran bertukar."
            }
        )
    }

    private fun applyPocketedBalls(balls: List<PoolBall>, pocketed: List<PocketedBall>): List<PoolBall> {
        val set = pocketed.map { it.number }.toSet()
        return balls.map { ball ->
            if (ball.number in set) ball.copy(pocketed = true, velocity = Vec2.ZERO) else ball
        }
    }

    private fun PlayerSeat.other() = if (this == PlayerSeat.HUMAN) PlayerSeat.AI else PlayerSeat.HUMAN
    private fun BallGroup.oppositeGroup() = when (this) {
        BallGroup.SOLIDS -> BallGroup.STRIPES
        BallGroup.STRIPES -> BallGroup.SOLIDS
        BallGroup.OPEN -> BallGroup.OPEN
    }
}
