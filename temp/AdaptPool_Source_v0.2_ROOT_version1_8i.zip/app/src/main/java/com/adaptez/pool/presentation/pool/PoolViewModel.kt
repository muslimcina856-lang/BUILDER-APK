package com.adaptez.pool.presentation.pool

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adaptez.pool.data.local.*
import com.adaptez.pool.domain.ai.AdaptivePoolAi
import com.adaptez.pool.domain.engine.PoolPhysics
import com.adaptez.pool.domain.engine.PoolRules
import com.adaptez.pool.domain.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import javax.inject.Inject

enum class MatchPhase { SETUP, READY, BALLS_MOVING, AI_THINKING, RESULT }

data class PoolUiState(
    val game: PoolGameState? = null,
    val phase: MatchPhase = MatchPhase.SETUP,
    val player: PlayerProfileEntity? = null,
    val learning: PlayerLearningProfile = PlayerLearningProfile(),
    val history: List<MatchEntity> = emptyList(),
    val aimDegrees: Double = 0.0,
    val power: Double = 0.58,
    val spinX: Double = 0.0,
    val spinY: Double = 0.0,
    val selectedPocket: Int? = null,
    val humanShots: Int = 0,
    val humanSuccessfulShots: Int = 0,
    val totalShots: Int = 0,
    val statusMessage: String = "Sedia untuk 8-Ball",
    val learningInsights: List<String> = listOf("AI akan belajar daripada setiap pukulan"),
    val collisionPulse: Int = 0,
    val pocketPulse: Int = 0,
    val cuePulse: Int = 0,
    val errorMessage: String? = null
) {
    val currentLevel: Int get() = player?.currentLevel ?: 1
    val isHumanTurn: Boolean get() = game?.turn == PlayerSeat.HUMAN
    val canShoot: Boolean get() = phase == MatchPhase.READY && isHumanTurn && game?.gameOver == false
}

@HiltViewModel
class PoolViewModel @Inject constructor(
    private val dao: PoolDao
) : ViewModel() {
    private val _uiState = MutableStateFlow(PoolUiState())
    val uiState: StateFlow<PoolUiState> = _uiState.asStateFlow()

    private var simulationJob: Job? = null
    private var matchStartedAt = 0L

    init {
        viewModelScope.launch {
            val player = dao.getPlayer() ?: PlayerProfileEntity().also { dao.savePlayer(it) }
            val learningEntity = dao.getLearningProfile() ?: LearningProfileEntity().also { dao.saveLearningProfile(it) }
            _uiState.value = _uiState.value.copy(
                player = player,
                learning = learningEntity.toDomain(),
                learningInsights = AdaptivePoolAi.profileSummary(learningEntity.toDomain())
            )
            dao.observeMatches().collectLatest { matches ->
                _uiState.value = _uiState.value.copy(history = matches)
            }
        }
    }

    fun startMatch() {
        simulationJob?.cancel()
        matchStartedAt = System.currentTimeMillis()
        val game = PoolGameState.playerBreakRack()
        _uiState.value = _uiState.value.copy(
            game = game,
            phase = MatchPhase.READY,
            aimDegrees = 0.0,
            power = 0.72,
            spinX = 0.0,
            spinY = 0.0,
            selectedPocket = null,
            humanShots = 0,
            humanSuccessfulShots = 0,
            totalShots = 0,
            statusMessage = "Giliran kamu • Break",
            learningInsights = AdaptivePoolAi.profileSummary(_uiState.value.learning),
            errorMessage = null
        )
    }

    fun returnToSetup() {
        simulationJob?.cancel()
        _uiState.value = _uiState.value.copy(game = null, phase = MatchPhase.SETUP, statusMessage = "Sedia untuk 8-Ball")
    }

    fun setAimDegrees(value: Double) {
        if (!_uiState.value.canShoot) return
        _uiState.value = _uiState.value.copy(aimDegrees = normalizeDegrees(value))
    }

    fun nudgeAim(delta: Double) = setAimDegrees(_uiState.value.aimDegrees + delta)

    fun setPower(value: Double) {
        if (_uiState.value.phase == MatchPhase.BALLS_MOVING) return
        _uiState.value = _uiState.value.copy(power = value.coerceIn(0.08, 1.0))
    }

    fun setSpin(x: Double, y: Double) {
        if (_uiState.value.phase == MatchPhase.BALLS_MOVING) return
        _uiState.value = _uiState.value.copy(spinX = x.coerceIn(-1.0, 1.0), spinY = y.coerceIn(-1.0, 1.0))
    }

    fun setCueBallPosition(x: Double? = null, y: Double? = null) {
        val state = _uiState.value
        val game = state.game ?: return
        if (!state.canShoot || !game.ballInHand) return
        val cue = game.ball(0) ?: return
        val limitX = PoolGameState.TABLE_HALF_LENGTH - PoolGameState.BALL_RADIUS * 1.2
        val limitY = PoolGameState.TABLE_HALF_WIDTH - PoolGameState.BALL_RADIUS * 1.2
        val candidate = Vec2(
            (x ?: cue.position.x).coerceIn(-limitX, limitX),
            (y ?: cue.position.y).coerceIn(-limitY, limitY)
        )
        val overlaps = game.balls.any { ball ->
            ball.number != 0 && !ball.pocketed && (ball.position - candidate).length() < PoolGameState.BALL_RADIUS * 2.05
        }
        if (overlaps) {
            _uiState.value = state.copy(statusMessage = "Cue ball tidak boleh bertindih dengan bola lain")
            return
        }
        val balls = game.balls.map { if (it.number == 0) it.copy(position = candidate, pocketed = false, velocity = Vec2.ZERO) else it }
        _uiState.value = state.copy(game = game.copy(balls = balls), statusMessage = "Ball-in-hand • pilih posisi dan pukul")
    }

    fun selectPocket(index: Int?) {
        _uiState.value = _uiState.value.copy(selectedPocket = index?.coerceIn(0, 5))
    }

    fun shoot() {
        val state = _uiState.value
        val game = state.game ?: return
        if (!state.canShoot) return
        val requiresCall = game.humanGroup != BallGroup.OPEN && game.remaining(game.humanGroup) == 0
        if (requiresCall && state.selectedPocket == null) {
            _uiState.value = state.copy(statusMessage = "Pilih poket panggilan untuk 8-ball")
            return
        }
        val radians = state.aimDegrees * PI / 180.0
        val direction = Vec2(cos(radians), sin(radians)).normalized()
        val spin = Vec2(state.spinX, state.spinY)
        simulateShot(
            actor = PlayerSeat.HUMAN,
            startState = game,
            direction = direction,
            power = state.power,
            spin = spin,
            calledPocket = state.selectedPocket,
            safetyIntent = state.power < 0.34
        )
    }

    private fun scheduleAiShot(waitMs: Long = 650L) {
        simulationJob = viewModelScope.launch {
            _uiState.value = _uiState.value.copy(phase = MatchPhase.AI_THINKING, statusMessage = "AI sedang membaca meja…")
            delay(waitMs)
            val state = _uiState.value
            val game = state.game ?: return@launch
            if (game.turn != PlayerSeat.AI || game.gameOver) return@launch
            val plan = AdaptivePoolAi.chooseShot(game, state.currentLevel, state.learning)
            simulateShot(
                actor = PlayerSeat.AI,
                startState = game,
                direction = plan.direction,
                power = plan.power,
                spin = plan.spin,
                calledPocket = plan.calledPocket,
                safetyIntent = plan.safetyIntent,
                launchNewJob = false
            )
        }
    }

    private fun simulateShot(
        actor: PlayerSeat,
        startState: PoolGameState,
        direction: Vec2,
        power: Double,
        spin: Vec2,
        calledPocket: Int?,
        safetyIntent: Boolean,
        launchNewJob: Boolean = true
    ) {
        val action: suspend () -> Unit = {
            var balls = PoolPhysics.strike(startState.balls, direction, power, spin)
            var firstContact: Int? = null
            var railAfterContact = false
            val objectRails = linkedSetOf<Int>()
            val pockets = linkedMapOf<Int, PocketedBall>()
            var collisionPulse = _uiState.value.collisionPulse
            var pocketPulse = _uiState.value.pocketPulse

            _uiState.value = _uiState.value.copy(
                game = startState.copy(balls = balls, calledPocket = calledPocket),
                phase = MatchPhase.BALLS_MOVING,
                totalShots = _uiState.value.totalShots + 1,
                humanShots = _uiState.value.humanShots + if (actor == PlayerSeat.HUMAN) 1 else 0,
                statusMessage = if (actor == PlayerSeat.HUMAN) "Pukulan bergerak…" else "AI melakukan pukulan…",
                cuePulse = _uiState.value.cuePulse + 1
            )

            for (renderFrame in 0 until 900) {
                repeat(2) {
                    val frame = PoolPhysics.step(balls)
                    balls = frame.balls
                    if (firstContact == null) {
                        frame.collisions.firstOrNull { (a, b) -> a == 0 || b == 0 }?.let { pair ->
                            firstContact = if (pair.first == 0) pair.second else pair.first
                        }
                    }
                    if (firstContact != null && frame.railContacts.isNotEmpty()) railAfterContact = true
                    objectRails += frame.railContacts.filter { it != 0 }
                    if (frame.collisions.isNotEmpty()) collisionPulse += frame.collisions.size
                    frame.pocketed.forEach { p ->
                        if (p.number !in pockets) {
                            pockets[p.number] = p
                            pocketPulse++
                        }
                    }
                }
                _uiState.value = _uiState.value.copy(
                    game = _uiState.value.game?.copy(balls = balls),
                    collisionPulse = collisionPulse,
                    pocketPulse = pocketPulse
                )
                if (PoolPhysics.isAtRest(balls)) break
                delay(16L)
            }

            balls = balls.map { if (!it.pocketed) it.copy(velocity = Vec2.ZERO) else it }
            val shotResult = ShotResult(
                firstContact = firstContact,
                pocketedBalls = pockets.values.toList(),
                cueBallPocketed = pockets.containsKey(0),
                railAfterContact = railAfterContact,
                objectBallsToRail = objectRails.size,
                calledPocket = calledPocket
            )
            val outcome = PoolRules.evaluateShot(startState, shotResult)
            var resolvedBalls = mergeFinalPositions(outcome.state.balls, balls)
            if (outcome.state.ballInHand) resolvedBalls = PoolPhysics.respotCueBall(resolvedBalls)
            val resolvedGame = outcome.state.copy(balls = resolvedBalls)

            var learning = _uiState.value.learning
            var successfulShots = _uiState.value.humanSuccessfulShots
            if (actor == PlayerSeat.HUMAN) {
                val pottedObject = pockets.keys.any { it in 1..15 }
                if (pottedObject && !outcome.foul) successfulShots++
                learning = AdaptivePoolAi.learn(
                    learning,
                    ShotObservation(
                        power = power,
                        spinMagnitude = spin.length().coerceIn(0.0, 1.0),
                        usedBank = objectRails.isNotEmpty(),
                        safetyIntent = safetyIntent,
                        pottedBall = pottedObject && !outcome.foul
                    )
                )
                dao.saveLearningProfile(learning.toEntity())
            }

            _uiState.value = _uiState.value.copy(
                game = resolvedGame,
                learning = learning,
                humanSuccessfulShots = successfulShots,
                selectedPocket = null,
                phase = when {
                    resolvedGame.gameOver -> MatchPhase.RESULT
                    resolvedGame.turn == PlayerSeat.AI -> MatchPhase.AI_THINKING
                    else -> MatchPhase.READY
                },
                statusMessage = outcome.message,
                learningInsights = AdaptivePoolAi.profileSummary(learning)
            )

            if (resolvedGame.gameOver) {
                finishMatch(resolvedGame.winner == PlayerSeat.HUMAN)
            } else if (resolvedGame.turn == PlayerSeat.AI) {
                scheduleAiShot(700L)
            }
        }

        if (launchNewJob) {
            simulationJob?.cancel()
            simulationJob = viewModelScope.launch { action() }
        } else {
            simulationJob = viewModelScope.launch { action() }
        }
    }

    private suspend fun finishMatch(playerWon: Boolean) {
        val state = _uiState.value
        val oldPlayer = state.player ?: return
        val duration = (System.currentTimeMillis() - matchStartedAt).coerceAtLeast(0L)
        val newStreak = if (playerWon) oldPlayer.currentStreak + 1 else 0
        val levelPlayed = oldPlayer.currentLevel
        val nextLevel = if (playerWon) (levelPlayed + 1).coerceAtMost(999) else levelPlayed
        val updatedPlayer = oldPlayer.copy(
            currentLevel = nextLevel,
            totalMatches = oldPlayer.totalMatches + 1,
            wins = oldPlayer.wins + if (playerWon) 1 else 0,
            losses = oldPlayer.losses + if (playerWon) 0 else 1,
            currentStreak = newStreak,
            bestStreak = maxOf(oldPlayer.bestStreak, newStreak),
            totalPlayTimeMs = oldPlayer.totalPlayTimeMs + duration,
            masteredLevel999 = oldPlayer.masteredLevel999 || (playerWon && levelPlayed == 999),
            updatedAt = System.currentTimeMillis()
        )
        dao.savePlayer(updatedPlayer)
        val game = state.game
        val playerGroup = game?.humanGroup?.name ?: BallGroup.OPEN.name
        val pottedCount = game?.balls?.count { it.number in 1..15 && it.pocketed } ?: 0
        val accuracy = if (state.humanShots == 0) 0.0 else state.humanSuccessfulShots * 100.0 / state.humanShots
        val summary = AdaptivePoolAi.profileSummary(state.learning).joinToString("\n")
        dao.saveMatch(
            MatchEntity(
                result = if (playerWon) "WIN" else "LOSS",
                level = levelPlayed,
                playerGroup = playerGroup,
                totalShots = state.humanShots,
                pottedBalls = pottedCount,
                shotAccuracy = accuracy,
                durationMs = duration,
                learningSummary = summary
            )
        )
        _uiState.value = _uiState.value.copy(
            player = updatedPlayer,
            phase = MatchPhase.RESULT,
            statusMessage = if (playerWon) {
                if (levelPlayed >= 999) "Level 999 dikuasai." else "Level $levelPlayed ditakluki • Level $nextLevel dibuka"
            } else "AI menang pada Level $levelPlayed • Cuba lagi"
        )
    }

    fun nextOrRetry() {
        val state = _uiState.value
        if (state.phase != MatchPhase.RESULT) return
        startMatch()
    }

    private fun mergeFinalPositions(ruleBalls: List<PoolBall>, finalBalls: List<PoolBall>): List<PoolBall> {
        val positions = finalBalls.associateBy { it.number }
        return ruleBalls.map { ball ->
            val final = positions[ball.number]
            if (final == null) ball else ball.copy(position = final.position, velocity = Vec2.ZERO)
        }
    }

    private fun normalizeDegrees(value: Double): Double {
        var result = value % 360.0
        if (result > 180.0) result -= 360.0
        if (result < -180.0) result += 360.0
        return result
    }

    private fun LearningProfileEntity.toDomain() = PlayerLearningProfile(
        aggression = aggression,
        safety = safety,
        averagePower = averagePower,
        spinUsage = spinUsage,
        bankUsage = bankUsage,
        potSuccess = potSuccess,
        samples = samples
    )

    private fun PlayerLearningProfile.toEntity() = LearningProfileEntity(
        aggression = aggression,
        safety = safety,
        averagePower = averagePower,
        spinUsage = spinUsage,
        bankUsage = bankUsage,
        potSuccess = potSuccess,
        samples = samples,
        updatedAt = System.currentTimeMillis()
    )
}
