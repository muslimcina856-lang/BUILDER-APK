package com.adaptez.pool.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PoolDao {
    @Query("SELECT * FROM player_profile WHERE id = 1")
    suspend fun getPlayer(): PlayerProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlayer(player: PlayerProfileEntity)

    @Query("SELECT * FROM learning_profile WHERE id = 1")
    suspend fun getLearningProfile(): LearningProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLearningProfile(profile: LearningProfileEntity)

    @Insert
    suspend fun saveMatch(match: MatchEntity): Long

    @Query("SELECT * FROM matches ORDER BY played_at DESC")
    fun observeMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches ORDER BY played_at DESC LIMIT :limit")
    suspend fun recentMatches(limit: Int): List<MatchEntity>
}
