package com.adaptez.pool.presentation.pool

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.adaptez.pool.domain.model.PoolBall
import com.adaptez.pool.domain.model.PoolGameState
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

internal data class PoolOpenGLScene(
    val balls: List<PoolBall> = emptyList(),
    val aimDegrees: Double = 0.0,
    val showAim: Boolean = false,
    val showCue: Boolean = false
)

internal class PoolOpenGLRenderer : GLSurfaceView.Renderer {
    @Volatile private var scene = PoolOpenGLScene()
    @Volatile private var cameraYaw = 0f
    @Volatile private var cameraPitch = 0.82f
    @Volatile private var viewportWidth = 1
    @Volatile private var viewportHeight = 1

    private var program = 0
    private var positionLocation = -1
    private var normalLocation = -1
    private var mvpLocation = -1
    private var modelLocation = -1
    private var colorLocation = -1
    private var lightLocation = -1
    private var cameraLocation = -1
    private var shininessLocation = -1

    private lateinit var cube: GlMesh
    private lateinit var sphere: GlMesh
    private lateinit var disc: GlMesh
    private lateinit var ring: GlMesh

    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val viewProjection = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    fun updateScene(updated: PoolOpenGLScene) { scene = updated }

    fun orbit(dx: Float, dy: Float) {
        cameraYaw = (cameraYaw - dx * 0.0032f).coerceIn(-0.55f, 0.55f)
        cameraPitch = (cameraPitch - dy * 0.0025f).coerceIn(0.58f, 1.02f)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.025f, 0.032f, 0.036f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        if (program == 0) return
        positionLocation = GLES20.glGetAttribLocation(program, "aPosition")
        normalLocation = GLES20.glGetAttribLocation(program, "aNormal")
        mvpLocation = GLES20.glGetUniformLocation(program, "uMvp")
        modelLocation = GLES20.glGetUniformLocation(program, "uModel")
        colorLocation = GLES20.glGetUniformLocation(program, "uColor")
        lightLocation = GLES20.glGetUniformLocation(program, "uLightPosition")
        cameraLocation = GLES20.glGetUniformLocation(program, "uCameraPosition")
        shininessLocation = GLES20.glGetUniformLocation(program, "uShininess")
        cube = GlMesh(PoolMeshFactory.cube())
        sphere = GlMesh(PoolMeshFactory.sphere())
        disc = GlMesh(PoolMeshFactory.disc())
        ring = GlMesh(PoolMeshFactory.ring())
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width.coerceAtLeast(1)
        viewportHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0,0,viewportWidth,viewportHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (program == 0) return
        val eye = cameraPosition()
        Matrix.setLookAtM(view,0, eye.x,eye.y,eye.z, 0f,0.1f,-0.2f, 0f,1f,0f)
        Matrix.perspectiveM(projection,0,42f,viewportWidth.toFloat()/viewportHeight.toFloat(),0.4f,30f)
        Matrix.multiplyMM(viewProjection,0,projection,0,view,0)
        GLES20.glUseProgram(program)
        GLES20.glUniform3f(lightLocation,-3.6f,8.8f,4.3f)
        GLES20.glUniform3f(cameraLocation,eye.x,eye.y,eye.z)
        drawTable()
        drawBalls()
        if (scene.showAim) drawAimAndCue()
    }

    private fun drawTable() {
        drawCube(0f,-0.12f,0f,4.55f,0.42f,8.45f,WOOD_DARK,34f)
        drawCube(0f,0.10f,0f,4.05f,0.18f,7.92f,FELT,10f)
        drawCube(-2.04f,0.28f,0f,0.24f,0.34f,7.92f,CUSHION,18f)
        drawCube(2.04f,0.28f,0f,0.24f,0.34f,7.92f,CUSHION,18f)
        drawCube(0f,0.28f,-3.96f,4.08f,0.34f,0.24f,CUSHION,18f)
        drawCube(0f,0.28f,3.96f,4.08f,0.34f,0.24f,CUSHION,18f)
        drawCube(-2.27f,-0.30f,0f,0.20f,0.36f,8.48f,WOOD_EDGE,42f)
        drawCube(2.27f,-0.30f,0f,0.20f,0.36f,8.48f,WOOD_EDGE,42f)
        drawCube(0f,-0.30f,-4.20f,4.55f,0.36f,0.20f,WOOD_EDGE,42f)
        drawCube(0f,-0.30f,4.20f,4.55f,0.36f,0.20f,WOOD_EDGE,42f)

        val pockets = arrayOf(
            -2.02f to -3.94f, 0f to -4.02f, 2.02f to -3.94f,
            2.02f to 3.94f, 0f to 4.02f, -2.02f to 3.94f
        )
        GLES20.glDepthMask(false)
        pockets.forEach { (x,z) -> drawFlat(disc,x,0.205f,z,0.26f,POCKET,3f) }
        GLES20.glDepthMask(true)
    }

    private fun drawBalls() {
        val visible = scene.balls.filterNot { it.pocketed }
        GLES20.glDepthMask(false)
        visible.forEach { ball ->
            val (x,z) = world(ball)
            drawFlat(disc,x,0.205f,z,0.145f,SHADOW,1f)
        }
        GLES20.glDepthMask(true)
        visible.sortedBy { world(it).second }.forEach { ball -> drawBall(ball) }
    }

    private fun drawBall(ball: PoolBall) {
        val (x,z) = world(ball)
        val y = 0.405f
        val r = 0.158f
        val color = ballColor(ball.number)
        when {
            ball.number == 0 -> drawSphere(x,y,z,r,r,r,CUE_IVORY,88f)
            ball.number in 9..15 -> {
                drawSphere(x,y,z,r,r,r,STRIPE_WHITE,76f)
                drawSphere(x,y,z,r*1.008f,r*0.56f,r*1.008f,color,84f)
            }
            else -> drawSphere(x,y,z,r,r,r,color,88f)
        }
        if (ball.number != 0) {
            GLES20.glDepthMask(false)
            drawFlat(disc,x,y+r*0.985f,z,0.054f,NUMBER_PATCH,8f)
            if (ball.number == 8) drawFlat(disc,x,y+r*0.992f,z,0.024f,BLACK,8f)
            GLES20.glDepthMask(true)
        }
    }

    private fun drawAimAndCue() {
        val cue = scene.balls.firstOrNull { it.number == 0 && !it.pocketed } ?: return
        val angle = Math.toRadians(scene.aimDegrees)
        val engineDx = cos(angle).toFloat()
        val engineDy = sin(angle).toFloat()
        val worldDx = engineDy
        val worldDz = -engineDx
        val (cx,cz) = world(cue)
        val lineLength = 3.35f
        val targetX = cx + worldDx * lineLength
        val targetZ = cz + worldDz * lineLength
        drawSegment(cx,0.39f,cz,targetX,0.39f,targetZ,0.018f,AIM,4f)
        drawFlat(ring,targetX,0.405f,targetZ,0.11f,AIM_RING,4f)
        if (scene.showCue) {
            val cueLength = 2.40f
            val tipGap = 0.21f
            val farX = cx - worldDx * (cueLength + tipGap)
            val farZ = cz - worldDz * (cueLength + tipGap)
            val nearX = cx - worldDx * tipGap
            val nearZ = cz - worldDz * tipGap
            drawSegment(farX,0.40f,farZ,nearX,0.40f,nearZ,0.052f,CUE_WOOD,46f)
            val tipEndX = cx - worldDx * (tipGap - 0.055f)
            val tipEndZ = cz - worldDz * (tipGap - 0.055f)
            drawSegment(nearX,0.40f,nearZ,tipEndX,0.40f,tipEndZ,0.058f,CUE_BLUE,42f)
        }
    }

    private fun drawSegment(x0:Float,y0:Float,z0:Float,x1:Float,y1:Float,z1:Float,thickness:Float,color:FloatArray,shininess:Float) {
        val dx=x1-x0; val dz=z1-z0
        val len=sqrt(dx*dx+dz*dz).coerceAtLeast(0.001f)
        val angle=(atan2(dx,dz)*180f/PI.toFloat())
        setModel((x0+x1)/2f,(y0+y1)/2f,(z0+z1)/2f,thickness,thickness,len,angle)
        draw(cube,color,shininess)
    }

    private fun drawCube(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,color:FloatArray,shine:Float) {
        setModel(x,y,z,sx,sy,sz,0f); draw(cube,color,shine)
    }
    private fun drawSphere(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,color:FloatArray,shine:Float) {
        setModel(x,y,z,sx,sy,sz,0f); draw(sphere,color,shine)
    }
    private fun drawFlat(mesh:GlMesh,x:Float,y:Float,z:Float,scale:Float,color:FloatArray,shine:Float) {
        setModel(x,y,z,scale,1f,scale,0f); draw(mesh,color,shine)
    }

    private fun setModel(x:Float,y:Float,z:Float,sx:Float,sy:Float,sz:Float,rotationY:Float) {
        Matrix.setIdentityM(model,0)
        Matrix.translateM(model,0,x,y,z)
        if (rotationY != 0f) Matrix.rotateM(model,0,rotationY,0f,1f,0f)
        Matrix.scaleM(model,0,sx,sy,sz)
    }

    private fun draw(mesh:GlMesh,color:FloatArray,shininess:Float) {
        Matrix.multiplyMM(mvp,0,viewProjection,0,model,0)
        GLES20.glUniformMatrix4fv(mvpLocation,1,false,mvp,0)
        GLES20.glUniformMatrix4fv(modelLocation,1,false,model,0)
        GLES20.glUniform4fv(colorLocation,1,color,0)
        GLES20.glUniform1f(shininessLocation,shininess)
        mesh.draw(positionLocation,normalLocation)
    }

    private fun world(ball: PoolBall): Pair<Float,Float> =
        (ball.position.y * WORLD_SCALE).toFloat() to (-ball.position.x * WORLD_SCALE).toFloat()

    private fun cameraPosition(): V3 {
        val radius = 10.6f
        val baseZ = radius * sin(cameraPitch)
        return V3(
            sin(cameraYaw) * 3.0f,
            radius * cos(cameraPitch) + 0.6f,
            baseZ * cos(cameraYaw)
        )
    }

    private fun createProgram(v:String,f:String):Int {
        val vs=compile(GLES20.GL_VERTEX_SHADER,v); val fs=compile(GLES20.GL_FRAGMENT_SHADER,f)
        if(vs==0||fs==0) return 0
        val p=GLES20.glCreateProgram(); GLES20.glAttachShader(p,vs); GLES20.glAttachShader(p,fs); GLES20.glLinkProgram(p)
        val linked=IntArray(1); GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,linked,0)
        if(linked[0]==0){Log.e(TAG,"link: ${GLES20.glGetProgramInfoLog(p)}");GLES20.glDeleteProgram(p);return 0}
        GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs);return p
    }
    private fun compile(type:Int,src:String):Int {
        val s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s)
        val ok=IntArray(1);GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0)
        if(ok[0]==0){Log.e(TAG,"shader: ${GLES20.glGetShaderInfoLog(s)}");GLES20.glDeleteShader(s);return 0};return s
    }

    private class GlMesh(data:PoolMeshData){
        private val vb:FloatBuffer=ByteBuffer.allocateDirect(data.vertices.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(data.vertices);position(0)}
        private val ib:ShortBuffer=ByteBuffer.allocateDirect(data.indices.size*2).order(ByteOrder.nativeOrder()).asShortBuffer().apply{put(data.indices);position(0)}
        private val count=data.indices.size
        fun draw(pos:Int,norm:Int){
            vb.position(0);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,24,vb);GLES20.glEnableVertexAttribArray(pos)
            vb.position(3);GLES20.glVertexAttribPointer(norm,3,GLES20.GL_FLOAT,false,24,vb);GLES20.glEnableVertexAttribArray(norm)
            ib.position(0);GLES20.glDrawElements(GLES20.GL_TRIANGLES,count,GLES20.GL_UNSIGNED_SHORT,ib)
        }
    }

    companion object {
        private const val TAG="AdaptPoolGL"
        private const val WORLD_SCALE=2.60
        private fun c(r:Int,g:Int,b:Int,a:Int=255)=floatArrayOf(r/255f,g/255f,b/255f,a/255f)
        private val FELT=c(19,108,83); private val CUSHION=c(14,75,59); private val WOOD_DARK=c(31,20,14)
        private val WOOD_EDGE=c(86,55,28); private val POCKET=c(3,4,5); private val SHADOW=c(0,0,0,92)
        private val CUE_IVORY=c(239,234,214); private val STRIPE_WHITE=c(235,230,212); private val NUMBER_PATCH=c(244,238,221)
        private val BLACK=c(20,20,21); private val AIM=c(216,180,119,188); private val AIM_RING=c(118,200,165,205)
        private val CUE_WOOD=c(184,124,62); private val CUE_BLUE=c(45,95,110)
        private val BALL_COLORS=arrayOf(
            c(238,220,186), c(231,188,48), c(43,90,166), c(190,58,51), c(101,62,139), c(219,120,42), c(54,132,73), c(128,47,46), c(22,22,24),
            c(231,188,48), c(43,90,166), c(190,58,51), c(101,62,139), c(219,120,42), c(54,132,73), c(128,47,46)
        )
        private fun ballColor(number:Int)=BALL_COLORS[number.coerceIn(0,15)]
        private const val VERTEX_SHADER="""
            uniform mat4 uMvp; uniform mat4 uModel; attribute vec3 aPosition; attribute vec3 aNormal;
            varying vec3 vWorldPosition; varying vec3 vNormal;
            void main(){vec4 w=uModel*vec4(aPosition,1.0);vWorldPosition=w.xyz;vNormal=normalize(mat3(uModel)*aNormal);gl_Position=uMvp*vec4(aPosition,1.0);}
        """
        private const val FRAGMENT_SHADER="""
            precision mediump float; uniform vec4 uColor; uniform vec3 uLightPosition; uniform vec3 uCameraPosition; uniform float uShininess;
            varying vec3 vWorldPosition; varying vec3 vNormal;
            void main(){vec3 n=normalize(vNormal);vec3 l=normalize(uLightPosition-vWorldPosition);vec3 v=normalize(uCameraPosition-vWorldPosition);vec3 h=normalize(l+v);
            float d=max(dot(n,l),0.0);float s=pow(max(dot(n,h),0.0),uShininess);float rim=pow(1.0-max(dot(n,v),0.0),2.0);
            float light=0.25+d*0.75;vec3 rgb=uColor.rgb*light+vec3(s*0.52)+uColor.rgb*rim*0.13;gl_FragColor=vec4(rgb,uColor.a);}
        """
    }
}

private data class V3(val x:Float,val y:Float,val z:Float)
