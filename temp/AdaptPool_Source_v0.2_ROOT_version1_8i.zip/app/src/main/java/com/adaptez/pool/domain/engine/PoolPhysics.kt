package com.adaptez.pool.domain.engine

import com.adaptez.pool.domain.model.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

object PoolPhysics {
    const val FIXED_STEP_SECONDS = 1.0 / 120.0
    private const val BALL_RESTITUTION = 0.94
    private const val CUSHION_RESTITUTION = 0.82
    private const val ROLLING_DECELERATION = 0.34
    private const val STOP_SPEED = 0.012
    private const val POCKET_RADIUS = 0.066

    data class FrameResult(
        val balls: List<PoolBall>,
        val pocketed: List<PocketedBall>,
        val railContacts: Set<Int>,
        val collisions: List<Pair<Int, Int>>
    )

    fun strike(balls: List<PoolBall>, direction: Vec2, power: Double, spin: Vec2 = Vec2.ZERO): List<PoolBall> {
        val speed = 0.35 + power.coerceIn(0.0, 1.0) * 3.9
        return balls.map { ball ->
            if (ball.number == 0 && !ball.pocketed) ball.copy(
                velocity = direction.normalized() * speed,
                angularVelocity = spin * (speed * 1.8)
            ) else ball
        }
    }

    fun step(input: List<PoolBall>, dt: Double = FIXED_STEP_SECONDS): FrameResult {
        val balls = input.map { it.copy() }.toMutableList()
        val pocketed = mutableListOf<PocketedBall>()
        val rails = mutableSetOf<Int>()
        val collisions = mutableListOf<Pair<Int, Int>>()

        for (i in balls.indices) {
            val b = balls[i]
            if (b.pocketed) continue
            var v = b.velocity
            val speed = v.length()
            if (speed > 0.0) {
                val nextSpeed = max(0.0, speed - ROLLING_DECELERATION * dt)
                v = if (nextSpeed <= STOP_SPEED) Vec2.ZERO else v.normalized() * nextSpeed
            }
            var p = b.position + v * dt
            var railHit = false
            val xLimit = PoolGameState.TABLE_HALF_LENGTH - PoolGameState.BALL_RADIUS
            val yLimit = PoolGameState.TABLE_HALF_WIDTH - PoolGameState.BALL_RADIUS
            if (abs(p.x) > xLimit) {
                p = p.copy(x = p.x.coerceIn(-xLimit, xLimit))
                v = v.copy(
                    x = -v.x * CUSHION_RESTITUTION,
                    y = v.y + if (b.number == 0) b.angularVelocity.x * 0.010 else 0.0
                )
                railHit = true
            }
            if (abs(p.y) > yLimit) {
                p = p.copy(y = p.y.coerceIn(-yLimit, yLimit))
                v = v.copy(
                    x = v.x - if (b.number == 0) b.angularVelocity.x * 0.010 else 0.0,
                    y = -v.y * CUSHION_RESTITUTION
                )
                railHit = true
            }
            if (railHit) rails += b.number
            balls[i] = b.copy(
                position = p,
                velocity = v,
                angularVelocity = b.angularVelocity * 0.992
            )
        }

        val minDistance = PoolGameState.BALL_RADIUS * 2.0
        for (i in 0 until balls.size) for (j in i + 1 until balls.size) {
            var a = balls[i]; var b = balls[j]
            if (a.pocketed || b.pocketed) continue
            val delta = b.position - a.position
            val distance = delta.length()
            if (distance <= 1e-9 || distance >= minDistance) continue
            val n = delta / distance
            val overlap = minDistance - distance
            a = a.copy(position = a.position - n * (overlap * 0.5))
            b = b.copy(position = b.position + n * (overlap * 0.5))
            val relative = (b.velocity - a.velocity).dot(n)
            if (relative < 0.0) {
                val impulse = -(1.0 + BALL_RESTITUTION) * relative / 2.0
                a = a.copy(velocity = a.velocity - n * impulse)
                b = b.copy(velocity = b.velocity + n * impulse)

                // Approximate cue-ball follow/draw and side English after impact.
                // spin.x = left/right English; spin.y = follow/draw.
                val tangent = Vec2(-n.y, n.x)
                if (a.number == 0) {
                    a = a.copy(velocity = a.velocity + n * (a.angularVelocity.y * 0.040) + tangent * (a.angularVelocity.x * 0.018))
                }
                if (b.number == 0) {
                    b = b.copy(velocity = b.velocity - n * (b.angularVelocity.y * 0.040) - tangent * (b.angularVelocity.x * 0.018))
                }
            }
            balls[i] = a; balls[j] = b
            collisions += a.number to b.number
        }

        val pockets = pocketCenters()
        for (i in balls.indices) {
            val b = balls[i]
            if (b.pocketed) continue
            val pocketIndex = pockets.indices.firstOrNull { (b.position - pockets[it]).length() <= POCKET_RADIUS }
            if (pocketIndex != null) {
                balls[i] = b.copy(pocketed = true, velocity = Vec2.ZERO, angularVelocity = Vec2.ZERO)
                pocketed += PocketedBall(b.number, pocketIndex)
            }
        }
        return FrameResult(balls, pocketed, rails, collisions)
    }

    fun isAtRest(balls: List<PoolBall>): Boolean = balls.all { it.pocketed || it.velocity.length() <= STOP_SPEED }

    fun respotCueBall(balls: List<PoolBall>, position: Vec2 = Vec2(-0.72, 0.0)): List<PoolBall> = balls.map {
        if (it.number == 0) it.copy(position = position, velocity = Vec2.ZERO, pocketed = false) else it
    }

    private fun pocketCenters() = listOf(
        Vec2(-PoolGameState.TABLE_HALF_LENGTH, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(0.0, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(PoolGameState.TABLE_HALF_LENGTH, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(PoolGameState.TABLE_HALF_LENGTH, PoolGameState.TABLE_HALF_WIDTH),
        Vec2(0.0, PoolGameState.TABLE_HALF_WIDTH),
        Vec2(-PoolGameState.TABLE_HALF_LENGTH, PoolGameState.TABLE_HALF_WIDTH)
    )
}
