package com.adaptez.pool.presentation.pool

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent

internal class PoolOpenGLSurfaceView(context: Context) : GLSurfaceView(context) {
    private val poolRenderer = PoolOpenGLRenderer()
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8,8,8,8,24,0)
        setRenderer(poolRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        preserveEGLContextOnPause = true
    }

    fun updateScene(scene: PoolOpenGLScene) {
        queueEvent { poolRenderer.updateScene(scene) }
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when(event.actionMasked){
            MotionEvent.ACTION_DOWN -> { lastX=event.x; lastY=event.y; dragging=true; return true }
            MotionEvent.ACTION_MOVE -> if(dragging){
                val dx=event.x-lastX; val dy=event.y-lastY; lastX=event.x; lastY=event.y
                queueEvent { poolRenderer.orbit(dx,dy) }; requestRender(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging=false; return true }
        }
        return super.onTouchEvent(event)
    }
}
