package com.adaptez.pool.domain.ai

import com.adaptez.pool.domain.model.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

object AdaptivePoolAi {
    fun learn(profile: PlayerLearningProfile, observation: ShotObservation): PlayerLearningProfile {
        val nextSamples = profile.samples + 1
        val alpha = if (profile.samples < 8) 0.24 else 0.12
        val aggressiveSignal = when {
            observation.safetyIntent -> 0.08
            observation.power >= 0.72 -> 0.95
            else -> 0.56
        }
        val safetySignal = if (observation.safetyIntent) 1.0 else 0.12
        val spinSignal = if (observation.spinMagnitude >= 0.12) 1.0 else 0.0
        val bankSignal = if (observation.usedBank) 1.0 else 0.0
        val potSignal = if (observation.pottedBall) 1.0 else 0.0
        return profile.copy(
            aggression = ema(profile.aggression, aggressiveSignal, alpha),
            safety = ema(profile.safety, safetySignal, alpha),
            averagePower = ema(profile.averagePower, observation.power.coerceIn(0.0, 1.0), alpha),
            spinUsage = ema(profile.spinUsage, spinSignal, alpha),
            bankUsage = ema(profile.bankUsage, bankSignal, alpha),
            potSuccess = ema(profile.potSuccess, potSignal, alpha),
            samples = nextSamples
        )
    }

    fun parametersFor(level: Int, profile: PlayerLearningProfile): AiParameters {
        val l = level.coerceIn(1, 999)
        val mastery = (l - 1) / 998.0
        val aimError = lerp(6.8, 0.12, mastery)
        val powerError = lerp(0.18, 0.006, mastery)
        val baseAggression = lerp(0.38, 0.86, mastery)
        val counterSafety = (profile.aggression - 0.5).coerceIn(-0.5, 0.5) * 0.42
        val counterAggression = (profile.safety - 0.5).coerceIn(-0.5, 0.5) * 0.20
        return AiParameters(
            aimErrorDegrees = aimError,
            powerErrorFraction = powerError,
            aggression = (baseAggression + counterAggression).coerceIn(0.15, 0.96),
            safetyBias = (lerp(0.25, 0.66, mastery) + counterSafety).coerceIn(0.08, 0.94),
            spinConfidence = lerp(0.10, 0.97, mastery),
            planningSamples = (12 + mastery * 380).toInt()
        )
    }

    fun chooseShot(
        state: PoolGameState,
        level: Int,
        profile: PlayerLearningProfile,
        random: Random = Random.Default
    ): PlannedShot {
        val params = parametersFor(level, profile)
        val cue = state.ball(0)?.takeUnless { it.pocketed }
            ?: return PlannedShot(Vec2(1.0, 0.0), 0.4)
        val group = state.groupFor(PlayerSeat.AI)
        val targets = state.balls.filter { ball ->
            !ball.pocketed && ball.number != 0 && when (group) {
                BallGroup.OPEN -> ball.number != 8
                BallGroup.SOLIDS, BallGroup.STRIPES ->
                    if (state.remaining(group) == 0) ball.number == 8 else ball.group == group
            }
        }
        if (targets.isEmpty()) return PlannedShot(Vec2(1.0, 0.0), 0.35)

        val pockets = pocketCenters()
        val options = buildList {
            targets.forEach { target -> pockets.indices.forEach { pocketIndex -> add(target to pocketIndex) } }
        }.shuffled(random)
        val budget = (6 + params.planningSamples / 7).coerceIn(6, options.size)
        var best: Candidate? = null

        for ((target, pocketIndex) in options.take(budget)) {
            val pocket = pockets[pocketIndex]
            val targetToPocket = (pocket - target.position).normalized()
            val ghost = target.position - targetToPocket * (PoolGameState.BALL_RADIUS * 2.03)
            if (!insidePlayableArea(ghost)) continue

            val cuePathClear = pathClear(
                cue.position,
                ghost,
                state.balls,
                ignored = setOf(0, target.number),
                clearance = PoolGameState.BALL_RADIUS * 2.08
            )
            if (!cuePathClear) continue

            val objectPathClear = pathClear(
                target.position,
                pocket,
                state.balls,
                ignored = setOf(target.number),
                clearance = PoolGameState.BALL_RADIUS * 1.92
            )
            if (!objectPathClear) continue

            val cueDirection = (ghost - cue.position).normalized()
            val objectDirection = (pocket - target.position).normalized()
            val cutQuality = cueDirection.dot(objectDirection).coerceIn(-1.0, 1.0)
            // Very thin cuts are possible but less attractive, especially at low levels.
            val angleQuality = ((cutQuality + 1.0) * 0.5).coerceIn(0.0, 1.0)
            val cueDistance = (ghost - cue.position).length()
            val objectDistance = (pocket - target.position).length()
            val centerPocketBonus = if (pocketIndex == 1 || pocketIndex == 4) 0.06 else 0.0
            val score = angleQuality * 3.2 - cueDistance * 0.46 - objectDistance * 0.30 + centerPocketBonus
            val candidate = Candidate(target, pocketIndex, ghost, score, cueDistance + objectDistance)
            if (best == null || candidate.score > best.score) best = candidate
        }

        val chosen = best
        if (chosen == null) {
            // No clean pot found within the current search budget: play a controlled safety/contact shot.
            val target = targets.minByOrNull { (it.position - cue.position).length() } ?: targets.first()
            var direction = (target.position - cue.position).normalized()
            val errorRad = Math.toRadians(params.aimErrorDegrees * random.nextDouble(-1.0, 1.0))
            direction = rotate(direction, errorRad)
            val safetyPower = (0.26 + params.aggression * 0.16).coerceIn(0.22, 0.48)
            return PlannedShot(
                direction = direction,
                power = safetyPower,
                spin = if (params.spinConfidence > 0.70) Vec2(random.nextDouble(-0.25, 0.25), -0.22) else Vec2.ZERO,
                safetyIntent = true
            )
        }

        var direction = (chosen.ghost - cue.position).normalized()
        val errorRad = Math.toRadians(params.aimErrorDegrees * random.nextDouble(-1.0, 1.0))
        direction = rotate(direction, errorRad)
        val nominalPower = (0.28 + chosen.travelDistance / 4.6).coerceIn(0.26, 0.92)
        val power = (nominalPower * (1.0 + params.powerErrorFraction * random.nextDouble(-1.0, 1.0)))
            .coerceIn(0.20, 1.0)

        // A defensive AI may deliberately choose a lower-speed shot when the candidate is marginal.
        val safetyIntent = chosen.score < 0.45 && random.nextDouble() < params.safetyBias * 0.55
        val finalPower = if (safetyIntent) power.coerceAtMost(0.46) else power
        val spin = if (params.spinConfidence > 0.55 && !safetyIntent) {
            // Mild follow/draw variation for cue-ball position rather than impossible perfect spin.
            Vec2(
                random.nextDouble(-0.20, 0.20) * params.spinConfidence,
                random.nextDouble(-0.30, 0.35) * params.spinConfidence
            )
        } else Vec2.ZERO

        return PlannedShot(
            direction = direction,
            power = finalPower,
            spin = spin,
            calledPocket = if (chosen.target.number == 8) chosen.pocketIndex else null,
            safetyIntent = safetyIntent
        )
    }

    private data class Candidate(
        val target: PoolBall,
        val pocketIndex: Int,
        val ghost: Vec2,
        val score: Double,
        val travelDistance: Double
    )

    private fun insidePlayableArea(point: Vec2): Boolean =
        kotlin.math.abs(point.x) < PoolGameState.TABLE_HALF_LENGTH - PoolGameState.BALL_RADIUS &&
            kotlin.math.abs(point.y) < PoolGameState.TABLE_HALF_WIDTH - PoolGameState.BALL_RADIUS

    private fun pathClear(
        start: Vec2,
        end: Vec2,
        balls: List<PoolBall>,
        ignored: Set<Int>,
        clearance: Double
    ): Boolean {
        val segment = end - start
        val lengthSquared = segment.dot(segment)
        if (lengthSquared <= 1e-10) return false
        return balls.asSequence()
            .filter { !it.pocketed && it.number !in ignored }
            .all { ball ->
                val t = ((ball.position - start).dot(segment) / lengthSquared).coerceIn(0.0, 1.0)
                val closest = start + segment * t
                (ball.position - closest).length() >= clearance
            }
    }

    fun profileSummary(profile: PlayerLearningProfile): List<String> {
        if (profile.samples < 3) return listOf("AI sedang mengumpul data gaya pukulan kamu")
        val result = mutableListOf<String>()
        if (profile.aggression >= 0.66) result += "Kamu cenderung menyerang dan menggunakan kuasa tinggi"
        if (profile.safety >= 0.58) result += "Kamu kerap memilih safety apabila laluan pot sukar"
        if (profile.spinUsage >= 0.42) result += "Kamu banyak menggunakan spin untuk kawalan cue ball"
        if (profile.bankUsage >= 0.30) result += "AI mengesan kecenderungan bank shot"
        if (profile.potSuccess >= 0.65) result += "Ketepatan pot kamu konsisten"
        return result.take(3).ifEmpty { listOf("Gaya kamu seimbang dan sukar diramal") }
    }

    private fun pocketCenters() = listOf(
        Vec2(-PoolGameState.TABLE_HALF_LENGTH, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(0.0, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(PoolGameState.TABLE_HALF_LENGTH, -PoolGameState.TABLE_HALF_WIDTH),
        Vec2(PoolGameState.TABLE_HALF_LENGTH, PoolGameState.TABLE_HALF_WIDTH),
        Vec2(0.0, PoolGameState.TABLE_HALF_WIDTH),
        Vec2(-PoolGameState.TABLE_HALF_LENGTH, PoolGameState.TABLE_HALF_WIDTH)
    )

    private fun rotate(v: Vec2, radians: Double): Vec2 {
        val c = cos(radians); val s = sin(radians)
        return Vec2(v.x * c - v.y * s, v.x * s + v.y * c).normalized()
    }

    private fun ema(current: Double, sample: Double, alpha: Double) = current + (sample - current) * alpha
    private fun lerp(a: Double, b: Double, t: Double) = a + (b - a) * t
}
