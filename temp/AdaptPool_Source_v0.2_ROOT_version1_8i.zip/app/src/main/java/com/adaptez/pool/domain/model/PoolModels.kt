package com.adaptez.pool.domain.model

import kotlin.math.hypot

data class Vec2(val x: Double, val y: Double) {
    operator fun plus(other: Vec2) = Vec2(x + other.x, y + other.y)
    operator fun minus(other: Vec2) = Vec2(x - other.x, y - other.y)
    operator fun times(scale: Double) = Vec2(x * scale, y * scale)
    operator fun div(scale: Double) = Vec2(x / scale, y / scale)
    fun length(): Double = hypot(x, y)
    fun normalized(): Vec2 = length().takeIf { it > 1e-9 }?.let { this / it } ?: ZERO
    fun dot(other: Vec2): Double = x * other.x + y * other.y
    companion object { val ZERO = Vec2(0.0, 0.0) }
}

enum class BallGroup { OPEN, SOLIDS, STRIPES }
enum class PlayerSeat { HUMAN, AI }

data class PoolBall(
    val number: Int,
    val position: Vec2,
    val velocity: Vec2 = Vec2.ZERO,
    val angularVelocity: Vec2 = Vec2.ZERO,
    val pocketed: Boolean = false
) {
    val group: BallGroup
        get() = when (number) {
            in 1..7 -> BallGroup.SOLIDS
            in 9..15 -> BallGroup.STRIPES
            else -> BallGroup.OPEN
        }
}

data class PoolGameState(
    val balls: List<PoolBall>,
    val turn: PlayerSeat = PlayerSeat.HUMAN,
    val humanGroup: BallGroup = BallGroup.OPEN,
    val aiGroup: BallGroup = BallGroup.OPEN,
    val isBreakShot: Boolean = true,
    val ballInHand: Boolean = false,
    val shotNumber: Int = 0,
    val calledPocket: Int? = null,
    val gameOver: Boolean = false,
    val winner: PlayerSeat? = null
) {
    fun groupFor(player: PlayerSeat): BallGroup = if (player == PlayerSeat.HUMAN) humanGroup else aiGroup
    fun remaining(group: BallGroup): Int = balls.count { !it.pocketed && it.group == group }
    fun ball(number: Int): PoolBall? = balls.firstOrNull { it.number == number }

    companion object {
        const val TABLE_HALF_LENGTH = 1.42
        const val TABLE_HALF_WIDTH = 0.71
        const val BALL_RADIUS = 0.028575

        fun playerBreakRack(): PoolGameState = standardRack().copy(
            turn = PlayerSeat.HUMAN,
            isBreakShot = true,
            ballInHand = false,
            shotNumber = 0,
            calledPocket = null,
            gameOver = false,
            winner = null
        )

        fun standardRack(): PoolGameState {
            val cue = PoolBall(0, Vec2(-0.72, 0.0))
            val rackNumbers = listOf(1, 9, 2, 10, 8, 3, 4, 11, 12, 5, 13, 6, 14, 7, 15)
            val balls = mutableListOf(cue)
            val startX = 0.72
            val rowGap = BALL_RADIUS * 1.74
            var index = 0
            for (row in 0 until 5) {
                val x = startX + row * rowGap
                for (slot in 0..row) {
                    val y = (slot - row / 2.0) * BALL_RADIUS * 2.03
                    balls += PoolBall(rackNumbers[index++], Vec2(x, y))
                }
            }
            return PoolGameState(balls = balls)
        }
    }
}

data class PocketedBall(val number: Int, val pocket: Int)

data class ShotResult(
    val firstContact: Int? = null,
    val pocketedBalls: List<PocketedBall> = emptyList(),
    val cueBallPocketed: Boolean = false,
    val railAfterContact: Boolean = false,
    val objectBallsToRail: Int = 0,
    val calledPocket: Int? = null
)

data class RuleOutcome(
    val state: PoolGameState,
    val foul: Boolean,
    val foulReason: String? = null,
    val message: String = ""
)

data class ShotObservation(
    val power: Double,
    val spinMagnitude: Double,
    val usedBank: Boolean,
    val safetyIntent: Boolean,
    val pottedBall: Boolean
)

data class PlayerLearningProfile(
    val aggression: Double = 0.5,
    val safety: Double = 0.5,
    val averagePower: Double = 0.5,
    val spinUsage: Double = 0.0,
    val bankUsage: Double = 0.0,
    val potSuccess: Double = 0.5,
    val samples: Int = 0
)

data class AiParameters(
    val aimErrorDegrees: Double,
    val powerErrorFraction: Double,
    val aggression: Double,
    val safetyBias: Double,
    val spinConfidence: Double,
    val planningSamples: Int
)

data class PlannedShot(
    val direction: Vec2,
    val power: Double,
    val spin: Vec2 = Vec2.ZERO,
    val calledPocket: Int? = null,
    val safetyIntent: Boolean = false
)
