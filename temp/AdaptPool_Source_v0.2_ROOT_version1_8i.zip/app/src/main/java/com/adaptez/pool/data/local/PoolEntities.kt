package com.adaptez.pool.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: Long = 1L,
    val username: String = "Player",
    @ColumnInfo(name = "current_level") val currentLevel: Int = 1,
    @ColumnInfo(name = "total_matches") val totalMatches: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    @ColumnInfo(name = "current_streak") val currentStreak: Int = 0,
    @ColumnInfo(name = "best_streak") val bestStreak: Int = 0,
    @ColumnInfo(name = "total_play_time_ms") val totalPlayTimeMs: Long = 0L,
    @ColumnInfo(name = "mastered_level_999") val masteredLevel999: Boolean = false,
    @ColumnInfo(name = "updated_at") val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val result: String,
    val level: Int,
    @ColumnInfo(name = "player_group") val playerGroup: String,
    @ColumnInfo(name = "total_shots") val totalShots: Int,
    @ColumnInfo(name = "potted_balls") val pottedBalls: Int,
    @ColumnInfo(name = "shot_accuracy") val shotAccuracy: Double,
    @ColumnInfo(name = "duration_ms") val durationMs: Long,
    @ColumnInfo(name = "learning_summary") val learningSummary: String,
    @ColumnInfo(name = "played_at") val playedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "learning_profile")
data class LearningProfileEntity(
    @PrimaryKey val id: Long = 1L,
    val aggression: Double = 0.5,
    val safety: Double = 0.5,
    @ColumnInfo(name = "average_power") val averagePower: Double = 0.5,
    @ColumnInfo(name = "spin_usage") val spinUsage: Double = 0.0,
    @ColumnInfo(name = "bank_usage") val bankUsage: Double = 0.0,
    @ColumnInfo(name = "pot_success") val potSuccess: Double = 0.5,
    val samples: Int = 0,
    @ColumnInfo(name = "updated_at") val updatedAt: Long = System.currentTimeMillis()
)
