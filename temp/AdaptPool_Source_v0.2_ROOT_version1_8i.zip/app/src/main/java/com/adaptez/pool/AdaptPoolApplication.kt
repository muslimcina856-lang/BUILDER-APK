package com.adaptez.pool

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AdaptPoolApplication : Application()
