package com.adaptez.pool.di

import android.app.Application
import com.adaptez.pool.data.local.PoolDao
import com.adaptez.pool.data.local.PoolDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun provideDatabase(application: Application): PoolDatabase = PoolDatabase.create(application)

    @Provides
    fun providePoolDao(database: PoolDatabase): PoolDao = database.poolDao()
}
