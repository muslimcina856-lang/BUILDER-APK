package com.adaptez.pool.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFD8B477),
    onPrimary = Color(0xFF21180A),
    primaryContainer = Color(0xFF44351F),
    secondary = Color(0xFF76C8A5),
    background = Color(0xFF0D0F12),
    surface = Color(0xFF171A1F),
    onBackground = Color(0xFFF3EEE4),
    onSurface = Color(0xFFF3EEE4),
    error = Color(0xFFE07171),
    outline = Color(0xFF34383F)
)

@Composable
fun AdaptPoolTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColorScheme, content = content)
}
