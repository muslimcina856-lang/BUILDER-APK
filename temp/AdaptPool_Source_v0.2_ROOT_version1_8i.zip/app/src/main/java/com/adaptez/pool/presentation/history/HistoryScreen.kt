package com.adaptez.pool.presentation.history

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adaptez.pool.data.local.MatchEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(games: List<MatchEntity>, modifier: Modifier = Modifier) {
    var selected by remember { mutableStateOf<MatchEntity?>(null) }
    selected?.let { MatchDialog(it) { selected = null } }

    Column(
        modifier = modifier.fillMaxSize().background(Color(0xFF0D0F12)).padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(22.dp))
        Text("Sejarah Permainan", color = Color(0xFFF3EEE4), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Lihat bagaimana lawan adaptif berkembang daripada pukulan kamu.", color = Color(0xFFA6A39C), fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))

        if (games.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada perlawanan direkodkan.", color = Color(0xFFA6A39C))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(games, key = { it.id }) { game -> HistoryCard(game) { selected = game } }
                item { Spacer(Modifier.height(12.dp)) }
            }
        }
    }
}

@Composable
private fun HistoryCard(game: MatchEntity, onClick: () -> Unit) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault()) }
    val win = game.result == "WIN"
    val color = if (win) Color(0xFF76C8A5) else Color(0xFFE07171)
    Surface(modifier = Modifier.clickable(onClick = onClick), color = Color(0xFF171A1F), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(color.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) { Text(if (win) "W" else "L", color = color, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (win) "MENANG" else "KALAH", color = color, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    game.learningSummary.lineSequence().firstOrNull().orEmpty().ifBlank { "8-Ball standard" },
                    color = Color(0xFFF3EEE4), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1
                )
                Text(dateFormat.format(Date(game.playedAt)), color = Color(0xFF858681), fontSize = 10.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Lv ${game.level}", color = Color(0xFFD8B477), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("${game.totalShots} pukulan", color = Color(0xFF858681), fontSize = 10.sp)
                Text("${game.shotAccuracy.toInt()}% tepat", color = Color(0xFF858681), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun MatchDialog(game: MatchEntity, onDismiss: () -> Unit) {
    val win = game.result == "WIN"
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF171A1F),
        titleContentColor = Color(0xFFF3EEE4),
        textContentColor = Color(0xFFA6A39C),
        title = { Text("Analisis Perlawanan", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(color = Color(0xFFD8B477).copy(alpha = 0.10f), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("${if (win) "Menang" else "Kalah"} • Level ${game.level}", color = Color(0xFFD8B477), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("${game.playerGroup.lowercase().replaceFirstChar { it.uppercase() }} • ${game.totalShots} pukulan • ${game.pottedBalls} bola dipot", fontSize = 11.sp)
                        Text("Ketepatan pukulan ${"%.1f".format(game.shotAccuracy)}% • ${formatDuration(game.durationMs)}", fontSize = 11.sp)
                    }
                }
                Text("APA YANG AI PELAJARI", color = Color(0xFF76C8A5), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.7.sp)
                game.learningSummary.lineSequence().filter { it.isNotBlank() }.forEach {
                    Text("• $it", color = Color(0xFFF3EEE4).copy(alpha = 0.88f), fontSize = 11.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFFD8B477), fontWeight = FontWeight.Bold) } }
    )
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%02d:%02d".format(minutes, seconds)
}
