package com.adaptez.pool.domain

import com.adaptez.pool.domain.engine.PoolRules
import com.adaptez.pool.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class PoolRulesTest {
    private fun state(
        turn: PlayerSeat = PlayerSeat.HUMAN,
        humanGroup: BallGroup = BallGroup.OPEN,
        aiGroup: BallGroup = BallGroup.OPEN,
        pocketed: Set<Int> = emptySet(),
        breakShot: Boolean = false
    ): PoolGameState = PoolGameState.standardRack().copy(
        turn = turn,
        humanGroup = humanGroup,
        aiGroup = aiGroup,
        balls = PoolGameState.standardRack().balls.map { it.copy(pocketed = it.number in pocketed) },
        isBreakShot = breakShot
    )

    @Test fun `legal open-table pot assigns solids`() {
        val outcome = PoolRules.evaluateShot(
            state(),
            ShotResult(firstContact = 1, pocketedBalls = listOf(PocketedBall(1, 0)), railAfterContact = true)
        )
        assertFalse(outcome.foul)
        assertEquals(BallGroup.SOLIDS, outcome.state.humanGroup)
        assertEquals(BallGroup.STRIPES, outcome.state.aiGroup)
        assertEquals(PlayerSeat.HUMAN, outcome.state.turn)
    }

    @Test fun `wrong first contact is foul after groups assigned`() {
        val outcome = PoolRules.evaluateShot(
            state(humanGroup = BallGroup.SOLIDS, aiGroup = BallGroup.STRIPES),
            ShotResult(firstContact = 10, railAfterContact = true)
        )
        assertTrue(outcome.foul)
        assertEquals(PlayerSeat.AI, outcome.state.turn)
        assertTrue(outcome.state.ballInHand)
    }

    @Test fun `early eight ball loses the rack`() {
        val outcome = PoolRules.evaluateShot(
            state(humanGroup = BallGroup.SOLIDS, aiGroup = BallGroup.STRIPES),
            ShotResult(firstContact = 1, pocketedBalls = listOf(PocketedBall(8, 2)), railAfterContact = true)
        )
        assertTrue(outcome.state.gameOver)
        assertEquals(PlayerSeat.AI, outcome.state.winner)
    }

    @Test fun `eight ball after clearing group wins`() {
        val solidsPocketed = (1..7).toSet()
        val outcome = PoolRules.evaluateShot(
            state(humanGroup = BallGroup.SOLIDS, aiGroup = BallGroup.STRIPES, pocketed = solidsPocketed),
            ShotResult(firstContact = 8, pocketedBalls = listOf(PocketedBall(8, 3)), railAfterContact = true, calledPocket = 3)
        )
        assertFalse(outcome.foul)
        assertTrue(outcome.state.gameOver)
        assertEquals(PlayerSeat.HUMAN, outcome.state.winner)
    }

    @Test fun `dry illegal break gives ball in hand`() {
        val outcome = PoolRules.evaluateShot(
            state(breakShot = true),
            ShotResult(firstContact = 1, railAfterContact = false, objectBallsToRail = 2)
        )
        assertTrue(outcome.foul)
        assertTrue(outcome.state.ballInHand)
        assertEquals(PlayerSeat.AI, outcome.state.turn)
    }
}
