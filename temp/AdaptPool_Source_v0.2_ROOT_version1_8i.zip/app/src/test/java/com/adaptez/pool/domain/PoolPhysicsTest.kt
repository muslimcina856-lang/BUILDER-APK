package com.adaptez.pool.domain

import com.adaptez.pool.domain.engine.PoolPhysics
import com.adaptez.pool.domain.model.PoolBall
import com.adaptez.pool.domain.model.Vec2
import org.junit.Assert.*
import org.junit.Test

class PoolPhysicsTest {
    @Test fun `head-on collision transfers velocity without creating energy`() {
        val r = 0.028575
        var balls = listOf(
            PoolBall(0, Vec2(0.0, 0.0), velocity = Vec2(1.0, 0.0)),
            PoolBall(1, Vec2(r * 1.95, 0.0), velocity = Vec2.ZERO)
        )
        val before = balls.sumOf { it.velocity.dot(it.velocity) }
        val frame = PoolPhysics.step(balls)
        val after = frame.balls.sumOf { it.velocity.dot(it.velocity) }
        assertTrue(frame.collisions.isNotEmpty())
        assertTrue(frame.balls.first { it.number == 1 }.velocity.x > 0.0)
        assertTrue(after <= before * 1.05)
    }

    @Test fun `friction eventually stops a rolling ball`() {
        var balls = listOf(PoolBall(0, Vec2(0.0, 0.0), velocity = Vec2(0.4, 0.0)))
        repeat(400) { balls = PoolPhysics.step(balls).balls }
        assertTrue(PoolPhysics.isAtRest(balls))
    }
}
