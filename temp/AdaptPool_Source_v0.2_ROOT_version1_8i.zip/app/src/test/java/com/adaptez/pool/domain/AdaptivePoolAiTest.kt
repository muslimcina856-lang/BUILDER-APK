package com.adaptez.pool.domain

import com.adaptez.pool.domain.ai.AdaptivePoolAi
import com.adaptez.pool.domain.model.PlayerLearningProfile
import com.adaptez.pool.domain.model.ShotObservation
import org.junit.Assert.*
import org.junit.Test

class AdaptivePoolAiTest {
    @Test fun `difficulty scales from level 1 to 999 without cheating`() {
        val beginner = AdaptivePoolAi.parametersFor(1, PlayerLearningProfile())
        val master = AdaptivePoolAi.parametersFor(999, PlayerLearningProfile())
        assertTrue(master.aimErrorDegrees < beginner.aimErrorDegrees)
        assertTrue(master.powerErrorFraction < beginner.powerErrorFraction)
        assertTrue(master.planningSamples > beginner.planningSamples)
        assertTrue(master.aimErrorDegrees > 0.0)
    }

    @Test fun `learning profile tracks aggressive high power player`() {
        var profile = PlayerLearningProfile()
        repeat(12) {
            profile = AdaptivePoolAi.learn(
                profile,
                ShotObservation(power = 0.92, spinMagnitude = 0.35, usedBank = false, safetyIntent = false, pottedBall = true)
            )
        }
        assertTrue(profile.aggression > 0.70)
        assertTrue(profile.averagePower > 0.70)
        assertTrue(profile.samples >= 12)
    }

    @Test fun `ai raises safety bias against aggressive player`() {
        val calm = AdaptivePoolAi.parametersFor(400, PlayerLearningProfile(aggression = 0.2, samples = 30))
        val aggressive = AdaptivePoolAi.parametersFor(400, PlayerLearningProfile(aggression = 0.9, samples = 30))
        assertTrue(aggressive.safetyBias > calm.safetyBias)
    }
}
