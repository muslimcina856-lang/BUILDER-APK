package com.adaptez.pool.domain

import com.adaptez.pool.domain.model.PlayerSeat
import com.adaptez.pool.domain.model.PoolGameState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MatchStartPolicyTest {
    @Test
    fun `new match always starts with human break`() {
        val game = PoolGameState.playerBreakRack()

        assertEquals(PlayerSeat.HUMAN, game.turn)
        assertTrue(game.isBreakShot)
        assertFalse(game.ballInHand)
        assertEquals(0, game.shotNumber)
        assertFalse(game.gameOver)
    }
}
