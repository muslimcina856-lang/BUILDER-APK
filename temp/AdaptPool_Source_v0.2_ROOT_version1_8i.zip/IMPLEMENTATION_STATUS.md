# Adapt Pool — implementation status

## Implemented in this source drop

- Official app identity: Adapt Pool / `com.adaptez.pool`.
- User-selected billiards icon exported to Android launcher densities and Play Store 512 px asset.
- Adapt Chess-style shell: Main, Sejarah, Prestasi; dark neutral panels with gold/mint accents.
- 3D OpenGL ES pool table, glossy balls, cue, pockets, rails, lighting, shadows, orbit camera and aim guide.
- Fixed-step 120 Hz pool physics with 60 Hz presentation updates.
- Ball/rail collision, rolling friction, pockets, cushion bounce, basic side/follow/draw spin response.
- 8-Ball rules engine including break legality, group assignment, fouls, ball-in-hand, 8-ball call pocket and win/loss.
- New-match flow: pemain manusia sentiasa melakukan break pertama; tiada pemilihan breaker atau coin toss.
- Adaptive AI level 1–999 with level-dependent aim/power error and search budget.
- Learning profile: aggression, safety, average power, spin, bank usage and pot success.
- Local Room history and performance statistics.
- Procedural low-latency AudioTrack PCM for cue, ball collision and pocket sounds.
- Domain regression tests for rules, AI scaling/learning and physics.

## Verification performed here

- Pure Kotlin domain sources compile with `kotlinc`.
- Rules + adaptive AI harness passes.
- Physics harness passes.
- Android XML resources parse successfully.
- Project contains no remaining old Chess package references in production code.

## Environment limitation

A full Android Gradle build could not be executed in this sandbox because Gradle 8.6 and Maven/Google dependencies are not cached and outbound dependency download is unavailable. Run `./gradlew testDebugUnitTest assembleDebug` on a machine with normal Gradle dependency access for the final APK build.
