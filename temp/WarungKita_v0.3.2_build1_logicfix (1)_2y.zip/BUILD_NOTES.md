# Nota kemas kini v0.3.2

- Build number kekal `1`.
- Watak penjual tidak lagi digunakan sebagai pelanggan.
- Pelanggan masuk, memilih meja dan duduk sebelum membuat pesanan.
- Dua penjual bergerak ke ruang penyediaan, menyediakan hidangan dan menghantarnya ke meja.
- Aset makanan dipaparkan di atas meja dan berkurang ketika pelanggan makan.
- Pelanggan meninggalkan pinggan serta baki makanan selepas selesai.
- Meja perlu dibersihkan oleh penjual sebelum boleh digunakan semula.
- Teks berkaitan prototaip dan enjin tidak lagi dipaparkan dalam aplikasi.
- Pembaikan Android splash resource terdahulu dikekalkan.
