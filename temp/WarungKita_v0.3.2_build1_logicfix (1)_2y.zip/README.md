# Warung Kita

Game pengurusan warung offline untuk Android.

## Cara bermain

1. Beli stok bahan.
2. Pilih menu yang hendak dijual.
3. Buka warung.
4. Pelanggan akan masuk dan duduk di meja.
5. Dua penjual akan menyediakan serta menghantar hidangan.
6. Pelanggan makan, membayar dan meninggalkan pinggan kotor.
7. Penjual membersihkan meja sebelum pelanggan seterusnya duduk.
8. Gunakan keuntungan untuk menaik taraf warung.

## Binaan Android

```bash
flutter clean
flutter pub get
flutter build apk --debug
```

Versi aplikasi: `0.3.2+1`
