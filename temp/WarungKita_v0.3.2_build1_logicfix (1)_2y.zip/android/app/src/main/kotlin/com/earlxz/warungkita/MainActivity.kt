package com.earlxz.warungkita

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
