package org.gradle.wrapper;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** A small self-contained Gradle launcher for environments without the official wrapper JAR. */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path wrapperJar = Paths.get(
                GradleWrapperMain.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        Path projectDir = wrapperJar.getParent().getParent().getParent();
        Path propertiesPath = projectDir.resolve("gradle/wrapper/gradle-wrapper.properties");

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(propertiesPath)) {
            properties.load(input);
        }

        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || distributionUrl.trim().isEmpty()) {
            throw new IllegalStateException("distributionUrl tidak ditemui dalam " + propertiesPath);
        }

        String fileName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String cacheName = fileName.endsWith(".zip")
                ? fileName.substring(0, fileName.length() - 4)
                : fileName;
        Path cacheDir = Paths.get(System.getProperty("user.home"), ".gradle", "portable-wrapper", cacheName);
        Path marker = cacheDir.resolve("gradle-home.txt");
        Path gradleHome = readGradleHome(marker);

        if (gradleHome == null || !Files.exists(gradleExecutable(gradleHome))) {
            Files.createDirectories(cacheDir);
            Path zipFile = cacheDir.resolve(fileName);
            download(distributionUrl, zipFile);
            unzip(zipFile, cacheDir);
            Files.deleteIfExists(zipFile);
            gradleHome = locateGradleHome(cacheDir);
            Files.write(marker, gradleHome.toString().getBytes("UTF-8"));
        }

        Path executable = gradleExecutable(gradleHome);
        if (!System.getProperty("os.name").toLowerCase().contains("win")) {
            executable.toFile().setExecutable(true);
        }

        List<String> command = new ArrayList<String>();
        command.add(executable.toString());
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command)
                .directory(projectDir.toFile())
                .inheritIO()
                .start();
        System.exit(process.waitFor());
    }

    private static Path readGradleHome(Path marker) {
        try {
            if (!Files.exists(marker)) return null;
            String value = new String(Files.readAllBytes(marker), "UTF-8").trim();
            return value.isEmpty() ? null : Paths.get(value);
        } catch (IOException ignored) {
            return null;
        }
    }

    private static Path gradleExecutable(Path gradleHome) {
        boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
        return gradleHome.resolve("bin").resolve(windows ? "gradle.bat" : "gradle");
    }

    private static void download(String location, Path target) throws Exception {
        URI current = URI.create(location);
        for (int redirect = 0; redirect < 8; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) current.toURL().openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(30000);
            connection.setReadTimeout(30000);
            connection.setRequestProperty("User-Agent", "WarungKita-GradleWrapper/1.0");
            int status = connection.getResponseCode();
            if (status >= 300 && status < 400) {
                String next = connection.getHeaderField("Location");
                connection.disconnect();
                if (next == null) throw new IOException("Ubah hala tanpa Location");
                current = current.resolve(next);
                continue;
            }
            if (status < 200 || status >= 300) {
                throw new IOException("Gagal memuat turun Gradle. HTTP " + status);
            }
            try (InputStream input = new BufferedInputStream(connection.getInputStream())) {
                Files.copy(input, target, StandardCopyOption.REPLACE_EXISTING);
            } finally {
                connection.disconnect();
            }
            return;
        }
        throw new IOException("Terlalu banyak ubah hala semasa memuat turun Gradle");
    }

    private static void unzip(Path zipFile, Path destination) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(Files.newInputStream(zipFile)))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                Path output = destination.resolve(entry.getName()).normalize();
                if (!output.startsWith(destination)) {
                    throw new IOException("Entri ZIP tidak selamat: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    Files.createDirectories(output);
                } else {
                    Files.createDirectories(output.getParent());
                    Files.copy(zip, output, StandardCopyOption.REPLACE_EXISTING);
                }
                zip.closeEntry();
            }
        }
    }

    private static Path locateGradleHome(Path cacheDir) throws IOException {
        try (java.util.stream.Stream<Path> stream = Files.walk(cacheDir, 3)) {
            return stream
                    .filter(Files::isDirectory)
                    .filter(path -> Files.exists(gradleExecutable(path)))
                    .findFirst()
                    .orElseThrow(() -> new IOException("Direktori Gradle tidak ditemui selepas ekstrak"));
        }
    }
}
