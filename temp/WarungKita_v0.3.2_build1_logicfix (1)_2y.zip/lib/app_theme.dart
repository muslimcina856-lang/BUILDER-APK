import 'package:flutter/material.dart';

abstract final class AppColors {
  static const cream = Color(0xFFFFF4D6);
  static const lightCream = Color(0xFFFFFAF0);
  static const brown = Color(0xFF6B3418);
  static const darkBrown = Color(0xFF2B160D);
  static const orange = Color(0xFFF28C28);
  static const orangeDark = Color(0xFFC95D13);
  static const green = Color(0xFF63A832);
  static const greenDark = Color(0xFF357A28);
  static const red = Color(0xFFC4482D);
  static const gold = Color(0xFFF7C744);
  static const muted = Color(0xFF8C735E);
}

ThemeData buildAppTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.orange,
    brightness: Brightness.light,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    primaryColor: AppColors.orange,
    cardColor: AppColors.lightCream,
    scaffoldBackgroundColor: const Color(0xFFF6E7C5),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.orange,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.darkBrown,
      indicatorColor: AppColors.orange,
      labelTextStyle: MaterialStateProperty.resolveWith((states) {
        final selected = states.contains(MaterialState.selected);
        return TextStyle(
          color: selected ? Colors.white : AppColors.cream,
          fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
          fontSize: 11,
        );
      }),
      iconTheme: MaterialStateProperty.resolveWith((states) {
        return IconThemeData(
          color: states.contains(MaterialState.selected)
              ? Colors.white
              : AppColors.cream,
        );
      }),
    ),
  );
}
