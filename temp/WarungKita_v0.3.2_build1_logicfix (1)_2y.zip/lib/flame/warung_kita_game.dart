import 'dart:collection';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

import '../game/game_controller.dart';

class WarungKitaGame extends FlameGame {
  WarungKitaGame({required this.controller});

  final GameController controller;
  final Random _random = Random();

  // Hanya watak pelanggan sebenar digunakan di sini.
  final List<String> _customerAssets = const [
    'student_boy.png',
    'student_girl.png',
  ];

  final Map<String, ui.Image> _loadedImages = <String, ui.Image>{};
  final Queue<CustomerComponent> _pendingOrders = Queue<CustomerComponent>();
  final Queue<SeatSlot> _cleanupQueue = Queue<SeatSlot>();
  final List<SeatSlot> _seats = <SeatSlot>[];
  final List<WorkerComponent> _workers = <WorkerComponent>[];

  WarungSceneComponent? _scene;
  bool _sessionRunning = false;
  bool _disposed = false;
  int _spawned = 0;
  int _customerStyleIndex = 0;
  double _spawnDelay = 0;

  @override
  Color backgroundColor() => const Color(0xFFEDD49F);

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    camera.viewfinder
      ..anchor = Anchor.topLeft
      ..position = Vector2.zero();

    const files = <String>[
      'warung_stall.png',
      'service_counter.png',
      'kitchen_equipment.png',
      'ingredient_storage.png',
      'cook_female.png',
      'waiter_male.png',
      'student_boy.png',
      'student_girl.png',
      'nasi_lemak.png',
      'mee_goreng.png',
      'roti_bakar.png',
      'teh_tarik.png',
      'kopi.png',
      'nasi_ayam.png',
    ];

    final loaded = await images.loadAll(files);
    for (var i = 0; i < files.length; i++) {
      _loadedImages[files[i]] = loaded[i];
    }

    _scene = WarungSceneComponent(
      images: _loadedImages,
      gameSize: size.clone(),
    );
    await world.add(_scene!);

    _createSeats();
    await _createWorkers();

    controller.addListener(_handleControllerChanged);
    _handleControllerChanged();
  }

  void _createSeats() {
    _seats
      ..clear()
      ..addAll([
        SeatSlot(
          index: 0,
          customerPoint: Vector2(size.x * 0.24, size.y * 0.77),
          mealPoint: Vector2(size.x * 0.24, size.y * 0.675),
          servicePoint: Vector2(size.x * 0.39, size.y * 0.67),
        ),
        SeatSlot(
          index: 1,
          customerPoint: Vector2(size.x * 0.76, size.y * 0.77),
          mealPoint: Vector2(size.x * 0.76, size.y * 0.675),
          servicePoint: Vector2(size.x * 0.61, size.y * 0.67),
        ),
      ]);
  }

  Future<void> _createWorkers() async {
    final firstImage = _loadedImages['cook_female.png'];
    final secondImage = _loadedImages['waiter_male.png'];
    if (firstImage == null || secondImage == null) return;

    final first = WorkerComponent(
      game: this,
      workerIndex: 0,
      sprite: Sprite(firstImage),
      homePoint: workerHomePoint(0),
      kitchenPoint: workerKitchenPoint(0),
    );
    final second = WorkerComponent(
      game: this,
      workerIndex: 1,
      sprite: Sprite(secondImage),
      homePoint: workerHomePoint(1),
      kitchenPoint: workerKitchenPoint(1),
    );

    _workers
      ..clear()
      ..add(first)
      ..add(second);
    for (final worker in _workers) {
      await world.add(worker);
    }
  }

  @override
  void onGameResize(Vector2 newSize) {
    super.onGameResize(newSize);
    _scene?.resizeTo(newSize);
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_disposed) return;

    _dispatchWorkerTasks();

    if (!_sessionRunning ||
        !controller.serviceActive ||
        !controller.acceptingCustomers) {
      return;
    }

    if (_spawnDelay > 0) {
      _spawnDelay -= dt;
      return;
    }

    if (_spawned >= controller.customersTotal) return;

    final seat = _findFreeSeat();
    if (seat == null) {
      _spawnDelay = 0.18;
      return;
    }

    _spawnCustomer(seat);
  }

  void _handleControllerChanged() {
    if (_disposed) return;

    if (controller.serviceActive && !_sessionRunning) {
      _sessionRunning = true;
      _spawned = 0;
      _spawnDelay = 0.25;
    } else if (!controller.serviceActive && _sessionRunning) {
      _sessionRunning = false;
    }
  }

  SeatSlot? _findFreeSeat() {
    for (final seat in _seats) {
      if (seat.isAvailable) return seat;
    }
    return null;
  }

  void _spawnCustomer(SeatSlot seat) {
    final imageName =
        _customerAssets[_customerStyleIndex % _customerAssets.length];
    _customerStyleIndex++;
    final image = _loadedImages[imageName];
    if (image == null) return;

    seat.reserved = true;
    _spawned++;
    _spawnDelay = 0.50 + _random.nextDouble() * 0.30;

    final customer = CustomerComponent(
      game: this,
      sprite: Sprite(image),
      seat: seat,
    );
    seat.customer = customer;
    world.add(customer);
  }

  void customerSeated(CustomerComponent customer) {
    final result = controller.takeCustomerOrder();
    if (!result.served || result.item == null) {
      customer.rejectOrder();
      return;
    }

    final imageName = result.item!.imagePath.split('/').last;
    final foodImage = _loadedImages[imageName];
    if (foodImage == null) {
      customer.rejectOrder();
      return;
    }

    customer.acceptOrder(result, foodImage);
    _pendingOrders.add(customer);
    _dispatchWorkerTasks();
  }

  void _dispatchWorkerTasks() {
    for (final worker in _workers) {
      if (!worker.isIdle) continue;

      CustomerComponent? nextCustomer;
      while (_pendingOrders.isNotEmpty && nextCustomer == null) {
        final candidate = _pendingOrders.removeFirst();
        if (candidate.canReceiveService) nextCustomer = candidate;
      }

      if (nextCustomer != null) {
        worker.assignOrder(nextCustomer);
        continue;
      }

      SeatSlot? cleanupSeat;
      while (_cleanupQueue.isNotEmpty && cleanupSeat == null) {
        final candidate = _cleanupQueue.removeFirst();
        if (candidate.dirty && candidate.meal != null) {
          cleanupSeat = candidate;
        }
      }

      if (cleanupSeat != null) {
        worker.assignCleanup(cleanupSeat);
      }
    }
  }

  void deliverOrder(WorkerComponent worker, CustomerComponent customer) {
    final order = customer.order;
    final foodImage = customer.foodImage;
    if (order == null || foodImage == null || !customer.canReceiveService) {
      return;
    }

    final meal = TableMealComponent(
      image: foodImage,
      position: customer.seat.mealPoint.clone(),
      mealSize: size.x * 0.135,
    );
    customer.seat.meal = meal;
    world.add(meal);
    customer.receiveMeal(meal);
    controller.markOrderDelivered(order);
  }

  void customerFinishedMeal(CustomerComponent customer) {
    final order = customer.order;
    final meal = customer.seat.meal;
    if (order == null || meal == null) return;

    meal.markDirty();
    customer.seat.dirty = true;
    controller.completeCustomerOrder(order);
  }

  void customerExited(CustomerComponent customer) {
    final seat = customer.seat;
    seat.customer = null;

    if (seat.dirty && seat.meal != null) {
      _cleanupQueue.add(seat);
    } else {
      seat.reserved = false;
    }
    _dispatchWorkerTasks();
  }

  void finishCleanup(SeatSlot seat) {
    seat.meal?.removeFromParent();
    seat.meal = null;
    seat.dirty = false;
    seat.reserved = false;
    _spawnDelay = min(_spawnDelay, 0.12);
  }

  Vector2 get entryPoint => Vector2(size.x * 0.50, size.y * 1.10);

  Vector2 get exitPoint => Vector2(size.x * 1.12, size.y * 0.90);

  Vector2 workerHomePoint(int index) {
    return Vector2(size.x * (index == 0 ? 0.16 : 0.84), size.y * 0.365);
  }

  Vector2 workerKitchenPoint(int index) {
    return Vector2(size.x * (index == 0 ? 0.34 : 0.66), size.y * 0.375);
  }

  double get customerSpeed => size.y * 0.43;

  double get workerSpeed {
    final kitchenLevel = controller.state.upgradeLevels['kitchen'] ?? 1;
    return size.y * (0.34 + kitchenLevel * 0.015);
  }

  double get preparationDuration {
    final kitchenLevel = controller.state.upgradeLevels['kitchen'] ?? 1;
    return max(0.55, 1.65 - kitchenLevel * 0.16);
  }

  double get eatingDuration => 1.65 + _random.nextDouble() * 0.55;

  double get cleaningDuration => 0.55;

  void shutdown() {
    if (_disposed) return;
    _disposed = true;
    controller.removeListener(_handleControllerChanged);
  }

  @override
  void onRemove() {
    shutdown();
    super.onRemove();
  }
}

class SeatSlot {
  SeatSlot({
    required this.index,
    required this.customerPoint,
    required this.mealPoint,
    required this.servicePoint,
  });

  final int index;
  final Vector2 customerPoint;
  final Vector2 mealPoint;
  final Vector2 servicePoint;

  bool reserved = false;
  bool dirty = false;
  CustomerComponent? customer;
  TableMealComponent? meal;

  bool get isAvailable => !reserved && !dirty && customer == null && meal == null;
}

class WarungSceneComponent extends PositionComponent {
  WarungSceneComponent({
    required this.images,
    required Vector2 gameSize,
  }) : _gameSize = gameSize {
    priority = -100;
    size = gameSize;
  }

  final Map<String, ui.Image> images;
  Vector2 _gameSize;

  void resizeTo(Vector2 newSize) {
    _gameSize = newSize.clone();
    size = newSize;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final width = _gameSize.x;
    final height = _gameSize.y;
    if (width <= 0 || height <= 0) return;

    final wallPaint = Paint()..color = const Color(0xFFF5DCA9);
    final floorPaintA = Paint()..color = const Color(0xFFE7BE74);
    final floorPaintB = Paint()..color = const Color(0xFFDFAE62);
    final borderPaint = Paint()
      ..color = const Color(0xFF8A4A25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = max(1.0, width * 0.004);

    canvas.drawRect(Rect.fromLTWH(0, 0, width, height * 0.48), wallPaint);

    const columns = 8;
    const rows = 7;
    final tileWidth = width / columns;
    final floorTop = height * 0.40;
    final tileHeight = (height - floorTop) / rows;
    for (var row = 0; row < rows; row++) {
      for (var column = 0; column < columns; column++) {
        final rect = Rect.fromLTWH(
          column * tileWidth,
          floorTop + row * tileHeight,
          tileWidth,
          tileHeight,
        );
        canvas.drawRect(
          rect,
          (row + column).isEven ? floorPaintA : floorPaintB,
        );
        canvas.drawRect(rect, borderPaint);
      }
    }

    final wallLine = Paint()
      ..color = const Color(0xFF6B3418)
      ..strokeWidth = max(2.0, width * 0.012);
    canvas.drawLine(
      Offset(0, floorTop),
      Offset(width, floorTop),
      wallLine,
    );

    _drawAsset(
      canvas,
      'warung_stall.png',
      Rect.fromLTWH(width * 0.16, height * 0.015, width * 0.68, height * 0.29),
    );
    _drawAsset(
      canvas,
      'kitchen_equipment.png',
      Rect.fromLTWH(width * 0.02, height * 0.25, width * 0.28, height * 0.14),
    );
    _drawAsset(
      canvas,
      'ingredient_storage.png',
      Rect.fromLTWH(width * 0.70, height * 0.25, width * 0.27, height * 0.13),
    );
    _drawAsset(
      canvas,
      'service_counter.png',
      Rect.fromLTWH(width * 0.30, height * 0.30, width * 0.40, height * 0.13),
    );

    _drawDiningSet(canvas, Offset(width * 0.24, height * 0.69), width);
    _drawDiningSet(canvas, Offset(width * 0.76, height * 0.69), width);

    final pathPaint = Paint()
      ..color = const Color(0x55FFF7DD)
      ..strokeWidth = width * 0.10
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(width * 0.5, height * 0.47),
      Offset(width * 0.5, height * 0.98),
      pathPaint,
    );

    final openPaint = Paint()..color = const Color(0xFF58A93B);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(width * 0.44, height * 0.455, width * 0.12, height * 0.025),
        Radius.circular(width * 0.02),
      ),
      openPaint,
    );
  }

  void _drawDiningSet(Canvas canvas, Offset center, double width) {
    final tablePaint = Paint()..color = const Color(0xFF9A572C);
    final tableTopPaint = Paint()..color = const Color(0xFFC97A3B);
    final chairPaint = Paint()..color = const Color(0xFF6F3C22);
    final tableWidth = width * 0.25;
    final tableHeight = width * 0.10;

    final table = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: center,
        width: tableWidth,
        height: tableHeight,
      ),
      Radius.circular(width * 0.025),
    );
    canvas.drawRRect(table, tablePaint);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(center.dx, center.dy - tableHeight * 0.10),
          width: tableWidth * 0.90,
          height: tableHeight * 0.70,
        ),
        Radius.circular(width * 0.018),
      ),
      tableTopPaint,
    );

    final chairSize = width * 0.06;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(center.dx, center.dy + tableHeight * 0.92),
          width: chairSize,
          height: chairSize,
        ),
        Radius.circular(width * 0.012),
      ),
      chairPaint,
    );
  }

  void _drawAsset(Canvas canvas, String name, Rect bounds) {
    final image = images[name];
    if (image == null) return;

    final imageRatio = image.width / image.height;
    final boundsRatio = bounds.width / bounds.height;
    late Rect destination;
    if (imageRatio > boundsRatio) {
      final targetHeight = bounds.width / imageRatio;
      destination = Rect.fromLTWH(
        bounds.left,
        bounds.top + (bounds.height - targetHeight) / 2,
        bounds.width,
        targetHeight,
      );
    } else {
      final targetWidth = bounds.height * imageRatio;
      destination = Rect.fromLTWH(
        bounds.left + (bounds.width - targetWidth) / 2,
        bounds.top,
        targetWidth,
        bounds.height,
      );
    }

    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      destination,
      Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

enum CustomerPhase {
  entering,
  waitingForFood,
  eating,
  rejected,
  leaving,
}

class CustomerComponent extends SpriteComponent {
  CustomerComponent({
    required this.game,
    required Sprite sprite,
    required this.seat,
  }) : super(sprite: sprite, anchor: Anchor.center, priority: 20);

  final WarungKitaGame game;
  final SeatSlot seat;

  CustomerPhase _phase = CustomerPhase.entering;
  late Vector2 _target;
  late Vector2 _standingSize;
  double _phaseTimer = 0;
  double _eatingDuration = 0;
  FoodBubbleComponent? _orderBubble;
  CustomerServiceResult? order;
  ui.Image? foodImage;
  TableMealComponent? meal;
  bool _completionRecorded = false;

  bool get canReceiveService =>
      _phase == CustomerPhase.waitingForFood &&
      order != null &&
      foodImage != null;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final characterWidth = game.size.x * 0.125;
    _standingSize = Vector2(characterWidth, characterWidth * 1.55);
    size = _standingSize.clone();
    position = game.entryPoint;
    _target = seat.customerPoint.clone();
  }

  @override
  void update(double dt) {
    super.update(dt);

    switch (_phase) {
      case CustomerPhase.entering:
      case CustomerPhase.leaving:
        _moveTowardsTarget(dt);
        break;
      case CustomerPhase.waitingForFood:
        break;
      case CustomerPhase.eating:
        _phaseTimer -= dt;
        if (_eatingDuration > 0) {
          final progress = 1 - max(0.0, _phaseTimer) / _eatingDuration;
          meal?.setEatingProgress(progress);
        }
        if (_phaseTimer <= 0) _finishEating();
        break;
      case CustomerPhase.rejected:
        _phaseTimer -= dt;
        if (_phaseTimer <= 0) _beginLeaving();
        break;
    }
  }

  void _moveTowardsTarget(double dt) {
    final delta = _target - position;
    final distance = delta.length;
    if (distance <= max(2.0, game.size.x * 0.006)) {
      position = _target;
      _arrived();
      return;
    }

    final step = game.customerSpeed * dt;
    if (step >= distance) {
      position = _target;
      _arrived();
      return;
    }
    position += delta.normalized() * step;
  }

  void _arrived() {
    switch (_phase) {
      case CustomerPhase.entering:
        _sitDown();
        game.customerSeated(this);
        break;
      case CustomerPhase.leaving:
        game.customerExited(this);
        removeFromParent();
        break;
      case CustomerPhase.waitingForFood:
      case CustomerPhase.eating:
      case CustomerPhase.rejected:
        break;
    }
  }

  void _sitDown() {
    size = Vector2(_standingSize.x, _standingSize.y * 0.78);
    position = seat.customerPoint.clone();
    _phase = CustomerPhase.waitingForFood;
  }

  void acceptOrder(CustomerServiceResult result, ui.Image image) {
    order = result;
    foodImage = image;
    _orderBubble?.removeFromParent();
    final bubble = FoodBubbleComponent(
      image: image,
      position: Vector2(size.x * 0.76, -size.y * 0.03),
      bubbleSize: game.size.x * 0.088,
    );
    _orderBubble = bubble;
    add(bubble);
  }

  void rejectOrder() {
    _orderBubble?.removeFromParent();
    _phase = CustomerPhase.rejected;
    _phaseTimer = 0.45;
    add(
      MoodBubbleComponent(
        happy: false,
        position: Vector2(size.x * 0.72, -size.y * 0.03),
        bubbleSize: game.size.x * 0.074,
      ),
    );
  }

  void receiveMeal(TableMealComponent deliveredMeal) {
    if (!canReceiveService) return;
    _orderBubble?.removeFromParent();
    _orderBubble = null;
    meal = deliveredMeal;
    _phase = CustomerPhase.eating;
    _eatingDuration = game.eatingDuration;
    _phaseTimer = _eatingDuration;
  }

  void _finishEating() {
    if (_completionRecorded) return;
    _completionRecorded = true;
    game.customerFinishedMeal(this);
    add(
      MoodBubbleComponent(
        happy: true,
        position: Vector2(size.x * 0.72, -size.y * 0.03),
        bubbleSize: game.size.x * 0.074,
      ),
    );
    _beginLeaving();
  }

  void _beginLeaving() {
    size = _standingSize.clone();
    _phase = CustomerPhase.leaving;
    _target = game.exitPoint;
  }
}

enum WorkerPhase {
  idle,
  walkingToKitchen,
  preparing,
  carryingToTable,
  walkingToCleanup,
  cleaning,
  returning,
}

class WorkerComponent extends SpriteComponent {
  WorkerComponent({
    required this.game,
    required this.workerIndex,
    required Sprite sprite,
    required Vector2 homePoint,
    required Vector2 kitchenPoint,
  })  : _homePoint = homePoint,
        _kitchenPoint = kitchenPoint,
        super(sprite: sprite, anchor: Anchor.center, priority: 30);

  final WarungKitaGame game;
  final int workerIndex;
  final Vector2 _homePoint;
  final Vector2 _kitchenPoint;

  WorkerPhase _phase = WorkerPhase.idle;
  late Vector2 _target;
  double _phaseTimer = 0;
  CustomerComponent? _customer;
  SeatSlot? _cleanupSeat;
  FoodBubbleComponent? _carriedFood;

  bool get isIdle => _phase == WorkerPhase.idle;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final workerWidth = game.size.x * 0.14;
    size = Vector2(workerWidth, workerWidth * 1.55);
    position = _homePoint.clone();
    _target = _homePoint.clone();
  }

  void assignOrder(CustomerComponent customer) {
    if (!isIdle || !customer.canReceiveService) return;
    _customer = customer;
    _phase = WorkerPhase.walkingToKitchen;
    _target = _kitchenPoint.clone();
  }

  void assignCleanup(SeatSlot seat) {
    if (!isIdle || !seat.dirty || seat.meal == null) return;
    _cleanupSeat = seat;
    _phase = WorkerPhase.walkingToCleanup;
    _target = seat.servicePoint.clone();
  }

  @override
  void update(double dt) {
    super.update(dt);

    switch (_phase) {
      case WorkerPhase.idle:
        break;
      case WorkerPhase.walkingToKitchen:
      case WorkerPhase.carryingToTable:
      case WorkerPhase.walkingToCleanup:
      case WorkerPhase.returning:
        _moveTowardsTarget(dt);
        break;
      case WorkerPhase.preparing:
        _phaseTimer -= dt;
        if (_phaseTimer <= 0) _finishPreparing();
        break;
      case WorkerPhase.cleaning:
        _phaseTimer -= dt;
        if (_phaseTimer <= 0) _finishCleaning();
        break;
    }
  }

  void _moveTowardsTarget(double dt) {
    final delta = _target - position;
    final distance = delta.length;
    if (distance <= max(2.0, game.size.x * 0.006)) {
      position = _target;
      _arrived();
      return;
    }

    final step = game.workerSpeed * dt;
    if (step >= distance) {
      position = _target;
      _arrived();
      return;
    }
    position += delta.normalized() * step;
  }

  void _arrived() {
    switch (_phase) {
      case WorkerPhase.walkingToKitchen:
        _phase = WorkerPhase.preparing;
        _phaseTimer = game.preparationDuration;
        break;
      case WorkerPhase.carryingToTable:
        final customer = _customer;
        if (customer != null) game.deliverOrder(this, customer);
        _clearCarriedFood();
        _customer = null;
        _returnHome();
        break;
      case WorkerPhase.walkingToCleanup:
        _phase = WorkerPhase.cleaning;
        _phaseTimer = game.cleaningDuration;
        break;
      case WorkerPhase.returning:
        _phase = WorkerPhase.idle;
        break;
      case WorkerPhase.idle:
      case WorkerPhase.preparing:
      case WorkerPhase.cleaning:
        break;
    }
  }

  void _finishPreparing() {
    final customer = _customer;
    if (customer == null || !customer.canReceiveService) {
      _customer = null;
      _returnHome();
      return;
    }

    final image = customer.foodImage;
    if (image != null) {
      final bubble = FoodBubbleComponent(
        image: image,
        position: Vector2(size.x * 0.76, size.y * 0.36),
        bubbleSize: game.size.x * 0.078,
      );
      _carriedFood = bubble;
      add(bubble);
    }

    _phase = WorkerPhase.carryingToTable;
    _target = customer.seat.servicePoint.clone();
  }

  void _finishCleaning() {
    final seat = _cleanupSeat;
    if (seat != null) game.finishCleanup(seat);
    _cleanupSeat = null;
    _returnHome();
  }

  void _returnHome() {
    _phase = WorkerPhase.returning;
    _target = _homePoint.clone();
  }

  void _clearCarriedFood() {
    _carriedFood?.removeFromParent();
    _carriedFood = null;
  }
}

class TableMealComponent extends PositionComponent {
  TableMealComponent({
    required this.image,
    required Vector2 position,
    required double mealSize,
  }) : super(
          position: position,
          size: Vector2(mealSize, mealSize * 0.72),
          anchor: Anchor.center,
          priority: 18,
        );

  final ui.Image image;
  bool _dirty = false;
  double _eatingProgress = 0;

  void setEatingProgress(double progress) {
    _eatingProgress = progress.clamp(0.0, 1.0).toDouble();
  }

  void markDirty() {
    _dirty = true;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);

    final shadow = Paint()..color = const Color(0x44000000);
    final plate = Paint()..color = const Color(0xFFF7F0DF);
    final rim = Paint()
      ..color = const Color(0xFFB9A47F)
      ..style = PaintingStyle.stroke
      ..strokeWidth = max(1.0, size.x * 0.035);

    final plateRect = Rect.fromLTWH(0, size.y * 0.15, size.x, size.y * 0.70);
    canvas.drawOval(plateRect.shift(Offset(size.x * 0.03, size.y * 0.05)), shadow);
    canvas.drawOval(plateRect, plate);
    canvas.drawOval(plateRect, rim);

    if (!_dirty) {
      final foodScale = 0.84 - _eatingProgress * 0.42;
      final foodWidth = size.x * foodScale;
      final foodHeight = size.y * (0.85 - _eatingProgress * 0.34);
      canvas.drawImageRect(
        image,
        Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
        Rect.fromLTWH(
          (size.x - foodWidth) / 2,
          size.y * 0.04 + _eatingProgress * size.y * 0.16,
          foodWidth,
          foodHeight,
        ),
        Paint()..filterQuality = FilterQuality.medium,
      );
      return;
    }

    final leftoverPaint = Paint()
      ..filterQuality = FilterQuality.medium
      ..color = const Color(0x88FFFFFF);
    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      Rect.fromLTWH(
        size.x * 0.30,
        size.y * 0.22,
        size.x * 0.40,
        size.y * 0.40,
      ),
      leftoverPaint,
    );

    final crumb = Paint()..color = const Color(0xFF8A4A25);
    canvas.drawCircle(Offset(size.x * 0.27, size.y * 0.52), size.x * 0.035, crumb);
    canvas.drawCircle(Offset(size.x * 0.66, size.y * 0.44), size.x * 0.025, crumb);
    canvas.drawCircle(Offset(size.x * 0.55, size.y * 0.62), size.x * 0.020, crumb);
  }
}

class FoodBubbleComponent extends PositionComponent {
  FoodBubbleComponent({
    required this.image,
    required Vector2 position,
    required double bubbleSize,
  }) : super(
          position: position,
          size: Vector2.all(bubbleSize),
          anchor: Anchor.center,
          priority: 50,
        );

  final ui.Image image;

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final shadowPaint = Paint()..color = const Color(0x44000000);
    final bubblePaint = Paint()..color = Colors.white;
    final borderPaint = Paint()
      ..color = const Color(0xFFF28C28)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.x * 0.06;

    canvas.drawCircle(
      Offset(size.x * 0.54, size.y * 0.57),
      size.x * 0.51,
      shadowPaint,
    );
    canvas.drawCircle(
      Offset(size.x * 0.5, size.y * 0.5),
      size.x * 0.48,
      bubblePaint,
    );
    canvas.drawCircle(
      Offset(size.x * 0.5, size.y * 0.5),
      size.x * 0.48,
      borderPaint,
    );

    final inset = size.x * 0.15;
    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      Rect.fromLTWH(
        inset,
        inset,
        size.x - inset * 2,
        size.y - inset * 2,
      ),
      Paint()..filterQuality = FilterQuality.medium,
    );
  }
}

class MoodBubbleComponent extends PositionComponent {
  MoodBubbleComponent({
    required this.happy,
    required Vector2 position,
    required double bubbleSize,
  }) : super(
          position: position,
          size: Vector2.all(bubbleSize),
          anchor: Anchor.center,
          priority: 50,
        );

  final bool happy;

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final background = Paint()..color = Colors.white;
    final line = Paint()
      ..color = happy ? const Color(0xFF3F8F35) : const Color(0xFFC4482D)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.x * 0.08
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(Offset(size.x / 2, size.y / 2), size.x * 0.47, background);
    canvas.drawCircle(
      Offset(size.x * 0.36, size.y * 0.40),
      size.x * 0.035,
      Paint()..color = line.color,
    );
    canvas.drawCircle(
      Offset(size.x * 0.64, size.y * 0.40),
      size.x * 0.035,
      Paint()..color = line.color,
    );

    final mouth = Path();
    if (happy) {
      mouth.moveTo(size.x * 0.31, size.y * 0.60);
      mouth.quadraticBezierTo(
        size.x * 0.50,
        size.y * 0.78,
        size.x * 0.69,
        size.y * 0.60,
      );
    } else {
      mouth.moveTo(size.x * 0.31, size.y * 0.70);
      mouth.quadraticBezierTo(
        size.x * 0.50,
        size.y * 0.52,
        size.x * 0.69,
        size.y * 0.70,
      );
    }
    canvas.drawPath(mouth, line);
  }
}
