import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_theme.dart';
import 'game/game_controller.dart';
import 'game/game_repository.dart';
import 'game/game_state.dart';
import 'screens/game_screen.dart';
import 'screens/main_menu_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const WarungKitaApp());
}

class WarungKitaApp extends StatelessWidget {
  const WarungKitaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Warung Kita',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const WarungKitaRoot(),
    );
  }
}

class WarungKitaRoot extends StatefulWidget {
  const WarungKitaRoot({super.key});

  @override
  State<WarungKitaRoot> createState() => _WarungKitaRootState();
}

class _WarungKitaRootState extends State<WarungKitaRoot> {
  GameRepository? _repository;
  GameController? _controller;
  bool _loading = true;
  bool _canContinue = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final repository = await GameRepository.create();
    if (!mounted) return;
    setState(() {
      _repository = repository;
      _canContinue = repository.hasSave;
      _loading = false;
    });
  }

  Future<void> _startNewGame() async {
    final repository = _repository;
    if (repository == null) return;
    _controller?.dispose();
    final state = GameState.fresh();
    await repository.save(state);
    if (!mounted) return;
    setState(() {
      _controller = GameController(state: state, repository: repository);
      _canContinue = true;
    });
  }

  Future<void> _continueGame() async {
    final repository = _repository;
    if (repository == null) return;
    final state = repository.load();
    if (state == null) {
      if (!mounted) return;
      setState(() => _canContinue = false);
      return;
    }
    state.applyOfflineProgress();
    await repository.save(state);
    if (!mounted) return;
    _controller?.dispose();
    setState(() => _controller = GameController(state: state, repository: repository));
  }

  Future<void> _exitGame() async {
    final controller = _controller;
    if (controller != null) await controller.save();
    if (!mounted) return;
    controller?.dispose();
    setState(() {
      _controller = null;
      _canContinue = _repository?.hasSave ?? false;
    });
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: AppColors.darkBrown,
        body: Center(child: CircularProgressIndicator(color: AppColors.gold)),
      );
    }

    final controller = _controller;
    if (controller != null) {
      return GameScreen(controller: controller, onExit: _exitGame);
    }

    return MainMenuScreen(
      canContinue: _canContinue,
      onContinue: _continueGame,
      onNewGame: _startNewGame,
    );
  }
}
