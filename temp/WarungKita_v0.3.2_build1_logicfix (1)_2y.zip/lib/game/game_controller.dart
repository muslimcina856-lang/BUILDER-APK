import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

import 'game_data.dart';
import 'game_repository.dart';
import 'game_state.dart';

class CustomerServiceResult {
  const CustomerServiceResult({
    required this.served,
    required this.message,
    this.item,
    this.earned = 0,
    this.tip = 0,
    this.reputation = 0,
  });

  final bool served;
  final String message;
  final MenuDefinition? item;
  final int earned;
  final int tip;
  final int reputation;
}

class GameController extends ChangeNotifier {
  GameController({required this.state, required GameRepository repository})
      : _repository = repository;

  final GameState state;
  final GameRepository _repository;
  final Random _random = Random();

  bool serviceActive = false;
  bool acceptingCustomers = false;
  int customersTotal = 0;
  int customersRemaining = 0;
  int ordersInProgress = 0;
  String serviceStatus = 'Warung bersedia dibuka.';
  String? lastSoldItemId;

  double get serviceProgress {
    if (customersTotal <= 0) return 0;
    return (customersTotal - customersRemaining) / customersTotal;
  }

  int get warungLevel => state.upgradeLevels['warung'] ?? 1;

  int get servedToday =>
      serviceActive ? _workingReport.served : (state.lastReport?.served ?? 0);

  int get missedToday =>
      serviceActive ? _workingReport.missed : (state.lastReport?.missed ?? 0);

  Future<void> save() => _repository.save(state);

  List<MenuDefinition> availableMenuItems({bool requireStock = true}) {
    final result = <MenuDefinition>[];
    for (final item in menuItems.values) {
      if (warungLevel < item.unlockLevel) continue;
      if (!(state.menuEnabled[item.id] ?? true)) continue;
      if (requireStock && !hasRecipe(item.recipe)) continue;
      result.add(item);
    }
    return result;
  }

  bool hasRecipe(Map<String, int> recipe) {
    for (final entry in recipe.entries) {
      if ((state.inventory[entry.key] ?? 0) < entry.value) return false;
    }
    return true;
  }

  int customerCapacity() {
    return min(
      34,
      8 +
          state.day +
          (state.upgradeLevels['tables'] ?? 1) * 3 +
          state.reputation ~/ 35,
    );
  }

  int estimatedServings() {
    final inventoryCopy = Map<String, int>.from(state.inventory);
    final enabled = availableMenuItems(requireStock: false);
    if (enabled.isEmpty) return 0;

    var estimate = 0;
    for (var cycle = 0; cycle < 100; cycle++) {
      var found = false;
      for (final item in enabled) {
        var canMake = true;
        for (final entry in item.recipe.entries) {
          if ((inventoryCopy[entry.key] ?? 0) < entry.value) {
            canMake = false;
            break;
          }
        }
        if (!canMake) continue;
        for (final entry in item.recipe.entries) {
          inventoryCopy[entry.key] =
              (inventoryCopy[entry.key] ?? 0) - entry.value;
        }
        estimate++;
        found = true;
        break;
      }
      if (!found) break;
    }
    return estimate;
  }

  String? startService() {
    if (serviceActive) return null;
    if (availableMenuItems().isEmpty) {
      return 'Tiada hidangan dapat disediakan. Beli stok atau aktifkan menu.';
    }

    _workingReport.reset();
    serviceActive = true;
    acceptingCustomers = true;
    customersTotal = customerCapacity();
    customersRemaining = customersTotal;
    ordersInProgress = 0;
    serviceStatus = 'Pelanggan mula datang dan mencari tempat duduk.';
    lastSoldItemId = null;
    notifyListeners();
    return null;
  }

  CustomerServiceResult takeCustomerOrder() {
    if (!serviceActive || !acceptingCustomers || customersRemaining <= 0) {
      return const CustomerServiceResult(
        served: false,
        message: 'Warung tidak menerima pesanan baharu.',
      );
    }

    final possible = availableMenuItems();
    if (possible.isEmpty) {
      _closeOrdersBecauseStockEnded();
      return CustomerServiceResult(
        served: false,
        message: serviceStatus,
      );
    }

    final item = possible[_random.nextInt(possible.length)];
    _consumeRecipe(item.recipe);

    final kitchenLevel = state.upgradeLevels['kitchen'] ?? 1;
    final tipChance = 0.05 + kitchenLevel * 0.035;
    final tip = _random.nextDouble() < tipChance ? 1 + _random.nextInt(4) : 0;
    final repGain = 1 + _random.nextInt(2);
    final earned = item.price + tip;

    ordersInProgress++;
    serviceStatus = '${item.name} dipesan. Penjual sedang menyediakan hidangan.';
    notifyListeners();

    return CustomerServiceResult(
      served: true,
      message: serviceStatus,
      item: item,
      earned: earned,
      tip: tip,
      reputation: repGain,
    );
  }

  void markOrderDelivered(CustomerServiceResult order) {
    final item = order.item;
    if (!serviceActive || item == null) return;
    serviceStatus = '${item.name} telah dihantar ke meja pelanggan.';
    notifyListeners();
  }

  void completeCustomerOrder(CustomerServiceResult order) {
    final item = order.item;
    if (!order.served || item == null || customersRemaining <= 0) return;

    ordersInProgress = max(0, ordersInProgress - 1);
    customersRemaining = max(0, customersRemaining - 1);

    state.money += order.earned;
    state.reputation += order.reputation;
    _workingReport.served++;
    _workingReport.revenue += item.price;
    _workingReport.tips += order.tip;
    _workingReport.reputation += order.reputation;
    lastSoldItemId = item.id;
    serviceStatus =
        '${item.name} selesai • +RM ${order.earned}${order.tip > 0 ? ' termasuk tip' : ''}';
    notifyListeners();
    _checkForServiceEnd();
  }

  Future<String> buyStock(String id, int amount) async {
    final ingredient = ingredients[id];
    if (ingredient == null) return 'Bahan tidak dikenali.';
    final cost = stockPrice(id, amount);
    if (state.money < cost) {
      return 'Wang tidak mencukupi untuk membeli ${ingredient.name}.';
    }
    state.money -= cost;
    state.inventory[id] = (state.inventory[id] ?? 0) + amount;
    await save();
    notifyListeners();
    return '${ingredient.name} +$amount dibeli dengan harga RM $cost.';
  }

  Future<String> buyBasicBundle() async {
    var cost = 0;
    for (final entry in basicBundle.entries) {
      cost += stockPrice(entry.key, entry.value);
    }
    cost = (cost * 0.88).round();
    if (state.money < cost) {
      return 'Pakej asas berharga RM $cost. Wang semasa tidak mencukupi.';
    }
    state.money -= cost;
    for (final entry in basicBundle.entries) {
      state.inventory[entry.key] =
          (state.inventory[entry.key] ?? 0) + entry.value;
    }
    await save();
    notifyListeners();
    return 'Pakej stok asas dibeli dengan harga RM $cost.';
  }

  Future<String> toggleMenu(String id) async {
    final item = menuItems[id];
    if (item == null) return 'Menu tidak dikenali.';
    if (warungLevel < item.unlockLevel) {
      return 'Menu ini memerlukan Taraf Warung Lv.${item.unlockLevel}.';
    }
    state.menuEnabled[id] = !(state.menuEnabled[id] ?? true);
    await save();
    notifyListeners();
    return state.menuEnabled[id]!
        ? '${item.name} diaktifkan.'
        : '${item.name} ditutup sementara.';
  }

  Future<String> buyUpgrade(String id) async {
    final definition = upgrades[id];
    if (definition == null) return 'Naik taraf tidak dikenali.';
    final current = state.upgradeLevels[id] ?? 1;
    if (current >= definition.maxLevel) {
      return '${definition.name} sudah maksimum.';
    }
    final cost = upgradeCost(id);
    if (state.money < cost) {
      return 'Wang tidak mencukupi. Naik taraf ini memerlukan RM $cost.';
    }
    state.money -= cost;
    state.upgradeLevels[id] = current + 1;
    await save();
    notifyListeners();
    return '${definition.name} dinaikkan ke Lv.${current + 1}.';
  }

  int stockPrice(String id, int amount) {
    final base = ingredients[id]?.buyPrice ?? 1;
    final storageLevel = state.upgradeLevels['storage'] ?? 1;
    final discount = 1 - min(0.20, (storageLevel - 1) * 0.05);
    return max(1, (base * amount * discount).ceil());
  }

  int upgradeCost(String id) {
    final definition = upgrades[id]!;
    final level = state.upgradeLevels[id] ?? 1;
    return (definition.baseCost * pow(1.65, level - 1)).round();
  }

  String recipeText(Map<String, int> recipe) {
    return recipe.entries
        .map(
          (entry) =>
              '${ingredients[entry.key]?.name ?? entry.key} x${entry.value}',
        )
        .join(', ');
  }

  final _workingReport = _MutableReport();

  void _closeOrdersBecauseStockEnded() {
    if (!serviceActive || !acceptingCustomers) return;

    acceptingCustomers = false;
    final customersWithoutOrders = max(0, customersRemaining - ordersInProgress);
    if (customersWithoutOrders > 0) {
      customersRemaining -= customersWithoutOrders;
      _workingReport.missed += customersWithoutOrders;
    }
    serviceStatus = ordersInProgress > 0
        ? 'Stok habis. Pesanan sedia ada akan diselesaikan dahulu.'
        : 'Stok habis. Operasi hari ini ditutup.';
    notifyListeners();
    _checkForServiceEnd();
  }

  void _checkForServiceEnd() {
    if (!serviceActive) return;
    if (customersRemaining <= 0 && ordersInProgress <= 0) {
      unawaited(_finishService());
    }
  }

  Future<void> _finishService() async {
    if (!serviceActive) return;
    serviceActive = false;
    acceptingCustomers = false;
    ordersInProgress = 0;

    var note = 'Hari operasi selesai dengan baik.';
    final served = _workingReport.served;
    final missed = _workingReport.missed;
    if (served >= (customersTotal * 0.8).floor()) {
      final bonus = 20 + warungLevel * 10;
      state.money += bonus;
      _workingReport.revenue += bonus;
      note = 'Bonus servis cemerlang: RM $bonus';
    } else if (missed > served) {
      note = 'Tambah stok sebelum membuka warung esok.';
    }

    state.lastReport = GameReport(
      day: state.day,
      served: served,
      missed: missed,
      revenue: _workingReport.revenue,
      tips: _workingReport.tips,
      reputation: _workingReport.reputation,
      note: note,
    );
    state.stats
      ..served += served
      ..missed += missed
      ..revenue += _workingReport.revenue
      ..daysPlayed += 1;
    state.day++;
    customersRemaining = 0;
    serviceStatus = note;
    _workingReport.reset();
    await save();
    notifyListeners();
  }

  void _consumeRecipe(Map<String, int> recipe) {
    for (final entry in recipe.entries) {
      state.inventory[entry.key] =
          max(0, (state.inventory[entry.key] ?? 0) - entry.value);
    }
  }
}

class _MutableReport {
  int served = 0;
  int missed = 0;
  int revenue = 0;
  int tips = 0;
  int reputation = 0;

  void reset() {
    served = 0;
    missed = 0;
    revenue = 0;
    tips = 0;
    reputation = 0;
  }
}
