class IngredientDefinition {
  const IngredientDefinition({
    required this.id,
    required this.name,
    required this.buyPrice,
  });

  final String id;
  final String name;
  final int buyPrice;
}

class MenuDefinition {
  const MenuDefinition({
    required this.id,
    required this.name,
    required this.price,
    required this.unlockLevel,
    required this.imagePath,
    required this.recipe,
  });

  final String id;
  final String name;
  final int price;
  final int unlockLevel;
  final String imagePath;
  final Map<String, int> recipe;
}

class UpgradeDefinition {
  const UpgradeDefinition({
    required this.id,
    required this.name,
    required this.baseCost,
    required this.maxLevel,
    required this.description,
  });

  final String id;
  final String name;
  final int baseCost;
  final int maxLevel;
  final String description;
}

const ingredients = <String, IngredientDefinition>{
  'rice': IngredientDefinition(id: 'rice', name: 'Beras', buyPrice: 2),
  'egg': IngredientDefinition(id: 'egg', name: 'Telur', buyPrice: 2),
  'chicken': IngredientDefinition(id: 'chicken', name: 'Ayam', buyPrice: 4),
  'noodles': IngredientDefinition(id: 'noodles', name: 'Mi', buyPrice: 2),
  'bread': IngredientDefinition(id: 'bread', name: 'Roti', buyPrice: 2),
  'tea': IngredientDefinition(id: 'tea', name: 'Teh', buyPrice: 1),
  'coffee': IngredientDefinition(id: 'coffee', name: 'Kopi', buyPrice: 2),
  'milk': IngredientDefinition(id: 'milk', name: 'Susu', buyPrice: 2),
  'sugar': IngredientDefinition(id: 'sugar', name: 'Gula', buyPrice: 1),
  'cucumber': IngredientDefinition(id: 'cucumber', name: 'Timun', buyPrice: 1),
  'chili': IngredientDefinition(id: 'chili', name: 'Cili', buyPrice: 1),
  'oil': IngredientDefinition(id: 'oil', name: 'Minyak', buyPrice: 2),
};

const menuItems = <String, MenuDefinition>{
  'nasi_lemak': MenuDefinition(
    id: 'nasi_lemak',
    name: 'Nasi Lemak',
    price: 18,
    unlockLevel: 1,
    imagePath: 'assets/images/nasi_lemak.png',
    recipe: {'rice': 2, 'egg': 1, 'chicken': 1, 'cucumber': 1, 'chili': 1, 'oil': 1},
  ),
  'mee_goreng': MenuDefinition(
    id: 'mee_goreng',
    name: 'Mee Goreng',
    price: 14,
    unlockLevel: 1,
    imagePath: 'assets/images/mee_goreng.png',
    recipe: {'noodles': 2, 'egg': 1, 'cucumber': 1, 'chili': 1, 'oil': 1},
  ),
  'roti_bakar': MenuDefinition(
    id: 'roti_bakar',
    name: 'Roti Bakar',
    price: 8,
    unlockLevel: 1,
    imagePath: 'assets/images/roti_bakar.png',
    recipe: {'bread': 2, 'milk': 1, 'sugar': 1},
  ),
  'teh_tarik': MenuDefinition(
    id: 'teh_tarik',
    name: 'Teh Tarik',
    price: 6,
    unlockLevel: 1,
    imagePath: 'assets/images/teh_tarik.png',
    recipe: {'tea': 1, 'milk': 1, 'sugar': 1},
  ),
  'kopi': MenuDefinition(
    id: 'kopi',
    name: 'Kopi Warung',
    price: 7,
    unlockLevel: 2,
    imagePath: 'assets/images/kopi.png',
    recipe: {'coffee': 1, 'sugar': 1},
  ),
  'nasi_ayam': MenuDefinition(
    id: 'nasi_ayam',
    name: 'Nasi Ayam',
    price: 17,
    unlockLevel: 2,
    imagePath: 'assets/images/nasi_ayam.png',
    recipe: {'rice': 2, 'chicken': 2, 'cucumber': 1, 'chili': 1},
  ),
};

const upgrades = <String, UpgradeDefinition>{
  'warung': UpgradeDefinition(
    id: 'warung',
    name: 'Taraf Warung',
    baseCost: 220,
    maxLevel: 3,
    description: 'Buka menu dan pelanggan baharu.',
  ),
  'kitchen': UpgradeDefinition(
    id: 'kitchen',
    name: 'Dapur',
    baseCost: 140,
    maxLevel: 5,
    description: 'Tambah peluang tip dan kelajuan servis.',
  ),
  'tables': UpgradeDefinition(
    id: 'tables',
    name: 'Meja Pelanggan',
    baseCost: 110,
    maxLevel: 5,
    description: 'Tambah bilangan pelanggan setiap hari.',
  ),
  'storage': UpgradeDefinition(
    id: 'storage',
    name: 'Stor Bahan',
    baseCost: 90,
    maxLevel: 5,
    description: 'Berikan diskaun pembelian stok.',
  ),
};

const basicBundle = <String, int>{
  'rice': 10,
  'egg': 8,
  'chicken': 6,
  'noodles': 6,
  'bread': 6,
  'milk': 5,
  'sugar': 5,
  'cucumber': 5,
  'chili': 5,
  'oil': 5,
  'tea': 4,
  'coffee': 4,
};
