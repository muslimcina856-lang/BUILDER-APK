import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'game_state.dart';

class GameRepository {
  GameRepository._(this._preferences);

  static const _saveKey = 'warung_kita_save_v2';
  final SharedPreferences _preferences;

  static Future<GameRepository> create() async {
    return GameRepository._(await SharedPreferences.getInstance());
  }

  bool get hasSave => _preferences.containsKey(_saveKey);

  GameState? load() {
    final raw = _preferences.getString(_saveKey);
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, dynamic>) return null;
      return GameState.fromJson(decoded);
    } on FormatException {
      return null;
    }
  }

  Future<void> save(GameState state) async {
    state.lastSeen = DateTime.now().millisecondsSinceEpoch;
    await _preferences.setString(_saveKey, jsonEncode(state.toJson()));
  }

  Future<void> clear() async {
    await _preferences.remove(_saveKey);
  }
}
