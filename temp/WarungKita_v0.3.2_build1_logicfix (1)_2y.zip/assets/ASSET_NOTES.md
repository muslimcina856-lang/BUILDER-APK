# Aset Warung Kita

## Aset yang digunakan oleh aplikasi

Folder `assets/images/` mengandungi potongan aset yang terus digunakan oleh UI Flutter:

- gerai warung
- makanan dan minuman
- dapur dan stor
- pekerja serta pelanggan
- imej hero menu utama

`assets/app_icon.png` ialah sumber ikon aplikasi 1024 × 1024.

## Helaian sumber

Folder `assets/source_sheets/` menyimpan helaian asal untuk:

- persekitaran dan perabot
- makanan dan bahan
- watak
- komponen UI
- ikon aplikasi

Helaian sumber tidak dibungkus ke dalam APK; ia disertakan untuk kerja penyuntingan dan pemotongan aset seterusnya.
