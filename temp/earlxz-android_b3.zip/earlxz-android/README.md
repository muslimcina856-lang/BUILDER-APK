# Earlxz Android (Native App)

Android native app version of **Earlxz — Website to Design System**.

Built with **Capacitor 6** → real APK that can be installed on any Android phone.

---

## Requirements

- Node.js 18+
- Android Studio (latest)
- Java 17 (recommended)
- Android SDK (API 24+)

---

## Cara bina APK

### 1. Install dependencies
```bash
cd earlxz-android
npm install
```

### 2. Tambah platform Android
```bash
npx cap add android
```

### 3. Sync web assets
```bash
npx cap sync android
```

### 4. Buka dalam Android Studio
```bash
npx cap open android
```

### 5. Build APK
Dalam Android Studio:
- **Build → Build Bundle(s) / APK(s) → Build APK(s)**

APK keluar di:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

Atau run terus ke phone:
```bash
npx cap run android
```

---

## Internet Permission

Capacitor **auto-add** permission ni dalam `AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

Tanpa permission ni app tak boleh fetch CSS dari website lain.  
Selepas `npx cap add android` + `npx cap sync`, permission ni sudah ada.

Kalau nak pastikan, buka:
```
android/app/src/main/AndroidManifest.xml
```
dan pastikan baris `INTERNET` wujud.

---

## Icon App

Icon sudah disediakan dalam folder `www/`:
- `icon-192.png`
- `icon-512.png`
- `icon-foreground.png` (untuk adaptive icon)

### Cara set icon yang lebih bagus dalam Android Studio

1. Selepas `npx cap add android`
2. Klik kanan folder `android/app/src/main/res`
3. **New → Image Asset**
4. Pilih **Launcher Icons (Adaptive and Legacy)**
5. Path ke `www/icon-foreground.png` (atau `icon-512.png`)
6. Background color: `#0a0a0b` atau `#4f46e5`
7. Next → Finish

Ini akan generate semua density (mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi) dengan betul.

---

## App Info

| Item | Value |
|------|-------|
| App ID | `com.earlxz.designsystem` |
| App Name | Earlxz |
| Min SDK | 24 (Android 7.0) |
| Theme | Dark (`#0a0a0b`) |

---

## Features

- Color clustering
- Typography, radii, spacing, shadows
- Responsive breakpoints
- Component detection
- CSS Variables
- DESIGN.md export
- Full screen dark UI + splash screen

---

## Nota

- Internet diperlukan semasa scan (CORS proxies)
- App ID boleh diubah dalam `capacitor.config.json` → `appId`

---

**Earlxz** · Website to Design System · Android Native
