import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class User {
  final String username;
  final String key;
  final String role;
  final int expired;

  User({
    required this.username,
    required this.key,
    required this.role,
    required this.expired,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      username: json['username'] ?? '',
      key: json['key'] ?? '',
      role: json['role'] ?? 'member',
      expired: json['expired'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'username': username,
      'key': key,
      'role': role,
      'expired': expired,
    };
  }

  bool get isExpired => DateTime.now().millisecondsSinceEpoch > expired;

  String get expiredFormatted {
    final dt = DateTime.fromMillisecondsSinceEpoch(expired);
    return '${dt.day.toString().padLeft(2, '0')}/'
        '${dt.month.toString().padLeft(2, '0')}/'
        '${dt.year} '
        '${dt.hour.toString().padLeft(2, '0')}:'
        '${dt.minute.toString().padLeft(2, '0')}';
  }

  int get daysRemaining {
    final remaining =
        expired - DateTime.now().millisecondsSinceEpoch;
    return remaining > 0 ? (remaining / 86400000).floor() : 0;
  }
}

class AuthService {
  static const String _usersKey = 'octagram_users';
  static const String _sessionKey = 'octagram_session';

  /// Get all users from local storage
  static Future<List<User>> getUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_usersKey);
    if (raw == null) return [];
    try {
      final List decoded = jsonDecode(raw);
      return decoded.map((e) => User.fromJson(e)).toList();
    } catch (_) {
      return [];
    }
  }

  /// Save users list
  static Future<void> saveUsers(List<User> users) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _usersKey, jsonEncode(users.map((u) => u.toJson()).toList()));
  }

  /// Create / update account
  /// [role]: 'member', 'reseller', 'owner', etc.
  /// [durationMs]: duration in milliseconds
  static Future<Map<String, dynamic>> createAccount({
    required String username,
    required String role,
    required int durationMs,
    String? customKey,
  }) async {
    final users = await getUsers();
    final key = customKey ?? _generateKey();
    final expired = DateTime.now().millisecondsSinceEpoch + durationMs;

    final idx = users.indexWhere((u) => u.username == username);
    final newUser = User(
      username: username,
      key: key,
      role: role,
      expired: expired,
    );

    if (idx >= 0) {
      users[idx] = newUser;
    } else {
      users.add(newUser);
    }

    await saveUsers(users);
    return {
      'success': true,
      'username': username,
      'key': key,
      'role': role,
      'expired': newUser.expiredFormatted,
    };
  }

  /// Delete account by username
  static Future<bool> deleteAccount(String username) async {
    final users = await getUsers();
    final before = users.length;
    users.removeWhere((u) => u.username == username);
    if (users.length < before) {
      await saveUsers(users);
      return true;
    }
    return false;
  }

  /// Login with username + key
  static Future<User?> login(String username, String key) async {
    final users = await getUsers();
    try {
      final user = users.firstWhere(
        (u) => u.username == username && u.key == key,
      );
      if (user.isExpired) return null;
      // Save session
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_sessionKey, username);
      return user;
    } catch (_) {
      return null;
    }
  }

  /// Get current session username
  static Future<String?> getSession() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sessionKey);
  }

  /// Get current logged-in user
  static Future<User?> getCurrentUser() async {
    final username = await getSession();
    if (username == null) return null;
    final users = await getUsers();
    try {
      return users.firstWhere((u) => u.username == username);
    } catch (_) {
      return null;
    }
  }

  /// Logout
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_sessionKey);
  }

  /// Parse duration string like "1d", "7d", "12h"
  static int? parseDuration(String str) {
    final match = RegExp(r'^(\d+)([dh])$').firstMatch(str.trim());
    if (match == null) return null;
    final value = int.parse(match.group(1)!);
    final unit = match.group(2)!;
    return unit == 'd' ? value * 86400000 : value * 3600000;
  }

  static String _generateKey({int length = 4}) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rand = List.generate(
        length,
        (_) =>
            chars[(DateTime.now().microsecondsSinceEpoch + length) %
                chars.length]);
    // Use a simple random approach
    final now = DateTime.now().millisecondsSinceEpoch;
    String key = '';
    for (int i = 0; i < length; i++) {
      key += chars[(now ~/ (i + 1)) % chars.length];
    }
    return key.toUpperCase();
  }
}
