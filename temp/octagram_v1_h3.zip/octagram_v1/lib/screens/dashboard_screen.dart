import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'login_screen.dart';
import 'manage_accounts_screen.dart';

class DashboardScreen extends StatefulWidget {
  final User user;
  const DashboardScreen({super.key, required this.user});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late User _user;

  @override
  void initState() {
    super.initState();
    _user = widget.user;
  }

  Future<void> _logout() async {
    await AuthService.logout();
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050508),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.5, -0.5),
            radius: 1.5,
            colors: [Color(0xFF0A0A1A), Color(0xFF000000)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _buildUserCard(),
                      const SizedBox(height: 20),
                      _buildHeroImage(),
                      const SizedBox(height: 20),
                      _buildMenuGrid(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF080812).withOpacity(0.85),
        border: Border(
          bottom: BorderSide(color: Colors.white.withOpacity(0.05)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [Color(0xFF00F3FF), Color(0xFFB967FF)],
            ).createShader(bounds),
            child: const Text(
              'OCTAGRAM V1',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 2,
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout, color: Color(0xFFB0C8FF)),
            onPressed: _logout,
          ),
        ],
      ),
    );
  }

  Widget _buildUserCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF14143A).withOpacity(0.7),
        borderRadius: BorderRadius.circular(20),
        border:
            Border.all(color: const Color(0xFF78B4FF).withOpacity(0.15)),
      ),
      child: Column(
        children: [
          _infoRow('Username', _user.username),
          const Divider(color: Color(0xFF1E3070)),
          _infoRow('Role', _user.role.toUpperCase()),
          const Divider(color: Color(0xFF1E3070)),
          _infoRow('Expired', _user.expiredFormatted),
          const Divider(color: Color(0xFF1E3070)),
          _infoRow('Sisa', '${_user.daysRemaining} Hari'),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: const TextStyle(
                  color: Color(0xFFB0C8FF), fontSize: 13, fontWeight: FontWeight.w600)),
          Text(value,
              style: const TextStyle(
                  color: Colors.white, fontSize: 13, fontFamily: 'monospace')),
        ],
      ),
    );
  }

  Widget _buildHeroImage() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Image.asset(
        'assets/images/image2.webp',
        width: double.infinity,
        height: 180,
        fit: BoxFit.cover,
      ),
    );
  }

  Widget _buildMenuGrid() {
    final menus = [
      {'icon': Icons.manage_accounts, 'label': 'Kelola Akun', 'color': const Color(0xFF4A7BFF)},
      {'icon': Icons.people, 'label': 'List User', 'color': const Color(0xFF6EE7E7)},
      {'icon': Icons.add_circle, 'label': 'Buat Akun', 'color': const Color(0xFF22D3A4)},
      {'icon': Icons.delete_outline, 'label': 'Hapus Akun', 'color': const Color(0xFFFF6B8B)},
    ];

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 14,
      mainAxisSpacing: 14,
      childAspectRatio: 1.3,
      children: menus.map((m) {
        return GestureDetector(
          onTap: () => _onMenuTap(m['label'] as String),
          child: Container(
            decoration: BoxDecoration(
              color: (m['color'] as Color).withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: (m['color'] as Color).withOpacity(0.3)),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(m['icon'] as IconData,
                    color: m['color'] as Color, size: 32),
                const SizedBox(height: 10),
                Text(
                  m['label'] as String,
                  style: TextStyle(
                    color: m['color'] as Color,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  void _onMenuTap(String label) {
    switch (label) {
      case 'Kelola Akun':
      case 'List User':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ManageAccountsScreen()),
        );
        break;
      case 'Buat Akun':
        _showCreateAccountDialog();
        break;
      case 'Hapus Akun':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ManageAccountsScreen(startOnDelete: true)),
        );
        break;
    }
  }

  void _showCreateAccountDialog() {
    final usernameCtrl = TextEditingController();
    final durationCtrl = TextEditingController(text: '1d');
    String selectedRole = 'member';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDState) => AlertDialog(
          backgroundColor: const Color(0xFF0A0F2E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Buat Akun Baru',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Username', style: TextStyle(color: Color(0xFFB0C8FF), fontSize: 12)),
                const SizedBox(height: 6),
                TextField(
                  controller: usernameCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: _inputDeco('contoh: shin'),
                ),
                const SizedBox(height: 14),
                const Text('Role', style: TextStyle(color: Color(0xFFB0C8FF), fontSize: 12)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: selectedRole,
                  dropdownColor: const Color(0xFF0A1432),
                  style: const TextStyle(color: Colors.white),
                  decoration: _inputDeco('pilih role'),
                  items: const [
                    DropdownMenuItem(value: 'member', child: Text('Member')),
                    DropdownMenuItem(value: 'reseller', child: Text('Reseller')),
                    DropdownMenuItem(value: 'moderator', child: Text('Moderator')),
                    DropdownMenuItem(value: 'owner', child: Text('Owner')),
                  ],
                  onChanged: (v) => setDState(() => selectedRole = v ?? 'member'),
                ),
                const SizedBox(height: 14),
                const Text('Durasi (1d / 7d / 12h)',
                    style: TextStyle(color: Color(0xFFB0C8FF), fontSize: 12)),
                const SizedBox(height: 6),
                TextField(
                  controller: durationCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: _inputDeco('contoh: 1d, 7d, 12h'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Batal', style: TextStyle(color: Color(0xFFB0C8FF))),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4A7BFF),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () async {
                final username = usernameCtrl.text.trim();
                final durStr = durationCtrl.text.trim();
                final durationMs = AuthService.parseDuration(durStr);

                if (username.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Username tidak boleh kosong!')),
                  );
                  return;
                }
                if (durationMs == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Format durasi salah! Contoh: 1d, 7d, 12h')),
                  );
                  return;
                }

                final result = await AuthService.createAccount(
                  username: username,
                  role: selectedRole,
                  durationMs: durationMs,
                );
                if (!mounted) return;
                Navigator.pop(ctx);
                _showResultDialog(result);
              },
              child: const Text('Buat', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _showResultDialog(Map<String, dynamic> result) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0A0F2E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('✅ Akun Berhasil Dibuat',
            style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _resultRow('Username', result['username']),
            _resultRow('Key', result['key']),
            _resultRow('Role', result['role']),
            _resultRow('Expired', result['expired']),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF4A7BFF)),
            onPressed: () => Navigator.pop(ctx),
            child: const Text('OK', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _resultRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Text('$label: ',
              style: const TextStyle(
                  color: Color(0xFFB0C8FF), fontWeight: FontWeight.w600)),
          Text(value,
              style: const TextStyle(
                  color: Colors.white, fontFamily: 'monospace')),
        ],
      ),
    );
  }

  InputDecoration _inputDeco(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
      filled: true,
      fillColor: const Color(0xFF0A1432).withOpacity(0.4),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: const Color(0xFF78B4FF).withOpacity(0.2)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: const Color(0xFF78B4FF).withOpacity(0.2)),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    );
  }
}
