import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class ManageAccountsScreen extends StatefulWidget {
  final bool startOnDelete;
  const ManageAccountsScreen({super.key, this.startOnDelete = false});

  @override
  State<ManageAccountsScreen> createState() => _ManageAccountsScreenState();
}

class _ManageAccountsScreenState extends State<ManageAccountsScreen> {
  List<User> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _users = await AuthService.getUsers();
    setState(() => _loading = false);
  }

  Future<void> _delete(String username) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0A0F2E),
        title: const Text('Hapus Akun',
            style: TextStyle(color: Colors.white)),
        content: Text('Hapus akun "$username"?',
            style: const TextStyle(color: Color(0xFFB0C8FF))),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF6B8B)),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await AuthService.deleteAccount(username);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050508),
      appBar: AppBar(
        backgroundColor: const Color(0xFF080812),
        foregroundColor: Colors.white,
        title: const Text('Kelola Akun',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF4A7BFF)))
          : _users.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.people_outline,
                          color: Color(0xFFB0C8FF), size: 64),
                      const SizedBox(height: 16),
                      const Text('Belum ada akun',
                          style: TextStyle(color: Color(0xFFB0C8FF))),
                    ],
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: _users.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) {
                    final u = _users[i];
                    return Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF14143A).withOpacity(0.7),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: u.isExpired
                                ? const Color(0xFFFF6B8B).withOpacity(0.4)
                                : const Color(0xFF78B4FF).withOpacity(0.15)),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(u.username,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15)),
                                const SizedBox(height: 4),
                                Text('Key: ${u.key}',
                                    style: const TextStyle(
                                        color: Color(0xFF6EE7E7),
                                        fontFamily: 'monospace',
                                        fontSize: 12)),
                                Text('Role: ${u.role.toUpperCase()}',
                                    style: const TextStyle(
                                        color: Color(0xFFB0C8FF),
                                        fontSize: 12)),
                                Text(
                                  u.isExpired
                                      ? '⛔ EXPIRED'
                                      : 'Exp: ${u.expiredFormatted}',
                                  style: TextStyle(
                                    color: u.isExpired
                                        ? const Color(0xFFFF6B8B)
                                        : const Color(0xFF22D3A4),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline,
                                color: Color(0xFFFF6B8B)),
                            onPressed: () => _delete(u.username),
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}
