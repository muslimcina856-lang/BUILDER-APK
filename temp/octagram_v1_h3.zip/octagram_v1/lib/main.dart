import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const OctagramV1App());
}

class OctagramV1App extends StatelessWidget {
  const OctagramV1App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Octagram V1',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFF4A7BFF),
          secondary: const Color(0xFF6EE7E7),
          surface: const Color(0xFF0A0F2E),
        ),
        scaffoldBackgroundColor: const Color(0xFF0A0A12),
        fontFamily: 'Inter',
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}
