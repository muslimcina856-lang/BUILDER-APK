package com.octagram.v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
