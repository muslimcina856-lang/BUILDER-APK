# Octagram V1

**Premium Cyber Hub** – Flutter App + Node.js Backend

---

## Struktur Proyek

```
octagram_v1/
├── pubspec.yaml              # Flutter config (WAJIB ADA)
├── lib/
│   ├── main.dart
│   ├── screens/
│   │   ├── splash_screen.dart
│   │   ├── login_screen.dart
│   │   ├── dashboard_screen.dart
│   │   └── manage_accounts_screen.dart
│   └── services/
│       └── auth_service.dart
├── assets/
│   └── images/
│       ├── image1.webp       # Logo utama (blue skull)
│       └── image2.webp       # Hero image (red eye)
└── backend/                  # Node.js backend (server)
    ├── index.js
    ├── config.js
    ├── package.json
    ├── database/
    │   ├── akses.json
    │   └── user.json
    └── OctagramV1/           # HTML web pages
        ├── Login.html
        ├── dashboard.html
        ├── tiktok.html
        ├── profil.html
        ├── iqc.html
        ├── my-senders.html
        └── music.html
```

---

## Setup Flutter

```bash
flutter pub get
flutter run
```

---

## Setup Backend (Node.js)

```bash
cd backend
npm install
node index.js
```

---

## Cara Buat Akun (dari Telegram Bot)

```
/addkey <username>,<durasi>
```

Contoh:
- `/addkey shin,1d`   → akun role default, 1 hari
- `/addkey shin,7d`   → 7 hari
- `/addkey shin,12h`  → 12 jam

---

## Cara Buat Akun (dari App Flutter)

Di dashboard Flutter:
1. Tap **Buat Akun**
2. Isi Username, pilih Role (member/reseller/moderator/owner)
3. Isi Durasi: `1d`, `7d`, `12h`, dll
4. Tap **Buat** → Key akan di-generate otomatis
5. Bagikan Username + Key ke user

---

## Role yang Tersedia

| Role       | Akses                        |
|------------|------------------------------|
| member     | Fitur dasar                  |
| reseller   | Bisa tambah user             |
| moderator  | Kelola user & reseller       |
| owner      | Full akses                   |

---

## Rename yang Sudah Dilakukan

| Sebelum       | Sesudah      |
|---------------|--------------|
| RED VERSE V5  | Octagram V1  |
| The Orbix     | Octagram V1  |
| DEWA CRUSH    | Octagram V1  |
| x-worm dll    | Yeagerist Empire |
