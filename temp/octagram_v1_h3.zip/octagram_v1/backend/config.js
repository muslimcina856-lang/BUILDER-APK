module.exports = {
  tokens: "8362671236:AAGc9dwDD7X3sWr9WFgOycWJAcY-Iti0xgk",  // Masukin Bot token kamu
  owners: "8011050977", // Masukin ID Telegram kamu
  port: "4167", // Masukin Port panel kamu 
  Domain: "http://RizzOfficiall.privat.walzcfxcloud.web.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://RizzOfficiall.id ) menjadi ( http://RizzOfficiall.id)
};

/* WAJIB BACA !!!
 cari di index.js halaman 1995-1996 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/