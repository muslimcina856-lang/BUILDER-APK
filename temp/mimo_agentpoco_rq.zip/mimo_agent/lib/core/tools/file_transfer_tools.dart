import 'dart:io';
import 'dart:convert';
import 'package:path/path.dart' as p;
import 'tool_models.dart';

/// File Read Tool - Baca apa-ja jenis fail
class FileReadTool extends BaseTool {
  @override
  String get name => 'FileRead';

  @override
  String get description =>
      'Read any file type - text, binary, image, video, zip, pdf, etc. '
      'Returns content as text or base64 for binary files.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'path': {
            'type': 'string',
            'description': 'Path to file',
          },
          'as_base64': {
            'type': 'boolean',
            'description': 'Force read as base64 (for binary files)',
          },
        },
        'required': ['path'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final path = args['path'] as String;
    final asBase64 = args['as_base64'] as bool? ?? false;

    try {
      final file = File(path);
      if (!await file.exists()) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'File not found: $path',
        );
      }

      final stat = await file.stat();
      final ext = p.extension(path).toLowerCase();
      final size = stat.size;

      // Text files
      final textExts = [
        '.txt', '.md', '.json', '.yaml', '.yml', '.xml', '.csv',
        '.dart', '.py', '.js', '.ts', '.java', '.kt', '.swift',
        '.c', '.cpp', '.h', '.rs', '.go', '.rb', '.php', '.sh',
        '.html', '.css', '.sql', '.toml', '.ini', '.cfg', '.conf',
        '.log', '.env', '.gitignore', '.dockerfile', '.makefile',
      ];

      if (textExts.contains(ext) && !asBase64) {
        final content = await file.readAsString();
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: true,
          output: 'File: $path\nSize: $size bytes\nType: $ext\n\n$content',
        );
      }

      // Binary files - return as base64
      final bytes = await file.readAsBytes();
      final b64 = base64Encode(bytes);

      // Detect mime type
      String mimeType = 'application/octet-stream';
      if (ext == '.png') mimeType = 'image/png';
      if (ext == '.jpg' || ext == '.jpeg') mimeType = 'image/jpeg';
      if (ext == '.gif') mimeType = 'image/gif';
      if (ext == '.webp') mimeType = 'image/webp';
      if (ext == '.mp3') mimeType = 'audio/mpeg';
      if (ext == '.wav') mimeType = 'audio/wav';
      if (ext == '.mp4') mimeType = 'video/mp4';
      if (ext == '.webm') mimeType = 'video/webm';
      if (ext == '.pdf') mimeType = 'application/pdf';
      if (ext == '.zip') mimeType = 'application/zip';
      if (ext == '.doc' || ext == '.docx') {
        mimeType = 'application/msword';
      }

      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: true,
        output: 'File: $path\nSize: $size bytes\nType: $mimeType\n'
            'Content (base64): ${b64.substring(0, b64.length > 200 ? 200 : b64.length)}...',
        metadata: {
          'base64': b64,
          'mime_type': mimeType,
          'size': size,
        },
      );
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'FileRead error: $e',
      );
    }
  }
}

/// Zip Extract Tool
class ZipExtractTool extends BaseTool {
  @override
  String get name => 'ZipExtract';

  @override
  String get description => 'Extract zip/archive files to a directory.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'archive_path': {
            'type': 'string',
            'description': 'Path to zip file',
          },
          'output_dir': {
            'type': 'string',
            'description': 'Directory to extract to',
          },
        },
        'required': ['archive_path'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final archivePath = args['archive_path'] as String;
    final outputDir = args['output_dir'] as String?;

    try {
      final file = File(archivePath);
      if (!await file.exists()) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'Archive not found: $archivePath',
        );
      }

      final ext = p.extension(archivePath).toLowerCase();
      final targetDir = outputDir ?? p.dirname(archivePath);

      String command;
      if (ext == '.zip') {
        command = 'unzip -o "$archivePath" -d "$targetDir"';
      } else if (ext == '.tar' || archivePath.endsWith('.tar.gz') || archivePath.endsWith('.tgz')) {
        command = 'tar -xzf "$archivePath" -C "$targetDir"';
      } else if (ext == '.gz') {
        command = 'gunzip -k "$archivePath"';
      } else if (ext == '.rar') {
        command = 'unrar x "$archivePath" "$targetDir"';
      } else if (ext == '.7z') {
        command = '7z x "$archivePath" -o"$targetDir"';
      } else {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'Unsupported archive format: $ext',
        );
      }

      final result = await Process.run('bash', ['-c', command]);

      if (result.exitCode == 0) {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: true,
          output: 'Extracted to: $targetDir\n${result.stdout}',
        );
      } else {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'Extract failed: ${result.stderr}',
        );
      }
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'ZipExtract error: $e',
      );
    }
  }
}

/// Zip Create Tool
class ZipCreateTool extends BaseTool {
  @override
  String get name => 'ZipCreate';

  @override
  String get description => 'Create zip archive from files or directory.';

  @override
  Map<String, dynamic> get parameters => {
        'type': 'object',
        'properties': {
          'source_path': {
            'type': 'string',
            'description': 'File or directory to compress',
          },
          'output_path': {
            'type': 'string',
            'description': 'Output zip file path',
          },
        },
        'required': ['source_path', 'output_path'],
      };

  @override
  Future<ToolResult> execute(
      Map<String, dynamic> args, String toolCallId) async {
    final source = args['source_path'] as String;
    final output = args['output_path'] as String;

    try {
      final result =
          await Process.run('bash', ['-c', 'zip -r "$output" "$source"']);

      if (result.exitCode == 0) {
        final stat = await File(output).stat();
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: true,
          output: 'Created: $output (${stat.size} bytes)',
        );
      } else {
        return ToolResult(
          toolName: name,
          toolCallId: toolCallId,
          success: false,
          output: '',
          error: 'Zip failed: ${result.stderr}',
        );
      }
    } catch (e) {
      return ToolResult(
        toolName: name,
        toolCallId: toolCallId,
        success: false,
        output: '',
        error: 'ZipCreate error: $e',
      );
    }
  }
}
