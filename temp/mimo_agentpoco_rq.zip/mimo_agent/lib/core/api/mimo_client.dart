import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_key_manager.dart';
import 'mimo_models.dart';
import 'streaming_handler.dart';

/// Mimo API Client - OpenAI-compatible API
class MimoClient {
  final String baseUrl;
  final ApiKeyManager keyManager;
  final http.Client _httpClient;

  MimoClient({
    required this.baseUrl,
    required this.keyManager,
    http.Client? httpClient,
  }) : _httpClient = httpClient ?? http.Client();

  /// Get common headers
  Map<String, String> _headers() => {
        'Authorization': 'Bearer ${keyManager.currentKey}',
        'Content-Type': 'application/json',
      };

  /// Handle API response with auto-retry on auth failure
  Future<http.Response> _makeRequest(
    String method,
    String endpoint, {
    Map<String, String>? headers,
    Object? body,
    int maxRetries = 3,
  }) async {
    for (int attempt = 0; attempt < maxRetries; attempt++) {
      try {
        final uri = Uri.parse('$baseUrl$endpoint');
        final requestHeaders = {..._headers(), ...?headers};

        http.Response response;
        switch (method.toUpperCase()) {
          case 'GET':
            response = await _httpClient
                .get(uri, headers: requestHeaders)
                .timeout(const Duration(seconds: 60));
            break;
          case 'POST':
            response = await _httpClient
                .post(uri, headers: requestHeaders, body: jsonEncode(body))
                .timeout(const Duration(seconds: 120));
            break;
          default:
            throw Exception('Unsupported method: $method');
        }

        if (response.statusCode == 401 || response.statusCode == 429) {
          keyManager.markFailedAndRotate();
          continue;
        }

        keyManager.markSuccess();
        return response;
      } catch (e) {
        if (attempt == maxRetries - 1) rethrow;
        keyManager.markFailedAndRotate();
      }
    }
    throw Exception('All API keys failed');
  }

  /// List available models
  Future<List<MimoModel>> listModels() async {
    final response = await _makeRequest('GET', '/models');
    final data = jsonDecode(response.body);
    return (data['data'] as List)
        .map((m) => MimoModel.fromJson(m))
        .toList();
  }

  /// Standard chat completion
  Future<MimoChatResponse> chatCompletion(MimoChatRequest request) async {
    final response = await _makeRequest(
      'POST',
      '/chat/completions',
      body: request.toJson(),
    );
    return MimoChatResponse.fromJson(jsonDecode(response.body));
  }

  /// Streaming chat completion
  Stream<MimoStreamChunk> chatCompletionStream(MimoChatRequest request) async* {
    final streamedRequest = request.toJson();
    streamedRequest['stream'] = true;

    final uri = Uri.parse('$baseUrl/chat/completions');
    final requestObj = http.Request('POST', uri);
    requestObj.headers.addAll(_headers());
    requestObj.body = jsonEncode(streamedRequest);

    final streamedResponse = await _httpClient.send(requestObj);

    if (streamedResponse.statusCode != 200) {
      final body = await streamedResponse.stream.bytesToString();
      if (streamedResponse.statusCode == 401 ||
          streamedResponse.statusCode == 429) {
        keyManager.markFailedAndRotate();
      }
      throw Exception('API Error: ${streamedResponse.statusCode} - $body');
    }

    keyManager.markSuccess();

    yield* MimoStreamHandler.parseSSE(streamedResponse.stream);
  }

  /// Text-to-Speech via chat completions with audio modality
  Future<AudioData> tts({
    required String text,
    String voice = 'Mia',
    String model = 'mimo-v2.5-tts',
    String format = 'mp3',
  }) async {
    final request = MimoChatRequest(
      model: model,
      messages: [
        MimoMessage(role: 'user', content: 'Convert to speech'),
        MimoMessage(role: 'assistant', content: text),
      ],
      modalities: ['text', 'audio'],
      audio: AudioConfig(voice: voice, format: format),
    );

    final response = await chatCompletion(request);
    if (response.choices.isEmpty) {
      throw Exception('TTS: No response from model');
    }

    final audio = response.choices.first.message.audio;
    if (audio == null) {
      throw Exception('TTS: No audio data in response');
    }

    return audio;
  }

  /// Speech-to-Text (ASR)
  Future<String> asr({
    required String audioBase64,
    String model = 'mimo-v2.5-asr',
    String format = 'wav',
  }) async {
    final request = {
      'model': model,
      'messages': [
        {
          'role': 'user',
          'content': [
            {
              'type': 'input_audio',
              'input_audio': {'data': audioBase64, 'format': format}
            }
          ]
        }
      ]
    };

    final response = await _makeRequest(
      'POST',
      '/chat/completions',
      body: request,
    );

    final data = jsonDecode(response.body);
    return data['choices']?[0]?['message']?['content'] ?? '';
  }

  /// Voice Clone TTS
  Future<AudioData> voiceClone({
    required String text,
    required String voiceDataUrl,
    String model = 'mimo-v2.5-tts-voiceclone',
    String format = 'mp3',
  }) async {
    final request = MimoChatRequest(
      model: model,
      messages: [
        MimoMessage(role: 'user', content: 'Clone voice and speak'),
        MimoMessage(role: 'assistant', content: text),
      ],
      modalities: ['text', 'audio'],
      audio: AudioConfig(voice: voiceDataUrl, format: format),
    );

    final response = await chatCompletion(request);
    if (response.choices.isEmpty) {
      throw Exception('Voice Clone: No response from model');
    }

    final audio = response.choices.first.message.audio;
    if (audio == null) {
      throw Exception('Voice Clone: No audio data in response');
    }

    return audio;
  }

  /// Chat with tool definitions (for agent mode)
  Future<MimoChatResponse> chatWithTools({
    required List<MimoMessage> messages,
    required List<ToolDefinition> tools,
    String? model,
    int? maxTokens,
    double? temperature,
  }) async {
    final request = MimoChatRequest(
      model: model ?? 'mimo-v2.5-pro',
      messages: messages,
      tools: tools,
      maxTokens: maxTokens,
      temperature: temperature,
    );

    return chatCompletion(request);
  }

  /// Dispose HTTP client
  void dispose() {
    _httpClient.close();
  }
}
