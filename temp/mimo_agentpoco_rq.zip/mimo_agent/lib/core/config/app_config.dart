import 'dart:io';
import 'dart:convert';
import 'package:yaml/yaml.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'config_models.dart';
import 'api_key_manager.dart';

/// Main configuration manager - reads from config.yaml + SharedPreferences
class AppConfigManager {
  static AppConfigManager? _instance;
  late AppConfig _config;
  late ApiKeyManager _keyManager;
  bool _initialized = false;

  AppConfigManager._();

  static AppConfigManager get instance {
    _instance ??= AppConfigManager._();
    return _instance!;
  }

  AppConfig get config {
    if (!_initialized) throw StateError('AppConfigManager not initialized');
    return _config;
  }

  ApiKeyManager get keyManager {
    if (!_initialized) throw StateError('AppConfigManager not initialized');
    return _keyManager;
  }

  bool get isInitialized => _initialized;

  /// Initialize config from SharedPreferences + config.yaml
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();

    // Load saved API keys from SharedPreferences
    final savedKeys = prefs.getString('api_keys');
    List<ApiKeyConfig> apiKeys = [];

    if (savedKeys != null) {
      final List<dynamic> keysList = jsonDecode(savedKeys);
      apiKeys = keysList
          .map((k) => ApiKeyConfig(
                key: k['key'] ?? '',
                name: k['name'] ?? '',
                priority: k['priority'] ?? 1,
              ))
          .toList();
    }

    // Load saved base URL
    final savedBaseUrl = prefs.getString('base_url');

    // Try to load config.yaml for other settings
    AppConfig yamlConfig = AppConfig.fromMap({});
    try {
      final configPath = await _getConfigPath();
      final configFile = File(configPath);
      if (await configFile.exists()) {
        final content = await configFile.readAsString();
        final yamlMap = loadYaml(content);
        yamlConfig = AppConfig.fromMap(_convertYaml(yamlMap));
      }
    } catch (_) {}

    // Load custom model if set
    final customModel = prefs.getString('custom_model');

    // Merge: saved keys take priority, then yaml, then defaults
    _config = AppConfig(
      apiKeys: apiKeys.isNotEmpty
          ? apiKeys
          : yamlConfig.apiKeys.isNotEmpty
              ? yamlConfig.apiKeys
              : [],
      models: customModel != null && customModel.isNotEmpty
          ? ModelConfig(
              defaultModel: customModel,
              available: [customModel],
            )
          : yamlConfig.models,
      tts: yamlConfig.tts,
      agent: yamlConfig.agent,
      skills: yamlConfig.skills,
      plugins: yamlConfig.plugins,
      baseUrl: savedBaseUrl ?? yamlConfig.baseUrl,
    );

    _keyManager = ApiKeyManager(_config.apiKeys);
    _initialized = true;
  }

  /// Get config file path
  Future<String> _getConfigPath() async {
    final appDir = await getApplicationSupportDirectory();
    return '${appDir.path}/config.yaml';
  }

  /// Update config and save
  Future<void> updateConfig(AppConfig newConfig) async {
    _config = newConfig;
    _keyManager = ApiKeyManager(_config.apiKeys);
  }

  /// Convert YAML to Map
  dynamic _convertYaml(dynamic yaml) {
    if (yaml is YamlMap) {
      final map = <String, dynamic>{};
      for (var entry in yaml.entries) {
        map[entry.key.toString()] = _convertYaml(entry.value);
      }
      return map;
    } else if (yaml is YamlList) {
      return yaml.map((e) => _convertYaml(e)).toList();
    }
    return yaml;
  }
}
