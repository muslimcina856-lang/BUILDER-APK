import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import '../../core/agent/ai_agent.dart';
import '../../core/tts/tts_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final List<_ChatMessage> _messages = [];
  final List<_AttachedFile> _attachedFiles = [];
  bool _isLoading = false;
  bool _isStreaming = false;
  String _streamingContent = '';
  String _streamingReasoning = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mimo Agent'),
        backgroundColor: const Color(0xFF1A1A2E),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _newChat,
            tooltip: 'New Chat',
          ),
          IconButton(
            icon: const Icon(Icons.terminal),
            onPressed: _showToolLog,
            tooltip: 'Tool Log',
          ),
        ],
      ),
      body: Column(
        children: [
          // Messages list
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length + (_isStreaming ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _messages.length && _isStreaming) {
                  return _StreamingBubble(
                    content: _streamingContent,
                    reasoning: _streamingReasoning,
                  );
                }
                return _MessageBubble(
                  message: _messages[index],
                  onTts: _speakMessage,
                );
              },
            ),
          ),

          // Attached files preview
          if (_attachedFiles.isNotEmpty)
            Container(
              height: 60,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              color: const Color(0xFF1A1A2E),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _attachedFiles.length,
                itemBuilder: (context, index) {
                  final file = _attachedFiles[index];
                  return Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F0F23),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFF2D2D44)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(_getFileIcon(file.ext),
                            size: 16, color: const Color(0xFF6366F1)),
                        const SizedBox(width: 4),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(file.name,
                                style: const TextStyle(
                                    fontSize: 11, color: Colors.white),
                                overflow: TextOverflow.ellipsis),
                            Text('${(file.size / 1024).toStringAsFixed(1)}KB',
                                style: const TextStyle(
                                    fontSize: 9, color: Colors.grey)),
                          ],
                        ),
                        const SizedBox(width: 4),
                        GestureDetector(
                          onTap: () =>
                              setState(() => _attachedFiles.removeAt(index)),
                          child: const Icon(Icons.close,
                              size: 14, color: Colors.grey),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),

          // Input area
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: Color(0xFF1A1A2E),
              border: Border(
                top: BorderSide(color: Color(0xFF2D2D44)),
              ),
            ),
            child: Row(
              children: [
                // Attach button
                IconButton(
                  onPressed: _pickFile,
                  icon: const Icon(Icons.attach_file, color: Colors.grey),
                  tooltip: 'Attach file',
                ),
                // Voice button
                IconButton(
                  onPressed: _pickVoice,
                  icon: const Icon(Icons.mic, color: Colors.grey),
                  tooltip: 'Voice message',
                ),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: const Color(0xFF0F0F23),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    maxLines: null,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: _isLoading ? null : _sendMessage,
                  icon: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.send),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _isLoading) return;

    setState(() {
      _messages.add(_ChatMessage(role: 'user', content: text));
      _isLoading = true;
      _controller.clear();
    });

    _scrollToBottom();

    try {
      final agent = context.read<AIAgent>();

      // Use streaming
      setState(() {
        _isStreaming = true;
        _streamingContent = '';
        _streamingReasoning = '';
      });

      final buffer = StringBuffer();
      final reasoningBuffer = StringBuffer();
      final toolLogs = <String>[];

      await for (final event in agent.sendMessageStream(text)) {
        switch (event.type) {
          case AgentStreamEventType.content:
            buffer.write(event.content);
            setState(() => _streamingContent = buffer.toString());
            _scrollToBottom();
            break;
          case AgentStreamEventType.reasoning:
            reasoningBuffer.write(event.content);
            setState(() => _streamingReasoning = reasoningBuffer.toString());
            break;
          case AgentStreamEventType.toolCall:
            toolLogs.add('🔧 Calling: ${event.content}');
            setState(() {});
            break;
          case AgentStreamEventType.toolResult:
            toolLogs.add('✅ ${event.metadata?['tool'] ?? 'tool'}: ${event.content.substring(0, event.content.length.clamp(0, 100))}');
            setState(() {});
            break;
          default:
            break;
        }
      }

      setState(() {
        _isStreaming = false;
        _messages.add(_ChatMessage(
          role: 'assistant',
          content: buffer.toString(),
          reasoning: reasoningBuffer.toString(),
          toolLogs: toolLogs,
        ));
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isStreaming = false;
        _messages.add(_ChatMessage(
          role: 'error',
          content: 'Error: $e',
        ));
        _isLoading = false;
      });
    }

    _scrollToBottom();
  }

  void _newChat() {
    setState(() {
      _messages.clear();
      _isStreaming = false;
      _streamingContent = '';
      _streamingReasoning = '';
    });
    context.read<AIAgent>().clear();
  }

  void _showToolLog() {
    // Show tool execution log
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tool Execution Log',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: _messages
                    .expand((m) => m.toolLogs ?? [])
                    .map((log) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Text(log,
                              style: const TextStyle(
                                  fontFamily: 'monospace', fontSize: 12)),
                        ))
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _speakMessage(String text) async {
    try {
      final tts = context.read<TtsService>();
      final result = await tts.speak(text: text);
      // Play audio file
      // just_audio player would go here
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('TTS saved: ${result.filePath}')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('TTS error: $e')),
      );
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _pickFile() async {
    // Show dialog to enter file path (since we're in terminal environment)
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        title: const Text('Attach File'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Enter file path:',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              decoration: InputDecoration(
                hintText: '/path/to/file.zip',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Supports: zip, tar, gz, images, audio, video, pdf, docs, code files',
              style: TextStyle(color: Colors.grey, fontSize: 10),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text),
            child: const Text('Attach'),
          ),
        ],
      ),
    );

    if (result != null && result.isNotEmpty) {
      final file = File(result);
      if (await file.exists()) {
        final stat = await file.stat();
        setState(() {
          _attachedFiles.add(_AttachedFile(
            name: p.basename(result),
            path: result,
            size: stat.size,
            ext: p.extension(result).toLowerCase(),
          ));
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('File not found')),
          );
        }
      }
    }
  }

  Future<void> _pickVoice() async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        title: const Text('Voice Message'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Enter voice file path:',
                style: TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              decoration: InputDecoration(
                hintText: '/path/to/voice.wav',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Supports: wav, mp3, m4a, ogg, flac',
              style: TextStyle(color: Colors.grey, fontSize: 10),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text),
            child: const Text('Send'),
          ),
        ],
      ),
    );

    if (result != null && result.isNotEmpty) {
      final file = File(result);
      if (await file.exists()) {
        setState(() {
          _attachedFiles.add(_AttachedFile(
            name: p.basename(result),
            path: result,
            size: file.lengthSync(),
            ext: p.extension(result).toLowerCase(),
            isVoice: true,
          ));
        });
      }
    }
  }

  IconData _getFileIcon(String ext) {
    if (['.jpg', '.jpeg', '.png', '.gif', '.webp'].contains(ext)) {
      return Icons.image;
    }
    if (['.mp3', '.wav', '.m4a', '.ogg', '.flac'].contains(ext)) {
      return Icons.audio_file;
    }
    if (['.mp4', '.webm', '.avi', '.mov'].contains(ext)) {
      return Icons.video_file;
    }
    if (['.zip', '.tar', '.gz', '.rar', '.7z'].contains(ext)) {
      return Icons.archive;
    }
    if (['.pdf'].contains(ext)) return Icons.picture_as_pdf;
    if (['.doc', '.docx', '.txt', '.md'].contains(ext)) {
      return Icons.description;
    }
    return Icons.insert_drive_file;
  }
}

class _AttachedFile {
  final String name;
  final String path;
  final int size;
  final String ext;
  final bool isVoice;

  _AttachedFile({
    required this.name,
    required this.path,
    required this.size,
    required this.ext,
    this.isVoice = false,
  });
}

class _ChatMessage {
  final String role;
  final String content;
  final String? reasoning;
  final List<String>? toolLogs;

  _ChatMessage({
    required this.role,
    required this.content,
    this.reasoning,
    this.toolLogs,
  });
}

class _MessageBubble extends StatelessWidget {
  final _ChatMessage message;
  final Function(String) onTts;

  const _MessageBubble({required this.message, required this.onTts});

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == 'user';
    final isError = message.role == 'error';

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8,
        ),
        child: Column(
          crossAxisAlignment:
              isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isUser
                    ? const Color(0xFF6366F1)
                    : isError
                        ? const Color(0xFFEF4444).withOpacity(0.2)
                        : const Color(0xFF1A1A2E),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Reasoning (collapsible)
                  if (message.reasoning != null &&
                      message.reasoning!.isNotEmpty)
                    ExpansionTile(
                      title: const Text('Reasoning',
                          style:
                              TextStyle(fontSize: 12, color: Colors.grey)),
                      children: [
                        Text(message.reasoning!,
                            style: const TextStyle(
                                fontSize: 12,
                                color: Colors.grey,
                                fontStyle: FontStyle.italic)),
                      ],
                      tilePadding: EdgeInsets.zero,
                      childrenPadding: EdgeInsets.zero,
                    ),

                  // Content
                  SelectableText(
                    message.content,
                    style: TextStyle(
                      color: isUser ? Colors.white : Colors.white70,
                      fontSize: 14,
                    ),
                  ),

                  // Tool logs
                  if (message.toolLogs != null &&
                      message.toolLogs!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: message.toolLogs!
                            .map((log) => Text(log,
                                style: const TextStyle(
                                    fontSize: 11,
                                    color: Colors.green,
                                    fontFamily: 'monospace')))
                            .toList(),
                      ),
                    ),
                ],
              ),
            ),

            // Action buttons
            if (!isUser && !isError)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.volume_up, size: 16),
                      onPressed: () => onTts(message.content),
                      tooltip: 'Read aloud',
                      constraints: const BoxConstraints(
                          minWidth: 32, minHeight: 32),
                    ),
                    IconButton(
                      icon: const Icon(Icons.copy, size: 16),
                      onPressed: () {
                        // Copy to clipboard
                      },
                      tooltip: 'Copy',
                      constraints: const BoxConstraints(
                          minWidth: 32, minHeight: 32),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _StreamingBubble extends StatelessWidget {
  final String content;
  final String reasoning;

  const _StreamingBubble({required this.content, required this.reasoning});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A2E),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (reasoning.isNotEmpty)
              Text(reasoning,
                  style: const TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                      fontStyle: FontStyle.italic)),
            if (content.isEmpty)
              const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            else
              Text(content, style: const TextStyle(color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}
