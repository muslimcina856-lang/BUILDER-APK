package com.devscope.app;

import android.webkit.ValueCallback;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

public final class AutomationEngine {
    public interface TextCallback {
        void onResult(String value);
        void onError(String error);
    }

    public interface JsonCallback {
        void onResult(JSONObject value);
        void onError(String error);
    }

    private final WebView webView;

    public AutomationEngine(WebView webView) {
        this.webView = webView;
    }

    public void installRecorder(TextCallback callback) {
        evalText("""
            (() => {
              try {
                if (window.__devscopeRecorderInstalled) {
                  window.__devscopeRecorderEnabled = true;
                  return 'recorder resumed';
                }
                window.__devscopeRecorderInstalled = true;
                window.__devscopeRecorderEnabled = true;
                window.__devscopeRecorderQueue = [];
                const cssEsc = x => (window.CSS && CSS.escape) ? CSS.escape(String(x)) : String(x).replace(/[^a-zA-Z0-9_-]/g, c => String.fromCharCode(92) + c);
                function unique(sel) {
                  try { return document.querySelectorAll(sel).length === 1; }
                  catch (_) { return false; }
                }
                function selector(el) {
                  if (!(el instanceof Element)) return '';
                  if (el.id) {
                    const s = '#' + cssEsc(el.id);
                    if (unique(s)) return s;
                  }
                  for (const attr of ['data-testid','data-test','data-cy','name','aria-label']) {
                    const v = el.getAttribute && el.getAttribute(attr);
                    if (v) {
                      const s = el.tagName.toLowerCase() + '[' + attr + '=' + JSON.stringify(v) + ']';
                      if (unique(s)) return s;
                    }
                  }
                  const parts = [];
                  let cur = el;
                  while (cur && cur.nodeType === 1 && parts.length < 7) {
                    let part = cur.tagName.toLowerCase();
                    const classes = Array.from(cur.classList || []).filter(Boolean).slice(0,2);
                    if (classes.length) part += '.' + classes.map(cssEsc).join('.');
                    const parent = cur.parentElement;
                    if (parent) {
                      const same = Array.from(parent.children).filter(x => x.tagName === cur.tagName);
                      if (same.length > 1) part += ':nth-of-type(' + (same.indexOf(cur) + 1) + ')';
                    }
                    parts.unshift(part);
                    const joined = parts.join(' > ');
                    if (unique(joined)) return joined;
                    cur = parent;
                  }
                  return parts.join(' > ');
                }
                function clip(s, n) {
                  s = String(s == null ? '' : s).replace(/\\s+/g, ' ').trim();
                  return s.length > n ? s.slice(0, n - 1) + '…' : s;
                }
                function push(step) {
                  if (!window.__devscopeRecorderEnabled) return;
                  step.ts = Date.now();
                  step.url = location.href;
                  window.__devscopeRecorderQueue.push(step);
                  if (window.__devscopeRecorderQueue.length > 500) window.__devscopeRecorderQueue.shift();
                  try { console.debug('__DEVSCOPE_REC__' + JSON.stringify(step)); } catch (_) {}
                }
                let lastClickAt = 0;
                document.addEventListener('click', e => {
                  if (!window.__devscopeRecorderEnabled || window.__devscopePickerCleanup) return;
                  const el = e.target && e.target.closest ? e.target.closest('a,button,input,select,textarea,[role="button"],[onclick],summary,label,*') : e.target;
                  if (!(el instanceof Element)) return;
                  if (el.id === '__devscope_picker_overlay') return;
                  lastClickAt = Date.now();
                  push({type:'click', selector:selector(el), tag:el.tagName.toLowerCase(), text:clip(el.innerText || el.value || el.getAttribute('aria-label') || '', 120)});
                }, true);
                document.addEventListener('change', e => {
                  if (!window.__devscopeRecorderEnabled) return;
                  const el = e.target;
                  if (!(el instanceof Element)) return;
                  const sel = selector(el);
                  if (!sel) return;
                  if (el instanceof HTMLSelectElement) {
                    push({type:'select', selector:sel, value:el.value});
                    return;
                  }
                  if (el instanceof HTMLInputElement) {
                    const type = String(el.type || 'text').toLowerCase();
                    if (type === 'checkbox' || type === 'radio') {
                      push({type:'check', selector:sel, checked:!!el.checked});
                    } else if (type === 'file') {
                      push({type:'fileInput', selector:sel, manual:true});
                    } else if (type === 'password') {
                      push({type:'input', selector:sel, value:'', secret:true});
                    } else {
                      push({type:'input', selector:sel, value:el.value});
                    }
                    return;
                  }
                  if (el instanceof HTMLTextAreaElement) push({type:'input', selector:sel, value:el.value});
                }, true);
                document.addEventListener('blur', e => {
                  if (!window.__devscopeRecorderEnabled) return;
                  const el = e.target;
                  if (!(el instanceof HTMLElement) || !el.isContentEditable) return;
                  push({type:'content', selector:selector(el), value:el.innerText || ''});
                }, true);
                document.addEventListener('submit', e => {
                  if (!window.__devscopeRecorderEnabled) return;
                  if (Date.now() - lastClickAt < 450) return;
                  const form = e.target;
                  if (form instanceof HTMLFormElement) push({type:'submit', selector:selector(form)});
                }, true);
                let scrollTimer = 0;
                window.addEventListener('scroll', () => {
                  if (!window.__devscopeRecorderEnabled) return;
                  clearTimeout(scrollTimer);
                  scrollTimer = setTimeout(() => push({type:'scroll', x:Math.round(scrollX), y:Math.round(scrollY)}), 350);
                }, {passive:true, capture:true});
                return 'recorder installed';
              } catch (e) { return 'recorder error: ' + e; }
            })()
        """, callback);
    }

    public void pauseRecorder(TextCallback callback) {
        evalText("(() => { window.__devscopeRecorderEnabled = false; return 'recorder paused'; })()", callback);
    }

    public void drainRecorder(JsonCallback callback) {
        evalJson("""
            (() => {
              const q = Array.isArray(window.__devscopeRecorderQueue) ? window.__devscopeRecorderQueue.splice(0) : [];
              return JSON.stringify({events:q, enabled:!!window.__devscopeRecorderEnabled, url:location.href});
            })()
        """, callback);
    }

    public void performDomStep(JSONObject step, JsonCallback callback) {
        String type = step.optString("type", "");
        String quotedStep = JSONObject.quote(step.toString());
        String script = """
            (() => {
              try {
                const step = JSON.parse(__STEP__);
                const type = step.type || '';
                const q = sel => {
                  if (!sel) throw new Error('selector is required');
                  const el = document.querySelector(sel);
                  if (!el) throw new Error('selector not found: ' + sel);
                  return el;
                };
                const nativeSet = (el, value) => {
                  const proto = Object.getPrototypeOf(el);
                  const desc = proto && Object.getOwnPropertyDescriptor(proto, 'value');
                  if (desc && desc.set) desc.set.call(el, value);
                  else el.value = value;
                };
                const fire = el => {
                  try { el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText'})); }
                  catch (_) { el.dispatchEvent(new Event('input', {bubbles:true})); }
                  el.dispatchEvent(new Event('change', {bubbles:true}));
                };
                if (type === 'click') {
                  const el = q(step.selector); el.scrollIntoView({block:'center', inline:'center'}); el.click();
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'input') {
                  if (step.secret && !step.value) throw new Error('secret value is empty; edit the script before running');
                  const el = q(step.selector); nativeSet(el, String(step.value == null ? '' : step.value)); fire(el); el.blur();
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'content') {
                  const el = q(step.selector); el.focus(); el.innerText = String(step.value == null ? '' : step.value); fire(el); el.blur();
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'select') {
                  const el = q(step.selector); nativeSet(el, String(step.value == null ? '' : step.value)); fire(el);
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'check') {
                  const el = q(step.selector); el.checked = !!step.checked; fire(el);
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'submit') {
                  const form = q(step.selector); if (form.requestSubmit) form.requestSubmit(); else form.submit();
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'scroll') {
                  window.scrollTo({left:Number(step.x || 0), top:Number(step.y || 0), behavior:'auto'});
                  return JSON.stringify({ok:true, type, x:scrollX, y:scrollY});
                }
                if (type === 'setText') {
                  const el = q(step.selector); el.textContent = String(step.value == null ? '' : step.value);
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'setHtml') {
                  const el = q(step.selector); el.innerHTML = String(step.value == null ? '' : step.value);
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'setAttr') {
                  const el = q(step.selector); if (!step.name) throw new Error('attribute name is required'); el.setAttribute(String(step.name), String(step.value == null ? '' : step.value));
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'removeAttr') {
                  const el = q(step.selector); if (!step.name) throw new Error('attribute name is required'); el.removeAttribute(String(step.name));
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'setStyle') {
                  const el = q(step.selector); if (!step.name) throw new Error('style property name is required'); el.style.setProperty(String(step.name), String(step.value == null ? '' : step.value), step.important ? 'important' : '');
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'remove') {
                  const el = q(step.selector); el.remove();
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'focus') {
                  const el = q(step.selector); el.focus();
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'storageSet' || type === 'storageRemove') {
                  const store = step.store === 'session' ? sessionStorage : localStorage;
                  if (!step.key) throw new Error('storage key is required');
                  if (type === 'storageSet') store.setItem(String(step.key), String(step.value == null ? '' : step.value)); else store.removeItem(String(step.key));
                  return JSON.stringify({ok:true, type, store:step.store === 'session' ? 'session' : 'local'});
                }
                if (type === 'dispatch') {
                  const el = q(step.selector); if (!step.event) throw new Error('event name is required'); el.dispatchEvent(new Event(String(step.event), {bubbles:step.bubbles !== false, cancelable:true}));
                  return JSON.stringify({ok:true, type, selector:step.selector});
                }
                if (type === 'js') {
                  const result = (0, eval)(String(step.code || ''));
                  let display;
                  try { display = typeof result === 'string' ? result : JSON.stringify(result); }
                  catch (_) { display = String(result); }
                  return JSON.stringify({ok:true, type, result:display == null ? 'undefined' : display});
                }
                if (type === 'fileInput') throw new Error('file input requires manual user selection in WebView');
                throw new Error('unsupported DOM step: ' + type);
              } catch (e) {
                return JSON.stringify({ok:false,error:String(e),stack:e && e.stack ? String(e.stack) : ''});
              }
            })()
        """.replace("__STEP__", quotedStep);
        evalJson(script, callback);
    }

    public void selectorExists(String selector, JsonCallback callback) {
        String q = JSONObject.quote(selector == null ? "" : selector);
        evalJson("(() => { try { const el=document.querySelector(" + q + "); return JSON.stringify({ok:true,exists:!!el}); } catch(e) { return JSON.stringify({ok:false,error:String(e)}); } })()", callback);
    }

    public void inspectSelector(String selector, JsonCallback callback) {
        String q = JSONObject.quote(selector == null ? "" : selector);
        evalJson("""
            (() => {
              try {
                const el = document.querySelector(__Q__);
                if (!el) return JSON.stringify({ok:false,error:'selector not found'});
                return JSON.stringify({ok:true,text:(el.innerText || el.textContent || '').trim(),value:'value' in el ? String(el.value || '') : '',html:el.outerHTML.slice(0,12000)});
              } catch (e) { return JSON.stringify({ok:false,error:String(e)}); }
            })()
        """.replace("__Q__", q), callback);
    }

    private void evalJson(String script, JsonCallback callback) {
        evalRaw(script, value -> {
            try {
                String decoded = InspectorEngine.decodeJavascriptResult(value);
                if (decoded == null || decoded.equals("null") || decoded.isEmpty()) {
                    callback.onError("No automation result returned by page.");
                    return;
                }
                callback.onResult(new JSONObject(decoded));
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? "Could not decode automation result." : e.getMessage());
            }
        });
    }

    private void evalText(String script, TextCallback callback) {
        evalRaw(script, value -> {
            try {
                callback.onResult(InspectorEngine.decodeJavascriptResult(value));
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? "Could not decode JavaScript result." : e.getMessage());
            }
        });
    }

    private void evalRaw(String script, ValueCallback<String> callback) {
        webView.post(() -> {
            try {
                webView.evaluateJavascript(script, callback);
            } catch (Exception e) {
                callback.onReceiveValue(JSONObject.quote("ERROR: " + e.getMessage()));
            }
        });
    }
}
