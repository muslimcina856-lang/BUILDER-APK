package com.devscope.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Converts DevScope's recorded Action Script into real source projects for external toolchains.
 * No generated target is executed inside Android; DevScope exports source + dependency metadata.
 */
public final class CodeProjectGenerator {
    public static final String PYTHON = "Python / Selenium";
    public static final String JAVASCRIPT = "JavaScript / Selenium";
    public static final String TYPESCRIPT = "TypeScript / Selenium";
    public static final String JAVA = "Java / Selenium";
    public static final String KOTLIN = "Kotlin / Selenium";
    public static final String CSHARP = "C# (C+) / Selenium";
    public static final String GO = "Go / chromedp";
    public static final String C = "C / W3C WebDriver";
    public static final String CPP = "C++ / W3C WebDriver";
    public static final String RUST = "Rust / thirtyfour";
    public static final String RUBY = "Ruby / Selenium";
    public static final String PHP = "PHP / WebDriver";

    public static final String[] TARGETS = {
            PYTHON, JAVASCRIPT, TYPESCRIPT, JAVA, KOTLIN, CSHARP,
            GO, C, CPP, RUST, RUBY, PHP
    };

    private static final Set<String> BASE = setOf(
            "open", "back", "forward", "reload", "click", "input", "content", "select", "check",
            "submit", "scroll", "focus", "wait", "waitFor", "waitUrl", "assertExists", "assertText",
            "assertUrl", "extractText", "extractValue", "setText", "setHtml", "setAttr", "removeAttr",
            "setStyle", "remove", "storageSet", "storageRemove", "js", "dispatch"
    );
    private static final Set<String> SELENIUM_EXTRA = setOf("fileInput", "clearCookies");

    private CodeProjectGenerator() {}

    public static final class GeneratedProject {
        public final String target;
        public final String mainFile;
        public final String extension;
        public final String engine;
        public final LinkedHashMap<String, String> files;

        GeneratedProject(String target, String mainFile, String extension, String engine, LinkedHashMap<String, String> files) {
            this.target = target;
            this.mainFile = mainFile;
            this.extension = extension;
            this.engine = engine;
            this.files = files;
        }

        public String mainSource() {
            String value = files.get(mainFile);
            return value == null ? "" : value;
        }
    }

    public static GeneratedProject generate(String target, JSONObject flow) throws Exception {
        if (flow == null) throw new IllegalArgumentException("Action Script is required");
        JSONArray steps = flow.optJSONArray("steps");
        if (steps == null) throw new IllegalArgumentException("steps array is required");
        validateTarget(target, steps);

        LinkedHashMap<String, String> files = new LinkedHashMap<>();
        files.put("flow.json", flow.toString(2));
        files.put("README.md", readme(target, steps.length()));

        if (PYTHON.equals(target)) {
            files.put("requirements.txt", "selenium>=4.20,<5\n");
            files.put("main.py", python(steps));
            return new GeneratedProject(target, "main.py", ".py", "Selenium WebDriver", files);
        }
        if (JAVASCRIPT.equals(target)) {
            files.put("package.json", "{\n  \"name\": \"devscope-generated\",\n  \"private\": true,\n  \"type\": \"module\",\n  \"scripts\": {\"test\": \"node main.js\"},\n  \"dependencies\": {\"selenium-webdriver\": \"^4.29.0\"}\n}\n");
            files.put("main.js", javascript(steps, false));
            return new GeneratedProject(target, "main.js", ".js", "Selenium WebDriver", files);
        }
        if (TYPESCRIPT.equals(target)) {
            files.put("package.json", "{\n  \"name\": \"devscope-generated\",\n  \"private\": true,\n  \"type\": \"module\",\n  \"scripts\": {\"test\": \"tsx main.ts\"},\n  \"dependencies\": {\"selenium-webdriver\": \"^4.29.0\"},\n  \"devDependencies\": {\"tsx\": \"^4.19.0\", \"typescript\": \"^5.7.0\", \"@types/selenium-webdriver\": \"^4.1.28\"}\n}\n");
            files.put("tsconfig.json", "{\n  \"compilerOptions\": {\"target\": \"ES2022\", \"module\": \"NodeNext\", \"moduleResolution\": \"NodeNext\", \"strict\": true}\n}\n");
            files.put("main.ts", javascript(steps, true));
            return new GeneratedProject(target, "main.ts", ".ts", "Selenium WebDriver", files);
        }
        if (JAVA.equals(target)) {
            files.put("pom.xml", javaPom());
            files.put("src/main/java/DevScopeGenerated.java", javaSource(steps));
            return new GeneratedProject(target, "src/main/java/DevScopeGenerated.java", ".java", "Selenium WebDriver", files);
        }
        if (KOTLIN.equals(target)) {
            files.put("settings.gradle.kts", "rootProject.name = \"devscope-generated\"\n");
            files.put("build.gradle.kts", kotlinGradle());
            files.put("src/main/kotlin/Main.kt", kotlinSource(steps));
            return new GeneratedProject(target, "src/main/kotlin/Main.kt", ".kt", "Selenium WebDriver", files);
        }
        if (CSHARP.equals(target)) {
            files.put("DevScopeGenerated.csproj", csharpProject());
            files.put("Program.cs", csharpSource(steps));
            return new GeneratedProject(target, "Program.cs", ".cs", "Selenium WebDriver", files);
        }
        if (GO.equals(target)) {
            files.put("go.mod", "module devscope-generated\n\ngo 1.22\n\nrequire github.com/chromedp/chromedp v0.11.2\n");
            files.put("main.go", goSource(steps));
            return new GeneratedProject(target, "main.go", ".go", "chromedp", files);
        }
        if (CPP.equals(target)) {
            files.put("CMakeLists.txt", cppCmake());
            files.put("main.cpp", cppSource(steps));
            return new GeneratedProject(target, "main.cpp", ".cpp", "W3C WebDriver + libcurl", files);
        }
        if (C.equals(target)) {
            files.put("CMakeLists.txt", cCmake());
            files.put("main.c", cSource(steps));
            return new GeneratedProject(target, "main.c", ".c", "W3C WebDriver + libcurl", files);
        }
        if (RUST.equals(target)) {
            files.put("Cargo.toml", rustCargo());
            files.put("src/main.rs", rustSource(steps));
            return new GeneratedProject(target, "src/main.rs", ".rs", "thirtyfour WebDriver", files);
        }
        if (RUBY.equals(target)) {
            files.put("Gemfile", "source 'https://rubygems.org'\ngem 'selenium-webdriver', '~> 4.29'\n");
            files.put("main.rb", rubySource(steps));
            return new GeneratedProject(target, "main.rb", ".rb", "Selenium WebDriver", files);
        }
        if (PHP.equals(target)) {
            files.put("composer.json", "{\n  \"require\": {\"php-webdriver/webdriver\": \"^1.15\"}\n}\n");
            files.put("main.php", phpSource(steps));
            return new GeneratedProject(target, "main.php", ".php", "php-webdriver", files);
        }
        throw new IllegalArgumentException("Unknown target: " + target);
    }

    private static void validateTarget(String target, JSONArray steps) {
        Set<String> allowed = new LinkedHashSet<>(BASE);
        if (PYTHON.equals(target) || JAVASCRIPT.equals(target) || TYPESCRIPT.equals(target) || JAVA.equals(target)
                || KOTLIN.equals(target) || CSHARP.equals(target) || RUST.equals(target) || RUBY.equals(target) || PHP.equals(target)) {
            allowed.addAll(SELENIUM_EXTRA);
        }
        if (GO.equals(target)) allowed.add("fileInput");

        LinkedHashSet<String> bad = new LinkedHashSet<>();
        for (int i = 0; i < steps.length(); i++) {
            JSONObject s = steps.optJSONObject(i);
            if (s == null) { bad.add("<invalid step #" + (i + 1) + ">"); continue; }
            String type = s.optString("type", "");
            if (!allowed.contains(type)) bad.add(type.isEmpty() ? "<missing type>" : type);
            if (C.equals(target)) {
                if ("extractText".equals(type) || "extractValue".equals(type)) bad.add(type + "(C target)");
                if (s.optBoolean("secret", false)) bad.add("secret input(C target)");
                if (hasVariableReference(s)) bad.add("{{variable}} interpolation(C target)");
            }
            if (CPP.equals(target) && s.optBoolean("secret", false)) bad.add("secret input(C++ target)");
        }
        if (!bad.isEmpty()) {
            throw new IllegalArgumentException(target + " cannot faithfully generate these recorded actions: " + String.join(", ", bad));
        }
    }

    private static boolean hasVariableReference(JSONObject s) {
        String[] keys = {"selector", "value", "url", "text", "contains", "code", "name", "key"};
        for (String key : keys) if (s.optString(key, "").contains("{{")) return true;
        return false;
    }

    private static Set<String> setOf(String... values) {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        for (String v : values) s.add(v);
        return s;
    }

    private static String readme(String target, int count) {
        return "# DevScope Generated Test\n\n" +
                "Target: **" + target + "**\n\n" +
                "Generated from a real DevScope Android Action Script containing " + count + " recorded step(s).\n\n" +
                "## Important\n\n" +
                "- The Android app records the flow; this exported project runs on the target language/toolchain.\n" +
                "- Password/file-input steps use environment variables instead of embedding secrets.\n" +
                "- CAPTCHA or other human-verification challenges are not bypassed. Handle them manually or remove that step.\n" +
                "- `flow.json` is included as the canonical recording used to generate this project.\n" +
                "- Browser/driver/toolchain prerequisites are real external dependencies. DevScope v4 adds devscope/setup.* and verify.* bootstrap files when the project is generated.\n";
    }

    // ---------- Python / Selenium ----------
    private static String python(JSONArray steps) {
        StringBuilder b = new StringBuilder();
        b.append("import os, re, time\nfrom selenium import webdriver\nfrom selenium.webdriver.common.by import By\nfrom selenium.webdriver.support.ui import Select\n\n");
        b.append("driver = webdriver.Chrome()\nvars = {}\n\ndef resolve(v):\n    s = str(v)\n    return re.sub(r'\\{\\{([^}]+)\\}\\}', lambda m: vars.get(m.group(1), m.group(0)), s)\n\ndef el(css):\n    return driver.find_element(By.CSS_SELECTOR, resolve(css))\n\ndef wait_for(css, timeout_ms=10000):\n    end = time.time() + timeout_ms/1000\n    while time.time() < end:\n        if driver.find_elements(By.CSS_SELECTOR, resolve(css)): return\n        time.sleep(.2)\n    raise TimeoutError('selector not found: ' + resolve(css))\n\ntry:\n");
        for (int i = 0; i < steps.length(); i++) emitPython(b, steps.optJSONObject(i), i);
        b.append("    print('DEV//SCOPE PASS')\nfinally:\n    driver.quit()\n");
        return b.toString();
    }

    private static void emitPython(StringBuilder b, JSONObject s, int i) {
        String t = s.optString("type", ""); String p = "    "; String sel = py(s.optString("selector", ""));
        b.append(p).append("# step ").append(i + 1).append(" // ").append(t).append('\n');
        switch (t) {
            case "open" -> b.append(p).append("driver.get(resolve(").append(py(s.optString("url", ""))).append("))\n");
            case "back" -> b.append(p).append("driver.back()\n");
            case "forward" -> b.append(p).append("driver.forward()\n");
            case "reload" -> b.append(p).append("driver.refresh()\n");
            case "click" -> b.append(p).append("el(").append(sel).append(").click()\n");
            case "input", "content" -> {
                String value = secretExprPython(s, i);
                b.append(p).append("_e=el(").append(sel).append("); _e.clear(); _e.send_keys(resolve(").append(value).append("))\n");
            }
            case "select" -> b.append(p).append("Select(el(").append(sel).append(")).select_by_value(resolve(").append(py(s.optString("value", ""))).append("))\n");
            case "check" -> b.append(p).append("_e=el(").append(sel).append("); _want=").append(s.optBoolean("checked", true) ? "True" : "False").append("; _cur=_e.is_selected(); (_e.click() if _cur != _want else None)\n");
            case "submit" -> b.append(p).append("el(").append(sel).append(").submit()\n");
            case "scroll" -> b.append(p).append("driver.execute_script('window.scrollTo(arguments[0],arguments[1])', ").append(s.optInt("x", 0)).append(", ").append(s.optInt("y", 0)).append(")\n");
            case "focus" -> b.append(p).append("driver.execute_script('arguments[0].focus()', el(").append(sel).append("))\n");
            case "wait" -> b.append(p).append("time.sleep(").append(Math.max(0, s.optLong("ms", 1000)) / 1000.0).append(")\n");
            case "waitFor" -> b.append(p).append("wait_for(").append(sel).append(", ").append(timeoutMs(s)).append(")\n");
            case "waitUrl" -> b.append(p).append("_end=time.time()+").append(timeoutMs(s) / 1000.0).append("\n").append(p).append("while resolve(").append(py(s.optString("contains", ""))).append(") not in driver.current_url:\n").append(p).append("    if time.time()>_end: raise TimeoutError('URL wait timed out')\n").append(p).append("    time.sleep(.2)\n");
            case "assertExists" -> b.append(p).append("assert driver.find_elements(By.CSS_SELECTOR, resolve(").append(sel).append(")), 'missing selector: '+resolve(").append(sel).append(")\n");
            case "assertText" -> b.append(p).append("assert resolve(").append(py(expectedText(s))).append(") in el(").append(sel).append(").text, 'text assertion failed'\n");
            case "assertUrl" -> b.append(p).append("assert resolve(").append(py(s.optString("contains", ""))).append(") in driver.current_url, 'URL assertion failed'\n");
            case "extractText" -> b.append(p).append("vars[").append(py(storeAs(s))).append("] = el(").append(sel).append(").text\n");
            case "extractValue" -> b.append(p).append("vars[").append(py(storeAs(s))).append("] = el(").append(sel).append(").get_attribute('value') or ''\n");
            case "setText" -> b.append(p).append("driver.execute_script('arguments[0].textContent=arguments[1]', el(").append(sel).append("), resolve(").append(py(s.optString("value", ""))).append("))\n");
            case "setHtml" -> b.append(p).append("driver.execute_script('arguments[0].innerHTML=arguments[1]', el(").append(sel).append("), resolve(").append(py(s.optString("value", ""))).append("))\n");
            case "setAttr" -> b.append(p).append("driver.execute_script('arguments[0].setAttribute(arguments[1],arguments[2])', el(").append(sel).append("), ").append(py(s.optString("name", ""))).append(", resolve(").append(py(s.optString("value", ""))).append("))\n");
            case "removeAttr" -> b.append(p).append("driver.execute_script('arguments[0].removeAttribute(arguments[1])', el(").append(sel).append("), ").append(py(s.optString("name", ""))).append(")\n");
            case "setStyle" -> b.append(p).append("driver.execute_script('arguments[0].style.setProperty(arguments[1],arguments[2])', el(").append(sel).append("), ").append(py(s.optString("name", ""))).append(", resolve(").append(py(s.optString("value", ""))).append("))\n");
            case "remove" -> b.append(p).append("driver.execute_script('arguments[0].remove()', el(").append(sel).append("))\n");
            case "storageSet" -> b.append(p).append("driver.execute_script('window[arguments[0]].setItem(arguments[1],arguments[2])', ").append(py(storageName(s))).append(", ").append(py(s.optString("key", ""))).append(", resolve(").append(py(s.optString("value", ""))).append("))\n");
            case "storageRemove" -> b.append(p).append("driver.execute_script('window[arguments[0]].removeItem(arguments[1])', ").append(py(storageName(s))).append(", ").append(py(s.optString("key", ""))).append(")\n");
            case "js" -> b.append(p).append("driver.execute_script(resolve(").append(py(s.optString("code", s.optString("value", "")))).append("))\n");
            case "dispatch" -> b.append(p).append("driver.execute_script('arguments[0].dispatchEvent(new Event(arguments[1],{bubbles:true}))', el(").append(sel).append("), ").append(py(s.optString("event", "change"))).append(")\n");
            case "fileInput" -> b.append(p).append("el(").append(sel).append(").send_keys(os.environ[").append(py("DEVSCOPE_FILE_" + (i + 1))).append("])\n");
            case "clearCookies" -> b.append(p).append("driver.delete_all_cookies()\n");
        }
    }

    // ---------- JS / TS Selenium ----------
    private static String javascript(JSONArray steps, boolean ts) {
        StringBuilder b = new StringBuilder();
        b.append("import { Builder, By } from 'selenium-webdriver';\n");
        if (ts) b.append("import type { WebDriver, WebElement } from 'selenium-webdriver';\n");
        b.append("\nconst driver = await new Builder().forBrowser('chrome').build();\nconst vars = new Map();\nconst resolve = (v").append(ts ? ": unknown" : "").append(") => String(v ?? '').replace(/\\{\\{([^}]+)\\}\\}/g, (_, k) => vars.get(k) ?? `{{${k}}}`);\nconst el = async (css").append(ts ? ": string" : "").append(") => driver.findElement(By.css(resolve(css)));\nconst waitFor = async (css").append(ts ? ": string, ms = 10000" : ", ms = 10000").append(") => { const end=Date.now()+ms; while(Date.now()<end){ if((await driver.findElements(By.css(resolve(css)))).length) return; await driver.sleep(200); } throw new Error('selector not found: '+resolve(css)); };\n\ntry {\n");
        for (int i = 0; i < steps.length(); i++) emitJs(b, steps.optJSONObject(i), i);
        b.append("  console.log('DEV//SCOPE PASS');\n} finally {\n  await driver.quit();\n}\n");
        return b.toString();
    }

    private static void emitJs(StringBuilder b, JSONObject s, int i) {
        String t=s.optString("type",""); String p="  "; String sel=js(s.optString("selector",""));
        b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open" -> b.append(p).append("await driver.get(resolve(").append(js(s.optString("url",""))).append("));\n");
            case "back" -> b.append(p).append("await driver.navigate().back();\n");
            case "forward" -> b.append(p).append("await driver.navigate().forward();\n");
            case "reload" -> b.append(p).append("await driver.navigate().refresh();\n");
            case "click" -> b.append(p).append("await (await el(").append(sel).append(")).click();\n");
            case "input", "content" -> b.append(p).append("{ const e=await el(").append(sel).append("); await e.clear(); await e.sendKeys(resolve(").append(secretExprJs(s,i)).append(")); }\n");
            case "select" -> b.append(p).append("await driver.executeScript(`const e=arguments[0],v=arguments[1]; e.value=v; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));`, await el(").append(sel).append("), resolve(").append(js(s.optString("value",""))).append("));\n");
            case "check" -> b.append(p).append("{ const e=await el(").append(sel).append("); const cur=await e.isSelected(); if(cur !== ").append(s.optBoolean("checked",true)).append(") await e.click(); }\n");
            case "submit" -> b.append(p).append("await driver.executeScript('arguments[0].requestSubmit ? arguments[0].requestSubmit() : arguments[0].submit()', await el(").append(sel).append("));\n");
            case "scroll" -> b.append(p).append("await driver.executeScript('window.scrollTo(arguments[0],arguments[1])', ").append(s.optInt("x",0)).append(", ").append(s.optInt("y",0)).append(");\n");
            case "focus" -> b.append(p).append("await driver.executeScript('arguments[0].focus()', await el(").append(sel).append("));\n");
            case "wait" -> b.append(p).append("await driver.sleep(").append(Math.max(0,s.optLong("ms",1000))).append(");\n");
            case "waitFor" -> b.append(p).append("await waitFor(").append(sel).append(", ").append(timeoutMs(s)).append(");\n");
            case "waitUrl" -> b.append(p).append("{ const end=Date.now()+").append(timeoutMs(s)).append("; while(!(await driver.getCurrentUrl()).includes(resolve(").append(js(s.optString("contains",""))).append("))){ if(Date.now()>end) throw new Error('URL wait timed out'); await driver.sleep(200); } }\n");
            case "assertExists" -> b.append(p).append("if(!(await driver.findElements(By.css(resolve(").append(sel).append(")))).length) throw new Error('missing selector: '+resolve(").append(sel).append("));\n");
            case "assertText" -> b.append(p).append("if(!(await (await el(").append(sel).append(")).getText()).includes(resolve(").append(js(expectedText(s))).append("))) throw new Error('text assertion failed');\n");
            case "assertUrl" -> b.append(p).append("if(!(await driver.getCurrentUrl()).includes(resolve(").append(js(s.optString("contains",""))).append("))) throw new Error('URL assertion failed');\n");
            case "extractText" -> b.append(p).append("vars.set(").append(js(storeAs(s))).append(", await (await el(").append(sel).append(")).getText());\n");
            case "extractValue" -> b.append(p).append("vars.set(").append(js(storeAs(s))).append(", (await (await el(").append(sel).append(")).getAttribute('value')) ?? '');\n");
            case "setText" -> b.append(p).append("await driver.executeScript('arguments[0].textContent=arguments[1]', await el(").append(sel).append("), resolve(").append(js(s.optString("value",""))).append("));\n");
            case "setHtml" -> b.append(p).append("await driver.executeScript('arguments[0].innerHTML=arguments[1]', await el(").append(sel).append("), resolve(").append(js(s.optString("value",""))).append("));\n");
            case "setAttr" -> b.append(p).append("await driver.executeScript('arguments[0].setAttribute(arguments[1],arguments[2])', await el(").append(sel).append("), ").append(js(s.optString("name",""))).append(", resolve(").append(js(s.optString("value",""))).append("));\n");
            case "removeAttr" -> b.append(p).append("await driver.executeScript('arguments[0].removeAttribute(arguments[1])', await el(").append(sel).append("), ").append(js(s.optString("name",""))).append(");\n");
            case "setStyle" -> b.append(p).append("await driver.executeScript('arguments[0].style.setProperty(arguments[1],arguments[2])', await el(").append(sel).append("), ").append(js(s.optString("name",""))).append(", resolve(").append(js(s.optString("value",""))).append("));\n");
            case "remove" -> b.append(p).append("await driver.executeScript('arguments[0].remove()', await el(").append(sel).append("));\n");
            case "storageSet" -> b.append(p).append("await driver.executeScript('window[arguments[0]].setItem(arguments[1],arguments[2])', ").append(js(storageName(s))).append(", ").append(js(s.optString("key",""))).append(", resolve(").append(js(s.optString("value",""))).append("));\n");
            case "storageRemove" -> b.append(p).append("await driver.executeScript('window[arguments[0]].removeItem(arguments[1])', ").append(js(storageName(s))).append(", ").append(js(s.optString("key",""))).append(");\n");
            case "js" -> b.append(p).append("await driver.executeScript(resolve(").append(js(s.optString("code",s.optString("value","")))).append("));\n");
            case "dispatch" -> b.append(p).append("await driver.executeScript('arguments[0].dispatchEvent(new Event(arguments[1],{bubbles:true}))', await el(").append(sel).append("), ").append(js(s.optString("event","change"))).append(");\n");
            case "fileInput" -> b.append(p).append("await (await el(").append(sel).append(")).sendKeys(process.env[").append(js("DEVSCOPE_FILE_"+(i+1))).append("] ?? (()=>{throw new Error('missing file env')})());\n");
            case "clearCookies" -> b.append(p).append("await driver.manage().deleteAllCookies();\n");
        }
    }

    // ---------- Java Selenium ----------
    private static String javaPom(){
        return "<project xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd\">\n  <modelVersion>4.0.0</modelVersion><groupId>devscope</groupId><artifactId>generated</artifactId><version>1.0</version>\n  <properties><maven.compiler.source>17</maven.compiler.source><maven.compiler.target>17</maven.compiler.target></properties>\n  <dependencies><dependency><groupId>org.seleniumhq.selenium</groupId><artifactId>selenium-java</artifactId><version>4.29.0</version></dependency></dependencies>\n</project>\n";
    }
    private static String javaSource(JSONArray steps){
        StringBuilder b=new StringBuilder("import org.openqa.selenium.*;\nimport org.openqa.selenium.chrome.ChromeDriver;\nimport org.openqa.selenium.support.ui.Select;\nimport java.time.Duration;\nimport java.util.*;\n\npublic class DevScopeGenerated {\n  static WebDriver d; static Map<String,String> vars=new HashMap<>();\n  static String r(String s){ for(var e:vars.entrySet()) s=s.replace(\"{{\"+e.getKey()+\"}}\",e.getValue()); return s; }\n  static WebElement el(String css){ return d.findElement(By.cssSelector(r(css))); }\n  static void waitFor(String css,long ms)throws Exception{ long end=System.currentTimeMillis()+ms; while(System.currentTimeMillis()<end){ if(!d.findElements(By.cssSelector(r(css))).isEmpty()) return; Thread.sleep(200);} throw new RuntimeException(\"selector not found: \"+r(css)); }\n  public static void main(String[] a)throws Exception{ d=new ChromeDriver(); try{\n");
        for(int i=0;i<steps.length();i++) emitJava(b,steps.optJSONObject(i),i);
        b.append("    System.out.println(\"DEV//SCOPE PASS\");\n  } finally { d.quit(); } }\n}\n"); return b.toString();
    }
    private static void emitJava(StringBuilder b,JSONObject s,int i){
        String t=s.optString("type",""); String p="    "; String sel=j(s.optString("selector","")); b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append(p).append("d.get(r(").append(j(s.optString("url",""))).append("));\n"); case "back"->b.append(p).append("d.navigate().back();\n"); case "forward"->b.append(p).append("d.navigate().forward();\n"); case "reload"->b.append(p).append("d.navigate().refresh();\n");
            case "click"->b.append(p).append("el(").append(sel).append(").click();\n");
            case "input","content"->b.append(p).append("{var e=el(").append(sel).append("); e.clear(); e.sendKeys(r(").append(secretExprJava(s,i)).append("));}\n");
            case "select"->b.append(p).append("new Select(el(").append(sel).append(")).selectByValue(r(").append(j(s.optString("value",""))).append("));\n");
            case "check"->b.append(p).append("{var e=el(").append(sel).append("); if(e.isSelected()!=").append(s.optBoolean("checked",true)).append(") e.click();}\n");
            case "submit"->b.append(p).append("el(").append(sel).append(").submit();\n"); case "scroll"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"window.scrollTo(arguments[0],arguments[1])\", ").append(s.optInt("x",0)).append(", ").append(s.optInt("y",0)).append(");\n");
            case "focus"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"arguments[0].focus()\",el(").append(sel).append("));\n"); case "wait"->b.append(p).append("Thread.sleep(").append(Math.max(0,s.optLong("ms",1000))).append(");\n"); case "waitFor"->b.append(p).append("waitFor(").append(sel).append(",").append(timeoutMs(s)).append(");\n");
            case "waitUrl"->b.append(p).append("{long end=System.currentTimeMillis()+").append(timeoutMs(s)).append("; while(!d.getCurrentUrl().contains(r(").append(j(s.optString("contains",""))).append("))){if(System.currentTimeMillis()>end)throw new RuntimeException(\"URL wait timed out\");Thread.sleep(200);}}\n");
            case "assertExists"->b.append(p).append("if(d.findElements(By.cssSelector(r(").append(sel).append("))).isEmpty()) throw new RuntimeException(\"missing selector\");\n"); case "assertText"->b.append(p).append("if(!el(").append(sel).append(").getText().contains(r(").append(j(expectedText(s))).append("))) throw new RuntimeException(\"text assertion failed\");\n"); case "assertUrl"->b.append(p).append("if(!d.getCurrentUrl().contains(r(").append(j(s.optString("contains",""))).append("))) throw new RuntimeException(\"URL assertion failed\");\n");
            case "extractText"->b.append(p).append("vars.put(").append(j(storeAs(s))).append(",el(").append(sel).append(").getText());\n"); case "extractValue"->b.append(p).append("vars.put(").append(j(storeAs(s))).append(",Optional.ofNullable(el(").append(sel).append(").getAttribute(\"value\")).orElse(\"\"));\n");
            case "setText"->jsJava(b,p,"arguments[0].textContent=arguments[1]",sel,j(s.optString("value","")),true); case "setHtml"->jsJava(b,p,"arguments[0].innerHTML=arguments[1]",sel,j(s.optString("value","")),true);
            case "setAttr"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"arguments[0].setAttribute(arguments[1],arguments[2])\",el(").append(sel).append("),").append(j(s.optString("name",""))).append(",r(").append(j(s.optString("value",""))).append("));\n");
            case "removeAttr"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"arguments[0].removeAttribute(arguments[1])\",el(").append(sel).append("),").append(j(s.optString("name",""))).append(");\n");
            case "setStyle"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"arguments[0].style.setProperty(arguments[1],arguments[2])\",el(").append(sel).append("),").append(j(s.optString("name",""))).append(",r(").append(j(s.optString("value",""))).append("));\n");
            case "remove"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"arguments[0].remove()\",el(").append(sel).append("));\n");
            case "storageSet"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"window[arguments[0]].setItem(arguments[1],arguments[2])\",").append(j(storageName(s))).append(",").append(j(s.optString("key",""))).append(",r(").append(j(s.optString("value",""))).append("));\n");
            case "storageRemove"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"window[arguments[0]].removeItem(arguments[1])\",").append(j(storageName(s))).append(",").append(j(s.optString("key",""))).append(");\n");
            case "js"->b.append(p).append("((JavascriptExecutor)d).executeScript(r(").append(j(s.optString("code",s.optString("value","")))).append("));\n"); case "dispatch"->b.append(p).append("((JavascriptExecutor)d).executeScript(\"arguments[0].dispatchEvent(new Event(arguments[1],{bubbles:true}))\",el(").append(sel).append("),").append(j(s.optString("event","change"))).append(");\n");
            case "fileInput"->b.append(p).append("el(").append(sel).append(").sendKeys(Optional.ofNullable(System.getenv(").append(j("DEVSCOPE_FILE_"+(i+1))).append(")).orElseThrow());\n"); case "clearCookies"->b.append(p).append("d.manage().deleteAllCookies();\n");
        }
    }
    private static void jsJava(StringBuilder b,String p,String code,String sel,String value,boolean resolve){ b.append(p).append("((JavascriptExecutor)d).executeScript(").append(j(code)).append(",el(").append(sel).append("),").append(resolve?"r("+value+")":value).append(");\n"); }

    // ---------- Kotlin Selenium ----------
    private static String kotlinGradle(){ return "plugins { kotlin(\"jvm\") version \"2.0.21\" application }\nrepositories { mavenCentral() }\ndependencies { implementation(\"org.seleniumhq.selenium:selenium-java:4.29.0\") }\napplication { mainClass.set(\"MainKt\") }\nkotlin { jvmToolchain(17) }\n"; }
    private static String kotlinSource(JSONArray steps){
        StringBuilder b=new StringBuilder("import org.openqa.selenium.*\nimport org.openqa.selenium.chrome.ChromeDriver\nimport org.openqa.selenium.support.ui.Select\n\nval vars=mutableMapOf<String,String>()\nlateinit var d: WebDriver\nfun r(v:String):String { var x=v; vars.forEach{(k,z)->x=x.replace(\"{{$k}}\",z)}; return x }\nfun el(css:String)=d.findElement(By.cssSelector(r(css)))\nfun waitFor(css:String,ms:Long){val end=System.currentTimeMillis()+ms;while(System.currentTimeMillis()<end){if(d.findElements(By.cssSelector(r(css))).isNotEmpty())return;Thread.sleep(200)};error(\"selector not found: ${r(css)}\")}\nfun main(){d=ChromeDriver();try{\n");
        for(int i=0;i<steps.length();i++) emitKotlin(b,steps.optJSONObject(i),i); b.append("  println(\"DEV//SCOPE PASS\")\n} finally { d.quit() }}\n"); return b.toString();
    }
    private static void emitKotlin(StringBuilder b,JSONObject s,int i){
        String t=s.optString("type","");String p="  ";String sel=kt(s.optString("selector",""));b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append(p).append("d.get(r(").append(kt(s.optString("url",""))).append("))\n"); case "back"->b.append(p).append("d.navigate().back()\n"); case "forward"->b.append(p).append("d.navigate().forward()\n"); case "reload"->b.append(p).append("d.navigate().refresh()\n"); case "click"->b.append(p).append("el(").append(sel).append(").click()\n");
            case "input","content"->b.append(p).append("el(").append(sel).append(").apply{clear();sendKeys(r(").append(secretExprKotlin(s,i)).append("))}\n"); case "select"->b.append(p).append("Select(el(").append(sel).append(")).selectByValue(r(").append(kt(s.optString("value",""))).append("))\n"); case "check"->b.append(p).append("el(").append(sel).append(").let{if(it.isSelected!=").append(s.optBoolean("checked",true)).append(")it.click()}\n"); case "submit"->b.append(p).append("el(").append(sel).append(").submit()\n");
            case "scroll"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"window.scrollTo(arguments[0],arguments[1])\",").append(s.optInt("x",0)).append(",").append(s.optInt("y",0)).append(")\n"); case "focus"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"arguments[0].focus()\",el(").append(sel).append("))\n"); case "wait"->b.append(p).append("Thread.sleep(").append(Math.max(0,s.optLong("ms",1000))).append(")\n"); case "waitFor"->b.append(p).append("waitFor(").append(sel).append(",").append(timeoutMs(s)).append(")\n");
            case "waitUrl"->b.append(p).append("run{val end=System.currentTimeMillis()+").append(timeoutMs(s)).append(";while(!d.currentUrl.contains(r(").append(kt(s.optString("contains",""))).append("))){if(System.currentTimeMillis()>end)error(\"URL wait timed out\");Thread.sleep(200)}}\n"); case "assertExists"->b.append(p).append("check(d.findElements(By.cssSelector(r(").append(sel).append("))).isNotEmpty()){\"missing selector\"}\n"); case "assertText"->b.append(p).append("check(el(").append(sel).append(").text.contains(r(").append(kt(expectedText(s))).append("))){\"text assertion failed\"}\n"); case "assertUrl"->b.append(p).append("check(d.currentUrl.contains(r(").append(kt(s.optString("contains",""))).append("))){\"URL assertion failed\"}\n");
            case "extractText"->b.append(p).append("vars[").append(kt(storeAs(s))).append("]=el(").append(sel).append(").text\n"); case "extractValue"->b.append(p).append("vars[").append(kt(storeAs(s))).append("]=el(").append(sel).append(").getAttribute(\"value\")?:\"\"\n");
            case "setText"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"arguments[0].textContent=arguments[1]\",el(").append(sel).append("),r(").append(kt(s.optString("value",""))).append("))\n"); case "setHtml"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"arguments[0].innerHTML=arguments[1]\",el(").append(sel).append("),r(").append(kt(s.optString("value",""))).append("))\n");
            case "setAttr"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"arguments[0].setAttribute(arguments[1],arguments[2])\",el(").append(sel).append("),").append(kt(s.optString("name",""))).append(",r(").append(kt(s.optString("value",""))).append("))\n"); case "removeAttr"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"arguments[0].removeAttribute(arguments[1])\",el(").append(sel).append("),").append(kt(s.optString("name",""))).append(")\n"); case "setStyle"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"arguments[0].style.setProperty(arguments[1],arguments[2])\",el(").append(sel).append("),").append(kt(s.optString("name",""))).append(",r(").append(kt(s.optString("value",""))).append("))\n"); case "remove"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"arguments[0].remove()\",el(").append(sel).append("))\n");
            case "storageSet"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"window[arguments[0]].setItem(arguments[1],arguments[2])\",").append(kt(storageName(s))).append(",").append(kt(s.optString("key",""))).append(",r(").append(kt(s.optString("value",""))).append("))\n"); case "storageRemove"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"window[arguments[0]].removeItem(arguments[1])\",").append(kt(storageName(s))).append(",").append(kt(s.optString("key",""))).append(")\n"); case "js"->b.append(p).append("(d as JavascriptExecutor).executeScript(r(").append(kt(s.optString("code",s.optString("value","")))).append("))\n"); case "dispatch"->b.append(p).append("(d as JavascriptExecutor).executeScript(\"arguments[0].dispatchEvent(new Event(arguments[1],{bubbles:true}))\",el(").append(sel).append("),").append(kt(s.optString("event","change"))).append(")\n");
            case "fileInput"->b.append(p).append("el(").append(sel).append(").sendKeys(System.getenv(").append(kt("DEVSCOPE_FILE_"+(i+1))).append(")?:error(\"missing file env\"))\n"); case "clearCookies"->b.append(p).append("d.manage().deleteAllCookies()\n");
        }
    }

    // ---------- C# Selenium ----------
    private static String csharpProject(){return "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable></PropertyGroup><ItemGroup><PackageReference Include=\"Selenium.WebDriver\" Version=\"4.29.0\" /></ItemGroup></Project>\n";}
    private static String csharpSource(JSONArray steps){
        StringBuilder b=new StringBuilder("using OpenQA.Selenium;\nusing OpenQA.Selenium.Chrome;\nusing OpenQA.Selenium.Support.UI;\nusing System.Text.RegularExpressions;\n\nvar d=new ChromeDriver();\nvar vars=new Dictionary<string,string>();\nstring R(string s)=>Regex.Replace(s,@\"\\{\\{([^}]+)\\}\\}\",m=>vars.TryGetValue(m.Groups[1].Value,out var v)?v:m.Value);\nIWebElement El(string css)=>d.FindElement(By.CssSelector(R(css)));\nvoid WaitFor(string css,int ms=10000){var end=DateTime.UtcNow.AddMilliseconds(ms);while(DateTime.UtcNow<end){if(d.FindElements(By.CssSelector(R(css))).Count>0)return;Thread.Sleep(200);}throw new Exception(\"selector not found: \"+R(css));}\ntry{\n");
        for(int i=0;i<steps.length();i++) emitCs(b,steps.optJSONObject(i),i); b.append("  Console.WriteLine(\"DEV//SCOPE PASS\");\n} finally { d.Quit(); }\n"); return b.toString();
    }
    private static void emitCs(StringBuilder b,JSONObject s,int i){
        String t=s.optString("type","");String p="  ";String sel=cs(s.optString("selector",""));b.append(p).append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append(p).append("d.Navigate().GoToUrl(R(").append(cs(s.optString("url",""))).append("));\n"); case "back"->b.append(p).append("d.Navigate().Back();\n"); case "forward"->b.append(p).append("d.Navigate().Forward();\n"); case "reload"->b.append(p).append("d.Navigate().Refresh();\n"); case "click"->b.append(p).append("El(").append(sel).append(").Click();\n");
            case "input","content"->b.append(p).append("{var e=El(").append(sel).append(");e.Clear();e.SendKeys(R(").append(secretExprCs(s,i)).append("));}\n"); case "select"->b.append(p).append("new SelectElement(El(").append(sel).append(")).SelectByValue(R(").append(cs(s.optString("value",""))).append("));\n"); case "check"->b.append(p).append("{var e=El(").append(sel).append(");if(e.Selected!=").append(s.optBoolean("checked",true)?"true":"false").append(")e.Click();}\n"); case "submit"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].requestSubmit?arguments[0].requestSubmit():arguments[0].submit()\",El(").append(sel).append("));\n");
            case "scroll"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"window.scrollTo(arguments[0],arguments[1])\",").append(s.optInt("x",0)).append(",").append(s.optInt("y",0)).append(");\n"); case "focus"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].focus()\",El(").append(sel).append("));\n"); case "wait"->b.append(p).append("Thread.Sleep(").append(Math.max(0,s.optLong("ms",1000))).append(");\n"); case "waitFor"->b.append(p).append("WaitFor(").append(sel).append(",").append(timeoutMs(s)).append(");\n");
            case "waitUrl"->b.append(p).append("{var end=DateTime.UtcNow.AddMilliseconds(").append(timeoutMs(s)).append(");while(!d.Url.Contains(R(").append(cs(s.optString("contains",""))).append("))){if(DateTime.UtcNow>end)throw new Exception(\"URL wait timed out\");Thread.Sleep(200);}}\n"); case "assertExists"->b.append(p).append("if(d.FindElements(By.CssSelector(R(").append(sel).append("))).Count==0)throw new Exception(\"missing selector\");\n"); case "assertText"->b.append(p).append("if(!El(").append(sel).append(").Text.Contains(R(").append(cs(expectedText(s))).append(")))throw new Exception(\"text assertion failed\");\n"); case "assertUrl"->b.append(p).append("if(!d.Url.Contains(R(").append(cs(s.optString("contains",""))).append(")))throw new Exception(\"URL assertion failed\");\n");
            case "extractText"->b.append(p).append("vars[").append(cs(storeAs(s))).append("]=El(").append(sel).append(").Text;\n"); case "extractValue"->b.append(p).append("vars[").append(cs(storeAs(s))).append("]=El(").append(sel).append(").GetAttribute(\"value\")??\"\";\n");
            case "setText"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].textContent=arguments[1]\",El(").append(sel).append("),R(").append(cs(s.optString("value",""))).append("));\n"); case "setHtml"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].innerHTML=arguments[1]\",El(").append(sel).append("),R(").append(cs(s.optString("value",""))).append("));\n");
            case "setAttr"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].setAttribute(arguments[1],arguments[2])\",El(").append(sel).append("),").append(cs(s.optString("name",""))).append(",R(").append(cs(s.optString("value",""))).append("));\n"); case "removeAttr"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].removeAttribute(arguments[1])\",El(").append(sel).append("),").append(cs(s.optString("name",""))).append(");\n"); case "setStyle"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].style.setProperty(arguments[1],arguments[2])\",El(").append(sel).append("),").append(cs(s.optString("name",""))).append(",R(").append(cs(s.optString("value",""))).append("));\n"); case "remove"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].remove()\",El(").append(sel).append("));\n");
            case "storageSet"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"window[arguments[0]].setItem(arguments[1],arguments[2])\",").append(cs(storageName(s))).append(",").append(cs(s.optString("key",""))).append(",R(").append(cs(s.optString("value",""))).append("));\n"); case "storageRemove"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"window[arguments[0]].removeItem(arguments[1])\",").append(cs(storageName(s))).append(",").append(cs(s.optString("key",""))).append(");\n"); case "js"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(R(").append(cs(s.optString("code",s.optString("value","")))).append("));\n"); case "dispatch"->b.append(p).append("((IJavaScriptExecutor)d).ExecuteScript(\"arguments[0].dispatchEvent(new Event(arguments[1],{bubbles:true}))\",El(").append(sel).append("),").append(cs(s.optString("event","change"))).append(");\n");
            case "fileInput"->b.append(p).append("El(").append(sel).append(").SendKeys(Environment.GetEnvironmentVariable(").append(cs("DEVSCOPE_FILE_"+(i+1))).append(")??throw new Exception(\"missing file env\"));\n"); case "clearCookies"->b.append(p).append("d.Manage().Cookies.DeleteAllCookies();\n");
        }
    }

    // ---------- Go / chromedp ----------
    private static String goSource(JSONArray steps){
        StringBuilder b=new StringBuilder("package main\n\nimport(\"context\";\"fmt\";\"os\";\"strings\";\"time\";\"github.com/chromedp/chromedp\")\n\nvar vars=map[string]string{}\nfunc r(s string)string{for k,v:=range vars{s=strings.ReplaceAll(s,\"{{\"+k+\"}}\",v)};return s}\nfunc jsq(s string)string{return fmt.Sprintf(\"%q\",s)}\nfunc main(){ctx,cancel:=chromedp.NewContext(context.Background());defer cancel();var err error\n");
        for(int i=0;i<steps.length();i++) emitGo(b,steps.optJSONObject(i),i); b.append("if err!=nil{panic(err)};fmt.Println(\"DEV//SCOPE PASS\") }\n"); return b.toString();
    }
    private static void emitGo(StringBuilder b,JSONObject s,int i){
        String t=s.optString("type",""); String sel=go(s.optString("selector","")); b.append("// step ").append(i+1).append(" // ").append(t).append('\n');
        switch(t){
            case "open"->b.append("err=chromedp.Run(ctx,chromedp.Navigate(r(").append(go(s.optString("url",""))).append(")))\n"); case "back"->b.append("err=chromedp.Run(ctx,chromedp.NavigateBack())\n"); case "forward"->b.append("err=chromedp.Run(ctx,chromedp.Evaluate(`history.forward()`,nil))\n"); case "reload"->b.append("err=chromedp.Run(ctx,chromedp.Reload())\n");
            case "click"->b.append("err=chromedp.Run(ctx,chromedp.Click(r(").append(sel).append("),chromedp.ByQuery))\n"); case "input","content"->b.append("err=chromedp.Run(ctx,chromedp.SetValue(r(").append(sel).append("),r(").append(secretExprGo(s,i)).append("),chromedp.ByQuery))\n");
            case "select"->b.append("err=chromedp.Run(ctx,chromedp.SetValue(r(").append(sel).append("),r(").append(go(s.optString("value",""))).append("),chromedp.ByQuery),chromedp.Evaluate(`document.querySelector(`+jsq(r(").append(sel).append("))+`).dispatchEvent(new Event('change',{bubbles:true}))`,nil))\n");
            case "check"->b.append("err=chromedp.Run(ctx,chromedp.Evaluate(`(()=>{const e=document.querySelector(`+jsq(r(").append(sel).append("))+`);if(!e)throw Error('missing selector');if(e.checked!==").append(s.optBoolean("checked",true)).append(")e.click()})()`,nil))\n");
            case "submit"->b.append("err=chromedp.Run(ctx,chromedp.Evaluate(`(()=>{const e=document.querySelector(`+jsq(r(").append(sel).append("))+`);if(e.requestSubmit)e.requestSubmit();else e.submit()})()`,nil))\n"); case "scroll"->b.append("err=chromedp.Run(ctx,chromedp.Evaluate(`window.scrollTo(").append(s.optInt("x",0)).append(",").append(s.optInt("y",0)).append(")`,nil))\n"); case "focus"->b.append("err=chromedp.Run(ctx,chromedp.Focus(r(").append(sel).append("),chromedp.ByQuery))\n");
            case "wait"->b.append("time.Sleep(").append(Math.max(0,s.optLong("ms",1000))).append("*time.Millisecond)\n"); case "waitFor"->b.append("err=chromedp.Run(ctx,chromedp.WaitReady(r(").append(sel).append("),chromedp.ByQuery))\n");
            case "waitUrl"->b.append("{end:=time.Now().Add(").append(timeoutMs(s)).append("*time.Millisecond);for{var u string;err=chromedp.Run(ctx,chromedp.Location(&u));if err!=nil||strings.Contains(u,r(").append(go(s.optString("contains",""))).append(")){break};if time.Now().After(end){panic(\"URL wait timed out\")};time.Sleep(200*time.Millisecond)}}\n");
            case "assertExists"->b.append("{var n int;err=chromedp.Run(ctx,chromedp.Evaluate(`document.querySelectorAll(`+jsq(r(").append(sel).append("))+`).length`,&n));if err==nil&&n==0{panic(\"missing selector\")}}\n"); case "assertText"->b.append("{var x string;err=chromedp.Run(ctx,chromedp.Text(r(").append(sel).append("),&x,chromedp.ByQuery));if err==nil&&!strings.Contains(x,r(").append(go(expectedText(s))).append(")){panic(\"text assertion failed\")}}\n"); case "assertUrl"->b.append("{var u string;err=chromedp.Run(ctx,chromedp.Location(&u));if err==nil&&!strings.Contains(u,r(").append(go(s.optString("contains",""))).append(")){panic(\"URL assertion failed\")}}\n");
            case "extractText"->b.append("{var x string;err=chromedp.Run(ctx,chromedp.Text(r(").append(sel).append("),&x,chromedp.ByQuery));vars[").append(go(storeAs(s))).append("]=x}\n"); case "extractValue"->b.append("{var x string;err=chromedp.Run(ctx,chromedp.Value(r(").append(sel).append("),&x,chromedp.ByQuery));vars[").append(go(storeAs(s))).append("]=x}\n");
            case "setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch"->b.append("err=chromedp.Run(ctx,chromedp.Evaluate(r(").append(go(jsForStep(s))).append("),nil))\n");
            case "fileInput"->b.append("{p:=os.Getenv(").append(go("DEVSCOPE_FILE_"+(i+1))).append(");if p==\"\"{panic(\"missing file env\")};err=chromedp.Run(ctx,chromedp.SetUploadFiles(r(").append(sel).append("),[]string{p},chromedp.ByQuery))}\n");
        }
        b.append("if err!=nil{panic(err)}\n");
    }

    // ---------- C++ raw W3C WebDriver ----------
    private static String cppCmake(){return "cmake_minimum_required(VERSION 3.16)\nproject(devscope_generated CXX)\nset(CMAKE_CXX_STANDARD 17)\nfind_package(CURL REQUIRED)\nadd_executable(devscope main.cpp)\ntarget_link_libraries(devscope PRIVATE CURL::libcurl)\n";}
    private static String cppSource(JSONArray steps){
        StringBuilder b=new StringBuilder("#include <curl/curl.h>\n#include <chrono>\n#include <cstdlib>\n#include <iostream>\n#include <stdexcept>\n#include <string>\n#include <thread>\n#include <unordered_map>\n\nstatic std::string base=std::getenv(\"WEBDRIVER_URL\")?std::getenv(\"WEBDRIVER_URL\"):\"http://127.0.0.1:9515\"; static std::string sid; static std::unordered_map<std::string,std::string> vars;\nstatic size_t wr(char*p,size_t s,size_t n,void*u){((std::string*)u)->append(p,s*n);return s*n;}\nstatic std::string esc(const std::string&s){std::string o;for(char c:s){if(c=='\\\\'||c=='\\\"')o+='\\\\';if(c=='\\n'){o+=\"\\\\n\";continue;}o+=c;}return o;}\nstatic std::string req(const std::string&m,const std::string&path,const std::string&body=\"\"){CURL*c=curl_easy_init();std::string out;struct curl_slist*h=nullptr;h=curl_slist_append(h,\"Content-Type: application/json\");curl_easy_setopt(c,CURLOPT_URL,(base+path).c_str());curl_easy_setopt(c,CURLOPT_HTTPHEADER,h);curl_easy_setopt(c,CURLOPT_WRITEFUNCTION,wr);curl_easy_setopt(c,CURLOPT_WRITEDATA,&out);if(m!=\"GET\")curl_easy_setopt(c,CURLOPT_CUSTOMREQUEST,m.c_str());if(!body.empty())curl_easy_setopt(c,CURLOPT_POSTFIELDS,body.c_str());auto rc=curl_easy_perform(c);long st=0;curl_easy_getinfo(c,CURLINFO_RESPONSE_CODE,&st);curl_slist_free_all(h);curl_easy_cleanup(c);if(rc!=CURLE_OK||st>=400)throw std::runtime_error(\"WebDriver HTTP error: \"+out);return out;}\nstatic std::string findJsonString(const std::string&j,const std::string&k){auto p=j.find(\"\\\"\"+k+\"\\\"\");if(p==std::string::npos)return\"\";p=j.find(':',p);p=j.find('\\\"',p);auto e=j.find('\\\"',p+1);return j.substr(p+1,e-p-1);}\nstatic bool boolValue(const std::string&j){return j.find(\"\\\"value\\\":true\")!=std::string::npos;}\nstatic void start(){auto r=req(\"POST\",\"/session\",R\"({\"capabilities\":{\"alwaysMatch\":{\"browserName\":\"chrome\"}}})\");sid=findJsonString(r,\"sessionId\");if(sid.empty())throw std::runtime_error(\"No sessionId; is ChromeDriver running?\");}\nstatic void nav(const std::string&u){req(\"POST\",\"/session/\"+sid+\"/url\",\"{\\\"url\\\":\\\"\"+esc(u)+\"\\\"}\");}\nstatic std::string exec(const std::string&js){return req(\"POST\",\"/session/\"+sid+\"/execute/sync\",\"{\\\"script\\\":\\\"\"+esc(js)+\"\\\",\\\"args\\\":[]}\");}\nstatic std::string r(std::string s){for(auto&kv:vars){std::string k=\"{{\"+kv.first+\"}}\";size_t p=0;while((p=s.find(k,p))!=std::string::npos){s.replace(p,k.size(),kv.second);p+=kv.second.size();}}return s;}\nint main(){curl_global_init(CURL_GLOBAL_DEFAULT);start();try{\n");
        for(int i=0;i<steps.length();i++) emitCpp(b,steps.optJSONObject(i),i); b.append("std::cout<<\"DEV//SCOPE PASS\\n\";}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';req(\"DELETE\",\"/session/\"+sid);return 1;}req(\"DELETE\",\"/session/\"+sid);curl_global_cleanup();}\n");return b.toString();
    }
    private static void emitCpp(StringBuilder b,JSONObject s,int i){String t=s.optString("type","");b.append("// step ").append(i+1).append(" // ").append(t).append('\n');switch(t){
        case "open"->b.append("nav(r(").append(cpp(s.optString("url",""))).append("));\n");
        case "back"->b.append("req(\"POST\",\"/session/\"+sid+\"/back\",\"{}\");\n");
        case "forward"->b.append("req(\"POST\",\"/session/\"+sid+\"/forward\",\"{}\");\n");
        case "reload"->b.append("req(\"POST\",\"/session/\"+sid+\"/refresh\",\"{}\");\n");
        case "wait"->b.append("std::this_thread::sleep_for(std::chrono::milliseconds(").append(Math.max(0,s.optLong("ms",1000))).append("));\n");
        case "waitFor"->b.append("{auto end=std::chrono::steady_clock::now()+std::chrono::milliseconds(").append(timeoutMs(s)).append(");for(;;){if(boolValue(exec(r(").append(cpp("return !!document.querySelector(" + JSONObject.quote(s.optString("selector","")) + ");")).append("))))break;if(std::chrono::steady_clock::now()>end)throw std::runtime_error(\"selector wait timed out\");std::this_thread::sleep_for(std::chrono::milliseconds(200));}}\n");
        case "waitUrl"->b.append("{auto end=std::chrono::steady_clock::now()+std::chrono::milliseconds(").append(timeoutMs(s)).append(");for(;;){if(boolValue(exec(r(").append(cpp("return location.href.includes(" + JSONObject.quote(s.optString("contains","")) + ");")).append("))))break;if(std::chrono::steady_clock::now()>end)throw std::runtime_error(\"URL wait timed out\");std::this_thread::sleep_for(std::chrono::milliseconds(200));}}\n");
        case "extractText","extractValue"->b.append("{auto q=exec(r(").append(cpp(jsForStep(s))).append("));vars[").append(cpp(storeAs(s))).append("]=findJsonString(q,\"value\");}\n");
        default->b.append("exec(r(").append(cpp(jsForStep(s))).append("));\n");}}


    // ---------- C raw W3C WebDriver ----------
    private static String cCmake(){return "cmake_minimum_required(VERSION 3.16)\nproject(devscope_generated C)\nfind_package(CURL REQUIRED)\nadd_executable(devscope main.c)\ntarget_link_libraries(devscope PRIVATE CURL::libcurl)\n";}
    private static String cSource(JSONArray steps){
        StringBuilder b=new StringBuilder("#include <curl/curl.h>\n#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <unistd.h>\n#define BUF 65536\nstatic char base[512]=\"http://127.0.0.1:9515\",sid[256]=\"\";\ntypedef struct{char*b;size_t n;}Out; static size_t wr(char*p,size_t s,size_t n,void*u){Out*o=u;size_t z=s*n;if(o->n+z<BUF-1){memcpy(o->b+o->n,p,z);o->n+=z;o->b[o->n]=0;}return z;}\nstatic void esc(const char*in,char*out,size_t cap){size_t j=0;for(size_t i=0;in[i]&&j+2<cap;i++){char c=in[i];if(c=='\\\\'||c=='\\\"')out[j++]='\\\\';if(c=='\\n'){out[j++]='\\\\';out[j++]='n';}else out[j++]=c;}out[j]=0;}\nstatic int req(const char*m,const char*path,const char*body,char*out){CURL*c=curl_easy_init();char url[1024];snprintf(url,sizeof(url),\"%s%s\",base,path);Out o={out,0};struct curl_slist*h=NULL;h=curl_slist_append(h,\"Content-Type: application/json\");curl_easy_setopt(c,CURLOPT_URL,url);curl_easy_setopt(c,CURLOPT_HTTPHEADER,h);curl_easy_setopt(c,CURLOPT_WRITEFUNCTION,wr);curl_easy_setopt(c,CURLOPT_WRITEDATA,&o);if(strcmp(m,\"GET\"))curl_easy_setopt(c,CURLOPT_CUSTOMREQUEST,m);if(body&&*body)curl_easy_setopt(c,CURLOPT_POSTFIELDS,body);CURLcode rc=curl_easy_perform(c);long st=0;curl_easy_getinfo(c,CURLINFO_RESPONSE_CODE,&st);curl_slist_free_all(h);curl_easy_cleanup(c);return rc==CURLE_OK&&st<400?0:-1;}\nstatic void findstr(const char*j,const char*k,char*out,size_t cap){char pat[128];snprintf(pat,sizeof(pat),\"\\\"%s\\\"\",k);char*p=strstr((char*)j,pat);if(!p){*out=0;return;}p=strchr(p,':');p=strchr(p,'\\\"');char*e=strchr(p+1,'\\\"');size_t n=e?(size_t)(e-p-1):0;if(n>=cap)n=cap-1;memcpy(out,p+1,n);out[n]=0;}\nstatic void execjs(const char*js){char e[32768],body[36000],out[BUF];esc(js,e,sizeof(e));snprintf(body,sizeof(body),\"{\\\"script\\\":\\\"%s\\\",\\\"args\\\":[]}\",e);char path[512];snprintf(path,sizeof(path),\"/session/%s/execute/sync\",sid);if(req(\"POST\",path,body,out))exit(2);}\nstatic int execbool(const char*js){char e[32768],body[36000],out[BUF];esc(js,e,sizeof(e));snprintf(body,sizeof(body),\"{\\\"script\\\":\\\"%s\\\",\\\"args\\\":[]}\",e);char path[512];snprintf(path,sizeof(path),\"/session/%s/execute/sync\",sid);if(req(\"POST\",path,body,out))return 0;return strstr(out,\"\\\"value\\\":true\")!=NULL;}\nint main(){const char*env=getenv(\"WEBDRIVER_URL\");if(env)snprintf(base,sizeof(base),\"%s\",env);curl_global_init(CURL_GLOBAL_DEFAULT);char out[BUF];if(req(\"POST\",\"/session\",\"{\\\"capabilities\\\":{\\\"alwaysMatch\\\":{\\\"browserName\\\":\\\"chrome\\\"}}}\",out)){fprintf(stderr,\"Cannot create WebDriver session\\n\");return 1;}findstr(out,\"sessionId\",sid,sizeof(sid));if(!*sid){fprintf(stderr,\"No sessionId\\n\");return 1;}char path[512],body[36000],e[32768];\n");
        for(int i=0;i<steps.length();i++) emitC(b,steps.optJSONObject(i),i); b.append("snprintf(path,sizeof(path),\"/session/%s\",sid);req(\"DELETE\",path,\"\",out);curl_global_cleanup();puts(\"DEV//SCOPE PASS\");return 0;}\n");return b.toString();
    }
    private static void emitC(StringBuilder b,JSONObject s,int i){String t=s.optString("type","");b.append("/* step ").append(i+1).append(" // ").append(t).append(" */\n");switch(t){
        case "open"->b.append("esc(").append(c(s.optString("url",""))).append(",e,sizeof(e));snprintf(body,sizeof(body),\"{\\\"url\\\":\\\"%s\\\"}\",e);snprintf(path,sizeof(path),\"/session/%s/url\",sid);if(req(\"POST\",path,body,out))return 2;\n");
        case "back","forward","reload"->{String endpoint="reload".equals(t)?"refresh":t;b.append("snprintf(path,sizeof(path),\"/session/%s/").append(endpoint).append("\",sid);if(req(\"POST\",path,\"{}\",out))return 2;\n");}
        case "wait"->b.append("usleep(").append(Math.max(0,s.optLong("ms",1000))*1000L).append(");\n");
        case "waitFor"->b.append("{long left=").append(timeoutMs(s)).append(";while(!execbool(").append(c("return !!document.querySelector(" + JSONObject.quote(s.optString("selector","")) + ");")).append(")){if(left<=0){fprintf(stderr,\"selector wait timed out\\n\");return 3;}usleep(200000);left-=200;}}\n");
        case "waitUrl"->b.append("{long left=").append(timeoutMs(s)).append(";while(!execbool(").append(c("return location.href.includes(" + JSONObject.quote(s.optString("contains","")) + ");")).append(")){if(left<=0){fprintf(stderr,\"URL wait timed out\\n\");return 3;}usleep(200000);left-=200;}}\n");
        default->b.append("execjs(").append(c(jsForStep(s))).append(");\n");}}


    // ---------- Rust thirtyfour ----------
    private static String rustCargo(){return "[package]\nname=\"devscope-generated\"\nversion=\"0.1.0\"\nedition=\"2021\"\n[dependencies]\nthirtyfour=\"0.35\"\ntokio={version=\"1\",features=[\"full\"]}\nregex=\"1\"\n";}
    private static String rustSource(JSONArray steps){
        StringBuilder b=new StringBuilder("use std::{collections::HashMap,env,time::Duration};\nuse thirtyfour::prelude::*;\nuse tokio::time::sleep;\nfn r(mut s:String,vars:&HashMap<String,String>)->String{for(k,v)in vars{s=s.replace(&format!(\"{{{{{}}}}}\",k),v);}s}\n#[tokio::main] async fn main()->WebDriverResult<()> {let caps=DesiredCapabilities::chrome();let d=WebDriver::new(\"http://localhost:4444\",caps).await?;let mut vars=HashMap::<String,String>::new();\n");
        for(int i=0;i<steps.length();i++) emitRust(b,steps.optJSONObject(i),i); b.append("println!(\"DEV//SCOPE PASS\");d.quit().await?;Ok(())}\n");return b.toString();
    }
    private static void emitRust(StringBuilder b,JSONObject s,int i){String t=s.optString("type","");String sel=rust(s.optString("selector",""));b.append("// step ").append(i+1).append(" // ").append(t).append('\n');switch(t){
        case "open"->b.append("d.goto(r(").append(rust(s.optString("url",""))).append(".to_string(),&vars)).await?;\n");case "back"->b.append("d.back().await?;\n");case "forward"->b.append("d.forward().await?;\n");case "reload"->b.append("d.refresh().await?;\n");case "click"->b.append("d.find(By::Css(r(").append(sel).append(".to_string(),&vars))).await?.click().await?;\n");
        case "input","content"->b.append("{let e=d.find(By::Css(r(").append(sel).append(".to_string(),&vars))).await?;e.clear().await?;e.send_keys(r(").append(secretExprRust(s,i)).append(".to_string(),&vars)).await?;}\n"); case "select"->b.append("d.execute(\"const e=document.querySelector(arguments[0]);e.value=arguments[1];e.dispatchEvent(new Event('change',{bubbles:true}));\",vec![r(").append(sel).append(".to_string(),&vars).into(),r(").append(rust(s.optString("value",""))).append(".to_string(),&vars).into()]).await?;\n");
        case "check"->b.append("d.execute(\"const e=document.querySelector(arguments[0]);if(e.checked!==arguments[1])e.click();\",vec![r(").append(sel).append(".to_string(),&vars).into(),").append(s.optBoolean("checked",true)?"true":"false").append(".into()]).await?;\n"); case "submit"->b.append("d.execute(\"const e=document.querySelector(arguments[0]);if(e.requestSubmit)e.requestSubmit();else e.submit();\",vec![r(").append(sel).append(".to_string(),&vars).into()]).await?;\n");
        case "scroll"->b.append("d.execute(\"window.scrollTo(arguments[0],arguments[1])\",vec![").append(s.optInt("x",0)).append(".into(),").append(s.optInt("y",0)).append(".into()]).await?;\n"); case "focus"->b.append("d.execute(\"document.querySelector(arguments[0]).focus()\",vec![r(").append(sel).append(".to_string(),&vars).into()]).await?;\n"); case "wait"->b.append("sleep(Duration::from_millis(").append(Math.max(0,s.optLong("ms",1000))).append(")).await;\n");
        case "waitFor"->b.append("{let end=std::time::Instant::now()+Duration::from_millis(").append(timeoutMs(s)).append(");loop{if !d.find_all(By::Css(r(").append(sel).append(".to_string(),&vars))).await?.is_empty(){break}if std::time::Instant::now()>end{panic!(\"selector wait timed out\")}sleep(Duration::from_millis(200)).await;}}\n"); case "waitUrl"->b.append("{let end=std::time::Instant::now()+Duration::from_millis(").append(timeoutMs(s)).append(");loop{if d.current_url().await?.as_str().contains(&r(").append(rust(s.optString("contains",""))).append(".to_string(),&vars)){break}if std::time::Instant::now()>end{panic!(\"URL wait timed out\")}sleep(Duration::from_millis(200)).await;}}\n");
        case "assertExists"->b.append("if d.find_all(By::Css(r(").append(sel).append(".to_string(),&vars))).await?.is_empty(){panic!(\"missing selector\")};\n"); case "assertText"->b.append("if !d.find(By::Css(r(").append(sel).append(".to_string(),&vars))).await?.text().await?.contains(&r(").append(rust(expectedText(s))).append(".to_string(),&vars)){panic!(\"text assertion failed\")};\n"); case "assertUrl"->b.append("if !d.current_url().await?.as_str().contains(&r(").append(rust(s.optString("contains",""))).append(".to_string(),&vars)){panic!(\"URL assertion failed\")};\n");
        case "extractText"->b.append("vars.insert(").append(rust(storeAs(s))).append(".to_string(),d.find(By::Css(r(").append(sel).append(".to_string(),&vars))).await?.text().await?);\n"); case "extractValue"->b.append("vars.insert(").append(rust(storeAs(s))).append(".to_string(),d.find(By::Css(r(").append(sel).append(".to_string(),&vars))).await?.attr(\"value\").await?.unwrap_or_default());\n");
        case "setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch"->b.append("d.execute(&r(").append(rust(jsForStep(s))).append(".to_string(),&vars),vec![]).await?;\n");
        case "fileInput"->b.append("d.find(By::Css(r(").append(sel).append(".to_string(),&vars))).await?.send_keys(env::var(").append(rust("DEVSCOPE_FILE_"+(i+1))).append(").expect(\"missing file env\")).await?;\n"); case "clearCookies"->b.append("d.delete_all_cookies().await?;\n");
    }}

    // ---------- Ruby Selenium ----------
    private static String rubySource(JSONArray steps){
        StringBuilder b=new StringBuilder("require 'selenium-webdriver'\nd=Selenium::WebDriver.for :chrome\nvars={}\ndef r(s,vars); vars.each{|k,v|s=s.gsub(\"{{#{k}}}\",v)};s;end\ndef el(d,css,vars);d.find_element(css:r(css,vars));end\nbegin\n");
        for(int i=0;i<steps.length();i++) emitRuby(b,steps.optJSONObject(i),i); b.append("  puts 'DEV//SCOPE PASS'\nensure\n  d.quit\nend\n");return b.toString();
    }
    private static void emitRuby(StringBuilder b,JSONObject s,int i){String t=s.optString("type","");String p="  ";String sel=rb(s.optString("selector",""));b.append(p).append("# step ").append(i+1).append(" // ").append(t).append('\n');switch(t){
        case "open"->b.append(p).append("d.navigate.to r(").append(rb(s.optString("url",""))).append(",vars)\n");case "back"->b.append(p).append("d.navigate.back\n");case "forward"->b.append(p).append("d.navigate.forward\n");case "reload"->b.append(p).append("d.navigate.refresh\n");case "click"->b.append(p).append("el(d,").append(sel).append(",vars).click\n");
        case "input","content"->b.append(p).append("e=el(d,").append(sel).append(",vars);e.clear;e.send_keys r(").append(secretExprRuby(s,i)).append(",vars)\n"); case "select"->b.append(p).append("Selenium::WebDriver::Support::Select.new(el(d,").append(sel).append(",vars)).select_by(:value,r(").append(rb(s.optString("value",""))).append(",vars))\n"); case "check"->b.append(p).append("e=el(d,").append(sel).append(",vars);e.click if e.selected? != ").append(s.optBoolean("checked",true)).append("\n"); case "submit"->b.append(p).append("el(d,").append(sel).append(",vars).submit\n");
        case "scroll"->b.append(p).append("d.execute_script('window.scrollTo(arguments[0],arguments[1])',").append(s.optInt("x",0)).append(",").append(s.optInt("y",0)).append(")\n"); case "focus"->b.append(p).append("d.execute_script('arguments[0].focus()',el(d,").append(sel).append(",vars))\n");case "wait"->b.append(p).append("sleep ").append(Math.max(0,s.optLong("ms",1000))/1000.0).append("\n");case "waitFor"->b.append(p).append("Selenium::WebDriver::Wait.new(timeout:").append(timeoutMs(s)/1000.0).append(").until{d.find_elements(css:r(").append(sel).append(",vars)).any?}\n");
        case "waitUrl"->b.append(p).append("Selenium::WebDriver::Wait.new(timeout:").append(timeoutMs(s)/1000.0).append(").until{d.current_url.include?(r(").append(rb(s.optString("contains",""))).append(",vars))}\n");case "assertExists"->b.append(p).append("raise 'missing selector' if d.find_elements(css:r(").append(sel).append(",vars)).empty?\n");case "assertText"->b.append(p).append("raise 'text assertion failed' unless el(d,").append(sel).append(",vars).text.include?(r(").append(rb(expectedText(s))).append(",vars))\n");case "assertUrl"->b.append(p).append("raise 'URL assertion failed' unless d.current_url.include?(r(").append(rb(s.optString("contains",""))).append(",vars))\n");
        case "extractText"->b.append(p).append("vars[").append(rb(storeAs(s))).append("]=el(d,").append(sel).append(",vars).text\n");case "extractValue"->b.append(p).append("vars[").append(rb(storeAs(s))).append("]=el(d,").append(sel).append(",vars).attribute('value').to_s\n");
        case "setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch"->b.append(p).append("d.execute_script(r(").append(rb(jsForStep(s))).append(",vars))\n");
        case "fileInput"->b.append(p).append("el(d,").append(sel).append(",vars).send_keys ENV.fetch(").append(rb("DEVSCOPE_FILE_"+(i+1))).append(")\n");case "clearCookies"->b.append(p).append("d.manage.delete_all_cookies\n");
    }}

    // ---------- PHP php-webdriver ----------
    private static String phpSource(JSONArray steps){
        StringBuilder b=new StringBuilder("<?php\nrequire __DIR__.'/vendor/autoload.php';\nuse Facebook\\WebDriver\\Remote\\RemoteWebDriver;\nuse Facebook\\WebDriver\\Remote\\DesiredCapabilities;\nuse Facebook\\WebDriver\\WebDriverBy;\nuse Facebook\\WebDriver\\WebDriverSelect;\n$d=RemoteWebDriver::create(getenv('WEBDRIVER_URL')?:'http://localhost:4444',DesiredCapabilities::chrome());$vars=[];\nfunction r($s,&$vars){foreach($vars as $k=>$v)$s=str_replace('{{'.$k.'}}',$v,$s);return $s;}\nfunction el($d,$css,&$vars){return $d->findElement(WebDriverBy::cssSelector(r($css,$vars)));}\ntry{\n");
        for(int i=0;i<steps.length();i++) emitPhp(b,steps.optJSONObject(i),i); b.append("echo \"DEV//SCOPE PASS\\n\";}finally{$d->quit();}\n");return b.toString();
    }
    private static void emitPhp(StringBuilder b,JSONObject s,int i){String t=s.optString("type","");String sel=php(s.optString("selector",""));b.append("// step ").append(i+1).append(" // ").append(t).append('\n');switch(t){
        case "open"->b.append("$d->get(r(").append(php(s.optString("url",""))).append(",$vars));\n");case "back"->b.append("$d->navigate()->back();\n");case "forward"->b.append("$d->navigate()->forward();\n");case "reload"->b.append("$d->navigate()->refresh();\n");case "click"->b.append("el($d,").append(sel).append(",$vars)->click();\n");
        case "input","content"->b.append("$e=el($d,").append(sel).append(",$vars);$e->clear();$e->sendKeys(r(").append(secretExprPhp(s,i)).append(",$vars));\n");case "select"->b.append("(new WebDriverSelect(el($d,").append(sel).append(",$vars)))->selectByValue(r(").append(php(s.optString("value",""))).append(",$vars));\n");case "check"->b.append("$e=el($d,").append(sel).append(",$vars);if($e->isSelected()!==").append(s.optBoolean("checked",true)?"true":"false").append(")$e->click();\n");case "submit"->b.append("el($d,").append(sel).append(",$vars)->submit();\n");
        case "scroll"->b.append("$d->executeScript('window.scrollTo(arguments[0],arguments[1])',[").append(s.optInt("x",0)).append(",").append(s.optInt("y",0)).append("]);\n");case "focus"->b.append("$d->executeScript('arguments[0].focus()',[el($d,").append(sel).append(",$vars)]);\n");case "wait"->b.append("usleep(").append(Math.max(0,s.optLong("ms",1000))*1000L).append(");\n");case "waitFor"->b.append("$d->wait(").append(Math.max(1,timeoutMs(s)/1000)).append(",200)->until(fn()=>count($d->findElements(WebDriverBy::cssSelector(r(").append(sel).append(",$vars))))>0);\n");
        case "waitUrl"->b.append("$d->wait(").append(Math.max(1,timeoutMs(s)/1000)).append(",200)->until(fn()=>str_contains($d->getCurrentURL(),r(").append(php(s.optString("contains",""))).append(",$vars)));\n");case "assertExists"->b.append("if(!count($d->findElements(WebDriverBy::cssSelector(r(").append(sel).append(",$vars)))))throw new Exception('missing selector');\n");case "assertText"->b.append("if(!str_contains(el($d,").append(sel).append(",$vars)->getText(),r(").append(php(expectedText(s))).append(",$vars)))throw new Exception('text assertion failed');\n");case "assertUrl"->b.append("if(!str_contains($d->getCurrentURL(),r(").append(php(s.optString("contains",""))).append(",$vars)))throw new Exception('URL assertion failed');\n");
        case "extractText"->b.append("$vars[").append(php(storeAs(s))).append("]=el($d,").append(sel).append(",$vars)->getText();\n");case "extractValue"->b.append("$vars[").append(php(storeAs(s))).append("]=el($d,").append(sel).append(",$vars)->getAttribute('value')??'';\n");
        case "setText","setHtml","setAttr","removeAttr","setStyle","remove","storageSet","storageRemove","js","dispatch"->b.append("$d->executeScript(r(").append(php(jsForStep(s))).append(",$vars));\n");
        case "fileInput"->b.append("el($d,").append(sel).append(",$vars)->sendKeys(getenv(").append(php("DEVSCOPE_FILE_"+(i+1))).append(")?:throw new Exception('missing file env'));\n");case "clearCookies"->b.append("$d->manage()->deleteAllCookies();\n");
    }}

    // ---------- Shared JS expression used by raw/compact targets ----------
    private static String jsForStep(JSONObject s){
        String t=s.optString("type",""); String sel=s.optString("selector",""); String q=JSONObject.quote(sel); String v=JSONObject.quote(s.optString("value","")); String name=JSONObject.quote(s.optString("name",""));
        return switch(t){
            case "click" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.click();return true})()";
            case "input" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.value="+v+";e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return true})()";
            case "content" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.textContent="+v+";e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return true})()";
            case "select" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.value="+v+";e.dispatchEvent(new Event('change',{bubbles:true}));return true})()";
            case "check" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');if(e.checked!=="+s.optBoolean("checked",true)+")e.click();return true})()";
            case "submit" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');if(e.requestSubmit)e.requestSubmit();else e.submit();return true})()";
            case "scroll" -> "window.scrollTo("+s.optInt("x",0)+","+s.optInt("y",0)+");true";
            case "focus" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.focus();return true})()";
            case "waitFor" -> "(()=>{if(!document.querySelector("+q+"))throw Error('selector not found');return true})()";
            case "waitUrl" -> "(()=>{if(!location.href.includes("+JSONObject.quote(s.optString("contains",""))+"))throw Error('URL assertion failed');return true})()";
            case "assertExists" -> "(()=>{if(!document.querySelector("+q+"))throw Error('missing selector');return true})()";
            case "assertText" -> "(()=>{const e=document.querySelector("+q+");if(!e||!String(e.innerText||e.textContent||'').includes("+JSONObject.quote(expectedText(s))+"))throw Error('text assertion failed');return true})()";
            case "assertUrl" -> "(()=>{if(!location.href.includes("+JSONObject.quote(s.optString("contains",""))+"))throw Error('URL assertion failed');return true})()";
            case "extractText" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');return String(e.innerText||e.textContent||'')})()";
            case "extractValue" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');return String(e.value??'')})()";
            case "setText" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.textContent="+v+";return true})()";
            case "setHtml" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.innerHTML="+v+";return true})()";
            case "setAttr" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.setAttribute("+name+","+v+");return true})()";
            case "removeAttr" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.removeAttribute("+name+");return true})()";
            case "setStyle" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.style.setProperty("+name+","+v+");return true})()";
            case "remove" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.remove();return true})()";
            case "storageSet" -> "window["+JSONObject.quote(storageName(s))+"].setItem("+JSONObject.quote(s.optString("key",""))+","+v+");true";
            case "storageRemove" -> "window["+JSONObject.quote(storageName(s))+"].removeItem("+JSONObject.quote(s.optString("key",""))+");true";
            case "js" -> s.optString("code",s.optString("value",""));
            case "dispatch" -> "(()=>{const e=document.querySelector("+q+");if(!e)throw Error('missing selector');e.dispatchEvent(new Event("+JSONObject.quote(s.optString("event","change"))+",{bubbles:true}));return true})()";
            default -> "true";
        };
    }

    private static long timeoutMs(JSONObject s) { return s.optLong("timeoutMs", s.optLong("timeout", 10000)); }
    private static String storeAs(JSONObject s) {
        String v = s.optString("storeAs", s.optString("var", "value"));
        return v == null || v.trim().isEmpty() ? "value" : v.trim();
    }
    private static String expectedText(JSONObject s) { return s.optString("contains", s.optString("text", "")); }

    private static String storageName(JSONObject s){ String raw=s.optString("store", s.optString("storage", s.optString("area","local"))); return ("session".equals(raw) || "sessionStorage".equals(raw)) ? "sessionStorage" : "localStorage"; }

    // Secret values are never embedded from recorder output.
    private static String secretExprPython(JSONObject s,int i){return s.optBoolean("secret",false)?"os.environ["+py("DEVSCOPE_SECRET_"+(i+1))+"]":py(s.optString("value",""));}
    private static String secretExprJs(JSONObject s,int i){return s.optBoolean("secret",false)?"(process.env["+js("DEVSCOPE_SECRET_"+(i+1))+"] ?? (()=>{throw new Error('missing secret env')})())":js(s.optString("value",""));}
    private static String secretExprJava(JSONObject s,int i){return s.optBoolean("secret",false)?"Optional.ofNullable(System.getenv("+j("DEVSCOPE_SECRET_"+(i+1))+")).orElseThrow()":j(s.optString("value",""));}
    private static String secretExprKotlin(JSONObject s,int i){return s.optBoolean("secret",false)?"System.getenv("+kt("DEVSCOPE_SECRET_"+(i+1))+")?:error(\"missing secret env\")":kt(s.optString("value",""));}
    private static String secretExprCs(JSONObject s,int i){return s.optBoolean("secret",false)?"Environment.GetEnvironmentVariable("+cs("DEVSCOPE_SECRET_"+(i+1))+")??throw new Exception(\"missing secret env\")":cs(s.optString("value",""));}
    private static String secretExprGo(JSONObject s,int i){return s.optBoolean("secret",false)?"mustEnv("+go("DEVSCOPE_SECRET_"+(i+1))+")":go(s.optString("value",""));}
    private static String secretExprRust(JSONObject s,int i){return s.optBoolean("secret",false)?"env::var("+rust("DEVSCOPE_SECRET_"+(i+1))+").expect(\"missing secret env\")":rust(s.optString("value",""));}
    private static String secretExprRuby(JSONObject s,int i){return s.optBoolean("secret",false)?"ENV.fetch("+rb("DEVSCOPE_SECRET_"+(i+1))+")":rb(s.optString("value",""));}
    private static String secretExprPhp(JSONObject s,int i){return s.optBoolean("secret",false)?"(getenv("+php("DEVSCOPE_SECRET_"+(i+1))+")?:throw new Exception('missing secret env'))":php(s.optString("value",""));}

    private static String py(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'").replace("\n","\\n").replace("\r","\\r")+"'";}
    private static String js(String s){return JSONObject.quote(s);}
    private static String j(String s){return JSONObject.quote(s);}
    private static String kt(String s){return JSONObject.quote(s).replace("$","\\$");}
    private static String cs(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","\\r").replace("\n","\\n")+"\"";}
    private static String go(String s){return JSONObject.quote(s);}
    private static String cpp(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";}
    private static String c(String s){return cpp(s);}
    private static String rust(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";}
    private static String rb(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}
    private static String php(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}
}
