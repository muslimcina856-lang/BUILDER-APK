package com.devscope.app;

import android.webkit.ValueCallback;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

public final class InspectorEngine {
    public interface JsonCallback {
        void onResult(JSONObject object);
        void onError(String error);
    }

    public interface TextCallback {
        void onResult(String value);
        void onError(String error);
    }

    private final WebView webView;

    public InspectorEngine(WebView webView) {
        this.webView = webView;
    }

    public void pageSummary(JsonCallback callback) {
        evalJson("""
            (() => {
              const all = document.getElementsByTagName('*');
              return JSON.stringify({
                ready: document.readyState,
                title: document.title || '',
                url: location.href,
                protocol: location.protocol,
                dom: all.length,
                resources: performance.getEntriesByType('resource').length,
                scripts: document.scripts.length,
                styles: document.styleSheets.length,
                links: document.links.length,
                forms: document.forms.length,
                iframes: document.querySelectorAll('iframe').length,
                images: document.images.length,
                viewport: innerWidth + 'x' + innerHeight,
                dpr: devicePixelRatio || 1
              });
            })()
        """, callback);
    }

    public void inspectDom(JsonCallback callback) {
        evalJson("""
            (() => {
              const MAX_NODES = 420;
              const MAX_DEPTH = 10;
              let count = 0;
              const lines = [];
              const esc = s => String(s || '').replace(/\\s+/g, ' ').trim();
              const clip = (s,n) => s.length > n ? s.slice(0,n-1) + '…' : s;
              function describe(el) {
                let out = '<' + el.tagName.toLowerCase();
                if (el.id) out += '#' + el.id;
                if (typeof el.className === 'string' && el.className.trim()) {
                  const cls = el.className.trim().split(/\\s+/).slice(0,4).join('.');
                  if (cls) out += '.' + cls;
                }
                const role = el.getAttribute('role');
                const name = el.getAttribute('name');
                const type = el.getAttribute('type');
                if (role) out += ' role=' + JSON.stringify(role);
                if (name) out += ' name=' + JSON.stringify(name);
                if (type) out += ' type=' + JSON.stringify(type);
                out += '>';
                const ownText = Array.from(el.childNodes)
                  .filter(n => n.nodeType === Node.TEXT_NODE)
                  .map(n => esc(n.textContent)).filter(Boolean).join(' ');
                if (ownText) out += '  ' + JSON.stringify(clip(ownText, 86));
                return out;
              }
              function walk(el, depth) {
                if (!el || count >= MAX_NODES || depth > MAX_DEPTH) return;
                count++;
                lines.push('  '.repeat(depth) + describe(el));
                for (const child of el.children) {
                  if (count >= MAX_NODES) break;
                  walk(child, depth + 1);
                }
              }
              if (document.documentElement) walk(document.documentElement, 0);
              const tech = [];
              if (window.__NEXT_DATA__ || document.getElementById('__next')) tech.push('Next.js signal');
              if (window.__NUXT__ || document.getElementById('__nuxt')) tech.push('Nuxt signal');
              if (window.Vue || document.querySelector('[data-v-app]')) tech.push('Vue signal');
              if (window.angular || document.querySelector('[ng-version]')) tech.push('Angular signal');
              if (document.querySelector('[data-reactroot],[data-reactid]') || document.querySelector('[id^="react-root"]')) tech.push('React signal');
              if (window.jQuery) tech.push('jQuery ' + (window.jQuery.fn && window.jQuery.fn.jquery || 'signal'));
              const generator = document.querySelector('meta[name="generator"]');
              if (generator) tech.push('generator=' + generator.content);
              return JSON.stringify({
                total: document.getElementsByTagName('*').length,
                emitted: count,
                truncated: count >= MAX_NODES,
                scripts: document.scripts.length,
                styles: document.styleSheets.length,
                forms: document.forms.length,
                iframes: document.querySelectorAll('iframe').length,
                shadowHosts: Array.from(document.querySelectorAll('*')).filter(e => e.shadowRoot).length,
                tech,
                tree: lines.join('\\n')
              });
            })()
        """, callback);
    }

    public void inspectStorage(String nativeCookies, JsonCallback callback) {
        String cookieLiteral = JSONObject.quote(nativeCookies == null ? "" : nativeCookies);
        evalJson("""
            (() => {
              const readStore = store => {
                const out = {};
                try {
                  for (let i = 0; i < store.length; i++) {
                    const key = store.key(i);
                    let value = store.getItem(key);
                    if (typeof value === 'string' && value.length > 4096) value = value.slice(0,4096) + '…';
                    out[key] = value;
                  }
                } catch (e) { out.__error = String(e); }
                return out;
              };
              return JSON.stringify({
                origin: location.origin,
                documentCookie: document.cookie || '',
                nativeCookieHeader: __COOKIE_LITERAL__,
                localStorage: readStore(localStorage),
                sessionStorage: readStore(sessionStorage)
              });
            })()
        """.replace("__COOKIE_LITERAL__", cookieLiteral), callback);
    }

    public void inspectPerformance(JsonCallback callback) {
        evalJson("""
            (() => {
              const nav = performance.getEntriesByType('navigation')[0];
              const resources = performance.getEntriesByType('resource').slice(-300).map((r,i) => ({
                i,
                name: r.name,
                type: r.initiatorType || 'resource',
                start: Math.round(r.startTime * 100) / 100,
                duration: Math.round(r.duration * 100) / 100,
                transfer: r.transferSize || 0,
                encoded: r.encodedBodySize || 0,
                decoded: r.decodedBodySize || 0,
                protocol: r.nextHopProtocol || '',
                worker: r.workerStart || 0
              }));
              return JSON.stringify({
                timeOrigin: performance.timeOrigin || 0,
                navigation: nav ? {
                  type: nav.type,
                  duration: Math.round(nav.duration * 100) / 100,
                  domInteractive: Math.round(nav.domInteractive * 100) / 100,
                  domContentLoaded: Math.round(nav.domContentLoadedEventEnd * 100) / 100,
                  loadEventEnd: Math.round(nav.loadEventEnd * 100) / 100,
                  transfer: nav.transferSize || 0,
                  encoded: nav.encodedBodySize || 0,
                  decoded: nav.decodedBodySize || 0,
                  protocol: nav.nextHopProtocol || ''
                } : null,
                resources
              });
            })()
        """, callback);
    }

    public void inspectSource(JsonCallback callback) {
        evalJson("""
            (() => {
              const html = document.documentElement ? document.documentElement.outerHTML : '';
              const LIMIT = 350000;
              return JSON.stringify({
                length: html.length,
                truncated: html.length > LIMIT,
                html: html.length > LIMIT ? html.slice(0, LIMIT) : html
              });
            })()
        """, callback);
    }

    public void installPicker(TextCallback callback) {
        evalText("""
            (() => {
              try {
                window.__devscopePicked = null;
                if (window.__devscopePickerCleanup) window.__devscopePickerCleanup();
                const overlay = document.createElement('div');
                overlay.id = '__devscope_picker_overlay';
                Object.assign(overlay.style, {
                  position:'fixed', pointerEvents:'none', zIndex:'2147483647',
                  border:'2px solid #8b5cf6', background:'rgba(139,92,246,.14)',
                  boxSizing:'border-box', display:'none'
                });
                document.documentElement.appendChild(overlay);
                let target = null;
                function selector(el) {
                  if (!(el instanceof Element)) return '';
                  const cssEsc = x => (window.CSS && CSS.escape) ? CSS.escape(x) : String(x).replace(/[^a-zA-Z0-9_-]/g, c => String.fromCharCode(92) + c);
                  if (el.id) return '#' + cssEsc(el.id);
                  const parts = [];
                  let cur = el;
                  while (cur && cur.nodeType === 1 && parts.length < 7) {
                    let part = cur.tagName.toLowerCase();
                    const classes = Array.from(cur.classList || []).slice(0,2);
                    if (classes.length) part += '.' + classes.map(c => cssEsc(c)).join('.');
                    const parent = cur.parentElement;
                    if (parent) {
                      const same = Array.from(parent.children).filter(x => x.tagName === cur.tagName);
                      if (same.length > 1) part += ':nth-of-type(' + (same.indexOf(cur)+1) + ')';
                    }
                    parts.unshift(part);
                    if (parent && parent.id) { parts.unshift('#' + cssEsc(parent.id)); break; }
                    cur = parent;
                  }
                  return parts.join(' > ');
                }
                function attrs(el) {
                  const out = {};
                  for (const a of Array.from(el.attributes || [])) out[a.name] = a.value;
                  return out;
                }
                function point(x,y) {
                  const el = document.elementFromPoint(x,y);
                  if (!el || el === overlay) return;
                  target = el;
                  const r = el.getBoundingClientRect();
                  Object.assign(overlay.style,{left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px',display:'block'});
                }
                function move(e) { point(e.clientX,e.clientY); }
                function touch(e) { if (e.touches && e.touches[0]) point(e.touches[0].clientX,e.touches[0].clientY); }
                function pick(e) {
                  if (!target) return;
                  e.preventDefault(); e.stopPropagation();
                  const r = target.getBoundingClientRect();
                  const cs = getComputedStyle(target);
                  window.__devscopePicked = {
                    selector: selector(target),
                    tag: target.tagName.toLowerCase(), id: target.id || '',
                    className: typeof target.className === 'string' ? target.className : '',
                    attributes: attrs(target),
                    rect: {x:r.x,y:r.y,width:r.width,height:r.height},
                    styles: {display:cs.display,position:cs.position,zIndex:cs.zIndex,color:cs.color,background:cs.backgroundColor,font:cs.font,margin:cs.margin,padding:cs.padding},
                    text: (target.innerText || target.textContent || '').trim().slice(0,2000),
                    outerHTML: target.outerHTML.slice(0,8000)
                  };
                  cleanup();
                }
                function cleanup() {
                  document.removeEventListener('mousemove', move, true);
                  document.removeEventListener('touchstart', touch, true);
                  document.removeEventListener('click', pick, true);
                  if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
                  window.__devscopePickerCleanup = null;
                }
                window.__devscopePickerCleanup = cleanup;
                document.addEventListener('mousemove', move, true);
                document.addEventListener('touchstart', touch, true);
                document.addEventListener('click', pick, true);
                return 'picker armed';
              } catch (e) { return 'picker error: ' + e; }
            })()
        """, callback);
    }

    public void pollPicker(JsonCallback callback) {
        evalJson("JSON.stringify(window.__devscopePicked || {})", callback);
    }

    public void evaluateRuntime(String code, TextCallback callback) {
        if (code == null || code.trim().isEmpty()) {
            callback.onError("Empty JavaScript expression.");
            return;
        }
        String quoted = JSONObject.quote(code);
        String script = """
            (() => {
              try {
                const __result = (0, eval)(__CODE__);
                if (__result === undefined) return JSON.stringify({ok:true,type:'undefined',display:'undefined'});
                if (__result === null) return JSON.stringify({ok:true,type:'null',display:'null'});
                if (typeof Promise !== 'undefined' && __result instanceof Promise) {
                  return JSON.stringify({ok:true,type:'Promise',display:'[Promise] Use .then(...) or console.log(...) to inspect asynchronous completion.'});
                }
                let display;
                if (typeof __result === 'string') display = __result;
                else {
                  try { display = JSON.stringify(__result, null, 2); }
                  catch (_) { display = String(__result); }
                }
                if (display === undefined) display = String(__result);
                return JSON.stringify({ok:true,type:typeof __result,display});
              } catch (e) {
                return JSON.stringify({ok:false,error:String(e),stack:e && e.stack ? String(e.stack) : ''});
              }
            })()
        """.replace("__CODE__", quoted);
        evalJson(script, new JsonCallback() {
            @Override
            public void onResult(JSONObject object) {
                if (object.optBoolean("ok", false)) {
                    callback.onResult("[" + object.optString("type", "value") + "]\n" + object.optString("display", ""));
                } else {
                    String error = object.optString("error", "JavaScript evaluation failed");
                    String stack = object.optString("stack", "");
                    callback.onResult("ERROR: " + error + (stack.isEmpty() ? "" : "\n" + stack));
                }
            }

            @Override
            public void onError(String error) {
                callback.onError(error);
            }
        });
    }

    private void evalJson(String script, JsonCallback callback) {
        evalRaw(script, value -> {
            try {
                String decoded = decodeJavascriptResult(value);
                if (decoded == null || decoded.equals("null") || decoded.isEmpty()) {
                    callback.onError("No inspector result returned by page.");
                    return;
                }
                callback.onResult(new JSONObject(decoded));
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? "Could not decode inspector result." : e.getMessage());
            }
        });
    }

    private void evalText(String script, TextCallback callback) {
        evalRaw(script, value -> {
            try {
                callback.onResult(decodeJavascriptResult(value));
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? "Could not decode JavaScript result." : e.getMessage());
            }
        });
    }

    private void evalRaw(String script, ValueCallback<String> callback) {
        webView.post(() -> {
            try {
                webView.evaluateJavascript(script, callback);
            } catch (Exception e) {
                callback.onReceiveValue(JSONObject.quote("ERROR: " + e.getMessage()));
            }
        });
    }

    public static String decodeJavascriptResult(String value) throws Exception {
        if (value == null) return "null";
        if (value.equals("null")) return "null";
        if (value.startsWith("\"") || value.startsWith("'")) {
            return new JSONArray("[" + value + "]").getString(0);
        }
        return value;
    }
}
