package com.devscope.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class FlowTimelineView extends View {
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint detailPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint timePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<TelemetryStore.FlowEvent> events = new ArrayList<>();
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private final float density;

    public FlowTimelineView(Context context) {
        this(context, null);
    }

    public FlowTimelineView(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = getResources().getDisplayMetrics().density;
        linePaint.setColor(Color.rgb(45, 51, 66));
        linePaint.setStrokeWidth(dp(1.2f));
        titlePaint.setColor(Color.rgb(232, 236, 244));
        titlePaint.setTextSize(sp(10));
        titlePaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        detailPaint.setColor(Color.rgb(139, 147, 167));
        detailPaint.setTextSize(sp(9));
        detailPaint.setTypeface(Typeface.MONOSPACE);
        timePaint.setColor(Color.rgb(96, 105, 124));
        timePaint.setTextSize(sp(8));
        timePaint.setTypeface(Typeface.MONOSPACE);
        setPadding((int) dp(8), (int) dp(10), (int) dp(8), (int) dp(12));
    }

    public void setEvents(List<TelemetryStore.FlowEvent> snapshot) {
        events.clear();
        if (snapshot != null) events.addAll(snapshot);
        requestLayout();
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int rows = Math.max(1, events.size());
        int desired = getPaddingTop() + getPaddingBottom() + (int) (rows * dp(58));
        setMeasuredDimension(width, resolveSize(desired, heightMeasureSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (events.isEmpty()) {
            detailPaint.setColor(Color.rgb(96, 105, 124));
            canvas.drawText("No trace events. Load a URL to start capture.", dp(12), dp(28), detailPaint);
            return;
        }

        float x = dp(22);
        float top = dp(22);
        float row = dp(58);
        float bottom = top + row * Math.max(0, events.size() - 1);
        canvas.drawLine(x, top, x, bottom, linePaint);

        long base = events.get(0).timeMs;
        for (int i = 0; i < events.size(); i++) {
            TelemetryStore.FlowEvent event = events.get(i);
            float y = top + i * row;
            dotPaint.setColor(colorFor(event.type));
            canvas.drawCircle(x, y, dp(4.5f), dotPaint);

            String type = "#" + event.seq + "  " + safe(event.type, 18);
            titlePaint.setColor(colorFor(event.type));
            canvas.drawText(type, dp(38), y - dp(5), titlePaint);

            long delta = event.timeMs - base;
            String timing = timeFormat.format(new Date(event.timeMs)) + "  +" + delta + "ms";
            canvas.drawText(timing, dp(38), y + dp(9), timePaint);

            String detail = event.detail == null || event.detail.isEmpty() ? event.url : event.detail;
            detailPaint.setColor(Color.rgb(139, 147, 167));
            canvas.drawText(safe(detail, 76), dp(38), y + dp(24), detailPaint);
        }
    }

    private int colorFor(String type) {
        String t = type == null ? "" : type.toUpperCase(Locale.US);
        if (t.contains("ERROR") || t.contains("HTTP")) return Color.rgb(251, 113, 133);
        if (t.contains("REQ")) return Color.rgb(34, 211, 238);
        if (t.contains("CONSOLE")) return Color.rgb(251, 191, 36);
        if (t.contains("DOM") || t.contains("FINISH")) return Color.rgb(74, 222, 128);
        if (t.contains("NAV") || t.contains("START") || t.contains("COMMIT")) return Color.rgb(139, 92, 246);
        return Color.rgb(160, 170, 192);
    }

    private String safe(String input, int max) {
        if (input == null) return "";
        String single = input.replace('\n', ' ').replace('\r', ' ').trim();
        if (single.length() <= max) return single;
        return single.substring(0, Math.max(1, max - 1)) + "...";
    }

    private float dp(float value) {
        return value * density;
    }

    private float sp(float value) {
        return value * getResources().getDisplayMetrics().scaledDensity;
    }
}
