package com.devscope.app;

import android.webkit.ConsoleMessage;
import android.webkit.WebResourceRequest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public final class TelemetryStore {
    public static final int MAX_FLOW = 500;
    public static final int MAX_NETWORK = 800;
    public static final int MAX_CONSOLE = 500;

    public static final class FlowEvent {
        public final int seq;
        public final long timeMs;
        public final String type;
        public final String detail;
        public final String url;

        FlowEvent(int seq, long timeMs, String type, String detail, String url) {
            this.seq = seq;
            this.timeMs = timeMs;
            this.type = type;
            this.detail = detail == null ? "" : detail;
            this.url = url == null ? "" : url;
        }
    }

    public static final class NetworkEntry {
        public final int seq;
        public final long timeMs;
        public final String method;
        public final String url;
        public final boolean mainFrame;
        public final Map<String, String> headers;

        NetworkEntry(int seq, long timeMs, String method, String url, boolean mainFrame, Map<String, String> headers) {
            this.seq = seq;
            this.timeMs = timeMs;
            this.method = method == null ? "GET" : method;
            this.url = url == null ? "" : url;
            this.mainFrame = mainFrame;
            this.headers = headers;
        }
    }

    public static final class ConsoleEntry {
        public final int seq;
        public final long timeMs;
        public final String level;
        public final String message;
        public final String source;
        public final int line;

        ConsoleEntry(int seq, long timeMs, String level, String message, String source, int line) {
            this.seq = seq;
            this.timeMs = timeMs;
            this.level = level == null ? "LOG" : level;
            this.message = message == null ? "" : message;
            this.source = source == null ? "" : source;
            this.line = line;
        }
    }

    private final AtomicInteger sequence = new AtomicInteger(0);
    private final List<FlowEvent> flow = Collections.synchronizedList(new ArrayList<>());
    private final List<NetworkEntry> network = Collections.synchronizedList(new ArrayList<>());
    private final List<ConsoleEntry> console = Collections.synchronizedList(new ArrayList<>());

    public FlowEvent addFlow(String type, String detail, String url) {
        FlowEvent event = new FlowEvent(sequence.incrementAndGet(), System.currentTimeMillis(), type, detail, url);
        synchronized (flow) {
            flow.add(event);
            trim(flow, MAX_FLOW);
        }
        return event;
    }

    public NetworkEntry addNetwork(WebResourceRequest request) {
        Map<String, String> headers = new LinkedHashMap<>();
        try {
            if (request.getRequestHeaders() != null) headers.putAll(request.getRequestHeaders());
        } catch (Exception ignored) {
        }
        NetworkEntry entry = new NetworkEntry(
                sequence.incrementAndGet(),
                System.currentTimeMillis(),
                request.getMethod(),
                request.getUrl() == null ? "" : request.getUrl().toString(),
                request.isForMainFrame(),
                headers
        );
        synchronized (network) {
            network.add(entry);
            trim(network, MAX_NETWORK);
        }
        return entry;
    }

    public ConsoleEntry addConsole(ConsoleMessage message) {
        String level = message.messageLevel() == null ? "LOG" : message.messageLevel().name();
        ConsoleEntry entry = new ConsoleEntry(
                sequence.incrementAndGet(),
                System.currentTimeMillis(),
                level,
                message.message(),
                message.sourceId(),
                message.lineNumber()
        );
        synchronized (console) {
            console.add(entry);
            trim(console, MAX_CONSOLE);
        }
        return entry;
    }

    public List<FlowEvent> flowSnapshot() {
        synchronized (flow) {
            return new ArrayList<>(flow);
        }
    }

    public List<NetworkEntry> networkSnapshot() {
        synchronized (network) {
            return new ArrayList<>(network);
        }
    }

    public List<ConsoleEntry> consoleSnapshot() {
        synchronized (console) {
            return new ArrayList<>(console);
        }
    }

    public int networkCount() {
        synchronized (network) {
            return network.size();
        }
    }

    public int consoleCount() {
        synchronized (console) {
            return console.size();
        }
    }

    public void clearFlow() {
        synchronized (flow) {
            flow.clear();
        }
    }

    public void clearNetwork() {
        synchronized (network) {
            network.clear();
        }
    }

    public void clearConsole() {
        synchronized (console) {
            console.clear();
        }
    }

    public void clearAll() {
        clearFlow();
        clearNetwork();
        clearConsole();
    }

    private static <T> void trim(List<T> list, int max) {
        while (list.size() > max) list.remove(0);
    }
}
