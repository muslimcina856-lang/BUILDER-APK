# DevScope uses only Android framework APIs. No reflection-based model keep rules required.
