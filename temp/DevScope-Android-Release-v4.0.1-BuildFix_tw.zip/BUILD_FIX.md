# DevScope Android v4.0.1 Build Fix

Fixed compile error:

- Wrong: `import android.app.PrintManager;`
- Correct: `import android.print.PrintManager;`

No UI or feature logic was removed or changed. PDF/print continues to use Android's system PrintManager service.

Validation performed:
- Android resource XML parses successfully.
- 67 Java-referenced view IDs exist in both portrait and landscape layouts.
- No stale `android.app.PrintManager` import remains.
- Version bumped to 4.0.1 / versionCode 5.
