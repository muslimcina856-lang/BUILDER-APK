import 'package:flutter/material.dart';

import 'widgets/bottom_nav.dart';
import 'services/storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final String theme = await StorageService.getTheme();

  runApp(RavenDarkNote(theme: theme));
}

class RavenDarkNote extends StatefulWidget {
  final String theme;

  const RavenDarkNote({
    super.key,
    required this.theme,
  });

  @override
  State<RavenDarkNote> createState() => _RavenDarkNoteState();
}

class _RavenDarkNoteState extends State<RavenDarkNote> {
  late ThemeMode _themeMode;

  @override
  void initState() {
    super.initState();
    _themeMode = _convertTheme(widget.theme);
  }

  ThemeMode _convertTheme(String theme) {
    switch (theme.toLowerCase()) {
      case "dark":
        return ThemeMode.dark;

      case "light":
        return ThemeMode.light;

      default:
        return ThemeMode.system;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: "Raven DarkNote",

      themeMode: _themeMode,

      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorSchemeSeed: const Color(0xFF7C3AED),
        scaffoldBackgroundColor: Colors.white,
      ),

      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF7C3AED),
        scaffoldBackgroundColor: const Color(0xFF121212),
      ),

      home: const BottomNav(),
    );
  }
}