import 'package:flutter/material.dart';

class MenuCard extends StatelessWidget {

  final IconData icon;
  final String title;


  const MenuCard({
    super.key,
    required this.icon,
    required this.title,
  });


  @override
  Widget build(BuildContext context) {

    final colorScheme =
        Theme.of(context).colorScheme;


    return Container(

      padding: const EdgeInsets.all(15),


      decoration: BoxDecoration(

        borderRadius:
            BorderRadius.circular(20),


        color:
            colorScheme.surfaceContainerHighest,

      ),


      child: Column(

        mainAxisAlignment:
            MainAxisAlignment.center,


        children: [

          Icon(

            icon,

            size: 35,

            color:
                colorScheme.primary,

          ),


          const SizedBox(
            height: 10,
          ),


          Text(

            title,

            textAlign:
                TextAlign.center,


            style:
                const TextStyle(

              fontWeight:
                  FontWeight.bold,

            ),

          ),

        ],

      ),

    );

  }

}