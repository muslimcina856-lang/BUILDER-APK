import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VideoBanner extends StatefulWidget {
  const VideoBanner({super.key});

  @override
  State<VideoBanner> createState() => _VideoBannerState();
}

class _VideoBannerState extends State<VideoBanner> {
  late VideoPlayerController controller;

  bool error = false;

  @override
  void initState() {
    super.initState();

    controller = VideoPlayerController.asset(
      "assets/banner.mp4",
    );

    loadVideo();
  }

  Future<void> loadVideo() async {
    try {
      await controller.initialize();

      if (!mounted) return;

      controller
        ..setLooping(true)
        ..setVolume(1)
        ..play();

      setState(() {});
    } catch (e) {
      if (mounted) {
        setState(() {
          error = true;
        });
      }
    }
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    if (error) {
      return const SizedBox(
        height: 200,
        child: Center(
          child: Text(
            "Video tidak dapat diputar",
          ),
        ),
      );
    }


    if (!controller.value.isInitialized) {
      return const SizedBox(
        height: 200,
        child: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }


    return ClipRRect(
      borderRadius: BorderRadius.circular(20),

      child: AspectRatio(
        aspectRatio: controller.value.aspectRatio,

        child: VideoPlayer(controller),
      ),
    );
  }
}