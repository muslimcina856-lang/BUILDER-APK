import 'package:flutter/material.dart';

import '../pages/dashboard.dart';
import '../pages/tabungan.dart';
import '../pages/tools.dart';
import '../pages/catatan.dart';
import '../pages/pengaturan.dart';


class BottomNav extends StatefulWidget {

  const BottomNav({super.key});


  @override
  State<BottomNav> createState() =>
      _BottomNavState();

}


class _BottomNavState extends State<BottomNav> {


  int index = 0;


  final pages = const [

    Dashboard(),

    Tabungan(),

    Tools(),

    Catatan(),

    Pengaturan(),

  ];



  @override
  Widget build(BuildContext context) {


    return Scaffold(


      body: IndexedStack(

        index: index,

        children: pages,

      ),



      bottomNavigationBar: NavigationBar(


        selectedIndex: index,


        onDestinationSelected: (i) {

          setState(() {

            index = i;

          });

        },



        destinations: const [


          NavigationDestination(

            icon: Icon(Icons.home),

            label: "Home",

          ),



          NavigationDestination(

            icon: Icon(Icons.savings),

            label: "Tabungan",

          ),



          NavigationDestination(

            icon: Icon(Icons.build),

            label: "Tools",

          ),



          NavigationDestination(

            icon: Icon(Icons.note),

            label: "Catatan",

          ),



          NavigationDestination(

            icon: Icon(Icons.settings),

            label: "Pengaturan",

          ),


        ],

      ),

    );

  }

}