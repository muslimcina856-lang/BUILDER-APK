import 'package:flutter/material.dart';

class ToolCard extends StatelessWidget {

  final String title;
  final IconData icon;
  final VoidCallback onTap;


  const ToolCard({
    super.key,
    required this.title,
    required this.icon,
    required this.onTap,
  });


  @override
  Widget build(BuildContext context) {

    return InkWell(

      borderRadius: BorderRadius.circular(18),

      onTap: onTap,


      child: Container(

        padding: const EdgeInsets.all(18),


        decoration: BoxDecoration(

          borderRadius: BorderRadius.circular(18),

          color: Theme.of(context)
              .colorScheme
              .surfaceContainerHighest,

        ),


        child: Column(

          mainAxisAlignment:
              MainAxisAlignment.center,


          children: [

            Icon(
              icon,

              size: 40,

              color: Theme.of(context)
                  .colorScheme
                  .primary,
            ),


            const SizedBox(
              height: 10,
            ),


            Text(
              title,

              textAlign:
                  TextAlign.center,

              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),

            ),

          ],

        ),

      ),

    );

  }

}