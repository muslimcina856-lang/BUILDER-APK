import 'package:flutter/material.dart';

import '../models/tabungan_model.dart';
import '../services/tabungan_service.dart';

class Tabungan extends StatefulWidget {
  const Tabungan({super.key});

  @override
  State<Tabungan> createState() => _TabunganState();
}

class _TabunganState extends State<Tabungan> {
  TabunganModel? data;

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {
    data = await TabunganService.load();

    if (mounted) {
      setState(() {});
    }
  }

  Future<void> buatTarget() async {
    final nama = TextEditingController();
    final target = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Target Baru"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nama,
                decoration: const InputDecoration(
                  labelText: "Nama Target",
                ),
              ),
              TextField(
                controller: target,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Target (Rp)",
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Batal"),
            ),
            ElevatedButton(
              onPressed: () async {
                final nilaiTarget =
                    double.tryParse(target.text.replaceAll(",", "")) ?? 0;

                if (nama.text.trim().isEmpty || nilaiTarget <= 0) {
                  return;
                }

                final baru = TabunganModel(
                  nama: nama.text.trim(),
                  target: nilaiTarget,
                  saldo: 0,
                );

                await TabunganService.save(baru);

                if (mounted) {
                  setState(() {
                    data = baru;
                  });
                }

                Navigator.pop(context);
              },
              child: const Text("Simpan"),
            ),
          ],
        );
      },
    ).then((_) {
      nama.dispose();
      target.dispose();
    });
  }

  Future<void> tambahSaldo() async {
    if (data == null) return;

    data!.saldo += 10000;

    await TabunganService.save(data!);

    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress =
        data == null ? 0.0 : data!.progress.clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Tabungan"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: buatTarget,
        child: const Icon(Icons.add),
      ),
      body: data == null
          ? const Center(
              child: Text("Belum ada target tabungan"),
            )
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data!.nama,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    "Saldo : Rp ${data!.saldo.toStringAsFixed(0)}",
                  ),

                  Text(
                    "Target : Rp ${data!.target.toStringAsFixed(0)}",
                  ),

                  const SizedBox(height: 20),

                  LinearProgressIndicator(value: progress),

                  const SizedBox(height: 8),

                  Text(
                    "${(progress * 100).toStringAsFixed(1)}%",
                  ),

                  const SizedBox(height: 20),

                  ElevatedButton.icon(
                    onPressed: tambahSaldo,
                    icon: const Icon(Icons.add),
                    label: const Text("Tambah Rp10.000"),
                  ),
                ],
              ),
            ),
    );
  }
}