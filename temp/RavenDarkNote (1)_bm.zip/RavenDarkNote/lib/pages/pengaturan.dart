import 'package:flutter/material.dart';

import '../services/storage_service.dart';
import '../widgets/theme_button.dart';

class Pengaturan extends StatefulWidget {
  const Pengaturan({super.key});

  @override
  State<Pengaturan> createState() => _PengaturanState();
}

class _PengaturanState extends State<Pengaturan> {
  String tema = "system";

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    tema = await StorageService.getTheme();

    if (mounted) {
      setState(() {});
    }
  }

  Future<void> pilihTema(String value) async {
    await StorageService.saveTheme(value);

    if (mounted) {
      setState(() {
        tema = value;
      });
    }
  }

  void caraPakai() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Cara Menggunakan"),
          content: const SingleChildScrollView(
            child: Text(
              """
Raven DarkNote

1. Dashboard
Menampilkan menu utama.

2. Tabungan
Buat target dan simpan uang secara offline.

3. Tools
Gunakan berbagai alat yang tersedia.

4. Catatan
Simpan catatan pribadi.

5. Pengaturan
Atur tema dan informasi aplikasi.

Semua data tersimpan di perangkat.
""",
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Tutup"),
            ),
          ],
        );
      },
    );
  }

  void donate() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Donate Raven DarkNote"),
          content: Image.asset("assets/donate.jpg"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Tutup"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pengaturan"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(15),
        children: [
          const Text(
            "Tema Aplikasi",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 15),

          ThemeButton(
            title: "Sistem",
            icon: Icons.settings,
            onTap: () => pilihTema("system"),
          ),

          ThemeButton(
            title: "Gelap",
            icon: Icons.dark_mode,
            onTap: () => pilihTema("dark"),
          ),

          ThemeButton(
            title: "Terang",
            icon: Icons.light_mode,
            onTap: () => pilihTema("light"),
          ),

          ThemeButton(
            title: "Pink",
            icon: Icons.palette,
            onTap: () => pilihTema("pink"),
          ),

          ThemeButton(
            title: "Biru",
            icon: Icons.water_drop,
            onTap: () => pilihTema("blue"),
          ),

          ThemeButton(
            title: "Merah",
            icon: Icons.favorite,
            onTap: () => pilihTema("red"),
          ),

          const SizedBox(height: 20),

          ListTile(
            leading: const Icon(Icons.favorite),
            title: const Text("Donate Developer"),
            onTap: donate,
          ),

          ListTile(
            leading: const Icon(Icons.help),
            title: const Text("Cara Pakai"),
            onTap: caraPakai,
          ),

          const ListTile(
            leading: Icon(Icons.info),
            title: Text("Versi APK"),
            subtitle: Text("1.0.0"),
          ),

          const ListTile(
            leading: Icon(Icons.apps),
            title: Text("Tentang Raven DarkNote"),
            subtitle: Text(
              "Aplikasi catatan, tabungan dan tools pribadi.",
            ),
          ),
        ],
      ),
    );
  }
}