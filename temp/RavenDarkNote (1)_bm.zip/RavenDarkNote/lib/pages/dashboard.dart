import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../widgets/video_banner.dart';
import '../widgets/menu_card.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  static const String whatsapp =
      "https://whatsapp.com/channel/0029Vb7ISSJDeON39wZx6s2M";

  Future<void> openWA() async {
    final Uri url = Uri.parse(whatsapp);

    if (await canLaunchUrl(url)) {
      await launchUrl(
        url,
        mode: LaunchMode.externalApplication,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Raven DarkNote",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              const VideoBanner(),

              const SizedBox(height: 20),

              const Text(
                "Menu Cepat",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                children: const [
                  MenuCard(
                    icon: Icons.savings,
                    title: "Tabungan",
                  ),
                  MenuCard(
                    icon: Icons.build,
                    title: "Tools",
                  ),
                  MenuCard(
                    icon: Icons.note,
                    title: "Catatan",
                  ),
                  MenuCard(
                    icon: Icons.settings,
                    title: "Pengaturan",
                  ),
                ],
              ),

              const SizedBox(height: 25),

              InkWell(
                onTap: openWA,
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Row(
                    children: [
                      Icon(
                        Icons.message,
                        color: Colors.white,
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "Join Saluran WhatsApp RavenZy",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Icon(
                        Icons.arrow_forward_ios,
                        color: Colors.white,
                        size: 16,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}