import 'package:flutter/material.dart';

import '../widgets/tool_card.dart';

import '../tools/calculator.dart';
import '../tools/password_generator.dart';
import '../tools/text_counter.dart';
import '../tools/case_converter.dart';
import '../tools/json_formatter.dart';
import '../tools/qr_generator.dart';
import '../tools/hash_tool.dart';
import '../tools/ip_checker.dart';
import '../tools/device_info.dart';
import '../tools/stopwatch_tool.dart';
import '../tools/timer_tool.dart';
import '../tools/unit_converter.dart';

class Tools extends StatelessWidget {
  const Tools({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> tools = [
      {
        "title": "Kalkulator",
        "icon": Icons.calculate,
        "page": const Calculator(),
      },
      {
        "title": "Password Generator",
        "icon": Icons.password,
        "page": const PasswordGenerator(),
      },
      {
        "title": "Text Counter",
        "icon": Icons.text_fields,
        "page": const TextCounter(),
      },
      {
        "title": "Case Converter",
        "icon": Icons.text_format,
        "page": const CaseConverter(),
      },
      {
        "title": "JSON Formatter",
        "icon": Icons.code,
        "page": const JsonFormatter(),
      },
      {
        "title": "QR Generator",
        "icon": Icons.qr_code,
        "page": const QRGenerator(),
      },
      {
        "title": "Hash Generator",
        "icon": Icons.tag,
        "page": const HashTool(),
      },
      {
        "title": "Cek IP",
        "icon": Icons.public,
        "page": const IPChecker(),
      },
      {
        "title": "Device Info",
        "icon": Icons.phone_android,
        "page": DeviceInfoPage(),
      },
      {
        "title": "Stopwatch",
        "icon": Icons.timer,
        "page": const StopwatchTool(),
      },
      {
        "title": "Timer",
        "icon": Icons.alarm,
        "page": const TimerTool(),
      },
      {
        "title": "Converter",
        "icon": Icons.swap_horiz,
        "page": const UnitConverter(),
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Raven Tools"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(15),
        child: GridView.builder(
          itemCount: tools.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
          ),
          itemBuilder: (context, index) {
            final tool = tools[index];

            return ToolCard(
              title: tool["title"] as String,
              icon: tool["icon"] as IconData,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => tool["page"] as Widget,
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}