class AppInfo {
  static const String name = "Raven DarkNote";

  static const String version = "1.0.0";
}