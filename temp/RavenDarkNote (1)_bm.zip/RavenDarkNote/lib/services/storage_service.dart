import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static Future<SharedPreferences> get _prefs async =>
      await SharedPreferences.getInstance();

  /// ==========================
  /// String
  /// ==========================
  static Future<void> saveData(String key, String value) async {
    final prefs = await _prefs;
    await prefs.setString(key, value);
  }

  static Future<String?> getData(String key) async {
    final prefs = await _prefs;
    return prefs.getString(key);
  }

  /// ==========================
  /// Bool
  /// ==========================
  static Future<void> saveBool(String key, bool value) async {
    final prefs = await _prefs;
    await prefs.setBool(key, value);
  }

  static Future<bool> getBool(
    String key, {
    bool defaultValue = false,
  }) async {
    final prefs = await _prefs;
    return prefs.getBool(key) ?? defaultValue;
  }

  /// ==========================
  /// Int
  /// ==========================
  static Future<void> saveInt(String key, int value) async {
    final prefs = await _prefs;
    await prefs.setInt(key, value);
  }

  static Future<int> getInt(
    String key, {
    int defaultValue = 0,
  }) async {
    final prefs = await _prefs;
    return prefs.getInt(key) ?? defaultValue;
  }

  /// ==========================
  /// Double
  /// ==========================
  static Future<void> saveDouble(String key, double value) async {
    final prefs = await _prefs;
    await prefs.setDouble(key, value);
  }

  static Future<double> getDouble(
    String key, {
    double defaultValue = 0,
  }) async {
    final prefs = await _prefs;
    return prefs.getDouble(key) ?? defaultValue;
  }

  /// ==========================
  /// Theme
  /// ==========================
  static Future<String> getTheme() async {
    final prefs = await _prefs;
    return prefs.getString("theme") ?? "system";
  }

  static Future<void> saveTheme(String theme) async {
    final prefs = await _prefs;
    await prefs.setString("theme", theme);
  }

  /// ==========================
  /// Hapus
  /// ==========================
  static Future<void> remove(String key) async {
    final prefs = await _prefs;
    await prefs.remove(key);
  }

  static Future<void> clearAll() async {
    final prefs = await _prefs;
    await prefs.clear();
  }
}