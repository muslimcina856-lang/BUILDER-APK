import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/catatan_model.dart';

class CatatanService {
  static const String _key = "catatan";

  static Future<void> save(List<CatatanModel> data) async {
    final prefs = await SharedPreferences.getInstance();

    final jsonData = jsonEncode(
      data.map((e) => e.toJson()).toList(),
    );

    await prefs.setString(_key, jsonData);
  }

  static Future<List<CatatanModel>> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final data = prefs.getString(_key);

      if (data == null || data.isEmpty) {
        return [];
      }

      final List<dynamic> hasil = jsonDecode(data);

      return hasil
          .map((e) => CatatanModel.fromJson(e))
          .toList();
    } catch (_) {
      return [];
    }
  }
}