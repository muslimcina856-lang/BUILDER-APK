import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/tabungan_model.dart';


class TabunganService {

  static const String _key = "tabungan";


  static Future<void> save(
    TabunganModel tabungan,
  ) async {

    final prefs =
        await SharedPreferences.getInstance();


    final data =
        jsonEncode(tabungan.toJson());


    await prefs.setString(
      _key,
      data,
    );
  }



  static Future<TabunganModel?> load() async {

    try {

      final prefs =
          await SharedPreferences.getInstance();


      final data =
          prefs.getString(_key);


      if (data == null || data.isEmpty) {
        return null;
      }


      final json =
          jsonDecode(data);


      if (json is! Map<String, dynamic>) {
        return null;
      }


      return TabunganModel.fromJson(json);


    } catch (e) {

      return null;

    }
  }



  static Future<void> delete() async {

    final prefs =
        await SharedPreferences.getInstance();


    await prefs.remove(_key);

  }

}