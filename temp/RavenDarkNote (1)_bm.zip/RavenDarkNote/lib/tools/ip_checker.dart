import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;


class IPChecker extends StatefulWidget {

  const IPChecker({super.key});


  @override
  State<IPChecker> createState() =>
      _IPCheckerState();

}



class _IPCheckerState
    extends State<IPChecker> {


  String ip = "Belum dicek";


  bool loading = false;



  Future<void> cek() async {


    setState(() {

      loading = true;

    });



    try {


      final response = await http.get(

        Uri.parse(
          "https://api.ipify.org?format=text",
        ),

      ).timeout(

        const Duration(seconds: 10),

      );



      if (!mounted) return;



      setState(() {

        ip = response.body;

      });



    } catch (e) {


      if (!mounted) return;



      setState(() {

        ip =
            "Gagal mengambil IP";

      });



    } finally {


      if (mounted) {

        setState(() {

          loading = false;

        });

      }


    }

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      appBar: AppBar(

        title:
            const Text("Public IP"),

      ),



      body: Center(

        child: Column(

          mainAxisAlignment:
              MainAxisAlignment.center,


          children: [


            Text(

              "IP Kamu:\n$ip",

              textAlign:
                  TextAlign.center,


              style:
                  const TextStyle(

                fontSize:18,

              ),

            ),



            const SizedBox(
              height:20,
            ),



            ElevatedButton(

              onPressed:
                  loading
                  ? null
                  : cek,


              child:

              loading

              ?

              const CircularProgressIndicator()

              :

              const Text(
                "Cek IP",
              ),


            ),


          ],

        ),

      ),

    );

  }

}