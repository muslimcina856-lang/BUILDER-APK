import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';


class DeviceInfoPage extends StatefulWidget {

  const DeviceInfoPage({super.key});


  @override
  State<DeviceInfoPage> createState() =>
      _DeviceInfoPageState();

}



class _DeviceInfoPageState
    extends State<DeviceInfoPage> {


  String info = "Loading...";



  @override
  void initState() {

    super.initState();

    load();

  }



  Future<void> load() async {

    try {

      final device =
          DeviceInfoPlugin();


      final android =
          await device.androidInfo;



      if (!mounted) return;



      setState(() {


        info =
        """
Brand : ${android.brand}

Model : ${android.model}

Android : ${android.version.release}

SDK : ${android.version.sdkInt}

Manufacturer : ${android.manufacturer}

Device : ${android.device}

""";


      });


    } catch (e) {


      if (mounted) {

        setState(() {

          info =
              "Gagal mengambil informasi perangkat";

        });

      }

    }

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      appBar: AppBar(

        title:
            const Text("Device Info"),

      ),



      body: Center(

        child: Padding(

          padding:
              const EdgeInsets.all(20),


          child: Text(

            info,

            style:
                const TextStyle(

              fontSize:18,

            ),

          ),

        ),

      ),

    );

  }

}