import 'dart:async';
import 'package:flutter/material.dart';


class StopwatchTool extends StatefulWidget {

  const StopwatchTool({super.key});


  @override
  State<StopwatchTool> createState() =>
      _StopwatchToolState();

}



class _StopwatchToolState
    extends State<StopwatchTool> {


  int detik = 0;


  Timer? timer;


  bool berjalan = false;



  void start() {


    if (berjalan) return;



    berjalan = true;



    timer = Timer.periodic(

      const Duration(seconds: 1),

      (e) {


        if (!mounted) return;


        setState(() {

          detik++;

        });


      },

    );


  }



  void stop() {


    timer?.cancel();


    berjalan = false;


  }



  void reset() {


    stop();



    setState(() {

      detik = 0;

    });


  }



  @override
  void dispose() {


    timer?.cancel();


    super.dispose();


  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar: AppBar(

        title:
            const Text("Stopwatch"),

      ),



      body: Center(


        child: Column(

          mainAxisAlignment:
              MainAxisAlignment.center,


          children: [


            Text(

              "$detik detik",

              style:
                  const TextStyle(

                fontSize:35,

                fontWeight:
                    FontWeight.bold,

              ),

            ),



            const SizedBox(
              height:20,
            ),



            Wrap(

              spacing:10,

              children: [


                ElevatedButton(

                  onPressed:
                      start,

                  child:
                      const Text("Start"),

                ),



                ElevatedButton(

                  onPressed:
                      stop,

                  child:
                      const Text("Stop"),

                ),



                ElevatedButton(

                  onPressed:
                      reset,

                  child:
                      const Text("Reset"),

                ),


              ],

            ),


          ],

        ),

      ),

    );

  }

}