import 'dart:async';
import 'package:flutter/material.dart';


class TimerTool extends StatefulWidget {

  const TimerTool({super.key});


  @override
  State<TimerTool> createState() =>
      _TimerToolState();

}



class _TimerToolState
    extends State<TimerTool> {


  int waktu = 60;


  Timer? timer;


  bool berjalan = false;



  void mulai() {


    if (berjalan || waktu <= 0) return;



    berjalan = true;



    timer = Timer.periodic(

      const Duration(seconds:1),

      (t) {


        if (!mounted) return;



        if (waktu > 0) {


          setState(() {

            waktu--;

          });



        } else {


          timer?.cancel();


          berjalan = false;


        }


      },

    );


  }



  void reset() {


    timer?.cancel();


    setState(() {


      waktu = 60;


      berjalan = false;


    });


  }



  @override
  void dispose() {


    timer?.cancel();


    super.dispose();


  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar: AppBar(

        title:
            const Text("Timer"),

      ),



      body: Center(

        child: Column(

          mainAxisAlignment:
              MainAxisAlignment.center,


          children: [


            Text(

              "$waktu",

              style:
                  const TextStyle(

                fontSize:50,

                fontWeight:
                    FontWeight.bold,

              ),

            ),



            const SizedBox(
              height:20,
            ),



            Wrap(

              spacing:10,

              children: [


                ElevatedButton(

                  onPressed:
                      mulai,

                  child:
                      const Text("Mulai"),

                ),



                ElevatedButton(

                  onPressed:
                      reset,

                  child:
                      const Text("Reset"),

                ),


              ],

            ),


          ],

        ),

      ),

    );

  }

}