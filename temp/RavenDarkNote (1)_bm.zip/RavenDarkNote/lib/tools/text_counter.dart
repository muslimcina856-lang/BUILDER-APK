import 'package:flutter/material.dart';


class TextCounter extends StatefulWidget {

  const TextCounter({super.key});


  @override
  State<TextCounter> createState() =>
      _TextCounterState();

}



class _TextCounterState
    extends State<TextCounter> {


  final TextEditingController controller =
      TextEditingController();


  int karakter = 0;

  int kata = 0;

  int baris = 0;



  @override
  void dispose() {

    controller.dispose();

    super.dispose();

  }



  void hitung(String text) {


    setState(() {


      karakter =
          text.length;



      kata =
          text.trim().isEmpty

          ?

          0

          :

          text.trim()
              .split(RegExp(r'\s+'))
              .length;



      baris =
          text.isEmpty
          ?
          0
          :
          text.split("\n").length;


    });


  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar: AppBar(

        title:
            const Text("Text Counter"),

      ),



      body: Padding(

        padding:
            const EdgeInsets.all(20),



        child: Column(

          children: [


            TextField(

              controller:
                  controller,


              maxLines:
                  8,


              onChanged:
                  hitung,


              decoration:
                  const InputDecoration(

                border:
                    OutlineInputBorder(),

                hintText:
                    "Tulis teks...",

              ),

            ),



            const SizedBox(
              height:20,
            ),



            Text(
              "Karakter : $karakter",
            ),



            Text(
              "Kata : $kata",
            ),



            Text(
              "Baris : $baris",
            ),


          ],

        ),

      ),

    );

  }

}