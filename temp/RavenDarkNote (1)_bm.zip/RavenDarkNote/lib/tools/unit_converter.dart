import 'package:flutter/material.dart';


class UnitConverter extends StatelessWidget{

const UnitConverter({super.key});


@override
Widget build(BuildContext context){

return Scaffold(

appBar:
AppBar(

title:
const Text("Converter"),

),


body:
const Center(

child:

Text(

"KB ↔ MB\nMeter ↔ KM\nCelsius ↔ Fahrenheit",

textAlign:
TextAlign.center,

),

),

);

}

}