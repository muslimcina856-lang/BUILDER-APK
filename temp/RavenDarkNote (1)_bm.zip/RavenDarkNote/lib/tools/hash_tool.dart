import 'dart:convert';

import 'package:crypto/crypto.dart';

import 'package:flutter/material.dart';


class HashTool extends StatefulWidget {

  const HashTool({super.key});


  @override
  State<HashTool> createState() =>
      _HashToolState();

}



class _HashToolState
    extends State<HashTool> {


  final TextEditingController controller =
      TextEditingController();


  String hasil = "";



  @override
  void dispose() {

    controller.dispose();

    super.dispose();

  }



  void generate() {


    final text =
        controller.text.trim();



    if (text.isEmpty) {

      setState(() {

        hasil =
            "Masukkan teks terlebih dahulu";

      });

      return;

    }



    final md5Hash =
        md5.convert(

          utf8.encode(text),

        );



    final sha =
        sha256.convert(

          utf8.encode(text),

        );



    setState(() {


      hasil =
      """
MD5:

$md5Hash


SHA256:

$sha
""";


    });


  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar: AppBar(

        title:
            const Text("Hash Generator"),

      ),



      body: Padding(

        padding:
            const EdgeInsets.all(20),



        child: Column(

          children: [


            TextField(

              controller:
                  controller,

              decoration:
                  const InputDecoration(

                labelText:
                    "Text",

              ),

            ),



            const SizedBox(
              height:10,
            ),



            ElevatedButton(

              onPressed:
                  generate,

              child:
                  const Text("Generate"),

            ),



            const SizedBox(
              height:20,
            ),



            SelectableText(

              hasil,

              style:
                  const TextStyle(

                fontSize:16,

              ),

            ),


          ],

        ),

      ),

    );

  }

}