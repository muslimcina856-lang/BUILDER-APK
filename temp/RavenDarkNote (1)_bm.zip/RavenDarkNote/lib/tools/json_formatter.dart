import 'dart:convert';

import 'package:flutter/material.dart';


class JsonFormatter extends StatefulWidget {

  const JsonFormatter({super.key});


  @override
  State<JsonFormatter> createState() =>
      _JsonFormatterState();

}



class _JsonFormatterState
    extends State<JsonFormatter> {


  final TextEditingController controller =
      TextEditingController();


  String hasil = "";



  @override
  void dispose() {

    controller.dispose();

    super.dispose();

  }



  void format() {


    final input =
        controller.text.trim();



    if (input.isEmpty) {

      setState(() {

        hasil =
            "Masukkan JSON terlebih dahulu";

      });

      return;

    }



    try {


      final data =
          jsonDecode(input);



      setState(() {


        hasil =
            const JsonEncoder.withIndent("  ")
                .convert(data);


      });



    } catch (e) {


      setState(() {


        hasil =
            "JSON tidak valid";


      });


    }


  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar: AppBar(

        title:
            const Text("JSON Formatter"),

      ),



      body: Padding(

        padding:
            const EdgeInsets.all(20),



        child: Column(

          children: [


            TextField(

              controller:
                  controller,


              maxLines:
                  8,


              decoration:
                  const InputDecoration(

                hintText:
                    "Masukkan JSON",

                border:
                    OutlineInputBorder(),

              ),

            ),



            const SizedBox(
              height:10,
            ),



            ElevatedButton(

              onPressed:
                  format,


              child:
                  const Text("Format"),

            ),



            const SizedBox(
              height:10,
            ),



            Expanded(

              child:
                  SingleChildScrollView(

                child:
                    SelectableText(hasil),

              ),

            ),


          ],

        ),

      ),

    );

  }

}