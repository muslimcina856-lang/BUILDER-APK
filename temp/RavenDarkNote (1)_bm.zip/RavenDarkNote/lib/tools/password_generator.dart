import 'dart:math';
import 'package:flutter/material.dart';


class PasswordGenerator extends StatefulWidget {

  const PasswordGenerator({super.key});


  @override
  State<PasswordGenerator> createState() =>
      _PasswordGeneratorState();

}



class _PasswordGeneratorState
    extends State<PasswordGenerator> {


  String password = "";

  int length = 12;



  void generate() {


    const chars =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#\$%^&*";


    final random =
        Random();



    String result = "";



    for (int i = 0; i < length; i++) {


      result += chars[
        random.nextInt(chars.length)
      ];


    }



    setState(() {

      password = result;

    });


  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(


      appBar: AppBar(

        title:
            const Text("Password Generator"),

      ),



      body: Padding(

        padding:
            const EdgeInsets.all(20),



        child: Column(

          children: [


            Text(

              "Panjang: $length",

              style:
                  const TextStyle(

                fontSize:18,

              ),

            ),



            Slider(

              value:
                  length.toDouble(),

              min:
                  4,

              max:
                  32,

              divisions:
                  28,


              onChanged:(v){

                setState((){

                  length =
                      v.toInt();

                });

              },


            ),



            const SizedBox(
              height:20,
            ),



            Container(

              width:
                  double.infinity,


              padding:
                  const EdgeInsets.all(15),



              child:
                  SelectableText(

                password.isEmpty

                ?

                "Belum dibuat"

                :

                password,


                style:
                    const TextStyle(

                  fontSize:20,

                ),

              ),

            ),



            const SizedBox(
              height:20,
            ),



            ElevatedButton(

              onPressed:
                  generate,


              child:
                  const Text(
                    "Generate",
                  ),

            ),


          ],

        ),

      ),

    );

  }

}