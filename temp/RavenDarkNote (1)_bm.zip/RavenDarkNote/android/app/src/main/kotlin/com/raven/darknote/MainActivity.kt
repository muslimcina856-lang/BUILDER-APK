package com.raven.darknote

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() 