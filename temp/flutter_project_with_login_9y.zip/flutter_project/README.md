# AYONZ Soul Founder - Flutter Mobile App

A professional Flutter/Android application by **AYONZ Soul Founder**.

## Project Structure

```
flutter_project/
├── lib/                    # Dart source code
│   └── main.dart          # Application entry point
├── android/               # Android native code
│   ├── app/              # Android app module
│   │   ├── build.gradle  # Android build config
│   │   └── src/          # Android source files
│   └── build.gradle      # Project-level build config
├── ios/                  # iOS native code
├── web/                  # Web platform files
├── test/                 # Unit and widget tests
├── assets/               # Images, fonts, and other assets
├── pubspec.yaml         # Flutter dependencies & configuration
└── analysis_options.yaml # Linting rules
```

## Getting Started

### Prerequisites
- Flutter SDK (>=3.0.0)
- Android SDK (API 21+)
- Xcode (for iOS development)
- Dart (included with Flutter)

### Installation

1. **Clone the project:**
   ```bash
   cd flutter_project
   ```

2. **Install dependencies:**
   ```bash
   flutter pub get
   ```

3. **Run the app:**
   ```bash
   # On Android emulator/device
   flutter run
   
   # With verbose output
   flutter run -v
   ```

### Build Release APK

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-app.apk`

### Build Release Bundle

```bash
flutter build appbundle --release
```

Output: `build/app/outputs/app-release.aab`

## Project Features

- ✨ Modern Material 3 UI design
- 🌙 Dark theme with cyan accent colors
- 🎯 Responsive layout
- 📱 Android-optimized
- 🚀 Production-ready structure
- 📦 Dependency injection ready
- 🧪 Test structure included

## Key Dependencies

- **provider** - State management
- **http** - HTTP requests
- **cached_network_image** - Image caching
- **shared_preferences** - Local storage
- **get_it** - Service locator
- **dio** - Advanced HTTP client

## Code Style & Linting

This project follows strict Dart/Flutter linting rules defined in `analysis_options.yaml`.

Run linting:
```bash
flutter analyze
```

Format code:
```bash
dart format lib/
```

## Development Workflow

1. **Create new screens** in `lib/screens/`
2. **Add models** in `lib/models/`
3. **Create services** in `lib/services/`
4. **Write unit tests** in `test/`
5. **Update assets** in `assets/`

## Contact

**AYONZ Soul Founder**  
Email: ayonsoulfounder@gmail.com  
WhatsApp: [Your WhatsApp Link]

---

**Version:** 1.0.0  
**Last Updated:** 2024
