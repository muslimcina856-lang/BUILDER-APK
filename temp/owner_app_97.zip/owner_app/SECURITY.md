# Security Policy — Owner Panel

## Access Model

The owner panel is currently **single-tenant**. Anyone with network access to
the Vercel deployment can call admin APIs. Mitigations applied:

- Telegram bot commands restricted to `OWNER_TELEGRAM_ID` env var matching
- GitHub repo access via personal access token (rotate quarterly)
- Server-side validation of all admin actions in `vercel-api/`

## Reporting Critical Vulnerabilities

This panel has elevated privileges (can grant credits, generate codes, toggle
maintenance mode). If you find a vulnerability, **report immediately and
privately**:

- **Telegram:** [@earlxz](https://t.me/earlxz)
- Subject: `[SECURITY] Earl Builder Owner Panel`

Do NOT open public issues for anything affecting:
- Code generation endpoints
- Credit grant endpoints
- Maintenance toggle endpoints
- Telegram bot token leakage

## Scope

The owner panel shares the same serverless backend with the user app. Critical
vulnerabilities in `vercel-api/` are applicable to BOTH apps.

## Response Time

| Severity | Acknowledgement | Patch |
|----------|------------------|-------|
| Critical | 24 hours | 7 days |
| High     | 48 hours | 14 days |
| Medium   | 7 days   | 30 days |
| Low      | 30 days  | Best effort |

## Permission Audit

Owner panel requests MINIMIZE permission scope:

| Permission | Why needed |
|-----------|-----------|
| INTERNET | API calls to Vercel |
| ACCESS_NETWORK_STATE | Detect offline state |
| POST_NOTIFICATIONS | Background music notifications |
| WAKE_LOCK | Background music playback |

No camera, contacts, location, or storage permissions requested.

## Defense in Depth

For maximum hardening, deploy:
1. Behind a Cloudflare proxy with API token validation
2. Vercel deploys only from signed GitHub commits
3. Database (when added) should use encrypted connection strings
4. Rotate `TELEGRAM_BOT_TOKEN` and `GITHUB_TOKEN` quarterly
