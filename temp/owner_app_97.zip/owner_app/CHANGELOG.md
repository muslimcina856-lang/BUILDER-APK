# Changelog — Earl Builder Owner Panel

## [1.4.0+5] — 2026-07-11 (v11.4c — no auto-play wording)

### Added
- Background music feature (mirror of user app) on Dashboard
- Amber accent color (`#F4C44A`) for admin branding
- Splash screen with amber background and centered admin shield
- Adaptive launcher icon (amber shield with crown) + monochrome layer

### Changed
- Renamed `initAutoPlay()` → `playSaved()` in audio service
- Removed all "auto-play" wording
- Background Music section moved from About screen to Dashboard (bottom, after About tile)

### Fixed
- Mid-session stream drop detection (`onPlayerStateChanged` listener)

## [1.3.0+4] — 2026-07-10 (v11.3c)

### Added
- Auto-play on app launch for admin convenience

## [1.2.0+3] — 2026-07-09 (v11.2)

### Added
- Background music TextField on About screen
- `AudioService` singleton (mirrors user app)

## [1.1.0+2] — 2026-07-08 (v11.1)

### Changed
- Material 3 dark theme
- Stat tiles with prominent hero numbers
- All action tiles centered with chevron indicator

## [1.0.0+1] — 2026-07-07 (v11.0 — initial release)

### Added
- User list with credit grant
- Add credit screen
- Generate code screen (create redeem codes)
- Active codes dashboard
- Server toggle (online/offline maintenance mode)
