/// Centralized configuration for Earl Builder Owner App.
///
/// ╔═══════════════════════════════════════════════════════╗
/// ║  HARDCODED — Edit values below before building       ║
/// ╚═══════════════════════════════════════════════════════╝
class OwnerConfig {
  /// URL of your Vercel deployment (NO trailing slash)
  /// Example: 'https://earl-builder.vercel.app'
  static const String baseUrl = 'https://your-project.vercel.app';

  /// ═══════════════════════════════════════════════════════
  ///  DO NOT EDIT — Permanent links to owner & channel
  /// ═══════════════════════════════════════════════════════
  static const String ownerLink = 'https://t.me/earlxz';
  static const String channelLink = 'https://t.me/earlstore2004';

  /// ═══════════════════════════════════════════════════════
  ///  INTERNAL — Do not edit
  /// ═══════════════════════════════════════════════════════
  static const String appName = 'Earl Builder - Owner';
  static const String appTagline = 'Management Panel';
}
