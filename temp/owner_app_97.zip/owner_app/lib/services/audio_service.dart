import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Background music service — singleton.
/// Plays a streaming audio URL, looping continuously while the app is open
/// (continues via OS background audio when minimized).
class AudioService {
  AudioService._internal() {
    _player.setReleaseMode(ReleaseMode.loop);

    // Detect mid-session stream drops so the UI can surface them.
    // If the player transitions while we believe it is streaming, mark as
    // interrupted. Restoring playback (e.g. user re-submits) flips it back.
    _player.onPlayerStateChanged.listen((state) {
      if (state == PlayerState.stopped || state == PlayerState.completed) {
        if (_isPlaying && _statusMessage == 'Streaming\u2026') {
          _isPlaying = false;
          _statusMessage = 'Stream interrupted';
        }
      } else if (state == PlayerState.playing) {
        _isPlaying = true;
        if (_statusMessage == 'Stream interrupted') {
          _statusMessage = 'Streaming\u2026';
        }
      }
    });
  }

  static final AudioService _instance = AudioService._internal();
  factory AudioService() => _instance;

  final AudioPlayer _player = AudioPlayer();
  bool _isPlaying = false;
  String _currentUrl = '';
  String _statusMessage = '';

  static const String _urlPrefKey = 'bg_music_url';

  bool get isPlaying => _isPlaying;
  String get currentUrl => _currentUrl;
  String get status => _statusMessage;

  /// Play a streaming URL and persist it.
  Future<bool> play(String url) async {
    final trimmed = url.trim();

    // Empty URL → stop playback and clear saved URL ("disable music").
    if (trimmed.isEmpty) {
      try {
        await _player.stop();
      } catch (_) {}
      _isPlaying = false;
      _currentUrl = '';
      _statusMessage = 'Music disabled.';
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_urlPrefKey);
      return false;
    }
    final uri = Uri.tryParse(trimmed);
    if (uri == null || !(uri.isAbsolute && (uri.scheme == 'http' || uri.scheme == 'https'))) {
      _statusMessage = 'Invalid URL — must start with http:// or https://';
      return false;
    }
    try {
      if (_isPlaying && _currentUrl == trimmed) {
        _statusMessage = 'Already playing';
        return true;
      }
      await _player.setAudioContext(AudioContext(
        android: AudioContextAndroid(
          isSpeakerphoneOn: false,
          stayAwake: true,
          contentType: AndroidContentType.music,
          usageType: AndroidUsageType.media,
          audioFocus: AndroidAudioFocus.gain,
        ),
        iOS: AudioContextIOS(
          category: AVAudioSessionCategory.playback,
        ),
      ));
      await _player.stop();
      await _player.play(UrlSource(trimmed));
      _currentUrl = trimmed;
      _isPlaying = true;
      _statusMessage = 'Streaming…';
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_urlPrefKey, trimmed);
      return true;
    } catch (e) {
      _statusMessage = 'Failed: $e';
      _isPlaying = false;
      return false;
    }
  }

  /// Stop playback (URL stays saved).
  Future<void> stop() async {
    try {
      await _player.stop();
    } catch (_) {}
    _isPlaying = false;
    _statusMessage = 'Stopped';
  }

  /// Restore the last URL saved on disk.
  Future<String?> loadSavedUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_urlPrefKey);
  }

  Future<void> dispose() async {
    await _player.dispose();
  }

  /// Plays the last saved URL on app launch. Returns true if it played.
  Future<bool> playSaved() async {
    final saved = await loadSavedUrl();
    if (saved == null || saved.trim().isEmpty) return false;
    return await play(saved);
  }
}
