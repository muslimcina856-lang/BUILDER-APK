import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:earl_builder_owner/services/audio_service.dart';
import 'screens/dashboard_screen.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Plays last saved music URL on launch (non-blocking).
  AudioService().playSaved().catchError((_) => false);

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColors.bgBase,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const EarlOwnerApp());
}

class EarlOwnerApp extends StatelessWidget {
  const EarlOwnerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Earl Builder - Owner',
      debugShowCheckedModeBanner: false,
      theme: buildOwnerAppTheme(),
      home: const DashboardScreen(),
    );
  }
}
