import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class UserListScreen extends StatefulWidget {
  const UserListScreen({super.key});

  @override
  State<UserListScreen> createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _isLoading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadUsers();
    _searchController.addListener(_filterUsers);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadUsers() async {
    setState(() => _isLoading = true);
    try {
      final result = await OwnerApiService.getUsers();
      if (!mounted) return;
      setState(() {
        _users = List<Map<String, dynamic>>.from(result['users'] ?? <dynamic>[]);
        _filterUsers();
      });
    } catch (_) {}
    if (!mounted) return;
    setState(() => _isLoading = false);
  }

  void _filterUsers() {
    final query = _searchController.text.trim().toLowerCase();
    setState(() {
      _filtered = query.isEmpty
          ? _users
          : _users.where((u) {
              final devId = (u['device_id'] ?? '').toString().toLowerCase();
              final tgId = (u['telegram_id'] ?? '').toString().toLowerCase();
              return devId.contains(query) || tgId.contains(query);
            }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('User List')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.xxl,
                AppSpacing.md,
                AppSpacing.xxl,
                AppSpacing.md,
              ),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Search by device ID or Telegram ID…',
                  prefixIcon: const Icon(
                    Icons.search_rounded,
                    size: AppIcons.md,
                    color: AppColors.textMuted,
                  ),
                ),
                style: AppText.body,
              ),
            ),
            Expanded(
              child: _isLoading
                  ? const Center(
                      child: SizedBox(
                        width: 28,
                        height: 28,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          valueColor: AlwaysStoppedAnimation(AppColors.accent),
                        ),
                      ),
                    )
                  : _filtered.isEmpty
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(AppSpacing.xxl),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.inbox_rounded,
                                  size: AppIcons.hero,
                                  color: AppColors.textMuted,
                                ),
                                const SizedBox(height: AppSpacing.md),
                                Text(
                                  _searchController.text.isNotEmpty
                                      ? 'No matching users'
                                      : 'No registered users yet',
                                  style: AppText.heading,
                                ),
                              ],
                            ),
                          ),
                        )
                      : RefreshIndicator(
                          color: AppColors.accent,
                          backgroundColor: AppColors.bgElevated,
                          onRefresh: _loadUsers,
                          child: ListView.separated(
                            padding: const EdgeInsets.fromLTRB(
                              AppSpacing.xxl,
                              0,
                              AppSpacing.xxl,
                              AppSpacing.huge,
                            ),
                            itemCount: _filtered.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: AppSpacing.sm),
                            itemBuilder: (_, i) =>
                                _UserCard(user: _filtered[i]),
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _UserCard extends StatelessWidget {
  final Map<String, dynamic> user;
  const _UserCard({required this.user});

  @override
  Widget build(BuildContext context) {
    final deviceId = (user['device_id'] ?? '').toString();
    final telegramId = user['telegram_id']?.toString();
    final credits = (user['credits'] ?? 0).toString();
    final uploads = (user['total_uploads'] ?? 0).toString();
    final createdAt = (user['created_at'] ?? '').toString();

    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                telegramId != null
                    ? Icons.link_rounded
                    : Icons.link_off_rounded,
                size: AppIcons.sm,
                color: telegramId != null
                    ? AppColors.accent
                    : AppColors.textMuted,
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  deviceId,
                  style: AppText.mono.copyWith(fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),
          Row(
            children: [
              _MicroStat(label: 'Credits', value: credits, accent: true),
              const SizedBox(width: AppSpacing.lg),
              _MicroStat(label: 'Submits', value: uploads),
              const SizedBox(width: AppSpacing.lg),
              _MicroStat(label: 'TG', value: telegramId ?? '-'),
            ],
          ),
          if (createdAt.isNotEmpty) ...[
            const SizedBox(height: AppSpacing.sm),
            Text('Since: $createdAt', style: AppText.caption),
          ],
        ],
      ),
    );
  }
}

class _MicroStat extends StatelessWidget {
  final String label;
  final String value;
  final bool accent;

  const _MicroStat({
    required this.label,
    required this.value,
    this.accent = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: AppText.body.copyWith(
            fontWeight: FontWeight.w600,
            color: accent ? AppColors.accent : AppColors.textPrimary,
          ),
        ),
        const SizedBox(width: 4),
        Text(label, style: AppText.caption),
      ],
    );
  }
}
