import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class AddCreditScreen extends StatefulWidget {
  final VoidCallback? onDone;
  const AddCreditScreen({super.key, this.onDone});

  @override
  State<AddCreditScreen> createState() => _AddCreditScreenState();
}

class _AddCreditScreenState extends State<AddCreditScreen> {
  final _targetController = TextEditingController();
  final _amountController = TextEditingController();
  bool _isLoading = false;
  String? _result;
  bool _isSuccess = false;

  @override
  void dispose() {
    _targetController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _addCredits() async {
    final target = _targetController.text.trim();
    final amount = int.tryParse(_amountController.text.trim());

    if (target.isEmpty || amount == null || amount <= 0) {
      setState(() {
        _result = 'Please enter a valid ID and amount.';
        _isSuccess = false;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _result = null;
    });

    try {
      final result = await OwnerApiService.addCredits(
        target: target,
        amount: amount,
      );
      if (!mounted) return;
      setState(() {
        _isSuccess = result['success'] == true;
        _result = (result['message'] ?? '').toString();
        if (_isSuccess) {
          _targetController.clear();
          _amountController.clear();
          widget.onDone?.call();
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSuccess = false;
        _result = 'Failed: $e';
      });
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Credits')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            const Text('Add Credits', style: AppText.title),
            const SizedBox(height: AppSpacing.xs),
            const Text(
              'Grant credits to a user by their device ID or Telegram ID.',
              style: AppText.subtitle,
            ),
            const SizedBox(height: AppSpacing.xxl),
            TextField(
              controller: _targetController,
              decoration: const InputDecoration(
                labelText: 'Device ID / Telegram ID',
                hintText: 'device_xxx or Telegram handle',
                prefixIcon: Icon(
                  Icons.person_search_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
              style: AppText.body.copyWith(fontSize: 13),
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(
                labelText: 'Amount',
                hintText: 'e.g. 50',
                prefixIcon: Icon(
                  Icons.add_circle_outline_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
              keyboardType: TextInputType.number,
              style: AppText.body,
            ),
            const SizedBox(height: AppSpacing.xl),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _isLoading ? null : _addCredits,
                icon: _isLoading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.onAccent,
                        ),
                      )
                    : const Icon(Icons.add_rounded, size: AppIcons.md),
                label: const Text('ADD CREDITS'),
              ),
            ),
            if (_result != null) ...[
              const SizedBox(height: AppSpacing.xl),
              _ResultBanner(isSuccess: _isSuccess, message: _result!),
            ],
          ],
        ),
      ),
    );
  }
}

class _ResultBanner extends StatelessWidget {
  final bool isSuccess;
  final String message;
  const _ResultBanner({required this.isSuccess, required this.message});

  @override
  Widget build(BuildContext context) {
    final color = isSuccess ? AppColors.success : AppColors.error;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: color.withAlpha(15),
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: color.withAlpha(60)),
      ),
      child: Row(
        children: [
          Icon(
            isSuccess ? Icons.check_circle_rounded : Icons.error_rounded,
            size: AppIcons.md,
            color: color,
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Text(message, style: AppText.body.copyWith(color: color)),
          ),
        ],
      ),
    );
  }
}
