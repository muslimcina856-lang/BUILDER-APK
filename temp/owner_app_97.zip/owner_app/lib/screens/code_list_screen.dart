import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class CodeListScreen extends StatefulWidget {
  const CodeListScreen({super.key});

  @override
  State<CodeListScreen> createState() => _CodeListScreenState();
}

class _CodeListScreenState extends State<CodeListScreen> {
  List<Map<String, dynamic>> _codes = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);
    try {
      final result = await OwnerApiService.getCodes();
      if (!mounted) return;
      setState(() {
        _codes = List<Map<String, dynamic>>.from(result['codes'] ?? <dynamic>[]);
      });
    } catch (_) {}
    if (!mounted) return;
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Active Codes')),
      body: SafeArea(
        child: _isLoading
            ? const Center(
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation(AppColors.accent),
                  ),
                ),
              )
            : _codes.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(AppSpacing.xxl),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.redeem_rounded,
                            size: AppIcons.hero,
                            color: AppColors.textMuted,
                          ),
                          const SizedBox(height: AppSpacing.md),
                          const Text('No active codes', style: AppText.heading),
                          const SizedBox(height: AppSpacing.xs),
                          const Text(
                            'Generate codes from the Generate Codes menu.',
                            style: AppText.subtitle,
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  )
                : RefreshIndicator(
                    color: AppColors.accent,
                    backgroundColor: AppColors.bgElevated,
                    onRefresh: _load,
                    child: ListView.separated(
                      padding: const EdgeInsets.fromLTRB(
                        AppSpacing.xxl,
                        AppSpacing.lg,
                        AppSpacing.xxl,
                        AppSpacing.huge,
                      ),
                      itemCount: _codes.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: AppSpacing.sm),
                      itemBuilder: (_, i) => _CodeRow(code: _codes[i]),
                    ),
                  ),
      ),
    );
  }
}

class _CodeRow extends StatelessWidget {
  final Map<String, dynamic> code;
  const _CodeRow({required this.code});

  @override
  Widget build(BuildContext context) {
    final c = (code['code'] ?? '').toString();
    final amount = (code['amount'] ?? 0).toString();
    final createdAt = (code['created_at'] ?? '').toString();

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.md,
      ),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  c,
                  style: AppText.body.copyWith(
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1,
                    color: AppColors.accent,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '$amount credits${createdAt.isNotEmpty ? ' · $createdAt' : ''}',
                  style: AppText.caption,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.sm + 2,
              vertical: 4,
            ),
            decoration: BoxDecoration(
              color: AppColors.success.withAlpha(20),
              borderRadius: BorderRadius.circular(AppRadius.pill),
            ),
            child: Text(
              'ACTIVE',
              style: AppText.caption.copyWith(
                color: AppColors.success,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
                fontSize: 11,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
