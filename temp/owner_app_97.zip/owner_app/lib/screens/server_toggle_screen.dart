import 'package:flutter/material.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class ServerToggleScreen extends StatefulWidget {
  final VoidCallback? onChanged;
  const ServerToggleScreen({super.key, this.onChanged});

  @override
  State<ServerToggleScreen> createState() => _ServerToggleScreenState();
}

class _ServerToggleScreenState extends State<ServerToggleScreen> {
  bool _isOn = false;
  bool _isLoading = true;
  bool _isSaving = false;
  final _titleController = TextEditingController();
  final _messageController = TextEditingController();
  String? _result;
  bool _isSuccess = false;

  @override
  void initState() {
    super.initState();
    _loadStatus();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _loadStatus() async {
    setState(() => _isLoading = true);
    try {
      final result = await OwnerApiService.getServerStatus();
      if (!mounted) return;
      setState(() {
        _isOn = result['maintenance_mode']?.toString() == 'on';
        _titleController.text = (result['maintenance_title'] ?? '').toString();
        _messageController.text = (result['maintenance_message'] ?? '').toString();
      });
    } catch (_) {}
    if (!mounted) return;
    setState(() => _isLoading = false);
  }

  Future<void> _toggle() async {
    setState(() {
      _isSaving = true;
      _result = null;
    });

    final newMode = _isOn ? 'off' : 'on';
    final title = _titleController.text.trim();
    final message = _messageController.text.trim();

    try {
      final result = await OwnerApiService.toggleServer(
        mode: newMode,
        title: title.isEmpty ? null : title,
        message: message.isEmpty ? null : message,
      );
      if (!mounted) return;
      setState(() {
        _isOn = newMode == 'on';
        _isSuccess = true;
        _result = (result['message'] ?? '').toString();
      });
      widget.onChanged?.call();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSuccess = false;
        _result = 'Failed: $e';
      });
    }
    setState(() => _isSaving = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Toggle Server')),
        body: const Center(
          child: SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              valueColor: AlwaysStoppedAnimation(AppColors.accent),
            ),
          ),
        ),
      );
    }

    final color = _isOn ? AppColors.error : AppColors.success;

    return Scaffold(
      appBar: AppBar(title: const Text('Toggle Server')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            Container(
              padding: const EdgeInsets.all(AppSpacing.xxl),
              decoration: BoxDecoration(
                color: color.withAlpha(15),
                borderRadius: BorderRadius.circular(AppRadius.hero),
                border: Border.all(color: color.withAlpha(60)),
              ),
              child: Column(
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Text(
                    _isOn ? 'SERVER OFFLINE' : 'SERVER ONLINE',
                    style: AppText.title.copyWith(color: color, fontSize: 18),
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    _isOn
                        ? 'Users will not be able to submit projects.'
                        : 'Everything is operating normally.',
                    style: AppText.subtitle.copyWith(
                      color: AppColors.textSecondary,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.xxxl),
            const Text('MAINTENANCE MESSAGE', style: AppText.sectionLabel),
            const SizedBox(height: 2),
            const Text(
              'Optional — shown to users while the server is offline.',
              style: AppText.caption,
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Title',
                hintText: 'Server undergoing maintenance',
                prefixIcon: Icon(
                  Icons.title_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _messageController,
              decoration: const InputDecoration(
                labelText: 'Message',
                hintText: 'Please try again later…',
                prefixIcon: Icon(
                  Icons.notes_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: AppSpacing.xl),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _isSaving ? null : _toggle,
                style: ElevatedButton.styleFrom(
                  backgroundColor: color,
                  foregroundColor: _isOn ? Colors.white : AppColors.onAccent,
                ),
                icon: _isSaving
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.onAccent,
                        ),
                      )
                    : Icon(
                        _isOn
                            ? Icons.toggle_on_rounded
                            : Icons.toggle_off_rounded,
                        size: AppIcons.md,
                      ),
                label: Text(_isOn ? 'BRING ONLINE' : 'TAKE OFFLINE'),
              ),
            ),
            if (_result != null) ...[
              const SizedBox(height: AppSpacing.xl),
              _ResultBanner(isSuccess: _isSuccess, message: _result!),
            ],
            const SizedBox(height: AppSpacing.xl),
            Text(
              'Note: the owner panel itself is not affected by this toggle.',
              style: AppText.caption.copyWith(color: AppColors.textDisabled),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResultBanner extends StatelessWidget {
  final bool isSuccess;
  final String message;
  const _ResultBanner({required this.isSuccess, required this.message});

  @override
  Widget build(BuildContext context) {
    final color = isSuccess ? AppColors.success : AppColors.error;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: color.withAlpha(15),
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: color.withAlpha(60)),
      ),
      child: Row(
        children: [
          Icon(
            isSuccess ? Icons.check_circle_rounded : Icons.error_rounded,
            size: AppIcons.md,
            color: color,
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Text(message, style: AppText.body.copyWith(color: color)),
          ),
        ],
      ),
    );
  }
}
