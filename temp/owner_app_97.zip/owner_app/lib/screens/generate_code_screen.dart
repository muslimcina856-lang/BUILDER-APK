import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:earl_builder_owner/services/api_service.dart';
import 'package:earl_builder_owner/theme/app_theme.dart';

class GenerateCodeScreen extends StatefulWidget {
  const GenerateCodeScreen({super.key});

  @override
  State<GenerateCodeScreen> createState() => _GenerateCodeScreenState();
}

class _GenerateCodeScreenState extends State<GenerateCodeScreen> {
  final _amountController = TextEditingController();
  final _countController = TextEditingController(text: '1');
  bool _isLoading = false;
  List<Map<String, dynamic>>? _generatedCodes;

  @override
  void dispose() {
    _amountController.dispose();
    _countController.dispose();
    super.dispose();
  }

  Future<void> _generate() async {
    final amount = int.tryParse(_amountController.text.trim());
    final count = int.tryParse(_countController.text.trim());

    if (amount == null || amount <= 0 || count == null || count <= 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter valid amount and count.'),
          backgroundColor: AppColors.error,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);
    try {
      final result = await OwnerApiService.generateCodes(amount: amount, count: count);
      if (!mounted) return;
      setState(() {
        _generatedCodes =
            List<Map<String, dynamic>>.from(result['codes'] ?? <dynamic>[]);
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed: $e'),
          backgroundColor: AppColors.error,
        ),
      );
    }
    setState(() => _isLoading = false);
  }

  Future<void> _shareCodes() async {
    if (_generatedCodes == null || _generatedCodes!.isEmpty) return;
    final text = _generatedCodes!
        .map((c) => '${c['code']} (${c['amount']} credits)')
        .join('\n');
    try {
      await SharePlus.instance.share(
        ShareParams(text: 'Earl Builder credit codes:\n\n$text'),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Share failed: $e'),
          backgroundColor: AppColors.error,
        ),
      );
    }
  }

  void _copyCode(String code) {
    Clipboard.setData(ClipboardData(text: code));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Code $code copied'),
        backgroundColor: AppColors.success,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Generate Codes')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            const Text('Set parameters', style: AppText.title),
            const SizedBox(height: AppSpacing.xs),
            const Text(
              'Generate 12-character codes to share with users.',
              style: AppText.subtitle,
            ),
            const SizedBox(height: AppSpacing.xxl),
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(
                labelText: 'Credits per code',
                hintText: 'e.g. 50',
                prefixIcon: Icon(
                  Icons.monetization_on_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
              keyboardType: TextInputType.number,
              style: AppText.body,
            ),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _countController,
              decoration: const InputDecoration(
                labelText: 'Number of codes (max 50)',
                hintText: '1 – 50',
                prefixIcon: Icon(
                  Icons.tag_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
              keyboardType: TextInputType.number,
              style: AppText.body,
            ),
            const SizedBox(height: AppSpacing.xl),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _isLoading ? null : _generate,
                icon: _isLoading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.onAccent,
                        ),
                      )
                    : const Icon(Icons.auto_awesome_rounded, size: AppIcons.md),
                label: const Text('GENERATE'),
              ),
            ),
            if (_generatedCodes != null && _generatedCodes!.isNotEmpty) ...[
              const SizedBox(height: AppSpacing.xxxl),
              Row(
                children: [
                  const Text('GENERATED CODES', style: AppText.sectionLabel),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: _shareCodes,
                    icon: const Icon(Icons.share_rounded, size: AppIcons.sm),
                    label: const Text('Share'),
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.accent,
                      textStyle: AppText.body.copyWith(
                        color: AppColors.accent,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              ..._generatedCodes!.map(
                (c) => Padding(
                  padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                  child: _CodeCard(
                    code: (c['code'] ?? '').toString(),
                    amount: (c['amount'] ?? 0).toString(),
                    onCopy: () => _copyCode((c['code'] ?? '').toString()),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _CodeCard extends StatelessWidget {
  final String code;
  final String amount;
  final VoidCallback onCopy;

  const _CodeCard({
    required this.code,
    required this.amount,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.lg,
        vertical: AppSpacing.md,
      ),
      decoration: BoxDecoration(
        color: AppColors.bgElevated,
        borderRadius: BorderRadius.circular(AppRadius.card),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  code,
                  style: AppText.body.copyWith(
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1,
                    color: AppColors.accent,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 3),
                Text('$amount credits', style: AppText.caption),
              ],
            ),
          ),
          IconButton(
            onPressed: onCopy,
            icon: const Icon(
              Icons.copy_rounded,
              size: AppIcons.sm,
              color: AppColors.textMuted,
            ),
            splashRadius: 20,
            tooltip: 'Copy code',
          ),
        ],
      ),
    );
  }
}
