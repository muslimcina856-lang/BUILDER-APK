# Contributing to Earl Builder (Owner Panel)

Same guidelines as the user app — see `user_app/CONTRIBUTING.md` for full
process. Differences for the owner app:

## Admin-Specific Setup

The owner panel requires:
- An active Vercel deployment URL (set in `lib/config.dart`)
- Telegram bot token (configured server-side in `vercel-api/`)
- GitHub repository for build artifacts

## Authentication

The owner panel is currently single-tenant (one panel = one admin). When
adding multi-admin support:

- Use Telegram OAuth (recommended) — owner authenticates via Telegram handle
- Alternative: simple password gate via env var (less secure)
- Avoid API-only auth (no MFA inside the app)

## Code Style

- Use `OwnerConfig.*` for all configurable constants
- All numeric values in cards use `AppText.statNumber` style
- Server status banner color: `success` for online, `error` for offline
- Action tiles: `Icon` → row → title + subtitle → trailing chevron

## Verifying Changes

```bash
flutter analyze        # Must be 0 errors / 0 warnings
flutter run            # Test against real Vercel deployment
```

## Reporting Bugs

Bugs affecting **production builds** (e.g., wrong user counts, broken code
generation) should be opened with `priority: critical` label and on-call
notification via Telegram bot.
