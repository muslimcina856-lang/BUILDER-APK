package com.example.prankapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener {

    private RelativeLayout root;
    private TextView mainText, subText, icon, swipeInstruction, swipeArrow;
    private Handler handler = new Handler(Looper.getMainLooper());

    private boolean[] flickerState = {true};
    private final int FLICKER_DURATION_MS = 300000;
    private final int FLICKER_INTERVAL_MS = 150;

    private MediaPlayer mediaPlayer;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean hasFlash = false;
    private Runnable flickerRunnableRef;
    private boolean canExit = false;

    // Untuk swipe-up + tahan
    private boolean isSwiping = false;
    private boolean swipeUnlockTriggered = false;
    private Runnable swipeHoldRunnable;
    private final long HOLD_DURATION_MS = 15000; // tahan 1.5 detik setelah swipe
    private float swipeStartY = 0f;

    // Untuk volume ramp-up
    private Runnable volumeRampRunnable;
    private int currentVolume = 0;
    private final int VOLUME_RAMP_STEP_MS = 700; // setiap 700ms naikkan volume

    private GestureDetectorCompat gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Layar full brightness
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = 1.0f;
        getWindow().setAttributes(lp);

        root = findViewById(R.id.root_layout);
        mainText = findViewById(R.id.main_text);
        subText = findViewById(R.id.sub_text);
        icon = findViewById(R.id.warning_icon);
        swipeInstruction = findViewById(R.id.swipe_instruction);
        swipeArrow = findViewById(R.id.swipe_arrow);

        // Setup gesture detector untuk swipe
        gestureDetector = new GestureDetectorCompat(this, this);

        // Vibrate saat pertama buka
        try {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(800);
                }
            }
        } catch (Exception ignored) {}

        setupFlashlight();

        // Minta permission kamera jika belum ada
        if (Build.VERSION.SDK_INT >= 28) {
            if (checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.CAMERA}, 100);
            }
        }

        // Start background service agar tetap jalan walau app ditutup
        Intent serviceIntent = new Intent(this, AlarmService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        // Mulai dengan volume 0, lalu naikan perlahan
        startVolumeRamp();

        playAlarmSound();
        startFlicker();
        startFlashBlink();

        // Setelah flicker selesai, tampil layar "kunci"
        handler.postDelayed(this::revealSwipeScreen, FLICKER_DURATION_MS);
    }

    // ===================== VOLUME RAMP-UP =====================
    // Volume mulai dari 0, naik satu langkah tiap VOLUME_RAMP_STEP_MS
    private void startVolumeRamp() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am == null) return;

        int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);

        // Mulai dari volume paling pelan
        currentVolume = 0;
        am.setStreamVolume(AudioManager.STREAM_ALARM, currentVolume, 0);

        volumeRampRunnable = new Runnable() {
            @Override
            public void run() {
                if (currentVolume < max) {
                    currentVolume++;
                    am.setStreamVolume(AudioManager.STREAM_ALARM, currentVolume, 0);
                    handler.postDelayed(this, VOLUME_RAMP_STEP_MS);
                }
                // Jika sudah max, berhenti naik
            }
        };
        handler.postDelayed(volumeRampRunnable, VOLUME_RAMP_STEP_MS);
    }

    private void stopVolumeRamp() {
        if (volumeRampRunnable != null) {
            handler.removeCallbacks(volumeRampRunnable);
            volumeRampRunnable = null;
        }
    }

    // ===================== ALARM SOUND =====================
    private void playAlarmSound() {
        try {
            Uri alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_NOTIFICATION);
            }
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE);
            }
            if (alarmUri != null) {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
                mediaPlayer.setDataSource(this, alarmUri);
                mediaPlayer.setLooping(true);
                mediaPlayer.prepare();
                // Jangan set volume max di sini — dibiarkan naik perlahan oleh volumeRamp
                mediaPlayer.start();
            }
        } catch (Exception ignored) {}
    }

    private void stopAlarmSound() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception ignored) {}
    }

    // ===================== FLASHLIGHT =====================
    private void setupFlashlight() {
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager != null) {
                for (String id : cameraManager.getCameraIdList()) {
                    Boolean flashAvailable = cameraManager.getCameraCharacteristics(id)
                            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (flashAvailable != null && flashAvailable) {
                        cameraId = id;
                        hasFlash = true;
                        break;
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void setFlash(boolean on) {
        if (!hasFlash || cameraManager == null || cameraId == null) return;
        try {
            cameraManager.setTorchMode(cameraId, on);
        } catch (CameraAccessException ignored) {}
    }

    private void startFlashBlink() {
        if (!hasFlash) return;
        Runnable flashRunnable = new Runnable() {
            boolean on = false;
            @Override
            public void run() {
                on = !on;
                setFlash(on);
                if (flickerRunnableRef != null) {
                    handler.postDelayed(this, FLICKER_INTERVAL_MS);
                } else {
                    setFlash(false);
                }
            }
        };
        handler.post(flashRunnable);
    }

    // ===================== FLICKER LAYAR =====================
    private void startFlicker() {
        Runnable flickerRunnable = new Runnable() {
            @Override
            public void run() {
                if (flickerState[0]) {
                    root.setBackgroundColor(Color.parseColor("#B71C1C"));
                } else {
                    root.setBackgroundColor(Color.parseColor("#FF1744"));
                }
                flickerState[0] = !flickerState[0];
                handler.postDelayed(this, FLICKER_INTERVAL_MS);
            }
        };
        handler.post(flickerRunnable);
        flickerRunnableRef = flickerRunnable;
    }

    // ===================== TAMPIL LAYAR KUNCI =====================
    private void revealSwipeScreen() {
        handler.removeCallbacks(flickerRunnableRef);
        flickerRunnableRef = null;
        setFlash(false);
        stopAlarmSound();
        stopVolumeRamp();

        root.setBackgroundColor(Color.parseColor("#1A1A1A"));
        icon.setText("🔒");
        mainText.setText("Terkunci");
        subText.setText("APK ini sedang disemak untuk membuka, geser ke atas dan tahan");

        swipeInstruction.setText("↑ Geser ke Atas & Tahan ↑");
        swipeInstruction.setVisibility(View.VISIBLE);
        swipeArrow.setVisibility(View.VISIBLE);

        canExit = false;
    }

    // ===================== TOUCH & GESTURE =====================
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);

        // Deteksi tahan (hold) setelah swipe ke atas
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                swipeStartY = event.getY();
                isSwiping = false;
                break;

            case MotionEvent.ACTION_MOVE:
                float dy = swipeStartY - event.getY(); // positif = gerak ke atas
                if (dy > 100 && !isSwiping && !swipeUnlockTriggered) {
                    // Pengguna sedang swipe ke atas — mulai hitung waktu tahan
                    isSwiping = true;
                    swipeHoldRunnable = () -> {
                        if (isSwiping && !swipeUnlockTriggered) {
                            swipeUnlockTriggered = true;
                            unlockScreen();
                        }
                    };
                    handler.postDelayed(swipeHoldRunnable, HOLD_DURATION_MS);
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                // Jika diangkat sebelum waktu tahan terpenuhi, batalkan unlock
                if (swipeHoldRunnable != null && !swipeUnlockTriggered) {
                    handler.removeCallbacks(swipeHoldRunnable);
                    swipeHoldRunnable = null;
                }
                isSwiping = false;
                break;
        }

        return true;
    }

    // Metode wajib dari GestureDetector.OnGestureListener
    @Override public boolean onDown(MotionEvent e) { return true; }
    @Override public void onShowPress(MotionEvent e) {}
    @Override public boolean onSingleTapUp(MotionEvent e) { return false; }
    @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dX, float dY) { return false; }
    @Override public void onLongPress(MotionEvent e) {}
    @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float velX, float velY) { return true; }

    // ===================== UNLOCK REVEAL =====================
    private void unlockScreen() {
        root.setBackgroundColor(Color.parseColor("#2E7D32"));
        icon.setText("😂");
        mainText.setText("JK! Cuma Prank!");
        subText.setText("Santai, HP kamu aman kok 😄");
        swipeInstruction.setVisibility(View.GONE);
        swipeArrow.setVisibility(View.GONE);

        // Tutup app setelah 2 detik
        handler.postDelayed(() -> finish(), 2000);
    }

    // ===================== TOMBOL BACK DIBLOKIR =====================
    @Override
    public void onBackPressed() {
        // Tidak bisa keluar sebelum swipe+tahan berhasil
        if (swipeUnlockTriggered) {
            super.onBackPressed();
        }
        // else: abaikan
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        setFlash(false);
        stopAlarmSound();
        stopVolumeRamp();
        handler.removeCallbacksAndMessages(null);
    }
}
