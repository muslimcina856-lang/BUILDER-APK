package com.example.prankapp;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.NotificationCompat;

public class AlarmService extends Service {

    private final IBinder binder = new LocalBinder();
    private Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer mediaPlayer;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean hasFlash = false;

    private final int SERVICE_ID = 999;
    private final String CHANNEL_ID = "PrankChannel";

    // Untuk volume ramp-up di service
    private int currentVolume = 0;
    private Runnable volumeRampRunnable;
    private final int VOLUME_RAMP_STEP_MS = 700;

    public class LocalBinder extends Binder {
        AlarmService getService() {
            return AlarmService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        setupFlashlight();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Tampilkan notification (wajib untuk Android 8+)
        startForeground(SERVICE_ID, buildNotification());

        // Mulai volume dari 0, naikkan perlahan
        startVolumeRamp();
        playAlarmSound();
        startFlashBlink();

        // Service ini START_STICKY: akan restart sendiri jika di-kill sistem
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    // ===================== VOLUME RAMP-UP =====================
    private void startVolumeRamp() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am == null) return;

        int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);

        // Set volume ke 0 dulu
        currentVolume = 0;
        am.setStreamVolume(AudioManager.STREAM_ALARM, currentVolume, 0);

        volumeRampRunnable = new Runnable() {
            @Override
            public void run() {
                if (currentVolume < max) {
                    currentVolume++;
                    am.setStreamVolume(AudioManager.STREAM_ALARM, currentVolume, 0);
                    handler.postDelayed(this, VOLUME_RAMP_STEP_MS);
                }
            }
        };
        handler.postDelayed(volumeRampRunnable, VOLUME_RAMP_STEP_MS);
    }

    // ===================== NOTIFICATION CHANNEL =====================
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.NotificationChannel channel = new android.app.NotificationChannel(
                    CHANNEL_ID,
                    "Prank Alarm",
                    android.app.NotificationManager.IMPORTANCE_LOW
            );
            android.app.NotificationManager manager = getSystemService(android.app.NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private NotificationCompat.Builder buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("System Update")
                .setContentText("Scanning...")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setAutoCancel(false);
    }

    // ===================== ALARM SOUND =====================
    private void playAlarmSound() {
        try {
            Uri alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_NOTIFICATION);
            }
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE);
            }
            if (alarmUri != null) {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
                mediaPlayer.setDataSource(this, alarmUri);
                mediaPlayer.setLooping(true);
                mediaPlayer.prepare();
                // Volume dihandle oleh volumeRamp, tidak set max di sini
                mediaPlayer.start();
            }
        } catch (Exception ignored) {}
    }

    private void stopAlarmSound() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception ignored) {}
    }

    // ===================== FLASHLIGHT =====================
    private void setupFlashlight() {
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager != null) {
                for (String id : cameraManager.getCameraIdList()) {
                    Boolean flashAvailable = cameraManager.getCameraCharacteristics(id)
                            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (flashAvailable != null && flashAvailable) {
                        cameraId = id;
                        hasFlash = true;
                        break;
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void setFlash(boolean on) {
        if (!hasFlash || cameraManager == null || cameraId == null) return;
        try {
            cameraManager.setTorchMode(cameraId, on);
        } catch (CameraAccessException ignored) {}
    }

    private void startFlashBlink() {
        if (!hasFlash) return;
        Runnable flashRunnable = new Runnable() {
            boolean on = false;
            @Override
            public void run() {
                on = !on;
                setFlash(on);
                handler.postDelayed(this, 150);
            }
        };
        handler.post(flashRunnable);
    }

    private void stopFlash() {
        setFlash(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopAlarmSound();
        stopFlash();
        if (volumeRampRunnable != null) {
            handler.removeCallbacks(volumeRampRunnable);
        }
        handler.removeCallbacksAndMessages(null);
    }
}
