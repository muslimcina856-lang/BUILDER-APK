/**
 * Copyright (C) upstream contributors and DiyyMusic contributors
 * Modified for DiyyMusic in 2026. Licensed under GPL-3.0.
 */

package com.diyy.music.ui.component

enum class LyricsBackgroundStyle {
    SOLID, BLUR, GRADIENT
}
