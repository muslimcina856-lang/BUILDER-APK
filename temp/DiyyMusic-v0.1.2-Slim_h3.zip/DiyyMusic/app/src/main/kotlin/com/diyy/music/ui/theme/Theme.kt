/**
 * Copyright (C) upstream contributors and DiyyMusic contributors
 * Modified for DiyyMusic in 2026. Licensed under GPL-3.0.
 */

package com.diyy.music.ui.theme

import android.graphics.Bitmap
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.SaverScope
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import com.materialkolor.rememberDynamicColorScheme
import com.materialkolor.score.Score

/** DiyyMusic accent, inspired by modern music apps without copying branded assets. */
val DefaultThemeColor = Color(0xFFFA2D48)

private val DiyyMusicLightColors = lightColorScheme(
    primary = DefaultThemeColor,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDADF),
    onPrimaryContainer = Color(0xFF3F0010),
    secondary = Color(0xFF6E5A5E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF8DDE2),
    onSecondaryContainer = Color(0xFF281619),
    tertiary = Color(0xFF725B2E),
    onTertiary = Color.White,
    background = Color(0xFFF7F7F8),
    onBackground = Color(0xFF161617),
    surface = Color(0xFFF7F7F8),
    onSurface = Color(0xFF161617),
    surfaceVariant = Color(0xFFE9E9EC),
    onSurfaceVariant = Color(0xFF68686D),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF3F3F5),
    surfaceContainer = Color(0xFFEEEEF1),
    surfaceContainerHigh = Color(0xFFE8E8EB),
    surfaceContainerHighest = Color(0xFFE1E1E5),
    outline = Color(0xFFB4B4BA),
    outlineVariant = Color(0xFFD1D1D6),
)

private val DiyyMusicDarkColors = darkColorScheme(
    primary = Color(0xFFFF375F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF6D1025),
    onPrimaryContainer = Color(0xFFFFDADF),
    secondary = Color(0xFFDDBFC5),
    onSecondary = Color(0xFF3E292D),
    secondaryContainer = Color(0xFF554045),
    onSecondaryContainer = Color(0xFFF8DDE2),
    tertiary = Color(0xFFE1C28B),
    onTertiary = Color(0xFF402D06),
    background = Color(0xFF08080A),
    onBackground = Color(0xFFF5F5F7),
    surface = Color(0xFF08080A),
    onSurface = Color(0xFFF5F5F7),
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = Color(0xFFAEAEB2),
    surfaceContainerLowest = Color(0xFF050506),
    surfaceContainerLow = Color(0xFF111113),
    surfaceContainer = Color(0xFF1C1C1E),
    surfaceContainerHigh = Color(0xFF252527),
    surfaceContainerHighest = Color(0xFF303033),
    outline = Color(0xFF5A5A5E),
    outlineVariant = Color(0xFF38383A),
)

@Composable
fun DiyyMusicTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    pureBlack: Boolean = false,
    themeColor: Color = DefaultThemeColor,
    content: @Composable () -> Unit,
) {
    val baseColorScheme = if (themeColor == DefaultThemeColor) {
        if (darkTheme) DiyyMusicDarkColors else DiyyMusicLightColors
    } else {
        rememberDynamicColorScheme(
            seedColor = themeColor,
            isDark = darkTheme,
            specVersion = ColorSpec.SpecVersion.SPEC_2025,
            style = PaletteStyle.TonalSpot,
        )
    }

    val colorScheme = remember(baseColorScheme, pureBlack, darkTheme) {
        if (darkTheme && pureBlack) baseColorScheme.pureBlack(true) else baseColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content,
    )
}

fun Bitmap.extractThemeColor(): Color {
    val colorsToPopulation = Palette.from(this)
        .maximumColorCount(8)
        .generate()
        .swatches
        .associate { it.rgb to it.population }
    val rankedColors = Score.score(colorsToPopulation)
    return Color(rankedColors.first())
}

fun Bitmap.extractGradientColors(): List<Color> {
    val extractedColors = Palette.from(this)
        .maximumColorCount(64)
        .generate()
        .swatches
        .associate { it.rgb to it.population }

    val orderedColors = Score.score(extractedColors, 2, 0xff4285f4.toInt(), true)
        .sortedByDescending { Color(it).luminance() }

    return if (orderedColors.size >= 2)
        listOf(Color(orderedColors[0]), Color(orderedColors[1]))
    else
        listOf(Color(0xFF595959), Color(0xFF0D0D0D))
}

fun ColorScheme.pureBlack(apply: Boolean) =
    if (apply) copy(
        surface = Color.Black,
        background = Color.Black,
        surfaceContainerLowest = Color.Black,
        surfaceContainerLow = Color.Black,
        surfaceContainer = Color(0xFF0C0C0E),
        surfaceContainerHigh = Color(0xFF151517),
        surfaceContainerHighest = Color(0xFF1C1C1E),
    ) else this

val ColorSaver = object : Saver<Color, Int> {
    override fun restore(value: Int): Color = Color(value)
    override fun SaverScope.save(value: Color): Int = value.toArgb()
}
