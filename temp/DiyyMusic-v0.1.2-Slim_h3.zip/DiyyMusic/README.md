# DiyyMusic

DiyyMusic adalah pemutar musik Android open-source berbasis Kotlin dan Jetpack Compose dengan tampilan modern yang terinspirasi dari pola antarmuka Apple Music tanpa memakai aset atau identitas Apple.

## Fitur utama

- Streaming dari YouTube Music
- Pemutaran latar belakang
- Login dan sinkronisasi library
- Playlist, album, artis, dan riwayat
- Lirik tersinkronisasi
- Download dan cache offline
- Equalizer, tempo, dan pitch
- Tema terang, gelap, hitam, serta warna dinamis
- Android Auto dan widget

## Build APK kecil

Builder Telegram dapat memakai perintah:

```bash
./gradlew assembleDebug
```

Proyek akan membuat satu APK FOSS yang sudah:

- diminify dengan R8
- memakai resource shrinking
- hanya membawa bahasa Inggris dan Indonesia
- hanya membawa satu ABI
- membersihkan file build sementara setelah APK selesai

APK akhir disimpan di:

```text
app/build/outputs/apk/foss/debug/DiyyMusic-v0.1.2.apk
```

ABI bawaan adalah `armeabi-v7a` agar cocok untuk banyak HP Android lama dan ukuran lebih kecil. Untuk ARM64:

```bash
DIYYMUSIC_ABI=arm64-v8a ./gradlew assembleDebug
```

## Identitas proyek

- Nama aplikasi: `DiyyMusic`
- Application ID: `com.diyy.music`
- Namespace: `com.diyy.music`
- Repository: `https://github.com/diyy4a/DiyyMusic`

## Lisensi dan kredit

DiyyMusic dikembangkan dari source code [Metrolist](https://github.com/MetrolistGroup/Metrolist) dan tetap didistribusikan berdasarkan GNU General Public License v3.0.

DiyyMusic bukan versi resmi dan tidak berafiliasi dengan Metrolist, YouTube, Google, atau Apple. Lihat berkas `LICENSE` untuk ketentuan lengkap.
