import 'package:dio/dio.dart';
import '../core/network/dio_client.dart';
import '../models/sender_model.dart';

class SenderLimitException implements Exception {
  final String message;
  final int currentCount;
  final int maxLimit;
  SenderLimitException(this.message, this.currentCount, this.maxLimit);
}

class SenderService {
  final Dio _dio = DioClient().dio;

  Future<List<SenderEmailModel>> listEmailSenders({int page = 1}) async {
    final response = await _dio.get('/sender/email', queryParameters: {'page': page});
    final List items = response.data['data']['data'];
    return items.map((e) => SenderEmailModel.fromJson(e)).toList();
  }

  Future<SenderEmailModel> addEmailSender(Map<String, dynamic> payload) async {
    try {
      final response = await _dio.post('/sender/email', data: payload);
      return SenderEmailModel.fromJson(response.data['data']);
    } on DioException catch (e) {
      if (e.response?.statusCode == 422 && e.response?.data['max_limit'] != null) {
        final d = e.response!.data;
        throw SenderLimitException(d['message'], d['current_count'], d['max_limit']);
      }
      rethrow;
    }
  }

  Future<void> deleteEmailSender(int id) async {
    await _dio.delete('/sender/email/$id');
  }

  Future<List<SenderTelegramModel>> listTelegramSenders({int page = 1}) async {
    final response = await _dio.get('/sender/telegram', queryParameters: {'page': page});
    final List items = response.data['data']['data'];
    return items.map((e) => SenderTelegramModel.fromJson(e)).toList();
  }

  Future<String> initTelegramLogin(String sessionName, String phoneNumber) async {
    try {
      final response = await _dio.post('/sender/telegram/init', data: {
        'session_name': sessionName,
        'phone_number': phoneNumber,
      });
      return response.data['data']['phone_code_hash'];
    } on DioException catch (e) {
      if (e.response?.statusCode == 422 && e.response?.data['max_limit'] != null) {
        final d = e.response!.data;
        throw SenderLimitException(d['message'], d['current_count'], d['max_limit']);
      }
      rethrow;
    }
  }

  Future<SenderTelegramModel> verifyTelegramLogin({
    required String phoneNumber,
    required String otpCode,
    required String phoneCodeHash,
    String? password2fa,
  }) async {
    final response = await _dio.post('/sender/telegram/verify', data: {
      'phone_number': phoneNumber,
      'otp_code': otpCode,
      'phone_code_hash': phoneCodeHash,
      'password_2fa': password2fa,
    });
    return SenderTelegramModel.fromJson(response.data['data']);
  }

  Future<void> deleteTelegramSender(int id) async {
    await _dio.delete('/sender/telegram/$id');
  }
}
