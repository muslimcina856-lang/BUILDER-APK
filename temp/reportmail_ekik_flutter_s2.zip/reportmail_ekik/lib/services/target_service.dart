import 'package:dio/dio.dart';
import '../core/network/dio_client.dart';
import '../models/target_model.dart';

class TargetPage<T> {
  final List<T> items;
  final int currentPage;
  final int lastPage;
  final int total;
  TargetPage({required this.items, required this.currentPage, required this.lastPage, required this.total});
}

class TargetService {
  final Dio _dio = DioClient().dio;

  Future<TargetPage<TargetEmailModel>> listEmailTargets({int page = 1, String? search}) async {
    final response = await _dio.get('/target/email', queryParameters: {
      'page': page,
      'per_page': 50,
      if (search != null && search.isNotEmpty) 'search': search,
    });
    final d = response.data['data'];
    final List items = d['data'];
    return TargetPage(
      items: items.map((e) => TargetEmailModel.fromJson(e)).toList(),
      currentPage: d['current_page'],
      lastPage: d['last_page'],
      total: d['total'],
    );
  }

  Future<TargetEmailModel> addEmailTarget(String email, {String? name, String? category}) async {
    final response = await _dio.post('/target/email', data: {
      'email': email,
      'name': name,
      'category': category,
    });
    return TargetEmailModel.fromJson(response.data['data']);
  }

  Future<Map<String, dynamic>> importEmailTargets(String filePath, {String? category}) async {
    final formData = FormData.fromMap({
      'file': await MultipartFile.fromFile(filePath),
      if (category != null) 'category': category,
    });
    final response = await _dio.post('/target/email/import', data: formData);
    return response.data;
  }

  Future<void> deleteEmailTarget(int id) async {
    await _dio.delete('/target/email/$id');
  }

  Future<TargetPage<TargetTelegramModel>> listTelegramTargets({int page = 1, String? search}) async {
    final response = await _dio.get('/target/telegram', queryParameters: {
      'page': page,
      'per_page': 50,
      if (search != null && search.isNotEmpty) 'search': search,
    });
    final d = response.data['data'];
    final List items = d['data'];
    return TargetPage(
      items: items.map((e) => TargetTelegramModel.fromJson(e)).toList(),
      currentPage: d['current_page'],
      lastPage: d['last_page'],
      total: d['total'],
    );
  }

  Future<TargetTelegramModel> addTelegramTarget(String chatId, {String? name, String? category}) async {
    final response = await _dio.post('/target/telegram', data: {
      'chat_id': chatId,
      'name': name,
      'category': category,
    });
    return TargetTelegramModel.fromJson(response.data['data']);
  }

  Future<Map<String, dynamic>> importTelegramTargets(String filePath, {String? category}) async {
    final formData = FormData.fromMap({
      'file': await MultipartFile.fromFile(filePath),
      if (category != null) 'category': category,
    });
    final response = await _dio.post('/target/telegram/import', data: formData);
    return response.data;
  }

  Future<void> deleteTelegramTarget(int id) async {
    await _dio.delete('/target/telegram/$id');
  }
}
