import 'package:dio/dio.dart';
import '../core/network/dio_client.dart';

class AdminUserSummary {
  final int id;
  final String username;
  final String role;
  final bool isActive;
  final int senderEmailsCount;
  final int senderTelegramsCount;

  AdminUserSummary({
    required this.id,
    required this.username,
    required this.role,
    required this.isActive,
    required this.senderEmailsCount,
    required this.senderTelegramsCount,
  });

  factory AdminUserSummary.fromJson(Map<String, dynamic> json) {
    return AdminUserSummary(
      id: json['id'],
      username: json['username'],
      role: json['role'],
      isActive: json['is_active'] ?? true,
      senderEmailsCount: json['sender_emails_count'] ?? 0,
      senderTelegramsCount: json['sender_telegrams_count'] ?? 0,
    );
  }
}

/// Layanan khusus Admin/Owner (section 3 & 7 dokumen spesifikasi).
class AdminService {
  final Dio _dio = DioClient().dio;

  Future<List<AdminUserSummary>> listUsers({int page = 1}) async {
    final response = await _dio.get('/admin/users', queryParameters: {'page': page});
    final List items = response.data['data']['data'];
    return items.map((e) => AdminUserSummary.fromJson(e)).toList();
  }

  Future<void> resetPassword(int userId, String newPassword) async {
    await _dio.post('/admin/users/$userId/reset-password', data: {'new_password': newPassword});
  }

  Future<void> deleteUser(int userId) async {
    await _dio.delete('/admin/users/$userId');
  }
}
