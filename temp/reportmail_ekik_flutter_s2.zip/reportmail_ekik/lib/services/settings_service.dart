import 'package:dio/dio.dart';
import '../core/network/dio_client.dart';
import '../models/user_settings_model.dart';

class SettingsService {
  final Dio _dio = DioClient().dio;

  Future<UserSettingsModel> getSettings() async {
    final response = await _dio.get('/user/settings');
    return UserSettingsModel.fromJson(response.data['data']);
  }

  Future<UserSettingsModel> saveSettings(UserSettingsModel settings) async {
    final response = await _dio.post('/user/settings', data: settings.toJson());
    return UserSettingsModel.fromJson(response.data['data']);
  }
}
