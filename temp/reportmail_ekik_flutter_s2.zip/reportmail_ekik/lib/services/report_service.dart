import 'package:dio/dio.dart';
import '../core/network/dio_client.dart';
import '../models/report_model.dart';

class SendReportResult {
  final int reportId;
  final int totalTargets;
  final String finalSubject;
  final String finalBody;
  SendReportResult({
    required this.reportId,
    required this.totalTargets,
    required this.finalSubject,
    required this.finalBody,
  });
}

class ReportService {
  final Dio _dio = DioClient().dio;

  Future<SendReportResult> sendReport({
    required String senderType,
    required int senderId,
    required List<int> targetIds,
    required bool selectAll,
    String? subject,
    required String body,
    String? attachmentBase64,
  }) async {
    final response = await _dio.post('/report/send', data: {
      'sender_type': senderType,
      'sender_id': senderId,
      'target_ids': targetIds,
      'select_all': selectAll,
      'subject': subject,
      'body': body,
      'attachment_base64': attachmentBase64,
    });

    final d = response.data;
    return SendReportResult(
      reportId: d['report_id'],
      totalTargets: d['total_targets'],
      finalSubject: d['final_subject'] ?? '',
      finalBody: d['final_body'] ?? '',
    );
  }

  Future<List<ReportModel>> listReports({int page = 1}) async {
    final response = await _dio.get('/report', queryParameters: {'page': page});
    final List items = response.data['data']['data'];
    return items.map((e) => ReportModel.fromJson(e)).toList();
  }

  Future<Map<String, dynamic>> reportDetail(int id) async {
    final response = await _dio.get('/report/$id/detail');
    return response.data['data'];
  }
}
