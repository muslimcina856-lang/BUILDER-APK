import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants/app_constants.dart';
import '../core/network/dio_client.dart';
import '../models/user_model.dart';

class AuthResult {
  final UserModel user;
  final bool settingsExist;
  AuthResult({required this.user, required this.settingsExist});
}

class AuthService {
  final Dio _dio = DioClient().dio;

  Future<AuthResult> login(String username, String password) async {
    final response = await _dio.post('/login', data: {
      'username': username,
      'password': password,
    });

    final data = response.data['data'];
    final token = data['token'] as String;
    final user = UserModel.fromJson(data['user']);
    final settingsExist = data['settings_exist'] ?? false;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.prefTokenKey, token);

    return AuthResult(user: user, settingsExist: settingsExist);
  }

  Future<void> logout() async {
    try {
      await _dio.post('/logout');
    } finally {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(AppConstants.prefTokenKey);
    }
  }

  Future<UserModel> getMe() async {
    final response = await _dio.get('/user');
    return UserModel.fromJson(response.data['data']);
  }

  Future<bool> hasToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.prefTokenKey) != null;
  }
}
