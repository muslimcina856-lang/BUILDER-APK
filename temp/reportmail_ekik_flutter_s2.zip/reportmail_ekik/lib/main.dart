import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'core/constants/app_theme.dart';
import 'providers/auth_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/theme_provider.dart';
import 'screens/admin/admin_users_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/dashboard/dashboard_screen.dart';
import 'screens/report/report_log_screen.dart';
import 'screens/report/send_report_screen.dart';
import 'screens/sender/sender_email_screen.dart';
import 'screens/sender/sender_telegram_screen.dart';
import 'screens/settings/settings_screen.dart';
import 'screens/target/target_screen.dart';
import 'screens/wizard/setup_wizard_screen.dart';

void main() {
  runApp(const ProviderScope(child: ReportMailEkikApp()));
}

final _router = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(path: '/splash', builder: (c, s) => const _SplashScreen()),
    GoRoute(path: '/login', builder: (c, s) => const LoginScreen()),
    GoRoute(path: '/wizard', builder: (c, s) => const SetupWizardScreen()),
    GoRoute(path: '/dashboard', builder: (c, s) => const DashboardScreen()),
    GoRoute(path: '/settings', builder: (c, s) => const SettingsScreen()),
    GoRoute(path: '/sender/email', builder: (c, s) => const SenderEmailScreen()),
    GoRoute(path: '/sender/telegram', builder: (c, s) => const SenderTelegramScreen()),
    GoRoute(path: '/target', builder: (c, s) => const TargetScreen()),
    GoRoute(path: '/report/send', builder: (c, s) => const SendReportScreen()),
    GoRoute(path: '/report/log', builder: (c, s) => const ReportLogScreen()),
    GoRoute(path: '/admin/users', builder: (c, s) => const AdminUsersScreen()),
  ],
);

class ReportMailEkikApp extends ConsumerWidget {
  const ReportMailEkikApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);

    return MaterialApp.router(
      title: 'ReportMail Ekik',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: themeMode,
      routerConfig: _router,
    );
  }
}

/// Splash sederhana: cek token tersimpan -> auto-login -> arahkan ke
/// Wizard (jika is_first_login) atau Dashboard, sebaliknya ke Login.
class _SplashScreen extends ConsumerStatefulWidget {
  const _SplashScreen();

  @override
  ConsumerState<_SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<_SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(_bootstrap);
  }

  Future<void> _bootstrap() async {
    final loggedIn = await ref.read(authControllerProvider.notifier).tryAutoLogin();

    if (!mounted) return;

    if (!loggedIn) {
      context.go('/login');
      return;
    }

    final user = ref.read(authControllerProvider).user!;
    await ref.read(settingsControllerProvider.notifier).load();

    if (!mounted) return;

    if (user.isFirstLogin) {
      context.go('/wizard');
    } else {
      context.go('/dashboard');
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
