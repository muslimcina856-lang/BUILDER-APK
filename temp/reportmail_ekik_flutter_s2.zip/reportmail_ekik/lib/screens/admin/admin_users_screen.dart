import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_colors.dart';
import '../../providers/admin_provider.dart';

/// Kelola User - hanya Admin/Owner (section 3).
class AdminUsersScreen extends ConsumerWidget {
  const AdminUsersScreen({super.key});

  void _showResetPasswordDialog(BuildContext context, WidgetRef ref, int userId, String username) {
    final passCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Reset Password: $username'),
        content: TextField(
          controller: passCtrl,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'Password Baru (min. 8 karakter)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () async {
              try {
                await ref.read(adminServiceProvider).resetPassword(userId, passCtrl.text);
                if (ctx.mounted) {
                  Navigator.pop(ctx);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Password berhasil direset.')),
                  );
                }
              } catch (_) {
                if (ctx.mounted) {
                  ScaffoldMessenger.of(ctx).showSnackBar(
                    const SnackBar(content: Text('Gagal mereset password.')),
                  );
                }
              }
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, int userId, String username) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus User'),
        content: Text('Yakin ingin menghapus user "$username"? Semua sender & target miliknya akan ikut terhapus.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.statusFailed, foregroundColor: Colors.white),
            onPressed: () async {
              await ref.read(adminUserListProvider.notifier).deleteUser(userId);
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(adminUserListProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Kelola User')),
      body: state.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
        data: (users) {
          if (users.isEmpty) return const Center(child: Text('Tidak ada user.'));

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: users.length,
            itemBuilder: (ctx, i) {
              final u = users[i];
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: u.role == 'admin' ? AppColors.goldPremium : AppColors.primaryNavy,
                    foregroundColor: u.role == 'admin' ? AppColors.primaryNavy : Colors.white,
                    child: Text(u.username[0].toUpperCase()),
                  ),
                  title: Text(u.username),
                  subtitle: Text(
                    '${u.role == "admin" ? "Admin" : "User"} - Sender: ${u.senderEmailsCount + u.senderTelegramsCount}',
                  ),
                  trailing: u.role == 'admin'
                      ? null
                      : PopupMenuButton<String>(
                          onSelected: (val) {
                            if (val == 'reset') {
                              _showResetPasswordDialog(context, ref, u.id, u.username);
                            } else if (val == 'delete') {
                              _confirmDelete(context, ref, u.id, u.username);
                            }
                          },
                          itemBuilder: (c) => const [
                            PopupMenuItem(value: 'reset', child: Text('Reset Password')),
                            PopupMenuItem(value: 'delete', child: Text('Hapus User')),
                          ],
                        ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
