import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_constants.dart';
import '../../models/user_settings_model.dart';
import '../../providers/settings_provider.dart';

/// Halaman Settings biasa (bukan Wizard) - bisa diakses kapan saja
/// dari ikon roda gigi di Dashboard. Admin bisa mengubah subject_prefix
/// & default_signature kapan saja (section 14.4).
class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  late int _batchSize;
  late double _telegramDelay;
  late int _maxAttachmentMb;
  late String _themeMode;
  late TextEditingController _prefixCtrl;
  late TextEditingController _signatureCtrl;
  bool _saving = false;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    final s = ref.read(settingsControllerProvider);
    _batchSize = s.batchSize;
    _telegramDelay = s.telegramDelay;
    _maxAttachmentMb = s.maxAttachmentMb;
    _themeMode = s.themeMode;
    _prefixCtrl = TextEditingController(text: s.subjectPrefix);
    _signatureCtrl = TextEditingController(text: s.defaultSignature);

    Future.microtask(() async {
      await ref.read(settingsControllerProvider.notifier).load();
      final updated = ref.read(settingsControllerProvider);
      setState(() {
        _batchSize = updated.batchSize;
        _telegramDelay = updated.telegramDelay;
        _maxAttachmentMb = updated.maxAttachmentMb;
        _themeMode = updated.themeMode;
        _prefixCtrl.text = updated.subjectPrefix;
        _signatureCtrl.text = updated.defaultSignature;
        _loaded = true;
      });
    });
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await ref.read(settingsControllerProvider.notifier).save(
            UserSettingsModel(
              batchSize: _batchSize,
              telegramDelay: _telegramDelay,
              maxAttachmentMb: _maxAttachmentMb,
              themeMode: _themeMode,
              subjectPrefix: _prefixCtrl.text,
              defaultSignature: _signatureCtrl.text,
            ),
          );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pengaturan berhasil disimpan')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal menyimpan pengaturan')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Pengiriman', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          const Text('Batch Size per Proses', style: TextStyle(fontWeight: FontWeight.bold)),
          ...AppConstants.batchSizeOptions.map((v) => RadioListTile<int>(
                title: Text('$v'),
                value: v,
                groupValue: _batchSize,
                onChanged: (val) => setState(() => _batchSize = val!),
                contentPadding: EdgeInsets.zero,
              )),
          const SizedBox(height: 8),
          const Text('Jeda Antar Pesan Telegram', style: TextStyle(fontWeight: FontWeight.bold)),
          ...AppConstants.telegramDelayOptions.map((v) => RadioListTile<double>(
                title: Text('${v == 0.5 ? "0.5" : v.toInt()} detik'),
                value: v,
                groupValue: _telegramDelay,
                onChanged: (val) => setState(() => _telegramDelay = val!),
                contentPadding: EdgeInsets.zero,
              )),
          const SizedBox(height: 8),
          const Text('Batas Maksimal Lampiran', style: TextStyle(fontWeight: FontWeight.bold)),
          ...AppConstants.maxAttachmentMbOptions.map((v) => RadioListTile<int>(
                title: Text('$v MB'),
                value: v,
                groupValue: _maxAttachmentMb,
                onChanged: (val) => setState(() => _maxAttachmentMb = val!),
                contentPadding: EdgeInsets.zero,
              )),
          const Divider(height: 32),
          Text('Tampilan', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'system', label: Text('System')),
              ButtonSegment(value: 'light', label: Text('Terang')),
              ButtonSegment(value: 'dark', label: Text('Gelap')),
            ],
            selected: {_themeMode},
            onSelectionChanged: (s) => setState(() => _themeMode = s.first),
          ),
          const Divider(height: 32),
          Text('Default Teks Laporan', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          const Text('Prefiks Subject', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          TextField(controller: _prefixCtrl, decoration: const InputDecoration(hintText: 'Contoh: [Laporan]')),
          const SizedBox(height: 16),
          const Text('Tanda Tangan Default', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          TextField(controller: _signatureCtrl, maxLines: 3),
          const SizedBox(height: 28),
          ElevatedButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Simpan Pengaturan'),
          ),
        ],
      ),
    );
  }
}
