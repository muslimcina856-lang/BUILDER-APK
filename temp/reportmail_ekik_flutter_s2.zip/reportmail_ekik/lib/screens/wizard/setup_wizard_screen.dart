import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../models/user_settings_model.dart';
import '../../providers/auth_provider.dart';
import '../../providers/settings_provider.dart';

/// Setup Wizard full-screen, tidak bisa dilewati (section 5).
/// Muncul saat is_first_login = true.
class SetupWizardScreen extends ConsumerStatefulWidget {
  const SetupWizardScreen({super.key});

  @override
  ConsumerState<SetupWizardScreen> createState() => _SetupWizardScreenState();
}

class _SetupWizardScreenState extends ConsumerState<SetupWizardScreen> {
  int _currentStep = 0;
  bool _saving = false;

  int _batchSize = AppConstants.defaultBatchSize;
  double _telegramDelay = AppConstants.defaultTelegramDelay;
  int _maxAttachmentMb = AppConstants.defaultMaxAttachmentMb;
  String _themeMode = 'system';

  final _subjectPrefixCtrl = TextEditingController();
  final _signatureCtrl = TextEditingController(text: 'Dikirim oleh ReportMail Ekik');

  Future<void> _next() async {
    if (_currentStep < 2) {
      setState(() => _currentStep++);
      return;
    }

    setState(() => _saving = true);

    final settings = UserSettingsModel(
      batchSize: _batchSize,
      telegramDelay: _telegramDelay,
      maxAttachmentMb: _maxAttachmentMb,
      themeMode: _themeMode,
      subjectPrefix: _subjectPrefixCtrl.text,
      defaultSignature: _signatureCtrl.text,
    );

    try {
      await ref.read(settingsControllerProvider.notifier).save(settings);
      ref.read(authControllerProvider.notifier).markWizardDone();
      if (mounted) context.go('/dashboard');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal menyimpan pengaturan. Coba lagi.')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _back() {
    if (_currentStep > 0) setState(() => _currentStep--);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false, // wizard tidak bisa dilewati
      child: Scaffold(
        backgroundColor: AppColors.bgLight,
        body: SafeArea(
          child: Stepper(
            currentStep: _currentStep,
            type: StepperType.vertical,
            controlsBuilder: (context, details) {
              return Padding(
                padding: const EdgeInsets.only(top: 24),
                child: Row(
                  children: [
                    if (_currentStep > 0)
                      TextButton(
                        onPressed: _saving ? null : _back,
                        child: const Text('Kembali'),
                      ),
                    const Spacer(),
                    SizedBox(
                      width: _currentStep == 2 ? double.infinity : 140,
                      child: ElevatedButton(
                        onPressed: _saving ? null : _next,
                        child: _saving
                            ? const SizedBox(
                                height: 18,
                                width: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : Text(_currentStep == 2 ? 'Simpan & Mulai' : 'Lanjut'),
                      ),
                    ),
                  ],
                ),
              );
            },
            steps: [
              Step(
                title: const Text('Pengaturan Pengiriman'),
                isActive: _currentStep >= 0,
                state: _currentStep > 0 ? StepState.complete : StepState.indexed,
                content: _buildStep1(),
              ),
              Step(
                title: const Text('Pengaturan Tampilan'),
                isActive: _currentStep >= 1,
                state: _currentStep > 1 ? StepState.complete : StepState.indexed,
                content: _buildStep2(),
              ),
              Step(
                title: const Text('Default Teks Laporan'),
                isActive: _currentStep >= 2,
                content: _buildStep3(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStep1() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Batch Size per Proses', style: TextStyle(fontWeight: FontWeight.bold)),
        ...AppConstants.batchSizeOptions.map((v) => RadioListTile<int>(
              title: Text('$v'),
              value: v,
              groupValue: _batchSize,
              activeColor: AppColors.goldPremium,
              onChanged: (val) => setState(() => _batchSize = val!),
              contentPadding: EdgeInsets.zero,
            )),
        const SizedBox(height: 12),
        const Text('Jeda Antar Pesan Telegram', style: TextStyle(fontWeight: FontWeight.bold)),
        ...AppConstants.telegramDelayOptions.map((v) => RadioListTile<double>(
              title: Text('${v == 0.5 ? '0.5' : v.toInt()} detik'),
              value: v,
              groupValue: _telegramDelay,
              activeColor: AppColors.goldPremium,
              onChanged: (val) => setState(() => _telegramDelay = val!),
              contentPadding: EdgeInsets.zero,
            )),
        const SizedBox(height: 12),
        const Text('Batas Maksimal Lampiran', style: TextStyle(fontWeight: FontWeight.bold)),
        ...AppConstants.maxAttachmentMbOptions.map((v) => RadioListTile<int>(
              title: Text('$v MB'),
              value: v,
              groupValue: _maxAttachmentMb,
              activeColor: AppColors.goldPremium,
              onChanged: (val) => setState(() => _maxAttachmentMb = val!),
              contentPadding: EdgeInsets.zero,
            )),
      ],
    );
  }

  Widget _buildStep2() {
    final options = [
      ('system', 'System Default', Icons.brightness_auto),
      ('light', 'Mode Terang (Navy-Gold)', Icons.light_mode),
      ('dark', 'Mode Gelap (Dark Elegant)', Icons.dark_mode),
    ];

    return Column(
      children: options.map((opt) {
        final isSelected = _themeMode == opt.$1;
        return GestureDetector(
          onTap: () => setState(() => _themeMode = opt.$1),
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? AppColors.goldPremium : Colors.grey.shade300,
                width: isSelected ? 2 : 1,
              ),
              color: opt.$1 == 'dark' ? AppColors.bgDark : Colors.white,
            ),
            child: Row(
              children: [
                Icon(opt.$3, color: opt.$1 == 'dark' ? AppColors.goldPremium : AppColors.primaryNavy),
                const SizedBox(width: 12),
                Text(
                  opt.$2,
                  style: TextStyle(
                    color: opt.$1 == 'dark' ? Colors.white : AppColors.textLight,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                if (isSelected) const Icon(Icons.check_circle, color: AppColors.goldPremium),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildStep3() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Prefiks Subject', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(
          controller: _subjectPrefixCtrl,
          decoration: const InputDecoration(hintText: 'Contoh: [Laporan]'),
        ),
        const SizedBox(height: 20),
        const Text('Tanda Tangan Default', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(
          controller: _signatureCtrl,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'Contoh: Hormat kami, Tim Manajemen'),
        ),
      ],
    );
  }
}
