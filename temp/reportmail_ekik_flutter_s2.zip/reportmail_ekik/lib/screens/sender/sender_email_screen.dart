import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/app_colors.dart';
import '../../providers/sender_provider.dart';
import '../../services/sender_service.dart';
import '../../widgets/quota_chip.dart';
import '../../widgets/sender_card.dart';

class SenderEmailScreen extends ConsumerWidget {
  const SenderEmailScreen({super.key});

  void _showAddDialog(BuildContext context, WidgetRef ref) {
    final displayNameCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    final hostCtrl = TextEditingController();
    final portCtrl = TextEditingController(text: '587');
    final usernameCtrl = TextEditingController();
    final passwordCtrl = TextEditingController();
    String encryption = 'tls';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 20,
            bottom: 20 + MediaQuery.of(ctx).viewInsets.bottom,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('Tambah Sender Email', style: Theme.of(ctx).textTheme.headlineSmall),
                const SizedBox(height: 16),
                TextField(controller: displayNameCtrl, decoration: const InputDecoration(labelText: 'Nama Tampilan')),
                const SizedBox(height: 12),
                TextField(controller: emailCtrl, decoration: const InputDecoration(labelText: 'Email')),
                const SizedBox(height: 12),
                TextField(controller: hostCtrl, decoration: const InputDecoration(labelText: 'SMTP Host')),
                const SizedBox(height: 12),
                TextField(controller: portCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'SMTP Port')),
                const SizedBox(height: 12),
                TextField(controller: usernameCtrl, decoration: const InputDecoration(labelText: 'SMTP Username')),
                const SizedBox(height: 12),
                TextField(controller: passwordCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'SMTP Password / App Password')),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: encryption,
                  decoration: const InputDecoration(labelText: 'Enkripsi'),
                  items: const [
                    DropdownMenuItem(value: 'tls', child: Text('TLS')),
                    DropdownMenuItem(value: 'ssl', child: Text('SSL')),
                    DropdownMenuItem(value: 'none', child: Text('Tanpa Enkripsi')),
                  ],
                  onChanged: (val) => encryption = val ?? 'tls',
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    try {
                      await ref.read(senderServiceProvider).addEmailSender({
                        'display_name': displayNameCtrl.text,
                        'email': emailCtrl.text,
                        'smtp_host': hostCtrl.text,
                        'smtp_port': int.tryParse(portCtrl.text) ?? 587,
                        'smtp_username': usernameCtrl.text,
                        'smtp_password': passwordCtrl.text,
                        'encryption': encryption,
                      });
                      ref.read(senderEmailListProvider.notifier).load();
                      if (ctx.mounted) Navigator.pop(ctx);
                    } on SenderLimitException catch (e) {
                      if (ctx.mounted) {
                        ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(e.message)));
                      }
                    } catch (_) {
                      if (ctx.mounted) {
                        ScaffoldMessenger.of(ctx).showSnackBar(
                          const SnackBar(content: Text('Gagal menambah sender. Periksa data anda.')),
                        );
                      }
                    }
                  },
                  child: const Text('Simpan'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(senderEmailListProvider);
    final controller = ref.read(senderEmailListProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('Sender Email')),
      body: state.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Gagal memuat data: $e')),
        data: (senders) {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: QuotaChip(current: senders.length),
                ),
              ),
              Expanded(
                child: senders.isEmpty
                    ? const Center(child: Text('Belum ada sender email.'))
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: senders.length,
                        itemBuilder: (ctx, i) {
                          final s = senders[i];
                          return SenderCard(
                            title: s.email,
                            subtitle: s.smtpHost,
                            isActive: s.isActive,
                            onDelete: () => controller.remove(s.id),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: controller.isQuotaFull
          ? null
          : FloatingActionButton(
              onPressed: () => _showAddDialog(context, ref),
              child: const Icon(Icons.add),
            ),
    );
  }
}
