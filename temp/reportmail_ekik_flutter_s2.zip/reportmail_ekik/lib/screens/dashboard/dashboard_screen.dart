import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/auth_provider.dart';
import '../../providers/sender_provider.dart';
import '../../providers/target_provider.dart';
import '../../widgets/stat_card.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authControllerProvider).user;
    final emailSenders = ref.watch(senderEmailListProvider);
    final emailTargets = ref.watch(targetEmailListProvider);

    final senderCount = emailSenders.value?.length ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ReportMail Ekik'),
        leading: IconButton(
          icon: const Icon(Icons.logout),
          onPressed: () async {
            await ref.read(authControllerProvider.notifier).logout();
            if (context.mounted) context.go('/login');
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => context.push('/settings'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.read(senderEmailListProvider.notifier).load();
          ref.read(targetEmailListProvider.notifier).load();
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Selamat datang, ${user?.username ?? ''}',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      label: 'Total Sender',
                      value: '$senderCount/${AppConstants.maxSenderPerUser}',
                      icon: Icons.outgoing_mail,
                      progress: senderCount / AppConstants.maxSenderPerUser,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: StatCard(
                      label: 'Total Target',
                      value: '${emailTargets.value?.length ?? 0}',
                      icon: Icons.groups_outlined,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const StatCard(
                label: 'Laporan Terkirim',
                value: '-',
                icon: Icons.fact_check_outlined,
              ),
              const SizedBox(height: 24),
              Text('Menu', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 12),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.3,
                children: [
                  _MenuTile(
                    icon: Icons.email_outlined,
                    label: 'Sender Email',
                    onTap: () => context.push('/sender/email'),
                  ),
                  _MenuTile(
                    icon: Icons.send_outlined,
                    label: 'Sender Telegram',
                    onTap: () => context.push('/sender/telegram'),
                  ),
                  _MenuTile(
                    icon: Icons.contacts_outlined,
                    label: 'Target',
                    onTap: () => context.push('/target'),
                  ),
                  _MenuTile(
                    icon: Icons.campaign_outlined,
                    label: 'Kirim Laporan',
                    onTap: () => context.push('/report/send'),
                  ),
                  _MenuTile(
                    icon: Icons.history_outlined,
                    label: 'Log Pengiriman',
                    onTap: () => context.push('/report/log'),
                  ),
                  if (user?.isAdmin == true)
                    _MenuTile(
                      icon: Icons.admin_panel_settings_outlined,
                      label: 'Kelola User',
                      onTap: () => context.push('/admin/users'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _MenuTile({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 32, color: theme.colorScheme.secondary),
              const SizedBox(height: 10),
              Text(label, textAlign: TextAlign.center, style: theme.textTheme.bodyMedium),
            ],
          ),
        ),
      ),
    );
  }
}
