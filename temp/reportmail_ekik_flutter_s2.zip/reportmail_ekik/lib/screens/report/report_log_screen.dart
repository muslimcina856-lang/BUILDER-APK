import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../models/report_model.dart';
import '../../providers/report_provider.dart';
import '../../widgets/status_indicator.dart';

class ReportLogScreen extends ConsumerWidget {
  const ReportLogScreen({super.key});

  Color _sideColor(String status) {
    switch (status) {
      case 'completed':
        return AppColors.statusSuccess;
      case 'processing':
      case 'pending':
        return AppColors.statusProcessing;
      case 'failed':
        return AppColors.statusFailed;
      default:
        return AppColors.statusInactive;
    }
  }

  void _showDetail(BuildContext context, WidgetRef ref, ReportModel report) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return FutureBuilder(
          future: ref.read(reportServiceProvider).reportDetail(report.id),
          builder: (c, snapshot) {
            if (!snapshot.hasData) {
              return const SizedBox(
                height: 200,
                child: Center(child: CircularProgressIndicator()),
              );
            }

            final data = snapshot.data as Map<String, dynamic>;
            final recipients = (data['recipients']['data'] as List)
                .map((e) => ReportRecipientModel.fromJson(e))
                .toList();
            final failedOnly = recipients.where((r) => r.status == 'failed').toList();

            return DraggableScrollableSheet(
              initialChildSize: 0.6,
              maxChildSize: 0.9,
              expand: false,
              builder: (c2, scrollCtrl) {
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text('Detail Laporan #${report.id}', style: Theme.of(c2).textTheme.headlineSmall),
                      const SizedBox(height: 4),
                      Text(
                        'Terkirim: ${report.processedTargets - report.failedTargets}/${report.totalTargets}, Gagal: ${report.failedTargets}',
                        style: Theme.of(c2).textTheme.labelSmall,
                      ),
                      const Divider(),
                      Expanded(
                        child: failedOnly.isEmpty
                            ? const Center(child: Text('Tidak ada penerima gagal.'))
                            : ListView.builder(
                                controller: scrollCtrl,
                                itemCount: failedOnly.length,
                                itemBuilder: (c3, i) {
                                  final r = failedOnly[i];
                                  return ListTile(
                                    leading: const StatusIndicator(status: ReportStatus.failed),
                                    title: Text(r.recipientAddress),
                                    subtitle: Text(r.errorMessage ?? 'Gagal terkirim'),
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(reportLogProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Log Pengiriman')),
      body: state.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Gagal memuat log: $e')),
        data: (reports) {
          if (reports.isEmpty) {
            return const Center(child: Text('Belum ada laporan terkirim.'));
          }
          return RefreshIndicator(
            onRefresh: () => ref.read(reportLogProvider.notifier).load(),
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: reports.length,
              itemBuilder: (ctx, i) {
                final r = reports[i];
                final sent = r.processedTargets - r.failedTargets;
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    border: Border(left: BorderSide(color: _sideColor(r.status), width: 4)),
                  ),
                  child: Card(
                    margin: EdgeInsets.zero,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(12),
                        bottomRight: Radius.circular(12),
                      ),
                    ),
                    child: ListTile(
                      title: Text(r.subject ?? '(Laporan Telegram)', maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(DateFormat('dd MMM yyyy, HH:mm').format(r.createdAt)),
                      trailing: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: _sideColor(r.status).withOpacity(0.12),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          'Terkirim: $sent/${r.totalTargets}',
                          style: TextStyle(color: _sideColor(r.status), fontSize: 11, fontWeight: FontWeight.w600),
                        ),
                      ),
                      onTap: () => _showDetail(context, ref, r),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
