import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';
import '../core/constants/app_constants.dart';

/// Chip "Kuota terpakai: X dari 200" (section 10.D), berubah warna jika penuh.
class QuotaChip extends StatelessWidget {
  final int current;

  const QuotaChip({super.key, required this.current});

  @override
  Widget build(BuildContext context) {
    final isFull = current >= AppConstants.maxSenderPerUser;
    final color = isFull ? AppColors.statusFailed : AppColors.statusProcessing;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(
        'Kuota terpakai: $current dari ${AppConstants.maxSenderPerUser}',
        style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12),
      ),
    );
  }
}
