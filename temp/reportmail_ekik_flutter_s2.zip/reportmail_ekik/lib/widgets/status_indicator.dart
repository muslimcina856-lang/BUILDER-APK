import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';

enum ReportStatus { sent, processing, failed, inactive }

/// Indikator status berupa lingkaran solid TANPA emoji (section 4.3).
class StatusIndicator extends StatelessWidget {
  final ReportStatus status;
  final double size;

  const StatusIndicator({super.key, required this.status, this.size = 10});

  Color get _color {
    switch (status) {
      case ReportStatus.sent:
        return AppColors.statusSuccess;
      case ReportStatus.processing:
        return AppColors.statusProcessing;
      case ReportStatus.failed:
        return AppColors.statusFailed;
      case ReportStatus.inactive:
        return AppColors.statusInactive;
    }
  }

  static ReportStatus fromApiStatus(String status) {
    switch (status) {
      case 'sent':
      case 'completed':
        return ReportStatus.sent;
      case 'processing':
      case 'pending':
        return ReportStatus.processing;
      case 'failed':
        return ReportStatus.failed;
      default:
        return ReportStatus.inactive;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: _color, shape: BoxShape.circle),
    );
  }
}
