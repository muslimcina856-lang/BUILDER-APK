import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AuthState {
  final UserModel? user;
  final bool isLoading;
  final bool settingsExist;
  final String? errorMessage;

  AuthState({this.user, this.isLoading = false, this.settingsExist = false, this.errorMessage});

  AuthState copyWith({UserModel? user, bool? isLoading, bool? settingsExist, String? errorMessage}) {
    return AuthState(
      user: user ?? this.user,
      isLoading: isLoading ?? this.isLoading,
      settingsExist: settingsExist ?? this.settingsExist,
      errorMessage: errorMessage,
    );
  }
}

class AuthController extends StateNotifier<AuthState> {
  final AuthService _service;
  AuthController(this._service) : super(AuthState());

  Future<bool> login(String username, String password) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final result = await _service.login(username, password);
      state = state.copyWith(
        user: result.user,
        settingsExist: result.settingsExist,
        isLoading: false,
      );
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: 'Username atau password salah.');
      return false;
    }
  }

  Future<void> logout() async {
    await _service.logout();
    state = AuthState();
  }

  Future<bool> tryAutoLogin() async {
    final has = await _service.hasToken();
    if (!has) return false;
    try {
      final user = await _service.getMe();
      state = state.copyWith(user: user);
      return true;
    } catch (_) {
      return false;
    }
  }

  void markWizardDone() {
    if (state.user == null) return;
    state = state.copyWith(
      user: UserModel(
        id: state.user!.id,
        username: state.user!.username,
        role: state.user!.role,
        isFirstLogin: false,
      ),
    );
  }
}

final authServiceProvider = Provider((ref) => AuthService());

final authControllerProvider = StateNotifierProvider<AuthController, AuthState>((ref) {
  return AuthController(ref.read(authServiceProvider));
});
