import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/user_settings_model.dart';
import '../services/settings_service.dart';
import 'theme_provider.dart';

final settingsServiceProvider = Provider((ref) => SettingsService());

class SettingsController extends StateNotifier<UserSettingsModel> {
  final SettingsService _service;
  final Ref _ref;

  SettingsController(this._service, this._ref) : super(UserSettingsModel.defaults());

  Future<void> load() async {
    try {
      final settings = await _service.getSettings();
      state = settings;
      _ref.read(themeModeProvider.notifier).setThemeMode(settings.themeMode);
    } catch (_) {
      // Pakai default jika belum pernah disimpan (first login).
    }
  }

  Future<void> save(UserSettingsModel settings) async {
    final saved = await _service.saveSettings(settings);
    state = saved;
    _ref.read(themeModeProvider.notifier).setThemeMode(saved.themeMode);
  }
}

final settingsControllerProvider = StateNotifierProvider<SettingsController, UserSettingsModel>((ref) {
  return SettingsController(ref.read(settingsServiceProvider), ref);
});
