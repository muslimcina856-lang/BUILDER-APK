import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/constants/app_constants.dart';
import '../models/sender_model.dart';
import '../services/sender_service.dart';

final senderServiceProvider = Provider((ref) => SenderService());

class SenderEmailListController extends StateNotifier<AsyncValue<List<SenderEmailModel>>> {
  final SenderService _service;
  SenderEmailListController(this._service) : super(const AsyncValue.loading()) {
    load();
  }

  Future<void> load() async {
    state = const AsyncValue.loading();
    try {
      final list = await _service.listEmailSenders();
      state = AsyncValue.data(list);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  bool get isQuotaFull => (state.value?.length ?? 0) >= AppConstants.maxSenderPerUser;

  Future<void> remove(int id) async {
    await _service.deleteEmailSender(id);
    await load();
  }
}

final senderEmailListProvider =
    StateNotifierProvider<SenderEmailListController, AsyncValue<List<SenderEmailModel>>>((ref) {
  return SenderEmailListController(ref.read(senderServiceProvider));
});

class SenderTelegramListController extends StateNotifier<AsyncValue<List<SenderTelegramModel>>> {
  final SenderService _service;
  SenderTelegramListController(this._service) : super(const AsyncValue.loading()) {
    load();
  }

  Future<void> load() async {
    state = const AsyncValue.loading();
    try {
      final list = await _service.listTelegramSenders();
      state = AsyncValue.data(list);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  bool get isQuotaFull => (state.value?.length ?? 0) >= AppConstants.maxSenderPerUser;

  Future<void> remove(int id) async {
    await _service.deleteTelegramSender(id);
    await load();
  }
}

final senderTelegramListProvider =
    StateNotifierProvider<SenderTelegramListController, AsyncValue<List<SenderTelegramModel>>>((ref) {
  return SenderTelegramListController(ref.read(senderServiceProvider));
});
