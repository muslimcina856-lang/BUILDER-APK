class SenderEmailModel {
  final int id;
  final String? displayName;
  final String email;
  final String smtpHost;
  final int smtpPort;
  final String encryption;
  final bool isActive;
  final int dailySentCount;

  SenderEmailModel({
    required this.id,
    this.displayName,
    required this.email,
    required this.smtpHost,
    required this.smtpPort,
    required this.encryption,
    required this.isActive,
    required this.dailySentCount,
  });

  factory SenderEmailModel.fromJson(Map<String, dynamic> json) {
    return SenderEmailModel(
      id: json['id'],
      displayName: json['display_name'],
      email: json['email'],
      smtpHost: json['smtp_host'],
      smtpPort: json['smtp_port'],
      encryption: json['encryption'] ?? 'tls',
      isActive: json['is_active'] ?? true,
      dailySentCount: json['daily_sent_count'] ?? 0,
    );
  }
}

class SenderTelegramModel {
  final int id;
  final String sessionName;
  final String phoneNumber;
  final bool isActive;

  SenderTelegramModel({
    required this.id,
    required this.sessionName,
    required this.phoneNumber,
    required this.isActive,
  });

  factory SenderTelegramModel.fromJson(Map<String, dynamic> json) {
    return SenderTelegramModel(
      id: json['id'],
      sessionName: json['session_name'],
      phoneNumber: json['phone_number'],
      isActive: json['is_active'] ?? true,
    );
  }
}
