class UserSettingsModel {
  final int batchSize;
  final double telegramDelay;
  final int maxAttachmentMb;
  final String themeMode; // 'system' | 'light' | 'dark'
  final String subjectPrefix;
  final String defaultSignature;

  UserSettingsModel({
    required this.batchSize,
    required this.telegramDelay,
    required this.maxAttachmentMb,
    required this.themeMode,
    required this.subjectPrefix,
    required this.defaultSignature,
  });

  factory UserSettingsModel.defaults() => UserSettingsModel(
        batchSize: 50,
        telegramDelay: 1,
        maxAttachmentMb: 5,
        themeMode: 'system',
        subjectPrefix: '',
        defaultSignature: 'Dikirim oleh ReportMail Ekik',
      );

  factory UserSettingsModel.fromJson(Map<String, dynamic> json) {
    return UserSettingsModel(
      batchSize: json['batch_size'] ?? 50,
      telegramDelay: (json['telegram_delay'] ?? 1).toDouble(),
      maxAttachmentMb: json['max_attachment_mb'] ?? 5,
      themeMode: json['theme_mode'] ?? 'system',
      subjectPrefix: json['subject_prefix'] ?? '',
      defaultSignature: json['default_signature'] ?? 'Dikirim oleh ReportMail Ekik',
    );
  }

  Map<String, dynamic> toJson() => {
        'batch_size': batchSize,
        'telegram_delay': telegramDelay,
        'max_attachment_mb': maxAttachmentMb,
        'theme_mode': themeMode,
        'subject_prefix': subjectPrefix,
        'default_signature': defaultSignature,
      };

  UserSettingsModel copyWith({
    int? batchSize,
    double? telegramDelay,
    int? maxAttachmentMb,
    String? themeMode,
    String? subjectPrefix,
    String? defaultSignature,
  }) {
    return UserSettingsModel(
      batchSize: batchSize ?? this.batchSize,
      telegramDelay: telegramDelay ?? this.telegramDelay,
      maxAttachmentMb: maxAttachmentMb ?? this.maxAttachmentMb,
      themeMode: themeMode ?? this.themeMode,
      subjectPrefix: subjectPrefix ?? this.subjectPrefix,
      defaultSignature: defaultSignature ?? this.defaultSignature,
    );
  }
}
