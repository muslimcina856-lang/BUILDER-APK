import 'package:flutter/material.dart';

/// Palet warna sesuai spesifikasi ReportMail Ekik (section 4.1).
/// DILARANG menggunakan warna lain di luar palet ini untuk elemen utama.
class AppColors {
  AppColors._();

  // Primary
  static const Color primaryNavy = Color(0xFF0F172A);
  static const Color primaryNavyAlt = Color(0xFF1E293B);

  // Secondary / Accent
  static const Color goldPremium = Color(0xFFD4AF37);
  static const Color goldPremiumAlt = Color(0xFFC9A84C);

  // Background
  static const Color bgLight = Color(0xFFF8FAFC);
  static const Color bgDark = Color(0xFF121212);

  // Card
  static const Color cardLight = Color(0xFFFFFFFF);
  static const Color cardDark = Color(0xFF1E1E1E);

  // Text
  static const Color textLight = Color(0xFF1A1A1A);
  static const Color textDark = Color(0xFFF1F5F9);

  // Status Indicators
  static const Color statusSuccess = Color(0xFF2E7D32); // Hijau Sage
  static const Color statusProcessing = Color(0xFF1976D2); // Biru Langit
  static const Color statusFailed = Color(0xFFB71C1C); // Merah Bata
  static const Color statusInactive = Color(0xFF9E9E9E); // Abu-abu

  // AppBar khusus dark mode
  static const Color appBarDark = Color(0xFF0A0A0A);
}
