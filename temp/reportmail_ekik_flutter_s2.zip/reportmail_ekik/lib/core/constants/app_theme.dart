import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

/// Tema Terang (Navy-Gold) & Gelap (Dark Elegant) sesuai spesifikasi
/// section 4.2 - 4.4. Border radius 12px (kartu) / 20px (tombol besar).
class AppTheme {
  AppTheme._();

  static const double cardRadius = 12;
  static const double buttonRadius = 20;
  static const double spacingStandard = 16;
  static const double spacingLarge = 24;

  static ThemeData get light => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: AppColors.bgLight,
        colorScheme: const ColorScheme.light(
          primary: AppColors.primaryNavy,
          secondary: AppColors.goldPremium,
          surface: AppColors.cardLight,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: AppColors.primaryNavy,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: GoogleFonts.montserrat(
            fontWeight: FontWeight.bold,
            fontSize: 22,
            color: Colors.white,
          ),
        ),
        cardTheme: CardThemeData(
          color: AppColors.cardLight,
          elevation: 2,
          shadowColor: Colors.black.withOpacity(0.05),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(cardRadius),
          ),
        ),
        textTheme: _textTheme(AppColors.textLight),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.goldPremium,
            foregroundColor: AppColors.primaryNavy,
            elevation: 3,
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(buttonRadius),
            ),
            textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: AppColors.goldPremium,
          foregroundColor: AppColors.primaryNavy,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: AppColors.cardLight,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(cardRadius),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(cardRadius),
            borderSide: const BorderSide(color: AppColors.goldPremium, width: 1.5),
          ),
        ),
      );

  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bgDark,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.goldPremium,
          secondary: AppColors.goldPremium,
          surface: AppColors.cardDark,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: AppColors.appBarDark,
          foregroundColor: AppColors.goldPremium,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: GoogleFonts.montserrat(
            fontWeight: FontWeight.bold,
            fontSize: 22,
            color: AppColors.goldPremium,
          ),
        ),
        cardTheme: CardThemeData(
          color: AppColors.cardDark,
          elevation: 2,
          shadowColor: Colors.black.withOpacity(0.3),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(cardRadius),
          ),
        ),
        textTheme: _textTheme(AppColors.textDark),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.goldPremium,
            foregroundColor: AppColors.primaryNavy,
            elevation: 3,
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(buttonRadius),
            ),
            textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: AppColors.goldPremium,
          foregroundColor: AppColors.primaryNavy,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: AppColors.cardDark,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(cardRadius),
            borderSide: BorderSide(color: Colors.grey.shade700),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(cardRadius),
            borderSide: const BorderSide(color: AppColors.goldPremium, width: 1.5),
          ),
        ),
      );

  static TextTheme _textTheme(Color textColor) {
    return TextTheme(
      headlineSmall: GoogleFonts.montserrat(
        fontWeight: FontWeight.bold,
        fontSize: 22,
        color: textColor,
      ),
      titleLarge: GoogleFonts.inter(
        fontWeight: FontWeight.bold,
        fontSize: 28,
        color: textColor,
      ),
      bodyMedium: GoogleFonts.inter(
        fontWeight: FontWeight.normal,
        fontSize: 14,
        color: textColor,
      ),
      labelSmall: GoogleFonts.inter(
        fontWeight: FontWeight.normal,
        fontSize: 12,
        color: textColor.withOpacity(0.7),
      ),
    );
  }
}
