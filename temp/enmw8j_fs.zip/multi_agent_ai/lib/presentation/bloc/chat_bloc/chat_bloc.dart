import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../data/models/chat_model.dart';
import '../../../data/models/message_model.dart';
import '../../../data/models/provider_model.dart';
import '../../../data/models/skill_model.dart';
import '../../../data/repositories/chat_repository.dart';
import '../../../data/repositories/provider_repository.dart';
import '../../../data/repositories/skill_repository.dart';
import '../../../data/services/fallback_manager.dart';
import '../../../data/services/shell_service.dart';
import '../../../core/constants/constants.dart';

part 'chat_event.dart';
part 'chat_state.dart';

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final ChatRepository _chatRepo;
  final ProviderRepository _providerRepo;
  final SkillRepository _skillRepo;
  final FallbackManager _fallbackManager;
  final ShellService _shellService;
  StreamSubscription? _chatSubscription;

  ChatBloc({
    required ChatRepository chatRepo,
    required ProviderRepository providerRepo,
    required SkillRepository skillRepo,
    required FallbackManager fallbackManager,
    required ShellService shellService,
  })  : _chatRepo = chatRepo,
        _providerRepo = providerRepo,
        _skillRepo = skillRepo,
        _fallbackManager = fallbackManager,
        _shellService = shellService,
        super(ChatInitial()) {
    on<LoadChats>(_onLoadChats);
    on<SearchChats>(_onSearchChats);
    on<CreateChat>(_onCreateChat);
    on<SelectChat>(_onSelectChat);
    on<SendMessage>(_onSendMessage);
    on<DeleteChat>(_onDeleteChat);
    on<DeleteAllChats>(_onDeleteAllChats);
  }

  Future<void> _onLoadChats(LoadChats event, Emitter<ChatState> emit) async {
    emit(ChatLoading());
    try {
      final chats = await _chatRepo.getAll();
      emit(ChatsLoaded(chats: chats, currentChat: null, isTyping: false));
    } catch (e) {
      emit(ChatError(message: 'Failed to load chats: $e'));
    }
  }

  Future<void> _onSearchChats(
      SearchChats event, Emitter<ChatState> emit) async {
    try {
      final chats = await _chatRepo.getAll(searchQuery: event.query);
      if (state is ChatsLoaded) {
        final current = (state as ChatsLoaded).currentChat;
        emit(ChatsLoaded(chats: chats, currentChat: current, isTyping: false));
      }
    } catch (e) {
      emit(ChatError(message: 'Search failed: $e'));
    }
  }

  Future<void> _onCreateChat(
      CreateChat event, Emitter<ChatState> emit) async {
    try {
      final chat = await _chatRepo.createChat(
        modelId: event.modelId,
        title: event.title,
        skillId: event.skillId,
        instructionOverride: event.instructionOverride,
      );
      final chats = await _chatRepo.getAll();
      emit(ChatsLoaded(chats: chats, currentChat: chat, isTyping: false));
    } catch (e) {
      emit(ChatError(message: 'Failed to create chat: $e'));
    }
  }

  Future<void> _onSelectChat(
      SelectChat event, Emitter<ChatState> emit) async {
    try {
      final chat = await _chatRepo.getById(event.chatId);
      if (chat != null && state is ChatsLoaded) {
        emit(ChatsLoaded(
            chats: (state as ChatsLoaded).chats,
            currentChat: chat,
            isTyping: false));
      }
    } catch (e) {
      emit(ChatError(message: 'Failed to load chat: $e'));
    }
  }

  Future<void> _onSendMessage(
      SendMessage event, Emitter<ChatState> emit) async {
    if (state is! ChatsLoaded) return;
    final currentState = state as ChatsLoaded;

    ChatModel chat;
    if (currentState.currentChat == null) {
      chat = await _chatRepo.createChat(
        modelId: event.modelId,
        skillId: event.skillId,
        instructionOverride: event.instructionOverride,
      );
    } else {
      chat = currentState.currentChat!;
    }

    final userMessage = await _chatRepo.addMessage(
      chatId: chat.id,
      role: 'user',
      content: event.content,
    );
    chat.messages.add(userMessage);

    emit(ChatsLoaded(
        chats: currentState.chats,
        currentChat: chat,
        isTyping: true,
        selectedModelId: event.modelId,
        selectedSkillId: event.skillId));

    try {
      if (event.content.startsWith('!')) {
        await _handleToolCommand(chat, event.content, emit, currentState);
        return;
      }

      await _handleAiResponse(chat, event, emit, currentState);
    } catch (e) {
      final errorMessage = await _chatRepo.addMessage(
        chatId: chat.id,
        role: 'assistant',
        content: 'Error: ${e.toString()}',
      );
      chat.messages.add(errorMessage);
      emit(ChatsLoaded(
          chats: currentState.chats,
          currentChat: chat,
          isTyping: false,
          selectedModelId: event.modelId,
          selectedSkillId: event.skillId));
    }
  }

  Future<void> _handleToolCommand(ChatModel chat, String content,
      Emitter<ChatState> emit, ChatsLoaded state) async {
    final firstNewline = content.indexOf('\n');
    final firstLine = firstNewline == -1 ? content : content.substring(0, firstNewline);
    final rest = firstNewline == -1 ? '' : content.substring(firstNewline + 1);
    final parts = firstLine.split(' ');
    final tool = parts.first.substring(1); // remove '!'
    final args = parts.skip(1).join(' ');

    if (!_shellService.hasPermission) {
      final msg = await _chatRepo.addMessage(
        chatId: chat.id,
        role: 'assistant',
        content: '⚠️ Akses shell tidak dibenarkan. Sila benarkan di Tetapan.',
      );
      chat.messages.add(msg);
      emit(ChatsLoaded(chats: state.chats, currentChat: chat, isTyping: false));
      return;
    }

    ShellResult result;
    switch (tool) {
      // Shell execution
      case 'sh':
      case 'shell':
      case 'bash':
      case 'zsh':
        result = await _shellService.execute(args);
        break;
      case 'timeout':
        final timeoutParts = args.split(' ');
        if (timeoutParts.length < 2) {
          result = ShellResult(stdout: '', stderr: 'Usage: !timeout <seconds> <command>', exitCode: 1);
          break;
        }
        final secs = int.tryParse(timeoutParts.first) ?? 30;
        result = await _shellService.executeWithTimeout(timeoutParts.skip(1).join(' '), Duration(seconds: secs));
        break;
      case 'cd':
        _shellService.changeDirectory(args);
        result = ShellResult(stdout: '✓ CWD → ${_shellService.workingDirectory}', stderr: '', exitCode: 0);
        break;
      case 'pwd':
        result = ShellResult(stdout: _shellService.workingDirectory, stderr: '', exitCode: 0);
        break;

      // File operations
      case 'cat':
      case 'read':
        result = await _shellService.readFile(args);
        break;
      case 'write':
        if (firstNewline == -1) {
          result = ShellResult(stdout: '', stderr: 'Usage: !write <path>\n<content>', exitCode: 1);
          break;
        }
        result = await _shellService.writeFile(args, rest);
        break;
      case 'append':
        if (firstNewline == -1) {
          result = ShellResult(stdout: '', stderr: 'Usage: !append <path>\n<content>', exitCode: 1);
          break;
        }
        result = await _shellService.appendFile(args, rest);
        break;
      case 'ls':
        result = await _shellService.listDirectory(args.isEmpty ? '.' : args);
        break;
      case 'rm':
        result = await _shellService.deletePath(args);
        break;
      case 'mkdir':
        result = await _shellService.createDirectory(args);
        break;
      case 'cp':
        final cpParts = args.split(' ');
        if (cpParts.length < 2) {
          result = ShellResult(stdout: '', stderr: 'Usage: !cp <source> <dest>', exitCode: 1);
          break;
        }
        result = await _shellService.copyPath(cpParts[0], cpParts[1]);
        break;
      case 'mv':
        final mvParts = args.split(' ');
        if (mvParts.length < 2) {
          result = ShellResult(stdout: '', stderr: 'Usage: !mv <source> <dest>', exitCode: 1);
          break;
        }
        result = await _shellService.movePath(mvParts[0], mvParts[1]);
        break;
      case 'stat':
        result = await _shellService.fileInfo(args);
        break;
      case 'grep':
        final grepParts = args.split(' ');
        if (grepParts.length < 2) {
          result = ShellResult(stdout: '', stderr: 'Usage: !grep <pattern> <path>', exitCode: 1);
          break;
        }
        result = await _shellService.grep(grepParts[0], grepParts[1]);
        break;
      case 'find':
        final findParts = args.split(' ');
        if (findParts.length < 2) {
          result = ShellResult(stdout: '', stderr: 'Usage: !find <path> <pattern>', exitCode: 1);
          break;
        }
        result = await _shellService.findFiles(findParts[0], findParts[1]);
        break;

      // Code execution
      case 'py':
      case 'python':
        if (firstNewline == -1) {
          result = ShellResult(stdout: '', stderr: 'Usage: !py\n<code>', exitCode: 1);
          break;
        }
        result = await _shellService.runPython(rest);
        break;
      case 'node':
      case 'js':
        if (firstNewline == -1) {
          result = ShellResult(stdout: '', stderr: 'Usage: !node\n<code>', exitCode: 1);
          break;
        }
        result = await _shellService.runNode(rest);
        break;
      case 'script':
        final scriptParts = args.split(' ');
        result = await _shellService.runScript(scriptParts.first, args: scriptParts.skip(1).toList());
        break;

      // System info
      case 'uname':
        result = await _shellService.systemInfo();
        break;
      case 'df':
      case 'disk':
        result = await _shellService.diskUsage();
        break;
      case 'free':
      case 'memory':
        result = await _shellService.memoryInfo();
        break;
      case 'ps':
      case 'processes':
        result = await _shellService.listProcesses();
        break;
      case 'kill':
        final pid = int.tryParse(args.split(' ').first);
        if (pid == null) {
          result = ShellResult(stdout: '', stderr: 'Usage: !kill <pid>', exitCode: 1);
          break;
        }
        result = await _shellService.killProcess(pid, force: args.contains('-9'));
        break;
      case 'env':
        result = await _shellService.envVars();
        break;

      // Network
      case 'ping':
        result = await _shellService.ping(args);
        break;
      case 'curl':
      case 'wget':
        final curlParts = args.split(' ');
        result = await _shellService.curl(curlParts.last, extraArgs: curlParts.length > 1 ? curlParts.sublist(0, curlParts.length - 1) : null);
        break;
      case 'download':
        final dlParts = args.split(' ');
        if (dlParts.length < 2) {
          result = ShellResult(stdout: '', stderr: 'Usage: !download <url> <output>', exitCode: 1);
          break;
        }
        result = await _shellService.download(dlParts[0], dlParts[1]);
        break;

      // Package management
      case 'apt':
        result = await _shellService.aptInstall(args);
        break;
      case 'pip':
        result = await _shellService.pipInstall(args);
        break;
      case 'npm':
        result = await _shellService.npmInstall(args, global: args.contains('-g'));
        break;

      // Batch / pipe
      case 'batch':
        final commands = content.split('\n').skip(1).where((l) => l.trim().isNotEmpty).toList();
        final results = await _shellService.executeBatch(commands);
        final sb = StringBuffer('Batch results:\n');
        for (var i = 0; i < results.length; i++) {
          sb.writeln('${i + 1}. Exit ${results[i].exitCode} (${results[i].duration})');
          if (results[i].stdout.isNotEmpty) sb.writeln('   ${results[i].stdout}');
        }
        result = ShellResult(stdout: sb.toString(), stderr: '', exitCode: results.any((r) => r.exitCode != 0) ? 1 : 0);
        break;
      case 'pipe':
        final pipeCmds = args.split('|').map((s) => s.trim()).toList();
        result = await _shellService.executePiped(pipeCmds);
        break;

      // Fallback: run as raw shell command
      default:
        result = await _shellService.execute(firstLine.substring(1)); // everything after !
        break;
    }

    final output = result.isSuccess
        ? '`${result.duration.inSeconds}s`\n\n```\n${result.stdout}\n```'
        : '❌ Exit: ${result.exitCode} (${result.duration.inSeconds}s)\n\nSTDERR:\n```\n${result.stderr}\n```\nSTDOUT:\n```\n${result.stdout}\n```';
    final msg = await _chatRepo.addMessage(
      chatId: chat.id,
      role: 'assistant',
      content: output.trim(),
    );
    chat.messages.add(msg);
    emit(ChatsLoaded(chats: state.chats, currentChat: chat, isTyping: false));
  }

  Future<void> _handleAiResponse(ChatModel chat, SendMessage event,
      Emitter<ChatState> emit, ChatsLoaded state) async {
    final provider = await _getProviderForModel(event.modelId);
    if (provider == null) {
      final msg = await _chatRepo.addMessage(
        chatId: chat.id,
        role: 'assistant',
        content: '❌ Provider untuk model ini tidak ditemui.',
      );
      chat.messages.add(msg);
      emit(ChatsLoaded(chats: state.chats, currentChat: chat, isTyping: false));
      return;
    }
    if (provider.apiKeys.isEmpty) {
      final msg = await _chatRepo.addMessage(
        chatId: chat.id,
        role: 'assistant',
        content: '❌ Tiada kunci API untuk provider ${provider.name}.',
      );
      chat.messages.add(msg);
      emit(ChatsLoaded(chats: state.chats, currentChat: chat, isTyping: false));
      return;
    }

    final instruction = event.instructionOverride ?? AppConstants.defaultInstruction;
    String? skillContent;
    if (event.skillId != null) {
      final skill = await _skillRepo.getById(event.skillId!);
      skillContent = skill?.content;
    }

    // Build message list for AI
    final messages = <Map<String, String>>[];
    messages.add({'role': 'system', 'content': instruction});
    if (skillContent != null && skillContent.isNotEmpty) {
      messages.add({'role': 'system', 'content': skillContent});
    }
    for (final m in chat.messages) {
      if (m.role != 'system') {
        messages.add({'role': m.role, 'content': m.content});
      }
    }

    // Agentic tool-use loop
    String finalResponse;
    try {
      finalResponse = await _runAgentLoop(
        provider: provider,
        model: event.modelId,
        messages: messages,
      );
    } catch (e) {
      if (e.toString().contains('All API keys failed')) {
        final msg = await _chatRepo.addMessage(
          chatId: chat.id,
          role: 'assistant',
          content: '❌ Semua kunci API gagal. Sila semak baki atau tambah kunci baru.',
        );
        chat.messages.add(msg);
        emit(ChatsLoaded(chats: state.chats, currentChat: chat, isTyping: false));
        return;
      }
      rethrow;
    }

    final assistantMessage = await _chatRepo.addMessage(
      chatId: chat.id,
      role: 'assistant',
      content: finalResponse,
    );
    chat.messages.add(assistantMessage);
    emit(ChatsLoaded(chats: state.chats, currentChat: chat, isTyping: false));
  }

  Future<String> _runAgentLoop({
    required ProviderModel provider,
    required String model,
    required List<Map<String, String>> messages,
  }) async {
    final recentCalls = <String>[];

    for (var iteration = 0;; iteration++) {
      final response = await _fallbackManager.sendWithFallback(
        apiKeys: provider.apiKeys,
        providerName: provider.name,
        model: model,
        messages: messages,
      );

      // Check for tool call
      final toolCall = _parseToolCall(response);
      if (toolCall == null) {
        return response;
      }

      // Detect repetitive same tool+args (stuck loop)
      final callKey = '${toolCall['name']}|${toolCall['args']}';
      recentCalls.add(callKey);
      if (recentCalls.length > 4) recentCalls.removeAt(0);
      if (recentCalls.where((c) => c == callKey).length >= 3) {
        return 'Error: tool call "$callKey" diulang 3 kali berturut-turut. Hentikan atau cuba pendekatan berbeza.';
      }

      // Safety: 100 iterations max to prevent runaway
      if (iteration >= 100) {
        return 'Error: 100 panggilan tool berturut-turut tanpa selesai. Proses dihentikan.';
      }

      // Execute tool
      final result = await _executeNamedTool(toolCall);
      final toolOutput = result.isSuccess
          ? result.stdout
          : 'ERROR (exit ${result.exitCode}):\n${result.stderr}';

      // Add AI's tool call message and result to context
      messages.add({'role': 'assistant', 'content': response});
      messages.add({
        'role': 'user',
        'content':
            '<system-tool-result>\nTool: ${toolCall['name']}\n${toolOutput.isNotEmpty ? "Output:\n$toolOutput" : "Done"}\n</system-tool-result>\n\nContinue your response. If the tool output is wrong, try a different approach.'
      });
    }
  }

  /// Parse <tool name="X" args="Y">...</tool> from AI response
  Map<String, String>? _parseToolCall(String response) {
    final nameMatch = RegExp(r'<tool\s+name=["\']([^"\']+)["\']').firstMatch(response);
    if (nameMatch == null) return null;

    final name = nameMatch.group(1)!;

    // Extract args attribute (inline args)
    String args = '';
    final argsMatch = RegExp(r'<tool\s+name=["\'][^"\']+["\']\s*args=["\']([^"\']*)["\']').firstMatch(response);
    if (argsMatch != null) {
      args = argsMatch.group(1)!;
    }

    // Extract content between tags (for multi-line code/content)
    String content = '';
    final contentMatch = RegExp(r'<tool[^>]*>([\s\S]*?)</tool>').firstMatch(response);
    if (contentMatch != null) {
      content = contentMatch.group(1)!.trim();
    }

    // For python/node/write tools, content is the code/text
    final codeTools = {'py', 'python', 'node', 'js', 'write', 'append', 'batch'};
    if (codeTools.contains(name) && content.isNotEmpty) {
      args = content;
    }

    return {'name': name, 'args': args};
  }

  Future<ShellResult> _executeNamedTool(Map<String, String> toolCall) async {
    final name = toolCall['name']!;
    final args = toolCall['args'] ?? '';

    switch (name) {
      case 'sh': case 'shell': case 'bash': case 'zsh':
        return _shellService.execute(args);
      case 'cat': case 'read':
        return _shellService.readFile(args);
      case 'write':
        return _shellService.writeFile(args.split(' ').first, args);
      case 'append':
        return _shellService.appendFile(args.split(' ').first, args);
      case 'ls':
        return _shellService.listDirectory(args.isEmpty ? '.' : args);
      case 'rm':
        return _shellService.deletePath(args);
      case 'mkdir':
        return _shellService.createDirectory(args);
      case 'cp': {
        final parts = args.split(' ');
        if (parts.length < 2) return ShellResult(stdout: '', stderr: 'Usage: cp <src> <dst>', exitCode: 1);
        return _shellService.copyPath(parts[0], parts[1]);
      }
      case 'mv': {
        final parts = args.split(' ');
        if (parts.length < 2) return ShellResult(stdout: '', stderr: 'Usage: mv <src> <dst>', exitCode: 1);
        return _shellService.movePath(parts[0], parts[1]);
      }
      case 'grep': {
        final parts = args.split(' ');
        if (parts.length < 2) return ShellResult(stdout: '', stderr: 'Usage: grep <pattern> <path>', exitCode: 1);
        return _shellService.grep(parts[0], parts[1]);
      }
      case 'find': {
        final parts = args.split(' ');
        if (parts.length < 2) return ShellResult(stdout: '', stderr: 'Usage: find <path> <pattern>', exitCode: 1);
        return _shellService.findFiles(parts[0], parts[1]);
      }
      case 'py': case 'python':
        return _shellService.runPython(args);
      case 'node': case 'js':
        return _shellService.runNode(args);
      case 'script': {
        final parts = args.split(' ');
        return _shellService.runScript(parts.first, args: parts.skip(1).toList());
      }
      case 'ping':
        return _shellService.ping(args);
      case 'curl': case 'wget': {
        final parts = args.split(' ');
        return _shellService.curl(parts.last, extraArgs: parts.length > 1 ? parts.sublist(0, parts.length - 1) : null);
      }
      case 'download': {
        final parts = args.split(' ');
        if (parts.length < 2) return ShellResult(stdout: '', stderr: 'Usage: download <url> <output>', exitCode: 1);
        return _shellService.download(parts[0], parts[1]);
      }
      case 'uname':
        return _shellService.systemInfo();
      case 'df': case 'disk':
        return _shellService.diskUsage();
      case 'free': case 'memory':
        return _shellService.memoryInfo();
      case 'ps': case 'processes':
        return _shellService.listProcesses();
      case 'kill': {
        final pid = int.tryParse(args.split(' ').first);
        if (pid == null) return ShellResult(stdout: '', stderr: 'Usage: kill <pid>', exitCode: 1);
        return _shellService.killProcess(pid, force: args.contains('-9'));
      }
      case 'env':
        return _shellService.envVars();
      case 'apt':
        return _shellService.aptInstall(args);
      case 'pip':
        return _shellService.pipInstall(args);
      case 'npm':
        return _shellService.npmInstall(args, global: args.contains('-g'));
      case 'cd':
        _shellService.changeDirectory(args);
        return ShellResult(stdout: 'CWD: ${_shellService.workingDirectory}', stderr: '', exitCode: 0);
      case 'pwd':
        return ShellResult(stdout: _shellService.workingDirectory, stderr: '', exitCode: 0);
      case 'timeout': {
        final parts = args.split(' ');
        if (parts.length < 2) return ShellResult(stdout: '', stderr: 'Usage: timeout <sec> <cmd>', exitCode: 1);
        final secs = int.tryParse(parts.first) ?? 30;
        return _shellService.executeWithTimeout(parts.skip(1).join(' '), Duration(seconds: secs));
      }
      case 'batch': {
        final cmds = args.split('\n').where((l) => l.trim().isNotEmpty).toList();
        final results = await _shellService.executeBatch(cmds);
        final sb = StringBuffer();
        for (var i = 0; i < results.length; i++) {
          sb.writeln('#${i + 1} exit=${results[i].exitCode}');
          if (results[i].stdout.isNotEmpty) sb.writeln(results[i].stdout);
        }
        return ShellResult(stdout: sb.toString(), stderr: '', exitCode: results.any((r) => r.exitCode != 0) ? 1 : 0);
      }
      case 'pipe':
        return _shellService.executePiped(args.split('|').map((s) => s.trim()).toList());
      default:
        return _shellService.execute('$name $args');
    }
  }

  Future<ProviderModel?> _getProviderForModel(String modelId) async {
    final providers = await _providerRepo.getAll();
    for (final p in providers) {
      if (p.models.any((m) => m.id == modelId || m.name == modelId)) {
        return p;
      }
    }
    return null;
  }

  Future<void> _onDeleteChat(
      DeleteChat event, Emitter<ChatState> emit) async {
    try {
      await _chatRepo.deleteChat(event.chatId);
      final chats = await _chatRepo.getAll();
      emit(ChatsLoaded(chats: chats, currentChat: null, isTyping: false));
    } catch (e) {
      emit(ChatError(message: 'Failed to delete chat: $e'));
    }
  }

  Future<void> _onDeleteAllChats(
      DeleteAllChats event, Emitter<ChatState> emit) async {
    try {
      await _chatRepo.deleteAll();
      emit(ChatsLoaded(chats: [], currentChat: null, isTyping: false));
    } catch (e) {
      emit(ChatError(message: 'Failed to delete all chats: $e'));
    }
  }

  @override
  Future<void> close() {
    _chatSubscription?.cancel();
    return super.close();
  }
}
