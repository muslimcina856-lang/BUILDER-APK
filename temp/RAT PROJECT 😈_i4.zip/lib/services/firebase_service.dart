import 'package:firebase_database/firebase_database.dart';

class FirebaseService {
  static DatabaseReference ref = FirebaseDatabase.instance.ref();

  static void init() {
    // Atur aturan keamanan di Firebase Console nanti
  }

  static void listenDevices(Function(List<String>) onDevicesChanged) {
    ref.child('devices').onValue.listen((event) {
      if (event.snapshot.value != null) {
        Map<dynamic, dynamic> map = event.snapshot.value as Map;
        onDevicesChanged(map.keys.map((e) => e.toString()).toList());
      } else {
        onDevicesChanged([]);
      }
    });
  }

  static Future<void> sendCommand(String deviceId, String command, Map<String, dynamic> params) async {
    await ref.child('commands/$deviceId').set({
      'command': command,
      'params': params,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  static Stream<DatabaseEvent> listenCommandResult(String deviceId) {
    return ref.child('results/$deviceId').onValue;
  }
}