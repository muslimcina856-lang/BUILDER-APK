import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PayloadBuilder extends StatefulWidget {
  @override
  _PayloadBuilderState createState() => _PayloadBuilderState();
}

class _PayloadBuilderState extends State<PayloadBuilder> {
  final TextEditingController _databaseUrl = TextEditingController();
  final TextEditingController _apiKey = TextEditingController();
  final TextEditingController _projectId = TextEditingController();
  final TextEditingController _appId = TextEditingController();
  final TextEditingController _senderId = TextEditingController();
  bool _isBuilding = false;
  String _status = "";

  Future<void> _buildPayload() async {
    setState(() {
      _isBuilding = true;
      _status = "Preparing template...";
    });

    try {
      // Ambil template payload dari assets
      // Template adalah folder payload_app yang sudah disiapkan
      final templateDir = Directory('assets/payload_template');
      if (!await templateDir.exists()) {
        setState(() => _status = "Template not found. Please add payload_template to assets.");
        return;
      }

      final outputDir = await getTemporaryDirectory();
      final outputZip = File('${outputDir.path}/payload_${DateTime.now().millisecondsSinceEpoch}.zip');

      // Copy template ke temporary directory
      final tempTemplateDir = Directory('${outputDir.path}/payload_temp');
      await _copyDirectory(templateDir, tempTemplateDir);

      // Update konfigurasi Firebase di main.dart payload
      final mainDart = File('${tempTemplateDir.path}/lib/main.dart');
      String content = await mainDart.readAsString();
      content = content.replaceAll('YOUR_DATABASE_URL', _databaseUrl.text);
      content = content.replaceAll('YOUR_API_KEY', _apiKey.text);
      content = content.replaceAll('YOUR_APP_ID', _appId.text);
      content = content.replaceAll('YOUR_SENDER_ID', _senderId.text);
      content = content.replaceAll('YOUR_PROJECT_ID', _projectId.text);
      await mainDart.writeAsString(content);

      // Update google-services.json jika ada
      final googleServices = File('${tempTemplateDir.path}/android/app/google-services.json');
      if (await googleServices.exists()) {
        // Bisa juga diganti dengan dynamic
      }

      // Zip folder
      await _zipDirectory(tempTemplateDir, outputZip);

      // Hapus temp folder
      await tempTemplateDir.delete(recursive: true);

      setState(() {
        _isBuilding = false;
        _status = "Build successful! APK source code zipped.";
      });

      // Tawarkan download
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text("Payload Ready"),
          content: Text("Source code payload telah di-zip. Anda bisa build sendiri dengan Flutter atau upload ke server builder."),
          actions: [
            TextButton(onPressed: () async {
              // Simpan ke storage dan share
              final savePath = await FilePicker.platform.saveFile(dialogTitle: "Save APK source zip", fileName: "payload_source.zip");
              if (savePath != null) {
                await outputZip.copy(savePath);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Saved to $savePath")));
              }
            }, child: Text("Save ZIP")),
            TextButton(onPressed: () => Navigator.pop(context), child: Text("Close")),
          ],
        ),
      );
    } catch (e) {
      setState(() {
        _isBuilding = false;
        _status = "Error: $e";
      });
    }
  }

  Future<void> _copyDirectory(Directory source, Directory destination) async {
    if (!await destination.exists()) await destination.create(recursive: true);
    await for (var entity in source.list(recursive: false)) {
      if (entity is File) {
        await entity.copy('${destination.path}/${entity.path.split('/').last}');
      } else if (entity is Directory) {
        await _copyDirectory(entity, Directory('${destination.path}/${entity.path.split('/').last}'));
      }
    }
  }

  Future<void> _zipDirectory(Directory dir, File zipFile) async {
    final archive = Archive();
    await _addDirectoryToArchive(archive, dir, dir.path);
    final bytes = ZipEncoder().encode(archive);
    await zipFile.writeAsBytes(bytes!);
  }

  Future<void> _addDirectoryToArchive(Archive archive, Directory dir, String rootPath) async {
    await for (var entity in dir.list(recursive: true)) {
      if (entity is File) {
        final relativePath = entity.path.substring(rootPath.length + 1);
        final data = await entity.readAsBytes();
        archive.addFile(ArchiveFile(relativePath, data.length, data));
      } else if (entity is Directory) {
        // skip empty
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Build Payload")),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text("Firebase Configuration", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            TextField(controller: _databaseUrl, decoration: InputDecoration(labelText: "Database URL")),
            TextField(controller: _apiKey, decoration: InputDecoration(labelText: "API Key")),
            TextField(controller: _projectId, decoration: InputDecoration(labelText: "Project ID")),
            TextField(controller: _appId, decoration: InputDecoration(labelText: "App ID")),
            TextField(controller: _senderId, decoration: InputDecoration(labelText: "Sender ID")),
            SizedBox(height: 20),
            if (_isBuilding) CircularProgressIndicator(),
            if (_status.isNotEmpty) Text(_status, style: TextStyle(color: Colors.orange)),
            SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _isBuilding ? null : _buildPayload,
              icon: Icon(Icons.build),
              label: Text("Generate Payload Source"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            ),
            SizedBox(height: 20),
            Card(
              color: Colors.grey[900],
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Note:", style: TextStyle(fontWeight: FontWeight.bold)),
                    Text("• Template payload harus disiapkan di assets/payload_template/"),
                    Text("• Setelah generate ZIP, Anda perlu build APK menggunakan Flutter SDK"),
                    Text("• Atau gunakan remote builder (GitHub Actions / VPS) untuk otomatisasi"),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}