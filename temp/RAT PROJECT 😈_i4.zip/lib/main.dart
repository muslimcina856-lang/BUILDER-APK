import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "YOUR_API_KEY",
      appId: "YOUR_APP_ID",
      messagingSenderId: "YOUR_SENDER_ID",
      projectId: "YOUR_PROJECT_ID",
      databaseURL: "https://YOUR_PROJECT.firebaseio.com",
    ),
  );
  runApp(YanzDevApp());
}

class YanzDevApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YanzDev',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.red,
        appBarTheme: AppBarTheme(backgroundColor: Colors.red[900]),
      ),
      home: SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}