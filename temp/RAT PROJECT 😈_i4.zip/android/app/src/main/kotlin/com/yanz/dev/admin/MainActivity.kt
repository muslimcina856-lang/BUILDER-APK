package com.yanzdev.admin
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()