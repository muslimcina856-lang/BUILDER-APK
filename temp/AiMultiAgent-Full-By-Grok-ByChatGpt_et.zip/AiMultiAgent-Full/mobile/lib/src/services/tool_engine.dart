import 'dart:convert';
import 'dart:io';

import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;
import 'package:math_expressions/math_expressions.dart';
import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../data/usage_guide.dart';
import '../models/app_models.dart';
import 'browser_session_service.dart';
import 'duckduckgo_search_service.dart';
import 'file_write_coordinator.dart';
import 'linux_workspace_service.dart';
import 'local_database.dart';
import 'mcp_service.dart';
import 'platform_bridge_service.dart';
import 'skill_service.dart';
import 'terminal_service.dart';

class _BrowserPage {
  const _BrowserPage({
    required this.id,
    required this.url,
    required this.title,
    required this.text,
    required this.html,
    required this.links,
  });

  final String id;
  final String url;
  final String title;
  final String text;
  final String html;
  final List<Map<String, String>> links;
}

class ToolEngine {
  ToolEngine(
    this.database, {
    http.Client? client,
    BrowserSessionService? browserSession,
    TerminalService? terminalService,
    LinuxWorkspaceService? linuxWorkspaceService,
    SkillService? skillService,
    McpService? mcpService,
    PlatformBridgeService? platformBridge,
    this.backgroundMode = false,
  })  : _client = client ?? http.Client(),
        browserSession = browserSession ?? BrowserSessionService(),
        terminalService = terminalService ?? TerminalService(),
        linuxWorkspaceService = linuxWorkspaceService ?? LinuxWorkspaceService(),
        skillService = skillService ?? SkillService(database),
        mcpService = mcpService ?? McpService(),
        platformBridge = platformBridge ?? PlatformBridgeService() {
    _searchService = DuckDuckGoSearchService(client: _client);
  }

  final LocalDatabase database;
  final http.Client _client;
  final BrowserSessionService browserSession;
  final TerminalService terminalService;
  final LinuxWorkspaceService linuxWorkspaceService;
  final SkillService skillService;
  final McpService mcpService;
  final PlatformBridgeService platformBridge;
  final bool backgroundMode;
  late final DuckDuckGoSearchService _searchService;
  static const _uuid = Uuid();
  FileWriteCoordinator? _fileWriteCoordinator;
  final Map<String, _BrowserPage> _pages = <String, _BrowserPage>{};

  List<ToolDefinition> get definitions => <ToolDefinition>[
        const ToolDefinition(
          id: 'web_search',
          name: 'DuckDuckGo Search',
          category: 'Web',
          risk: ToolRisk.readOnly,
          description: 'Cari web menggunakan DuckDuckGo. Pulangkan hasil penuh dengan ranking, tajuk, URL, domain dan petikan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'query': <String, dynamic>{'type': 'string'},
              'max_results': <String, dynamic>{'type': 'integer', 'minimum': 1, 'maximum': 20},
              'region': <String, dynamic>{'type': 'string', 'description': 'Contoh wt-wt, my-en, us-en.'},
              'time_range': <String, dynamic>{'type': 'string', 'description': 'Kosong, d, w, m atau y.'},
            },
            'required': <String>['query'],
          },
        ),
        const ToolDefinition(
          id: 'browser_open',
          name: 'Buka URL di Browser Latar',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Buka URL dalam WebView tersembunyi (JS sentiasa ON). '
              'BUKAN untuk membuka panel Browser kepada pengguna; guna workspace_show untuk itu. '
              'new_tab=true buka tab baharu (max 5). window.open/target=_blank auto-cipta tab.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'desktop_mode': <String, dynamic>{
                'type': 'boolean',
                'description': 'true = desktop; false = mudah alih.',
              },
              'new_tab': <String, dynamic>{
                'type': 'boolean',
                'description': 'true = tab baharu (max 5); false = tab aktif.',
              },
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'browser_tabs',
          name: 'Senarai Tab Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Senarai tab terbuka (max 5): id, url, title, active. '
              'Guna selepas login/OTP yang buka tab lain.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'browser_switch_tab',
          name: 'Tukar Tab Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Tukar tab aktif mengikut tab_id dari browser_tabs. '
              'click/fill/read/screenshot seterusnya pada tab itu.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'tab_id': <String, dynamic>{
                'type': 'integer',
                'description': 'ID tab dari browser_tabs.',
              },
            },
            'required': <String>['tab_id'],
          },
        ),
        const ToolDefinition(
          id: 'browser_close_tab',
          name: 'Tutup Tab Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Tutup tab mengikut tab_id (atau tab aktif jika tiada). '
              'Wajib bila had 5 tab penuh.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'tab_id': <String, dynamic>{
                'type': 'integer',
                'description': 'ID tab; kosong = tab aktif.',
              },
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_session_status',
          name: 'Status Sesi Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Semak metadata sesi WebView bagi URL/origin: nama cookie dan kunci localStorage/sessionStorage sahaja. '
              'Nilai cookie dan token tidak pernah dipulangkan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{
                'type': 'string',
                'description': 'URL sasaran; kosong menggunakan halaman aktif.',
              },
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_clear_session',
          name: 'Kosongkan Sesi Browser',
          category: 'Browser',
          risk: ToolRisk.sensitive,
          description:
              'Reset penuh semua tab WebView, cookies, Web Storage, cache, history, data borang dan HTTP auth. '
              'Gunakan hanya apabila pengguna meminta clear/logout/reset sesi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'browser_cookie_set',
          name: 'Tetapkan Cookie Browser',
          category: 'Browser',
          risk: ToolRisk.sensitive,
          description:
              'Tetapkan satu cookie host-only untuk URL sasaran. Hasil hanya menyatakan nama dan atribut, bukan nilai.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{
                'type': 'string',
                'description': 'URL sasaran; kosong menggunakan halaman aktif.',
              },
              'name': <String, dynamic>{'type': 'string'},
              'value': <String, dynamic>{'type': 'string'},
              'path': <String, dynamic>{'type': 'string', 'description': 'Lalai /. '},
              'secure': <String, dynamic>{'type': 'boolean'},
              'http_only': <String, dynamic>{'type': 'boolean'},
              'same_site': <String, dynamic>{
                'type': 'string',
                'enum': <String>['Lax', 'Strict', 'None'],
              },
            },
            'required': <String>['name', 'value'],
          },
        ),
        const ToolDefinition(
          id: 'browser_cookie_delete',
          name: 'Padam Cookie Browser',
          category: 'Browser',
          risk: ToolRisk.sensitive,
          description: 'Padam satu cookie pada URL/path sasaran tanpa mendedahkan nilainya.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{
                'type': 'string',
                'description': 'URL sasaran; kosong menggunakan halaman aktif.',
              },
              'name': <String, dynamic>{'type': 'string'},
              'path': <String, dynamic>{'type': 'string', 'description': 'Lalai /.'},
            },
            'required': <String>['name'],
          },
        ),
        const ToolDefinition(
          id: 'browser_inject_token',
          name: 'Suntik Token Browser',
          category: 'Browser',
          risk: ToolRisk.sensitive,
          description:
              'Suntik satu token ke cookie, localStorage atau sessionStorage bagi origin sasaran. '
              'Untuk storan web, buka origin itu dahulu. Nilai token tidak dipulangkan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{
                'type': 'string',
                'description': 'URL sasaran; kosong menggunakan halaman aktif.',
              },
              'target': <String, dynamic>{
                'type': 'string',
                'enum': <String>['cookie', 'local_storage', 'session_storage'],
              },
              'key': <String, dynamic>{'type': 'string'},
              'token': <String, dynamic>{'type': 'string'},
              'path': <String, dynamic>{'type': 'string'},
              'secure': <String, dynamic>{'type': 'boolean'},
              'http_only': <String, dynamic>{'type': 'boolean'},
              'same_site': <String, dynamic>{
                'type': 'string',
                'enum': <String>['Lax', 'Strict', 'None'],
              },
            },
            'required': <String>['target', 'key', 'token'],
          },
        ),
        const ToolDefinition(
          id: 'browser_inject_session',
          name: 'Suntik Sesi Browser',
          category: 'Browser',
          risk: ToolRisk.sensitive,
          description:
              'Suntik beberapa cookies dan peta localStorage/sessionStorage untuk origin sasaran. '
              'Buka origin dahulu jika menggunakan storan web. Hasil hanya nama/kunci dan bilangan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{
                'type': 'string',
                'description': 'URL sasaran; kosong menggunakan halaman aktif.',
              },
              'cookies': <String, dynamic>{
                'type': 'array',
                'items': <String, dynamic>{
                  'type': 'object',
                  'properties': <String, dynamic>{
                    'name': <String, dynamic>{'type': 'string'},
                    'value': <String, dynamic>{'type': 'string'},
                    'path': <String, dynamic>{'type': 'string'},
                    'secure': <String, dynamic>{'type': 'boolean'},
                    'http_only': <String, dynamic>{'type': 'boolean'},
                    'same_site': <String, dynamic>{
                      'type': 'string',
                      'enum': <String>['Lax', 'Strict', 'None'],
                    },
                  },
                  'required': <String>['name', 'value'],
                },
              },
              'local_storage': <String, dynamic>{
                'type': 'object',
                'additionalProperties': <String, dynamic>{'type': 'string'},
              },
              'session_storage': <String, dynamic>{
                'type': 'object',
                'additionalProperties': <String, dynamic>{'type': 'string'},
              },
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_read',
          name: 'Baca Halaman Aktif',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Baca keadaan halaman browser aktif: URL, tajuk, teks, senarai elemen interaktif (dengan index), pautan dan borang. '
              'Sentiasa panggil ini sebelum click/fill. Gunakan index dari interactive_elements untuk tindakan seterusnya.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'browser_screenshot',
          name: 'Screenshot Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Ambil screenshot Browser untuk analisis AI sahaja. '
              'Screenshot laman tidak dilampirkan ke chat kerana panel native boleh dilihat secara langsung.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'workspace_show',
          name: 'Buka Panel Browser Terapung',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Buka, aktifkan atau paparkan panel Browser native di atas aplikasi—bukan dalam chat. '
              'Panel bersaiz kompak, boleh dialih dari seluruh bar atas atau dijadikan skrin penuh dan kekal sehingga ditutup. '
              'Tidak membuat carian web dan tidak memerlukan URL.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'fullscreen': <String, dynamic>{
                'type': 'boolean',
                'description':
                    'true = skrin penuh; false = saiz terapung biasa. Jika tidak diberi, kekalkan keadaan semasa.',
              },
            },
          },
        ),
        const ToolDefinition(
          id: 'workspace_hide',
          name: 'Sembunyikan Workspace Terapung',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Sembunyikan panel terapung tanpa memadam tab browser atau sesi login.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'workspace_status',
          name: 'Status Workspace Terapung',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Semak sama ada panel Browser sedang terlihat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'browser_adblock',
          name: 'Adblock Sesi Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Hidup/matikan adblock hanya untuk chat semasa. Lalai sentiasa mati.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'enabled': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['enabled'],
          },
        ),
        const ToolDefinition(
          id: 'browser_audio',
          name: 'Audio Browser Sesi',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Hidup atau matikan audio Browser bagi chat semasa. Lalai hidup; '
              'hanya tab aktif yang sedang terlihat boleh berbunyi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'enabled': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['enabled'],
          },
        ),
        const ToolDefinition(
          id: 'browser_devtools',
          name: 'DevTools Dalaman Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Pantau log sambungan dan console tab aktif, kosongkan log, atau '
              'jalankan JavaScript dalam halaman untuk memeriksa/mengubah DOM dan CSS. '
              'Log dibatasi supaya aplikasi kekal ringan. action=evaluate memerlukan script.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'action': <String, dynamic>{
                'type': 'string',
                'enum': <String>['inspect', 'clear', 'evaluate'],
              },
              'script': <String, dynamic>{
                'type': 'string',
                'maxLength': 12000,
                'description': 'JavaScript untuk action=evaluate.',
              },
              'limit': <String, dynamic>{
                'type': 'integer',
                'minimum': 1,
                'maximum': 100,
              },
            },
            'required': <String>['action'],
          },
        ),
        const ToolDefinition(
          id: 'browser_media_control',
          name: 'Kawal dan Sahkan Media Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Semak keadaan video/audio sebenar atau cuba play, pause dan skip_ad. '
              'Hasil memulangkan playing, paused, readyState, adShowing dan skipAvailable. '
              'Selepas play, wajib semak playing=true; jika masih paused gunakan gesture native.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'action': <String, dynamic>{
                'type': 'string',
                'enum': <String>['status', 'play', 'pause', 'skip_ad'],
              },
              'selector': <String, dynamic>{
                'type': 'string',
                'description': 'Selector butang play tersuai jika diperlukan.',
              },
            },
            'required': <String>['action'],
          },
        ),
        const ToolDefinition(
          id: 'browser_wait',
          name: 'Tunggu Keadaan Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description:
              'Tunggu sehingga halaman siap, selector/teks/URL muncul, media benar-benar '
              'bermain atau iklan sudah tiada. Maksimum 30 saat dan boleh dibatalkan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'condition': <String, dynamic>{
                'type': 'string',
                'enum': <String>[
                  'page_ready',
                  'selector',
                  'text',
                  'url',
                  'media_playing',
                  'ad_gone',
                ],
              },
              'selector': <String, dynamic>{'type': 'string'},
              'text': <String, dynamic>{'type': 'string'},
              'url_contains': <String, dynamic>{'type': 'string'},
              'timeout_ms': <String, dynamic>{
                'type': 'integer',
                'minimum': 500,
                'maximum': 30000,
              },
            },
            'required': <String>['condition'],
          },
        ),
        const ToolDefinition(
          id: 'browser_native_gesture',
          name: 'Gesture Native Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Laluan kedua selepas DOM/index: hantar sentuhan Android sebenar '
              'untuk click, long_press, swipe atau scroll. Boleh guna index, selector '
              'atau koordinat screenshot Browser.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'action': <String, dynamic>{
                'type': 'string',
                'enum': <String>['click', 'long_press', 'swipe', 'scroll'],
              },
              'index': <String, dynamic>{'type': 'integer'},
              'selector': <String, dynamic>{'type': 'string'},
              'text': <String, dynamic>{'type': 'string'},
              'x': <String, dynamic>{'type': 'number'},
              'y': <String, dynamic>{'type': 'number'},
              'to_x': <String, dynamic>{'type': 'number'},
              'to_y': <String, dynamic>{'type': 'number'},
              'delta_y': <String, dynamic>{
                'type': 'number',
                'description': 'Positif = scroll halaman ke bawah.',
              },
              'duration_ms': <String, dynamic>{
                'type': 'integer',
                'minimum': 70,
                'maximum': 1600,
              },
            },
            'required': <String>['action'],
          },
        ),
        const ToolDefinition(
          id: 'browser_follow_link',
          name: 'Ikut Pautan',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Buka pautan daripada page_id dan indeks hasil browser.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'page_id': <String, dynamic>{'type': 'string'},
              'link_index': <String, dynamic>{'type': 'integer'},
            },
            'required': <String>['page_id', 'link_index'],
          },
        ),
        const ToolDefinition(
          id: 'browser_click',
          name: 'Klik Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Klik elemen pada halaman browser. UTAMAKAN parameter index dari interactive_elements (hasil browser_read). '
              'Alternatif: text (teks butang/pautan) atau selector CSS.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'index': <String, dynamic>{
                'type': 'integer',
                'description': 'Index elemen dari interactive_elements (disyorkan).',
              },
              'selector': <String, dynamic>{'type': 'string'},
              'text': <String, dynamic>{'type': 'string'},
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_fill',
          name: 'Isi Input Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Isi input/textarea/select pada halaman browser. UTAMAKAN parameter index dari interactive_elements. '
              'Alternatif: selector CSS. Wajib sertakan value. '
              'Jangan guna untuk dropdown tersuai (widget=true / role=combobox); guna browser_select_option.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'index': <String, dynamic>{
                'type': 'integer',
                'description': 'Index elemen input dari interactive_elements (disyorkan).',
              },
              'selector': <String, dynamic>{'type': 'string'},
              'value': <String, dynamic>{'type': 'string'},
              'type_mode': <String, dynamic>{
                'type': 'boolean',
                'description':
                    'true = taip aksara demi aksara untuk medan bertopeng seperti tarikh atau nombor kad.',
              },
            },
            'required': <String>['value'],
          },
        ),
        const ToolDefinition(
          id: 'browser_select_option',
          name: 'Pilih Dropdown Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Pilih nilai daripada select native atau dropdown React tersuai seperti '
              'Radix, Headless UI, MUI dan react-select. Gunakan apabila '
              'interactive_elements menunjukkan widget=true atau role=combobox/listbox.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'index': <String, dynamic>{
                'type': 'integer',
                'description': 'Index pencetus dropdown daripada browser_read.',
              },
              'label': <String, dynamic>{
                'type': 'string',
                'description': 'Teks/label pencetus jika index tidak diketahui.',
              },
              'selector': <String, dynamic>{'type': 'string'},
              'option_text': <String, dynamic>{
                'type': 'string',
                'description': 'Teks pilihan yang hendak dipilih.',
              },
            },
            'required': <String>['option_text'],
          },
        ),
        const ToolDefinition(
          id: 'browser_press_key',
          name: 'Tekan Kekunci Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Hantar kekunci atau taip aksara demi aksara untuk combobox, input bertopeng, '
              'Escape, Tab, Enter dan anak panah. Beri key atau text.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'index': <String, dynamic>{'type': 'integer'},
              'selector': <String, dynamic>{'type': 'string'},
              'key': <String, dynamic>{
                'type': 'string',
                'description': 'Enter, Tab, Escape, ArrowDown, ArrowUp, Backspace atau satu aksara.',
              },
              'text': <String, dynamic>{
                'type': 'string',
                'description': 'Teks untuk ditaip aksara demi aksara.',
              },
              'repeat': <String, dynamic>{
                'type': 'integer',
                'description': 'Bilangan ulangan, lalai 1 dan maksimum 40.',
              },
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_submit_form',
          name: 'Hantar Borang Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description:
              'Hantar borang dalam browser. Boleh guna index elemen (butang submit / input dalam form) atau selector CSS form.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'index': <String, dynamic>{'type': 'integer'},
              'selector': <String, dynamic>{'type': 'string'},
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_download',
          name: 'Muat Turun Fail',
          category: 'Browser',
          risk: ToolRisk.localWrite,
          description: 'Muat turun URL ke folder workspace tempatan aplikasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'filename': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'media_preview',
          name: 'Hantar Fail / Media ke Chat',
          category: 'Media',
          risk: ToolRisk.readOnly,
          description:
              'Hantar fail workspace terus ke chat sebagai kad pratonton/muat turun. '
              'Bukan media sahaja: json, zip, pdf, html, txt, csv, imej, video, audio. '
              'Path: trylink_all_users.json, /workspace/a.zip, output/data.json. '
              'URL http(s) untuk imej/video/audio. Jangan suruh user buka File Manager '
              'jika fail sudah dalam /workspace — panggil tool ini.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{
                'type': 'string',
                'description':
                    'URL http(s) ATAU path workspace/lampiran (relatif atau /workspace/...).',
              },
              'path': <String, dynamic>{
                'type': 'string',
                'description': 'Path workspace jika tidak guna url.',
              },
              'kind': <String, dynamic>{
                'type': 'string',
                'enum': <String>['image', 'video', 'audio', 'file', 'html'],
              },
              'title': <String, dynamic>{'type': 'string'},
              'mime_type': <String, dynamic>{'type': 'string'},
            },
            'required': <String>[],
          },
        ),
        const ToolDefinition(
          id: 'send_file',
          name: 'Hantar Fail Workspace',
          category: 'Fail',
          risk: ToolRisk.readOnly,
          description:
              'Hantar fail siap yang sudah ada dalam workspace/lampiran ke chat. '
              'Fail kosong, staging, atau sasaran transaksi aktif akan ditolak.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'title': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'open_url',
          name: 'Buka URL Latar',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Buka URL dalam browser latar dan pulangkan ringkasan halaman kepada chat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'desktop_mode': <String, dynamic>{
                'type': 'boolean',
                'description': 'true untuk emulasi browser desktop/PC.',
              },
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'http_request',
          name: 'HTTP Request',
          category: 'Web',
          risk: ToolRisk.externalWrite,
          description: 'Hantar permintaan HTTP. Hanya operasi yang dikesan destruktif akan meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'method': <String, dynamic>{'type': 'string'},
              'url': <String, dynamic>{'type': 'string'},
              'headers': <String, dynamic>{'type': 'object'},
              'body': <String, dynamic>{},
            },
            'required': <String>['method', 'url'],
          },
        ),
        const ToolDefinition(
          id: 'file_list',
          name: 'Senarai Fail',
          category: 'Fail',
          risk: ToolRisk.readOnly,
          description: 'Senaraikan fail dalam workspace tempatan aplikasi.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{'path': <String, dynamic>{'type': 'string'}}},
        ),
        const ToolDefinition(
          id: 'file_read',
          name: 'Baca Fail',
          category: 'Fail',
          risk: ToolRisk.readOnly,
          description:
              'Baca fail teks secara berhalaman tanpa memuatkan seluruh fail ke memori. '
              'Pulangkan SHA-256 penuh untuk edit exact-safe. Gunakan next_start_line '
              'sehingga has_more=false jika perlu.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'offset': <String, dynamic>{
                'type': 'integer',
                'description': 'Serasi lama: indeks aksara mula (0 = awal).',
              },
              'length': <String, dynamic>{
                'type': 'integer',
                'description': 'Serasi lama: bilangan aksara, maksimum 24000.',
              },
              'start_line': <String, dynamic>{
                'type': 'integer',
                'minimum': 1,
              },
              'max_lines': <String, dynamic>{
                'type': 'integer',
                'minimum': 1,
                'maximum': 500,
              },
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'file_write',
          name: 'Tulis Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Mulakan penulisan bertransaksi pada path tepat. Maksimum 6000 bait UTF-8 '
              'setiap content. Fail kecil: done=true (lalai) untuk atomic commit. '
              'Fail panjang: done=false, kemudian file_append dengan write_id + sequence. '
              'Path atau extension tidak pernah diteka atau ditukar.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'content': <String, dynamic>{
                'type': 'string',
                'maxLength': FileWriteCoordinator.maxChunkBytes,
              },
              'done': <String, dynamic>{'type': 'boolean'},
              'append': <String, dynamic>{
                'type': 'boolean',
                'description': 'Serasi lama: true melakukan atomic append pada path.',
              },
              'overwrite': <String, dynamic>{'type': 'boolean'},
              'base_sha256': <String, dynamic>{'type': 'string'},
              'expected_sha256': <String, dynamic>{'type': 'string'},
              'expected_bytes': <String, dynamic>{'type': 'integer'},
            },
            'required': <String>['path', 'content'],
          },
        ),
        const ToolDefinition(
          id: 'file_append',
          name: 'Tambah ke Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Sambung transaksi dengan write_id + next_sequence, atau gunakan path + content '
              'untuk mod append lama yang tetap atomic. Maksimum 6000 bait setiap content.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'write_id': <String, dynamic>{'type': 'string'},
              'sequence': <String, dynamic>{'type': 'integer', 'minimum': 1},
              'path': <String, dynamic>{'type': 'string'},
              'content': <String, dynamic>{
                'type': 'string',
                'maxLength': FileWriteCoordinator.maxChunkBytes,
              },
              'done': <String, dynamic>{'type': 'boolean'},
              'expected_sha256': <String, dynamic>{'type': 'string'},
              'expected_bytes': <String, dynamic>{'type': 'integer'},
            },
            'required': <String>['content'],
          },
        ),
        const ToolDefinition(
          id: 'file_commit',
          name: 'Sahkan dan Commit Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Sahkan saiz, hash dan format fail staging sebelum atomic commit. '
              'Fail belum dihantar ke chat sebelum commit berjaya.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'write_id': <String, dynamic>{'type': 'string'},
              'expected_sha256': <String, dynamic>{'type': 'string'},
              'expected_bytes': <String, dynamic>{'type': 'integer'},
            },
            'required': <String>['write_id'],
          },
        ),
        const ToolDefinition(
          id: 'file_write_status',
          name: 'Status Penulisan Fail',
          category: 'Fail',
          risk: ToolRisk.readOnly,
          description:
              'Semak bytes, lines, tail, SHA-256 dan next_sequence transaksi untuk resume selamat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'write_id': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['write_id'],
          },
        ),
        const ToolDefinition(
          id: 'file_abort',
          name: 'Batalkan Penulisan Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Batalkan transaksi staging tanpa menyentuh fail sasaran atau fail asal.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'write_id': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['write_id'],
          },
        ),
        const ToolDefinition(
          id: 'file_replace',
          name: 'Ganti Teks dalam Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Cari dan ganti teks dalam fail workspace tanpa menulis semula seluruh fail secara manual. '
              'Sokong plain text atau regex. Lalai ganti semua padanan; set replace_all=false untuk sekali sahaja.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{
                'type': 'string',
                'description': 'Path fail relatif workspace.',
              },
              'find': <String, dynamic>{
                'type': 'string',
                'description': 'Teks atau corak yang dicari.',
              },
              'replace': <String, dynamic>{
                'type': 'string',
                'description': 'Teks gantian (boleh kosong untuk padam padanan).',
              },
              'regex': <String, dynamic>{
                'type': 'boolean',
                'description': 'true = interpret find sebagai RegExp Dart.',
              },
              'replace_all': <String, dynamic>{
                'type': 'boolean',
                'description': 'true (lalai) = ganti semua; false = ganti padanan pertama sahaja.',
              },
              'case_sensitive': <String, dynamic>{
                'type': 'boolean',
                'description': 'true (lalai) = sensitif huruf; false = abaikan case.',
              },
              'expected_sha256': <String, dynamic>{
                'type': 'string',
                'description': 'Pilihan: SHA-256 daripada file_read.',
              },
            },
            'required': <String>['path', 'find', 'replace'],
          },
        ),
        const ToolDefinition(
          id: 'str_replace',
          name: 'Ganti String Tepat',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Edit exact-safe untuk fail sedia ada. Wajib file_read dahulu dan hantar '
              'expected_sha256. Lalai memerlukan tepat satu padanan; replace_all=true mesti eksplisit.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'find': <String, dynamic>{'type': 'string'},
              'replace': <String, dynamic>{'type': 'string'},
              'regex': <String, dynamic>{'type': 'boolean'},
              'replace_all': <String, dynamic>{'type': 'boolean'},
              'case_sensitive': <String, dynamic>{'type': 'boolean'},
              'expected_sha256': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['path', 'find', 'replace', 'expected_sha256'],
          },
        ),
        const ToolDefinition(
          id: 'file_copy',
          name: 'Salin Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Salin fail dalam workspace. Penimpaan destinasi meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'source': <String, dynamic>{'type': 'string'},
              'destination': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['source', 'destination'],
          },
        ),
        const ToolDefinition(
          id: 'file_move',
          name: 'Pindah Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Pindah atau namakan semula fail. Penimpaan destinasi meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'source': <String, dynamic>{'type': 'string'},
              'destination': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['source', 'destination'],
          },
        ),
        const ToolDefinition(
          id: 'file_delete',
          name: 'Padam Fail',
          category: 'Fail',
          risk: ToolRisk.sensitive,
          description: 'Padam fail atau folder dalam workspace. Tindakan ini sentiasa dianggap berisiko.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'recursive': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'memory_search',
          name: 'Cari Memori',
          category: 'Memori',
          risk: ToolRisk.readOnly,
          description: 'Cari rekod memori tempatan berdasarkan kata kunci.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'query': <String, dynamic>{'type': 'string'}},
            'required': <String>['query'],
          },
        ),
        const ToolDefinition(
          id: 'memory_add',
          name: 'Tambah Memori',
          category: 'Memori',
          risk: ToolRisk.localWrite,
          description: 'Simpan fakta atau nota ke memori tempatan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'title': <String, dynamic>{'type': 'string'},
              'content': <String, dynamic>{'type': 'string'},
              'tags': <String, dynamic>{'type': 'array', 'items': <String, dynamic>{'type': 'string'}},
            },
            'required': <String>['title', 'content'],
          },
        ),
        const ToolDefinition(
          id: 'memory_delete',
          name: 'Padam Memori',
          category: 'Memori',
          risk: ToolRisk.sensitive,
          description: 'Padam satu rekod memori tempatan menggunakan ID.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'id': <String, dynamic>{'type': 'string'}},
            'required': <String>['id'],
          },
        ),
        const ToolDefinition(
          id: 'linux_workspace_status',
          name: 'Status Linux Workspace',
          category: 'Terminal',
          risk: ToolRisk.readOnly,
          description: 'Semak pemasangan automatik Alpine Linux ARM64 melalui PRoot, versi manifest, status kesihatan, storan private dan pengurus pakej apk.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'terminal_start',
          name: 'Terminal Latar Belakang',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description:
              'Pasang runtime Alpine ARM64 bawaan jika perlu, jalankan arahan shell melalui PRoot dalam /workspace, dan pulangkan job_id. '
              'Gunakan apk untuk pakej (contoh: apk add --no-cache wine). '
              'Untuk menjalankan fail .exe: pasang wine terlebih dahulu, kemudian gunakan wine /workspace/fail.exe atau tool run_exe. '
              'Semua arahan dibenarkan automatik (tiada dialog kelulusan).',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'command': <String, dynamic>{'type': 'string'},
              'working_directory': <String, dynamic>{'type': 'string'},
              'environment': <String, dynamic>{'type': 'object'},
            },
            'required': <String>['command'],
          },
        ),
        const ToolDefinition(
          id: 'terminal_poll',
          name: 'Pantau Terminal',
          category: 'Terminal',
          risk: ToolRisk.readOnly,
          description: 'Baca stdout, stderr, status dan exit code job terminal supaya AI boleh melihat proses latar belakang.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'job_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['job_id'],
          },
        ),
        const ToolDefinition(
          id: 'terminal_stop',
          name: 'Hentikan Terminal',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description: 'Hentikan job terminal latar belakang.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'job_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['job_id'],
          },
        ),
        const ToolDefinition(
          id: 'terminal_stdin',
          name: 'Input Terminal',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description:
              'Hantar teks ke stdin job terminal yang sedang berjalan. '
              'Pengguna juga boleh taip terus dalam konsol chat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'job_id': <String, dynamic>{'type': 'string'},
              'text': <String, dynamic>{'type': 'string'},
              'newline': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['job_id', 'text'],
          },
        ),
        const ToolDefinition(
          id: 'run_exe',
          name: 'Jalankan EXE (via Wine)',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description:
              'Jalankan fail .exe dalam Linux Workspace menggunakan Wine. '
              'Tool ini akan cuba pastikan Wine tersedia (apk add --no-cache wine jika perlu), kemudian jalankan wine <path> [args]. '
              'Path relatif kepada /workspace atau path absolute guest. '
              'Nota: keserasian terhad pada aarch64; bukan semua aplikasi Windows serasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{
                'type': 'string',
                'description': 'Path ke fail .exe (contoh: /workspace/app.exe atau relative path).',
              },
              'arguments': <String, dynamic>{
                'type': 'array',
                'items': <String, dynamic>{'type': 'string'},
              },
              'working_directory': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'skill_create',
          name: 'Cipta Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description:
              'Cipta skill local baharu tanpa dialog. Nama mesti unik; tool ini '
              'dilarang menimpa skill sedia ada.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'id': <String, dynamic>{'type': 'string', 'description': 'ID pilihan. Kosongkan untuk jana ID.'},
              'name': <String, dynamic>{'type': 'string'},
              'description': <String, dynamic>{'type': 'string'},
              'instructions': <String, dynamic>{'type': 'string'},
              'tool_ids': <String, dynamic>{
                'type': 'array',
                'items': <String, dynamic>{'type': 'string'},
              },
              'enabled': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['name', 'description', 'instructions'],
          },
        ),
        const ToolDefinition(
          id: 'skill_update',
          name: 'Kemas Kini Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description:
              'Cadangkan perubahan maklumat skill pengguna sedia ada. '
              'Aplikasi sentiasa memaparkan perbezaan dan menunggu pengesahan pengguna.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'id': <String, dynamic>{'type': 'string'},
              'name': <String, dynamic>{
                'type': 'string',
                'description': 'Nama semasa untuk mencari skill.',
              },
              'new_name': <String, dynamic>{'type': 'string'},
              'description': <String, dynamic>{'type': 'string'},
              'instructions': <String, dynamic>{'type': 'string'},
              'tool_ids': <String, dynamic>{
                'type': 'array',
                'items': <String, dynamic>{'type': 'string'},
              },
              'enabled': <String, dynamic>{'type': 'boolean'},
            },
          },
        ),
        const ToolDefinition(
          id: 'skill_delete',
          name: 'Padam Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description:
              'Cadangkan pemadaman skill pengguna. Aplikasi sentiasa '
              'memaparkan butiran skill dan menunggu pengesahan pengguna.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'id': <String, dynamic>{'type': 'string'},
              'name': <String, dynamic>{'type': 'string'},
            },
          },
        ),
        const ToolDefinition(
          id: 'skill_set_enabled',
          name: 'Hidup/Mati Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description:
              'Hidupkan atau matikan skill sedia ada mengikut nama atau id. '
              'Jika skill sudah enabled, jangan ulang — beritahu user ia dah aktif.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'name': <String, dynamic>{'type': 'string'},
              'id': <String, dynamic>{'type': 'string'},
              'enabled': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['enabled'],
          },
        ),
        const ToolDefinition(
          id: 'skill_install_url',
          name: 'Pasang Skill dari URL atau Fail',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description:
              'Pasang skill dari URL HTTP(S) ATAU fail ZIP lampiran/workspace. '
              'ZIP mesti ada skill.json ATAU SKILL.md (auto-convert). '
              'Repo GitHub biasa tanpa kedua-dua → JANGAN paksa; baca README/SKILL.md lalu skill_create. '
              'Path: nama.zip, /attachments/nama.zip, atau path workspace.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string', 'description': 'URL HTTP(S) arkib skill (pilihan jika path diberi)'},
              'path': <String, dynamic>{
                'type': 'string',
                'description':
                    'Path fail ZIP tempatan: nama lampiran, /attachments/nama.zip, atau path workspace relatif',
              },
            },
            'required': <String>[],
          },
        ),
        const ToolDefinition(
          id: 'archive_unzip',
          name: 'Unzip Arkib',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description:
              'Extract fail ZIP ke folder workspace. Sumber boleh dari lampiran chat '
              '(/attachments/nama.zip atau nama fail) atau path workspace relatif.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string', 'description': 'Fail ZIP sumber'},
              'destination': <String, dynamic>{
                'type': 'string',
                'description': 'Folder destinasi dalam workspace (lalai: nama arkib tanpa .zip)',
              },
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'archive_zip',
          name: 'Zip Folder/Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Cipta fail ZIP dari path workspace relatif.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string', 'description': 'Fail atau folder sumber dalam workspace'},
              'destination': <String, dynamic>{
                'type': 'string',
                'description': 'Nama fail ZIP output dalam workspace (pilihan)',
              },
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'skill_run_script',
          name: 'Jalankan Skrip Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description:
              'Jalankan skrip dari pakej skill yang dipasang (ZIP/SKILL.md dengan folder). '
              'JANGAN guna untuk skill dari skill_create (arahan sahaja, tiada folder skrip) — '
              'untuk itu guna terminal_start. Gagal dengan mesej jelas jika skill tiada sourcePath.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'skill_id': <String, dynamic>{'type': 'string'},
              'script': <String, dynamic>{'type': 'string'},
              'arguments': <String, dynamic>{'type': 'array', 'items': <String, dynamic>{'type': 'string'}},
            },
            'required': <String>['skill_id', 'script'],
          },
        ),
        const ToolDefinition(
          id: 'mcp_list_tools',
          name: 'Senarai Tools MCP',
          category: 'MCP',
          risk: ToolRisk.readOnly,
          description: 'Senaraikan tools daripada server MCP yang telah dikonfigurasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'server_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['server_id'],
          },
        ),
        const ToolDefinition(
          id: 'mcp_call',
          name: 'Panggil Tool MCP',
          category: 'MCP',
          risk: ToolRisk.externalWrite,
          description: 'Panggil tool pada server MCP. Nama/argumen destruktif meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'server_id': <String, dynamic>{'type': 'string'},
              'tool_name': <String, dynamic>{'type': 'string'},
              'arguments': <String, dynamic>{'type': 'object'},
            },
            'required': <String>['server_id', 'tool_name'],
          },
        ),
        const ToolDefinition(
          id: 'mcp_configure',
          name: 'Konfigurasi MCP',
          category: 'MCP',
          risk: ToolRisk.localWrite,
          description:
              'Simpan atau kemas kini server MCP dari data pengguna (nama, URL, headers). '
              'Guna bila pengguna beri URL/token MCP dalam chat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'id': <String, dynamic>{'type': 'string'},
              'name': <String, dynamic>{'type': 'string'},
              'url': <String, dynamic>{'type': 'string'},
              'headers': <String, dynamic>{'type': 'object'},
              'enabled': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'video_sample_frames',
          name: 'Sampel Frame Video',
          category: 'Media',
          risk: ToolRisk.readOnly,
          description:
              'Ambil frame video pada FPS yang AI tentukan. Tiada had frame. '
              'fps=1 = 1 frame/saat sepanjang video.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'url': <String, dynamic>{'type': 'string'},
              'fps': <String, dynamic>{'type': 'number'},
              'frames': <String, dynamic>{
                'type': 'integer',
                'description': 'Bilangan frame jika AI mahu had sendiri. Kosong = semua pada fps itu.',
              },
            },
          },
        ),
        const ToolDefinition(
          id: 'calculator',
          name: 'Kalkulator',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Kira ungkapan matematik asas dengan tepat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'expression': <String, dynamic>{'type': 'string'}},
            'required': <String>['expression'],
          },
        ),
        const ToolDefinition(
          id: 'app_usage_guide',
          name: 'Cara Guna Aplikasi',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Baca panduan rasmi cara menggunakan chat, browser, media, Linux Workspace, fail dan sub-agent dalam aplikasi.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'runtime_info',
          name: 'Konteks Peranti dan Browser',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Dapatkan konteks sebenar peranti Android, edisi, target API, enjin browser terbina dalam dan sempadan akses PC jauh.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'current_time',
          name: 'Masa Semasa',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Dapatkan tarikh dan masa semasa pada peranti.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
      ];

  ToolDefinition? definition(String id) {
    for (final item in definitions) {
      if (item.id == id) return item;
    }
    return null;
  }

  Future<bool> requiresPermission(String toolId, Map<String, dynamic> arguments) async {
    // Semua tool lain kekal auto-benarkan. Hanya perubahan/pemadaman skill
    // oleh AI mesti menunggu keputusan pengguna setiap kali.
    return toolId == 'skill_update' || toolId == 'skill_delete';
  }

  String permissionScope(String toolId, Map<String, dynamic> arguments) {
    if (toolId == 'http_request') {
      return Uri.tryParse(arguments['url']?.toString() ?? '')?.host.toLowerCase() ?? 'web';
    }
    if (toolId.startsWith('file_')) {
      return arguments['path']?.toString() ?? arguments['destination']?.toString() ?? 'workspace';
    }
    if (toolId.startsWith('memory_')) return 'local-memory';
    if (toolId == 'skill_update' || toolId == 'skill_delete') {
      final selector = arguments['id'] ?? arguments['name'] ?? 'skill';
      return 'skill:$selector';
    }
    if (toolId.startsWith('terminal_') || toolId == 'run_exe') return 'terminal-sandbox';
    if (toolId.startsWith('mcp_')) return arguments['server_id']?.toString() ?? 'mcp-local';
    return '*';
  }

  Future<String> permissionDescription(
    String toolId,
    Map<String, dynamic> arguments,
  ) async {
    if (toolId == 'skill_update' || toolId == 'skill_delete') {
      try {
        return await skillService.mutationPreview(toolId, arguments);
      } catch (error) {
        return 'AI meminta $toolId, tetapi butiran awal tidak dapat disahkan: $error';
      }
    }
    switch (toolId) {
      case 'file_write':
        return 'Fail ${arguments['path']} sudah wujud dan akan ditimpa.';
      case 'file_copy':
      case 'file_move':
        return 'Destinasi ${arguments['destination']} sudah wujud dan akan diganti.';
      case 'file_delete':
        return 'Padam ${arguments['path']} daripada workspace tempatan.';
      case 'memory_delete':
        return 'Padam memori ${arguments['id']}.';
      case 'terminal_start':
        return 'Jalankan arahan terminal berisiko: ${arguments['command']}';
      case 'run_exe':
        return 'Jalankan fail EXE melalui Wine: ${arguments['path']}';
      case 'http_request':
        return 'Hantar operasi HTTP destruktif ${arguments['method']} ke ${arguments['url']}.';
      case 'mcp_call':
        return 'Panggil tool MCP yang dikesan berisiko: ${arguments['tool_name']}.';
      default:
        return 'Jalankan tindakan berisiko $toolId.';
    }
  }

  Future<ToolResult> execute(
    String toolId,
    Map<String, dynamic> arguments, {
    String ownerId = 'orchestrator',
  }) async {
    try {
      return await switch (toolId) {
        'web_search' => _webSearch(arguments),
        'browser_open' => _browserOpen(
            arguments['url']?.toString() ?? '',
            desktopMode: arguments['desktop_mode'] as bool? ?? true,
            newTab: arguments['new_tab'] as bool? ?? false,
          ),
        'browser_tabs' => _browserTabs(),
        'browser_switch_tab' => _browserSwitchTab(arguments),
        'browser_close_tab' => _browserCloseTab(arguments),
        'browser_session_status' => _browserSessionStatus(arguments),
        'browser_clear_session' => _browserClearSession(),
        'browser_cookie_set' => _browserCookieSet(arguments),
        'browser_cookie_delete' => _browserCookieDelete(arguments),
        'browser_inject_token' => _browserInjectToken(arguments),
        'browser_inject_session' => _browserInjectSession(arguments),
        'browser_read' => _browserRead(),
        'browser_screenshot' => _browserScreenshot(arguments),
        'workspace_show' => _workspaceShow(arguments),
        'workspace_hide' => _workspaceHide(),
        'workspace_status' => _workspaceStatus(),
        'browser_adblock' => _browserAdblock(arguments),
        'browser_audio' => _browserAudio(arguments),
        'browser_devtools' => _browserDevtools(arguments),
        'browser_media_control' => _browserMediaControl(arguments),
        'browser_wait' => _browserWait(arguments),
        'browser_native_gesture' => _browserNativeGesture(arguments),
        'browser_follow_link' => _browserFollow(arguments),
        'browser_click' => _browserAction('click', arguments),
        'browser_fill' => _browserAction('fill', arguments),
        'browser_select_option' => _browserAction('selectOption', arguments),
        'browser_press_key' => _browserAction('pressKey', arguments),
        'browser_submit_form' => _browserAction('submit', arguments),
        'browser_download' => _browserDownload(arguments),
        'media_preview' => _mediaPreview(arguments),
        'send_file' => _sendFile(arguments),
        'open_url' => _openUrl(arguments),
        'http_request' => _httpRequest(arguments),
        'file_list' => _fileList(arguments),
        'file_read' => _fileRead(arguments),
        'file_write' => _fileWrite(arguments, ownerId),
        'file_append' => _fileAppend(arguments, ownerId),
        'file_commit' => _fileCommit(arguments, ownerId),
        'file_write_status' => _fileWriteStatus(arguments, ownerId),
        'file_abort' => _fileAbort(arguments, ownerId),
        'file_replace' => _fileReplace(arguments, strict: false),
        'str_replace' => _fileReplace(arguments, strict: true),
        'file_copy' => _fileCopy(arguments),
        'file_move' => _fileMove(arguments),
        'file_delete' => _fileDelete(arguments),
        'memory_search' => _memorySearch(arguments),
        'memory_add' => _memoryAdd(arguments),
        'memory_delete' => _memoryDelete(arguments),
        'linux_workspace_status' => _linuxWorkspaceStatus(),
        'terminal_start' => terminalService.start(
            command: arguments['command']?.toString() ?? '',
            workingDirectory: (() {
              final raw = arguments['working_directory']?.toString();
              if (raw == null || raw.trim().isEmpty) return '.';
              return raw.trim();
            })(),
            environment: Map<String, String>.from(arguments['environment'] as Map? ?? const <String, String>{}),
          ),
        'terminal_poll' => terminalService.poll(arguments['job_id']?.toString() ?? ''),
        'terminal_stop' => terminalService.stop(arguments['job_id']?.toString() ?? ''),
        'terminal_stdin' => terminalService.writeStdin(
            arguments['job_id']?.toString() ?? '',
            arguments['text']?.toString() ?? '',
            newline: arguments['newline'] as bool? ?? true,
          ),
        'run_exe' => _runExe(arguments),
        'skill_create' => _skillCreate(arguments),
        'skill_update' => _skillUpdate(arguments),
        'skill_delete' => _skillDelete(arguments),
        'skill_set_enabled' => _skillSetEnabled(arguments),
        'skill_install_url' => _skillInstall(arguments),
        'archive_unzip' => _archiveUnzip(arguments),
        'archive_zip' => _archiveZip(arguments),
        'skill_run_script' => _skillRunScript(arguments),
        'mcp_list_tools' => _mcpListTools(arguments),
        'mcp_call' => _mcpCall(arguments),
        'mcp_configure' => _mcpConfigure(arguments),
        'video_sample_frames' => _videoSampleFrames(arguments),
        'calculator' => _calculator(arguments),
        'app_usage_guide' => Future<ToolResult>.value(
            ToolResult(
              success: true,
              output: UsageGuide.asPlainText(),
              data: UsageGuide.toMap(),
            ),
          ),
        'runtime_info' => _runtimeInfo(),
        'current_time' => Future<ToolResult>.value(ToolResult(success: true, output: DateTime.now().toIso8601String())),
        _ => Future<ToolResult>.value(ToolResult(success: false, output: 'Tool tidak dikenali: $toolId')),
      };
    } on FileWriteException catch (error) {
      return ToolResult(
        success: false,
        output: '${error.code}: ${error.message}',
        data: <String, dynamic>{
          'code': error.code,
          'retryable': <String>{
            'PAYLOAD_TOO_LARGE',
            'SEQUENCE_MISMATCH',
            'SIZE_MISMATCH',
            'HASH_MISMATCH',
          }.contains(error.code),
        },
      );
    } catch (error) {
      // Jangan dedahkan path host Android kepada model/pengguna.
      var message = error.toString();
      message = message.replaceAllMapped(
        RegExp(
          r'''/(?:data/(?:user/\d+/|data/)|storage|sdcard|mnt)[^\s"')\]]*''',
          caseSensitive: false,
        ),
        (_) => '[path-host-disembunyikan]',
      );
      if (message.contains('Permission denied') ||
          message.contains('PathAccess') ||
          message.contains('errno = 13')) {
        message =
            'Akses folder itu tidak dibenarkan. Gunakan path dalam /workspace sahaja '
            '(contoh: "." atau "projek/saya"). Jangan cuba path host Android.';
      }
      return ToolResult(success: false, output: message);
    }
  }

  Future<Map<String, dynamic>> runtimeContextSnapshot() async {
    // Konteks untuk model: Shell Linux (Alpine PRoot) + browser/panel pilihan.
    // Maklumat peranti sebenar (manufacturer, model, SDK, path host Android)
    // TIDAK dihantar supaya model tidak cuba akses path host.
    final linux = await linuxWorkspaceService.status();
    final userNickname = await database.getSetting('userNickname') ?? '';
    final customInstructions =
        await database.getSetting('customInstructions') ?? '';
    final mcpServers = (await database.listObjects('mcp_server'))
        .map(McpServerConfig.fromJson)
        .where((server) => server.enabled)
        .map(
          (server) => <String, dynamic>{
            'id': server.id,
            'name': server.name,
            'baseUrl': server.baseUrl,
            'transport': server.transport.name,
          },
        )
        .toList();
    return <String, dynamic>{
      'platform': 'android',
      'edition': AppConfig.editionName,
      'packageName': AppConfig.packageName,
      'fullEdition': AppConfig.isFullEdition,
      'embeddedBrowserAvailable': true,
      'embeddedBrowserEngine': 'Android System WebView/Chromium',
      'browserDefaultMode': 'desktop-emulation',
      'embeddedBrowserSessionActive': browserSession.isRunning,
      'embeddedBrowserCurrentUrl': browserSession.currentUrl,
      'embeddedBrowserDesktopMode': browserSession.desktopMode,
      'embeddedBrowserCompletedActions': browserSession.completedActions,
      'floatingWorkspaceAvailable': true,
      'floatingWorkspacePersistsUntilHidden': true,
      'browserNativeGestureAvailable': true,
      'browserAdblockDefault': false,
      'browserScreenshotPreviewDefault': false,
      'configuredMcpServers': mcpServers,
      if (userNickname.trim().isNotEmpty) 'userNickname': userNickname.trim(),
      if (customInstructions.trim().isNotEmpty)
        'customInstructions': customInstructions.trim(),
      'remotePcAccess': false,
      'androidRootAccess': false,
      'hostFilesystemAccess': false,
      'allowedWorkspaces': <String>[
        'linux_guest:/workspace',
        'linux_guest:/root',
      ],
      'linuxWorkspace': <String, dynamic>{
        'availableInEdition': AppConfig.isFullEdition,
        'ready': linux.ready,
        'healthStatus': linux.healthStatus,
        'installedRuntimeVersion': linux.runtimeVersion,
        'expectedRuntimeVersion': AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedRuntimeVersion
            : null,
        'distribution': linux.distribution.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedDistribution
            : linux.distribution,
        'distributionVersion':
            linux.distributionVersion.isEmpty && AppConfig.isFullEdition
                ? LinuxWorkspaceService.expectedDistributionVersion
                : linux.distributionVersion,
        'guestArchitecture': linux.architecture.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedArchitecture
            : linux.architecture,
        'packageManager': linux.packageManager.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedPackageManager
            : linux.packageManager,
        'automaticInstallOnFirstCommand': AppConfig.isFullEdition,
        'workspacePath': '/workspace',
        'homePath': '/root',
        'persistentWorkspace': true,
        'interactiveStdin': false,
        'maxConcurrentJobs': 8,
        'maxRetainedJobs': 64,
        'sudoRequired': false,
        'androidRootAccess': false,
        'remotePcAccess': false,
        'exeSupport': 'via Wine (apk add --no-cache wine, then wine file.exe or tool run_exe)',
      },
    };
  }

  Future<ToolResult> _runtimeInfo() async {
    final data = await runtimeContextSnapshot();
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(data),
      data: data,
    );
  }

  /// Jalankan fail .exe melalui Wine di dalam Linux Workspace.
  /// Cubaan automatik pasang wine jika belum wujud.
  Future<ToolResult> _runExe(Map<String, dynamic> arguments) async {
    final path = arguments['path']?.toString().trim() ?? '';
    if (path.isEmpty) {
      return ToolResult(success: false, output: 'Path fail .exe diperlukan.');
    }
    final args = (arguments['arguments'] as List? ?? const <dynamic>[])
        .map((item) => item.toString())
        .toList(growable: false);
    final workDir = arguments['working_directory']?.toString() ?? '.';

    // Pastikan Wine tersedia (pasang sekali jika perlu)
    final ensureWine = await terminalService.start(
      command: 'command -v wine >/dev/null 2>&1 || apk add --no-cache wine',
      workingDirectory: workDir,
      environment: const <String, String>{},
    );
    if (!ensureWine.success) {
      // teruskan juga; mungkin wine sudah ada atau apk gagal sementara
    }

    final quotedPath = path.contains(' ') ? '"$path"' : path;
    final argStr = args.map((a) => a.contains(' ') ? '"$a"' : a).join(' ');
    final command = 'wine $quotedPath${argStr.isEmpty ? '' : ' $argStr'}';

    return terminalService.start(
      command: command,
      workingDirectory: workDir,
      environment: const <String, String>{},
    );
  }

  Future<ToolResult> _linuxWorkspaceStatus() async {
    final status = await linuxWorkspaceService.status();
    final data = <String, dynamic>{
      'edition': AppConfig.editionName,
      'package': AppConfig.packageName,
      'runtime_ready': status.runtimeReady,
      'rootfs_ready': status.rootfsReady,
      'manifest_valid': status.manifestValid,
      'ready': status.ready,
      'health_status': status.healthStatus,
      'runtime_version': status.runtimeVersion,
      'distribution': status.distribution,
      'distribution_version': status.distributionVersion,
      'guest_architecture': status.architecture,
      'package_manager': status.packageManager,
      'shell': '/bin/sh',
      'workspace_path': '/workspace',
      'home_path': '/root',
      'persistent_workspace': true,
      'interactive_stdin': false,
      'sudo_required': false,
      'automatic_install': AppConfig.isFullEdition,
      'bundled_asset': AppConfig.isFullEdition
          ? LinuxWorkspaceService.bundledRuntimeAsset
          : null,
      'used_bytes': status.usedBytes,
      'package_install_enabled': status.packageInstallEnabled,
      'storage': 'private_app_storage',
      'external_storage_bound': false,
      'android_root_access': false,
      'remote_pc_access': false,
    };
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(data),
      data: data,
    );
  }

  Future<ToolResult> _webSearch(Map<String, dynamic> arguments) async {
    final query = arguments['query']?.toString() ?? '';
    try {
      final response = await _searchService.search(
        query: query,
        maxResults: (arguments['max_results'] as num?)?.toInt() ?? 10,
        region: arguments['region']?.toString() ?? 'wt-wt',
        timeRange: arguments['time_range']?.toString() ?? '',
      );
      final raw = response.toJson();
      return ToolResult(
        success: true,
        output: response.prettyJson(),
        // Hasil carian ialah konteks kerja AI sahaja. Jawapan akhir AI yang
        // merumuskan sumber akan dipaparkan, bukan kad hasil mentah.
        data: raw,
      );
    } catch (error) {
      if (query.trim().isEmpty) {
        return ToolResult(success: false, output: 'Carian gagal: $error');
      }
      // Fallback deterministik: gunakan Browser WebView sedia ada.
      final fallbackUri = Uri.https(
        'duckduckgo.com',
        '/',
        <String, String>{'q': query.trim()},
      );
      final fallback = await _browserOpen(
        fallbackUri.toString(),
        desktopMode: true,
      );
      if (fallback.success) {
        final fallbackData = Map<String, dynamic>.from(fallback.data)
          ..remove('artifact')
          ..remove('artifacts');
        return ToolResult(
          success: true,
          output:
              'Carian terus DuckDuckGo gagal, jadi hasil dibuka melalui '
              'Browser WebView.\n${fallback.output}',
          data: <String, dynamic>{
            ...fallbackData,
            'fallback_browser': true,
            'fallback_reason': error.toString(),
            'query': query.trim(),
          },
        );
      }
      return ToolResult(
        success: false,
        output:
            'Carian gagal untuk "$query": $error. '
            'Fallback Browser WebView juga gagal: ${fallback.output}',
        data: <String, dynamic>{
          'fallback_browser': true,
          'query': query.trim(),
        },
      );
    }
  }

  Future<ToolResult> _browserOpen(
    String rawUrl, {
    bool desktopMode = true,
    bool newTab = false,
  }) async {
    final Uri uri;
    try {
      uri = _validatedHttpUri(rawUrl);
    } on FormatException catch (error) {
      return ToolResult(
        success: false,
        output:
            '${error.message}\n'
            'Jangan henti tugasan. Pautan javascript:/kosong bukan URL. '
            'Guna browser_click pada elemen, atau browser_open dengan https://… sebenar.',
      );
    }
    if (backgroundMode) {
      return _browserOpenHttp(uri, desktopMode: desktopMode);
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'open',
        arguments: <String, dynamic>{
          'url': uri.toString(),
          'desktopMode': desktopMode,
          'newTab': newTab,
        },
      ),
    );
    return _storeBrowserPage(result);
  }

  Future<ToolResult> _browserTabs() async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Senarai tab hanya untuk browser WebView (bukan background HTTP).',
      );
    }
    final result = await browserSession.execute(
      const BrowserAction(type: 'tabs', arguments: <String, dynamic>{}),
    );
    return ToolResult(
      success: result['success'] == true,
      output: const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  Future<ToolResult> _browserSwitchTab(Map<String, dynamic> arguments) async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Tukar tab tidak tersedia dalam background HTTP.',
      );
    }
    final tabId = (arguments['tab_id'] as num?)?.toInt();
    if (tabId == null) {
      return const ToolResult(success: false, output: 'tab_id diperlukan. Panggil browser_tabs dulu.');
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'switchTab',
        arguments: <String, dynamic>{'tabId': tabId},
      ),
    );
    final ok = result['success'] == true;
    final recovered = result['recovered'] == true;
    final msg = result['message']?.toString() ??
        (ok ? 'Tab $tabId aktif.' : 'Gagal tukar tab $tabId.');
    return ToolResult(
      success: ok,
      output: recovered
          ? '$msg\n${const JsonEncoder.withIndent('  ').convert(result)}'
          : const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  Future<ToolResult> _browserCloseTab(Map<String, dynamic> arguments) async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Tutup tab tidak tersedia dalam background HTTP.',
      );
    }
    final tabId = (arguments['tab_id'] as num?)?.toInt();
    final result = await browserSession.execute(
      BrowserAction(
        type: 'closeTab',
        arguments: <String, dynamic>{
          if (tabId != null) 'tabId': tabId,
        },
      ),
    );
    return ToolResult(
      success: result['success'] == true,
      output: const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  ToolResult _browserSessionResult(Map<String, dynamic> result) {
    return ToolResult(
      success: result['success'] == true,
      output: const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  ToolResult _browserSessionUnavailable() {
    return const ToolResult(
      success: false,
      output:
          'Pengurusan sesi memerlukan WebView aplikasi aktif dan tidak tersedia dalam background HTTP.',
    );
  }

  Future<ToolResult> _browserSessionStatus(
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) return _browserSessionUnavailable();
    final result = await browserSession.execute(
      BrowserAction(
        type: 'sessionStatus',
        arguments: <String, dynamic>{
          if ((arguments['url']?.toString().trim() ?? '').isNotEmpty)
            'url': arguments['url'].toString().trim(),
        },
      ),
    );
    return _browserSessionResult(result);
  }

  Future<ToolResult> _browserClearSession() async {
    if (backgroundMode) return _browserSessionUnavailable();
    final result = await browserSession.execute(
      const BrowserAction(type: 'clearSession', arguments: <String, dynamic>{}),
    );
    if (result['success'] == true) {
      _pages.clear();
    }
    return _browserSessionResult(result);
  }

  Future<ToolResult> _browserCookieSet(
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) return _browserSessionUnavailable();
    final name = arguments['name']?.toString() ?? '';
    if (name.isEmpty || !arguments.containsKey('value')) {
      return const ToolResult(
        success: false,
        output: 'name dan value cookie diperlukan.',
      );
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'setCookie',
        arguments: <String, dynamic>{
          if ((arguments['url']?.toString().trim() ?? '').isNotEmpty)
            'url': arguments['url'].toString().trim(),
          'name': name,
          'value': arguments['value']?.toString() ?? '',
          'path': arguments['path']?.toString() ?? '/',
          'secure': arguments['secure'] as bool? ?? true,
          'httpOnly': arguments['http_only'] as bool? ?? true,
          'sameSite': arguments['same_site']?.toString() ?? 'Lax',
        },
      ),
    );
    return _browserSessionResult(result);
  }

  Future<ToolResult> _browserCookieDelete(
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) return _browserSessionUnavailable();
    final name = arguments['name']?.toString() ?? '';
    if (name.isEmpty) {
      return const ToolResult(success: false, output: 'name cookie diperlukan.');
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'deleteCookie',
        arguments: <String, dynamic>{
          if ((arguments['url']?.toString().trim() ?? '').isNotEmpty)
            'url': arguments['url'].toString().trim(),
          'name': name,
          'path': arguments['path']?.toString() ?? '/',
        },
      ),
    );
    return _browserSessionResult(result);
  }

  Future<ToolResult> _browserInjectToken(
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) return _browserSessionUnavailable();
    final target = arguments['target']?.toString() ?? '';
    final key = arguments['key']?.toString() ?? '';
    if (!<String>{'cookie', 'local_storage', 'session_storage'}.contains(target) ||
        key.isEmpty ||
        !arguments.containsKey('token')) {
      return const ToolResult(
        success: false,
        output: 'target, key dan token diperlukan.',
      );
    }
    final token = arguments['token']?.toString() ?? '';
    final nativeArguments = <String, dynamic>{
      if ((arguments['url']?.toString().trim() ?? '').isNotEmpty)
        'url': arguments['url'].toString().trim(),
      'cookies': <Map<String, dynamic>>[
        if (target == 'cookie')
          <String, dynamic>{
            'name': key,
            'value': token,
            'path': arguments['path']?.toString() ?? '/',
            'secure': arguments['secure'] as bool? ?? true,
            'httpOnly': arguments['http_only'] as bool? ?? true,
            'sameSite': arguments['same_site']?.toString() ?? 'Lax',
          },
      ],
      'localStorage': <String, dynamic>{
        if (target == 'local_storage') key: token,
      },
      'sessionStorage': <String, dynamic>{
        if (target == 'session_storage') key: token,
      },
    };
    final result = await browserSession.execute(
      BrowserAction(type: 'injectSession', arguments: nativeArguments),
    );
    return _browserSessionResult(result);
  }

  Future<ToolResult> _browserInjectSession(
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) return _browserSessionUnavailable();
    final cookiesRaw = arguments['cookies'];
    final cookies = <Map<String, dynamic>>[];
    if (cookiesRaw is List) {
      for (final item in cookiesRaw) {
        if (item is Map) {
          cookies.add(Map<String, dynamic>.from(item));
        }
      }
    }
    Map<String, dynamic> storageMap(Object? raw) =>
        raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{};

    final localStorage = storageMap(arguments['local_storage']);
    final sessionStorage = storageMap(arguments['session_storage']);
    if (cookies.isEmpty && localStorage.isEmpty && sessionStorage.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'Berikan sekurang-kurangnya cookies, local_storage atau session_storage.',
      );
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'injectSession',
        arguments: <String, dynamic>{
          if ((arguments['url']?.toString().trim() ?? '').isNotEmpty)
            'url': arguments['url'].toString().trim(),
          'cookies': cookies,
          'localStorage': localStorage,
          'sessionStorage': sessionStorage,
        },
      ),
    );
    return _browserSessionResult(result);
  }

  Future<ToolResult> _browserRead() async {
    if (backgroundMode) {
      if (_pages.isEmpty) {
        return const ToolResult(
          success: false,
          output: 'Tiada halaman aktif dalam automasi background. Gunakan browser_open dengan URL.',
        );
      }
      final page = _pages.values.last;
      return _pageResult(page, mode: 'background-cache');
    }
    final result = await browserSession.execute(
      BrowserAction(type: 'read', arguments: const <String, dynamic>{}),
    );
    return _storeBrowserPage(result);
  }

  Future<ToolResult> _browserScreenshot(
    Map<String, dynamic> _,
  ) async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Screenshot WebView memerlukan proses aplikasi aktif.',
      );
    }
    final result = await browserSession.execute(
      const BrowserAction(
        type: 'screenshot',
        arguments: <String, dynamic>{},
      ),
    );
    final path = result['path']?.toString() ?? '';
    if (path.isEmpty) {
      return ToolResult(
        success: false,
        output: result['error']?.toString() ?? 'Screenshot browser gagal.',
        data: result,
      );
    }
    return ToolResult(
      success: true,
      output: 'Screenshot tersedia untuk analisis AI sahaja dan tidak dipaparkan dalam chat.',
      data: <String, dynamic>{...result},
    );
  }

  Future<ToolResult> _workspaceShow(Map<String, dynamic> arguments) async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Panel Workspace memerlukan aplikasi berada di hadapan.',
      );
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'workspaceShow',
        arguments: <String, dynamic>{
          if (arguments['fullscreen'] is bool)
            'fullscreen': arguments['fullscreen'],
        },
      ),
    );
    return _workspaceToolResult(
      result,
      successText: 'Browser AI dipaparkan dalam panel terapung.',
    );
  }

  Future<ToolResult> _workspaceHide() async {
    final result = await browserSession.execute(
      const BrowserAction(
        type: 'workspaceHide',
        arguments: <String, dynamic>{},
      ),
    );
    return _workspaceToolResult(
      result,
      successText: 'Panel Workspace telah disembunyikan.',
    );
  }

  Future<ToolResult> _workspaceStatus() async {
    final result = await browserSession.execute(
      const BrowserAction(
        type: 'workspaceStatus',
        arguments: <String, dynamic>{},
      ),
    );
    return _workspaceToolResult(
      result,
      successText: jsonEncode(result),
    );
  }

  Future<ToolResult> _browserAdblock(
    Map<String, dynamic> arguments,
  ) async {
    final enabled = arguments['enabled'] as bool? ?? false;
    final result = await browserSession.execute(
      BrowserAction(
        type: 'setAdblock',
        arguments: <String, dynamic>{'enabled': enabled},
      ),
    );
    return _workspaceToolResult(
      result,
      successText: enabled
          ? 'Adblock hidup untuk chat ini sahaja.'
          : 'Adblock dimatikan untuk chat ini.',
    );
  }

  Future<ToolResult> _browserAudio(
    Map<String, dynamic> arguments,
  ) async {
    final enabled = arguments['enabled'] as bool? ?? true;
    final result = await browserSession.execute(
      BrowserAction(
        type: 'setBrowserAudio',
        arguments: <String, dynamic>{'enabled': enabled},
      ),
    );
    return _workspaceToolResult(
      result,
      successText: enabled
          ? 'Audio Browser hidup untuk tab aktif chat ini.'
          : 'Audio Browser dimatikan untuk chat ini.',
    );
  }

  Future<ToolResult> _browserDevtools(
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) return _browserSessionUnavailable();
    final action = arguments['action']?.toString().toLowerCase() ?? 'inspect';
    final result = await browserSession.execute(
      BrowserAction(
        type: 'devtools',
        arguments: <String, dynamic>{
          'action': action,
          if ((arguments['script']?.toString() ?? '').isNotEmpty)
            'script': arguments['script'].toString(),
          'limit': arguments['limit'] ?? 50,
        },
      ),
    );
    return _workspaceToolResult(
      result,
      successText: action == 'evaluate'
          ? 'JavaScript DevTools selesai dijalankan pada tab aktif.'
          : action == 'clear'
              ? 'Log DevTools tab aktif telah dikosongkan.'
              : 'Log rangkaian dan console tab aktif tersedia untuk analisis AI.',
    );
  }

  Future<ToolResult> _browserMediaControl(
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) return _browserSessionUnavailable();
    final action = arguments['action']?.toString().toLowerCase() ?? 'status';
    final result = await browserSession.execute(
      BrowserAction(
        type: 'mediaControl',
        arguments: <String, dynamic>{
          'action': action,
          if ((arguments['selector']?.toString() ?? '').isNotEmpty)
            'selector': arguments['selector'].toString(),
        },
      ),
    );
    return _workspaceToolResult(
      result,
      successText: action == 'status'
          ? 'Status media Browser diperiksa.'
          : 'Tindakan media $action selesai dan status semasa dipulangkan.',
    );
  }

  Future<ToolResult> _browserWait(
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) return _browserSessionUnavailable();
    final condition =
        arguments['condition']?.toString().toLowerCase() ?? 'page_ready';
    final result = await browserSession.execute(
      BrowserAction(
        type: 'waitFor',
        arguments: <String, dynamic>{
          'condition': condition,
          if ((arguments['selector']?.toString() ?? '').isNotEmpty)
            'selector': arguments['selector'].toString(),
          if ((arguments['text']?.toString() ?? '').isNotEmpty)
            'text': arguments['text'].toString(),
          if ((arguments['url_contains']?.toString() ?? '').isNotEmpty)
            'urlContains': arguments['url_contains'].toString(),
          'timeoutMs': arguments['timeout_ms'] ?? 15000,
        },
      ),
    );
    return _workspaceToolResult(
      result,
      successText: 'Keadaan Browser "$condition" sudah dipenuhi.',
    );
  }

  Future<ToolResult> _browserNativeGesture(
    Map<String, dynamic> arguments,
  ) async {
    final action = arguments['action']?.toString().toLowerCase() ?? 'click';
    final nativeArguments = <String, dynamic>{
      'action': action,
      if (arguments['index'] != null) 'index': arguments['index'],
      if ((arguments['selector']?.toString() ?? '').isNotEmpty)
        'selector': arguments['selector'],
      if ((arguments['text']?.toString() ?? '').isNotEmpty)
        'text': arguments['text'],
      if (arguments['x'] != null) 'x': arguments['x'],
      if (arguments['y'] != null) 'y': arguments['y'],
      if (arguments['to_x'] != null) 'toX': arguments['to_x'],
      if (arguments['to_y'] != null) 'toY': arguments['to_y'],
      if (arguments['delta_y'] != null) 'deltaY': arguments['delta_y'],
      if (arguments['duration_ms'] != null)
        'durationMs': arguments['duration_ms'],
    };
    final result = await browserSession.execute(
      BrowserAction(type: 'nativeGesture', arguments: nativeArguments),
    );
    return _workspaceToolResult(
      result,
      successText: 'Gesture native $action dihantar kepada Browser.',
    );
  }

  ToolResult _workspaceToolResult(
    Map<String, dynamic> result, {
    required String successText,
  }) {
    final success = result['success'] != false;
    return ToolResult(
      success: success,
      output: success
          ? successText
          : result['message']?.toString() ??
              result['error']?.toString() ??
              'Tindakan Workspace gagal.',
      data: result,
    );
  }

  Future<ToolResult> _browserAction(
    String type,
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) {
      return ToolResult(
        success: false,
        output: 'Interaksi DOM memerlukan proses aplikasi aktif. Browser masih tidak dipaparkan kepada pengguna.',
      );
    }
    final result = await browserSession.execute(
      BrowserAction(type: type, arguments: arguments),
    );
    if (result['url'] != null || result['html'] != null) {
      return _storeBrowserPage(result);
    }
    final success = result['success'] != false;
    // Self-heal: bila gagal, baca semula page. Tiada max retry hardcoded —
    // agent loop (while !cancelled) juga tiada had step; AI boleh terus cuba.
    if (!success && result['self_heal_hint'] == true) {
      try {
        final fresh = await browserSession.execute(
          const BrowserAction(type: 'read', arguments: <String, dynamic>{}),
        );
        final pageResult = _storeBrowserPage(fresh);
        return ToolResult(
          success: false,
          output:
              '${result['error'] ?? 'Tindakan browser gagal'}. '
              'Page dibaca semula — guna index baharu dari interactive_elements.\n'
              '${pageResult.output}',
          data: <String, dynamic>{
            ...result,
            'healed_page': pageResult.data,
          },
        );
      } catch (_) {
        // pulangkan ralat asal
      }
    }
    return ToolResult(
      success: success,
      output: const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  ToolResult _storeBrowserPage(Map<String, dynamic> result) {
    final url = result['url']?.toString() ?? browserSession.currentUrl;
    final links = (result['links'] as List? ?? const <dynamic>[])
        .whereType<Map>()
        .map(
          (item) => <String, String>{
            'text': item['text']?.toString() ?? '',
            'url': item['url']?.toString() ?? '',
          },
        )
        .where((item) => item['url']!.isNotEmpty)
        .toList();
    final interactive = (result['interactive_elements'] as List? ?? const <dynamic>[])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
    final html = _sanitizeHtmlPreview(result['html']?.toString() ?? '', url);
    final page = _BrowserPage(
      id: _uuid.v4(),
      url: url,
      title: result['title']?.toString() ?? '',
      text: _clip(result['text']?.toString() ?? ''),
      html: html,
      links: links,
    );
    _pages[page.id] = page;
    return _pageResult(
      page,
      mode: result['mode']?.toString() ??
          result['engine']?.toString() ??
          'headless-webview',
      extra: <String, dynamic>{
        if (result['forms'] is List) 'forms': result['forms'],
        'interactive_elements': interactive,
      },
    );
  }

  ToolResult _pageResult(
    _BrowserPage page, {
    required String mode,
    Map<String, dynamic> extra = const <String, dynamic>{},
  }) {
    final interactive = (extra['interactive_elements'] as List? ?? const <dynamic>[]);
    final elementSummary = interactive.isEmpty
        ? ''
        : '\n\nElemen interaktif (guna index untuk click/fill; bbox = x,y,w,h):\n${interactive.take(40).map((e) {
            final m = e is Map ? e : <String, dynamic>{};
            final idx = m['index'] ?? '?';
            final tag = m['tag'] ?? '';
            final type = m['type'] ?? '';
            final text = (m['text'] ?? m['placeholder'] ?? '').toString();
            final href = (m['href'] ?? '').toString();
            final short = text.length > 60 ? '${text.substring(0, 60)}…' : text;
            final extraHref = href.isNotEmpty ? ' → $href' : '';
            final bbox = m['bbox'];
            var bboxStr = '';
            if (bbox is Map) {
              bboxStr =
                  ' @(${bbox['x']},${bbox['y']} ${bbox['width']}x${bbox['height']})';
            }
            return '[$idx] <$tag/$type> $short$extraHref$bboxStr';
          }).join('\n')}';
    final data = <String, dynamic>{
      'page_id': page.id,
      'url': page.url,
      'title': page.title,
      'text': page.text,
      'links': page.links,
      'mode': mode,
      ...extra,
    };
    final titleLine = page.title.isEmpty
        ? 'Halaman browser berjaya dibaca: ${page.url}'
        : 'Halaman browser berjaya dibaca: ${page.title} · ${page.url}';
    return ToolResult(
      success: true,
      output: '$titleLine$elementSummary',
      data: data,
    );
  }

  Future<ToolResult> _browserFollow(Map<String, dynamic> arguments) async {
    final page = _pages[arguments['page_id']?.toString()];
    if (page == null) {
      return const ToolResult(
        success: false,
        output: 'Page ID tidak ditemui atau sesi browser telah tamat.',
      );
    }
    final index = (arguments['link_index'] as num?)?.toInt() ?? -1;
    if (index < 0 || index >= page.links.length) {
      return ToolResult(
        success: false,
        output: 'Indeks pautan tidak sah. Julat 0-${page.links.length - 1}.',
      );
    }
    return _browserOpen(
      page.links[index]['url']!,
      desktopMode: browserSession.desktopMode,
    );
  }

  Future<ToolResult> _browserOpenHttp(
    Uri uri, {
    bool desktopMode = true,
  }) async {
    final response = await _client
        .get(uri, headers: _browserHeaders(desktop: desktopMode))
        .timeout(AppConfig.browserTimeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      return ToolResult(
        success: false,
        output: 'HTTP ${response.statusCode}',
      );
    }
    final contentType = response.headers['content-type'] ?? '';
    if (!contentType.contains('html')) {
      final body = _clip(response.body);
      return ToolResult(
        success: true,
        output: body,
        data: <String, dynamic>{
          'url': uri.toString(),
          'contentType': contentType,
        },
      );
    }
    final document = html_parser.parse(response.body);
    for (final node in document.querySelectorAll(
      'script,style,noscript,svg,object,embed,template',
    )) {
      node.remove();
    }
    final title = document.querySelector('title')?.text.trim() ?? uri.host;
    final text = document.body?.text.replaceAll(RegExp(r'\s+'), ' ').trim() ?? '';
    final links = <Map<String, String>>[];
    for (final anchor in document.querySelectorAll('a[href]')) {
      final href = anchor.attributes['href'];
      if (href == null || href.startsWith('#') || href.startsWith('javascript:')) {
        continue;
      }
      final resolved = uri.resolve(href);
      if (!<String>{'http', 'https'}.contains(resolved.scheme)) continue;
      final label = anchor.text.replaceAll(RegExp(r'\s+'), ' ').trim();
      links.add(<String, String>{
        'text': label.isEmpty ? resolved.toString() : label,
        'url': resolved.toString(),
      });
      if (links.length >= 160) break;
    }
    final page = _BrowserPage(
      id: _uuid.v4(),
      url: uri.toString(),
      title: title,
      text: _clip(text),
      html: _sanitizeHtmlPreview(document.outerHtml, uri.toString()),
      links: links,
    );
    _pages[page.id] = page;
    return _pageResult(
      page,
      mode: desktopMode ? 'background-http-desktop' : 'background-http-mobile',
      extra: <String, dynamic>{'desktopMode': desktopMode},
    );
  }

  Future<ToolResult> _browserDownload(
    Map<String, dynamic> arguments,
  ) async {
    final uri = _validatedHttpUri(arguments['url']?.toString() ?? '');
    final request = http.Request('GET', uri);
    request.headers.addAll(
      _browserHeaders(desktop: browserSession.desktopMode),
    );
    final streamed = await _client.send(request).timeout(AppConfig.browserTimeout);
    if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
      return ToolResult(
        success: false,
        output: 'HTTP ${streamed.statusCode}',
      );
    }
    final declared = streamed.contentLength;
    if (declared != null && declared > AppConfig.maxDownloadBytes) {
      return const ToolResult(
        success: false,
        output: 'Fail melebihi had muat turun 250 MB.',
      );
    }
    final filename = _safeFilename(
      arguments['filename']?.toString().trim().isNotEmpty == true
          ? arguments['filename'].toString()
          : p.basename(uri.path).isEmpty
              ? 'download.bin'
              : p.basename(uri.path),
    );
    final root = await _workspace();
    final file = File(p.join(root.path, filename));
    await file.parent.create(recursive: true);
    final sink = file.openWrite();
    var received = 0;
    try {
      await for (final chunk in streamed.stream) {
        received += chunk.length;
        if (received > AppConfig.maxDownloadBytes) {
          throw const FileSystemException(
            'Fail melebihi had muat turun 250 MB.',
          );
        }
        sink.add(chunk);
      }
      await sink.flush();
    } catch (_) {
      await sink.close();
      if (await file.exists()) await file.delete();
      rethrow;
    }
    await sink.close();
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: filename,
      subtitle: '$received bait',
      localPath: file.path,
      mimeType: streamed.headers['content-type'] ?? _mimeForPath(file.path),
      url: uri.toString(),
    );
    return ToolResult(
      success: true,
      output: 'Fail disimpan: ${p.relative(file.path, from: root.path)}',
      data: <String, dynamic>{
        'path': file.path,
        'bytes': received,
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _mediaPreview(Map<String, dynamic> arguments) async {
    final rawUrl = arguments['url']?.toString().trim() ?? '';
    final rawPath = arguments['path']?.toString().trim() ?? '';
    final rawLocation = rawUrl.isNotEmpty ? rawUrl : rawPath;
    final requestedKind = arguments['kind']?.toString().trim().toLowerCase() ?? '';
    var mimeType = arguments['mime_type']?.toString().trim() ?? '';
    final requestedTitle = arguments['title']?.toString().trim() ?? '';
    ArtifactKind? kind = switch (requestedKind) {
      'image' => ArtifactKind.image,
      'video' => ArtifactKind.video,
      'audio' => ArtifactKind.audio,
      'html' || 'webpage' => ArtifactKind.html,
      'file' || 'zip' || 'json' || 'pdf' || 'document' || 'text' =>
        ArtifactKind.file,
      _ => null,
    };

    if (rawLocation.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'Berikan url (http/https) atau path fail workspace/lampiran.',
      );
    }

    final parsedLocation = Uri.tryParse(rawLocation);
    final isHttpLocation = parsedLocation != null &&
        <String>{'http', 'https'}.contains(parsedLocation.scheme) &&
        parsedLocation.host.isNotEmpty;

    // --- Local / workspace / attachments ---
    if (!isHttpLocation) {
      final local = await _resolveLocalMediaFile(rawLocation);
      if (local == null) {
        return ToolResult(
          success: false,
          output:
              'Path media tidak ditemui dalam workspace/lampiran: $rawLocation. '
              'Guna path relatif (cth. foto.jpg, output/a.mp4) atau URL http(s).',
        );
      }

      if (kind == null && mimeType.isNotEmpty) {
        if (mimeType.startsWith('image/')) kind = ArtifactKind.image;
        if (mimeType.startsWith('video/')) kind = ArtifactKind.video;
        if (mimeType.startsWith('audio/')) kind = ArtifactKind.audio;
        if (mimeType.contains('html')) kind = ArtifactKind.html;
        if (kind == null) kind = ArtifactKind.file;
      }
      final inferred = _artifactKindForPath(local.path);
      kind ??= inferred;
      if (mimeType.isEmpty || mimeType == 'application/octet-stream') {
        mimeType = _mimeForPath(local.path);
      }

      final rel = local.relative;
      final title = requestedTitle.isNotEmpty
          ? requestedTitle
          : p.basename(local.path);
      final artifact = ChatArtifact(
        id: _uuid.v4(),
        kind: kind,
        title: title,
        subtitle: 'Dari workspace · $rel',
        localPath: local.path,
        mimeType: mimeType,
        data: <String, dynamic>{
          'previewOnly': false,
          'fromWorkspace': true,
          'relativePath': rel,
        },
      );
      return ToolResult(
        success: true,
        output:
            'Fail workspace dihantar ke chat: $rel (${kind.name}). '
            'Pengguna boleh pratonton/muat turun terus — jangan suruh buka File Manager.',
        data: <String, dynamic>{
          'path': rel,
          'localPath': local.path,
          'kind': kind.name,
          'mimeType': mimeType,
          'artifact': artifact.toJson(),
        },
      );
    }

    // --- HTTP / HTTPS ---
    final uri = parsedLocation!;
    if (kind == null && mimeType.isNotEmpty) {
      if (mimeType.startsWith('image/')) kind = ArtifactKind.image;
      if (mimeType.startsWith('video/')) kind = ArtifactKind.video;
      if (mimeType.startsWith('audio/')) kind = ArtifactKind.audio;
    }
    if (kind == null) {
      final inferred = _artifactKindForPath(uri.path);
      if (<ArtifactKind>{
        ArtifactKind.image,
        ArtifactKind.video,
        ArtifactKind.audio,
      }.contains(inferred)) {
        kind = inferred;
      }
    }
    if (kind == null) {
      return const ToolResult(
        success: false,
        output:
            'Jenis media tidak dapat dikenal pasti. Berikan kind image, video atau audio bersama URL media langsung.',
      );
    }

    if (mimeType.isEmpty || mimeType == 'application/octet-stream') {
      mimeType = _mimeForPath(uri.path);
      if (mimeType == 'application/octet-stream') {
        mimeType = switch (kind) {
          ArtifactKind.image => 'image/jpeg',
          ArtifactKind.video => 'video/mp4',
          ArtifactKind.audio => 'audio/mpeg',
          _ => 'application/octet-stream',
        };
      }
    }
    final basename = p.basename(uri.path).trim();
    final title = requestedTitle.isNotEmpty
        ? requestedTitle
        : basename.isNotEmpty
            ? basename
            : 'Media daripada ${uri.host}';
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: kind,
      title: title,
      subtitle: 'Pratonton URL · belum disimpan ke peranti',
      url: uri.toString(),
      mimeType: mimeType,
      data: const <String, dynamic>{'previewOnly': true},
    );
    return ToolResult(
      success: true,
      output:
          'Pratonton ${kind.name} telah dihantar tanpa memuat turun fail ke storan.',
      data: <String, dynamic>{
        'url': uri.toString(),
        'kind': kind.name,
        'mimeType': mimeType,
        'previewOnly': true,
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _sendFile(Map<String, dynamic> arguments) async {
    final path = arguments['path']?.toString().trim() ?? '';
    if (path.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'send_file memerlukan path fail siap.',
      );
    }
    _rejectStagingPath(path);
    final local = await _resolveLocalMediaFile(path);
    if (local == null) {
      return ToolResult(success: false, output: 'Fail tidak ditemui: $path');
    }
    final file = File(local.path);
    if (await file.length() == 0) {
      return ToolResult(success: false, output: 'Fail kosong ditolak: $path');
    }
    final writer = await _fileWriter();
    if (await writer.isTargetBusy(file.path)) {
      return ToolResult(
        success: false,
        output:
            'Fail masih mempunyai transaksi aktif dan belum boleh dihantar: $path',
      );
    }
    return _mediaPreview(<String, dynamic>{
      'path': path,
      if (arguments['title'] != null) 'title': arguments['title'],
    });
  }

  /// Resolve path relative workspace, /workspace/..., /attachments/..., or absolute internal.
  Future<({String path, String relative})?> _resolveLocalMediaFile(
    String raw,
  ) async {
    var value = raw.trim();
    if (value.isEmpty) return null;

    // file:// URI
    final uri = Uri.tryParse(value);
    if (uri != null && uri.scheme == 'file') {
      try {
        value = uri.toFilePath();
      } catch (_) {}
    }

    final root = await _workspace();
    final attachmentsRoot = Directory(
      p.join((await getApplicationSupportDirectory()).path, 'attachments'),
    );

    // Guest-style prefixes
    if (value == '/workspace' || value == '/workspace/') {
      return null;
    }
    if (value.startsWith('/workspace/')) {
      value = value.substring('/workspace/'.length);
    }
    if (value.startsWith('workspace/')) {
      value = value.substring('workspace/'.length);
    }
    if (value.startsWith('/attachments/')) {
      value = value.substring('/attachments/'.length);
      final file = File(p.normalize(p.join(attachmentsRoot.path, value)));
      if (await file.exists()) {
        return (path: file.path, relative: 'attachments/$value');
      }
      return null;
    }
    if (value.startsWith('attachments/')) {
      final name = value.substring('attachments/'.length);
      final file = File(p.normalize(p.join(attachmentsRoot.path, name)));
      if (await file.exists()) {
        return (path: file.path, relative: value);
      }
    }

    // Absolute path inside app storage
    if (p.isAbsolute(value)) {
      final file = File(p.normalize(value));
      if (!await file.exists()) return null;
      final resolved = await file.resolveSymbolicLinks();
      final allowedRoots = <String>[
        p.normalize(root.path),
        p.normalize((await getApplicationSupportDirectory()).path),
        p.normalize((await getApplicationDocumentsDirectory()).path),
        p.normalize((await getTemporaryDirectory()).path),
      ];
      final ok = allowedRoots.any(
        (r) => resolved == r || p.isWithin(r, resolved),
      );
      if (!ok) return null;
      final rel = p.isWithin(root.path, resolved)
          ? p.relative(resolved, from: root.path)
          : p.basename(resolved);
      return (path: resolved, relative: rel);
    }

    // Relative workspace path
    try {
      final file = _safeWorkspaceFile(root, value);
      if (await file.exists()) {
        return (
          path: file.path,
          relative: p.relative(file.path, from: root.path),
        );
      }
    } catch (_) {
      return null;
    }

    final base = p.basename(value);
    final attach = File(p.join(attachmentsRoot.path, base));
    if (await attach.exists()) {
      return (path: attach.path, relative: 'attachments/$base');
    }

    // Lampiran chat sebenar: Documents/chat_attachments/<session>/*
    try {
      final docs = await getApplicationDocumentsDirectory();
      final chatRoot = Directory(p.join(docs.path, 'chat_attachments'));
      if (await chatRoot.exists()) {
        await for (final entity in chatRoot.list(recursive: true, followLinks: false)) {
          if (entity is! File) continue;
          final name = p.basename(entity.path);
          if (name == base || name.endsWith('_$base') || name.contains(base)) {
            return (path: entity.path, relative: 'attachments/$base');
          }
        }
      }
    } catch (_) {}
    return null;
  }

  Future<ToolResult> _openUrl(Map<String, dynamic> arguments) async {
    return _browserOpen(
      arguments['url']?.toString() ?? '',
      desktopMode: arguments['desktop_mode'] as bool? ?? true,
    );
  }

  Future<ToolResult> _httpRequest(Map<String, dynamic> arguments) async {
    final method = arguments['method']?.toString().toUpperCase() ?? 'GET';
    final uri = _validatedHttpUri(arguments['url']?.toString() ?? '');
    final headers = Map<String, String>.from(arguments['headers'] as Map? ?? const <String, String>{});
    final bodyValue = arguments['body'];
    final body = bodyValue is String ? bodyValue : bodyValue == null ? null : jsonEncode(bodyValue);
    final request = http.Request(method, uri)..headers.addAll(headers);
    if (body != null) request.body = body;
    final streamed = await _client.send(request).timeout(AppConfig.defaultTimeout);
    final response = await http.Response.fromStream(streamed);
    final output = _clip(response.body);
    return ToolResult(
      success: response.statusCode >= 200 && response.statusCode < 400,
      output: output,
      data: <String, dynamic>{'statusCode': response.statusCode, 'headers': response.headers, 'body': output},
    );
  }

  Future<ToolResult> _fileList(Map<String, dynamic> arguments) async {
    final requested = arguments['path']?.toString() ?? '.';
    if (_isAttachmentsAlias(requested)) {
      return _listSessionAttachments();
    }
    final root = await _workspace();
    final directory = _safeWorkspaceDirectory(root, requested);
    if (!await directory.exists()) {
      return const ToolResult(success: false, output: 'Folder tidak ditemui.');
    }
    final values = <Map<String, dynamic>>[];
    try {
      await for (final entity in directory.list(followLinks: false)) {
        final stat = await entity.stat();
        values.add(<String, dynamic>{
          'name': p.basename(entity.path),
          'path': p.relative(entity.path, from: root.path),
          'type': entity is Directory ? 'directory' : 'file',
          'bytes': stat.size,
          'modified': stat.modified.toIso8601String(),
        });
      }
    } on PathAccessException {
      return const ToolResult(
        success: false,
        output:
            'Folder itu tidak boleh disenaraikan. Gunakan path relatif dalam /workspace sahaja.',
      );
    } on FileSystemException {
      return const ToolResult(
        success: false,
        output:
            'Folder itu tidak boleh disenaraikan. Gunakan path relatif dalam /workspace sahaja.',
      );
    }
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(values),
      data: <String, dynamic>{'items': values},
    );
  }

  Future<ToolResult> _fileRead(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final requested = arguments['path']?.toString() ?? '';
    _rejectStagingPath(requested);
    final file = _safeWorkspaceFile(root, requested);
    if (!await file.exists()) {
      return const ToolResult(success: false, output: 'Fail tidak ditemui.');
    }

    final rel = p.relative(file.path, from: root.path);
    final size = await file.length();
    final ext = p.extension(file.path).toLowerCase();
    const binaryExtensions = <String>{
      '.apk', '.aab', '.zip', '.jar', '.so', '.dex', '.exe',
      '.png', '.jpg', '.jpeg', '.webp', '.gif', '.mp4', '.mp3',
      '.pdf', '.7z', '.rar',
    };
    if (binaryExtensions.contains(ext)) {
      return ToolResult(
        success: false,
        output:
            '$rel ialah fail binari/arkib ($size bait). Gunakan archive_unzip '
            'untuk arkib atau send_file untuk menghantarnya.',
        data: <String, dynamic>{'path': rel, 'bytes': size, 'binary': true},
      );
    }

    // Probe kecil melalui RandomAccessFile menolak NUL/binari tanpa memuatkan
    // seluruh fail. Kandungan sebenar tetap dibaca sebagai stream di bawah.
    final RandomAccessFile probe = await file.open();
    try {
      final head = await probe.read(size.clamp(0, 4096).toInt());
      if (head.contains(0)) {
        return ToolResult(
          success: false,
          output: '$rel nampak seperti fail binari; file_read hanya untuk teks.',
          data: <String, dynamic>{'path': rel, 'bytes': size, 'binary': true},
        );
      }
    } finally {
      await probe.close();
    }

    final offset = int.tryParse('${arguments['offset'] ?? ''}') ?? 0;
    final lengthArg = int.tryParse('${arguments['length'] ?? ''}') ?? 0;
    final useLinePaging =
        arguments.containsKey('start_line') || arguments.containsKey('max_lines');
    final useCharacterPaging = !useLinePaging;
    final startLine = (int.tryParse('${arguments['start_line'] ?? ''}') ?? 1)
        .clamp(1, 1 << 31)
        .toInt();
    final maxLines = (int.tryParse('${arguments['max_lines'] ?? ''}') ?? 300)
        .clamp(1, 500)
        .toInt();

    final selected = StringBuffer();
    var selectedChars = 0;
    var totalChars = 0;
    var totalLines = 0;
    var endLine = startLine - 1;
    var tail = '';
    var lineTruncated = false;
    try {
      if (useCharacterPaging) {
        final start = offset.clamp(0, 1 << 31).toInt();
        final take = (lengthArg > 0 ? lengthArg : 12000)
            .clamp(1, 24000)
            .toInt();
        await for (final chunk in file.openRead().transform(utf8.decoder)) {
          totalLines += '\n'.allMatches(chunk).length;
          tail = '$tail$chunk';
          if (tail.length > 300) tail = tail.substring(tail.length - 300);
          final chunkStart = totalChars;
          final chunkEnd = chunkStart + chunk.length;
          final wantedEnd = start + take;
          if (chunkEnd > start && chunkStart < wantedEnd) {
            final localStart =
                (start - chunkStart).clamp(0, chunk.length).toInt();
            final localEnd =
                (wantedEnd - chunkStart).clamp(0, chunk.length).toInt();
            if (localEnd > localStart) {
              final part = chunk.substring(localStart, localEnd);
              selected.write(part);
              selectedChars += part.length;
            }
          }
          totalChars = chunkEnd;
        }
      } else {
        var lineNumber = 0;
        await for (final line in file
            .openRead()
            .transform(utf8.decoder)
            .transform(const LineSplitter())) {
          lineNumber++;
          totalLines = lineNumber;
          tail = tail.isEmpty ? line : '$tail\n$line';
          if (tail.length > 300) tail = tail.substring(tail.length - 300);
          if (lineNumber < startLine || lineNumber >= startLine + maxLines) {
            continue;
          }
          final separatorLength = selectedChars == 0 ? 0 : 1;
          final remaining = 12000 - selectedChars - separatorLength;
          if (remaining <= 0) continue;
          if (selectedChars > 0) selected.writeln();
          if (line.length > remaining) {
            selected.write(line.substring(0, remaining));
            selectedChars += separatorLength + remaining;
            lineTruncated = true;
          } else {
            selected.write(line);
            selectedChars += separatorLength + line.length;
          }
          endLine = lineNumber;
        }
      }
    } on FormatException {
      return ToolResult(
        success: false,
        output: '$rel bukan teks UTF-8 yang sah; gunakan send_file atau tool arkib.',
        data: <String, dynamic>{'path': rel, 'bytes': size, 'binary': true},
      );
    }

    final hash = await FileWriteCoordinator.sha256File(file);
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: p.basename(file.path),
      subtitle: rel,
      localPath: file.path,
      mimeType: _mimeForPath(file.path),
    );
    final data = <String, dynamic>{
      'path': rel,
      'bytes': size,
      'sha256': hash,
      'tail': tail,
      'artifact': artifact.toJson(),
    };
    if (useCharacterPaging) {
      final start = offset.clamp(0, totalChars).toInt();
      final hasMore = start + selectedChars < totalChars;
      data.addAll(<String, dynamic>{
        'offset': start,
        'characters': selectedChars,
        'has_more': hasMore,
        if (hasMore) 'next_offset': start + selectedChars,
      });
    } else {
      final hasMore = endLine < totalLines;
      data.addAll(<String, dynamic>{
        'total_lines': totalLines,
        'start_line': startLine,
        'end_line': endLine,
        'has_more': hasMore,
        if (lineTruncated) 'line_truncated': true,
        if (hasMore) 'next_start_line': endLine + 1,
      });
    }
    return ToolResult(success: true, output: selected.toString(), data: data);
  }

  Future<FileWriteCoordinator> _fileWriter() async {
    final root = await _workspace();
    return _fileWriteCoordinator ??= FileWriteCoordinator(root);
  }

  Future<List<FileWriteSnapshot>> pendingFileWrites(String ownerId) async =>
      (await _fileWriter()).pendingForOwner(ownerId);

  Future<void> abortPendingFileWrites(String ownerId) async =>
      (await _fileWriter()).abortAllForOwner(ownerId);

  Future<ToolResult> _fileWrite(
    Map<String, dynamic> arguments,
    String ownerId,
  ) async {
    final requested = arguments['path']?.toString().trim() ?? '';
    if (requested.isEmpty) {
      throw const FileWriteException(
        'PATH_REQUIRED',
        'Path sebenar wajib diberi. Path atau extension tidak akan diteka.',
      );
    }
    _rejectStagingPath(requested);
    final root = await _workspace();
    final file = _safeWorkspaceFile(root, requested);
    if (arguments['append'] == true) {
      return _appendExistingPath(arguments, ownerId, root: root, file: file);
    }
    var overwrite = arguments['overwrite'] == true;
    var baseSha256 = arguments['base_sha256']?.toString();
    if (await file.exists() && !arguments.containsKey('overwrite')) {
      // Kontrak lama file_write menimpa fail sedia ada. Kekalkan kemampuan itu,
      // tetapi ambil hash semasa dan biar coordinator menyemak semula sebelum
      // atomic commit supaya perubahan serentak tidak tertindih senyap.
      overwrite = true;
      baseSha256 = await FileWriteCoordinator.sha256File(file);
    }
    final snapshot = await (await _fileWriter()).begin(
      ownerId: ownerId,
      target: file,
      relativePath: p.relative(file.path, from: root.path),
      content: arguments['content']?.toString() ?? '',
      done: arguments['done'] != false,
      overwrite: overwrite,
      baseSha256: baseSha256,
      expectedSha256: arguments['expected_sha256']?.toString(),
      expectedBytes: (arguments['expected_bytes'] as num?)?.toInt(),
    );
    return _fileWriteResult(snapshot, root);
  }

  Future<ToolResult> _fileAppend(
    Map<String, dynamic> arguments,
    String ownerId,
  ) async {
    final writeId = arguments['write_id']?.toString().trim() ?? '';
    if (writeId.isEmpty) {
      final requested = arguments['path']?.toString().trim() ?? '';
      if (requested.isEmpty) {
        throw const FileWriteException(
          'WRITE_TARGET_REQUIRED',
          'file_append memerlukan write_id + sequence, atau path untuk mod serasi lama.',
        );
      }
      _rejectStagingPath(requested);
      final root = await _workspace();
      return _appendExistingPath(
        arguments,
        ownerId,
        root: root,
        file: _safeWorkspaceFile(root, requested),
      );
    }
    final sequence = (arguments['sequence'] as num?)?.toInt();
    if (sequence == null) {
      throw const FileWriteException(
        'SEQUENCE_REQUIRED',
        'file_append memerlukan next_sequence daripada hasil sebelumnya.',
      );
    }
    final snapshot = await (await _fileWriter()).append(
      ownerId: ownerId,
      writeId: writeId,
      sequence: sequence,
      content: arguments['content']?.toString() ?? '',
      done: arguments['done'] == true,
      expectedSha256: arguments['expected_sha256']?.toString(),
      expectedBytes: (arguments['expected_bytes'] as num?)?.toInt(),
    );
    return _fileWriteResult(snapshot, await _workspace());
  }

  Future<ToolResult> _appendExistingPath(
    Map<String, dynamic> arguments,
    String ownerId, {
    required Directory root,
    required File file,
  }) async {
    final relative = p.relative(file.path, from: root.path);
    final snapshot = await (await _fileWriter()).appendExisting(
      ownerId: ownerId,
      target: file,
      relativePath: relative,
      content: arguments['content']?.toString() ?? '',
      expectedSha256: arguments['expected_sha256']?.toString(),
    );
    return _fileWriteResult(snapshot, root);
  }

  Future<ToolResult> _fileCommit(
    Map<String, dynamic> arguments,
    String ownerId,
  ) async {
    final writeId = arguments['write_id']?.toString().trim() ?? '';
    if (writeId.isEmpty) {
      throw const FileWriteException(
        'WRITE_ID_REQUIRED',
        'file_commit memerlukan write_id.',
      );
    }
    final snapshot = await (await _fileWriter()).commit(
      ownerId: ownerId,
      writeId: writeId,
      expectedSha256: arguments['expected_sha256']?.toString(),
      expectedBytes: (arguments['expected_bytes'] as num?)?.toInt(),
    );
    return _fileWriteResult(snapshot, await _workspace());
  }

  Future<ToolResult> _fileWriteStatus(
    Map<String, dynamic> arguments,
    String ownerId,
  ) async {
    final writeId = arguments['write_id']?.toString().trim() ?? '';
    if (writeId.isEmpty) {
      throw const FileWriteException(
        'WRITE_ID_REQUIRED',
        'file_write_status memerlukan write_id.',
      );
    }
    final snapshot = await (await _fileWriter()).status(
      ownerId: ownerId,
      writeId: writeId,
    );
    return ToolResult(
      success: true,
      output: snapshot.committed
          ? 'Transaksi sudah committed: ${snapshot.path}.'
          : 'Transaksi aktif untuk ${snapshot.path}; next_sequence=${snapshot.nextSequence}.',
      data: snapshot.toData(),
    );
  }

  Future<ToolResult> _fileAbort(
    Map<String, dynamic> arguments,
    String ownerId,
  ) async {
    final writeId = arguments['write_id']?.toString().trim() ?? '';
    if (writeId.isEmpty) {
      throw const FileWriteException(
        'WRITE_ID_REQUIRED',
        'file_abort memerlukan write_id.',
      );
    }
    await (await _fileWriter()).abort(ownerId: ownerId, writeId: writeId);
    return ToolResult(
      success: true,
      output: 'Transaksi $writeId dibatalkan. Fail sasaran tidak disentuh.',
      data: <String, dynamic>{
        'write_id': writeId,
        'aborted': true,
      },
    );
  }

  ToolResult _fileWriteResult(
    FileWriteSnapshot snapshot,
    Directory root,
  ) {
    final data = snapshot.toData();
    if (!snapshot.committed) {
      return ToolResult(
        success: true,
        output:
            'Chunk disimpan dalam staging untuk ${snapshot.path}. '
            'Jumlah ${snapshot.bytes} bait; next_sequence=${snapshot.nextSequence}. '
            'Gunakan file_append atau file_commit. Fail belum dipersembahkan.',
        data: data,
      );
    }
    final file = _safeWorkspaceFile(root, snapshot.path);
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: p.basename(file.path),
      subtitle: '${snapshot.bytes} bait · ${snapshot.sha256.substring(0, 12)}…',
      localPath: file.path,
      mimeType: _mimeForPath(file.path),
    );
    data['artifact'] = artifact.toJson();
    return ToolResult(
      success: true,
      output:
          'COMMITTED: ${snapshot.path} (${snapshot.bytes} bait, ${snapshot.lines} baris, SHA-256 ${snapshot.sha256}).',
      data: data,
    );
  }

  void _rejectStagingPath(String path) {
    final normalized = path.replaceAll('\\', '/').toLowerCase();
    if (normalized.split('/').contains('.write_staging')) {
      throw const FileWriteException(
        'STAGING_PATH_FORBIDDEN',
        'Fail staging tidak boleh dibaca, ditulis atau dipersembahkan secara langsung.',
      );
    }
  }

  Future<ToolResult> _fileReplace(
    Map<String, dynamic> arguments, {
    required bool strict,
  }) async {
    final root = await _workspace();
    final relative = arguments['path']?.toString() ?? '';
    final find = arguments['find']?.toString() ?? '';
    final replacement = arguments['replace']?.toString() ?? '';
    final useRegex = arguments['regex'] == true;
    final replaceAll = arguments.containsKey('replace_all')
        ? arguments['replace_all'] == true
        : !strict;
    final caseSensitive = arguments['case_sensitive'] != false;
    final expectedSha256 =
        arguments['expected_sha256']?.toString().trim() ?? '';

    if (relative.trim().isEmpty) {
      return const ToolResult(success: false, output: 'Path fail kosong.');
    }
    if (find.isEmpty) {
      return const ToolResult(success: false, output: 'Parameter find kosong.');
    }
    if (strict && expectedSha256.isEmpty) {
      throw const FileWriteException(
        'BASE_HASH_REQUIRED',
        'str_replace memerlukan expected_sha256 daripada file_read.',
      );
    }

    _rejectStagingPath(relative);
    final file = _safeWorkspaceFile(root, relative);
    if (!await file.exists()) {
      return const ToolResult(success: false, output: 'Fail tidak ditemui.');
    }
    if (await file.length() > 48 * 1024 * 1024) {
      return const ToolResult(
        success: false,
        output:
            'Fail melebihi 48 MB untuk replace. Untuk arkib, extract dan edit fail kecil.',
      );
    }

    final original = await file.readAsString();
    final actualSha256 = await FileWriteCoordinator.sha256File(file);
    if (expectedSha256.isNotEmpty &&
        actualSha256 != expectedSha256.toLowerCase()) {
      throw const FileWriteException(
        'VERSION_CONFLICT',
        'Fail berubah sejak file_read. Baca semula sebelum mengganti teks.',
      );
    }
    late final String updated;
    late final int count;

    try {
      if (useRegex) {
        final pattern = RegExp(
          find,
          caseSensitive: caseSensitive,
          multiLine: true,
          dotAll: true,
        );
        final matches = pattern.allMatches(original).length;
        _validateReplaceMatches(matches, replaceAll, strict: strict);
        count = replaceAll ? matches : 1;
        updated = replaceAll
            ? original.replaceAll(pattern, replacement)
            : original.replaceFirst(pattern, replacement);
      } else {
        if (caseSensitive) {
          final matches = find.allMatches(original).length;
          _validateReplaceMatches(matches, replaceAll, strict: strict);
          count = replaceAll ? matches : 1;
          updated = replaceAll
              ? original.replaceAll(find, replacement)
              : original.replaceFirst(find, replacement);
        } else {
          final pattern = RegExp(RegExp.escape(find), caseSensitive: false);
          final matches = pattern.allMatches(original).length;
          _validateReplaceMatches(matches, replaceAll, strict: strict);
          count = replaceAll ? matches : 1;
          updated = replaceAll
              ? original.replaceAllMapped(pattern, (_) => replacement)
              : original.replaceFirstMapped(pattern, (_) => replacement);
        }
      }
    } on FormatException catch (error) {
      return ToolResult(
        success: false,
        output: 'Regex tidak sah: $error',
      );
    }

    final rel = p.relative(file.path, from: root.path);
    final snapshot = await (await _fileWriter()).atomicReplace(
      target: file,
      relativePath: rel,
      content: updated,
      baseSha256: expectedSha256.isEmpty ? actualSha256 : expectedSha256,
    );
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: p.basename(file.path),
      subtitle: '$count gantian · ${snapshot.bytes} bait · $rel',
      localPath: file.path,
      mimeType: _mimeForPath(file.path),
    );
    return ToolResult(
      success: true,
      output: 'Diganti $count padanan dalam $rel.',
      data: <String, dynamic>{
        'path': rel,
        'replacements': count,
        'regex': useRegex,
        'replace_all': replaceAll,
        'strict': strict,
        'bytes_before': utf8.encode(original).length,
        'bytes_after': snapshot.bytes,
        'lines': snapshot.lines,
        'sha256': snapshot.sha256,
        'tail': snapshot.tail,
        'artifact': artifact.toJson(),
      },
    );
  }

  void _validateReplaceMatches(
    int matches,
    bool replaceAll, {
    required bool strict,
  }) {
    if (matches == 0) {
      throw const FileWriteException(
        'MATCH_NOT_FOUND',
        'Teks/corak tidak ditemui. Baca semula fail dan gunakan padanan exact.',
      );
    }
    if (strict && !replaceAll && matches != 1) {
      throw FileWriteException(
        'AMBIGUOUS_MATCH',
        'Padanan dijangka tepat satu tetapi ditemui $matches. Gunakan konteks lebih panjang atau replace_all=true secara eksplisit.',
      );
    }
  }

  Future<ToolResult> _fileCopy(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final source = _safeWorkspaceFile(root, arguments['source']?.toString() ?? '');
    final destination = _safeWorkspaceFile(root, arguments['destination']?.toString() ?? '');
    if (!await source.exists()) return const ToolResult(success: false, output: 'Fail sumber tidak ditemui.');
    await destination.parent.create(recursive: true);
    await source.copy(destination.path);
    return ToolResult(success: true, output: 'Fail disalin ke ${p.relative(destination.path, from: root.path)}.');
  }

  Future<ToolResult> _fileMove(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final source = _safeWorkspaceFile(root, arguments['source']?.toString() ?? '');
    final destination = _safeWorkspaceFile(root, arguments['destination']?.toString() ?? '');
    if (!await source.exists()) return const ToolResult(success: false, output: 'Fail sumber tidak ditemui.');
    await destination.parent.create(recursive: true);
    if (await destination.exists()) await destination.delete();
    await source.rename(destination.path);
    return ToolResult(success: true, output: 'Fail dipindah ke ${p.relative(destination.path, from: root.path)}.');
  }

  Future<ToolResult> _fileDelete(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final relative = arguments['path']?.toString() ?? '';
    final normalized = _resolveWorkspaceRelative(root, relative);
    if (normalized == root.path) {
      return const ToolResult(
        success: false,
        output: 'Pemadaman root workspace tidak dibenarkan.',
      );
    }
    final type = await FileSystemEntity.type(normalized, followLinks: false);
    if (type == FileSystemEntityType.notFound) {
      return const ToolResult(
        success: false,
        output: 'Fail atau folder tidak ditemui.',
      );
    }
    if (type == FileSystemEntityType.directory) {
      await Directory(normalized).delete(
        recursive: arguments['recursive'] as bool? ?? false,
      );
    } else {
      await File(normalized).delete();
    }
    return ToolResult(success: true, output: '$relative telah dipadam.');
  }

  Future<ToolResult> _memorySearch(Map<String, dynamic> arguments) async {
    final query = arguments['query']?.toString().toLowerCase() ?? '';
    final values = (await database.listObjects('memory'))
        .map(MemoryRecord.fromJson)
        .where((item) => '${item.title} ${item.content} ${item.tags.join(' ')}'.toLowerCase().contains(query))
        .take(50)
        .map((item) => item.toJson())
        .toList();
    return ToolResult(success: true, output: const JsonEncoder.withIndent('  ').convert(values), data: <String, dynamic>{'results': values});
  }

  Future<ToolResult> _memoryAdd(Map<String, dynamic> arguments) async {
    final record = MemoryRecord(
      id: _uuid.v4(),
      title: arguments['title']?.toString() ?? 'Memori',
      content: arguments['content']?.toString() ?? '',
      createdAt: DateTime.now(),
      tags: (arguments['tags'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
    );
    await database.saveObject('memory', record.id, record.toJson());
    return ToolResult(success: true, output: 'Memori disimpan dengan ID ${record.id}.', data: record.toJson());
  }

  Future<ToolResult> _memoryDelete(Map<String, dynamic> arguments) async {
    final id = arguments['id']?.toString() ?? '';
    final existing = await database.getObject('memory', id);
    if (existing == null) return const ToolResult(success: false, output: 'Memori tidak ditemui.');
    await database.deleteObject('memory', id);
    return ToolResult(success: true, output: 'Memori $id dipadam.');
  }

  Future<ToolResult> _skillSetEnabled(Map<String, dynamic> arguments) async {
    final enabled = arguments['enabled'] == true;
    final needle = (arguments['id'] ?? arguments['name'] ?? '')
        .toString()
        .trim()
        .toLowerCase();
    if (needle.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'Berikan name atau id skill.',
      );
    }
    final all = await skillService.loadSkills();
    final matches = all.where((s) {
      return s.id.toLowerCase() == needle || s.name.toLowerCase() == needle;
    }).toList();
    if (matches.isEmpty) {
      final names = all.map((s) => s.name).join(', ');
      return ToolResult(
        success: false,
        output: 'Skill "$needle" tidak dijumpai. Ada: $names',
      );
    }
    final changed = <String>[];
    for (final skill in matches) {
      if (skill.enabled == enabled) {
        changed.add('${skill.name} sudah ${enabled ? 'aktif' : 'mati'}');
        continue;
      }
      await skillService.save(skill.copyWith(enabled: enabled));
      changed.add('${skill.name} ${enabled ? 'diaktifkan' : 'dimatikan'}');
    }
    return ToolResult(success: true, output: changed.join('. '));
  }

  Future<ToolResult> _skillCreate(Map<String, dynamic> arguments) async {
    try {
      final skill = await skillService.createFromTool(arguments);
      return ToolResult(
        success: true,
        output: 'Skill ${skill.name} telah disimpan dan tersedia kepada model.',
        data: <String, dynamic>{
          ...skill.toJson(),
          'artifact': ChatArtifact(
            id: _uuid.v4(),
            kind: ArtifactKind.file,
            title: skill.name,
            subtitle: 'Skill local',
            data: skill.toJson(),
          ).toJson(),
        },
      );
    } on FormatException catch (error) {
      return ToolResult(
        success: false,
        output:
            '${error.message}\n'
            'Jangan henti tugasan. Isi name + instructions, kemudian skill_create semula.',
      );
    } on StateError catch (error) {
      return ToolResult(
        success: false,
        output:
            'SKILL_CONFLICT: $error\n'
            'Jangan cipta nama alternatif atau salinan secara automatik. '
            'Jika pengguna mahu mengubah skill itu, gunakan skill_update.',
      );
    } catch (error) {
      return ToolResult(
        success: false,
        output:
            'Gagal cipta skill: $error\n'
            'Jangan henti. Betulkan argumen dan cuba lagi.',
      );
    }
  }

  Future<ToolResult> _skillUpdate(Map<String, dynamic> arguments) async {
    try {
      final skill = await skillService.updateFromTool(arguments);
      return ToolResult(
        success: true,
        output: 'Skill ${skill.name} telah dikemas kini selepas disahkan pengguna.',
        data: <String, dynamic>{
          ...skill.toJson(),
          'operation': 'updated',
          'artifact': ChatArtifact(
            id: _uuid.v4(),
            kind: ArtifactKind.file,
            title: skill.name,
            subtitle: 'Skill dikemas kini',
            data: skill.toJson(),
          ).toJson(),
        },
      );
    } catch (error) {
      return ToolResult(
        success: false,
        output: 'Gagal mengemas kini skill: $error',
      );
    }
  }

  Future<ToolResult> _skillDelete(Map<String, dynamic> arguments) async {
    try {
      final skill = await skillService.deleteFromTool(arguments);
      return ToolResult(
        success: true,
        output: 'Skill ${skill.name} telah dipadam selepas disahkan pengguna.',
        data: <String, dynamic>{
          'operation': 'deleted',
          'id': skill.id,
          'name': skill.name,
        },
      );
    } catch (error) {
      return ToolResult(
        success: false,
        output: 'Gagal memadam skill: $error',
      );
    }
  }

  Future<ToolResult> _skillInstall(Map<String, dynamic> arguments) async {
    final url = arguments['url']?.toString().trim() ?? '';
    final path = arguments['path']?.toString().trim() ?? '';
    if (url.isEmpty && path.isEmpty) {
      return const ToolResult(
        success: false,
        output:
            'Berikan url ATAU path. Untuk lampiran chat: path="strix-main.zip" atau path="/attachments/strix-main.zip".',
      );
    }
    final SkillDefinition skill;
    if (path.isNotEmpty) {
      final file = await _resolveReadableFile(path);
      if (!await file.exists()) {
        return ToolResult(success: false, output: 'Fail skill tidak jumpa: $path');
      }
      skill = await skillService.importZip(file.path);
    } else {
      skill = await skillService.importUrl(url);
    }
    return ToolResult(
      success: true,
      output: 'Skill ${skill.name} dipasang dan diaktifkan.',
      data: skill.toJson(),
    );
  }

  Future<ToolResult> _archiveUnzip(Map<String, dynamic> arguments) async {
    final src = arguments['path']?.toString().trim() ?? '';
    if (src.isEmpty) {
      return const ToolResult(success: false, output: 'path ZIP diperlukan.');
    }
    final file = await _resolveReadableFile(src);
    if (!await file.exists()) {
      return ToolResult(success: false, output: 'ZIP tidak jumpa: $src');
    }
    final bytes = await file.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes, verify: true);
    final root = await _workspace();
    var destRel = arguments['destination']?.toString().trim() ?? '';
    if (destRel.isEmpty) {
      final base = p.basename(file.path);
      destRel = base.toLowerCase().endsWith('.zip')
          ? base.substring(0, base.length - 4)
          : '${base}_extracted';
    }
    destRel = destRel.replaceAll('\\', '/');
    if (destRel.startsWith('/workspace/')) {
      destRel = destRel.substring('/workspace/'.length);
    }
    if (p.isAbsolute(destRel) || destRel.contains('..')) {
      return const ToolResult(success: false, output: 'destination mesti relatif dalam workspace.');
    }
    final destDir = Directory(p.join(root.path, destRel));
    await destDir.create(recursive: true);
    var count = 0;
    for (final entry in archive) {
      final name = p.normalize(entry.name.replaceAll('\\', '/'));
      if (name.startsWith('../') || p.isAbsolute(name) || name.contains('/../')) {
        continue;
      }
      final outPath = p.join(destDir.path, name);
      if (!p.isWithin(destDir.path, outPath) && outPath != destDir.path) continue;
      if (entry.isDirectory) {
        await Directory(outPath).create(recursive: true);
      } else {
        await File(outPath).parent.create(recursive: true);
        await File(outPath).writeAsBytes(entry.content as List<int>);
        count += 1;
      }
    }
    return ToolResult(
      success: true,
      output: 'Extract $count fail ke /workspace/$destRel',
      data: <String, dynamic>{'destination': destRel, 'files': count},
    );
  }

  Future<ToolResult> _archiveZip(Map<String, dynamic> arguments) async {
    final src = arguments['path']?.toString().trim() ?? '';
    if (src.isEmpty) {
      return const ToolResult(success: false, output: 'path sumber diperlukan.');
    }
    final root = await _workspace();
    final sourcePath = _resolveWorkspaceRelative(root, src);
    final entityType = FileSystemEntity.typeSync(sourcePath, followLinks: false);
    if (entityType == FileSystemEntityType.notFound) {
      return ToolResult(success: false, output: 'Sumber tidak jumpa: $src');
    }
    var destRel = arguments['destination']?.toString().trim() ?? '';
    if (destRel.isEmpty) {
      final base = p.basename(sourcePath);
      destRel = base.endsWith('.zip') ? base : '$base.zip';
    }
    destRel = destRel.replaceAll('\\', '/');
    if (destRel.startsWith('/workspace/')) destRel = destRel.substring('/workspace/'.length);
    if (p.isAbsolute(destRel) || destRel.contains('..')) {
      return const ToolResult(success: false, output: 'destination mesti relatif workspace.');
    }
    final outPath = _resolveWorkspaceRelative(root, destRel);
    final archive = Archive();
    if (entityType == FileSystemEntityType.file) {
      final data = await File(sourcePath).readAsBytes();
      archive.addFile(ArchiveFile(p.basename(sourcePath), data.length, data));
    } else {
      final dir = Directory(sourcePath);
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is! File) continue;
        final rel = p.relative(entity.path, from: sourcePath);
        final data = await entity.readAsBytes();
        archive.addFile(ArchiveFile(rel.replaceAll('\\', '/'), data.length, data));
      }
    }
    final encoded = ZipEncoder().encode(archive);
    if (encoded.isEmpty) {
      return const ToolResult(success: false, output: 'Gagal encode ZIP (kosong).');
    }
    await File(outPath).parent.create(recursive: true);
    await File(outPath).writeAsBytes(encoded, flush: true);
    return ToolResult(
      success: true,
      output: 'ZIP dicipta: /workspace/$destRel (${encoded.length} bait)',
      data: <String, dynamic>{'destination': destRel, 'bytes': encoded.length},
    );
  }


  Future<ToolResult> _skillRunScript(Map<String, dynamic> arguments) async {
    final skillId = arguments['skill_id']?.toString() ?? '';
    final script = arguments['script']?.toString() ?? '';
    if (skillId.trim().isEmpty) {
      return const ToolResult(
        success: false,
        output:
            'skill_id diperlukan. Skill dari skill_create (arahan sahaja) tiada folder skrip — guna terminal_start.',
      );
    }
    if (p.isAbsolute(script) || p.normalize(script).startsWith('../')) {
      return const ToolResult(success: false, output: 'Path skrip di luar sandbox tidak dibenarkan.');
    }
    try {
      final cwd = await skillService.prepareScriptSandbox(skillId);
      final args = (arguments['arguments'] as List? ?? const <dynamic>[])
          .map((item) => _shellQuote(item.toString()))
          .join(' ');
      final command = '${_shellQuote(script)}${args.isEmpty ? '' : ' $args'}';
      return terminalService.start(command: command, workingDirectory: cwd);
    } on StateError catch (e) {
      // Skill skill_create / tiada sourcePath → bukan pakej skrip.
      return ToolResult(
        success: false,
        output:
            '${e.message}\n'
            'Skill arahan-sahaja (skill_create) tiada folder skrip. '
            'Guna terminal_start untuk jalan perintah, atau pasang ZIP skill yang ada skrip.',
      );
    }
  }

  Future<ToolResult> _mcpListTools(Map<String, dynamic> arguments) async {
    final server = await _mcpServer(arguments['server_id']?.toString() ?? '');
    final tools = await mcpService.listTools(server);
    return ToolResult(success: true, output: const JsonEncoder.withIndent('  ').convert(tools), data: <String, dynamic>{'server': server.toJson(), 'tools': tools});
  }

  Future<ToolResult> _mcpConfigure(Map<String, dynamic> arguments) async {
    final url = arguments['url']?.toString().trim() ??
        arguments['baseUrl']?.toString().trim() ??
        '';
    if (url.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'URL MCP diperlukan (http/https).',
      );
    }
    try {
      final parsed = Uri.parse(url);
      if (!<String>{'http', 'https'}.contains(parsed.scheme) ||
          parsed.host.isEmpty) {
        return const ToolResult(success: false, output: 'URL MCP tidak sah.');
      }
    } catch (_) {
      return const ToolResult(success: false, output: 'URL MCP tidak sah.');
    }

    var headers = <String, String>{};
    final rawHeaders = arguments['headers'];
    if (rawHeaders is Map) {
      headers = rawHeaders.map(
        (key, value) => MapEntry(key.toString(), value.toString()),
      );
    } else if (rawHeaders is String && rawHeaders.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(rawHeaders);
        if (decoded is Map) {
          headers = decoded.map(
            (key, value) => MapEntry(key.toString(), value.toString()),
          );
        }
      } catch (_) {}
    }

    final requestedId = arguments['id']?.toString().trim() ?? '';
    final existing = requestedId.isEmpty
        ? null
        : await database.getObject('mcp_server', requestedId);
    final id = requestedId.isNotEmpty
        ? requestedId
        : (existing?['id']?.toString() ?? _uuid.v4());
    final name = (arguments['name']?.toString().trim().isNotEmpty == true)
        ? arguments['name'].toString().trim()
        : (Uri.tryParse(url)?.host ?? 'MCP');
    final enabled = arguments['enabled'] as bool? ?? true;
    final server = McpServerConfig(
      id: id,
      name: name,
      baseUrl: url,
      enabled: enabled,
      headers: headers,
      transport: McpTransport.streamableHttp,
    );
    await database.saveObject('mcp_server', server.id, server.toJson());
    return ToolResult(
      success: true,
      output:
          'MCP "${server.name}" disimpan (${server.baseUrl}). '
          'Guna mcp_list_tools / mcp_call dengan server_id=${server.id}.',
      data: server.toJson(),
    );
  }

  Future<ToolResult> _mcpCall(Map<String, dynamic> arguments) async {
    final server = await _mcpServer(arguments['server_id']?.toString() ?? '');
    final result = await mcpService.callTool(
      server,
      name: arguments['tool_name']?.toString() ?? '',
      arguments: Map<String, dynamic>.from(arguments['arguments'] as Map? ?? const <String, dynamic>{}),
    );
    return ToolResult(success: result['isError'] != true, output: const JsonEncoder.withIndent('  ').convert(result), data: result);
  }

  Future<McpServerConfig> _mcpServer(String id) async {
    final json = await database.getObject('mcp_server', id);
    if (json == null) throw StateError('Server MCP $id tidak ditemui.');
    final server = McpServerConfig.fromJson(json);
    if (!server.enabled) throw StateError('Server MCP ${server.name} tidak aktif.');
    return server;
  }

  Future<ToolResult> _videoSampleFrames(Map<String, dynamic> arguments) async {
    final fpsRaw = arguments['fps'];
    final fps = fpsRaw is num
        ? fpsRaw.toDouble()
        : double.tryParse(fpsRaw?.toString() ?? '') ?? 1;
    final clampedFps = fps.clamp(0.05, 30.0);
    final requestedFrames = (arguments['frames'] as num?)?.toInt();

    File? source;
    final path = arguments['path']?.toString().trim() ?? '';
    final url = arguments['url']?.toString().trim() ?? '';
    if (path.isNotEmpty) {
      final resolved = await _resolveLocalMediaFile(path);
      if (resolved != null) source = File(resolved.path);
    }
    if (source == null && url.isNotEmpty) {
      final uri = Uri.tryParse(url);
      if (uri != null && <String>{'http', 'https'}.contains(uri.scheme)) {
        final root = await _workspace();
        final dest = File(
          p.join(root.path, 'generated', 'src_${_uuid.v4().substring(0, 8)}.mp4'),
        );
        await dest.parent.create(recursive: true);
        final response = await _client.get(uri).timeout(AppConfig.defaultTimeout);
        if (response.statusCode < 200 || response.statusCode >= 300) {
          return ToolResult(
            success: false,
            output: 'Muat turun video gagal HTTP ${response.statusCode}.',
          );
        }
        await dest.writeAsBytes(response.bodyBytes);
        source = dest;
      }
    }
    if (source == null || !await source.exists()) {
      return const ToolResult(
        success: false,
        output: 'Video tidak ditemui. Beri path lampiran atau URL.',
      );
    }

    final root = await _workspace();
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final outDir = Directory(p.join(root.path, 'generated', 'frames_$stamp'));
    await outDir.create(recursive: true);
    final pattern = p.join(outDir.path, 'frame_%04d.jpg');

    final copied = File(p.join(root.path, 'generated', 'src_$stamp${p.extension(source.path)}'));
    if (p.normalize(copied.path) != p.normalize(source.path)) {
      await source.copy(copied.path);
    } else {
      await copied.parent.create(recursive: true);
    }
    final guestIn = '/workspace/generated/${p.basename(copied.path)}';
    final guestOut = '/workspace/generated/frames_$stamp/frame_%04d.jpg';
    final frameLimit = requestedFrames != null && requestedFrames > 0
        ? <String>['-frames:v', '$requestedFrames']
        : const <String>[];
    final guestLimit = requestedFrames != null && requestedFrames > 0
        ? '-frames:v $requestedFrames'
        : '';

    var extracted = await _runHostFfmpeg(<String>[
      '-y',
      '-i',
      copied.path,
      '-vf',
      'fps=$clampedFps',
      ...frameLimit,
      '-q:v',
      '4',
      pattern,
    ]);
    if (!extracted) {
      extracted = await _runGuestFfmpeg(
        'command -v ffmpeg >/dev/null 2>&1 || apk add --no-cache ffmpeg >/dev/null 2>&1; '
        'ffmpeg -y -i "$guestIn" -vf fps=$clampedFps $guestLimit -q:v 4 "$guestOut"',
      );
    }
    if (!extracted) {
      return const ToolResult(
        success: false,
        output:
            'ffmpeg tidak berjaya. Pasang ffmpeg dalam Shell (apk add ffmpeg) atau guna path video sah.',
      );
    }

    final frames = outDir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.toLowerCase().endsWith('.jpg'))
        .toList()
      ..sort((a, b) => a.path.compareTo(b.path));
    if (frames.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'Tiada frame dihasilkan. Fail mungkin bukan video.',
      );
    }

    final artifacts = <Map<String, dynamic>>[];
    final attachments = <Map<String, dynamic>>[];
    for (var i = 0; i < frames.length; i++) {
      final file = frames[i];
      final name = p.basename(file.path);
      final rel = 'generated/frames_$stamp/$name';
      artifacts.add(
        ChatArtifact(
          id: _uuid.v4(),
          kind: ArtifactKind.image,
          title: 'Frame ${i + 1} @ ${clampedFps}fps',
          subtitle: rel,
          localPath: file.path,
          mimeType: 'image/jpeg',
        ).toJson(),
      );
      attachments.add(
        ChatAttachment(
          id: _uuid.v4(),
          name: name,
          path: file.path,
          mimeType: 'image/jpeg',
          sizeBytes: file.lengthSync(),
          kind: AttachmentKind.image,
        ).toJson(),
      );
    }
    return ToolResult(
      success: true,
      output:
          '${frames.length} frame diambil pada ${clampedFps} fps. '
          'Imej dihantar ke model + chat.',
      data: <String, dynamic>{
        'fps': clampedFps,
        'count': frames.length,
        'artifacts': artifacts,
        'attachments': attachments,
      },
    );
  }

  Future<bool> _runHostFfmpeg(List<String> args) async {
    try {
      final result = await Process.run('ffmpeg', args);
      return result.exitCode == 0;
    } catch (_) {
      return false;
    }
  }

  Future<bool> _runGuestFfmpeg(String command) async {
    try {
      await linuxWorkspaceService.ensureBundledRuntimeReady();
      final spec = await linuxWorkspaceService.commandSpec(
        command: command,
        relativeWorkingDirectory: '.',
      );
      if (spec == null) return false;
      final result = await Process.run(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
      ).timeout(const Duration(minutes: 2));
      return result.exitCode == 0;
    } catch (_) {
      return false;
    }
  }

  Future<ToolResult> _calculator(Map<String, dynamic> arguments) async {
    final expression = arguments['expression']?.toString() ?? '';
    final parsed = Parser().parse(expression);
    final value = parsed.evaluate(EvaluationType.REAL, ContextModel());
    return ToolResult(success: true, output: value.toString());
  }

  Future<bool> _workspaceEntityExists(String relative) async {
    if (relative.trim().isEmpty) return false;
    final root = await _workspace();
    final normalized = p.normalize(p.join(root.path, relative));
    if (normalized == root.path || !p.isWithin(root.path, normalized)) return true;
    return FileSystemEntity.type(normalized, followLinks: false).then((type) => type != FileSystemEntityType.notFound);
  }

  bool _looksDestructive(String value) {
    final text = value.toLowerCase();
    return <String>['delete', 'remove', 'destroy', 'drop', 'erase', 'wipe', 'reset', 'revoke', 'uninstall', 'truncate', 'padam', 'hapus']
        .any(text.contains);
  }

  Uri _validatedHttpUri(String raw) {
    var text = raw.trim();
    // Buang quotes / whitespace yang model sering letak.
    if ((text.startsWith('"') && text.endsWith('"')) ||
        (text.startsWith("'") && text.endsWith("'"))) {
      text = text.substring(1, text.length - 1).trim();
    }
    text = text.replaceAll(RegExp(r'\s+'), '');
    if (text.isEmpty) {
      throw const FormatException('URL kosong — berikan http(s)://…');
    }
    final lower = text.toLowerCase();
    if (lower.startsWith('javascript:') ||
        lower.startsWith('data:') ||
        lower.startsWith('about:blank') && text.length < 20 ||
        lower == 'about:blank') {
      throw FormatException(
        'URL tidak dilayari: "$text". Guna http(s) sahaja, bukan javascript:/data:.',
      );
    }
    // //example.com → https://example.com
    if (text.startsWith('//')) {
      text = 'https:$text';
    }
    // example.com/path tanpa skema → https://
    final hasScheme = RegExp(r'^[a-zA-Z][a-zA-Z0-9+.-]*:').hasMatch(text);
    if (!hasScheme && text.contains('.')) {
      text = 'https://$text';
    }
    final uri = Uri.tryParse(text);
    if (uri == null ||
        !<String>{'http', 'https'}.contains(uri.scheme) ||
        (uri.host.isEmpty && uri.path.isEmpty)) {
      throw FormatException(
        'URL HTTP/HTTPS tidak sah: "${raw.length > 120 ? '${raw.substring(0, 120)}…' : raw}". '
        'Guna bentuk penuh cth. https://example.com/path',
      );
    }
    if (uri.host.isEmpty) {
      throw FormatException(
        'URL tiada host: "$text". Contoh sah: https://example.com',
      );
    }
    return uri;
  }

  bool _isAttachmentsAlias(String raw) {
    final value = raw.trim().replaceAll('\\', '/').toLowerCase();
    return value == '/attachments' ||
        value == 'attachments' ||
        value == 'attachments/' ||
        value == '/attachments/';
  }

  Future<ToolResult> _listSessionAttachments() async {
    final values = <Map<String, dynamic>>[];
    Future<void> addDir(Directory dir, String prefix) async {
      if (!await dir.exists()) return;
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is! File) continue;
        final stat = await entity.stat();
        values.add(<String, dynamic>{
          'name': p.basename(entity.path),
          'path': '$prefix/${p.basename(entity.path)}',
          'type': 'file',
          'bytes': stat.size,
          'modified': stat.modified.toIso8601String(),
        });
      }
    }

    final ws = await _workspace();
    await addDir(Directory(p.join(ws.path, 'attachments')), 'attachments');
    try {
      final docs = await getApplicationDocumentsDirectory();
      await addDir(Directory(p.join(docs.path, 'chat_attachments')), 'attachments');
    } catch (_) {}

    if (values.isEmpty) {
      return const ToolResult(
        success: true,
        output:
            'Tiada lampiran sesi. Guna nama fail dari metadata mesej, atau media_preview path=<nama>.',
        data: <String, dynamic>{'items': <Map<String, dynamic>>[]},
      );
    }
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(values),
      data: <String, dynamic>{'items': values},
    );
  }

  Future<Directory> _workspace() async {
    final directory = Directory(p.join((await getApplicationSupportDirectory()).path, 'linux', 'workspace'));
    await directory.create(recursive: true);
    return directory;
  }

  /// Tolak path host Android / absolute luar workspace supaya model tidak
  /// boleh list/read path seperti /data/user/0/.../rootfs/dev/pts.
  bool _looksLikeForbiddenHostPath(String raw) {
    final normalized = raw.replaceAll('\\', '/').trim();
    if (normalized.isEmpty) return false;
    final lower = normalized.toLowerCase();
    const blockedPrefixes = <String>[
      '/data/',
      '/storage/',
      '/sdcard',
      '/mnt/',
      '/proc/',
      '/sys/',
      '/dev/',
      '/system/',
      '/vendor/',
      '/apex/',
    ];
    if (blockedPrefixes.any(
      (prefix) =>
          lower == prefix.replaceAll('/', '') || lower.startsWith(prefix),
    )) {
      return true;
    }
    // Path relatif yang cuba keluar ke rootfs host / pts.
    if (lower.contains('com.aiauto.claw') ||
        lower.contains('/files/linux') ||
        lower.contains('rootfs/dev') ||
        lower.contains('/dev/pts') ||
        lower.contains('../rootfs') ||
        lower.contains('..\\rootfs')) {
      return true;
    }
    // Path absolute lain di luar guest workspace juga ditolak.
    if (p.isAbsolute(normalized) &&
        !lower.startsWith('/workspace') &&
        !lower.startsWith('/root') &&
        !lower.startsWith('/tmp') &&
        !lower.startsWith('/attachments')) {
      return true;
    }
    return false;
  }

  String _resolveWorkspaceRelative(Directory root, String relative) {
    final raw = relative.trim().replaceAll('\\', '/');
    if (raw.isEmpty) {
      throw const FileSystemException('Path kosong tidak dibenarkan.');
    }
    if (_looksLikeForbiddenHostPath(raw)) {
      throw const FileSystemException(
        'Akses path host Android atau path di luar workspace tidak dibenarkan. '
        'Gunakan path relatif dalam workspace, atau nama fail lampiran.',
      );
    }

    var rel = raw;
    if (rel.startsWith('/workspace/')) {
      rel = rel.substring('/workspace/'.length);
    } else if (rel == '/workspace') {
      rel = '.';
    } else if (rel.startsWith('/attachments/')) {
      rel = p.join('attachments', rel.substring('/attachments/'.length));
    } else if (rel == '/attachments' || rel == 'attachments') {
      rel = 'attachments';
    } else if (rel.startsWith('attachments/')) {
      // kekal
    } else if (p.isAbsolute(rel)) {
      throw const FileSystemException(
        'Path mutlak host tidak dibenarkan. Gunakan path relatif dalam workspace.',
      );
    }

    final path = p.normalize(p.join(root.path, rel));
    if (path != root.path && !p.isWithin(root.path, path)) {
      throw const FileSystemException(
        'Akses di luar workspace tidak dibenarkan.',
      );
    }
    return path;
  }

  Future<File> _resolveReadableFile(String rawPath) async {
    final raw = rawPath.trim().replaceAll('\\', '/');
    if (raw.isEmpty) {
      throw const FileSystemException('Path fail kosong.');
    }

    // Path host chat_attachments dari metadata mesej — dibenarkan.
    if (raw.contains('/chat_attachments/')) {
      final file = File(raw);
      if (await file.exists()) return file;
    }

    String? fileName;
    final lower = raw.toLowerCase();
    if (lower.startsWith('/attachments/')) {
      fileName = raw.substring('/attachments/'.length);
    } else if (lower.startsWith('attachments/')) {
      fileName = raw.substring('attachments/'.length);
    } else if (!raw.contains('/') && raw.contains('.')) {
      fileName = raw;
    }

    if (fileName != null &&
        fileName.isNotEmpty &&
        !fileName.contains('..') &&
        !fileName.startsWith('/')) {
      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory(p.join(docs.path, 'chat_attachments'));
      if (await dir.exists()) {
        await for (final entity in dir.list(recursive: true, followLinks: false)) {
          if (entity is! File) continue;
          final base = p.basename(entity.path);
          if (base == fileName ||
              base.endsWith('_$fileName') ||
              base.endsWith(fileName)) {
            return entity;
          }
        }
      }
    }

    final root = await _workspace();
    return File(_resolveWorkspaceRelative(root, raw));
  }


  Directory _safeWorkspaceDirectory(Directory root, String relative) {
    return Directory(_resolveWorkspaceRelative(root, relative));
  }

  File _safeWorkspaceFile(Directory root, String relative) {
    return File(_resolveWorkspaceRelative(root, relative));
  }

  String _sanitizeHtmlPreview(String rawHtml, String baseUrl) {
    if (rawHtml.trim().isEmpty) return '';
    final document = html_parser.parse(rawHtml);
    for (final node in document.querySelectorAll(
      'script,noscript,iframe,object,embed,template,canvas,form,input,textarea,select,button,video,audio,source,track,meta[http-equiv="refresh"]',
    )) {
      node.remove();
    }
    final base = Uri.tryParse(baseUrl);
    for (final element in document.querySelectorAll('*')) {
      final unsafe = element.attributes.keys.where((name) {
        final normalizedName = name.toString().toLowerCase();
        return normalizedName.startsWith('on') || normalizedName == 'srcdoc';
      }).toList();
      for (final name in unsafe) {
        element.attributes.remove(name);
      }
      element.attributes.remove('autoplay');
      element.attributes.remove('srcdoc');
      if (base != null) {
        for (final attribute in const <String>['href', 'src', 'poster']) {
          final value = element.attributes[attribute];
          if (value == null || value.trim().isEmpty || value.startsWith('data:') || value.startsWith('#')) continue;
          final resolved = base.resolve(value);
          if (<String>{'http', 'https'}.contains(resolved.scheme)) {
            element.attributes[attribute] = resolved.toString();
          }
        }
      }
    }
    final output = document.outerHtml;
    if (output.length <= AppConfig.maxHtmlPreviewChars) return output;
    final title = document.querySelector('title')?.text.trim() ?? 'Pratonton halaman';
    final text = document.body?.text.replaceAll(RegExp(r'\s+'), ' ').trim() ?? '';
    final clipped = text.length <= AppConfig.maxHtmlPreviewChars
        ? text
        : '${text.substring(0, AppConfig.maxHtmlPreviewChars)}…';
    return '<article><h2>${const HtmlEscape().convert(title)}</h2><p>${const HtmlEscape().convert(clipped)}</p></article>';
  }

  ArtifactKind _artifactKindForPath(String path) {
    final extension = p.extension(path).toLowerCase();
    if (<String>{'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.heic', '.svg'}.contains(extension)) {
      return ArtifactKind.image;
    }
    if (<String>{'.mp4', '.mkv', '.mov', '.webm', '.m4v', '.avi'}.contains(extension)) {
      return ArtifactKind.video;
    }
    if (<String>{'.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac', '.opus'}.contains(extension)) {
      return ArtifactKind.audio;
    }
    if (<String>{'.html', '.htm'}.contains(extension)) return ArtifactKind.html;
    return ArtifactKind.file;
  }

  String _mimeForPath(String path) {
    return switch (p.extension(path).toLowerCase()) {
      '.png' => 'image/png',
      '.jpg' || '.jpeg' => 'image/jpeg',
      '.gif' => 'image/gif',
      '.webp' => 'image/webp',
      '.svg' => 'image/svg+xml',
      '.mp4' || '.m4v' => 'video/mp4',
      '.webm' => 'video/webm',
      '.mp3' => 'audio/mpeg',
      '.wav' => 'audio/wav',
      '.m4a' => 'audio/mp4',
      '.ogg' || '.opus' => 'audio/ogg',
      '.pdf' => 'application/pdf',
      '.json' => 'application/json',
      '.html' || '.htm' => 'text/html',
      '.md' => 'text/markdown',
      '.txt' || '.log' => 'text/plain',
      '.csv' => 'text/csv',
      '.zip' => 'application/zip',
      _ => 'application/octet-stream',
    };
  }

  String _safeFilename(String value) => value.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
  String _clip(String value) => value.length <= AppConfig.maxToolOutputChars ? value : '${value.substring(0, AppConfig.maxToolOutputChars)}…';
  String _shellQuote(String value) => "'${value.replaceAll("'", "'\\''")}'";

  Map<String, String> _browserHeaders({bool desktop = true}) =>
      <String, String>{
        'User-Agent': desktop
            ? 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Safari/537.36 AiMultiAgent/1.0.0'
            : 'Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Mobile Safari/537.36 '
                'AiMultiAgent/1.0.0',
        'Accept':
            'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
      };

  void dispose() {
    browserSession.dispose();
    terminalService.dispose();
    skillService.dispose();
    mcpService.dispose();
    _client.close();
  }
}
