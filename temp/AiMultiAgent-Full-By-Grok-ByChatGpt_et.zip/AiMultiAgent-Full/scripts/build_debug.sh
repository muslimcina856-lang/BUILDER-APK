#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
MOBILE="$ROOT/mobile"
APK="$MOBILE/build/app/outputs/flutter-apk/app-debug.apk"
RUNTIME="$MOBILE/assets/linux/full/runtime-pack.zip"
RUNTIME_SHA="$MOBILE/assets/linux/full/runtime-pack.sha256"
RUNTIME_ENTRY_SUFFIX="flutter_assets/assets/linux/full/runtime-pack.zip"

command -v python3 >/dev/null 2>&1 || {
  echo "Python 3 diperlukan untuk menyediakan Linux runtime." >&2
  exit 1
}
command -v flutter >/dev/null 2>&1 || {
  echo "Flutter SDK tidak ditemui." >&2
  exit 1
}
command -v unzip >/dev/null 2>&1 || {
  echo "unzip diperlukan untuk mengesahkan APK debug." >&2
  exit 1
}
command -v sha256sum >/dev/null 2>&1 || {
  echo "sha256sum diperlukan untuk mengesahkan asset Linux." >&2
  exit 1
}

# Debug Full mesti menggunakan runtime yang sama seperti release supaya ujian
# terminal tidak memberi keputusan palsu hanya kerana asset belum dibina.
python3 "$ROOT/scripts/linux/prepare_bundled_runtime.py"
python3 "$ROOT/scripts/linux/prepare_bundled_runtime.py" --verify-only
"$ROOT/scripts/check_project.sh"

cd "$MOBILE"
flutter pub get
flutter build apk --debug --target-platform android-arm64 --no-pub

[[ -s "$APK" ]] || {
  echo "APK debug tiada atau kosong: $APK" >&2
  exit 1
}
unzip -tq "$APK" >/dev/null
mapfile -t runtime_entries < <(unzip -Z1 "$APK" | awk -v suffix="$RUNTIME_ENTRY_SUFFIX" 'length($0) >= length(suffix) && substr($0, length($0) - length(suffix) + 1) == suffix' || true)
if [[ "${#runtime_entries[@]}" -ne 1 ]]; then
  echo "Linux runtime mesti muncul tepat sekali dalam APK debug: $APK" >&2
  exit 1
fi
EXPECTED_RUNTIME_SHA="$(awk 'NF {print $1; exit}' "$RUNTIME_SHA")"
[[ "$EXPECTED_RUNTIME_SHA" =~ ^[0-9a-fA-F]{64}$ ]] || {
  echo "Checksum runtime sumber tidak sah: $RUNTIME_SHA" >&2
  exit 1
}
embedded_runtime="$(mktemp)"
if ! unzip -p "$APK" "${runtime_entries[0]}" > "$embedded_runtime"; then
  rm -f "$embedded_runtime"
  echo "Gagal mengekstrak Linux runtime daripada APK debug." >&2
  exit 1
fi
EMBEDDED_RUNTIME_SHA="$(sha256sum "$embedded_runtime" | awk '{print $1}')"
if [[ "$EMBEDDED_RUNTIME_SHA" != "$EXPECTED_RUNTIME_SHA" ]]; then
  rm -f "$embedded_runtime"
  echo "Checksum Linux runtime dalam APK debug tidak sepadan." >&2
  exit 1
fi
python3 "$ROOT/scripts/linux/prepare_bundled_runtime.py" \
  --verify-only --output "$embedded_runtime" >/dev/null
rm -f "$embedded_runtime"

echo "APK debug Full siap dan runtime Linux terbenam telah disahkan: $APK"
