#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
MOBILE="$ROOT/mobile"
DIST="$ROOT/dist/full"
APK="$MOBILE/build/app/outputs/flutter-apk/app-release.apk"
AAB="$MOBILE/build/app/outputs/bundle/release/app-release.aab"
MAPPING="$MOBILE/build/app/outputs/mapping/release/mapping.txt"
RUNTIME="$MOBILE/assets/linux/full/runtime-pack.zip"
RUNTIME_SHA="$MOBILE/assets/linux/full/runtime-pack.sha256"
RUNTIME_MANIFEST="$MOBILE/assets/linux/full/runtime-manifest.json"
RUNTIME_ENTRY_SUFFIX="flutter_assets/assets/linux/full/runtime-pack.zip"

command -v python3 >/dev/null 2>&1 || {
  echo "Python 3 diperlukan untuk menyediakan Linux runtime." >&2
  exit 1
}
command -v flutter >/dev/null 2>&1 || {
  echo "Flutter SDK tidak ditemui." >&2
  exit 1
}
command -v unzip >/dev/null 2>&1 || {
  echo "unzip diperlukan untuk mengesahkan APK/AAB." >&2
  exit 1
}
command -v sha256sum >/dev/null 2>&1 || {
  echo "sha256sum diperlukan untuk mengesahkan asset Linux." >&2
  exit 1
}

# Release Full tidak dibenarkan dibina tanpa Linux sebenar. Skrip ini memuat
# turun sumber commit/version-pinned, mengesahkan Alpine SHA-256 dan PRoot
# ARM64, kemudian membina asset ZIP yang akan dimasukkan oleh Flutter.
python3 "$ROOT/scripts/linux/prepare_bundled_runtime.py"
python3 "$ROOT/scripts/linux/prepare_bundled_runtime.py" --verify-only
"$ROOT/scripts/check_project.sh"

rm -rf "$DIST"

cd "$MOBILE"
flutter pub get
flutter build apk --release --target-platform android-arm64 --no-pub
flutter build appbundle --release --target-platform android-arm64 --no-pub

EXPECTED_RUNTIME_SHA="$(awk 'NF {print $1; exit}' "$RUNTIME_SHA")"
[[ "$EXPECTED_RUNTIME_SHA" =~ ^[0-9a-fA-F]{64}$ ]] || {
  echo "Checksum runtime sumber tidak sah: $RUNTIME_SHA" >&2
  exit 1
}

for artifact in "$APK" "$AAB"; do
  [[ -s "$artifact" ]] || {
    echo "Artifact release tiada atau kosong: $artifact" >&2
    exit 1
  }
  unzip -tq "$artifact" >/dev/null
  mapfile -t runtime_entries < <(unzip -Z1 "$artifact" | awk -v suffix="$RUNTIME_ENTRY_SUFFIX" 'length($0) >= length(suffix) && substr($0, length($0) - length(suffix) + 1) == suffix' || true)
  if [[ "${#runtime_entries[@]}" -ne 1 ]]; then
    echo "Linux runtime mesti muncul tepat sekali dalam artifact: $artifact" >&2
    printf 'Entri ditemui: %s\n' "${runtime_entries[*]:-tiada}" >&2
    exit 1
  fi
  embedded_runtime="$(mktemp)"
  if ! unzip -p "$artifact" "${runtime_entries[0]}" > "$embedded_runtime"; then
    rm -f "$embedded_runtime"
    echo "Gagal mengekstrak Linux runtime daripada artifact: $artifact" >&2
    exit 1
  fi
  EMBEDDED_RUNTIME_SHA="$(sha256sum "$embedded_runtime" | awk '{print $1}')"
  if [[ "$EMBEDDED_RUNTIME_SHA" != "$EXPECTED_RUNTIME_SHA" ]]; then
    rm -f "$embedded_runtime"
    echo "Checksum Linux runtime dalam artifact tidak sepadan: $artifact" >&2
    exit 1
  fi
  python3 "$ROOT/scripts/linux/prepare_bundled_runtime.py" \
    --verify-only --output "$embedded_runtime" >/dev/null
  rm -f "$embedded_runtime"
done

[[ -s "$MAPPING" ]] || {
  echo "R8 mapping.txt tidak dijana: $MAPPING" >&2
  exit 1
}

mkdir -p "$DIST"
cp "$APK" "$DIST/AiMultiAgent-Full-arm64-release.apk"
cp "$AAB" "$DIST/AiMultiAgent-Full-arm64-release.aab"
cp "$MAPPING" "$DIST/mapping.txt"
cp "$RUNTIME" "$DIST/runtime-pack.zip"
cp "$RUNTIME_SHA" "$DIST/runtime-pack.sha256"
cp "$RUNTIME_MANIFEST" "$DIST/runtime-manifest.json"

cat > "$DIST/R8_STATUS.txt" <<'EOF'
R8 minify: enabled
Resource shrinking: enabled
mapping.txt: included
EOF

if command -v apksigner >/dev/null 2>&1; then
  apksigner verify --print-certs "$APK" > "$DIST/SIGNING_INFO.txt"
else
  printf '%s\n' \
    'apksigner tidak tersedia pada mesin build.' \
    'Semak tandatangan APK menggunakan apksigner verify --print-certs.' \
    > "$DIST/SIGNING_INFO.txt"
fi

(
  cd "$DIST"
  sha256sum \
    AiMultiAgent-Full-arm64-release.apk \
    AiMultiAgent-Full-arm64-release.aab \
    mapping.txt \
    runtime-pack.zip \
    runtime-manifest.json \
    > SHA256SUMS.txt
)

echo "Build Full siap dan disahkan: $DIST"
