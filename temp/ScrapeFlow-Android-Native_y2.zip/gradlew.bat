@echo off
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle executable not found. Install Gradle 8.9 or let your Android builder use its bundled Gradle.
exit /b 1
