# ScrapeFlow Android Native

Versi Android Native untuk builder yang hanya mengenali Android Native / Flutter / React Native dan seumpamanya.

## Jenis projek
- Android Native
- Java
- Gradle project
- Package: `com.scrapeflow.app`
- Minimum Android: API 24
- Compile / target SDK: 35

## Fungsi MVP
- WebView sebenar dan interaktif: tap, scroll, type, login.
- Scraping berasaskan CSS selector.
- Pagination melalui selector `Next`.
- Detect teks/elemen CAPTCHA atau human verification yang lazim.
- Bila verification muncul, automasi PAUSE dan WebView kekal di tangan pengguna.
- `Resume` memeriksa semula halaman dan sambung pada session/cookies yang sama.
- Simpan konfigurasi project melalui SharedPreferences.
- Export hasil kepada CSV menggunakan Android document picker.
- Local demo challenge di `app/src/main/assets/demo-target.html`.

## Ujian demo
1. Build dan buka app.
2. Tekan `Run` dengan config default.
3. Page 1 akan discrape.
4. Page 2 memaparkan verification dan scraper bertukar `PAUSED`.
5. Tick `I am not a robot` secara manual dalam WebView.
6. Tekan `Resume`.
7. Scraper sambung page 2 dan page 3 sehingga `DONE`.

## Penting
Aplikasi ini tidak cuba memecah atau memintas CAPTCHA secara automatik. Ia hanya menghentikan automasi dan memberi kawalan browser kepada pengguna untuk menyelesaikan verification secara manual.

## Import ke builder
Upload keseluruhan folder/ZIP projek ini. Di root projek terdapat:
- `settings.gradle`
- `build.gradle`
- `gradlew`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`

Struktur ini adalah projek Android Native Gradle standard.
