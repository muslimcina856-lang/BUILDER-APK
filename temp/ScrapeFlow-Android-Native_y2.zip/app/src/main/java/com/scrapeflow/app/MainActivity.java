package com.scrapeflow.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CREATE_CSV = 42;

    private WebView webView;
    private EditText urlInput;
    private TextView statusText, pagesText, itemsText, logText;
    private ScrollView logScroll;
    private Button runButton, resumeButton;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<ScrapedItem> items = new ArrayList<>();
    private SharedPreferences prefs;

    private boolean scraperRunning = false;
    private boolean pausedForManual = false;
    private int pageCount = 0;

    private String startUrl;
    private String itemSelector;
    private String titleSelector;
    private String priceSelector;
    private String nextSelector;
    private int maxPages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("scrapeflow", MODE_PRIVATE);
        bindViews();
        loadConfig();
        configureWebView();
        wireActions();
        webView.loadUrl(startUrl);
        log("READY", "Android WebView session initialized.");
    }

    private void bindViews() {
        webView = findViewById(R.id.webView);
        urlInput = findViewById(R.id.urlInput);
        statusText = findViewById(R.id.statusText);
        pagesText = findViewById(R.id.pagesText);
        itemsText = findViewById(R.id.itemsText);
        logText = findViewById(R.id.logText);
        logScroll = findViewById(R.id.logScroll);
        runButton = findViewById(R.id.runButton);
        resumeButton = findViewById(R.id.resumeButton);
    }

    private void loadConfig() {
        startUrl = prefs.getString("url", "file:///android_asset/demo-target.html?page=1");
        itemSelector = prefs.getString("item", ".product-card");
        titleSelector = prefs.getString("title", ".product-title");
        priceSelector = prefs.getString("price", ".price");
        nextSelector = prefs.getString("next", ".next");
        maxPages = prefs.getInt("max", 10);
        urlInput.setText(startUrl);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                urlInput.setText(url);
                if (scraperRunning && !pausedForManual) setStatus("LOADING", Color.rgb(154,112,255));
            }

            @Override public void onPageFinished(WebView view, String url) {
                urlInput.setText(url);
                CookieManager.getInstance().flush();
                if (scraperRunning && !pausedForManual) {
                    handler.postDelayed(() -> inspectCurrentPage(), 450);
                }
            }
        });
    }

    private void wireActions() {
        findViewById(R.id.backButton).setOnClickListener(v -> { if (webView.canGoBack()) webView.goBack(); });
        findViewById(R.id.reloadButton).setOnClickListener(v -> webView.reload());

        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            String u = urlInput.getText().toString().trim();
            if (!u.isEmpty()) webView.loadUrl(normalizeUrl(u));
            return true;
        });

        findViewById(R.id.projectButton).setOnClickListener(v -> showProjectDialog());
        findViewById(R.id.takeControlButton).setOnClickListener(v -> {
            scraperRunning = false;
            pausedForManual = true;
            webView.requestFocus(View.FOCUS_DOWN);
            setStatus("MANUAL", Color.rgb(245,200,76));
            resumeButton.setEnabled(true);
            log("MANUAL", "Browser handed to user. Tap, scroll or type directly in the WebView.");
            Toast.makeText(this, "Kawalan manual aktif", Toast.LENGTH_SHORT).show();
        });

        runButton.setOnClickListener(v -> startScrape());
        resumeButton.setOnClickListener(v -> resumeScrape());
        findViewById(R.id.exportButton).setOnClickListener(v -> exportCsv());
    }

    private void startScrape() {
        items.clear();
        pageCount = 0;
        itemsText.setText("0");
        pagesText.setText("0");
        scraperRunning = true;
        pausedForManual = false;
        resumeButton.setEnabled(false);
        setStatus("RUNNING", Color.rgb(85,217,139));
        log("INFO", "Starting scraper at " + startUrl);
        webView.loadUrl(startUrl);
    }

    private void resumeScrape() {
        pausedForManual = false;
        scraperRunning = true;
        resumeButton.setEnabled(false);
        setStatus("RUNNING", Color.rgb(85,217,139));
        log("INFO", "Manual step finished. Re-checking the current page...");
        inspectCurrentPage();
    }

    private void inspectCurrentPage() {
        if (!scraperRunning || pausedForManual) return;
        String js = buildInspectorScript();
        webView.evaluateJavascript(js, new ValueCallback<String>() {
            @Override public void onReceiveValue(String value) {
                try {
                    if (value == null || "null".equals(value)) throw new Exception("No result from page");
                    String decoded = new JSONArray("[" + value + "]").getString(0);
                    JSONObject result = new JSONObject(decoded);
                    if (result.optBoolean("challenge", false)) {
                        pauseForManual(result.optString("reason", "verification challenge"));
                        return;
                    }

                    JSONArray found = result.optJSONArray("items");
                    if (found != null) {
                        for (int i = 0; i < found.length(); i++) {
                            JSONObject o = found.getJSONObject(i);
                            items.add(new ScrapedItem(o.optString("title"), o.optString("price"), webView.getUrl()));
                        }
                    }
                    pageCount++;
                    pagesText.setText(String.valueOf(pageCount));
                    itemsText.setText(String.valueOf(items.size()));
                    log("INFO", "Page " + pageCount + " scraped · total items " + items.size());

                    String next = result.optString("next", "");
                    if (!next.isEmpty() && pageCount < maxPages) {
                        log("INFO", "Navigating to next page...");
                        webView.loadUrl(next);
                    } else {
                        finishScrape();
                    }
                } catch (Exception e) {
                    setStatus("ERROR", Color.rgb(255,107,107));
                    scraperRunning = false;
                    log("ERROR", e.getMessage() == null ? "Could not parse page result." : e.getMessage());
                }
            }
        });
    }

    private String buildInspectorScript() {
        return "(function(){try{" +
                "var txt=((document.body&&document.body.innerText)||'').toLowerCase();" +
                "var challenge=(txt.includes('verify you are human')||txt.includes('captcha')||txt.includes('are you a robot')||document.querySelector('[class*=captcha],[id*=captcha],iframe[src*=captcha],iframe[src*=challenge]'));" +
                "if(challenge){return JSON.stringify({challenge:true,reason:'CAPTCHA / verification detected'});}" +
                "var itemSel=" + JSONObject.quote(itemSelector) + ";" +
                "var titleSel=" + JSONObject.quote(titleSelector) + ";" +
                "var priceSel=" + JSONObject.quote(priceSelector) + ";" +
                "var nextSel=" + JSONObject.quote(nextSelector) + ";" +
                "var rows=[].slice.call(document.querySelectorAll(itemSel)).map(function(el){" +
                "var t=el.querySelector(titleSel),p=el.querySelector(priceSel);" +
                "return {title:t?t.innerText.trim():'',price:p?p.innerText.trim():''};});" +
                "var n=document.querySelector(nextSel);var next=n?(n.href||''):'';" +
                "return JSON.stringify({challenge:false,items:rows,next:next});" +
                "}catch(e){return JSON.stringify({challenge:false,items:[],next:'',error:String(e)});}})()";
    }

    private void pauseForManual(String reason) {
        scraperRunning = false;
        pausedForManual = true;
        resumeButton.setEnabled(true);
        setStatus("PAUSED", Color.rgb(245,200,76));
        log("WARN", reason + ". Scraper paused; WebView remains fully interactive.");
        Toast.makeText(this, "Verification dikesan — selesaikan secara manual", Toast.LENGTH_LONG).show();
    }

    private void finishScrape() {
        scraperRunning = false;
        pausedForManual = false;
        resumeButton.setEnabled(false);
        setStatus("DONE", Color.rgb(85,217,139));
        log("DONE", "Scraping completed · " + items.size() + " items collected.");
    }

    private void showProjectDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        form.setPadding(pad, dp(6), pad, dp(6));

        EditText url = field("Start URL", startUrl); form.addView(url);
        EditText item = field("Item selector", itemSelector); form.addView(item);
        EditText title = field("Title selector", titleSelector); form.addView(title);
        EditText price = field("Price selector", priceSelector); form.addView(price);
        EditText next = field("Next selector", nextSelector); form.addView(next);
        EditText max = field("Max pages", String.valueOf(maxPages)); max.setInputType(2); form.addView(max);

        new AlertDialog.Builder(this)
                .setTitle("Project configuration")
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, which) -> {
                    startUrl = normalizeUrl(url.getText().toString().trim());
                    itemSelector = item.getText().toString().trim();
                    titleSelector = title.getText().toString().trim();
                    priceSelector = price.getText().toString().trim();
                    nextSelector = next.getText().toString().trim();
                    try { maxPages = Math.max(1, Integer.parseInt(max.getText().toString().trim())); } catch (Exception e) { maxPages = 10; }
                    prefs.edit().putString("url", startUrl).putString("item", itemSelector).putString("title", titleSelector).putString("price", priceSelector).putString("next", nextSelector).putInt("max", maxPages).apply();
                    urlInput.setText(startUrl);
                    webView.loadUrl(startUrl);
                    log("INFO", "Project configuration saved.");
                }).show();
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setTextSize(13);
        e.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(5), 0, dp(5));
        e.setLayoutParams(lp);
        return e;
    }

    private void exportCsv() {
        if (items.isEmpty()) {
            Toast.makeText(this, "Belum ada data untuk dieksport", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/csv");
        i.putExtra(Intent.EXTRA_TITLE, "scrapeflow-export.csv");
        startActivityForResult(i, CREATE_CSV);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_CSV && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                StringBuilder csv = new StringBuilder("title,price,source\n");
                for (ScrapedItem item : items) {
                    csv.append(csv(item.title)).append(',').append(csv(item.price)).append(',').append(csv(item.source)).append('\n');
                }
                if (out != null) out.write(csv.toString().getBytes(StandardCharsets.UTF_8));
                log("DONE", "CSV exported.");
            } catch (Exception e) {
                log("ERROR", "CSV export failed: " + e.getMessage());
            }
        }
    }

    private String csv(String v) { return "\"" + (v == null ? "" : v.replace("\"", "\"\"")) + "\""; }
    private String normalizeUrl(String url) {
        if (url.startsWith("file://") || url.startsWith("http://") || url.startsWith("https://")) return url;
        return "https://" + url;
    }

    private void setStatus(String status, int color) {
        statusText.setText(status);
        statusText.setTextColor(color);
    }

    private void log(String level, String msg) {
        String time = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        logText.append("[" + time + "] [" + level + "] " + msg + "\n");
        logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private static class ScrapedItem {
        final String title, price, source;
        ScrapedItem(String title, String price, String source) { this.title = title; this.price = price; this.source = source; }
    }
}
