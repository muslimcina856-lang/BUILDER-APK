package com.mediacompressor.data

import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CompressionRepository @Inject constructor(
    private val historyDao: HistoryDao
) {
    fun getHistory(): Flow<List<CompressionHistoryEntity>> = historyDao.getAllHistory()

    suspend fun addLog(log: CompressionHistoryEntity): Long = historyDao.insertHistory(log)

    suspend fun deleteLog(log: CompressionHistoryEntity) = historyDao.deleteHistory(log)

    suspend fun clearHistory() = historyDao.clearAllHistory()
}
