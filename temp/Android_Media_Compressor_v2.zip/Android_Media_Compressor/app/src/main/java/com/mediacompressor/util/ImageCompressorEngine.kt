package com.mediacompressor.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ImageCompressorEngine @Inject constructor() {

    fun compressImage(
        context: Context,
        inputUri: Uri,
        outputFile: File,
        preset: CompressionPreset
    ): Boolean {
        var inputStream: InputStream? = null
        try {
            inputStream = context.contentResolver.openInputStream(inputUri)
            val options = BitmapFactory.Options()
            options.inJustDecodeBounds = true
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            var width = options.outWidth
            var height = options.outHeight

            // Configure Quality & Bounds based on presets
            val quality = when (preset) {
                CompressionPreset.HIGH_QUALITY -> 85
                CompressionPreset.BALANCED -> 70
                CompressionPreset.MAX_COMPRESSION -> 50
            }

            val maxDimension = when (preset) {
                CompressionPreset.HIGH_QUALITY -> 3072 // Max size cap
                CompressionPreset.BALANCED -> 1920
                CompressionPreset.MAX_COMPRESSION -> 1280
            }

            // Calculate Sample Size (scale factor)
            var sampleSize = 1
            while (width / sampleSize > maxDimension || height / sampleSize > maxDimension) {
                sampleSize *= 2
            }

            // Decode image with sample size
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
            }
            inputStream = context.contentResolver.openInputStream(inputUri)
            var bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
            inputStream?.close()

            if (bitmap == null) return false

            // Precise scaling if necessary
            if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
                val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
                val targetW: Int
                val targetH: Int
                if (bitmap.width > bitmap.height) {
                    targetW = maxDimension
                    targetH = (maxDimension / ratio).toInt()
                } else {
                    targetH = maxDimension
                    targetW = (maxDimension * ratio).toInt()
                }
                val scaledBitmap = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
                if (scaledBitmap != bitmap) {
                    bitmap.recycle()
                    bitmap = scaledBitmap
                }
            }

            // Compress to output stream
            FileOutputStream(outputFile).use { fos ->
                val format = Bitmap.CompressFormat.JPEG
                bitmap.compress(format, quality, fos)
                fos.flush()
            }
            bitmap.recycle()
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            inputStream?.close()
        }
    }
}
