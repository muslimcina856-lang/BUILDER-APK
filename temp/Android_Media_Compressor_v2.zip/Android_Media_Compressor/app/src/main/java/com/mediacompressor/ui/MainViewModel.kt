package com.mediacompressor.ui

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mediacompressor.data.CompressionHistoryEntity
import com.mediacompressor.data.CompressionRepository
import com.mediacompressor.domain.CompressImageUseCase
import com.mediacompressor.domain.CompressVideoUseCase
import com.mediacompressor.util.CompressionPreset
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface CompressionUiState {
    object Idle : CompressionUiState
    object Processing : CompressionUiState
    data class Success(val log: CompressionHistoryEntity) : CompressionUiState
    data class Error(val message: String) : CompressionUiState
}

@HiltViewModel
class MainViewModel @Inject constructor(
    private val repository: CompressionRepository,
    private val compressImageUseCase: CompressImageUseCase,
    private val compressVideoUseCase: CompressVideoUseCase
) : ViewModel() {

    val historyState: StateFlow<List<CompressionHistoryEntity>> = repository.getHistory()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    var uiState: CompressionUiState by mutableStateOf(CompressionUiState.Idle)
        private set

    var videoProgress: Float by mutableStateOf(0f)
        private set

    fun compressImage(context: Context, inputUri: Uri, preset: CompressionPreset) {
        viewModelScope.launch {
            uiState = CompressionUiState.Processing
            val result = compressImageUseCase.execute(context, inputUri, preset)
            uiState = result.fold(
                onSuccess = { CompressionUiState.Success(it) },
                onFailure = { CompressionUiState.Error(it.message ?: "Unknown error occurred") }
            )
        }
    }

    fun compressVideo(context: Context, inputUri: Uri, preset: CompressionPreset) {
        viewModelScope.launch {
            uiState = CompressionUiState.Processing
            videoProgress = 0f
            val result = compressVideoUseCase.execute(context, inputUri, preset) { progress ->
                videoProgress = progress
            }
            uiState = result.fold(
                onSuccess = { CompressionUiState.Success(it) },
                onFailure = { CompressionUiState.Error(it.message ?: "Unknown error occurred") }
            )
        }
    }

    fun deleteHistory(log: CompressionHistoryEntity) {
        viewModelScope.launch {
            repository.deleteLog(log)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun resetState() {
        uiState = CompressionUiState.Idle
        videoProgress = 0f
    }
}
