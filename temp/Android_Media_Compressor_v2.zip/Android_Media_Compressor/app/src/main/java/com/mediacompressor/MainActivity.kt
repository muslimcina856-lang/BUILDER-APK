package com.mediacompressor

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mediacompressor.ui.CompressionUiState
import com.mediacompressor.ui.MainViewModel
import com.mediacompressor.ui.home.HomeScreen
import com.mediacompressor.ui.preview.PreviewScreen
import com.mediacompressor.ui.theme.MediaCompressorTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MediaCompressorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val historyList by viewModel.historyState.collectAsState()
                    val uiState = viewModel.uiState
                    val context = LocalContext.current

                    Box(modifier = Modifier.fillMaxSize()) {
                        when (val state = uiState) {
                            is CompressionUiState.Idle -> {
                                HomeScreen(
                                    historyList = historyList,
                                    onCompressImage = { uri, preset ->
                                        viewModel.compressImage(context, uri, preset)
                                    },
                                    onCompressVideo = { uri, preset ->
                                        viewModel.compressVideo(context, uri, preset)
                                    },
                                    onViewDetail = { log ->
                                        // Simple navigation to detail view inside MainActivity state
                                        setContent {
                                            MediaCompressorTheme {
                                                PreviewScreen(log = log, onBack = {
                                                    viewModel.resetState()
                                                    recreate() // Recreate/reload base compose view
                                                })
                                            }
                                        }
                                    },
                                    onDeleteHistory = { viewModel.deleteHistory(it) },
                                    onClearHistory = { viewModel.clearHistory() }
                                )
                            }
                            is CompressionUiState.Processing -> {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        CircularProgressIndicator()
                                        Text("Processing compression...")
                                        if (viewModel.videoProgress > 0f) {
                                            Text("Progress: ${(viewModel.videoProgress * 100).toInt()}%")
                                        }
                                    }
                                }
                            }
                            is CompressionUiState.Success -> {
                                LaunchedEffectUnit {
                                    Toast.makeText(context, "Compression complete!", Toast.LENGTH_SHORT).show()
                                }
                                PreviewScreen(log = state.log, onBack = {
                                    viewModel.resetState()
                                })
                            }
                            is CompressionUiState.Error -> {
                                LaunchedEffectUnit {
                                    Toast.makeText(context, "Error: ${state.message}", Toast.LENGTH_LONG).show()
                                    viewModel.resetState()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Simple composable wrapper to run side effects exactly once
@Composable
fun LaunchedEffectUnit(action: () -> Unit) {
    androidx.compose.runtime.LaunchedEffect(Unit) {
        action()
    }
}
