package com.mediacompressor.ui.home

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mediacompressor.data.CompressionHistoryEntity
import com.mediacompressor.util.CompressionPreset
import java.text.DecimalFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    historyList: List<CompressionHistoryEntity>,
    onCompressImage: (Uri, CompressionPreset) -> Unit,
    onCompressVideo: (Uri, CompressionPreset) -> Unit,
    onViewDetail: (CompressionHistoryEntity) -> Unit,
    onDeleteHistory: (CompressionHistoryEntity) -> Unit,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var isVideoSelected by remember { mutableStateOf(false) }
    var showPresetDialog by remember { mutableStateOf(false) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            isVideoSelected = false
            showPresetDialog = true
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            isVideoSelected = true
            showPresetDialog = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Media Compressor MVP", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Summary Banner
            val totalSavedBytes = historyList.sumOf { it.originalSizeBytes - it.compressedSizeBytes }
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Total Space Saved",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Text(
                        text = formatFileSize(totalSavedBytes),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(
                    onClick = { imagePickerLauncher.launch("image/*") },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Compress Image")
                }
                Button(
                    onClick = { videoPickerLauncher.launch("video/*") },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Compress Video")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // History Label
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Compression History",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                if (historyList.isNotEmpty()) {
                    TextButton(onClick = onClearHistory) {
                        Text("Clear All", color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // History List
            if (historyList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No history available. Start compressing media to save storage!",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(historyList) { item ->
                        HistoryItem(
                            item = item,
                            onClick = { onViewDetail(item) },
                            onDelete = { onDeleteHistory(item) }
                        )
                    }
                }
            }
        }
    }

    // Preset Selection Dialog
    if (showPresetDialog && selectedUri != null) {
        AlertDialog(
            onDismissRequest = { showPresetDialog = false },
            title = { Text("Select Compression Preset") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose the level of compression optimization:")
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            showPresetDialog = false
                            if (isVideoSelected) {
                                onCompressVideo(selectedUri!!, CompressionPreset.HIGH_QUALITY)
                            } else {
                                onCompressImage(selectedUri!!, CompressionPreset.HIGH_QUALITY)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("High Quality (Perceptually Lossless)")
                    }
                    Button(
                        onClick = {
                            showPresetDialog = false
                            if (isVideoSelected) {
                                onCompressVideo(selectedUri!!, CompressionPreset.BALANCED)
                            } else {
                                onCompressImage(selectedUri!!, CompressionPreset.BALANCED)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Balanced (Recommended)")
                    }
                    Button(
                        onClick = {
                            showPresetDialog = false
                            if (isVideoSelected) {
                                onCompressVideo(selectedUri!!, CompressionPreset.MAX_COMPRESSION)
                            } else {
                                onCompressImage(selectedUri!!, CompressionPreset.MAX_COMPRESSION)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Maximum Compression")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPresetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun HistoryItem(
    item: CompressionHistoryEntity,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.originalFilename,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Preset: ${item.presetUsed} | Saved: ${(item.compressionRatio * 100).toInt()}%",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${formatFileSize(item.originalSizeBytes)} ➔ ${formatFileSize(item.compressedSizeBytes)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = onDelete) {
                Text("✕", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
        }
    }
}

fun formatFileSize(size: Long): String {
    if (size <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
    return DecimalFormat("#,##0.#").format(size / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
}
