package com.mediacompressor.util

enum class CompressionPreset {
    HIGH_QUALITY,   // Balanced visual quality, light compression
    BALANCED,       // Medium compression, minor resizing if large
    MAX_COMPRESSION // Aggressive file size reduction, max compression
}
