package com.mediacompressor.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "compression_history")
data class CompressionHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originalFilename: String,
    val originalPath: String,
    val compressedPath: String,
    val originalSizeBytes: Long,
    val compressedSizeBytes: Long,
    val compressionRatio: Double,
    val presetUsed: String,
    val timestamp: Long,
    val durationMs: Long
)
