package com.mediacompressor

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MediaCompressorApp : Application()
