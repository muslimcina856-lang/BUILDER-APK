package com.mediacompressor.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Query("SELECT * FROM compression_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<CompressionHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: CompressionHistoryEntity): Long

    @Delete
    suspend fun deleteHistory(history: CompressionHistoryEntity)

    @Query("DELETE FROM compression_history")
    suspend fun clearAllHistory()
}
