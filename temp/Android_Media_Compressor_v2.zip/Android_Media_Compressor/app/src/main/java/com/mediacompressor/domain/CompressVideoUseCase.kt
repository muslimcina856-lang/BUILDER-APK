package com.mediacompressor.domain

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.mediacompressor.data.CompressionHistoryEntity
import com.mediacompressor.data.CompressionRepository
import com.mediacompressor.util.CompressionPreset
import com.mediacompressor.util.VideoCompressorEngine
import java.io.File
import javax.inject.Inject

class CompressVideoUseCase @Inject constructor(
    private val repository: CompressionRepository,
    private val videoCompressorEngine: VideoCompressorEngine
) {
    suspend fun execute(
        context: Context,
        inputUri: Uri,
        preset: CompressionPreset,
        onProgress: (Float) -> Unit = {}
    ): Result<CompressionHistoryEntity> {
        val startTime = System.currentTimeMillis()
        try {
            // Get original file info
            val originalName = getFileName(context, inputUri) ?: "video_${System.currentTimeMillis()}.mp4"
            val originalSize = getFileSize(context, inputUri)

            // Setup output file in cache directory
            val cacheDir = context.cacheDir
            val nameWithoutExtension = originalName.substringBeforeLast(".")
            val extension = "mp4" // Compressed output is MP4
            val outputName = "${nameWithoutExtension}_compressed.$extension"
            val outputFile = File(cacheDir, outputName)

            // Perform video compression
            val success = videoCompressorEngine.compressVideo(context, inputUri, outputFile, preset, onProgress)
            if (!success) {
                return Result.failure(Exception("Video compression failed"))
            }

            val compressedSize = outputFile.length()
            val ratio = if (originalSize > 0) {
                (originalSize - compressedSize).toDouble() / originalSize.toDouble()
            } else {
                0.0
            }

            val duration = System.currentTimeMillis() - startTime

            val log = CompressionHistoryEntity(
                originalFilename = originalName,
                originalPath = inputUri.toString(),
                compressedPath = outputFile.absolutePath,
                originalSizeBytes = originalSize,
                compressedSizeBytes = compressedSize,
                compressionRatio = ratio,
                presetUsed = preset.name,
                timestamp = System.currentTimeMillis(),
                durationMs = duration
            )

            // Save to database
            repository.addLog(log)

            return Result.success(log)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index != -1) {
                        name = cursor.getString(index)
                    }
                }
            }
        }
        if (name == null) {
            name = uri.path?.let { path ->
                val cut = path.lastIndexOf('/')
                if (cut != -1) path.substring(cut + 1) else path
            }
        }
        return name
    }

    private fun getFileSize(context: Context, uri: Uri): Long {
        var size: Long = 0
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (index != -1) {
                        size = cursor.getLong(index)
                    }
                }
            }
        }
        if (size == 0L && uri.path != null) {
            val file = File(uri.path!!)
            if (file.exists()) {
                size = file.length()
            }
        }
        return size
    }
}
