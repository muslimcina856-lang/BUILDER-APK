package com.mediacompressor.ui.preview

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mediacompressor.data.CompressionHistoryEntity
import com.mediacompressor.ui.home.formatFileSize

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(
    log: CompressionHistoryEntity,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Compression Details", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    TextButton(onClick = onBack) {
                        Text("◀ Back", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Filename", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(log.originalFilename, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Original Size", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(formatFileSize(log.originalSizeBytes), fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Compressed Size", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(formatFileSize(log.compressedSizeBytes), fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Space Reclaimed", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    val saved = log.originalSizeBytes - log.compressedSizeBytes
                    Text("${formatFileSize(saved)} (${(log.compressionRatio * 100).toInt()}% saved)", fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Preset Used", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(log.presetUsed, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Duration", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${log.durationMs} ms", fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Output Path", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(log.compressedPath, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Side-by-side preview available locally in App Cache\nPath: ${log.compressedPath}",
                    modifier = Modifier.padding(24.dp)
                )
            }
        }
    }
}
