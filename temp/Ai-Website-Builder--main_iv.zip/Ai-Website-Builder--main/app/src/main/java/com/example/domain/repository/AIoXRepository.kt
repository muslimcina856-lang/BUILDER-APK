package com.example.domain.repository

import com.example.data.local.GeneratedWebsiteEntity
import com.example.data.local.ProviderConfigEntity
import kotlinx.coroutines.flow.Flow

interface AIoXRepository {
    fun getAllWebsites(): Flow<List<GeneratedWebsiteEntity>>
    suspend fun insertWebsite(website: GeneratedWebsiteEntity): Long
    suspend fun deleteWebsite(website: GeneratedWebsiteEntity)
    suspend fun clearHistory()

    fun getAllProviders(): Flow<List<ProviderConfigEntity>>
    fun getActiveProvider(): Flow<ProviderConfigEntity?>
    suspend fun getActiveProviderSync(): ProviderConfigEntity?
    suspend fun insertProvider(provider: ProviderConfigEntity)
    suspend fun updateProvider(provider: ProviderConfigEntity)
    suspend fun setActiveProvider(activeId: Int)
    
    suspend fun generateWebsiteHTML(prompt: String, systemPrompt: String, provider: ProviderConfigEntity, temperature: Double, maxTokens: Int, topP: Double): Pair<String, Int>
}
