package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.data.api.GeminiApi
import com.example.data.api.OpenAIApi
import com.example.data.local.AIoXDao
import com.example.data.local.AIoXDatabase
import com.example.data.local.ProviderConfigEntity
import com.example.data.repository.AIoXRepositoryImpl
import com.example.domain.repository.AIoXRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AIoXDatabase {
        val db = Room.databaseBuilder(
            context,
            AIoXDatabase::class.java,
            "aiox_database"
        ).fallbackToDestructiveMigration(true).build()
        
        // Populate default providers if needed
        CoroutineScope(Dispatchers.IO).launch {
            val dao = db.aioxDao()
            val existing = dao.getActiveProviderSync()
            if (existing == null) {
                dao.insertProvider(ProviderConfigEntity(1, "OPENROUTER", "OpenRouter", "https://openrouter.ai/api/v1", "", "openai/gpt-4o-mini", true))
                dao.insertProvider(ProviderConfigEntity(2, "GROQ", "Groq", "https://api.groq.com/openai/v1", "", "llama-3.3-70b-versatile", false))
                dao.insertProvider(ProviderConfigEntity(3, "GEMINI", "Gemini", "https://generativelanguage.googleapis.com/v1beta", "", "gemini-2.0-flash", false))
            }
        }
        return db
    }

    @Provides
    @Singleton
    fun provideAIoXDao(db: AIoXDatabase): AIoXDao {
        return db.aioxDao()
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        return OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofitBuilder(okHttpClient: OkHttpClient): Retrofit.Builder {
        val moshi = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
        return Retrofit.Builder()
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
    }

    @Provides
    @Singleton
    fun provideOpenAIApi(retrofitBuilder: Retrofit.Builder): OpenAIApi {
        // BaseUrl is dynamic, so we provide an arbitrary dummy here, but URL is actually passed in @Url
        return retrofitBuilder.baseUrl("https://dummy.com/").build().create(OpenAIApi::class.java)
    }

    @Provides
    @Singleton
    fun provideGeminiApi(retrofitBuilder: Retrofit.Builder): GeminiApi {
        return retrofitBuilder.baseUrl("https://dummy.com/").build().create(GeminiApi::class.java)
    }

    @Provides
    @Singleton
    fun provideAIoXRepository(
        dao: AIoXDao,
        openAIApi: OpenAIApi,
        geminiApi: GeminiApi
    ): AIoXRepository {
        return AIoXRepositoryImpl(dao, openAIApi, geminiApi)
    }
}
