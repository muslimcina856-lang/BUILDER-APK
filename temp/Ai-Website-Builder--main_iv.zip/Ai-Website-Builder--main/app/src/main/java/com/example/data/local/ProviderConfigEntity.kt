package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "provider_config")
data class ProviderConfigEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val providerType: String, // OPENROUTER, GROQ, GEMINI, CUSTOM
    val name: String,
    val baseUrl: String,
    val apiKey: String, // Encrypted in real-world, plain here or obfuscated
    val modelId: String,
    val isActive: Boolean
)
