package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.generate.GenerateScreen
import com.example.ui.screens.history.HistoryScreen
import com.example.ui.screens.settings.SettingsScreen

@Composable
fun AppNavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            SplashScreen(navController = navController)
        }
        composable("home") {
            HomeScreen(navController = navController)
        }
        composable("history") {
            HistoryScreen(navController = navController)
        }
        composable("settings") {
            SettingsScreen(navController = navController)
        }
        composable("generate/{prompt}") { backStackEntry ->
            val prompt = java.net.URLDecoder.decode(backStackEntry.arguments?.getString("prompt") ?: "", "UTF-8")
            GenerateScreen(navController = navController, prompt = prompt)
        }
    }
}
