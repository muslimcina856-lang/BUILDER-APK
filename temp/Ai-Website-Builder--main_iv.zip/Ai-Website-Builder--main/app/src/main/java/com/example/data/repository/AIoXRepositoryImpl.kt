package com.example.data.repository

import com.example.data.api.GeminiApi
import com.example.data.api.GeminiContent
import com.example.data.api.GeminiGenerationConfig
import com.example.data.api.GeminiPart
import com.example.data.api.GeminiRequest
import com.example.data.api.GeminiSystemInstruction
import com.example.data.api.OpenAIApi
import com.example.data.api.OpenAiMessage
import com.example.data.api.OpenAiRequest
import com.example.data.local.AIoXDao
import com.example.data.local.GeneratedWebsiteEntity
import com.example.data.local.ProviderConfigEntity
import com.example.domain.repository.AIoXRepository
import kotlinx.coroutines.flow.Flow

class AIoXRepositoryImpl(
    private val dao: AIoXDao,
    private val openAIApi: OpenAIApi,
    private val geminiApi: GeminiApi
) : AIoXRepository {
    override fun getAllWebsites(): Flow<List<GeneratedWebsiteEntity>> = dao.getAllWebsites()
    override suspend fun insertWebsite(website: GeneratedWebsiteEntity): Long = dao.insertWebsite(website)
    override suspend fun deleteWebsite(website: GeneratedWebsiteEntity) = dao.deleteWebsite(website)
    override suspend fun clearHistory() = dao.clearHistory()
    override fun getAllProviders(): Flow<List<ProviderConfigEntity>> = dao.getAllProviders()
    override fun getActiveProvider(): Flow<ProviderConfigEntity?> = dao.getActiveProvider()
    override suspend fun getActiveProviderSync(): ProviderConfigEntity? = dao.getActiveProviderSync()
    override suspend fun insertProvider(provider: ProviderConfigEntity) = dao.insertProvider(provider)
    override suspend fun updateProvider(provider: ProviderConfigEntity) = dao.updateProvider(provider)
    override suspend fun setActiveProvider(activeId: Int) = dao.setActiveProvider(activeId)

    override suspend fun generateWebsiteHTML(
        prompt: String,
        systemPrompt: String,
        provider: ProviderConfigEntity,
        temperature: Double,
        maxTokens: Int,
        topP: Double
    ): Pair<String, Int> {
        val baseUrl = provider.baseUrl.trimEnd('/')
        var requestUrl = baseUrl
        var resultHtml = ""
        var tokensUsed = 0

        if (provider.providerType == "GEMINI") {
            // Gemini API formatting
            val modelId = provider.modelId
            requestUrl = "$baseUrl/models/$modelId:generateContent?key=${provider.apiKey}"
            
            val request = GeminiRequest(
                contents = listOf(
                    GeminiContent(
                        role = "user",
                        parts = listOf(GeminiPart(text = prompt))
                    )
                ),
                systemInstruction = GeminiSystemInstruction(
                    parts = listOf(GeminiPart(text = systemPrompt))
                ),
                generationConfig = GeminiGenerationConfig(
                    temperature = temperature,
                    maxOutputTokens = maxTokens,
                    topP = topP
                )
            )
            
            val response = geminiApi.generateContent(requestUrl, request)
            resultHtml = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: ""
            tokensUsed = response.usageMetadata?.totalTokenCount ?: 0
        } else {
            // OpenAI Compatible formatting
            if (!requestUrl.endsWith("/chat/completions")) {
                requestUrl = "$requestUrl/chat/completions"
            }
            
            val request = OpenAiRequest(
                model = provider.modelId,
                messages = listOf(
                    OpenAiMessage(role = "system", content = systemPrompt),
                    OpenAiMessage(role = "user", content = prompt)
                ),
                temperature = temperature,
                maxTokens = maxTokens,
                topP = topP
            )
            
            val authHeader = "Bearer ${provider.apiKey}"
            val response = openAIApi.generateCompletion(requestUrl, authHeader, request)
            resultHtml = response.choices.firstOrNull()?.message?.content ?: ""
            tokensUsed = response.usage?.totalTokens ?: 0
        }

        return Pair(resultHtml, tokensUsed)
    }
}
