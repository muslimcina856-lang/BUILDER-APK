package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryPurple = Color(0xFF6750A4)
val PrimaryPurpleLight = Color(0xFFD0BCFF)
val PrimaryPurpleContainer = Color(0xFFEADDFF)
val OnPrimaryPurpleContainer = Color(0xFF21005D)

val BackgroundTint = Color(0xFFFDF7FF)
val SurfaceTint = Color(0xFFFFFFFF)
val SurfaceVariantTint = Color(0xFFF3EDF7)

val TextPrimary = Color(0xFF1D1B20)
val TextSecondary = Color(0xFF49454F)

val StatusGreen = Color(0xFF00A36C)

val OutlineColor = Color(0xFFE7E0EB)
val OutlineVariantColor = Color(0xFFD0BCFF)

val GradientBlueStart = Color(0xFF80DEEA)
val GradientBlueEnd = Color(0xFF0097A7)
