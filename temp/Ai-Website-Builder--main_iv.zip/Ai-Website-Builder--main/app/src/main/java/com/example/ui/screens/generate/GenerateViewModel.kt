package com.example.ui.screens.generate

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.GeneratedWebsiteEntity
import com.example.domain.repository.AIoXRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class GenerateUiState {
    data class Loading(val status: String = "Initializing...") : GenerateUiState()
    data class Success(val html: String) : GenerateUiState()
    data class Error(val message: String) : GenerateUiState()
}

@HiltViewModel
class GenerateViewModel @Inject constructor(
    private val repository: AIoXRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<GenerateUiState>(GenerateUiState.Loading())
    val uiState: StateFlow<GenerateUiState> = _uiState.asStateFlow()

    fun generate(prompt: String) {
        viewModelScope.launch {
            _uiState.value = GenerateUiState.Loading("Checking provider...")
            try {
                val provider = repository.getActiveProviderSync()
                if (provider == null) {
                    _uiState.value = GenerateUiState.Error("No active provider found. Please select an AI provider in Settings.")
                    return@launch
                }
                
                if (provider.apiKey.isBlank()) {
                    _uiState.value = GenerateUiState.Error("API Key is missing for ${provider.name}. Please update in Settings.")
                    return@launch
                }

                _uiState.value = GenerateUiState.Loading("Generating website with ${provider.name}...")
                
                val systemPrompt = """
                    You are an expert frontend web developer. Create a single, responsive, complete HTML file.
                    Include CSS in a <style> block and JS in a <script> block.
                    Use Tailwind CSS via CDN (https://cdn.tailwindcss.com) if styling is needed.
                    Use FontAwesome or Google Material Icons via CDN for icons.
                    Return ONLY raw HTML code without markdown formatting (do not wrap in ```html).
                """.trimIndent()
                
                val result = repository.generateWebsiteHTML(
                    prompt = prompt,
                    systemPrompt = systemPrompt,
                    provider = provider,
                    temperature = 0.7,
                    maxTokens = 4096,
                    topP = 0.95
                )

                // Clean the output in case it wrapped in markdown
                val html = result.first.replace("```html", "").replace("```", "").trim()
                
                // Save to History
                _uiState.value = GenerateUiState.Loading("Saving to history...")
                repository.insertWebsite(
                    GeneratedWebsiteEntity(
                        prompt = prompt,
                        generatedHtml = html,
                        providerUsed = provider.name,
                        modelUsed = provider.modelId,
                        tokensUsed = result.second,
                        createdAt = System.currentTimeMillis()
                    )
                )

                _uiState.value = GenerateUiState.Success(html)

            } catch (e: Exception) {
                _uiState.value = GenerateUiState.Error(e.localizedMessage ?: "An unexpected error occurred.")
            }
        }
    }
}
