package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AIoXDao {
    @Query("SELECT * FROM generated_website ORDER BY createdAt DESC")
    fun getAllWebsites(): Flow<List<GeneratedWebsiteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebsite(website: GeneratedWebsiteEntity): Long

    @Delete
    suspend fun deleteWebsite(website: GeneratedWebsiteEntity)

    @Query("DELETE FROM generated_website")
    suspend fun clearHistory()

    @Query("SELECT * FROM provider_config ORDER BY id ASC")
    fun getAllProviders(): Flow<List<ProviderConfigEntity>>

    @Query("SELECT * FROM provider_config WHERE isActive = 1 LIMIT 1")
    fun getActiveProvider(): Flow<ProviderConfigEntity?>
    
    @Query("SELECT * FROM provider_config WHERE isActive = 1 LIMIT 1")
    suspend fun getActiveProviderSync(): ProviderConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProvider(provider: ProviderConfigEntity)

    @Update
    suspend fun updateProvider(provider: ProviderConfigEntity)

    @Query("UPDATE provider_config SET isActive = (id = :activeId)")
    suspend fun setActiveProvider(activeId: Int)
}
