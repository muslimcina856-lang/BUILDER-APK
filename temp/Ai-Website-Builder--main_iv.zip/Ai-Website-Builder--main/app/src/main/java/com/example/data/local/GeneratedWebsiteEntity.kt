package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "generated_website")
data class GeneratedWebsiteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val prompt: String,
    val generatedHtml: String,
    val providerUsed: String,
    val modelUsed: String,
    val tokensUsed: Int,
    val createdAt: Long,
    val isFavorite: Boolean = false
)
