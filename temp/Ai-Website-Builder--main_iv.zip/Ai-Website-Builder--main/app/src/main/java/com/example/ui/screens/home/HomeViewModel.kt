package com.example.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.GeneratedWebsiteEntity
import com.example.domain.repository.AIoXRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: AIoXRepository
) : ViewModel() {

    private val _recentWebsites = MutableStateFlow<List<GeneratedWebsiteEntity>>(emptyList())
    val recentWebsites: StateFlow<List<GeneratedWebsiteEntity>> = _recentWebsites.asStateFlow()

    private val _activeProviderName = MutableStateFlow("Loading...")
    val activeProviderName: StateFlow<String> = _activeProviderName.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getAllWebsites().collect {
                _recentWebsites.value = it.take(5) // Just show recent 5
            }
        }
        viewModelScope.launch {
            repository.getActiveProvider().collect { provider ->
                _activeProviderName.value = provider?.name ?: "No active provider"
            }
        }
    }
}
