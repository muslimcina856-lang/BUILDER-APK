package com.example.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [GeneratedWebsiteEntity::class, ProviderConfigEntity::class], version = 1, exportSchema = false)
abstract class AIoXDatabase : RoomDatabase() {
    abstract fun aioxDao(): AIoXDao
}
