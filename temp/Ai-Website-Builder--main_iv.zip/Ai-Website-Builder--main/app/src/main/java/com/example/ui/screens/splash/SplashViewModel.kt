package com.example.ui.screens.splash

import androidx.lifecycle.ViewModel
import com.example.domain.repository.AIoXRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val repository: AIoXRepository
) : ViewModel() {
    // Logic for checking active provider
}
