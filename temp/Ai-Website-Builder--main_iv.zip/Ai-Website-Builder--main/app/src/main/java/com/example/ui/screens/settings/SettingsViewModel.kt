package com.example.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProviderConfigEntity
import com.example.domain.repository.AIoXRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: AIoXRepository
) : ViewModel() {

    private val _providers = MutableStateFlow<List<ProviderConfigEntity>>(emptyList())
    val providers: StateFlow<List<ProviderConfigEntity>> = _providers.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getAllProviders().collect {
                _providers.value = it
            }
        }
    }

    fun setActiveProvider(id: Int) {
        viewModelScope.launch {
            repository.setActiveProvider(id)
        }
    }

    fun updateProvider(provider: ProviderConfigEntity, apiKey: String, modelId: String, baseUrl: String) {
        viewModelScope.launch {
            repository.updateProvider(provider.copy(apiKey = apiKey, modelId = modelId, baseUrl = baseUrl))
        }
    }
}
