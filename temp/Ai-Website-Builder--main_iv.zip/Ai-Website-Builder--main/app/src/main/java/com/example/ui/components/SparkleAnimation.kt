package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SparkleAnimation(modifier: Modifier = Modifier) {
    Box(modifier = modifier) {
        val colors = listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.secondary,
            MaterialTheme.colorScheme.tertiary
        )

        val starConfigs = listOf(
            StarConfig(x = (-60).dp, y = (-70).dp, size = 24, color = colors[0], delayMs = 0),
            StarConfig(x = 80.dp, y = (-50).dp, size = 18, color = colors[1], delayMs = 300),
            StarConfig(x = (-90).dp, y = 40.dp, size = 14, color = colors[2], delayMs = 600),
            StarConfig(x = 70.dp, y = 70.dp, size = 28, color = colors[0], delayMs = 200),
            StarConfig(x = (-30).dp, y = 90.dp, size = 16, color = colors[1], delayMs = 800),
            StarConfig(x = 100.dp, y = 0.dp, size = 20, color = colors[2], delayMs = 500)
        )

        starConfigs.forEach { config ->
            Sparkle(config)
        }
    }
}

private data class StarConfig(
    val x: Dp,
    val y: Dp,
    val size: Int,
    val color: Color,
    val delayMs: Int
)

@Composable
private fun Sparkle(config: StarConfig) {
    val infiniteTransition = rememberInfiniteTransition(label = "SparklePulse")

    val scale by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, delayMillis = config.delayMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "StarScale"
    )

    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, delayMillis = config.delayMs, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "StarAlpha"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "StarRotation"
    )

    val yOffset by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, delayMillis = config.delayMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "StarYOffset"
    )

    Box(
        modifier = Modifier
            .offset(x = config.x, y = config.y + yOffset.dp)
            .scale(scale)
            .alpha(alpha)
            .graphicsLayer { rotationZ = rotation }
    ) {
        Text(
            text = "✦",
            fontSize = config.size.sp,
            color = config.color
        )
    }
}
