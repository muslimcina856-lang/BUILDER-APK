package com.example.ui.screens.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.GeneratedWebsiteEntity
import com.example.domain.repository.AIoXRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val repository: AIoXRepository
) : ViewModel() {

    private val _history = MutableStateFlow<List<GeneratedWebsiteEntity>>(emptyList())
    val history: StateFlow<List<GeneratedWebsiteEntity>> = _history.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getAllWebsites().collect {
                _history.value = it
            }
        }
    }

    fun delete(website: GeneratedWebsiteEntity) {
        viewModelScope.launch {
            repository.deleteWebsite(website)
        }
    }

    fun clearAll() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }
}
