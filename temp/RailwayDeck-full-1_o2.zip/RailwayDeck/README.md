# Railway Deck

**Unofficial Railway client for Android**

Arah semasa: **Embed / guna Railway CLI** di belakang (mengikut permintaan user).

---

## Status

### Sudah siap:
- Icon (yang user pilih)
- Multi-account UI + storage
- Semua screen utama
- **RailwayCli** helper (execute `railway` command)
- Login screen diubah ke arah CLI (`railway login`)
- FileUtils (unzip + zip)
- Deploy Bridge skeleton
- Dark theme + navigation

### Cara CLI berfungsi di Android:

Railway CLI **tiada official Android binary**.

Pilihan yang realistik:

1. **Termux (paling disyorkan)**
   - User install Termux
   - Dalam Termux: `pkg install` / install railway
   - App boleh call Termux atau share intent

2. **Embed binary arm64 (experimental)**
   - Download Railway CLI Linux arm64
   - Letak di `app/src/main/assets/cli/railway`
   - App extract + cuba execute
   - Sering gagal kerana missing shared libraries

3. **Login tetap buka browser**
   - Walaupun guna CLI, `railway login` masih OAuth + browser
   - Ini normal

---

## Cara buka

1. Extract ZIP
2. Buka dalam Android Studio
3. (Optional) Letak binary CLI di `app/src/main/assets/cli/railway`
4. Sync & Run

---

**Ini unofficial client.** Bukan aplikasi rasmi Railway.
