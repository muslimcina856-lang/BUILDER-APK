# Railway Deck ProGuard rules
-keepattributes *Annotation*
-keep class com.railway.deck.** { *; }
