package com.railway.deck.data.model

data class Account(
    val id: String,          // Railway "sub" (stable user ID)
    val email: String?,
    val alias: String,       // Nama yang user berikan (Personal, Store, dll)
    val isActive: Boolean = false
)
