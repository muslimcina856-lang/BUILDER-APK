package com.railway.deck.auth

import com.railway.deck.data.model.Account
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AccountManager @Inject constructor(
    private val tokenStore: TokenStore
) {
    companion object {
        private const val ACTIVE_ACCOUNT_KEY = "active_account_id"
    }

    fun getAllAccounts(): List<Account> {
        val ids = tokenStore.getAccountIds()
        val activeId = getActiveAccountId()

        return ids.map { id ->
            Account(
                id = id,
                email = tokenStore.getEmail(id),
                alias = tokenStore.getAlias(id) ?: tokenStore.getEmail(id) ?: "Account",
                isActive = id == activeId
            )
        }.sortedByDescending { it.isActive }
    }

    fun getActiveAccountId(): String? {
        return tokenStore.getActiveAccountId()
    }

    fun getActiveAccount(): Account? {
        val activeId = getActiveAccountId() ?: return null
        return Account(
            id = activeId,
            email = tokenStore.getEmail(activeId),
            alias = tokenStore.getAlias(activeId) ?: tokenStore.getEmail(activeId) ?: "Account",
            isActive = true
        )
    }

    fun setActiveAccount(accountId: String) {
        tokenStore.setActiveAccountId(accountId)
    }

    fun addAccount(
        accountId: String,
        accessToken: String,
        refreshToken: String?,
        email: String?,
        alias: String?
    ) {
        tokenStore.saveTokens(
            accountId = accountId,
            accessToken = accessToken,
            refreshToken = refreshToken,
            email = email,
            alias = alias
        )
        // Auto set as active bila baru tambah
        setActiveAccount(accountId)
    }

    fun removeAccount(accountId: String) {
        tokenStore.removeAccount(accountId)
        // Kalau yang dipadam adalah active, pilih yang lain
        if (getActiveAccountId() == accountId) {
            val remaining = tokenStore.getAccountIds()
            if (remaining.isNotEmpty()) {
                setActiveAccount(remaining.first())
            } else {
                tokenStore.clearActiveAccount()
            }
        }
    }

    fun hasAnyAccount(): Boolean = tokenStore.getAccountIds().isNotEmpty()

    fun updateAlias(accountId: String, newAlias: String) {
        tokenStore.updateAlias(accountId, newAlias)
    }
}
