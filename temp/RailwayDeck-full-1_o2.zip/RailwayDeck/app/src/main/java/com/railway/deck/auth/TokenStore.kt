package com.railway.deck.auth

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TokenStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "railway_deck_secure_tokens",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveTokens(
        accountId: String,
        accessToken: String,
        refreshToken: String?,
        email: String?,
        alias: String?
    ) {
        prefs.edit()
            .putString("access_$accountId", accessToken)
            .putString("refresh_$accountId", refreshToken)
            .putString("email_$accountId", email)
            .putString("alias_$accountId", alias ?: email)
            .apply()

        // Simpan list account
        val accounts = getAccountIds().toMutableSet()
        accounts.add(accountId)
        prefs.edit().putStringSet("account_ids", accounts).apply()
    }

    fun getAccessToken(accountId: String): String? =
        prefs.getString("access_$accountId", null)

    fun getRefreshToken(accountId: String): String? =
        prefs.getString("refresh_$accountId", null)

    fun getEmail(accountId: String): String? =
        prefs.getString("email_$accountId", null)

    fun getAlias(accountId: String): String? =
        prefs.getString("alias_$accountId", null)

    fun updateAlias(accountId: String, newAlias: String) {
        prefs.edit().putString("alias_$accountId", newAlias).apply()
    }

    fun getAccountIds(): Set<String> =
        prefs.getStringSet("account_ids", emptySet()) ?: emptySet()

    fun setActiveAccountId(accountId: String) {
        prefs.edit().putString("active_account_id", accountId).apply()
    }

    fun getActiveAccountId(): String? =
        prefs.getString("active_account_id", null)

    fun clearActiveAccount() {
        prefs.edit().remove("active_account_id").apply()
    }

    fun removeAccount(accountId: String) {
        prefs.edit()
            .remove("access_$accountId")
            .remove("refresh_$accountId")
            .remove("email_$accountId")
            .remove("alias_$accountId")
            .apply()

        val accounts = getAccountIds().toMutableSet()
        accounts.remove(accountId)
        prefs.edit().putStringSet("account_ids", accounts).apply()

        if (getActiveAccountId() == accountId) {
            clearActiveAccount()
        }
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
