package com.railway.deck.cli

import android.content.Context
import android.util.Log
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Railway CLI runner.
 * 
 * Arah baharu: guna Railway CLI di belakang (seperti permintaan user).
 * 
 * Nota penting:
 * - Railway CLI tiada official Android build.
 * - Cara paling stabil di Android = Termux.
 * - Alternatif: extract binary Linux arm64 (experimental, sering gagal kerana library).
 * 
 * Kelas ni sediakan interface untuk execute command `railway ...`
 */
class RailwayCli(private val context: Context) {

    companion object {
        private const val TAG = "RailwayCli"
        private const val BINARY_NAME = "railway"
    }

    private val cliDir: File by lazy {
        File(context.filesDir, "cli").also { it.mkdirs() }
    }

    private val binaryFile: File
        get() = File(cliDir, BINARY_NAME)

    /**
     * Semak sama ada binary sudah wujud.
     */
    fun isInstalled(): Boolean = binaryFile.exists() && binaryFile.canExecute()

    /**
     * Cuba extract binary dari assets (kalau ada).
     * User perlu letak binary arm64 di assets/cli/railway
     */
    fun installFromAssets(): Boolean {
        return try {
            if (isInstalled()) return true

            val assetPath = "cli/railway"
            context.assets.open(assetPath).use { input ->
                binaryFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            binaryFile.setExecutable(true, false)
            Log.i(TAG, "Railway CLI extracted to ${binaryFile.absolutePath}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to install CLI from assets", e)
            false
        }
    }

    /**
     * Execute railway command.
     * Contoh: run(listOf("whoami")) atau run(listOf("list"))
     */
    fun run(args: List<String>, timeoutSeconds: Long = 60): CliResult {
        if (!isInstalled()) {
            return CliResult(
                success = false,
                output = "",
                error = "Railway CLI belum dipasang. Letak binary di assets/cli/railway atau guna Termux."
            )
        }

        return try {
            val command = mutableListOf(binaryFile.absolutePath).apply { addAll(args) }
            val process = ProcessBuilder(command)
                .directory(cliDir)
                .redirectErrorStream(true)
                .start()

            val finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                return CliResult(false, "", "Command timeout")
            }

            val output = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val exitCode = process.exitValue()

            CliResult(
                success = exitCode == 0,
                output = output.trim(),
                error = if (exitCode != 0) output.trim() else null,
                exitCode = exitCode
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to run CLI", e)
            CliResult(false, "", e.message ?: "Unknown error")
        }
    }

    /** Shortcut commands */
    fun login(): CliResult = run(listOf("login"))
    fun whoami(): CliResult = run(listOf("whoami"))
    fun listProjects(): CliResult = run(listOf("list"))
    fun status(): CliResult = run(listOf("status"))
}

data class CliResult(
    val success: Boolean,
    val output: String,
    val error: String? = null,
    val exitCode: Int = -1
)
