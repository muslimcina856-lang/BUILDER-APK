# Owner App — Map

Internal control panel for the Earl Builder owner. Not intended for
Play Store distribution (sideload / internal use) — hence no R8/
ProGuard hardening here (see `user_app/MAP.md` for that side of things).

## What it does

Talks to `bot.py` (the Python backend) to manage users, credits,
redeemable codes, maintenance mode, and ads — nothing here builds or
touches APKs directly; that's the user app's job.

## Screens

| Screen | File | Does |
|---|---|---|
| Dashboard | `dashboard_screen.dart` | Home — quick stats, links to every screen below |
| User List | `user_list_screen.dart` | Search, select, bulk-delete users; copy a user's full device ID (needed to target an ad at them) |
| Add Credit | `add_credit_screen.dart` | Manually credit a user by device ID or Telegram ID |
| Generate Codes | `generate_code_screen.dart` | Create redeemable credit codes |
| Active Codes | `code_list_screen.dart` | Search, select, bulk-delete, copy active codes |
| Server Toggle | `server_toggle_screen.dart` | Maintenance on/off, custom title/message, background music URL for the user app's offline screen |
| Create Ad | `create_ad_screen.dart` | New ad — broadcast (no target) or aimed at one device/Telegram ID |
| Manage Ads | `ads_list_screen.dart` | Search, select, bulk-delete ads; see view counts against each ad's limit |
| About | `about_screen.dart` | App info, owner/channel links |

## Permissions used

| Permission | Why |
|---|---|
| `INTERNET` | Every screen talks to `bot.py` |
| `ACCESS_NETWORK_STATE` | Detect connectivity before showing network errors |
| `POST_NOTIFICATIONS` | Background-music-related local notifications (see `server_toggle_screen.dart`) |
| `WAKE_LOCK` | Keep audio-related background work running |

Nothing sensitive (no storage, camera, location, contacts).

## Dependencies (`pubspec.yaml`)

`dio` (HTTP), `shared_preferences` (local prefs), `url_launcher` (open
Telegram links), `share_plus` (share codes/text).

## Updating this app

1. Point `lib/services/api_service.dart`'s base URL at your `bot.py`
   deployment (same Cloudflare tunnel domain as the user app).
2. Everything else is plain Flutter — `flutter run` / `flutter build apk`
   as usual. There's no separate signing/release checklist here since
   this isn't published to a store.
