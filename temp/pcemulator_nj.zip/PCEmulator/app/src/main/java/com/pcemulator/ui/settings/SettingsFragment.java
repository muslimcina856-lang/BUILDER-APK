package com.pcemulator.ui.settings;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.pcemulator.BuildConfig;
import com.pcemulator.R;
import com.pcemulator.core.NativeLibManager;
import com.pcemulator.core.StorageManager;

public class SettingsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        NativeLibManager nlm = new NativeLibManager(requireContext());
        StorageManager sm = new StorageManager(requireContext());

        TextView tvVersion = view.findViewById(R.id.tv_version);
        TextView tvWineStatus = view.findViewById(R.id.tv_wine_status);
        TextView tvQemuStatus = view.findViewById(R.id.tv_qemu_status);
        TextView tvStorage = view.findViewById(R.id.tv_storage);
        TextView tvEngineSize = view.findViewById(R.id.tv_engine_size);
        View btnClearEngine = view.findViewById(R.id.btn_clear_engine);
        View btnAbout = view.findViewById(R.id.btn_about);

        tvVersion.setText("Version " + BuildConfig.VERSION_NAME);
        tvWineStatus.setText(nlm.isWineInstalled() ? "Installed" : "Not installed");
        tvQemuStatus.setText(nlm.isQemuInstalled() ? "Installed" : "Not installed");
        tvStorage.setText("Available: " + sm.getAvailableStorageDisplay());

        long engineBytes = nlm.getEngineSize();
        tvEngineSize.setText(engineBytes > 0
            ? (engineBytes / (1024 * 1024)) + " MB"
            : "0 MB");

        btnClearEngine.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                .setTitle("Clear Engine")
                .setMessage("Remove all downloaded engine files (Wine + QEMU)?")
                .setPositiveButton("Clear", (d, w) -> {
                    nlm.deleteEngine();
                    tvWineStatus.setText("Not installed");
                    tvQemuStatus.setText("Not installed");
                    tvEngineSize.setText("0 MB");
                    Toast.makeText(requireContext(), "Engine files cleared", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
        });

        btnAbout.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                .setTitle("PC Emulator for Android")
                .setMessage("Version " + BuildConfig.VERSION_NAME + "\n\n"
                    + "Run Windows applications and x86 OS on Android\n"
                    + "using Wine and QEMU.\n\n"
                    + "Engine: Wine 9.0 + QEMU 9.0\n"
                    + "Architecture: ARM64 / x86_64")
                .setPositiveButton("OK", null)
                .show();
        });
    }
}
