package com.pcemulator.core;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.pcemulator.ui.MainActivity;

import java.io.File;
import java.io.IOException;

public class EmulatorService extends Service {

    private static final String CHANNEL_ID = "pce_channel";
    private static boolean running = false;
    private Process emulatorProcess;

    public static boolean isRunning() { return running; }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        createChannel();
        startForeground(1, buildNotif("Initializing..."));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;

        String mode = intent.getStringExtra("mode");
        String containerPath = intent.getStringExtra("container_path");
        String exePath = intent.getStringExtra("exe_path");

        if ("wine".equals(mode)) {
            startWine(containerPath, exePath);
        }

        return START_STICKY;
    }

    private void startWine(String containerPath, String exePath) {
        updateNotif("Running...");
        try {
            File wineBin = new File(getFilesDir(), "engine/wine/bin/wine");
            if (!wineBin.exists()) {
                updateNotif("Wine not installed");
                return;
            }

            ProcessBuilder pb = new ProcessBuilder();
            if (containerPath != null) pb.directory(new File(containerPath));
            pb.environment().put("WINEPREFIX",
                containerPath != null ? containerPath : getFilesDir() + "/containers/default");
            pb.environment().put("WINEARCH", "win64");
            pb.environment().put("DISPLAY", ":0");
            pb.environment().put("LD_LIBRARY_PATH",
                getFilesDir() + "/engine/wine/lib:" + getFilesDir() + "/engine/wine/lib64");
            pb.environment().put("HOME", getFilesDir().getAbsolutePath());

            if (exePath != null && !exePath.isEmpty()) {
                pb.command(wineBin.getAbsolutePath(), exePath);
            } else {
                pb.command(wineBin.getAbsolutePath(), "winecfg");
            }

            emulatorProcess = pb.start();
            emulatorProcess.waitFor();
        } catch (IOException | InterruptedException e) {
            updateNotif("Error: " + e.getMessage());
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        if (emulatorProcess != null && emulatorProcess.isAlive()) {
            emulatorProcess.destroy();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "PC Emulator",
                NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private void updateNotif(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(1, buildNotif(text));
    }

    private Notification buildNotif(String text) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PC Emulator")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }
}
