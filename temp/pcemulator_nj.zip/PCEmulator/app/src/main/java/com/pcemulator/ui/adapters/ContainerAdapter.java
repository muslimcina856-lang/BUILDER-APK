package com.pcemulator.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pcemulator.R;
import com.pcemulator.model.Container;

import java.util.ArrayList;
import java.util.List;

public class ContainerAdapter extends RecyclerView.Adapter<ContainerAdapter.VH> {

    private final List<Container> list = new ArrayList<>();
    private final OnClick onClick;
    private final OnLongClick onLongClick;

    public interface OnClick { void onClick(Container c); }
    public interface OnLongClick { void onLongClick(Container c); }

    public ContainerAdapter(OnClick c, OnLongClick l) {
        this.onClick = c;
        this.onLongClick = l;
    }

    public void submitList(List<Container> containers) {
        list.clear();
        list.addAll(containers);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) {
        return new VH(LayoutInflater.from(p.getContext())
            .inflate(R.layout.item_container, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int i) {
        Container c = list.get(i);
        h.name.setText(c.getName());
        h.info.setText(c.getWineVersion() + " | " + c.getArch()
            + " | " + c.getSizeDisplay()
            + " | " + c.getInstalledApps().size() + " apps");
        h.itemView.setOnClickListener(v -> onClick.onClick(c));
        h.itemView.setOnLongClickListener(v -> {
            onLongClick.onLongClick(c);
            return true;
        });
    }

    @Override
    public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView name, info;
        VH(View v) { super(v);
            name = v.findViewById(R.id.tv_name);
            info = v.findViewById(R.id.tv_info);
        }
    }
}
