package com.pcemulator.ui.wine;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.pcemulator.R;
import com.pcemulator.core.ContainerManager;
import com.pcemulator.core.EmulatorService;
import com.pcemulator.model.Container;
import com.pcemulator.model.InstalledApp;
import com.pcemulator.ui.adapters.AppAdapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class WineAppFragment extends Fragment {

    private static final String ARG_CONTAINER_ID = "container_id";

    private ContainerManager containerManager;
    private Container container;
    private RecyclerView recyclerView;
    private AppAdapter adapter;
    private TextView tvContainerName, tvContainerInfo;

    private final androidx.activity.result.ActivityResultLauncher<String[]> filePicker =
        registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri == null || container == null) return;
            try {
                String fileName = getFileName(uri);
                if (fileName == null) fileName = "app.exe";
                if (!fileName.endsWith(".exe") && !fileName.endsWith(".msi")) {
                    fileName += ".exe";
                }

                File appsDir = new File(container.getPath(), "apps");
                appsDir.mkdirs();
                File dest = new File(appsDir, fileName);

                try (InputStream is = requireContext().getContentResolver().openInputStream(uri);
                     FileOutputStream os = new FileOutputStream(dest)) {
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = is.read(buf)) > 0) {
                        os.write(buf, 0, len);
                    }
                }

                String appName = fileName
                    .replace(".exe", "")
                    .replace(".msi", "")
                    .replace(".EXE", "")
                    .replace(".MSI", "");

                InstalledApp app = new InstalledApp(appName,
                    dest.getAbsolutePath(), container.getId());
                containerManager.addAppToContainer(container.getId(), app);
                refresh();
                Toast.makeText(requireContext(), "Added: " + app.getName(), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(requireContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    public static WineAppFragment newInstance(String containerId) {
        WineAppFragment f = new WineAppFragment();
        Bundle b = new Bundle();
        b.putString(ARG_CONTAINER_ID, containerId);
        f.setArguments(b);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_wine_apps, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        containerManager = new ContainerManager(requireContext());
        String cid = getArguments() != null ? getArguments().getString(ARG_CONTAINER_ID) : null;
        if (cid == null) return;
        container = containerManager.getContainer(cid);

        tvContainerName = view.findViewById(R.id.tv_container_name);
        tvContainerInfo = view.findViewById(R.id.tv_container_info);
        recyclerView = view.findViewById(R.id.rv_apps);
        Button btnAddApp = view.findViewById(R.id.btn_add_app);
        Button btnOpenWineCfg = view.findViewById(R.id.btn_winecfg);
        Button btnDeleteContainer = view.findViewById(R.id.btn_delete_container);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new AppAdapter(this::onAppClick, this::onAppLongClick);
        recyclerView.setAdapter(adapter);

        btnAddApp.setOnClickListener(v -> pickExe());
        btnOpenWineCfg.setOnClickListener(v -> openWineCfg());
        btnDeleteContainer.setOnClickListener(v -> deleteContainer());

        refresh();
    }

    private void refresh() {
        if (container != null) {
            container = containerManager.getContainer(container.getId());
            tvContainerName.setText(container.getName());
            tvContainerInfo.setText("Wine: " + container.getWineVersion()
                + " | " + container.getInstalledApps().size() + " apps"
                + " | " + container.getSizeDisplay());
            adapter.submitList(container.getInstalledApps());
        }
    }

    private void pickExe() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + requireContext().getPackageName()));
                startActivity(i);
                return;
            }
        }
        filePicker.launch(new String[]{"application/x-msdownload", "application/x-msi", "*/*"});
    }

    private String getFileName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (android.database.Cursor cursor = requireContext().getContentResolver()
                    .query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) name = cursor.getString(idx);
                }
            } catch (Exception ignored) {}
        }
        if (name == null) {
            name = uri.getLastPathSegment();
        }
        return name;
    }

    private void openWineCfg() {
        Intent intent = new Intent(requireContext(), EmulatorService.class);
        intent.putExtra("mode", "wine");
        intent.putExtra("container_path", container.getPath());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            requireContext().startForegroundService(intent);
        } else {
            requireContext().startService(intent);
        }
    }

    private void onAppClick(InstalledApp app) {
        Intent intent = new Intent(requireContext(), EmulatorService.class);
        intent.putExtra("mode", "wine");
        intent.putExtra("container_path", container.getPath());
        intent.putExtra("exe_path", app.getExePath());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            requireContext().startForegroundService(intent);
        } else {
            requireContext().startService(intent);
        }
    }

    private void onAppLongClick(InstalledApp app) {
        new AlertDialog.Builder(requireContext())
            .setTitle("Remove App")
            .setMessage("Remove " + app.getName() + "?")
            .setPositiveButton("Remove", (d, w) -> {
                containerManager.removeAppFromContainer(container.getId(), app);
                refresh();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void deleteContainer() {
        new AlertDialog.Builder(requireContext())
            .setTitle("Delete Container")
            .setMessage("Delete " + container.getName() + " permanently?")
            .setPositiveButton("Delete", (d, w) -> {
                containerManager.deleteContainer(container.getId());
                requireActivity().getSupportFragmentManager().popBackStack();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
