package com.pcemulator.core;

import android.content.Context;
import android.content.SharedPreferences;

import com.pcemulator.model.Container;
import com.pcemulator.model.InstalledApp;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ContainerManager {

    private static final String PREFS_NAME = "pce_containers";
    private final Context context;
    private final SharedPreferences prefs;
    private final File containersDir;

    public ContainerManager(Context context) {
        this.context = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.containersDir = new File(context.getFilesDir(), "containers");
        containersDir.mkdirs();
    }

    public Container createContainer(String name, String wineVersion, String arch) {
        String id = UUID.randomUUID().toString().substring(0, 8);
        File containerPath = new File(containersDir, id);
        containerPath.mkdirs();

        Container container = new Container(id, name, wineVersion, arch, containerPath.getAbsolutePath());
        saveContainer(container);
        return container;
    }

    public void deleteContainer(String id) {
        File containerPath = new File(containersDir, id);
        deleteRecursive(containerPath);
        prefs.edit().remove("c_" + id).apply();
        removeFromList(id);
    }

    public List<Container> getContainers() {
        List<Container> list = new ArrayList<>();
        try {
            String json = prefs.getString("list", "[]");
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                String cid = arr.getString(i);
                Container c = getContainer(cid);
                if (c != null) list.add(c);
            }
        } catch (Exception ignored) {}
        return list;
    }

    public Container getContainer(String id) {
        try {
            String json = prefs.getString("c_" + id, null);
            if (json != null) return fromJson(new JSONObject(json));
        } catch (Exception ignored) {}
        return null;
    }

    public void addAppToContainer(String containerId, InstalledApp app) {
        Container c = getContainer(containerId);
        if (c != null) {
            c.getInstalledApps().add(app);
            saveContainer(c);
        }
    }

    public void removeAppFromContainer(String containerId, InstalledApp app) {
        Container c = getContainer(containerId);
        if (c != null) {
            c.getInstalledApps().remove(app);
            saveContainer(c);
        }
    }

    private void saveContainer(Container c) {
        try {
            prefs.edit().putString("c_" + c.getId(), toJson(c).toString()).apply();
            addToList(c.getId());
        } catch (Exception ignored) {}
    }

    private void addToList(String id) {
        List<String> ids = getList();
        if (!ids.contains(id)) {
            ids.add(id);
            saveList(ids);
        }
    }

    private void removeFromList(String id) {
        List<String> ids = getList();
        ids.remove(id);
        saveList(ids);
    }

    private List<String> getList() {
        List<String> list = new ArrayList<>();
        try {
            String json = prefs.getString("list", "[]");
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                list.add(arr.getString(i));
            }
        } catch (Exception ignored) {}
        return list;
    }

    private void saveList(List<String> ids) {
        try {
            JSONArray arr = new JSONArray();
            for (String id : ids) arr.put(id);
            prefs.edit().putString("list", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private JSONObject toJson(Container c) throws Exception {
        JSONObject obj = new JSONObject();
        obj.put("id", c.getId());
        obj.put("name", c.getName());
        obj.put("wineVersion", c.getWineVersion());
        obj.put("arch", c.getArch());
        obj.put("createdDate", c.getCreatedDate());
        obj.put("sizeBytes", c.getSizeBytes());
        obj.put("path", c.getPath());

        JSONArray apps = new JSONArray();
        for (InstalledApp a : c.getInstalledApps()) {
            JSONObject ao = new JSONObject();
            ao.put("name", a.getName());
            ao.put("exePath", a.getExePath());
            ao.put("iconPath", a.getIconPath() != null ? a.getIconPath() : "");
            ao.put("containerId", a.getContainerId());
            ao.put("workingDir", a.getWorkingDir() != null ? a.getWorkingDir() : "");
            ao.put("arguments", a.getArguments() != null ? a.getArguments() : "");
            ao.put("useGPU", a.isUseGPU());
            apps.put(ao);
        }
        obj.put("installedApps", apps);
        return obj;
    }

    private Container fromJson(JSONObject obj) throws Exception {
        Container c = new Container(
            obj.getString("id"),
            obj.getString("name"),
            obj.getString("wineVersion"),
            obj.getString("arch"),
            obj.getString("path")
        );
        JSONArray apps = obj.optJSONArray("installedApps");
        if (apps != null) {
            for (int i = 0; i < apps.length(); i++) {
                JSONObject ao = apps.getJSONObject(i);
                InstalledApp app = new InstalledApp(
                    ao.getString("name"),
                    ao.getString("exePath"),
                    ao.getString("containerId")
                );
                app.setIconPath(ao.optString("iconPath", null));
                app.setWorkingDir(ao.optString("workingDir", ""));
                app.setArguments(ao.optString("arguments", ""));
                app.setUseGPU(ao.optBoolean("useGPU", true));
                c.addApp(app);
            }
        }
        return c;
    }

    private void deleteRecursive(File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File f : files) deleteRecursive(f);
            }
        }
        file.delete();
    }
}
