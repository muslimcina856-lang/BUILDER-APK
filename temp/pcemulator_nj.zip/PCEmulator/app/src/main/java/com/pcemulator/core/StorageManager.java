package com.pcemulator.core;

import android.content.Context;
import android.os.Build;
import android.os.Environment;

import java.io.File;

public class StorageManager {

    private final Context context;

    public StorageManager(Context context) {
        this.context = context;
    }

    public File getExternalDir() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return context.getExternalFilesDir(null);
        }
        return Environment.getExternalStorageDirectory();
    }

    public long getAvailableStorage() {
        File path = getExternalDir();
        return path != null ? path.getFreeSpace() : 0;
    }

    public String getAvailableStorageDisplay() {
        long bytes = getAvailableStorage();
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)) + " MB";
        return (bytes / (1024 * 1024 * 1024)) + " GB";
    }
}
