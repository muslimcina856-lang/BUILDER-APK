package com.pcemulator.model;

public class InstalledApp {
    private String name;
    private String exePath;
    private String iconPath;
    private String containerId;
    private String workingDir;
    private String arguments;
    private boolean useGPU;

    public InstalledApp(String name, String exePath, String containerId) {
        this.name = name;
        this.exePath = exePath;
        this.containerId = containerId;
        this.workingDir = "";
        this.arguments = "";
        this.useGPU = true;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getExePath() { return exePath; }
    public String getIconPath() { return iconPath; }
    public void setIconPath(String iconPath) { this.iconPath = iconPath; }
    public String getContainerId() { return containerId; }
    public String getWorkingDir() { return workingDir; }
    public void setWorkingDir(String wd) { this.workingDir = wd; }
    public String getArguments() { return arguments; }
    public void setArguments(String args) { this.arguments = args; }
    public boolean isUseGPU() { return useGPU; }
    public void setUseGPU(boolean gpu) { this.useGPU = gpu; }
}
