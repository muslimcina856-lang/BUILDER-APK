package com.pcemulator.core;

import android.content.Context;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class NativeLibManager {

    private final Context context;
    private final File baseDir;

    public NativeLibManager(Context context) {
        this.context = context;
        this.baseDir = new File(context.getFilesDir(), "engine");
        baseDir.mkdirs();
    }

    public boolean isWineInstalled() {
        return new File(baseDir, "wine/bin/wine").exists();
    }

    public boolean isQemuInstalled() {
        return new File(baseDir, "qemu/bin/qemu-system-x86_64").exists();
    }

    public interface DownloadCallback {
        void onProgress(int percent, String status);
        void onComplete(boolean success, String message);
    }

    public void downloadWine(DownloadCallback callback) {
        String arch = Build.SUPPORTED_ABIS[0];
        String url;
        if (arch.contains("arm64") || arch.contains("aarch64")) {
            url = "https://github.com/FreddyWenger/wine-android/releases/download/v9.0/wine-arm64.zip";
        } else if (arch.contains("arm")) {
            url = "https://github.com/FreddyWenger/wine-android/releases/download/v9.0/wine-arm.zip";
        } else {
            url = "https://github.com/FreddyWenger/wine-android/releases/download/v9.0/wine-x86_64.zip";
        }
        downloadAndExtract(url, "wine", callback);
    }

    public void downloadQemu(DownloadCallback callback) {
        String url = "https://github.com/termux/termux-packages/releases/download/qemu-system-x86-64-9.0.0/qemu-system-x86-64_9.0.0_aarch64.zip";
        downloadAndExtract(url, "qemu", callback);
    }

    private void downloadAndExtract(String url, String destDir, DownloadCallback callback) {
        new Thread(() -> {
            File tempFile = null;
            try {
                callback.onProgress(0, "Connecting...");
                File targetDir = new File(baseDir, destDir);
                targetDir.mkdirs();

                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setInstanceFollowRedirects(true);
                conn.connect();

                int totalSize = conn.getContentLength();
                tempFile = new File(baseDir, destDir + "_download.tmp");

                try (InputStream is = conn.getInputStream();
                     FileOutputStream fos = new FileOutputStream(tempFile)) {
                    byte[] buffer = new byte[8192];
                    int read;
                    long downloaded = 0;
                    while ((read = is.read(buffer)) != -1) {
                        fos.write(buffer, 0, read);
                        downloaded += read;
                        if (totalSize > 0) {
                            int pct = (int) ((downloaded * 100) / totalSize);
                            callback.onProgress(pct, "Downloading...");
                        }
                    }
                }

                callback.onProgress(0, "Extracting...");

                try (ZipInputStream zis = new ZipInputStream(new FileInputStream(tempFile))) {
                    ZipEntry ze;
                    byte[] buf = new byte[4096];
                    while ((ze = zis.getNextEntry()) != null) {
                        File entryFile = new File(targetDir, ze.getName());
                        if (ze.isDirectory()) {
                            entryFile.mkdirs();
                        } else {
                            entryFile.getParentFile().mkdirs();
                            try (FileOutputStream efos = new FileOutputStream(entryFile)) {
                                int len;
                                while ((len = zis.read(buf)) > 0) {
                                    efos.write(buf, 0, len);
                                }
                            }
                            String name = ze.getName();
                            if (name.startsWith("bin/") || name.endsWith(".so")
                                    || name.contains("/bin/")) {
                                entryFile.setExecutable(true);
                            }
                        }
                        zis.closeEntry();
                    }
                }

                if (tempFile.exists()) tempFile.delete();

                callback.onComplete(true, destDir + " installed successfully");
            } catch (Exception e) {
                if (tempFile != null && tempFile.exists()) tempFile.delete();
                callback.onComplete(false, "Failed: " + e.getMessage());
            }
        }).start();
    }

    public long getEngineSize() {
        return getDirSize(baseDir);
    }

    private long getDirSize(File dir) {
        long size = 0;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                size += f.isDirectory() ? getDirSize(f) : f.length();
            }
        }
        return size;
    }

    public void deleteEngine() {
        deleteRecursive(baseDir);
    }

    private void deleteRecursive(File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File f : files) deleteRecursive(f);
            }
        }
        file.delete();
    }
}
