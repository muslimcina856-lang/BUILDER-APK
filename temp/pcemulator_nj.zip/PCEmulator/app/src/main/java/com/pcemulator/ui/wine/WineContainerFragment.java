package com.pcemulator.ui.wine;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import com.pcemulator.R;
import com.pcemulator.core.ContainerManager;
import com.pcemulator.core.NativeLibManager;
import com.pcemulator.model.Container;
import com.pcemulator.ui.adapters.ContainerAdapter;

import java.util.List;

public class WineContainerFragment extends Fragment {

    private ContainerManager containerManager;
    private NativeLibManager nativeLibManager;
    private RecyclerView recyclerView;
    private ContainerAdapter adapter;
    private TextView tvEmpty, tvEngineStatus;
    private Button btnInstallEngine;
    private LinearProgressIndicator progressBar;
    private LinearLayout progressLayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_wine, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        containerManager = new ContainerManager(requireContext());
        nativeLibManager = new NativeLibManager(requireContext());

        recyclerView = view.findViewById(R.id.rv_containers);
        tvEmpty = view.findViewById(R.id.tv_empty);
        tvEngineStatus = view.findViewById(R.id.tv_engine_status);
        btnInstallEngine = view.findViewById(R.id.btn_install_engine);
        progressBar = view.findViewById(R.id.progress_bar);
        progressLayout = view.findViewById(R.id.progress_layout);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ContainerAdapter(this::onContainerClick, this::onContainerLongClick);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fabAdd = view.findViewById(R.id.fab_add);
        fabAdd.setOnClickListener(v -> showCreateDialog());

        btnInstallEngine.setOnClickListener(v -> installEngine());

        checkEngine();
        refreshList();
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshList();
    }

    private void checkEngine() {
        if (nativeLibManager.isWineInstalled()) {
            tvEngineStatus.setText("Wine engine: Installed");
            btnInstallEngine.setVisibility(View.GONE);
        } else {
            tvEngineStatus.setText("Wine engine: Not installed");
            btnInstallEngine.setVisibility(View.VISIBLE);
        }
    }

    private void installEngine() {
        progressLayout.setVisibility(View.VISIBLE);
        progressBar.setProgressCompat(0, true);
        btnInstallEngine.setEnabled(false);

        nativeLibManager.downloadWine(new NativeLibManager.DownloadCallback() {
            @Override
            public void onProgress(int percent, String status) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        progressBar.setProgressCompat(percent, true);
                        tvEngineStatus.setText(status + " " + percent + "%");
                    });
                }
            }

            @Override
            public void onComplete(boolean success, String message) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        progressLayout.setVisibility(View.GONE);
                        btnInstallEngine.setEnabled(true);
                        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show();
                        checkEngine();
                    });
                }
            }
        });
    }

    private void refreshList() {
        List<Container> containers = containerManager.getContainers();
        adapter.submitList(containers);
        boolean empty = containers.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private void showCreateDialog() {
        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_create_container, null);
        EditText etName = dialogView.findViewById(R.id.et_name);

        new AlertDialog.Builder(requireContext())
            .setTitle("New Container")
            .setView(dialogView)
            .setPositiveButton("Create", (d, w) -> {
                String name = etName.getText().toString().trim();
                if (name.isEmpty()) {
                    name = "Container " + (containerManager.getContainers().size() + 1);
                }
                containerManager.createContainer(name, "wine-9.0", "win64");
                refreshList();
                Toast.makeText(requireContext(), "Container created", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void onContainerClick(Container container) {
        WineAppFragment fragment = WineAppFragment.newInstance(container.getId());
        requireActivity().getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit();
    }

    private void onContainerLongClick(Container container) {
        new AlertDialog.Builder(requireContext())
            .setTitle("Delete Container")
            .setMessage("Delete " + container.getName() + "? All apps will be removed.")
            .setPositiveButton("Delete", (d, w) -> {
                containerManager.deleteContainer(container.getId());
                refreshList();
                Toast.makeText(requireContext(), "Deleted", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
