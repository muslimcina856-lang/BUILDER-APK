package com.pcemulator.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pcemulator.R;
import com.pcemulator.model.InstalledApp;

import java.util.ArrayList;
import java.util.List;

public class AppAdapter extends RecyclerView.Adapter<AppAdapter.VH> {

    private final List<InstalledApp> list = new ArrayList<>();
    private final OnClick onClick;
    private final OnLongClick onLongClick;

    public interface OnClick { void onClick(InstalledApp a); }
    public interface OnLongClick { void onLongClick(InstalledApp a); }

    public AppAdapter(OnClick c, OnLongClick l) {
        this.onClick = c;
        this.onLongClick = l;
    }

    public void submitList(List<InstalledApp> apps) {
        list.clear();
        list.addAll(apps);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) {
        return new VH(LayoutInflater.from(p.getContext())
            .inflate(R.layout.item_app, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int i) {
        InstalledApp a = list.get(i);
        h.name.setText(a.getName());
        h.info.setText(a.getExePath());
        h.itemView.setOnClickListener(v -> onClick.onClick(a));
        h.itemView.setOnLongClickListener(v -> {
            onLongClick.onLongClick(a);
            return true;
        });
    }

    @Override
    public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView name, info;
        VH(View v) { super(v);
            name = v.findViewById(R.id.tv_name);
            info = v.findViewById(R.id.tv_info);
        }
    }
}
