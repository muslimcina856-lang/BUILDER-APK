package com.pcemulator.model;

import java.util.ArrayList;
import java.util.List;

public class Container {
    private String id;
    private String name;
    private String wineVersion;
    private String arch;
    private long createdDate;
    private long sizeBytes;
    private String path;
    private List<InstalledApp> installedApps;

    public Container(String id, String name, String wineVersion, String arch, String path) {
        this.id = id;
        this.name = name;
        this.wineVersion = wineVersion;
        this.arch = arch;
        this.path = path;
        this.createdDate = System.currentTimeMillis();
        this.sizeBytes = 0;
        this.installedApps = new ArrayList<>();
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getWineVersion() { return wineVersion; }
    public void setWineVersion(String wv) { this.wineVersion = wv; }
    public String getArch() { return arch; }
    public long getCreatedDate() { return createdDate; }
    public long getSizeBytes() { return sizeBytes; }
    public void setSizeBytes(long size) { this.sizeBytes = size; }
    public String getPath() { return path; }
    public List<InstalledApp> getInstalledApps() { return installedApps; }

    public String getSizeDisplay() {
        if (sizeBytes < 1024) return sizeBytes + " B";
        if (sizeBytes < 1024 * 1024) return (sizeBytes / 1024) + " KB";
        if (sizeBytes < 1024 * 1024 * 1024) return (sizeBytes / (1024 * 1024)) + " MB";
        return (sizeBytes / (1024 * 1024 * 1024)) + " GB";
    }

    public void addApp(InstalledApp app) { installedApps.add(app); }
}
