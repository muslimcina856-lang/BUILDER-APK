package com.pcemulator.ui.vm;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import com.pcemulator.R;
import com.pcemulator.core.NativeLibManager;

import java.util.UUID;

public class VMListFragment extends Fragment {

    private NativeLibManager nativeLibManager;
    private TextView tvQemuStatus;
    private Button btnInstallQemu;
    private LinearProgressIndicator progressBar;
    private View progressLayout;
    private RecyclerView recyclerView;
    private View tvEmpty;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_vm, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        nativeLibManager = new NativeLibManager(requireContext());

        tvQemuStatus = view.findViewById(R.id.tv_qemu_status);
        btnInstallQemu = view.findViewById(R.id.btn_install_qemu);
        progressBar = view.findViewById(R.id.progress_bar);
        progressLayout = view.findViewById(R.id.progress_layout);
        tvEmpty = view.findViewById(R.id.tv_empty);
        recyclerView = view.findViewById(R.id.rv_vms);
        FloatingActionButton fabAdd = view.findViewById(R.id.fab_add_vm);

        checkQemu();

        btnInstallQemu.setOnClickListener(v -> installQemu());
        fabAdd.setOnClickListener(v -> showCreateVMDialog());
    }

    private void checkQemu() {
        if (nativeLibManager.isQemuInstalled()) {
            tvQemuStatus.setText("QEMU engine: Installed");
            btnInstallQemu.setVisibility(View.GONE);
        } else {
            tvQemuStatus.setText("QEMU engine: Not installed");
            btnInstallQemu.setVisibility(View.VISIBLE);
        }
    }

    private void installQemu() {
        progressLayout.setVisibility(View.VISIBLE);
        progressBar.setProgressCompat(0, true);
        btnInstallQemu.setEnabled(false);

        nativeLibManager.downloadQemu(new NativeLibManager.DownloadCallback() {
            @Override
            public void onProgress(int percent, String status) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        progressBar.setProgressCompat(percent, true);
                        tvQemuStatus.setText(status + " " + percent + "%");
                    });
                }
            }

            @Override
            public void onComplete(boolean success, String message) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        progressLayout.setVisibility(View.GONE);
                        btnInstallQemu.setEnabled(true);
                        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show();
                        checkQemu();
                    });
                }
            }
        });
    }

    private void showCreateVMDialog() {
        View dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_create_vm, null);
        EditText etName = dialogView.findViewById(R.id.et_vm_name);
        EditText etRam = dialogView.findViewById(R.id.et_ram);
        EditText etCores = dialogView.findViewById(R.id.et_cores);
        EditText etDisk = dialogView.findViewById(R.id.et_disk);

        new AlertDialog.Builder(requireContext())
            .setTitle("New Virtual Machine")
            .setView(dialogView)
            .setPositiveButton("Create", (d, w) -> {
                String name = etName.getText().toString().trim();
                if (name.isEmpty()) {
                    name = "VM-" + UUID.randomUUID().toString().substring(0, 4);
                }
                Toast.makeText(requireContext(),
                    "VM '" + name + "' created. Add ISO to boot.", Toast.LENGTH_LONG).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
