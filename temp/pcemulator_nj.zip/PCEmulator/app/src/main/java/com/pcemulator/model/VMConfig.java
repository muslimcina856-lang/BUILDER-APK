package com.pcemulator.model;

public class VMConfig {
    private String id;
    private String name;
    private int ramMB;
    private int cores;
    private String diskPath;
    private String cdromPath;
    private String networkType;
    private boolean enableGPU;
    private boolean enableAudio;
    private int diskSizeGB;

    public VMConfig(String id, String name) {
        this.id = id;
        this.name = name;
        this.ramMB = 2048;
        this.cores = 4;
        this.networkType = "user";
        this.enableGPU = true;
        this.enableAudio = true;
        this.diskSizeGB = 32;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getRamMB() { return ramMB; }
    public void setRamMB(int mb) { this.ramMB = mb; }
    public int getCores() { return cores; }
    public void setCores(int cores) { this.cores = cores; }
    public String getDiskPath() { return diskPath; }
    public void setDiskPath(String p) { this.diskPath = p; }
    public String getCdromPath() { return cdromPath; }
    public void setCdromPath(String p) { this.cdromPath = p; }
    public String getNetworkType() { return networkType; }
    public void setNetworkType(String nt) { this.networkType = nt; }
    public boolean isEnableGPU() { return enableGPU; }
    public void setEnableGPU(boolean gpu) { this.enableGPU = gpu; }
    public boolean isEnableAudio() { return enableAudio; }
    public void setEnableAudio(boolean a) { this.enableAudio = a; }
    public int getDiskSizeGB() { return diskSizeGB; }
    public void setDiskSizeGB(int gb) { this.diskSizeGB = gb; }
}
