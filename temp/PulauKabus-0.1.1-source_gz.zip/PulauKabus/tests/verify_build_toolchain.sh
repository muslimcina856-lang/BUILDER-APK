#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")/.." && pwd)"
root_build="$project_dir/build.gradle.kts"
app_build="$project_dir/app/build.gradle.kts"
wrapper="$project_dir/gradle/wrapper/gradle-wrapper.properties"

assert_contains() {
  local file="$1"
  local expected="$2"
  if ! grep -Fq "$expected" "$file"; then
    echo "GAGAL: $file tidak mengandungi: $expected" >&2
    exit 1
  fi
}

assert_contains "$root_build" 'version "8.9.2"'
assert_contains "$app_build" 'compileSdk = 35'
assert_contains "$app_build" 'targetSdk = 35'
assert_contains "$app_build" 'JavaVersion.VERSION_17'
assert_contains "$app_build" 'ndkVersion = "27.0.12077973"'
assert_contains "$wrapper" 'gradle-8.11.1-bin.zip'

echo "Konfigurasi binaan disahkan: AGP 8.9.2, Gradle 8.11.1, JDK 17, SDK 35."
