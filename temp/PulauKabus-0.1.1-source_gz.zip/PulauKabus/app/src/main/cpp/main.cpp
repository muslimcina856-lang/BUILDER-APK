#include "engine/AudioEngine.hpp"
#include "engine/InputController.hpp"
#include "engine/Renderer.hpp"
#include "engine/SaveSystem.hpp"
#include "game/GameWorld.hpp"

#include <android/log.h>
#include <android_native_app_glue.h>

#include <algorithm>
#include <chrono>
#include <memory>
#include <string>

namespace pk {

namespace {
constexpr const char* kTag = "PulauKabus";

struct Runtime {
    explicit Runtime(android_app* application)
        : app(application),
          saveSystem(std::make_unique<SaveSystem>(
              application->activity->internalDataPath != nullptr
                  ? application->activity->internalDataPath
                  : ".")) {
        WorldSnapshot stored{};
        if (saveSystem->load(stored)) world.restore(stored);
    }

    android_app* app = nullptr;
    GameWorld world{};
    InputController input{};
    Renderer renderer{};
    AudioEngine audio{};
    std::unique_ptr<SaveSystem> saveSystem;
    bool focused = false;
    bool paused = false;
    std::chrono::steady_clock::time_point lastFrame = std::chrono::steady_clock::now();

    void save() const {
        if (!saveSystem->save(world.snapshot())) {
            __android_log_print(ANDROID_LOG_WARN, kTag, "Save failed");
        }
    }
};

void handleCommand(android_app* app, int32_t command) {
    auto* runtime = static_cast<Runtime*>(app->userData);
    if (runtime == nullptr) return;
    switch (command) {
        case APP_CMD_INIT_WINDOW:
            if (app->window != nullptr && runtime->renderer.initialize(app->window, runtime->world)) {
                runtime->input.setViewport(runtime->renderer.width(), runtime->renderer.height());
                runtime->lastFrame = std::chrono::steady_clock::now();
            }
            break;
        case APP_CMD_TERM_WINDOW:
            runtime->save();
            runtime->renderer.shutdown();
            break;
        case APP_CMD_GAINED_FOCUS:
            runtime->focused = true;
            runtime->audio.start();
            runtime->lastFrame = std::chrono::steady_clock::now();
            break;
        case APP_CMD_LOST_FOCUS:
        case APP_CMD_PAUSE:
        case APP_CMD_STOP:
            runtime->focused = false;
            runtime->save();
            runtime->audio.stop();
            break;
        case APP_CMD_SAVE_STATE:
            runtime->save();
            break;
        default:
            break;
    }
}

int32_t handleInput(android_app* app, AInputEvent* event) {
    auto* runtime = static_cast<Runtime*>(app->userData);
    return runtime != nullptr && runtime->input.handleEvent(event) ? 1 : 0;
}

float nearestEnemyTension(const GameWorld& world) {
    float nearest = 20.0F;
    for (const EnemyState& enemy : world.enemies()) {
        if (enemy.alive) nearest = std::min(nearest, distanceXZ(enemy.position, world.player().position));
    }
    return clamp(1.0F - nearest / 9.0F, 0.0F, 1.0F);
}
}  // namespace

}  // namespace pk

void android_main(android_app* app) {
    app_dummy();
    pk::Runtime runtime(app);
    app->userData = &runtime;
    app->onAppCmd = pk::handleCommand;
    app->onInputEvent = pk::handleInput;
    ANativeActivity_setWindowFlags(app->activity,
                                   AWINDOW_FLAG_FULLSCREEN | AWINDOW_FLAG_KEEP_SCREEN_ON,
                                   0);

    while (app->destroyRequested == 0) {
        const int timeout = runtime.focused && runtime.renderer.ready() ? 0 : -1;
        int events = 0;
        android_poll_source* source = nullptr;
        int pollResult = 0;
        while ((pollResult = ALooper_pollOnce(timeout, nullptr, &events,
                                               reinterpret_cast<void**>(&source))) >= 0) {
            if (source != nullptr) source->process(app, source);
            if (app->destroyRequested != 0) break;
            if (timeout == 0) break;
        }
        if (!runtime.focused || !runtime.renderer.ready()) continue;

        const auto now = std::chrono::steady_clock::now();
        const float dt = std::chrono::duration<float>(now - runtime.lastFrame).count();
        runtime.lastFrame = now;
        pk::FrameInput frameInput = runtime.input.consumeFrame();
        if (frameInput.recenterPressed) {
            runtime.input.recenterCamera(runtime.world.player().facing);
            frameInput.cameraYaw = runtime.input.cameraYaw();
        }
        if (frameInput.pausePressed) {
            runtime.paused = !runtime.paused;
            if (runtime.paused) runtime.save();
        }
        if (!runtime.paused) runtime.world.update(std::clamp(dt, 0.0F, 0.05F), frameInput);
        for (const pk::GameEvent event : runtime.world.consumeEvents()) runtime.audio.trigger(event);
        runtime.audio.setTension(pk::nearestEnemyTension(runtime.world));
        runtime.renderer.render(runtime.world, runtime.input, runtime.paused);
    }

    runtime.save();
    runtime.audio.stop();
    runtime.renderer.shutdown();
}
