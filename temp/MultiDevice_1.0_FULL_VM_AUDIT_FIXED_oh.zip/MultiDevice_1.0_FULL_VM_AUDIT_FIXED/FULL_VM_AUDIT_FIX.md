# Multi Device — Full VM Audit / Phone Guest Fix

Tarikh: 2026-08-19
Versi projek dikekalkan: `1.0` / versionCode `1`.

## Apa yang dibaiki

1. **Portrait guest sebenar**
   - `DeviceConfig.width/height` kini dihantar ke `virtio-gpu-pci` sebagai `edid=on,xres=...,yres=...`.
   - Viewport Running VM ikut aspect ratio profile, bukan nisbah tetap 0.72.
   - Preset phone baharu dioptimumkan: Standard Phone = 720×1600 / 320 DPI; Large/Performance masih menyediakan 1080×2400.
   - Profile lama tidak ditukar nilainya secara automatik; resolusi yang sudah tersimpan kini benar-benar digunakan.

2. **Paparan QMP kurang berat**
   - QMP kini menggunakan satu sambungan persistent per endpoint, bukan greeting + `qmp_capabilities` bagi setiap frame/touch/key.
   - Sambungan rosak di-reset dan dicuba sekali lagi pada connection-level failure.
   - Capture interval diturunkan daripada 700 ms ke 350 ms.
   - Session QMP ditutup semasa VM tamat/force stop/crash.

3. **First Start tidak lagi patut menanggung full disk seed jika profile sempat disediakan**
   - Selepas Create Profile, writable guest disk disediakan di background dengan status `CREATING`.
   - Copy multi-GB kini dibuat ke fail `.part`, diperiksa saiznya, kemudian commit melalui rename dalam direktori yang sama.
   - Fail `.part` lama dibersihkan pada retry.
   - Jika process mati semasa prepare, profile pulih ke STOPPED pada launch seterusnya dan prepare boleh menyambung dengan selamat ketika Start.

4. **Tukar Android image tidak guna disk lama secara senyap**
   - Private profile state diikat kepada base image melalui `.image-id`.
   - Apabila image ditukar, working drives + UEFI vars dibina semula; snapshots berasingan tidak dipadam automatik.

5. **Catalog OS lebih luas / ringan**
   - GitHub releases request dinaikkan daripada 30 kepada 100 release records.
   - Catalog tidak berhenti selepas 8 varian pertama; sehingga 24 varian boleh dipaparkan.
   - ARM64-only dan varian Go (jika upstream menyediakannya) diberi keutamaan.
   - Parser turut menerima Lineage 15–23 (Android 8–16), jika release yang serasi memang wujud di upstream.

6. **Storage I/O guest**
   - Writable QEMU drives menggunakan `discard=unmap,detect-zeroes=unmap`.

7. **Background/session lifecycle**
   - Foreground VM service kini eksplisit `android:stopWithTask="false"`.
   - Process watcher membersihkan runtime/QMP/service sebaik QEMU mati sendiri, termasuk native crash atau VPN kill-switch.
   - Deliberate service stop dibezakan daripada service teardown luar untuk elak recursive emergency-stop.

8. **Guest bundle validation**
   - Bundle mesti ada salah satu boot path: direct kernel atau ARM64 UEFI.
   - `initrd` / kernel command line tidak diterima tanpa kernel.

9. **UI audit kecil**
   - Badge status Image Library bukan lagi butang palsu dengan callback kosong.
   - Butang Network pada Running VM kini membuka maklumat mode/MAC/DNS/kill-switch.
   - Verifier kini gagal jika `onClick = {}` kosong muncul semula dalam UI.

## Yang sengaja tidak dipalsukan / masih limitation

- **DPI dan refresh rate:** disimpan sebagai guest preference, tetapi backend QEMU generik ini tidak mempunyai cara universal untuk memaksa Android guest memakai nilai tersebut. Resolusi x/y kini benar-benar dihantar ke virtio-gpu; DPI/Hz tidak diklaim sebagai enforced.
- **Storage GB slider:** actual partition/virtual disk capacity masih bergantung pada guest image. Ia belum di-resize kerana qcow2 memerlukan tooling/flow resize yang berasingan.
- **VMOS-level smoothness:** display masih datang daripada QMP `screendump`, bukan shared-memory GPU/display stream. Persistent QMP + resolusi lebih ringan mengurangkan overhead, tetapi ia bukan pipeline 60 FPS.
- **Cold boot:** backend default masih QEMU TCG pada stock Android. Direct-kernel bundle memang disokong, tetapi Lineage UTM images yang diimport sekarang menggunakan UEFI/pflash.
- **AVF/pKVM:** capability scanner ada, tetapi projek ini belum mempunyai backend AVF/pKVM. Tiada claim hardware acceleration dibuat.

## Verification

- `python3 tools/verify_project.py` — PASS.
- Pure Kotlin `CoreSelfTest` — PASS.
- `QemuCommandBuilder` 720×1600 geometry micro-test — PASS.
- `QmpClient.kt` syntax compile dengan minimal platform stubs — PASS.
- Full Gradle/Android compile — belum dapat masuk fasa compilation kerana Gradle 8.7 distribution tiada secara lokal dan artifact environment tidak dapat resolve `services.gradle.org`.

## Fokus test pada telefon sebenar

1. Create profile dan tunggu status `CREATING` bertukar `STOPPED`.
2. Start Standard Phone; pastikan framebuffer 720×1600/portrait.
3. Rotate host portrait ↔ landscape; VM mesti terus hidup dan route kembali ke session yang sama.
4. Tekan Back/minimize/swipe task; ongoing VM notification/service patut kekal selagi OS/vendor tidak force-stop app.
5. Buka semula app; Open mesti attach session sedia ada, bukan launch QEMU kedua.
6. Cuba Network control; dialog info mesti muncul.
7. Uji lightweight ARM64-only image daripada Library jika tersedia.
