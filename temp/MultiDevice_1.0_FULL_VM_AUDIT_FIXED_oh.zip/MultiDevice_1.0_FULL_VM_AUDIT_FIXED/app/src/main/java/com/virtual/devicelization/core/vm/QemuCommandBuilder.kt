package com.virtual.devicelization.core.vm

import com.virtual.devicelization.core.image.GuestImageManifest
import com.virtual.devicelization.core.model.NetworkMode
import com.virtual.devicelization.core.model.Profile
import java.io.File

/**
 * Builds arguments for the local ARM64 QEMU runtime. Image-specific details live in manifest.json;
 * profile-specific resources/MAC/network remain owned by Multi Device.
 *
 * The embedded Android QEMU runtime is intentionally headless. Multi Device does not require QEMU's
 * VNC/SDL/GTK display backends; display capture and input are bridged through QMP instead.
 */
object QemuCommandBuilder {
    const val DEFAULT_QMP_PORT = 4444

    fun build(
        profile: Profile,
        image: GuestImageManifest,
        driveFiles: Map<String, File>,
        firmwareVarsFile: File? = null,
        qemuDataDir: File? = null,
        qmpPort: Int = DEFAULT_QMP_PORT,
    ): List<String> = buildList {
        require(qmpPort in 1024..65535) { "Invalid private QMP port: $qmpPort" }
        addAll(listOf(
            "-name", profile.name,
            "-machine", image.machine,
            "-cpu", image.cpu,
        ))
        // TCG is the universal stock-Android fallback. multi-thread + a larger TB cache are
        // materially better for ARM64 guests when KVM/AVF is unavailable to a normal app.
        if (!image.machine.contains("accel=", ignoreCase = true)) {
            addAll(listOf("-accel", "tcg,thread=multi,tb-size=512"))
        }
        qemuDataDir?.let { addAll(listOf("-L", it.absolutePath)) }
        addAll(listOf(
            "-smp", profile.device.cpuCores.coerceAtLeast(1).toString(),
            "-m", profile.device.ramMb.coerceAtLeast(512).toString(),
            // The runtime fetched by this project is a headless Android build. A primary graphical
            // console still exists for virtio-gpu and is captured with QMP screendump.
            "-display", "none",
            "-qmp", "tcp:127.0.0.1:$qmpPort,server=on,wait=off",
            "-no-reboot",
        ))

        if (image.firmwareCode != null && image.firmwareVars != null) {
            val code = image.resolve(image.firmwareCode)
            val vars = firmwareVarsFile ?: image.resolve(image.firmwareVars)
            addAll(listOf(
                "-drive", "if=pflash,unit=0,file=${code.absolutePath},format=raw,readonly=on",
                "-drive", "if=pflash,unit=1,file=${vars.absolutePath},format=raw",
            ))
        }

        image.kernel?.let { addAll(listOf("-kernel", image.resolve(it).absolutePath)) }
        image.initrd?.let { addAll(listOf("-initrd", image.resolve(it).absolutePath)) }
        image.kernelCmdline?.let { addAll(listOf("-append", it)) }

        image.drives.forEach { drive ->
            val file = driveFiles[drive.id] ?: image.resolve(drive.file)
            val options = buildString {
                append("file=").append(file.absolutePath)
                append(",format=").append(drive.format)
                append(",id=").append(drive.id)
                if (drive.qemuIf.isNotBlank()) append(",if=").append(drive.qemuIf)
                if (drive.readOnly) {
                    append(",readonly=on")
                } else {
                    append(",discard=unmap,detect-zeroes=unmap")
                }
            }
            addAll(listOf("-drive", options))
            drive.device?.let { device ->
                val deviceOptions = buildString {
                    append(device).append(",drive=").append(drive.id)
                    drive.bootIndex?.let { append(",bootindex=").append(it) }
                }
                addAll(listOf("-device", deviceOptions))
            }
        }

        when (profile.network.mode) {
            NetworkMode.OFFLINE -> addAll(listOf("-nic", "none"))
            NetworkMode.DIRECT_NAT,
            NetworkMode.ENCRYPTED_TUNNEL -> {
                // ENCRYPTED_TUNNEL is admitted only after LocalQemuVmBackend verifies that this
                // app's current default network is a host VPN. QEMU then uses normal user-mode NAT
                // and Android routes those host sockets through that VPN.
                addAll(listOf(
                    "-netdev", "user,id=mdnet0",
                    "-device", "virtio-net-pci,netdev=mdnet0,mac=${profile.network.virtualMac}",
                ))
            }
        }

        addAll(profileAwareExtraArgs(profile, image.extraArgs))
    }

    /**
     * Guest bundles own the display device model, while the profile owns its phone/tablet geometry.
     * QEMU virtio-gpu exposes EDID xres/yres properties, so inject the selected portrait/landscape
     * resolution without changing unrelated image arguments. DPI/refresh remain guest-OS policy.
     */
    private fun profileAwareExtraArgs(profile: Profile, args: List<String>): List<String> {
        if (args.isEmpty()) return args
        val out = ArrayList<String>(args.size)
        var index = 0
        while (index < args.size) {
            val arg = args[index]
            if (arg == "-device" && index + 1 < args.size && args[index + 1].startsWith("virtio-gpu")) {
                out += arg
                out += withDisplayGeometry(args[index + 1], profile.device.width, profile.device.height)
                index += 2
            } else {
                out += arg
                index++
            }
        }
        return out
    }

    private fun withDisplayGeometry(device: String, width: Int, height: Int): String {
        val safeWidth = width.coerceIn(320, 4096)
        val safeHeight = height.coerceIn(320, 4096)
        val parts = device.split(',')
        val kept = parts.drop(1).filterNot { option ->
            val key = option.substringBefore('=').lowercase()
            key == "xres" || key == "yres" || key == "edid"
        }
        return buildList {
            add(parts.first())
            addAll(kept)
            add("edid=on")
            add("xres=$safeWidth")
            add("yres=$safeHeight")
        }.joinToString(",")
    }
}
