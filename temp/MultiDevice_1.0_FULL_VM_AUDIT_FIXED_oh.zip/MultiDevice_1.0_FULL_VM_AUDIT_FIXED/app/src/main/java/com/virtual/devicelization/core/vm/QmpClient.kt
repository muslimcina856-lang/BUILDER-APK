package com.virtual.devicelization.core.vm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

/**
 * Loopback-only QMP client with one shared persistent session per QEMU endpoint.
 *
 * Display capture and input can issue several commands every second. Reusing the QMP connection
 * avoids repeating the greeting + qmp_capabilities handshake for every frame/key/touch while the
 * per-session monitor keeps all request/response transactions serialized.
 */
class QmpClient(
    private val host: String = "127.0.0.1",
    private val port: Int = QemuCommandBuilder.DEFAULT_QMP_PORT,
    private val timeoutMs: Int = 6_000,
) {
    suspend fun execute(command: String, arguments: JSONObject? = null): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val key = Endpoint(host, port)
            val session = sessions.computeIfAbsent(key) { Session(host, port, timeoutMs) }
            try {
                session.execute(command, arguments)
            } catch (io: IOException) {
                // Connection-level failure only: drop the stale socket and retry once on a fresh
                // QMP session. QMP command errors are not retried because some commands have effects.
                session.close()
                sessions.remove(key, session)
                val retry = Session(host, port, timeoutMs)
                sessions[key] = retry
                retry.execute(command, arguments)
            }
        }
    }

    suspend fun commandNames(): Result<Set<String>> = execute("query-commands").map { response ->
        val items: JSONArray = response.optJSONArray("return") ?: JSONArray()
        buildSet {
            for (i in 0 until items.length()) {
                val name = items.optJSONObject(i)?.optString("name").orEmpty()
                if (name.isNotBlank()) add(name)
            }
        }
    }

    suspend fun queryStatus(): Result<String> = execute("query-status").map { response ->
        response.optJSONObject("return")?.optString("status").orEmpty()
    }

    private data class Endpoint(val host: String, val port: Int)

    private class Session(
        private val host: String,
        private val port: Int,
        private val timeoutMs: Int,
    ) {
        private var socket: Socket? = null
        private var reader: BufferedReader? = null
        private var writer: OutputStreamWriter? = null

        @Synchronized
        @Throws(IOException::class)
        fun execute(command: String, arguments: JSONObject?): JSONObject {
            ensureConnected()
            val activeReader = reader ?: throw IOException("QMP reader is unavailable")
            val activeWriter = writer ?: throw IOException("QMP writer is unavailable")
            val request = JSONObject().put("execute", command)
            if (arguments != null) request.put("arguments", arguments)
            try {
                activeWriter.write(request.toString())
                activeWriter.write("\r\n")
                activeWriter.flush()
                val response = readUntilReturn(activeReader)
                throwIfError(response)
                return response
            } catch (t: Throwable) {
                if (t is QmpCommandException) throw t
                closeLocked()
                if (t is IOException) throw t
                throw IOException("QMP transaction failed: ${t.message ?: t.javaClass.simpleName}", t)
            }
        }

        @Synchronized
        fun close() = closeLocked()

        @Throws(IOException::class)
        private fun ensureConnected() {
            if (socket?.isConnected == true && socket?.isClosed == false && reader != null && writer != null) return
            closeLocked()
            val newSocket = Socket()
            try {
                newSocket.connect(InetSocketAddress(host, port), 1_500)
                newSocket.soTimeout = timeoutMs
                val newReader = BufferedReader(InputStreamReader(newSocket.getInputStream()))
                val newWriter = OutputStreamWriter(newSocket.getOutputStream())
                val greeting = newReader.readLine() ?: throw IOException("QMP greeting missing")
                val greetingJson = runCatching { JSONObject(greeting) }
                    .getOrElse { throw IOException("Invalid QMP greeting", it) }
                if (!greetingJson.has("QMP")) throw IOException("Invalid QMP greeting")

                newWriter.write("{\"execute\":\"qmp_capabilities\"}\r\n")
                newWriter.flush()
                val capabilities = readUntilReturn(newReader)
                throwIfError(capabilities)

                socket = newSocket
                reader = newReader
                writer = newWriter
            } catch (t: Throwable) {
                runCatching { newSocket.close() }
                if (t is QmpCommandException) throw t
                if (t is IOException) throw t
                throw IOException("Unable to establish QMP session: ${t.message ?: t.javaClass.simpleName}", t)
            }
        }

        private fun throwIfError(response: JSONObject) {
            if (response.has("error")) {
                val error = response.getJSONObject("error")
                throw QmpCommandException(error.optString("desc", error.toString()))
            }
        }

        @Throws(IOException::class)
        private fun readUntilReturn(reader: BufferedReader): JSONObject {
            while (true) {
                val line = reader.readLine() ?: throw IOException("QMP connection closed")
                val json = runCatching { JSONObject(line) }
                    .getOrElse { throw IOException("Invalid QMP response", it) }
                // QMP may interleave asynchronous events; only a command response ends this call.
                if (json.has("return") || json.has("error")) return json
            }
        }

        private fun closeLocked() {
            runCatching { reader?.close() }
            runCatching { writer?.close() }
            runCatching { socket?.close() }
            reader = null
            writer = null
            socket = null
        }
    }

    private class QmpCommandException(message: String) : IllegalStateException(message)

    companion object {
        private val sessions = ConcurrentHashMap<Endpoint, Session>()

        fun closeShared(port: Int, host: String = "127.0.0.1") {
            sessions.remove(Endpoint(host, port))?.close()
        }

        fun closeAllShared() {
            val open = sessions.values.toList()
            sessions.clear()
            open.forEach { it.close() }
        }
    }
}
