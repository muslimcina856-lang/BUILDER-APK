package com.virtual.devicelization.core.vm

import android.content.Context
import android.os.Build
import com.virtual.devicelization.core.image.GuestImageManifest
import com.virtual.devicelization.core.image.GuestImageStore
import com.virtual.devicelization.core.model.NetworkMode
import com.virtual.devicelization.core.model.Profile
import com.virtual.devicelization.core.network.HostVpnInspector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

/**
 * Fully local backend. No remote control server is required.
 *
 * The QEMU runtime is packaged as an ARM64 PIE executable named libqemu-system-aarch64.so under
 * jniLibs/arm64-v8a. Multi Device launches it with ProcessBuilder. The runtime is intentionally
 * headless; display capture, pointer/keyboard input and lifecycle controls use loopback-only QMP.
 */
class LocalQemuVmBackend(
    private val context: Context,
    private val images: GuestImageStore,
) : VmBackend {
    private data class PreparedVm(
        val profile: Profile,
        val image: GuestImageManifest,
        val driveFiles: Map<String, File>,
        val firmwareVarsFile: File?,
        val qemuDataDir: File,
    )

    private val assetInstaller = QemuAssetInstaller(context)
    private val vpnInspector = HostVpnInspector(context)
    @Volatile private var vpnGuardStop = false
    private var vpnGuardThread: Thread? = null
    private var process: Process? = null
    private var runningProfileId: String? = null
    private var currentQmpPort: Int? = null
    private var prepared: PreparedVm? = null
    private val runtimeLock = Any()
    @Volatile private var runtimeDeviceProbeError: String? = null
    @Volatile private var runtimeDeviceProbeDone = false

    private val runtimeFile: File
        get() = File(context.applicationInfo.nativeLibraryDir, RUNTIME_NAME)

    override fun status(): VmBackendStatus {
        val arm64 = Build.SUPPORTED_64_BIT_ABIS.any { it.equals("arm64-v8a", ignoreCase = true) }
        val runtime = runtimeFile
        val present = runtime.isFile && runtime.length() > 0
        val host = StockAndroidCapabilityScanner(context).scan()
        return VmBackendStatus(
            backendName = "Local QEMU headless/QMP engine",
            available = arm64 && present,
            arm64 = arm64,
            avfFeaturePresent = host.avfFeaturePresent,
            avfJavaApiPresent = host.avfJavaApiPresent,
            manageVmPermissionGranted = host.manageVmPermissionGranted,
            fullAndroidGuestSupported = arm64 && present,
            message = when {
                !arm64 -> "Local engine requires an ARM64 host."
                !present -> "Local engine runtime is not packaged yet: $RUNTIME_NAME"
                runtimeDeviceProbeDone && runtimeDeviceProbeError != null -> runtimeDeviceProbeError!!
                else -> "Local ARM64 QEMU engine is installed. Display/input are bridged locally through QMP."
            },
        )
    }

    override suspend fun prepare(profile: Profile): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val currentStatus = status()
            check(currentStatus.available) { currentStatus.message }
            check(runningProfileId == null || runningProfileId == profile.id) { "Another VM is already active." }
            if (profile.network.mode == NetworkMode.ENCRYPTED_TUNNEL) {
                check(vpnInspector.isVpnReady(profile.network.dnsProtection)) {
                    if (profile.network.dnsProtection) {
                        "Encrypted Tunnel requires an active Android VPN that includes Multi Device and exposes VPN DNS servers. Connect/configure your VPN first, then start this profile."
                    } else {
                        "Encrypted Tunnel requires an active Android VPN that includes Multi Device. Connect your VPN first, then start this profile."
                    }
                }
            }
            val image = images.findFor(profile)
                ?: error("No local Android ${profile.androidVersion} ARM64 image bundle is installed for this profile.")
            images.validate(image)?.let { error(it) }
            val qemuDataDir = assetInstaller.ensureInstalled()
            probeRuntimeDevices(qemuDataDir)?.let { error(it) }
            val driveFiles = images.prepareProfileDrives(profile, image)
            val firmwareVarsFile = images.prepareProfileFirmwareVars(profile, image)
            if (image.firmwareCode != null && image.firmwareVars != null) {
                val firmwareCode = image.resolve(image.firmwareCode)
                check(firmwareVarsFile != null && firmwareVarsFile.length() == firmwareCode.length()) {
                    "UEFI pflash geometry mismatch: code=${firmwareCode.length()} bytes, " +
                        "vars=${firmwareVarsFile?.length() ?: 0L} bytes."
                }
            }
            prepared = PreparedVm(profile, image, driveFiles, firmwareVarsFile, qemuDataDir)
        }
    }

    override suspend fun start(profile: Profile): Result<Unit> = withContext(Dispatchers.IO) {
        var serviceStartedThisAttempt = false
        var processStartedThisAttempt = false
        runCatching {
            check(process?.isAlive != true) { "A local QEMU process is already running." }
            val item = prepared?.takeIf { it.profile.id == profile.id }
                ?: error("Profile was not prepared.")
            val qmpPort = allocateLoopbackPort()
            val args = QemuCommandBuilder.build(
                item.profile,
                item.image,
                item.driveFiles,
                item.firmwareVarsFile,
                item.qemuDataDir,
                qmpPort,
            )
            val logDir = File(context.filesDir, "vm_logs").apply { mkdirs() }
            val log = File(logDir, "${profile.id}.log")
            val launcher = File(context.applicationInfo.nativeLibraryDir, LAUNCHER_NAME)
            val command = buildList {
                // The optional launcher sets PR_SET_PDEATHSIG so an OOM/app kill cannot orphan QEMU.
                if (launcher.isFile && launcher.length() > 0) add(launcher.absolutePath)
                add(runtimeFile.absolutePath)
                addAll(args)
            }
            log.appendText("\n\n=== Multi Device VM start ${System.currentTimeMillis()} ===\n")
            VmKeepAliveService.start(context, profile.name)
            serviceStartedThisAttempt = true
            val pb = ProcessBuilder(command)
                .directory(item.image.directory)
                .redirectErrorStream(true)
                .redirectOutput(ProcessBuilder.Redirect.appendTo(log))
            applyRuntimeEnvironment(pb)
            val launched = pb.start()
            process = launched
            processStartedThisAttempt = true
            runningProfileId = profile.id
            currentQmpPort = qmpPort
            startProcessWatcher(launched, profile.id, qmpPort)
            startVpnGuardIfNeeded(profile)

            // QMP is the one required local control/display/input transport. Do not require VNC:
            // the bundled Android QEMU runtime is deliberately headless and may be built without it.
            if (!waitForPort(qmpPort, 30_000)) {
                val p = process
                if (p?.isAlive == false) error(startupError("Local QEMU exited during startup.", log))
                error(startupError("Local QEMU started but its QMP control endpoint did not become ready in time.", log))
            }

            val qmp = QmpClient(port = qmpPort)
            val commands = qmp.commandNames().getOrElse { error ->
                throw IllegalStateException(startupError("QMP connected but command discovery failed: ${error.message}", log), error)
            }
            val missing = REQUIRED_QMP_COMMANDS - commands
            check(missing.isEmpty()) {
                startupError(
                    "The packaged QEMU runtime is missing required headless display/input commands: ${missing.sorted().joinToString()}.",
                    log,
                )
            }
            qmp.queryStatus().getOrElse { error ->
                throw IllegalStateException(startupError("QMP status probe failed: ${error.message}", log), error)
            }

            VmRuntimeState.activate(profile.id, qmpPort)
        }.onFailure {
            // A failed *new* start may be cleaned up, but a rejected duplicate start must never
            // destroy the QEMU process that was already running before this method was called.
            if (serviceStartedThisAttempt || processStartedThisAttempt) {
                stopVpnGuard()
                if (processStartedThisAttempt) process?.destroyForcibly()
                currentQmpPort?.let { QmpClient.closeShared(it) }
                process = null
                runningProfileId = null
                currentQmpPort = null
                prepared = null
                VmRuntimeState.clear(profile.id)
                if (serviceStartedThisAttempt) VmKeepAliveService.stop(context)
            }
        }
    }

    /** Suspend is a real QMP pause. The process/RAM still exists, so it remains the one active VM. */
    override suspend fun suspendVm(profile: Profile): Result<Unit> {
        requireRunning(profile)
        return qmpClient().execute("stop").map { Unit }
    }

    override suspend fun resume(profile: Profile): Result<Unit> {
        requireRunning(profile)
        return qmpClient().execute("cont").map { Unit }
    }

    override suspend fun shutdown(profile: Profile): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isRunning(profile.id)) return@runCatching
            val qmp = qmpClient()
            qmp.execute("system_powerdown")
            val p = process
            if (p != null && !p.waitFor(8, TimeUnit.SECONDS)) {
                qmp.execute("quit")
                if (!p.waitFor(3, TimeUnit.SECONDS)) p.destroy()
                if (!p.waitFor(2, TimeUnit.SECONDS)) p.destroyForcibly()
            }
            cleanupRuntime(profile.id)
        }
    }

    override suspend fun forceStop(profile: Profile): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (runningProfileId != profile.id) return@runCatching
            stopVpnGuard()
            process?.destroy()
            delay(250)
            if (process?.isAlive == true) process?.destroyForcibly()
            cleanupRuntime(profile.id)
        }
    }

    fun emergencyStop() {
        stopVpnGuard()
        val port = currentQmpPort
        runCatching { process?.destroyForcibly() }
        process = null
        runningProfileId = null
        currentQmpPort = null
        prepared = null
        if (port != null) QmpClient.closeShared(port)
        VmRuntimeState.clear()
        VmKeepAliveService.stop(context)
    }

    private fun cleanupRuntime(profileId: String) {
        stopVpnGuard()
        val port = currentQmpPort
        process = null
        runningProfileId = null
        currentQmpPort = null
        prepared = null
        if (port != null) QmpClient.closeShared(port)
        VmRuntimeState.clear(profileId)
        VmKeepAliveService.stop(context)
    }

    /**
     * QEMU can exit without a UI command (guest crash, VPN kill switch, native failure). Keep the
     * process-wide owner/service/QMP state honest immediately instead of waiting for a later UI poll.
     */
    private fun startProcessWatcher(launched: Process, profileId: String, qmpPort: Int) {
        Thread({
            runCatching { launched.waitFor() }
            var ownsRuntime = false
            synchronized(runtimeLock) {
                if (process === launched) {
                    process = null
                    runningProfileId = null
                    currentQmpPort = null
                    prepared = null
                    VmRuntimeState.clear(profileId)
                    ownsRuntime = true
                }
            }
            if (ownsRuntime) {
                stopVpnGuard()
                QmpClient.closeShared(qmpPort)
                VmKeepAliveService.stop(context)
            }
        }, "MultiDevice-QEMU-Watcher").apply { isDaemon = true; start() }
    }

    private fun startVpnGuardIfNeeded(profile: Profile) {
        stopVpnGuard()
        if (profile.network.mode != NetworkMode.ENCRYPTED_TUNNEL || !profile.network.killSwitch) return
        vpnGuardStop = false
        vpnGuardThread = Thread({
            while (!vpnGuardStop && process?.isAlive == true) {
                if (!vpnInspector.isVpnReady(profile.network.dnsProtection)) {
                    // Fail closed: with kill switch enabled, terminate QEMU before it can continue
                    // opening guest NAT sockets on the underlying physical network.
                    runCatching { process?.destroyForcibly() }
                    break
                }
                try { Thread.sleep(500) } catch (_: InterruptedException) { break }
            }
        }, "MultiDevice-VPN-Guard").apply { isDaemon = true; start() }
    }

    private fun stopVpnGuard() {
        vpnGuardStop = true
        vpnGuardThread?.interrupt()
        vpnGuardThread = null
    }

    override fun isRunning(profileId: String): Boolean =
        runningProfileId == profileId && process?.isAlive == true

    private fun requireRunning(profile: Profile) {
        check(isRunning(profile.id)) { "Profile ${profile.name} is not running." }
    }

    private fun qmpClient(): QmpClient {
        val port = currentQmpPort ?: VmRuntimeState.qmpPort ?: error("QMP endpoint is not active.")
        return QmpClient(port = port)
    }

    private suspend fun waitForPort(port: Int, timeoutMs: Long): Boolean {
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (process?.isAlive != true) return false
            val ok = runCatching {
                Socket().use { socket -> socket.connect(InetSocketAddress("127.0.0.1", port), 350) }
                true
            }.getOrDefault(false)
            if (ok) return true
            delay(200)
        }
        return false
    }

    private fun allocateLoopbackPort(): Int {
        return ServerSocket(0, 1, InetAddress.getByName("127.0.0.1")).use { it.localPort }
    }

    /**
     * Fast executable preflight. This catches a mismatched/minimal QEMU package before profile disks
     * are touched or a profile is persisted as ERROR.
     */
    private fun probeRuntimeDevices(qemuDataDir: File): String? {
        if (runtimeDeviceProbeDone) return runtimeDeviceProbeError
        synchronized(this) {
            if (runtimeDeviceProbeDone) return runtimeDeviceProbeError
            val result = runCatching {
                val probeLog = File(context.cacheDir, "qemu-device-probe.txt")
                runCatching { probeLog.delete() }
                val pb = ProcessBuilder(runtimeFile.absolutePath, "-L", qemuDataDir.absolutePath, "-device", "help")
                    .redirectErrorStream(true)
                    .redirectOutput(probeLog)
                applyRuntimeEnvironment(pb)
                val p = pb.start()
                if (!p.waitFor(8, TimeUnit.SECONDS)) {
                    p.destroyForcibly()
                    error("QEMU device capability probe timed out.")
                }
                val output = if (probeLog.isFile) probeLog.readText() else ""
                val missing = REQUIRED_QEMU_DEVICES.filterNot { output.contains(it, ignoreCase = true) }
                check(missing.isEmpty()) {
                    "The packaged QEMU runtime lacks required Android VM devices: ${missing.joinToString()}."
                }
            }
            runtimeDeviceProbeError = result.exceptionOrNull()?.message
            runtimeDeviceProbeDone = true
            return runtimeDeviceProbeError
        }
    }

    private fun applyRuntimeEnvironment(pb: ProcessBuilder) {
        pb.environment()["HOME"] = context.filesDir.absolutePath
        pb.environment()["TMPDIR"] = context.cacheDir.absolutePath
        pb.environment()["LD_LIBRARY_PATH"] = context.applicationInfo.nativeLibraryDir
    }

    private fun startupError(prefix: String, log: File): String {
        val tail = logTail(log)
        return buildString {
            append(prefix)
            if (tail.isNotBlank()) {
                append("\nQEMU: ")
                append(tail)
            }
            append("\nLog: ")
            append(log.absolutePath)
        }
    }

    private fun logTail(file: File, maxLines: Int = 8): String = runCatching {
        if (!file.isFile) return@runCatching ""
        file.useLines { lines -> lines.filter { it.isNotBlank() }.toList().takeLast(maxLines).joinToString(" | ") }
            .take(1400)
    }.getOrDefault("")

    companion object {
        const val RUNTIME_NAME = "libqemu-system-aarch64.so"
        const val LAUNCHER_NAME = "libmultidevice-launcher.so"

        private val REQUIRED_QMP_COMMANDS = setOf(
            "query-status",
            "query-commands",
            "screendump",
            "input-send-event",
            "send-key",
            "stop",
            "cont",
            "system_powerdown",
            "quit",
        )

        private val REQUIRED_QEMU_DEVICES = listOf(
            "virtio-blk-pci",
            "virtio-gpu-pci",
            "virtio-net-pci",
            "usb-ehci",
            "usb-tablet",
            "usb-kbd",
        )
    }
}
