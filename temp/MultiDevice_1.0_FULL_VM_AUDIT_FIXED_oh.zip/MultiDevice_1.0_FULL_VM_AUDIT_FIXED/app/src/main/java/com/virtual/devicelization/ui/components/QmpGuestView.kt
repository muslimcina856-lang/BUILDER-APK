package com.virtual.devicelization.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.virtual.devicelization.core.display.QmpDisplayClient
import com.virtual.devicelization.core.vm.QmpClient
import com.virtual.devicelization.core.vm.VmRuntimeState
import kotlinx.coroutines.runBlocking
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Live display/input surface for the headless local QEMU runtime using QMP only. */
class LocalQmpView(context: Context) : View(context) {
    private var framebuffer: Bitmap? = null
    private val destination = RectF()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(169, 182, 211)
        textAlign = Paint.Align.CENTER
        textSize = 16f * resources.displayMetrics.scaledDensity
    }
    private val running = AtomicBoolean(false)
    private var captureThread: Thread? = null
    private var inputExecutor: ExecutorService? = null
    @Volatile private var bridge: QmpDisplayClient? = null
    @Volatile private var statusText = "Waiting for local guest display…"
    private var pointerDown = false
    private var lastKeyboardRequest = 0

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startBridge()
    }

    override fun onDetachedFromWindow() {
        running.set(false)
        captureThread?.interrupt()
        captureThread = null
        inputExecutor?.shutdownNow()
        inputExecutor = null
        bridge = null
        framebuffer?.recycle()
        framebuffer = null
        super.onDetachedFromWindow()
    }

    private fun startBridge() {
        if (!running.compareAndSet(false, true)) return
        inputExecutor = Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "MultiDevice-QMP-Input").apply { isDaemon = true }
        }
        captureThread = Thread({ captureLoop() }, "MultiDevice-QMP-Display").apply {
            isDaemon = true
            start()
        }
    }

    private fun captureLoop() {
        var activePort: Int? = null
        while (running.get()) {
            try {
                val port = VmRuntimeState.qmpPort
                if (port == null) {
                    statusText = "Waiting for local QMP display…"
                    postInvalidate()
                    Thread.sleep(350)
                    continue
                }
                if (port != activePort || bridge == null) {
                    activePort = port
                    val dir = File(context.cacheDir, "qmp-display-$port").apply { mkdirs() }
                    bridge = QmpDisplayClient(QmpClient(port = port), dir)
                    statusText = "Connecting to Android display…"
                    postInvalidate()
                }

                val current = bridge ?: continue
                val captured = runBlocking { current.captureFrame() }
                captured.onSuccess { bitmap ->
                    post {
                        val old = framebuffer
                        framebuffer = bitmap
                        statusText = "Android guest display"
                        invalidate()
                        if (old != null && old !== bitmap && !old.isRecycled) old.recycle()
                    }
                }.onFailure { error ->
                    statusText = "Display waiting: ${error.message ?: "QMP not ready"}"
                    postInvalidate()
                }
                Thread.sleep(if (captured.isSuccess) FRAME_INTERVAL_MS else RETRY_INTERVAL_MS)
            } catch (_: InterruptedException) {
                break
            } catch (t: Throwable) {
                statusText = "Display waiting: ${t.message ?: t.javaClass.simpleName}"
                postInvalidate()
                try { Thread.sleep(RETRY_INTERVAL_MS) } catch (_: InterruptedException) { break }
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(3, 7, 18))
        val bitmap = framebuffer
        if (bitmap == null || bitmap.isRecycled) {
            canvas.drawText(statusText.take(80), width / 2f, height / 2f, textPaint)
            return
        }
        val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val drawW = bitmap.width * scale
        val drawH = bitmap.height * scale
        val left = (width - drawW) / 2f
        val top = (height - drawH) / 2f
        destination.set(left, top, left + drawW, top + drawH)
        canvas.drawBitmap(bitmap, null, destination, bitmapPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (destination.width() <= 0f || destination.height() <= 0f) return true
        val inside = event.x in destination.left..destination.right && event.y in destination.top..destination.bottom
        val nx = (((event.x - destination.left) / destination.width()) * QmpDisplayClient.ABS_MAX)
            .toInt().coerceIn(0, QmpDisplayClient.ABS_MAX)
        val ny = (((event.y - destination.top) / destination.height()) * QmpDisplayClient.ABS_MAX)
            .toInt().coerceIn(0, QmpDisplayClient.ABS_MAX)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> if (inside) {
                requestFocus()
                pointerDown = true
                queuePointer(nx, ny, true)
            }
            MotionEvent.ACTION_MOVE -> if (inside && pointerDown) queuePointer(nx, ny, null)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                queuePointer(nx, ny, false)
                pointerDown = false
            }
        }
        return true
    }

    private fun queuePointer(x: Int, y: Int, down: Boolean?) {
        val current = bridge ?: return
        inputExecutor?.execute { runBlocking { current.sendPointer(x, y, down) } }
    }

    fun showKeyboard(requestToken: Int = lastKeyboardRequest + 1) {
        if (requestToken <= lastKeyboardRequest) return
        lastKeyboardRequest = requestToken
        requestFocus()
        val imm = context.getSystemService(InputMethodManager::class.java)
        imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        outAttrs.imeOptions = EditorInfo.IME_ACTION_NONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        return object : BaseInputConnection(this, false) {
            private var composing = ""

            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val committed = text?.toString().orEmpty()
                if (committed != composing) {
                    if (composing.isNotEmpty()) repeat(composing.codePointCount(0, composing.length)) { queueQCodes(listOf("backspace")) }
                    if (committed.isNotEmpty()) sendText(committed)
                }
                composing = ""
                return true
            }

            override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
                val next = text?.toString().orEmpty()
                if (next.startsWith(composing)) {
                    sendText(next.substring(composing.length))
                } else {
                    repeat(composing.codePointCount(0, composing.length)) { queueQCodes(listOf("backspace")) }
                    sendText(next)
                }
                composing = next
                return true
            }

            override fun finishComposingText(): Boolean {
                composing = ""
                return true
            }

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                composing = ""
                repeat(beforeLength.coerceIn(0, 128)) { queueQCodes(listOf("backspace")) }
                repeat(afterLength.coerceIn(0, 128)) { queueQCodes(listOf("delete")) }
                return true
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean = handlePhysicalKey(event)
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = handlePhysicalKey(event)
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean = handlePhysicalKey(event)

    private fun handlePhysicalKey(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return true
        val base = androidKeyToQCode(event) ?: return false
        val keys = buildList {
            if (event.isCtrlPressed) add("ctrl")
            if (event.isAltPressed) add("alt")
            if (event.isShiftPressed && base != "shift") add("shift")
            add(base)
        }
        queueQCodes(keys)
        return true
    }

    private fun sendText(text: String) {
        text.forEach { char -> asciiQCodes(char)?.let(::queueQCodes) }
    }

    private fun queueQCodes(keys: List<String>) {
        val current = bridge ?: return
        inputExecutor?.execute { runBlocking { current.sendQCodes(keys) } }
    }

    private fun androidKeyToQCode(event: KeyEvent): String? = when (event.keyCode) {
        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> "ret"
        KeyEvent.KEYCODE_DEL -> "backspace"
        KeyEvent.KEYCODE_FORWARD_DEL -> "delete"
        KeyEvent.KEYCODE_TAB -> "tab"
        KeyEvent.KEYCODE_ESCAPE -> "esc"
        KeyEvent.KEYCODE_DPAD_LEFT -> "left"
        KeyEvent.KEYCODE_DPAD_UP -> "up"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
        KeyEvent.KEYCODE_DPAD_DOWN -> "down"
        KeyEvent.KEYCODE_MOVE_HOME -> "home"
        KeyEvent.KEYCODE_MOVE_END -> "end"
        KeyEvent.KEYCODE_PAGE_UP -> "pgup"
        KeyEvent.KEYCODE_PAGE_DOWN -> "pgdn"
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "shift"
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "ctrl"
        KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT -> "alt"
        in KeyEvent.KEYCODE_A..KeyEvent.KEYCODE_Z -> ('a'.code + event.keyCode - KeyEvent.KEYCODE_A).toChar().toString()
        in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> ('0'.code + event.keyCode - KeyEvent.KEYCODE_0).toChar().toString()
        else -> event.unicodeChar.takeIf { it in 0x20..0x7e }?.toChar()?.let { asciiQCodes(it)?.lastOrNull() }
    }

    private fun asciiQCodes(char: Char): List<String>? {
        if (char in 'a'..'z') return listOf(char.toString())
        if (char in 'A'..'Z') return listOf("shift", char.lowercaseChar().toString())
        if (char in '0'..'9') return listOf(char.toString())
        return when (char) {
            ' ' -> listOf("spc")
            '\n', '\r' -> listOf("ret")
            '\t' -> listOf("tab")
            '-' -> listOf("minus")
            '_' -> listOf("shift", "minus")
            '=' -> listOf("equal")
            '+' -> listOf("shift", "equal")
            '[' -> listOf("bracket_left")
            '{' -> listOf("shift", "bracket_left")
            ']' -> listOf("bracket_right")
            '}' -> listOf("shift", "bracket_right")
            ';' -> listOf("semicolon")
            ':' -> listOf("shift", "semicolon")
            '\'' -> listOf("apostrophe")
            '"' -> listOf("shift", "apostrophe")
            '`' -> listOf("grave_accent")
            '~' -> listOf("shift", "grave_accent")
            '\\' -> listOf("backslash")
            '|' -> listOf("shift", "backslash")
            ',' -> listOf("comma")
            '<' -> listOf("shift", "comma")
            '.' -> listOf("dot")
            '>' -> listOf("shift", "dot")
            '/' -> listOf("slash")
            '?' -> listOf("shift", "slash")
            '!' -> listOf("shift", "1")
            '@' -> listOf("shift", "2")
            '#' -> listOf("shift", "3")
            '$' -> listOf("shift", "4")
            '%' -> listOf("shift", "5")
            '^' -> listOf("shift", "6")
            '&' -> listOf("shift", "7")
            '*' -> listOf("shift", "8")
            '(' -> listOf("shift", "9")
            ')' -> listOf("shift", "0")
            else -> null
        }
    }

    companion object {
        private const val FRAME_INTERVAL_MS = 350L
        private const val RETRY_INTERVAL_MS = 950L
    }
}

@Composable
fun QmpGuestView(modifier: Modifier = Modifier, keyboardRequest: Int = 0) {
    AndroidView(
        modifier = modifier,
        factory = { LocalQmpView(it) },
        update = { view -> if (keyboardRequest > 0) view.showKeyboard(keyboardRequest) },
    )
}
