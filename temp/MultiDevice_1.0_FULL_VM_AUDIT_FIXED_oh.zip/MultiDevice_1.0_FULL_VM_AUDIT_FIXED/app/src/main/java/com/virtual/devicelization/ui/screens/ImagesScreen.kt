package com.virtual.devicelization.ui.screens

import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.virtual.devicelization.core.image.GuestImageManifest
import com.virtual.devicelization.core.image.ImageDownloadProgress
import com.virtual.devicelization.core.image.RemoteGuestImage
import com.virtual.devicelization.ui.components.GradientButton
import com.virtual.devicelization.ui.components.NeonCard
import com.virtual.devicelization.ui.theme.*

@Composable
fun ImagesScreen(
    images: List<GuestImageManifest>,
    remoteImages: List<RemoteGuestImage>,
    catalogLoading: Boolean,
    catalogError: String?,
    downloadProgress: ImageDownloadProgress?,
    installingImageId: String?,
    downloadedImageIds: Set<String>,
    installErrors: Map<String, String>,
    onRefreshCatalog: () -> Unit,
    onDownload: (RemoteGuestImage) -> Unit,
    onInstallDownloaded: (RemoteGuestImage) -> Unit,
    onImport: (Uri) -> Unit,
    onDelete: (String) -> Unit,
) {
    val context = LocalContext.current
    var section by remember { mutableStateOf("Catalog") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(onImport) }
    val free = Formatter.formatFileSize(context, context.filesDir.usableSpace)
    val total = Formatter.formatFileSize(context, context.filesDir.totalSpace)

    LaunchedEffect(Unit) {
        if (remoteImages.isEmpty() && !catalogLoading) onRefreshCatalog()
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Header(
                "Image Library",
                "Download only the Android images you actually use",
                trailing = {
                    IconButton(onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) {
                        Icon(Icons.Outlined.FileOpen, "Import image", tint = Cyan)
                    }
                },
            )
        }
        item {
            NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("App storage free", color = TextMuted)
                        Text(free, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("of $total", color = TextSubtle)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Icon(Icons.Outlined.Inventory2, null, tint = Purple)
                        Text("Installed", color = TextMuted)
                        Text(images.size.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Row(
                Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                LibraryTab("Catalog", section == "Catalog", Modifier.weight(1f)) { section = "Catalog" }
                LibraryTab("Installed (${images.size})", section == "Installed", Modifier.weight(1f)) { section = "Installed" }
            }
        }

        if (section == "Catalog") {
            item {
                Text(
                    "Recommended Downloads",
                    modifier = Modifier.padding(horizontal = 20.dp),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
            }
            when {
                catalogLoading && remoteImages.isEmpty() -> item {
                    NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Cyan) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Loading image catalog…", fontWeight = FontWeight.Bold)
                                Text("Checking current ARM64 QEMU releases", color = TextMuted)
                            }
                        }
                    }
                }
                catalogError != null && remoteImages.isEmpty() -> item {
                    NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Danger) {
                        Text("Catalog unavailable", fontWeight = FontWeight.Bold, color = Danger)
                        Text(catalogError, color = TextMuted)
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = onRefreshCatalog) { Text("Retry") }
                    }
                }
                else -> items(remoteImages, key = { it.id }) { image ->
                    RemoteImageRow(
                        image = image,
                        installed = images.any { it.id == image.id.replace(Regex("[^A-Za-z0-9._-]"), "_").take(96) },
                        downloaded = image.id in downloadedImageIds,
                        installError = installErrors[image.id],
                        progress = downloadProgress?.takeIf { it.imageId == image.id },
                        installing = installingImageId == image.id,
                        onDownload = { onDownload(image) },
                        onInstallDownloaded = { onInstallDownloaded(image) },
                    )
                }
            }
            item {
                NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Purple) {
                    Text("Other Android versions & builds", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "The VM engine supports ARM64 guest bundles described by Multi Device's .mdvm manifest. That lets you use other compatible AOSP/Lineage/custom builds without baking them into this APK.",
                        color = TextMuted,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        (8..16).forEach { v ->
                            Surface(
                                shape = MaterialTheme.shapes.extraLarge,
                                color = Surface2,
                                border = BorderStroke(1.dp, Outline),
                            ) {
                                Text("Android $v", modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = TextMuted)
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    GradientButton(
                        text = "Import local .mdvm / ZIP",
                        onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            item {
                NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth()) {
                    Text("Why images are not bundled", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Full Android VM images are commonly hundreds of megabytes to multiple gigabytes. Multi Device keeps the engine in the APK and downloads guest images separately so installation stays manageable and you choose exactly what occupies storage.",
                        color = TextMuted,
                    )
                }
            }
        } else {
            item {
                Text(
                    "Installed Android Images",
                    modifier = Modifier.padding(horizontal = 20.dp),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (images.isEmpty()) {
                item {
                    NeonCard(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), borderColor = Purple) {
                        Icon(Icons.Outlined.Android, null, tint = Purple, modifier = Modifier.size(42.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Nothing installed yet", fontWeight = FontWeight.Bold)
                        Text("Switch to Catalog to download a recommended image or import your own compatible bundle.", color = TextMuted)
                    }
                }
            } else {
                items(images, key = { it.id }) { image -> ImageRow(image = image, onDelete = { onDelete(image.id) }) }
            }
        }
    }
}

@Composable
private fun LibraryTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        modifier = modifier,
        label = { Text(label, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center) },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Surface,
            labelColor = TextMuted,
            selectedContainerColor = Cyan.copy(alpha = .15f),
            selectedLabelColor = TextPrimary,
        ),
        border = BorderStroke(1.dp, if (selected) Cyan else Outline),
    )
}

@Composable
private fun RemoteImageRow(
    image: RemoteGuestImage,
    installed: Boolean,
    downloaded: Boolean,
    installError: String?,
    progress: ImageDownloadProgress?,
    installing: Boolean,
    onDownload: () -> Unit,
    onInstallDownloaded: () -> Unit,
) {
    val context = LocalContext.current
    val statusLabel = when {
        installed -> "INSTALLED"
        installing && progress == null -> "INSTALLING"
        downloaded -> "DOWNLOADED"
        else -> "AVAILABLE"
    }
    val statusColor = when {
        installed -> Green
        installing -> Purple
        downloaded -> Cyan
        else -> Cyan
    }

    NeonCard(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
        borderColor = when {
            installed -> Green
            installError != null -> Danger
            downloaded -> Purple
            else -> Cyan
        },
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = Cyan.copy(alpha = .09f),
                border = BorderStroke(1.dp, Cyan.copy(alpha = .45f)),
            ) {
                Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Android, null, tint = Green, modifier = Modifier.size(36.dp))
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(image.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("Android ${image.androidVersion} • API ${image.apiLevel} • ${image.architecture}", color = TextMuted)
                Text("${image.releaseTag} • ${image.format}", color = TextSubtle, style = MaterialTheme.typography.bodySmall)
                if (image.sizeBytes > 0L) Text(Formatter.formatFileSize(context, image.sizeBytes), color = TextSubtle, style = MaterialTheme.typography.bodySmall)
            }
            Surface(
                shape = MaterialTheme.shapes.small,
                color = Surface3.copy(alpha = .45f),
                border = BorderStroke(1.dp, statusColor.copy(alpha = .7f)),
            ) {
                Text(
                    statusLabel,
                    color = statusColor,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                )
            }
        }

        when {
            progress != null -> {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = progress.fraction,
                    modifier = Modifier.fillMaxWidth(),
                    color = Cyan,
                    trackColor = Surface3,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (progress.totalBytes > 0L) {
                        "Downloading ${Formatter.formatFileSize(context, progress.bytesDownloaded)} / ${Formatter.formatFileSize(context, progress.totalBytes)}"
                    } else {
                        "Downloading ${Formatter.formatFileSize(context, progress.bytesDownloaded)}"
                    },
                    color = TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
                Text("If interrupted, the next Retry resumes from the saved partial download.", color = TextSubtle, style = MaterialTheme.typography.labelSmall)
            }

            installing -> {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = Purple,
                    trackColor = Surface3,
                )
                Spacer(Modifier.height(6.dp))
                Text("Installing from the completed local ZIP…", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                Text("The downloaded ZIP is kept until installation succeeds.", color = TextSubtle, style = MaterialTheme.typography.labelSmall)
            }

            !installed && downloaded -> {
                Spacer(Modifier.height(12.dp))
                NeonCard(Modifier.fillMaxWidth(), borderColor = if (installError == null) Purple else Danger) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (installError == null) Icons.Outlined.DownloadDone else Icons.Outlined.ErrorOutline,
                            null,
                            tint = if (installError == null) Green else Danger,
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Download complete — saved locally", fontWeight = FontWeight.Bold)
                            Text(
                                installError ?: "No network download is needed. Tap Install to use this saved archive.",
                                color = if (installError == null) TextMuted else Danger,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                GradientButton(
                    if (installError == null) "Install Downloaded Image" else "Retry Install — No Re-download",
                    onInstallDownloaded,
                    Modifier.fillMaxWidth(),
                )
            }

            !installed -> {
                Spacer(Modifier.height(12.dp))
                GradientButton("Download & Install", onDownload, Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Source: ${image.source}", color = TextSubtle, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ImageRow(image: GuestImageManifest, onDelete: () -> Unit) {
    NeonCard(
        Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
        borderColor = if (image.androidVersion % 2 == 0) Purple else Cyan,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Outlined.Android,
                null,
                tint = if (image.androidVersion % 2 == 0) Purple else Green,
                modifier = Modifier.size(46.dp),
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(image.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("Android ${image.androidVersion} • API ${image.apiLevel}", color = TextMuted)
                Text("${image.architecture} • ${image.machine}", color = TextSubtle, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(image.id, color = Cyan, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = Surface3.copy(alpha = .45f),
                    border = BorderStroke(1.dp, Green.copy(alpha = .7f)),
                ) {
                    Text(
                        "INSTALLED",
                        color = Green,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete image", tint = Danger)
                }
            }
        }
    }
}
