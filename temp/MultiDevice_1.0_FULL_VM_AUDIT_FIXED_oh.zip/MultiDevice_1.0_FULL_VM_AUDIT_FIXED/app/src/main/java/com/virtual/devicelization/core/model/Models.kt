package com.virtual.devicelization.core.model

enum class VmStatus {
    CREATING, READY, STARTING, RUNNING, SUSPENDING, SUSPENDED,
    RESUMING, STOPPING, STOPPED, ERROR, DELETING
}

enum class MacMode { KEEP_CURRENT, RANDOM_EVERY_BOOT, MANUAL_RESET_ONLY }
enum class NetworkMode { DIRECT_NAT, ENCRYPTED_TUNNEL, OFFLINE }

data class DeviceConfig(
    val preset: String = "Standard Phone",
    val cpuCores: Int = 4,
    val ramMb: Int = 4096,
    val storageGb: Int = 32,
    val width: Int = 720,
    val height: Int = 1600,
    val dpi: Int = 320,
    val refreshRate: Int = 60,
)

data class NetworkConfig(
    val virtualMac: String,
    val macMode: MacMode = MacMode.MANUAL_RESET_ONLY,
    val mode: NetworkMode = NetworkMode.DIRECT_NAT,
    val exitRegion: String = "Singapore",
    val dnsProtection: Boolean = true,
    val killSwitch: Boolean = true,
)

data class Profile(
    val id: String,
    val name: String,
    val androidVersion: Int,
    val apiLevel: Int,
    val architecture: String = "ARM64",
    val imageId: String? = null,
    val modelLabel: String = "Standard Phone",
    val device: DeviceConfig = DeviceConfig(),
    val network: NetworkConfig,
    val status: VmStatus = VmStatus.STOPPED,
    val createdAtEpochMs: Long = System.currentTimeMillis(),
)
