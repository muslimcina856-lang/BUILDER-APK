package com.virtual.devicelization.core.vm

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.virtual.devicelization.MainActivity
import com.virtual.devicelization.R

/**
 * Foreground owner for the one local VM session. It does not implement the engine itself; it keeps
 * the app process foreground while QEMU is active/paused so Android does not treat it as an idle UI
 * process. QEMU itself is owned process-wide by LocalEngineRegistry.
 */
class VmKeepAliveService : Service() {
    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        startForeground(NOTIFICATION_ID, notification("Virtual device is starting"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        deliberateStop = false
        val profile = intent?.getStringExtra(EXTRA_PROFILE_NAME)?.takeIf { it.isNotBlank() }
        val text = profile?.let { "$it is running locally" } ?: "Virtual device is running locally"
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification(text))
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        // If Android tears down the foreground service unexpectedly, do not leave an unowned VM.
        // A normal backend shutdown marks deliberateStop first to avoid stopService -> onDestroy ->
        // emergencyStop recursion.
        if (!deliberateStop) LocalEngineRegistry.backend(this).emergencyStop()
        deliberateStop = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_vm_notification)
            .setContentTitle("Multi Device")
            .setContentText(text)
            .setContentIntent(pending)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Virtual device session",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Keeps the active local Android virtual device running"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "multidevice_vm"
        private const val NOTIFICATION_ID = 101
        private const val EXTRA_PROFILE_NAME = "profile_name"
        @Volatile private var deliberateStop = false

        fun start(context: Context, profileName: String) {
            val intent = Intent(context, VmKeepAliveService::class.java)
                .putExtra(EXTRA_PROFILE_NAME, profileName)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            deliberateStop = true
            context.stopService(Intent(context, VmKeepAliveService::class.java))
        }
    }
}
