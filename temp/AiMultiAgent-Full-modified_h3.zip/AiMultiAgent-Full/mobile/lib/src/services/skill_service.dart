import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'local_database.dart';

class SkillService {
  SkillService(this.database, {http.Client? client}) : _client = client ?? http.Client();
  final LocalDatabase database;
  final http.Client _client;
  static const _uuid = Uuid();

  Future<List<SkillDefinition>> loadSkills() async {
    final saved = (await database.listObjects('skill'))
        .map(SkillDefinition.fromJson)
        .toList();
    final byId = <String, SkillDefinition>{
      for (final skill in saved) skill.id: skill,
    };
    for (final builtIn in _builtInSkills()) {
      final previous = byId[builtIn.id];
      final value = previous == null
          ? builtIn
          : SkillDefinition(
              id: builtIn.id,
              name: builtIn.name,
              description: builtIn.description,
              instructions: builtIn.instructions,
              toolIds: builtIn.toolIds,
              enabled: previous.enabled,
              sourcePath: previous.sourcePath,
              isBuiltIn: true,
            );
      byId[builtIn.id] = value;
      await database.saveObject('skill', value.id, value.toJson());
    }
    return byId.values.toList();
  }

  Future<SkillDefinition> importZip(String zipPath) async => importBytes(
        await File(zipPath).readAsBytes(),
        sourceLabel: zipPath,
      );

  Future<SkillDefinition> importUrl(String rawUrl) async {
    final uri = Uri.tryParse(rawUrl.trim());
    if (uri == null || !<String>{'http', 'https'}.contains(uri.scheme) || uri.host.isEmpty) {
      throw const FormatException('URL skill tidak sah.');
    }
    final response = await _client.get(uri).timeout(AppConfig.defaultTimeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException('Muat turun skill gagal: HTTP ${response.statusCode}.');
    }
    if (response.bodyBytes.length > AppConfig.maxSkillArchiveBytes) {
      throw const FileSystemException('Arkib skill melebihi had 50 MB.');
    }
    return importBytes(response.bodyBytes, sourceLabel: uri.toString());
  }

  Future<SkillDefinition> importBytes(List<int> bytes, {required String sourceLabel}) async {
    if (bytes.length > AppConfig.maxSkillArchiveBytes) {
      throw const FileSystemException('Arkib skill melebihi had 50 MB.');
    }
    final archive = ZipDecoder().decodeBytes(bytes, verify: true);
    final skillsRoot = Directory(p.join((await getApplicationDocumentsDirectory()).path, 'skills'));
    await skillsRoot.create(recursive: true);
    final root = Directory(p.join(skillsRoot.path, _uuid.v4()));
    await root.create(recursive: true);

    var extractedBytes = 0;
    for (final entry in archive) {
      final normalizedName = p.normalize(entry.name.replaceAll('\\', '/'));
      if (normalizedName.startsWith('../') || p.isAbsolute(normalizedName)) continue;
      final target = p.normalize(p.join(root.path, normalizedName));
      if (!p.isWithin(root.path, target)) continue;
      if (entry.isFile) {
        final content = entry.readBytes();
        if (content == null) {
          throw const FileSystemException('Kandungan fail skill tidak dapat dibaca.');
        }
        extractedBytes += content.length;
        if (extractedBytes > AppConfig.maxSkillArchiveBytes * 4) {
          await root.delete(recursive: true);
          throw const FileSystemException('Arkib skill mengembang melebihi had keselamatan.');
        }
        final output = File(target);
        await output.parent.create(recursive: true);
        await output.writeAsBytes(content, flush: true);
      } else {
        await Directory(target).create(recursive: true);
      }
    }

    final manifest = await _findManifest(root);
    if (manifest == null) {
      await root.delete(recursive: true);
      throw const FormatException('skill.json tidak ditemui dalam fail ZIP.');
    }
    final data = Map<String, dynamic>.from(jsonDecode(await manifest.readAsString()) as Map);
    final instructionFile = File(p.join(manifest.parent.path, data['instructionsFile']?.toString() ?? 'instructions.md'));
    final instructions = data['instructions']?.toString() ?? (await instructionFile.exists() ? await instructionFile.readAsString() : '');
    final skill = SkillDefinition(
      id: data['id']?.toString().trim().isNotEmpty == true ? data['id'].toString() : _uuid.v4(),
      name: data['name']?.toString() ?? 'Imported Skill',
      description: data['description']?.toString() ?? 'Dipasang daripada $sourceLabel',
      instructions: instructions,
      triggers: const <String>[],
      toolIds: (data['tools'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
      enabled: data['enabled'] as bool? ?? true,
      sourcePath: manifest.parent.path,
    );
    await database.saveObject('skill', skill.id, skill.toJson());
    return skill;
  }

  Future<SkillDefinition> createFromTool(Map<String, dynamic> arguments) async {
    final name = arguments['name']?.toString().trim() ?? '';
    final description = arguments['description']?.toString().trim() ?? '';
    final instructions = arguments['instructions']?.toString().trim() ?? '';
    if (name.isEmpty) {
      throw const FormatException('Nama skill diperlukan.');
    }
    if (description.isEmpty) {
      throw const FormatException('Penerangan skill diperlukan.');
    }
    if (instructions.isEmpty) {
      throw const FormatException('Arahan skill diperlukan.');
    }

    final requestedId = arguments['id']?.toString().trim() ?? '';
    final id = requestedId.isEmpty ? _uuid.v4() : _safeSkillId(requestedId);
    final toolIds = (arguments['tool_ids'] as List? ?? const <dynamic>[])
        .map((item) => item.toString().trim())
        .where((item) => item.isNotEmpty)
        .toSet()
        .toList(growable: false);

    final existingJson = await database.getObject('skill', id);
    final existing = existingJson == null ? null : SkillDefinition.fromJson(existingJson);
    if (existing?.isBuiltIn == true) {
      throw StateError('Skill terbina dalam tidak boleh ditulis semula.');
    }

    // Jika model tak senaraikan tool, biarkan kosong — runtime tetap boleh
    // pilih tool global; skill hanya arahan/konteks.
    final skill = SkillDefinition(
      id: id,
      name: name,
      description: description,
      instructions: instructions,
      triggers: const <String>[],
      toolIds: toolIds,
      enabled: arguments['enabled'] as bool? ?? existing?.enabled ?? true,
      sourcePath: existing?.sourcePath ?? '',
      isBuiltIn: false,
    );
    await save(skill);
    return skill;
  }

  String _safeSkillId(String raw) {
    final normalized = raw
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9_-]+'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^[_-]+|[_-]+$'), '');
    if (normalized.isEmpty) return _uuid.v4();
    return normalized.length <= 80 ? normalized : normalized.substring(0, 80);
  }

  Future<String> prepareScriptSandbox(String skillId) async {
    final json = await database.getObject('skill', skillId);
    if (json == null) throw StateError('Skill $skillId tidak ditemui.');
    final skill = SkillDefinition.fromJson(json);
    if (skill.sourcePath.isEmpty) throw StateError('Skill ini tidak mempunyai folder skrip.');
    final source = Directory(skill.sourcePath);
    if (!await source.exists()) throw StateError('Folder skill tidak ditemui.');
    final appRoot = await getApplicationDocumentsDirectory();
    final allowedRoot = p.join(appRoot.path, 'skills');
    final normalizedSource = p.normalize(source.path);
    if (!p.isWithin(allowedRoot, normalizedSource)) throw const FileSystemException('Folder skill di luar sandbox aplikasi.');

    final supportRoot = await getApplicationSupportDirectory();
    final workspaceRoot = Directory(p.join(supportRoot.path, 'linux', 'workspace'));
    await workspaceRoot.create(recursive: true);
    final workspace = Directory(p.join(workspaceRoot.path, '.skill_runs', skillId));
    if (await workspace.exists()) await workspace.delete(recursive: true);
    await _copyDirectory(source, workspace);
    return p.relative(workspace.path, from: workspaceRoot.path);
  }

  Future<void> _copyDirectory(Directory source, Directory destination) async {
    await destination.create(recursive: true);
    await for (final entity in source.list(recursive: false, followLinks: false)) {
      final target = p.join(destination.path, p.basename(entity.path));
      if (entity is Directory) {
        await _copyDirectory(entity, Directory(target));
      } else if (entity is File) {
        await entity.copy(target);
      }
    }
  }

  Future<File?> _findManifest(Directory root) async {
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is File && p.basename(entity.path) == 'skill.json') return entity;
    }
    return null;
  }

  Future<void> save(SkillDefinition skill) => database.saveObject('skill', skill.id, skill.toJson());

  Future<void> delete(SkillDefinition skill) async {
    await database.deleteObject('skill', skill.id);
    if (skill.sourcePath.isNotEmpty) {
      final directory = Directory(skill.sourcePath);
      if (await directory.exists()) await directory.delete(recursive: true);
    }
  }

  List<SkillDefinition> _builtInSkills() => const <SkillDefinition>[
        SkillDefinition(
          id: 'skill_creator',
          name: 'Skill Creator',
          description:
              'Membina skill local baharu berdasarkan tujuan dan aliran kerja yang diperlukan.',
          instructions:
              'Apabila satu aliran kerja berulang memerlukan skill khusus, gunakan tool skill_create. Tulis tujuan, arahan langkah demi langkah dan tools yang benar-benar diperlukan. Tiada trigger manual; model menentukan masa penggunaan berdasarkan nama, penerangan dan arahan skill.',
          toolIds: <String>['skill_create', 'file_write', 'file_read'],
          isBuiltIn: true,
        ),
        SkillDefinition(
          id: 'web_research',
          name: 'Web Research',
          description:
              'Mencari beberapa sumber, membaca halaman sebenar dan menghasilkan ringkasan bersumber.',
          instructions:
              'Gunakan web_search dahulu. Buka hasil penting dengan browser_open, baca kandungan sebenar dan bandingkan sumber sebelum membuat kesimpulan.',
          toolIds: <String>[
            'web_search',
            'browser_open',
            'browser_read',
            'browser_click',
          ],
          isBuiltIn: true,
        ),
        SkillDefinition(
          id: 'document_writer',
          name: 'Document Writer',
          description:
              'Menyediakan teks tersusun dan menyimpan hasil ke fail tempatan.',
          instructions:
              'Susun kandungan dengan tajuk yang jelas. Gunakan file_write hanya selepas kandungan siap.',
          toolIds: <String>['file_write', 'file_read', 'file_list'],
          isBuiltIn: true,
        ),
        SkillDefinition(
          id: 'local_memory',
          name: 'Local Memory',
          description:
              'Mencari dan menyimpan fakta pengguna dalam pangkalan data tempatan.',
          instructions:
              'Gunakan memory_search sebelum menganggap fakta peribadi. Simpan apabila pengguna meminta atau fakta jelas berguna.',
          toolIds: <String>['memory_search', 'memory_add', 'memory_delete'],
          isBuiltIn: true,
        ),
        SkillDefinition(
          id: 'sandbox_automation',
          name: 'Sandbox Automation',
          description:
              'Menjalankan skrip skill dan terminal di workspace sandbox aplikasi.',
          instructions:
              'Gunakan skill_run_script untuk skrip pakej skill atau terminal_start untuk arahan workspace. Pantau stdout, stderr dan status dengan terminal_poll.',
          toolIds: <String>[
            'skill_run_script',
            'terminal_start',
            'terminal_poll',
            'terminal_stop',
          ],
          isBuiltIn: true,
        ),
      ];

  void dispose() => _client.close();
}
