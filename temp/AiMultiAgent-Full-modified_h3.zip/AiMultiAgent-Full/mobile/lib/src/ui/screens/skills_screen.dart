import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../app.dart';
import '../../models/app_models.dart';
import '../../theme/app_theme.dart';

class SkillsScreen extends StatefulWidget {
  const SkillsScreen({super.key});

  @override
  State<SkillsScreen> createState() => _SkillsScreenState();
}

class _SkillsScreenState extends State<SkillsScreen> {
  bool _selectMode = false;
  final Set<String> _selected = <String>{};

  @override
  void initState() {
    super.initState();
    // Pastikan senarai skill segar (selepas AI cipta skill tanpa restart).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      AppScope.read(context).reloadSkills();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final skills = state.skills;
    final userSkills = skills.where((s) => !s.isBuiltIn).toList();
    final allUserSelected =
        userSkills.isNotEmpty && userSkills.every((s) => _selected.contains(s.id));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Skills'),
        actions: <Widget>[
          if (_selectMode) ...<Widget>[
            TextButton(
              onPressed: () {
                setState(() {
                  if (allUserSelected) {
                    _selected.clear();
                  } else {
                    _selected
                      ..clear()
                      ..addAll(userSkills.map((s) => s.id));
                  }
                });
              },
              child: Text(allUserSelected ? 'Nyahpilih' : 'Pilih semua'),
            ),
            IconButton(
              tooltip: 'Padam dipilih',
              onPressed: _selected.isEmpty ? null : () => _deleteSelected(context),
              icon: const Icon(Icons.delete_outline_rounded),
            ),
            TextButton(
              onPressed: () => setState(() {
                _selectMode = false;
                _selected.clear();
              }),
              child: const Text('Selesai'),
            ),
          ] else ...<Widget>[
            IconButton(
              tooltip: 'Pilih / padam',
              onPressed: userSkills.isEmpty
                  ? null
                  : () => setState(() => _selectMode = true),
              icon: const Icon(Icons.checklist_rounded),
            ),
            IconButton(
              onPressed: () => _installUrl(context),
              icon: const Icon(Icons.download_rounded),
              tooltip: 'Pasang dari URL',
            ),
            IconButton(
              onPressed: () => _import(context),
              icon: const Icon(Icons.file_upload_outlined),
              tooltip: 'Import ZIP',
            ),
            IconButton(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const SkillEditorScreen(),
                ),
              ),
              icon: const Icon(Icons.add_rounded),
              tooltip: 'Skill baharu',
            ),
          ],
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 40),
        itemCount: skills.length,
        itemBuilder: (context, index) {
          final skill = skills[index];
          final builtin = skill.isBuiltIn;
          final selected = _selected.contains(skill.id);
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: <Widget>[
                  if (_selectMode && !builtin)
                    Checkbox(
                      value: selected,
                      onChanged: (v) {
                        setState(() {
                          if (v == true) {
                            _selected.add(skill.id);
                          } else {
                            _selected.remove(skill.id);
                          }
                        });
                      },
                    )
                  else if (_selectMode && builtin)
                    const SizedBox(width: 48),
                  CircleAvatar(
                    backgroundColor: AppTheme.purple.withValues(alpha: .14),
                    child: Icon(
                      builtin ? Icons.lock_rounded : Icons.extension_rounded,
                      color: AppTheme.purpleLight,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          skill.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          skill.description,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 5),
                        Text(
                          builtin
                              ? 'Skill lalai · tidak boleh dipadam'
                              : 'Skill pengguna · tools auto',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  Switch.adaptive(
                    value: skill.enabled,
                    onChanged: (value) =>
                        state.saveSkill(skill.copyWith(enabled: value)),
                  ),
                  if (!builtin && !_selectMode)
                    IconButton(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => SkillEditorScreen(skill: skill),
                        ),
                      ),
                      icon: const Icon(Icons.edit_outlined),
                    )
                  else if (builtin)
                    const SizedBox(width: 12),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => const SkillEditorScreen()),
        ),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Skill'),
      ),
    );
  }

  Future<void> _deleteSelected(BuildContext context) async {
    final state = AppScope.read(context);
    final toDelete = state.skills
        .where((s) => !s.isBuiltIn && _selected.contains(s.id))
        .toList();
    if (toDelete.isEmpty) return;
    final ok = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Padam skill dipilih?'),
            content: Text('${toDelete.length} skill pengguna akan dipadam.'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Batal'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Padam'),
              ),
            ],
          ),
        ) ??
        false;
    if (!ok || !context.mounted) return;
    for (final skill in toDelete) {
      await state.deleteSkill(skill);
    }
    if (mounted) {
      setState(() {
        _selected.clear();
        _selectMode = false;
      });
    }
  }

  Future<void> _import(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const <String>['zip'],
    );
    final path = result?.files.single.path;
    if (path == null || !context.mounted) return;
    try {
      await AppScope.read(context).importSkill(path);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Skill berjaya dipasang.')),
        );
      }
    } catch (error) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memasang skill: $error')),
        );
      }
    }
  }

  Future<void> _installUrl(BuildContext context) async {
    final controller = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pasang skill dari URL'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.url,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'URL arkib ZIP'),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Pasang'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (url == null || url.isEmpty || !context.mounted) return;
    try {
      await AppScope.read(context).installSkillFromUrl(url);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Skill dipasang.')),
        );
      }
    } catch (error) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memasang skill: $error')),
        );
      }
    }
  }
}

class SkillEditorScreen extends StatefulWidget {
  const SkillEditorScreen({this.skill, super.key});
  final SkillDefinition? skill;

  @override
  State<SkillEditorScreen> createState() => _SkillEditorScreenState();
}

class _SkillEditorScreenState extends State<SkillEditorScreen> {
  static const _uuid = Uuid();
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _description;
  late final TextEditingController _instructions;
  late bool _enabled;

  @override
  void initState() {
    super.initState();
    final skill = widget.skill;
    _name = TextEditingController(text: skill?.name ?? 'Skill Baharu');
    _description = TextEditingController(
      text: skill?.description ?? 'Penerangan ringkas skill.',
    );
    _instructions = TextEditingController(
      text: skill?.instructions ?? 'Terangkan langkah kerja skill di sini.',
    );
    _enabled = skill?.enabled ?? true;
  }

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    _instructions.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final builtin = widget.skill?.isBuiltIn == true;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          builtin
              ? 'Skill lalai'
              : widget.skill == null
                  ? 'Skill Baharu'
                  : 'Edit Skill',
        ),
        actions: <Widget>[
          if (widget.skill != null && !builtin)
            IconButton(
              onPressed: _delete,
              icon: const Icon(Icons.delete_outline_rounded),
              tooltip: 'Padam',
            ),
          if (!builtin)
            TextButton(onPressed: _save, child: const Text('Simpan')),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
          children: <Widget>[
            if (builtin)
              const Card(
                child: ListTile(
                  leading: Icon(Icons.lock_rounded, color: AppTheme.purpleLight),
                  title: Text('Skill lalai aplikasi'),
                  subtitle: Text(
                    'Tidak boleh dipadam atau diubah. Hanya boleh on/off.',
                  ),
                ),
              ),
            TextFormField(
              controller: _name,
              readOnly: builtin,
              decoration: const InputDecoration(labelText: 'Nama skill'),
              validator: _required,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _description,
              readOnly: builtin,
              decoration: const InputDecoration(labelText: 'Penerangan'),
              maxLines: 2,
              validator: _required,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _instructions,
              readOnly: builtin,
              decoration: const InputDecoration(
                labelText: 'Arahan skill',
                alignLabelWithHint: true,
              ),
              minLines: 8,
              maxLines: 24,
              validator: _required,
            ),
            const SizedBox(height: 10),
            const Card(
              child: ListTile(
                leading: Icon(
                  Icons.auto_awesome_rounded,
                  color: AppTheme.purpleLight,
                ),
                title: Text('Tools automatik'),
                subtitle: Text(
                  'Model pilih tool yang diperlukan sendiri. Tiada senarai tick tool di UI.',
                ),
              ),
            ),
            if (!builtin)
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: _enabled,
                onChanged: (value) => setState(() => _enabled = value),
                title: const Text('Skill aktif'),
              ),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) =>
      value == null || value.trim().isEmpty ? 'Ruangan ini diperlukan.' : null;

  Future<void> _save() async {
    if (widget.skill?.isBuiltIn == true) return;
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final old = widget.skill;
    final state = AppScope.read(context);
    // Tools: biarkan yang sedia ada, atau semua tool (kecuali runtime multi-agent) jika baharu.
    final toolIds = old?.toolIds.isNotEmpty == true
        ? old!.toolIds
        : state.toolEngine.definitions.map((t) => t.id).toList();
    final skill = SkillDefinition(
      id: old?.id ?? _uuid.v4(),
      name: _name.text.trim(),
      description: _description.text.trim(),
      instructions: _instructions.text.trim(),
      triggers: const <String>[],
      toolIds: toolIds,
      enabled: _enabled,
      sourcePath: old?.sourcePath ?? '',
      isBuiltIn: false,
    );
    await state.saveSkill(skill);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final skill = widget.skill;
    if (skill == null || skill.isBuiltIn) return;
    final ok = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Padam skill?'),
            content: Text('${skill.name} akan dipadam.'),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Batal'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Padam'),
              ),
            ],
          ),
        ) ??
        false;
    if (!ok || !mounted) return;
    await AppScope.read(context).deleteSkill(skill);
    if (mounted) Navigator.pop(context);
  }
}
