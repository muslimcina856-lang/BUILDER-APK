# 📱 TikTok Downloader (Flutter)

Aplikasi Flutter untuk mengunduh video TikTok tanpa watermark, dengan build APK otomatis via GitHub Actions — **tidak perlu install Flutter/Android Studio di komputer sendiri**.

## ✨ Fitur

- Unduh video TikTok tanpa watermark (kualitas HD)
- Tempel link otomatis dari clipboard
- Preview video (thumbnail, judul, jumlah like/komentar/views) sebelum download
- Progress bar saat mengunduh
- Riwayat unduhan tersimpan lokal
- Video otomatis tersimpan ke galeri HP
- UI gelap bertema TikTok (merah muda–cyan)

## 🚀 Cara Build APK via GitHub Actions (Tanpa Coding)

1. **Buat repository baru** di GitHub (bisa public atau private).
2. **Upload semua file project ini** ke repository tersebut — bisa lewat web GitHub (drag & drop folder) atau lewat `git push`:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: TikTok Downloader"
   git branch -M main
   git remote add origin https://github.com/USERNAME/NAMA-REPO.git
   git push -u origin main
   ```
3. Setelah push, buka tab **Actions** di repository GitHub kamu.
4. Workflow **"Build APK"** akan otomatis berjalan (prosesnya sekitar 5–10 menit).
5. Setelah selesai (centang hijau ✅):
   - Buka halaman **Actions** → klik run yang selesai → scroll ke bawah ke bagian **Artifacts** → download `tiktok-downloader-apk.zip`. **ATAU**
   - Buka tab **Releases** di repository — APK juga otomatis dipublish di sana setiap kali push ke branch `main`.
6. Ekstrak/download file APK-nya (disarankan pakai `tiktok-downloader-arm64-v8a.apk` untuk HP modern), lalu install di HP Android kamu (aktifkan "Install dari sumber tidak dikenal" jika diminta).

> Kamu juga bisa memicu build secara manual: buka tab **Actions** → pilih workflow **"Build APK"** → klik **"Run workflow"**.

## 🛠️ Build Manual di Komputer Sendiri (Opsional)

Jika kamu punya Flutter SDK terinstal:

```bash
flutter pub get
flutter pub run flutter_launcher_icons
flutter build apk --release
```

Hasil APK ada di: `build/app/outputs/flutter-apk/app-release.apk`

## 🔐 Signing APK untuk Play Store (Opsional)

Secara default, APK ditandatangani dengan **debug key** — ini cukup untuk instal manual (sideload) tapi **tidak bisa** dipublikasikan ke Google Play Store.

Jika ingin publish ke Play Store:

1. Buat keystore:
   ```bash
   keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```
2. Salin `android/key.properties.example` menjadi `android/key.properties`, isi sesuai keystore kamu.
3. **Jangan pernah commit** file `key.properties` atau `.jks` ke repository publik (sudah otomatis di-ignore lewat `.gitignore`).
4. Untuk build di GitHub Actions dengan signing asli, tambahkan keystore & password sebagai **GitHub Secrets**, lalu sesuaikan workflow `.github/workflows/build-apk.yml` untuk membaca secrets tersebut sebelum build.

## 📂 Struktur Project

```
lib/
├── main.dart                  # Entry point aplikasi
├── models/
│   └── video_info.dart        # Model data video TikTok & riwayat
├── services/
│   ├── tiktok_service.dart    # Ekstraksi data video dari TikTok
│   ├── download_service.dart  # Unduh video & simpan ke galeri
│   └── history_service.dart   # Simpan riwayat unduhan (lokal)
├── screens/
│   ├── home_screen.dart       # Layar utama
│   └── history_screen.dart    # Layar riwayat unduhan
└── widgets/
    ├── video_preview_card.dart
    └── gradient_button.dart

android/                       # Konfigurasi native Android
.github/workflows/build-apk.yml # Workflow build APK otomatis
```

## ⚠️ Catatan Penting

- Aplikasi ini menggunakan endpoint publik pihak ketiga untuk mengekstrak link video TikTok (bukan API resmi TikTok, karena TikTok tidak menyediakan API publik untuk keperluan ini). Jika endpoint tersebut berubah/down, fitur pencarian video bisa gagal — ini adalah keterbatasan yang melekat pada semua aplikasi downloader TikTok pihak ketiga.
- Gunakan aplikasi ini untuk mengunduh video yang kamu punya hak/izin untuk diunduh (video sendiri, atau video publik untuk keperluan pribadi). Hormati hak cipta kreator konten.
- Package `applicationId` masih `com.example.tiktok_downloader` — ganti sesuai keinginan di `android/app/build.gradle` sebelum publish ke Play Store.

## 📦 Dependencies Utama

| Package | Kegunaan |
|---|---|
| `dio` | HTTP client untuk request & download dengan progress |
| `permission_handler` | Meminta izin penyimpanan/media |
| `gallery_saver_plus` | Simpan video ke galeri |
| `cached_network_image` | Cache thumbnail video |
| `shared_preferences` | Simpan riwayat unduhan lokal |
| `google_fonts` & `animate_do` | Styling & animasi UI |

---

Dibuat dengan Flutter 💙
