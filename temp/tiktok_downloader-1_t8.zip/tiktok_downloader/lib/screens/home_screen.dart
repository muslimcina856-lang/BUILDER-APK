import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:animate_do/animate_do.dart';
import '../models/video_info.dart';
import '../services/tiktok_service.dart';
import '../services/download_service.dart';
import '../services/history_service.dart';
import '../widgets/video_preview_card.dart';
import '../widgets/gradient_button.dart';
import 'history_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _linkController = TextEditingController();
  final TikTokService _tikTokService = TikTokService();
  final DownloadService _downloadService = DownloadService();
  final HistoryService _historyService = HistoryService();

  TikTokVideoInfo? _videoInfo;
  bool _isLoading = false;
  bool _isDownloading = false;
  double _downloadProgress = 0.0;
  String? _errorMessage;

  @override
  void dispose() {
    _linkController.dispose();
    super.dispose();
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null) {
      setState(() {
        _linkController.text = data!.text!;
        _errorMessage = null;
      });
    }
  }

  Future<void> _fetchVideo() async {
    FocusScope.of(context).unfocus();
    if (_linkController.text.trim().isEmpty) {
      setState(() => _errorMessage = 'Masukkan link video TikTok terlebih dahulu.');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoInfo = null;
    });

    try {
      final info = await _tikTokService.fetchVideoInfo(_linkController.text);
      setState(() => _videoInfo = info);
    } on TikTokServiceException catch (e) {
      setState(() => _errorMessage = e.toString());
    } catch (e) {
      setState(() => _errorMessage = 'Terjadi kesalahan tak terduga.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _downloadVideo() async {
    if (_videoInfo == null) return;

    setState(() {
      _isDownloading = true;
      _downloadProgress = 0.0;
    });

    try {
      final path = await _downloadService.downloadVideo(
        videoUrl: _videoInfo!.noWatermarkUrl,
        fileName: _videoInfo!.title.isNotEmpty ? _videoInfo!.title : _videoInfo!.id,
        onProgress: (progress) {
          if (mounted) setState(() => _downloadProgress = progress);
        },
      );

      await _historyService.addToHistory(
        DownloadHistoryItem(
          title: _videoInfo!.title,
          filePath: path,
          coverUrl: _videoInfo!.coverUrl,
          downloadedAt: DateTime.now(),
        ),
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Video berhasil disimpan ke galeri! 🎉'),
            backgroundColor: Color(0xFF25D366),
          ),
        );
      }
    } on DownloadServiceException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString()), backgroundColor: Colors.redAccent),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal mengunduh video.'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isDownloading = false;
          _downloadProgress = 0.0;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('TikTok Downloader'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history_rounded),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HistoryScreen()),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              FadeInDown(
                duration: const Duration(milliseconds: 500),
                child: _buildHeader(),
              ),
              const SizedBox(height: 28),
              FadeInUp(
                duration: const Duration(milliseconds: 500),
                child: _buildInputCard(),
              ),
              if (_errorMessage != null) ...[
                const SizedBox(height: 16),
                FadeIn(child: _buildErrorBanner()),
              ],
              if (_isLoading) ...[
                const SizedBox(height: 32),
                const Center(child: CircularProgressIndicator()),
              ],
              if (_videoInfo != null) ...[
                const SizedBox(height: 24),
                FadeInUp(
                  duration: const Duration(milliseconds: 400),
                  child: VideoPreviewCard(videoInfo: _videoInfo!),
                ),
                const SizedBox(height: 20),
                _buildDownloadSection(),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFE2C55), Color(0xFF25F4EE)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Icon(Icons.download_rounded, color: Colors.white, size: 36),
        ),
        const SizedBox(height: 16),
        Text(
          'Unduh Video TikTok',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 6),
        Text(
          'Tanpa watermark, kualitas HD, gratis',
          style: TextStyle(color: Colors.grey[400], fontSize: 14),
        ),
      ],
    );
  }

  Widget _buildInputCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF161616),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        children: [
          TextField(
            controller: _linkController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Tempel link video TikTok di sini...',
              hintStyle: TextStyle(color: Colors.grey[500]),
              filled: true,
              fillColor: const Color(0xFF0A0A0A),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
              suffixIcon: IconButton(
                icon: const Icon(Icons.paste_rounded, color: Colors.grey),
                onPressed: _pasteFromClipboard,
                tooltip: 'Tempel dari clipboard',
              ),
            ),
            onSubmitted: (_) => _fetchVideo(),
          ),
          const SizedBox(height: 14),
          GradientButton(
            label: _isLoading ? 'Mencari video...' : 'Cari Video',
            icon: Icons.search_rounded,
            onPressed: _isLoading ? null : _fetchVideo,
          ),
        ],
      ),
    );
  }

  Widget _buildErrorBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.redAccent.withOpacity(0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _errorMessage!,
              style: const TextStyle(color: Colors.redAccent, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDownloadSection() {
    if (_isDownloading) {
      return Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: _downloadProgress > 0 ? _downloadProgress : null,
              minHeight: 8,
              backgroundColor: Colors.white.withOpacity(0.1),
              valueColor: const AlwaysStoppedAnimation(Color(0xFFFE2C55)),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Mengunduh... ${(_downloadProgress * 100).toStringAsFixed(0)}%',
            style: TextStyle(color: Colors.grey[400], fontSize: 13),
          ),
        ],
      );
    }

    return Row(
      children: [
        Expanded(
          child: GradientButton(
            label: 'Download Tanpa Watermark',
            icon: Icons.file_download_rounded,
            onPressed: _downloadVideo,
          ),
        ),
      ],
    );
  }
}
