class TikTokVideoInfo {
  final String id;
  final String title;
  final String coverUrl;
  final String authorName;
  final String authorAvatar;
  final String noWatermarkUrl;
  final String? watermarkUrl;
  final String? musicUrl;
  final int duration;
  final int playCount;
  final int likeCount;
  final int commentCount;
  final int shareCount;

  TikTokVideoInfo({
    required this.id,
    required this.title,
    required this.coverUrl,
    required this.authorName,
    required this.authorAvatar,
    required this.noWatermarkUrl,
    this.watermarkUrl,
    this.musicUrl,
    this.duration = 0,
    this.playCount = 0,
    this.likeCount = 0,
    this.commentCount = 0,
    this.shareCount = 0,
  });

  factory TikTokVideoInfo.fromTikwmJson(Map<String, dynamic> json) {
    final data = json['data'] ?? {};
    return TikTokVideoInfo(
      id: data['id']?.toString() ?? '',
      title: data['title']?.toString() ?? 'TikTok Video',
      coverUrl: data['cover']?.toString() ?? '',
      authorName: data['author']?['nickname']?.toString() ?? 'Unknown',
      authorAvatar: data['author']?['avatar']?.toString() ?? '',
      noWatermarkUrl: data['play']?.toString() ?? '',
      watermarkUrl: data['wmplay']?.toString(),
      musicUrl: data['music']?.toString(),
      duration: (data['duration'] is int) ? data['duration'] : 0,
      playCount: (data['play_count'] is int) ? data['play_count'] : 0,
      likeCount: (data['digg_count'] is int) ? data['digg_count'] : 0,
      commentCount: (data['comment_count'] is int) ? data['comment_count'] : 0,
      shareCount: (data['share_count'] is int) ? data['share_count'] : 0,
    );
  }
}

class DownloadHistoryItem {
  final String title;
  final String filePath;
  final String coverUrl;
  final DateTime downloadedAt;

  DownloadHistoryItem({
    required this.title,
    required this.filePath,
    required this.coverUrl,
    required this.downloadedAt,
  });

  Map<String, dynamic> toJson() => {
        'title': title,
        'filePath': filePath,
        'coverUrl': coverUrl,
        'downloadedAt': downloadedAt.toIso8601String(),
      };

  factory DownloadHistoryItem.fromJson(Map<String, dynamic> json) =>
      DownloadHistoryItem(
        title: json['title'] ?? '',
        filePath: json['filePath'] ?? '',
        coverUrl: json['coverUrl'] ?? '',
        downloadedAt: DateTime.tryParse(json['downloadedAt'] ?? '') ?? DateTime.now(),
      );
}
