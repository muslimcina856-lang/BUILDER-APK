import 'dart:convert';
import 'package:dio/dio.dart';
import '../models/video_info.dart';

/// Exception khusus untuk error yang berhubungan dengan proses ekstraksi TikTok.
class TikTokServiceException implements Exception {
  final String message;
  TikTokServiceException(this.message);

  @override
  String toString() => message;
}

/// Service untuk mengambil data video TikTok (tanpa watermark) melalui
/// endpoint publik pihak ketiga (tikwm.com). Tidak ada API resmi dari
/// TikTok untuk keperluan ini, sehingga pendekatan ini bisa berhenti
/// berfungsi jika penyedia endpoint mengubah struktur responnya.
class TikTokService {
  final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 20),
      headers: {
        'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
      },
    ),
  );

  static const String _apiBase = 'https://www.tikwm.com/api/';

  /// Memvalidasi dan menormalkan link TikTok yang dimasukkan pengguna.
  String? extractValidUrl(String rawInput) {
    final trimmed = rawInput.trim();
    if (trimmed.isEmpty) return null;

    final urlPattern = RegExp(
      r'(https?:\/\/(?:www\.|vt\.|vm\.|m\.)?tiktok\.com\/[^\s]+)',
      caseSensitive: false,
    );
    final match = urlPattern.firstMatch(trimmed);
    if (match == null) return null;
    return match.group(0);
  }

  /// Mengambil metadata & link unduhan video dari link TikTok.
  Future<TikTokVideoInfo> fetchVideoInfo(String tiktokUrl) async {
    final validUrl = extractValidUrl(tiktokUrl);
    if (validUrl == null) {
      throw TikTokServiceException(
        'Link TikTok tidak valid. Pastikan kamu menyalin link video yang benar.',
      );
    }

    try {
      final response = await _dio.get(
        _apiBase,
        queryParameters: {
          'url': validUrl,
          'hd': 1,
        },
      );

      final body = response.data is String
          ? jsonDecode(response.data as String)
          : response.data;

      if (body == null || body['code'] != 0 || body['data'] == null) {
        throw TikTokServiceException(
          'Video tidak ditemukan. Video mungkin privat, dihapus, atau link salah.',
        );
      }

      return TikTokVideoInfo.fromTikwmJson(body as Map<String, dynamic>);
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout) {
        throw TikTokServiceException(
          'Koneksi timeout. Periksa koneksi internet kamu dan coba lagi.',
        );
      }
      throw TikTokServiceException(
        'Gagal mengambil data video. Coba lagi beberapa saat lagi.',
      );
    } catch (e) {
      if (e is TikTokServiceException) rethrow;
      throw TikTokServiceException('Terjadi kesalahan tak terduga: $e');
    }
  }
}
