import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/video_info.dart';

class HistoryService {
  static const String _storageKey = 'download_history';

  Future<List<DownloadHistoryItem>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_storageKey) ?? [];
    return raw
        .map((item) => DownloadHistoryItem.fromJson(jsonDecode(item)))
        .toList()
        .reversed
        .toList();
  }

  Future<void> addToHistory(DownloadHistoryItem item) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_storageKey) ?? [];
    raw.add(jsonEncode(item.toJson()));
    // Batasi riwayat maksimal 50 item terbaru.
    final trimmed = raw.length > 50 ? raw.sublist(raw.length - 50) : raw;
    await prefs.setStringList(_storageKey, trimmed);
  }

  Future<void> clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_storageKey);
  }
}
