import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';

class DownloadServiceException implements Exception {
  final String message;
  DownloadServiceException(this.message);

  @override
  String toString() => message;
}

class DownloadService {
  final Dio _dio = Dio();

  /// Meminta izin penyimpanan/media yang diperlukan sesuai versi Android.
  Future<bool> requestPermissions() async {
    if (!Platform.isAndroid) return true;

    // Android 13+ menggunakan izin granular (photos/videos).
    final statuses = await [
      Permission.videos,
      Permission.photos,
      Permission.storage,
    ].request();

    return statuses.values.any((status) => status.isGranted);
  }

  /// Mengunduh video dari [videoUrl] dan menyimpannya ke galeri perangkat.
  /// [onProgress] memberikan nilai 0.0 - 1.0.
  Future<String> downloadVideo({
    required String videoUrl,
    required String fileName,
    required void Function(double progress) onProgress,
  }) async {
    final hasPermission = await requestPermissions();
    if (!hasPermission) {
      throw DownloadServiceException(
        'Izin penyimpanan ditolak. Aktifkan izin di pengaturan aplikasi untuk melanjutkan.',
      );
    }

    try {
      final tempDir = await getTemporaryDirectory();
      final sanitizedName = fileName.replaceAll(RegExp(r'[^\w\s-]'), '');
      final safeName = sanitizedName.isEmpty ? 'tiktok_video' : sanitizedName;
      final filePath =
          '${tempDir.path}/${safeName}_${DateTime.now().millisecondsSinceEpoch}.mp4';

      await _dio.download(
        videoUrl,
        filePath,
        onReceiveProgress: (received, total) {
          if (total > 0) {
            onProgress(received / total);
          }
        },
      );

      final file = File(filePath);
      if (!await file.exists()) {
        throw DownloadServiceException('File gagal disimpan sementara.');
      }

      final saveResult = await GallerySaver.saveVideo(filePath, albumName: 'TikTok Downloader');
      if (saveResult != true) {
        throw DownloadServiceException('Gagal menyimpan video ke galeri.');
      }

      return filePath;
    } on DioException catch (_) {
      throw DownloadServiceException(
        'Gagal mengunduh video. Periksa koneksi internet dan coba lagi.',
      );
    } catch (e) {
      if (e is DownloadServiceException) rethrow;
      throw DownloadServiceException('Terjadi kesalahan saat mengunduh: $e');
    }
  }
}
