package com.qntm.bizz;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
