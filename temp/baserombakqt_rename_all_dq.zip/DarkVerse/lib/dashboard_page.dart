import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // ========== TEMA MERAH HITAM (SESUAI GAMBAR) ==========
  final Color _bgDark = const Color(0xFF0A0A0A);
  final Color _cardColor = const Color(0xFF151515);
  final Color _surfaceColor = const Color(0xFF1A1A1E);
  final Color _accentColor = const Color(0xFFB71C1C);   // merah gelap tegas
  final Color _accentSoft = const Color(0xFF8B0000);
  final Color _textPrimary = const Color(0xFFE8E8E8);
  final Color _textSecondary = const Color(0xFF9CA3AF);
  final Color _borderColor = const Color(0xFF2D2D30);
  final Color _glowColor = const Color(0xFFB71C1C);

  String _dailyQuote = "⚔️ Ketekunan adalah kunci kesuksesan.";
  int _remainingDays = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _calculateRemainingDays();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _controller.forward();

    _selectedPage = _buildDashboardContent();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
    _loadDailyQuote();
    _showWelcomeNotification();
  }

  void _calculateRemainingDays() {
    try {
      final exp = DateTime.parse(expiredDate);
      final now = DateTime.now();
      _remainingDays = exp.difference(now).inDays;
      if (_remainingDays < 0) _remainingDays = 0;
    } catch (_) {
      _remainingDays = 0;
    }
  }

  void _loadDailyQuote() {
    final List<String> quotes = [
      "⚔️ Jangan menyerah, mimpi itu gratis.",
      "🔥 Hari ini lebih baik dari kemarin.",
      "🎯 Kesuksesan dimulai dari keberanian untuk memulai.",
      "💀 Bekerja keras dalam diam, biarkan kesuksesan yang berbicara.",
      "⏳ Setiap hari adalah kesempatan baru.",
      "🌑 KURAPIKA CRASH – Always on the next level.",
      "🚀 KURAPIKA CRASH: Gacor, Terupdate, Stabil.",
      "📖 Belajar dari masa lalu, jalani hari ini, impikan masa depan.",
      "⚡ Konsistensi lebih penting daripada intensitas.",
      "🛡️ KURAPIKA CRASH – The Future is Now.",
    ];
    final randomIndex = DateTime.now().day % quotes.length;
    setState(() {
      _dailyQuote = quotes[randomIndex];
    });
  }

  void _showWelcomeNotification() async {
    final prefs = await SharedPreferences.getInstance();
    final lastDate = prefs.getString('last_notification_date');
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (lastDate != today) {
      await prefs.setString('last_notification_date', today);
      if (mounted) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: _cardColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: BorderSide(color: _accentColor, width: 1.5),
            ),
            title: Row(
              children: [
                Icon(Icons.notifications_active, color: _accentColor),
                const SizedBox(width: 10),
                Text('NOTIFIKASI', style: TextStyle(color: _accentColor, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              ],
            ),
            content: Text(
              "Halo $username, selamat datang kembali di KURAPIKA CRASH!\n\n✨ Daily Quote:\n“$_dailyQuote”",
              style: TextStyle(color: _textSecondary),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: BoxDecoration(border: Border.all(color: _accentColor), borderRadius: BorderRadius.circular(8)),
                  child: Text('Tutup', style: TextStyle(color: _accentColor, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        );
      }
    }
  }

  // ========== FUNGSI ASLI (TIDAK BERUBAH) ==========
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  void _initMenuVideo() {
    _menuVideoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() {});
        _menuVideoController?.setLooping(true);
        _menuVideoController?.play();
      });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws-dark.darkverse.my.id'));
    channel.sink.add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        _handleInvalidSession(data['reason'] == 'androidIdMismatch'
            ? "Your account has logged on another device."
            : "Key is not valid. Please login again.");
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: _accentColor, width: 1.5)),
        title: Text("⚠️ Session Expired", style: TextStyle(color: _accentColor, fontWeight: FontWeight.bold)),
        content: Text(message, style: TextStyle(color: _textSecondary)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(border: Border.all(color: _accentColor), borderRadius: BorderRadius.circular(8)),
              child: Text("OK", style: TextStyle(color: _accentColor, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) _selectedPage = _buildDashboardContent();
      else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      else if (index == 4) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      else if (index == 5) _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  // ========== DASHBOARD CONTENT - TAMPILAN MERAH HITAM ==========
  Widget _buildDashboardContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        children: [
          _buildHeaderCard(),
          const SizedBox(height: 16),
          _buildQuickInfoRow(),
          const SizedBox(height: 16),
          _buildQuoteCard(),
          const SizedBox(height: 16),
          _buildStatsCard(),
          const SizedBox(height: 20),
          _buildNewsCarousel(),
          const SizedBox(height: 20),
          _buildActionRow(),
          const SizedBox(height: 16),
          _buildFooterNote(),
        ],
      ),
    );
  }

  Widget _buildHeaderCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_cardColor, _accentColor.withOpacity(0.1)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _borderColor, width: 1),
        boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12, offset: const Offset(0, 6))],
      ),
      child: Row(
        children: [
          Stack(
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _accentColor, width: 2),
                  boxShadow: [BoxShadow(color: _glowColor.withOpacity(0.4), blurRadius: 12)],
                ),
                child: ClipOval(
                  child: _profileImage != null
                      ? Image.file(_profileImage!, fit: BoxFit.cover)
                      : Icon(FontAwesomeIcons.userAstronaut, size: 36, color: _textSecondary),
                ),
              ),
              Positioned(
                bottom: 2,
                right: 2,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF10B981),
                    border: Border.all(color: _bgDark, width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: _accentColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: TextStyle(color: _accentColor, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.calendar_today, size: 12, color: _textSecondary),
                    const SizedBox(width: 4),
                    Text(
                      "Exp: $expiredDate",
                      style: TextStyle(color: _textSecondary, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _accentColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  "$_remainingDays hari",
                  style: TextStyle(color: _accentColor, fontSize: 11, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 6),
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2),
                  color: _accentColor.withOpacity(0.3),
                ),
                child: FractionallySizedBox(
                  widthFactor: _remainingDays.clamp(0, 30) / 30,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(2),
                      color: _accentColor,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickInfoRow() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildInfoTile(Icons.devices, "Device ID", androidId.length > 12 ? "${androidId.substring(0, 12)}..." : androidId),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildInfoTile(Icons.verified_user, "Session", "Active"),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoTile(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor),
      ),
      child: Column(
        children: [
          Icon(icon, color: _accentColor, size: 18),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(color: _textSecondary, fontSize: 10),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(color: _textPrimary, fontSize: 11, fontWeight: FontWeight.w500),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildQuoteCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _borderColor),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _accentColor.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.format_quote, color: _accentColor, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              _dailyQuote,
              style: TextStyle(color: _textPrimary, fontSize: 13, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_cardColor, _accentColor.withOpacity(0.1)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _borderColor),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem(Icons.people, "ONLINE", "$onlineUsers"),
          Container(width: 1, height: 40, color: _borderColor),
          _buildStatItem(Icons.wifi_tethering, "ACTIVE", "$activeConnections"),
        ],
      ),
    );
  }

  Widget _buildStatItem(IconData icon, String label, String value) {
    return Column(
      children: [
        Icon(icon, color: _accentColor, size: 28),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(color: _textPrimary, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
        ),
        Text(label, style: TextStyle(color: _textSecondary, fontSize: 11, letterSpacing: 1)),
      ],
    );
  }

  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        height: 180,
        margin: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: _cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _borderColor),
        ),
        child: Center(child: Text("No announcements", style: TextStyle(color: _textSecondary))),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Icon(Icons.newspaper, color: _accentColor, size: 18),
              const SizedBox(width: 8),
              Text("ANNOUNCEMENTS", style: TextStyle(color: _textSecondary, fontSize: 12, letterSpacing: 1)),
            ],
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 210,
          child: PageView.builder(
            controller: PageController(viewportFraction: 0.85),
            itemCount: newsList.length,
            itemBuilder: (context, index) {
              final item = newsList[index];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  color: _cardColor,
                  border: Border.all(color: _borderColor),
                  boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 12, offset: const Offset(0, 4))],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: Stack(
                    children: [
                      if (item['image'] != null && item['image'].toString().isNotEmpty)
                        Positioned.fill(
                          child: Image.network(item['image'], fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: _surfaceColor)),
                        ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [Colors.transparent, _bgDark.withOpacity(0.85)],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 20,
                        left: 20,
                        right: 20,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'] ?? "Announcement",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                shadows: [Shadow(color: _glowColor.withOpacity(0.5), blurRadius: 8)],
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              item['desc'] ?? "",
                              style: TextStyle(color: Colors.white70, fontSize: 12),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildActionRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildActionButton(
              icon: FontAwesomeIcons.telegram,
              label: "JOIN CHANNEL",
              onTap: () => _openUrl("https://t.me/nexvoidnew"),
              color: const Color(0xFF0088cc),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: _buildActionButton(
              icon: Icons.bug_report,
              label: "BUG SENDER",
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => BugSenderPage(
                      sessionKey: sessionKey,
                      username: username,
                      role: role,
                    ),
                  ),
                );
              },
              color: _accentColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({required IconData icon, required String label, required VoidCallback onTap, required Color color}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: _surfaceColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.5)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(color: _textPrimary, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooterNote() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.shield_moon, color: _accentColor.withOpacity(0.6), size: 14),
          const SizedBox(width: 6),
          Text(
            "SECURE ENVIRONMENT • ALL ACTIONS LOGGED",
            style: TextStyle(color: _textSecondary.withOpacity(0.5), fontSize: 9, fontFamily: 'ShareTechMono', letterSpacing: 1),
          ),
        ],
      ),
    );
  }

  // ========== DRAWER ==========
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: _bgDark,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 250,
            color: Colors.black,
            child: Stack(
              children: [
                if (_menuVideoController != null && _menuVideoController!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoController!.value.size.width,
                        height: _menuVideoController!.value.size.height,
                        child: VideoPlayer(_menuVideoController!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.2), Colors.black.withOpacity(0.85)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: _accentColor, width: 2),
                            boxShadow: [BoxShadow(color: _glowColor.withOpacity(0.5), blurRadius: 12)],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Icon(FontAwesomeIcons.userAstronaut, size: 40, color: _textSecondary),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          username,
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          margin: const EdgeInsets.only(top: 6),
                          decoration: BoxDecoration(
                            color: _accentColor.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            role.toUpperCase(),
                            style: TextStyle(color: _accentColor, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: _bgDark,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                children: [
                  if (role == "reseller")
                    _buildDrawerMenuItem(icon: Icons.storefront, label: "Seller Page", onTap: () => _onSidebarTabSelected(1)),
                  if (role == "admin")
                    _buildDrawerMenuItem(icon: Icons.admin_panel_settings, label: "Admin Page", onTap: () => _onSidebarTabSelected(2)),
                  if (role == "partner")
                    _buildDrawerMenuItem(icon: FontAwesomeIcons.handshake, label: "Partner Page", onTap: () => _onSidebarTabSelected(4)),
                  if (role == "moderator")
                    _buildDrawerMenuItem(icon: FontAwesomeIcons.userShield, label: "Moderator Page", onTap: () => _onSidebarTabSelected(5)),
                  if (role == "owner")
                    _buildDrawerMenuItem(icon: Icons.workspace_premium, label: "Owner Page", onTap: () => _onSidebarTabSelected(3)),
                  _buildDrawerMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
                    },
                  ),
                  const SizedBox(height: 20),
                  _buildDrawerMenuItem(
                    icon: Icons.logout,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({required IconData icon, required String label, required VoidCallback onTap, bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: isLogout ? _accentColor.withOpacity(0.1) : _surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isLogout ? _accentColor.withOpacity(0.5) : _borderColor),
      ),
      child: ListTile(
        leading: Icon(icon, color: _accentColor, size: 22),
        title: Text(label, style: TextStyle(color: isLogout ? _accentColor : _textPrimary, fontWeight: FontWeight.w500, fontSize: 14)),
        trailing: Icon(Icons.chevron_right, color: _textSecondary.withOpacity(0.6), size: 18),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onTap: onTap,
      ),
    );
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          "DASHBOARD",
          style: TextStyle(
            color: _textPrimary,
            fontWeight: FontWeight.bold,
            fontSize: 18,
            fontFamily: 'Orbitron',
            letterSpacing: 1.5,
            shadows: [Shadow(color: _glowColor.withOpacity(0.4), blurRadius: 8)],
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(Icons.headset_mic_outlined, color: _accentColor),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage())),
          ),
          IconButton(
            icon: Icon(FontAwesomeIcons.userCircle, color: _accentColor),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                ),
              ),
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_bgDark, _accentColor.withOpacity(0.05), _bgDark],
          ),
        ),
        child: SafeArea(child: FadeTransition(opacity: _animation, child: _selectedPage)),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: _surfaceColor,
          border: Border(top: BorderSide(color: _borderColor)),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: _accentColor,
          unselectedItemColor: _textSecondary,
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WhatsApp"),
            BottomNavigationBarItem(icon: Icon(Icons.notifications_none), label: "Info"),
            BottomNavigationBarItem(icon: Icon(Icons.build_circle_outlined), label: "Tools"),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _menuVideoController?.dispose();
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) => url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.endsWith(".mkv");

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(aspectRatio: _controller!.value.aspectRatio, child: VideoPlayer(_controller!));
      } else {
        return const Center(child: CircularProgressIndicator(color: Colors.white));
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: Colors.grey.shade800, child: Icon(Icons.error, color: Colors.white)),
      );
    }
  }
}