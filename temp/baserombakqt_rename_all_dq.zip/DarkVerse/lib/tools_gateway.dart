import 'dart:ui';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  // ========== TEMA SANGAR DENGAN DETAIL KAYA ==========
  final Color _bgDark = const Color(0xFF0A0A0A);
  final Color _cardColor = const Color(0xFF121212);
  final Color _surfaceColor = const Color(0xFF1A1A1E);
  final Color _accentColor = const Color(0xFFB71C1C);   // merah gelap tegas
  final Color _accentSoft = const Color(0xFF8B0000);
  final Color _textPrimary = const Color(0xFFE8E8E8);
  final Color _textSecondary = const Color(0xFF9CA3AF);
  final Color _borderColor = const Color(0xFF2D2D30);
  final Color _glowColor = const Color(0xFFB71C1C);

  // Data jumlah tools per kategori
  final Map<String, int> _toolsCount = {
    "DDoS Tools": 2,
    "Network": 3,
    "OSINT": 4,
    "Downloader": 2,
    "Utilities": 3,
    "Quick Access": 0,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      body: Stack(
        children: [
          // Background pattern (grid halus) - DIPERBAIKI
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage('https://www.transparenttextures.com/patterns/carbon-fiber.png'),
                fit: BoxFit.cover,
                repeat: ImageRepeat.repeat,
                opacity: 0.03,
              ),
            ),
          ),
          // Glass overlay atas
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      _accentColor.withOpacity(0.05),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                // === HEADER DENGAN DETAIL ===
                _buildHeader(),
                const SizedBox(height: 8),
                // === STATISTIK CEPAT ===
                _buildQuickStats(),
                const SizedBox(height: 16),
                // === GRID CARD ===
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: GridView.count(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 1.1,
                      children: [
                        _buildToolCard(
                          icon: Icons.flash_on,
                          title: "DDoS Tools",
                          subtitle: "Attack & Server",
                          toolCount: _toolsCount["DDoS Tools"]!,
                          onTap: () => _showDDoSTools(context),
                        ),
                        _buildToolCard(
                          icon: Icons.wifi,
                          title: "Network",
                          subtitle: "WiFi & Spam",
                          toolCount: _toolsCount["Network"]!,
                          onTap: () => _showNetworkTools(context),
                        ),
                        _buildToolCard(
                          icon: Icons.search,
                          title: "OSINT",
                          subtitle: "Investigation",
                          toolCount: _toolsCount["OSINT"]!,
                          onTap: () => _showOSINTTools(context),
                        ),
                        _buildToolCard(
                          icon: Icons.download,
                          title: "Downloader",
                          subtitle: "Social Media",
                          toolCount: _toolsCount["Downloader"]!,
                          onTap: () => _showDownloaderTools(context),
                        ),
                        _buildToolCard(
                          icon: Icons.build,
                          title: "Utilities",
                          subtitle: "Extra Tools",
                          toolCount: _toolsCount["Utilities"]!,
                          onTap: () => _showUtilityTools(context),
                        ),
                        _buildToolCard(
                          icon: Icons.rocket_launch,
                          title: "Quick Access",
                          subtitle: "Favorites",
                          toolCount: _toolsCount["Quick Access"]!,
                          onTap: () => _showQuickAccess(context),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // === FOOTER KECIL ===
                _buildFooter(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _accentColor.withOpacity(0.12),
            Colors.black.withOpacity(0.6),
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _accentColor.withOpacity(0.4), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: _glowColor.withOpacity(0.2),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [_accentColor, _accentSoft]),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: _accentColor.withOpacity(0.5), blurRadius: 8),
              ],
            ),
            child: const Icon(Icons.build_circle_outlined, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "TOOLS DASHBOARD",
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 20,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    shadows: [Shadow(color: _accentColor.withOpacity(0.5), blurRadius: 8)],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Advanced Security & OSINT Suite",
                  style: TextStyle(
                    color: _textSecondary,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _accentColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _accentColor.withOpacity(0.5)),
            ),
            child: Text(
              "v2.0",
              style: TextStyle(
                color: _accentColor,
                fontSize: 10,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStats() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor),
        boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2))],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _statItem(Icons.category, "${_toolsCount.values.reduce((a,b)=>a+b)}", "Total Tools"),
          _statItem(Icons.security, "Active", "Session"),
          _statItem(Icons.badge, userRole.toUpperCase(), "Role"),
        ],
      ),
    );
  }

  Widget _statItem(IconData icon, String value, String label) {
    return Column(
      children: [
        Icon(icon, color: _accentColor, size: 18),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(color: _textPrimary, fontSize: 14, fontWeight: FontWeight.bold),
        ),
        Text(
          label,
          style: TextStyle(color: _textSecondary, fontSize: 10),
        ),
      ],
    );
  }

  Widget _buildToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required int toolCount,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutCubic,
      builder: (context, double scale, child) {
        return Transform.scale(scale: scale, child: child);
      },
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: _cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _borderColor, width: 1),
            boxShadow: [
              BoxShadow(color: Colors.black54, blurRadius: 8, offset: const Offset(0, 4)),
            ],
          ),
          child: Stack(
            children: [
              // Efek gradient border di bagian atas
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: 3,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_accentColor, _accentSoft, Colors.transparent],
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: _accentColor.withOpacity(0.15),
                            shape: BoxShape.circle,
                            border: Border.all(color: _accentColor.withOpacity(0.5), width: 1.5),
                          ),
                          child: Icon(icon, color: _accentColor, size: 24),
                        ),
                        if (toolCount > 0)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: _accentColor.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              "$toolCount",
                              style: TextStyle(
                                color: _accentColor,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      title,
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 15,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: _textSecondary,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                    const Spacer(),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Icon(Icons.arrow_forward, color: _accentColor, size: 16),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ========== BOTTOM SHEET DENGAN DETAIL ==========
  Widget _buildBottomSheet({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: const BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24)),
        border: Border(top: BorderSide(color: _accentColor, width: 2)),
        boxShadow: [BoxShadow(color: _accentColor.withOpacity(0.3), blurRadius: 20)],
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: _accentColor.withOpacity(0.5),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _accentColor.withOpacity(0.08),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(24),
                topRight: Radius.circular(24),
              ),
              border: Border(bottom: BorderSide(color: _accentColor.withOpacity(0.3))),
            ),
            child: Row(
              children: [
                Icon(icon, color: _accentColor, size: 28),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 20,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                Text(
                  "${children.length} tools",
                  style: TextStyle(color: _textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: children,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToolOption({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Card(
      color: _surfaceColor,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: _borderColor, width: 1),
      ),
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _accentColor.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: _accentColor.withOpacity(0.4)),
                ),
                child: Icon(icon, color: _accentColor, size: 20),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: _textPrimary,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: _accentColor, size: 14),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.shield_moon, color: _accentColor.withOpacity(0.6), size: 14),
          const SizedBox(width: 6),
          Text(
            "SECURE ENVIRONMENT • ALL ACTIONS LOGGED",
            style: TextStyle(
              color: _textSecondary.withOpacity(0.6),
              fontSize: 9,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // === FUNGSI NAVIGASI TIDAK BERUBAH ===
  void _showDDoSTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => SizedBox(
        height: MediaQuery.of(context).size.height * 0.6,
        child: _buildBottomSheet(
          title: "DDoS Tools",
          icon: Icons.flash_on,
          children: [
            _buildToolOption(
              icon: Icons.flash_on,
              label: "Attack Panel",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AttackPanel(sessionKey: sessionKey, listDoos: listDoos),
                  ),
                );
              },
            ),
            _buildToolOption(
              icon: Icons.dns,
              label: "Manage Server",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ManageServerPage(keyToken: sessionKey)),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showNetworkTools(BuildContext context) {
    final children = [
      _buildToolOption(
        icon: Icons.newspaper_outlined,
        label: "Spam NGL",
        onTap: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => NglPage()));
        },
      ),
      _buildToolOption(
        icon: Icons.wifi_off,
        label: "WiFi Killer (Internal)",
        onTap: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => WifiKillerPage()));
        },
      ),
    ];
    if (userRole == "vip" || userRole == "owner") {
      children.add(
        _buildToolOption(
          icon: Icons.router,
          label: "WiFi Killer (External)",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)),
            );
          },
        ),
      );
    }
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => SizedBox(
        height: MediaQuery.of(context).size.height * 0.65,
        child: _buildBottomSheet(title: "Network Tools", icon: Icons.wifi, children: children),
      ),
    );
  }

  void _showOSINTTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => SizedBox(
        height: MediaQuery.of(context).size.height * 0.7,
        child: _buildBottomSheet(
          title: "OSINT Tools",
          icon: Icons.search,
          children: [
            _buildToolOption(
              icon: Icons.badge,
              label: "NIK Detail",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
              },
            ),
            _buildToolOption(
              icon: Icons.domain,
              label: "Domain OSINT",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
              },
            ),
            _buildToolOption(
              icon: Icons.person_search,
              label: "Phone Lookup",
              onTap: () => _showComingSoon(context),
            ),
            _buildToolOption(
              icon: Icons.email,
              label: "Email OSINT",
              onTap: () => _showComingSoon(context),
            ),
          ],
        ),
      ),
    );
  }

  void _showDownloaderTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => SizedBox(
        height: MediaQuery.of(context).size.height * 0.55,
        child: _buildBottomSheet(
          title: "Media Downloader",
          icon: Icons.download,
          children: [
            _buildToolOption(
              icon: Icons.video_library,
              label: "TikTok Downloader",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
              },
            ),
            _buildToolOption(
              icon: Icons.camera_alt,
              label: "Instagram Downloader",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showUtilityTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => SizedBox(
        height: MediaQuery.of(context).size.height * 0.6,
        child: _buildBottomSheet(
          title: "Utility Tools",
          icon: Icons.build,
          children: [
            _buildToolOption(
              icon: Icons.qr_code,
              label: "QR Generator",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
              },
            ),
            _buildToolOption(
              icon: Icons.security,
              label: "IP Scanner",
              onTap: () => _showComingSoon(context),
            ),
            _buildToolOption(
              icon: Icons.network_check,
              label: "Port Scanner",
              onTap: () => _showComingSoon(context),
            ),
          ],
        ),
      ),
    );
  }

  void _showQuickAccess(BuildContext context) => _showComingSoon(context);

  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.hourglass_top, color: _textPrimary, size: 18),
            const SizedBox(width: 8),
            Text(
              'Feature Coming Soon!',
              style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, color: _textPrimary),
            ),
          ],
        ),
        backgroundColor: _accentColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: _accentSoft, width: 1),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}