import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  static const Color _bgDark = Color(0xFF0A0A0A);
  static const Color _cardColor = Color(0xFF151515);
  static const Color _surfaceColor = Color(0xFF1A1A1E);
  static const Color _accentColor = Color(0xFFB71C1C);
  static const Color _accentSoft = Color(0xFF8B0000);
  static const Color _textPrimary = Color(0xFFE8E8E8);
  static const Color _textSecondary = Color(0xFF9CA3AF);
  static const Color _borderColor = Color(0xFF2D2D30);
  static const Color _glowColor = Color(0xFFB71C1C);

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: _accentColor),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: Text(
          "CUSTOMER SERVICE",
          style: TextStyle(
            color: _textPrimary,
            fontSize: 16,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            shadows: [Shadow(color: _glowColor.withOpacity(0.4), blurRadius: 8)],
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Colors.transparent, _accentColor, Colors.transparent]),
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background pattern dengan perbaikan
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage('https://www.transparenttextures.com/patterns/carbon-fiber.png'),
                fit: BoxFit.cover,
                repeat: ImageRepeat.repeat,
                opacity: 0.03,
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 180,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [_accentColor.withOpacity(0.05), Colors.transparent],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  Center(
                    child: Container(
                      width: 130,
                      height: 130,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [_accentColor.withOpacity(0.15), Colors.transparent]),
                        border: Border.all(color: _accentColor.withOpacity(0.6), width: 2),
                        boxShadow: [BoxShadow(color: _glowColor.withOpacity(0.4), blurRadius: 30, spreadRadius: 6)],
                      ),
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(color: _accentColor.withOpacity(0.2), shape: BoxShape.circle),
                          child: Icon(Icons.support_agent_rounded, size: 54, color: _accentColor),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(colors: [_textPrimary, _accentColor]).createShader(bounds),
                    child: Text(
                      "NEED HELP?",
                      style: TextStyle(color: _textPrimary, fontSize: 28, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 2),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(color: _surfaceColor, borderRadius: BorderRadius.circular(20), border: Border.all(color: _borderColor)),
                    child: Text("24/7 SUPPORT AVAILABLE", style: TextStyle(color: _accentColor, fontSize: 10, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Hubungi tim kami melalui platform sosial media resmi di bawah ini.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: _textSecondary, fontSize: 13, fontFamily: 'ShareTechMono', height: 1.4),
                  ),
                  const SizedBox(height: 40),
                  Column(
                    children: [
                      _buildContactButton(label: "TELEGRAM", icon: FontAwesomeIcons.telegram, color: const Color(0xFF229ED9), url: "https://t.me/kyu_Reals01"),
                      const SizedBox(height: 16),
                      _buildContactButton(label: "WHATSAPP", icon: FontAwesomeIcons.whatsapp, color: const Color(0xFF25D366), url: "https://wa.me//6285373901036"),
                      const SizedBox(height: 16),
                      _buildContactButton(label: "TIKTOK", icon: FontAwesomeIcons.tiktok, color: const Color(0xFF00F2EA), url: "https://www.tiktok.com/@painloggg?_r=1&_t=ZS-932NwfrWU5o"),
                      const SizedBox(height: 16),
                      _buildContactButton(label: "INSTAGRAM", icon: FontAwesomeIcons.instagram, color: const Color(0xFFE4405F), url: "https://www.instagram.com/darkness_reals?igsh=MWM2MDl5NXg0bTJpNg=="),
                    ],
                  ),
                  const SizedBox(height: 40),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: _surfaceColor, borderRadius: BorderRadius.circular(16), border: Border.all(color: _borderColor)),
                    child: Row(
                      children: [
                        Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: _accentColor.withOpacity(0.15), shape: BoxShape.circle), child: Icon(Icons.shield_moon, color: _accentColor, size: 20)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("RESPONSE TIME", style: TextStyle(color: _textSecondary, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                              const SizedBox(height: 2),
                              Text("Biasanya membalas dalam < 30 menit", style: TextStyle(color: _textPrimary, fontSize: 12)),
                            ],
                          ),
                        ),
                        Icon(Icons.access_time, color: _accentColor, size: 18),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Center(
                    child: Text("© 2024 Official Support • All rights reserved", style: TextStyle(color: _textSecondary.withOpacity(0.5), fontSize: 10, fontFamily: 'ShareTechMono')),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactButton({required String label, required IconData icon, required Color color, required String url}) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutCubic,
      builder: (context, double scale, child) => Transform.scale(scale: scale, child: child),
      child: InkWell(
        onTap: () => _launchUrl(url),
        borderRadius: BorderRadius.circular(20),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: _cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _borderColor, width: 1),
            boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 8, offset: const Offset(0, 4))],
          ),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                width: 4,
                child: Container(decoration: BoxDecoration(color: color, borderRadius: const BorderRadius.only(topLeft: Radius.circular(20), bottomLeft: Radius.circular(20)))),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: color.withOpacity(0.15), shape: BoxShape.circle, border: Border.all(color: color.withOpacity(0.4), width: 1)),
                          child: FaIcon(icon, color: color, size: 22),
                        ),
                        const SizedBox(width: 18),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(label, style: TextStyle(color: _textPrimary, fontSize: 16, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 0.8)),
                            const SizedBox(height: 2),
                            Text("Tap to open", style: TextStyle(color: _textSecondary, fontSize: 10)),
                          ],
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(color: _accentColor.withOpacity(0.1), shape: BoxShape.circle),
                      child: Icon(Icons.arrow_forward, color: color, size: 16),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}