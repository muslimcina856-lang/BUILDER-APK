import 'dart:convert';
import 'dart:ui'; // IMPORT INI UNTUK ImageFilter
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';

class NikCheckerPage extends StatefulWidget {
  const NikCheckerPage({super.key});

  @override
  State<NikCheckerPage> createState() => _NikCheckerPageState();
}

class _NikCheckerPageState extends State<NikCheckerPage> with SingleTickerProviderStateMixin {
  final TextEditingController _nikController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _data;
  String? _errorMessage;

  // ========== TEMA SANGAR GELAP + AKSEN MERAH TUA ==========
  final Color _bgDark = const Color(0xFF0A0A0A);
  final Color _cardColor = const Color(0xFF151515);
  final Color _surfaceColor = const Color(0xFF1A1A1E);
  final Color _accentColor = const Color(0xFFB71C1C);
  final Color _accentSoft = const Color(0xFF8B0000);
  final Color _textPrimary = const Color(0xFFE8E8E8);
  final Color _textSecondary = const Color(0xFF9CA3AF);
  final Color _borderColor = const Color(0xFF2D2D30);
  final Color _glowColor = const Color(0xFFB71C1C);
  final Color _successColor = const Color(0xFF10B981);

  late final AnimationController _animController;
  late final Animation<double> _fadeAnimation;
  late final AnimationController _pulseController;
  late final Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnimation = CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _pulseController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _nikController.dispose();
    _animController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _checkNik() async {
    final nik = _nikController.text.trim();
    if (nik.isEmpty) {
      setState(() {
        _errorMessage = "NIK tidak boleh kosong.";
        _data = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _data = null;
    });

    final url = Uri.parse("https://api.siputzx.my.id/api/tools/nik-checker?nik=$nik");

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() {
            _data = json['data'];
            _errorMessage = null;
          });
          _animController.forward(from: 0);
        } else {
          setState(() {
            _errorMessage = "Data tidak ditemukan atau NIK tidak valid.";
          });
        }
      } else {
        setState(() {
          _errorMessage = "Gagal mengambil data dari server.";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Terjadi kesalahan: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Widget _buildCategoryCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor, width: 1),
        boxShadow: [
          BoxShadow(color: Colors.black54, blurRadius: 8, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _accentColor.withOpacity(0.12),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
              border: Border(bottom: BorderSide(color: _accentColor.withOpacity(0.3))),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: _accentColor.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: _accentColor, size: 18),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }

  Widget _buildInteractiveInfoRow({
    required String label,
    required String? value,
    IconData? copyIcon = Icons.copy,
    VoidCallback? onCopy,
  }) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _borderColor),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: _textSecondary,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          if (onCopy != null)
            Container(
              decoration: BoxDecoration(
                color: _accentColor.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: Icon(copyIcon, color: _accentColor, size: 16),
                onPressed: onCopy,
                padding: const EdgeInsets.all(6),
                constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                tooltip: 'Salin $label',
              ),
            ),
        ],
      ),
    );
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle, color: _textPrimary, size: 18),
            const SizedBox(width: 8),
            Text(
              '$label disalin',
              style: TextStyle(color: _textPrimary, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        backgroundColor: _accentColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: _accentColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'NIK CHECKER',
          style: TextStyle(
            color: _textPrimary,
            fontSize: 18,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            shadows: [Shadow(color: _glowColor.withOpacity(0.4), blurRadius: 8)],
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, _accentColor, Colors.transparent],
              ),
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background pattern karbon - PERBAIKAN: menggunakan ImageRepeat.repeat
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage('https://www.transparenttextures.com/patterns/carbon-fiber.png'),
                repeat: ImageRepeat.repeat, // PERBAIKAN: ganti BoxFit.repeat dengan ImageRepeat.repeat
                opacity: 0.03,
              ),
            ),
          ),
          // Glass overlay atas - PERBAIKAN: import dart:ui sudah ada
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 180,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [_accentColor.withOpacity(0.05), Colors.transparent],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Header icon animasi
                  AnimatedBuilder(
                    animation: _pulseAnimation,
                    builder: (context, child) {
                      return Transform.scale(scale: _pulseAnimation.value, child: child);
                    },
                    child: Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [_accentColor.withOpacity(0.2), Colors.transparent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(color: _accentColor.withOpacity(0.6), width: 1.5),
                        boxShadow: [BoxShadow(color: _glowColor.withOpacity(0.3), blurRadius: 15)],
                      ),
                      child: Icon(Icons.badge, color: _accentColor, size: 34),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Input Section
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _cardColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _borderColor),
                      boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 8, offset: const Offset(0, 4))],
                    ),
                    child: Column(
                      children: [
                        TextField(
                          controller: _nikController,
                          keyboardType: TextInputType.number,
                          style: TextStyle(color: _textPrimary, fontSize: 15),
                          decoration: InputDecoration(
                            labelText: 'NOMOR INDUK KEPENDUDUKAN',
                            labelStyle: TextStyle(color: _textSecondary, fontSize: 12, letterSpacing: 0.5),
                            hintText: 'Contoh: 5206085405880001',
                            hintStyle: TextStyle(color: _textSecondary.withOpacity(0.5), fontSize: 13),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: _borderColor),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: _accentColor, width: 1.5),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            filled: true,
                            fillColor: _surfaceColor,
                            suffixIcon: _isLoading
                                ? Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        color: _accentColor,
                                        strokeWidth: 2,
                                      ),
                                    ),
                                  )
                                : null,
                          ),
                          onSubmitted: (_) => _checkNik(),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: _isLoading ? null : _checkNik,
                            icon: Icon(_isLoading ? Icons.hourglass_top : Icons.search, color: _textPrimary, size: 20),
                            label: Text(
                              _isLoading ? 'PROCESSING...' : 'VERIFY NIK',
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _accentColor,
                              foregroundColor: _textPrimary,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              elevation: 4,
                              shadowColor: _glowColor.withOpacity(0.5),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Error Message
                  if (_errorMessage != null)
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: _accentColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _accentColor.withOpacity(0.4)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.error_outline, color: _accentColor, size: 20),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: TextStyle(color: _textSecondary, fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                    ),

                  const SizedBox(height: 20),

                  // Results Section
                  if (_data != null)
                    Expanded(
                      child: FadeTransition(
                        opacity: _fadeAnimation,
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              // Ringkasan singkat
                              Container(
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: _accentColor.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: _accentColor.withOpacity(0.3)),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(10),
                                      decoration: BoxDecoration(
                                        color: _accentColor.withOpacity(0.2),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(Icons.verified_user, color: _accentColor, size: 24),
                                    ),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            _data!["data"]["nama"]?.toString() ?? "-",
                                            style: TextStyle(color: _textPrimary, fontSize: 16, fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            "NIK: ${_data!["nik"]?.toString() ?? "-"}",
                                            style: TextStyle(color: _textSecondary, fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: _successColor.withOpacity(0.15),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Text(
                                        "VALID",
                                        style: TextStyle(color: _successColor, fontSize: 10, fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16),

                              // Identitas Diri
                              _buildCategoryCard(
                                title: "IDENTITAS DIRI",
                                icon: Icons.person,
                                children: [
                                  _buildInteractiveInfoRow(
                                    label: "NIK",
                                    value: _data!["nik"]?.toString(),
                                    onCopy: () => _copyToClipboard(_data!["nik"]?.toString() ?? "", "NIK"),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Nama Lengkap",
                                    value: _data!["data"]["nama"]?.toString(),
                                    onCopy: () => _copyToClipboard(_data!["data"]["nama"]?.toString() ?? "", "Nama"),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Jenis Kelamin",
                                    value: _data!["data"]["kelamin"]?.toString(),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Tempat Lahir",
                                    value: _data!["data"]["tempat_lahir"]?.toString(),
                                    onCopy: () => _copyToClipboard(_data!["data"]["tempat_lahir"]?.toString() ?? "", "Tempat Lahir"),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Usia",
                                    value: _data!["data"]["usia"]?.toString(),
                                  ),
                                ],
                              ),

                              // Data Domisili
                              _buildCategoryCard(
                                title: "DATA DOMISILI",
                                icon: Icons.location_on,
                                children: [
                                  _buildInteractiveInfoRow(
                                    label: "Provinsi",
                                    value: _data!["data"]["provinsi"]?.toString(),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Kabupaten/Kota",
                                    value: _data!["data"]["kabupaten"]?.toString(),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Kecamatan",
                                    value: _data!["data"]["kecamatan"]?.toString(),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Kelurahan/Desa",
                                    value: _data!["data"]["kelurahan"]?.toString(),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Alamat Lengkap",
                                    value: _data!["data"]["alamat"]?.toString(),
                                    onCopy: () => _copyToClipboard(_data!["data"]["alamat"]?.toString() ?? "", "Alamat"),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "TPS",
                                    value: _data!["data"]["tps"]?.toString(),
                                  ),
                                ],
                              ),

                              // Informasi Tambahan
                              _buildCategoryCard(
                                title: "INFORMASI TAMBAHAN",
                                icon: Icons.info,
                                children: [
                                  _buildInteractiveInfoRow(
                                    label: "Zodiak",
                                    value: _data!["data"]["zodiak"]?.toString(),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Ultah Mendatang",
                                    value: _data!["data"]["ultah_mendatang"]?.toString(),
                                  ),
                                  _buildInteractiveInfoRow(
                                    label: "Pasaran",
                                    value: _data!["data"]["pasaran"]?.toString(),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}