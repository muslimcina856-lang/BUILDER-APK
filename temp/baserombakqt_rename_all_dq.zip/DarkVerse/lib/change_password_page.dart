import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const String baseUrl = "http://papii.queen-official.com:2445";

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;
  bool _obscureOld = true;
  bool _obscureNew = true;
  bool _obscureConfirm = true;

  // ========== TEMA BARU: SANGAR GELAP + AKSEN MERAH TUA ==========
  final Color _bgDark = const Color(0xFF0A0A0A);          // hitam pekat
  final Color _surfaceColor = const Color(0xFF151515);    // surface gelap
  final Color _cardColor = const Color(0xFF1A1A1E);       // untuk card input
  final Color _accentColor = const Color(0xFFB71C1C);     // merah gelap (sangar)
  final Color _accentSoft = const Color(0xFF8B0000);
  final Color _textPrimary = const Color(0xFFE8E8E8);
  final Color _textSecondary = const Color(0xFF9CA3AF);
  final Color _borderColor = const Color(0xFF2D2D30);
  final Color _glowColor = const Color(0xFFB71C1C);

  // Strength indicator
  int _passwordStrength = 0;
  String _strengthText = "";
  Color _strengthColor = Colors.grey;

  void _checkPasswordStrength(String pass) {
    int strength = 0;
    if (pass.length >= 6) strength++;
    if (pass.length >= 10) strength++;
    if (RegExp(r'[A-Z]').hasMatch(pass)) strength++;
    if (RegExp(r'[0-9]').hasMatch(pass)) strength++;
    if (RegExp(r'[!@#$%^&*(),.?":{}|<>]').hasMatch(pass)) strength++;

    setState(() {
      _passwordStrength = strength;
      if (strength <= 2) {
        _strengthText = "Weak";
        _strengthColor = const Color(0xFFEF4444);
      } else if (strength <= 4) {
        _strengthText = "Medium";
        _strengthColor = const Color(0xFFF59E0B);
      } else {
        _strengthText = "Strong";
        _strengthColor = const Color(0xFF10B981);
      }
    });
  }

  Future<void> _changePassword() async {
    final oldPass = oldPassCtrl.text.trim();
    final newPass = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showMessage("Semua field harus diisi.");
      return;
    }

    if (newPass != confirmPass) {
      _showMessage("Password baru tidak cocok dengan konfirmasi.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _showMessage("Password berhasil diubah!", isSuccess: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
        _passwordStrength = 0;
      } else {
        _showMessage(data['message'] ?? "Gagal mengubah password");
      }
    } catch (e) {
      _showMessage("Koneksi error: $e");
    }

    setState(() => isLoading = false);
  }

  void _showMessage(String msg, {bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _accentColor, width: 1.5),
        ),
        title: Row(
          children: [
            Icon(
              isSuccess ? Icons.check_circle_outline : Icons.warning_amber_rounded,
              color: _accentColor,
            ),
            const SizedBox(width: 10),
            Text(
              isSuccess ? "Sukses" : "Peringatan",
              style: TextStyle(
                color: _textPrimary,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ],
        ),
        content: Text(msg, style: TextStyle(color: _textSecondary)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: _accentColor),
                borderRadius: BorderRadius.circular(8),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text("OK", style: TextStyle(color: _accentColor, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required bool obscure,
    required VoidCallback onToggle,
    String? suffixText,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderColor),
        boxShadow: [
          BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2)),
        ],
      ),
      child: TextFormField(
        controller: controller,
        obscureText: obscure,
        onChanged: (value) {
          if (controller == newPassCtrl) _checkPasswordStrength(value);
        },
        style: TextStyle(color: _textPrimary, fontSize: 15),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: _textSecondary, fontSize: 13),
          prefixIcon: Icon(icon, color: _accentColor, size: 20),
          suffixIcon: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (suffixText != null)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Text(
                    suffixText,
                    style: TextStyle(color: _strengthColor, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ),
              IconButton(
                icon: Icon(
                  obscure ? Icons.visibility_off : Icons.visibility,
                  color: _textSecondary,
                  size: 18,
                ),
                onPressed: onToggle,
              ),
            ],
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: _accentColor),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: Text(
          "CHANGE PASSWORD",
          style: TextStyle(
            color: _textPrimary,
            fontSize: 18,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            shadows: [Shadow(color: _glowColor.withOpacity(0.4), blurRadius: 8)],
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, _accentColor, Colors.transparent],
              ),
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background pattern (grid halus) - DIPERBAIKI
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage('https://www.transparenttextures.com/patterns/carbon-fiber.png'),
                fit: BoxFit.cover,
                repeat: ImageRepeat.repeat,
                opacity: 0.03,
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),

                  // Header Icon dengan efek glow
                  Center(
                    child: Container(
                      width: 110,
                      height: 110,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [_accentColor.withOpacity(0.2), _accentSoft.withOpacity(0.05)],
                        ),
                        border: Border.all(color: _accentColor.withOpacity(0.6), width: 2),
                        boxShadow: [
                          BoxShadow(color: _glowColor.withOpacity(0.4), blurRadius: 25, spreadRadius: 5),
                        ],
                      ),
                      child: Icon(Icons.lock_reset, color: _accentColor, size: 54),
                    ),
                  ),
                  const SizedBox(height: 20),

                  Center(
                    child: Text(
                      "SECURITY UPDATE",
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 22,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Center(
                    child: Text(
                      "Perbarui kata sandi Anda dengan aman",
                      style: TextStyle(
                        color: _textSecondary,
                        fontSize: 13,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),

                  // Form Inputs
                  _buildInput(
                    controller: oldPassCtrl,
                    label: "OLD PASSWORD",
                    icon: Icons.lock_outline,
                    obscure: _obscureOld,
                    onToggle: () => setState(() => _obscureOld = !_obscureOld),
                  ),
                  _buildInput(
                    controller: newPassCtrl,
                    label: "NEW PASSWORD",
                    icon: Icons.vpn_key,
                    obscure: _obscureNew,
                    onToggle: () => setState(() => _obscureNew = !_obscureNew),
                    suffixText: _passwordStrength > 0 ? _strengthText : null,
                  ),
                  // Indikator kekuatan password (progress bar)
                  if (_passwordStrength > 0)
                    Container(
                      margin: const EdgeInsets.only(top: -12, bottom: 16),
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: _passwordStrength / 5,
                              backgroundColor: _borderColor,
                              valueColor: AlwaysStoppedAnimation<Color>(_strengthColor),
                              minHeight: 4,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              _strengthText,
                              style: TextStyle(color: _strengthColor, fontSize: 10, fontWeight: FontWeight.w500),
                            ),
                          ),
                        ],
                      ),
                    ),
                  _buildInput(
                    controller: confirmPassCtrl,
                    label: "CONFIRM PASSWORD",
                    icon: Icons.enhanced_encryption,
                    obscure: _obscureConfirm,
                    onToggle: () => setState(() => _obscureConfirm = !_obscureConfirm),
                  ),

                  const SizedBox(height: 30),

                  // Tombol Update dengan efek gradien merah
                  Container(
                    width: double.infinity,
                    height: 55,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_accentColor, _accentSoft],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(color: _glowColor.withOpacity(0.4), blurRadius: 12, offset: Offset(0, 4)),
                      ],
                    ),
                    child: ElevatedButton(
                      onPressed: isLoading ? null : _changePassword,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: isLoading
                          ? SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(strokeWidth: 2, color: _textPrimary),
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.update, color: _textPrimary, size: 20),
                                const SizedBox(width: 10),
                                Text(
                                  "UPDATE PASSWORD",
                                  style: TextStyle(
                                    color: _textPrimary,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Orbitron',
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Footer security note
                  Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: _surfaceColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _borderColor),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.shield_moon, color: _accentColor, size: 16),
                          const SizedBox(width: 8),
                          Text(
                            "Gunakan password yang kuat dan unik",
                            style: TextStyle(color: _textSecondary, fontSize: 11, fontFamily: 'ShareTechMono'),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}