import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RiwayatPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage> with SingleTickerProviderStateMixin {
  // ========== TEMA SANGAR GELAP + AKSEN MERAH TUA ==========
  final Color _bgDark = const Color(0xFF0A0A0A);
  final Color _cardColor = const Color(0xFF151515);
  final Color _surfaceColor = const Color(0xFF1A1A1E);
  final Color _accentColor = const Color(0xFFB71C1C);   // merah gelap tegas
  final Color _accentSoft = const Color(0xFF8B0000);
  final Color _textPrimary = const Color(0xFFE8E8E8);
  final Color _textSecondary = const Color(0xFF9CA3AF);
  final Color _borderColor = const Color(0xFF2D2D30);
  final Color _glowColor = const Color(0xFFB71C1C);

  // Warna khusus untuk tipe aktivitas
  final Color _loginColor = const Color(0xFF10B981);   // hijau
  final Color _attackColor = const Color(0xFFF59E0B);  // orange
  final Color _createColor = const Color(0xFF06B6D4);  // cyan
  final Color _systemColor = const Color(0xFF6B7280);  // abu

  List<ActivityModel> activities = [];
  bool isLoading = true;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _loadActivities();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _loadActivities() async {
    const baseUrl = "http://papii.queen-official.com:2445";

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/getMyActivity?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid']) {
          List<dynamic> rawList = data['activities'];

          setState(() {
            activities = rawList.map((item) {
              return ActivityModel(
                type: item['type'] ?? 'system',
                title: item['title'] ?? 'Aktivitas',
                description: item['description'] ?? '-',
                timestamp: DateTime.fromMillisecondsSinceEpoch(
                  item['timestamp'] ?? DateTime.now().millisecondsSinceEpoch
                ),
              );
            }).toList();
            isLoading = false;
          });
          _fadeController.forward(from: 0);
        } else {
          setState(() => isLoading = false);
        }
      } else {
        print("Server Error: ${response.statusCode}");
        setState(() => isLoading = false);
      }
    } catch (e) {
      print("Error fetching history: $e");
      setState(() => isLoading = false);
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm:ss').format(date);
  }

  String _formatRelativeTime(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);
    if (diff.inDays > 7) return _formatDate(date);
    if (diff.inDays >= 1) return "${diff.inDays} hari lalu";
    if (diff.inHours >= 1) return "${diff.inHours} jam lalu";
    if (diff.inMinutes >= 1) return "${diff.inMinutes} menit lalu";
    return "Baru saja";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: _accentColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "ACTIVITY LOG",
          style: TextStyle(
            color: _textPrimary,
            fontSize: 18,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            shadows: [Shadow(color: _glowColor.withOpacity(0.4), blurRadius: 8)],
          ),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, _accentColor, Colors.transparent],
              ),
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background pattern karbon - DIPERBAIKI
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage('https://www.transparenttextures.com/patterns/carbon-fiber.png'),
                fit: BoxFit.cover,
                repeat: ImageRepeat.repeat,
                opacity: 0.03,
              ),
            ),
          ),
          // Glass overlay atas
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 180,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [_accentColor.withOpacity(0.05), Colors.transparent],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: isLoading
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 40,
                          height: 40,
                          child: CircularProgressIndicator(
                            color: _accentColor,
                            strokeWidth: 2.5,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          "MEMUAT DATA...",
                          style: TextStyle(
                            color: _textSecondary,
                            fontSize: 12,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  )
                : activities.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: _surfaceColor,
                                shape: BoxShape.circle,
                                border: Border.all(color: _borderColor),
                              ),
                              child: Icon(Icons.history_toggle_off, size: 50, color: _textSecondary),
                            ),
                            const SizedBox(height: 20),
                            Text(
                              "TIDAK ADA AKTIVITAS",
                              style: TextStyle(
                                color: _textPrimary,
                                fontSize: 16,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              "Belum ada catatan aktivitas",
                              style: TextStyle(color: _textSecondary, fontSize: 13),
                            ),
                          ],
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _loadActivities,
                        color: _accentColor,
                        backgroundColor: _cardColor,
                        child: FadeTransition(
                          opacity: _fadeAnimation,
                          child: ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: activities.length,
                            itemBuilder: (context, index) {
                              final activity = activities[index];
                              return _buildActivityCard(activity, index);
                            },
                          ),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityCard(ActivityModel activity, int index) {
    // Tentukan warna dan ikon berdasarkan tipe
    Color iconColor;
    IconData iconData;
    String typeLabel;
    Color badgeColor;

    switch (activity.type) {
      case 'login':
        iconColor = _loginColor;
        iconData = Icons.login_rounded;
        typeLabel = "LOGIN";
        badgeColor = _loginColor;
        break;
      case 'bug':
        iconColor = _attackColor;
        iconData = Icons.flash_on;
        typeLabel = "ATTACK";
        badgeColor = _attackColor;
        break;
      case 'create':
        iconColor = _createColor;
        iconData = Icons.person_add_alt_1_rounded;
        typeLabel = "CREATE";
        badgeColor = _createColor;
        break;
      default:
        iconColor = _systemColor;
        iconData = Icons.info_outline;
        typeLabel = "SYSTEM";
        badgeColor = _systemColor;
    }

    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + (index * 50)),
      curve: Curves.easeOutCubic,
      builder: (context, double scale, child) {
        return Transform.scale(scale: scale, child: child);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: _cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _borderColor, width: 1),
          boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 6, offset: const Offset(0, 3))],
        ),
        child: Stack(
          children: [
            // Strip warna di sisi kiri
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              width: 4,
              child: Container(
                decoration: BoxDecoration(
                  color: iconColor,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Ikon dengan efek glow
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: iconColor.withOpacity(0.12),
                      shape: BoxShape.circle,
                      border: Border.all(color: iconColor.withOpacity(0.4), width: 1),
                      boxShadow: [
                        BoxShadow(color: iconColor.withOpacity(0.2), blurRadius: 6),
                      ],
                    ),
                    child: Icon(iconData, color: iconColor, size: 22),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                activity.title,
                                style: TextStyle(
                                  color: _textPrimary,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 0.3,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: badgeColor.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: badgeColor.withOpacity(0.4)),
                              ),
                              child: Text(
                                typeLabel,
                                style: TextStyle(
                                  color: badgeColor,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          activity.description,
                          style: TextStyle(
                            color: _textSecondary,
                            fontSize: 13,
                            height: 1.4,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Icon(Icons.access_time, size: 12, color: _textSecondary.withOpacity(0.6)),
                            const SizedBox(width: 6),
                            Text(
                              _formatRelativeTime(activity.timestamp),
                              style: TextStyle(
                                color: _textSecondary.withOpacity(0.7),
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                            const SizedBox(width: 12),
                            Container(
                              width: 3,
                              height: 3,
                              decoration: BoxDecoration(
                                color: _textSecondary.withOpacity(0.5),
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              _formatDate(activity.timestamp),
                              style: TextStyle(
                                color: _textSecondary.withOpacity(0.5),
                                fontSize: 10,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ActivityModel {
  final String type;
  final String title;
  final String description;
  final DateTime timestamp;

  ActivityModel({
    required this.type,
    required this.title,
    required this.description,
    required this.timestamp,
  });
}