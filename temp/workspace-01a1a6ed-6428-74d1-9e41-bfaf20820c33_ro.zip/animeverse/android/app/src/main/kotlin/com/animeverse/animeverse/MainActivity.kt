package com.animeverse.animeverse

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
