import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../data/providers.dart';
import '../../features/admin/admin_screen.dart';
import '../../features/auth/forgot_password_screen.dart';
import '../../features/auth/login_screen.dart';
import '../../features/auth/onboarding_screen.dart';
import '../../features/auth/register_screen.dart';
import '../../features/auth/splash_screen.dart';
import '../../features/auth/verify_email_screen.dart';
import '../../features/catalog/category_screen.dart';
import '../../features/catalog/search_screen.dart';
import '../../features/community/community_screen.dart';
import '../../features/detail/media_detail_screen.dart';
import '../../features/gamification/achievements_screen.dart';
import '../../features/gamification/leaderboard_screen.dart';
import '../../features/gamification/quests_screen.dart';
import '../../features/home/home_screen.dart';
import '../../features/library/bookmark_screen.dart';
import '../../features/library/download_screen.dart';
import '../../features/library/history_screen.dart';
import '../../features/library/library_screen.dart';
import '../../features/membership/membership_screen.dart';
import '../../features/notifications/notifications_screen.dart';
import '../../features/player/video_player_screen.dart';
import '../../features/profile/browse_categories_screen.dart';
import '../../features/profile/edit_profile_screen.dart';
import '../../features/profile/profile_screen.dart';
import '../../features/profile/settings_screen.dart';
import '../../features/reader/comic_reader_screen.dart';
import '../../features/reader/novel_reader_screen.dart';
import '../../features/schedule/schedule_screen.dart';
import '../../features/support/faq_screen.dart';
import '../../shared/widgets/app_network_image.dart';
import '../theme/app_colors.dart';
import '../../features/shell/main_shell.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>();
final _shellNavigatorKey = GlobalKey<NavigatorState>();

/// Route yang membutuhkan login.
const Set<String> protectedRoutes = {
  '/library',
  '/profile',
  '/community',
  '/notifications',
  '/membership',
  '/settings',
  '/edit-profile',
  '/achievements',
  '/quests',
  '/admin',
  '/bookmarks',
  '/downloads',
  '/history',
};

class _RouterNotifier extends ChangeNotifier {
  _RouterNotifier(this._ref) {
    _ref.listen<SessionState>(
      sessionProvider,
      (previous, next) {
        if (previous?.status != next.status ||
            previous?.profile?.role != next.profile?.role) {
          notifyListeners();
        }
      },
    );
  }

  final Ref _ref;
}

final routerProvider = Provider<GoRouter>((ref) {
  final notifier = _RouterNotifier(ref);
  ref.onDispose(notifier.dispose);

  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/splash',
    refreshListenable: notifier,
    debugLogDiagnostics: kDebugMode,
    redirect: (context, state) {
      final session = ref.read(sessionProvider);
      final location = state.matchedLocation;
      final loggingIn = const {
        '/splash',
        '/onboarding',
        '/login',
        '/register',
        '/forgot-password',
        '/verify-email',
      }.contains(location);

      if (session.status == SessionStatus.loading) {
        return location == '/splash' ? null : '/splash';
      }
      final needsAuth = protectedRoutes.any(
        (route) => location == route || location.startsWith('$route/'),
      );
      if (!session.isAuthenticated && needsAuth) {
        return '/login?redirect=${Uri.encodeComponent(state.uri.toString())}';
      }
      if (session.isAuthenticated && loggingIn) {
        return '/home';
      }
      if (location.startsWith('/admin') && !session.isAdmin) {
        return '/home';
      }
      return null;
    },
    routes: [
      GoRoute(
        path: '/splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/onboarding',
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: '/login',
        builder: (context, state) => LoginScreen(
          redirect: state.uri.queryParameters['redirect'],
        ),
      ),
      GoRoute(
        path: '/register',
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(
        path: '/forgot-password',
        builder: (context, state) => const ForgotPasswordScreen(),
      ),
      GoRoute(
        path: '/verify-email',
        builder: (context, state) => VerifyEmailScreen(
          email: state.uri.queryParameters['email'] ?? '',
        ),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) =>
            MainShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(
            navigatorKey: _shellNavigatorKey,
            routes: [
              GoRoute(path: '/home', builder: (context, state) => const HomeScreen()),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/browse',
                builder: (context, state) => const BrowseCategoriesScreen(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/community',
                builder: (context, state) => const CommunityScreen(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/library',
                builder: (context, state) => const LibraryScreen(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/profile',
                builder: (context, state) => const ProfileScreen(),
              ),
            ],
          ),
        ],
      ),
      GoRoute(
        path: '/category/:slug',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => CategoryScreen(
          slug: state.pathParameters['slug'] ?? 'anime',
        ),
      ),
      GoRoute(
        path: '/search',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => SearchScreen(
          initialQuery: state.uri.queryParameters['q'],
        ),
      ),
      GoRoute(
        path: '/media',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => MediaDetailScreen(
          mediaId: state.uri.queryParameters['id'] ?? '',
          kindSlug: state.uri.queryParameters['kind'] ?? 'anime',
        ),
      ),
      GoRoute(
        path: '/watch',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => VideoPlayerScreen(
          mediaId: state.uri.queryParameters['id'] ?? '',
          kindSlug: state.uri.queryParameters['kind'] ?? 'anime',
          episode: int.tryParse(state.uri.queryParameters['episode'] ?? '1') ?? 1,
          title: state.uri.queryParameters['title'],
        ),
      ),
      GoRoute(
        path: '/read-comic',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => ComicReaderScreen(
          mediaId: state.uri.queryParameters['mediaId'] ?? '',
          chapterId: state.uri.queryParameters['chapterId'] ?? '',
          kindSlug: state.uri.queryParameters['kind'] ?? 'manga',
          title: state.uri.queryParameters['title'],
          chapterNumber: state.uri.queryParameters['chapter'],
        ),
      ),
      GoRoute(
        path: '/read-novel',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => NovelReaderScreen(
          mediaId: state.uri.queryParameters['mediaId'] ?? '',
          startIndex: int.tryParse(state.uri.queryParameters['index'] ?? '1') ?? 1,
          title: state.uri.queryParameters['title'],
        ),
      ),
      GoRoute(
        path: '/history',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const HistoryScreen(),
      ),
      GoRoute(
        path: '/bookmarks',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const BookmarkScreen(),
      ),
      GoRoute(
        path: '/downloads',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const DownloadScreen(),
      ),
      GoRoute(
        path: '/notifications',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const NotificationsScreen(),
      ),
      GoRoute(
        path: '/membership',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const MembershipScreen(),
      ),
      GoRoute(
        path: '/achievements',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const AchievementsScreen(),
      ),
      GoRoute(
        path: '/quests',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const QuestsScreen(),
      ),
      GoRoute(
        path: '/leaderboard',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const LeaderboardScreen(),
      ),
      GoRoute(
        path: '/settings',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const SettingsScreen(),
      ),
      GoRoute(
        path: '/edit-profile',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const EditProfileScreen(),
      ),
      GoRoute(
        path: '/schedule',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const ScheduleScreen(),
      ),
      GoRoute(
        path: '/faq',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const FaqScreen(),
      ),
      GoRoute(
        path: '/admin',
        parentNavigatorKey: _rootNavigatorKey,
        builder: (context, state) => const AdminScreen(),
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Halaman tidak ditemukan')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const AppNetworkImage(url: null, width: 120, height: 120),
              const SizedBox(height: 20),
              Text(
                'Rute "${state.uri}" tidak tersedia.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: () => context.go('/home'),
                child: const Text('Kembali ke Beranda'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
});
