import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/local_store.dart';

/// Preferensi aplikasi yang tersimpan lokal (dan disinkronkan ke
/// `user_settings` saat Supabase aktif).
class AppSettings {
  const AppSettings({
    this.themeMode = ThemeMode.dark,
    this.locale = 'id',
    this.streamingQuality = 720,
    this.autoPlayNext = true,
    this.skipIntroEnabled = true,
    this.subtitleLanguage = 'id',
    this.downloadWifiOnly = true,
    this.notificationsEnabled = true,
    this.autoSaveProgress = true,
    this.readerDirectionRtl = false,
    this.readerNightMode = true,
    this.readerFontSize = 18,
    this.readerLineHeight = 1.7,
    this.readerFontFamily = 'Roboto',
    this.readerBackground = 'dark',
    this.reduceMotion = false,
    this.dataSaver = false,
  });

  final ThemeMode themeMode;
  final String locale;
  final int streamingQuality;
  final bool autoPlayNext;
  final bool skipIntroEnabled;
  final String subtitleLanguage;
  final bool downloadWifiOnly;
  final bool notificationsEnabled;
  final bool autoSaveProgress;
  final bool readerDirectionRtl;
  final bool readerNightMode;
  final double readerFontSize;
  final double readerLineHeight;
  final String readerFontFamily;
  final String readerBackground;
  final bool reduceMotion;
  final bool dataSaver;

  static const List<String> readerFonts = ['Roboto', 'Serif', 'Monospace', 'Georgia'];

  AppSettings copyWith({
    ThemeMode? themeMode,
    String? locale,
    int? streamingQuality,
    bool? autoPlayNext,
    bool? skipIntroEnabled,
    String? subtitleLanguage,
    bool? downloadWifiOnly,
    bool? notificationsEnabled,
    bool? autoSaveProgress,
    bool? readerDirectionRtl,
    bool? readerNightMode,
    double? readerFontSize,
    double? readerLineHeight,
    String? readerFontFamily,
    String? readerBackground,
    bool? reduceMotion,
    bool? dataSaver,
  }) =>
      AppSettings(
        themeMode: themeMode ?? this.themeMode,
        locale: locale ?? this.locale,
        streamingQuality: streamingQuality ?? this.streamingQuality,
        autoPlayNext: autoPlayNext ?? this.autoPlayNext,
        skipIntroEnabled: skipIntroEnabled ?? this.skipIntroEnabled,
        subtitleLanguage: subtitleLanguage ?? this.subtitleLanguage,
        downloadWifiOnly: downloadWifiOnly ?? this.downloadWifiOnly,
        notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
        autoSaveProgress: autoSaveProgress ?? this.autoSaveProgress,
        readerDirectionRtl: readerDirectionRtl ?? this.readerDirectionRtl,
        readerNightMode: readerNightMode ?? this.readerNightMode,
        readerFontSize: readerFontSize ?? this.readerFontSize,
        readerLineHeight: readerLineHeight ?? this.readerLineHeight,
        readerFontFamily: readerFontFamily ?? this.readerFontFamily,
        readerBackground: readerBackground ?? this.readerBackground,
        reduceMotion: reduceMotion ?? this.reduceMotion,
        dataSaver: dataSaver ?? this.dataSaver,
      );

  Map<String, dynamic> toJson() => {
        'themeMode': themeMode.name,
        'locale': locale,
        'streamingQuality': streamingQuality,
        'autoPlayNext': autoPlayNext,
        'skipIntroEnabled': skipIntroEnabled,
        'subtitleLanguage': subtitleLanguage,
        'downloadWifiOnly': downloadWifiOnly,
        'notificationsEnabled': notificationsEnabled,
        'autoSaveProgress': autoSaveProgress,
        'readerDirectionRtl': readerDirectionRtl,
        'readerNightMode': readerNightMode,
        'readerFontSize': readerFontSize,
        'readerLineHeight': readerLineHeight,
        'readerFontFamily': readerFontFamily,
        'readerBackground': readerBackground,
        'reduceMotion': reduceMotion,
        'dataSaver': dataSaver,
      };

  factory AppSettings.fromJson(Map<String, dynamic> json) => AppSettings(
        themeMode: ThemeMode.values.firstWhere(
          (value) => value.name == json['themeMode'],
          orElse: () => ThemeMode.dark,
        ),
        locale: json['locale'] as String? ?? 'id',
        streamingQuality: (json['streamingQuality'] as num?)?.toInt() ?? 720,
        autoPlayNext: json['autoPlayNext'] as bool? ?? true,
        skipIntroEnabled: json['skipIntroEnabled'] as bool? ?? true,
        subtitleLanguage: json['subtitleLanguage'] as String? ?? 'id',
        downloadWifiOnly: json['downloadWifiOnly'] as bool? ?? true,
        notificationsEnabled: json['notificationsEnabled'] as bool? ?? true,
        autoSaveProgress: json['autoSaveProgress'] as bool? ?? true,
        readerDirectionRtl: json['readerDirectionRtl'] as bool? ?? false,
        readerNightMode: json['readerNightMode'] as bool? ?? true,
        readerFontSize: (json['readerFontSize'] as num?)?.toDouble() ?? 18,
        readerLineHeight: (json['readerLineHeight'] as num?)?.toDouble() ?? 1.7,
        readerFontFamily: json['readerFontFamily'] as String? ?? 'Roboto',
        readerBackground: json['readerBackground'] as String? ?? 'dark',
        reduceMotion: json['reduceMotion'] as bool? ?? false,
        dataSaver: json['dataSaver'] as bool? ?? false,
      );
}

class SettingsController extends StateNotifier<AppSettings> {
  SettingsController() : super(_load());

  static const String _key = 'app::settings';

  static AppSettings _load() {
    final raw = LocalStore.getJson(_key);
    if (raw == null) return const AppSettings();
    return AppSettings.fromJson(raw);
  }

  Future<void> update(AppSettings settings) async {
    state = settings;
    await LocalStore.setJson(_key, settings.toJson());
  }

  Future<void> patch({
    ThemeMode? themeMode,
    int? streamingQuality,
    bool? autoPlayNext,
    bool? skipIntroEnabled,
    String? subtitleLanguage,
    bool? downloadWifiOnly,
    bool? notificationsEnabled,
    bool? autoSaveProgress,
    bool? readerDirectionRtl,
    bool? readerNightMode,
    double? readerFontSize,
    double? readerLineHeight,
    String? readerFontFamily,
    String? readerBackground,
    bool? reduceMotion,
    bool? dataSaver,
    String? locale,
  }) =>
      update(state.copyWith(
        themeMode: themeMode,
        streamingQuality: streamingQuality,
        autoPlayNext: autoPlayNext,
        skipIntroEnabled: skipIntroEnabled,
        subtitleLanguage: subtitleLanguage,
        downloadWifiOnly: downloadWifiOnly,
        notificationsEnabled: notificationsEnabled,
        autoSaveProgress: autoSaveProgress,
        readerDirectionRtl: readerDirectionRtl,
        readerNightMode: readerNightMode,
        readerFontSize: readerFontSize,
        readerLineHeight: readerLineHeight,
        readerFontFamily: readerFontFamily,
        readerBackground: readerBackground,
        reduceMotion: reduceMotion,
        dataSaver: dataSaver,
        locale: locale,
      ));

  Future<void> toggleTheme() => patch(
        themeMode:
            state.themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark,
      );
}
