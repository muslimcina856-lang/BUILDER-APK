import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/app_config.dart';

/// Wrapper tipis di atas Supabase.
///
/// Semua repository memeriksa [enabled]; bila kredensial Supabase belum diisi
/// aplikasi memakai penyimpanan lokal sehingga tetap berfungsi penuh (mode
/// demo). Begitu kredensial di-*inject* lewat `--dart-define`, seluruh data
/// otomatis pindah ke PostgreSQL + RLS.
class SupabaseGateway {
  SupabaseGateway._();

  static final SupabaseGateway instance = SupabaseGateway._();

  SupabaseClient? _client;
  bool _initialized = false;

  bool get enabled => _initialized && _client != null;

  SupabaseClient get client {
    final value = _client;
    if (value == null) {
      throw StateError(
        'Supabase belum dikonfigurasi. Jalankan dengan --dart-define=SUPABASE_URL=... ',
      );
    }
    return value;
  }

  Future<bool> initialize() async {
    if (_initialized) return enabled;
    _initialized = true;
    if (!AppConfig.hasSupabase) {
      debugPrint('[Supabase] kredensial kosong → mode lokal aktif');
      return false;
    }
    try {
      await Supabase.initialize(
        url: AppConfig.supabaseUrl,
        anonKey: AppConfig.supabaseAnonKey,
        debug: kDebugMode,
      );
      _client = Supabase.instance.client;
      return true;
    } catch (error) {
      debugPrint('[Supabase] gagal inisialisasi: $error → mode lokal');
      _client = null;
      return false;
    }
  }

  String? get currentUserId => _client?.auth.currentUser?.id;

  Stream<AuthState>? get authStateChanges => _client?.auth.onAuthStateChange;

  // ─────────────────────────── Query helpers ───────────────────────────

  Future<List<Map<String, dynamic>>> select(
    String table, {
    Map<String, dynamic>? eq,
    Map<String, dynamic>? neq,
    String? orderBy,
    bool ascending = false,
    int? limit,
    String columns = '*',
  }) async {
    if (!enabled) return const [];
    try {
      var query = client.from(table).select(columns);
      if (eq != null) {
        for (final entry in eq.entries) {
          query = query.eq(entry.key, entry.value);
        }
      }
      if (neq != null) {
        for (final entry in neq.entries) {
          query = query.neq(entry.key, entry.value);
        }
      }
      if (orderBy != null) {
        query = query.order(orderBy, ascending: ascending);
      }
      if (limit != null) query = query.limit(limit);
      final response = await query;
      return (response as List)
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .toList();
    } catch (error) {
      debugPrint('[Supabase] select $table gagal: $error');
      return const [];
    }
  }

  Future<Map<String, dynamic>?> single(
    String table, {
    required Map<String, dynamic> eq,
    String columns = '*',
  }) async {
    final rows = await select(table, eq: eq, limit: 1, columns: columns);
    return rows.isEmpty ? null : rows.first;
  }

  Future<bool> upsert(
    String table,
    Map<String, dynamic> data, {
    String onConflict = 'id',
  }) async {
    if (!enabled) return false;
    try {
      await client.from(table).upsert(data, onConflict: onConflict);
      return true;
    } catch (error) {
      debugPrint('[Supabase] upsert $table gagal: $error');
      return false;
    }
  }

  Future<bool> insert(String table, Map<String, dynamic> data) async {
    if (!enabled) return false;
    try {
      await client.from(table).insert(data);
      return true;
    } catch (error) {
      debugPrint('[Supabase] insert $table gagal: $error');
      return false;
    }
  }

  Future<bool> update(
    String table,
    Map<String, dynamic> data, {
    required Map<String, dynamic> eq,
  }) async {
    if (!enabled) return false;
    try {
      var query = client.from(table).update(data);
      for (final entry in eq.entries) {
        query = query.eq(entry.key, entry.value);
      }
      await query;
      return true;
    } catch (error) {
      debugPrint('[Supabase] update $table gagal: $error');
      return false;
    }
  }

  Future<bool> delete(String table, {required Map<String, dynamic> eq}) async {
    if (!enabled) return false;
    try {
      var query = client.from(table).delete();
      for (final entry in eq.entries) {
        query = query.eq(entry.key, entry.value);
      }
      await query;
      return true;
    } catch (error) {
      debugPrint('[Supabase] delete $table gagal: $error');
      return false;
    }
  }

  Future<dynamic> rpc(String function, {Map<String, dynamic>? params}) async {
    if (!enabled) return null;
    try {
      return await client.rpc(function, params: params);
    } catch (error) {
      debugPrint('[Supabase] rpc $function gagal: $error');
      return null;
    }
  }

  // ───────────────────────────── Storage ─────────────────────────────

  /// Upload foto profil / cover. Mengembalikan public URL.
  Future<String?> uploadImage({
    required String bucket,
    required String path,
    required Uint8List bytes,
    String contentType = 'image/jpeg',
  }) async {
    if (!enabled) return null;
    try {
      await client.storage.from(bucket).uploadBinary(
            path,
            bytes,
            fileOptions: FileOptions(
              contentType: contentType,
              upsert: true,
            ),
          );
      return client.storage.from(bucket).getPublicUrl(path);
    } catch (error) {
      debugPrint('[Supabase] upload $bucket/$path gagal: $error');
      return null;
    }
  }

  /// Realtime stream untuk komentar / chat.
  RealtimeChannel? channel(String name) =>
      enabled ? client.channel(name) : null;
}
