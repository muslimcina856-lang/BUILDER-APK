import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../config/app_config.dart';
import 'local_store.dart';

/// Cache dua lapis (memori + disk) dengan TTL untuk mencegah pemanggilan API
/// berlebihan (rate-limit AniList 90 req/menit, MangaDex 5 req/detik).
class CacheService {
  CacheService._();

  static final Map<String, _CacheEntry> _memory = {};
  static const String _prefix = 'cache::';

  static T? read<T>(String key, {Duration? ttl}) {
    final effectiveTtl = ttl ?? AppConfig.memoryCacheTtl;
    final entry = _memory[key];
    if (entry != null && !entry.isExpired(effectiveTtl)) {
      return entry.value as T?;
    }
    final diskKey = '$_prefix$key';
    final raw = LocalStore.getString(diskKey);
    if (raw == null) return null;
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      final savedAt = DateTime.parse(decoded['at'] as String);
      final age = DateTime.now().difference(savedAt);
      final maxAge = ttl ?? AppConfig.diskCacheTtl;
      if (age > maxAge) return decodeCached(decoded['data']);
      final value = decodeCached(decoded['data']);
      _memory[key] = _CacheEntry(value, savedAt);
      return value as T?;
    } catch (error) {
      debugPrint('[Cache] read failed: $error');
      return null;
    }
  }

  static Future<void> write(String key, Object? value, {Object? Function()? encode}) async {
    final now = DateTime.now();
    _memory[key] = _CacheEntry(value, now);
    try {
      final payload = {
        'at': now.toIso8601String(),
        'data': encode != null ? encode() : encodeForCache(value),
      };
      await LocalStore.setString('$_prefix$key', jsonEncode(payload));
    } catch (error) {
      debugPrint('[Cache] write failed: $error');
    }
  }

  /// Mengambil dari cache bila masih valid, jika tidak jalankan [fetcher].
  static Future<T> remember<T>(
    String key,
    Future<T> Function() fetcher, {
    Duration? ttl,
    Object? Function(T value)? encode,
    T? Function(Object? raw)? decode,
  }) async {
    final cached = read<T>(key, ttl: ttl);
    if (cached != null) return cached;
    final fresh = await fetcher();
    await write(key, fresh, encode: encode == null ? null : () => encode(fresh));
    return fresh;
  }

  static Future<void> invalidate(String key) async {
    _memory.remove(key);
    await LocalStore.remove('$_prefix$key');
  }

  static Future<void> clear() async {
    _memory.clear();
    for (final key in LocalStore.getJsonList('${_prefix}index')) {
      await LocalStore.remove('$_prefix$key');
    }
  }

  static Object? decodeCached(Object? raw) => raw;

  static Object? encodeForCache(Object? value) {
    if (value == null || value is num || value is bool || value is String) {
      return value;
    }
    if (value is List) return value.map(encodeForCache).toList();
    if (value is Map) {
      return value.map((key, val) => MapEntry(key.toString(), encodeForCache(val)));
    }
    // Model objects must expose toJson().
    try {
      // ignore: avoid_dynamic_calls
      return encodeForCache((value as dynamic).toJson());
    } catch (_) {
      return null;
    }
  }
}

class _CacheEntry {
  _CacheEntry(this.value, this.savedAt);
  final Object? value;
  final DateTime savedAt;
  bool isExpired(Duration ttl) => DateTime.now().difference(savedAt) > ttl;
}
