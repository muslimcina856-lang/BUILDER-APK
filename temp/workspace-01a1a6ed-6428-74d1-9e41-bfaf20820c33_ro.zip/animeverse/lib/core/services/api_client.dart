import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

import '../config/app_config.dart';

class ApiException implements Exception {
  ApiException(this.message, {this.statusCode, this.isNetwork = false});

  final String message;
  final int? statusCode;
  final bool isNetwork;

  bool get isRateLimited => statusCode == 429;

  @override
  String toString() => 'ApiException($statusCode): $message';

  /// Pesan ramah pengguna dalam Bahasa Indonesia.
  String get userMessage {
    if (isNetwork) {
      return 'Tidak ada koneksi internet. Periksa jaringan lalu coba lagi.';
    }
    if (isRateLimited) {
      return 'Terlalu banyak permintaan ke server. Tunggu beberapa detik.';
    }
    if (statusCode != null && statusCode! >= 500) {
      return 'Server sedang bermasalah. Coba lagi nanti.';
    }
    return message;
  }
}

class ApiClient {
  ApiClient({Dio? dio}) : dio = dio ?? _buildDio();

  final Dio dio;

  static Dio _buildDio() {
    final instance = Dio(
      BaseOptions(
        connectTimeout: AppConfig.networkTimeout,
        receiveTimeout: AppConfig.networkTimeout,
        sendTimeout: AppConfig.networkTimeout,
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'ANIMEVERSE/${AppConfig.appVersion} (Flutter)',
        },
      ),
    );
    instance.interceptors.add(
      InterceptorsWrapper(
        onError: (error, handler) {
          if (kDebugMode) {
            debugPrint('[API] ${error.requestOptions.uri} → ${error.response?.statusCode}');
          }
          handler.next(error);
        },
      ),
    );
    return instance;
  }

  Future<Map<String, dynamic>> postJson(
    String url,
    Map<String, dynamic> body, {
    Map<String, String>? headers,
  }) async {
    try {
      final response = await dio.post<dynamic>(
        url,
        data: body,
        options: Options(headers: headers),
      );
      final data = response.data;
      if (data is Map<String, dynamic>) return data;
      return {'data': data};
    } on DioException catch (error) {
      throw _mapError(error);
    }
  }

  Future<dynamic> getJson(
    String url, {
    Map<String, dynamic>? query,
    Map<String, String>? headers,
  }) async {
    try {
      final response = await dio.get<dynamic>(
        url,
        queryParameters: query,
        options: Options(headers: headers),
      );
      return response.data;
    } on DioException catch (error) {
      throw _mapError(error);
    }
  }

  ApiException _mapError(DioException error) {
    final status = error.response?.statusCode;
    final isNetwork = error.type == DioExceptionType.connectionError ||
        error.type == DioExceptionType.connectionTimeout ||
        error.type == DioExceptionType.receiveTimeout ||
        error.type == DioExceptionType.sendTimeout ||
        error.error is SocketException;
    final data = error.response?.data;
    String message = error.message ?? 'Permintaan gagal';
    if (data is Map) {
      final errors = data['errors'];
      if (errors is List && errors.isNotEmpty) {
        message = (errors.first is Map
                ? (errors.first as Map)['message']?.toString()
                : errors.first.toString()) ??
            message;
      } else if (data['message'] != null) {
        message = data['message'].toString();
      }
    }
    return ApiException(message, statusCode: status, isNetwork: isNetwork);
  }
}
