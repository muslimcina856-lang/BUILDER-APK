import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Penyimpanan key-value yang tahan banting.
///
/// - Android/iOS: memakai `SharedPreferences`.
/// - Web (termasuk iframe sandbox tanpa `allow-same-origin`): `localStorage`
///   dapat melempar `SecurityError`, sehingga otomatis jatuh ke penyimpanan
///   memori. Aplikasi tetap berjalan, hanya tidak persisten antar-reload.
class LocalStore {
  LocalStore._();

  static final Map<String, String> _memory = {};
  static SharedPreferences? _prefs;
  static bool persistent = false;
  static bool _initialized = false;

  static Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    try {
      _prefs = await SharedPreferences.getInstance();
      persistent = true;
    } catch (error) {
      persistent = false;
      debugPrint('[LocalStore] persistent storage unavailable: $error');
    }
  }

  static String? getString(String key) {
    try {
      final value = _prefs?.getString(key);
      if (value != null) return value;
    } catch (_) {}
    return _memory[key];
  }

  static Future<void> setString(String key, String value) async {
    _memory[key] = value;
    try {
      await _prefs?.setString(key, value);
    } catch (_) {}
  }

  static Future<void> remove(String key) async {
    _memory.remove(key);
    try {
      await _prefs?.remove(key);
    } catch (_) {}
  }

  static Future<void> clear() async {
    _memory.clear();
    try {
      await _prefs?.clear();
    } catch (_) {}
  }

  // ── JSON helpers ──
  static Map<String, dynamic>? getJson(String key) {
    final raw = getString(key);
    if (raw == null) return null;
    try {
      final decoded = jsonDecode(raw);
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }

  static List<dynamic> getJsonList(String key) {
    final raw = getString(key);
    if (raw == null) return const [];
    try {
      final decoded = jsonDecode(raw);
      return decoded is List ? decoded : const [];
    } catch (_) {
      return const [];
    }
  }

  static Future<void> setJson(String key, Object? value) =>
      setString(key, jsonEncode(value));

  static bool getBool(String key, {bool fallback = false}) {
    final raw = getString(key);
    if (raw == null) return fallback;
    return raw == 'true';
  }

  static Future<void> setBool(String key, bool value) =>
      setString(key, value ? 'true' : 'false');

  static int getInt(String key, {int fallback = 0}) {
    final raw = getString(key);
    return raw == null ? fallback : int.tryParse(raw) ?? fallback;
  }

  static Future<void> setInt(String key, int value) =>
      setString(key, value.toString());
}
