import 'package:intl/intl.dart';

class Fmt {
  const Fmt._();

  static final NumberFormat _decimal = NumberFormat('#,##0', 'id_ID');

  static String number(num value) => _decimal.format(value);

  static String compact(num value) {
    if (value >= 1000000) {
      return '${(value / 1000000).toStringAsFixed(value >= 10000000 ? 0 : 1)}M';
    }
    if (value >= 1000) {
      return '${(value / 1000).toStringAsFixed(value >= 10000 ? 0 : 1)}K';
    }
    return value.toString();
  }

  static String relative(DateTime? time) {
    if (time == null) return '—';
    final diff = DateTime.now().difference(time);
    if (diff.inSeconds < 60) return 'baru saja';
    if (diff.inMinutes < 60) return '${diff.inMinutes} menit lalu';
    if (diff.inHours < 24) return '${diff.inHours} jam lalu';
    if (diff.inDays < 7) return '${diff.inDays} hari lalu';
    if (diff.inDays < 30) return '${(diff.inDays / 7).floor()} minggu lalu';
    if (diff.inDays < 365) return '${(diff.inDays / 30).floor()} bulan lalu';
    return '${(diff.inDays / 365).floor()} tahun lalu';
  }

  static String date(DateTime? time, {String pattern = 'd MMM yyyy'}) {
    if (time == null) return '—';
    return DateFormat(pattern, 'id_ID').format(time);
  }

  static String dateTime(DateTime? time) {
    if (time == null) return '—';
    return DateFormat('d MMM yyyy • HH:mm', 'id_ID').format(time);
  }

  static String weekday(DateTime time) => DateFormat('EEEE', 'id_ID').format(time);

  static String duration(int seconds) {
    if (seconds <= 0) return '00:00';
    final h = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    final s = seconds % 60;
    if (h > 0) {
      return '$h:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
    }
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  static String countdown(DateTime? target) {
    if (target == null) return '—';
    final diff = target.difference(DateTime.now());
    if (diff.isNegative) return 'Sudah tayang';
    if (diff.inDays > 0) return '${diff.inDays}h ${diff.inHours % 24}j';
    if (diff.inHours > 0) return '${diff.inHours}j ${diff.inMinutes % 60}m';
    return '${diff.inMinutes}m';
  }

  static String season(int? year, String? season) {
    if (year == null && season == null) return '—';
    const map = {
      'WINTER': 'Winter',
      'SPRING': 'Spring',
      'SUMMER': 'Summer',
      'FALL': 'Fall',
    };
    final label = map[season?.toUpperCase()] ?? '';
    return [label, if (year != null) '$year'].where((e) => e.isNotEmpty).join(' ');
  }

  static String bytesFromMb(double mb) =>
      mb >= 1024 ? '${(mb / 1024).toStringAsFixed(1)} GB' : '${mb.toStringAsFixed(0)} MB';
}
