import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../data/models/media.dart';

/// Helper navigasi terpusat agar tidak ada string route yang tersebar.
class AppNav {
  const AppNav._();

  static void media(BuildContext context, MediaItem media) {
    context.push(
      '/media?kind=${media.kind.slug}&id=${Uri.encodeComponent(media.id)}',
    );
  }

  static void mediaById(BuildContext context, String id, MediaKind kind) {
    context.push('/media?kind=${kind.slug}&id=${Uri.encodeComponent(id)}');
  }

  static void category(BuildContext context, MediaKind kind) {
    context.push('/category/${kind.slug}');
  }

  static void watch(
    BuildContext context, {
    required String mediaId,
    required MediaKind kind,
    required int episode,
    String? title,
  }) {
    context.push(
      '/watch?id=${Uri.encodeComponent(mediaId)}&kind=${kind.slug}&episode=$episode'
      '${title == null ? '' : '&title=${Uri.encodeComponent(title)}'}',
    );
  }

  static void readComic(
    BuildContext context, {
    required String mediaId,
    required String chapterId,
    required MediaKind kind,
    String? title,
    String? chapterNumber,
  }) {
    context.push(
      '/read-comic?mediaId=${Uri.encodeComponent(mediaId)}'
      '&chapterId=${Uri.encodeComponent(chapterId)}'
      '&kind=${kind.slug}'
      '${title == null ? '' : '&title=${Uri.encodeComponent(title)}'}'
      '${chapterNumber == null ? '' : '&chapter=${Uri.encodeComponent(chapterNumber)}'}',
    );
  }

  static void readNovel(
    BuildContext context, {
    required String mediaId,
    required int index,
    String? title,
  }) {
    context.push(
      '/read-novel?mediaId=${Uri.encodeComponent(mediaId)}&index=$index'
      '${title == null ? '' : '&title=${Uri.encodeComponent(title)}'}',
    );
  }

  static void search(BuildContext context, {String? query}) {
    context.push('/search${query == null ? '' : '?q=${Uri.encodeComponent(query)}'}');
  }

  static void back(BuildContext context) {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go('/home');
    }
  }
}
