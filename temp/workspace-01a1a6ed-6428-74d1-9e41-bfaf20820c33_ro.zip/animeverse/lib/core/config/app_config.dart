/// Central application configuration.
///
/// Values can be injected at build time, e.g.
/// `flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...`
/// or by using `--dart-define-from-file=config/app.env.json`.
///
/// When Supabase credentials are absent the app boots in [BackendMode.local]
/// (fully usable offline demo backend) instead of crashing. See docs/SETUP.md.
class AppConfig {
  const AppConfig._();

  static const String appName =
      String.fromEnvironment('APP_NAME', defaultValue: 'ANIMEVERSE');
  static const String appTagline = 'Anime, Komik & Novel dalam satu semesta';
  static const String appVersion = '1.0.0';

  // ───────────────────────── Supabase ─────────────────────────
  static const String supabaseUrl =
      String.fromEnvironment('SUPABASE_URL', defaultValue: '');
  static const String supabaseAnonKey =
      String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: '');
  static const String storageBucketAvatars =
      String.fromEnvironment('SUPABASE_BUCKET_AVATAR', defaultValue: 'avatars');
  static const String storageBucketCovers =
      String.fromEnvironment('SUPABASE_BUCKET_COVER', defaultValue: 'covers');

  static bool get hasSupabase =>
      supabaseUrl.trim().isNotEmpty && supabaseAnonKey.trim().isNotEmpty;

  // ─────────────────────── Public content APIs ───────────────────────
  /// AniList GraphQL — metadata resmi untuk anime, donghua, movie, manga,
  /// manhwa, manhua dan novel (rating, genre, jadwal tayang, cover, trailer).
  static const String anilistEndpoint = 'https://graphql.anilist.co';

  /// MangaDex — API publik untuk daftar chapter + gambar halaman komik.
  /// Konten diunggah komunitas; verifikasi lisensi sebelum rilis komersial.
  static const String mangadexEndpoint = 'https://api.mangadex.org';
  static const String mangadexUploads = 'https://uploads.mangadex.org';

  /// Wikisource Bahasa Indonesia — teks domain publik / CC BY-SA untuk reader
  /// novel. Konten nyata, bukan dummy.
  static const String wikisourceEndpoint = 'https://id.wikisource.org/w/api.php';

  // ───────────────────────────── Limits ─────────────────────────────
  static const Duration networkTimeout = Duration(seconds: 20);
  static const Duration memoryCacheTtl = Duration(minutes: 10);
  static const Duration diskCacheTtl = Duration(hours: 12);

  static const int pageSize = 24;

  /// EXP harian maksimum per jenis aktivitas (anti-spam / farming).
  static const int dailyExpCapWatch = 300;
  static const int dailyExpCapRead = 300;
  static const int dailyExpCapComment = 120;

  /// Kualitas streaming yang tersedia.
  static const List<int> videoQualities = [360, 480, 720, 1080];

  static const List<String> supportEmail = ['support@animeverse.app'];
}
