import 'package:flutter/material.dart';

/// Palet warna ANIMEVERSE: dark purple, deep black, gold, violet neon.
class AppColors {
  const AppColors._();

  // ── Base ──
  static const Color deepBlack = Color(0xFF07050D);
  static const Color background = Color(0xFF0B0714);
  static const Color surface = Color(0xFF141024);
  static const Color surfaceAlt = Color(0xFF1B1533);
  static const Color surfaceHigh = Color(0xFF241C42);
  static const Color border = Color(0xFF2E2650);

  // ── Brand ──
  static const Color violet = Color(0xFF7C4DFF);
  static const Color violetNeon = Color(0xFFB388FF);
  static const Color purple = Color(0xFF4A1D96);
  static const Color deepPurple = Color(0xFF2A1057);
  static const Color gold = Color(0xFFFFC857);
  static const Color goldDeep = Color(0xFFE0A020);

  // ── Semantic ──
  static const Color success = Color(0xFF34D399);
  static const Color warning = Color(0xFFFBBF24);
  static const Color danger = Color(0xFFF87171);
  static const Color info = Color(0xFF60A5FA);

  // ── Text ──
  static const Color textPrimary = Color(0xFFF5F2FF);
  static const Color textSecondary = Color(0xFFB7AEDA);
  static const Color textMuted = Color(0xFF7E76A3);

  // ── Light theme ──
  static const Color lightBackground = Color(0xFFF7F5FF);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightBorder = Color(0xFFE4DEF7);
  static const Color lightTextPrimary = Color(0xFF160F2B);
  static const Color lightTextSecondary = Color(0xFF5B5378);

  // ── Gradients ──
  static const LinearGradient brandGradient = LinearGradient(
    colors: [Color(0xFF7C4DFF), Color(0xFFB388FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient goldGradient = LinearGradient(
    colors: [Color(0xFFFFE29B), Color(0xFFFFC857), Color(0xFFD99A18)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient premiumGradient = LinearGradient(
    colors: [Color(0xFF2A1057), Color(0xFF4A1D96), Color(0xFF7C4DFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient heroScrim = LinearGradient(
    colors: [Color(0xF2000000), Color(0x800B0714), Color(0x000B0714)],
    begin: Alignment.bottomCenter,
    end: Alignment.topCenter,
  );

  static const LinearGradient cardScrim = LinearGradient(
    colors: [Color(0xE60B0714), Color(0x000B0714)],
    begin: Alignment.bottomCenter,
    end: Alignment.topCenter,
  );

  // ── VIP frames per tier ──
  static const Map<String, List<Color>> frameGradients = {
    'free': [Color(0xFF3A3360), Color(0xFF6B5EA8)],
    'vip': [Color(0xFF6EE7F9), Color(0xFF3B82F6)],
    'premium': [Color(0xFFFFE29B), Color(0xFFD99A18)],
    'ultimate': [Color(0xFFF0ABFC), Color(0xFF7C4DFF), Color(0xFFFFC857)],
  };

  static List<Color> frameFor(String tier) =>
      frameGradients[tier] ?? frameGradients['free']!;

  /// Warna aksen dari hex AniList (#RRGGBB) dengan fallback violet.
  static Color fromHex(String? hex, {Color fallback = violet}) {
    if (hex == null) return fallback;
    final cleaned = hex.replaceAll('#', '').trim();
    if (cleaned.length != 6) return fallback;
    final value = int.tryParse(cleaned, radix: 16);
    if (value == null) return fallback;
    return Color(0xFF000000 | value);
  }
}
