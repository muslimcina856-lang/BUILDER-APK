import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../data/models/media.dart';
import 'app_network_image.dart';
import 'glass_card.dart';

/// Kartu poster vertikal (dipakai di daftar horizontal maupun grid).
class PosterCard extends StatelessWidget {
  const PosterCard({
    super.key,
    required this.media,
    this.width = 132,
    this.onTap,
    this.showRank,
    this.progress,
    this.subtitle,
    this.showScore = true,
    this.expand = false,
  });

  final MediaItem media;
  final double width;

  /// Bila `true`, kartu mengikuti lebar parent (dipakai di GridView).
  final bool expand;
  final VoidCallback? onTap;
  final int? showRank;
  final double? progress;
  final String? subtitle;
  final bool showScore;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final double? height = expand ? null : width * 1.46;

    final poster = Stack(
      children: [
        Hero(
          tag: 'poster-${media.id}',
          child: Container(
            height: height,
            width: expand ? null : width,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: media.accent.withValues(alpha: 0.22),
                  blurRadius: 18,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  AppNetworkImage(url: media.coverUrl, fit: BoxFit.cover),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.center,
                        colors: [Color(0xCC05030B), Color(0x0005030B)],
                      ),
                    ),
                  ),
                  if (progress != null)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: ClipRRect(
                        borderRadius: const BorderRadius.vertical(
                          bottom: Radius.circular(18),
                        ),
                        child: LinearProgressIndicator(
                          value: progress!.clamp(0.0, 1.0),
                          minHeight: 3.5,
                          backgroundColor: Colors.white.withValues(alpha: 0.18),
                          valueColor:
                              const AlwaysStoppedAnimation(AppColors.violetNeon),
                        ),
                      ),
                    ),
                  Positioned(
                    left: 8,
                    top: 8,
                    child: GradientBadge(
                      label: media.kind.label,
                      gradient: media.kind.isVideo
                          ? AppColors.brandGradient
                          : AppColors.goldGradient,
                      foreground: media.kind.isVideo
                          ? Colors.white
                          : AppColors.deepBlack,
                      fontSize: 9,
                      padding:
                          const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    ),
                  ),
                  if (showScore && media.score != null)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.6),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.star_rounded,
                              size: 11,
                              color: AppColors.gold,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              media.scoreLabel,
                              style: const TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  if (media.isAiring && media.nextEpisodeNumber != null)
                    Positioned(
                      left: 8,
                      bottom: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.violet.withValues(alpha: 0.85),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          'E${media.nextEpisodeNumber}',
                          style: const TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
        if (showRank != null)
          Positioned(
            left: -6,
            bottom: -6,
            child: Container(
              width: 34,
              height: 34,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: showRank! <= 3
                    ? AppColors.goldGradient
                    : AppColors.brandGradient,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.deepBlack, width: 2),
              ),
              child: Text(
                '$showRank',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  color: showRank! <= 3 ? AppColors.deepBlack : Colors.white,
                ),
              ),
            ),
          ),
      ],
    );

    final card = GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          expand ? AspectRatio(aspectRatio: 0.685, child: poster) : poster,
          const SizedBox(height: 8),
          Text(
            media.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.titleMedium?.copyWith(
              fontSize: 12.8,
              height: 1.25,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle ??
                [
                  if (media.year != null) '${media.year}',
                  if (media.kind.isVideo && media.episodes != null)
                    '${media.episodes} eps',
                  if (media.kind.isComic && media.chapters != null)
                    '${media.chapters} ch',
                  if (media.kind == MediaKind.novel && media.studio != null)
                    media.studio!,
                ].join(' • '),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.bodySmall?.copyWith(
              fontSize: 10.5,
              color: AppColors.textMuted,
            ),
          ),
        ],
      ),
    );

    if (expand) return card;
    return SizedBox(width: width, child: card);
  }
}

/// Kartu horizontal lebar (continue watching, episode terbaru, dsb).
class WideMediaCard extends StatelessWidget {
  const WideMediaCard({
    super.key,
    required this.media,
    this.onTap,
    this.label,
    this.progress,
    this.thumbnailUrl,
    this.trailing,
    this.height = 96,
  });

  final MediaItem media;
  final VoidCallback? onTap;
  final String? label;
  final double? progress;
  final String? thumbnailUrl;
  final Widget? trailing;
  final double height;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        height: height,
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: SizedBox(
                width: height * 1.55,
                height: height,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    AppNetworkImage(
                      url: thumbnailUrl ?? media.bannerUrl ?? media.coverUrl,
                      fit: BoxFit.cover,
                    ),
                    if (progress != null)
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: LinearProgressIndicator(
                          value: progress!.clamp(0.0, 1.0),
                          minHeight: 3,
                          backgroundColor: Colors.black.withValues(alpha: 0.4),
                          valueColor:
                              const AlwaysStoppedAnimation(AppColors.violetNeon),
                        ),
                      ),
                    Positioned(
                      right: 6,
                      top: 6,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.55),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.play_arrow_rounded,
                          size: 14,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    media.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleMedium?.copyWith(fontSize: 14),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    label ??
                        [
                          media.kind.label,
                          if (media.year != null) '${media.year}',
                        ].join(' • '),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
            ),
            if (trailing != null) trailing!,
          ],
        ),
      ),
    );
  }
}

/// Placeholder ketika data kosong.
class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.title,
    this.message,
    this.icon = Icons.inbox_rounded,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String? message;
  final IconData icon;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppColors.violet.withValues(alpha: 0.22),
                    AppColors.violetNeon.withValues(alpha: 0.08),
                  ],
                ),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 38, color: AppColors.violetNeon),
            ),
            const SizedBox(height: 18),
            Text(
              title,
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium,
            ),
            if (message != null) ...[
              const SizedBox(height: 8),
              Text(
                message!,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodySmall?.copyWith(height: 1.5),
              ),
            ],
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 20),
              FilledButton.tonal(
                onPressed: onAction,
                child: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
