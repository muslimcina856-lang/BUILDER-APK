import 'dart:convert';
import 'dart:typed_data';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Gambar jaringan dengan shimmer placeholder + fallback gradient.
/// Mendukung `data:` URI (foto profil hasil upload mode lokal).
class AppNetworkImage extends StatelessWidget {
  const AppNetworkImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.borderRadius = 0,
    this.alignment = Alignment.center,
  });

  final String? url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final double borderRadius;
  final Alignment alignment;

  @override
  Widget build(BuildContext context) {
    final child = _buildContent(context);
    if (borderRadius <= 0) return child;
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: child,
    );
  }

  Widget _buildContent(BuildContext context) {
    final value = url;
    if (value == null || value.trim().isEmpty) {
      return _Fallback(width: width, height: height);
    }
    if (value.startsWith('data:image')) {
      try {
        final base64Part = value.split(',').last;
        final bytes = Uint8List.fromList(base64Decode(base64Part));
        return Image.memory(
          bytes,
          width: width,
          height: height,
          fit: fit,
          alignment: alignment,
          errorBuilder: (_, __, ___) => _Fallback(width: width, height: height),
        );
      } catch (_) {
        return _Fallback(width: width, height: height);
      }
    }
    if (value.startsWith('assets/')) {
      return Image.asset(
        value,
        width: width,
        height: height,
        fit: fit,
        errorBuilder: (_, __, ___) => _Fallback(width: width, height: height),
      );
    }
    return CachedNetworkImage(
      imageUrl: value,
      width: width,
      height: height,
      fit: fit,
      alignment: alignment,
      fadeInDuration: const Duration(milliseconds: 260),
      placeholder: (_, __) => _Placeholder(width: width, height: height),
      errorWidget: (_, __, ___) => _Fallback(width: width, height: height),
    );
  }
}

class _Placeholder extends StatelessWidget {
  const _Placeholder({this.width, this.height});
  final double? width;
  final double? height;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.surfaceAlt, AppColors.surfaceHigh],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: const Center(
        child: SizedBox(
          width: 18,
          height: 18,
          child: CircularProgressIndicator(strokeWidth: 1.8),
        ),
      ),
    );
  }
}

class _Fallback extends StatelessWidget {
  const _Fallback({this.width, this.height});
  final double? width;
  final double? height;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.deepPurple, AppColors.surfaceAlt],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Icon(
          Icons.auto_awesome_rounded,
          color: AppColors.violetNeon.withValues(alpha: 0.5),
          size: (width ?? 60) * 0.3,
        ),
      ),
    );
  }
}
