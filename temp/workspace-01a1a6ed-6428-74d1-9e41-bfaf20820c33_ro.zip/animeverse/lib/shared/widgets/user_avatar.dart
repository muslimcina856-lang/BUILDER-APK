import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../data/models/gamification.dart';
import '../../data/models/user_profile.dart';
import 'app_network_image.dart';
import 'glass_card.dart';

/// Avatar dengan frame sesuai tier membership + ring rank.
class UserAvatar extends StatelessWidget {
  const UserAvatar({
    super.key,
    this.imageUrl,
    this.initials = 'AV',
    this.size = 56,
    this.tier = MembershipTier.free,
    this.rankKey,
    this.showFrame = true,
    this.onTap,
  });

  final String? imageUrl;
  final String initials;
  final double size;
  final MembershipTier tier;
  final String? rankKey;
  final bool showFrame;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final colors = AppColors.frameFor(tier.value);
    final rank = rankKey == null ? null : RankTier.fromKey(rankKey);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        padding: EdgeInsets.all(showFrame ? 2.5 : 0),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: showFrame ? LinearGradient(colors: colors) : null,
          boxShadow: showFrame
              ? [
                  BoxShadow(
                    color: colors.last.withValues(alpha: 0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.deepBlack, width: 1.6),
            color: AppColors.surfaceHigh,
          ),
          child: ClipOval(
            child: imageUrl == null || imageUrl!.isEmpty
                ? _Initials(initials: initials, size: size)
                : AppNetworkImage(url: imageUrl, fit: BoxFit.cover),
          ),
        ),
      ),
    );
  }
}

class _Initials extends StatelessWidget {
  const _Initials({required this.initials, required this.size});
  final String initials;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppColors.premiumGradient),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: TextStyle(
          fontSize: size * 0.32,
          fontWeight: FontWeight.w800,
          color: Colors.white,
        ),
      ),
    );
  }
}

/// Badge tier (VIP/Premium/Ultimate) dengan ikon mahkota.
class TierBadge extends StatelessWidget {
  const TierBadge({super.key, required this.tier, this.size = 11});

  final MembershipTier tier;
  final double size;

  @override
  Widget build(BuildContext context) {
    if (!tier.isPaid) return const SizedBox.shrink();
    final colors = AppColors.frameFor(tier.value);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            tier == MembershipTier.ultimate
                ? Icons.diamond_rounded
                : Icons.workspace_premium_rounded,
            size: size,
            color: AppColors.deepBlack,
          ),
          const SizedBox(width: 3),
          Text(
            tier.label.toUpperCase(),
            style: TextStyle(
              fontSize: size - 1.5,
              fontWeight: FontWeight.w900,
              color: AppColors.deepBlack,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}

/// Bar EXP dengan gradient & label rank berikutnya.
class ExpBar extends StatelessWidget {
  const ExpBar({
    super.key,
    required this.level,
    required this.progress,
    this.expIntoLevel = 0,
    this.expForNext = 0,
    this.height = 8,
    this.showLabels = true,
    this.rankKey,
  });

  final int level;
  final double progress;
  final int expIntoLevel;
  final int expForNext;
  final double height;
  final bool showLabels;
  final String? rankKey;

  @override
  Widget build(BuildContext context) {
    final rank = rankKey == null ? null : RankTier.fromKey(rankKey);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showLabels)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: [
                Text(
                  'Level $level',
                  style: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                if (rank != null) ...[
                  const SizedBox(width: 6),
                  Text(
                    '• ${rank.name}',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: rank.color,
                    ),
                  ),
                ],
                const Spacer(),
                Text(
                  '$expIntoLevel / $expForNext EXP',
                  style: const TextStyle(
                    fontSize: 10.5,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            children: [
              Container(
                height: height,
                color: AppColors.surfaceHigh,
              ),
              FractionallySizedBox(
                widthFactor: progress.clamp(0.02, 1.0),
                child: Container(
                  height: height,
                  decoration: const BoxDecoration(gradient: AppColors.brandGradient),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// Chip statistik (tontonan, bacaan, komentar...).
class StatChip extends StatelessWidget {
  const StatChip({
    super.key,
    required this.icon,
    required this.value,
    required this.label,
    this.color = AppColors.violetNeon,
    this.onTap,
  });

  final IconData icon;
  final String value;
  final String label;
  final Color color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withValues(alpha: 0.22)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 14, color: color),
                const SizedBox(width: 6),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: const TextStyle(
                fontSize: 10,
                color: AppColors.textMuted,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Label section dengan gradient text.
class GradientText extends StatelessWidget {
  const GradientText(
    this.text, {
    super.key,
    this.style,
    this.gradient = AppColors.brandGradient,
  });

  final String text;
  final TextStyle? style;
  final Gradient gradient;

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      shaderCallback: (bounds) => gradient.createShader(bounds),
      blendMode: BlendMode.srcIn,
      child: Text(
        text,
        style: style ??
            const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.4,
              color: Colors.white,
            ),
      ),
    );
  }
}

/// Dialog konfirmasi generik.
Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  String? message,
  String confirmLabel = 'Lanjutkan',
  String cancelLabel = 'Batal',
  bool destructive = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: message == null ? null : Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: Text(cancelLabel),
        ),
        FilledButton(
          style: destructive
              ? FilledButton.styleFrom(backgroundColor: AppColors.danger)
              : null,
          onPressed: () => Navigator.pop(context, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result ?? false;
}

void showSnack(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      backgroundColor: error ? const Color(0xFF7F1D1D) : AppColors.surfaceHigh,
      duration: Duration(seconds: error ? 4 : 2),
    ),
  );
}

/// Bottom sheet standar dengan handle.
Future<T?> showAppSheet<T>(
  BuildContext context, {
  required Widget child,
  bool isScrollControlled = true,
}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: isScrollControlled,
    backgroundColor: Colors.transparent,
    builder: (context) => Container(
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.dark
            ? AppColors.surface
            : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 10),
          Container(
            width: 42,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.border,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          Flexible(child: child),
        ],
      ),
    ),
  );
}

/// Badge kecil berikon untuk label sumber konten.
class SourcePill extends StatelessWidget {
  const SourcePill({super.key, required this.label, this.icon, this.color});

  final String label;
  final IconData? icon;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final effective = color ?? AppColors.violetNeon;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: effective.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: effective.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 11, color: effective),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
              color: effective,
            ),
          ),
        ],
      ),
    );
  }
}

/// Wrapper untuk membuat badge gradient pada kartu gelap.
class HeroBanner extends StatelessWidget {
  const HeroBanner({
    super.key,
    required this.child,
    this.gradient = AppColors.premiumGradient,
    this.padding = const EdgeInsets.all(18),
    this.radius = 26,
  });

  final Widget child;
  final Gradient gradient;
  final EdgeInsetsGeometry padding;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        gradient: gradient,
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: AppColors.violet.withValues(alpha: 0.28),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: child,
    );
  }
}

/// Wrapper glass yang dipakai di atas gambar (mis. tombol back).
class CircleGlassButton extends StatelessWidget {
  const CircleGlassButton({
    super.key,
    required this.icon,
    this.onTap,
    this.size = 40,
    this.badgeCount,
  });

  final IconData icon;
  final VoidCallback? onTap;
  final double size;
  final int? badgeCount;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.35),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withValues(alpha: 0.16)),
            ),
            child: Icon(icon, size: size * 0.5, color: Colors.white),
          ),
          if (badgeCount != null && badgeCount! > 0)
            Positioned(
              right: -2,
              top: -2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                decoration: BoxDecoration(
                  color: AppColors.danger,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  badgeCount! > 9 ? '9+' : '$badgeCount',
                  style: const TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
