import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

/// Efek shimmer tanpa dependency eksternal.
class Shimmer extends StatefulWidget {
  const Shimmer({
    super.key,
    required this.child,
    this.baseColor = AppColors.surfaceAlt,
    this.highlightColor = AppColors.surfaceHigh,
    this.enabled = true,
  });

  final Widget child;
  final Color baseColor;
  final Color highlightColor;
  final bool enabled;

  @override
  State<Shimmer> createState() => _ShimmerState();
}

class _ShimmerState extends State<Shimmer> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  );

  @override
  void initState() {
    super.initState();
    if (widget.enabled) _controller.repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.enabled) return widget.child;
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (bounds) {
            final offset = _controller.value * 2 - 1;
            return LinearGradient(
              begin: Alignment(-1.5 + offset, -0.4),
              end: Alignment(1.5 + offset, 0.4),
              colors: [
                widget.baseColor,
                widget.highlightColor,
                widget.baseColor,
              ],
              stops: const [0.2, 0.5, 0.8],
            ).createShader(bounds);
          },
          child: child,
        );
      },
      child: widget.child,
    );
  }
}

/// Kotak skeleton dasar.
class SkeletonBox extends StatelessWidget {
  const SkeletonBox({
    super.key,
    this.width,
    this.height = 12,
    this.radius = 10,
  });

  final double? width;
  final double height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: AppColors.surfaceAlt,
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }
}

/// Skeleton untuk deretan poster (dashboard/beranda).
class PosterRowSkeleton extends StatelessWidget {
  const PosterRowSkeleton({super.key, this.count = 4, this.height = 210});

  final int count;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: count,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) => SizedBox(
          width: height * 0.62,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: SkeletonBox(height: height, radius: 18)),
              const SizedBox(height: 8),
              SkeletonBox(width: height * 0.5, height: 10),
              const SizedBox(height: 6),
              SkeletonBox(width: height * 0.32, height: 8),
            ],
          ),
        ),
      ),
    );
  }
}

class DetailSkeleton extends StatelessWidget {
  const DetailSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return Shimmer(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SkeletonBox(height: 320, radius: 0),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SkeletonBox(width: 220, height: 22),
                  const SizedBox(height: 12),
                  const SkeletonBox(width: 140, height: 12),
                  const SizedBox(height: 20),
                  Row(
                    children: List.generate(
                      3,
                      (index) => const Padding(
                        padding: EdgeInsets.only(right: 10),
                        child: SkeletonBox(width: 64, height: 28, radius: 20),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const SkeletonBox(height: 12),
                  const SizedBox(height: 8),
                  const SkeletonBox(height: 12),
                  const SizedBox(height: 8),
                  const SkeletonBox(width: 240, height: 12),
                  const SizedBox(height: 24),
                  ...List.generate(
                    4,
                    (index) => const Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: SkeletonBox(height: 64, radius: 16),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
