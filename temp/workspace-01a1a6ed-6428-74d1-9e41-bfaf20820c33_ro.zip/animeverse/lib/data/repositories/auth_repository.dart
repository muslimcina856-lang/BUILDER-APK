import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;

import '../../core/config/app_config.dart';
import '../../core/services/local_store.dart';
import '../../core/services/supabase_gateway.dart';
import '../models/user_profile.dart';

class AuthResult {
  const AuthResult({
    this.profile,
    this.error,
    this.needsEmailVerification = false,
    this.message,
  });

  final UserProfile? profile;
  final String? error;
  final bool needsEmailVerification;
  final String? message;

  bool get isSuccess => profile != null && error == null;

  static AuthResult failure(String message) => AuthResult(error: message);
}

/// Autentikasi + profil pengguna.
///
/// Mode Supabase: `Supabase Auth` (email/password, Google OAuth, verifikasi
/// email, reset password) + tabel `profiles` dengan RLS.
/// Mode lokal: penyimpanan lokal terenkripsi-hash (SHA-256 + salt) agar alur
/// registrasi/login/upload foto tetap dapat diuji tanpa backend.
class AuthRepository {
  AuthRepository(this._gateway);

  final SupabaseGateway _gateway;

  static const String _sessionKey = 'auth::session';
  static const String _usersKey = 'auth::users';
  static const String _rememberKey = 'auth::remember';

  bool get isCloud => _gateway.enabled;

  // ───────────────────────────── Session ─────────────────────────────

  Future<UserProfile?> restoreSession() async {
    if (isCloud) {
      final user = _gateway.client.auth.currentUser;
      if (user == null) return null;
      return _fetchCloudProfile(user.id) ??
          await _ensureCloudProfile(user);
    }
    final session = LocalStore.getJson(_sessionKey);
    if (session == null) return null;
    final userId = session['userId'] as String?;
    if (userId == null) return null;
    return _localProfile(userId);
  }

  bool get rememberLogin => LocalStore.getBool(_rememberKey, fallback: true);

  Future<void> setRememberLogin(bool value) => LocalStore.setBool(_rememberKey, value);

  // ───────────────────────────── Sign in ─────────────────────────────

  Future<AuthResult> signIn(String email, String password) async {
    final normalizedEmail = email.trim().toLowerCase();
    if (normalizedEmail.isEmpty || password.isEmpty) {
      return AuthResult.failure('Email dan password wajib diisi.');
    }
    if (isCloud) {
      try {
        final response = await _gateway.client.auth
            .signInWithPassword(email: normalizedEmail, password: password);
        final user = response.user;
        if (user == null) {
          return AuthResult.failure('Gagal masuk. Coba lagi.');
        }
        final profile =
            _fetchCloudProfile(user.id) ?? await _ensureCloudProfile(user);
        await _cacheCloudProfile(profile);
        return AuthResult(profile: profile);
      } on sb.AuthException catch (error) {
        return AuthResult.failure(_mapAuthError(error));
      } catch (error) {
        return AuthResult.failure('Tidak dapat terhubung ke server: $error');
      }
    }

    final user = _findLocalUser(email: normalizedEmail);
    if (user == null) {
      return AuthResult.failure('Email belum terdaftar. Silakan daftar dulu.');
    }
    if (user['banned'] == true) {
      return AuthResult.failure('Akun ini diblokir. Hubungi dukungan.');
    }
    final hash = _hashPassword(password, normalizedEmail);
    if (user['passwordHash'] != hash) {
      return AuthResult.failure('Password salah. Periksa kembali.');
    }
    final profile = UserProfile.fromJson(
      Map<String, dynamic>.from(user['profile'] as Map),
    );
    await _saveLocalProfile(profile);
    await LocalStore.setJson(_sessionKey, {'userId': profile.id});
    return AuthResult(profile: profile);
  }

  Future<AuthResult> signUp({
    required String email,
    required String password,
    required String username,
  }) async {
    final normalizedEmail = email.trim().toLowerCase();
    final cleanUsername = username.trim().toLowerCase();
    if (!_isValidEmail(normalizedEmail)) {
      return AuthResult.failure('Format email tidak valid.');
    }
    if (password.length < 6) {
      return AuthResult.failure('Password minimal 6 karakter.');
    }
    if (cleanUsername.length < 3) {
      return AuthResult.failure('Username minimal 3 karakter.');
    }
    if (!RegExp(r'^[a-z0-9_.]+$').hasMatch(cleanUsername)) {
      return AuthResult.failure(
        'Username hanya boleh huruf kecil, angka, titik dan garis bawah.',
      );
    }

    if (isCloud) {
      try {
        final response = await _gateway.client.auth.signUp(
          email: normalizedEmail,
          password: password,
          data: {'username': cleanUsername, 'display_name': username.trim()},
        );
        final user = response.user;
        if (user == null) {
          return AuthResult.failure('Pendaftaran gagal. Coba lagi.');
        }
        if (response.session == null) {
          return const AuthResult(
            needsEmailVerification: true,
            message: 'Cek email Anda untuk verifikasi lalu masuk kembali.',
          );
        }
        final profile = await _ensureCloudProfile(user, username: cleanUsername);
        return AuthResult(profile: profile);
      } on sb.AuthException catch (error) {
        return AuthResult.failure(_mapAuthError(error));
      } catch (error) {
        return AuthResult.failure('Gagal mendaftar: $error');
      }
    }

    if (_findLocalUser(normalizedEmail) != null) {
      return AuthResult.failure('Email sudah terdaftar. Silakan masuk.');
    }
    if (_localUsers.any((user) =>
        (user['profile'] as Map?)?['username'] == cleanUsername)) {
      return AuthResult.failure('Username sudah dipakai. Pilih yang lain.');
    }

    final profile = UserProfile(
      id: _generateId(),
      username: cleanUsername,
      displayName: username.trim(),
      email: normalizedEmail,
      bio: 'Pecinta anime & komik 🎌',
      joinedAt: DateTime.now(),
      exp: 50,
      level: 1,
      rankKey: 'beginner',
      badgeIds: const ['first_comment'],
    );
    final users = _localUsers
      ..add({
        'email': normalizedEmail,
        'passwordHash': _hashPassword(password, normalizedEmail),
        'profile': profile.toJson(),
        'banned': false,
        'createdAt': DateTime.now().toIso8601String(),
      });
    await LocalStore.setJson(_usersKey, users);
    await _saveLocalProfile(profile);
    await LocalStore.setJson(_sessionKey, {'userId': profile.id});
    return AuthResult(profile: profile);
  }

  Future<AuthResult> signInWithGoogle() async {
    if (!isCloud) {
      return AuthResult.failure(
        'Google Sign-In memerlukan konfigurasi Supabase (SUPABASE_URL & '
        'SUPABASE_ANON_KEY). Lihat docs/SETUP.md bagian OAuth.',
      );
    }
    try {
      await _gateway.client.auth.signInWithOAuth(
        sb.OAuthProvider.google,
        redirectTo: kIsWeb ? null : 'io.supabase.animeverse://login-callback',
      );
      // Di mobile, penyelesaian sesi ditangani oleh listener authStateChanges.
      final user = _gateway.client.auth.currentUser;
      if (user == null) {
        return const AuthResult(
          message: 'Menyelesaikan proses masuk dengan Google…',
        );
      }
      final profile = _fetchCloudProfile(user.id) ?? await _ensureCloudProfile(user);
      return AuthResult(profile: profile);
    } on sb.AuthException catch (error) {
      return AuthResult.failure(_mapAuthError(error));
    } catch (error) {
      return AuthResult.failure('Google Sign-In gagal: $error');
    }
  }

  Future<AuthResult> sendPasswordReset(String email) async {
    final normalized = email.trim().toLowerCase();
    if (!_isValidEmail(normalized)) {
      return AuthResult.failure('Format email tidak valid.');
    }
    if (isCloud) {
      try {
        await _gateway.client.auth.resetPasswordForEmail(normalized);
        return AuthResult(
          message: 'Tautan reset password dikirim ke $normalized.',
        );
      } on sb.AuthException catch (error) {
        return AuthResult.failure(_mapAuthError(error));
      }
    }
    if (_findLocalUser(normalized) == null) {
      return AuthResult.failure('Email tidak terdaftar.');
    }
    return AuthResult(
      message: 'Mode lokal: tautan reset disimulasikan untuk $normalized. '
          'Gunakan menu Keamanan untuk mengganti password.',
    );
  }

  Future<AuthResult> resendVerificationEmail(String email) async {
    if (isCloud) {
      try {
        await _gateway.client.auth.resend(type: sb.OtpType.signup, email: email);
        return const AuthResult(message: 'Email verifikasi dikirim ulang.');
      } on sb.AuthException catch (error) {
        return AuthResult.failure(_mapAuthError(error));
      }
    }
    return const AuthResult(message: 'Mode lokal: email dianggap terverifikasi.');
  }

  Future<void> signOut() async {
    if (isCloud) {
      try {
        await _gateway.client.auth.signOut();
      } catch (error) {
        debugPrint('[Auth] signOut gagal: $error');
      }
    }
    await LocalStore.remove(_sessionKey);
  }

  // ─────────────────────────── Profile update ───────────────────────────

  Future<AuthResult> updateProfile({
    String? displayName,
    String? username,
    String? bio,
    bool? isPrivate,
    String? selectedTitle,
    List<String>? badgeIds,
    Uint8List? avatarBytes,
    Uint8List? coverBytes,
  }) async {
    final current = await restoreSession();
    if (current == null) return AuthResult.failure('Sesi berakhir, masuk kembali.');

    String? avatarUrl = current.avatarUrl;
    String? coverUrl = current.coverUrl;

    if (avatarBytes != null) {
      avatarUrl = await _uploadImage(
        bytes: avatarBytes,
        bucket: AppConfig.storageBucketAvatars,
        folder: 'avatars',
        userId: current.id,
      );
      if (avatarUrl == null) {
        return AuthResult.failure('Upload foto profil gagal.');
      }
    }
    if (coverBytes != null) {
      coverUrl = await _uploadImage(
        bytes: coverBytes,
        bucket: AppConfig.storageBucketCovers,
        folder: 'covers',
        userId: current.id,
      );
      if (coverUrl == null) {
        return AuthResult.failure('Upload cover gagal.');
      }
    }

    // Optimistic local cache agar UI langsung berubah.
    final optimistic = current.copyWith(
      displayName: displayName,
      username: username?.trim().toLowerCase(),
      bio: bio,
      isPrivate: isPrivate,
      avatarUrl: avatarUrl,
      coverUrl: coverUrl,
      selectedTitle: selectedTitle,
      badgeIds: badgeIds,
    );
    await _saveLocalProfile(optimistic);

    if (isCloud) {
      final payload = <String, dynamic>{
        'id': current.id,
        if (displayName != null) 'display_name': displayName,
        if (username != null) 'username': username.trim().toLowerCase(),
        if (bio != null) 'bio': bio,
        if (isPrivate != null) 'is_private': isPrivate,
        if (avatarUrl != null) 'avatar_url': avatarUrl,
        if (coverUrl != null) 'cover_url': coverUrl,
        if (selectedTitle != null) 'selected_title': selectedTitle,
        if (badgeIds != null) 'badge_ids': badgeIds,
        'updated_at': DateTime.now().toIso8601String(),
      };
      final ok = await _gateway.upsert('profiles', payload);
      if (!ok) {
        return AuthResult(profile: optimistic, error: 'Sinkronisasi profil gagal, perubahan disimpan lokal.');
      }
      return AuthResult(profile: optimistic);
    }

    // Mode lokal: update record user.
    final users = _localUsers;
    for (final user in users) {
      final profile = user['profile'] as Map?;
      if (profile?['id'] == current.id) {
        user['profile'] = optimistic.toJson();
      }
    }
    await LocalStore.setJson(_usersKey, users);
    return AuthResult(profile: optimistic);
  }

  Future<AuthResult> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    if (newPassword.length < 6) {
      return AuthResult.failure('Password baru minimal 6 karakter.');
    }
    if (isCloud) {
      try {
        await _gateway.client.auth.updateUser(
          sb.UserAttributes(password: newPassword),
        );
        return const AuthResult(message: 'Password berhasil diperbarui.');
      } on sb.AuthException catch (error) {
        return AuthResult.failure(_mapAuthError(error));
      }
    }
    final session = LocalStore.getJson(_sessionKey);
    final userId = session?['userId'] as String?;
    if (userId == null) return AuthResult.failure('Sesi berakhir.');
    final users = _localUsers;
    for (final user in users) {
      final profile = user['profile'] as Map?;
      if (profile?['id'] == userId) {
        final email = user['email'] as String? ?? '';
        if (user['passwordHash'] != _hashPassword(currentPassword, email)) {
          return AuthResult.failure('Password saat ini salah.');
        }
        user['passwordHash'] = _hashPassword(newPassword, email);
      }
    }
    await LocalStore.setJson(_usersKey, users);
    return const AuthResult(message: 'Password berhasil diperbarui.');
  }

  Future<AuthResult> saveUserSettings(Map<String, dynamic> settings) async {
    final profile = await restoreSession();
    if (profile == null) return AuthResult.failure('Sesi berakhir.');
    await LocalStore.setJson('settings::${profile.id}', settings);
    if (isCloud) {
      await _gateway.upsert('user_settings', {
        'user_id': profile.id,
        ...settings,
        'updated_at': DateTime.now().toIso8601String(),
      }, onConflict: 'user_id');
    }
    return AuthResult(profile: profile, message: 'Pengaturan disimpan.');
  }

  Future<Map<String, dynamic>> loadUserSettings() async {
    final profile = await _lastKnownUser();
    if (profile == null) return const {};
    final local = LocalStore.getJson('settings::${profile.id}') ?? {};
    if (isCloud) {
      final row = await _gateway.single(
        'user_settings',
        eq: {'user_id': profile.id},
      );
      if (row != null) return {...local, ...row};
    }
    return local;
  }

  // ───────────────────────────── Helpers ─────────────────────────────

  List<Map<String, dynamic>> get _localUsers {
    final raw = LocalStore.getJsonList(_usersKey);
    return raw
        .whereType<Map>()
        .map((entry) => Map<String, dynamic>.from(entry))
        .toList();
  }

  Map<String, dynamic>? _findLocalUser(String email) {
    for (final user in _localUsers) {
      if (user['email'] == email) return user;
    }
    return null;
  }

  Future<UserProfile?> _localProfile(String userId) async {
    final raw = LocalStore.getJson('profile::$userId');
    if (raw != null) return UserProfile.fromJson(raw);
    final users = _localUsers;
    for (final user in users) {
      final profile = user['profile'] as Map?;
      if (profile?['id'] == userId) {
        return UserProfile.fromJson(Map<String, dynamic>.from(profile));
      }
    }
    return null;
  }

  Future<void> _saveLocalProfile(UserProfile profile) =>
      LocalStore.setJson('profile::${profile.id}', profile.toJson());

  Future<UserProfile?> _lastKnownUser() async {
    final session = LocalStore.getJson(_sessionKey);
    final id = session?['userId'] as String?;
    if (id == null) return null;
    return _localProfile(id);
  }

  Future<String?> _uploadImage({
    required Uint8List bytes,
    required String bucket,
    required String folder,
    required String userId,
  }) async {
    if (bytes.length > 3 * 1024 * 1024) {
      throw StateError('Ukuran gambar maksimal 3 MB.');
    }
    if (isCloud) {
      final path = '$folder/${userId}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      return _gateway.uploadImage(bucket: bucket, path: path, bytes: bytes);
    }
    // Mode lokal: simpan sebagai data URI agar tetap tampil di UI.
    final base64Image = base64Encode(bytes);
    return 'data:image/jpeg;base64,$base64Image';
  }

  String _hashPassword(String password, String salt) =>
      sha256.convert(utf8.encode('$salt::$password::animeverse')).toString();

  bool _isValidEmail(String email) =>
      RegExp(r'^[\w.+-]+@[\w-]+\.[\w.-]+$').hasMatch(email);

  String _generateId() {
    final now = DateTime.now().microsecondsSinceEpoch;
    final random = DateTime.now().hashCode.abs() % 100000;
    return 'u${now.toRadixString(36)}$random';
  }

  String _mapAuthError(sb.AuthException error) {
    final code = error.code ?? '';
    switch (code) {
      case 'invalid_credentials':
        return 'Email atau password salah.';
      case 'email_not_confirmed':
        return 'Email belum diverifikasi. Cek inbox Anda.';
      case 'user_already_exists':
      case 'email_exists':
        return 'Email sudah terdaftar. Silakan masuk.';
      case 'weak_password':
        return 'Password terlalu lemah (minimal 6 karakter).';
      case 'over_email_send_rate_limit':
        return 'Terlalu banyak email terkirim. Tunggu beberapa menit.';
      case 'same_password':
        return 'Password baru harus berbeda dari yang lama.';
      default:
        return error.message;
    }
  }

  // ───────────────────────── Supabase profiles ─────────────────────────

  Map<String, dynamic>? _cloudProfileCache;

  Future<void> _cacheCloudProfile(UserProfile profile) async {
    _cloudProfileCache = profile.toJson();
    await _saveLocalProfile(profile);
  }

  UserProfile? _fetchCloudProfile(String userId) {
    // Data profil diambil sinkron dari cache; sinkronisasi berikutnya lewat
    // [refreshCloudProfile].
    final cached = LocalStore.getJson('profile::$userId');
    if (cached != null) return UserProfile.fromJson(cached);
    final cache = _cloudProfileCache;
    if (cache != null && cache['id'] == userId) {
      return UserProfile.fromJson(cache);
    }
    return null;
  }

  Future<UserProfile> refreshCloudProfile() async {
    final user = _gateway.client.auth.currentUser;
    if (user == null || !isCloud) {
      throw StateError('Tidak ada sesi Supabase aktif');
    }
    final row = await _gateway.single('profiles', eq: {'id': user.id});
    if (row == null) return _ensureCloudProfile(user);
    final profile = _profileFromRow(row, fallbackEmail: user.email ?? '');
    await _cacheCloudProfile(profile);
    return profile;
  }

  Future<UserProfile> _ensureCloudProfile(
    sb.User user, {
    String? username,
  }) async {
    final row = await _gateway.single('profiles', eq: {'id': user.id});
    if (row != null) {
      final profile = _profileFromRow(row, fallbackEmail: user.email ?? '');
      await _cacheCloudProfile(profile);
      return profile;
    }
    final metadata = user.userMetadata ?? const {};
    final baseUsername = (username ??
            metadata['username']?.toString() ??
            user.email?.split('@').first ??
            'pengguna')
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9_.]'), '');
    final profile = UserProfile(
      id: user.id,
      username: baseUsername.isEmpty ? 'pengguna${user.id.substring(0, 4)}' : baseUsername,
      displayName: (metadata['display_name'] ?? metadata['full_name'] ?? baseUsername)
          .toString(),
      email: user.email ?? '',
      joinedAt: DateTime.tryParse(user.createdAt),
      exp: 50,
      level: 1,
      rankKey: 'beginner',
    );
    await _gateway.upsert('profiles', {
      'id': profile.id,
      'username': profile.username,
      'display_name': profile.displayName,
      'bio': profile.bio,
      'avatar_url': profile.avatarUrl,
      'cover_url': profile.coverUrl,
      'role': profile.role.value,
      'tier': profile.tier.value,
      'exp': profile.exp,
      'level': profile.level,
      'rank_key': profile.rankKey,
      'is_private': false,
    });
    await _cacheCloudProfile(profile);
    return profile;
  }

  UserProfile _profileFromRow(Map<String, dynamic> row, {String fallbackEmail = ''}) {
    return UserProfile(
      id: row['id'].toString(),
      username: row['username'] as String? ?? 'pengguna',
      displayName: row['display_name'] as String? ?? row['username'] as String? ?? 'Pengguna',
      email: row['email'] as String? ?? fallbackEmail,
      bio: row['bio'] as String? ?? '',
      avatarUrl: row['avatar_url'] as String?,
      coverUrl: row['cover_url'] as String?,
      joinedAt: DateTime.tryParse(row['created_at']?.toString() ?? '') ??
          DateTime.now(),
      role: UserRole.fromValue(row['role'] as String?),
      tier: MembershipTier.fromValue(row['tier'] as String?),
      tierExpiresAt: DateTime.tryParse(row['tier_expires_at']?.toString() ?? ''),
      exp: (row['exp'] as num?)?.toInt() ?? 0,
      level: (row['level'] as num?)?.toInt() ?? 1,
      rankKey: row['rank_key'] as String? ?? 'beginner',
      selectedTitle: row['selected_title'] as String?,
      badgeIds: (row['badge_ids'] as List?)?.map((e) => '$e').toList() ?? const [],
      isPrivate: row['is_private'] as bool? ?? false,
      isBanned: row['is_banned'] as bool? ?? false,
    );
  }

  /// Membuat akun demo (dipanggil saat mode lokal pertama kali).
  Future<void> seedDemoAccounts() async {
    if (isCloud) return;
    final users = _localUsers;
    if (users.isNotEmpty) return;
    final now = DateTime.now();
    final admin = UserProfile(
      id: 'demo-admin',
      username: 'kirito_av',
      displayName: 'Kirito Animeverse',
      email: 'demo@animeverse.app',
      bio: 'Founder ANIMEVERSE. Anime & manhwa enthusiast. Admin panel unlocked 🛡️',
      joinedAt: now.subtract(const Duration(days: 412)),
      role: UserRole.admin,
      tier: MembershipTier.ultimate,
      tierExpiresAt: now.add(const Duration(days: 320)),
      exp: 26400,
      level: 27,
      rankKey: 'mythic',
      selectedTitle: 'legenda',
      badgeIds: const ['early_bird', 'first_comment', 'critic', 'vip_frame', 'founder', 'legend'],
      stats: const UserStats(
        episodesWatched: 486,
        watchMinutes: 12980,
        chaptersRead: 1240,
        novelsRead: 12,
        comments: 184,
        followers: 1284,
        following: 96,
        bookmarks: 64,
        downloads: 18,
      ),
    );
    final user = UserProfile(
      id: 'demo-user',
      username: 'sakura_reads',
      displayName: 'Sakura',
      email: 'user@animeverse.app',
      bio: 'Pembaca manhwa garis keras 📚',
      joinedAt: now.subtract(const Duration(days: 96)),
      role: UserRole.user,
      tier: MembershipTier.vip,
      tierExpiresAt: now.add(const Duration(days: 24)),
      exp: 4200,
      level: 8,
      rankKey: 'advanced',
      selectedTitle: 'bookworm',
      badgeIds: const ['first_comment', 'collector'],
      stats: const UserStats(
        episodesWatched: 148,
        watchMinutes: 3120,
        chaptersRead: 620,
        novelsRead: 3,
        comments: 62,
        followers: 120,
        following: 54,
        bookmarks: 38,
      ),
    );
    await LocalStore.setJson(_usersKey, [
      {
        'email': admin.email,
        'passwordHash': _hashPassword('demo1234', admin.email),
        'profile': admin.toJson(),
        'banned': false,
        'createdAt': admin.joinedAt?.toIso8601String(),
      },
      {
        'email': user.email,
        'passwordHash': _hashPassword('user1234', user.email),
        'profile': user.toJson(),
        'banned': false,
        'createdAt': user.joinedAt?.toIso8601String(),
      },
    ]);
    await _saveLocalProfile(admin);
    await _saveLocalProfile(user);
    // Seed komunitas agar halaman community tidak kosong saat demo.
    await seedDemoCommunity(admin, user);
  }

  Future<void> seedDemoCommunity(UserProfile admin, UserProfile user) async {
    if (LocalStore.getString('community::seeded') == 'true') return;
    final now = DateTime.now();
    final comments = [
      {
        'id': 'c1',
        'content':
            'Animasi fight scene episode terakhir benar-benar gila 🔥 Studio-nya '
            'naik level. Yang belum nonton wajib maraton!',
        'author': {'id': admin.id, 'username': admin.username, 'displayName': admin.displayName, 'level': 27, 'tier': 'ultimate', 'rankKey': 'mythic'},
        'createdAt': now.subtract(const Duration(hours: 3)).toIso8601String(),
        'targetType': 'media',
        'targetId': 'anilist:21',
        'likes': 128,
        'dislikes': 2,
        'myReaction': 0,
        'isPinned': true,
        'replies': [
          {
            'id': 'c1r1',
            'content': 'Setuju! OST-nya juga epic, masuk playlist terus 🎧',
            'author': {'id': user.id, 'username': user.username, 'displayName': user.displayName, 'level': 8, 'tier': 'vip', 'rankKey': 'advanced'},
            'createdAt': now.subtract(const Duration(hours: 2)).toIso8601String(),
            'targetType': 'media',
            'targetId': 'anilist:21',
            'parentId': 'c1',
            'likes': 24,
            'dislikes': 0,
          },
        ],
      },
      {
        'id': 'c2',
        'content':
            'Rekomendasi manhwa romance yang art-nya bagus dong, yang sudah tamat '
            'lebih baik biar tidak menggantung 😭',
        'author': {'id': user.id, 'username': user.username, 'displayName': user.displayName, 'level': 8, 'tier': 'vip', 'rankKey': 'advanced'},
        'createdAt': now.subtract(const Duration(hours: 9)).toIso8601String(),
        'targetType': 'community',
        'targetId': 'global',
        'likes': 41,
        'dislikes': 1,
      },
    ];
    await LocalStore.setJson('comments::seed', comments);
    await LocalStore.setJson('chat::global', [
      {
        'id': 'm1',
        'roomId': 'global',
        'author': {'id': admin.id, 'username': admin.username, 'displayName': admin.displayName, 'level': 27, 'tier': 'ultimate'},
        'text': 'Selamat datang di ANIMEVERSE Community! Jaga sopan santun ya 🎌',
        'createdAt': now.subtract(const Duration(hours: 5)).toIso8601String(),
        'isSystem': true,
      },
      {
        'id': 'm2',
        'roomId': 'global',
        'author': {'id': user.id, 'username': user.username, 'displayName': user.displayName, 'level': 8, 'tier': 'vip'},
        'text': 'Ada yang sudah nonton episode baru hari ini? 👀',
        'createdAt': now.subtract(const Duration(hours: 1)).toIso8601String(),
      },
    ]);
    await LocalStore.setString('community::seeded', 'true');
  }
}
