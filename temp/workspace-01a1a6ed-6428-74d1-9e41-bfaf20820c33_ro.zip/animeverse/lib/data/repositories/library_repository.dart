import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import '../../core/services/local_store.dart';
import '../../core/services/supabase_gateway.dart';
import '../models/library.dart';
import '../models/media.dart';

/// Bookmark, favorit, riwayat tontonan/bacaan, dan unduhan.
///
/// Penyimpanan lokal selalu menjadi sumber utama agar data tetap ada saat
/// offline; bila Supabase aktif setiap perubahan juga disinkronkan ke tabel
/// `bookmarks` / `watch_history` / `reading_history`.
class LibraryRepository {
  LibraryRepository(this._gateway);

  final SupabaseGateway _gateway;
  String _userId = 'guest';

  void bindUser(String userId) {
    _userId = userId;
    _cache = null;
  }

  List<LibraryEntry>? _cache;

  String get _libraryKey => 'library::$_userId';
  String get _historyKey => 'history::$_userId';
  String get _downloadKey => 'downloads::$_userId';

  // ───────────────────────────── Bookmark ─────────────────────────────

  Future<List<LibraryEntry>> library({
    LibraryKind kind = LibraryKind.bookmark,
  }) async {
    final entries = _loadLibrary();
    return entries.where((entry) => entry.kind == kind).toList()
      ..sort((a, b) => b.addedAt.compareTo(a.addedAt));
  }

  List<LibraryEntry> _loadLibrary() {
    final cached = _cache;
    if (cached != null) return cached;
    final raw = LocalStore.getJsonList(_libraryKey);
    final entries = raw
        .whereType<Map>()
        .map((entry) => LibraryEntry.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
    _cache = entries;
    return entries;
  }

  Future<void> _persistLibrary(List<LibraryEntry> entries) async {
    _cache = entries;
    await LocalStore.setJson(
      _libraryKey,
      entries.map((entry) => entry.toJson()).toList(),
    );
  }

  bool isBookmarked(String mediaId) =>
      _loadLibrary().any((entry) => entry.media.id == mediaId && entry.kind == LibraryKind.bookmark);

  bool isFavorite(String mediaId) =>
      _loadLibrary().any((entry) => entry.media.id == mediaId && entry.kind == LibraryKind.favorite);

  /// Mengembalikan `true` bila sekarang berstatus bookmark.
  Future<bool> toggleBookmark(MediaItem media) =>
      _toggle(media, LibraryKind.bookmark);

  Future<bool> toggleFavorite(MediaItem media) =>
      _toggle(media, LibraryKind.favorite);

  Future<bool> _toggle(MediaItem media, LibraryKind kind) async {
    final entries = _loadLibrary();
    final existingIndex = entries.indexWhere(
      (entry) => entry.media.id == media.id && entry.kind == kind,
    );
    final adding = existingIndex < 0;
    if (adding) {
      entries.insert(0, LibraryEntry(media: media, addedAt: DateTime.now(), kind: kind));
    } else {
      entries.removeAt(existingIndex);
    }
    await _persistLibrary(entries);

    if (_gateway.enabled) {
      final row = {
        'user_id': _userId,
        'media_id': media.id,
        'kind': media.kind.slug,
        'type': kind.name,
        'title': media.title,
        'cover_url': media.coverUrl,
        'metadata': media.toJson(),
        'created_at': DateTime.now().toIso8601String(),
      };
      if (adding) {
        await _gateway.upsert('bookmarks', row, onConflict: 'user_id,media_id,type');
      } else {
        await _gateway.delete('bookmarks', eq: {
          'user_id': _userId,
          'media_id': media.id,
          'type': kind.name,
        });
      }
    }
    return adding;
  }

  // ───────────────────────────── History ─────────────────────────────

  List<HistoryEntry> _loadHistory() {
    final raw = LocalStore.getJsonList(_historyKey);
    return raw
        .whereType<Map>()
        .map((entry) => HistoryEntry.fromJson(Map<String, dynamic>.from(entry)))
        .toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  Future<List<HistoryEntry>> history({MediaGroup? group, int? limit}) async {
    var entries = _loadHistory();
    if (group != null) {
      entries = entries.where((entry) => entry.media.kind.group == group).toList();
    }
    if (limit != null && entries.length > limit) {
      entries = entries.sublist(0, limit);
    }
    return entries;
  }

  Future<List<HistoryEntry>> continueWatching({int limit = 10}) async {
    final entries = _loadHistory()
        .where((entry) => !entry.completed && entry.progress > 0.01 && entry.progress < 0.96)
        .toList();
    return entries.take(limit).toList();
  }

  Future<HistoryEntry?> findHistory(String mediaId) async {
    for (final entry in _loadHistory()) {
      if (entry.media.id == mediaId) return entry;
    }
    return null;
  }

  /// Simpan progres. ID = `mediaId` + episode/chapter agar tiap episode punya
  /// baris sendiri namun daftar tetap ringkas.
  Future<void> saveProgress(HistoryEntry entry) async {
    final entries = _loadHistory();
    final index = entries.indexWhere((item) => item.id == entry.id);
    if (index >= 0) {
      entries[index] = entry;
    } else {
      entries.insert(0, entry);
    }
    // Batasi 200 entri terbaru.
    final trimmed = entries.take(200).toList();
    await LocalStore.setJson(
      _historyKey,
      trimmed.map((item) => item.toJson()).toList(),
    );

    if (_gateway.enabled) {
      final table = entry.media.kind.isVideo ? 'watch_history' : 'reading_history';
      await _gateway.upsert(table, {
        'user_id': _userId,
        'media_id': entry.media.id,
        'kind': entry.media.kind.slug,
        'title': entry.media.title,
        'cover_url': entry.media.coverUrl,
        'episode_number': entry.episodeNumber,
        'chapter_id': entry.chapterId,
        'chapter_number': entry.chapterNumber,
        'position_seconds': entry.positionSeconds,
        'duration_seconds': entry.durationSeconds,
        'page_index': entry.pageIndex,
        'total_pages': entry.totalPages,
        'completed': entry.completed,
        'metadata': entry.media.toJson(),
        'updated_at': entry.updatedAt.toIso8601String(),
      }, onConflict: 'user_id,media_id');
    }
  }

  Future<void> removeHistory(String id) async {
    final entries = _loadHistory()..removeWhere((entry) => entry.id == id);
    await LocalStore.setJson(
      _historyKey,
      entries.map((item) => item.toJson()).toList(),
    );
  }

  Future<void> clearHistory() async {
    await LocalStore.setJson(_historyKey, const []);
  }

  // ──────────────────────────── Downloads ────────────────────────────

  List<DownloadTask> downloads() {
    final raw = LocalStore.getJsonList(_downloadKey);
    return raw
        .whereType<Map>()
        .map((entry) => DownloadTask.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
  }

  Future<void> _persistDownloads(List<DownloadTask> tasks) =>
      LocalStore.setJson(_downloadKey, tasks.map((task) => task.toJson()).toList());

  /// Unduhan nyata (HTTP) ke folder dokumen aplikasi. Hanya untuk sumber yang
  /// lisensinya mengizinkan unduhan offline (kolom `downloadable` pada
  /// `content_sources`). Web tidak mendukung unduhan file → mengembalikan error.
  Future<String?> download({
    required MediaItem media,
    required String label,
    required String url,
    String quality = '720p',
    void Function(double progress)? onProgress,
  }) async {
    if (kIsWeb) {
      return 'Unduhan offline hanya tersedia di aplikasi Android/iOS.';
    }
    final tasks = downloads();
    final task = DownloadTask(
      id: '${media.id}::$label',
      media: media,
      label: label,
      url: url,
      quality: quality,
      status: DownloadStatus.downloading,
      createdAt: DateTime.now(),
    );
    final existingIndex = tasks.indexWhere((item) => item.id == task.id);
    if (existingIndex >= 0) {
      tasks[existingIndex] = task;
    } else {
      tasks.insert(0, task);
    }
    await _persistDownloads(tasks);

    try {
      final directory = await _downloadDirectory();
      final safeName = '${media.id.replaceAll(':', '_')}_${label.replaceAll(' ', '_')}.mp4';
      final path = '${directory.path}/$safeName';
      await Dio().download(
        url,
        path,
        onReceiveProgress: (received, total) {
          if (total <= 0) return;
          final progress = received / total;
          onProgress?.call(progress);
          _updateTask(task.id, (current) => current.copyWith(
                progress: progress,
                sizeMb: total / (1024 * 1024),
              ));
        },
      );
      _updateTask(
        task.id,
        (current) => current.copyWith(
          status: DownloadStatus.completed,
          progress: 1,
          localPath: path,
        ),
      );
      return null;
    } catch (error) {
      _updateTask(
        task.id,
        (current) => current.copyWith(
          status: DownloadStatus.failed,
          errorMessage: '$error',
        ),
      );
      debugPrint('[Download] gagal: $error');
      return 'Unduhan gagal: $error';
    }
  }

  Future<Directory> _downloadDirectory() async {
    Directory base;
    try {
      base = await getApplicationDocumentsDirectory();
    } catch (_) {
      base = Directory.systemTemp;
    }
    final directory = Directory('${base.path}/animeverse_downloads');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  void _updateTask(String id, DownloadTask Function(DownloadTask) update) {
    final tasks = downloads();
    final index = tasks.indexWhere((task) => task.id == id);
    if (index < 0) return;
    tasks[index] = update(tasks[index]);
    _persistDownloads(tasks);
  }

  Future<void> removeDownload(String id) async {
    final tasks = downloads()..removeWhere((task) => task.id == id);
    await _persistDownloads(tasks);
  }

  Future<void> clearDownloads() => LocalStore.setJson(_downloadKey, const []);

  // ───────────────────────────── Stats ─────────────────────────────

  Map<String, int> localStats() {
    final history = _loadHistory();
    final library = _loadLibrary();
    var episodes = 0;
    var minutes = 0;
    var chapters = 0;
    var novels = 0;
    for (final entry in history) {
      if (entry.media.kind.isVideo) {
        episodes += 1;
        minutes += (entry.positionSeconds / 60).round();
      } else if (entry.media.kind == MediaKind.novel) {
        novels += entry.completed ? 1 : 0;
        chapters += 1;
      } else {
        chapters += 1;
      }
    }
    return {
      'episodesWatched': episodes,
      'watchMinutes': minutes,
      'chaptersRead': chapters,
      'novelsRead': novels,
      'bookmarks': library.where((e) => e.kind == LibraryKind.bookmark).length,
      'downloads': downloads().length,
    };
  }

  /// Rekomendasi sederhana berbasis genre favorit dari riwayat & bookmark.
  List<String> preferredGenres() {
    final counts = <String, int>{};
    for (final entry in [..._loadHistory(), ..._loadLibrary()]) {
      for (final genre in entry.media.genres) {
        counts[genre] = (counts[genre] ?? 0) + 1;
      }
    }
    final entries = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return entries.take(3).map((entry) => entry.key).toList();
  }
}
