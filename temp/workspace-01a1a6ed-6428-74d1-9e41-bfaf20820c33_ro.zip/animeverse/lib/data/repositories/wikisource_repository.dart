import 'package:flutter/foundation.dart';
import 'package:html/parser.dart' as html_parser;

import '../../core/config/app_config.dart';
import '../../core/services/api_client.dart';
import '../../core/services/cache_service.dart';
import '../models/chapter.dart';
import '../models/media.dart';

/// Karya sastra domain publik di Wikisource Bahasa Indonesia.
class WikisourceWork {
  const WikisourceWork({
    required this.pageTitle,
    required this.title,
    required this.author,
    required this.year,
    required this.description,
    this.genre = 'Sastra',
  });

  final String pageTitle;
  final String title;
  final String author;
  final int year;
  final String description;
  final String genre;
}

/// Repository novel: sumber teks nyata dari Wikisource (domain publik /
/// CC BY-SA). Setiap bab diambil on-demand dan di-cache.
class WikisourceRepository {
  WikisourceRepository(this._client);

  final ApiClient _client;

  /// Katalog kurasi karya yang tersedia lengkap dengan bab di Wikisource.
  static const List<WikisourceWork> curated = [
    WikisourceWork(
      pageTitle: 'Sitti Nurbaya',
      title: 'Sitti Nurbaya',
      author: 'Marah Rusli',
      year: 1922,
      description:
          'Novel Indonesia klasik tentang Sitti Nurbaya yang dipaksa menikah dengan '
          'Datuk Maringgih demi menyelamatkan keluarganya dari utang. Kisah tragis '
          'tentang adat, kekuasaan, dan cinta yang harus dikorbankan.',
      genre: 'Sastra Klasik',
    ),
    WikisourceWork(
      pageTitle: 'Azab dan Sengsara',
      title: 'Azab dan Sengsara',
      author: 'Merari Siregar',
      year: 1921,
      description:
          'Kisah Mariamin dan Aminu\'ddin yang terpisahkan oleh perjodohan paksa dan '
          'tekanan adat Batak. Dianggap sebagai novel berbahasa Indonesia modern pertama.',
      genre: 'Sastra Klasik',
    ),
    WikisourceWork(
      pageTitle: 'Habis Gelap Terbitlah Terang',
      title: 'Habis Gelap Terbitlah Terang',
      author: 'R.A. Kartini',
      year: 1911,
      description:
          'Kumpulan surat R.A. Kartini kepada sahabat-sahabatnya di Eropa tentang '
          'pendidikan perempuan, emansipasi dan cita-cita kebangsaan.',
      genre: 'Non-Fiksi / Surat',
    ),
  ];

  /// Kategori novel pada UI memakai katalog kurasi + hasil pencarian live.
  Future<PagedMedia> browse({
    CatalogFilter filter = const CatalogFilter(),
  }) async {
    final query = filter.query.trim();
    final base = curated
        .where((work) =>
            query.isEmpty ||
            work.title.toLowerCase().contains(query.toLowerCase()) ||
            work.author.toLowerCase().contains(query.toLowerCase()))
        .toList();

    final results = <MediaItem>[
      for (final work in base) await _toMedia(work),
    ];

    if (query.isNotEmpty || filter.page == 1) {
      final extra = await _searchWorks(query.isEmpty ? 'novel' : query);
      for (final work in extra) {
        if (base.any((existing) => existing.pageTitle == work.pageTitle)) continue;
        results.add(await _toMedia(work));
      }
    }

    return PagedMedia(items: results, page: filter.page, hasNextPage: false);
  }

  Future<List<MediaItem>> trending({int limit = 10}) async {
    final items = <MediaItem>[];
    for (final work in curated.take(limit)) {
      items.add(await _toMedia(work));
    }
    return items;
  }

  Future<MediaItem?> detail(String pageTitle) async {
    final existing = curated.where((work) => work.pageTitle == pageTitle).firstOrNull;
    if (existing != null) return _toMedia(existing);
    final work = await _pageInfo(pageTitle);
    if (work == null) return null;
    return _toMedia(work);
  }

  Future<MediaItem> _toMedia(WikisourceWork work) async {
    final thumb = await _pageThumbnail(work.pageTitle);
    final chapters = await this.chapters(work.pageTitle);
    return MediaItem(
      id: 'wikisource:${work.pageTitle}',
      remoteId: work.pageTitle,
      kind: MediaKind.novel,
      title: work.title,
      source: ContentSource.wikisource,
      coverUrl: thumb,
      description: work.description,
      genres: [work.genre],
      year: work.year,
      status: 'FINISHED',
      format: 'NOVEL',
      chapters: chapters.length,
      studio: work.author,
      siteUrl: 'https://id.wikisource.org/wiki/${Uri.encodeComponent(work.pageTitle)}',
    );
  }

  Future<String?> _pageThumbnail(String pageTitle) async {
    try {
      final data = await CacheService.remember<Map<String, dynamic>>(
        'wikisource::thumb::$pageTitle',
        () async {
          final raw = await _client.getJson(AppConfig.wikisourceEndpoint, query: {
            'action': 'query',
            'format': 'json',
            'formatversion': '2',
            'prop': 'pageimages',
            'titles': pageTitle,
            'pithumbsize': '600',
          });
          return Map<String, dynamic>.from(raw as Map);
        },
        ttl: const Duration(days: 7),
      );
      final pages = ((data['query'] as Map?)?['pages'] as List?) ?? const [];
      if (pages.isEmpty) return null;
      final page = pages.first as Map;
      final thumbnail = page['thumbnail'] as Map?;
      return thumbnail?['source']?.toString();
    } catch (_) {
      return null;
    }
  }

  Future<List<WikisourceWork>> _searchWorks(String query) async {
    try {
      final data = await CacheService.remember<Map<String, dynamic>>(
        'wikisource::search::$query',
        () async {
          final raw = await _client.getJson(AppConfig.wikisourceEndpoint, query: {
            'action': 'query',
            'format': 'json',
            'formatversion': '2',
            'list': 'search',
            'srsearch': query,
            'srlimit': 12,
            'srnamespace': 0,
          });
          return Map<String, dynamic>.from(raw as Map);
        },
        ttl: const Duration(hours: 12),
      );
      final results = ((data['query'] as Map?)?['search'] as List?) ?? const [];
      final works = <WikisourceWork>[];
      for (final entry in results.whereType<Map>()) {
        final title = entry['title']?.toString();
        if (title == null || title.contains('/')) continue;
        final work = await _pageInfo(title);
        if (work != null && work.year > 0) works.add(work);
      }
      return works;
    } catch (error) {
      debugPrint('[Wikisource] search failed: $error');
      return const [];
    }
  }

  Future<WikisourceWork?> _pageInfo(String pageTitle) async {
    try {
      final data = await _client.getJson(AppConfig.wikisourceEndpoint, query: {
        'action': 'query',
        'format': 'json',
        'formatversion': '2',
        'prop': 'extracts|revisions',
        'exintro': 1,
        'explaintext': 1,
        'rvprop': 'timestamp',
        'titles': pageTitle,
      });
      final pages = ((data['query'] as Map?)?['pages'] as List?) ?? const [];
      if (pages.isEmpty) return null;
      final page = pages.first as Map;
      if (page['missing'] == true) return null;
      final extract = (page['extract'] as String? ?? '').trim();
      return WikisourceWork(
        pageTitle: pageTitle,
        title: pageTitle,
        author: _guessAuthor(extract),
        year: int.tryParse(RegExp(r'\b(1[6-9]\d{2}|20\d{2})\b').firstMatch(extract)?.group(0) ?? '') ?? 0,
        description: extract.length > 400 ? '${extract.substring(0, 400)}…' : extract,
        genre: 'Domain Publik',
      );
    } catch (_) {
      return null;
    }
  }

  String _guessAuthor(String extract) {
    final match = RegExp(r'oleh\s+([A-Z][\w\.\s]{2,40})').firstMatch(extract);
    return match?.group(1)?.trim() ?? 'Anonim';
  }

  /// Daftar bab = subhalaman `Judul/Bab n` (atau nama subbab lain).
  Future<List<NovelChapter>> chapters(String pageTitle) async {
    try {
      final data = await CacheService.remember<Map<String, dynamic>>(
        'wikisource::chapters::$pageTitle',
        () async {
          final raw = await _client.getJson(AppConfig.wikisourceEndpoint, query: {
            'action': 'query',
            'format': 'json',
            'formatversion': '2',
            'list': 'allpages',
            'apprefix': '$pageTitle/',
            'aplimit': 500,
          });
          return Map<String, dynamic>.from(raw as Map);
        },
        ttl: const Duration(days: 3),
      );
      final pages = ((data['query'] as Map?)?['allpages'] as List?) ?? const [];
      final chapters = <NovelChapter>[];
      for (final entry in pages.whereType<Map>()) {
        final title = entry['title']?.toString() ?? '';
        final part = title.replaceFirst('$pageTitle/', '');
        if (part.isEmpty) continue;
        final number = int.tryParse(RegExp(r'(\d+)').firstMatch(part)?.group(1) ?? '');
        chapters.add(NovelChapter(
          index: number ?? chapters.length + 1,
          title: part,
          id: title,
        ));
      }
      chapters.sort((a, b) => a.index.compareTo(b.index));
      // Renumber agar selalu berurutan walau judul tanpa angka.
      return [
        for (var i = 0; i < chapters.length; i++)
          NovelChapter(
            index: i + 1,
            title: chapters[i].title,
            id: chapters[i].id,
            wordCount: chapters[i].wordCount,
          ),
      ];
    } catch (error) {
      debugPrint('[Wikisource] chapters failed: $error');
      return const [];
    }
  }

  /// Isi teks satu bab, sudah dibersihkan dari markup MediaWiki.
  Future<String> chapterText(String pageTitle) async {
    final data = await CacheService.remember<Map<String, dynamic>>(
      'wikisource::text::$pageTitle',
      () async {
        final raw = await _client.getJson(AppConfig.wikisourceEndpoint, query: {
          'action': 'parse',
          'format': 'json',
          'formatversion': '2',
          'page': pageTitle,
          'prop': 'text',
          'disableeditsection': 1,
        });
        return Map<String, dynamic>.from(raw as Map);
      },
      ttl: const Duration(days: 3),
    );
    final parse = data['parse'] as Map?;
    final html = parse?['text']?.toString();
    if (html == null || html.isEmpty) {
      throw ApiException('Isi bab tidak tersedia di Wikisource');
    }
    return extractPlainText(html);
  }

  /// Konversi HTML MediaWiki menjadi teks paragraf yang nyaman dibaca.
  @visibleForTesting
  static String extractPlainText(String html) {
    final document = html_parser.parse(html);
    const removeSelectors = [
      'style',
      'script',
      '.ws-noexport',
      '.noprint',
      '.mw-editsection',
      '.headerContainer',
      '.licensetpl',
      '.ws-summary',
      'table',
      'sup.reference',
    ];
    for (final selector in removeSelectors) {
      for (final element in document.querySelectorAll(selector)) {
        element.remove();
      }
    }
    final buffer = StringBuffer();
    final blocks = document.querySelectorAll('p, h1, h2, h3, h4, h5, li, blockquote, dd');
    for (final block in blocks) {
      final text = block.text.replaceAll(RegExp(r'\s+'), ' ').trim();
      if (text.isEmpty) continue;
      if (text.length < 2) continue;
      buffer.writeln(text);
      buffer.writeln();
    }
    final result = buffer.toString().trim();
    return result.isEmpty
        ? document.body?.text.replaceAll(RegExp(r'\n{3,}'), '\n\n').trim() ?? ''
        : result;
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
