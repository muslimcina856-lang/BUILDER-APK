import 'package:flutter/foundation.dart';

import '../../core/config/app_config.dart';
import '../../core/services/api_client.dart';
import '../../core/services/cache_service.dart';
import '../models/media.dart';

/// Client AniList GraphQL.
///
/// AniList menyediakan metadata resmi (judul, sinopsis, genre, rating, jadwal
/// tayang, cover, trailer) untuk anime, donghua, movie, manga, manhwa, manhua
/// dan novel. Rate limit publik ±90 request/menit — semua panggilan di-cache
/// dan di-dedupe agar tidak boros kuota.
class AniListRepository {
  AniListRepository(this._client);

  final ApiClient _client;
  final Map<String, Future<dynamic>> _inFlight = {};

  static const String _mediaFields = '''
    id
    title { romaji english native }
    coverImage { extraLarge large medium color }
    bannerImage
    description(asHtml: false)
    genres
    averageScore
    popularity
    favourites
    episodes
    chapters
    volumes
    duration
    season
    seasonYear
    status
    format
    isAdult
    siteUrl
    startDate { year month day }
    studios(isMain: true) { nodes { name } }
    trailer { id site }
    nextAiringEpisode { episode airingAt }
  ''';

  // ────────────────────────────── Queries ──────────────────────────────

  Future<Map<String, dynamic>> _query(
    String query,
    Map<String, dynamic> variables, {
    Duration? cacheTtl,
    String? cacheKey,
  }) async {
    final key = cacheKey ?? '$query|${variables.toString()}';
    Future<Map<String, dynamic>> run() async {
      final response = await _client.postJson(
        AppConfig.anilistEndpoint,
        {'query': query, 'variables': variables},
      );
      final errors = response['errors'];
      if (errors is List && errors.isNotEmpty) {
        final first = errors.first;
        throw ApiException(
          first is Map ? (first['message']?.toString() ?? 'AniList error') : 'AniList error',
        );
      }
      final data = response['data'];
      if (data is! Map<String, dynamic>) {
        throw ApiException('Respons AniList tidak valid');
      }
      return data;
    }

    return CacheService.remember<Map<String, dynamic>>(
      'anilist::$key',
      () {
        final pending = _inFlight[key];
        if (pending != null) return pending.then((value) => value as Map<String, dynamic>);
        final future = run();
        _inFlight[key] = future;
        return future.whenComplete(() => _inFlight.remove(key));
      },
      ttl: cacheTtl,
    );
  }

  Future<PagedMedia> browse({
    required MediaKind kind,
    CatalogFilter filter = const CatalogFilter(),
  }) async {
    const query = '''
      query Browse(
        \$page: Int, \$perPage: Int, \$type: MediaType, \$sort: [MediaSort],
        \$genre: String, \$year: Int, \$status: MediaStatus, \$search: String,
        \$format: MediaFormat, \$country: CountryCode
      ) {
        Page(page: \$page, perPage: \$perPage) {
          pageInfo { currentPage hasNextPage total }
          media(
            type: \$type, sort: \$sort, genre: \$genre, seasonYear: \$year,
            status: \$status, search: \$search, format: \$format,
            countryOfOrigin: \$country, isAdult: false
          ) { $_mediaFields }
        }
      }
    ''';

    final searches = filter.query.trim().isNotEmpty;
    final variables = <String, dynamic>{
      'page': filter.page,
      'perPage': AppConfig.pageSize,
      'type': kind.aniListType,
      'sort': [searches ? 'SEARCH_MATCH' : filter.sort.aniListValue],
      if (filter.genre != null && filter.genre!.isNotEmpty) 'genre': filter.genre,
      if (filter.year != null) 'year': filter.year,
      if (filter.status != null && filter.status!.isNotEmpty) 'status': filter.status,
      if (searches) 'search': filter.query.trim(),
      if (kind.aniListFormat != null) 'format': kind.aniListFormat,
      if (kind.countryOfOrigin != null) 'country': kind.countryOfOrigin,
    };

    final data = await _query(query, variables);
    final page = data['Page'] as Map? ?? const {};
    final media = (page['media'] as List?) ?? const [];
    final info = page['pageInfo'] as Map? ?? const {};
    return PagedMedia(
      items: media
          .whereType<Map>()
          .map((item) => MediaItem.fromAniList(Map<String, dynamic>.from(item), kind))
          .toList(),
      hasNextPage: info['hasNextPage'] as bool? ?? false,
      page: filter.page,
    );
  }

  Future<List<MediaItem>> trending(MediaKind kind, {int limit = 12}) =>
      _simpleList(kind, 'TRENDING_DESC', limit, 'trending');

  Future<List<MediaItem>> popularNow(MediaKind kind, {int limit = 12}) =>
      _simpleList(kind, 'POPULARITY_DESC', limit, 'popular');

  Future<List<MediaItem>> topRated(MediaKind kind, {int limit = 12}) =>
      _simpleList(kind, 'SCORE_DESC', limit, 'top_rated');

  Future<List<MediaItem>> recentlyUpdated(MediaKind kind, {int limit = 12}) =>
      _simpleList(kind, 'UPDATED_AT_DESC', limit, 'updated');

  Future<List<MediaItem>> upcoming(MediaKind kind, {int limit = 12}) async {
    const query = '''
      query Upcoming(\$type: MediaType, \$perPage: Int, \$format: MediaFormat, \$country: CountryCode) {
        Page(perPage: \$perPage) {
          media(
            type: \$type, status: NOT_YET_RELEASED, sort: POPULARITY_DESC,
            isAdult: false, format: \$format, countryOfOrigin: \$country
          ) { $_mediaFields }
        }
      }
    ''';
    final data = await CacheService.remember<Map<String, dynamic>>(
      'anilist::upcoming::${kind.slug}',
      () => _query(query, {
        'type': kind.aniListType,
        'perPage': limit,
        if (kind.aniListFormat != null) 'format': kind.aniListFormat,
        if (kind.countryOfOrigin != null) 'country': kind.countryOfOrigin,
      }),
      ttl: const Duration(hours: 2),
    );
    return _parseList(data, kind);
  }

  Future<List<MediaItem>> thisSeason(MediaKind kind, {int limit = 12}) async {
    final now = DateTime.now();
    final quarter = ((now.month - 1) ~/ 3);
    const seasons = ['WINTER', 'SPRING', 'SUMMER', 'FALL'];
    const query = '''
      query Season(\$type: MediaType, \$season: MediaSeason, \$year: Int, \$perPage: Int, \$sort: [MediaSort], \$country: CountryCode) {
        Page(perPage: \$perPage) {
          media(
            type: \$type, season: \$season, seasonYear: \$year, sort: \$sort,
            isAdult: false, countryOfOrigin: \$country
          ) { $_mediaFields }
        }
      }
    ''';
    final data = await CacheService.remember<Map<String, dynamic>>(
      'anilist::season::${kind.slug}::${seasons[quarter]}-${now.year}',
      () => _query(query, {
        'type': kind.aniListType,
        'season': seasons[quarter],
        'year': now.year,
        'perPage': limit,
        'sort': ['POPULARITY_DESC'],
        if (kind.countryOfOrigin != null) 'country': kind.countryOfOrigin,
      }),
      ttl: const Duration(hours: 2),
    );
    return _parseList(data, kind);
  }

  Future<List<MediaItem>> _simpleList(
    MediaKind kind,
    String sort,
    int limit,
    String tag,
  ) async {
    const query = '''
      query SimpleList(\$type: MediaType, \$perPage: Int, \$sort: [MediaSort], \$format: MediaFormat, \$country: CountryCode) {
        Page(perPage: \$perPage) {
          media(
            type: \$type, sort: \$sort, isAdult: false,
            format: \$format, countryOfOrigin: \$country
          ) { $_mediaFields }
        }
      }
    ''';
    final data = await CacheService.remember<Map<String, dynamic>>(
      'anilist::$tag::${kind.slug}::$limit',
      () => _query(query, {
        'type': kind.aniListType,
        'perPage': limit,
        'sort': [sort],
        if (kind.aniListFormat != null) 'format': kind.aniListFormat,
        if (kind.countryOfOrigin != null) 'country': kind.countryOfOrigin,
      }),
      ttl: const Duration(minutes: 15),
    );
    return _parseList(data, kind);
  }

  List<MediaItem> _parseList(Map<String, dynamic> data, MediaKind kind) {
    final page = data['Page'] as Map? ?? const {};
    final media = (page['media'] as List?) ?? const [];
    return media
        .whereType<Map>()
        .map((item) => MediaItem.fromAniList(Map<String, dynamic>.from(item), kind))
        .toList();
  }

  /// Detail lengkap satu judul.
  Future<MediaItem?> detail(MediaKind kind, int id) async {
    const query = '''
      query Detail(\$id: Int) {
        Media(id: \$id) {
          $_mediaFields
          genres
          recommendations(sort: RATING_DESC, perPage: 12) {
            nodes { mediaRecommendation { $_mediaFields } }
          }
          relations {
            edges { relationType node { $_mediaFields } }
          }
          characters(sort: [ROLE, RELEVANCE], perPage: 10) {
            nodes { id name { full native } image { large } }
          }
          staff(perPage: 6) { nodes { id name { full } } }
          streamingEpisodes { title thumbnail url site }
          externalLinks { id site url type }
          tags { id name rank isMediaSpoiler }
          rankings { rank type allTime season year }
        }
      }
    ''';
    final data = await CacheService.remember<Map<String, dynamic>>(
      'anilist::detail::$id',
      () => _query(query, {'id': id}),
      ttl: const Duration(hours: 6),
    );
    final media = data['Media'];
    if (media is! Map) return null;
    final item = MediaItem.fromAniList(Map<String, dynamic>.from(media), kind);
    AniListDetailCache.instance.store(item.id, {
      'recommendations': _parseMediaNodes(media['recommendations'], kind),
      'relations': _parseRelations(media['relations'], kind),
      'characters': _parseCharacters(media['characters']),
      'streamingEpisodes': _parseStreamingEpisodes(media['streamingEpisodes']),
      'externalLinks': (media['externalLinks'] as List? ?? const [])
          .whereType<Map>()
          .map((e) => {
                'site': e['site'],
                'url': e['url'],
                'type': e['type'],
              })
          .toList(),
    });
    return item;
  }

  List<MediaItem> _parseMediaNodes(Object? nodes, MediaKind kind) {
    final list = (nodes as Map?)?['nodes'];
    if (list is! List) return const [];
    return list
        .whereType<Map>()
        .map((node) => node['mediaRecommendation'])
        .whereType<Map>()
        .map((media) => MediaItem.fromAniList(Map<String, dynamic>.from(media), kind))
        .toList();
  }

  List<Map<String, dynamic>> _parseRelations(Object? relations, MediaKind kind) {
    final edges = (relations as Map?)?['edges'];
    if (edges is! List) return const [];
    return edges.whereType<Map>().map((edge) {
      final node = edge['node'];
      final media = node is Map
          ? MediaItem.fromAniList(Map<String, dynamic>.from(node), kind)
          : null;
      return {
        'relationType': edge['relationType'],
        'media': media?.toJson(),
      };
    }).toList();
  }

  List<Map<String, dynamic>> _parseCharacters(Object? characters) {
    final nodes = (characters as Map?)?['nodes'];
    if (nodes is! List) return const [];
    return nodes.whereType<Map>().map((node) {
      final name = node['name'] as Map? ?? const {};
      final image = node['image'] as Map? ?? const {};
      return {
        'name': name['full'] ?? name['native'] ?? '',
        'native': name['native'],
        'image': image['large'],
      };
    }).toList();
  }

  List<Map<String, dynamic>> _parseStreamingEpisodes(Object? episodes) {
    if (episodes is! List) return const [];
    return episodes
        .whereType<Map>()
        .map((e) => {
              'title': e['title'],
              'thumbnail': e['thumbnail'],
              'url': e['url'],
              'site': e['site'],
            })
        .toList();
  }

  /// Jadwal rilis 7 hari ke depan (Senin–Minggu) untuk anime & donghua.
  Future<List<ScheduleSlot>> schedule({
    MediaKind kind = MediaKind.anime,
    DateTime? weekStart,
  }) async {
    final start = weekStart ?? _startOfWeek(DateTime.now());
    final from = start.millisecondsSinceEpoch ~/ 1000;
    final to = start.add(const Duration(days: 7)).millisecondsSinceEpoch ~/ 1000;
    const query = '''
      query Schedule(\$from: Int, \$to: Int, \$country: CountryCode) {
        Page(perPage: 60) {
          airingSchedules(airingAt_greater: \$from, airingAt_lesser: \$to, sort: TIME) {
            airingAt
            episode
            media { $_mediaFields }
          }
        }
      }
    ''';
    final data = await CacheService.remember<Map<String, dynamic>>(
      'anilist::schedule::${kind.slug}::${start.toIso8601String().substring(0, 10)}',
      () => _query(query, {
        'from': from,
        'to': to,
        if (kind.countryOfOrigin != null) 'country': kind.countryOfOrigin,
      }),
      ttl: const Duration(hours: 3),
    );
    final page = data['Page'] as Map? ?? const {};
    final schedules = (page['airingSchedules'] as List?) ?? const [];
    final slots = <ScheduleSlot>[];
    for (final entry in schedules.whereType<Map>()) {
      final media = entry['media'];
      if (media is! Map) continue;
      slots.add(ScheduleSlot(
        airingAt: DateTime.fromMillisecondsSinceEpoch(
          ((entry['airingAt'] as num?)?.toInt() ?? 0) * 1000,
        ),
        episode: (entry['episode'] as num?)?.toInt() ?? 1,
        media: MediaItem.fromAniList(Map<String, dynamic>.from(media), kind),
      ));
    }
    return slots;
  }

  static DateTime _startOfWeek(DateTime date) {
    final normalized = DateTime(date.year, date.month, date.day);
    return normalized.subtract(Duration(days: normalized.weekday - 1));
  }

  /// Pencarian global lintas tipe (anime + manga).
  Future<List<MediaItem>> searchAll(String query, {int perPage = 20}) async {
    if (query.trim().length < 2) return const [];
    const q = '''
      query Search(\$search: String, \$perPage: Int) {
        Page(perPage: \$perPage) {
          media(search: \$search, sort: SEARCH_MATCH, isAdult: false) {
            $_mediaFields
            type
          }
        }
      }
    ''';
    final data = await _query(q, {'search': query.trim(), 'perPage': perPage},
        cacheTtl: const Duration(minutes: 5));
    final page = data['Page'] as Map? ?? const {};
    final media = (page['media'] as List?) ?? const [];
    return media.whereType<Map>().map((item) {
      final type = item['type']?.toString();
      final kind = type == 'MANGA'
          ? _kindFromFormat(item['format']?.toString())
          : MediaKind.anime;
      return MediaItem.fromAniList(Map<String, dynamic>.from(item), kind);
    }).toList();
  }

  MediaKind _kindFromFormat(String? format) {
    switch (format) {
      case 'NOVEL':
        return MediaKind.novel;
      case 'ONE_SHOT':
        return MediaKind.manga;
      default:
        return MediaKind.manga;
    }
  }

  /// Semua genre yang dikenal AniList (untuk chip filter).
  static const List<String> genres = [
    'Action', 'Adventure', 'Comedy', 'Drama', 'Ecchi', 'Fantasy', 'Horror',
    'Mahou Shoujo', 'Mecha', 'Music', 'Mystery', 'Psychological', 'Romance',
    'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller',
  ];

  static const Map<String, String> genreLabelId = {
    'Action': 'Aksi',
    'Adventure': 'Petualangan',
    'Comedy': 'Komedi',
    'Drama': 'Drama',
    'Ecchi': 'Ecchi',
    'Fantasy': 'Fantasi',
    'Horror': 'Horor',
    'Mahou Shoujo': 'Mahou Shoujo',
    'Mecha': 'Mecha',
    'Music': 'Musik',
    'Mystery': 'Misteri',
    'Psychological': 'Psikologis',
    'Romance': 'Romansa',
    'Sci-Fi': 'Sci-Fi',
    'Slice of Life': 'Slice of Life',
    'Sports': 'Olahraga',
    'Supernatural': 'Supranatural',
    'Thriller': 'Thriller',
  };
}

class ScheduleSlot {
  const ScheduleSlot({
    required this.airingAt,
    required this.episode,
    required this.media,
  });

  final DateTime airingAt;
  final int episode;
  final MediaItem media;
}

/// Cache detail tambahan (rekomendasi, karakter, dsb.) agar tidak query ulang.
class AniListDetailCache {
  AniListDetailCache._();
  static final AniListDetailCache instance = AniListDetailCache._();

  final Map<String, Map<String, dynamic>> _store = {};

  void store(String mediaId, Map<String, dynamic> payload) {
    _store[mediaId] = payload;
    if (_store.length > 40) {
      _store.remove(_store.keys.first);
    }
  }

  Map<String, dynamic>? read(String mediaId) => _store[mediaId];

  @visibleForTesting
  void clear() => _store.clear();
}
