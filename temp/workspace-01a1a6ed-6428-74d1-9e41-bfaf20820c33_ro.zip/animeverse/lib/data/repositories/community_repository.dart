import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/services/local_store.dart';
import '../../core/services/supabase_gateway.dart';
import '../models/community.dart';
import '../models/user_profile.dart';

/// Komentar, reply, reaksi, follow, notifikasi, chat, dan moderasi.
///
/// Supabase: tabel `comments`, `comment_replies`, `likes`, `follows`,
/// `notifications`, `community_messages`, `reports` + Realtime.
/// Mode lokal: JSON store yang sama strukturnya sehingga UI identik.
class CommunityRepository {
  CommunityRepository(this._gateway);

  final SupabaseGateway _gateway;
  UserProfile? _currentUser;

  static const String _commentsKey = 'community::comments';
  static const String _chatKey = 'community::chat';
  static const String _notifKey = 'community::notifications';
  static const String _followKey = 'community::follows';
  static const String _reportsKey = 'community::reports';
  static const String _blockKey = 'community::blocks';

  void bindUser(UserProfile? profile) => _currentUser = profile;

  // ───────────────────────────── Moderasi ─────────────────────────────

  static const List<String> _bannedWords = [
    'anjing', 'bangsat', 'kontol', 'memek', 'idiot', 'bego', 'tolol',
    'goblok', 'jancok', 'kimak', 'fuck', 'bitch', 'asshole',
  ];

  static const int _maxCommentLength = 1000;
  static const int _minSecondsBetweenComments = 15;

  /// Validasi anti-spam sederhana di sisi klien (server juga memvalidasi
  /// melalui trigger `check_comment_spam` pada schema SQL).
  String? validateComment(String text) {
    final trimmed = text.trim();
    if (trimmed.length < 2) return 'Komentar terlalu pendek.';
    if (trimmed.length > _maxCommentLength) {
      return 'Komentar maksimal $_maxCommentLength karakter.';
    }
    final lower = trimmed.toLowerCase();
    for (final word in _bannedWords) {
      if (lower.contains(word)) {
        return 'Komentar mengandung kata yang tidak pantas.';
      }
    }
    final links = RegExp(r'https?://').allMatches(lower).length;
    if (links > 2) return 'Terlalu banyak tautan pada satu komentar.';
    final lastAt = LocalStore.getInt('community::lastCommentAt');
    if (lastAt > 0) {
      final diff = DateTime.now().millisecondsSinceEpoch - lastAt;
      if (diff < _minSecondsBetweenComments * 1000) {
        final wait = _minSecondsBetweenComments - (diff ~/ 1000);
        return 'Tunggu $wait detik sebelum berkomentar lagi (anti-spam).';
      }
    }
    return null;
  }

  // ───────────────────────────── Komentar ─────────────────────────────

  List<CommentItem> _allComments() {
    final raw = LocalStore.getJsonList(_commentsKey);
    if (raw.isEmpty) {
      final seed = LocalStore.getJsonList('comments::seed');
      if (seed.isNotEmpty) {
        return seed
            .whereType<Map>()
            .map((entry) => CommentItem.fromJson(Map<String, dynamic>.from(entry)))
            .toList();
      }
    }
    return raw
        .whereType<Map>()
        .map((entry) => CommentItem.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
  }

  Future<void> _persist(List<CommentItem> comments) async {
    await LocalStore.setJson(
      _commentsKey,
      comments.map((comment) => comment.toJson()).toList(),
    );
  }

  Future<List<CommentItem>> comments({
    required CommentTarget target,
    required String targetId,
  }) async {
    final List<CommentItem> source;
    if (_gateway.enabled) {
      final rows = await _gateway.select(
        'comments',
        eq: {'target_type': target.name, 'target_id': targetId},
        orderBy: 'created_at',
        limit: 200,
      );
      source = rows.map(_mapRow).toList();
    } else {
      source = _allComments()
          .where((comment) => comment.targetType == target && comment.targetId == targetId)
          .toList();
    }
    final topLevel = source.where((comment) => comment.parentId == null).toList()
      ..sort((a, b) {
        if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
        return b.createdAt.compareTo(a.createdAt);
      });
    return topLevel;
  }

  Future<List<CommentItem>> recentActivity({int limit = 20}) async {
    final all = _allComments()..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return all.take(limit).toList();
  }

  CommentItem _mapRow(Map<String, dynamic> row) {
    final author = row['author'] as Map?;
    return CommentTimelineMapper.fromRow(row, author);
  }

  Future<CommentItem?> postComment({
    required CommentTarget target,
    required String targetId,
    required String content,
    String? parentId,
  }) async {
    final user = _currentUser;
    if (user == null) return null;
    final error = validateComment(content);
    if (error != null) {
      throw CommunityException(error);
    }
    await LocalStore.setInt(
      'community::lastCommentAt',
      DateTime.now().millisecondsSinceEpoch,
    );
    final comment = CommentItem(
      id: 'c${DateTime.now().microsecondsSinceEpoch}',
      content: content.trim(),
      author: CommentAuthor(
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl,
        level: user.level,
        tier: user.tier.value,
        selectedTitle: user.selectedTitle,
        rankKey: user.rankKey,
      ),
      createdAt: DateTime.now(),
      targetType: target,
      targetId: targetId,
      parentId: parentId,
      mentionedUsers: _extractMentions(content),
    );

    if (_gateway.enabled) {
      final inserted = await _gateway.insert('comments', {
        'id': comment.id,
        'user_id': user.id,
        'target_type': target.name,
        'target_id': targetId,
        'parent_id': parentId,
        'content': comment.content,
        'created_at': comment.createdAt.toIso8601String(),
      });
      if (!inserted) {
        debugPrint('[Community] insert Supabase gagal, fallback lokal');
      }
    }

    final all = _allComments();
    all.add(comment);
    await _persist(all);
    return comment;
  }

  List<String> _extractMentions(String text) => RegExp(r'@([a-zA-Z0-9_.]{3,})')
      .allMatches(text)
      .map((match) => match.group(1)!)
      .toList();

  Future<CommentItem> react({
    required List<CommentItem> all,
    required String commentId,
    required int reaction, // 1 like, -1 dislike, 0 clear
  }) async {
    final comments = _allComments();
    final index = comments.indexWhere((comment) => comment.id == commentId);
    if (index < 0) throw CommunityException('Komentar tidak ditemukan');
    final current = comments[index];
    final previous = current.myReaction;
    var likes = current.likes;
    var dislikes = current.dislikes;
    if (previous == 1) likes -= 1;
    if (previous == -1) dislikes -= 1;
    if (reaction == 1) likes += 1;
    if (reaction == -1) dislikes += 1;
    comments[index] = current.copyWith(
      likes: max(0, likes),
      dislikes: max(0, dislikes),
      myReaction: previous == reaction ? 0 : reaction,
    );
    await _persist(comments);
    if (_gateway.enabled && _currentUser != null) {
      await _gateway.upsert('likes', {
        'user_id': _currentUser!.id,
        'comment_id': commentId,
        'value': previous == reaction ? 0 : reaction,
        'updated_at': DateTime.now().toIso8601String(),
      }, onConflict: 'user_id,comment_id');
    }
    return comments[index];
  }

  Future<void> pinComment(String commentId, bool pinned) async {
    final comments = _allComments();
    final index = comments.indexWhere((comment) => comment.id == commentId);
    if (index < 0) return;
    comments[index] = comments[index].copyWith(isPinned: pinned);
    await _persist(comments);
    if (_gateway.enabled) {
      await _gateway.update('comments', {'is_pinned': pinned}, eq: {'id': commentId});
    }
  }

  Future<void> deleteComment(String commentId) async {
    final comments = _allComments()..removeWhere((comment) => comment.id == commentId);
    await _persist(comments);
    if (_gateway.enabled) {
      await _gateway.update('comments', {'is_deleted': true}, eq: {'id': commentId});
    }
  }

  Future<void> reportComment({
    required String commentId,
    required String reason,
    String detail = '',
  }) async {
    final report = ContentReport(
      id: 'r${DateTime.now().microsecondsSinceEpoch}',
      targetType: 'comment',
      targetId: commentId,
      reason: reason,
      detail: detail,
      reporterId: _currentUser?.id ?? 'guest',
      reporterName: _currentUser?.username ?? 'guest',
      createdAt: DateTime.now(),
    );
    final raw = LocalStore.getJsonList(_reportsKey)
      ..add(report.toJson());
    await LocalStore.setJson(_reportsKey, raw);
    if (_gateway.enabled) {
      await _gateway.insert('reports', {
        'id': report.id,
        'reporter_id': report.reporterId,
        'target_type': report.targetType,
        'target_id': report.targetId,
        'reason': report.reason,
        'detail': report.detail,
        'status': 'open',
        'created_at': report.createdAt.toIso8601String(),
      });
    }
  }

  Future<void> reportContent({
    required String targetType,
    required String targetId,
    required String reason,
    String detail = '',
  }) async {
    final report = ContentReport(
      id: 'r${DateTime.now().microsecondsSinceEpoch}',
      targetType: targetType,
      targetId: targetId,
      reason: reason,
      detail: detail,
      reporterId: _currentUser?.id ?? 'guest',
      reporterName: _currentUser?.username ?? 'guest',
      createdAt: DateTime.now(),
    );
    final raw = LocalStore.getJsonList(_reportsKey)..add(report.toJson());
    await LocalStore.setJson(_reportsKey, raw);
    if (_gateway.enabled) {
      await _gateway.insert('reports', {
        'id': report.id,
        'reporter_id': report.reporterId,
        'target_type': report.targetType,
        'target_id': report.targetId,
        'reason': report.reason,
        'detail': report.detail,
        'status': 'open',
        'created_at': report.createdAt.toIso8601String(),
      });
    }
  }

  List<ContentReport> reports() => LocalStore.getJsonList(_reportsKey)
      .whereType<Map>()
      .map((entry) => ContentReport.fromJson(Map<String, dynamic>.from(entry)))
      .toList()
    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  Future<void> updateReportStatus(String id, ReportStatus status) async {
    final list = reports();
    final index = list.indexWhere((report) => report.id == id);
    if (index < 0) return;
    list[index] = list[index].copyWith(status: status);
    await LocalStore.setJson(
      _reportsKey,
      list.map((report) => report.toJson()).toList(),
    );
    if (_gateway.enabled) {
      await _gateway.update('reports', {'status': status.name}, eq: {'id': id});
    }
  }

  // ───────────────────────────── Follow ─────────────────────────────

  Set<String> get _following =>
      LocalStore.getJsonList(_followKey).map((e) => '$e').toSet();

  bool isFollowing(String userId) => _following.contains(userId);

  Future<bool> toggleFollow(String userId) async {
    final following = _following;
    final adding = !following.contains(userId);
    if (adding) {
      following.add(userId);
    } else {
      following.remove(userId);
    }
    await LocalStore.setJson(_followKey, following.toList());
    if (_gateway.enabled && _currentUser != null) {
      if (adding) {
        await _gateway.upsert('follows', {
          'follower_id': _currentUser!.id,
          'following_id': userId,
          'created_at': DateTime.now().toIso8601String(),
        }, onConflict: 'follower_id,following_id');
      } else {
        await _gateway.delete('follows', eq: {
          'follower_id': _currentUser!.id,
          'following_id': userId,
        });
      }
    }
    return adding;
  }

  Future<void> toggleBlock(String userId, bool blocked) async {
    final blockedUsers = LocalStore.getJsonList(_blockKey).map((e) => '$e').toSet();
    if (blocked) {
      blockedUsers.add(userId);
    } else {
      blockedUsers.remove(userId);
    }
    await LocalStore.setJson(_blockKey, blockedUsers.toList());
    if (_gateway.enabled && _currentUser != null) {
      await _gateway.upsert('blocked_users', {
        'user_id': _currentUser!.id,
        'blocked_user_id': userId,
      }, onConflict: 'user_id,blocked_user_id');
    }
  }

  Set<String> get blockedUsers =>
      LocalStore.getJsonList(_blockKey).map((e) => '$e').toSet();

  // ───────────────────────────── Chat ─────────────────────────────

  List<ChatMessage> messages(String roomId) {
    final raw = LocalStore.getJsonList('$_chatKey::$roomId');
    final list = raw
        .whereType<Map>()
        .map((entry) => ChatMessage.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
    if (list.isEmpty) {
      final seed = LocalStore.getJsonList(_chatKey);
      if (roomId == Bus.chatRoomId && seed.isNotEmpty) {
        return seed
            .whereType<Map>()
            .map((entry) => ChatMessage.fromJson(Map<String, dynamic>.from(entry)))
            .toList();
      }
    }
    return list..sort((a, b) => a.createdAt.compareTo(b.createdAt));
  }

  Stream<List<ChatMessage>> watchMessages(String roomId) async* {
    yield messages(roomId);
    if (_gateway.enabled) {
      final channel = _gateway.channel('room:$roomId');
      final controller = StreamController<List<ChatMessage>>();
      channel
          ?.onPostgresChanges(
            event: PostgresChangeEvent.insert,
            schema: 'public',
            table: 'community_messages',
            filter: PostgresChangeFilter(
              type: PostgresChangeFilterType.eq,
              column: 'room_id',
              value: roomId,
            ),
            callback: (_) => controller.add(messages(roomId)),
          )
          ?.subscribe();
      await for (final value in controller.stream) {
        yield value;
      }
      return;
    }
    // Mode lokal: polling ringan.
    yield* Stream.periodic(const Duration(seconds: 4), (_) => messages(roomId));
  }

  Future<ChatMessage?> sendMessage(String roomId, String text) async {
    final user = _currentUser;
    if (user == null) return null;
    final trimmed = text.trim();
    if (trimmed.isEmpty) return null;
    if (trimmed.length > 500) throw CommunityException('Pesan maksimal 500 karakter.');
    final lower = trimmed.toLowerCase();
    for (final word in _bannedWords) {
      if (lower.contains(word)) {
        throw CommunityException('Pesan mengandung kata yang tidak pantas.');
      }
    }
    final message = ChatMessage(
      id: 'm${DateTime.now().microsecondsSinceEpoch}',
      roomId: roomId,
      author: CommentAuthor(
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl,
        level: user.level,
        tier: user.tier.value,
      ),
      text: trimmed,
      createdAt: DateTime.now(),
    );
    final raw = LocalStore.getJsonList('$_chatKey::$roomId')
      ..add(message.toJson());
    await LocalStore.setJson('$_chatKey::$roomId', raw);
    if (_gateway.enabled) {
      await _gateway.insert('community_messages', {
        'id': message.id,
        'room_id': roomId,
        'user_id': user.id,
        'content': trimmed,
        'created_at': message.createdAt.toIso8601String(),
      });
    }
    return message;
  }

  // ───────────────────────── Notifikasi ─────────────────────────

  List<AppNotification> notifications() {
    final raw = LocalStore.getJsonList(_notifKey);
    final list = raw
        .whereType<Map>()
        .map((entry) => AppNotification.fromJson(Map<String, dynamic>.from(entry)))
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    if (list.isEmpty) return _seedNotifications();
    return list;
  }

  List<AppNotification> _seedNotifications() {
    final now = DateTime.now();
    return [
      AppNotification(
        id: 'n1',
        title: 'Episode baru tersedia',
        body: 'Episode terbaru dari anime favoritmu sudah tayang. Lanjutkan menonton!',
        createdAt: now.subtract(const Duration(minutes: 40)),
        type: NotificationKind.newEpisode,
        payload: const {'mediaId': 'anilist:21'},
      ),
      AppNotification(
        id: 'n2',
        title: 'Chapter baru',
        body: 'Manhwa di bookmark kamu mengunggah chapter baru.',
        createdAt: now.subtract(const Duration(hours: 5)),
        type: NotificationKind.newChapter,
      ),
      AppNotification(
        id: 'n3',
        title: 'Selamat datang di ANIMEVERSE',
        body: 'Selesaikan quest harian untuk mengumpulkan EXP & naikkan rank.',
        createdAt: now.subtract(const Duration(days: 1)),
        type: NotificationKind.system,
      ),
    ];
  }

  int get unreadCount => notifications().where((item) => !item.read).length;

  Future<void> markNotificationRead(String id) async {
    final list = notifications();
    final index = list.indexWhere((item) => item.id == id);
    if (index < 0) return;
    list[index] = list[index].copyWith(read: true);
    await LocalStore.setJson(_notifKey, list.map((item) => item.toJson()).toList());
  }

  Future<void> markAllNotificationsRead() async {
    final list = notifications()
        .map((item) => item.copyWith(read: true))
        .toList();
    await LocalStore.setJson(_notifKey, list.map((item) => item.toJson()).toList());
  }

  Future<void> pushNotification(AppNotification notification) async {
    final list = notifications().where((item) => item.id != notification.id).toList()
      ..insert(0, notification);
    await LocalStore.setJson(_notifKey, list.map((item) => item.toJson()).toList());
    if (_gateway.enabled) {
      await _gateway.insert('notifications', {
        'id': notification.id,
        'user_id': _currentUser?.id,
        'title': notification.title,
        'body': notification.body,
        'type': notification.type.name,
        'payload': notification.payload,
        'created_at': notification.createdAt.toIso8601String(),
      });
    }
  }

  /// Reset store (dipakai pengaturan "hapus data lokal").
  Future<void> clearLocal() async {
    for (final key in [
      _commentsKey,
      _chatKey,
      _notifKey,
      _followKey,
      _reportsKey,
      _blockKey,
    ]) {
      await LocalStore.remove(key);
    }
  }
}

class CommunityException implements Exception {
  CommunityException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Helper kecil agar konversi baris Supabase tetap mudah dibaca.
class CommentTimelineMapper {
  static CommentItem fromRow(Map<String, dynamic> row, Map? author) {
    final profile = (row['profiles'] as Map?) ?? author;
    return CommentItem(
      id: row['id'].toString(),
      content: row['content'] as String? ?? '',
      author: CommentAuthor(
        id: row['user_id']?.toString() ?? '',
        username: profile?['username']?.toString() ?? 'pengguna',
        displayName: profile?['display_name']?.toString() ?? '',
        avatarUrl: profile?['avatar_url'] as String?,
        level: (profile?['level'] as num?)?.toInt() ?? 1,
        tier: profile?['tier']?.toString() ?? 'free',
        selectedTitle: profile?['selected_title'] as String?,
        rankKey: profile?['rank_key']?.toString() ?? 'beginner',
      ),
      createdAt: DateTime.tryParse(row['created_at']?.toString() ?? '') ?? DateTime.now(),
      targetType: CommentTarget.values.firstWhere(
        (value) => value.name == row['target_type'],
        orElse: () => CommentTarget.media,
      ),
      targetId: row['target_id']?.toString() ?? '',
      parentId: row['parent_id']?.toString(),
      likes: (row['like_count'] as num?)?.toInt() ?? 0,
      dislikes: (row['dislike_count'] as num?)?.toInt() ?? 0,
      isPinned: row['is_pinned'] as bool? ?? false,
      isDeleted: row['is_deleted'] as bool? ?? false,
    );
  }
}

/// Konstanta kecil untuk room chat global.
class Bus {
  const Bus._();
  static const String chatRoomId = 'global';
}
