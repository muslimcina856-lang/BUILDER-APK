import 'package:flutter/foundation.dart';

import '../../core/config/app_config.dart';
import '../../core/services/api_client.dart';
import '../../core/services/cache_service.dart';
import '../models/chapter.dart';
import '../models/media.dart';

/// Client MangaDex (API publik resmi, dokumentasi: api.mangadex.org/docs).
///
/// Catatan lisensi: MangaDex menampung unggahan komunitas. Sebelum dipakai
/// secara komersial, ganti [preferredLanguages] dan daftar grup/scanlation
/// sesuai perjanjian lisensi Anda, atau arahkan repository ini ke sumber
/// berlisensi lewat tabel `content_sources`.
class MangaDexRepository {
  MangaDexRepository(this._client);

  final ApiClient _client;

  /// Bahasa terjemahan yang diutamakan: Indonesia dulu, lalu Inggris.
  static const List<String> preferredLanguages = ['id', 'en'];

  static const List<String> _contentRatings = ['safe', 'suggestive'];

  Future<List<MediaItem>> browse({
    required MediaKind kind,
    CatalogFilter filter = const CatalogFilter(),
  }) async {
    final order = switch (filter.sort) {
      CatalogSort.trending => 'followedCount',
      CatalogSort.popular => 'followedCount',
      CatalogSort.score => 'rating',
      CatalogSort.newest => 'createdAt',
      CatalogSort.updated => 'latestUploadedChapter',
      CatalogSort.title => 'title',
    };
    final direction = filter.sort == CatalogSort.title ? 'asc' : 'desc';
    final query = <String, dynamic>{
      'limit': AppConfig.pageSize,
      'offset': (filter.page - 1) * AppConfig.pageSize,
      'includes[]': ['cover_art'],
      'contentRating[]': _contentRatings,
      'order[$order]': direction,
      'hasAvailableChapters': 'true',
      if (kind.mangadexOriginalLanguage != null)
        'originalLanguage[]': [kind.mangadexOriginalLanguage],
      if (filter.query.trim().isNotEmpty) 'title': filter.query.trim(),
      if (filter.year != null) 'year': filter.year,
      if (filter.status != null) 'status[]': [_mangaDexStatus(filter.status!)],
      if (filter.genre != null && filter.genre!.isNotEmpty)
        'includedTags[]': [await _tagId(filter.genre!)].whereType<String>().toList(),
    };
    query.removeWhere((key, value) => value == null || (value is List && value.isEmpty));

    final cacheKey = 'mangadex::browse::${kind.slug}::${query.toString()}';
    final data = await CacheService.remember<Map<String, dynamic>>(
      cacheKey,
      () async {
        final raw = await _client.getJson(
          '${AppConfig.mangadexEndpoint}/manga',
          query: _flatten(query),
        );
        return Map<String, dynamic>.from(raw as Map);
      },
      ttl: const Duration(minutes: 10),
    );

    final items = _parseCollection(data, kind);
    final total = (data['total'] as num?)?.toInt() ?? items.length;
    return items.isEmpty && filter.page == 1
        ? await _fallbackSearch(kind, filter)
        : PagedMedia(
            items: items,
            page: filter.page,
            hasNextPage: (filter.page * AppConfig.pageSize) < total,
          );
  }

  Future<PagedMedia> _fallbackSearch(MediaKind kind, CatalogFilter filter) async {
    // Beberapa filter MangaDex (mis. tag + tahun) bisa kosong; longgarkan filter.
    final raw = await _client.getJson(
      '${AppConfig.mangadexEndpoint}/manga',
      query: {
        'limit': AppConfig.pageSize,
        'includes[]': 'cover_art',
        'contentRating[]': _contentRatings,
        'order[followedCount]': 'desc',
        if (kind.mangadexOriginalLanguage != null)
          'originalLanguage[]': kind.mangadexOriginalLanguage,
      },
    );
    final data = Map<String, dynamic>.from(raw as Map);
    return PagedMedia(items: _parseCollection(data, kind), page: 1);
  }

  /// MangaDex menerima array sebagai `key[]=a&key[]=b`. Dio akan meng-encode
  /// list menjadi `key[]=a&key[]=b` bila key sudah berakhiran `[]`.
  Map<String, dynamic> _flatten(Map<String, dynamic> source) {
    final result = <String, dynamic>{};
    source.forEach((key, value) {
      if (value == null) return;
      if (value is List) {
        result[key.contains('[]') ? key : '$key[]'] = value;
      } else {
        result[key] = value;
      }
    });
    return result;
  }

  List<MediaItem> _parseCollection(Map<String, dynamic> data, MediaKind kind) {
    final list = (data['data'] as List?) ?? const [];
    return list
        .whereType<Map>()
        .map((raw) => _mapManga(Map<String, dynamic>.from(raw), kind))
        .whereType<MediaItem>()
        .toList();
  }

  MediaItem? _mapManga(Map<String, dynamic> raw, MediaKind kind) {
    final id = raw['id']?.toString();
    if (id == null) return null;
    final attributes = Map<String, dynamic>.from(raw['attributes'] as Map? ?? const {});
    final titleMap = Map<String, dynamic>.from(attributes['title'] as Map? ?? const {});
    final altTitles = (attributes['altTitles'] as List?) ?? const [];
    final title = (titleMap['id'] ??
            titleMap['en'] ??
            titleMap['ja-ro'] ??
            titleMap['ja'] ??
            (altTitles.isNotEmpty && altTitles.first is Map
                ? (altTitles.first as Map).values.first
                : null) ??
            'Tanpa Judul')
        .toString();
    final descriptionMap =
        Map<String, dynamic>.from(attributes['description'] as Map? ?? const {});
    final coverUrl = _coverUrl(raw, id);
    final tags = (attributes['tags'] as List?) ?? const [];
    final genres = tags
        .whereType<Map>()
        .map((tag) {
          final attrs = Map<String, dynamic>.from(tag['attributes'] as Map? ?? const {});
          final names = Map<String, dynamic>.from(attrs['name'] as Map? ?? const {});
          return (names['id'] ?? names['en'])?.toString();
        })
        .whereType<String>()
        .take(8)
        .toList();
    final year = int.tryParse('${attributes['year'] ?? ''}');
    final lastVolume = attributes['lastVolume'];
    final relationships = (raw['relationships'] as List?) ?? const [];
    final authorNames = relationships
        .whereType<Map>()
        .where((rel) => rel['type'] == 'author')
        .map((rel) => (rel['attributes'] as Map?)?['name']?.toString())
        .whereType<String>()
        .toList();
    final author = authorNames.isEmpty ? null : authorNames.first;

    return MediaItem(
      id: 'mangadex:$id',
      remoteId: id,
      kind: kind,
      title: title,
      titleEnglish: titleMap['en'] as String?,
      source: ContentSource.mangadex,
      coverUrl: coverUrl,
      description: (descriptionMap['id'] ?? descriptionMap['en'])?.toString(),
      genres: genres,
      year: year,
      status: _mapStatus(attributes['status']?.toString()),
      format: kind.label,
      volumes: int.tryParse('$lastVolume'),
      studio: author,
      popularity: null,
      siteUrl: 'https://mangadex.org/title/$id',
    );
  }

  String? _coverUrl(Map<String, dynamic> raw, String mangaId) {
    final relationships = (raw['relationships'] as List?) ?? const [];
    for (final rel in relationships.whereType<Map>()) {
      if (rel['type'] == 'cover_art') {
        final fileName = (rel['attributes'] as Map?)?['fileName']?.toString();
        if (fileName != null) {
          return '${AppConfig.mangadexUploads}/covers/$mangaId/$fileName.512.jpg';
        }
      }
    }
    return null;
  }

  String _mapStatus(String? status) {
    switch (status) {
      case 'ongoing':
        return 'RELEASING';
      case 'completed':
        return 'FINISHED';
      case 'hiatus':
        return 'HIATUS';
      case 'cancelled':
        return 'CANCELLED';
      default:
        return 'RELEASING';
    }
  }

  String _mangaDexStatus(String aniListStatus) {
    switch (aniListStatus) {
      case 'RELEASING':
        return 'ongoing';
      case 'FINISHED':
        return 'completed';
      case 'HIATUS':
        return 'hiatus';
      case 'CANCELLED':
        return 'cancelled';
      default:
        return 'ongoing';
    }
  }

  Future<String?> _tagId(String genreName) async {
    final data = await CacheService.remember<Map<String, dynamic>>(
      'mangadex::tags',
      () async {
        final raw = await _client.getJson('${AppConfig.mangadexEndpoint}/manga/tag');
        return {'data': raw};
      },
      ttl: const Duration(days: 7),
    );
    final list = (data['data'] as List?) ?? const [];
    for (final tag in list.whereType<Map>()) {
      final attrs = Map<String, dynamic>.from(tag['attributes'] as Map? ?? const {});
      final names = Map<String, dynamic>.from(attrs['name'] as Map? ?? const {});
      if ((names['en']?.toString().toLowerCase() ?? '') == genreName.toLowerCase()) {
        return tag['id']?.toString();
      }
    }
    return null;
  }

  /// Cari judul di MangaDex untuk mencocokkan metadata AniList.
  Future<MediaItem?> searchByTitle(String title, {MediaKind kind = MediaKind.manga}) async {
    final cleanTitle = title
        .replaceAll(RegExp(r'\(.*?\)'), '')
        .replaceAll(RegExp(r'[^\w\s]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    if (cleanTitle.isEmpty) return null;
    try {
      final data = await CacheService.remember<Map<String, dynamic>>(
        'mangadex::titleSearch::$cleanTitle::${kind.slug}',
        () async {
          final raw = await _client.getJson(
            '${AppConfig.mangadexEndpoint}/manga',
            query: {
              'title': cleanTitle,
              'limit': 5,
              'includes[]': ['cover_art'],
              'contentRating[]': _contentRatings,
              if (kind.mangadexOriginalLanguage != null)
                'originalLanguage[]': kind.mangadexOriginalLanguage,
            },
          );
          return Map<String, dynamic>.from(raw as Map);
        },
        ttl: const Duration(days: 3),
      );
      final items = _parseCollection(data, kind);
      return items.isEmpty ? null : items.first;
    } catch (error) {
      debugPrint('[MangaDex] searchByTitle gagal: \$error');
      return null;
    }
  }

  /// Detail satu judul MangaDex.
  Future<MediaItem?> detail(MediaKind kind, String mangaId) async {
    final raw = await CacheService.remember<Map<String, dynamic>>(
      'mangadex::detail::$mangaId',
      () async {
        final response = await _client.getJson(
          '${AppConfig.mangadexEndpoint}/manga/$mangaId',
          query: {'includes[]': ['cover_art', 'author', 'artist']},
        );
        return Map<String, dynamic>.from(response as Map);
      },
      ttl: const Duration(hours: 6),
    );
    final data = raw['data'];
    if (data is! Map) return null;
    return _mapManga(Map<String, dynamic>.from(data), kind);
  }

  /// Daftar chapter (Indonesia diutamakan, fallback Inggris).
  Future<List<ChapterInfo>> chapters(String mangaId, {String? language}) async {
    final languages = language == null ? preferredLanguages : [language];
    for (final lang in languages) {
      final items = await _fetchFeed(mangaId, lang);
      if (items.isNotEmpty) return items;
    }
    return const [];
  }

  Future<List<ChapterInfo>> _fetchFeed(String mangaId, String lang) async {
    final data = await CacheService.remember<Map<String, dynamic>>(
      'mangadex::feed::$mangaId::$lang',
      () async {
        final raw = await _client.getJson(
          '${AppConfig.mangadexEndpoint}/manga/$mangaId/feed',
          query: {
            'limit': 500,
            'translatedLanguage[]': [lang],
            'order[chapter]': 'desc',
            'includeEmptyPages': 0,
            'includeExternalUrl': 0,
            'contentRating[]': _contentRatings,
          },
        );
        return Map<String, dynamic>.from(raw as Map);
      },
      ttl: const Duration(minutes: 20),
    );
    final list = (data['data'] as List?) ?? const [];
    final chapters = <ChapterInfo>[];
    for (final raw in list.whereType<Map>()) {
      final attributes =
          Map<String, dynamic>.from(raw['attributes'] as Map? ?? const {});
      final chapterNumber = double.tryParse('${attributes['chapter']}');
      if (chapterNumber == null) continue;
      final pages = (attributes['pages'] as num?)?.toInt() ?? 0;
      if (pages == 0) continue;
      final groups = (raw['relationships'] as List?) ?? const [];
      final groupNames = groups
          .whereType<Map>()
          .where((rel) => rel['type'] == 'scanlation_group')
          .map((rel) => (rel['attributes'] as Map?)?['name']?.toString())
          .whereType<String>()
          .toList();
      final group = groupNames.isEmpty ? null : groupNames.first;
      chapters.add(ChapterInfo(
        id: raw['id'].toString(),
        mediaId: mangaId,
        number: chapterNumber,
        title: (attributes['title'] as String?) ?? '',
        volume: attributes['volume']?.toString(),
        language: lang,
        pages: pages,
        publishedAt: DateTime.tryParse('${attributes['publishAt']}'),
        group: group,
        isAvailable: true,
      ));
    }
    chapters.sort((a, b) => a.number.compareTo(b.number));
    return chapters;
  }

  /// URL gambar halaman chapter (endpoint resmi `at-home`).
  Future<List<ReaderPage>> pages(String chapterId) async {
    final data = await CacheService.remember<Map<String, dynamic>>(
      'mangadex::pages::$chapterId',
      () async {
        final raw = await _client.getJson(
          '${AppConfig.mangadexEndpoint}/at-home/server/$chapterId',
        );
        return Map<String, dynamic>.from(raw as Map);
      },
      ttl: const Duration(hours: 6),
    );
    final baseUrl = data['baseUrl']?.toString();
    final chapter = data['chapter'] as Map? ?? const {};
    final hash = chapter['hash']?.toString();
    final files = (chapter['data'] as List?) ?? const [];
    if (baseUrl == null || hash == null) {
      throw ApiException('Halaman chapter tidak tersedia pada server MangaDex');
    }
    return List.generate(files.length, (index) {
      return ReaderPage(
        index: index,
        url: '$baseUrl/data/$hash/${files[index]}',
      );
    });
  }

  /// Sinkronisasi progres baca (opsional, butuh login MangaDex) — dipakai bila
  /// admin mengaktifkan integrasi akun MangaDex pada pengaturan API.
  Future<void> reportRead(String chapterId) async {
    try {
      await _client.postJson(
        '${AppConfig.mangadexEndpoint}/reading-history/$chapterId',
        const {},
      );
    } catch (error) {
      debugPrint('[MangaDex] reportRead skipped: $error');
    }
  }
}
