import 'package:flutter/foundation.dart';

import '../../core/services/local_store.dart';
import '../../core/services/supabase_gateway.dart';
import '../models/chapter.dart';
import '../models/episode.dart';
import '../models/media.dart';
import 'anilist_repository.dart';
import 'mangadex_repository.dart';
import 'wikisource_repository.dart';

/// Facade konten: memilih sumber data yang tepat untuk setiap kategori lalu
/// menormalkannya menjadi [MediaItem], [EpisodeInfo], [ChapterInfo].
///
/// | Kategori              | Metadata      | Chapter/Halaman | Streaming        |
/// |-----------------------|---------------|-----------------|------------------|
/// | Anime/Donghua/Movie   | AniList       | —               | `content_sources`|
/// | Manga/Manhwa/Manhua   | MangaDex*     | MangaDex        | —                |
/// | Novel                 | Wikisource    | Wikisource      | —                |
///
/// (*) AniList dipakai untuk pencarian global & metadata tambahan.
class ContentService {
  ContentService({
    required AniListRepository anilist,
    required MangaDexRepository mangadex,
    required WikisourceRepository wikisource,
    required SupabaseGateway gateway,
  })  : _anilist = anilist,
        _mangadex = mangadex,
        _wikisource = wikisource,
        _gateway = gateway;

  final AniListRepository _anilist;
  final MangaDexRepository _mangadex;
  final WikisourceRepository _wikisource;
  final SupabaseGateway _gateway;

  AniListRepository get anilist => _anilist;
  MangaDexRepository get mangadex => _mangadex;
  WikisourceRepository get wikisource => _wikisource;

  // ───────────────────────────── Browse ─────────────────────────────

  Future<PagedMedia> browse(MediaKind kind, [CatalogFilter filter = const CatalogFilter()]) {
    if (kind == MediaKind.novel) {
      return _wikisource.browse(filter: filter);
    }
    if (kind.isComic) {
      return _mangadex.browse(kind: kind, filter: filter);
    }
    return _anilist.browse(kind: kind, filter: filter);
  }

  Future<List<MediaItem>> trending(MediaKind kind, {int limit = 12}) {
    if (kind == MediaKind.novel) return _wikisource.trending(limit: limit);
    if (kind.isComic) {
      return _mangadex
          .browse(
            kind: kind,
            filter: const CatalogFilter(sort: CatalogSort.popular),
          )
          .then((page) => page.items.take(limit).toList());
    }
    return _anilist.trending(kind, limit: limit);
  }

  Future<List<MediaItem>> popularNow(MediaKind kind, {int limit = 12}) {
    if (kind == MediaKind.novel) return _wikisource.trending(limit: limit);
    if (kind.isComic) {
      return _mangadex
          .browse(kind: kind, filter: const CatalogFilter(sort: CatalogSort.popular))
          .then((page) => page.items.take(limit).toList());
    }
    return _anilist.popularNow(kind, limit: limit);
  }

  Future<List<MediaItem>> topRated(MediaKind kind, {int limit = 12}) {
    if (kind.isComic) {
      return _mangadex
          .browse(kind: kind, filter: const CatalogFilter(sort: CatalogSort.score))
          .then((page) => page.items.take(limit).toList());
    }
    if (kind == MediaKind.novel) return _wikisource.trending(limit: limit);
    return _anilist.topRated(kind, limit: limit);
  }

  Future<List<MediaItem>> recentlyUpdated(MediaKind kind, {int limit = 12}) {
    if (kind.isComic) {
      return _mangadex
          .browse(kind: kind, filter: const CatalogFilter(sort: CatalogSort.updated))
          .then((page) => page.items.take(limit).toList());
    }
    if (kind == MediaKind.novel) return _wikisource.trending(limit: limit);
    return _anilist.recentlyUpdated(kind, limit: limit);
  }

  Future<List<MediaItem>> upcoming(MediaKind kind, {int limit = 12}) {
    if (kind.isReadable) return Future.value(const []);
    return _anilist.upcoming(kind, limit: limit);
  }

  Future<List<MediaItem>> thisSeason(MediaKind kind, {int limit = 12}) {
    if (kind.isReadable) return Future.value(const []);
    return _anilist.thisSeason(kind, limit: limit);
  }

  Future<List<ScheduleSlot>> schedule({MediaKind kind = MediaKind.anime}) =>
      _anilist.schedule(kind: kind);

  // ───────────────────────────── Detail ─────────────────────────────

  Future<MediaItem?> detail(String mediaId, MediaKind kind) async {
    if (mediaId.startsWith('anilist:')) {
      final id = int.tryParse(mediaId.split(':').last);
      if (id == null) return null;
      return _anilist.detail(kind, id);
    }
    if (mediaId.startsWith('mangadex:')) {
      return _mangadex.detail(kind, mediaId.split(':').last);
    }
    if (mediaId.startsWith('wikisource:')) {
      return _wikisource.detail(mediaId.split(':').skip(1).join(':'));
    }
    debugPrint('[Content] ID tidak dikenal: $mediaId');
    return null;
  }

  Future<List<MediaItem>> recommendations(MediaItem media) async {
    if (media.id.startsWith('anilist:')) {
      final cached = AniListDetailCache.instance.read(media.id);
      final list = (cached?['recommendations'] as List?) ?? const [];
      if (list.isNotEmpty) {
        return list
            .whereType<Map>()
            .map((json) => MediaItem.fromJson(Map<String, dynamic>.from(json)))
            .toList();
      }
      if (media.genres.isNotEmpty) {
        final page = await _anilist.browse(
          kind: media.kind,
          filter: CatalogFilter(genre: media.genres.first),
        );
        return page.items.where((item) => item.id != media.id).take(12).toList();
      }
    }
    if (media.kind.isComic) {
      final page = await _mangadex.browse(kind: media.kind);
      return page.items.where((item) => item.id != media.id).take(12).toList();
    }
    return const [];
  }

  Future<List<Map<String, dynamic>>> relations(MediaItem media) async {
    final cached = AniListDetailCache.instance.read(media.id);
    final list = (cached?['relations'] as List?) ?? const [];
    return list.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> characters(MediaItem media) async {
    final cached = AniListDetailCache.instance.read(media.id);
    final list = (cached?['characters'] as List?) ?? const [];
    return list.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> externalLinks(MediaItem media) async {
    final cached = AniListDetailCache.instance.read(media.id);
    final list = (cached?['externalLinks'] as List?) ?? const [];
    return list.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  // ───────────────────────────── Episodes ─────────────────────────────

  /// Daftar episode beserta ketersediaan sumber legal.
  Future<List<EpisodeInfo>> episodes(MediaItem media) async {
    if (!media.kind.isVideo) return const [];
    final sources = await allSources(media.id);
    final episodesWithSource = sources.map((source) => source.episodeNumber).toSet();
    final total = media.kind == MediaKind.movie ? 1 : (media.episodes ?? 0);
    if (total <= 0) return const [];
    return List.generate(total, (index) {
      final number = index + 1;
      return EpisodeInfo(
        number: number,
        title: 'Episode $number',
        airDate: media.nextEpisodeAt,
        duration: (media.duration ?? 24) * 60,
        hasSource: episodesWithSource.contains(number),
      );
    });
  }

  // ───────────────────────── Chapters komik ─────────────────────────

  Future<List<ChapterInfo>> chapters(MediaItem media) async {
    if (media.kind.isComic) {
      if (media.source == ContentSource.mangadex) {
        return _mangadex.chapters(media.remoteId ?? media.id.split(':').last);
      }
      // Media dari AniList: coba cocokkan ke MangaDex berdasarkan judul.
      final match = await _mangadex.searchByTitle(media.title, kind: media.kind);
      if (match == null) return const [];
      return _mangadex.chapters(match.remoteId ?? '');
    }
    return const [];
  }

  Future<List<ReaderPage>> comicPages(String chapterId) => _mangadex.pages(chapterId);

  // ───────────────────────── Chapter novel ─────────────────────────

  Future<List<NovelChapter>> novelChapters(MediaItem media) async {
    if (media.source != ContentSource.wikisource) return const [];
    return _wikisource.chapters(media.remoteId ?? '');
  }

  Future<String> novelChapterText(NovelChapter chapter) =>
      _wikisource.chapterText(chapter.id);

  // ─────────────────────────── Streaming ───────────────────────────

  /// Sumber streaming yang terdaftar admin (harus resmi/berlisensi).
  /// Kosong = konten belum tersedia untuk streaming.
  Future<List<StreamSource>> sources(String contentId, int episodeNumber) async {
    final all = await allSources(contentId);
    return all.where((source) => source.episodeNumber == episodeNumber).toList();
  }

  Future<List<StreamSource>> allSources(String contentId) async {
    if (_gateway.enabled) {
      final rows = await _gateway.select(
        'content_sources',
        eq: {'content_id': contentId},
        orderBy: 'episode_number',
        ascending: true,
      );
      if (rows.isNotEmpty) {
        return rows.map(StreamSource.fromJson).toList();
      }
    }
    final local = LocalStore.getJsonList('admin::sources')
        .whereType<Map>()
        .map((entry) => StreamSource.fromJson(Map<String, dynamic>.from(entry)))
        .where((source) => source.contentId == contentId)
        .toList();
    // Source demo hanya dipakai untuk media uji player (lihat PlayerScreen).
    return local;
  }

  Future<bool> hasStreaming(String contentId) async {
    final sources = await allSources(contentId);
    return sources.isNotEmpty;
  }

  // ───────────────────────────── Search ─────────────────────────────

  Future<List<MediaItem>> searchGlobal(String query) async {
    if (query.trim().length < 2) return const [];
    final results = <MediaItem>[];
    try {
      results.addAll(await _anilist.searchAll(query));
    } catch (error) {
      debugPrint('[Search] AniList gagal: $error');
    }
    try {
      final comics = await _mangadex.browse(
        kind: MediaKind.manga,
        filter: CatalogFilter(query: query),
      );
      results.addAll(comics.items);
    } catch (error) {
      debugPrint('[Search] MangaDex gagal: $error');
    }
    return results;
  }

  /// Rekomendasi personal berdasarkan genre favorit pengguna.
  Future<List<MediaItem>> personalized({
    required List<String> preferredGenres,
    MediaKind kind = MediaKind.anime,
  }) async {
    final genre = preferredGenres.isEmpty ? null : preferredGenres.first;
    final page = await browse(kind, CatalogFilter(genre: genre));
    return page.items.take(12).toList();
  }
}
