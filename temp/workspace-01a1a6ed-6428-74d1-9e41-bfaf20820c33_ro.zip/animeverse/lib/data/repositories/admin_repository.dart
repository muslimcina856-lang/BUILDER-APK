import 'dart:math';

import 'package:flutter/foundation.dart';

import '../../core/services/local_store.dart';
import '../../core/services/supabase_gateway.dart';
import '../models/community.dart';
import '../models/episode.dart';
import '../models/library.dart';
import '../models/media.dart';
import '../models/membership.dart';
import '../models/user_profile.dart';

class AdminStats {
  const AdminStats({
    this.totalUsers = 0,
    this.activeUsers = 0,
    this.totalContent = 0,
    this.totalEpisodes = 0,
    this.totalChapters = 0,
    this.totalComments = 0,
    this.openReports = 0,
    this.paidTransactions = 0,
    this.revenueIdr = 0,
    this.newUsersThisWeek = 0,
    this.streamSources = 0,
  });

  final int totalUsers;
  final int activeUsers;
  final int totalContent;
  final int totalEpisodes;
  final int totalChapters;
  final int totalComments;
  final int openReports;
  final int paidTransactions;
  final int revenueIdr;
  final int newUsersThisWeek;
  final int streamSources;

  String get revenueLabel => MembershipPlan.formatIdr(revenueIdr);
}

class BannerItem {
  const BannerItem({
    required this.id,
    required this.title,
    required this.imageUrl,
    this.subtitle = '',
    this.targetId = '',
    this.isActive = true,
    this.order = 0,
  });

  final String id;
  final String title;
  final String subtitle;
  final String imageUrl;
  final String targetId;
  final bool isActive;
  final int order;

  BannerItem copyWith({bool? isActive, int? order, String? title, String? imageUrl}) =>
      BannerItem(
        id: id,
        title: title ?? this.title,
        subtitle: subtitle,
        imageUrl: imageUrl ?? this.imageUrl,
        targetId: targetId,
        isActive: isActive ?? this.isActive,
        order: order ?? this.order,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'subtitle': subtitle,
        'image_url': imageUrl,
        'target_id': targetId,
        'is_active': isActive,
        'sort_order': order,
      };

  factory BannerItem.fromJson(Map<String, dynamic> json) => BannerItem(
        id: json['id'].toString(),
        title: json['title'] as String? ?? '',
        subtitle: json['subtitle'] as String? ?? '',
        imageUrl: json['image_url'] as String? ?? '',
        targetId: json['target_id']?.toString() ?? '',
        isActive: json['is_active'] as bool? ?? true,
        order: (json['sort_order'] as num?)?.toInt() ?? 0,
      );
}

/// Panel admin: statistik, moderasi, konten, sumber streaming, banner,
/// notifikasi, membership, dan pengaturan aplikasi.
///
/// Cloud: semua operasi memakai tabel Supabase + RLS yang membatasi ke role
/// `admin`/`moderator` (lihat `supabase/schema.sql`).
/// Lokal: perubahan disimpan pada LocalStore sehingga panel tetap berfungsi
/// untuk demo & QA.
class AdminRepository {
  AdminRepository(this._gateway);

  final SupabaseGateway _gateway;

  static const String _bannersKey = 'admin::banners';
  static const String _sourcesKey = 'admin::sources';
  static const String _settingsKey = 'admin::settings';
  static const String _usersKey = 'admin::users';

  bool get isCloud => _gateway.enabled;

  // ───────────────────────────── Stats ─────────────────────────────

  Future<AdminStats> stats() async {
    final reports = LocalStore.getJsonList('community::reports');
    final comments = LocalStore.getJsonList('community::comments');
    final payments = LocalStore.getJsonList('membership::all');
    final sources = LocalStore.getJsonList(_sourcesKey);
    final users = _localUsers();
    final parsedPayments = payments
        .whereType<Map>()
        .map((entry) => PaymentRecord.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
    final paid = parsedPayments.where((payment) => payment.status == PaymentStatus.paid);

    if (isCloud) {
      final usersRows = await _gateway.select('profiles', limit: 1000);
      final contentRows = await _gateway.select('admin_content_index', limit: 2000);
      final commentsRows = await _gateway.select('comments', limit: 2000);
      final reportsRows = await _gateway.select('reports', eq: {'status': 'open'});
      final transactionRows = await _gateway.select('transactions', eq: {'status': 'paid'});
      final sourceRows = await _gateway.select('content_sources', limit: 2000);
      final revenue = transactionRows.fold<int>(
        0,
        (sum, row) => sum + ((row['amount_idr'] as num?)?.toInt() ?? 0),
      );
      return AdminStats(
        totalUsers: usersRows.length,
        activeUsers: usersRows.where((row) => row['is_banned'] != true).length,
        totalContent: contentRows.length,
        totalEpisodes: contentRows.fold<int>(
          0,
          (sum, row) => sum + ((row['episodes'] as num?)?.toInt() ?? 0),
        ),
        totalChapters: contentRows.fold<int>(
          0,
          (sum, row) => sum + ((row['chapters'] as num?)?.toInt() ?? 0),
        ),
        totalComments: commentsRows.length,
        openReports: reportsRows.length,
        paidTransactions: transactionRows.length,
        revenueIdr: revenue,
        streamSources: sourceRows.length,
      );
    }

    return AdminStats(
      totalUsers: users.length + 1240,
      activeUsers: users.length + 1186,
      totalContent: 486,
      totalEpisodes: 8420,
      totalChapters: 21540,
      totalComments: comments.length + max(0, comments.isEmpty ? 2 : 0),
      openReports: reports.whereType<Map>().where((row) => row['status'] == 'open').length,
      paidTransactions: paid.length,
      revenueIdr: paid.fold<int>(0, (sum, payment) => sum + payment.amountIdr),
      streamSources: sources.length,
    );
  }

  // ───────────────────────────── Users ─────────────────────────────

  List<UserProfile> _localUsers() {
    final raw = LocalStore.getJsonList('auth::users');
    return raw
        .whereType<Map>()
        .map((entry) {
          final profile = entry['profile'];
          if (profile is! Map) return null;
          return UserProfile.fromJson(Map<String, dynamic>.from(profile));
        })
        .whereType<UserProfile>()
        .toList();
  }

  Future<List<UserProfile>> users({String query = ''}) async {
    if (isCloud) {
      final rows = await _gateway.select('profiles', limit: 200);
      return rows.map((row) => UserProfile(
            id: row['id'].toString(),
            username: row['username'] as String? ?? 'pengguna',
            displayName: row['display_name'] as String? ?? '',
            email: row['email'] as String? ?? '',
            role: UserRole.fromValue(row['role'] as String?),
            tier: MembershipTier.fromValue(row['tier'] as String?),
            exp: (row['exp'] as num?)?.toInt() ?? 0,
            level: (row['level'] as num?)?.toInt() ?? 1,
            rankKey: row['rank_key'] as String? ?? 'beginner',
            isBanned: row['is_banned'] as bool? ?? false,
            avatarUrl: row['avatar_url'] as String?,
            joinedAt: DateTime.tryParse(row['created_at']?.toString() ?? ''),
          )).toList();
    }
    final list = _localUsers();
    if (query.trim().isEmpty) return list;
    final lowered = query.toLowerCase();
    return list
        .where((user) =>
            user.username.toLowerCase().contains(lowered) ||
            user.displayName.toLowerCase().contains(lowered) ||
            user.email.toLowerCase().contains(lowered))
        .toList();
  }

  Future<void> setUserRole(String userId, UserRole role) async {
    if (isCloud) {
      await _gateway.update('profiles', {'role': role.value}, eq: {'id': userId});
      return;
    }
    final raw = LocalStore.getJsonList('auth::users');
    final list = raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    for (final entry in list) {
      final profile = entry['profile'];
      if (profile is Map && profile['id'] == userId) {
        final updated = Map<String, dynamic>.from(profile)..['role'] = role.value;
        entry['profile'] = updated;
      }
    }
    await LocalStore.setJson('auth::users', list);
    final stored = LocalStore.getJson('profile::$userId');
    if (stored != null) {
      stored['role'] = role.value;
      await LocalStore.setJson('profile::$userId', stored);
    }
  }

  Future<void> setUserBanned(String userId, bool banned) async {
    if (isCloud) {
      await _gateway.update('profiles', {'is_banned': banned}, eq: {'id': userId});
      return;
    }
    final raw = LocalStore.getJsonList('auth::users');
    final list = raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    for (final entry in list) {
      final profile = entry['profile'];
      if (profile is Map && profile['id'] == userId) {
        entry['banned'] = banned;
      }
    }
    await LocalStore.setJson('auth::users', list);
  }

  Future<void> grantMembership(String userId, MembershipTier tier, int months) async {
    if (isCloud) {
      await _gateway.rpc('admin_grant_membership', params: {
        'p_user_id': userId,
        'p_tier': tier.value,
        'p_months': months,
      });
      return;
    }
    final expires = DateTime.now().add(Duration(days: 30 * months));
    final raw = LocalStore.getJsonList('auth::users');
    final list = raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    for (final entry in list) {
      final profile = entry['profile'];
      if (profile is Map && profile['id'] == userId) {
        final updated = Map<String, dynamic>.from(profile)
          ..['tier'] = tier.value
          ..['tierExpiresAt'] = expires.toIso8601String();
        entry['profile'] = updated;
      }
    }
    await LocalStore.setJson('auth::users', list);
    final stored = LocalStore.getJson('profile::$userId');
    if (stored != null) {
      stored['tier'] = tier.value;
      stored['tierExpiresAt'] = expires.toIso8601String();
      await LocalStore.setJson('profile::$userId', stored);
    }
  }

  // ─────────────────────── Konten & sumber ───────────────────────

  /// Tambah/perbarui sumber streaming resmi untuk sebuah konten.
  Future<String?> saveSource(StreamSource source) async {
    if (source.url.trim().isEmpty) {
      return 'URL sumber wajib diisi.';
    }
    if (!RegExp(r'^https?://').hasMatch(source.url)) {
      return 'URL harus diawali http:// atau https://';
    }
    if (!source.isOfficial) {
      return 'Hanya sumber resmi/berlisensi yang boleh didaftarkan.';
    }
    final sources = sourcesList()
      ..removeWhere((item) => item.id == source.id)
      ..add(source);
    await LocalStore.setJson(
      _sourcesKey,
      sources.map((item) => item.toJson()).toList(),
    );
    if (isCloud) {
      await _gateway.upsert('content_sources', {
        'id': source.id,
        'content_id': source.contentId,
        'episode_number': source.episodeNumber,
        'server': source.server,
        'url': source.url,
        'type': source.type,
        'qualities': source.qualities,
        'subtitles': source.subtitles.map((e) => e.toJson()).toList(),
        'audios': source.audios.map((e) => e.toJson()).toList(),
        'license_note': source.licenseNote,
        'is_official': source.isOfficial,
        'intro_start': source.introStart,
        'intro_end': source.introEnd,
        'outro_start': source.outroStart,
        'created_at': DateTime.now().toIso8601String(),
      });
    }
    return null;
  }

  List<StreamSource> sourcesList() => LocalStore.getJsonList(_sourcesKey)
      .whereType<Map>()
      .map((entry) => StreamSource.fromJson(Map<String, dynamic>.from(entry)))
      .toList();

  Future<void> deleteSource(String id) async {
    final sources = sourcesList()..removeWhere((item) => item.id == id);
    await LocalStore.setJson(
      _sourcesKey,
      sources.map((item) => item.toJson()).toList(),
    );
    if (isCloud) {
      await _gateway.delete('content_sources', eq: {'id': id});
    }
  }

  /// Konten kustom (di luar API publik) — mis. lisensi eksklusif.
  Future<List<MediaItem>> customContent() async {
    if (isCloud) {
      final rows = await _gateway.select('admin_content_index', limit: 200);
      return rows
          .map((row) => MediaItem(
                id: row['id'].toString(),
                kind: MediaKind.fromSlug(row['kind']?.toString() ?? 'anime'),
                title: row['title']?.toString() ?? 'Tanpa Judul',
                source: ContentSource.manual,
                coverUrl: row['cover_url'] as String?,
                episodes: (row['episodes'] as num?)?.toInt(),
                chapters: (row['chapters'] as num?)?.toInt(),
                status: row['status']?.toString(),
              ))
          .toList();
    }
    return LocalStore.getJsonList('admin::content')
        .whereType<Map>()
        .map((entry) => MediaItem.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
  }

  Future<void> saveCustomContent(MediaItem media) async {
    final list = LocalStore.getJsonList('admin::content')
        .whereType<Map>()
        .map((entry) => Map<String, dynamic>.from(entry))
        .toList()
      ..removeWhere((entry) => entry['id'] == media.id)
      ..add(media.toJson());
    await LocalStore.setJson('admin::content', list);
    if (isCloud) {
      await _gateway.upsert('admin_content_index', {
        'id': media.id,
        'kind': media.kind.slug,
        'title': media.title,
        'cover_url': media.coverUrl,
        'episodes': media.episodes,
        'chapters': media.chapters,
        'status': media.status,
        'metadata': media.toJson(),
      });
    }
  }

  Future<void> deleteCustomContent(String id) async {
    final list = LocalStore.getJsonList('admin::content')
        .whereType<Map>()
        .map((entry) => Map<String, dynamic>.from(entry))
        .where((entry) => entry['id'] != id)
        .toList();
    await LocalStore.setJson('admin::content', list);
    if (isCloud) {
      await _gateway.delete('admin_content_index', eq: {'id': id});
    }
  }

  // ───────────────────────────── Banner ─────────────────────────────

  List<BannerItem> banners() {
    final raw = LocalStore.getJsonList(_bannersKey);
    final list = raw
        .whereType<Map>()
        .map((entry) => BannerItem.fromJson(Map<String, dynamic>.from(entry)))
        .toList()
      ..sort((a, b) => a.order.compareTo(b.order));
    return list;
  }

  Future<List<BannerItem>> cloudBanners() async {
    if (isCloud) {
      final rows = await _gateway.select('banners', orderBy: 'sort_order', ascending: true);
      if (rows.isNotEmpty) return rows.map(BannerItem.fromJson).toList();
    }
    return banners();
  }

  Future<void> saveBanner(BannerItem banner) async {
    final list = banners()
      ..removeWhere((item) => item.id == banner.id)
      ..add(banner);
    await LocalStore.setJson(_bannersKey, list.map((item) => item.toJson()).toList());
    if (isCloud) {
      await _gateway.upsert('banners', banner.toJson());
    }
  }

  Future<void> deleteBanner(String id) async {
    final list = banners()..removeWhere((item) => item.id == id);
    await LocalStore.setJson(_bannersKey, list.map((item) => item.toJson()).toList());
    if (isCloud) {
      await _gateway.delete('banners', eq: {'id': id});
    }
  }

  // ─────────────────────── Notifikasi & laporan ───────────────────────

  Future<void> sendPushNotification({
    required String title,
    required String body,
    String audience = 'all',
  }) async {
    final notification = AppNotification(
      id: 'push${DateTime.now().microsecondsSinceEpoch}',
      title: title,
      body: body,
      createdAt: DateTime.now(),
      type: NotificationKind.system,
      payload: {'audience': audience},
    );
    final raw = LocalStore.getJsonList('community::notifications')
      ..add(notification.toJson());
    await LocalStore.setJson('community::notifications', raw);
    if (isCloud) {
      await _gateway.insert('notifications', {
        'id': notification.id,
        'title': title,
        'body': body,
        'type': 'system',
        'payload': {'audience': audience},
        'created_at': notification.createdAt.toIso8601String(),
      });
      // Push FCM ditangani Edge Function `send-push` (lihat docs/SETUP.md).
      await _gateway.rpc('queue_push', params: {'p_title': title, 'p_body': body});
    }
  }

  Future<List<CommentItem>> reportedComments() async {
    final reports = LocalStore.getJsonList('community::reports');
    return reports
        .whereType<Map>()
        .map((entry) => CommentItem(
              id: entry['targetId']?.toString() ?? '',
              content: 'Dilaporkan: ${entry['reason']}',
              author: const CommentAuthor(id: '', username: 'sistem'),
              createdAt: DateTime.tryParse(entry['createdAt']?.toString() ?? '') ??
                  DateTime.now(),
            ))
        .toList();
  }

  // ───────────────────────── App settings ─────────────────────────

  Map<String, dynamic> settings() =>
      LocalStore.getJson(_settingsKey) ??
      {
        'appName': 'ANIMEVERSE',
        'maintenanceMode': false,
        'adEnabled': false,
        'maxQuality': '1080p',
        'commentsEnabled': true,
        'registrationOpen': true,
        'anilistEndpoint': 'https://graphql.anilist.co',
        'mangadexEndpoint': 'https://api.mangadex.org',
        'copyrightNotice':
            'Streaming hanya tersedia untuk konten yang lisensinya dimiliki ANIMEVERSE.',
      };

  Future<void> saveSettings(Map<String, dynamic> value) async {
    await LocalStore.setJson(_settingsKey, value);
    if (isCloud) {
      await _gateway.upsert('app_settings', {
        'id': 'global',
        'value': value,
        'updated_at': DateTime.now().toIso8601String(),
      });
    }
  }

  // ───────────────────────── Moderasi akun ─────────────────────────

  Future<List<LibraryEntry>> flaggedBookmarks() async {
    // Placeholder untuk audit konten tersimpan; dipakai panel moderasi.
    debugPrint('[Admin] audit bookmark');
    return const [];
  }
}
