import 'dart:math';

import 'package:flutter/foundation.dart';

import '../../core/config/app_config.dart';
import '../../core/services/local_store.dart';
import '../../core/services/supabase_gateway.dart';
import '../models/gamification.dart';
import '../models/user_profile.dart';

class GamificationUpdate {
  const GamificationUpdate({
    required this.state,
    this.gainedExp = 0,
    this.leveledUp = false,
    this.rankedUp = false,
    this.message,
    this.previousLevel,
    this.previousRankKey,
  });

  final GamificationState state;
  final int gainedExp;
  final bool leveledUp;
  final bool rankedUp;
  final String? message;
  final int? previousLevel;
  final String? previousRankKey;
}

/// Sistem EXP, level, rank, title, badge, quest, achievement, daily login,
/// dan leaderboard.
///
/// Anti-farming: setiap jenis aktivitas punya batas EXP harian
/// ([AppConfig.dailyExpCapWatch] dll) yang dicatat per tanggal.
class GamificationRepository {
  GamificationRepository(this._gateway);

  final SupabaseGateway _gateway;
  String _userId = 'guest';

  void bindUser(String userId) => _userId = userId;

  String get _stateKey => 'gamification::$_userId';
  String get _activityKey => 'gamification::activity::$_userId';

  // ───────────────────────────── Load ─────────────────────────────

  Future<GamificationState> load() async {
    final raw = LocalStore.getJson(_stateKey);
    GamificationState state;
    if (raw == null) {
      state = GamificationState(
        exp: 0,
        level: 1,
        rankKey: 'beginner',
        titles: TitleItem.catalog,
        unlockedTitles: const ['newbie'],
        badges: const [],
        quests: [...QuestCatalog.freshDaily(), ...QuestCatalog.freshWeekly()],
        achievements: AchievementCatalog.templates
            .map((achievement) => Achievement(
                  id: achievement.id,
                  title: achievement.title,
                  description: achievement.description,
                  target: achievement.target,
                  progress: 0,
                  expReward: achievement.expReward,
                ))
            .toList(),
      );
    } else {
      state = GamificationState.fromJson(raw);
      state = _withCatalog(state);
    }
    if (_gateway.enabled) {
      final row = await _gateway.single('user_exp', eq: {'user_id': _userId});
      if (row != null) {
        final cloudExp = (row['total_exp'] as num?)?.toInt() ?? state.exp;
        state = state.copyWith(
          exp: max(state.exp, cloudExp),
          level: LevelMath.levelFromExp(max(state.exp, cloudExp)),
          badges: ((row['badge_ids'] as List?) ?? const [])
              .map((id) => BadgeItem.byId('$id'))
              .whereType<BadgeItem>()
              .toList(),
        );
        state = state.copyWith(rankKey: RankTier.fromExp(state.exp).key);
      }
    }
    await _persist(state);
    return state;
  }

  GamificationState _withCatalog(GamificationState state) {
    final today = _todayKey;
    final lastDay = LocalStore.getString('gamification::questDay::$_userId');
    final lastWeek = LocalStore.getString('gamification::questWeek::$_userId');
    final weekKey = _weekKey(DateTime.now());

    var quests = state.quests;
    if (quests.isEmpty || lastDay != today) {
      quests = [
        ...QuestCatalog.freshDaily(),
        ...quests.where((quest) => quest.period == QuestPeriod.weekly),
      ];
      LocalStore.setString('gamification::questDay::$_userId', today);
    }
    if (lastWeek != weekKey) {
      final weekly = QuestCatalog.freshWeekly();
      quests = [
        ...quests.where((quest) => quest.period == QuestPeriod.daily),
        ...weekly,
      ];
      LocalStore.setString('gamification::questWeek::$_userId', weekKey);
    }

    final achievements = state.achievements.isEmpty
        ? AchievementCatalog.templates
            .map((achievement) => Achievement(
                  id: achievement.id,
                  title: achievement.title,
                  description: achievement.description,
                  target: achievement.target,
                  progress: 0,
                  expReward: achievement.expReward,
                ))
            .toList()
        : state.achievements;

    return state.copyWith(
      quests: quests,
      achievements: achievements,
      badges: state.badges,
    );
  }

  Future<void> _persist(GamificationState state) =>
      LocalStore.setJson(_stateKey, state.toJson());

  // ───────────────────────────── EXP ─────────────────────────────

  /// Menambah EXP dengan batas harian. [category] menentukan cap:
  /// watch, read, comment, social.
  Future<GamificationUpdate> awardExp({
    required int amount,
    required String category,
    required String reason,
    int? questProgress,
    String? questId,
  }) async {
    final state = await load();
    final gained = _applyDailyCap(category, amount);
    if (gained <= 0 && questProgress == null) {
      return GamificationUpdate(
        state: state,
        message: 'Batas EXP harian untuk aktivitas ini sudah tercapai.',
      );
    }

    final previousLevel = state.level;
    final previousRank = state.rankKey;
    final newExp = state.exp + gained;
    final newLevel = LevelMath.levelFromExp(newExp);
    final newRank = RankTier.fromExp(newExp).key;

    var quests = state.quests;
    if (questId != null && questProgress != null) {
      quests = quests.map((quest) {
        if (quest.id != questId) return quest;
        return quest.copyWith(progress: quest.progress + questProgress);
      }).toList();
    }

    final unlockedTitles = _resolveTitles(state.unlockedTitles, newLevel, newRank);
    final badges = _resolveBadges(state.badges, newExp, newRank);

    final updated = state.copyWith(
      exp: newExp,
      level: newLevel,
      rankKey: newRank,
      quests: quests,
      unlockedTitles: unlockedTitles,
      badges: badges,
    );
    await _persist(updated);
    await _pushCloud(newExp, newRank, newLevel);

    return GamificationUpdate(
      state: updated,
      gainedExp: gained,
      leveledUp: newLevel > previousLevel,
      rankedUp: newRank != previousRank,
      previousLevel: previousLevel,
      previousRankKey: previousRank,
      message: reason,
    );
  }

  Future<void> _pushCloud(int exp, String rankKey, int level) async {
    if (!_gateway.enabled) return;
    await _gateway.rpc('award_exp', params: {
      'p_user_id': _userId,
      'p_amount': exp,
      'p_rank_key': rankKey,
      'p_level': level,
    });
  }

  List<String> _resolveTitles(List<String> current, int level, String rankKey) {
    final unlocked = {...current};
    for (final title in TitleItem.catalog) {
      if (!title.isPremium && level >= title.minLevel) {
        unlocked.add(title.id);
      }
    }
    if (RankTier.fromKey(rankKey).minExp >= RankTier.fromKey('legend').minExp) {
      unlocked.add('legenda');
    }
    return unlocked.toList();
  }

  List<BadgeItem> _resolveBadges(List<BadgeItem> current, int exp, String rankKey) {
    final ids = current.map((badge) => badge.id).toSet();
    if (RankTier.fromKey(rankKey).minExp >= RankTier.fromKey('legend').minExp) {
      ids.add('legend');
    }
    if (exp >= 5000) ids.add('marathon');
    if (exp >= 10000) ids.add('completionist');
    return ids.map(BadgeItem.byId).whereType<BadgeItem>().toList();
  }

  /// Batas EXP harian per kategori (anti-spam).
  int _applyDailyCap(String category, int amount) {
    final activity = LocalStore.getJson(_activityKey) ?? {};
    final today = _todayKey;
    final data = Map<String, dynamic>.from(activity);
    final dayKey = 'day_$today';
    if (data['date'] != today) {
      data
        ..clear()
        ..['date'] = today;
    }
    final used = (data[category] as num?)?.toInt() ?? 0;
    final cap = switch (category) {
      'watch' => AppConfig.dailyExpCapWatch,
      'read' => AppConfig.dailyExpCapRead,
      'comment' => AppConfig.dailyExpCapComment,
      _ => 500,
    };
    final remaining = max(0, cap - used);
    final granted = min(amount, remaining);
    data[category] = used + granted;
    data[dayKey] = true;
    LocalStore.setJson(_activityKey, data);
    return granted;
  }

  // ───────────────────────── Daily login ─────────────────────────

  Future<GamificationUpdate> claimDailyLogin() async {
    final state = await load();
    if (state.dailyClaimed) {
      return GamificationUpdate(
        state: state,
        message: 'Reward login hari ini sudah diklaim. Kembali besok!',
      );
    }
    final streak = state.loginStreak + 1;
    final reward = ExpRules.forDailyLogin(streak);
    final previousLevel = state.level;
    final newExp = state.exp + reward;
    final newLevel = LevelMath.levelFromExp(newExp);
    final newRank = RankTier.fromExp(newExp).key;
    final updated = state.copyWith(
      exp: newExp,
      level: newLevel,
      rankKey: newRank,
      dailyClaimed: true,
      loginStreak: streak,
    );
    await _persist(updated);
    LocalStore.setString('gamification::lastLogin::$_userId', _todayKey);
    await _pushCloud(newExp, newRank, newLevel);
    return GamificationUpdate(
      state: updated,
      gainedExp: reward,
      leveledUp: newLevel > previousLevel,
      rankedUp: newRank != state.rankKey,
      previousLevel: previousLevel,
      message: 'Daily login streak $streak hari • +$reward EXP',
    );
  }

  bool get canClaimDaily {
    final last = LocalStore.getString('gamification::lastLogin::$_userId');
    return last != _todayKey;
  }

  // ─────────────────────────── Quests ───────────────────────────

  Future<GamificationUpdate> claimQuest(String questId) async {
    final state = await load();
    final index = state.quests.indexWhere((quest) => quest.id == questId);
    if (index < 0) {
      return GamificationUpdate(state: state, message: 'Quest tidak ditemukan.');
    }
    final quest = state.quests[index];
    if (!quest.isComplete) {
      return GamificationUpdate(
        state: state,
        message: 'Quest belum selesai (${quest.progress}/${quest.target}).',
      );
    }
    if (quest.claimed) {
      return GamificationUpdate(state: state, message: 'Reward sudah diklaim.');
    }
    final quests = [...state.quests];
    quests[index] = quest.copyWith(claimed: true);
    final newExp = state.exp + quest.expReward;
    final newLevel = LevelMath.levelFromExp(newExp);
    final updated = state.copyWith(
      exp: newExp,
      level: newLevel,
      rankKey: RankTier.fromExp(newExp).key,
      quests: quests,
    );
    await _persist(updated);
    await _pushCloud(newExp, updated.rankKey, newLevel);
    return GamificationUpdate(
      state: updated,
      gainedExp: quest.expReward,
      leveledUp: newLevel > state.level,
      rankedUp: updated.rankKey != state.rankKey,
      previousLevel: state.level,
      message: 'Reward "${quest.title}" diklaim • +${quest.expReward} EXP',
    );
  }

  Future<GamificationUpdate> claimAchievement(String achievementId) async {
    final state = await load();
    final index = state.achievements.indexWhere((item) => item.id == achievementId);
    if (index < 0) {
      return GamificationUpdate(state: state, message: 'Achievement tidak ditemukan.');
    }
    final achievement = state.achievements[index];
    if (!achievement.isUnlocked || achievement.unlockedAt != null) {
      return GamificationUpdate(
        state: state,
        message: 'Achievement belum terbuka atau sudah diklaim.',
      );
    }
    final achievements = [...state.achievements];
    achievements[index] = Achievement(
      id: achievement.id,
      title: achievement.title,
      description: achievement.description,
      target: achievement.target,
      progress: achievement.progress,
      expReward: achievement.expReward,
      unlockedAt: DateTime.now(),
    );
    final newExp = state.exp + achievement.expReward;
    final updated = state.copyWith(
      exp: newExp,
      level: LevelMath.levelFromExp(newExp),
      rankKey: RankTier.fromExp(newExp).key,
      achievements: achievements,
    );
    await _persist(updated);
    return GamificationUpdate(
      state: updated,
      gainedExp: achievement.expReward,
      message: 'Achievement "${achievement.title}" • +${achievement.expReward} EXP',
    );
  }

  /// Sinkronkan progres achievement dari statistik pengguna.
  Future<GamificationState> syncAchievements(UserStats stats) async {
    final state = await load();
    int progressFor(String id) {
      switch (id) {
        case 'first_episode':
          return stats.episodesWatched;
        case 'episodes_50':
          return stats.episodesWatched;
        case 'episodes_200':
          return stats.episodesWatched;
        case 'chapters_100':
          return stats.chaptersRead;
        case 'novel_5':
          return stats.novelsRead;
        case 'comments_50':
          return stats.comments;
        case 'login_30':
          return state.loginStreak;
        case 'bookmark_30':
          return stats.bookmarks;
        default:
          return 0;
      }
    }

    final achievements = state.achievements
        .map((achievement) => Achievement(
              id: achievement.id,
              title: achievement.title,
              description: achievement.description,
              target: achievement.target,
              progress: max(achievement.progress, progressFor(achievement.id)),
              expReward: achievement.expReward,
              unlockedAt: achievement.unlockedAt,
            ))
        .toList();
    final updated = state.copyWith(achievements: achievements);
    await _persist(updated);
    return updated;
  }

  Future<GamificationState> selectTitle(String? titleId) async {
    final state = await load();
    final updated = state;
    await _persist(updated);
    return updated;
  }

  // ─────────────────────────── Leaderboard ───────────────────────────

  /// Leaderboard mingguan/bulanan.
  /// Cloud: view `leaderboard_weekly` / `leaderboard_monthly`.
  /// Lokal: data contoh yang diberi label "demo" pada UI.
  Future<List<LeaderboardEntry>> leaderboard({
    required String period,
    String currentUserId = '',
    int currentExp = 0,
  }) async {
    if (_gateway.enabled) {
      final table = period == 'monthly' ? 'leaderboard_monthly' : 'leaderboard_weekly';
      final rows = await _gateway.select(table, limit: 50);
      if (rows.isNotEmpty) {
        return [
          for (var i = 0; i < rows.length; i++)
            LeaderboardEntry(
              position: i + 1,
              userId: rows[i]['user_id']?.toString() ?? '',
              username: rows[i]['username']?.toString() ?? 'pengguna',
              displayName: rows[i]['display_name']?.toString() ?? '',
              exp: (rows[i]['total_exp'] as num?)?.toInt() ?? 0,
              level: (rows[i]['level'] as num?)?.toInt() ?? 1,
              rankKey: rows[i]['rank_key']?.toString() ?? 'beginner',
              avatarUrl: rows[i]['avatar_url'] as String?,
              tier: rows[i]['tier']?.toString() ?? 'free',
              isMe: rows[i]['user_id']?.toString() == currentUserId,
            ),
        ];
      }
    }

    const seedNames = [
      ('aiko.exe', 'Aiko', 48200, 'supreme'),
      ('shadowblade', 'ShadowBlade', 39400, 'mythic'),
      ('nagi_kun', 'Nagi', 31200, 'mythic'),
      ('mei_reads', 'Mei', 24800, 'legend'),
      ('ryuuji', 'Ryuuji', 19600, 'grandmaster'),
      ('hana_v', 'Hana', 15400, 'grandmaster'),
      ('zerotwo', 'Zero Two', 12800, 'master'),
      ('kenshin', 'Kenshin', 9800, 'expert'),
      ('luffy_id', 'Luffy', 7200, 'expert'),
      ('sora_av', 'Sora', 5400, 'advanced'),
    ];
    final list = <LeaderboardEntry>[
      for (var i = 0; i < seedNames.length; i++)
        LeaderboardEntry(
          position: i + 1,
          userId: 'seed-${seedNames[i].$1}',
          username: seedNames[i].$1,
          displayName: seedNames[i].$2,
          exp: seedNames[i].$3,
          level: LevelMath.levelFromExp(seedNames[i].$3),
          rankKey: seedNames[i].$4,
          tier: i < 3 ? 'ultimate' : (i < 6 ? 'premium' : 'vip'),
        ),
    ];
    if (currentUserId.isNotEmpty) {
      list.add(LeaderboardEntry(
        position: 0,
        userId: currentUserId,
        username: 'kamu',
        displayName: 'Kamu',
        exp: currentExp,
        level: LevelMath.levelFromExp(currentExp),
        rankKey: RankTier.fromExp(currentExp).key,
        isMe: true,
      ));
    }
    list.sort((a, b) => b.exp.compareTo(a.exp));
    return [
      for (var i = 0; i < list.length; i++)
        LeaderboardEntry(
          position: i + 1,
          userId: list[i].userId,
          username: list[i].username,
          displayName: list[i].displayName,
          exp: list[i].exp,
          level: list[i].level,
          rankKey: list[i].rankKey,
          avatarUrl: list[i].avatarUrl,
          tier: list[i].tier,
          isMe: list[i].isMe,
        ),
    ];
  }

  // ──────────────────────────── Helpers ────────────────────────────

  String get _todayKey {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  String _weekKey(DateTime date) {
    final thursday = date.add(Duration(days: 3 - (date.weekday + 6) % 7));
    final firstThursday = DateTime(thursday.year, 1, 4);
    final week = 1 +
        ((thursday.difference(firstThursday).inDays) / 7).floor();
    return '${thursday.year}-W$week';
  }

  @visibleForTesting
  Future<void> resetForTesting() async {
    await LocalStore.remove(_stateKey);
    await LocalStore.remove(_activityKey);
  }
}
