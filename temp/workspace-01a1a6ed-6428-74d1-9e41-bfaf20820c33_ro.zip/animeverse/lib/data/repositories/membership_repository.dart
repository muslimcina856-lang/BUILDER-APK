import 'package:flutter/foundation.dart';

import '../../core/services/local_store.dart';
import '../../core/services/supabase_gateway.dart';
import '../models/membership.dart';
import '../models/user_profile.dart';

class PurchaseResult {
  const PurchaseResult({
    required this.success,
    required this.message,
    this.status,
    this.payment,
  });

  final bool success;
  final String message;
  final MembershipStatus? status;
  final PaymentRecord? payment;
}

/// Langganan premium.
///
/// Pembayaran **tidak** disimulasikan sebagai sukses palsu:
/// - Cloud: memanggil Edge Function `create-payment` (integrasi Midtrans/Xendit)
///   yang mengembalikan invoice/QRIS asli, lalu status diperbarui oleh webhook.
/// - Lokal: transaksi dicatat `pending` dan menunggu verifikasi manual admin
///   pada panel admin → Manajemen Transaksi.
class MembershipRepository {
  MembershipRepository(this._gateway);

  final SupabaseGateway _gateway;
  String _userId = 'guest';
  UserProfile? _profile;

  void bindUser(UserProfile? profile) {
    _profile = profile;
    _userId = profile?.id ?? 'guest';
  }

  String get _statusKey => 'membership::status::$_userId';
  String get _paymentsKey => 'membership::payments::$_userId';

  Future<MembershipStatus> status() async {
    final raw = LocalStore.getJson(_statusKey);
    var local = raw == null
        ? MembershipStatus(tier: _profile?.tier ?? MembershipTier.free, expiresAt: _profile?.tierExpiresAt)
        : MembershipStatus.fromJson(raw);
    if (_gateway.enabled && _userId != 'guest') {
      final row = await _gateway.single('memberships', eq: {'user_id': _userId});
      if (row != null) {
        local = MembershipStatus(
          tier: MembershipTier.fromValue(row['tier'] as String?),
          expiresAt: DateTime.tryParse(row['expires_at']?.toString() ?? ''),
          autoRenew: row['auto_renew'] as bool? ?? false,
          startedAt: DateTime.tryParse(row['started_at']?.toString() ?? ''),
        );
        await LocalStore.setJson(_statusKey, local.toJson());
      }
    }
    return local;
  }

  Future<List<PaymentRecord>> payments() async {
    final local = LocalStore.getJsonList(_paymentsKey)
        .whereType<Map>()
        .map((entry) => PaymentRecord.fromJson(Map<String, dynamic>.from(entry)))
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    if (_gateway.enabled && _userId != 'guest') {
      final rows = await _gateway.select(
        'transactions',
        eq: {'user_id': _userId},
        orderBy: 'created_at',
      );
      if (rows.isNotEmpty) {
        return rows.map(_mapTransaction).toList();
      }
    }
    return local;
  }

  PaymentRecord _mapTransaction(Map<String, dynamic> row) => PaymentRecord(
        id: row['id'].toString(),
        tier: MembershipTier.fromValue(row['tier'] as String?),
        months: (row['months'] as num?)?.toInt() ?? 1,
        amountIdr: (row['amount_idr'] as num?)?.toInt() ?? 0,
        method: row['method'] as String? ?? 'QRIS',
        status: PaymentStatus.values.firstWhere(
          (value) => value.name == row['status'],
          orElse: () => PaymentStatus.pending,
        ),
        createdAt: DateTime.tryParse(row['created_at']?.toString() ?? '') ?? DateTime.now(),
        invoiceUrl: row['invoice_url'] as String?,
      );

  /// Membuat pesanan langganan.
  Future<PurchaseResult> purchase({
    required MembershipPlan plan,
    required String method,
  }) async {
    if (_userId == 'guest') {
      return const PurchaseResult(
        success: false,
        message: 'Masuk terlebih dahulu untuk berlangganan.',
      );
    }

    if (_gateway.enabled) {
      final response = await _gateway.rpc('create_payment', params: {
        'p_tier': plan.tier.value,
        'p_months': plan.months,
        'p_amount': plan.priceIdr,
        'p_method': method,
      });
      if (response is Map && response['invoice_url'] != null) {
        return PurchaseResult(
          success: true,
          message: 'Pembayaran dibuat. Selesaikan melalui halaman invoice.',
          payment: PaymentRecord(
            id: response['id']?.toString() ?? '',
            tier: plan.tier,
            months: plan.months,
            amountIdr: plan.priceIdr,
            method: method,
            status: PaymentStatus.pending,
            createdAt: DateTime.now(),
            invoiceUrl: response['invoice_url']?.toString(),
          ),
        );
      }
      if (response == null) {
        return const PurchaseResult(
          success: false,
          message:
              'Gateway pembayaran belum aktif. Hubungi admin atau gunakan '
              'transfer manual melalui menu Bantuan.',
        );
      }
    }

    final payment = PaymentRecord(
      id: 'TRX${DateTime.now().millisecondsSinceEpoch}',
      tier: plan.tier,
      months: plan.months,
      amountIdr: plan.priceIdr,
      method: method,
      status: PaymentStatus.pending,
      createdAt: DateTime.now(),
    );
    final list = payments().toList()..insert(0, payment);
    await LocalStore.setJson(
      _paymentsKey,
      list.map((item) => item.toJson()).toList(),
    );
    if (_gateway.enabled) {
      await _gateway.insert('transactions', {
        'id': payment.id,
        'user_id': _userId,
        'tier': plan.tier.value,
        'months': plan.months,
        'amount_idr': plan.priceIdr,
        'method': method,
        'status': 'pending',
        'created_at': payment.createdAt.toIso8601String(),
      });
    }
    return PurchaseResult(
      success: true,
      message:
          'Pesanan ${plan.tier.label} ${plan.label} dibuat (${payment.id}). '
          'Selesaikan pembayaran $method, admin akan memverifikasi.',
      payment: payment,
    );
  }

  /// Aktivasi langganan — dipanggil setelah pembayaran terverifikasi
  /// (webhook gateway atau approve manual admin).
  Future<MembershipStatus> activate({
    required MembershipTier tier,
    required int months,
    String? referenceId,
  }) async {
    final current = await status();
    final base = current.isActive && current.expiresAt != null
        ? current.expiresAt!
        : DateTime.now();
    final expiresAt = DateTime(
      base.year,
      base.month + months,
      base.day,
      base.hour,
      base.minute,
    );
    final updated = MembershipStatus(
      tier: tier,
      expiresAt: expiresAt,
      autoRenew: current.autoRenew,
      startedAt: DateTime.now(),
    );
    await LocalStore.setJson(_statusKey, updated.toJson());

    if (referenceId != null) {
      final list = payments();
      final index = list.indexWhere((payment) => payment.id == referenceId);
      if (index >= 0) {
        list[index] = PaymentRecord(
          id: list[index].id,
          tier: list[index].tier,
          months: list[index].months,
          amountIdr: list[index].amountIdr,
          method: list[index].method,
          status: PaymentStatus.paid,
          createdAt: list[index].createdAt,
          invoiceUrl: list[index].invoiceUrl,
        );
        await LocalStore.setJson(
          _paymentsKey,
          list.map((item) => item.toJson()).toList(),
        );
      }
    }

    if (_gateway.enabled && _userId != 'guest') {
      await _gateway.upsert('memberships', {
        'user_id': _userId,
        'tier': tier.value,
        'expires_at': expiresAt.toIso8601String(),
        'auto_renew': current.autoRenew,
        'started_at': DateTime.now().toIso8601String(),
      }, onConflict: 'user_id');
      await _gateway.update('profiles', {
        'tier': tier.value,
        'tier_expires_at': expiresAt.toIso8601String(),
      }, eq: {'id': _userId});
    }
    return updated;
  }

  Future<void> setAutoRenew(bool value) async {
    final current = await status();
    final updated = MembershipStatus(
      tier: current.tier,
      expiresAt: current.expiresAt,
      autoRenew: value,
      startedAt: current.startedAt,
    );
    await LocalStore.setJson(_statusKey, updated.toJson());
    if (_gateway.enabled) {
      await _gateway.update('memberships', {'auto_renew': value}, eq: {'user_id': _userId});
    }
  }

  /// Admin: daftar semua transaksi (cloud) / lokal.
  Future<List<PaymentRecord>> allTransactions() async {
    if (_gateway.enabled) {
      final rows = await _gateway.select('transactions', orderBy: 'created_at');
      if (rows.isNotEmpty) return rows.map(_mapTransaction).toList();
    }
    final raw = LocalStore.getJsonList('membership::all');
    final list = raw
        .whereType<Map>()
        .map((entry) => PaymentRecord.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
    if (list.isNotEmpty) return list;
    return payments();
  }

  /// Admin: menyetujui pembayaran manual (mode lokal).
  Future<void> approveFromAdmin(PaymentRecord payment, String userId) async {
    if (!_gateway.enabled) {
      final raw = LocalStore.getJsonList('membership::all');
      final list = raw
          .whereType<Map>()
          .map((entry) => PaymentRecord.fromJson(Map<String, dynamic>.from(entry)))
          .toList();
      final index = list.indexWhere((item) => item.id == payment.id);
      final paid = PaymentRecord(
        id: payment.id,
        tier: payment.tier,
        months: payment.months,
        amountIdr: payment.amountIdr,
        method: payment.method,
        status: PaymentStatus.paid,
        createdAt: payment.createdAt,
        invoiceUrl: payment.invoiceUrl,
      );
      if (index >= 0) {
        list[index] = paid;
      } else {
        list.insert(0, paid);
      }
      await LocalStore.setJson(
        'membership::all',
        list.map((item) => item.toJson()).toList(),
      );
      // Aktifkan untuk user terkait (mode lokal memakai 1 perangkat).
      final statusKey = 'membership::status::$userId';
      final expiresAt = DateTime.now().add(Duration(days: 30 * payment.months));
      await LocalStore.setJson(statusKey, MembershipStatus(
        tier: payment.tier,
        expiresAt: expiresAt,
        startedAt: DateTime.now(),
      ).toJson());
      await LocalStore.setJson('membership::payments::$userId', [
        paid.toJson(),
      ]);
      return;
    }
    await _gateway.update('transactions', {'status': 'paid'}, eq: {'id': payment.id});
    await _gateway.rpc('approve_transaction', params: {'p_transaction_id': payment.id});
  }

  Future<void> rejectFromAdmin(PaymentRecord payment) async {
    if (!_gateway.enabled) {
      final raw = LocalStore.getJsonList('membership::all');
      final list = raw
          .whereType<Map>()
          .map((entry) => PaymentRecord.fromJson(Map<String, dynamic>.from(entry)))
          .toList();
      final index = list.indexWhere((item) => item.id == payment.id);
      if (index >= 0) {
        list[index] = PaymentRecord(
          id: payment.id,
          tier: payment.tier,
          months: payment.months,
          amountIdr: payment.amountIdr,
          method: payment.method,
          status: PaymentStatus.failed,
          createdAt: payment.createdAt,
        );
        await LocalStore.setJson(
          'membership::all',
          list.map((item) => item.toJson()).toList(),
        );
      }
      return;
    }
    await _gateway.update('transactions', {'status': 'failed'}, eq: {'id': payment.id});
  }

  Future<void> recordLocalTransaction(PaymentRecord payment) async {
    final raw = LocalStore.getJsonList('membership::all');
    final list = raw
        .whereType<Map>()
        .map((entry) => PaymentRecord.fromJson(Map<String, dynamic>.from(entry)))
        .toList();
    list.insert(0, payment);
    await LocalStore.setJson('membership::all', list.map((item) => item.toJson()).toList());
    debugPrint('[Membership] transaksi dicatat: ${payment.id}');
  }
}
