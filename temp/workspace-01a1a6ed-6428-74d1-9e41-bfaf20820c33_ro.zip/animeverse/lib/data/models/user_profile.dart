import 'package:flutter/material.dart';

enum UserRole {
  user('user', 'Pengguna'),
  moderator('moderator', 'Moderator'),
  admin('admin', 'Admin');

  const UserRole(this.value, this.label);
  final String value;
  final String label;

  bool get canModerate => this == UserRole.admin || this == UserRole.moderator;
  bool get isAdmin => this == UserRole.admin;

  static UserRole fromValue(String? value) => UserRole.values.firstWhere(
        (role) => role.value == value,
        orElse: () => UserRole.user,
      );
}

enum MembershipTier {
  free('free', 'Free', 0, Color(0xFF8E86B8)),
  vip('vip', 'VIP', 1, Color(0xFF60A5FA)),
  premium('premium', 'Premium', 2, Color(0xFFFFC857)),
  ultimate('ultimate', 'Ultimate', 3, Color(0xFFB388FF));

  const MembershipTier(this.value, this.label, this.rank, this.color);
  final String value;
  final String label;
  final int rank;
  final Color color;

  bool get isPaid => this != MembershipTier.free;
  bool get isAtLeastVip => rank >= 1;

  static MembershipTier fromValue(String? value) =>
      MembershipTier.values.firstWhere(
        (tier) => tier.value == value,
        orElse: () => MembershipTier.free,
      );
}

class AuthUser {
  const AuthUser({
    required this.id,
    required this.email,
    this.emailVerified = false,
    this.provider = 'email',
    this.createdAt,
  });

  final String id;
  final String email;
  final bool emailVerified;
  final String provider;
  final DateTime? createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'email': email,
        'emailVerified': emailVerified,
        'provider': provider,
        'createdAt': createdAt?.toIso8601String(),
      };

  factory AuthUser.fromJson(Map<String, dynamic> json) => AuthUser(
        id: json['id'] as String,
        email: json['email'] as String? ?? '',
        emailVerified: json['emailVerified'] as bool? ?? false,
        provider: json['provider'] as String? ?? 'email',
        createdAt: json['createdAt'] == null
            ? null
            : DateTime.tryParse(json['createdAt'] as String),
      );
}

class UserStats {
  const UserStats({
    this.episodesWatched = 0,
    this.watchMinutes = 0,
    this.chaptersRead = 0,
    this.novelsRead = 0,
    this.comments = 0,
    this.followers = 0,
    this.following = 0,
    this.bookmarks = 0,
    this.downloads = 0,
  });

  final int episodesWatched;
  final int watchMinutes;
  final int chaptersRead;
  final int novelsRead;
  final int comments;
  final int followers;
  final int following;
  final int bookmarks;
  final int downloads;

  Map<String, dynamic> toJson() => {
        'episodesWatched': episodesWatched,
        'watchMinutes': watchMinutes,
        'chaptersRead': chaptersRead,
        'novelsRead': novelsRead,
        'comments': comments,
        'followers': followers,
        'following': following,
        'bookmarks': bookmarks,
        'downloads': downloads,
      };

  factory UserStats.fromJson(Map<String, dynamic> json) => UserStats(
        episodesWatched: (json['episodesWatched'] as num?)?.toInt() ?? 0,
        watchMinutes: (json['watchMinutes'] as num?)?.toInt() ?? 0,
        chaptersRead: (json['chaptersRead'] as num?)?.toInt() ?? 0,
        novelsRead: (json['novelsRead'] as num?)?.toInt() ?? 0,
        comments: (json['comments'] as num?)?.toInt() ?? 0,
        followers: (json['followers'] as num?)?.toInt() ?? 0,
        following: (json['following'] as num?)?.toInt() ?? 0,
        bookmarks: (json['bookmarks'] as num?)?.toInt() ?? 0,
        downloads: (json['downloads'] as num?)?.toInt() ?? 0,
      );
}

class UserProfile {
  const UserProfile({
    required this.id,
    required this.username,
    required this.displayName,
    this.email = '',
    this.bio = '',
    this.avatarUrl,
    this.coverUrl,
    this.joinedAt,
    this.role = UserRole.user,
    this.tier = MembershipTier.free,
    this.tierExpiresAt,
    this.exp = 0,
    this.level = 1,
    this.rankKey = 'beginner',
    this.selectedTitle,
    this.badgeIds = const [],
    this.isPrivate = false,
    this.isBanned = false,
    this.stats = const UserStats(),
    this.favoriteAnime = const [],
    this.favoriteComics = const [],
    this.favoriteNovels = const [],
  });

  final String id;
  final String username;
  final String displayName;
  final String email;
  final String bio;
  final String? avatarUrl;
  final String? coverUrl;
  final DateTime? joinedAt;
  final UserRole role;
  final MembershipTier tier;
  final DateTime? tierExpiresAt;
  final int exp;
  final int level;
  final String rankKey;
  final String? selectedTitle;
  final List<String> badgeIds;
  final bool isPrivate;
  final bool isBanned;
  final UserStats stats;
  final List<String> favoriteAnime;
  final List<String> favoriteComics;
  final List<String> favoriteNovels;

  String get shortId =>
      id.length <= 8 ? id.toUpperCase() : 'AV-${id.substring(0, 8).toUpperCase()}';

  String get initials {
    final source = displayName.trim().isEmpty ? username : displayName.trim();
    if (source.isEmpty) return 'AV';
    final parts = source.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return 'AV';
    if (parts.length == 1) {
      final value = parts.first;
      return (value.length >= 2 ? value.substring(0, 2) : value).toUpperCase();
    }
    return (parts[0].substring(0, 1) + parts[1].substring(0, 1)).toUpperCase();
  }

  bool get isVipActive {
    if (!tier.isPaid) return false;
    if (tierExpiresAt == null) return true;
    return tierExpiresAt!.isAfter(DateTime.now());
  }

  UserProfile copyWith({
    String? username,
    String? displayName,
    String? bio,
    String? avatarUrl,
    String? coverUrl,
    UserRole? role,
    MembershipTier? tier,
    DateTime? tierExpiresAt,
    int? exp,
    int? level,
    String? rankKey,
    String? selectedTitle,
    List<String>? badgeIds,
    bool? isPrivate,
    bool? isBanned,
    UserStats? stats,
    List<String>? favoriteAnime,
    List<String>? favoriteComics,
    List<String>? favoriteNovels,
  }) =>
      UserProfile(
        id: id,
        username: username ?? this.username,
        displayName: displayName ?? this.displayName,
        email: email,
        bio: bio ?? this.bio,
        avatarUrl: avatarUrl ?? this.avatarUrl,
        coverUrl: coverUrl ?? this.coverUrl,
        joinedAt: joinedAt,
        role: role ?? this.role,
        tier: tier ?? this.tier,
        tierExpiresAt: tierExpiresAt ?? this.tierExpiresAt,
        exp: exp ?? this.exp,
        level: level ?? this.level,
        rankKey: rankKey ?? this.rankKey,
        selectedTitle: selectedTitle ?? this.selectedTitle,
        badgeIds: badgeIds ?? this.badgeIds,
        isPrivate: isPrivate ?? this.isPrivate,
        isBanned: isBanned ?? this.isBanned,
        stats: stats ?? this.stats,
        favoriteAnime: favoriteAnime ?? this.favoriteAnime,
        favoriteComics: favoriteComics ?? this.favoriteComics,
        favoriteNovels: favoriteNovels ?? this.favoriteNovels,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'displayName': displayName,
        'email': email,
        'bio': bio,
        'avatarUrl': avatarUrl,
        'coverUrl': coverUrl,
        'joinedAt': joinedAt?.toIso8601String(),
        'role': role.value,
        'tier': tier.value,
        'tierExpiresAt': tierExpiresAt?.toIso8601String(),
        'exp': exp,
        'level': level,
        'rankKey': rankKey,
        'selectedTitle': selectedTitle,
        'badgeIds': badgeIds,
        'isPrivate': isPrivate,
        'isBanned': isBanned,
        'stats': stats.toJson(),
        'favoriteAnime': favoriteAnime,
        'favoriteComics': favoriteComics,
        'favoriteNovels': favoriteNovels,
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        id: json['id'] as String,
        username: json['username'] as String? ?? 'pengguna',
        displayName: json['displayName'] as String? ?? json['username'] as String? ?? 'Pengguna',
        email: json['email'] as String? ?? '',
        bio: json['bio'] as String? ?? '',
        avatarUrl: json['avatarUrl'] as String?,
        coverUrl: json['coverUrl'] as String?,
        joinedAt: json['joinedAt'] == null
            ? null
            : DateTime.tryParse(json['joinedAt'] as String),
        role: UserRole.fromValue(json['role'] as String?),
        tier: MembershipTier.fromValue(json['tier'] as String?),
        tierExpiresAt: json['tierExpiresAt'] == null
            ? null
            : DateTime.tryParse(json['tierExpiresAt'] as String),
        exp: (json['exp'] as num?)?.toInt() ?? 0,
        level: (json['level'] as num?)?.toInt() ?? 1,
        rankKey: json['rankKey'] as String? ?? 'beginner',
        selectedTitle: json['selectedTitle'] as String?,
        badgeIds: (json['badgeIds'] as List?)?.map((e) => '$e').toList() ?? const [],
        isPrivate: json['isPrivate'] as bool? ?? false,
        isBanned: json['isBanned'] as bool? ?? false,
        stats: json['stats'] is Map
            ? UserStats.fromJson(Map<String, dynamic>.from(json['stats'] as Map))
            : const UserStats(),
        favoriteAnime:
            (json['favoriteAnime'] as List?)?.map((e) => '$e').toList() ?? const [],
        favoriteComics:
            (json['favoriteComics'] as List?)?.map((e) => '$e').toList() ?? const [],
        favoriteNovels:
            (json['favoriteNovels'] as List?)?.map((e) => '$e').toList() ?? const [],
      );
}
