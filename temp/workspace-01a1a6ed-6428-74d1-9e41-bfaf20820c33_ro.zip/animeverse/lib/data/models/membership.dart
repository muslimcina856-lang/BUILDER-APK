import 'package:flutter/material.dart';

import 'user_profile.dart';

class MembershipPlan {
  const MembershipPlan({
    required this.tier,
    required this.months,
    required this.priceIdr,
    required this.originalPriceIdr,
    required this.label,
    this.isPopular = false,
    this.savePercent = 0,
  });

  final MembershipTier tier;
  final int months;
  final int priceIdr;
  final int originalPriceIdr;
  final String label;
  final bool isPopular;
  final int savePercent;

  String get priceLabel => formatIdr(priceIdr);
  String get originalPriceLabel => formatIdr(originalPriceIdr);
  String get perMonthLabel => formatIdr((priceIdr / months).round());

  static String formatIdr(int value) {
    final text = value.toString();
    final buffer = StringBuffer();
    for (var i = 0; i < text.length; i++) {
      final remaining = text.length - i;
      buffer.write(text[i]);
      if (remaining > 1 && remaining % 3 == 1) buffer.write('.');
    }
    return 'Rp${buffer.toString()}';
  }

  /// Daftar harga resmi aplikasi (dapat diubah admin melalui `membership_plans`).
  static const List<MembershipPlan> catalog = [
    MembershipPlan(tier: MembershipTier.vip, months: 1, priceIdr: 29000, originalPriceIdr: 39000, label: '1 Bulan'),
    MembershipPlan(tier: MembershipTier.vip, months: 3, priceIdr: 79000, originalPriceIdr: 117000, label: '3 Bulan', savePercent: 32),
    MembershipPlan(tier: MembershipTier.vip, months: 12, priceIdr: 249000, originalPriceIdr: 468000, label: '12 Bulan', savePercent: 46),
    MembershipPlan(tier: MembershipTier.premium, months: 1, priceIdr: 59000, originalPriceIdr: 79000, label: '1 Bulan', isPopular: true),
    MembershipPlan(tier: MembershipTier.premium, months: 3, priceIdr: 159000, originalPriceIdr: 237000, label: '3 Bulan', savePercent: 33),
    MembershipPlan(tier: MembershipTier.premium, months: 12, priceIdr: 499000, originalPriceIdr: 948000, label: '12 Bulan', savePercent: 47),
    MembershipPlan(tier: MembershipTier.ultimate, months: 1, priceIdr: 99000, originalPriceIdr: 129000, label: '1 Bulan'),
    MembershipPlan(tier: MembershipTier.ultimate, months: 3, priceIdr: 269000, originalPriceIdr: 387000, label: '3 Bulan', savePercent: 30),
    MembershipPlan(tier: MembershipTier.ultimate, months: 12, priceIdr: 849000, originalPriceIdr: 1548000, label: '12 Bulan', savePercent: 45),
  ];

  static List<MembershipPlan> forTier(MembershipTier tier) =>
      catalog.where((plan) => plan.tier == tier).toList();
}

class MembershipBenefit {
  const MembershipBenefit(this.icon, this.title, this.description, this.minTier);
  final IconData icon;
  final String title;
  final String description;
  final MembershipTier minTier;
}

class MembershipBenefits {
  const MembershipBenefits._();

  static const List<MembershipBenefit> all = [
    MembershipBenefit(Icons.block_rounded, 'Bebas Iklan', 'Tanpa banner & pre-roll ads di semua halaman', MembershipTier.vip),
    MembershipBenefit(Icons.hd_rounded, 'Kualitas 1080p', 'Streaming hingga Full HD di semua perangkat', MembershipTier.vip),
    MembershipBenefit(Icons.download_rounded, 'Download Offline', 'Unduh episode/konten yang lisensinya mengizinkan', MembershipTier.vip),
    MembershipBenefit(Icons.workspace_premium_rounded, 'Badge & Frame VIP', 'Badge profil, frame eksklusif dan title khusus', MembershipTier.vip),
    MembershipBenefit(Icons.palette_rounded, 'Tema Premium', 'Akses tema & aksen eksklusif aplikasi', MembershipTier.premium),
    MembershipBenefit(Icons.bolt_rounded, 'Server Prioritas', 'Antrean streaming prioritas & bitrate stabil', MembershipTier.premium),
    MembershipBenefit(Icons.groups_rounded, 'Private Chat', 'Buka private chat & room eksklusif', MembershipTier.premium),
    MembershipBenefit(Icons.auto_awesome_rounded, 'Koleksi Eksklusif', 'Akses koleksi kurasi & early access chapter', MembershipTier.ultimate),
    MembershipBenefit(Icons.support_agent_rounded, 'Support Prioritas', 'Respon CS < 2 jam, 24/7', MembershipTier.ultimate),
    MembershipBenefit(Icons.diamond_rounded, 'Frame Ultimate', 'Frame profil animasi emas + nama berkilau', MembershipTier.ultimate),
  ];

  static List<MembershipBenefit> forTier(MembershipTier tier) =>
      all.where((benefit) => benefit.minTier.rank <= tier.rank).toList();
}

class MembershipStatus {
  const MembershipStatus({
    this.tier = MembershipTier.free,
    this.expiresAt,
    this.autoRenew = false,
    this.startedAt,
  });

  final MembershipTier tier;
  final DateTime? expiresAt;
  final bool autoRenew;
  final DateTime? startedAt;

  bool get isActive =>
      tier.isPaid && (expiresAt == null || expiresAt!.isAfter(DateTime.now()));

  MembershipTier get effectiveTier => isActive ? tier : MembershipTier.free;

  int get daysRemaining {
    if (expiresAt == null) return 0;
    final diff = expiresAt!.difference(DateTime.now()).inDays;
    return diff < 0 ? 0 : diff;
  }

  Map<String, dynamic> toJson() => {
        'tier': tier.value,
        'expiresAt': expiresAt?.toIso8601String(),
        'autoRenew': autoRenew,
        'startedAt': startedAt?.toIso8601String(),
      };

  factory MembershipStatus.fromJson(Map<String, dynamic> json) => MembershipStatus(
        tier: MembershipTier.fromValue(json['tier'] as String?),
        expiresAt: json['expiresAt'] == null
            ? null
            : DateTime.tryParse(json['expiresAt'] as String),
        autoRenew: json['autoRenew'] as bool? ?? false,
        startedAt: json['startedAt'] == null
            ? null
            : DateTime.tryParse(json['startedAt'] as String),
      );
}

enum PaymentStatus { pending, paid, failed, refunded }

class PaymentRecord {
  const PaymentRecord({
    required this.id,
    required this.tier,
    required this.months,
    required this.amountIdr,
    required this.method,
    required this.status,
    required this.createdAt,
    this.invoiceUrl,
  });

  final String id;
  final MembershipTier tier;
  final int months;
  final int amountIdr;
  final String method;
  final PaymentStatus status;
  final DateTime createdAt;
  final String? invoiceUrl;

  String get statusLabel {
    switch (status) {
      case PaymentStatus.pending:
        return 'Menunggu Pembayaran';
      case PaymentStatus.paid:
        return 'Berhasil';
      case PaymentStatus.failed:
        return 'Gagal';
      case PaymentStatus.refunded:
        return 'Dikembalikan';
    }
  }

  String get amountLabel => MembershipPlan.formatIdr(amountIdr);

  Map<String, dynamic> toJson() => {
        'id': id,
        'tier': tier.value,
        'months': months,
        'amountIdr': amountIdr,
        'method': method,
        'status': status.name,
        'createdAt': createdAt.toIso8601String(),
        'invoiceUrl': invoiceUrl,
      };

  factory PaymentRecord.fromJson(Map<String, dynamic> json) => PaymentRecord(
        id: json['id'].toString(),
        tier: MembershipTier.fromValue(json['tier'] as String?),
        months: (json['months'] as num?)?.toInt() ?? 1,
        amountIdr: (json['amountIdr'] as num?)?.toInt() ?? 0,
        method: json['method'] as String? ?? 'QRIS',
        status: PaymentStatus.values.firstWhere(
          (value) => value.name == json['status'],
          orElse: () => PaymentStatus.paid,
        ),
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
            DateTime.now(),
        invoiceUrl: json['invoiceUrl'] as String?,
      );
}
