import 'media.dart';

enum LibraryKind { bookmark, favorite, download }

/// Ringkasan judul yang disimpan pada bookmark / favorite / download.
class LibraryEntry {
  const LibraryEntry({
    required this.media,
    required this.addedAt,
    this.kind = LibraryKind.bookmark,
    this.note = '',
    this.progressLabel,
  });

  final MediaItem media;
  final DateTime addedAt;
  final LibraryKind kind;
  final String note;
  final String? progressLabel;

  Map<String, dynamic> toJson() => {
        'media': media.toJson(),
        'addedAt': addedAt.toIso8601String(),
        'kind': kind.name,
        'note': note,
        'progressLabel': progressLabel,
      };

  factory LibraryEntry.fromJson(Map<String, dynamic> json) => LibraryEntry(
        media: MediaItem.fromJson(Map<String, dynamic>.from(json['media'] as Map)),
        addedAt: DateTime.tryParse(json['addedAt'] as String? ?? '') ?? DateTime.now(),
        kind: LibraryKind.values.firstWhere(
          (value) => value.name == json['kind'],
          orElse: () => LibraryKind.bookmark,
        ),
        note: json['note'] as String? ?? '',
        progressLabel: json['progressLabel'] as String?,
      );
}

/// Riwayat tonton/baca + posisi terakhir (continue watching / reading).
class HistoryEntry {
  const HistoryEntry({
    required this.id,
    required this.media,
    required this.updatedAt,
    this.episodeNumber,
    this.chapterId,
    this.chapterNumber,
    this.positionSeconds = 0,
    this.durationSeconds = 0,
    this.pageIndex = 0,
    this.totalPages = 0,
    this.completed = false,
  });

  final String id;
  final MediaItem media;
  final DateTime updatedAt;
  final int? episodeNumber;
  final String? chapterId;
  final double? chapterNumber;
  final int positionSeconds;
  final int durationSeconds;
  final int pageIndex;
  final int totalPages;
  final bool completed;

  bool get isVideo => media.kind.isVideo;

  double get progress {
    if (media.kind.isVideo) {
      if (durationSeconds <= 0) return 0;
      return (positionSeconds / durationSeconds).clamp(0.0, 1.0);
    }
    if (totalPages > 0) return ((pageIndex + 1) / totalPages).clamp(0.0, 1.0);
    return 0;
  }

  String get progressLabel {
    if (media.kind.isVideo) {
      return 'E${episodeNumber ?? 1} • ${_formatDuration(positionSeconds)} / ${_formatDuration(durationSeconds)}';
    }
    return 'Bab ${chapterNumber ?? 1} • Halaman ${pageIndex + 1}';
  }

  HistoryEntry copyWith({
    int? positionSeconds,
    int? durationSeconds,
    int? pageIndex,
    int? totalPages,
    int? episodeNumber,
    String? chapterId,
    double? chapterNumber,
    bool? completed,
    DateTime? updatedAt,
  }) =>
      HistoryEntry(
        id: id,
        media: media,
        updatedAt: updatedAt ?? DateTime.now(),
        episodeNumber: episodeNumber ?? this.episodeNumber,
        chapterId: chapterId ?? this.chapterId,
        chapterNumber: chapterNumber ?? this.chapterNumber,
        positionSeconds: positionSeconds ?? this.positionSeconds,
        durationSeconds: durationSeconds ?? this.durationSeconds,
        pageIndex: pageIndex ?? this.pageIndex,
        totalPages: totalPages ?? this.totalPages,
        completed: completed ?? this.completed,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'media': media.toJson(),
        'updatedAt': updatedAt.toIso8601String(),
        'episodeNumber': episodeNumber,
        'chapterId': chapterId,
        'chapterNumber': chapterNumber,
        'positionSeconds': positionSeconds,
        'durationSeconds': durationSeconds,
        'pageIndex': pageIndex,
        'totalPages': totalPages,
        'completed': completed,
      };

  factory HistoryEntry.fromJson(Map<String, dynamic> json) => HistoryEntry(
        id: json['id'].toString(),
        media: MediaItem.fromJson(Map<String, dynamic>.from(json['media'] as Map)),
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ??
            DateTime.now(),
        episodeNumber: (json['episodeNumber'] as num?)?.toInt(),
        chapterId: json['chapterId']?.toString(),
        chapterNumber: (json['chapterNumber'] as num?)?.toDouble(),
        positionSeconds: (json['positionSeconds'] as num?)?.toInt() ?? 0,
        durationSeconds: (json['durationSeconds'] as num?)?.toInt() ?? 0,
        pageIndex: (json['pageIndex'] as num?)?.toInt() ?? 0,
        totalPages: (json['totalPages'] as num?)?.toInt() ?? 0,
        completed: json['completed'] as bool? ?? false,
      );

  static String _formatDuration(int seconds) {
    if (seconds <= 0) return '00:00';
    final hours = seconds ~/ 3600;
    final minutes = (seconds % 3600) ~/ 60;
    final secs = seconds % 60;
    final mm = minutes.toString().padLeft(2, '0');
    final ss = secs.toString().padLeft(2, '0');
    return hours > 0 ? '$hours:$mm:$ss' : '$mm:$ss';
  }
}

enum DownloadStatus { queued, downloading, paused, completed, failed }

class DownloadTask {
  const DownloadTask({
    required this.id,
    required this.media,
    required this.label,
    required this.url,
    this.status = DownloadStatus.queued,
    this.progress = 0,
    this.sizeMb = 0,
    this.quality = '720p',
    this.localPath,
    this.createdAt,
    this.errorMessage,
  });

  final String id;
  final MediaItem media;
  final String label;
  final String url;
  final DownloadStatus status;
  final double progress;
  final double sizeMb;
  final String quality;
  final String? localPath;
  final DateTime? createdAt;
  final String? errorMessage;

  String get statusLabel {
    switch (status) {
      case DownloadStatus.queued:
        return 'Menunggu';
      case DownloadStatus.downloading:
        return 'Mengunduh ${(progress * 100).toStringAsFixed(0)}%';
      case DownloadStatus.paused:
        return 'Dijeda';
      case DownloadStatus.completed:
        return 'Selesai';
      case DownloadStatus.failed:
        return 'Gagal';
    }
  }

  DownloadTask copyWith({
    DownloadStatus? status,
    double? progress,
    double? sizeMb,
    String? localPath,
    String? errorMessage,
  }) =>
      DownloadTask(
        id: id,
        media: media,
        label: label,
        url: url,
        status: status ?? this.status,
        progress: progress ?? this.progress,
        sizeMb: sizeMb ?? this.sizeMb,
        quality: quality,
        localPath: localPath ?? this.localPath,
        createdAt: createdAt,
        errorMessage: errorMessage ?? this.errorMessage,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'media': media.toJson(),
        'label': label,
        'url': url,
        'status': status.name,
        'progress': progress,
        'sizeMb': sizeMb,
        'quality': quality,
        'localPath': localPath,
        'createdAt': createdAt?.toIso8601String(),
        'errorMessage': errorMessage,
      };

  factory DownloadTask.fromJson(Map<String, dynamic> json) => DownloadTask(
        id: json['id'].toString(),
        media: MediaItem.fromJson(Map<String, dynamic>.from(json['media'] as Map)),
        label: json['label'] as String? ?? '',
        url: json['url'] as String? ?? '',
        status: DownloadStatus.values.firstWhere(
          (value) => value.name == json['status'],
          orElse: () => DownloadStatus.queued,
        ),
        progress: (json['progress'] as num?)?.toDouble() ?? 0,
        sizeMb: (json['sizeMb'] as num?)?.toDouble() ?? 0,
        quality: json['quality'] as String? ?? '720p',
        localPath: json['localPath'] as String?,
        createdAt: json['createdAt'] == null
            ? null
            : DateTime.tryParse(json['createdAt'] as String),
        errorMessage: json['errorMessage'] as String?,
      );
}
