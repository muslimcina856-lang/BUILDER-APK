import 'package:flutter/material.dart';

/// Kategori utama aplikasi. Setiap kategori memakai adapter berbeda pada
/// [ContentRepository] namun berbagi model & UI yang sama.
enum MediaKind {
  anime('anime', 'Anime', MediaGroup.video),
  donghua('donghua', 'Donghua', MediaGroup.video),
  movie('movie', 'Movie', MediaGroup.video),
  manga('manga', 'Manga', MediaGroup.comic),
  manhwa('manhwa', 'Manhwa', MediaGroup.comic),
  manhua('manhua', 'Manhua', MediaGroup.comic),
  novel('novel', 'Novel', MediaGroup.text);

  const MediaKind(this.slug, this.label, this.group);

  final String slug;
  final String label;
  final MediaGroup group;

  bool get isVideo => group == MediaGroup.video;
  bool get isComic => group == MediaGroup.comic;
  bool get isText => group == MediaGroup.text;
  bool get isReadable => group != MediaGroup.video;

  IconData get icon {
    switch (this) {
      case MediaKind.anime:
        return Icons.auto_awesome_rounded;
      case MediaKind.donghua:
        return Icons.local_fire_department_rounded;
      case MediaKind.movie:
        return Icons.movie_creation_rounded;
      case MediaKind.manga:
        return Icons.menu_book_rounded;
      case MediaKind.manhwa:
        return Icons.collections_bookmark_rounded;
      case MediaKind.manhua:
        return Icons.auto_stories_rounded;
      case MediaKind.novel:
        return Icons.book_rounded;
    }
  }

  static MediaKind fromSlug(String slug) => MediaKind.values.firstWhere(
        (kind) => kind.slug == slug,
        orElse: () => MediaKind.anime,
      );

  static List<MediaKind> get videoKinds => [
        MediaKind.anime,
        MediaKind.donghua,
        MediaKind.movie,
      ];

  static List<MediaKind> get comicKinds => [
        MediaKind.manga,
        MediaKind.manhwa,
        MediaKind.manhua,
      ];
}

enum MediaGroup { video, comic, text }

/// Asal data sebuah judul.
enum ContentSource { anilist, mangadex, wikisource, manual }

/// MediaType pada AniList yang dipakai untuk memfilter kategori.
extension MediaKindAniList on MediaKind {
  String get aniListType => isReadable ? 'MANGA' : 'ANIME';

  String? get aniListFormat {
    switch (this) {
      case MediaKind.movie:
        return 'MOVIE';
      case MediaKind.novel:
        return 'NOVEL';
      default:
        return null;
    }
  }

  String? get countryOfOrigin {
    switch (this) {
      case MediaKind.donghua:
        return 'CN';
      case MediaKind.manhwa:
        return 'KR';
      case MediaKind.manhua:
        return 'CN';
      default:
        return null;
    }
  }

  String? get mangadexOriginalLanguage {
    switch (this) {
      case MediaKind.manhwa:
        return 'ko';
      case MediaKind.manhua:
        return 'zh';
      case MediaKind.manga:
        return 'ja';
      default:
        return null;
    }
  }
}

@immutable
class MediaItem {
  const MediaItem({
    required this.id,
    required this.kind,
    required this.title,
    required this.source,
    this.remoteId,
    this.titleEnglish,
    this.titleNative,
    this.coverUrl,
    this.bannerUrl,
    this.description,
    this.genres = const [],
    this.score,
    this.popularity,
    this.year,
    this.status,
    this.format,
    this.season,
    this.episodes,
    this.chapters,
    this.volumes,
    this.duration,
    this.studio,
    this.trailerId,
    this.trailerSite,
    this.colorHex,
    this.nextEpisodeNumber,
    this.nextEpisodeAt,
    this.isAdult = false,
    this.siteUrl,
  });

  /// ID unik lintas sumber, contoh: `anilist:21`, `mangadex:uuid4`.
  final String id;
  final MediaKind kind;
  final String title;
  final String? titleEnglish;
  final String? titleNative;
  final ContentSource source;
  final String? remoteId;
  final String? coverUrl;
  final String? bannerUrl;
  final String? description;
  final List<String> genres;
  final int? score; // 0..100
  final int? popularity;
  final int? year;
  final String? status;
  final String? format;
  final String? season;
  final int? episodes;
  final int? chapters;
  final int? volumes;
  final int? duration; // menit / halaman
  final String? studio;
  final String? trailerId;
  final String? trailerSite;
  final String? colorHex;
  final int? nextEpisodeNumber;
  final DateTime? nextEpisodeAt;
  final bool isAdult;
  final String? siteUrl;

  String get displayTitle => title;
  String get scoreLabel => score == null ? '—' : (score! / 10).toStringAsFixed(1);
  Color get accent => _hexColor(colorHex);

  bool get isAiring => (status ?? '').toLowerCase() == 'releasing';

  String get formatLabel {
    final value = (format ?? kind.label).toLowerCase();
    if (value == 'tv') return 'TV';
    if (value == 'tv_short') return 'TV Short';
    if (value == 'ona') return 'ONA';
    if (value == 'ova') return 'OVA';
    if (value == 'one_shot') return 'One Shot';
    return value.isEmpty ? kind.label : _capitalize(value);
  }

  String get statusLabel {
    switch ((status ?? '').toLowerCase()) {
      case 'releasing':
        return isVideo ? 'Sedang Tayang' : 'Ongoing';
      case 'finished':
        return 'Tamat';
      case 'not_yet_released':
        return 'Belum Rilis';
      case 'cancelled':
        return 'Dibatalkan';
      case 'hiatus':
        return isVideo ? 'Ditunda' : 'Hiatus';
      default:
        return status ?? '—';
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.slug,
        'title': title,
        'titleEnglish': titleEnglish,
        'titleNative': titleNative,
        'source': source.name,
        'remoteId': remoteId,
        'coverUrl': coverUrl,
        'bannerUrl': bannerUrl,
        'description': description,
        'genres': genres,
        'score': score,
        'popularity': popularity,
        'year': year,
        'status': status,
        'format': format,
        'season': season,
        'episodes': episodes,
        'chapters': chapters,
        'volumes': volumes,
        'duration': duration,
        'studio': studio,
        'trailerId': trailerId,
        'trailerSite': trailerSite,
        'colorHex': colorHex,
        'nextEpisodeNumber': nextEpisodeNumber,
        'nextEpisodeAt': nextEpisodeAt?.toIso8601String(),
        'isAdult': isAdult,
        'siteUrl': siteUrl,
      };

  factory MediaItem.fromJson(Map<String, dynamic> json) => MediaItem(
        id: json['id'] as String,
        kind: MediaKind.fromSlug(json['kind'] as String? ?? 'anime'),
        title: json['title'] as String? ?? 'Tanpa Judul',
        titleEnglish: json['titleEnglish'] as String?,
        titleNative: json['titleNative'] as String?,
        source: ContentSource.values.firstWhere(
          (value) => value.name == json['source'],
          orElse: () => ContentSource.anilist,
        ),
        remoteId: json['remoteId'] as String?,
        coverUrl: json['coverUrl'] as String?,
        bannerUrl: json['bannerUrl'] as String?,
        description: json['description'] as String?,
        genres: (json['genres'] as List?)?.cast<String>() ?? const [],
        score: (json['score'] as num?)?.toInt(),
        popularity: (json['popularity'] as num?)?.toInt(),
        year: (json['year'] as num?)?.toInt(),
        status: json['status'] as String?,
        format: json['format'] as String?,
        season: json['season'] as String?,
        episodes: (json['episodes'] as num?)?.toInt(),
        chapters: (json['chapters'] as num?)?.toInt(),
        volumes: (json['volumes'] as num?)?.toInt(),
        duration: (json['duration'] as num?)?.toInt(),
        studio: json['studio'] as String?,
        trailerId: json['trailerId'] as String?,
        trailerSite: json['trailerSite'] as String?,
        colorHex: json['colorHex'] as String?,
        nextEpisodeNumber: (json['nextEpisodeNumber'] as num?)?.toInt(),
        nextEpisodeAt: json['nextEpisodeAt'] == null
            ? null
            : DateTime.tryParse(json['nextEpisodeAt'] as String),
        isAdult: json['isAdult'] as bool? ?? false,
        siteUrl: json['siteUrl'] as String?,
      );

  factory MediaItem.fromAniList(Map<String, dynamic> json, MediaKind kind) {
    final title = json['title'] as Map? ?? const {};
    final cover = json['coverImage'] as Map? ?? const {};
    final trailer = json['trailer'] as Map?;
    final studios = json['studios'] as Map?;
    final nodes = (studios?['nodes'] as List?) ?? const [];
    final nextAiring = json['nextAiringEpisode'] as Map?;
    return MediaItem(
      id: 'anilist:${json['id']}',
      remoteId: '${json['id']}',
      kind: kind,
      title: (title['romaji'] ?? title['english'] ?? title['native'] ?? 'Tanpa Judul')
          .toString(),
      titleEnglish: title['english'] as String?,
      titleNative: title['native'] as String?,
      source: ContentSource.anilist,
      coverUrl: (cover['extraLarge'] ?? cover['large'] ?? cover['medium'])
          ?.toString(),
      bannerUrl: json['bannerImage'] as String?,
      description: _cleanHtml(json['description'] as String?),
      genres: (json['genres'] as List?)?.map((e) => '$e').toList() ?? const [],
      score: (json['averageScore'] as num?)?.toInt(),
      popularity: (json['popularity'] as num?)?.toInt(),
      year: (json['seasonYear'] as num?)?.toInt() ??
          (json['startDate'] is Map
              ? ((json['startDate'] as Map)['year'] as num?)?.toInt()
              : null),
      status: json['status'] as String?,
      format: json['format'] as String?,
      season: json['season'] as String?,
      episodes: (json['episodes'] as num?)?.toInt(),
      chapters: (json['chapters'] as num?)?.toInt(),
      volumes: (json['volumes'] as num?)?.toInt(),
      duration: (json['duration'] as num?)?.toInt(),
      studio: nodes.isEmpty
          ? null
          : ((nodes.first as Map)['name']?.toString()),
      trailerId: trailer?['id']?.toString(),
      trailerSite: trailer?['site'] as String?,
      colorHex: cover['color'] as String?,
      nextEpisodeNumber: (nextAiring?['episode'] as num?)?.toInt(),
      nextEpisodeAt: (nextAiring?['airingAt'] as num?) == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(
              (nextAiring!['airingAt'] as num).toInt() * 1000,
            ),
      isAdult: json['isAdult'] as bool? ?? false,
      siteUrl: json['siteUrl'] as String?,
    );
  }

  MediaItem copyWith({String? title, String? coverUrl}) => MediaItem(
        id: id,
        kind: kind,
        title: title ?? this.title,
        titleEnglish: titleEnglish,
        titleNative: titleNative,
        source: source,
        remoteId: remoteId,
        coverUrl: coverUrl ?? this.coverUrl,
        bannerUrl: bannerUrl,
        description: description,
        genres: genres,
        score: score,
        popularity: popularity,
        year: year,
        status: status,
        format: format,
        season: season,
        episodes: episodes,
        chapters: chapters,
        volumes: volumes,
        duration: duration,
        studio: studio,
        trailerId: trailerId,
        trailerSite: trailerSite,
        colorHex: colorHex,
        nextEpisodeNumber: nextEpisodeNumber,
        nextEpisodeAt: nextEpisodeAt,
        isAdult: isAdult,
        siteUrl: siteUrl,
      );

  static String _capitalize(String input) =>
      input.isEmpty ? input : input[0].toUpperCase() + input.substring(1);

  static String? _cleanHtml(String? html) {
    if (html == null) return null;
    return html
        .replaceAll(RegExp(r'<br\s*/?>'), '\n')
        .replaceAll(RegExp(r'<[^>]+>'), '')
        .replaceAll('&quot;', '"')
        .replaceAll('&amp;', '&')
        .replaceAll('&#039;', "'")
        .replaceAll('&mdash;', '—')
        .replaceAll('&nbsp;', ' ')
        .trim();
  }

  static Color _hexColor(String? hex) {
    if (hex == null) return const Color(0xFF7C4DFF);
    final cleaned = hex.replaceAll('#', '');
    if (cleaned.length != 6) return const Color(0xFF7C4DFF);
    final value = int.tryParse(cleaned, radix: 16);
    if (value == null) return const Color(0xFF7C4DFF);
    return Color(0xFF000000 | value);
  }
}

/// Hasil paginasi generik dari repository.
class PagedMedia {
  const PagedMedia({
    required this.items,
    this.hasNextPage = false,
    this.page = 1,
  });

  final List<MediaItem> items;
  final bool hasNextPage;
  final int page;

  bool get isEmpty => items.isEmpty;
}

/// Filter katalog yang dipakai bersama oleh semua halaman kategori.
class CatalogFilter {
  const CatalogFilter({
    this.query = '',
    this.genre,
    this.year,
    this.status,
    this.sort = CatalogSort.trending,
    this.page = 1,
  });

  final String query;
  final String? genre;
  final int? year;
  final String? status;
  final CatalogSort sort;
  final int page;

  CatalogFilter copyWith({
    String? query,
    String? genre,
    int? year,
    String? status,
    CatalogSort? sort,
    int? page,
    bool clearGenre = false,
    bool clearYear = false,
    bool clearStatus = false,
  }) =>
      CatalogFilter(
        query: query ?? this.query,
        genre: clearGenre ? null : (genre ?? this.genre),
        year: clearYear ? null : (year ?? this.year),
        status: clearStatus ? null : (status ?? this.status),
        sort: sort ?? this.sort,
        page: page ?? this.page,
      );

  bool get hasActiveFilters =>
      (genre != null && genre!.isNotEmpty) ||
      year != null ||
      (status != null && status!.isNotEmpty);
}

enum CatalogSort {
  trending('TRENDING_DESC', 'Trending'),
  popular('POPULARITY_DESC', 'Paling Populer'),
  score('SCORE_DESC', 'Rating Tertinggi'),
  newest('START_DATE_DESC', 'Terbaru'),
  title('TITLE_ROMAJI', 'A–Z'),
  updated('UPDATED_AT_DESC', 'Baru Diperbarui');

  const CatalogSort(this.aniListValue, this.label);
  final String aniListValue;
  final String label;
}
