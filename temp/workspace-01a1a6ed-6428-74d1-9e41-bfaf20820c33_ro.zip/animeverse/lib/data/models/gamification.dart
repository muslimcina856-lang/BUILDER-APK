import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Rank berdasarkan total EXP. 12 tingkatan sesuai spesifikasi.
class RankTier {
  const RankTier({
    required this.key,
    required this.name,
    required this.minExp,
    required this.color,
    required this.icon,
    required this.perk,
  });

  final String key;
  final String name;
  final int minExp;
  final Color color;
  final IconData icon;
  final String perk;

  static const List<RankTier> all = [
    RankTier(key: 'beginner', name: 'Beginner', minExp: 0, color: Color(0xFF9CA3AF), icon: Icons.egg_outlined, perk: 'Akses dasar katalog & komentar'),
    RankTier(key: 'novice', name: 'Novice', minExp: 800, color: Color(0xFF86EFAC), icon: Icons.spa_outlined, perk: 'Bookmark tanpa batas'),
    RankTier(key: 'amateur', name: 'Amateur', minExp: 2000, color: Color(0xFF34D399), icon: Icons.auto_awesome_outlined, perk: 'Tema aksen tambahan'),
    RankTier(key: 'advanced', name: 'Advanced', minExp: 4000, color: Color(0xFF38BDF8), icon: Icons.rocket_launch_outlined, perk: 'Badge profil + highlight komentar'),
    RankTier(key: 'expert', name: 'Expert', minExp: 7000, color: Color(0xFF60A5FA), icon: Icons.workspace_premium_outlined, perk: 'Akses early access episode'),
    RankTier(key: 'master', name: 'Master', minExp: 11000, color: Color(0xFF818CF8), icon: Icons.military_tech_outlined, perk: 'Frame profil eksklusif'),
    RankTier(key: 'grandmaster', name: 'Grandmaster', minExp: 16000, color: Color(0xFFA78BFA), icon: Icons.shield_outlined, perk: 'Warna nama khusus di komentar'),
    RankTier(key: 'legend', name: 'Legend', minExp: 24000, color: Color(0xFFC084FC), icon: Icons.emoji_events_outlined, perk: 'Akses beta fitur baru'),
    RankTier(key: 'mythic', name: 'Mythic', minExp: 35000, color: Color(0xFFE879F9), icon: Icons.cruelty_free_outlined, perk: 'Emoji & sticker eksklusif'),
    RankTier(key: 'immortal', name: 'Immortal', minExp: 50000, color: Color(0xFFFB7185), icon: Icons.local_fire_department_outlined, perk: 'Vote di polling komunitas'),
    RankTier(key: 'supreme', name: 'Supreme', minExp: 75000, color: Color(0xFFFFC857), icon: Icons.diamond_outlined, perk: 'Baris leaderboard highlight'),
    RankTier(key: 'godlike', name: 'Godlike', minExp: 120000, color: Color(0xFFFFE29B), icon: Icons.flare_rounded, perk: 'Title legendaris + frame emas'),
  ];

  static RankTier fromKey(String? key) => all.firstWhere(
        (rank) => rank.key == key,
        orElse: () => all.first,
      );

  static RankTier fromExp(int exp) {
    var current = all.first;
    for (final rank in all) {
      if (exp >= rank.minExp) current = rank;
    }
    return current;
  }

  RankTier? get next {
    final index = all.indexOf(this);
    if (index < 0 || index == all.length - 1) return null;
    return all[index + 1];
  }
}

/// Kurva level: total EXP untuk mencapai level L = 250 * (L-1) * L / 2.
class LevelMath {
  const LevelMath._();

  static int totalExpForLevel(int level) {
    if (level <= 1) return 0;
    return 125 * (level - 1) * level;
  }

  static int levelFromExp(int exp) {
    if (exp <= 0) return 1;
    final value = 125.0 + math.sqrt(125.0 * 125.0 + 4 * 125.0 * exp);
    final level = ((value) / (2 * 125)).floor();
    return math.max(1, level);
  }

  static int expInCurrentLevel(int exp) {
    final level = levelFromExp(exp);
    return exp - totalExpForLevel(level);
  }

  static int expForNextLevel(int level) => totalExpForLevel(level + 1) - totalExpForLevel(level);

  static double levelProgress(int exp) {
    final level = levelFromExp(exp);
    final need = expForNextLevel(level);
    if (need <= 0) return 0;
    return (expInCurrentLevel(exp) / need).clamp(0.0, 1.0);
  }
}

class TitleItem {
  const TitleItem({
    required this.id,
    required this.label,
    required this.description,
    this.minLevel = 1,
    this.requiresTier = 'free',
    this.isPremium = false,
  });

  final String id;
  final String label;
  final String description;
  final int minLevel;
  final String requiresTier;
  final bool isPremium;

  static const List<TitleItem> catalog = [
    TitleItem(id: 'newbie', label: 'Pendatang Baru', description: 'Default semua pengguna'),
    TitleItem(id: 'binge', label: 'Binge Watcher', description: 'Tonton 50 episode', minLevel: 3),
    TitleItem(id: 'otaku', label: 'Otaku Sejati', description: 'Tonton 200 episode', minLevel: 8),
    TitleItem(id: 'bookworm', label: 'Bookworm', description: 'Baca 100 chapter', minLevel: 5),
    TitleItem(id: 'novelis', label: 'Pembaca Novel', description: 'Selesaikan 5 novel', minLevel: 6),
    TitleItem(id: 'kolektor', label: 'Kolektor', description: 'Bookmark 30 judul', minLevel: 4),
    TitleItem(id: 'kritikus', label: 'Kritikus', description: 'Tulis 50 komentar', minLevel: 7),
    TitleItem(id: 'legenda', label: 'Legenda Semesta', description: 'Capai rank Legend', minLevel: 15),
    TitleItem(id: 'vip', label: 'VIP Member', description: 'Eksklusif member VIP', requiresTier: 'vip', isPremium: true),
    TitleItem(id: 'premium', label: 'Premium Elite', description: 'Eksklusif member Premium', requiresTier: 'premium', isPremium: true),
    TitleItem(id: 'ultimate', label: 'Ultimate Immortal', description: 'Eksklusif member Ultimate', requiresTier: 'ultimate', isPremium: true),
  ];

  static TitleItem? byId(String? id) {
    if (id == null) return null;
    for (final item in catalog) {
      if (item.id == id) return item;
    }
    return null;
  }
}

class BadgeItem {
  const BadgeItem({
    required this.id,
    required this.label,
    required this.icon,
    required this.description,
    this.color = const Color(0xFFB388FF),
  });

  final String id;
  final String label;
  final IconData icon;
  final String description;
  final Color color;

  static const List<BadgeItem> catalog = [
    BadgeItem(id: 'early_bird', label: 'Early Bird', icon: Icons.wb_twilight_rounded, description: 'Login 7 hari berturut-turut'),
    BadgeItem(id: 'night_owl', label: 'Night Owl', icon: Icons.nightlight_round, description: 'Menonton setelah jam 00:00'),
    BadgeItem(id: 'first_comment', label: 'First Voice', icon: Icons.forum_rounded, description: 'Komentar pertama'),
    BadgeItem(id: 'marathon', label: 'Marathon', icon: Icons.directions_run_rounded, description: 'Tonton 12 episode dalam sehari'),
    BadgeItem(id: 'completionist', label: 'Completionist', icon: Icons.done_all_rounded, description: 'Selesaikan 1 judul penuh'),
    BadgeItem(id: 'collector', label: 'Collector', icon: Icons.collections_bookmark_rounded, description: 'Bookmark 30 judul'),
    BadgeItem(id: 'critic', label: 'Top Critic', icon: Icons.rate_review_rounded, description: 'Komentar mendapat 100 like'),
    BadgeItem(id: 'vip_frame', label: 'VIP Frame', icon: Icons.workspace_premium_rounded, description: 'Berlangganan VIP+'),
    BadgeItem(id: 'founder', label: 'Founder', icon: Icons.emoji_events_rounded, description: 'Pengguna 1000 pertama'),
    BadgeItem(id: 'legend', label: 'Legend', icon: Icons.flare_rounded, description: 'Capai rank Legend'),
  ];

  static BadgeItem? byId(String id) {
    for (final item in catalog) {
      if (item.id == id) return item;
    }
    return null;
  }
}

enum QuestPeriod { daily, weekly }

class Quest {
  const Quest({
    required this.id,
    required this.title,
    required this.description,
    required this.target,
    required this.progress,
    required this.expReward,
    this.period = QuestPeriod.daily,
    this.claimed = false,
    this.coinReward = 0,
  });

  final String id;
  final String title;
  final String description;
  final int target;
  final int progress;
  final int expReward;
  final int coinReward;
  final QuestPeriod period;
  final bool claimed;

  double get ratio => target == 0 ? 0 : (progress / target).clamp(0.0, 1.0);
  bool get isComplete => progress >= target;
  bool get isClaimable => isComplete && !claimed;

  Quest copyWith({int? progress, bool? claimed}) => Quest(
        id: id,
        title: title,
        description: description,
        target: target,
        progress: progress ?? this.progress,
        expReward: expReward,
        coinReward: coinReward,
        period: period,
        claimed: claimed ?? this.claimed,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'target': target,
        'progress': progress,
        'expReward': expReward,
        'coinReward': coinReward,
        'period': period.name,
        'claimed': claimed,
      };

  factory Quest.fromJson(Map<String, dynamic> json) => Quest(
        id: json['id'] as String,
        title: json['title'] as String? ?? '',
        description: json['description'] as String? ?? '',
        target: (json['target'] as num?)?.toInt() ?? 1,
        progress: (json['progress'] as num?)?.toInt() ?? 0,
        expReward: (json['expReward'] as num?)?.toInt() ?? 0,
        coinReward: (json['coinReward'] as num?)?.toInt() ?? 0,
        period: QuestPeriod.values.firstWhere(
          (value) => value.name == json['period'],
          orElse: () => QuestPeriod.daily,
        ),
        claimed: json['claimed'] as bool? ?? false,
      );
}

class Achievement {
  const Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.target,
    required this.progress,
    required this.expReward,
    this.unlockedAt,
  });

  final String id;
  final String title;
  final String description;
  final int target;
  final int progress;
  final int expReward;
  final DateTime? unlockedAt;

  bool get isUnlocked => unlockedAt != null || progress >= target;
  double get ratio => target == 0 ? 0 : (progress / target).clamp(0.0, 1.0);

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'target': target,
        'progress': progress,
        'expReward': expReward,
        'unlockedAt': unlockedAt?.toIso8601String(),
      };

  factory Achievement.fromJson(Map<String, dynamic> json) => Achievement(
        id: json['id'] as String,
        title: json['title'] as String? ?? '',
        description: json['description'] as String? ?? '',
        target: (json['target'] as num?)?.toInt() ?? 1,
        progress: (json['progress'] as num?)?.toInt() ?? 0,
        expReward: (json['expReward'] as num?)?.toInt() ?? 0,
        unlockedAt: json['unlockedAt'] == null
            ? null
            : DateTime.tryParse(json['unlockedAt'] as String),
      );
}

class LeaderboardEntry {
  const LeaderboardEntry({
    required this.position,
    required this.userId,
    required this.username,
    required this.displayName,
    required this.exp,
    required this.level,
    required this.rankKey,
    this.avatarUrl,
    this.tier = 'free',
    this.isMe = false,
  });

  final int position;
  final String userId;
  final String username;
  final String displayName;
  final int exp;
  final int level;
  final String rankKey;
  final String? avatarUrl;
  final String tier;
  final bool isMe;

  RankTier get rank => RankTier.fromKey(rankKey);

  Map<String, dynamic> toJson() => {
        'position': position,
        'userId': userId,
        'username': username,
        'displayName': displayName,
        'exp': exp,
        'level': level,
        'rankKey': rankKey,
        'avatarUrl': avatarUrl,
        'tier': tier,
        'isMe': isMe,
      };

  factory LeaderboardEntry.fromJson(Map<String, dynamic> json) => LeaderboardEntry(
        position: (json['position'] as num?)?.toInt() ?? 0,
        userId: json['userId']?.toString() ?? '',
        username: json['username'] as String? ?? '',
        displayName: json['displayName'] as String? ?? '',
        exp: (json['exp'] as num?)?.toInt() ?? 0,
        level: (json['level'] as num?)?.toInt() ?? 1,
        rankKey: json['rankKey'] as String? ?? 'beginner',
        avatarUrl: json['avatarUrl'] as String?,
        tier: json['tier'] as String? ?? 'free',
        isMe: json['isMe'] as bool? ?? false,
      );
}

/// Ringkasan gamifikasi user (dipakai profil, dashboard EXP, dsb).
class GamificationState {
  const GamificationState({
    this.exp = 0,
    this.level = 1,
    this.rankKey = 'beginner',
    this.titles = const [],
    this.unlockedTitles = const [],
    this.badges = const [],
    this.quests = const [],
    this.achievements = const [],
    this.dailyClaimed = false,
    this.loginStreak = 0,
    this.lastLoginAt,
  });

  final int exp;
  final int level;
  final String rankKey;
  final List<TitleItem> titles;
  final List<String> unlockedTitles;
  final List<BadgeItem> badges;
  final List<Quest> quests;
  final List<Achievement> achievements;
  final bool dailyClaimed;
  final int loginStreak;
  final DateTime? lastLoginAt;

  RankTier get rank => RankTier.fromKey(rankKey);
  int get expIntoLevel => LevelMath.expInCurrentLevel(exp);
  int get expForNext => LevelMath.expForNextLevel(level);
  double get levelProgress => LevelMath.levelProgress(exp);

  int? get expToNextRank {
    final next = rank.next;
    if (next == null) return null;
    return (next.minExp - exp).clamp(0, 1 << 30);
  }

  GamificationState copyWith({
    int? exp,
    int? level,
    String? rankKey,
    List<Quest>? quests,
    List<Achievement>? achievements,
    bool? dailyClaimed,
    int? loginStreak,
    List<String>? unlockedTitles,
    List<BadgeItem>? badges,
  }) =>
      GamificationState(
        exp: exp ?? this.exp,
        level: level ?? this.level,
        rankKey: rankKey ?? this.rankKey,
        titles: titles,
        unlockedTitles: unlockedTitles ?? this.unlockedTitles,
        badges: badges ?? this.badges,
        quests: quests ?? this.quests,
        achievements: achievements ?? this.achievements,
        dailyClaimed: dailyClaimed ?? this.dailyClaimed,
        loginStreak: loginStreak ?? this.loginStreak,
        lastLoginAt: lastLoginAt,
      );

  Map<String, dynamic> toJson() => {
        'exp': exp,
        'level': level,
        'rankKey': rankKey,
        'unlockedTitles': unlockedTitles,
        'badgeIds': badges.map((e) => e.id).toList(),
        'quests': quests.map((e) => e.toJson()).toList(),
        'achievements': achievements.map((e) => e.toJson()).toList(),
        'dailyClaimed': dailyClaimed,
        'loginStreak': loginStreak,
        'lastLoginAt': lastLoginAt?.toIso8601String(),
      };

  factory GamificationState.fromJson(Map<String, dynamic> json) =>
      GamificationState(
        exp: (json['exp'] as num?)?.toInt() ?? 0,
        level: (json['level'] as num?)?.toInt() ?? 1,
        rankKey: json['rankKey'] as String? ?? 'beginner',
        unlockedTitles:
            (json['unlockedTitles'] as List?)?.map((e) => '$e').toList() ?? const [],
        badges: ((json['badgeIds'] as List?) ?? const [])
            .map((id) => BadgeItem.byId('$id'))
            .whereType<BadgeItem>()
            .toList(),
        quests: (json['quests'] as List?)
                ?.map((e) => Quest.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
        achievements: (json['achievements'] as List?)
                ?.map((e) => Achievement.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
        dailyClaimed: json['dailyClaimed'] as bool? ?? false,
        loginStreak: (json['loginStreak'] as num?)?.toInt() ?? 0,
        lastLoginAt: json['lastLoginAt'] == null
            ? null
            : DateTime.tryParse(json['lastLoginAt'] as String),
      );
}

/// Katalog quest default (dipakai untuk reset harian/mingguan).
class QuestCatalog {
  const QuestCatalog._();

  static const List<Quest> templates = [
    Quest(id: 'daily_watch_1', title: 'Nonton 1 Episode', description: 'Tonton minimal 1 episode hari ini', target: 1, progress: 0, expReward: 40, coinReward: 5),
    Quest(id: 'daily_watch_3', title: 'Maraton Ringan', description: 'Tonton 3 episode hari ini', target: 3, progress: 0, expReward: 100, coinReward: 10),
    Quest(id: 'daily_read_2', title: 'Baca 2 Chapter', description: 'Selesaikan 2 chapter komik', target: 2, progress: 0, expReward: 80, coinReward: 8),
    Quest(id: 'daily_comment', title: 'Suarakan Pendapat', description: 'Tulis 1 komentar berkualitas', target: 1, progress: 0, expReward: 50, coinReward: 5),
    Quest(id: 'daily_bookmark', title: 'Simpan Koleksi', description: 'Bookmark 1 judul baru', target: 1, progress: 0, expReward: 30, coinReward: 3),
    Quest(id: 'weekly_watch_10', title: 'Weekly Binge', description: 'Tonton 10 episode minggu ini', target: 10, progress: 0, expReward: 400, coinReward: 40, period: QuestPeriod.weekly),
    Quest(id: 'weekly_read_15', title: 'Weekly Reader', description: 'Baca 15 chapter minggu ini', target: 15, progress: 0, expReward: 400, coinReward: 40, period: QuestPeriod.weekly),
    Quest(id: 'weekly_comment_5', title: 'Diskusi Aktif', description: 'Tulis 5 komentar minggu ini', target: 5, progress: 0, expReward: 250, coinReward: 25, period: QuestPeriod.weekly),
  ];

  static List<Quest> freshDaily() => templates
      .where((quest) => quest.period == QuestPeriod.daily)
      .map((quest) => quest.copyWith(progress: 0, claimed: false))
      .toList();

  static List<Quest> freshWeekly() => templates
      .where((quest) => quest.period == QuestPeriod.weekly)
      .map((quest) => quest.copyWith(progress: 0, claimed: false))
      .toList();
}

class AchievementCatalog {
  const AchievementCatalog._;

  static const List<Achievement> templates = [
    Achievement(id: 'first_episode', title: 'Langkah Pertama', description: 'Tonton episode pertama', target: 1, progress: 0, expReward: 50),
    Achievement(id: 'episodes_50', title: 'Binge Watcher', description: 'Tonton 50 episode', target: 50, progress: 0, expReward: 500),
    Achievement(id: 'episodes_200', title: 'Otaku Sejati', description: 'Tonton 200 episode', target: 200, progress: 0, expReward: 2000),
    Achievement(id: 'chapters_100', title: 'Bookworm', description: 'Baca 100 chapter', target: 100, progress: 0, expReward: 1200),
    Achievement(id: 'novel_5', title: 'Pembaca Novel', description: 'Selesaikan 5 novel', target: 5, progress: 0, expReward: 800),
    Achievement(id: 'comments_50', title: 'Kritikus', description: 'Tulis 50 komentar', target: 50, progress: 0, expReward: 600),
    Achievement(id: 'login_30', title: 'Setia', description: 'Login 30 hari total', target: 30, progress: 0, expReward: 700),
    Achievement(id: 'bookmark_30', title: 'Kolektor', description: 'Bookmark 30 judul', target: 30, progress: 0, expReward: 400),
  ];
}

/// Aturan EXP agar tidak bisa di-farm (anti-spam).
class ExpRules {
  const ExpRules._();

  static int forWatch({required int minutes}) => (minutes * 2).clamp(0, 30);
  static int forReadChapter() => 8;
  static int forReadNovelChapter() => 10;
  static int forComment() => 15;
  static int forDailyLogin(int streak) => (20 + streak * 5).clamp(20, 100);
  static int forBookmark() => 5;
}
