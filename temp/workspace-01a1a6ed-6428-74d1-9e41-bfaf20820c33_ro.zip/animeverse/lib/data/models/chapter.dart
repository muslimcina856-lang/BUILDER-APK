/// Chapter komik (manga / manhwa / manhua).
class ChapterInfo {
  const ChapterInfo({
    required this.id,
    required this.mediaId,
    required this.number,
    required this.title,
    this.volume,
    this.language = 'id',
    this.pages = 0,
    this.publishedAt,
    this.group,
    this.isAvailable = true,
  });

  final String id;
  final String mediaId;
  final double number;
  final String title;
  final String? volume;
  final String language;
  final int pages;
  final DateTime? publishedAt;
  final String? group;
  final bool isAvailable;

  String get label {
    final isWhole = number == number.roundToDouble();
    return 'Chapter ${isWhole ? number.toInt() : number}';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'mediaId': mediaId,
        'number': number,
        'title': title,
        'volume': volume,
        'language': language,
        'pages': pages,
        'publishedAt': publishedAt?.toIso8601String(),
        'group': group,
        'isAvailable': isAvailable,
      };

  factory ChapterInfo.fromJson(Map<String, dynamic> json) => ChapterInfo(
        id: json['id'] as String,
        mediaId: json['mediaId'] as String? ?? '',
        number: (json['number'] as num?)?.toDouble() ?? 0,
        title: json['title'] as String? ?? '',
        volume: json['volume'] as String?,
        language: json['language'] as String? ?? 'id',
        pages: (json['pages'] as num?)?.toInt() ?? 0,
        publishedAt: json['publishedAt'] == null
            ? null
            : DateTime.tryParse(json['publishedAt'] as String),
        group: json['group'] as String?,
        isAvailable: json['isAvailable'] as bool? ?? true,
      );
}

/// Satu halaman gambar pada reader komik.
class ReaderPage {
  const ReaderPage({
    required this.index,
    required this.url,
    this.width,
    this.height,
    this.headers = const {},
  });

  final int index;
  final String url;
  final int? width;
  final int? height;
  final Map<String, String> headers;

  double get aspectRatio {
    if (width == null || height == null || width == 0 || height == 0) {
      return 0.7;
    }
    return width! / height!;
  }

  Map<String, dynamic> toJson() => {
        'index': index,
        'url': url,
        'width': width,
        'height': height,
      };

  factory ReaderPage.fromJson(Map<String, dynamic> json) => ReaderPage(
        index: (json['index'] as num).toInt(),
        url: json['url'] as String,
        width: (json['width'] as num?)?.toInt(),
        height: (json['height'] as num?)?.toInt(),
      );
}

/// Chapter novel (teks). Sumber: tabel `chapters` (Supabase) atau Wikisource.
class NovelChapter {
  const NovelChapter({
    required this.index,
    required this.title,
    required this.id,
    this.wordCount = 0,
    this.content,
    this.updatedAt,
  });

  final int index;
  final String title;
  final String id;
  final int wordCount;
  final String? content;
  final DateTime? updatedAt;

  String get label => 'Bab $index';

  Map<String, dynamic> toJson() => {
        'index': index,
        'title': title,
        'id': id,
        'wordCount': wordCount,
        'content': content,
        'updatedAt': updatedAt?.toIso8601String(),
      };

  factory NovelChapter.fromJson(Map<String, dynamic> json) => NovelChapter(
        index: (json['index'] as num?)?.toInt() ?? 1,
        title: json['title'] as String? ?? '',
        id: json['id']?.toString() ?? '',
        wordCount: (json['wordCount'] as num?)?.toInt() ?? 0,
        content: json['content'] as String?,
        updatedAt: json['updatedAt'] == null
            ? null
            : DateTime.tryParse(json['updatedAt'] as String),
      );
}
