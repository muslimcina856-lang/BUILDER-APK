/// Komentar, reply, reaksi, laporan dan chat komunitas.
class CommentAuthor {
  const CommentAuthor({
    required this.id,
    required this.username,
    this.displayName = '',
    this.avatarUrl,
    this.level = 1,
    this.tier = 'free',
    this.selectedTitle,
    this.rankKey = 'beginner',
  });

  final String id;
  final String username;
  final String displayName;
  final String? avatarUrl;
  final int level;
  final String tier;
  final String? selectedTitle;
  final String rankKey;

  String get name => displayName.isEmpty ? username : displayName;

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'displayName': displayName,
        'avatarUrl': avatarUrl,
        'level': level,
        'tier': tier,
        'selectedTitle': selectedTitle,
        'rankKey': rankKey,
      };

  factory CommentAuthor.fromJson(Map<String, dynamic> json) => CommentAuthor(
        id: json['id']?.toString() ?? '',
        username: json['username'] as String? ?? 'pengguna',
        displayName: json['displayName'] as String? ?? '',
        avatarUrl: json['avatarUrl'] as String?,
        level: (json['level'] as num?)?.toInt() ?? 1,
        tier: json['tier'] as String? ?? 'free',
        selectedTitle: json['selectedTitle'] as String?,
        rankKey: json['rankKey'] as String? ?? 'beginner',
      );
}

enum CommentTarget { media, episode, chapter, novelChapter, community }

class CommentItem {
  const CommentItem({
    required this.id,
    required this.content,
    required this.author,
    required this.createdAt,
    this.targetType = CommentTarget.media,
    this.targetId = '',
    this.parentId,
    this.likes = 0,
    this.dislikes = 0,
    this.myReaction = 0,
    this.isPinned = false,
    this.isDeleted = false,
    this.replies = const [],
    this.replyCount = 0,
    this.mentionedUsers = const [],
  });

  final String id;
  final String content;
  final CommentAuthor author;
  final DateTime createdAt;
  final CommentTarget targetType;
  final String targetId;
  final String? parentId;
  final int likes;
  final int dislikes;
  final int myReaction; // 1 like, -1 dislike, 0 none
  final bool isPinned;
  final bool isDeleted;
  final List<CommentItem> replies;
  final int replyCount;
  final List<String> mentionedUsers;

  CommentItem copyWith({
    String? content,
    int? likes,
    int? dislikes,
    int? myReaction,
    bool? isPinned,
    bool? isDeleted,
    List<CommentItem>? replies,
    int? replyCount,
  }) =>
      CommentItem(
        id: id,
        content: content ?? this.content,
        author: author,
        createdAt: createdAt,
        targetType: targetType,
        targetId: targetId,
        parentId: parentId,
        likes: likes ?? this.likes,
        dislikes: dislikes ?? this.dislikes,
        myReaction: myReaction ?? this.myReaction,
        isPinned: isPinned ?? this.isPinned,
        isDeleted: isDeleted ?? this.isDeleted,
        replies: replies ?? this.replies,
        replyCount: replyCount ?? this.replyCount,
        mentionedUsers: mentionedUsers,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'content': content,
        'author': author.toJson(),
        'createdAt': createdAt.toIso8601String(),
        'targetType': targetType.name,
        'targetId': targetId,
        'parentId': parentId,
        'likes': likes,
        'dislikes': dislikes,
        'myReaction': myReaction,
        'isPinned': isPinned,
        'isDeleted': isDeleted,
        'replies': replies.map((e) => e.toJson()).toList(),
        'replyCount': replyCount,
        'mentionedUsers': mentionedUsers,
      };

  factory CommentItem.fromJson(Map<String, dynamic> json) => CommentItem(
        id: json['id']?.toString() ?? '',
        content: json['content'] as String? ?? '',
        author: CommentAuthor.fromJson(
          Map<String, dynamic>.from(json['author'] as Map? ?? const {}),
        ),
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
            DateTime.now(),
        targetType: CommentTarget.values.firstWhere(
          (value) => value.name == json['targetType'],
          orElse: () => CommentTarget.media,
        ),
        targetId: json['targetId']?.toString() ?? '',
        parentId: json['parentId']?.toString(),
        likes: (json['likes'] as num?)?.toInt() ?? 0,
        dislikes: (json['dislikes'] as num?)?.toInt() ?? 0,
        myReaction: (json['myReaction'] as num?)?.toInt() ?? 0,
        isPinned: json['isPinned'] as bool? ?? false,
        isDeleted: json['isDeleted'] as bool? ?? false,
        replies: (json['replies'] as List?)
                ?.map((e) => CommentItem.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
        replyCount: (json['replyCount'] as num?)?.toInt() ?? 0,
        mentionedUsers:
            (json['mentionedUsers'] as List?)?.map((e) => '$e').toList() ?? const [],
      );
}

class ChatMessage {
  const ChatMessage({
    required this.id,
    required this.roomId,
    required this.author,
    required this.text,
    required this.createdAt,
    this.isSystem = false,
  });

  final String id;
  final String roomId;
  final CommentAuthor author;
  final String text;
  final DateTime createdAt;
  final bool isSystem;

  Map<String, dynamic> toJson() => {
        'id': id,
        'roomId': roomId,
        'author': author.toJson(),
        'text': text,
        'createdAt': createdAt.toIso8601String(),
        'isSystem': isSystem,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        id: json['id']?.toString() ?? '',
        roomId: json['roomId'] as String? ?? 'global',
        author: CommentAuthor.fromJson(
          Map<String, dynamic>.from(json['author'] as Map? ?? const {}),
        ),
        text: json['text'] as String? ?? '',
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
            DateTime.now(),
        isSystem: json['isSystem'] as bool? ?? false,
      );
}

enum ReportStatus { open, reviewing, resolved, rejected }

class ContentReport {
  const ContentReport({
    required this.id,
    required this.targetType,
    required this.targetId,
    required this.reason,
    required this.createdAt,
    this.detail = '',
    this.reporterId = '',
    this.reporterName = '',
    this.status = ReportStatus.open,
  });

  final String id;
  final String targetType;
  final String targetId;
  final String reason;
  final String detail;
  final String reporterId;
  final String reporterName;
  final DateTime createdAt;
  final ReportStatus status;

  String get statusLabel {
    switch (status) {
      case ReportStatus.open:
        return 'Baru';
      case ReportStatus.reviewing:
        return 'Ditinjau';
      case ReportStatus.resolved:
        return 'Selesai';
      case ReportStatus.rejected:
        return 'Ditolak';
    }
  }

  ContentReport copyWith({ReportStatus? status}) => ContentReport(
        id: id,
        targetType: targetType,
        targetId: targetId,
        reason: reason,
        detail: detail,
        reporterId: reporterId,
        reporterName: reporterName,
        createdAt: createdAt,
        status: status ?? this.status,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'targetType': targetType,
        'targetId': targetId,
        'reason': reason,
        'detail': detail,
        'reporterId': reporterId,
        'reporterName': reporterName,
        'createdAt': createdAt.toIso8601String(),
        'status': status.name,
      };

  factory ContentReport.fromJson(Map<String, dynamic> json) => ContentReport(
        id: json['id']?.toString() ?? '',
        targetType: json['targetType'] as String? ?? 'comment',
        targetId: json['targetId']?.toString() ?? '',
        reason: json['reason'] as String? ?? 'Lainnya',
        detail: json['detail'] as String? ?? '',
        reporterId: json['reporterId']?.toString() ?? '',
        reporterName: json['reporterName'] as String? ?? '',
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
            DateTime.now(),
        status: ReportStatus.values.firstWhere(
          (value) => value.name == json['status'],
          orElse: () => ReportStatus.open,
        ),
      );
}

class AppNotification {
  const AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.createdAt,
    this.type = NotificationKind.system,
    this.read = false,
    this.payload = const {},
  });

  final String id;
  final String title;
  final String body;
  final DateTime createdAt;
  final NotificationKind type;
  final bool read;
  final Map<String, dynamic> payload;

  AppNotification copyWith({bool? read}) => AppNotification(
        id: id,
        title: title,
        body: body,
        createdAt: createdAt,
        type: type,
        read: read ?? this.read,
        payload: payload,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'createdAt': createdAt.toIso8601String(),
        'type': type.name,
        'read': read,
        'payload': payload,
      };

  factory AppNotification.fromJson(Map<String, dynamic> json) => AppNotification(
        id: json['id']?.toString() ?? '',
        title: json['title'] as String? ?? '',
        body: json['body'] as String? ?? '',
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
            DateTime.now(),
        type: NotificationKind.values.firstWhere(
          (value) => value.name == json['type'],
          orElse: () => NotificationKind.system,
        ),
        read: json['read'] as bool? ?? false,
        payload: Map<String, dynamic>.from(json['payload'] as Map? ?? const {}),
      );
}

enum NotificationKind { newEpisode, newChapter, comment, follow, membership, system }
