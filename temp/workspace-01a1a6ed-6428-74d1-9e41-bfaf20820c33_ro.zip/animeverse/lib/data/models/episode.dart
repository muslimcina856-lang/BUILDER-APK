/// Model episode (anime / donghua / movie) beserta sumber streaming legal.
class EpisodeInfo {
  const EpisodeInfo({
    required this.number,
    required this.title,
    this.id,
    this.thumbnail,
    this.airDate,
    this.duration,
    this.isFiller = false,
    this.hasSource = false,
  });

  final int number;
  final String title;
  final String? id;
  final String? thumbnail;
  final DateTime? airDate;
  final int? duration;
  final bool isFiller;
  final bool hasSource;

  String get label => 'Episode $number';

  EpisodeInfo copyWith({bool? hasSource, String? thumbnail, String? title}) =>
      EpisodeInfo(
        number: number,
        title: title ?? this.title,
        id: id,
        thumbnail: thumbnail ?? this.thumbnail,
        airDate: airDate,
        duration: duration,
        isFiller: isFiller,
        hasSource: hasSource ?? this.hasSource,
      );

  Map<String, dynamic> toJson() => {
        'number': number,
        'title': title,
        'id': id,
        'thumbnail': thumbnail,
        'airDate': airDate?.toIso8601String(),
        'duration': duration,
        'isFiller': isFiller,
        'hasSource': hasSource,
      };

  factory EpisodeInfo.fromJson(Map<String, dynamic> json) => EpisodeInfo(
        number: (json['number'] as num).toInt(),
        title: json['title'] as String? ?? 'Episode ${json['number']}',
        id: json['id'] as String?,
        thumbnail: json['thumbnail'] as String?,
        airDate: json['airDate'] == null
            ? null
            : DateTime.tryParse(json['airDate'] as String),
        duration: (json['duration'] as num?)?.toInt(),
        isFiller: json['isFiller'] as bool? ?? false,
        hasSource: json['hasSource'] as bool? ?? false,
      );
}

/// Track subtitle/audio untuk player.
class MediaTrack {
  const MediaTrack({
    required this.label,
    required this.url,
    this.language = 'id',
    this.isDefault = false,
  });

  final String label;
  final String url;
  final String language;
  final bool isDefault;

  String get shortLabel => label;

  Map<String, dynamic> toJson() => {
        'label': label,
        'url': url,
        'language': language,
        'isDefault': isDefault,
      };

  factory MediaTrack.fromJson(Map<String, dynamic> json) => MediaTrack(
        label: json['label'] as String? ?? 'Default',
        url: json['url'] as String? ?? '',
        language: json['language'] as String? ?? 'id',
        isDefault: json['isDefault'] as bool? ?? false,
      );
}

/// Sumber streaming yang terdaftar admin pada tabel `content_sources`.
/// Hanya URL resmi/berlisensi (HLS/DASH/MP4) yang boleh diisi di sini.
class StreamSource {
  const StreamSource({
    required this.id,
    required this.contentId,
    required this.episodeNumber,
    required this.server,
    required this.url,
    required this.type,
    this.qualities = const [],
    this.subtitles = const [],
    this.audios = const [],
    this.licenseNote,
    this.isOfficial = true,
    this.introStart,
    this.introEnd,
    this.outroStart,
  });

  final String id;
  final String contentId;
  final int episodeNumber;
  final String server;
  final String url;
  final String type; // hls | mp4 | dash
  final List<String> qualities;
  final List<MediaTrack> subtitles;
  final List<MediaTrack> audios;
  final String? licenseNote;
  final bool isOfficial;
  final int? introStart;
  final int? introEnd;
  final int? outroStart;

  Map<String, dynamic> toJson() => {
        'id': id,
        'content_id': contentId,
        'episode_number': episodeNumber,
        'server': server,
        'url': url,
        'type': type,
        'qualities': qualities,
        'subtitles': subtitles.map((e) => e.toJson()).toList(),
        'audios': audios.map((e) => e.toJson()).toList(),
        'license_note': licenseNote,
        'is_official': isOfficial,
        'intro_start': introStart,
        'intro_end': introEnd,
        'outro_start': outroStart,
      };

  factory StreamSource.fromJson(Map<String, dynamic> json) => StreamSource(
        id: json['id'].toString(),
        contentId: json['content_id'].toString(),
        episodeNumber: (json['episode_number'] as num?)?.toInt() ?? 1,
        server: json['server'] as String? ?? 'Server 1',
        url: json['url'] as String? ?? '',
        type: json['type'] as String? ?? 'hls',
        qualities: (json['qualities'] as List?)?.map((e) => '$e').toList() ??
            const [],
        subtitles: (json['subtitles'] as List?)
                ?.map((e) => MediaTrack.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
        audios: (json['audios'] as List?)
                ?.map((e) => MediaTrack.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
        licenseNote: json['license_note'] as String?,
        isOfficial: json['is_official'] as bool? ?? true,
        introStart: (json['intro_start'] as num?)?.toInt(),
        introEnd: (json['intro_end'] as num?)?.toInt(),
        outroStart: (json['outro_start'] as num?)?.toInt(),
      );
}
