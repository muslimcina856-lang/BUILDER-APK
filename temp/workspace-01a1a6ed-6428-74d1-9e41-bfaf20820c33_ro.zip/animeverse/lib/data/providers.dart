import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/services/api_client.dart';
import '../core/services/local_store.dart';
import '../core/services/supabase_gateway.dart';
import '../core/settings/app_settings.dart';
import 'models/community.dart';
import 'models/gamification.dart';
import 'models/library.dart';
import 'models/media.dart';
import 'models/membership.dart';
import 'models/user_profile.dart';
import 'repositories/admin_repository.dart';
import 'repositories/anilist_repository.dart';
import 'repositories/auth_repository.dart';
import 'repositories/community_repository.dart';
import 'repositories/content_service.dart';
import 'repositories/gamification_repository.dart';
import 'repositories/library_repository.dart';
import 'repositories/mangadex_repository.dart';
import 'repositories/membership_repository.dart';
import 'repositories/wikisource_repository.dart';

// ─────────────────────────── Infrastructure ───────────────────────────

final supabaseGatewayProvider = Provider<SupabaseGateway>(
  (ref) => SupabaseGateway.instance,
);

final apiClientProvider = Provider<ApiClient>((ref) => ApiClient());

final anilistRepositoryProvider = Provider<AniListRepository>(
  (ref) => AniListRepository(ref.watch(apiClientProvider)),
);

final mangadexRepositoryProvider = Provider<MangaDexRepository>(
  (ref) => MangaDexRepository(ref.watch(apiClientProvider)),
);

final wikisourceRepositoryProvider = Provider<WikisourceRepository>(
  (ref) => WikisourceRepository(ref.watch(apiClientProvider)),
);

final contentServiceProvider = Provider<ContentService>(
  (ref) => ContentService(
    anilist: ref.watch(anilistRepositoryProvider),
    mangadex: ref.watch(mangadexRepositoryProvider),
    wikisource: ref.watch(wikisourceRepositoryProvider),
    gateway: ref.watch(supabaseGatewayProvider),
  ),
);

final authRepositoryProvider = Provider<AuthRepository>(
  (ref) => AuthRepository(ref.watch(supabaseGatewayProvider)),
);

final libraryRepositoryProvider = Provider<LibraryRepository>(
  (ref) => LibraryRepository(ref.watch(supabaseGatewayProvider)),
);

final communityRepositoryProvider = Provider<CommunityRepository>(
  (ref) => CommunityRepository(ref.watch(supabaseGatewayProvider)),
);

final gamificationRepositoryProvider = Provider<GamificationRepository>(
  (ref) => GamificationRepository(ref.watch(supabaseGatewayProvider)),
);

final membershipRepositoryProvider = Provider<MembershipRepository>(
  (ref) => MembershipRepository(ref.watch(supabaseGatewayProvider)),
);

final adminRepositoryProvider = Provider<AdminRepository>(
  (ref) => AdminRepository(ref.watch(supabaseGatewayProvider)),
);

// ───────────────────────────── Settings ─────────────────────────────

final settingsProvider =
    StateNotifierProvider<SettingsController, AppSettings>((ref) {
  return SettingsController();
});

// ───────────────────────────── Bootstrap ─────────────────────────────

class BootstrapState {
  const BootstrapState({
    this.ready = false,
    this.cloudMode = false,
    this.error,
  });

  final bool ready;
  final bool cloudMode;
  final String? error;
}

/// Inisialisasi aplikasi: penyimpanan lokal, Supabase (opsional), akun demo.
final bootstrapProvider = FutureProvider<BootstrapState>((ref) async {
  await LocalStore.init();
  final gateway = ref.watch(supabaseGatewayProvider);
  final cloudMode = await gateway.initialize();
  final auth = ref.watch(authRepositoryProvider);
  if (!cloudMode) {
    await auth.seedDemoAccounts();
  }
  return BootstrapState(ready: true, cloudMode: cloudMode);
});

// ───────────────────────────── Session ─────────────────────────────

class SessionState {
  const SessionState({
    this.status = SessionStatus.loading,
    this.profile,
    this.error,
    this.cloudMode = false,
  });

  final SessionStatus status;
  final UserProfile? profile;
  final String? error;
  final bool cloudMode;

  bool get isAuthenticated => status == SessionStatus.authenticated && profile != null;
  bool get isAdmin => profile?.role.isAdmin ?? false;
  bool get canModerate => profile?.role.canModerate ?? false;
  bool get isVip => profile?.isVipActive ?? false;

  SessionState copyWith({
    SessionStatus? status,
    UserProfile? profile,
    String? error,
    bool? cloudMode,
    bool clearProfile = false,
  }) =>
      SessionState(
        status: status ?? this.status,
        profile: clearProfile ? null : (profile ?? this.profile),
        error: error,
        cloudMode: cloudMode ?? this.cloudMode,
      );
}

enum SessionStatus { loading, authenticated, unauthenticated }

class SessionController extends StateNotifier<SessionState> {
  SessionController(this._ref) : super(const SessionState()) {
    _boot();
  }

  final Ref _ref;
  bool _initialized = false;

  Future<void> _boot() async {
    final bootstrap = await _ref.read(bootstrapProvider.future);
    final auth = _ref.read(authRepositoryProvider);
    final profile = await auth.restoreSession();
    state = SessionState(
      status: profile == null ? SessionStatus.unauthenticated : SessionStatus.authenticated,
      profile: profile,
      cloudMode: bootstrap.cloudMode,
    );
    _bind(profile);
    _initialized = true;

    if (bootstrap.cloudMode) {
      _watchCloudAuth();
    }
  }

  void _watchCloudAuth() {
    final gateway = _ref.read(supabaseGatewayProvider);
    final stream = gateway.authStateChanges;
    if (stream == null) return;
    stream.listen((authState) async {
      final user = authState.session?.user;
      if (user == null) {
        state = state.copyWith(status: SessionStatus.unauthenticated, clearProfile: true);
        _bind(null);
        return;
      }
      try {
        final profile = await _ref.read(authRepositoryProvider).refreshCloudProfile();
        state = state.copyWith(status: SessionStatus.authenticated, profile: profile);
        _bind(profile);
      } catch (error) {
        debugPrint('[Session] refresh profil gagal: $error');
      }
    });
  }

  void _bind(UserProfile? profile) {
    final library = _ref.read(libraryRepositoryProvider);
    final community = _ref.read(communityRepositoryProvider);
    final gamification = _ref.read(gamificationRepositoryProvider);
    final membership = _ref.read(membershipRepositoryProvider);
    library.bindUser(profile?.id ?? 'guest');
    community.bindUser(profile);
    gamification.bindUser(profile?.id ?? 'guest');
    membership.bindUser(profile);
    if (profile != null) {
      _ref.read(settingsProvider.notifier);
    }
    _ref.invalidate(libraryProvider);
    _ref.invalidate(historyProvider);
    _ref.invalidate(bookmarkProvider);
    _ref.invalidate(favoriteProvider);
    _ref.invalidate(downloadsProvider);
    _ref.invalidate(gamificationProvider);
    _ref.invalidate(membershipProvider);
    _ref.invalidate(paymentsProvider);
    _ref.invalidate(notificationsProvider);
    _ref.invalidate(continueWatchingProvider);
  }

  Future<AuthResult> signIn(String email, String password) async {
    state = state.copyWith(status: SessionStatus.loading);
    final result = await _ref.read(authRepositoryProvider).signIn(email, password);
    if (result.isSuccess) {
      state = SessionState(
        status: SessionStatus.authenticated,
        profile: result.profile,
        cloudMode: state.cloudMode,
      );
      _bind(result.profile);
    } else {
      state = state.copyWith(
        status: SessionStatus.unauthenticated,
        error: result.error,
        clearProfile: true,
      );
    }
    return result;
  }

  Future<AuthResult> signUp({
    required String email,
    required String password,
    required String username,
  }) async {
    final result = await _ref.read(authRepositoryProvider).signUp(
          email: email,
          password: password,
          username: username,
        );
    if (result.isSuccess) {
      state = SessionState(
        status: SessionStatus.authenticated,
        profile: result.profile,
        cloudMode: state.cloudMode,
      );
      _bind(result.profile);
    }
    return result;
  }

  Future<AuthResult> signInWithGoogle() async {
    final result = await _ref.read(authRepositoryProvider).signInWithGoogle();
    if (result.isSuccess) {
      state = SessionState(
        status: SessionStatus.authenticated,
        profile: result.profile,
        cloudMode: state.cloudMode,
      );
      _bind(result.profile);
    }
    return result;
  }

  Future<void> signOut() async {
    await _ref.read(authRepositoryProvider).signOut();
    state = SessionState(
      status: SessionStatus.unauthenticated,
      cloudMode: state.cloudMode,
    );
    _bind(null);
  }

  Future<void> refreshProfile() async {
    final auth = _ref.read(authRepositoryProvider);
    UserProfile? profile;
    if (state.cloudMode) {
      try {
        profile = await auth.refreshCloudProfile();
      } catch (_) {
        profile = await auth.restoreSession();
      }
    } else {
      profile = await auth.restoreSession();
    }
    if (profile != null) {
      state = state.copyWith(profile: profile, status: SessionStatus.authenticated);
      _bind(profile);
    }
  }

  Future<void> applyProfile(UserProfile profile) async {
    state = state.copyWith(profile: profile, status: SessionStatus.authenticated);
    _bind(profile);
  }

  bool get isReady => _initialized;
}

final sessionProvider =
    StateNotifierProvider<SessionController, SessionState>((ref) {
  return SessionController(ref);
});

/// Profil aktif (null jika belum login).
final currentProfileProvider = Provider<UserProfile?>(
  (ref) => ref.watch(sessionProvider).profile,
);

final isAdminProvider = Provider<bool>(
  (ref) => ref.watch(sessionProvider).isAdmin,
);

// ───────────────────────────── Library ─────────────────────────────

final libraryProvider = FutureProvider<List<LibraryEntry>>((ref) async {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return ref.watch(libraryRepositoryProvider).library();
});

final bookmarkProvider = FutureProvider<List<LibraryEntry>>((ref) async {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return ref.watch(libraryRepositoryProvider).library(kind: LibraryKind.bookmark);
});

final favoriteProvider = FutureProvider<List<LibraryEntry>>((ref) async {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return ref.watch(libraryRepositoryProvider).library(kind: LibraryKind.favorite);
});

final historyProvider = FutureProvider<List<HistoryEntry>>((ref) async {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return ref.watch(libraryRepositoryProvider).history();
});

final continueWatchingProvider = FutureProvider<List<HistoryEntry>>((ref) async {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return ref.watch(libraryRepositoryProvider).continueWatching();
});

final downloadsProvider = FutureProvider<List<DownloadTask>>((ref) async {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return ref.watch(libraryRepositoryProvider).downloads();
});

final isBookmarkedProvider = Provider.family<bool, String>((ref, mediaId) {
  final entries = ref.watch(bookmarkProvider).valueOrNull ?? const [];
  return entries.any((entry) => entry.media.id == mediaId);
});

final isFavoriteProvider = Provider.family<bool, String>((ref, mediaId) {
  final entries = ref.watch(favoriteProvider).valueOrNull ?? const [];
  return entries.any((entry) => entry.media.id == mediaId);
});

// ───────────────────────────── Content ─────────────────────────────

final trendingProvider =
    FutureProvider.family<List<MediaItem>, MediaKind>((ref, kind) {
  return ref.watch(contentServiceProvider).trending(kind);
});

final popularProvider =
    FutureProvider.family<List<MediaItem>, MediaKind>((ref, kind) {
  return ref.watch(contentServiceProvider).popularNow(kind);
});

final topRatedProvider =
    FutureProvider.family<List<MediaItem>, MediaKind>((ref, kind) {
  return ref.watch(contentServiceProvider).topRated(kind);
});

final seasonProvider =
    FutureProvider.family<List<MediaItem>, MediaKind>((ref, kind) {
  return ref.watch(contentServiceProvider).thisSeason(kind);
});

final upcomingProvider =
    FutureProvider.family<List<MediaItem>, MediaKind>((ref, kind) {
  return ref.watch(contentServiceProvider).upcoming(kind);
});

final recentlyUpdatedProvider =
    FutureProvider.family<List<MediaItem>, MediaKind>((ref, kind) {
  return ref.watch(contentServiceProvider).recentlyUpdated(kind);
});

final scheduleProvider = FutureProvider<List<ScheduleSlot>>((ref) {
  return ref.watch(contentServiceProvider).schedule();
});

final mediaDetailProvider =
    FutureProvider.family<MediaItem?, ({String id, MediaKind kind})>((ref, args) {
  return ref.watch(contentServiceProvider).detail(args.id, args.kind);
});

final recommendationsProvider =
    FutureProvider.family<List<MediaItem>, MediaItem>((ref, media) {
  return ref.watch(contentServiceProvider).recommendations(media);
});

final episodesProvider =
    FutureProvider.family<List<EpisodeInfo>, MediaItem>((ref, media) {
  return ref.watch(contentServiceProvider).episodes(media);
});

final chaptersProvider =
    FutureProvider.family<List<ChapterInfo>, MediaItem>((ref, media) {
  return ref.watch(contentServiceProvider).chapters(media);
});

final novelChaptersProvider =
    FutureProvider.family<List<NovelChapter>, MediaItem>((ref, media) {
  return ref.watch(contentServiceProvider).novelChapters(media);
});

final personalizedProvider =
    FutureProvider.family<List<MediaItem>, MediaKind>((ref, kind) async {
  final library = ref.watch(libraryRepositoryProvider);
  final genres = library.preferredGenres();
  return ref.watch(contentServiceProvider).personalized(
        preferredGenres: genres,
        kind: kind,
      );
});

// ───────────────────────────── Community ─────────────────────────────

final commentsProvider = FutureProvider.family<List<CommentItem>, ({CommentTarget target, String id})>(
  (ref, args) {
    return ref.watch(communityRepositoryProvider).comments(
          target: args.target,
          targetId: args.id,
        );
  },
);

final communityFeedProvider = FutureProvider<List<CommentItem>>((ref) {
  return ref.watch(communityRepositoryProvider).recentActivity();
});

final notificationsProvider = FutureProvider<List<AppNotification>>((ref) {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return Future.value(ref.watch(communityRepositoryProvider).notifications());
});

final unreadNotificationProvider = Provider<int>((ref) {
  final list = ref.watch(notificationsProvider).valueOrNull ?? const [];
  return list.where((item) => !item.read).length;
});

// ───────────────────────────── Gamifikasi ─────────────────────────────

final gamificationProvider = FutureProvider<GamificationState>((ref) async {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  final repo = ref.watch(gamificationRepositoryProvider);
  final library = ref.watch(libraryRepositoryProvider);
  final stats = library.localStats();
  var state = await repo.load();
  state = await repo.syncAchievements(UserStats(
    episodesWatched: stats['episodesWatched'] ?? 0,
    watchMinutes: stats['watchMinutes'] ?? 0,
    chaptersRead: stats['chaptersRead'] ?? 0,
    novelsRead: stats['novelsRead'] ?? 0,
    comments: ref.watch(currentProfileProvider)?.stats.comments ?? 0,
    bookmarks: stats['bookmarks'] ?? 0,
  ));
  return state;
});

final leaderboardProvider =
    FutureProvider.family<List<LeaderboardEntry>, String>((ref, period) async {
  final session = ref.watch(sessionProvider);
  final gamification = ref.watch(gamificationProvider).valueOrNull;
  return ref.watch(gamificationRepositoryProvider).leaderboard(
        period: period,
        currentUserId: session.profile?.id ?? '',
        currentExp: gamification?.exp ?? 0,
      );
});

// ───────────────────────────── Membership ─────────────────────────────

final membershipProvider = FutureProvider<MembershipStatus>((ref) {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return ref.watch(membershipRepositoryProvider).status();
});

final paymentsProvider = FutureProvider<List<PaymentRecord>>((ref) {
  ref.watch(sessionProvider.select((state) => state.profile?.id));
  return ref.watch(membershipRepositoryProvider).payments();
});

// ───────────────────────────── Admin ─────────────────────────────

final adminStatsProvider = FutureProvider<AdminStats>((ref) {
  return ref.watch(adminRepositoryProvider).stats();
});

final adminUsersProvider = FutureProvider.family<List<UserProfile>, String>((ref, query) {
  return ref.watch(adminRepositoryProvider).users(query: query);
});

final adminReportsProvider = FutureProvider<List<ContentReport>>((ref) {
  return Future.value(ref.watch(communityRepositoryProvider).reports());
});

final adminBannersProvider = FutureProvider<List<BannerItem>>((ref) {
  return ref.watch(adminRepositoryProvider).cloudBanners();
});

final adminSourcesProvider = FutureProvider<List<dynamic>>((ref) {
  return Future.value(ref.watch(adminRepositoryProvider).sourcesList());
});

final adminTransactionsProvider = FutureProvider<List<PaymentRecord>>((ref) {
  return ref.watch(membershipRepositoryProvider).allTransactions();
});

final adminSettingsProvider = FutureProvider<Map<String, dynamic>>((ref) {
  return Future.value(ref.watch(adminRepositoryProvider).settings());
});
