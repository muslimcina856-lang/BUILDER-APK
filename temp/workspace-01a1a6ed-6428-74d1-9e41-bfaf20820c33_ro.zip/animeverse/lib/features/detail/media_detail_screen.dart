import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/chapter.dart';
import '../../data/models/community.dart';
import '../../data/models/episode.dart';
import '../../data/models/library.dart';
import '../../data/models/media.dart';
import '../../data/models/user_profile.dart';
import '../../data/providers.dart';
import '../../shared/widgets/app_network_image.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/shimmer.dart';
import '../../shared/widgets/user_avatar.dart';
import '../community/comment_section.dart';

class MediaDetailScreen extends ConsumerStatefulWidget {
  const MediaDetailScreen({
    super.key,
    required this.mediaId,
    required this.kindSlug,
  });

  final String mediaId;
  final String kindSlug;

  @override
  ConsumerState<MediaDetailScreen> createState() => _MediaDetailScreenState();
}

class _MediaDetailScreenState extends ConsumerState<MediaDetailScreen> {
  int _section = 0;
  MediaItem? _media;
  bool _loading = true;
  String? _error;
  List<EpisodeInfo> _episodes = const [];
  List<ChapterInfo> _chapters = const [];
  List<NovelChapter> _novelChapters = const [];
  List<Map<String, dynamic>> _recommendations = const [];
  List<Map<String, dynamic>> _relations = const [];
  List<Map<String, dynamic>> _links = const [];
  bool _hasStreaming = false;

  MediaKind get _kind => MediaKind.fromSlug(widget.kindSlug);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final service = ref.read(contentServiceProvider);
    try {
      final media = await service.detail(widget.mediaId, _kind);
      if (media == null) {
        setState(() {
          _loading = false;
          _error = 'Detail judul tidak ditemukan pada sumber data.';
        });
        return;
      }
      var episodes = <EpisodeInfo>[];
      var chapters = <ChapterInfo>[];
      var novelChapters = <NovelChapter>[];
      var hasStreaming = false;
      if (media.kind.isVideo) {
        episodes = await service.episodes(media);
        hasStreaming = await service.hasStreaming(media.id);
      } else if (media.kind.isComic) {
        chapters = await service.chapters(media);
      } else {
        novelChapters = await service.novelChapters(media);
      }
      final recommendations = await service.recommendations(media);
      final relations = await service.relations(media);
      final links = await service.externalLinks(media);
      if (!mounted) return;
      setState(() {
        _media = media;
        _episodes = episodes;
        _chapters = chapters;
        _novelChapters = novelChapters;
        _hasStreaming = hasStreaming;
        _recommendations = recommendations
            .map((item) => {'media': item.toJson()})
            .toList();
        _relations = relations;
        _links = links;
        _loading = false;
        _section = 0;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '$error';
      });
    }
  }

  Future<void> _toggleBookmark() async {
    final media = _media;
    if (media == null) return;
    if (!ref.read(sessionProvider).isAuthenticated) {
      context.push('/login?redirect=${Uri.encodeComponent('/home')}');
      return;
    }
    final added = await ref.read(libraryRepositoryProvider).toggleBookmark(media);
    ref.invalidate(bookmarkProvider);
    ref.invalidate(libraryProvider);
    if (added) {
      await ref.read(gamificationRepositoryProvider).awardExp(
            amount: 5,
            category: 'social',
            reason: 'Bookmark baru',
            questId: 'daily_bookmark',
            questProgress: 1,
          );
      ref.invalidate(gamificationProvider);
    }
    if (mounted) {
      showSnack(context, added ? 'Ditambahkan ke bookmark' : 'Dihapus dari bookmark');
    }
  }

  Future<void> _toggleFavorite() async {
    final media = _media;
    if (media == null) return;
    if (!ref.read(sessionProvider).isAuthenticated) {
      context.push('/login');
      return;
    }
    final added = await ref.read(libraryRepositoryProvider).toggleFavorite(media);
    ref.invalidate(favoriteProvider);
    if (mounted) {
      showSnack(context, added ? 'Ditambahkan ke favorit' : 'Dihapus dari favorit');
    }
  }

  Future<void> _openReport() async {
    const reasons = ['Konten tidak tersedia', 'Metadata salah', 'Konten tidak pantas', 'Pelanggaran hak cipta', 'Lainnya'];
    final reason = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Laporkan konten', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            for (final reason in reasons)
              ListTile(
                title: Text(reason, style: const TextStyle(fontSize: 13.5)),
                onTap: () => Navigator.pop(context, reason),
              ),
          ],
        ),
      ),
    );
    if (reason == null || _media == null) return;
    await ref.read(communityRepositoryProvider).reportContent(
          targetType: _media!.kind.slug,
          targetId: _media!.id,
          reason: reason,
        );
    if (mounted) showSnack(context, 'Laporan terkirim, terima kasih.');
  }

  Future<void> _openPrimary() async {
    final media = _media;
    if (media == null) return;
    if (media.kind.isVideo) {
      final history = await ref.read(libraryRepositoryProvider).findHistory(media.id);
      final episode = history?.episodeNumber ?? 1;
      if (!mounted) return;
      AppNav.watch(
        context,
        mediaId: media.id,
        kind: media.kind,
        episode: episode,
        title: media.title,
      );
    } else if (media.kind.isComic) {
      if (_chapters.isEmpty) {
        _showUnavailable(
          'Chapter belum tersedia',
          'Sumber chapter untuk judul ini belum tersedia. Kami hanya menampilkan '
          'chapter dari penyedia yang mengizinkan distribusi.',
        );
        return;
      }
      final chapter = _chapters.first;
      AppNav.readComic(
        context,
        mediaId: media.id,
        chapterId: chapter.id,
        kind: media.kind,
        title: media.title,
        chapterNumber: '${chapter.number}',
      );
    } else {
      if (_novelChapters.isEmpty) {
        _showUnavailable(
          'Teks novel belum tersedia',
          'Novel ini baru tersedia metadatanya. Teks lengkap hanya tersedia untuk '
          'karya domain publik yang tersedia di Wikisource.',
        );
        return;
      }
      final history = await ref.read(libraryRepositoryProvider).findHistory(media.id);
      final index = history?.chapterNumber?.toInt() ?? 1;
      if (!mounted) return;
      AppNav.readNovel(
        context,
        mediaId: media.id,
        index: index,
        title: media.title,
      );
    }
  }

  void _showUnavailable(String title, String message) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.info_outline_rounded, color: AppColors.gold, size: 20),
            const SizedBox(width: 8),
            Expanded(child: Text(title, style: const TextStyle(fontSize: 16))),
          ],
        ),
        content: Text(message, style: const TextStyle(fontSize: 13, height: 1.6)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Mengerti'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: SafeArea(child: DetailSkeleton()));
    }
    if (_error != null || _media == null) {
      return Scaffold(
        appBar: AppBar(leading: const BackButton()),
        body: EmptyState(
          title: 'Gagal memuat detail',
          message: _error,
          icon: Icons.cloud_off_rounded,
          actionLabel: 'Coba lagi',
          onAction: _load,
        ),
      );
    }
    final media = _media!;
    final isBookmarked = ref.watch(isBookmarkedProvider(media.id));
    final isFavorite = ref.watch(isFavoriteProvider(media.id));
    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverAppBar(
            expandedHeight: 330,
            pinned: true,
            stretch: true,
            backgroundColor: AppColors.background,
            leading: _GlassIconButton(
              icon: Icons.arrow_back_rounded,
              onTap: () => AppNav.back(context),
            ),
            actions: [
              _GlassIconButton(
                icon: Icons.share_rounded,
                onTap: () => _share(media),
              ),
              _GlassIconButton(
                icon: Icons.flag_outlined,
                onTap: _openReport,
              ),
              const SizedBox(width: 8),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: _HeroBackground(media: media),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    media.title,
                    style: const TextStyle(
                      fontSize: 23,
                      height: 1.2,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                      letterSpacing: -0.4,
                    ),
                  ),
                  if (media.titleNative != null && media.titleNative!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        media.titleNative!,
                        style: const TextStyle(
                          fontSize: 12.5,
                          color: AppColors.textMuted,
                        ),
                      ),
                    ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      if (media.score != null)
                        SourcePill(
                          label: '★ ${media.scoreLabel}',
                          icon: Icons.star_rounded,
                          color: AppColors.gold,
                        ),
                      SourcePill(
                        label: media.statusLabel,
                        icon: Icons.circle,
                        color: media.isAiring ? AppColors.success : AppColors.textMuted,
                      ),
                      SourcePill(
                        label: media.formatLabel,
                        icon: Icons.movie_filter_rounded,
                      ),
                      if (media.year != null)
                        SourcePill(
                          label: '${media.year}',
                          icon: Icons.calendar_today_rounded,
                        ),
                      if (media.isVideo && media.episodes != null)
                        SourcePill(
                          label: '${media.episodes} episode',
                          icon: Icons.playlist_play_rounded,
                        ),
                      if (media.kind.isComic && _chapters.isNotEmpty)
                        SourcePill(
                          label: '${_chapters.length} chapter',
                          icon: Icons.menu_book_rounded,
                        ),
                      if (media.kind == MediaKind.novel &&
                          _novelChapters.isNotEmpty)
                        SourcePill(
                          label: '${_novelChapters.length} bab',
                          icon: Icons.book_rounded,
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: FilledButton.icon(
                          onPressed: _openPrimary,
                          icon: Icon(
                            media.kind.isVideo
                                ? Icons.play_arrow_rounded
                                : Icons.chrome_reader_mode_rounded,
                            size: 20,
                          ),
                          label: Text(
                            media.kind.isVideo
                                ? 'Tonton Sekarang'
                                : media.kind.isComic
                                    ? 'Baca Chapter 1'
                                    : 'Mulai Membaca',
                          ),
                          style: FilledButton.styleFrom(
                            backgroundColor: AppColors.violet,
                            minimumSize: const Size(0, 50),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _ActionIcon(
                        icon: isBookmarked
                            ? Icons.bookmark_rounded
                            : Icons.bookmark_border_rounded,
                        active: isBookmarked,
                        onTap: _toggleBookmark,
                        tooltip: 'Bookmark',
                      ),
                      const SizedBox(width: 8),
                      _ActionIcon(
                        icon: isFavorite
                            ? Icons.favorite_rounded
                            : Icons.favorite_border_rounded,
                        active: isFavorite,
                        onTap: _toggleFavorite,
                        tooltip: 'Favorit',
                      ),
                    ],
                  ),
                  if (media.kind.isVideo && !_hasStreaming)
                    Padding(
                      padding: const EdgeInsets.only(top: 14),
                      child: _NoticeCard(
                        icon: Icons.info_outline_rounded,
                        color: AppColors.gold,
                        title: 'Streaming belum tersedia',
                        message:
                            'Episode untuk judul ini belum memiliki sumber video resmi '
                            'yang terdaftar. ANIMEVERSE hanya memutar video dari sumber '
                            'berlisensi; silakan gunakan tautan platform resmi di tab Info.',
                      ),
                    ),
                  if (media.kind.isComic && _chapters.isEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 14),
                      child: _NoticeCard(
                        icon: Icons.info_outline_rounded,
                        color: AppColors.info,
                        title: 'Chapter belum tersedia',
                        message:
                            'Belum ada chapter berbahasa Indonesia/Inggris yang dapat '
                            'ditampilkan untuk judul ini pada penyedia data.',
                      ),
                    ),
                  if (media.kind == MediaKind.novel && _novelChapters.isEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 14),
                      child: _NoticeCard(
                        icon: Icons.menu_book_rounded,
                        color: AppColors.violetNeon,
                        title: 'Teks belum tersedia',
                        message:
                            'Judul ini hanya tersedia sebagai metadata. Untuk membaca '
                            'karya domain publik, buka kategori Novel.',
                      ),
                    ),
                  const SizedBox(height: 18),
                  _SectionSwitcher(
                    labels: media.kind.isVideo
                        ? ['Episode', 'Info', 'Komentar']
                        : ['Chapter', 'Info', 'Komentar'],
                    index: _section,
                    onChanged: (index) => setState(() => _section = index),
                  ),
                  const SizedBox(height: 16),
                  _buildSection(media),
                  const SizedBox(height: 28),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(MediaItem media) {
    switch (_section) {
      case 0:
        return media.kind.isVideo
            ? _EpisodeList(
                media: media,
                episodes: _episodes,
                onTap: (episode) {
                  if (!_hasStreaming) {
                    _showUnavailable(
                      'Episode belum tersedia',
                      'Sumber video resmi untuk episode ${episode.number} belum '
                      'didaftarkan. Hubungi admin jika Anda pemegang lisensi.',
                    );
                    return;
                  }
                  AppNav.watch(
                    context,
                    mediaId: media.id,
                    kind: media.kind,
                    episode: episode.number,
                    title: media.title,
                  );
                },
              )
            : media.kind.isComic
                ? _ChapterList(
                    media: media,
                    chapters: _chapters,
                    onTap: (chapter) => AppNav.readComic(
                      context,
                      mediaId: media.id,
                      chapterId: chapter.id,
                      kind: media.kind,
                      title: media.title,
                      chapterNumber: '${chapter.number}',
                    ),
                  )
                : _NovelChapterList(
                    media: media,
                    chapters: _novelChapters,
                    onTap: (chapter) => AppNav.readNovel(
                      context,
                      mediaId: media.id,
                      index: chapter.index,
                      title: media.title,
                    ),
                  );
      case 1:
        return _InfoTab(
          media: media,
          relations: _relations,
          links: _links,
          recommendations: _recommendations,
        );
      default:
        return CommentSection(
          target: CommentTarget.media,
          targetId: media.id,
          title: 'Komentar',
        );
    }
  }

  Future<void> _share(MediaItem media) async {
    final url = media.siteUrl ??
        'https://animeverse.app/media/${Uri.encodeComponent(media.id)}';
    await showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Bagikan', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            ListTile(
              leading: const Icon(Icons.link_rounded),
              title: const Text('Buka tautan sumber'),
              subtitle: Text(url, maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: () async {
                Navigator.pop(context);
                final uri = Uri.tryParse(url);
                if (uri != null && await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.copy_rounded),
              title: const Text('Salin tautan'),
              onTap: () {
                Navigator.pop(context);
                showSnack(context, 'Tautan disalin: $url');
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroBackground extends StatelessWidget {
  const _HeroBackground({required this.media});

  final MediaItem media;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        AppNetworkImage(
          url: media.bannerUrl ?? media.coverUrl,
          fit: BoxFit.cover,
        ),
        const DecoratedBox(
          decoration: BoxDecoration(gradient: AppColors.heroScrim),
        ),
        Positioned(
          left: 20,
          right: 20,
          bottom: 16,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: SizedBox(
                  width: 92,
                  height: 132,
                  child: AppNetworkImage(url: media.coverUrl),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        GradientBadge(label: media.kind.label, icon: media.kind.icon),
                        if (media.studio != null) ...[
                          const SizedBox(width: 6),
                          Flexible(
                            child: Text(
                              media.studio!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 10.5,
                                color: Colors.white.withValues(alpha: 0.8),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      media.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        height: 1.25,
                      ),
                    ),
                    if (media.genres.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          media.genres.take(3).join(' • '),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10.5,
                            color: Colors.white.withValues(alpha: 0.7),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _GlassIconButton extends StatelessWidget {
  const _GlassIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: GestureDetector(
        onTap: onTap,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              width: 36,
              height: 36,
              margin: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.32),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withValues(alpha: 0.18)),
              ),
              child: Icon(icon, size: 18, color: Colors.white),
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionIcon extends StatelessWidget {
  const _ActionIcon({
    required this.icon,
    required this.onTap,
    this.active = false,
    this.tooltip,
  });

  final IconData icon;
  final VoidCallback onTap;
  final bool active;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final button = GestureDetector(
      onTap: onTap,
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: active
              ? AppColors.violet.withValues(alpha: 0.25)
              : AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: active ? AppColors.violet : AppColors.border,
          ),
        ),
        child: Icon(
          icon,
          size: 22,
          color: active ? AppColors.violetNeon : AppColors.textSecondary,
        ),
      ),
    );
    if (tooltip == null) return button;
    return Tooltip(message: tooltip!, child: button);
  }
}

class _SectionSwitcher extends StatelessWidget {
  const _SectionSwitcher({
    required this.labels,
    required this.index,
    required this.onChanged,
  });

  final List<String> labels;
  final int index;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: GestureDetector(
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    gradient: index == i ? AppColors.brandGradient : null,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      labels[i],
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: index == i ? Colors.white : AppColors.textSecondary,
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _EpisodeList extends ConsumerWidget {
  const _EpisodeList({
    required this.media,
    required this.episodes,
    required this.onTap,
  });

  final MediaItem media;
  final List<EpisodeInfo> episodes;
  final void Function(EpisodeInfo episode) onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (episodes.isEmpty) {
      return const _EmptyBlock(
        icon: Icons.playlist_remove_rounded,
        message: 'Daftar episode belum tersedia dari sumber data.',
      );
    }
    final history = ref.watch(historyProvider).valueOrNull ?? const [];
    final lastEpisode = history
        .where((entry) => entry.media.id == media.id)
        .map((entry) => entry.episodeNumber ?? 0)
        .fold<int>(0, (previous, current) => current > previous ? current : previous);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Daftar Episode',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const Spacer(),
            if (lastEpisode > 0)
              SourcePill(
                label: 'Terakhir E$lastEpisode',
                icon: Icons.history_rounded,
                color: AppColors.info,
              ),
          ],
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 74,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 1.7,
          ),
          itemCount: episodes.length,
          itemBuilder: (context, index) {
            final episode = episodes[index];
            final isLast = episode.number == lastEpisode;
            return GestureDetector(
              onTap: () => onTap(episode),
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: isLast
                      ? AppColors.violet.withValues(alpha: 0.28)
                      : AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isLast ? AppColors.violet : AppColors.border,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${episode.number}',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: episode.hasSource
                            ? AppColors.textPrimary
                            : AppColors.textMuted,
                      ),
                    ),
                    if (!episode.hasSource)
                      const Icon(
                        Icons.lock_outline_rounded,
                        size: 9,
                        color: AppColors.textMuted,
                      ),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 10),
        Text(
          'Ikon gembok = sumber video resmi belum tersedia untuk episode tersebut.',
          style: TextStyle(
            fontSize: 10,
            color: AppColors.textMuted.withValues(alpha: 0.9),
          ),
        ),
      ],
    );
  }
}

class _ChapterList extends StatelessWidget {
  const _ChapterList({
    required this.media,
    required this.chapters,
    required this.onTap,
  });

  final MediaItem media;
  final List<ChapterInfo> chapters;
  final void Function(ChapterInfo chapter) onTap;

  @override
  Widget build(BuildContext context) {
    if (chapters.isEmpty) {
      return const _EmptyBlock(
        icon: Icons.menu_book_rounded,
        message: 'Belum ada chapter yang dapat ditampilkan.',
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              '${chapters.length} Chapter',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const Spacer(),
            SourcePill(
              label: chapters.first.language == 'id' ? 'Bahasa Indonesia' : 'English',
              icon: Icons.translate_rounded,
              color: AppColors.info,
            ),
          ],
        ),
        const SizedBox(height: 10),
        ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 420),
          child: ListView.separated(
            shrinkWrap: true,
            physics: const BouncingScrollPhysics(),
            itemCount: chapters.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final chapter = chapters[index];
              return SoftCard(
                onTap: () => onTap(chapter),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppColors.violet.withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        chapter.number == chapter.number.roundToDouble()
                            ? '${chapter.number.toInt()}'
                            : '${chapter.number}',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          color: AppColors.violetNeon,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            chapter.title.isEmpty ? chapter.label : chapter.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            [
                              if (chapter.group != null) chapter.group!,
                              '${chapter.pages} halaman',
                              Fmt.relative(chapter.publishedAt),
                            ].join(' • '),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 10,
                              color: AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.chevron_right_rounded,
                      size: 18,
                      color: AppColors.textMuted,
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _NovelChapterList extends StatelessWidget {
  const _NovelChapterList({
    required this.media,
    required this.chapters,
    required this.onTap,
  });

  final MediaItem media;
  final List<NovelChapter> chapters;
  final void Function(NovelChapter chapter) onTap;

  @override
  Widget build(BuildContext context) {
    if (chapters.isEmpty) {
      return const _EmptyBlock(
        icon: Icons.book_rounded,
        message: 'Teks bab belum tersedia untuk judul ini.',
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              '${chapters.length} Bab',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const Spacer(),
            SourcePill(
              label: 'Domain publik',
              icon: Icons.verified_rounded,
              color: AppColors.success,
            ),
          ],
        ),
        const SizedBox(height: 10),
        ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 420),
          child: ListView.separated(
            shrinkWrap: true,
            physics: const BouncingScrollPhysics(),
            itemCount: chapters.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final chapter = chapters[index];
              return SoftCard(
                onTap: () => onTap(chapter),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Row(
                  children: [
                    const Icon(
                      Icons.article_outlined,
                      size: 18,
                      color: AppColors.violetNeon,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        chapter.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 12.5,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                    const Icon(
                      Icons.chevron_right_rounded,
                      size: 18,
                      color: AppColors.textMuted,
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _InfoTab extends StatelessWidget {
  const _InfoTab({
    required this.media,
    required this.relations,
    required this.links,
    required this.recommendations,
  });

  final MediaItem media;
  final List<Map<String, dynamic>> relations;
  final List<Map<String, dynamic>> links;
  final List<Map<String, dynamic>> recommendations;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Sinopsis',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          media.description?.isNotEmpty == true
              ? media.description!
              : 'Sinopsis belum tersedia untuk judul ini.',
          style: const TextStyle(
            fontSize: 12.5,
            height: 1.7,
            color: AppColors.textSecondary,
          ),
        ),
        if (media.genres.isNotEmpty) ...[
          const SizedBox(height: 18),
          const Text(
            'Genre',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final genre in media.genres)
                SourcePill(label: genre, icon: Icons.tag_rounded),
            ],
          ),
        ],
        const SizedBox(height: 18),
        SoftCard(
          child: Column(
            children: [
              _InfoRow('Judul asli', media.titleNative ?? '—'),
              _InfoRow('Studio / Penulis', media.studio ?? '—'),
              _InfoRow('Format', media.formatLabel),
              _InfoRow('Status', media.statusLabel),
              _InfoRow('Musim', Fmt.season(media.year, media.season)),
              if (media.kind.isVideo)
                _InfoRow('Durasi', '${media.duration ?? 24} menit/episode')
              else if (media.kind.isComic)
                _InfoRow('Volume', '${media.volumes ?? '—'}'),
              _InfoRow(
                'Sumber data',
                media.source.name == 'anilist'
                    ? 'AniList (metadata resmi)'
                    : media.source.name == 'mangadex'
                        ? 'MangaDex'
                        : 'Wikisource Indonesia',
              ),
            ],
          ),
        ),
        if (relations.isNotEmpty) ...[
          const SizedBox(height: 18),
          const Text(
            'Judul Terkait',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          for (final relation in relations.take(4))
            if (relation['media'] is Map)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: SoftCard(
                  padding: const EdgeInsets.all(10),
                  onTap: () => AppNav.media(
                    context,
                    MediaItem.fromJson(
                      Map<String, dynamic>.from(relation['media'] as Map),
                    ),
                  ),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: SizedBox(
                          width: 42,
                          height: 58,
                          child: AppNetworkImage(
                            url: (relation['media'] as Map)['coverUrl'] as String?,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              (relation['media'] as Map)['title']?.toString() ??
                                  'Tanpa judul',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '${relation['relationType']}',
                              style: const TextStyle(
                                fontSize: 10,
                                color: AppColors.textMuted,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
        ],
        if (links.isNotEmpty) ...[
          const SizedBox(height: 18),
          const Text(
            'Platform Resmi',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Tonton/baca melalui platform berlisensi berikut.',
            style: TextStyle(fontSize: 10.5, color: AppColors.textMuted),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final link in links.take(6))
                ActionChip(
                  avatar: const Icon(Icons.open_in_new_rounded, size: 14),
                  label: Text('${link['site'] ?? 'Buka'}'),
                  onPressed: () async {
                    final uri = Uri.tryParse('${link['url']}');
                    if (uri != null && await canLaunchUrl(uri)) {
                      await launchUrl(uri, mode: LaunchMode.externalApplication);
                    }
                  },
                ),
            ],
          ),
        ],
        if (recommendations.isNotEmpty) ...[
          const SizedBox(height: 22),
          const Text(
            'Rekomendasi Serupa',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 240,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: recommendations.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final item = MediaItem.fromJson(
                  Map<String, dynamic>.from(recommendations[index]['media'] as Map),
                );
                return PosterCard(
                  media: item,
                  width: 112,
                  onTap: () => AppNav.media(context, item),
                );
              },
            ),
          ),
        ],
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(fontSize: 11.5, color: AppColors.textMuted),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NoticeCard extends StatelessWidget {
  const _NoticeCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.message,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.32)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  message,
                  style: const TextStyle(
                    fontSize: 11,
                    height: 1.6,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyBlock extends StatelessWidget {
  const _EmptyBlock({required this.icon, required this.message});

  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Icon(icon, size: 26, color: AppColors.textMuted),
          const SizedBox(height: 8),
          Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
          ),
        ],
      ),
    );
  }
}
