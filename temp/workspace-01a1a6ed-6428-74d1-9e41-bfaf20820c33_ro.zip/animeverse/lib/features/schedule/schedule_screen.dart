import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/navigation.dart';
import '../../data/providers.dart';
import '../../data/repositories/anilist_repository.dart';
import '../../shared/widgets/app_network_image.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/widgets.dart';

class ScheduleScreen extends ConsumerWidget {
  const ScheduleScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final schedule = ref.watch(scheduleProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Jadwal Rilis')),
      body: schedule.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => EmptyState(
          title: 'Gagal memuat jadwal',
          message: '$error',
          icon: Icons.cloud_off_rounded,
          actionLabel: 'Coba lagi',
          onAction: () => ref.invalidate(scheduleProvider),
        ),
        data: (slots) {
          if (slots.isEmpty) {
            return const EmptyState(
              title: 'Tidak ada jadwal',
              message: 'Belum ada anime yang dijadwalkan tayang minggu ini.',
              icon: Icons.event_busy_rounded,
            );
          }
          final grouped = <String, List<ScheduleSlot>>{};
          for (final slot in slots) {
            final key = Fmt.date(slot.airingAt, pattern: 'EEEE, d MMM');
            grouped.putIfAbsent(key, () => []).add(slot);
          }
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
            children: [
              GlassCard(
                child: Row(
                  children: [
                    const Icon(Icons.info_outline_rounded,
                        size: 16, color: AppColors.violetNeon),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'Jadwal berdasarkan data AniList untuk 7 hari ke depan '
                        'dan diperbarui otomatis setiap 3 jam.',
                        style: TextStyle(
                          fontSize: 10.5,
                          height: 1.5,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              for (final entry in grouped.entries) ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
                  child: Text(
                    entry.key,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
                for (final slot in entry.value)
                  SoftCard(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(10),
                    onTap: () => AppNav.media(context, slot.media),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            width: 46,
                            height: 62,
                            child: AppNetworkImage(url: slot.media.coverUrl),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                slot.media.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                'Episode ${slot.episode} • '
                                '${Fmt.date(slot.airingAt, pattern: 'HH:mm')} WIB',
                                style: const TextStyle(
                                  fontSize: 10,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SourcePill(
                          label: Fmt.countdown(slot.airingAt),
                          icon: Icons.timer_outlined,
                          color: AppColors.gold,
                        ),
                      ],
                    ),
                  ),
              ],
            ],
          );
        },
      ),
    );
  }
}
