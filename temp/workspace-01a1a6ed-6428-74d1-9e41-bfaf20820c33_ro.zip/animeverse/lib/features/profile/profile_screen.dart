import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/gamification.dart';
import '../../data/models/library.dart';
import '../../data/models/media.dart';
import '../../data/models/membership.dart';
import '../../data/models/user_profile.dart';
import '../../data/providers.dart';
import '../../shared/widgets/app_network_image.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/user_avatar.dart';
import '../../shared/widgets/widgets.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 3, vsync: this);

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final session = ref.watch(sessionProvider);
    final profile = session.profile;
    final gamification = ref.watch(gamificationProvider).valueOrNull;
    final membership = ref.watch(membershipProvider).valueOrNull;
    final bookmarks = ref.watch(bookmarkProvider).valueOrNull ?? const [];
    final favorites = ref.watch(favoriteProvider).valueOrNull ?? const [];
    final history = ref.watch(historyProvider).valueOrNull ?? const [];

    if (profile == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final stats = _ProfileStats.from(
      profile: profile,
      history: history,
      bookmarks: bookmarks,
      gamification: gamification,
    );

    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverToBoxAdapter(
            child: _ProfileHeader(
              profile: profile,
              membership: membership,
              gamification: gamification,
              stats: stats,
            ),
          ),
        ],
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    gradient: AppColors.brandGradient,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  indicatorSize: TabBarIndicatorSize.tab,
                  dividerColor: Colors.transparent,
                  labelColor: Colors.white,
                  unselectedLabelColor: AppColors.textSecondary,
                  labelStyle:
                      const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                  tabs: const [
                    Tab(text: 'Favorit'),
                    Tab(text: 'Pencapaian'),
                    Tab(text: 'Aktivitas'),
                  ],
                ),
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _FavoritesTab(favorites: favorites, bookmarks: bookmarks),
                  _AchievementsTab(gamification: gamification, profile: profile),
                  _ActivityTab(history: history),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileStats {
  const _ProfileStats({
    required this.episodes,
    required this.minutes,
    required this.chapters,
    required this.novels,
    required this.comments,
    required this.bookmarks,
  });

  final int episodes;
  final int minutes;
  final int chapters;
  final int novels;
  final int comments;
  final int bookmarks;

  factory _ProfileStats.from({
    required UserProfile profile,
    required List<HistoryEntry> history,
    required List<LibraryEntry> bookmarks,
    required GamificationState? gamification,
  }) {
    var episodes = 0;
    var minutes = 0;
    var chapters = 0;
    var novels = 0;
    for (final entry in history) {
      if (entry.media.kind.isVideo) {
        episodes += 1;
        minutes += (entry.positionSeconds / 60).round();
      } else if (entry.media.kind == MediaKind.novel) {
        novels += entry.completed ? 1 : 0;
        chapters += 1;
      } else {
        chapters += 1;
      }
    }
    return _ProfileStats(
      episodes: episodes + profile.stats.episodesWatched,
      minutes: minutes + profile.stats.watchMinutes,
      chapters: chapters + profile.stats.chaptersRead,
      novels: novels + profile.stats.novelsRead,
      comments: profile.stats.comments + (gamification == null ? 0 : 0),
      bookmarks: bookmarks.length,
    );
  }
}

class _ProfileHeader extends ConsumerWidget {
  const _ProfileHeader({
    required this.profile,
    required this.membership,
    required this.gamification,
    required this.stats,
  });

  final UserProfile profile;
  final MembershipStatus? membership;
  final GamificationState? gamification;
  final _ProfileStats stats;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tier = membership?.effectiveTier ?? profile.tier;
    return Column(
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            SizedBox(
              height: 200,
              width: double.infinity,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  AppNetworkImage(
                    url: profile.coverUrl,
                    fit: BoxFit.cover,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withValues(alpha: 0.25),
                          AppColors.background,
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 12,
              right: 12,
              child: Row(
                children: [
                  CircleGlassButton(
                    icon: Icons.settings_rounded,
                    onTap: () => context.push('/settings'),
                  ),
                  const Spacer(),
                  if (ref.watch(isAdminProvider))
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GradientBadge(
                        label: 'ADMIN',
                        icon: Icons.shield_rounded,
                        gradient: AppColors.goldGradient,
                        foreground: AppColors.deepBlack,
                      ),
                    ),
                  CircleGlassButton(
                    icon: Icons.edit_rounded,
                    onTap: () => context.push('/edit-profile'),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 20,
              bottom: 0,
              child: UserAvatar(
                imageUrl: profile.avatarUrl,
                initials: profile.initials,
                tier: tier,
                size: 92,
                onTap: () => context.push('/edit-profile'),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      profile.displayName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                        letterSpacing: -0.3,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  TierBadge(tier: tier),
                ],
              ),
              const SizedBox(height: 2),
              Row(
                children: [
                  Text(
                    '@${profile.username}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.violetNeon,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'ID: ${profile.shortId}',
                    style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted),
                  ),
                ],
              ),
              if (profile.bio.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  profile.bio,
                  style: const TextStyle(
                    fontSize: 12.5,
                    height: 1.55,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  SourcePill(
                    label: 'Bergabung ${Fmt.date(profile.joinedAt, pattern: 'MMM yyyy')}',
                    icon: Icons.cake_rounded,
                  ),
                  SourcePill(
                    label: gamification?.rank.name ?? 'Beginner',
                    icon: RankTier.fromKey(gamification?.rankKey).icon,
                    color: RankTier.fromKey(gamification?.rankKey).color,
                  ),
                  if (profile.selectedTitle != null)
                    SourcePill(
                      label: TitleItem.byId(profile.selectedTitle)?.label ??
                          profile.selectedTitle!,
                      icon: Icons.military_tech_rounded,
                      color: AppColors.gold,
                    ),
                ],
              ),
              const SizedBox(height: 14),
              ExpBar(
                level: gamification?.level ?? profile.level,
                progress: gamification?.levelProgress ?? 0,
                expIntoLevel: gamification?.expIntoLevel ?? 0,
                expForNext: gamification?.expForNext ?? 100,
                rankKey: gamification?.rankKey ?? profile.rankKey,
              ),
              const SizedBox(height: 16),
              // Membership card
              GestureDetector(
                onTap: () => context.push('/membership'),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: AppColors.frameFor(tier.value),
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.frameFor(tier.value).last
                            .withValues(alpha: 0.35),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Icon(
                        tier == MembershipTier.ultimate
                            ? Icons.diamond_rounded
                            : Icons.workspace_premium_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              tier.isPaid
                                  ? '${tier.label} Membership aktif'
                                  : 'Upgrade ke VIP',
                              style: const TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              tier.isPaid
                                  ? 'Berakhir ${Fmt.date(membership?.expiresAt)} • '
                                      '${membership?.daysRemaining ?? 0} hari lagi'
                                  : 'Nikmati bebas iklan, 1080p, dan badge eksklusif',
                              style: TextStyle(
                                fontSize: 10.5,
                                color: Colors.white.withValues(alpha: 0.9),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.chevron_right_rounded, color: Colors.white),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Stats
              Row(
                children: [
                  Expanded(
                    child: StatChip(
                      icon: Icons.play_circle_fill_rounded,
                      value: '${stats.episodes}',
                      label: 'Episode ditonton',
                      color: AppColors.violetNeon,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: StatChip(
                      icon: Icons.schedule_rounded,
                      value: '${(stats.minutes / 60).toStringAsFixed(0)}j',
                      label: 'Jam menonton',
                      color: AppColors.info,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: StatChip(
                      icon: Icons.menu_book_rounded,
                      value: '${stats.chapters}',
                      label: 'Chapter dibaca',
                      color: AppColors.success,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: StatChip(
                      icon: Icons.book_rounded,
                      value: '${stats.novels}',
                      label: 'Novel selesai',
                      color: AppColors.gold,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: StatChip(
                      icon: Icons.forum_rounded,
                      value: '${profile.stats.comments}',
                      label: 'Komentar',
                      color: AppColors.warning,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: StatChip(
                      icon: Icons.bookmark_rounded,
                      value: '${stats.bookmarks}',
                      label: 'Bookmark',
                      color: AppColors.violet,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => context.push('/edit-profile'),
                      icon: const Icon(Icons.edit_rounded, size: 16),
                      label: const Text('Edit Profil', style: TextStyle(fontSize: 12)),
                      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 44)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => context.push('/leaderboard'),
                      icon: const Icon(Icons.leaderboard_rounded, size: 16),
                      label: const Text('Ranking', style: TextStyle(fontSize: 12)),
                      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 44)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextButton.icon(
                      onPressed: () => context.push('/quests'),
                      icon: const Icon(Icons.task_alt_rounded, size: 15),
                      label: const Text('Quest', style: TextStyle(fontSize: 12)),
                    ),
                  ),
                  Expanded(
                    child: TextButton.icon(
                      onPressed: () => context.push('/faq'),
                      icon: const Icon(Icons.help_outline_rounded, size: 15),
                      label: const Text('Bantuan', style: TextStyle(fontSize: 12)),
                    ),
                  ),
                  Expanded(
                    child: TextButton.icon(
                      onPressed: () async {
                        final confirmed = await confirmDialog(
                          context,
                          title: 'Keluar dari akun?',
                          message: 'Kamu dapat masuk kembali kapan saja.',
                          confirmLabel: 'Keluar',
                          destructive: true,
                        );
                        if (!confirmed || !context.mounted) return;
                        await ref.read(sessionProvider.notifier).signOut();
                        if (context.mounted) context.go('/login');
                      },
                      icon: const Icon(Icons.logout_rounded, size: 15),
                      label: const Text('Keluar', style: TextStyle(fontSize: 12)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _FavoritesTab extends StatelessWidget {
  const _FavoritesTab({required this.favorites, required this.bookmarks});

  final List<LibraryEntry> favorites;
  final List<LibraryEntry> bookmarks;

  @override
  Widget build(BuildContext context) {
    final entries = favorites.isEmpty ? bookmarks : favorites;
    if (entries.isEmpty) {
      return const EmptyState(
        title: 'Belum ada favorit',
        message:
            'Tandai judul sebagai favorit dari halaman detail untuk menampilkannya di sini.',
        icon: Icons.favorite_border_rounded,
      );
    }
    final anime = entries.where((entry) => entry.media.kind.isVideo).toList();
    final comics = entries.where((entry) => entry.media.kind.isComic).toList();
    final novels = entries.where((entry) => entry.media.kind == MediaKind.novel).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 120),
      children: [
        if (anime.isNotEmpty) ...[
          const _MiniHeader('Anime Favorit'),
          _Row(entries: anime),
          const SizedBox(height: 14),
        ],
        if (comics.isNotEmpty) ...[
          const _MiniHeader('Komik Favorit'),
          _Row(entries: comics),
          const SizedBox(height: 14),
        ],
        if (novels.isNotEmpty) ...[
          const _MiniHeader('Novel Favorit'),
          _Row(entries: novels),
        ],
      ],
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.entries});
  final List<LibraryEntry> entries;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 240,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: entries.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) => PosterCard(
          media: entries[index].media,
          width: 112,
          onTap: () => AppNav.media(context, entries[index].media),
        ),
      ),
    );
  }
}

class _MiniHeader extends StatelessWidget {
  const _MiniHeader(this.title);
  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
        ),
      ),
    );
  }
}

class _AchievementsTab extends StatelessWidget {
  const _AchievementsTab({required this.gamification, required this.profile});

  final GamificationState? gamification;
  final UserProfile profile;

  @override
  Widget build(BuildContext context) {
    final badges = gamification?.badges ?? const <BadgeItem>[];
    final quests = gamification?.quests ?? const <Quest>[];
    final achievements = gamification?.achievements ?? const <Achievement>[];
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 120),
      children: [
        Row(
          children: [
            const Text(
              'Badge',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const Spacer(),
            Text(
              '${badges.length}/${BadgeItem.catalog.length}',
              style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            for (final badge in BadgeItem.catalog)
              _BadgeTile(
                badge: badge,
                unlocked: badges.any((item) => item.id == badge.id),
              ),
          ],
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            const Text(
              'Judul (Title)',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const Spacer(),
            TextButton(
              onPressed: () => context.push('/quests'),
              child: const Text('Quest', style: TextStyle(fontSize: 11.5)),
            ),
          ],
        ),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final title in TitleItem.catalog)
              ChoiceChip(
                label: Text(
                  title.label,
                  style: const TextStyle(fontSize: 11),
                ),
                selected: profile.selectedTitle == title.id,
                avatar: title.isPremium
                    ? const Icon(Icons.workspace_premium_rounded, size: 13)
                    : null,
                onSelected: (value) {
                  if (title.isPremium && !profile.tier.isPaid) {
                    context.push('/membership');
                    return;
                  }
                  context.push('/edit-profile');
                },
              ),
          ],
        ),
        const SizedBox(height: 18),
        const Text(
          'Achievement',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 10),
        for (final achievement in achievements)
          SoftCard(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(
                  achievement.isUnlocked
                      ? Icons.emoji_events_rounded
                      : Icons.lock_outline_rounded,
                  size: 20,
                  color: achievement.isUnlocked ? AppColors.gold : AppColors.textMuted,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        achievement.title,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Text(
                        achievement.description,
                        style: const TextStyle(
                          fontSize: 10.5,
                          color: AppColors.textMuted,
                        ),
                      ),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: achievement.ratio == 0 ? 0.02 : achievement.ratio,
                          minHeight: 4,
                          backgroundColor: AppColors.surfaceHigh,
                          valueColor: const AlwaysStoppedAnimation(AppColors.gold),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  '${achievement.progress}/${achievement.target}',
                  style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
        if (quests.isNotEmpty) ...[
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => context.push('/achievements'),
            icon: const Icon(Icons.workspace_premium_rounded, size: 16),
            label: const Text('Lihat semua achievement'),
          ),
        ],
      ],
    );
  }
}

class _BadgeTile extends StatelessWidget {
  const _BadgeTile({required this.badge, required this.unlocked});

  final BadgeItem badge;
  final bool unlocked;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: badge.description,
      child: Container(
        width: 74,
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: unlocked
              ? badge.color.withValues(alpha: 0.14)
              : AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: unlocked ? badge.color.withValues(alpha: 0.4) : AppColors.border,
          ),
        ),
        child: Column(
          children: [
            Icon(
              badge.icon,
              size: 20,
              color: unlocked ? badge.color : AppColors.textMuted,
            ),
            const SizedBox(height: 5),
            Text(
              badge.label,
              textAlign: TextAlign.center,
              maxLines: 2,
              style: TextStyle(
                fontSize: 8.5,
                fontWeight: FontWeight.w600,
                color: unlocked ? AppColors.textPrimary : AppColors.textMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActivityTab extends StatelessWidget {
  const _ActivityTab({required this.history});

  final List<HistoryEntry> history;

  @override
  Widget build(BuildContext context) {
    if (history.isEmpty) {
      return const EmptyState(
        title: 'Belum ada aktivitas',
        message: 'Aktivitas menonton dan membaca akan tercatat di sini.',
        icon: Icons.timeline_rounded,
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 120),
      itemCount: history.length,
      itemBuilder: (context, index) {
        final entry = history[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  Container(
                    width: 9,
                    height: 9,
                    margin: const EdgeInsets.only(top: 5),
                    decoration: BoxDecoration(
                      gradient: AppColors.brandGradient,
                      shape: BoxShape.circle,
                    ),
                  ),
                  if (index != history.length - 1)
                    Container(
                      width: 1.5,
                      height: 44,
                      color: AppColors.border,
                    ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GestureDetector(
                  onTap: () => AppNav.media(context, entry.media),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        entry.media.title,
                        style: const TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Text(
                        [
                          entry.media.kind.label,
                          entry.progressLabel,
                          Fmt.relative(entry.updatedAt),
                        ].join(' • '),
                        style: const TextStyle(
                          fontSize: 10.5,
                          color: AppColors.textMuted,
                        ),
                      ),
                      const SizedBox(height: 6),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
