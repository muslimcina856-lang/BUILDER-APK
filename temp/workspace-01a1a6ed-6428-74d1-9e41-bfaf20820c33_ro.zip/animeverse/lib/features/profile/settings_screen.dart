import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/config/app_config.dart';
import '../../core/services/local_store.dart';
import '../../core/theme/app_colors.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/widgets.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);
    final profile = ref.watch(currentProfileProvider);
    final cloudMode = ref.watch(bootstrapProvider).valueOrNull?.cloudMode ?? false;

    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        children: [
          _Group(
            title: 'Tampilan',
            children: [
              _Tile(
                icon: Icons.brightness_6_rounded,
                title: 'Tema aplikasi',
                subtitle: settings.themeMode == ThemeMode.dark
                    ? 'Mode gelap premium'
                    : 'Mode terang',
                trailing: Switch.adaptive(
                  value: settings.themeMode == ThemeMode.dark,
                  onChanged: (value) => notifier
                      .patch(themeMode: value ? ThemeMode.dark : ThemeMode.light),
                ),
              ),
              _Tile(
                icon: Icons.translate_rounded,
                title: 'Bahasa',
                subtitle: 'Bahasa Indonesia',
                trailing: const Icon(Icons.chevron_right_rounded, size: 18),
                onTap: () => showSnack(
                  context,
                  'Bahasa Indonesia aktif. Terjemahan lain akan hadir sesuai permintaan.',
                ),
              ),
              _Tile(
                icon: Icons.animation_rounded,
                title: 'Kurangi animasi',
                subtitle: 'Matikan transisi berat untuk perangkat low-end',
                trailing: Switch.adaptive(
                  value: settings.reduceMotion,
                  onChanged: (value) => notifier.patch(reduceMotion: value),
                ),
              ),
            ],
          ),
          _Group(
            title: 'Streaming',
            children: [
              _Tile(
                icon: Icons.high_quality_rounded,
                title: 'Kualitas default',
                subtitle: '${settings.streamingQuality}p',
                trailing: const Icon(Icons.chevron_right_rounded, size: 18),
                onTap: () => _pickQuality(settings.streamingQuality),
              ),
              _Tile(
                icon: Icons.skip_next_rounded,
                title: 'Auto next episode',
                trailing: Switch.adaptive(
                  value: settings.autoPlayNext,
                  onChanged: (value) => notifier.patch(autoPlayNext: value),
                ),
              ),
              _Tile(
                icon: Icons.fast_forward_rounded,
                title: 'Tombol lewati OP/ED',
                subtitle: 'Tampilkan tombol skip bila data tersedia',
                trailing: Switch.adaptive(
                  value: settings.skipIntroEnabled,
                  onChanged: (value) => notifier.patch(skipIntroEnabled: value),
                ),
              ),
              _Tile(
                icon: Icons.subtitles_rounded,
                title: 'Subtitle default',
                subtitle: settings.subtitleLanguage == 'id'
                    ? 'Bahasa Indonesia'
                    : 'English',
                trailing: const Icon(Icons.chevron_right_rounded, size: 18),
                onTap: () async {
                  final value = await showModalBottomSheet<String>(
                    context: context,
                    builder: (context) => SafeArea(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ListTile(
                            title: const Text('Bahasa Indonesia'),
                            onTap: () => Navigator.pop(context, 'id'),
                          ),
                          ListTile(
                            title: const Text('English'),
                            onTap: () => Navigator.pop(context, 'en'),
                          ),
                        ],
                      ),
                    ),
                  );
                  if (value != null) notifier.patch(subtitleLanguage: value);
                },
              ),
              _Tile(
                icon: Icons.data_saver_on_rounded,
                title: 'Hemat data',
                subtitle: 'Batasi kualitas saat memakai data seluler',
                trailing: Switch.adaptive(
                  value: settings.dataSaver,
                  onChanged: (value) => notifier.patch(dataSaver: value),
                ),
              ),
            ],
          ),
          _Group(
            title: 'Baca (Komik & Novel)',
            children: [
              _Tile(
                icon: Icons.swap_horiz_rounded,
                title: 'Arah baca',
                subtitle: settings.readerDirectionRtl
                    ? 'Kanan ke kiri (RTL)'
                    : 'Kiri ke kanan (LTR)',
                trailing: Switch.adaptive(
                  value: settings.readerDirectionRtl,
                  onChanged: (value) => notifier.patch(readerDirectionRtl: value),
                ),
              ),
              _Tile(
                icon: Icons.text_fields_rounded,
                title: 'Ukuran teks novel',
                subtitle: '${settings.readerFontSize.round()} pt',
                trailing: SizedBox(
                  width: 130,
                  child: Slider(
                    value: settings.readerFontSize,
                    min: 13,
                    max: 28,
                    divisions: 15,
                    onChanged: (value) => notifier.patch(readerFontSize: value),
                  ),
                ),
              ),
              _Tile(
                icon: Icons.format_line_spacing_rounded,
                title: 'Jarak antarbaris',
                subtitle: settings.readerLineHeight.toStringAsFixed(1),
                trailing: SizedBox(
                  width: 130,
                  child: Slider(
                    value: settings.readerLineHeight,
                    min: 1.2,
                    max: 2.4,
                    divisions: 12,
                    onChanged: (value) => notifier.patch(readerLineHeight: value),
                  ),
                ),
              ),
              _Tile(
                icon: Icons.save_rounded,
                title: 'Auto-save posisi baca',
                trailing: Switch.adaptive(
                  value: settings.autoSaveProgress,
                  onChanged: (value) => notifier.patch(autoSaveProgress: value),
                ),
              ),
            ],
          ),
          _Group(
            title: 'Privasi & Keamanan',
            children: [
              _Tile(
                icon: Icons.lock_person_rounded,
                title: 'Profil privat',
                subtitle: 'Sembunyikan statistik dari pengguna lain',
                trailing: Switch.adaptive(
                  value: profile?.isPrivate ?? false,
                  onChanged: (value) async {
                    final result = await ref
                        .read(authRepositoryProvider)
                        .updateProfile(isPrivate: value);
                    if (result.profile != null) {
                      await ref
                          .read(sessionProvider.notifier)
                          .applyProfile(result.profile!);
                    }
                    if (context.mounted) {
                      showSnack(
                        context,
                        value ? 'Profil kini privat' : 'Profil kembali publik',
                      );
                    }
                  },
                ),
              ),
              _Tile(
                icon: Icons.password_rounded,
                title: 'Ubah password',
                trailing: const Icon(Icons.chevron_right_rounded, size: 18),
                onTap: () => _changePasswordDialog(),
              ),
              _Tile(
                icon: Icons.block_rounded,
                title: 'Pengguna diblokir',
                subtitle: '${ref.read(communityRepositoryProvider).blockedUsers.length} pengguna',
                trailing: const Icon(Icons.chevron_right_rounded, size: 18),
                onTap: () => showSnack(
                  context,
                  'Blokir pengguna dari menu komentar (ikon ⋯ → Blokir).',
                ),
              ),
              _Tile(
                icon: Icons.download_for_offline_rounded,
                title: 'Unduh hanya via Wi-Fi',
                trailing: Switch.adaptive(
                  value: settings.downloadWifiOnly,
                  onChanged: (value) => notifier.patch(downloadWifiOnly: value),
                ),
              ),
            ],
          ),
          _Group(
            title: 'Notifikasi',
            children: [
              _Tile(
                icon: Icons.notifications_active_rounded,
                title: 'Notifikasi episode & chapter baru',
                trailing: Switch.adaptive(
                  value: settings.notificationsEnabled,
                  onChanged: (value) => notifier.patch(notificationsEnabled: value),
                ),
              ),
              _Tile(
                icon: Icons.campaign_rounded,
                title: 'Notifikasi komunitas',
                subtitle: 'Balasan komentar & mention',
                trailing: const Icon(Icons.chevron_right_rounded, size: 18),
                onTap: () => context.push('/notifications'),
              ),
            ],
          ),
          _Group(
            title: 'Akun',
            children: [
              _Tile(
                icon: Icons.account_circle_rounded,
                title: 'Email',
                subtitle: profile?.email ?? '—',
                trailing: Icon(
                  cloudMode ? Icons.cloud_done_rounded : Icons.cloud_off_rounded,
                  size: 16,
                  color: cloudMode ? AppColors.success : AppColors.gold,
                ),
              ),
              _Tile(
                icon: Icons.storage_rounded,
                title: 'Hapus data lokal',
                subtitle: 'Riwayat, cache, dan pengaturan di perangkat ini',
                onTap: () async {
                  final confirmed = await confirmDialog(
                    context,
                    title: 'Hapus data lokal?',
                    message:
                        'Riwayat dan cache pada perangkat ini akan dihapus. Data akun '
                        'di server (bila terhubung Supabase) tidak terpengaruh.',
                    confirmLabel: 'Hapus',
                    destructive: true,
                  );
                  if (!confirmed) return;
                  await LocalStore.remove('history::${profile?.id ?? 'guest'}');
                  await ref.read(communityRepositoryProvider).clearLocal();
                  ref.invalidate(historyProvider);
                  if (context.mounted) showSnack(context, 'Data lokal dibersihkan');
                },
              ),
              _Tile(
                icon: Icons.logout_rounded,
                title: 'Keluar',
                onTap: () async {
                  final confirmed = await confirmDialog(
                    context,
                    title: 'Keluar dari akun?',
                    confirmLabel: 'Keluar',
                    destructive: true,
                  );
                  if (!confirmed) return;
                  await ref.read(sessionProvider.notifier).signOut();
                  if (context.mounted) context.go('/login');
                },
              ),
            ],
          ),
          const SizedBox(height: 10),
          Center(
            child: Column(
              children: [
                Text(
                  '${AppConfig.appName} v${AppConfig.appVersion}',
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  cloudMode
                      ? 'Terhubung Supabase Cloud'
                      : 'Mode lokal — konfigurasi SUPABASE_URL untuk cloud',
                  style: const TextStyle(fontSize: 9.5, color: AppColors.textMuted),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: () => context.push('/faq'),
                  child: const Text(
                    'FAQ, Kebijakan & Dukungan',
                    style: TextStyle(fontSize: 11.5),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _pickQuality(int current) {
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Kualitas streaming',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            for (final quality in AppConfig.videoQualities.reversed)
              ListTile(
                title: Text('${quality}p'),
                trailing: current == quality
                    ? const Icon(Icons.check_rounded, color: AppColors.violetNeon)
                    : null,
                onTap: () {
                  ref.read(settingsProvider.notifier).patch(streamingQuality: quality);
                  Navigator.pop(context);
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _changePasswordDialog() async {
    final currentController = TextEditingController();
    final newController = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ubah Password'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: currentController,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password saat ini'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: newController,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password baru'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    if (result != true || !mounted) return;
    final response = await ref.read(authRepositoryProvider).changePassword(
          currentPassword: currentController.text,
          newPassword: newController.text,
        );
    if (!mounted) return;
    showSnack(
      context,
      response.message ?? response.error ?? 'Selesai',
      error: response.error != null,
    );
  }
}

class _Group extends StatelessWidget {
  const _Group({required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 8),
            child: Text(
              title.toUpperCase(),
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.1,
                color: AppColors.textMuted,
              ),
            ),
          ),
          SoftCard(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            child: Column(children: children),
          ),
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      onTap: onTap,
      leading: Icon(icon, size: 18, color: AppColors.violetNeon),
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 12.5,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
      ),
      subtitle: subtitle == null
          ? null
          : Text(
              subtitle!,
              style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted),
            ),
      trailing: trailing,
    );
  }
}
