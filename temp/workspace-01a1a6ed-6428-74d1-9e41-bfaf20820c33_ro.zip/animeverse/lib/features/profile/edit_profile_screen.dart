import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';

import '../../core/theme/app_colors.dart';
import '../../data/models/gamification.dart';
import '../../data/models/user_profile.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/user_avatar.dart';
import '../../shared/widgets/widgets.dart';

class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({super.key});

  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  late final TextEditingController _displayName;
  late final TextEditingController _username;
  late final TextEditingController _bio;
  final ImagePicker _picker = ImagePicker();
  Uint8List? _avatarBytes;
  Uint8List? _coverBytes;
  bool _isPrivate = false;
  String? _selectedTitle;
  bool _saving = false;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    final profile = ref.read(currentProfileProvider);
    _displayName = TextEditingController(text: profile?.displayName ?? '');
    _username = TextEditingController(text: profile?.username ?? '');
    _bio = TextEditingController(text: profile?.bio ?? '');
    _isPrivate = profile?.isPrivate ?? false;
    _selectedTitle = profile?.selectedTitle;
    _initialized = true;
  }

  @override
  void dispose() {
    _displayName.dispose();
    _username.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _pickImage({required bool isAvatar}) async {
    try {
      final file = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1200,
        maxHeight: 1200,
        imageQuality: 85,
      );
      if (file == null) return;
      final bytes = await file.readAsBytes();
      if (!mounted) return;
      setState(() {
        if (isAvatar) {
          _avatarBytes = bytes;
        } else {
          _coverBytes = bytes;
        }
      });
    } catch (error) {
      if (mounted) {
        showSnack(
          context,
          'Tidak dapat membuka galeri: $error. Di web, gunakan browser '
          'yang mendukung pemilih berkas.',
          error: true,
        );
      }
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final result = await ref.read(authRepositoryProvider).updateProfile(
          displayName: _displayName.text.trim(),
          username: _username.text.trim(),
          bio: _bio.text.trim(),
          isPrivate: _isPrivate,
          selectedTitle: _selectedTitle,
          avatarBytes: _avatarBytes,
          coverBytes: _coverBytes,
        );
    if (!mounted) return;
    setState(() => _saving = false);
    if (result.profile != null) {
      await ref.read(sessionProvider.notifier).applyProfile(result.profile!);
      if (!mounted) return;
      showSnack(context, result.error ?? 'Profil berhasil diperbarui');
      if (result.error == null) context.pop();
    } else {
      showSnack(context, result.error ?? 'Gagal menyimpan profil', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final profile = ref.watch(currentProfileProvider);
    final gamification = ref.watch(gamificationProvider).valueOrNull;
    if (!_initialized || profile == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final availableTitles = gamification?.unlockedTitles ?? const ['newbie'];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profil'),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Simpan'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        children: [
          GestureDetector(
            onTap: () => _pickImage(isAvatar: false),
            child: Container(
              height: 132,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: AppColors.premiumGradient,
                image: _coverBytes != null
                    ? DecorationImage(
                        image: MemoryImage(_coverBytes!),
                        fit: BoxFit.cover,
                      )
                    : (profile.coverUrl != null && profile.coverUrl!.isNotEmpty
                        ? DecorationImage(
                            image: NetworkImage(profile.coverUrl!),
                            fit: BoxFit.cover,
                          )
                        : null),
              ),
              child: Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.5),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.image_rounded, size: 14, color: Colors.white),
                      SizedBox(width: 6),
                      Text(
                        'Ganti cover',
                        style: TextStyle(fontSize: 11, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              GestureDetector(
                onTap: () => _pickImage(isAvatar: true),
                child: Stack(
                  children: [
                    if (_avatarBytes != null)
                      ClipOval(
                        child: Image.memory(
                          _avatarBytes!,
                          width: 84,
                          height: 84,
                          fit: BoxFit.cover,
                        ),
                      )
                    else
                      UserAvatar(
                        imageUrl: profile.avatarUrl,
                        initials: profile.initials,
                        tier: profile.tier,
                        size: 84,
                      ),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        width: 26,
                        height: 26,
                        decoration: const BoxDecoration(
                          gradient: AppColors.brandGradient,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.camera_alt_rounded,
                          size: 13,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Text(
                  'Foto profil dan cover disimpan di Supabase Storage '
                  '(bucket avatars & covers). Mode lokal menyimpan sebagai data URI.',
                  style: TextStyle(
                    fontSize: 10.5,
                    height: 1.6,
                    color: AppColors.textMuted,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _displayName,
            decoration: const InputDecoration(labelText: 'Nama tampilan'),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _username,
            decoration: const InputDecoration(
              labelText: 'Username',
              prefixText: '@',
              helperText: 'Huruf kecil, angka, titik dan garis bawah',
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _bio,
            maxLines: 3,
            maxLength: 160,
            decoration: const InputDecoration(labelText: 'Bio'),
          ),
          const SizedBox(height: 6),
          const Text(
            'Judul (Title)',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final title in TitleItem.catalog)
                ChoiceChip(
                  label: Text(title.label, style: const TextStyle(fontSize: 11)),
                  selected: _selectedTitle == title.id,
                  avatar: title.isPremium
                      ? const Icon(Icons.workspace_premium_rounded, size: 13)
                      : null,
                  onSelected: (value) {
                    final unlocked = availableTitles.contains(title.id) ||
                        title.id == 'newbie';
                    if (title.isPremium && !profile.tier.isPaid) {
                      context.push('/membership');
                      return;
                    }
                    if (!unlocked) {
                      showSnack(
                        context,
                        '${title.label} belum terbuka. ${title.description}',
                        error: true,
                      );
                      return;
                    }
                    setState(() => _selectedTitle = value ? title.id : null);
                  },
                ),
            ],
          ),
          const SizedBox(height: 18),
          SoftCard(
            child: SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: _isPrivate,
              onChanged: (value) => setState(() => _isPrivate = value),
              title: const Text(
                'Profil privat',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
              ),
              subtitle: const Text(
                'Sembunyikan statistik dan aktivitas dari pengguna lain',
                style: TextStyle(fontSize: 10.5, color: AppColors.textMuted),
              ),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _saving ? null : _save,
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.violet,
              minimumSize: const Size(0, 52),
            ),
            child: Text(_saving ? 'Menyimpan…' : 'Simpan Perubahan'),
          ),
        ],
      ),
    );
  }
}
