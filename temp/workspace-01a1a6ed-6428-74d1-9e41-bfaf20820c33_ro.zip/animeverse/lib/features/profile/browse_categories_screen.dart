import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/media.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/widgets.dart';

/// Halaman "Kategori": pintu masuk ke 12 kategori utama aplikasi.
class BrowseCategoriesScreen extends ConsumerWidget {
  const BrowseCategoriesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final trending = ref.watch(trendingProvider(MediaKind.anime)).valueOrNull ??
        const [];
    final seasonal = ref.watch(seasonProvider(MediaKind.anime)).valueOrNull ?? const [];

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 120),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 12, 0),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Jelajahi Semesta',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                            letterSpacing: -0.4,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          '12 kategori hiburan dalam satu aplikasi',
                          style: TextStyle(fontSize: 11.5, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ),
                  CircleGlassButton(
                    icon: Icons.search_rounded,
                    onTap: () => AppNav.search(context),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 3,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.92,
                children: [
                  for (final kind in MediaKind.values)
                    _CategoryTile(kind: kind),
                ],
              ),
            ),
            const SectionHeader(
              title: 'Akses Cepat',
              icon: Icons.bolt_rounded,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  _QuickTile(
                    icon: Icons.history_rounded,
                    title: 'Riwayat Tontonan & Bacaan',
                    subtitle: 'Lanjutkan dari posisi terakhir',
                    color: AppColors.info,
                    onTap: () => context.push('/history'),
                  ),
                  const SizedBox(height: 10),
                  _QuickTile(
                    icon: Icons.bookmark_rounded,
                    title: 'Bookmark',
                    subtitle: 'Koleksi judul tersimpan',
                    color: AppColors.violetNeon,
                    onTap: () => context.push('/bookmarks'),
                  ),
                  const SizedBox(height: 10),
                  _QuickTile(
                    icon: Icons.download_rounded,
                    title: 'Download Manager',
                    subtitle: 'Unduhan offline yang diizinkan lisensi',
                    color: AppColors.success,
                    onTap: () => context.push('/downloads'),
                  ),
                  const SizedBox(height: 10),
                  _QuickTile(
                    icon: Icons.calendar_month_rounded,
                    title: 'Jadwal Rilis',
                    subtitle: 'Anime tayang minggu ini',
                    color: AppColors.gold,
                    onTap: () => context.push('/schedule'),
                  ),
                  const SizedBox(height: 10),
                  _QuickTile(
                    icon: Icons.leaderboard_rounded,
                    title: 'Leaderboard',
                    subtitle: 'Peringkat mingguan & bulanan',
                    color: AppColors.warning,
                    onTap: () => context.push('/leaderboard'),
                  ),
                ],
              ),
            ),
            if (trending.isNotEmpty) ...[
              SectionHeader(
                title: 'Trending Sekarang',
                icon: Icons.local_fire_department_rounded,
                onSeeAll: () => AppNav.category(context, MediaKind.anime),
              ),
              SizedBox(
                height: 268,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: trending.take(10).length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, index) => PosterCard(
                    media: trending[index],
                    showRank: index + 1,
                    onTap: () => AppNav.media(context, trending[index]),
                  ),
                ),
              ),
            ],
            if (seasonal.isNotEmpty) ...[
              SectionHeader(
                title: 'Populer Musim Ini',
                icon: Icons.whatshot_rounded,
                onSeeAll: () => AppNav.category(context, MediaKind.anime),
              ),
              SizedBox(
                height: 268,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: seasonal.take(10).length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, index) => PosterCard(
                    media: seasonal[index],
                    onTap: () => AppNav.media(context, seasonal[index]),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({required this.kind});

  final MediaKind kind;

  @override
  Widget build(BuildContext context) {
    final gradients = <MediaKind, List<Color>>{
      MediaKind.anime: [const Color(0xFF7C4DFF), const Color(0xFF4A1D96)],
      MediaKind.donghua: [const Color(0xFFFF6B6B), const Color(0xFF8E1F3F)],
      MediaKind.movie: [const Color(0xFF38BDF8), const Color(0xFF1E3A8A)],
      MediaKind.manga: [const Color(0xFFFFC857), const Color(0xFFB45309)],
      MediaKind.manhwa: [const Color(0xFF34D399), const Color(0xFF065F46)],
      MediaKind.manhua: [const Color(0xFFF472B6), const Color(0xFF831843)],
      MediaKind.novel: [const Color(0xFFB388FF), const Color(0xFF3B0764)],
    };
    final colors = gradients[kind]!;
    return GestureDetector(
      onTap: () => AppNav.category(context, kind),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: colors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: colors.first.withValues(alpha: 0.28),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(kind.icon, size: 26, color: Colors.white),
            const SizedBox(height: 8),
            Text(
              kind.label,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickTile extends StatelessWidget {
  const _QuickTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SoftCard(
      onTap: onTap,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, size: 19, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, size: 18, color: AppColors.textMuted),
        ],
      ),
    );
  }
}
