import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/membership.dart';
import '../../data/models/user_profile.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/user_avatar.dart';
import '../../shared/widgets/widgets.dart';

class MembershipScreen extends ConsumerStatefulWidget {
  const MembershipScreen({super.key});

  @override
  ConsumerState<MembershipScreen> createState() => _MembershipScreenState();
}

class _MembershipScreenState extends ConsumerState<MembershipScreen> {
  MembershipTier _tier = MembershipTier.premium;
  int _months = 1;
  String _method = 'QRIS';
  bool _processing = false;

  static const List<String> _methods = ['QRIS', 'GoPay', 'OVO', 'DANA', 'Transfer Bank'];

  @override
  Widget build(BuildContext context) {
    final membership = ref.watch(membershipProvider);
    final payments = ref.watch(paymentsProvider).valueOrNull ?? const [];
    final status = membership.valueOrNull;
    final plans = MembershipPlan.forTier(_tier);
    final selectedPlan = plans.firstWhere(
      (plan) => plan.months == _months,
      orElse: () => plans.first,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Membership')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 40),
        children: [
          _StatusCard(status: status),
          const SizedBox(height: 20),
          const Text(
            'Pilih paket',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              for (final tier in [
                MembershipTier.vip,
                MembershipTier.premium,
                MembershipTier.ultimate,
              ])
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () => setState(() {
                        _tier = tier;
                        _months = 1;
                      }),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          gradient: _tier == tier
                              ? LinearGradient(colors: AppColors.frameFor(tier.value))
                              : null,
                          color: _tier == tier ? null : AppColors.surface,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: _tier == tier
                                ? Colors.transparent
                                : AppColors.border,
                          ),
                        ),
                        child: Column(
                          children: [
                            Icon(
                              tier == MembershipTier.ultimate
                                  ? Icons.diamond_rounded
                                  : Icons.workspace_premium_rounded,
                              size: 18,
                              color: _tier == tier
                                  ? _tier == MembershipTier.vip
                                      ? Colors.white
                                      : AppColors.deepBlack
                                  : AppColors.textSecondary,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              tier.label,
                              style: TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w800,
                                color: _tier == tier
                                    ? _tier == MembershipTier.vip
                                        ? Colors.white
                                        : AppColors.deepBlack
                                    : AppColors.textPrimary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              for (final plan in plans)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () => setState(() => _months = plan.months),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: _months == plan.months
                              ? AppColors.violet.withValues(alpha: 0.2)
                              : AppColors.surface,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: _months == plan.months
                                ? AppColors.violet
                                : AppColors.border,
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              plan.label,
                              style: const TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              plan.priceLabel,
                              style: TextStyle(
                                fontSize: 10.5,
                                color: _months == plan.months
                                    ? AppColors.violetNeon
                                    : AppColors.textMuted,
                              ),
                            ),
                            if (plan.savePercent > 0)
                              Text(
                                'Hemat ${plan.savePercent}%',
                                style: const TextStyle(
                                  fontSize: 8.5,
                                  color: AppColors.success,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 18),
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      selectedPlan.tier.label,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(width: 8),
                    SourcePill(
                      label: selectedPlan.label,
                      icon: Icons.schedule_rounded,
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      selectedPlan.priceLabel,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: AppColors.gold,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(
                        '≈ ${selectedPlan.perMonthLabel}/bulan',
                        style: const TextStyle(
                          fontSize: 10.5,
                          color: AppColors.textMuted,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Text(
                  'Manfaat yang didapat',
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                for (final benefit in MembershipBenefits.forTier(_tier))
                  Padding(
                    padding: const EdgeInsets.only(bottom: 7),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(benefit.icon, size: 14, color: AppColors.success),
                        const SizedBox(width: 8),
                        Expanded(
                          child: RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                fontSize: 11.5,
                                height: 1.5,
                                color: AppColors.textSecondary,
                              ),
                              children: [
                                TextSpan(
                                  text: '${benefit.title} — ',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                TextSpan(text: benefit.description),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 6),
                const Text(
                  'Metode pembayaran',
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final method in _methods)
                      ChoiceChip(
                        label: Text(method, style: const TextStyle(fontSize: 11)),
                        selected: _method == method,
                        onSelected: (_) => setState(() => _method = method),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _processing ? null : () => _purchase(selectedPlan),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.violet,
                      minimumSize: const Size(0, 52),
                    ),
                    child: _processing
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(Colors.white),
                            ),
                          )
                        : Text('Berlangganan ${selectedPlan.tier.label}'),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Pembayaran diproses melalui gateway resmi (Midtrans/Xendit) bila '
                  'dikonfigurasi. Tanpa gateway, pesanan dicatat sebagai pending dan '
                  'diverifikasi manual oleh admin.',
                  style: TextStyle(
                    fontSize: 9.5,
                    height: 1.55,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            'Riwayat pembayaran',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 10),
          if (payments.isEmpty)
            const SoftCard(
              child: Text(
                'Belum ada transaksi.',
                style: TextStyle(fontSize: 12, color: AppColors.textMuted),
              ),
            )
          else
            for (final payment in payments)
              SoftCard(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: payment.status == PaymentStatus.paid
                            ? AppColors.success.withValues(alpha: 0.15)
                            : AppColors.warning.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(
                        payment.status == PaymentStatus.paid
                            ? Icons.check_rounded
                            : Icons.schedule_rounded,
                        size: 18,
                        color: payment.status == PaymentStatus.paid
                            ? AppColors.success
                            : AppColors.warning,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${payment.tier.label} • ${payment.months} bulan',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          Text(
                            '${payment.id} • ${Fmt.dateTime(payment.createdAt)}',
                            style: const TextStyle(
                              fontSize: 9.5,
                              color: AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          payment.amountLabel,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: AppColors.gold,
                          ),
                        ),
                        Text(
                          payment.statusLabel,
                          style: TextStyle(
                            fontSize: 9,
                            color: payment.status == PaymentStatus.paid
                                ? AppColors.success
                                : AppColors.warning,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
          const SizedBox(height: 20),
          SoftCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Ketentuan membership',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  '• Langganan berlaku sesuai durasi yang dipilih dan tidak diperpanjang '
                  'otomatis tanpa persetujuan.\n'
                  '• Akses download offline hanya untuk konten yang lisensinya '
                  'mengizinkan.\n'
                  '• Refund mengikuti kebijakan yang tercantum pada halaman FAQ.\n'
                  '• Koleksi eksklusif hanya tersedia bila pemegang lisensi '
                  'menyediakannya.',
                  style: TextStyle(
                    fontSize: 10.5,
                    height: 1.7,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _purchase(MembershipPlan plan) async {
    setState(() => _processing = true);
    final result = await ref.read(membershipRepositoryProvider).purchase(
          plan: plan,
          method: _method,
        );
    if (result.payment != null) {
      await ref
          .read(membershipRepositoryProvider)
          .recordLocalTransaction(result.payment!);
    }
    if (!mounted) return;
    setState(() => _processing = false);
    ref.invalidate(paymentsProvider);
    ref.invalidate(membershipProvider);
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(result.success ? 'Pesanan dibuat' : 'Gagal'),
        content: Text(result.message, style: const TextStyle(fontSize: 12.5, height: 1.6)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  const _StatusCard({this.status});

  final MembershipStatus? status;

  @override
  Widget build(BuildContext context) {
    final tier = status?.effectiveTier ?? MembershipTier.free;
    final colors = AppColors.frameFor(tier.value);
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            colors.first.withValues(alpha: 0.9),
            colors.last.withValues(alpha: 0.75),
            AppColors.deepPurple,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: colors.last.withValues(alpha: 0.35),
            blurRadius: 26,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                tier == MembershipTier.ultimate
                    ? Icons.diamond_rounded
                    : Icons.workspace_premium_rounded,
                color: Colors.white,
                size: 24,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  tier.isPaid ? '${tier.label} Member' : 'Free Member',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
              ),
              TierBadge(tier: tier),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            tier.isPaid
                ? 'Aktif hingga ${Fmt.date(status?.expiresAt)} '
                    '(${status?.daysRemaining ?? 0} hari lagi)'
                : 'Upgrade untuk menikmati pengalaman tanpa iklan dan kualitas 1080p.',
            style: TextStyle(
              fontSize: 11.5,
              height: 1.5,
              color: Colors.white.withValues(alpha: 0.92),
            ),
          ),
        ],
      ),
    );
  }
}
