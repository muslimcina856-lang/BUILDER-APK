import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:video_player/video_player.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/episode.dart';
import '../../data/models/library.dart';
import '../../data/models/media.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/shimmer.dart';
import '../../shared/widgets/user_avatar.dart';
import '../../shared/widgets/widgets.dart';

/// Stream uji publik untuk memverifikasi pipeline player (bukan konten
/// berlisensi, tidak diatribusikan ke judul apa pun).
const String kPlayerTestHls =
    'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8';

class VideoPlayerScreen extends ConsumerStatefulWidget {
  const VideoPlayerScreen({
    super.key,
    required this.mediaId,
    required this.kindSlug,
    required this.episode,
    this.title,
  });

  final String mediaId;
  final String kindSlug;
  final int episode;
  final String? title;

  @override
  ConsumerState<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends ConsumerState<VideoPlayerScreen>
    with WidgetsBindingObserver {
  VideoPlayerController? _controller;
  MediaItem? _media;
  List<StreamSource> _sources = const [];
  StreamSource? _activeSource;
  List<EpisodeInfo> _episodes = const [];

  bool _loading = true;
  String? _error;
  bool _unavailable = false;
  bool _showControls = true;
  bool _fullscreen = false;
  bool _locked = false;
  double _speed = 1.0;
  double _brightness = 1.0;
  double _volume = 1.0;
  int _activeSubtitle = -1;
  Timer? _controlsTimer;
  Timer? _progressTimer;
  bool _skipIntroVisible = false;
  bool _skipOutroVisible = false;
  bool _usingTestStream = false;
  ClosedCaptionFile? _captionFile;

  MediaKind get _kind => MediaKind.fromSlug(widget.kindSlug);
  int _episode = 0;

  @override
  void initState() {
    super.initState();
    _episode = widget.episode;
    WidgetsBinding.instance.addObserver(this);
    _bootstrap();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controlsTimer?.cancel();
    _progressTimer?.cancel();
    _controller?.dispose();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    ref.read(libraryRepositoryProvider).bindUser(
          ref.read(currentProfileProvider)?.id ?? 'guest',
        );
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _saveProgress();
      _controller?.pause();
    }
  }

  Future<void> _bootstrap({bool playTestStream = false}) async {
    setState(() {
      _loading = true;
      _error = null;
      _unavailable = false;
    });
    final service = ref.read(contentServiceProvider);
    try {
      final media = await service.detail(widget.mediaId, _kind);
      if (media == null) {
        setState(() {
          _loading = false;
          _error = 'Detail judul tidak ditemukan.';
        });
        return;
      }
      _media = media;
      _episodes = await service.episodes(media);
      _sources = playTestStream
          ? const []
          : await service.sources(media.id, _episode);
      if (!mounted) return;
      if (playTestStream) {
        _usingTestStream = true;
        await _initController(
          url: kPlayerTestHls,
          title: 'Uji Player',
          startAt: 0,
        );
        return;
      }
      if (_sources.isEmpty) {
        setState(() {
          _loading = false;
          _unavailable = true;
        });
        return;
      }
      _usingTestStream = false;
      _activeSource = _pickServer(_sources);
      final history = await ref
          .read(libraryRepositoryProvider)
          .findHistory('${media.id}::$_episode');
      final startAt = history != null &&
              history.episodeNumber == _episode &&
              history.progress < 0.95
          ? history.positionSeconds
          : 0;
      await _initController(
        url: _activeSource!.url,
        title: media.title,
        startAt: startAt,
      );
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.toString();
      });
    }
  }

  StreamSource _pickServer(List<StreamSource> sources) {
    final servers = [...sources]..sort((a, b) => a.server.compareTo(b.server));
    return servers.first;
  }

  Future<void> _initController({
    required String url,
    required String title,
    required int startAt,
  }) async {
    await _controller?.dispose();
    final controller = VideoPlayerController.networkUrl(Uri.parse(url));
    _controller = controller;
    try {
      await controller.initialize();
      if (startAt > 0) {
        await controller.seekTo(Duration(seconds: startAt));
      }
      await controller.play();
      await controller.setPlaybackSpeed(_speed);
      if (!mounted) return;
      setState(() {
        _loading = false;
      });
      _startProgressTimer();
      _scheduleHideControls();
      controller.addListener(_onControllerUpdate);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Gagal memutar video: $error';
      });
    }
  }

  void _onControllerUpdate() {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    final position = controller.value.position;
    final introStart = _activeSource?.introStart;
    final introEnd = _activeSource?.introEnd;
    final outroStart = _activeSource?.outroStart;

    var skipIntro = false;
    if (_activeSource != null && introStart != null && introEnd != null) {
      skipIntro = position.inSeconds >= introStart &&
          position.inSeconds < introEnd - 2;
    }
    var skipOutro = false;
    if (_activeSource != null && outroStart != null) {
      skipOutro = position.inSeconds >= outroStart;
    }
    if (skipIntro != _skipIntroVisible || skipOutro != _skipOutroVisible) {
      setState(() {
        _skipIntroVisible = skipIntro;
        _skipOutroVisible = skipOutro;
      });
    }
    if (controller.value.isCompleted && controller.value.position > Duration.zero) {
      _onEpisodeCompleted();
    }
  }

  bool _completionHandled = false;

  void _onEpisodeCompleted() {
    if (_completionHandled) return;
    _completionHandled = true;
    _saveProgress(completed: true);
    final settings = ref.read(settingsProvider);
    if (settings.autoPlayNext) {
      final next = _episode + 1;
      if (_episodes.any((episode) => episode.number == next)) {
        _switchEpisode(next);
      }
    }
  }

  Future<void> _switchEpisode(int episode) async {
    _completionHandled = false;
    setState(() {
      _episode = episode;
      _loading = true;
    });
    _progressTimer?.cancel();
    await _bootstrap();
  }

  void _startProgressTimer() {
    _progressTimer?.cancel();
    _progressTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _saveProgress();
    });
  }

  Future<void> _saveProgress({bool completed = false}) async {
    final media = _media;
    final controller = _controller;
    if (media == null || controller == null || !controller.value.isInitialized) {
      return;
    }
    if (_usingTestStream) return;
    final settings = ref.read(settingsProvider);
    if (!settings.autoSaveProgress) return;
    final position = controller.value.position;
    if (position.inSeconds < 3) return;
    final entry = HistoryEntry(
      id: '${media.id}::$_episode',
      media: media,
      updatedAt: DateTime.now(),
      episodeNumber: _episode,
      positionSeconds: position.inSeconds,
      durationSeconds: controller.value.duration.inSeconds,
      completed: completed,
    );
    await ref.read(libraryRepositoryProvider).saveProgress(entry);
    ref.invalidate(continueWatchingProvider);
    ref.invalidate(historyProvider);

    // EXP menonton: 1 EXP per menit, maks 30 per simpan (anti-farming).
    final minutes = (position.inSeconds / 60).floor();
    if (minutes >= 1 && !completed) {
      final lastAwarded = _awardedMinutes;
      if (minutes > lastAwarded) {
        _awardedMinutes = minutes;
        await ref.read(gamificationRepositoryProvider).awardExp(
              amount: (minutes - lastAwarded).clamp(1, 30),
              category: 'watch',
              reason: 'Menonton episode $_episode',
              questId: 'daily_watch_1',
              questProgress: 1,
            );
        ref.invalidate(gamificationProvider);
      }
    }
  }

  int _awardedMinutes = 0;

  void _scheduleHideControls() {
    _controlsTimer?.cancel();
    _controlsTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _showControls = false);
    });
  }

  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _scheduleHideControls();
  }

  Future<void> _toggleFullscreen() async {
    if (_fullscreen) {
      await SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    } else {
      await SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
    setState(() => _fullscreen = !_fullscreen);
  }

  Future<void> _loadSubtitle(int index) async {
    final source = _activeSource;
    if (source == null || index < 0 || index >= source.subtitles.length) {
      await _controller?.setClosedCaptionFile(null);
      setState(() {
        _activeSubtitle = -1;
        _captionFile = null;
      });
      return;
    }
    final track = source.subtitles[index];
    try {
      final response = await Dio().get<String>(track.url);
      final content = response.data ?? '';
      final file = track.url.toLowerCase().endsWith('.vtt')
          ? WebVTTCaptionFile(content)
          : SubRipCaptionFile(content);
      await _controller?.setClosedCaptionFile(Future<ClosedCaptionFile>.value(file));
      setState(() {
        _activeSubtitle = index;
        _captionFile = file;
      });
    } catch (error) {
      if (mounted) showSnack(context, 'Subtitle gagal dimuat: $error', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (_unavailable) return _buildUnavailable();
    if (_loading) {
      return const Scaffold(
        body: Center(
          child: SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(strokeWidth: 2.4),
          ),
        ),
      );
    }
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Streaming')),
        body: EmptyState(
          title: 'Tidak dapat memutar video',
          message: _error,
          icon: Icons.videocam_off_rounded,
          actionLabel: 'Coba lagi',
          onAction: () => _bootstrap(),
        ),
      );
    }
    if (controller == null || !controller.value.isInitialized) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        await _saveProgress();
        if (!mounted) return;
        if (_fullscreen) await _toggleFullscreen();
        if (mounted) {
          if (context.canPop()) {
            context.pop();
          } else {
            context.go('/home');
          }
        }
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          top: false,
          bottom: !_fullscreen,
          child: Stack(
            children: [
              GestureDetector(
                onTap: _toggleControls,
                onDoubleTapDown: (details) {
                  final width = MediaQuery.of(context).size.width;
                  final isForward = details.localPosition.dx > width / 2;
                  final position = controller.value.position;
                  final delta = const Duration(seconds: 10);
                  final target = isForward ? position + delta : position - delta;
                  controller.seekTo(
                    target < Duration.zero
                        ? Duration.zero
                        : (target > controller.value.duration
                            ? controller.value.duration
                            : target),
                  );
                  setState(() => _showControls = true);
                  _scheduleHideControls();
                },
                onVerticalDragUpdate: (details) {
                  if (_locked) return;
                  final width = MediaQuery.of(context).size.width;
                  final isLeft = details.localPosition.dx < width / 2;
                  final delta = -details.delta.dy / 220;
                  setState(() {
                    if (isLeft) {
                      _brightness = (_brightness + delta).clamp(0.2, 1.0);
                    } else {
                      _volume = (_volume + delta).clamp(0.0, 1.0);
                      controller.setVolume(_volume);
                    }
                  });
                },
                child: Center(
                  child: AspectRatio(
                    aspectRatio: controller.value.aspectRatio == 0
                        ? 16 / 9
                        : controller.value.aspectRatio,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        VideoPlayer(controller),
                        // Brightness overlay (tanpa plugin tambahan)
                        IgnorePointer(
                          child: Container(
                            color: Colors.black.withValues(
                              alpha: (1 - _brightness).clamp(0.0, 0.8),
                            ),
                          ),
                        ),
                        if (_activeSubtitle >= 0) _CaptionOverlay(controller: controller),
                        if (_brightness < 0.99 || _volume < 0.99)
                          Positioned(
                            left: 16,
                            top: 16,
                            child: _IndicatorPill(
                              icon: _volume < 0.99
                                  ? Icons.volume_up_rounded
                                  : Icons.brightness_6_rounded,
                              value: _volume < 0.99 ? _volume : _brightness,
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
              if (_showControls) _buildControls(controller),
              if (_skipIntroVisible)
                Positioned(
                  right: 16,
                  bottom: 110,
                  child: _SkipButton(
                    label: 'Lewati Opening',
                    onTap: () {
                      final end = _activeSource?.introEnd ?? 90;
                      controller.seekTo(Duration(seconds: end));
                    },
                  ),
                ),
              if (_skipOutroVisible)
                Positioned(
                  right: 16,
                  bottom: 60,
                  child: _SkipButton(
                    label: 'Lewati Ending',
                    onTap: () {
                      controller.seekTo(controller.value.duration);
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControls(VideoPlayerController controller) {
    final value = controller.value;
    final duration = value.duration;
    final position = value.position;
    return Positioned.fill(
      child: Container(
        decoration: const BoxDecoration(gradient: AppColors.heroScrim),
        child: Column(
          children: [
            // Top bar
            SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 12, 0),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white),
                      onPressed: () async {
                        await _saveProgress();
                        if (!mounted) return;
                        if (_fullscreen) await _toggleFullscreen();
                        if (!mounted) return;
                        if (context.canPop()) {
                          context.pop();
                        } else {
                          context.go('/home');
                        }
                      },
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _media?.title ?? widget.title ?? 'Streaming',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            'Episode $_episode${_usingTestStream ? ' • stream uji' : ''}'
                            '${_activeSource?.server != null ? ' • ${_activeSource!.server}' : ''}',
                            style: TextStyle(
                              fontSize: 10.5,
                              color: Colors.white.withValues(alpha: 0.72),
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        _locked ? Icons.lock_rounded : Icons.lock_open_rounded,
                        color: Colors.white,
                        size: 19,
                      ),
                      onPressed: () => setState(() => _locked = !_locked),
                    ),
                    if (_sources.length > 1)
                      IconButton(
                        icon: const Icon(Icons.dns_rounded, color: Colors.white, size: 20),
                        onPressed: _openServerSheet,
                      ),
                    if (_activeSource != null && _activeSource!.subtitles.isNotEmpty)
                      IconButton(
                        icon: Icon(
                          Icons.subtitles_rounded,
                          color: _activeSubtitle >= 0
                              ? AppColors.violetNeon
                              : Colors.white,
                          size: 20,
                        ),
                        onPressed: _openSubtitleSheet,
                      ),
                    IconButton(
                      icon: const Icon(Icons.speed_rounded, color: Colors.white, size: 20),
                      onPressed: _openSpeedSheet,
                    ),
                    IconButton(
                      icon: const Icon(Icons.settings_rounded, color: Colors.white, size: 20),
                      onPressed: _openQualitySheet,
                    ),
                    IconButton(
                      icon: const Icon(Icons.picture_in_picture_alt_rounded,
                          color: Colors.white, size: 20),
                      onPressed: _showPipInfo,
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            // Center play/pause + seek
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  iconSize: 30,
                  icon: const Icon(Icons.replay_10_rounded, color: Colors.white),
                  onPressed: () {
                    final target = position - const Duration(seconds: 10);
                    controller.seekTo(target < Duration.zero ? Duration.zero : target);
                  },
                ),
                const SizedBox(width: 18),
                GestureDetector(
                  onTap: () {
                    if (value.isPlaying) {
                      controller.pause();
                    } else {
                      controller.play();
                    }
                    setState(() {});
                  },
                  child: Container(
                    width: 62,
                    height: 62,
                    decoration: const BoxDecoration(
                      gradient: AppColors.brandGradient,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      value.isPlaying
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      size: 34,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 18),
                IconButton(
                  iconSize: 30,
                  icon: const Icon(Icons.forward_10_rounded, color: Colors.white),
                  onPressed: () {
                    final target = position + const Duration(seconds: 10);
                    controller.seekTo(
                      target > duration ? duration : target,
                    );
                  },
                ),
              ],
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text(
                        Fmt.duration(position.inSeconds),
                        style: const TextStyle(fontSize: 11, color: Colors.white),
                      ),
                      Expanded(
                        child: SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            trackHeight: 3,
                            thumbShape:
                                const RoundSliderThumbShape(enabledThumbRadius: 6),
                            overlayShape:
                                const RoundSliderOverlayShape(overlayRadius: 14),
                          ),
                          child: Slider(
                            value: duration.inMilliseconds == 0
                                ? 0
                                : (position.inMilliseconds /
                                        duration.inMilliseconds)
                                    .clamp(0.0, 1.0),
                            activeColor: AppColors.violetNeon,
                            inactiveColor: Colors.white.withValues(alpha: 0.24),
                            onChanged: (value) => controller.seekTo(
                              Duration(
                                milliseconds:
                                    (value * duration.inMilliseconds).round(),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Text(
                        Fmt.duration(duration.inSeconds),
                        style: const TextStyle(fontSize: 11, color: Colors.white),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(
                          _fullscreen
                              ? Icons.fullscreen_exit_rounded
                              : Icons.fullscreen_rounded,
                          color: Colors.white,
                        ),
                        onPressed: _toggleFullscreen,
                      ),
                      const Text(
                        'Kecepatan',
                        style: TextStyle(fontSize: 10.5, color: Colors.white70),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '${_speed}x',
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: AppColors.violetNeon,
                        ),
                      ),
                      const Spacer(),
                      TextButton.icon(
                        onPressed: _openEpisodeSheet,
                        icon: const Icon(
                          Icons.playlist_play_rounded,
                          size: 16,
                          color: Colors.white,
                        ),
                        label: Text(
                          'Episode',
                          style: TextStyle(
                            fontSize: 11.5,
                            color: Colors.white.withValues(alpha: 0.9),
                          ),
                        ),
                      ),
                      TextButton.icon(
                        onPressed: _openNextEpisode,
                        icon: const Icon(
                          Icons.skip_next_rounded,
                          size: 16,
                          color: Colors.white,
                        ),
                        label: Text(
                          'Berikutnya',
                          style: TextStyle(
                            fontSize: 11.5,
                            color: Colors.white.withValues(alpha: 0.9),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _openNextEpisode() {
    final next = _episode + 1;
    if (_episodes.any((episode) => episode.number == next)) {
      _switchEpisode(next);
    } else {
      showSnack(context, 'Ini episode terakhir yang tersedia.');
    }
  }

  void _openSpeedSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Kecepatan Putar',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            for (final speed in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
              ListTile(
                title: Text('${speed}x'),
                trailing: _speed == speed
                    ? const Icon(Icons.check_rounded, color: AppColors.violetNeon)
                    : null,
                onTap: () {
                  _controller?.setPlaybackSpeed(speed);
                  setState(() => _speed = speed);
                  Navigator.pop(context);
                },
              ),
          ],
        ),
      ),
    );
  }

  void _openServerSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Pilih Server',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            for (final source in _sources)
              ListTile(
                leading: const Icon(Icons.dns_rounded, size: 18),
                title: Text(source.server),
                subtitle: Text(
                  [
                    source.type.toUpperCase(),
                    if (source.qualities.isNotEmpty) source.qualities.join('/'),
                    if (source.licenseNote != null) source.licenseNote!,
                  ].join(' • '),
                  style: const TextStyle(fontSize: 10.5),
                ),
                trailing: _activeSource?.id == source.id
                    ? const Icon(Icons.check_rounded, color: AppColors.violetNeon)
                    : null,
                onTap: () async {
                  Navigator.pop(context);
                  setState(() {
                    _activeSource = source;
                    _loading = true;
                  });
                  await _initController(
                    url: source.url,
                    title: _media?.title ?? '',
                    startAt: _controller?.value.position.inSeconds ?? 0,
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  void _openSubtitleSheet() {
    final subtitles = _activeSource?.subtitles ?? const <MediaTrack>[];
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Subtitle & Audio',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            ListTile(
              leading: const Icon(Icons.subtitles_off_rounded, size: 18),
              title: const Text('Nonaktif'),
              trailing: _activeSubtitle == -1
                  ? const Icon(Icons.check_rounded, color: AppColors.violetNeon)
                  : null,
              onTap: () {
                Navigator.pop(context);
                _loadSubtitle(-1);
              },
            ),
            for (var index = 0; index < subtitles.length; index++)
              ListTile(
                leading: const Icon(Icons.subtitles_rounded, size: 18),
                title: Text(subtitles[index].label),
                subtitle: Text(subtitles[index].language.toUpperCase(),
                    style: const TextStyle(fontSize: 10.5)),
                trailing: _activeSubtitle == index
                    ? const Icon(Icons.check_rounded, color: AppColors.violetNeon)
                    : null,
                onTap: () {
                  Navigator.pop(context);
                  _loadSubtitle(index);
                },
              ),
            if ((_activeSource?.audios ?? const []).isNotEmpty) ...[
              const Divider(),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Audio',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ),
              for (final audio in _activeSource!.audios)
                ListTile(
                  leading: const Icon(Icons.audiotrack_rounded, size: 18),
                  title: Text(audio.label),
                  trailing: audio.isDefault
                      ? const Text('Default',
                          style: TextStyle(fontSize: 10, color: AppColors.textMuted))
                      : null,
                ),
            ],
          ],
        ),
      ),
    );
  }

  void _openQualitySheet() {
    final qualities = _activeSource?.qualities.isNotEmpty == true
        ? _activeSource!.qualities
        : const ['Auto'];
    final isVip = ref.read(sessionProvider).isVip;
    final settings = ref.read(settingsProvider);
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Kualitas Video',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Streaming HLS memakai adaptive bitrate; pilihan di bawah '
                'menetapkan batas kualitas maksimum sesuai pengaturan.',
                style: TextStyle(fontSize: 11, height: 1.5, color: AppColors.textMuted),
              ),
            ),
            const SizedBox(height: 8),
            for (final quality in qualities)
              Builder(builder: (context) {
                final numeric = int.tryParse(quality.replaceAll(RegExp(r'\\D'), ''));
                final locked = numeric != null && numeric > 720 && !isVip;
                return ListTile(
                  leading: const Icon(Icons.hd_rounded, size: 18),
                  title: Text(quality),
                  subtitle: locked
                      ? const Text('Khusus VIP & Premium',
                          style: TextStyle(fontSize: 10, color: AppColors.gold))
                      : null,
                  trailing: locked
                      ? const Icon(Icons.lock_rounded, size: 16, color: AppColors.gold)
                      : (settings.streamingQuality.toString() ==
                              quality.replaceAll(RegExp(r'\\D'), '')
                          ? const Icon(Icons.check_rounded,
                              color: AppColors.violetNeon)
                          : null),
                  onTap: () {
                    if (locked) {
                      Navigator.pop(context);
                      context.push('/membership');
                      return;
                    }
                    final value = numeric ?? settings.streamingQuality;
                    ref.read(settingsProvider.notifier).patch(streamingQuality: value);
                    Navigator.pop(context);
                    showSnack(context, 'Kualitas maksimum: ${value}p');
                  },
                );
              }),
          ],
        ),
      ),
    );
  }

  void _openEpisodeSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 480),
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Daftar Episode',
                    style: TextStyle(fontWeight: FontWeight.w700)),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 72,
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                    childAspectRatio: 1.6,
                  ),
                  itemCount: _episodes.length,
                  itemBuilder: (context, index) {
                    final episode = _episodes[index];
                    final active = episode.number == _episode;
                    return GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        _switchEpisode(episode.number);
                      },
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: active
                              ? AppColors.violet.withValues(alpha: 0.3)
                              : AppColors.surfaceAlt,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: active ? AppColors.violet : AppColors.border,
                          ),
                        ),
                        child: Text(
                          '${episode.number}',
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPipInfo() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Picture-in-Picture'),
        content: const Text(
          'PiP memerlukan dukungan sistem operasi dan izin aplikasi. Pada Android '
          '11+ aktifkan "Picture-in-picture" di Pengaturan aplikasi, lalu tekan '
          'tombol Home saat video berjalan. Bila perangkat tidak mendukung, '
          'gunakan mode mini player dengan keluar dari layar penuh.',
          style: TextStyle(fontSize: 12.5, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Mengerti'),
          ),
        ],
      ),
    );
  }

  Widget _buildUnavailable() {
    final media = _media;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => AppNav.back(context),
        ),
        title: const Text('Streaming'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        children: [
          if (media != null)
            SoftCard(
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: SizedBox(
                      width: 56,
                      height: 78,
                      child: Shimmer(
                        enabled: false,
                        child: Container(color: AppColors.surfaceHigh),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          media.title,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Episode $_episode',
                          style: const TextStyle(
                            fontSize: 11.5,
                            color: AppColors.textMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppColors.gold.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.gold.withValues(alpha: 0.3)),
            ),
            child: Column(
              children: [
                const Icon(Icons.videocam_off_rounded, size: 34, color: AppColors.gold),
                const SizedBox(height: 12),
                const Text(
                  'Konten belum tersedia',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'ANIMEVERSE tidak menayangkan tautan streaming tidak resmi. '
                  'Episode ini belum memiliki sumber video berlisensi yang '
                  'terdaftar, jadi player tidak dijalankan.\n\n'
                  'Admin dapat menambahkan sumber resmi (HLS/MP4) melalui '
                  'Panel Admin → Sumber Streaming. Pemegang lisensi juga dapat '
                  'menghubungi tim kami untuk integrasi katalog.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.65,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () => _bootstrap(playTestStream: true),
            icon: const Icon(Icons.play_circle_outline_rounded, size: 18),
            label: const Text('Uji player dengan stream uji publik'),
          ),
          const SizedBox(height: 8),
          const Text(
            'Stream uji hanya berfungsi memverifikasi pipeline HLS player, '
            'bukan konten katalog.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 10, color: AppColors.textMuted),
          ),
          if (media?.siteUrl != null) ...[
            const SizedBox(height: 16),
            FilledButton.tonal(
              onPressed: () => AppNav.media(context, media!),
              child: const Text('Lihat platform resmi'),
            ),
          ],
        ],
      ),
    );
  }
}

class _CaptionOverlay extends StatelessWidget {
  const _CaptionOverlay({required this.controller});

  final VideoPlayerController controller;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<VideoPlayerValue>(
      valueListenable: controller,
      builder: (context, value, _) {
        final caption = value.caption;
        if (caption.text.isEmpty) return const SizedBox.shrink();
        return Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 64, left: 24, right: 24),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.66),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                caption.text,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  height: 1.4,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _SkipButton extends StatelessWidget {
  const _SkipButton({required this.label, required this.onTap});

  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.7),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            const Icon(Icons.skip_next_rounded, size: 15, color: Colors.white),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _IndicatorPill extends StatelessWidget {
  const _IndicatorPill({required this.icon, required this.value});

  final IconData icon;
  final double value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, size: 14, color: Colors.white),
          const SizedBox(width: 6),
          SizedBox(
            width: 52,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: value,
                minHeight: 4,
                backgroundColor: Colors.white24,
                valueColor: const AlwaysStoppedAnimation(AppColors.violetNeon),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
