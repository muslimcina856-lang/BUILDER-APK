import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/config/app_config.dart';
import '../../core/services/local_store.dart';
import '../../core/theme/app_colors.dart';
import '../../data/providers.dart';
import '../../shared/widgets/user_avatar.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1600),
  )..forward();

  @override
  void initState() {
    super.initState();
    _route();
  }

  Future<void> _route() async {
    final start = DateTime.now();
    final bootstrap = await ref.read(bootstrapProvider.future);
    final session = ref.read(sessionProvider);
    // Tunggu sesi selesai dipulihkan.
    var attempts = 0;
    while (session.status == SessionStatus.loading && attempts < 40) {
      await Future<void>.delayed(const Duration(milliseconds: 100));
      attempts++;
    }
    final elapsed = DateTime.now().difference(start);
    final minimum = Duration(milliseconds: bootstrap.cloudMode ? 900 : 600);
    if (elapsed < minimum) {
      await Future<void>.delayed(minimum - elapsed);
    }
    if (!mounted) return;
    final seenOnboarding = LocalStore.getBool('app::onboardingSeen');
    final current = ref.read(sessionProvider);
    if (!seenOnboarding) {
      context.go('/onboarding');
    } else if (current.isAuthenticated) {
      context.go('/home');
    } else {
      context.go('/login');
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.deepBlack,
      body: Stack(
        children: [
          // Glow background
          Positioned(
            top: -80,
            left: -60,
            child: _Glow(color: AppColors.violet.withValues(alpha: 0.5), size: 320),
          ),
          Positioned(
            bottom: -100,
            right: -70,
            child: _Glow(color: AppColors.gold.withValues(alpha: 0.22), size: 300),
          ),
          Center(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, _) {
                final value = Curves.easeOutBack.transform(
                  _controller.value.clamp(0.0, 1.0),
                );
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Transform.scale(
                      scale: 0.7 + (value * 0.3),
                      child: Opacity(
                        opacity: _controller.value.clamp(0.0, 1.0),
                        child: Container(
                          width: 108,
                          height: 108,
                          decoration: BoxDecoration(
                            gradient: AppColors.brandGradient,
                            borderRadius: BorderRadius.circular(32),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.violet.withValues(alpha: 0.5),
                                blurRadius: 40,
                                spreadRadius: 4,
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Icon(
                              Icons.play_arrow_rounded,
                              size: 56,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 26),
                    GradientText(
                      AppConfig.appName,
                      style: const TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4,
                        color: Colors.white,
                      ),
                      gradient: const LinearGradient(
                        colors: [Colors.white, AppColors.violetNeon, AppColors.gold],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      AppConfig.appTagline,
                      style: TextStyle(
                        fontSize: 12.5,
                        color: AppColors.textSecondary.withValues(alpha: 0.9),
                        letterSpacing: 0.4,
                      ),
                    ),
                    const SizedBox(height: 38),
                    const SizedBox(
                      width: 26,
                      height: 26,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.2,
                        valueColor: AlwaysStoppedAnimation(AppColors.violetNeon),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          Positioned(
            bottom: 34,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Text(
                  'v${AppConfig.appVersion} • ${ref.watch(bootstrapProvider).when(
                        data: (state) => state.cloudMode ? 'Cloud mode' : 'Mode lokal (demo)',
                        loading: () => 'Menghubungkan…',
                        error: (_, __) => 'Mode lokal',
                      )}',
                  style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Glow extends StatelessWidget {
  const _Glow({required this.color, required this.size});
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, color.withValues(alpha: 0)]),
        ),
      ),
    );
  }
}
