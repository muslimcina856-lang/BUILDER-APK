import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/services/local_store.dart';
import '../../core/theme/app_colors.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/user_avatar.dart';

class _Slide {
  const _Slide({
    required this.title,
    required this.description,
    required this.icon,
    required this.accent,
    required this.features,
  });

  final String title;
  final String description;
  final IconData icon;
  final Color accent;
  final List<String> features;
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _controller = PageController();
  int _index = 0;

  static const List<_Slide> _slides = [
    _Slide(
      title: 'Semua Hiburan\ndalam Satu Semesta',
      description:
          'Anime, donghua, movie, manga, manhwa, manhua, dan novel — semuanya '
          'tersedia dalam satu aplikasi premium dengan pengalaman sinematik.',
      icon: Icons.auto_awesome_rounded,
      accent: AppColors.violet,
      features: [
        'Streaming HLS kualitas hingga 1080p',
        'Reader komik & novel yang bisa dikustom',
        'Metadata resmi dari AniList & MangaDex',
      ],
    ),
    _Slide(
      title: 'Naik Level,\nKumpulkan Rank',
      description:
          'Setiap episode yang kamu tonton dan chapter yang kamu baca memberi EXP. '
          'Naik dari Beginner hingga Godlike dan buka badge eksklusif.',
      icon: Icons.workspace_premium_rounded,
      accent: AppColors.gold,
      features: [
        '12 rank, quest harian & achievement',
        'Leaderboard mingguan dan bulanan',
        'Title dan frame profil yang bisa dipilih',
      ],
    ),
    _Slide(
      title: 'Komunitas\nYang Hidup',
      description:
          'Diskusikan episode terbaru, bagikan rekomendasi, dan ikuti pengguna lain. '
          'Moderasi aktif menjaga ruang tetap nyaman.',
      icon: Icons.forum_rounded,
      accent: AppColors.violetNeon,
      features: [
        'Komentar per anime, episode, dan chapter',
        'Global chat & private chat',
        'Sistem laporan dengan moderasi cepat',
      ],
    ),
  ];

  Future<void> _finish() async {
    await LocalStore.setBool('app::onboardingSeen', true);
    if (!mounted) return;
    context.go('/login');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.deepBlack,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: _finish,
                child: const Text(
                  'Lewati',
                  style: TextStyle(color: AppColors.textSecondary),
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _slides.length,
                onPageChanged: (value) => setState(() => _index = value),
                itemBuilder: (context, index) => _SlideView(slide: _slides[index]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      _slides.length,
                      (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        height: 8,
                        width: _index == index ? 26 : 8,
                        decoration: BoxDecoration(
                          gradient: _index == index ? AppColors.brandGradient : null,
                          color: _index == index ? null : AppColors.surfaceHigh,
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        if (_index == _slides.length - 1) {
                          _finish();
                        } else {
                          _controller.nextPage(
                            duration: const Duration(milliseconds: 320),
                            curve: Curves.easeOutCubic,
                          );
                        }
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.violet,
                        minimumSize: const Size(0, 54),
                      ),
                      child: Text(
                        _index == _slides.length - 1 ? 'Mulai Sekarang' : 'Lanjut',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SlideView extends StatelessWidget {
  const _SlideView({required this.slide});

  final _Slide slide;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 190,
              height: 190,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    slide.accent.withValues(alpha: 0.5),
                    slide.accent.withValues(alpha: 0.02),
                  ],
                ),
              ),
              child: Center(
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [slide.accent, slide.accent.withValues(alpha: 0.45)],
                    ),
                    borderRadius: BorderRadius.circular(34),
                    boxShadow: [
                      BoxShadow(
                        color: slide.accent.withValues(alpha: 0.4),
                        blurRadius: 30,
                      ),
                    ],
                  ),
                  child: Icon(slide.icon, size: 52, color: Colors.white),
                ),
              ),
            ),
          ),
          const SizedBox(height: 40),
          Text(
            slide.title,
            style: const TextStyle(
              fontSize: 30,
              height: 1.18,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              letterSpacing: -0.6,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            slide.description,
            style: const TextStyle(
              fontSize: 13.5,
              height: 1.6,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 24),
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Column(
              children: [
                for (final feature in slide.features)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(
                      children: [
                        Icon(
                          Icons.check_circle_rounded,
                          size: 16,
                          color: slide.accent,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            feature,
                            style: const TextStyle(
                              fontSize: 12.5,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
