import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/community.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/widgets.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifications = ref.watch(notificationsProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifikasi'),
        actions: [
          TextButton(
            onPressed: () async {
              await ref.read(communityRepositoryProvider).markAllNotificationsRead();
              ref.invalidate(notificationsProvider);
            },
            child: const Text('Tandai dibaca', style: TextStyle(fontSize: 11.5)),
          ),
        ],
      ),
      body: notifications.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => EmptyState(
          title: 'Gagal memuat notifikasi',
          message: '$error',
          icon: Icons.cloud_off_rounded,
        ),
        data: (items) {
          if (items.isEmpty) {
            return const EmptyState(
              title: 'Belum ada notifikasi',
              message:
                  'Notifikasi episode baru, balasan komentar, dan info membership '
                  'akan muncul di sini.',
              icon: Icons.notifications_none_rounded,
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final item = items[index];
              return SoftCard(
                padding: const EdgeInsets.all(12),
                color: item.read ? null : AppColors.violet.withValues(alpha: 0.08),
                onTap: () async {
                  await ref
                      .read(communityRepositoryProvider)
                      .markNotificationRead(item.id);
                  ref.invalidate(notificationsProvider);
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: _color(item.type).withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: Icon(_icon(item.type), size: 17, color: _color(item.type)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  item.title,
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: item.read
                                        ? FontWeight.w500
                                        : FontWeight.w700,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                              ),
                              if (!item.read)
                                Container(
                                  width: 7,
                                  height: 7,
                                  decoration: const BoxDecoration(
                                    color: AppColors.violetNeon,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(
                            item.body,
                            style: const TextStyle(
                              fontSize: 11,
                              height: 1.5,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            Fmt.relative(item.createdAt),
                            style: const TextStyle(
                              fontSize: 9.5,
                              color: AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  IconData _icon(NotificationKind type) {
    switch (type) {
      case NotificationKind.newEpisode:
        return Icons.play_circle_fill_rounded;
      case NotificationKind.newChapter:
        return Icons.menu_book_rounded;
      case NotificationKind.comment:
        return Icons.forum_rounded;
      case NotificationKind.follow:
        return Icons.person_add_alt_1_rounded;
      case NotificationKind.membership:
        return Icons.workspace_premium_rounded;
      case NotificationKind.system:
        return Icons.campaign_rounded;
    }
  }

  Color _color(NotificationKind type) {
    switch (type) {
      case NotificationKind.newEpisode:
        return AppColors.violetNeon;
      case NotificationKind.newChapter:
        return AppColors.success;
      case NotificationKind.comment:
        return AppColors.info;
      case NotificationKind.follow:
        return AppColors.violet;
      case NotificationKind.membership:
        return AppColors.gold;
      case NotificationKind.system:
        return AppColors.warning;
    }
  }
}
