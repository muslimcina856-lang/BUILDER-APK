import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/media.dart';
import '../../data/providers.dart';
import '../../data/repositories/anilist_repository.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/shimmer.dart';

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key, this.initialQuery});

  final String? initialQuery;

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initialQuery ?? '');
  Timer? _debounce;
  List<MediaItem> _results = const [];
  bool _loading = false;
  String? _error;
  String _activeFilter = 'Semua';
  List<MediaItem> _suggestions = const [];

  static const List<String> _filters = [
    'Semua',
    'Anime',
    'Donghua',
    'Movie',
    'Manga',
    'Manhwa',
    'Manhua',
    'Novel',
  ];

  @override
  void initState() {
    super.initState();
    _loadSuggestions();
    if ((widget.initialQuery ?? '').isNotEmpty) {
      _search(widget.initialQuery!);
    }
  }

  Future<void> _loadSuggestions() async {
    final items = await ref.read(contentServiceProvider).trending(MediaKind.anime);
    if (!mounted) return;
    setState(() => _suggestions = items.take(8).toList());
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onChanged(String value) {
    _debounce?.cancel();
    if (value.trim().length < 2) {
      setState(() {
        _results = const [];
        _loading = false;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 450), () => _search(value));
  }

  Future<void> _search(String query) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await ref.read(contentServiceProvider).searchGlobal(query);
      if (!mounted) return;
      setState(() {
        _results = results;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '$error';
      });
    }
  }

  List<MediaItem> get _filtered {
    if (_activeFilter == 'Semua') return _results;
    return _results
        .where((item) => item.kind.label.toLowerCase() == _activeFilter.toLowerCase())
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 16, 8),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_rounded),
                    onPressed: () => AppNav.back(context),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      autofocus: widget.initialQuery == null,
                      textInputAction: TextInputAction.search,
                      onChanged: _onChanged,
                      onSubmitted: _search,
                      decoration: InputDecoration(
                        hintText: 'Cari anime, manga, novel…',
                        isDense: true,
                        prefixIcon: const Icon(Icons.search_rounded, size: 20),
                        suffixIcon: _controller.text.isEmpty
                            ? null
                            : IconButton(
                                icon: const Icon(Icons.close_rounded, size: 18),
                                onPressed: () {
                                  _controller.clear();
                                  setState(() => _results = const []);
                                },
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: _filters.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final filter = _filters[index];
                  return ChoiceChip(
                    label: Text(filter),
                    selected: _activeFilter == filter,
                    onSelected: (_) => setState(() => _activeFilter = filter),
                  );
                },
              ),
            ),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return Shimmer(
        child: GridView.builder(
          padding: const EdgeInsets.all(20),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 150,
            mainAxisSpacing: 16,
            crossAxisSpacing: 12,
            childAspectRatio: 0.52,
          ),
          itemCount: 6,
          itemBuilder: (_, __) => const SkeletonBox(height: 200, radius: 18),
        ),
      );
    }
    if (_error != null) {
      return EmptyState(
        title: 'Pencarian gagal',
        message: _error,
        icon: Icons.cloud_off_rounded,
        actionLabel: 'Coba lagi',
        onAction: () => _search(_controller.text),
      );
    }
    if (_controller.text.trim().length < 2) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
        children: [
          const Text(
            'Trending Pencarian',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final genre in AniListRepository.genres.take(10))
                ActionChip(
                  label: Text(AniListRepository.genreLabelId[genre] ?? genre),
                  onPressed: () {
                    _controller.text = genre;
                    _search(genre);
                  },
                ),
            ],
          ),
          const SizedBox(height: 22),
          const Text(
            'Populer Minggu Ini',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 130,
              mainAxisSpacing: 16,
              crossAxisSpacing: 12,
              childAspectRatio: 0.5,
            ),
            itemCount: _suggestions.length,
            itemBuilder: (context, index) => PosterCard(
              media: _suggestions[index],
              expand: true,
              onTap: () => AppNav.media(context, _suggestions[index]),
            ),
          ),
        ],
      );
    }
    final items = _filtered;
    if (items.isEmpty) {
      return const EmptyState(
        title: 'Tidak ada hasil',
        message: 'Coba kata kunci lain, atau periksa ejaan judul.',
        icon: Icons.search_off_rounded,
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 150,
        mainAxisSpacing: 16,
        crossAxisSpacing: 12,
        childAspectRatio: 0.52,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) => PosterCard(
        media: items[index],
        expand: true,
        onTap: () => AppNav.media(context, items[index]),
      ),
    );
  }
}
