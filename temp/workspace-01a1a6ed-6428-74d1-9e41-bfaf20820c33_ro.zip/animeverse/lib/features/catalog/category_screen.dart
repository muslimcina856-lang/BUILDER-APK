import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/services/api_client.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/media.dart';
import '../../data/providers.dart';
import '../../data/repositories/anilist_repository.dart';
import '../../shared/widgets/async_view.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/shimmer.dart';

class CategoryScreen extends ConsumerStatefulWidget {
  const CategoryScreen({super.key, required this.slug});

  final String slug;

  @override
  ConsumerState<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends ConsumerState<CategoryScreen> {
  final ScrollController _scrollController = ScrollController();
  final List<MediaItem> _items = [];
  CatalogFilter _filter = const CatalogFilter();
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasNext = false;
  String? _error;

  MediaKind get _kind => MediaKind.fromSlug(widget.slug);

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    _load(reset: true);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >
            _scrollController.position.maxScrollExtent - 400 &&
        _hasNext &&
        !_loadingMore) {
      _load();
    }
  }

  Future<void> _load({bool reset = false}) async {
    if (reset) {
      setState(() {
        _loading = true;
        _error = null;
        _items.clear();
      });
      _filter = _filter.copyWith(page: 1);
    } else {
      setState(() => _loadingMore = true);
    }
    try {
      final page = await ref.read(contentServiceProvider).browse(
            _kind,
            _filter.copyWith(page: reset ? 1 : _filter.page + 1),
          );
      if (!mounted) return;
      setState(() {
        if (reset) {
          _items
            ..clear()
            ..addAll(page.items);
        } else {
          _items.addAll(page.items);
          _filter = _filter.copyWith(page: _filter.page + 1);
        }
        _hasNext = page.hasNextPage;
        _loading = false;
        _loadingMore = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _loadingMore = false;
        _error = error is ApiException ? error.userMessage : '$error';
      });
    }
  }

  void _applyFilter(CatalogFilter filter) {
    _filter = filter.copyWith(page: 1);
    _load(reset: true);
  }

  Future<void> _openFilterSheet() async {
    final result = await showModalBottomSheet<CatalogFilter>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _FilterSheet(
        kind: _kind,
        initial: _filter,
      ),
    );
    if (result != null) _applyFilter(result);
  }

  @override
  Widget build(BuildContext context) {
    final kind = _kind;
    final genres = kind.isReadable
        ? const <String>[]
        : AniListRepository.genres.take(12).toList();

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _Header(
              kind: kind,
              onBack: () => AppNav.back(context),
              onSearch: () => AppNav.search(context),
              onFilter: _openFilterSheet,
              activeFilters: _filter.hasActiveFilters,
            ),
            if (genres.isNotEmpty)
              SizedBox(
                height: 42,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: genres.length + 1,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    if (index == 0) {
                      final selected = _filter.genre == null;
                      return ChoiceChip(
                        label: const Text('Semua'),
                        selected: selected,
                        onSelected: (_) =>
                            _applyFilter(_filter.copyWith(clearGenre: true)),
                      );
                    }
                    final genre = genres[index - 1];
                    final selected = _filter.genre == genre;
                    return ChoiceChip(
                      label: Text(
                        AniListRepository.genreLabelId[genre] ?? genre,
                      ),
                      selected: selected,
                      onSelected: (value) => _applyFilter(
                        value
                            ? _filter.copyWith(genre: genre)
                            : _filter.copyWith(clearGenre: true),
                      ),
                    );
                  },
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 6),
              child: Row(
                children: [
                  Text(
                    '${_items.length} judul',
                    style: const TextStyle(
                      fontSize: 11.5,
                      color: AppColors.textMuted,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _filter.sort.label,
                    style: const TextStyle(
                      fontSize: 11.5,
                      color: AppColors.violetNeon,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _loading
                  ? const _GridSkeleton()
                  : _error != null
                      ? AsyncView<List<MediaItem>>(
                          value: AsyncValue.error(_error!, StackTrace.empty),
                          onRetry: () => _load(reset: true),
                          builder: (_) => const SizedBox.shrink(),
                        )
                      : _items.isEmpty
                          ? EmptyState(
                              title: 'Tidak ada hasil',
                              message:
                                  'Coba ubah kata kunci atau filter genre untuk ${kind.label}.',
                              icon: Icons.search_off_rounded,
                              actionLabel: 'Reset filter',
                              onAction: () =>
                                  _applyFilter(const CatalogFilter()),
                            )
                          : RefreshIndicator(
                              onRefresh: () => _load(reset: true),
                              color: AppColors.violet,
                              child: GridView.builder(
                                controller: _scrollController,
                                physics: const BouncingScrollPhysics(),
                                padding: const EdgeInsets.fromLTRB(20, 4, 20, 120),
                                gridDelegate:
                                    SliverGridDelegateWithMaxCrossAxisExtent(
                                  maxCrossAxisExtent: 160,
                                  mainAxisSpacing: 18,
                                  crossAxisSpacing: 14,
                                  childAspectRatio: 0.52,
                                ),
                                itemCount: _items.length + (_loadingMore ? 1 : 0),
                                itemBuilder: (context, index) {
                                  if (index >= _items.length) {
                                    return const Center(
                                      child: SizedBox(
                                        width: 22,
                                        height: 22,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      ),
                                    );
                                  }
                                  final media = _items[index];
                                  return PosterCard(
                                    media: media,
                                    expand: true,
                                    onTap: () => AppNav.media(context, media),
                                  );
                                },
                              ),
                            ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({
    required this.kind,
    required this.onBack,
    required this.onSearch,
    required this.onFilter,
    required this.activeFilters,
  });

  final MediaKind kind;
  final VoidCallback onBack;
  final VoidCallback onSearch;
  final VoidCallback onFilter;
  final bool activeFilters;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: onBack,
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: AppColors.brandGradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(kind.icon, size: 18, color: Colors.white),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  kind.label,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  kind.isVideo
                      ? 'Streaming kualitas premium'
                      : kind.isComic
                          ? 'Baca chapter terbaru'
                          : 'Pustaka teks domain publik',
                  style: const TextStyle(
                    fontSize: 10.5,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
          IconButton(icon: const Icon(Icons.search_rounded), onPressed: onSearch),
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.tune_rounded),
                onPressed: onFilter,
              ),
              if (activeFilters)
                Positioned(
                  right: 10,
                  top: 10,
                  child: Container(
                    width: 7,
                    height: 7,
                    decoration: const BoxDecoration(
                      color: AppColors.gold,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FilterSheet extends StatefulWidget {
  const _FilterSheet({required this.kind, required this.initial});

  final MediaKind kind;
  final CatalogFilter initial;

  @override
  State<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<_FilterSheet> {
  late CatalogFilter _draft = widget.initial;

  static const List<String> _statuses = [
    'RELEASING',
    'FINISHED',
    'NOT_YET_RELEASED',
    'HIATUS',
  ];

  @override
  Widget build(BuildContext context) {
    final years = List.generate(30, (index) => DateTime.now().year - index);
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.8,
      ),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 42,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Filter & Urutkan',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 20),
            const _Label('Urutkan'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final sort in CatalogSort.values)
                  ChoiceChip(
                    label: Text(sort.label),
                    selected: _draft.sort == sort,
                    onSelected: (_) =>
                        setState(() => _draft = _draft.copyWith(sort: sort)),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            if (!widget.kind.isReadable) ...[
              const _Label('Status'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  ChoiceChip(
                    label: const Text('Semua'),
                    selected: _draft.status == null,
                    onSelected: (_) => setState(
                      () => _draft = _draft.copyWith(clearStatus: true),
                    ),
                  ),
                  for (final status in _statuses)
                    ChoiceChip(
                      label: Text(_statusLabel(status)),
                      selected: _draft.status == status,
                      onSelected: (_) => setState(
                        () => _draft = _draft.copyWith(status: status),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 18),
            ],
            const _Label('Tahun'),
            SizedBox(
              height: 40,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: years.length + 1,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return ChoiceChip(
                      label: const Text('Semua'),
                      selected: _draft.year == null,
                      onSelected: (_) => setState(
                        () => _draft = _draft.copyWith(clearYear: true),
                      ),
                    );
                  }
                  final year = years[index - 1];
                  return ChoiceChip(
                    label: Text('$year'),
                    selected: _draft.year == year,
                    onSelected: (_) =>
                        setState(() => _draft = _draft.copyWith(year: year)),
                  );
                },
              ),
            ),
            const SizedBox(height: 26),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(
                      context,
                      const CatalogFilter(sort: CatalogSort.trending),
                    ),
                    child: const Text('Reset'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: FilledButton(
                    onPressed: () => Navigator.pop(
                      context,
                      _draft.copyWith(page: 1),
                    ),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.violet,
                      minimumSize: const Size(0, 50),
                    ),
                    child: const Text('Terapkan'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'RELEASING':
        return widget.kind.isVideo ? 'Sedang Tayang' : 'Ongoing';
      case 'FINISHED':
        return 'Tamat';
      case 'NOT_YET_RELEASED':
        return 'Belum Rilis';
      case 'HIATUS':
        return 'Hiatus';
      default:
        return status;
    }
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }
}

class _GridSkeleton extends StatelessWidget {
  const _GridSkeleton();

  @override
  Widget build(BuildContext context) {
    return Shimmer(
      child: GridView.builder(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 120),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 160,
          mainAxisSpacing: 18,
          crossAxisSpacing: 14,
          childAspectRatio: 0.52,
        ),
        itemCount: 9,
        itemBuilder: (_, __) => const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: SkeletonBox(height: 200, radius: 18)),
            SizedBox(height: 8),
            SkeletonBox(height: 10),
            SizedBox(height: 6),
            SkeletonBox(width: 60, height: 8),
          ],
        ),
      ),
    );
  }
}
