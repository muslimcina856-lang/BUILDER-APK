import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/config/app_config.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/library.dart';
import '../../data/models/media.dart';
import '../../data/models/user_profile.dart';
import '../../data/providers.dart';
import '../../shared/widgets/app_network_image.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/shimmer.dart';
import '../../shared/widgets/user_avatar.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> _refresh(WidgetRef ref) async {
    ref.invalidate(trendingProvider);
    ref.invalidate(seasonProvider);
    ref.invalidate(topRatedProvider);
    ref.invalidate(upcomingProvider);
    ref.invalidate(recentlyUpdatedProvider);
    ref.invalidate(continueWatchingProvider);
    ref.invalidate(gamificationProvider);
    ref.invalidate(personalizedProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(currentProfileProvider);
    final trending = ref.watch(trendingProvider(MediaKind.anime));
    final continueWatching = ref.watch(continueWatchingProvider);
    final gamification = ref.watch(gamificationProvider).valueOrNull;
    final unread = ref.watch(unreadNotificationProvider);

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: RefreshIndicator(
        onRefresh: () => _refresh(ref),
        color: AppColors.violet,
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: _TopBar(
                profile: profile,
                unread: unread,
                exp: gamification?.exp ?? 0,
                level: gamification?.level ?? 1,
                progress: gamification?.levelProgress ?? 0,
                rankKey: gamification?.rankKey ?? 'beginner',
              ),
            ),
            SliverToBoxAdapter(child: _HeroCarousel(trending: trending)),
            // Continue watching
            SliverToBoxAdapter(
              child: continueWatching.maybeWhen(
                data: (items) => items.isEmpty
                    ? const SizedBox.shrink()
                    : _ContinueWatchingSection(items: items),
                orElse: () => const SizedBox.shrink(),
              ),
            ),
            SliverToBoxAdapter(
              child: _QuickActions(
                onSchedule: () => context.push('/schedule'),
                onLeaderboard: () => context.push('/leaderboard'),
                onQuests: () => context.push('/quests'),
                onMembership: () => context.push('/membership'),
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Trending Minggu Ini',
                icon: Icons.local_fire_department_rounded,
                provider: trendingProvider(MediaKind.anime),
                onSeeAll: () => AppNav.category(context, MediaKind.anime),
                ranked: true,
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Populer Musim Ini',
                icon: Icons.whatshot_rounded,
                provider: seasonProvider(MediaKind.anime),
                onSeeAll: () => AppNav.category(context, MediaKind.anime),
                subtitle: 'Anime tayang musim ini',
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Donghua Pilihan',
                icon: Icons.bolt_rounded,
                provider: trendingProvider(MediaKind.donghua),
                onSeeAll: () => AppNav.category(context, MediaKind.donghua),
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Rekomendasi Untukmu',
                icon: Icons.auto_awesome_rounded,
                provider: personalizedProvider(MediaKind.anime),
                subtitle: 'Berdasarkan riwayat tontonanmu',
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Movie Terbaik',
                icon: Icons.movie_creation_rounded,
                provider: topRatedProvider(MediaKind.movie),
                onSeeAll: () => AppNav.category(context, MediaKind.movie),
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Manga & Manhwa Populer',
                icon: Icons.menu_book_rounded,
                provider: popularProvider(MediaKind.manga),
                onSeeAll: () => AppNav.category(context, MediaKind.manga),
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Manhwa Trending',
                icon: Icons.collections_bookmark_rounded,
                provider: trendingProvider(MediaKind.manhwa),
                onSeeAll: () => AppNav.category(context, MediaKind.manhwa),
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Novel Domain Publik',
                icon: Icons.book_rounded,
                provider: trendingProvider(MediaKind.novel),
                onSeeAll: () => AppNav.category(context, MediaKind.novel),
                subtitle: 'Baca langsung dari Wikisource Indonesia',
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Sedang Diperbarui',
                icon: Icons.update_rounded,
                provider: recentlyUpdatedProvider(MediaKind.manga),
                onSeeAll: () => AppNav.category(context, MediaKind.manga),
              ),
            ),
            SliverToBoxAdapter(
              child: _MediaRowSection(
                title: 'Segera Tayang',
                icon: Icons.event_rounded,
                provider: upcomingProvider(MediaKind.anime),
                onSeeAll: () => context.push('/schedule'),
              ),
            ),
            const SliverToBoxAdapter(child: _Footer()),
            const SliverToBoxAdapter(child: SizedBox(height: 110)),
          ],
        ),
      ),
    );
  }
}

class _TopBar extends ConsumerWidget {
  const _TopBar({
    required this.profile,
    required this.unread,
    required this.exp,
    required this.level,
    required this.progress,
    required this.rankKey,
  });

  final UserProfile? profile;
  final int unread;
  final int exp;
  final int level;
  final double progress;
  final String rankKey;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hour = DateTime.now().hour;
    final greeting = hour < 11
        ? 'Selamat pagi'
        : hour < 15
            ? 'Selamat siang'
            : hour < 19
                ? 'Selamat sore'
                : 'Selamat malam';
    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 12, 4),
        child: Column(
          children: [
            Row(
              children: [
                if (profile != null)
                  UserAvatar(
                    imageUrl: profile!.avatarUrl,
                    initials: profile!.initials,
                    tier: profile!.tier,
                    size: 44,
                    onTap: () => context.go('/profile'),
                  )
                else
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: AppColors.brandGradient,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.play_arrow_rounded, color: Colors.white),
                  ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '$greeting,',
                        style: const TextStyle(
                          fontSize: 11.5,
                          color: AppColors.textMuted,
                        ),
                      ),
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              profile?.displayName ?? 'Penjelajah',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                          if (profile != null && profile!.tier.isPaid) ...[
                            const SizedBox(width: 6),
                            TierBadge(tier: profile!.tier),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
                CircleGlassButton(
                  icon: Icons.search_rounded,
                  onTap: () => AppNav.search(context),
                ),
                const SizedBox(width: 8),
                CircleGlassButton(
                  icon: Icons.notifications_none_rounded,
                  badgeCount: unread,
                  onTap: () => context.push('/notifications'),
                ),
              ],
            ),
            if (profile != null) ...[
              const SizedBox(height: 14),
              GestureDetector(
                onTap: () => context.push('/quests'),
                child: GlassCard(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  radius: 16,
                  child: Row(
                    children: [
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          gradient: AppColors.goldGradient,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.bolt_rounded,
                          size: 18,
                          color: AppColors.deepBlack,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  'Lv $level',
                                  style: const TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  '• ${Fmt.number(exp)} EXP',
                                  style: const TextStyle(
                                    fontSize: 10.5,
                                    color: AppColors.textMuted,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 5),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: LinearProgressIndicator(
                                value: progress.clamp(0.02, 1),
                                minHeight: 5,
                                backgroundColor: AppColors.surfaceHigh,
                                valueColor: const AlwaysStoppedAnimation(
                                  AppColors.violetNeon,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      SourcePill(
                        label: 'Quest harian',
                        icon: Icons.task_alt_rounded,
                        color: AppColors.gold,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _HeroCarousel extends ConsumerStatefulWidget {
  const _HeroCarousel({required this.trending});

  final AsyncValue<List<MediaItem>> trending;

  @override
  ConsumerState<_HeroCarousel> createState() => _HeroCarouselState();
}

class _HeroCarouselState extends ConsumerState<_HeroCarousel> {
  final PageController _controller = PageController(viewportFraction: 0.9);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.trending.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Shimmer(child: SkeletonBox(height: 220, radius: 26)),
      ),
      error: (_, __) => const SizedBox.shrink(),
      data: (items) {
        final heroes = items.take(5).toList();
        if (heroes.isEmpty) return const SizedBox.shrink();
        return Column(
          children: [
            SizedBox(
              height: 232,
              child: PageView.builder(
                controller: _controller,
                itemCount: heroes.length,
                itemBuilder: (context, index) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
                  child: _HeroCard(media: heroes[index]),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.media});

  final MediaItem media;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => AppNav.media(context, media),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(26),
        child: Stack(
          fit: StackFit.expand,
          children: [
            AppNetworkImage(
              url: media.bannerUrl ?? media.coverUrl,
              fit: BoxFit.cover,
            ),
            const DecoratedBox(
              decoration: BoxDecoration(gradient: AppColors.heroScrim),
            ),
            Positioned(
              left: 18,
              right: 18,
              bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      GradientBadge(
                        label: media.kind.label,
                        icon: media.kind.icon,
                      ),
                      const SizedBox(width: 6),
                      if (media.score != null)
                        GradientBadge(
                          label: '★ ${media.scoreLabel}',
                          gradient: AppColors.goldGradient,
                          foreground: AppColors.deepBlack,
                        ),
                      const SizedBox(width: 6),
                      if (media.statusLabel.isNotEmpty)
                        GradientBadge(
                          label: media.statusLabel,
                          gradient: LinearGradient(
                            colors: [
                              Colors.white.withValues(alpha: 0.22),
                              Colors.white.withValues(alpha: 0.12),
                            ],
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    media.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 21,
                      height: 1.15,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: -0.4,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text(
                        [
                          if (media.year != null) '${media.year}',
                          if (media.episodes != null) '${media.episodes} eps',
                          if (media.genres.isNotEmpty) media.genres.first,
                        ].join(' • '),
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.white.withValues(alpha: 0.75),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => AppNav.media(context, media),
                          icon: const Icon(Icons.play_arrow_rounded, size: 20),
                          label: const Text('Tonton Sekarang'),
                          style: FilledButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: AppColors.deepBlack,
                            minimumSize: const Size(0, 44),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      _HeroIconButton(
                        icon: Icons.add_rounded,
                        onTap: () => AppNav.media(context, media),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroIconButton extends StatelessWidget {
  const _HeroIconButton({required this.icon, this.onTap});

  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white.withValues(alpha: 0.25)),
            ),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
        ),
      ),
    );
  }
}

class _ContinueWatchingSection extends StatelessWidget {
  const _ContinueWatchingSection({required this.items});

  final List<HistoryEntry> items;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SectionHeader(
          title: 'Lanjutkan Menonton',
          icon: Icons.play_circle_outline_rounded,
          onSeeAll: () => context.push('/history'),
        ),
        SizedBox(
          height: 132,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              final entry = items[index];
              return SizedBox(
                width: 250,
                child: WideMediaCard(
                  media: entry.media,
                  height: 108,
                  label: entry.progressLabel,
                  progress: entry.progress,
                  onTap: () {
                    if (entry.media.kind.isVideo) {
                      AppNav.watch(
                        context,
                        mediaId: entry.media.id,
                        kind: entry.media.kind,
                        episode: entry.episodeNumber ?? 1,
                        title: entry.media.title,
                      );
                    } else {
                      AppNav.media(context, entry.media);
                    }
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({
    required this.onSchedule,
    required this.onLeaderboard,
    required this.onQuests,
    required this.onMembership,
  });

  final VoidCallback onSchedule;
  final VoidCallback onLeaderboard;
  final VoidCallback onQuests;
  final VoidCallback onMembership;

  @override
  Widget build(BuildContext context) {
    final actions = [
      (Icons.calendar_month_rounded, 'Jadwal', AppColors.info, onSchedule),
      (Icons.leaderboard_rounded, 'Ranking', AppColors.violetNeon, onLeaderboard),
      (Icons.task_alt_rounded, 'Quest', AppColors.success, onQuests),
      (Icons.workspace_premium_rounded, 'VIP', AppColors.gold, onMembership),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Row(
        children: [
          for (final action in actions) ...[
            Expanded(
              child: GestureDetector(
                onTap: action.$4,
                child: GlassCard(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  radius: 18,
                  child: Column(
                    children: [
                      Icon(action.$1, size: 20, color: action.$3),
                      const SizedBox(height: 6),
                      Text(
                        action.$2,
                        style: const TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (action != actions.last) const SizedBox(width: 10),
          ],
        ],
      ),
    );
  }
}

class _MediaRowSection extends ConsumerWidget {
  const _MediaRowSection({
    required this.title,
    required this.icon,
    required this.provider,
    this.onSeeAll,
    this.subtitle,
    this.ranked = false,
  });

  final String title;
  final String? subtitle;
  final IconData icon;
  final FutureProvider<List<MediaItem>> provider;
  final VoidCallback? onSeeAll;
  final bool ranked;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watch(provider).maybeWhen(
      data: (items) {
        if (items.isEmpty) return const SizedBox.shrink();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionHeader(
              title: title,
              subtitle: subtitle,
              icon: icon,
              onSeeAll: onSeeAll,
            ),
            SizedBox(
              height: 268,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (context, index) => PosterCard(
                  media: items[index],
                  showRank: ranked ? index + 1 : null,
                  onTap: () => AppNav.media(context, items[index]),
                ),
              ),
            ),
          ],
        );
      },
      loading: () => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(title: title, subtitle: subtitle, icon: icon),
          const PosterRowSkeleton(),
        ],
      ),
      orElse: () => const SizedBox.shrink(),
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 30, 20, 0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GradientText(
                AppConfig.appName,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.5,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                AppConfig.appVersion,
                style: TextStyle(fontSize: 10, color: AppColors.textMuted),
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Text(
            'Data katalog: AniList • MangaDex • Wikisource\n'
            'Streaming hanya untuk konten berlisensi resmi.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 10, height: 1.6, color: AppColors.textMuted),
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: () => context.push('/faq'),
            child: const Text(
              'Bantuan & Kebijakan',
              style: TextStyle(fontSize: 11.5, color: AppColors.violetNeon),
            ),
          ),
        ],
      ),
    );
  }
}
