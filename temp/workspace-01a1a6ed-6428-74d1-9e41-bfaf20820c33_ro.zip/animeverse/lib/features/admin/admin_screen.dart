import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/config/app_config.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/community.dart';
import '../../data/models/episode.dart';
import '../../data/models/media.dart';
import '../../data/models/membership.dart';
import '../../data/models/user_profile.dart';
import '../../data/providers.dart';
import '../../data/repositories/admin_repository.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/user_avatar.dart';
import '../../shared/widgets/widgets.dart';

class AdminScreen extends ConsumerStatefulWidget {
  const AdminScreen({super.key});

  @override
  ConsumerState<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends ConsumerState<AdminScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController =
      TabController(length: 6, vsync: this);

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final session = ref.watch(sessionProvider);
    if (!session.canModerate) {
      return Scaffold(
        appBar: AppBar(title: const Text('Panel Admin')),
        body: const EmptyState(
          title: 'Akses ditolak',
          message: 'Halaman ini hanya untuk admin dan moderator.',
          icon: Icons.lock_rounded,
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.shield_rounded, size: 18, color: AppColors.gold),
            const SizedBox(width: 8),
            const Text('Panel Admin'),
            const SizedBox(width: 8),
            GradientBadge(
              label: session.profile?.role.label.toUpperCase() ?? 'ADMIN',
              gradient: AppColors.goldGradient,
              foreground: AppColors.deepBlack,
            ),
          ],
        ),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          dividerColor: Colors.transparent,
          labelColor: AppColors.violetNeon,
          unselectedLabelColor: AppColors.textMuted,
          indicatorColor: AppColors.violet,
          labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
          tabs: const [
            Tab(text: 'Dashboard'),
            Tab(text: 'Konten'),
            Tab(text: 'Pengguna'),
            Tab(text: 'Moderasi'),
            Tab(text: 'Transaksi'),
            Tab(text: 'Sistem'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _DashboardTab(),
          _ContentTab(),
          _UsersTab(),
          _ModerationTab(),
          _TransactionsTab(),
          _SystemTab(),
        ],
      ),
    );
  }
}

// ───────────────────────────── Dashboard ─────────────────────────────

class _DashboardTab extends ConsumerWidget {
  const _DashboardTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stats = ref.watch(adminStatsProvider);
    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(adminStatsProvider),
      color: AppColors.violet,
      child: stats.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => EmptyState(
          title: 'Gagal memuat statistik',
          message: '$error',
          icon: Icons.cloud_off_rounded,
        ),
        data: (data) => ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
          children: [
            GlassCard(
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: AppColors.brandGradient,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.insights_rounded, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          data.revenueLabel,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            color: AppColors.gold,
                          ),
                        ),
                        const Text(
                          'Pendapatan membership terverifikasi',
                          style: TextStyle(fontSize: 10.5, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.9,
              children: [
                _StatCard(
                  icon: Icons.people_alt_rounded,
                  label: 'Total pengguna',
                  value: Fmt.number(data.totalUsers),
                  color: AppColors.violetNeon,
                ),
                _StatCard(
                  icon: Icons.verified_user_rounded,
                  label: 'Pengguna aktif',
                  value: Fmt.number(data.activeUsers),
                  color: AppColors.success,
                ),
                _StatCard(
                  icon: Icons.video_library_rounded,
                  label: 'Judul terdaftar',
                  value: Fmt.number(data.totalContent),
                  color: AppColors.info,
                ),
                _StatCard(
                  icon: Icons.playlist_play_rounded,
                  label: 'Total episode',
                  value: Fmt.number(data.totalEpisodes),
                  color: AppColors.violet,
                ),
                _StatCard(
                  icon: Icons.menu_book_rounded,
                  label: 'Total chapter',
                  value: Fmt.number(data.totalChapters),
                  color: AppColors.gold,
                ),
                _StatCard(
                  icon: Icons.forum_rounded,
                  label: 'Komentar',
                  value: Fmt.number(data.totalComments),
                  color: AppColors.warning,
                ),
                _StatCard(
                  icon: Icons.flag_rounded,
                  label: 'Laporan terbuka',
                  value: Fmt.number(data.openReports),
                  color: AppColors.danger,
                ),
                _StatCard(
                  icon: Icons.dns_rounded,
                  label: 'Sumber streaming',
                  value: Fmt.number(data.streamSources),
                  color: AppColors.success,
                ),
              ],
            ),
            const SizedBox(height: 16),
            SoftCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Checklist operasional',
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _CheckRow(
                    ok: data.streamSources > 0,
                    text: 'Sumber streaming resmi terdaftar '
                        '(${data.streamSources})',
                  ),
                  const _CheckRow(
                    ok: true,
                    text: 'Kredensial API metadata aktif (AniList/MangaDex)',
                  ),
                  _CheckRow(
                    ok: data.openReports == 0,
                    text: 'Laporan moderasi tertangani (${data.openReports} tersisa)',
                  ),
                  const _CheckRow(
                    ok: true,
                    text: 'RLS aktif pada tabel pengguna (cek schema.sql)',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  final IconData icon;
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return SoftCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Icon(icon, size: 15, color: color),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 9.5, color: AppColors.textMuted),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

class _CheckRow extends StatelessWidget {
  const _CheckRow({required this.ok, required this.text});

  final bool ok;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(
            ok ? Icons.check_circle_rounded : Icons.error_rounded,
            size: 14,
            color: ok ? AppColors.success : AppColors.warning,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────────── Konten ─────────────────────────────

class _ContentTab extends ConsumerStatefulWidget {
  const _ContentTab();

  @override
  ConsumerState<_ContentTab> createState() => _ContentTabState();
}

class _ContentTabState extends ConsumerState<_ContentTab> {
  @override
  Widget build(BuildContext context) {
    final sources = ref.watch(adminSourcesProvider);
    final content = ref.watch(adminRepositoryProvider);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text(
                'Sumber streaming (HLS/MP4)',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
            FilledButton.icon(
              onPressed: () => _openSourceDialog(),
              icon: const Icon(Icons.add_rounded, size: 16),
              label: const Text('Tambah', style: TextStyle(fontSize: 11.5)),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.violet,
                minimumSize: const Size(0, 36),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        const Text(
          'Hanya URL resmi/berlisensi. Sumber dipakai player untuk episode terkait; '
          'tanpa sumber, aplikasi menampilkan status konten belum tersedia.',
          style: TextStyle(fontSize: 10, height: 1.5, color: AppColors.textMuted),
        ),
        const SizedBox(height: 12),
        sources.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Text('$error'),
          data: (list) {
            final items = list.whereType<StreamSource>().toList();
            if (items.isEmpty) {
              return const SoftCard(
                child: Text(
                  'Belum ada sumber terdaftar. Player akan menampilkan status '
                  '"konten belum tersedia" untuk semua episode.',
                  style: TextStyle(fontSize: 11.5, height: 1.6, color: AppColors.textMuted),
                ),
              );
            }
            return Column(
              children: [
                for (final source in items)
                  SoftCard(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SourcePill(
                              label: source.type.toUpperCase(),
                              icon: Icons.dns_rounded,
                              color: AppColors.success,
                            ),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                source.server,
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline_rounded, size: 18),
                              onPressed: () async {
                                await content.deleteSource(source.id);
                                ref.invalidate(adminSourcesProvider);
                                ref.invalidate(adminStatsProvider);
                              },
                            ),
                          ],
                        ),
                        Text(
                          '${source.contentId} • Episode ${source.episodeNumber}',
                          style: const TextStyle(
                            fontSize: 10.5,
                            color: AppColors.textMuted,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          source.url,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 9.5,
                            color: AppColors.info,
                          ),
                        ),
                        if (source.licenseNote != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              'Lisensi: ${source.licenseNote}',
                              style: const TextStyle(
                                fontSize: 9.5,
                                color: AppColors.gold,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
              ],
            );
          },
        ),
        const SizedBox(height: 20),
        const Text(
          'Konten kustom (lisensi eksklusif)',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        FutureBuilder<List<MediaItem>>(
          future: content.customContent(),
          builder: (context, snapshot) {
            final items = snapshot.data ?? const <MediaItem>[];
            if (items.isEmpty) {
              return const SoftCard(
                child: Text(
                  'Belum ada konten kustom. Katalog API publik tetap tampil di '
                  'halaman kategori.',
                  style: TextStyle(fontSize: 11.5, color: AppColors.textMuted),
                ),
              );
            }
            return Column(
              children: [
                for (final item in items)
                  ListTile(
                    dense: true,
                    title: Text(item.title, style: const TextStyle(fontSize: 12)),
                    subtitle: Text(
                      '${item.kind.label} • ${item.status ?? '-'}',
                      style: const TextStyle(fontSize: 10),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, size: 16),
                      onPressed: () async {
                        await content.deleteCustomContent(item.id);
                        setState(() {});
                      },
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }

  Future<void> _openSourceDialog() async {
    final contentIdController = TextEditingController();
    final episodeController = TextEditingController(text: '1');
    final serverController = TextEditingController(text: 'Server Utama');
    final urlController = TextEditingController();
    final licenseController = TextEditingController();
    final subtitleController = TextEditingController();
    final introStartController = TextEditingController();
    final introEndController = TextEditingController();
    String type = 'hls';

    await showDialog<void>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateLocal) => AlertDialog(
          title: const Text('Tambah sumber streaming', style: TextStyle(fontSize: 16)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: contentIdController,
                  decoration: const InputDecoration(
                    labelText: 'Content ID',
                    hintText: 'anilist:21',
                    helperText: 'ID media (contoh: anilist:21 atau mangadex:uuid)',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: episodeController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Episode'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: serverController,
                  decoration: const InputDecoration(labelText: 'Nama server'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: urlController,
                  decoration: const InputDecoration(
                    labelText: 'URL manifest',
                    hintText: 'https://cdn.example.com/master.m3u8',
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  children: [
                    for (final option in ['hls', 'mp4', 'dash'])
                      ChoiceChip(
                        label: Text(option.toUpperCase(),
                            style: const TextStyle(fontSize: 10)),
                        selected: type == option,
                        onSelected: (_) => setStateLocal(() => type = option),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: subtitleController,
                  decoration: const InputDecoration(
                    labelText: 'URL subtitle (VTT/SRT)',
                    hintText: 'https://cdn.example.com/ep1-id.vtt',
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: introStartController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Intro mulai (s)'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: introEndController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Intro akhir (s)'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: licenseController,
                  decoration: const InputDecoration(
                    labelText: 'Catatan lisensi',
                    hintText: 'Lisensi distribusi dari pemegang hak',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            FilledButton(
              onPressed: () async {
                final error = await ref.read(adminRepositoryProvider).saveSource(
                      StreamSource(
                        id: 'src${DateTime.now().microsecondsSinceEpoch}',
                        contentId: contentIdController.text.trim(),
                        episodeNumber:
                            int.tryParse(episodeController.text.trim()) ?? 1,
                        server: serverController.text.trim().isEmpty
                            ? 'Server 1'
                            : serverController.text.trim(),
                        url: urlController.text.trim(),
                        type: type,
                        qualities: const ['360', '480', '720', '1080'],
                        subtitles: subtitleController.text.trim().isEmpty
                            ? const []
                            : [
                                MediaTrack(
                                  label: 'Bahasa Indonesia',
                                  url: subtitleController.text.trim(),
                                  language: 'id',
                                  isDefault: true,
                                ),
                              ],
                        licenseNote: licenseController.text.trim().isEmpty
                            ? null
                            : licenseController.text.trim(),
                        introStart: int.tryParse(introStartController.text.trim()),
                        introEnd: int.tryParse(introEndController.text.trim()),
                      ),
                    );
                if (!context.mounted) return;
                if (error != null) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text(error)));
                  return;
                }
                Navigator.pop(context);
                ref.invalidate(adminSourcesProvider);
                ref.invalidate(adminStatsProvider);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Sumber streaming disimpan')),
                );
              },
              child: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────────── Pengguna ─────────────────────────────

class _UsersTab extends ConsumerStatefulWidget {
  const _UsersTab();

  @override
  ConsumerState<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends ConsumerState<_UsersTab> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final users = ref.watch(adminUsersProvider(_query));
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Cari username, nama, atau email…',
              isDense: true,
              prefixIcon: Icon(Icons.search_rounded, size: 18),
            ),
            onChanged: (value) => setState(() => _query = value),
          ),
        ),
        Expanded(
          child: users.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Text('$error'),
            data: (list) {
              if (list.isEmpty) {
                return const EmptyState(
                  title: 'Tidak ada pengguna',
                  message: 'Coba kata kunci lain.',
                  icon: Icons.people_outline_rounded,
                );
              }
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                itemCount: list.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final user = list[index];
                  return SoftCard(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        UserAvatar(
                          imageUrl: user.avatarUrl,
                          initials: user.initials,
                          size: 38,
                          tier: user.tier,
                          showFrame: user.tier.isPaid,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    user.displayName,
                                    style: const TextStyle(
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textPrimary,
                                    ),
                                  ),
                                  if (user.isBanned) ...[
                                    const SizedBox(width: 6),
                                    const SourcePill(
                                      label: 'Banned',
                                      color: AppColors.danger,
                                      icon: Icons.block_rounded,
                                    ),
                                  ],
                                ],
                              ),
                              Text(
                                '@${user.username} • ${user.role.label} • ${user.tier.label}',
                                style: const TextStyle(
                                  fontSize: 10,
                                  color: AppColors.textMuted,
                                ),
                              ),
                              Text(
                                'Lv ${user.level} • ${Fmt.number(user.exp)} EXP',
                                style: const TextStyle(
                                  fontSize: 9.5,
                                  color: AppColors.violetNeon,
                                ),
                              ),
                            ],
                          ),
                        ),
                        PopupMenuButton<String>(
                          icon: const Icon(Icons.more_vert_rounded, size: 18),
                          color: AppColors.surfaceHigh,
                          onSelected: (value) async {
                            final repo = ref.read(adminRepositoryProvider);
                            switch (value) {
                              case 'admin':
                                await repo.setUserRole(user.id, UserRole.admin);
                                break;
                              case 'moderator':
                                await repo.setUserRole(user.id, UserRole.moderator);
                                break;
                              case 'user':
                                await repo.setUserRole(user.id, UserRole.user);
                                break;
                              case 'ban':
                                await repo.setUserBanned(user.id, !user.isBanned);
                                break;
                              case 'vip':
                                await repo.grantMembership(
                                    user.id, MembershipTier.vip, 1);
                                break;
                              case 'premium':
                                await repo.grantMembership(
                                    user.id, MembershipTier.premium, 1);
                                break;
                            }
                            ref.invalidate(adminUsersProvider(_query));
                            ref.invalidate(adminStatsProvider);
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              value: 'admin',
                              child: Text('Jadikan Admin', style: TextStyle(fontSize: 12)),
                            ),
                            const PopupMenuItem(
                              value: 'moderator',
                              child: Text('Jadikan Moderator',
                                  style: TextStyle(fontSize: 12)),
                            ),
                            const PopupMenuItem(
                              value: 'user',
                              child: Text('Turunkan ke User',
                                  style: TextStyle(fontSize: 12)),
                            ),
                            PopupMenuItem(
                              value: 'ban',
                              child: Text(
                                user.isBanned ? 'Buka blokir' : 'Blokir pengguna',
                                style: const TextStyle(fontSize: 12),
                              ),
                            ),
                            const PopupMenuItem(
                              value: 'vip',
                              child: Text('Beri VIP 1 bulan',
                                  style: TextStyle(fontSize: 12)),
                            ),
                            const PopupMenuItem(
                              value: 'premium',
                              child: Text('Beri Premium 1 bulan',
                                  style: TextStyle(fontSize: 12)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

// ───────────────────────────── Moderasi ─────────────────────────────

class _ModerationTab extends ConsumerWidget {
  const _ModerationTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reports = ref.watch(adminReportsProvider);
    return reports.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Text('$error'),
      data: (items) {
        if (items.isEmpty) {
          return const EmptyState(
            title: 'Tidak ada laporan',
            message: 'Semua laporan moderasi sudah ditangani.',
            icon: Icons.verified_rounded,
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final report = items[index];
            return SoftCard(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      SourcePill(
                        label: report.statusLabel,
                        icon: Icons.flag_rounded,
                        color: report.status == ReportStatus.open
                            ? AppColors.danger
                            : AppColors.success,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          report.reason,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ),
                      Text(
                        Fmt.relative(report.createdAt),
                        style: const TextStyle(
                          fontSize: 9,
                          color: AppColors.textMuted,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Target: ${report.targetType} • ${report.targetId}',
                    style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                  ),
                  if (report.detail.isNotEmpty)
                    Text(
                      report.detail,
                      style: const TextStyle(
                        fontSize: 10.5,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () async {
                            await ref
                                .read(communityRepositoryProvider)
                                .updateReportStatus(report.id, ReportStatus.resolved);
                            ref.invalidate(adminReportsProvider);
                            ref.invalidate(adminStatsProvider);
                          },
                          style: OutlinedButton.styleFrom(
                            minimumSize: const Size(0, 34),
                          ),
                          child: const Text('Selesaikan', style: TextStyle(fontSize: 11)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () async {
                            await ref
                                .read(communityRepositoryProvider)
                                .updateReportStatus(report.id, ReportStatus.rejected);
                            ref.invalidate(adminReportsProvider);
                          },
                          style: OutlinedButton.styleFrom(
                            minimumSize: const Size(0, 34),
                          ),
                          child: const Text('Tolak', style: TextStyle(fontSize: 11)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () async {
                            await ref
                                .read(communityRepositoryProvider)
                                .deleteComment(report.targetId);
                            await ref
                                .read(communityRepositoryProvider)
                                .updateReportStatus(report.id, ReportStatus.resolved);
                            ref.invalidate(adminReportsProvider);
                            ref.invalidate(communityFeedProvider);
                          },
                          style: OutlinedButton.styleFrom(
                            minimumSize: const Size(0, 34),
                            foregroundColor: AppColors.danger,
                          ),
                          child: const Text('Hapus konten',
                              style: TextStyle(fontSize: 11)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ───────────────────────────── Transaksi ─────────────────────────────

class _TransactionsTab extends ConsumerWidget {
  const _TransactionsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final transactions = ref.watch(adminTransactionsProvider);
    return transactions.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Text('$error'),
      data: (items) {
        if (items.isEmpty) {
          return const EmptyState(
            title: 'Belum ada transaksi',
            message: 'Transaksi membership akan tampil di sini untuk diverifikasi.',
            icon: Icons.receipt_long_rounded,
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final payment = items[index];
            return SoftCard(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${payment.tier.label} • ${payment.months} bulan',
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ),
                      Text(
                        payment.amountLabel,
                        style: const TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: AppColors.gold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${payment.id} • ${payment.method} • ${Fmt.dateTime(payment.createdAt)}',
                    style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                  ),
                  const SizedBox(height: 4),
                  SourcePill(
                    label: payment.statusLabel,
                    icon: Icons.info_rounded,
                    color: payment.status == PaymentStatus.paid
                        ? AppColors.success
                        : payment.status == PaymentStatus.pending
                            ? AppColors.warning
                            : AppColors.danger,
                  ),
                  if (payment.status == PaymentStatus.pending) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton(
                            onPressed: () async {
                              await ref
                                  .read(membershipRepositoryProvider)
                                  .approveFromAdmin(
                                    payment,
                                    ref.read(currentProfileProvider)?.id ?? 'guest',
                                  );
                              ref.invalidate(adminTransactionsProvider);
                              ref.invalidate(adminStatsProvider);
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Transaksi disetujui & membership aktif'),
                                  ),
                                );
                              }
                            },
                            style: FilledButton.styleFrom(
                              backgroundColor: AppColors.success,
                              minimumSize: const Size(0, 36),
                            ),
                            child: const Text('Setujui',
                                style: TextStyle(fontSize: 11, color: Colors.black)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () async {
                              await ref
                                  .read(membershipRepositoryProvider)
                                  .rejectFromAdmin(payment);
                              ref.invalidate(adminTransactionsProvider);
                            },
                            style: OutlinedButton.styleFrom(
                              minimumSize: const Size(0, 36),
                              foregroundColor: AppColors.danger,
                            ),
                            child: const Text('Tolak', style: TextStyle(fontSize: 11)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            );
          },
        );
      },
    );
  }
}

// ───────────────────────────── Sistem ─────────────────────────────

class _SystemTab extends ConsumerStatefulWidget {
  const _SystemTab();

  @override
  ConsumerState<_SystemTab> createState() => _SystemTabState();
}

class _SystemTabState extends ConsumerState<_SystemTab> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _bodyController = TextEditingController();

  @override
  void dispose() {
    _titleController.dispose();
    _bodyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final banners = ref.watch(adminBannersProvider);
    final settings = ref.watch(adminSettingsProvider).valueOrNull ?? const {};
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
      children: [
        const Text(
          'Push Notification',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        SoftCard(
          child: Column(
            children: [
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Judul'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _bodyController,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'Isi pesan'),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () async {
                    if (_titleController.text.trim().isEmpty) return;
                    await ref.read(adminRepositoryProvider).sendPushNotification(
                          title: _titleController.text.trim(),
                          body: _bodyController.text.trim(),
                        );
                    _titleController.clear();
                    _bodyController.clear();
                    ref.invalidate(notificationsProvider);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Notifikasi dikirim')),
                      );
                    }
                  },
                  icon: const Icon(Icons.send_rounded, size: 16),
                  label: const Text('Kirim ke semua pengguna'),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.violet,
                    minimumSize: const Size(0, 44),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            const Expanded(
              child: Text(
                'Banner beranda',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
            FilledButton.icon(
              onPressed: _addBanner,
              icon: const Icon(Icons.add_rounded, size: 16),
              label: const Text('Tambah', style: TextStyle(fontSize: 11.5)),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.violet,
                minimumSize: const Size(0, 36),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        banners.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Text('$error'),
          data: (items) {
            if (items.isEmpty) {
              return const SoftCard(
                child: Text(
                  'Belum ada banner kustom. Beranda memakai banner otomatis dari '
                  'judul trending AniList.',
                  style: TextStyle(fontSize: 11.5, color: AppColors.textMuted),
                ),
              );
            }
            return Column(
              children: [
                for (final banner in items)
                  SoftCard(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(10),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                banner.title,
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              Text(
                                banner.imageUrl,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 9.5,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Switch.adaptive(
                          value: banner.isActive,
                          onChanged: (value) async {
                            await ref.read(adminRepositoryProvider).saveBanner(
                                  banner.copyWith(isActive: value),
                                );
                            ref.invalidate(adminBannersProvider);
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, size: 16),
                          onPressed: () async {
                            await ref
                                .read(adminRepositoryProvider)
                                .deleteBanner(banner.id);
                            ref.invalidate(adminBannersProvider);
                          },
                        ),
                      ],
                    ),
                  ),
              ],
            );
          },
        ),
        const SizedBox(height: 20),
        const Text(
          'Pengaturan aplikasi & API',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        SoftCard(
          child: Column(
            children: [
              _SettingRow(
                label: 'Nama aplikasi',
                value: '${settings['appName'] ?? AppConfig.appName}',
              ),
              _SettingRow(
                label: 'Kualitas maksimum',
                value: '${settings['maxQuality'] ?? '1080p'}',
              ),
              _SettingRow(
                label: 'Mode maintenance',
                value: (settings['maintenanceMode'] == true) ? 'Aktif' : 'Nonaktif',
              ),
              _SettingRow(
                label: 'Komentar',
                value: (settings['commentsEnabled'] == false) ? 'Nonaktif' : 'Aktif',
              ),
              _SettingRow(
                label: 'Registrasi',
                value: (settings['registrationOpen'] == false) ? 'Ditutup' : 'Terbuka',
              ),
              _SettingRow(
                label: 'Endpoint AniList',
                value: '${settings['anilistEndpoint'] ?? AppConfig.anilistEndpoint}',
              ),
              _SettingRow(
                label: 'Endpoint MangaDex',
                value: '${settings['mangadexEndpoint'] ?? AppConfig.mangadexEndpoint}',
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    await ref.read(adminRepositoryProvider).saveSettings({
                      ...settings,
                      'commentsEnabled': !(settings['commentsEnabled'] == false),
                    });
                    ref.invalidate(adminSettingsProvider);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Pengaturan disimpan')),
                      );
                    }
                  },
                  icon: const Icon(Icons.toggle_on_rounded, size: 16),
                  label: const Text('Toggle komentar'),
                  style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const SoftCard(
          child: Text(
            'Catatan: pada mode Supabase, seluruh operasi panel ini memakai tabel '
            'Postgres dengan RLS. Kebijakan admin_roles membatasi akses tulis hanya '
            'untuk role admin/moderator sesuai permission pada schema.sql.',
            style: TextStyle(fontSize: 10.5, height: 1.6, color: AppColors.textMuted),
          ),
        ),
      ],
    );
  }

  Future<void> _addBanner() async {
    final titleController = TextEditingController();
    final imageController = TextEditingController();
    final targetController = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Banner baru', style: TextStyle(fontSize: 15)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: 'Judul'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: imageController,
              decoration: const InputDecoration(
                labelText: 'URL gambar',
                hintText: 'https://…',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: targetController,
              decoration: const InputDecoration(
                labelText: 'Target ID (opsional)',
                hintText: 'anilist:21',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () async {
              if (titleController.text.trim().isEmpty ||
                  imageController.text.trim().isEmpty) {
                return;
              }
              await ref.read(adminRepositoryProvider).saveBanner(
                    BannerItem(
                      id: 'banner${DateTime.now().microsecondsSinceEpoch}',
                      title: titleController.text.trim(),
                      imageUrl: imageController.text.trim(),
                      targetId: targetController.text.trim(),
                      order: ref.read(adminBannersProvider).valueOrNull?.length ?? 0,
                    ),
                  );
              ref.invalidate(adminBannersProvider);
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }
}

class _SettingRow extends StatelessWidget {
  const _SettingRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          SizedBox(
            width: 130,
            child: Text(
              label,
              style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted),
            ),
          ),
          Expanded(
            child: Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
