import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/config/app_config.dart';
import '../../core/theme/app_colors.dart';
import '../../shared/widgets/glass_card.dart';

class FaqScreen extends StatelessWidget {
  const FaqScreen({super.key});

  static const List<(String, String)> _faqs = [
    (
      'Kenapa beberapa anime tidak bisa diputar?',
      'ANIMEVERSE hanya memutar video dari sumber resmi/berlisensi. Bila episode '
          'belum memiliki sumber video resmi yang terdaftar, aplikasi menampilkan '
          'status "konten belum tersedia" dan tidak menayangkan tautan tidak resmi. '
          'Gunakan tautan platform resmi pada tab Info judul.'
    ),
    (
      'Dari mana data katalog berasal?',
      'Metadata anime, donghua, movie, manga, manhwa, manhua dan novel diambil dari '
          'AniList GraphQL API. Chapter komik berasal dari MangaDex. Teks novel '
          'berasal dari Wikisource Bahasa Indonesia (domain publik / CC BY-SA).'
    ),
    (
      'Bagaimana cara naik level dan rank?',
      'EXP diperoleh dari menonton (maks 300/hari), membaca (maks 300/hari), '
          'komentar (maks 120/hari), bookmark, dan quest. Total 12 rank dari '
          'Beginner hingga Godlike.'
    ),
    (
      'Apakah download offline tersedia untuk semua judul?',
      'Tidak. Unduhan hanya tersedia bila pemegang lisensi mengizinkan dan sumber '
          'video resmi sudah didaftarkan admin dengan penanda downloadable.'
    ),
    (
      'Bagaimana kebijakan refund membership?',
      'Refund dapat diajukan maksimal 3 hari setelah pembayaran jika fitur premium '
          'belum digunakan. Hubungi support dengan menyertakan ID transaksi.'
    ),
    (
      'Apakah data saya aman?',
      'Autentikasi memakai Supabase Auth. Data pengguna dilindungi Row Level '
          'Security (RLS) sehingga hanya pemilik akun dan admin berwenang yang dapat '
          'mengakses. Foto profil dan cover disimpan di Supabase Storage.'
    ),
    (
      'Kenapa komentar saya ditolak?',
      'Ada filter anti-spam: panjang minimal, kata terlarang, tautan berlebih, dan '
          'jeda 15 detik antar komentar. Moderator juga dapat meninjau laporan.'
    ),
    (
      'Bagaimana menambahkan judul berlisensi?',
      'Pemegang lisensi/penerbit dapat menghubungi support@animeverse.app. Admin '
          'menambahkan konten dan sumber HLS resmi melalui Panel Admin.'
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bantuan & Kebijakan')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        children: [
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.support_agent_rounded,
                        size: 18, color: AppColors.violetNeon),
                    SizedBox(width: 8),
                    Text(
                      'Customer Support',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Tim kami merespons dalam 1×24 jam pada hari kerja. '
                  'Untuk member Ultimate, prioritas < 2 jam.',
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.55,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final uri = Uri(
                            scheme: 'mailto',
                            path: AppConfig.supportEmail.first,
                            query: 'subject=Dukungan ANIMEVERSE',
                          );
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(uri);
                          }
                        },
                        icon: const Icon(Icons.email_rounded, size: 16),
                        label: const Text(
                          'Email',
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => showModalBottomSheet<void>(
                          context: context,
                          builder: (context) => const _ReportSheet(),
                        ),
                        icon: const Icon(Icons.flag_rounded, size: 16),
                        label: const Text(
                          'Laporkan',
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Pertanyaan Umum',
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          for (final faq in _faqs)
            Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: SoftCard(
                margin: const EdgeInsets.only(bottom: 8),
                padding: EdgeInsets.zero,
                child: ExpansionTile(
                  tilePadding: const EdgeInsets.symmetric(horizontal: 14),
                  childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                  collapsedIconColor: AppColors.textMuted,
                  iconColor: AppColors.violetNeon,
                  title: Text(
                    faq.$1,
                    style: const TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  children: [
                    Text(
                      faq.$2,
                      style: const TextStyle(
                        fontSize: 11.5,
                        height: 1.65,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 16),
          const Text(
            'Legal',
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          const SoftCard(
            child: Text(
              'ANIMEVERSE adalah aplikasi agregator hiburan. Seluruh metadata dan '
              'gambar poster merupakan hak pemiliknya masing-masing dan disediakan '
              'oleh API publik (AniList, MangaDex, Wikimedia). Konten video hanya '
              'ditampilkan dari sumber yang memiliki izin distribusi. Untuk '
              'permintaan takedown, hubungi support@animeverse.app dengan bukti '
              'kepemilikan hak.',
              style: TextStyle(
                fontSize: 10.5,
                height: 1.7,
                color: AppColors.textMuted,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReportSheet extends StatefulWidget {
  const _ReportSheet();

  @override
  State<_ReportSheet> createState() => _ReportSheetState();
}

class _ReportSheetState extends State<_ReportSheet> {
  final TextEditingController _controller = TextEditingController();
  String _type = 'Bug aplikasi';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Laporkan Masalah',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: [
              for (final type in ['Bug aplikasi', 'Konten salah', 'Pelanggaran hak cipta'])
                ChoiceChip(
                  label: Text(type, style: const TextStyle(fontSize: 11)),
                  selected: _type == type,
                  onSelected: (_) => setState(() => _type = type),
                ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _controller,
            maxLines: 4,
            decoration: const InputDecoration(hintText: 'Jelaskan detail masalah…'),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Laporan "$_type" terkirim. Tim akan meninjau dalam 1×24 jam.',
                    ),
                  ),
                );
              },
              style: FilledButton.styleFrom(backgroundColor: AppColors.violet),
              child: const Text('Kirim laporan'),
            ),
          ),
        ],
      ),
    );
  }
}
