import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/community.dart';
import '../../data/providers.dart';
import '../../data/repositories/community_repository.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/user_avatar.dart';
import 'comment_section.dart';
import '../../shared/widgets/widgets.dart';

class CommunityScreen extends ConsumerStatefulWidget {
  const CommunityScreen({super.key});

  @override
  ConsumerState<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends ConsumerState<CommunityScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 2, vsync: this);
  final TextEditingController _chatController = TextEditingController();
  List<ChatMessage> _messages = const [];
  bool _sending = false;
  bool _privateChatEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadChat();
    _checkPrivateChat();
  }

  Future<void> _checkPrivateChat() async {
    final media = ref.read(membershipProvider).valueOrNull;
    if (!mounted) return;
    setState(() {
      _privateChatEnabled = (media?.effectiveTier.rank ?? 0) >= 2;
    });
  }

  Future<void> _loadChat() async {
    final messages = ref
        .read(communityRepositoryProvider)
        .messages(Bus.chatRoomId);
    if (mounted) setState(() => _messages = messages);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _chatController.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _chatController.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    try {
      await ref.read(communityRepositoryProvider).sendMessage(Bus.chatRoomId, text);
      _chatController.clear();
      await _loadChat();
      await ref.read(gamificationRepositoryProvider).awardExp(
            amount: 5,
            category: 'social',
            reason: 'Chat komunitas',
          );
      ref.invalidate(gamificationProvider);
    } on CommunityException catch (error) {
      if (mounted) showSnack(context, error.message, error: true);
    } catch (error) {
      if (mounted) showSnack(context, 'Gagal mengirim pesan', error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 16, 8),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Komunitas',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                            letterSpacing: -0.4,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'Diskusi, chat, dan teman baru sesama penggemar',
                          style: TextStyle(fontSize: 11.5, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ),
                  CircleGlassButton(
                    icon: _privateChatEnabled
                        ? Icons.chat_bubble_rounded
                        : Icons.lock_rounded,
                    onTap: () {
                      if (_privateChatEnabled) {
                        showSnack(context, 'Private chat tersedia untuk Premium & Ultimate');
                      } else {
                        context.push('/membership');
                      }
                    },
                  ),
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  gradient: AppColors.brandGradient,
                  borderRadius: BorderRadius.circular(12),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: Colors.white,
                unselectedLabelColor: AppColors.textSecondary,
                labelStyle:
                    const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                tabs: const [Tab(text: 'Feed'), Tab(text: 'Chat Global')],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [_buildFeed(), _buildChat()],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeed() {
    final feed = ref.watch(communityFeedProvider);
    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(communityFeedProvider),
      color: AppColors.violet,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 130),
        children: [
          CommentSection(
            target: CommentTarget.community,
            targetId: 'global',
            title: 'Diskusi Global',
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              const Text(
                'Aktivitas Terbaru',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              const Spacer(),
              feed.maybeWhen(
                data: (items) => Text(
                  '${items.length} aktivitas',
                  style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted),
                ),
                orElse: () => const SizedBox.shrink(),
              ),
            ],
          ),
          const SizedBox(height: 10),
          feed.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => Text('$error'),
            data: (items) {
              if (items.isEmpty) {
                return const Text(
                  'Belum ada aktivitas komunitas.',
                  style: TextStyle(fontSize: 12, color: AppColors.textMuted),
                );
              }
              return Column(
                children: [
                  for (final item in items.take(12))
                    SoftCard(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          UserAvatar(
                            imageUrl: item.author.avatarUrl,
                            initials: item.author.username
                                .substring(0, item.author.username.length >= 2 ? 2 : 1)
                                .toUpperCase(),
                            size: 30,
                            showFrame: item.author.tier != 'free',
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      item.author.name,
                                      style: const TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      Fmt.relative(item.createdAt),
                                      style: const TextStyle(
                                        fontSize: 9.5,
                                        color: AppColors.textMuted,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  item.content,
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 11.5,
                                    height: 1.5,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Row(
                                  children: [
                                    const Icon(Icons.thumb_up_alt_rounded,
                                        size: 11, color: AppColors.textMuted),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${item.likes}',
                                      style: const TextStyle(
                                        fontSize: 10,
                                        color: AppColors.textMuted,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    SourcePill(
                                      label: item.targetType.name,
                                      icon: Icons.tag_rounded,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildChat() {
    final session = ref.watch(sessionProvider);
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
            itemCount: _messages.length,
            itemBuilder: (context, index) {
              final message = _messages[index];
              final isMe = message.author.id == session.profile?.id;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment:
                      isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
                  children: [
                    if (!isMe)
                      UserAvatar(
                        imageUrl: message.author.avatarUrl,
                        initials: message.author.username
                            .substring(
                              0,
                              message.author.username.length >= 2 ? 2 : 1,
                            )
                            .toUpperCase(),
                        size: 28,
                        showFrame: false,
                      ),
                    if (!isMe) const SizedBox(width: 8),
                    Flexible(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 9,
                        ),
                        decoration: BoxDecoration(
                          gradient: isMe ? AppColors.brandGradient : null,
                          color: isMe ? null : AppColors.surface,
                          borderRadius: BorderRadius.only(
                            topLeft: const Radius.circular(14),
                            topRight: const Radius.circular(14),
                            bottomLeft: Radius.circular(isMe ? 14 : 4),
                            bottomRight: Radius.circular(isMe ? 4 : 14),
                          ),
                          border: isMe ? null : Border.all(color: AppColors.border),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (!isMe)
                              Text(
                                message.author.name,
                                style: const TextStyle(
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.violetNeon,
                                ),
                              ),
                            Text(
                              message.text,
                              style: TextStyle(
                                fontSize: 12.5,
                                height: 1.5,
                                color: isMe ? Colors.white : AppColors.textPrimary,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              Fmt.relative(message.createdAt),
                              style: TextStyle(
                                fontSize: 8.5,
                                color: isMe
                                    ? Colors.white70
                                    : AppColors.textMuted,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (isMe) const SizedBox(width: 8),
                    if (isMe)
                      UserAvatar(
                        imageUrl: session.profile?.avatarUrl,
                        initials: session.profile?.initials ?? 'AV',
                        size: 28,
                        showFrame: false,
                      ),
                  ],
                ),
              );
            },
          ),
        ),
        Container(
          padding: EdgeInsets.fromLTRB(
            16,
            10,
            16,
            MediaQuery.of(context).viewInsets.bottom + 110,
          ),
          decoration: BoxDecoration(
            color: AppColors.surface,
            border: Border(top: BorderSide(color: AppColors.border)),
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _chatController,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _send(),
                  decoration: const InputDecoration(
                    hintText: 'Tulis pesan ke #global…',
                    isDense: true,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _sending ? null : _send,
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: const BoxDecoration(
                    gradient: AppColors.brandGradient,
                    shape: BoxShape.circle,
                  ),
                  child: _sending
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation(Colors.white),
                          ),
                        )
                      : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
