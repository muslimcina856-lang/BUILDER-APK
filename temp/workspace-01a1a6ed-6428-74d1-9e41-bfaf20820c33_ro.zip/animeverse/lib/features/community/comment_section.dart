import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/community.dart';
import '../../data/models/user_profile.dart';
import '../../data/providers.dart';
import '../../data/repositories/community_repository.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/user_avatar.dart';
import '../../shared/widgets/widgets.dart';

/// Bagian komentar yang dipakai di halaman detail, episode, chapter, dan
/// community feed.
class CommentSection extends ConsumerStatefulWidget {
  const CommentSection({
    super.key,
    required this.target,
    required this.targetId,
    this.title = 'Komentar',
    this.compact = false,
  });

  final CommentTarget target;
  final String targetId;
  final String title;
  final bool compact;

  @override
  ConsumerState<CommentSection> createState() => _CommentSectionState();
}

class _CommentSectionState extends ConsumerState<CommentSection> {
  final TextEditingController _controller = TextEditingController();
  bool _sending = false;
  String? _replyToId;
  String? _replyToName;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final session = ref.read(sessionProvider);
    if (!session.isAuthenticated) {
      context.push('/login?redirect=${Uri.encodeComponent('/home')}');
      return;
    }
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    try {
      await ref.read(communityRepositoryProvider).postComment(
            target: widget.target,
            targetId: widget.targetId,
            content: text,
            parentId: _replyToId,
          );
      _controller.clear();
      setState(() {
        _replyToId = null;
        _replyToName = null;
      });
      ref.invalidate(commentsProvider(
        (target: widget.target, id: widget.targetId),
      ));
      ref.invalidate(communityFeedProvider);
      // EXP komentar (dibatasi anti-spam).
      final update = await ref.read(gamificationRepositoryProvider).awardExp(
            amount: 15,
            category: 'comment',
            reason: 'Komentar baru',
            questId: 'daily_comment',
            questProgress: 1,
          );
      ref.invalidate(gamificationProvider);
      if (mounted && update.gainedExp > 0) {
        showSnack(context, '+${update.gainedExp} EXP dari komentar');
      }
    } on CommunityException catch (error) {
      if (mounted) showSnack(context, error.message, error: true);
    } catch (error) {
      if (mounted) showSnack(context, 'Gagal mengirim komentar: $error', error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _react(String commentId, int reaction) async {
    if (!ref.read(sessionProvider).isAuthenticated) {
      showSnack(context, 'Masuk untuk memberi reaksi', error: true);
      return;
    }
    try {
      await ref.read(communityRepositoryProvider).react(
            all: const [],
            commentId: commentId,
            reaction: reaction,
          );
      ref.invalidate(commentsProvider(
        (target: widget.target, id: widget.targetId),
      ));
      ref.invalidate(communityFeedProvider);
    } catch (error) {
      if (mounted) showSnack(context, '$error', error: true);
    }
  }

  Future<void> _openReport(CommentItem comment) async {
    const reasons = [
      'Spam / promosi',
      'Ujaran kebencian',
      'Konten tidak pantas',
      'Spoiler tanpa tag',
      'Lainnya',
    ];
    final reason = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Laporkan komentar',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
              ),
            ),
            for (final reason in reasons)
              ListTile(
                title: Text(reason, style: const TextStyle(fontSize: 13.5)),
                onTap: () => Navigator.pop(context, reason),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (reason == null) return;
    await ref.read(communityRepositoryProvider).reportComment(
          commentId: comment.id,
          reason: reason,
        );
    if (mounted) {
      showSnack(context, 'Laporan terkirim. Tim moderasi akan meninjau.');
    }
  }

  void _startReply(CommentItem comment) {
    setState(() {
      _replyToId = comment.id;
      _replyToName = comment.author.name;
    });
  }

  @override
  Widget build(BuildContext context) {
    final comments = ref.watch(
      commentsProvider((target: widget.target, id: widget.targetId)),
    );
    final session = ref.watch(sessionProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              widget.title,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(width: 8),
            if (comments.valueOrNull != null)
              Text(
                '(${comments.valueOrNull!.length})',
                style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
              ),
          ],
        ),
        const SizedBox(height: 12),
        if (_replyToName != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: [
                Text(
                  'Membalas @$_replyToName',
                  style: const TextStyle(fontSize: 11, color: AppColors.violetNeon),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: () => setState(() {
                    _replyToId = null;
                    _replyToName = null;
                  }),
                  child: const Icon(Icons.close_rounded, size: 13),
                ),
              ],
            ),
          ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            UserAvatar(
              imageUrl: session.profile?.avatarUrl,
              initials: session.profile?.initials ?? 'AV',
              size: 34,
              tier: session.profile?.tier ?? MembershipTier.free,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _controller,
                maxLines: 3,
                minLines: 1,
                maxLength: 1000,
                decoration: InputDecoration(
                  hintText: session.isAuthenticated
                      ? 'Tulis komentar… gunakan @username untuk mention'
                      : 'Masuk untuk berkomentar',
                  counterText: '',
                  isDense: true,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  suffixIcon: IconButton(
                    icon: _sending
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.send_rounded, size: 18),
                    onPressed: _sending ? null : _submit,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        comments.when(
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Center(
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            ),
          ),
          error: (error, _) => Text(
            'Gagal memuat komentar: $error',
            style: const TextStyle(fontSize: 11.5, color: AppColors.danger),
          ),
          data: (items) {
            if (items.isEmpty) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 18),
                child: Text(
                  'Belum ada komentar. Jadilah yang pertama!',
                  style: TextStyle(fontSize: 12, color: AppColors.textMuted),
                ),
              );
            }
            return Column(
              children: [
                for (final comment in items)
                  _CommentTile(
                    comment: comment,
                    compact: widget.compact,
                    onReply: () => _startReply(comment),
                    onLike: () => _react(comment.id, 1),
                    onDislike: () => _react(comment.id, -1),
                    onReport: () => _openReport(comment),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }

}

class _CommentTile extends StatelessWidget {
  const _CommentTile({
    required this.comment,
    required this.onReply,
    required this.onLike,
    required this.onDislike,
    required this.onReport,
    this.compact = false,
  });

  final CommentItem comment;
  final VoidCallback onReply;
  final VoidCallback onLike;
  final VoidCallback onDislike;
  final VoidCallback onReport;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final tierColors = AppColors.frameFor(comment.author.tier);
    return SoftCard(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              UserAvatar(
                imageUrl: comment.author.avatarUrl,
                initials: comment.author.username.isEmpty
                    ? 'AV'
                    : comment.author.username
                        .substring(0, comment.author.username.length >= 2 ? 2 : 1)
                        .toUpperCase(),
                size: 32,
                showFrame: comment.author.tier != 'free',
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            comment.author.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                        const SizedBox(width: 5),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 5,
                            vertical: 1,
                          ),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: tierColors),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            'Lv${comment.author.level}',
                            style: const TextStyle(
                              fontSize: 8.5,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        if (comment.isPinned) ...[
                          const SizedBox(width: 5),
                          const Icon(
                            Icons.push_pin_rounded,
                            size: 11,
                            color: AppColors.gold,
                          ),
                        ],
                      ],
                    ),
                    Text(
                      Fmt.relative(comment.createdAt),
                      style: const TextStyle(
                        fontSize: 9.5,
                        color: AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                padding: EdgeInsets.zero,
                iconSize: 16,
                icon: const Icon(Icons.more_horiz_rounded, color: AppColors.textMuted),
                color: AppColors.surfaceHigh,
                onSelected: (value) {
                  if (value == 'report') onReport();
                  if (value == 'reply') onReply();
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(value: 'reply', child: Text('Balas', style: TextStyle(fontSize: 13))),
                  PopupMenuItem(value: 'report', child: Text('Laporkan', style: TextStyle(fontSize: 13))),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            comment.isDeleted ? 'Komentar telah dihapus.' : comment.content,
            style: TextStyle(
              fontSize: 12.5,
              height: 1.55,
              color: comment.isDeleted
                  ? AppColors.textMuted
                  : AppColors.textPrimary.withValues(alpha: 0.92),
              fontStyle: comment.isDeleted ? FontStyle.italic : null,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _ReactionButton(
                icon: Icons.thumb_up_alt_rounded,
                count: comment.likes,
                active: comment.myReaction == 1,
                onTap: onLike,
              ),
              const SizedBox(width: 12),
              _ReactionButton(
                icon: Icons.thumb_down_alt_rounded,
                count: comment.dislikes,
                active: comment.myReaction == -1,
                onTap: onDislike,
              ),
              const SizedBox(width: 14),
              GestureDetector(
                onTap: onReply,
                child: const Text(
                  'Balas',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: AppColors.violetNeon,
                  ),
                ),
              ),
            ],
          ),
          if (comment.replies.isNotEmpty && !compact) ...[
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.only(left: 14),
              child: Column(
                children: [
                  for (final reply in comment.replies)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 2,
                            height: 32,
                            color: AppColors.border,
                            margin: const EdgeInsets.only(right: 10),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '@${reply.author.name}',
                                  style: const TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.violetNeon,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  reply.content,
                                  style: const TextStyle(
                                    fontSize: 11.5,
                                    height: 1.5,
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ReactionButton extends StatelessWidget {
  const _ReactionButton({
    required this.icon,
    required this.count,
    required this.active,
    required this.onTap,
  });

  final IconData icon;
  final int count;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = active ? AppColors.violetNeon : AppColors.textMuted;
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 4),
          Text(
            '$count',
            style: TextStyle(
              fontSize: 11,
              fontWeight: active ? FontWeight.w700 : FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
