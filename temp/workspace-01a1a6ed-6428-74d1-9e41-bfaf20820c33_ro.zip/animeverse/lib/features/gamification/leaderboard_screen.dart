import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/gamification.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/user_avatar.dart';
import '../../shared/widgets/widgets.dart';

class LeaderboardScreen extends ConsumerStatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  ConsumerState<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends ConsumerState<LeaderboardScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 2, vsync: this);

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cloudMode = ref.watch(bootstrapProvider).valueOrNull?.cloudMode ?? false;
    return Scaffold(
      appBar: AppBar(title: const Text('Leaderboard')),
      body: Column(
        children: [
          if (!cloudMode)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.gold.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.gold.withValues(alpha: 0.3)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.science_rounded, size: 14, color: AppColors.gold),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Mode demo lokal: sebagian entri leaderboard adalah data contoh. '
                        'Pada mode Supabase, data diambil dari view leaderboard_weekly.',
                        style: TextStyle(fontSize: 9.5, height: 1.5, color: AppColors.gold),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                gradient: AppColors.brandGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: Colors.white,
              unselectedLabelColor: AppColors.textSecondary,
              labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
              tabs: const [Tab(text: 'Mingguan'), Tab(text: 'Bulanan')],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: const [
                _LeaderboardList(period: 'weekly'),
                _LeaderboardList(period: 'monthly'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LeaderboardList extends ConsumerWidget {
  const _LeaderboardList({required this.period});

  final String period;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final leaderboard = ref.watch(leaderboardProvider(period));
    return leaderboard.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => EmptyState(
        title: 'Gagal memuat peringkat',
        message: '$error',
        icon: Icons.cloud_off_rounded,
      ),
      data: (entries) {
        if (entries.isEmpty) {
          return const EmptyState(
            title: 'Belum ada data',
            message: 'Leaderboard akan terisi setelah pengguna mengumpulkan EXP.',
            icon: Icons.leaderboard_rounded,
          );
        }
        final top = entries.take(3).toList();
        final rest = entries.skip(3).toList();
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 40),
          children: [
            if (top.isNotEmpty)
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  for (var i = 0; i < top.length; i++)
                    Expanded(
                      child: _PodiumCard(
                        entry: top[i],
                        height: i == 0 ? 132 : (i == 1 ? 116 : 104),
                        medalColor: i == 0
                            ? AppColors.gold
                            : i == 1
                                ? const Color(0xFFC0C0C0)
                                : const Color(0xFFCD7F32),
                      ),
                    ),
                ],
              ),
            const SizedBox(height: 18),
            for (final entry in rest)
              SoftCard(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Row(
                  children: [
                    SizedBox(
                      width: 26,
                      child: Text(
                        '${entry.position}',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textMuted,
                        ),
                      ),
                    ),
                    UserAvatar(
                      imageUrl: entry.avatarUrl,
                      initials: entry.username
                          .substring(0, entry.username.length >= 2 ? 2 : 1)
                          .toUpperCase(),
                      size: 34,
                      rankKey: entry.rankKey,
                      showFrame: entry.tier != 'free',
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            entry.displayName.isEmpty ? entry.username : entry.displayName,
                            style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          Text(
                            '${entry.rank.name} • Lv ${entry.level}',
                            style: TextStyle(fontSize: 9.5, color: entry.rank.color),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          Fmt.number(entry.exp),
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: AppColors.gold,
                          ),
                        ),
                        const Text(
                          'EXP',
                          style: TextStyle(fontSize: 8.5, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
          ],
        );
      },
    );
  }
}

class _PodiumCard extends StatelessWidget {
  const _PodiumCard({
    required this.entry,
    required this.height,
    required this.medalColor,
  });

  final LeaderboardEntry entry;
  final double height;
  final Color medalColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Container(
        height: height,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              medalColor.withValues(alpha: 0.24),
              AppColors.surface,
            ],
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: medalColor.withValues(alpha: 0.5)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.military_tech_rounded, color: medalColor, size: 18),
            const SizedBox(height: 6),
            UserAvatar(
              imageUrl: entry.avatarUrl,
              initials: entry.username
                  .substring(0, entry.username.length >= 2 ? 2 : 1)
                  .toUpperCase(),
              size: 44,
              rankKey: entry.rankKey,
              showFrame: entry.tier != 'free',
            ),
            const SizedBox(height: 6),
            Text(
              entry.displayName.isEmpty ? entry.username : entry.displayName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            Text(
              '${Fmt.compact(entry.exp)} EXP',
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                color: medalColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
