import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../data/models/gamification.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/shimmer.dart';
import '../../shared/widgets/user_avatar.dart';
import '../../shared/widgets/widgets.dart';

class QuestsScreen extends ConsumerStatefulWidget {
  const QuestsScreen({super.key});

  @override
  ConsumerState<QuestsScreen> createState() => _QuestsScreenState();
}

class _QuestsScreenState extends ConsumerState<QuestsScreen> {
  bool _claiming = false;

  Future<void> _claimDaily() async {
    setState(() => _claiming = true);
    final update = await ref.read(gamificationRepositoryProvider).claimDailyLogin();
    if (!mounted) return;
    setState(() => _claiming = false);
    ref.invalidate(gamificationProvider);
    if (update.leveledUp && mounted) {
      await showLevelUpDialog(context, update);
    } else if (mounted) {
      showSnack(
        context,
        update.message ?? '+${update.gainedExp} EXP',
        error: update.gainedExp == 0,
      );
    }
  }

  Future<void> _claimQuest(Quest quest) async {
    final update = await ref.read(gamificationRepositoryProvider).claimQuest(quest.id);
    if (!mounted) return;
    ref.invalidate(gamificationProvider);
    if (update.leveledUp && mounted) {
      await showLevelUpDialog(context, update);
    } else if (mounted) {
      showSnack(context, update.message ?? 'Reward diklaim');
    }
  }

  @override
  Widget build(BuildContext context) {
    final gamification = ref.watch(gamificationProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Quest & Reward')),
      body: gamification.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => EmptyState(
          title: 'Gagal memuat quest',
          message: '$error',
          icon: Icons.cloud_off_rounded,
        ),
        data: (state) {
          final daily = state.quests.where((q) => q.period == QuestPeriod.daily).toList();
          final weekly = state.quests.where((q) => q.period == QuestPeriod.weekly).toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
            children: [
              GlassCard(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            gradient: AppColors.goldGradient,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(
                            Icons.local_fire_department_rounded,
                            color: AppColors.deepBlack,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Daily login streak: ${state.loginStreak} hari',
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              Text(
                                state.dailyClaimed
                                    ? 'Reward hari ini sudah diklaim'
                                    : 'Klaim +${ExpRules.forDailyLogin(state.loginStreak + 1)} EXP sekarang',
                                style: const TextStyle(
                                  fontSize: 10.5,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: state.dailyClaimed || _claiming ? null : _claimDaily,
                        style: FilledButton.styleFrom(
                          backgroundColor: AppColors.gold,
                          foregroundColor: AppColors.deepBlack,
                          minimumSize: const Size(0, 44),
                        ),
                        child: Text(
                          state.dailyClaimed ? 'Sudah diklaim hari ini' : 'Klaim reward harian',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              ExpBar(
                level: state.level,
                progress: state.levelProgress,
                expIntoLevel: state.expIntoLevel,
                expForNext: state.expForNext,
                rankKey: state.rankKey,
              ),
              const SizedBox(height: 6),
              Text(
                state.expToNextRank == null
                    ? 'Kamu sudah mencapai rank tertinggi: ${state.rank.name}'
                    : '${state.expToNextRank} EXP lagi menuju ${state.rank.next?.name}',
                style: TextStyle(
                  fontSize: 10.5,
                  color: state.rank.color,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 20),
              const _SectionTitle('Quest Harian', 'Reset setiap 00:00 WIB'),
              const SizedBox(height: 8),
              for (final quest in daily) _QuestTile(quest: quest, onClaim: () => _claimQuest(quest)),
              const SizedBox(height: 18),
              const _SectionTitle('Quest Mingguan', 'Reset setiap Senin'),
              const SizedBox(height: 8),
              for (final quest in weekly) _QuestTile(quest: quest, onClaim: () => _claimQuest(quest)),
              const SizedBox(height: 18),
              SoftCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Batas EXP harian',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Menonton maks 300 EXP/hari • Membaca maks 300 EXP/hari • '
                      'Komentar maks 120 EXP/hari. Sistem ini mencegah farming EXP '
                      'dan spam aktivitas.',
                      style: const TextStyle(
                        fontSize: 10.5,
                        height: 1.6,
                        color: AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.title, this.subtitle);

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 13.5,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        const Spacer(),
        Text(
          subtitle,
          style: const TextStyle(fontSize: 9.5, color: AppColors.textMuted),
        ),
      ],
    );
  }
}

class _QuestTile extends StatelessWidget {
  const _QuestTile({required this.quest, required this.onClaim});

  final Quest quest;
  final VoidCallback onClaim;

  @override
  Widget build(BuildContext context) {
    return SoftCard(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: quest.isComplete
                  ? AppColors.success.withValues(alpha: 0.16)
                  : AppColors.violet.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(
              quest.isComplete ? Icons.check_rounded : Icons.bolt_rounded,
              size: 17,
              color: quest.isComplete ? AppColors.success : AppColors.violetNeon,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  quest.title,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  '${quest.description} • +${quest.expReward} EXP',
                  style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: quest.ratio == 0 ? 0.02 : quest.ratio,
                          minHeight: 4,
                          backgroundColor: AppColors.surfaceHigh,
                          valueColor: AlwaysStoppedAnimation(
                            quest.isComplete ? AppColors.success : AppColors.violetNeon,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${quest.progress}/${quest.target}',
                      style: const TextStyle(
                        fontSize: 9.5,
                        color: AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          if (quest.isClaimable)
            FilledButton(
              onPressed: onClaim,
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.gold,
                foregroundColor: AppColors.deepBlack,
                minimumSize: const Size(62, 34),
                padding: const EdgeInsets.symmetric(horizontal: 10),
              ),
              child: const Text('Klaim', style: TextStyle(fontSize: 11)),
            )
          else if (quest.claimed)
            const Icon(Icons.verified_rounded, size: 18, color: AppColors.success)
          else
            const Icon(Icons.lock_outline_rounded, size: 16, color: AppColors.textMuted),
        ],
      ),
    );
  }
}

/// Dialog animasi level up / rank up yang dipakai di beberapa layar.
Future<void> showLevelUpDialog(BuildContext context, dynamic update) async {
  final level = update.state.level as int;
  final rankName = (update.state.rank as RankTier).name;
  final rankedUp = update.rankedUp as bool;
  await showDialog<void>(
    context: context,
    builder: (context) => Dialog(
      backgroundColor: Colors.transparent,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.85, end: 1),
        duration: const Duration(milliseconds: 420),
        curve: Curves.elasticOut,
        builder: (context, value, child) =>
            Transform.scale(scale: value, child: child),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: AppColors.premiumGradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: AppColors.violet.withValues(alpha: 0.5),
                blurRadius: 40,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: AppColors.goldGradient,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.gold.withValues(alpha: 0.5),
                      blurRadius: 30,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.emoji_events_rounded,
                  size: 42,
                  color: AppColors.deepBlack,
                ),
              ),
              const SizedBox(height: 18),
              Text(
                rankedUp ? 'RANK UP!' : 'LEVEL UP!',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Kamu mencapai Level $level${rankedUp ? ' • $rankName' : ''}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.white.withValues(alpha: 0.9),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                update.message ?? '',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  color: Colors.white.withValues(alpha: 0.7),
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.pop(context),
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: AppColors.deepPurple,
                  ),
                  child: const Text('Lanjutkan'),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
