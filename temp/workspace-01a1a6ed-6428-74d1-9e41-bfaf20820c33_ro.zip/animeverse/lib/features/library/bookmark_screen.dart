import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/library.dart';
import '../../data/models/media.dart';
import '../../data/providers.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/widgets.dart';

class BookmarkScreen extends ConsumerStatefulWidget {
  const BookmarkScreen({super.key, this.embedded = false});

  final bool embedded;

  @override
  ConsumerState<BookmarkScreen> createState() => _BookmarkScreenState();
}

class _BookmarkScreenState extends ConsumerState<BookmarkScreen> {
  String _filter = 'Semua';

  static const List<String> _filters = [
    'Semua',
    'Anime',
    'Donghua',
    'Movie',
    'Manga',
    'Manhwa',
    'Manhua',
    'Novel',
  ];

  @override
  Widget build(BuildContext context) {
    final bookmarks = ref.watch(bookmarkProvider);
    final favorites = ref.watch(favoriteProvider).valueOrNull ?? const [];
    final body = bookmarks.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => EmptyState(
        title: 'Gagal memuat bookmark',
        message: '$error',
        icon: Icons.cloud_off_rounded,
      ),
      data: (entries) {
        final combined = <LibraryEntry>[...entries, ...favorites];
        final filtered = _filter == 'Semua'
            ? combined
            : combined
                .where((entry) => entry.media.kind.label == _filter)
                .toList();
        if (filtered.isEmpty) {
          return EmptyState(
            title: 'Belum ada koleksi',
            message:
                'Tekan ikon bookmark pada halaman detail judul untuk menyimpannya '
                'di sini. Koleksi tersinkron dengan akunmu.',
            icon: Icons.bookmark_border_rounded,
          );
        }
        return GridView.builder(
          padding: EdgeInsets.fromLTRB(20, 16, 20, widget.embedded ? 120 : 40),
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 150,
            mainAxisSpacing: 16,
            crossAxisSpacing: 12,
            childAspectRatio: 0.52,
          ),
          itemCount: filtered.length,
          itemBuilder: (context, index) {
            final entry = filtered[index];
            return PosterCard(
              media: entry.media,
              expand: true,
              onTap: () => AppNav.media(context, entry.media),
            );
          },
        );
      },
    );

    final content = Column(
      children: [
        SizedBox(
          height: 40,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: _filters.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final filter = _filters[index];
              return ChoiceChip(
                label: Text(filter),
                selected: _filter == filter,
                onSelected: (_) => setState(() => _filter = filter),
              );
            },
          ),
        ),
        Expanded(child: body),
      ],
    );

    if (widget.embedded) return content;
    return Scaffold(
      appBar: AppBar(title: const Text('Bookmark & Favorit')),
      body: content,
    );
  }
}
