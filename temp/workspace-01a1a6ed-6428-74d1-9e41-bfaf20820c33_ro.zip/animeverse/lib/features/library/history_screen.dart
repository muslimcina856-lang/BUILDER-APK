import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/library.dart';
import '../../data/models/media.dart';
import '../../data/providers.dart';
import '../../shared/widgets/app_network_image.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/widgets.dart';

class HistoryScreen extends ConsumerStatefulWidget {
  const HistoryScreen({super.key, this.embedded = false});

  final bool embedded;

  @override
  ConsumerState<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends ConsumerState<HistoryScreen> {
  MediaGroup? _group;

  @override
  Widget build(BuildContext context) {
    final history = ref.watch(historyProvider);
    final content = Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 12, 0),
          child: Row(
            children: [
              for (final entry in <MediaGroup?, String>{
                null: 'Semua',
                MediaGroup.video: 'Tontonan',
                MediaGroup.comic: 'Komik',
                MediaGroup.text: 'Novel',
              }.entries)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(entry.value),
                    selected: _group == entry.key,
                    onSelected: (_) => setState(() => _group = entry.key),
                  ),
                ),
              const Spacer(),
              IconButton(
                tooltip: 'Hapus semua riwayat',
                icon: const Icon(Icons.delete_sweep_rounded, size: 20),
                onPressed: () async {
                  final confirmed = await confirmDialog(
                    context,
                    title: 'Hapus semua riwayat?',
                    message:
                        'Progress menonton dan membaca akan hilang. Bookmark tidak terpengaruh.',
                    confirmLabel: 'Hapus',
                    destructive: true,
                  );
                  if (!confirmed) return;
                  await ref.read(libraryRepositoryProvider).clearHistory();
                  ref.invalidate(historyProvider);
                  ref.invalidate(continueWatchingProvider);
                },
              ),
            ],
          ),
        ),
        Expanded(
          child: history.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, _) => EmptyState(
              title: 'Gagal memuat riwayat',
              message: '$error',
              icon: Icons.cloud_off_rounded,
            ),
            data: (entries) {
              final filtered = _group == null
                  ? entries
                  : entries.where((entry) => entry.media.kind.group == _group).toList();
              if (filtered.isEmpty) {
                return const EmptyState(
                  title: 'Riwayat masih kosong',
                  message:
                      'Mulai tonton anime atau baca komik, dan progresmu akan muncul '
                      'di sini secara otomatis.',
                  icon: Icons.history_rounded,
                );
              }
              return ListView.separated(
                padding: EdgeInsets.fromLTRB(20, 12, 20, widget.embedded ? 120 : 40),
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final entry = filtered[index];
                  return SoftCard(
                    padding: const EdgeInsets.all(10),
                    onTap: () => _open(entry),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            width: 54,
                            height: 72,
                            child: AppNetworkImage(url: entry.media.coverUrl),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                entry.media.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                entry.progressLabel,
                                style: const TextStyle(
                                  fontSize: 10.5,
                                  color: AppColors.textMuted,
                                ),
                              ),
                              const SizedBox(height: 6),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: LinearProgressIndicator(
                                  value: entry.progress == 0 ? 0.02 : entry.progress,
                                  minHeight: 4,
                                  backgroundColor: AppColors.surfaceHigh,
                                  valueColor: const AlwaysStoppedAnimation(
                                    AppColors.violetNeon,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 5),
                              Row(
                                children: [
                                  SourcePill(
                                    label: entry.media.kind.label,
                                    icon: entry.media.kind.icon,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    Fmt.relative(entry.updatedAt),
                                    style: const TextStyle(
                                      fontSize: 9.5,
                                      color: AppColors.textMuted,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close_rounded, size: 16),
                          onPressed: () async {
                            await ref
                                .read(libraryRepositoryProvider)
                                .removeHistory(entry.id);
                            ref.invalidate(historyProvider);
                            ref.invalidate(continueWatchingProvider);
                          },
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );

    if (widget.embedded) return content;
    return Scaffold(
      appBar: AppBar(title: const Text('Riwayat')),
      body: content,
    );
  }

  void _open(HistoryEntry entry) {
    if (entry.media.kind.isVideo) {
      AppNav.watch(
        context,
        mediaId: entry.media.id,
        kind: entry.media.kind,
        episode: entry.episodeNumber ?? 1,
        title: entry.media.title,
      );
    } else if (entry.media.kind.isComic && entry.chapterId != null) {
      AppNav.readComic(
        context,
        mediaId: entry.media.id,
        chapterId: entry.chapterId!,
        kind: entry.media.kind,
        title: entry.media.title,
        chapterNumber: '${entry.chapterNumber ?? 1}',
      );
    } else if (entry.media.kind == MediaKind.novel) {
      AppNav.readNovel(
        context,
        mediaId: entry.media.id,
        index: entry.chapterNumber?.toInt() ?? 1,
        title: entry.media.title,
      );
    } else {
      AppNav.media(context, entry.media);
    }
  }
}
