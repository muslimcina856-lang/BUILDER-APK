import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/library.dart';
import '../../data/providers.dart';
import '../../shared/widgets/app_network_image.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/poster_card.dart';
import '../../shared/widgets/widgets.dart';

class DownloadScreen extends ConsumerWidget {
  const DownloadScreen({super.key, this.embedded = false});

  final bool embedded;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final downloads = ref.watch(downloadsProvider);
    final content = downloads.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => EmptyState(
        title: 'Gagal memuat unduhan',
        message: '$error',
        icon: Icons.cloud_off_rounded,
      ),
      data: (tasks) {
        if (tasks.isEmpty) {
          return const EmptyState(
            title: 'Belum ada unduhan',
            message:
                'Unduhan offline hanya tersedia untuk konten yang lisensinya '
                'mengizinkan. Fitur ini memerlukan sumber video resmi yang sudah '
                'didaftarkan admin.',
            icon: Icons.download_for_offline_rounded,
          );
        }
        return ListView(
          padding: EdgeInsets.fromLTRB(20, 16, 20, embedded ? 120 : 40),
          children: [
            GlassCard(
              child: Row(
                children: [
                  const Icon(Icons.info_outline_rounded,
                      size: 16, color: AppColors.gold),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      '${tasks.where((task) => task.status == DownloadStatus.completed).length} '
                      'selesai • ${Fmt.bytesFromMb(tasks.fold<double>(0, (sum, task) => sum + task.sizeMb))} terpakai',
                      style: const TextStyle(
                        fontSize: 11.5,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () async {
                      await ref.read(libraryRepositoryProvider).clearDownloads();
                      ref.invalidate(downloadsProvider);
                    },
                    child: const Text('Bersihkan', style: TextStyle(fontSize: 11.5)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            for (final task in tasks)
              SoftCard(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: SizedBox(
                        width: 52,
                        height: 70,
                        child: AppNetworkImage(url: task.media.coverUrl),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            task.media.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          Text(
                            '${task.label} • ${task.quality}',
                            style: const TextStyle(
                              fontSize: 10.5,
                              color: AppColors.textMuted,
                            ),
                          ),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: LinearProgressIndicator(
                              value: task.progress == 0 ? 0.02 : task.progress,
                              minHeight: 4,
                              backgroundColor: AppColors.surfaceHigh,
                              valueColor: AlwaysStoppedAnimation(
                                task.status == DownloadStatus.completed
                                    ? AppColors.success
                                    : task.status == DownloadStatus.failed
                                        ? AppColors.danger
                                        : AppColors.violetNeon,
                              ),
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            task.errorMessage ?? task.statusLabel,
                            style: TextStyle(
                              fontSize: 10,
                              color: task.status == DownloadStatus.failed
                                  ? AppColors.danger
                                  : AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, size: 18),
                      onPressed: () async {
                        await ref
                            .read(libraryRepositoryProvider)
                            .removeDownload(task.id);
                        ref.invalidate(downloadsProvider);
                      },
                    ),
                  ],
                ),
              ),
          ],
        );
      },
    );

    if (embedded) return content;
    return Scaffold(
      appBar: AppBar(title: const Text('Download Manager')),
      body: content,
    );
  }
}
