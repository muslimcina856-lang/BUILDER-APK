import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/chapter.dart';
import '../../data/models/library.dart';
import '../../data/models/media.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/shimmer.dart';
import '../../shared/widgets/widgets.dart';

class ComicReaderScreen extends ConsumerStatefulWidget {
  const ComicReaderScreen({
    super.key,
    required this.mediaId,
    required this.chapterId,
    required this.kindSlug,
    this.title,
    this.chapterNumber,
  });

  final String mediaId;
  final String chapterId;
  final String kindSlug;
  final String? title;
  final String? chapterNumber;

  @override
  ConsumerState<ComicReaderScreen> createState() => _ComicReaderScreenState();
}

class _ComicReaderScreenState extends ConsumerState<ComicReaderScreen> {
  MediaItem? _media;
  List<ChapterInfo> _chapters = const [];
  List<ReaderPage> _pages = const [];
  ChapterInfo? _chapter;
  bool _loading = true;
  String? _error;
  bool _vertical = true;
  bool _allPages = true;
  bool _showUi = true;
  bool _nightMode = true;
  bool _rtl = false;
  int _currentPage = 0;
  Timer? _saveTimer;

  final ScrollController _scrollController = ScrollController();
  final PageController _pageController = PageController();

  MediaKind get _kind => MediaKind.fromSlug(widget.kindSlug);

  @override
  void initState() {
    super.initState();
    final settings = ref.read(settingsProvider);
    _vertical = settings.readerDirectionRtl == false ? true : true;
    _nightMode = settings.readerNightMode;
    _rtl = settings.readerDirectionRtl;
    _load();
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _scrollController.dispose();
    _pageController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final service = ref.read(contentServiceProvider);
    try {
      final media = await service.detail(widget.mediaId, _kind);
      final chapters = media == null ? <ChapterInfo>[] : await service.chapters(media);
      final chapter = chapters.firstWhere(
        (item) => item.id == widget.chapterId,
        orElse: () => ChapterInfo(
          id: widget.chapterId,
          mediaId: widget.mediaId,
          number: double.tryParse(widget.chapterNumber ?? '1') ?? 1,
          title: 'Chapter ${widget.chapterNumber ?? 1}',
        ),
      );
      final pages = await service.comicPages(widget.chapterId);
      if (!mounted) return;
      setState(() {
        _media = media;
        _chapters = chapters;
        _pages = pages;
        _chapter = chapter;
        _loading = false;
      });
      await _restorePosition();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '$error';
      });
    }
  }

  Future<void> _restorePosition() async {
    final media = _media;
    if (media == null) return;
    final history = await ref.read(libraryRepositoryProvider).findHistory(media.id);
    if (history == null || history.chapterId != widget.chapterId) return;
    final page = history.pageIndex;
    if (page <= 0 || page >= _pages.length) return;
    if (!mounted) return;
    setState(() => _currentPage = page);
    if (_vertical) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!_scrollController.hasClients) return;
        final target = (page / _pages.length) *
            _scrollController.position.maxScrollExtent;
        _scrollController.jumpTo(target.clamp(
          0,
          _scrollController.position.maxScrollExtent,
        ));
      });
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients) _pageController.jumpToPage(page);
      });
    }
    if (mounted) {
      showSnack(context, 'Melanjutkan dari halaman ${page + 1}');
    }
  }

  void _scheduleSave(int page) {
    setState(() => _currentPage = page);
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 800), _saveProgress);
  }

  Future<void> _saveProgress() async {
    final media = _media;
    final chapter = _chapter;
    if (media == null || chapter == null) return;
    final settings = ref.read(settingsProvider);
    if (!settings.autoSaveProgress) return;
    final completed = _currentPage >= _pages.length - 1;
    await ref.read(libraryRepositoryProvider).saveProgress(
          HistoryEntry(
            id: '${media.id}::chapter',
            media: media,
            updatedAt: DateTime.now(),
            chapterId: chapter.id,
            chapterNumber: chapter.number,
            pageIndex: _currentPage,
            totalPages: _pages.length,
            completed: completed,
          ),
        );
    ref.invalidate(historyProvider);
    ref.invalidate(continueWatchingProvider);
    if (completed) {
      await ref.read(gamificationRepositoryProvider).awardExp(
            amount: 8,
            category: 'read',
            reason: 'Selesai ${chapter.label}',
            questId: 'daily_read_2',
            questProgress: 1,
          );
      ref.invalidate(gamificationProvider);
      ref.invalidate(gamificationProvider);
    }
  }

  ChapterInfo? get _previousChapter {
    final index = _chapters.indexWhere((item) => item.id == _chapter?.id);
    if (index <= 0) return null;
    return _chapters[index - 1];
  }

  ChapterInfo? get _nextChapter {
    final index = _chapters.indexWhere((item) => item.id == _chapter?.id);
    if (index < 0 || index >= _chapters.length - 1) return null;
    return _chapters[index + 1];
  }

  void _goToChapter(ChapterInfo chapter) {
    if (!mounted) return;
    context.pushReplacement(
      '/read-comic?mediaId=${Uri.encodeComponent(widget.mediaId)}'
      '&chapterId=${Uri.encodeComponent(chapter.id)}'
      '&kind=${widget.kindSlug}'
      '&title=${Uri.encodeComponent(widget.title ?? '')}'
      '&chapter=${chapter.number}',
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Shimmer(
          enabled: false,
          child: ListView.builder(
            itemCount: 3,
            itemBuilder: (_, __) => const Padding(
              padding: EdgeInsets.all(8),
              child: SkeletonBox(height: 420, radius: 8),
            ),
          ),
        ),
      );
    }
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Reader')),
        body: EmptyState(
          title: 'Chapter tidak dapat dibuka',
          message: _error,
          icon: Icons.image_not_supported_rounded,
          actionLabel: 'Coba lagi',
          onAction: _load,
        ),
      );
    }

    final background = _nightMode ? Colors.black : const Color(0xFF1B1B1B);
    return Scaffold(
      backgroundColor: background,
      body: GestureDetector(
        onTap: () => setState(() => _showUi = !_showUi),
        child: Stack(
          children: [
            Positioned.fill(
              child: _vertical ? _buildVertical() : _buildHorizontal(),
            ),
            if (_showUi) _buildTopBar(),
            if (_showUi) _buildBottomBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildVertical() {
    if (_allPages) {
      return NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (notification is ScrollUpdateNotification) {
            final max = notification.metrics.maxScrollExtent;
            if (max > 0) {
              final page = ((notification.metrics.pixels / max) * (_pages.length - 1))
                  .round();
              if (page != _currentPage) _scheduleSave(page);
            }
          }
          return false;
        },
        child: ListView.builder(
          controller: _scrollController,
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.only(top: 70, bottom: 90),
          itemCount: _pages.length,
          itemBuilder: (context, index) => _PageView(
            page: _pages[index],
            zoomEnabled: true,
          ),
        ),
      );
    }
    return PageView.builder(
      controller: _pageController,
      reverse: _rtl,
      onPageChanged: _scheduleSave,
      itemCount: _pages.length,
      itemBuilder: (context, index) => InteractiveViewer(
        minScale: 1,
        maxScale: 4,
        child: Center(child: _PageView(page: _pages[index], fit: BoxFit.contain)),
      ),
    );
  }

  Widget _buildHorizontal() {
    return PageView.builder(
      controller: _pageController,
      reverse: _rtl,
      onPageChanged: _scheduleSave,
      itemCount: _allPages ? _pages.length : 1,
      itemBuilder: (context, index) {
        final pageIndex = _allPages ? index : _currentPage;
        if (pageIndex >= _pages.length) return const SizedBox.shrink();
        return InteractiveViewer(
          minScale: 1,
          maxScale: 4,
          child: Center(child: _PageView(page: _pages[pageIndex], fit: BoxFit.contain)),
        );
      },
    );
  }

  Widget _buildTopBar() {
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: Container(
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 6,
          bottom: 10,
          left: 6,
          right: 6,
        ),
        decoration: const BoxDecoration(gradient: AppColors.heroScrim),
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
              onPressed: () {
                _saveProgress();
                AppNav.back(context);
              },
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.title ?? _media?.title ?? 'Reader',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    '${_chapter?.label ?? 'Chapter'} • '
                    '${_currentPage + 1}/${_pages.length} '
                    '${_chapter?.language == 'id' ? '• ID' : ''}',
                    style: const TextStyle(color: Colors.white70, fontSize: 10.5),
                  ),
                ],
              ),
            ),
            IconButton(
              tooltip: 'Mode halaman',
              icon: Icon(
                _vertical ? Icons.view_carousel_rounded : Icons.view_day_rounded,
                color: Colors.white,
                size: 20,
              ),
              onPressed: () => setState(() => _vertical = !_vertical),
            ),
            IconButton(
              tooltip: _allPages ? 'Satu halaman' : 'Semua halaman',
              icon: Icon(
                _allPages ? Icons.crop_portrait_rounded : Icons.auto_stories_rounded,
                color: Colors.white,
                size: 20,
              ),
              onPressed: () => setState(() => _allPages = !_allPages),
            ),
            IconButton(
              tooltip: 'Mode malam',
              icon: Icon(
                _nightMode ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
                color: Colors.white,
                size: 20,
              ),
              onPressed: () => setState(() => _nightMode = !_nightMode),
            ),
            IconButton(
              tooltip: 'Arah baca',
              icon: const Icon(Icons.swap_horiz_rounded, color: Colors.white, size: 20),
              onPressed: () {
                setState(() => _rtl = !_rtl);
                ref.read(settingsProvider.notifier).patch(readerDirectionRtl: _rtl);
                showSnack(context, _rtl ? 'Arah: kanan → kiri' : 'Arah: kiri → kanan');
              },
            ),
            IconButton(
              tooltip: 'Daftar chapter',
              icon: const Icon(Icons.list_rounded, color: Colors.white, size: 20),
              onPressed: _openChapterList,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Positioned(
      left: 0,
      right: 0,
      bottom: 0,
      child: Container(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).padding.bottom + 10,
          top: 10,
          left: 12,
          right: 12,
        ),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.bottomCenter,
            end: Alignment.topCenter,
            colors: [Color(0xF2000000), Color(0x00000000)],
          ),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Text(
                  '${_currentPage + 1}',
                  style: const TextStyle(color: Colors.white, fontSize: 11),
                ),
                Expanded(
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
                      trackHeight: 2.5,
                    ),
                    child: Slider(
                      value: _pages.isEmpty
                          ? 0
                          : (_currentPage / (_pages.length - 1).clamp(1, 999))
                              .clamp(0.0, 1.0),
                      activeColor: AppColors.violetNeon,
                      inactiveColor: Colors.white24,
                      onChanged: (value) {
                        final page = (value * (_pages.length - 1)).round();
                        _scheduleSave(page);
                        if (_vertical && _allPages && _scrollController.hasClients) {
                          _scrollController.jumpTo(
                            value * _scrollController.position.maxScrollExtent,
                          );
                        } else if (_pageController.hasClients) {
                          _pageController.jumpToPage(page);
                        }
                      },
                    ),
                  ),
                ),
                Text(
                  '${_pages.length}',
                  style: const TextStyle(color: Colors.white54, fontSize: 11),
                ),
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed:
                        _previousChapter == null ? null : () => _goToChapter(_previousChapter!),
                    icon: const Icon(Icons.chevron_left_rounded, size: 18),
                    label: const Text('Sebelumnya', style: TextStyle(fontSize: 11.5)),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 40),
                      foregroundColor: Colors.white,
                      side: BorderSide(color: Colors.white.withValues(alpha: 0.3)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _nextChapter == null ? null : () => _goToChapter(_nextChapter!),
                    icon: const Icon(Icons.chevron_right_rounded, size: 18),
                    label: const Text('Berikutnya', style: TextStyle(fontSize: 11.5)),
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(0, 40),
                      backgroundColor: AppColors.violet,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _openChapterList() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: const BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          children: [
            const SizedBox(height: 12),
            Text(
              '${_chapters.length} Chapter',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: _chapters.length,
                itemBuilder: (context, index) {
                  final chapter = _chapters[index];
                  final active = chapter.id == _chapter?.id;
                  return ListTile(
                    dense: true,
                    title: Text(
                      chapter.title.isEmpty ? chapter.label : chapter.title,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: active ? FontWeight.w700 : FontWeight.w400,
                        color: active ? AppColors.violetNeon : AppColors.textPrimary,
                      ),
                    ),
                    subtitle: Text(
                      '${chapter.pages} halaman • ${chapter.group ?? 'Official'}',
                      style: const TextStyle(fontSize: 10),
                    ),
                    trailing: active
                        ? const Icon(Icons.play_arrow_rounded,
                            color: AppColors.violetNeon, size: 16)
                        : null,
                    onTap: () {
                      Navigator.pop(context);
                      _goToChapter(chapter);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PageView extends StatelessWidget {
  const _PageView({
    required this.page,
    this.fit = BoxFit.fitWidth,
    this.zoomEnabled = false,
  });

  final ReaderPage page;
  final BoxFit fit;
  final bool zoomEnabled;

  @override
  Widget build(BuildContext context) {
    final image = CachedNetworkImage(
      imageUrl: page.url,
      fit: fit,
      width: double.infinity,
      placeholder: (_, __) => AspectRatio(
        aspectRatio: 0.7,
        child: Container(
          color: Colors.black,
          alignment: Alignment.center,
          child: const SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white24),
          ),
        ),
      ),
      errorWidget: (_, __, ___) => AspectRatio(
        aspectRatio: 0.7,
        child: Container(
          color: Colors.black,
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.broken_image_rounded, color: Colors.white38, size: 30),
                SizedBox(height: 8),
                Text(
                  'Halaman gagal dimuat',
                  style: TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (!zoomEnabled) return image;
    return InteractiveViewer(
      minScale: 1,
      maxScale: 4,
      child: image,
    );
  }
}
