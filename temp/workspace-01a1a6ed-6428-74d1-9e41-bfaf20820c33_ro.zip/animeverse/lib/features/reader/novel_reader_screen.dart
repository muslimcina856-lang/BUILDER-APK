import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/navigation.dart';
import '../../data/models/chapter.dart';
import '../../data/models/library.dart';
import '../../data/models/media.dart';
import '../../data/providers.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/widgets.dart';

class NovelReaderScreen extends ConsumerStatefulWidget {
  const NovelReaderScreen({
    super.key,
    required this.mediaId,
    required this.startIndex,
    this.title,
  });

  final String mediaId;
  final int startIndex;
  final String? title;

  @override
  ConsumerState<NovelReaderScreen> createState() => _NovelReaderScreenState();
}

class _NovelReaderScreenState extends ConsumerState<NovelReaderScreen> {
  MediaItem? _media;
  List<NovelChapter> _chapters = const [];
  NovelChapter? _chapter;
  String? _content;
  bool _loading = true;
  String? _error;
  bool _showUi = true;
  bool _nightMode = true;
  double _fontSize = 18;
  double _lineHeight = 1.7;
  String _fontFamily = 'Roboto';
  String _background = 'dark';
  double _scrollProgress = 0;
  final ScrollController _scrollController = ScrollController();
  Timer? _saveTimer;

  @override
  void initState() {
    super.initState();
    final settings = ref.read(settingsProvider);
    _nightMode = settings.readerNightMode;
    _fontSize = settings.readerFontSize;
    _lineHeight = settings.readerLineHeight;
    _fontFamily = settings.readerFontFamily;
    _background = settings.readerBackground;
    _scrollController.addListener(_onScroll);
    _load();
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _scrollController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _load({int? index}) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final service = ref.read(contentServiceProvider);
    try {
      final media = await service.detail(widget.mediaId, MediaKind.novel);
      if (media == null) {
        setState(() {
          _loading = false;
          _error = 'Novel tidak ditemukan.';
        });
        return;
      }
      final chapters = await service.novelChapters(media);
      if (chapters.isEmpty) {
        setState(() {
          _loading = false;
          _media = media;
          _error = 'Teks belum tersedia untuk judul ini.';
        });
        return;
      }
      final targetIndex = index ?? _initialIndex(chapters);
      final chapter = chapters.firstWhere(
        (item) => item.index == targetIndex,
        orElse: () => chapters.first,
      );
      final content = await service.novelChapterText(chapter);
      if (!mounted) return;
      setState(() {
        _media = media;
        _chapters = chapters;
        _chapter = chapter;
        _content = content;
        _loading = false;
        _scrollProgress = 0;
      });
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(0);
      }
      _saveProgress();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '$error';
      });
    }
  }

  int _initialIndex(List<NovelChapter> chapters) {
    if (widget.startIndex <= 0) return chapters.first.index;
    return chapters.any((chapter) => chapter.index == widget.startIndex)
        ? widget.startIndex
        : chapters.first.index;
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final max = _scrollController.position.maxScrollExtent;
    final progress = max <= 0 ? 1.0 : (_scrollController.position.pixels / max);
    if ((progress - _scrollProgress).abs() > 0.02) {
      setState(() => _scrollProgress = progress.clamp(0.0, 1.0));
      _saveTimer?.cancel();
      _saveTimer = Timer(const Duration(seconds: 2), _saveProgress);
    }
    if (progress >= 0.985) {
      _saveTimer?.cancel();
      _saveProgress(completed: true);
    }
  }

  Future<void> _saveProgress({bool completed = false}) async {
    final media = _media;
    final chapter = _chapter;
    if (media == null || chapter == null) return;
    final settings = ref.read(settingsProvider);
    if (!settings.autoSaveProgress) return;
    await ref.read(libraryRepositoryProvider).saveProgress(
          HistoryEntry(
            id: '${media.id}::novel',
            media: media,
            updatedAt: DateTime.now(),
            chapterNumber: chapter.index.toDouble(),
            chapterId: chapter.id,
            pageIndex: (_scrollProgress * 100).round(),
            totalPages: 100,
            completed: completed,
          ),
        );
    ref.invalidate(historyProvider);
    if (completed) {
      await ref.read(gamificationRepositoryProvider).awardExp(
            amount: 10,
            category: 'read',
            reason: 'Selesai ${chapter.label}',
            questId: 'daily_read_2',
            questProgress: 1,
          );
      ref.invalidate(gamificationProvider);
    }
  }

  NovelChapter? get _previous {
    final index = _chapters.indexWhere((item) => item.index == _chapter?.index);
    return index > 0 ? _chapters[index - 1] : null;
  }

  NovelChapter? get _next {
    final index = _chapters.indexWhere((item) => item.index == _chapter?.index);
    return (index >= 0 && index < _chapters.length - 1) ? _chapters[index + 1] : null;
  }

  Color get _backgroundColor {
    if (!_nightMode) {
      return switch (_background) {
        'sepia' => const Color(0xFFF3E9D2),
        'paper' => const Color(0xFFFAF7F0),
        'slate' => const Color(0xFF1F2430),
        _ => const Color(0xFF101010),
      };
    }
    return const Color(0xFF08070C);
  }

  Color get _textColor {
    if (!_nightMode) {
      return _background == 'sepia' || _background == 'paper'
          ? const Color(0xFF2A2118)
          : const Color(0xFFE6E2F2);
    }
    return const Color(0xFFD8D3EA);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        backgroundColor: _backgroundColor,
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Novel')),
        body: EmptyState(
          title: 'Tidak dapat membuka novel',
          message: _error,
          icon: Icons.menu_book_rounded,
          actionLabel: 'Coba lagi',
          onAction: _load,
        ),
      );
    }
    return Scaffold(
      backgroundColor: _backgroundColor,
      body: GestureDetector(
        onTap: () => setState(() => _showUi = !_showUi),
        child: Stack(
          children: [
            Positioned.fill(
              child: SingleChildScrollView(
                controller: _scrollController,
                padding: EdgeInsets.fromLTRB(
                  24,
                  MediaQuery.of(context).padding.top + (_showUi ? 64 : 28),
                  24,
                  140,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _media?.title ?? '',
                      style: TextStyle(
                        fontSize: 12,
                        letterSpacing: 1.4,
                        fontWeight: FontWeight.w700,
                        color: _textColor.withValues(alpha: 0.45),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      _chapter?.title ?? '',
                      style: TextStyle(
                        fontSize: 22,
                        height: 1.3,
                        fontWeight: FontWeight.w800,
                        color: _textColor,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${_chapter?.label ?? ''} • ${_media?.studio ?? ''}',
                      style: TextStyle(
                        fontSize: 11.5,
                        color: _textColor.withValues(alpha: 0.5),
                      ),
                    ),
                    const SizedBox(height: 22),
                    Text(
                      _content ?? '',
                      style: TextStyle(
                        fontSize: _fontSize,
                        height: _lineHeight,
                        color: _textColor,
                        fontFamily: _fontFamily == 'Roboto' ? null : _fontFamily,
                        letterSpacing: 0.2,
                      ),
                    ),
                    const SizedBox(height: 34),
                    Row(
                      children: [
                        Expanded(
                          child: _ChapterButton(
                            label: 'Bab sebelumnya',
                            icon: Icons.chevron_left_rounded,
                            enabled: _previous != null,
                            onTap: () => _load(index: _previous!.index),
                            textColor: _textColor,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _ChapterButton(
                            label: 'Bab berikutnya',
                            icon: Icons.chevron_right_rounded,
                            trailingIcon: true,
                            enabled: _next != null,
                            onTap: () => _load(index: _next!.index),
                            textColor: _textColor,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'Sumber: Wikisource Bahasa Indonesia • lisensi CC BY-SA / '
                      'domain publik. Mohon cantumkan atribusi saat membagikan ulang.',
                      style: TextStyle(
                        fontSize: 9.5,
                        height: 1.6,
                        color: _textColor.withValues(alpha: 0.35),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (_showUi) _buildTopBar(),
            if (_showUi) _buildBottomBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: Container(
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 4,
          left: 4,
          right: 8,
          bottom: 4,
        ),
        decoration: BoxDecoration(
          color: _backgroundColor.withValues(alpha: 0.92),
        ),
        child: Row(
          children: [
            IconButton(
              icon: Icon(Icons.arrow_back_rounded, color: _textColor),
              onPressed: () {
                _saveProgress();
                AppNav.back(context);
              },
            ),
            Expanded(
              child: Text(
                widget.title ?? _media?.title ?? 'Novel',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: _textColor,
                ),
              ),
            ),
            IconButton(
              icon: Icon(
                _nightMode ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
                size: 19,
                color: _textColor,
              ),
              onPressed: () {
                setState(() => _nightMode = !_nightMode);
                ref.read(settingsProvider.notifier).patch(readerNightMode: _nightMode);
              },
            ),
            IconButton(
              icon: Icon(Icons.text_fields_rounded, size: 19, color: _textColor),
              onPressed: _openSettingsSheet,
            ),
            IconButton(
              icon: Icon(Icons.list_rounded, size: 19, color: _textColor),
              onPressed: _openChapterList,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Positioned(
      left: 20,
      right: 20,
      bottom: MediaQuery.of(context).padding.bottom + 12,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          color: _nightMode
              ? AppColors.surface.withValues(alpha: 0.95)
              : Colors.white.withValues(alpha: 0.9),
          child: Row(
            children: [
              Text(
                _chapter?.label ?? '',
                style: TextStyle(
                  fontSize: 11,
                  color: _nightMode ? AppColors.textSecondary : AppColors.lightTextSecondary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: _scrollProgress == 0 ? 0.02 : _scrollProgress,
                    minHeight: 4,
                    backgroundColor: _nightMode
                        ? AppColors.surfaceHigh
                        : const Color(0xFFE7E1F5),
                    valueColor:
                        const AlwaysStoppedAnimation(AppColors.violetNeon),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                '${(_scrollProgress * 100).round()}%',
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: AppColors.violetNeon,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openSettingsSheet() {
    showModalBottomSheet<void>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Pengaturan Reader',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 18),
                const Text('Ukuran teks', style: TextStyle(fontSize: 12)),
                Slider(
                  value: _fontSize,
                  min: 13,
                  max: 28,
                  divisions: 15,
                  label: '${_fontSize.round()}',
                  onChanged: (value) {
                    setSheetState(() => _fontSize = value);
                    setState(() {});
                    ref.read(settingsProvider.notifier).patch(readerFontSize: value);
                  },
                ),
                const Text('Jarak antarbaris', style: TextStyle(fontSize: 12)),
                Slider(
                  value: _lineHeight,
                  min: 1.2,
                  max: 2.4,
                  divisions: 12,
                  label: _lineHeight.toStringAsFixed(1),
                  onChanged: (value) {
                    setSheetState(() => _lineHeight = value);
                    setState(() {});
                    ref.read(settingsProvider.notifier).patch(readerLineHeight: value);
                  },
                ),
                const SizedBox(height: 10),
                const Text('Jenis huruf', style: TextStyle(fontSize: 12)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final font in ['Roboto', 'Georgia', 'Monospace', 'Serif'])
                      ChoiceChip(
                        label: Text(font, style: const TextStyle(fontSize: 11)),
                        selected: _fontFamily == font,
                        onSelected: (_) {
                          setSheetState(() => _fontFamily = font);
                          setState(() {});
                          ref.read(settingsProvider.notifier).patch(readerFontFamily: font);
                        },
                      ),
                  ],
                ),
                const SizedBox(height: 14),
                const Text('Latar reader', style: TextStyle(fontSize: 12)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final entry in {
                      'dark': 'Gelap',
                      'slate': 'Slate',
                      'sepia': 'Sepia',
                      'paper': 'Kertas',
                    }.entries)
                      ChoiceChip(
                        label: Text(entry.value, style: const TextStyle(fontSize: 11)),
                        selected: _background == entry.key,
                        onSelected: (_) {
                          setSheetState(() {
                            _background = entry.key;
                            _nightMode = false;
                          });
                          setState(() {});
                          ref.read(settingsProvider.notifier).patch(
                                readerBackground: entry.key,
                                readerNightMode: false,
                              );
                        },
                      ),
                  ],
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openChapterList() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: const BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          children: [
            const SizedBox(height: 12),
            Text(
              '${_chapters.length} Bab',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: _chapters.length,
                itemBuilder: (context, index) {
                  final chapter = _chapters[index];
                  final active = chapter.index == _chapter?.index;
                  return ListTile(
                    dense: true,
                    leading: CircleAvatar(
                      radius: 14,
                      backgroundColor: active
                          ? AppColors.violet
                          : AppColors.surfaceHigh,
                      child: Text(
                        '${chapter.index}',
                        style: const TextStyle(fontSize: 10, color: Colors.white),
                      ),
                    ),
                    title: Text(
                      chapter.title,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: active ? FontWeight.w700 : FontWeight.w400,
                        color: active ? AppColors.violetNeon : AppColors.textPrimary,
                      ),
                    ),
                    trailing: active
                        ? const Icon(Icons.play_arrow_rounded,
                            size: 16, color: AppColors.violetNeon)
                        : null,
                    onTap: () {
                      Navigator.pop(context);
                      _load(index: chapter.index);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChapterButton extends StatelessWidget {
  const _ChapterButton({
    required this.label,
    required this.icon,
    required this.enabled,
    required this.onTap,
    required this.textColor,
    this.trailingIcon = false,
  });

  final String label;
  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;
  final Color textColor;
  final bool trailingIcon;

  @override
  Widget build(BuildContext context) {
    final color = enabled ? textColor : textColor.withValues(alpha: 0.3);
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          border: Border.all(color: textColor.withValues(alpha: 0.2)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (!trailingIcon) Icon(icon, size: 16, color: color),
            if (!trailingIcon) const SizedBox(width: 4),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 11.5, color: color),
              ),
            ),
            if (trailingIcon) const SizedBox(width: 4),
            if (trailingIcon) Icon(icon, size: 16, color: color),
          ],
        ),
      ),
    );
  }
}
