import 'package:flutter_test/flutter_test.dart';

import 'package:animeverse/data/models/gamification.dart';
import 'package:animeverse/data/models/media.dart';
import 'package:animeverse/data/repositories/wikisource_repository.dart';

void main() {
  test('EXP curve menghitung level dengan benar', () {
    expect(LevelMath.levelFromExp(0), 1);
    expect(LevelMath.levelFromExp(250), 2);
    expect(LevelMath.totalExpForLevel(2), 250);
    expect(LevelMath.levelProgress(250), closeTo(0, 0.001));
  });

  test('Rank ditentukan dari total EXP', () {
    expect(RankTier.fromExp(0).key, 'beginner');
    expect(RankTier.fromExp(2500).key, 'amateur');
    expect(RankTier.fromExp(130000).key, 'godlike');
  });

  test('Pembersih HTML Wikisource menghasilkan teks paragraf', () {
    const html = '<div><p>Halo <b>dunia</b>.</p>'
        '<div class="ws-noexport">hapus saya</div>'
        '<p>Paragraf kedua.</p></div>';
    final text = WikisourceRepository.extractPlainText(html);
    expect(text.contains('Halo dunia.'), isTrue);
    expect(text.contains('Paragraf kedua.'), isTrue);
    expect(text.contains('hapus saya'), isFalse);
  });

  test('MediaItem parsing AniList', () {
    final item = MediaItem.fromAniList({
      'id': 21,
      'title': {'romaji': 'One Punch Man', 'english': 'One Punch Man'},
      'coverImage': {'extraLarge': 'https://example.com/a.jpg', 'color': '#e4a15d'},
      'genres': ['Action', 'Comedy'],
      'averageScore': 85,
      'episodes': 12,
      'status': 'FINISHED',
      'format': 'TV',
    }, MediaKind.anime);
    expect(item.id, 'anilist:21');
    expect(item.title, 'One Punch Man');
    expect(item.scoreLabel, '8.5');
    expect(item.kind.isVideo, isTrue);
  });
}
