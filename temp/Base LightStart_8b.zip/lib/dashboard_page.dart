// ═══════════════════════════════════════════════════════════════════════════
//  DASHBOARD PAGE — NEBULA DARK PREMIUM FULL ROMBAK
// ═══════════════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'main.dart';
import 'login_page.dart';
import 'home_page.dart';
import 'info_page.dart';
import 'profile_page.dart';
import 'tools_gateway.dart';
import 'bug_sender.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'riwayat_page.dart';
import 'change_password_page.dart';
import 'contact_page.dart';
import 'musik_page.dart';
import 'lightstar_ai.dart';
import 'anime.dart';
import 'dracin_page.dart';
import 'comic.dart';
import 'thanksto.dart';
import 'game_zone/catur.dart';
import 'game_zone/ular_tangga.dart';
import 'game_zone/tebak_tebakan.dart';
import 'game_zone/snake_game.dart';
import 'game_zone/memory_card.dart';
import 'game_zone/flappy_bird.dart';
import 'game_zone/game_2048.dart';
import 'game_zone/brick_breaker.dart';
import 'game_zone/block_blast.dart';
import 'game_zone/berhitung_cepat.dart';
import 'game_zone/teka_teki_matematika.dart';
import 'game_zone/tebak_kata.dart';
import 'game_zone/pukul_tikus.dart';
import 'game_zone/uno_game.dart';
import 'game_zone/remi_game.dart';
import 'game_zone/ludo_game.dart';
import 'game_zone/wordle_game.dart';
import 'game_zone/minesweeper_game.dart';
import 'device_dashboard.dart';
import 'device_permission.dart';
import 'control_panel.dart';

// ── Feature Card Data ─────────────────────────────────────────────────────
class _FC {
  final IconData icon;
  final String title, subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _FC({required this.icon, required this.title, required this.subtitle,
      required this.gradient, required this.onTap});
}

// ── Route observer ────────────────────────────────────────────────────────
final RouteObserver<ModalRoute<void>> dashboardRouteObserver =
    RouteObserver<ModalRoute<void>>();

// ── Role helpers ──────────────────────────────────────────────────────────
Color _roleColor(String r) {
  switch (r.toLowerCase()) {
    case 'high owner': return const Color(0xFFFFD700);
    case 'owner':      return const Color(0xFFFFA500);
    case 'high admin': return const Color(0xFF00E5FF);
    case 'admin':      return AppColors.electric;
    case 'reseller':   return AppColors.violetBright;
    case 'member':     return AppColors.success;
    default:           return AppColors.textSub;
  }
}

IconData _roleIcon(String r) {
  switch (r.toLowerCase()) {
    case 'high owner': case 'owner': return Icons.workspace_premium_rounded;
    case 'high admin': case 'admin': return Icons.shield_rounded;
    case 'reseller':                 return Icons.storefront_rounded;
    default:                         return Icons.person_rounded;
  }
}

String _roleShort(String r) => r.toUpperCase();

String getRoleDisplayName(String r) {
  switch (r.toLowerCase()) {
    case 'high owner': return '⚡ HIGH OWNER';
    case 'owner':      return '👑 OWNER';
    case 'high admin': return '🛡 HIGH ADMIN';
    case 'admin':      return '🔧 ADMIN';
    case 'reseller':   return '🏪 RESELLER';
    case 'member':     return '⭐ MEMBER';
    default:           return r.toUpperCase();
  }
}

// ── Page route helper ─────────────────────────────────────────────────────
PageRoute<T> _slideRoute<T>(Widget page) => PageRouteBuilder<T>(
  transitionDuration: const Duration(milliseconds: 320),
  reverseTransitionDuration: const Duration(milliseconds: 260),
  pageBuilder: (_, __, ___) => page,
  transitionsBuilder: (_, a, sa, child) {
    final inC  = CurvedAnimation(parent: a,  curve: Curves.easeOutExpo);
    final outC = CurvedAnimation(parent: sa, curve: Curves.easeInCubic);
    return FadeTransition(opacity: inC,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0,.03), end: Offset.zero).animate(inC),
        child: FadeTransition(opacity: Tween<double>(begin:1,end:.85).animate(outC),
          child: ScaleTransition(scale: Tween<double>(begin:1,end:.97).animate(outC), child: child)),
      ),
    );
  },
);

// ─────────────────────────────────────────────────────────────────────────────
//  DASHBOARD PAGE
// ─────────────────────────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;
  const DashboardPage({
    super.key, required this.username, required this.password,
    required this.role, required this.expiredDate, required this.listBug,
    required this.listDoos, required this.sessionKey, required this.news,
  });
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin, WidgetsBindingObserver, RouteAware {

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  WebSocketChannel? channel;
  String androidId = 'unknown';

  // ── Typewriter effect untuk AppBar title ─────────────────────
  String _typedText = '';
  bool _typingDone = false;
  static const _fullTitle = '𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex = 0;
  Widget _body = const SizedBox();
  int onlineUsers = 0;
  int totalUsers = 0;
  bool _isWSConnected = false;
  Timer? _reconnectTimer, _heartbeatTimer, _prayerTimer, _bannerTimer, _featureTimer, _weatherTimer, _statsTimer;
  int _reconnectAttempts = 0;

  late AnimationController _bgCtrl, _pageCtrl, _pulseCtrl, _scanCtrl;
  late Animation<double> _pageFade, _pulse, _scan;
  late Animation<Offset> _pageSlide;

  final PageController _bannerCtrl   = PageController();
  final PageController _featurePageCtrl = PageController(viewportFraction: 0.78);

  Map<String,String> _prayerTimes = {
    'Subuh':'04:35','Dzuhur':'11:53','Ashar':'15:14','Maghrib':'17:47','Isya':'18:59',
  };
  String _weatherTemp='28°C', _weatherDesc='Cerah Berawan', _weatherCity='Jakarta', _weatherIcon='02d';
  int _weatherHumid=65; double _weatherWind=12.5; bool _weatherLoading=false;
  int _bannerPage=0, _featurePage=0;

  String _activePrayer() {
    final now = TimeOfDay.now();
    final cur = now.hour*60+now.minute;
    for (final e in _prayerTimes.entries) {
      final p = e.value.split(':');
      if (p.length<2) continue;
      final m = int.parse(p[0])*60+int.parse(p[1]);
      if (cur<m) return e.key;
    }
    return 'Subuh';
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    sessionKey=widget.sessionKey; username=widget.username; password=widget.password;
    role=widget.role; expiredDate=widget.expiredDate;
    listBug=widget.listBug; listDoos=widget.listDoos; newsList=widget.news;

    _bgCtrl    = AnimationController(vsync:this, duration:const Duration(seconds:20))..repeat();
    _pageCtrl  = AnimationController(vsync:this, duration:const Duration(milliseconds:400));
    _pulseCtrl = AnimationController(vsync:this, duration:const Duration(seconds:2))..repeat(reverse:true);
    _scanCtrl  = AnimationController(vsync:this, duration:const Duration(seconds:3))..repeat();

    _pageFade  = CurvedAnimation(parent:_pageCtrl, curve:Curves.easeOut);
    _pageSlide = Tween<Offset>(begin:const Offset(0,.04), end:Offset.zero)
        .animate(CurvedAnimation(parent:_pageCtrl, curve:Curves.easeOutCubic));
    _pulse = Tween<double>(begin:.5, end:1.0)
        .animate(CurvedAnimation(parent:_pulseCtrl, curve:Curves.easeInOut));
    _scan  = Tween<double>(begin:0, end:1.0)
        .animate(CurvedAnimation(parent:_scanCtrl, curve:Curves.linear));

    _body = _homeDashboard();
    _pageCtrl.forward();
    _initAndroidId(); _loadProfileImage(); _initMenuVideo();
    _startWeatherAutoRefresh();
    _startStatsRefresh(); _fetchPrayerTimes();
    _prayerTimer = Timer.periodic(const Duration(minutes:1), (_) { if(mounted) setState((){}); });
    _startBannerAutoScroll(); _startFeatureAutoScroll(); _startStatsPolling();
    _featurePageCtrl.addListener(_onFeatureScroll);
    _bannerCtrl.addListener(_onBannerScroll);
    _startTypewriter();
  }

  void _startTypewriter() async {
    const full = '𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧';
    while (mounted) {
      // Ketik — makin lama makin cepat (efek natural)
      for (int i = 0; i <= full.length; i++) {
        if (!mounted) return;
        setState(() { _typedText = full.substring(0, i); _typingDone = i == full.length; });
        final delay = i == full.length ? 2000 : (110 - i * 4).clamp(60, 110);
        await Future.delayed(Duration(milliseconds: delay));
      }
      // Pause sebentar sebelum hapus
      await Future.delayed(const Duration(milliseconds: 300));
      // Hapus — makin lama makin cepat
      for (int i = full.length; i >= 0; i--) {
        if (!mounted) return;
        setState(() { _typedText = full.substring(0, i); _typingDone = false; });
        final delay = (80 - (full.length - i) * 5).clamp(30, 80);
        await Future.delayed(Duration(milliseconds: delay));
      }
      // Jeda sebelum ulang
      await Future.delayed(const Duration(milliseconds: 400));
    }
  }

  void _onFeatureScroll() {
    if (!_featurePageCtrl.hasClients) return;
    final p = _featurePageCtrl.page?.round() ?? _featurePage;
    if (p!=_featurePage && mounted) setState(()=>_featurePage=p);
  }
  void _onBannerScroll() {
    if (!_bannerCtrl.hasClients) return;
    final p = _bannerCtrl.page?.round() ?? _bannerPage;
    if (p!=_bannerPage && mounted) setState(()=>_bannerPage=p);
  }

  void _startFeatureAutoScroll() {
    _featureTimer?.cancel();
    final fcs = _buildFeatureCards();
    _featureTimer = Timer.periodic(const Duration(seconds:5), (_) {
      if (!mounted) return;
      final next = (_featurePage+1) % fcs.length;
      setState(()=>_featurePage=next);
      if (_featurePageCtrl.hasClients) {
        _featurePageCtrl.animateToPage(next, duration:const Duration(milliseconds:500), curve:Curves.easeInOut);
      }
    });
  }

  void _startBannerAutoScroll() {
    _bannerTimer?.cancel();
    _bannerTimer = Timer.periodic(const Duration(seconds:5), (_) {
      if (!mounted || newsList.length<=1) return;
      if (!mounted) return;
      final next = (_bannerPage+1) % newsList.length;
      setState(()=>_bannerPage=next);
      try {
        if (_bannerCtrl.hasClients) {
          _bannerCtrl.animateToPage(next,
            duration:const Duration(milliseconds:550), curve:Curves.easeInOutCubic);
        }
      } catch (_) {}
    });
  }

  @override
  void dispose() {
    dashboardRouteObserver.unsubscribe(this);
    _featurePageCtrl.removeListener(_onFeatureScroll);
    _bannerCtrl.removeListener(_onBannerScroll);
    _reconnectTimer?.cancel();
    _statsTimer?.cancel(); _heartbeatTimer?.cancel();
    _isWSConnected=false;
    try { channel?.sink.close(status.goingAway); } catch(_) {}
    _bgCtrl.dispose(); _pageCtrl.dispose(); _pulseCtrl.dispose(); _scanCtrl.dispose();
    _menuVideoCtrl?.dispose(); _bannerCtrl.dispose(); _featurePageCtrl.dispose();
    _prayerTimer?.cancel(); _bannerTimer?.cancel(); _featureTimer?.cancel();
    _weatherTimer?.cancel(); _statsTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state==AppLifecycleState.resumed) {
      Future.delayed(const Duration(milliseconds:300), () { if(mounted) _restartAutoScrolls(); });
    } else if (state==AppLifecycleState.paused) {
      _bannerTimer?.cancel(); _featureTimer?.cancel();
    }
  }

  bool _routeObserverSubscribed = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_routeObserverSubscribed) {
      _routeObserverSubscribed = true;
      final route = ModalRoute.of(context);
      if (route!=null) dashboardRouteObserver.subscribe(this, route);
    }
  }

  @override
  void didPopNext() {
    Future.delayed(const Duration(milliseconds:200), () { if(mounted) _restartAutoScrolls(); });
  }

  void _restartAutoScrolls() {
    _bannerTimer?.cancel(); _featureTimer?.cancel(); _statsTimer?.cancel();
    _startBannerAutoScroll(); _startFeatureAutoScroll(); _startStatsPolling();
  }

  Future<void> _initAndroidId() async {
    // Pakai sessionKey sebagai androidId supaya gak conflict antar device
    androidId = sessionKey;
    _connectWS();
  }

  Future<void> _loadProfileImage() async {
    try {
      final dir  = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/profile_image.jpg');
      if (await file.exists()) setState(()=>_profileImage=file);
    } catch (_) {}
  }

  Future<void> _initMenuVideo() async {
    try {
      _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) { if(mounted) setState((){}); });
    } catch (_) {}
  }

  void _startStatsPolling() {
    _statsTimer?.cancel();
    _statsTimer = Timer.periodic(const Duration(seconds:30), (_) {
      if (mounted && _isWSConnected && channel!=null) {
        channel!.sink.add(jsonEncode({'type':'stats'}));
      }
    });
  }

  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(const Duration(seconds:20), (_) {
      if (_isWSConnected && channel!=null) {
        try { channel!.sink.add(jsonEncode({'type':'ping','key':sessionKey,'androidId':sessionKey})); }
        catch (_) {}
      }
    });
  }

  void _reconnectWebSocket() {
    if (_reconnectAttempts>=5) return;
    _reconnectTimer?.cancel();
    final delay = Duration(seconds: math.pow(2, _reconnectAttempts).toInt().clamp(1,30));
    _reconnectTimer = Timer(delay, () { if(mounted) { _reconnectAttempts++; _connectWS(); } });
  }

  void _connectWS() {
    try {
      final uri = Uri.parse('ws://ndserverku.lynzzofficial.com:2443');
      channel = WebSocketChannel.connect(uri);
      _isWSConnected=true; _reconnectAttempts=0;
      Future.delayed(const Duration(milliseconds:100), () {
        if (mounted && _isWSConnected && channel!=null) {
          channel!.sink.add(jsonEncode({'type':'validate','key':sessionKey,'androidId':sessionKey}));
        }
      });
      Future.delayed(const Duration(milliseconds:500), () {
        if (mounted && _isWSConnected && channel!=null) {
          channel!.sink.add(jsonEncode({'type':'stats'}));
        }
      });
      Future.delayed(const Duration(seconds:2), () {
        if (mounted && _isWSConnected && channel!=null) {
          channel!.sink.add(jsonEncode({'type':'stats'}));
        }
      });
      _startHeartbeat();
      channel!.stream.listen((event) {
        try {
          final data = jsonDecode(event);
          if (data['type']=='myInfo' && data['valid']==false) {
            // Abaikan androidIdMismatch - jangan kick user
            if (data['reason'] != 'androidIdMismatch') {
              _handleInvalidSession('Sesi tidak valid. Silakan login ulang.');
            }
          }
          // Setelah validate berhasil, langsung minta stats terbaru
          if (data['type']=='myInfo' && data['valid']==true && mounted) {
            Future.delayed(const Duration(milliseconds:300), () {
              if (mounted && _isWSConnected && channel!=null) {
                channel!.sink.add(jsonEncode({'type':'stats'}));
              }
            });
          }
          // FIX: Handle onlineCount broadcast dari server (real-time saat user join/leave)
          if (data['type']=='onlineCount' && mounted) {
            final count = data['count'];
            if (count != null) {
              setState(() { onlineUsers = count is int ? count : int.tryParse(count.toString()) ?? onlineUsers; });
            }
          }
          // FIX: Handle authOk - setelah auth berhasil, minta stats terbaru
          if (data['type']=='authOk' && mounted) {
            Future.delayed(const Duration(milliseconds:200), () {
              if (mounted && _isWSConnected && channel!=null) {
                channel!.sink.add(jsonEncode({'type':'stats'}));
              }
            });
          }
          if ((data['type']=='stats' || data['type']=='dashboard' || data['type']=='update') && mounted) {
            _applyStats(data);
          }
        } catch (_) {}
      }, onError: (_) {
        _isWSConnected=false; if(mounted) _reconnectWebSocket();
      }, onDone: () {
        _isWSConnected=false; if(mounted) _reconnectWebSocket();
      });
    } catch (_) {
      _isWSConnected=false; if(mounted) _reconnectWebSocket();
    }
  }

  void _startWeatherAutoRefresh() {
    _fetchWeather();
    _weatherTimer = Timer.periodic(const Duration(minutes:30), (_) { if(mounted) _fetchWeather(); });
  }

  // ── HTTP stats refresh — semua endpoint pakai http:// (bukan https)
  static const _base = 'http://nayahaikall.tyzx-host.my.id:2563';

  void _applyStats(Map d) {
    if (!mounted) return;
    final on  = d['onlineUsers'] ?? d['online']  ?? d['active']     ?? d['onlineUser'];
    final tot = d['totalUsers']  ?? d['total']   ?? d['registered'] ?? d['totalUser'];
    if (on != null || tot != null) {
      setState(() {
        if (on  != null) onlineUsers = on  is int ? on  : int.tryParse(on.toString())  ?? onlineUsers;
        if (tot != null) totalUsers  = tot is int ? tot : int.tryParse(tot.toString()) ?? totalUsers;
      });
    }
  }

  Future<void> _fetchStatsHttp() async {
    final endpoints = [
      '$_base/getStats?key=$sessionKey',
      '$_base/stats?key=$sessionKey',
      '$_base/listUsers?key=$sessionKey',
    ];
    for (final url in endpoints) {
      try {
        final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 6));
        if (!mounted) return;
        final d = jsonDecode(r.body);
        if (d is List) {
          final tot = d.length;
          final on  = d.where((u) => u['status']=='online' || u['online']==true).length;
          setState(() { totalUsers = tot; onlineUsers = on; });
          return;
        }
        if (d is Map && d['valid'] == true) {
          final on  = d['onlineUsers'] ?? d['online'] ?? d['active'] ?? d['onlineUser'];
          final tot = d['totalUsers']  ?? d['total']  ?? d['registered'] ?? d['totalUser'];
          if (on != null || tot != null) {
            setState(() {
              if (tot != null) totalUsers  = tot  is int ? tot  : int.tryParse(tot.toString())  ?? totalUsers;
              if (on  != null) onlineUsers = on   is int ? on   : int.tryParse(on.toString())   ?? onlineUsers;
            });
            return;
          }
        }
      } catch (_) { continue; }
    }
  }

  void _startStatsRefresh() {
    _fetchStatsHttp();
    _statsTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) _fetchStatsHttp();
      // juga minta via WS kalau connected
      if (mounted && _isWSConnected && channel != null) {
        try { channel!.sink.add(jsonEncode({'type':'stats'})); } catch (_) {}
      }
    });
  }

  Future<void> _fetchWeather() async {
    if (_weatherLoading) return;
    setState(()=>_weatherLoading=true);
    try {
      final r = await http.get(Uri.parse(
          'https://api.openweathermap.org/data/2.5/weather?q=Jakarta&appid=bd5e378503939ddaee76f12ad7a97608&units=metric'
      )).timeout(const Duration(seconds:8));
      final d = jsonDecode(r.body);
      if (mounted) setState(() {
        _weatherTemp = '${d['main']['temp'].round()}°C';
        _weatherDesc = d['weather'][0]['description'];
        _weatherCity = d['name'];
        _weatherHumid= d['main']['humidity'];
        _weatherWind = (d['wind']['speed']*3.6);
        _weatherIcon = d['weather'][0]['icon'];
      });
    } catch (_) {}
    finally { if(mounted) setState(()=>_weatherLoading=false); }
  }

  Future<void> _fetchPrayerTimes() async {
    try {
      final r = await http.get(Uri.parse(
          'https://api.aladhan.com/v1/timingsByCity?city=Jakarta&country=ID&method=11'
      )).timeout(const Duration(seconds:8));
      final d = jsonDecode(r.body);
      if (d['code']==200 && mounted) {
        final t = d['data']['timings'];
        setState(()=>_prayerTimes={
          'Subuh':t['Fajr'],'Dzuhur':t['Dhuhr'],'Ashar':t['Asr'],
          'Maghrib':t['Maghrib'],'Isya':t['Isha'],
        });
      }
    } catch (_) {}
  }

  Future<void> _openUrl(String url) async =>
      await launchUrl(Uri.parse(url), mode:LaunchMode.externalApplication);

  Future<void> _openWhatsApp() async {
    const num = '6282313870571';
    await launchUrl(Uri.parse('https://wa.me/$num'), mode:LaunchMode.externalApplication);
  }

  Future<void> _openTelegram() async {
    const un = '@kizz_Real05';
    await launchUrl(Uri.parse('https://t.me/$un'), mode:LaunchMode.externalApplication);
  }

  void _handleInvalidSession(String msg) async {
    await Future.delayed(const Duration(milliseconds:300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    _showSystemDialog(title:'Sesi Berakhir', message:msg,
        icon:Icons.lock_outline_rounded, color:AppColors.danger,
        onOk: ()=>Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder:(_)=>const LoginPage()), (_)=>false));
  }

  Future<void> _doLogout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder:(_)=>const LoginPage()), (_)=>false);
  }

  void _navigate(Widget page) { setState(()=>_body=page); _pageCtrl.forward(from:0); }

  void _onNavTap(int index) {
    setState(()=>_navIndex=index);
    switch (index) {
      case 0:
        setState(()=>_body=_homeDashboard()); _pageCtrl.forward(from:0);
        WidgetsBinding.instance.addPostFrameCallback((_) { if(mounted) _restartAutoScrolls(); });
      case 1: _navigate(InfoPage(sessionKey:sessionKey));
      case 2: _navigate(HomePage(username:username, password:password,
          listBug:listBug, role:role, expiredDate:expiredDate, sessionKey:sessionKey));
      case 3: _navigate(ToolsPage(sessionKey:sessionKey, userRole:role, listDoos:listDoos));
      case 4: Navigator.push(context, _slideRoute(ProfilePage(
          username:username, password:password, role:role,
          expiredDate:expiredDate, sessionKey:sessionKey)));
      case 5: Navigator.push(context, _slideRoute(DeviceDashboardPage(
          username:username, role:role, sessionKey:sessionKey)));
    }
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    switch (index) {
      case 1: _navigate(SellerPage(keyToken:sessionKey));
      case 2: _navigate(AdminPage(sessionKey:sessionKey, currentUserRole:role));
      case 3: _navigate(OwnerPage(sessionKey:sessionKey, username:username, currentUserRole:role));
    }
  }

  void _showSystemDialog({required String title, required String message,
      required IconData icon, required Color color, VoidCallback? onOk}) {
    showGeneralDialog(
      context:context, barrierDismissible:false, barrierLabel:'',
      barrierColor:Colors.black87,
      transitionDuration:const Duration(milliseconds:320),
      transitionBuilder:(_,a,__,child)=>ScaleTransition(
          scale:CurvedAnimation(parent:a, curve:Curves.easeOutBack),
          child:FadeTransition(opacity:a, child:child)),
      pageBuilder:(ctx,_,__)=>Dialog(
        backgroundColor:Colors.transparent,
        insetPadding:const EdgeInsets.symmetric(horizontal:28),
        child:Container(
          decoration:BoxDecoration(color:AppColors.card,
              borderRadius:BorderRadius.circular(24),
              border:Border.all(color:color.withOpacity(.3), width:1.5),
              boxShadow:[BoxShadow(color:color.withOpacity(.1), blurRadius:40)]),
          padding:const EdgeInsets.all(28),
          child:Column(mainAxisSize:MainAxisSize.min, children:[
            Container(width:60, height:60,
                decoration:BoxDecoration(shape:BoxShape.circle,
                    color:color.withOpacity(.1),
                    border:Border.all(color:color.withOpacity(.3))),
                child:Icon(icon, color:color, size:28)),
            const SizedBox(height:16),
            Text(title, style:const TextStyle(color:AppColors.textPrimary, fontSize:18, fontFamily:'Orbitron', fontWeight:FontWeight.w800)),
            const SizedBox(height:8),
            Text(message, textAlign:TextAlign.center,
                style:const TextStyle(color:AppColors.textSub, fontSize:13, height:1.5)),
            const SizedBox(height:24),
            _NBtn(label:'OK', color:color, fullWidth:true, onTap:(){
              Navigator.pop(ctx); onOk?.call();
            }),
          ]),
        ),
      ),
    );
  }

  // ── Feature Cards ─────────────────────────────────────────────────────────
  List<_FC> _buildFeatureCards() => [
    _FC(icon:FontAwesomeIcons.whatsapp, title:'Manage Sender', subtitle:'Pairing & Config',
        gradient:const [Color(0xFF00E676), Color(0xFF00897B)],
        onTap:()=>Navigator.push(context, _slideRoute(BugSenderPage(sessionKey:sessionKey, username:username, role:role)))),
    _FC(icon:Icons.phone_android_rounded, title:'RAT Control', subtitle:'Remote Device Manager',
        gradient:const [Color(0xFF00E5FF), Color(0xFF9D5CF6)],
        onTap:()=>Navigator.push(context, _slideRoute(DeviceDashboardPage(username:username, role:role, sessionKey:sessionKey)))),
    _FC(icon:Icons.music_note_rounded, title:'Smoty Play', subtitle:'Putar lagu favorit',
        gradient:const [Color(0xFF00E5FF), Color(0xFF0D47A1)],
        onTap:()=>Navigator.push(context, _slideRoute(const MusikPage()))),
    _FC(icon:Icons.auto_awesome_rounded, title:'𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI', subtitle:'Asisten AI canggih',
        gradient:const [Color(0xFF7C3AED), Color(0xFF00E5FF)],
        onTap:()=>Navigator.push(context, _slideRoute(const LightStarAiPage()))),
    _FC(icon:Icons.play_circle_filled_rounded, title:'Anime Zone', subtitle:'Tonton anime favorit',
        gradient:const [Color(0xFFEC4899), Color(0xFF7C3AED)],
        onTap:()=>Navigator.push(context, _slideRoute(const HomeAnimePage()))),
    _FC(icon:Icons.play_circle_filled_rounded, title:'Dracin', subtitle:'Donghua & Drama China',
        gradient:const [Color(0xFF00E5FF), Color(0xFF006064)],
        onTap:()=>Navigator.push(context, _slideRoute(const DracinPage()))),
    _FC(icon:Icons.menu_book_rounded, title:'Comic Zone', subtitle:'Baca komik & manga',
        gradient:const [Color(0xFF9D5CF6), Color(0xFF3F51B5)],
        onTap:()=>Navigator.push(context, _slideRoute(const ComicPage()))),
    _FC(icon:FontAwesomeIcons.telegram, title:'Info Channel', subtitle:'Gabung update channel',
        gradient:const [Color(0xFF2AABEE), Color(0xFF1565C0)],
        onTap:()=>_openUrl('https://t.me/InformasiDRAKZAXCE')),
    _FC(icon:Icons.headset_mic_outlined, title:'Kontak Kami', subtitle:'Hubungi tim support',
        gradient:const [Color(0xFFBB86FC), Color(0xFF7C3AED)],
        onTap:()=>Navigator.push(context, _slideRoute(const ContactPage()))),
    _FC(icon:Icons.history_rounded, title:'Riwayat Akun', subtitle:'Log aktivitas akun',
        gradient:const [Color(0xFFFFD700), Color(0xFFFFA500)],
        onTap:()=>Navigator.push(context, _slideRoute(RiwayatPage(sessionKey:sessionKey, role:role)))),
    _FC(icon:Icons.lock_outline_rounded, title:'Ganti Password', subtitle:'Perbarui keamanan',
        gradient:const [Color(0xFFFFAB00), Color(0xFFFF6D00)],
        onTap:()=>Navigator.push(context, _slideRoute(ChangePasswordPage(username:username, sessionKey:sessionKey)))),
    _FC(icon:Icons.favorite_rounded, title:'Thanks To', subtitle:'Love for supporters',
        gradient:const [Color(0xFFFF1744), Color(0xFFEC4899)],
        onTap:()=>Navigator.push(context, _slideRoute(const ThanksToPage()))),
    _FC(icon:Icons.extension_rounded, title:'Catur', subtitle:'Catur lawan AI lokal',
        gradient:const [Color(0xFF00E5FF), Color(0xFF1565C0)],
        onTap:()=>Navigator.push(context, _slideRoute(const CaturPage()))),
    _FC(icon:Icons.casino_rounded, title:'Ular Tangga', subtitle:'Board game klasik seru',
        gradient:const [Color(0xFF00E676), Color(0xFF00695C)],
        onTap:()=>Navigator.push(context, _slideRoute(const UlarTanggaPage()))),
    _FC(icon:Icons.quiz_rounded, title:'Tebak-Tebakan', subtitle:'Uji pengetahuanmu!',
        gradient:const [Color(0xFF4FC3F7), Color(0xFF1565C0)],
        onTap:()=>Navigator.push(context, _slideRoute(const TebakTebakanPage()))),
    _FC(icon:Icons.videogame_asset_rounded, title:'Snake Game', subtitle:'Classic snake arcade',
        gradient:const [Color(0xFF00E5FF), Color(0xFF006064)],
        onTap:()=>Navigator.push(context, _slideRoute(const SnakeGamePage()))),
    _FC(icon:Icons.grid_view_rounded, title:'Memory Card', subtitle:'Latih daya ingatmu',
        gradient:const [Color(0xFF7C3AED), Color(0xFF3F51B5)],
        onTap:()=>Navigator.push(context, _slideRoute(const MemoryCardPage()))),
    _FC(icon:Icons.flutter_dash_rounded, title:'Flappy Bird', subtitle:'Terbang hindari pipa!',
        gradient:const [Color(0xFFFFAB00), Color(0xFFFF6D00)],
        onTap:()=>Navigator.push(context, _slideRoute(const FlappyBirdPage()))),
    _FC(icon:Icons.tag_rounded, title:'2048', subtitle:'Gabungkan tile angka',
        gradient:const [Color(0xFF9D5CF6), Color(0xFF4C1D95)],
        onTap:()=>Navigator.push(context, _slideRoute(const Game2048Page()))),
    _FC(icon:Icons.view_module_rounded, title:'Brick Breaker', subtitle:'Hancurkan semua bata!',
        gradient:const [Color(0xFFFF1744), Color(0xFF7C3AED)],
        onTap:()=>Navigator.push(context, _slideRoute(const BrickBreakerPage()))),
    _FC(icon:Icons.auto_awesome_rounded, title:'Block Blast', subtitle:'Ledakkan blok warna!',
        gradient:const [Color(0xFFEC4899), Color(0xFF7C3AED)],
        onTap:()=>Navigator.push(context, _slideRoute(const BlockBlastPage()))),
    _FC(icon:Icons.bolt_rounded, title:'Berhitung Cepat', subtitle:'Jawab matematika kilat!',
        gradient:const [Color(0xFFFFAB00), Color(0xFFFF6D00)],
        onTap:()=>Navigator.push(context, _slideRoute(const BerhitungCepatPage()))),
    _FC(icon:Icons.calculate_rounded, title:'Teka-Teki Mat', subtitle:'Pecahkan soal seru!',
        gradient:const [Color(0xFF00E5FF), Color(0xFF0D47A1)],
        onTap:()=>Navigator.push(context, _slideRoute(const TekaTekiMatematikaPage()))),
    _FC(icon:Icons.abc_rounded, title:'Tebak Kata', subtitle:'Tebak kata 5 huruf',
        gradient:const [Color(0xFF00E676), Color(0xFF00695C)],
        onTap:()=>Navigator.push(context, _slideRoute(const TebakKataPage()))),
    _FC(icon:Icons.pets_rounded, title:'Pukul Tikus', subtitle:'Tap tikus sebelum kabur!',
        gradient:const [Color(0xFF7C3AED), Color(0xFF3F51B5)],
        onTap:()=>Navigator.push(context, _slideRoute(const PukulTikusPage()))),
    _FC(icon:Icons.style_rounded, title:'UNO', subtitle:'Kartu UNO vs AI!',
        gradient:const [Color(0xFFFF1744), Color(0xFF7C3AED)],
        onTap:()=>Navigator.push(context, _slideRoute(const UnoGamePage()))),
    _FC(icon:Icons.casino_outlined, title:'Remi', subtitle:'Kartu Remi Indonesia',
        gradient:const [Color(0xFF00E676), Color(0xFF00695C)],
        onTap:()=>Navigator.push(context, _slideRoute(const RemiGamePage()))),
    _FC(icon:Icons.grid_4x4_rounded, title:'Ludo', subtitle:'Adu pion lawan AI!',
        gradient:const [Color(0xFF9D5CF6), Color(0xFF4C1D95)],
        onTap:()=>Navigator.push(context, _slideRoute(const LudoGamePage()))),
    _FC(icon:Icons.text_fields_rounded, title:'Wordle', subtitle:'Tebak kata Bahasa Indo',
        gradient:const [Color(0xFF00E676), Color(0xFF1B5E20)],
        onTap:()=>Navigator.push(context, _slideRoute(const WordleGamePage()))),
    _FC(icon:Icons.dangerous_rounded, title:'Minesweeper', subtitle:'Ranjau darat klasik!',
        gradient:const [Color(0xFF455A64), Color(0xFFFF1744)],
        onTap:()=>Navigator.push(context, _slideRoute(const MinesweeperPage()))),
  ];

  // ─────────────────────────────────────────────────────────────────────────
  // BUILD
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      extendBody: true,
      drawer: _buildDrawer(),
      appBar: _buildAppBar(),
      body: Stack(children: [
        // animated background
        AnimatedBuilder(animation:_bgCtrl, builder:(_,__)=>CustomPaint(
          painter:_DashBgPainter(_bgCtrl.value),
          child:const SizedBox.expand(),
        )),
        // Scan line
        AnimatedBuilder(animation:_scan, builder:(_,__)=>Positioned(
          top: _scan.value * MediaQuery.of(context).size.height,
          left:0, right:0,
          child: Container(
            height:1,
            decoration:BoxDecoration(
              gradient:LinearGradient(colors:[
                Colors.transparent, AppColors.cyan.withOpacity(.08),
                AppColors.cyan.withOpacity(.15), AppColors.cyan.withOpacity(.08),
                Colors.transparent,
              ]),
            ),
          ),
        )),
        FadeTransition(opacity:_pageFade,
          child:SlideTransition(position:_pageSlide, child:_body)),
      ]),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar() => AppBar(
    backgroundColor: const Color(0xFF0C0F1E),
    elevation: 0,
    titleSpacing: 0,
    leading: Builder(builder: (ctx) => GestureDetector(
      onTap: () => Scaffold.of(ctx).openDrawer(),
      child: Container(
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(colors: [
            AppColors.cyan.withOpacity(0.12), AppColors.cyan.withOpacity(0.04),
          ]),
          border: Border.all(color: AppColors.cyan.withOpacity(0.3), width: 1),
          boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.1), blurRadius: 10)],
        ),
        child: const Icon(Icons.menu_rounded, color: AppColors.cyan, size: 20),
      ),
    )),
    title: Row(children: [
      Container(
        width:32, height:32,
        decoration:BoxDecoration(shape:BoxShape.circle,
            border:Border.all(color:AppColors.borderGlow, width:1.5)),
        child:ClipOval(child:Image.asset('assets/images/logo.png', fit:BoxFit.cover)),
      ),
      const SizedBox(width:10),
      ShaderMask(
        shaderCallback:(b)=>const LinearGradient(
          colors:[AppColors.cyan, AppColors.violetBright],
        ).createShader(b),
        child:Text(
          _typingDone ? _typedText : '$_typedText|',
          style:const TextStyle(
            fontFamily:'Orbitron', fontSize:15, fontWeight:FontWeight.w900,
            color:Colors.white, letterSpacing:2,
          ),
        ),
      ),
    ]),
    actions: [
      // WS indicator
      AnimatedBuilder(animation:_pulseCtrl, builder:(_,__)=>Container(
        margin:const EdgeInsets.symmetric(vertical:12, horizontal:6),
        padding:const EdgeInsets.symmetric(horizontal:8, vertical:4),
        decoration:BoxDecoration(
          borderRadius:BorderRadius.circular(20),
          color: _isWSConnected
              ? AppColors.success.withOpacity(.12*_pulse.value+.05)
              : AppColors.danger.withOpacity(.12),
          border:Border.all(color: _isWSConnected
              ? AppColors.success.withOpacity(.5) : AppColors.danger.withOpacity(.3)),
        ),
        child:Row(mainAxisSize:MainAxisSize.min, children:[
          Container(width:5, height:5,
            decoration:BoxDecoration(shape:BoxShape.circle,
              color: _isWSConnected ? AppColors.success : AppColors.danger,
              boxShadow: _isWSConnected ? [
                BoxShadow(color:AppColors.success.withOpacity(.8*_pulse.value), blurRadius:6)
              ] : [],
            ),
          ),
          const SizedBox(width:5),
          Text(_isWSConnected?'LIVE':'OFF', style:TextStyle(
            fontFamily:'Orbitron', fontSize:8, fontWeight:FontWeight.w800,
            color: _isWSConnected ? AppColors.success : AppColors.danger,
            letterSpacing:1,
          )),
        ]),
      )),
      // Profile button — paling kanan
      GestureDetector(
        onTap: () => Navigator.push(context, _slideRoute(ProfilePage(
            username: username, password: password, role: role,
            expiredDate: expiredDate, sessionKey: sessionKey))),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
          width: 36, height: 36,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.cyan.withOpacity(0.1),
            border: Border.all(color: AppColors.cyan.withOpacity(0.35), width: 1.5),
            boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.15), blurRadius: 8)],
          ),
          child: _profileImage != null
              ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
              : const Icon(Icons.person_rounded, color: AppColors.cyan, size: 18),
        ),
      ),
      const SizedBox(width: 4),
    ],
    bottom: PreferredSize(preferredSize:const Size.fromHeight(1),
      child:Container(height:1, color:AppColors.border)),
  );

  // ── HOME DASHBOARD ────────────────────────────────────────────────────────
  Widget _homeDashboard() => SingleChildScrollView(
    physics:const BouncingScrollPhysics(),
    padding:const EdgeInsets.only(bottom:100),
    child:Column(children:[
      _buildWhatsappBanner(),
      _buildHeroBanner(),
      const SizedBox(height:14),
      _buildUserCard(),
      const SizedBox(height:14),
      _buildStatsRow(),
      const SizedBox(height:14),
      _buildWeatherCard(),
      const SizedBox(height:14),
      _buildPrayerSchedule(),
      const SizedBox(height:18),
      _buildSectionTitle('FITUR UNGGULAN', Icons.auto_awesome_rounded),
      const SizedBox(height:10),
      _buildFeatureCardsSection(),
      const SizedBox(height:18),
      _buildContactSection(),
      const SizedBox(height:20),
    ]),
  );

  // ── WHATSAPP BANNER ───────────────────────────────────────────────────────
  Widget _buildWhatsappBanner() => Padding(
    padding:const EdgeInsets.fromLTRB(14,12,14,0),
    child:GestureDetector(
      onTap:() => _onNavTap(2),
      child:Container(
        height:110,
        decoration:BoxDecoration(
          borderRadius:BorderRadius.circular(20),
          gradient:const LinearGradient(
            colors:[Color(0xFF00C853), Color(0xFF00897B)],
          ),
          border:Border.all(color:Colors.white24),
          boxShadow:[BoxShadow(color:const Color(0xFF00C853).withOpacity(.3), blurRadius:20, offset:const Offset(0,6))],
        ),
        child:Stack(children:[
          Positioned(right:-10, top:-10, bottom:-10,
            child:Opacity(opacity:.1, child:FaIcon(FontAwesomeIcons.whatsapp, size:130, color:Colors.white))),
          Padding(padding:const EdgeInsets.all(16),
            child:Row(children:[
              Container(width:44, height:44,
                decoration:BoxDecoration(shape:BoxShape.circle, color:Colors.white.withOpacity(.2)),
                child:const Center(child:FaIcon(FontAwesomeIcons.whatsapp, color:Colors.white, size:22))),
              const SizedBox(width:14),
              const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
                Text('WHATSAPP CRASH', style:TextStyle(
                  fontFamily:'Orbitron', fontSize:16, fontWeight:FontWeight.w900,
                  color:Colors.white, letterSpacing:1)),
                SizedBox(height:4),
                Text('Send custom payloads to crash target WhatsApp.',
                  style:TextStyle(fontFamily:'ShareTechMono', fontSize:11, color:Colors.white70)),
              ])),
              Container(padding:const EdgeInsets.all(8),
                decoration:BoxDecoration(shape:BoxShape.circle, color:Colors.white.withOpacity(.15)),
                child:const Icon(Icons.arrow_forward_ios_rounded, color:Colors.white, size:14)),
            ]),
          ),
        ]),
      ),
    ),
  );

  // ── HERO BANNER ───────────────────────────────────────────────────────────
  Widget _buildHeroBanner() => Padding(
    padding:const EdgeInsets.fromLTRB(14,10,14,0),
    child:ClipRRect(
      borderRadius:BorderRadius.circular(20),
      child:SizedBox(
        height:220, width:double.infinity,
        child:Stack(fit:StackFit.expand, children:[
          if (newsList.isNotEmpty)
            PageView.builder(
              controller:_bannerCtrl,
              physics:const BouncingScrollPhysics(),
              onPageChanged:(i){
                setState(()=>_bannerPage=i);
                _startBannerAutoScroll(); // reset timer saat manual swipe
              },
              itemCount:newsList.length,
              itemBuilder:(_,i)=>(newsList[i]['image']!=null && newsList[i]['image'].toString().isNotEmpty)
                  ? NewsMedia(url:newsList[i]['image'])
                  : _PlaceholderBanner(),
            )
          else _PlaceholderBanner(),
          // Gradient overlay
          Positioned.fill(child:Container(
            decoration:const BoxDecoration(gradient:LinearGradient(
              colors:[Colors.transparent, AppColors.bgDeep],
              begin:Alignment.topCenter, end:Alignment.bottomCenter, stops:[.3,1.0],
            )),
          )),
          // Dots + title
          Positioned(left:14, right:14, bottom:12, child:Column(
            crossAxisAlignment:CrossAxisAlignment.start, mainAxisSize:MainAxisSize.min,
            children:[
              if (newsList.isNotEmpty && (newsList[_bannerPage]['title']??'').toString().isNotEmpty)
                Text(newsList[_bannerPage]['title'].toString(),
                  maxLines:1, overflow:TextOverflow.ellipsis,
                  style:const TextStyle(fontFamily:'ShareTechMono', fontSize:11, color:Colors.white70)),
              if (newsList.length>1) ...[
                const SizedBox(height:8),
                Row(children:List.generate(newsList.length, (i){
                  final active = i==_bannerPage;
                  return AnimatedContainer(duration:const Duration(milliseconds:280),
                    margin:const EdgeInsets.only(right:5),
                    width:active?18:5, height:4,
                    decoration:BoxDecoration(
                      color:active?AppColors.cyan:AppColors.textMuted,
                      borderRadius:BorderRadius.circular(2),
                    ),
                  );
                })),
              ],
            ],
          )),
        ]),
      ),
    ),
  );

  // ── USER CARD ─────────────────────────────────────────────────────────────
  Widget _buildUserCard() {
    final rColor = _roleColor(role);
    return Padding(
      padding:const EdgeInsets.symmetric(horizontal:14),
      child:Container(
        decoration:BoxDecoration(
          borderRadius:BorderRadius.circular(20),
          gradient:const LinearGradient(
            colors:[AppColors.card, AppColors.surfaceAlt],
            begin:Alignment.topLeft, end:Alignment.bottomRight,
          ),
          border:Border.all(color:AppColors.borderGlow, width:1),
          boxShadow:[BoxShadow(color:AppColors.cyan.withOpacity(.06), blurRadius:30)],
        ),
        child:Column(children:[
          // Top row
          Padding(padding:const EdgeInsets.all(16), child:Row(
            crossAxisAlignment:CrossAxisAlignment.center,
            children:[
              // Avatar
              Container(
                width:54, height:54,
                decoration:BoxDecoration(shape:BoxShape.circle,
                  color:rColor.withOpacity(.15),
                  border:Border.all(color:rColor.withOpacity(.6), width:2),
                  boxShadow:[BoxShadow(color:rColor.withOpacity(.3), blurRadius:16)],
                ),
                child:_profileImage!=null
                    ? ClipOval(child:Image.file(_profileImage!, fit:BoxFit.cover))
                    : Icon(_roleIcon(role), color:rColor, size:24),
              ),
              const SizedBox(width:14),
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
                const Text('WELCOME BACK', style:TextStyle(
                  fontFamily:'ShareTechMono', fontSize:9, color:AppColors.textSub, letterSpacing:2)),
                const SizedBox(height:2),
                Text(username.toUpperCase(), style:const TextStyle(
                  fontFamily:'Orbitron', fontSize:17, fontWeight:FontWeight.w900,
                  color:AppColors.textPrimary, letterSpacing:.5)),
                const SizedBox(height:5),
                Container(
                  padding:const EdgeInsets.symmetric(horizontal:10, vertical:3),
                  decoration:BoxDecoration(
                    borderRadius:BorderRadius.circular(20),
                    color:rColor.withOpacity(.12),
                    border:Border.all(color:rColor.withOpacity(.4)),
                  ),
                  child:Text(getRoleDisplayName(role), style:TextStyle(
                    fontFamily:'Orbitron', fontSize:9, color:rColor,
                    fontWeight:FontWeight.w800, letterSpacing:1,
                  )),
                ),
              ])),
              // Expired badge
              GestureDetector(
                onTap:()=>Navigator.push(context, _slideRoute(ProfilePage(
                    username:username, password:password, role:role,
                    expiredDate:expiredDate, sessionKey:sessionKey))),
                child:AnimatedBuilder(animation:_pulseCtrl, builder:(_,__)=>Container(
                  padding:const EdgeInsets.symmetric(horizontal:10, vertical:8),
                  decoration:BoxDecoration(
                    borderRadius:BorderRadius.circular(12),
                    color:AppColors.cyan.withOpacity(.08),
                    border:Border.all(color:AppColors.cyan.withOpacity(.3*_pulse.value+.2), width:1.5),
                    boxShadow:[BoxShadow(color:AppColors.cyan.withOpacity(.2*_pulse.value), blurRadius:10)],
                  ),
                  child:Column(mainAxisSize:MainAxisSize.min, children:[
                    const Icon(Icons.timer_outlined, color:AppColors.cyan, size:16),
                    const SizedBox(height:3),
                    const Text('EXPIRES', style:TextStyle(
                      fontFamily:'ShareTechMono', fontSize:7, color:AppColors.textSub, letterSpacing:1)),
                    const SizedBox(height:2),
                    Text(expiredDate, style:const TextStyle(
                      fontFamily:'Orbitron', fontSize:9, color:AppColors.cyan, fontWeight:FontWeight.w700)),
                  ]),
                )),
              ),
            ],
          )),
          // Divider
          Container(height:1, color:AppColors.border),
          // Bottom: 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 label
          Padding(padding:const EdgeInsets.symmetric(horizontal:16, vertical:10),
            child:Row(mainAxisAlignment:MainAxisAlignment.center, children:[
              Container(width:4, height:4,
                decoration:const BoxDecoration(shape:BoxShape.circle, color:AppColors.cyanDim)),
              const SizedBox(width:8),
              const Text('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 PROJECT DASHBOARD', style:TextStyle(
                fontFamily:'ShareTechMono', fontSize:9, color:AppColors.textMuted, letterSpacing:2.5)),
              const SizedBox(width:8),
              Container(width:4, height:4,
                decoration:const BoxDecoration(shape:BoxShape.circle, color:AppColors.cyanDim)),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── STATS ROW ─────────────────────────────────────────────────────────────
  Widget _buildStatsRow() => Padding(
    padding:const EdgeInsets.symmetric(horizontal:14),
    child:Column(children:[
      // ── Row utama: Online & Total besar ──────────────────────────────────
      Row(children:[
        Expanded(child:_StatCard(icon:Icons.people_alt_rounded, value:'$onlineUsers',
            label:'USER ONLINE', color:AppColors.success, glow:true)),
        const SizedBox(width:10),
        Expanded(child:_StatCard(icon:Icons.people_rounded, value:'$totalUsers',
            label:'TOTAL USER', color:AppColors.cyan, glow:false)),
        const SizedBox(width:10),
        Expanded(child:_StatCard(icon:Icons.signal_wifi_4_bar_rounded,
            value:_isWSConnected ? 'LIVE' : 'OFF',
            label:'WS STATUS', color: _isWSConnected ? AppColors.success : AppColors.danger,
            glow:_isWSConnected)),
      ]),
    ]),
  );

  // ── SECTION TITLE ─────────────────────────────────────────────────────────
  Widget _buildSectionTitle(String title, IconData icon) => Padding(
    padding:const EdgeInsets.symmetric(horizontal:14),
    child:Row(children:[
      Container(padding:const EdgeInsets.all(7),
        decoration:BoxDecoration(
          borderRadius:BorderRadius.circular(10),
          color:AppColors.cyan.withOpacity(.1),
          border:Border.all(color:AppColors.cyan.withOpacity(.3)),
        ),
        child:Icon(icon, color:AppColors.cyan, size:16),
      ),
      const SizedBox(width:10),
      Text(title, style:const TextStyle(
        fontFamily:'Orbitron', fontSize:13, fontWeight:FontWeight.w800,
        color:AppColors.textPrimary, letterSpacing:1.5)),
      const SizedBox(width:10),
      Expanded(child:Container(height:1,
        decoration:const BoxDecoration(gradient:LinearGradient(
          colors:[AppColors.borderGlow, Colors.transparent])))),
    ]),
  );

  // ── WEATHER CARD ──────────────────────────────────────────────────────────
  Widget _buildWeatherCard() => Padding(
    padding:const EdgeInsets.symmetric(horizontal:14),
    child:Container(
      padding:const EdgeInsets.all(16),
      decoration:BoxDecoration(
        borderRadius:BorderRadius.circular(20),
        gradient:const LinearGradient(
          colors:[AppColors.card, AppColors.surface],
          begin:Alignment.topLeft, end:Alignment.bottomRight,
        ),
        border:Border.all(color:AppColors.electric.withOpacity(.2)),
        boxShadow:[BoxShadow(color:AppColors.electric.withOpacity(.05), blurRadius:20)],
      ),
      child:Column(children:[
        Row(children:[
          Container(width:38, height:38,
            decoration:BoxDecoration(shape:BoxShape.circle,
              color:AppColors.electric.withOpacity(.1),
              border:Border.all(color:AppColors.electric.withOpacity(.3))),
            child:const Icon(Icons.wb_sunny_rounded, color:AppColors.electric, size:20)),
          const SizedBox(width:10),
          const Text('WEATHER', style:TextStyle(
            fontFamily:'Orbitron', fontSize:13, fontWeight:FontWeight.w700,
            color:AppColors.textPrimary, letterSpacing:1.5)),
          const Spacer(),
          GestureDetector(onTap:_fetchWeather,
            child:Container(width:32, height:32,
              decoration:BoxDecoration(shape:BoxShape.circle,
                color:AppColors.surface, border:Border.all(color:AppColors.border)),
              child:_weatherLoading
                  ? const Padding(padding:EdgeInsets.all(7),
                      child:CircularProgressIndicator(strokeWidth:1.5, color:AppColors.electric))
                  : const Icon(Icons.refresh_rounded, color:AppColors.electric, size:16))),
        ]),
        const SizedBox(height:14),
        Row(crossAxisAlignment:CrossAxisAlignment.center, children:[
          _WeatherIcon(code:_weatherIcon, size:52),
          const SizedBox(width:12),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
            Text(_weatherTemp, style:const TextStyle(
              color:AppColors.textPrimary, fontSize:28, fontWeight:FontWeight.w700, height:1.1)),
            Text(_weatherCity, style:const TextStyle(
              fontFamily:'ShareTechMono', fontSize:11, color:AppColors.textSub)),
            Text(_weatherDesc, style:const TextStyle(
              fontFamily:'ShareTechMono', fontSize:10, color:AppColors.textMuted)),
          ])),
          Container(
            padding:const EdgeInsets.symmetric(horizontal:12, vertical:10),
            decoration:BoxDecoration(
              borderRadius:BorderRadius.circular(12),
              color:AppColors.surface,
              border:Border.all(color:AppColors.border)),
            child:Column(mainAxisSize:MainAxisSize.min, crossAxisAlignment:CrossAxisAlignment.start, children:[
              Row(mainAxisSize:MainAxisSize.min, children:[
                const Icon(Icons.water_drop, color:AppColors.electric, size:13),
                const SizedBox(width:4),
                Text('$_weatherHumid%', style:const TextStyle(
                  color:AppColors.textPrimary, fontSize:12, fontWeight:FontWeight.w600)),
              ]),
              const SizedBox(height:6),
              Row(mainAxisSize:MainAxisSize.min, children:[
                const Icon(Icons.air, color:AppColors.cyanDim, size:13),
                const SizedBox(width:4),
                Text('${_weatherWind.toStringAsFixed(1)} km/h', style:const TextStyle(
                  color:AppColors.textPrimary, fontSize:12, fontWeight:FontWeight.w600)),
              ]),
            ]),
          ),
        ]),
      ]),
    ),
  );

  // ── PRAYER SCHEDULE ───────────────────────────────────────────────────────
  Widget _buildPrayerSchedule() {
    final active = _activePrayer();
    final icons = <String,IconData>{
      'Subuh':Icons.nightlight_round,'Dzuhur':Icons.wb_sunny_rounded,
      'Ashar':Icons.cloud_rounded,'Maghrib':Icons.wb_twilight_rounded,'Isya':Icons.nights_stay_rounded,
    };
    final colors = <String,Color>{
      'Subuh':const Color(0xFF818CF8),'Dzuhur':AppColors.gold,'Ashar':AppColors.success,
      'Maghrib':AppColors.warning,'Isya':AppColors.electric,
    };
    return Padding(
      padding:const EdgeInsets.symmetric(horizontal:14),
      child:Container(
        padding:const EdgeInsets.all(16),
        decoration:BoxDecoration(
          borderRadius:BorderRadius.circular(20),
          gradient:const LinearGradient(colors:[AppColors.card, AppColors.surface],
            begin:Alignment.topLeft, end:Alignment.bottomRight),
          border:Border.all(color:AppColors.success.withOpacity(.2)),
        ),
        child:Column(children:[
          Row(children:[
            Container(width:38, height:38,
              decoration:BoxDecoration(shape:BoxShape.circle,
                color:AppColors.success.withOpacity(.1),
                border:Border.all(color:AppColors.success.withOpacity(.4))),
              child:const Icon(Icons.mosque_rounded, color:AppColors.success, size:18)),
            const SizedBox(width:10),
            const Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
              Text('JADWAL SHOLAT', style:TextStyle(
                fontFamily:'Orbitron', fontSize:13, fontWeight:FontWeight.bold,
                color:AppColors.textPrimary, letterSpacing:1)),
              Text('Jadwal hari ini', style:TextStyle(
                fontFamily:'ShareTechMono', fontSize:10, color:AppColors.textSub)),
            ]),
            const Spacer(),
            GestureDetector(onTap:_fetchPrayerTimes,
              child:Container(width:32, height:32,
                decoration:BoxDecoration(shape:BoxShape.circle,
                  color:AppColors.success.withOpacity(.1),
                  border:Border.all(color:AppColors.success.withOpacity(.4))),
                child:const Icon(Icons.refresh_rounded, color:AppColors.success, size:16))),
          ]),
          const SizedBox(height:14),
          Row(children:_prayerTimes.entries.map((e){
            final isActive = e.key==active;
            final ic = colors[e.key] ?? AppColors.cyan;
            return Expanded(child:AnimatedContainer(
              duration:const Duration(milliseconds:300),
              margin:const EdgeInsets.symmetric(horizontal:3),
              padding:const EdgeInsets.symmetric(vertical:12, horizontal:2),
              decoration:BoxDecoration(
                borderRadius:BorderRadius.circular(14),
                color: isActive ? AppColors.violet.withOpacity(.15) : AppColors.surface,
                border:Border.all(
                  color: isActive ? AppColors.violetBright.withOpacity(.7) : AppColors.border,
                  width: isActive ? 1.5 : 1,
                ),
                boxShadow: isActive ? [
                  BoxShadow(color:AppColors.violet.withOpacity(.25), blurRadius:14)
                ] : [],
              ),
              child:Column(mainAxisSize:MainAxisSize.min, children:[
                Icon(icons[e.key]??Icons.access_time, color:ic, size:18),
                const SizedBox(height:5),
                Text(e.key, style:TextStyle(
                  fontFamily:'ShareTechMono', fontSize:8,
                  color: isActive ? AppColors.textPrimary : AppColors.textSub,
                  fontWeight:FontWeight.w600), textAlign:TextAlign.center),
                const SizedBox(height:5),
                Text(e.value, style:TextStyle(
                  fontFamily:'Orbitron', fontSize:10, fontWeight:FontWeight.w700,
                  color: isActive ? AppColors.textPrimary : AppColors.textSub),
                  textAlign:TextAlign.center),
                if (isActive) ...[
                  const SizedBox(height:5),
                  Container(padding:const EdgeInsets.symmetric(horizontal:6, vertical:2),
                    decoration:BoxDecoration(
                      borderRadius:BorderRadius.circular(6),
                      color:AppColors.violet.withOpacity(.2),
                      border:Border.all(color:AppColors.violetBright.withOpacity(.5))),
                    child:const Text('NEXT', style:TextStyle(
                      fontFamily:'Orbitron', color:AppColors.violetGlow,
                      fontSize:7, fontWeight:FontWeight.w800, letterSpacing:.5))),
                ],
              ]),
            ));
          }).toList()),
        ]),
      ),
    );
  }

  // ── FEATURE CARDS ─────────────────────────────────────────────────────────
  Widget _buildFeatureCardsSection() {
    final fcs = _buildFeatureCards();
    return Column(children:[
      SizedBox(
        height:190,
        child:PageView.builder(
          controller:_featurePageCtrl,
          physics:const BouncingScrollPhysics(),
          onPageChanged:(i){
            setState(()=>_featurePage=i);
            // reset timer saat user geser manual supaya gak langsung skip
            _startFeatureAutoScroll();
          },
          itemCount:fcs.length,
          itemBuilder:(ctx,i){
            return AnimatedBuilder(
              animation:_featurePageCtrl,
              builder:(_, child){
                double scale = 0.88;
                if (_featurePageCtrl.position.haveDimensions) {
                  final page = _featurePageCtrl.page ?? _featurePage.toDouble();
                  scale = (1.0 - (page - i).abs() * 0.13).clamp(0.85, 1.0);
                } else {
                  scale = i == _featurePage ? 1.0 : 0.88;
                }
                return Transform.scale(scale:scale, child:child);
              },
              child:_FeatureCard(fc:fcs[i]),
            );
          },
        ),
      ),
      const SizedBox(height:10),
      // Dot indicator — ikut scroll smooth
      Row(mainAxisAlignment:MainAxisAlignment.center,
        children:List.generate(math.min(fcs.length,10), (i){
          final active = i==_featurePage%10;
          return AnimatedContainer(duration:const Duration(milliseconds:280),
            curve:Curves.easeOutCubic,
            margin:const EdgeInsets.symmetric(horizontal:3),
            width:active?20:6, height:6,
            decoration:BoxDecoration(
              borderRadius:BorderRadius.circular(4),
              gradient:active ? const LinearGradient(
                colors:[AppColors.cyan, AppColors.violetBright],
              ) : null,
              color:active ? null : AppColors.border,
              boxShadow:active ? [
                BoxShadow(color:AppColors.cyan.withOpacity(0.5), blurRadius:8),
              ] : [],
            ),
          );
        }),
      ),
    ]);
  }

  // ── CONTACT SECTION ───────────────────────────────────────────────────────
  Widget _buildContactSection() => Padding(
    padding:const EdgeInsets.symmetric(horizontal:14),
    child:Container(
      padding:const EdgeInsets.all(18),
      decoration:BoxDecoration(
        borderRadius:BorderRadius.circular(20),
        gradient:const LinearGradient(
          colors:[AppColors.card, AppColors.surfaceAlt],
          begin:Alignment.topLeft, end:Alignment.bottomRight),
        border:Border.all(color:AppColors.borderGlow),
      ),
      child:Column(children:[
        Row(children:[
          Container(width:42, height:42,
            decoration:BoxDecoration(shape:BoxShape.circle,
              gradient:const LinearGradient(colors:[AppColors.cyan, AppColors.cyanDim]),
              boxShadow:[BoxShadow(color:AppColors.cyan.withOpacity(.4), blurRadius:12)]),
            child:const Icon(Icons.headset_mic_rounded, color:AppColors.bg, size:20)),
          const SizedBox(width:12),
          const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
            Text('HUBUNGI KAMI', style:TextStyle(
              fontFamily:'Orbitron', fontSize:14, fontWeight:FontWeight.w800,
              color:AppColors.textPrimary, letterSpacing:1.5)),
            Text('Fast Response • 24/7 Support', style:TextStyle(
              fontFamily:'ShareTechMono', fontSize:10, color:AppColors.textSub)),
          ])),
          Container(
            padding:const EdgeInsets.symmetric(horizontal:10, vertical:5),
            decoration:BoxDecoration(
              borderRadius:BorderRadius.circular(20),
              color:AppColors.success.withOpacity(.1),
              border:Border.all(color:AppColors.success.withOpacity(.4))),
            child:Row(mainAxisSize:MainAxisSize.min, children:[
              Container(width:6, height:6,
                decoration:BoxDecoration(shape:BoxShape.circle, color:AppColors.success,
                  boxShadow:[BoxShadow(color:AppColors.success.withOpacity(.8), blurRadius:6)])),
              const SizedBox(width:6),
              const Text('ONLINE', style:TextStyle(
                fontFamily:'Orbitron', fontSize:8, color:AppColors.success,
                fontWeight:FontWeight.w800, letterSpacing:1)),
            ]),
          ),
        ]),
        const SizedBox(height:16),
        Container(height:1, decoration:BoxDecoration(gradient:LinearGradient(colors:[
          Colors.transparent, AppColors.cyan.withOpacity(.4),
          AppColors.violet.withOpacity(.4), Colors.transparent]))),
        const SizedBox(height:16),
        Row(children:[
          Expanded(child:_ContactBtn(
            icon:FontAwesomeIcons.whatsapp, label:'WHATSAPP',
            sub:'Chat sekarang', color:const Color(0xFF25D366), onTap:_openWhatsApp)),
          const SizedBox(width:12),
          Expanded(child:_ContactBtn(
            icon:FontAwesomeIcons.telegram, label:'TELEGRAM',
            sub:'Hubungi admin', color:const Color(0xFF2AABEE), onTap:_openTelegram)),
        ]),
      ]),
    ),
  );

  // ── BOTTOM NAV ────────────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0C0F1E), Color(0xFF080B16)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        border: const Border(top: BorderSide(color: AppColors.borderGlow, width: 1)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 24, offset: const Offset(0, -4)),
          BoxShadow(color: AppColors.cyan.withOpacity(0.04), blurRadius: 20, offset: const Offset(0, -2)),
        ],
      ),
      child: SafeArea(top: false,
        child: Stack(clipBehavior: Clip.none, alignment: Alignment.topCenter, children: [
          SizedBox(height: 68, child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
            _NavItem(0, Icons.home_rounded, 'Home', _navIndex, _onNavTap),
            _NavItem(1, Icons.newspaper_rounded, 'Berita', _navIndex, _onNavTap),
            _BugNavItem(2, _navIndex, _onNavTap, _pulse),
            _NavItem(3, Icons.build_rounded, 'Tools', _navIndex, _onNavTap),
            _RatNavItem(5, _navIndex, _onNavTap),
          ])),
        ]),
      ),
    );
  }

  // ── DRAWER ────────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    final isHO = role.toLowerCase()=='high owner';
    final isO  = role.toLowerCase()=='owner';
    final isHA = role.toLowerCase()=='high admin';
    final isA  = role.toLowerCase()=='admin';
    final isR  = role.toLowerCase()=='reseller';
    final rColor = _roleColor(role);

    return Drawer(
      backgroundColor:Colors.transparent,
      width:MediaQuery.of(context).size.width*0.80,
      child:Container(
        decoration:BoxDecoration(
          gradient:const LinearGradient(
            colors:[AppColors.surfaceAlt, AppColors.surface],
            begin:Alignment.topLeft, end:Alignment.bottomRight),
          border:Border(right:BorderSide(color:AppColors.borderGlow))),
        child:Column(children:[
          // Drawer header
          Container(
            padding:const EdgeInsets.fromLTRB(20,50,20,20),
            decoration:BoxDecoration(
              gradient:LinearGradient(colors:[
                AppColors.bgDeep, rColor.withOpacity(.08), AppColors.surface]),
              border:const Border(bottom:BorderSide(color:AppColors.border))),
            child:Row(children:[
              Container(width:56, height:56,
                decoration:BoxDecoration(shape:BoxShape.circle,
                  color:rColor.withOpacity(.15),
                  border:Border.all(color:rColor.withOpacity(.5), width:2),
                  boxShadow:[BoxShadow(color:rColor.withOpacity(.3), blurRadius:16)]),
                child:_profileImage!=null
                    ? ClipOval(child:Image.file(_profileImage!, fit:BoxFit.cover))
                    : Icon(_roleIcon(role), color:rColor, size:26)),
              const SizedBox(width:14),
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
                Text(username.toUpperCase(), style:const TextStyle(
                  fontFamily:'Orbitron', fontSize:15, fontWeight:FontWeight.w900,
                  color:AppColors.textPrimary, letterSpacing:.5),
                  overflow:TextOverflow.ellipsis),
                const SizedBox(height:4),
                Container(padding:const EdgeInsets.symmetric(horizontal:8, vertical:3),
                  decoration:BoxDecoration(
                    borderRadius:BorderRadius.circular(20),
                    color:rColor.withOpacity(.12),
                    border:Border.all(color:rColor.withOpacity(.4))),
                  child:Text(getRoleDisplayName(role), style:TextStyle(
                    fontFamily:'Orbitron', fontSize:9, color:rColor,
                    fontWeight:FontWeight.w800, letterSpacing:1))),
                const SizedBox(height:4),
                Text('EXP: $expiredDate', style:const TextStyle(
                  fontFamily:'ShareTechMono', fontSize:10, color:AppColors.textMuted)),
              ])),
            ]),
          ),
          // Drawer items
          Expanded(child:ListView(padding:const EdgeInsets.fromLTRB(16,16,16,0), children:[
            if (isHO||isO||isHA||isA||isR)
              _DItem(icon:Icons.storefront_rounded, label:'Seller Page',
                  color:AppColors.violetBright, onTap:()=>_onDrawerNav(1)),
            if (isHO||isO)
              _DItem(icon:Icons.workspace_premium_rounded, label:'Owner Page',
                  color:AppColors.gold, onTap:()=>_onDrawerNav(3)),
            if (isHO||isO||isHA||isA)
              _DItem(icon:Icons.admin_panel_settings_rounded, label:'Admin Page',
                  color:AppColors.cyan, onTap:()=>_onDrawerNav(2)),
            const Padding(padding:EdgeInsets.symmetric(vertical:8),
              child:Divider(color:AppColors.border)),
            _DItem(icon:Icons.history_rounded, label:'Riwayat Aktivitas',
                color:AppColors.textSub,
                onTap:(){
                  Navigator.pop(context);
                  Navigator.push(context, _slideRoute(RiwayatPage(sessionKey:sessionKey, role:role)));
                }),
          ])),
          // Logout
          Padding(padding:const EdgeInsets.fromLTRB(16,0,16,24),
            child:_DItem(icon:Icons.logout_rounded, label:'Keluar',
                color:AppColors.danger, isDestructive:true,
                onTap:()async{ Navigator.pop(context); await _doLogout(); })),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SHARED WIDGETS
// ═══════════════════════════════════════════════════════════════════════════

// ── Stat Card ─────────────────────────────────────────────────────────────
class _StatCard extends StatelessWidget {
  final IconData icon; final String value, label;
  final Color color; final bool glow;
  const _StatCard({required this.icon, required this.value, required this.label,
      required this.color, this.glow=false});
  @override
  Widget build(BuildContext context) => Container(
    padding:const EdgeInsets.symmetric(vertical:12, horizontal:6),
    decoration:BoxDecoration(
      borderRadius:BorderRadius.circular(14),
      gradient: LinearGradient(
        colors:[color.withOpacity(0.12), color.withOpacity(0.03)],
        begin:Alignment.topLeft, end:Alignment.bottomRight,
      ),
      border:Border.all(color:color.withOpacity(glow ? .5 : .22), width: glow ? 1.5 : 1),
      boxShadow:glow ? [
        BoxShadow(color:color.withOpacity(.22), blurRadius:18),
      ] : [],
    ),
    child:Column(mainAxisSize:MainAxisSize.min, children:[
      Container(
        width:32, height:32,
        decoration:BoxDecoration(
          shape:BoxShape.circle,
          color:color.withOpacity(0.13),
          border:Border.all(color:color.withOpacity(0.35), width:1.2),
        ),
        child:Icon(icon, size:16, color:color),
      ),
      const SizedBox(height:7),
      Text(
        value,
        style:TextStyle(
          fontFamily:'ShareTechMono', fontSize:18,
          fontWeight:FontWeight.w900, color:color, letterSpacing:1.5,
        ),
      ),
      const SizedBox(height:3),
      Text(label, style:TextStyle(
        fontFamily:'ShareTechMono', fontSize:7,
        color:color.withOpacity(0.65), letterSpacing:1,
      ), textAlign:TextAlign.center),
    ]),
  );
}

// ── Feature Card ──────────────────────────────────────────────────────────
class _FeatureCard extends StatefulWidget {
  final _FC fc;
  const _FeatureCard({required this.fc});
  @override State<_FeatureCard> createState() => _FeatureCardState();
}
class _FeatureCardState extends State<_FeatureCard> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final fc = widget.fc;
    return GestureDetector(
      onTapDown:(_)=>setState(()=>_pressed=true),
      onTapUp:(_){ setState(()=>_pressed=false); fc.onTap(); },
      onTapCancel:()=>setState(()=>_pressed=false),
      child:AnimatedScale(scale:_pressed ? 0.96 : 1.0, duration:const Duration(milliseconds:120),
        child:Container(
          margin:const EdgeInsets.symmetric(horizontal:10, vertical:8),
          decoration:BoxDecoration(
            borderRadius:BorderRadius.circular(22),
            gradient:LinearGradient(colors:fc.gradient,
              begin:Alignment.topLeft, end:Alignment.bottomRight),
            boxShadow:[BoxShadow(
              color:fc.gradient[0].withOpacity(.4),
              blurRadius:22, offset:const Offset(0,8))],
          ),
          child:Stack(children:[
            // Watermark icon
            Positioned(right:-14, bottom:-14,
              child:Opacity(opacity:.12, child:Icon(fc.icon, size:110, color:Colors.white))),
            // TAP badge
            Positioned(top:14, right:14, child:Container(
              padding:const EdgeInsets.symmetric(horizontal:10, vertical:4),
              decoration:BoxDecoration(
                borderRadius:BorderRadius.circular(20),
                color:Colors.white.withOpacity(.2),
                border:Border.all(color:Colors.white.withOpacity(.4))),
              child:const Text('TAP →', style:TextStyle(
                color:Colors.white, fontSize:9, fontWeight:FontWeight.w800, letterSpacing:.5)))),
            // Content
            Padding(padding:const EdgeInsets.fromLTRB(18,18,18,16),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
                Container(width:44, height:44,
                  decoration:BoxDecoration(shape:BoxShape.circle,
                    color:Colors.white.withOpacity(.2),
                    border:Border.all(color:Colors.white.withOpacity(.4), width:1.5)),
                  child:Icon(fc.icon, color:Colors.white, size:22)),
                const Spacer(),
                Text(fc.title, style:const TextStyle(
                  fontFamily:'Orbitron', color:Colors.white, fontSize:14,
                  fontWeight:FontWeight.w800, letterSpacing:.5)),
                const SizedBox(height:4),
                Text(fc.subtitle, style:TextStyle(
                  fontFamily:'ShareTechMono', color:Colors.white.withOpacity(.8), fontSize:11)),
              ])),
          ]),
        ),
      ),
    );
  }
}

// ── Contact Button ────────────────────────────────────────────────────────
class _ContactBtn extends StatefulWidget {
  final IconData icon; final String label, sub; final Color color; final VoidCallback onTap;
  const _ContactBtn({required this.icon, required this.label, required this.sub,
      required this.color, required this.onTap});
  @override State<_ContactBtn> createState() => _ContactBtnState();
}
class _ContactBtnState extends State<_ContactBtn> {
  bool _p=false;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown:(_)=>setState(()=>_p=true),
    onTapUp:(_){ setState(()=>_p=false); widget.onTap(); },
    onTapCancel:()=>setState(()=>_p=false),
    child:AnimatedScale(scale:_p ? 0.97 : 1.0, duration:const Duration(milliseconds:120),
      child:Container(
        padding:const EdgeInsets.symmetric(vertical:14, horizontal:10),
        decoration:BoxDecoration(
          borderRadius:BorderRadius.circular(16),
          gradient:LinearGradient(colors:[widget.color, widget.color.withOpacity(.7)],
            begin:Alignment.topLeft, end:Alignment.bottomRight),
          boxShadow:_p ? [] : [
            BoxShadow(color:widget.color.withOpacity(.45), blurRadius:16, offset:const Offset(0,5))],
          border:Border.all(color:Colors.white.withOpacity(.25))),
        child:Column(mainAxisSize:MainAxisSize.min, children:[
          Container(width:46, height:46,
            decoration:BoxDecoration(shape:BoxShape.circle,
              color:Colors.white, border:Border.all(color:widget.color, width:2),
              boxShadow:[BoxShadow(color:widget.color.withOpacity(.4), blurRadius:8)]),
            child:Icon(widget.icon, color:widget.color, size:24)),
          const SizedBox(height:8),
          Text(widget.label, style:const TextStyle(
            fontFamily:'Orbitron', color:Colors.white, fontSize:11,
            fontWeight:FontWeight.w800, letterSpacing:1.5)),
          const SizedBox(height:3),
          Text(widget.sub, style:TextStyle(
            fontFamily:'ShareTechMono', color:Colors.white.withOpacity(.8), fontSize:9)),
        ]),
      ),
    ),
  );
}

// ── Nav Item ──────────────────────────────────────────────────────────────
class _NavItem extends StatelessWidget {
  final int index, current; final IconData icon; final String label;
  final void Function(int) onTap;
  const _NavItem(this.index, this.icon, this.label, this.current, this.onTap);
  @override
  Widget build(BuildContext context) {
    final active = index == current;
    return Expanded(child: GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: active ? 32 : 0,
          height: 2,
          margin: const EdgeInsets.only(bottom: 5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(2),
            gradient: const LinearGradient(colors: [AppColors.cyan, AppColors.violetBright]),
            boxShadow: active ? [BoxShadow(color: AppColors.cyan.withOpacity(0.7), blurRadius: 6)] : [],
          ),
        ),
        AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 36, height: 36,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? AppColors.cyan.withOpacity(0.12) : Colors.transparent,
            border: active ? Border.all(color: AppColors.cyan.withOpacity(0.3), width: 1) : null,
          ),
          child: Icon(icon, size: 20, color: active ? AppColors.cyan : AppColors.textMuted),
        ),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(
          fontFamily: 'ShareTechMono', fontSize: 8, fontWeight: FontWeight.w700,
          color: active ? AppColors.cyan : AppColors.textMuted, letterSpacing: 0.5)),
      ]),
    ));
  }
}

// ── RAT Control Nav Item ──────────────────────────────────────────────────────
class _RatNavItem extends StatelessWidget {
  final int index, current;
  final void Function(int) onTap;
  const _RatNavItem(this.index, this.current, this.onTap);
  @override
  Widget build(BuildContext context) {
    final active = index == current;
    return Expanded(child: GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: active ? 32 : 0, height: 2,
          margin: const EdgeInsets.only(bottom: 5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(2),
            gradient: const LinearGradient(colors: [AppColors.cyan, AppColors.violetBright]),
            boxShadow: active ? [BoxShadow(color: AppColors.cyan.withOpacity(0.7), blurRadius: 6)] : [],
          ),
        ),
        AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 36, height: 36,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? AppColors.cyan.withOpacity(0.12) : Colors.transparent,
            border: active ? Border.all(color: AppColors.cyan.withOpacity(0.3), width: 1) : null,
          ),
          child: Icon(Icons.phone_android_rounded, size: 20, color: active ? AppColors.cyan : AppColors.textMuted),
        ),
        const SizedBox(height: 2),
        Text('RAT', style: TextStyle(
          fontFamily: 'ShareTechMono', fontSize: 8, fontWeight: FontWeight.w700,
          color: active ? AppColors.cyan : AppColors.textMuted, letterSpacing: 0.5)),
      ]),
    ));
  }
}

// ── BUG Nav Item — tampil inline sejajar, ukuran sedikit lebih besar ──────────
class _BugNavItem extends StatelessWidget {
  final int index, current;
  final void Function(int) onTap;
  final Animation<double> pulse;
  const _BugNavItem(this.index, this.current, this.onTap, this.pulse);
  @override
  Widget build(BuildContext context) {
    final active = index == current;
    return Expanded(child: GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        AnimatedBuilder(animation: pulse, builder: (_, __) => Container(
          width: 58, height: 58,
          margin: const EdgeInsets.only(bottom: 2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [Color(0xFF00B4CC), Color(0xFF00E5FF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: Colors.white.withOpacity(0.15), width: 2),
            boxShadow: [
              BoxShadow(
                color: AppColors.cyan.withOpacity(active ? 0.7 * pulse.value : 0.35),
                blurRadius: active ? 24 : 12,
                spreadRadius: active ? 3 : 1,
              ),
              BoxShadow(
                color: AppColors.cyan.withOpacity(0.15),
                blurRadius: 40,
              ),
            ],
          ),
          child: const Icon(Icons.bug_report_rounded, color: Color(0xFF080B16), size: 28),
        )),
        Text('BUG', style: TextStyle(
          fontFamily: 'Orbitron', fontSize: 7, fontWeight: FontWeight.w800,
          color: active ? AppColors.cyan : AppColors.textSub, letterSpacing: 1.5)),
      ]),
    ));
  }
}

// ── Drawer Item ───────────────────────────────────────────────────────────
class _DItem extends StatelessWidget {
  final IconData icon; final String label; final Color color;
  final VoidCallback onTap; final bool isDestructive;
  const _DItem({required this.icon, required this.label, required this.color,
      required this.onTap, this.isDestructive = false});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 7),
    child: Material(color: Colors.transparent,
      child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14),
        splashColor: color.withOpacity(0.12),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: LinearGradient(colors: [
              isDestructive
                  ? AppColors.danger.withOpacity(0.08)
                  : color.withOpacity(0.07),
              Colors.transparent,
            ]),
            border: Border.all(color: color.withOpacity(0.22), width: 1),
          ),
          child: Row(children: [
            Container(width: 38, height: 38,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(11),
                gradient: LinearGradient(colors: [
                  color.withOpacity(0.18), color.withOpacity(0.06),
                ]),
                border: Border.all(color: color.withOpacity(0.35), width: 1),
                boxShadow: [BoxShadow(color: color.withOpacity(0.2), blurRadius: 8)],
              ),
              child: Icon(icon, color: color, size: 18)),
            const SizedBox(width: 13),
            Text(label, style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 13, fontWeight: FontWeight.w700,
              color: isDestructive ? AppColors.danger : AppColors.textPrimary)),
            const Spacer(),
            Icon(Icons.chevron_right_rounded, color: color.withOpacity(0.45), size: 18),
          ]),
        ),
      ),
    ),
  );
}

// ── AppBar Icon Button ────────────────────────────────────────────────────
class _AppIconBtn extends StatelessWidget {
  final IconData icon; final VoidCallback onTap;
  const _AppIconBtn({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 38, height: 38,
      margin: const EdgeInsets.symmetric(vertical: 9, horizontal: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(colors: [
          AppColors.cyan.withOpacity(0.1), AppColors.cyan.withOpacity(0.04),
        ]),
        border: Border.all(color: AppColors.borderGlow, width: 1),
        boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.08), blurRadius: 10)],
      ),
      child: Icon(icon, color: AppColors.cyan, size: 18)),
  );
}

// ── NBtn ──────────────────────────────────────────────────────────────────
class _NBtn extends StatelessWidget {
  final String label; final Color color; final bool fullWidth; final VoidCallback onTap;
  const _NBtn({required this.label, required this.color, this.fullWidth = false, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: fullWidth ? double.infinity : null,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(colors: [color, color.withOpacity(0.7)]),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.45), blurRadius: 18, offset: const Offset(0, 6)),
          BoxShadow(color: color.withOpacity(0.15), blurRadius: 30, offset: const Offset(0, 3)),
        ],
        border: Border.all(color: Colors.white.withOpacity(0.12), width: 1),
      ),
      child: Text(label, textAlign: TextAlign.center, style: const TextStyle(
        fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.w800,
        color: Colors.white, letterSpacing: 1.5))),
  );
}

// ── Weather Icon ──────────────────────────────────────────────────────────
class _WeatherIcon extends StatelessWidget {
  final String code; final double size;
  const _WeatherIcon({required this.code, required this.size});
  @override
  Widget build(BuildContext context) {
    if (code.startsWith('01')) return Icon(Icons.wb_sunny_rounded, color:AppColors.gold, size:size*.6);
    if (code.startsWith('02')) return SizedBox(width:size, height:size*.65, child:Stack(clipBehavior:Clip.none, children:[
      Positioned(left:0,bottom:0,child:Icon(Icons.cloud_rounded,color:Colors.white70,size:size*.55)),
      Positioned(right:0,top:0,child:Icon(Icons.wb_sunny_rounded,color:AppColors.gold,size:size*.45)),
    ]));
    if (code.startsWith('03')||code.startsWith('04')) return Icon(Icons.cloud_rounded,color:Colors.white70,size:size*.55);
    if (code.startsWith('09')) return Icon(Icons.grain,color:AppColors.electric,size:size*.55);
    if (code.startsWith('10')) return Icon(Icons.umbrella_rounded,color:AppColors.electric,size:size*.55);
    if (code.startsWith('11')) return Icon(Icons.thunderstorm_rounded,color:AppColors.violetBright,size:size*.55);
    if (code.startsWith('13')) return Icon(Icons.ac_unit,color:Colors.lightBlue,size:size*.55);
    return Icon(Icons.cloud_queue,color:Colors.white54,size:size*.55);
  }
}

// ── Placeholder Banner ────────────────────────────────────────────────────
class _PlaceholderBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
    decoration:const BoxDecoration(gradient:AppColors.heroGrad),
    child:Column(mainAxisAlignment:MainAxisAlignment.center, children:[
      ShaderMask(
        shaderCallback:(b)=>const LinearGradient(colors:[AppColors.cyan,AppColors.violetBright]).createShader(b),
        child:const Text('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧', style:TextStyle(
          fontFamily:'Orbitron', fontSize:28, fontWeight:FontWeight.w900,
          color:Colors.white, letterSpacing:4))),
      const SizedBox(height:8),
      const Text('PROJECT V1.0', style:TextStyle(
        fontFamily:'ShareTechMono', fontSize:12, color:AppColors.textSub, letterSpacing:3)),
    ]),
  );
}

// ── News Media ────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override State<NewsMedia> createState() => _NewsMediaState();
}
class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _vCtrl;
  bool _isVideo=false, _videoReady=false;
  @override
  void initState() {
    super.initState();
    final u = widget.url.toLowerCase();
    _isVideo = u.endsWith('.mp4')||u.endsWith('.mov')||u.endsWith('.webm');
    if (_isVideo) {
      _vCtrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_){ if(mounted){ setState(()=>_videoReady=true); _vCtrl!.play(); _vCtrl!.setLooping(true); } });
    }
  }
  @override
  void dispose() { _vCtrl?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo) {
      return _videoReady && _vCtrl!=null
          ? FittedBox(fit:BoxFit.cover, child:SizedBox(
              width:_vCtrl!.value.size.width, height:_vCtrl!.value.size.height,
              child:VideoPlayer(_vCtrl!)))
          : const Center(child:CircularProgressIndicator(color:AppColors.cyan, strokeWidth:2));
    }
    return Image.network(widget.url, fit:BoxFit.cover,
      errorBuilder:(_,__,___)=>_PlaceholderBanner());
  }
}

// ── Dashboard Background Painter ──────────────────────────────────────────
class _DashBgPainter extends CustomPainter {
  final double t;
  _DashBgPainter(this.t);
  @override
  void paint(Canvas canvas, Size size) {
    final angle = t*2*math.pi;
    // Base
    canvas.drawRect(Rect.fromLTWH(0,0,size.width,size.height),
      Paint()..shader=const LinearGradient(
        colors:[AppColors.bgDeep, AppColors.bg, AppColors.surface],
        begin:Alignment.topCenter, end:Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0,0,size.width,size.height)));
    // Orbs
    final cx=size.width/2;
    canvas.drawCircle(
      Offset(cx+math.cos(angle)*60, size.height*.18+math.sin(angle)*20), 200,
      Paint()..shader=RadialGradient(colors:[AppColors.violet.withOpacity(.08),Colors.transparent])
          .createShader(Rect.fromCircle(center:Offset(cx,size.height*.18),radius:200)));
    canvas.drawCircle(
      Offset(cx-math.cos(angle)*40, size.height*.75+math.sin(angle)*15), 180,
      Paint()..shader=RadialGradient(colors:[AppColors.cyan.withOpacity(.05),Colors.transparent])
          .createShader(Rect.fromCircle(center:Offset(cx,size.height*.75),radius:180)));
    // Dot grid
    final dot=Paint()..color=AppColors.cyan.withOpacity(.025);
    const s=32.0;
    for (double x=0;x<size.width;x+=s) for (double y=0;y<size.height;y+=s) {
      canvas.drawCircle(Offset(x,y),1,dot);
    }
  }
  @override bool shouldRepaint(_DashBgPainter o)=>o.t!=t;
}
