import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart';

// ─── Palette (sama dengan tools_gateway) ─────────────────────────────────────
// _C removed - using AppColors

// ─── Data Pantun ─────────────────────────────────────────────────────────────
class PantunData {
  final String sampiran1;
  final String sampiran2;
  final String isi1;
  final String isi2;
  final String kategori;

  const PantunData({
    required this.sampiran1,
    required this.sampiran2,
    required this.isi1,
    required this.isi2,
    required this.kategori,
  });

  String get fullText =>
      '$sampiran1\n$sampiran2\n$isi1\n$isi2';
}

const List<PantunData> _pantunPercintaan = [
  PantunData(
    sampiran1: 'Bunga melati harum semerbak,',
    sampiran2: 'Ditanam di tepi kolam yang biru,',
    isi1:      'Hatiku selalu bergerak-gerak,',
    isi2:      'Setiap kali aku melihatmu.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Pergi ke pasar membeli mangga,',
    sampiran2: 'Mangga dipetik dari pohon tinggi,',
    isi1:      'Cinta ini datang tak tersangka,',
    isi2:      'Semenjak kau hadir di hati ini.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Sungai mengalir jernih airnya,',
    sampiran2: 'Ikan berenang di antara batu,',
    isi1:      'Kaulah cahaya di hidupku,',
    isi2:      'Takkan hilang meski waktu berlalu.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Burung merpati terbang ke utara,',
    sampiran2: 'Hinggap sebentar di dahan beringin,',
    isi1:      'Rindu ini sungguh tersiksa,',
    isi2:      'Mengharap hadirmu setiap malam.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Daun sirih merah warnanya,',
    sampiran2: 'Disimpan rapi di dalam bakul,',
    isi1:      'Bila cinta sudah terpaut mesra,',
    isi2:      'Tak ada lagi yang mampu memisahkan.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Padi menguning di sawah luas,',
    sampiran2: 'Petani memanen dengan suka cita,',
    isi1:      'Kaulah bintang paling terang,',
    isi2:      'Yang selalu menerangi jalan hidupku.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Nelayan pergi ke tengah laut,',
    sampiran2: 'Membawa jala penuh harapan,',
    isi1:      'Hatiku gelisah tanpa kamu,',
    isi2:      'Seperti kapal tanpa tujuan.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Kupu-kupu hinggap di mawar merah,',
    sampiran2: 'Menyesap madu sepanjang hari,',
    isi1:      'Sejak kau hadir, hidupku indah,',
    isi2:      'Kau manis bagai madu di hati.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Roti bakar dimakan pagi,',
    sampiran2: 'Disajikan hangat bersama selai,',
    isi1:      'Bila kamu ada di sisi,',
    isi2:      'Hari terasa selalu cerai berai indah.',
    kategori:  'percintaan',
  ),
  PantunData(
    sampiran1: 'Bintang bersinar di langit malam,',
    sampiran2: 'Rembulan tersenyum di antara awan,',
    isi1:      'Cintaku padamu begitu dalam,',
    isi2:      'Tak tergoyahkan oleh badai dan terpaan.',
    kategori:  'percintaan',
  ),
];

const List<PantunData> _pantunLucu = [
  PantunData(
    sampiran1: 'Pergi ke warung beli tempe,',
    sampiran2: 'Tempe digoreng jadi lauk makan,',
    isi1:      'Ngaku jago main bola,',
    isi2:      'Eh malah bola masuk gawang sendiri.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Makan siang pakai sambel,',
    sampiran2: 'Sambelnya pedas bikin nangis,',
    isi1:      'Ngaku diet tapi tetap gembel,',
    isi2:      'Tiap malam makan nasi goreng habis.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Kucing tidur di atas kasur,',
    sampiran2: 'Tidurnya nyenyak sampai siang hari,',
    isi1:      'Kalau ngantuk jangan dibiarkan,',
    isi2:      'Nanti tiba-tiba bangun jam tiga pagi.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Bebek berenang di kolam kecil,',
    sampiran2: 'Kolam airnya jernih dan dingin,',
    isi1:      'Punya pacar tapi diam-diam,',
    isi2:      'Eh ketahuan sama mamah sendiri.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Beli gorengan di pinggir jalan,',
    sampiran2: 'Gorengannya panas baru digoreng,',
    isi1:      'Niat makan satu biji saja,',
    isi2:      'Eh abis sebungkus gak kerasa.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Monyet loncat ke dahan tinggi,',
    sampiran2: 'Dahan patah monyet terjatuh,',
    isi1:      'Ngaku jago masak di dapur,',
    isi2:      'Eh mie instan pun gosong juga.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Ayam berkokok di pagi hari,',
    sampiran2: 'Kokok keras bangunkan tetangga,',
    isi1:      'Set alarm jam enam pagi,',
    isi2:      'Eh bangunnya malah jam dua belas siang.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Gajah mandi di sungai besar,',
    sampiran2: 'Main air sampai basah kuyup,',
    isi1:      'Ngaku sibuk isinya kosong,',
    isi2:      'Scrolling medsos dari pagi sampai subuh.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Tikus lari keluar dari got,',
    sampiran2: 'Larinya kencang tidak ketahuan,',
    isi1:      'Bilang mau belajar semalam suntuk,',
    isi2:      'Eh ketiduran buka buku satu halaman.',
    kategori:  'lucu',
  ),
  PantunData(
    sampiran1: 'Kodok bernyanyi malam hari,',
    sampiran2: 'Suaranya keras bikin ribut,',
    isi1:      'Niat gym supaya kurus,',
    isi2:      'Eh abis gym langsung makan bakso.',
    kategori:  'lucu',
  ),
];

const List<PantunData> _pantunKeberhasilan = [
  PantunData(
    sampiran1: 'Emas murni dalam tanah tersimpan,',
    sampiran2: 'Perlu digali dengan penuh usaha,',
    isi1:      'Keberhasilan takkan datang sembarang,',
    isi2:      'Hanya milik yang mau berjuang keras.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Pohon besar berawal dari benih,',
    sampiran2: 'Disiram setiap hari dengan sabar,',
    isi1:      'Impian besar butuh tekad yang gigih,',
    isi2:      'Pantang menyerah walau jalan tak gampang.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Elang terbang tinggi di angkasa,',
    sampiran2: 'Mengepak sayap melawan angin kencang,',
    isi1:      'Jadilah insan yang penuh semangat,',
    isi2:      'Raih sukses di setiap perjuangan.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Berlian terbentuk dari tekanan,',
    sampiran2: 'Semakin kuat makin bercahaya,',
    isi1:      'Cobaan hidup jangan jadi beban,',
    isi2:      'Jadikan pelajaran untuk lebih berdaya.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Matahari terbit setiap pagi,',
    sampiran2: 'Menerangi bumi tanpa henti,',
    isi1:      'Jadilah cahaya bagi sesama,',
    isi2:      'Suksesmu berkah untuk semua.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Pelaut handal lahir dari badai,',
    sampiran2: 'Bukan dari laut yang tenang saja,',
    isi1:      'Tantangan hidup bukan untuk dihindari,',
    isi2:      'Tapi dihadapi dengan kepala tegak.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Seribu langkah berawal dari satu,',
    sampiran2: 'Perjalanan jauh dimulai dari dekat,',
    isi1:      'Jangan tunda apa yang bisa kamu,',
    isi2:      'Mulailah kini sebelum terlambat.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Hujan deras membasahi bumi,',
    sampiran2: 'Setelah hujan langit biru cerah,',
    isi1:      'Setelah susah pasti ada bahagia,',
    isi2:      'Teruslah berjalan jangan menyerah.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Baja ditempa dengan panas membara,',
    sampiran2: 'Semakin kuat semakin tajam pula,',
    isi1:      'Proses sulit jangan diratapi,',
    isi2:      'Itulah cara terbaik kau ditempa.',
    kategori:  'keberhasilan',
  ),
  PantunData(
    sampiran1: 'Anak panah melesat jauh ke depan,',
    sampiran2: 'Hanya jika ditarik ke belakang dulu,',
    isi1:      'Mundur sejenak bukan berarti kalah,',
    isi2:      'Tapi persiapan untuk melesat jauh.',
    kategori:  'keberhasilan',
  ),
];

// ─── Page ─────────────────────────────────────────────────────────────────────
class PantunPage extends StatefulWidget {
  const PantunPage({super.key});

  @override
  State<PantunPage> createState() => _PantunPageState();
}

class _PantunPageState extends State<PantunPage>
    with SingleTickerProviderStateMixin {
  int _tabIndex = 0;
  late AnimationController _bgCtrl;

  final List<String> _tabLabels   = ['Percintaan', 'Lucu', 'Keberhasilan'];
  final List<Color>  _tabColors   = [const Color(0xFFEC4899), AppColors.warning, AppColors.success];
  final List<IconData> _tabIcons  = [
    Icons.favorite_rounded,
    Icons.sentiment_very_satisfied_rounded,
    Icons.emoji_events_rounded,
  ];

  List<PantunData> get _currentList {
    switch (_tabIndex) {
      case 0: return _pantunPercintaan;
      case 1: return _pantunLucu;
      case 2: return _pantunKeberhasilan;
      default: return _pantunPercintaan;
    }
  }

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 16))
      ..repeat();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    super.dispose();
  }

  void _copyPantun(PantunData p) {
    Clipboard.setData(ClipboardData(text: p.fullText));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Row(children: [
        Icon(Icons.copy_rounded, color: Colors.white, size: 16),
        SizedBox(width: 8),
        Text('Pantun disalin!',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
      ]),
      backgroundColor: AppColors.cyanDim,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      duration: const Duration(seconds: 2),
    ));
  }

  PantunData _getRandomPantun() {
    final r = Random();
    return _currentList[r.nextInt(_currentList.length)];
  }

  void _showRandom() {
    final p = _getRandomPantun();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _RandomSheet(pantun: p, color: _tabColors[_tabIndex],
          onCopy: () => _copyPantun(p)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accent = _tabColors[_tabIndex];

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: Column(
              children: [
                // Header
                _buildHeader(accent),
                // Tabs
                _buildTabs(),
                // List
                Expanded(child: _buildList(accent)),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showRandom,
        backgroundColor: accent,
        icon: const Icon(Icons.shuffle_rounded, color: Colors.white),
        label: const Text('Acak Pantun',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      ),
    );
  }

  Widget _buildHeader(Color accent) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.border),
          boxShadow: [
            BoxShadow(color: accent.withOpacity(0.08),
                blurRadius: 20, offset: const Offset(0, 6)),
          ],
        ),
        child: Row(children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppColors.border),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: AppColors.textPrimary, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [accent.withOpacity(0.8), accent],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [BoxShadow(color: accent.withOpacity(0.3), blurRadius: 10)],
            ),
            child: const Icon(Icons.auto_stories_rounded,
                color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ShaderMask(
              shaderCallback: (b) => AppColors.glowGrad.createShader(b),
              child: const Text('Pantun',
                  style: TextStyle(color: Colors.white, fontSize: 17,
                      fontWeight: FontWeight.w800)),
            ),
            const Text('Koleksi Pantun Nusantara',
                style: TextStyle(color: AppColors.textSub, fontSize: 11)),
          ]),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: accent.withOpacity(0.25)),
            ),
            child: Text('${_currentList.length} pantun',
                style: TextStyle(color: accent, fontSize: 10,
                    fontWeight: FontWeight.w700)),
          ),
        ]),
      ),
    );
  }

  Widget _buildTabs() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(children: List.generate(_tabLabels.length, (i) {
        final sel = _tabIndex == i;
        final c   = _tabColors[i];
        return Expanded(
          child: GestureDetector(
            onTap: () => setState(() => _tabIndex = i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              margin: EdgeInsets.only(right: i < 2 ? 8 : 0),
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: sel ? c.withOpacity(0.15) : AppColors.card,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: sel ? c.withOpacity(0.5) : AppColors.border,
                  width: sel ? 1.5 : 1.0,
                ),
              ),
              child: Column(children: [
                Icon(_tabIcons[i], color: sel ? c : AppColors.textSub, size: 18),
                const SizedBox(height: 4),
                Text(_tabLabels[i],
                    style: TextStyle(
                      color: sel ? c : AppColors.textSub,
                      fontSize: 10,
                      fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                    )),
              ]),
            ),
          ),
        );
      })),
    );
  }

  Widget _buildList(Color accent) {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      itemCount: _currentList.length,
      itemBuilder: (_, i) {
        final p = _currentList[i];
        return _PantunCard(
          pantun: p,
          index: i,
          accent: accent,
          onCopy: () => _copyPantun(p),
        );
      },
    );
  }
}

// ─── Pantun Card ──────────────────────────────────────────────────────────────
class _PantunCard extends StatefulWidget {
  final PantunData pantun;
  final int index;
  final Color accent;
  final VoidCallback onCopy;

  const _PantunCard({
    required this.pantun, required this.index,
    required this.accent, required this.onCopy,
  });

  @override
  State<_PantunCard> createState() => _PantunCardState();
}

class _PantunCardState extends State<_PantunCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + (widget.index * 60).clamp(0, 500)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 20 * (1 - v)), child: ch),
      ),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) => setState(() => _pressed = false),
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: _pressed
                ? widget.accent.withOpacity(0.08)
                : AppColors.card,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: _pressed
                  ? widget.accent.withOpacity(0.4)
                  : AppColors.border,
              width: _pressed ? 1.5 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.accent.withOpacity(_pressed ? 0.12 : 0.04),
                blurRadius: _pressed ? 16 : 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Number badge
            Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: widget.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(7),
                  border: Border.all(color: widget.accent.withOpacity(0.25)),
                ),
                child: Text('#${widget.index + 1}',
                    style: TextStyle(color: widget.accent, fontSize: 10,
                        fontWeight: FontWeight.w800)),
              ),
              const Spacer(),
              GestureDetector(
                onTap: widget.onCopy,
                child: Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Icon(Icons.copy_rounded,
                      color: AppColors.textSub, size: 15),
                ),
              ),
            ]),
            const SizedBox(height: 14),

            // Sampiran
            _pantunLine(widget.pantun.sampiran1, AppColors.textSub, false),
            const SizedBox(height: 4),
            _pantunLine(widget.pantun.sampiran2, AppColors.textSub, false),
            const SizedBox(height: 10),

            // Divider
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Colors.transparent,
                  widget.accent.withOpacity(0.3),
                  Colors.transparent,
                ]),
              ),
            ),
            const SizedBox(height: 10),

            // Isi
            _pantunLine(widget.pantun.isi1, AppColors.textPrimary, true),
            const SizedBox(height: 4),
            _pantunLine(widget.pantun.isi2, AppColors.textPrimary, true),
          ]),
        ),
      ),
    );
  }

  Widget _pantunLine(String text, Color color, bool bold) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('  ', style: TextStyle(color: color, fontSize: 14)),
      Expanded(
        child: Text(text,
            style: TextStyle(
              color: color,
              fontSize: bold ? 14 : 13,
              fontWeight: bold ? FontWeight.w600 : FontWeight.w400,
              height: 1.4,
              fontStyle: FontStyle.italic,
            )),
      ),
    ]);
  }
}

// ─── Random Sheet ─────────────────────────────────────────────────────────────
class _RandomSheet extends StatelessWidget {
  final PantunData pantun;
  final Color color;
  final VoidCallback onCopy;

  const _RandomSheet({required this.pantun, required this.color,
      required this.onCopy});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 32),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.1), blurRadius: 30),
        ],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 36, height: 4,
            decoration: BoxDecoration(color: AppColors.border,
                borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 20),
        Icon(Icons.auto_stories_rounded, color: color, size: 32),
        const SizedBox(height: 16),
        Text(pantun.sampiran1,
            style: const TextStyle(color: AppColors.textSub, fontSize: 15,
                fontStyle: FontStyle.italic, height: 1.5),
            textAlign: TextAlign.center),
        Text(pantun.sampiran2,
            style: const TextStyle(color: AppColors.textSub, fontSize: 15,
                fontStyle: FontStyle.italic, height: 1.5),
            textAlign: TextAlign.center),
        const SizedBox(height: 12),
        Container(height: 1, decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              Colors.transparent, color.withOpacity(0.4), Colors.transparent]))),
        const SizedBox(height: 12),
        Text(pantun.isi1,
            style: TextStyle(color: color, fontSize: 16,
                fontWeight: FontWeight.w700, fontStyle: FontStyle.italic, height: 1.5),
            textAlign: TextAlign.center),
        Text(pantun.isi2,
            style: TextStyle(color: color, fontSize: 16,
                fontWeight: FontWeight.w700, fontStyle: FontStyle.italic, height: 1.5),
            textAlign: TextAlign.center),
        const SizedBox(height: 20),
        GestureDetector(
          onTap: () { Navigator.pop(context); onCopy(); },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.copy_rounded, color: color, size: 16),
              const SizedBox(width: 8),
              Text('Salin Pantun',
                  style: TextStyle(color: color, fontWeight: FontWeight.w700,
                      fontSize: 14)),
            ]),
          ),
        ),
      ]),
    );
  }
}

// ─── Animated BG ─────────────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: controller,
        builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
      );
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = AppColors.border.withOpacity(0.26)
      ..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        AppColors.borderGlow.withOpacity(0.1 + sin(t * pi * 2) * 0.03),
        Colors.transparent,
      ], radius: 0.9).createShader(
          Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}
