import 'main.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();

  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;

  // TEMA BIRU PEKAT
  final Color bgDark = AppColors.bg;
  final Color primaryBlue = AppColors.border;
  final Color accentBlue = const Color(0xFF2D4ED8);
  final Color lightBlue = AppColors.cyanDim;
  final Color deepBlue = AppColors.surface;
  final Color putih = Colors.white;
  final Color putihAbu = Colors.white70;
  final Color cardGlass = AppColors.card.withOpacity(0.7);
  final Color borderGlass = AppColors.border.withOpacity(0.5);

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://nayahaikall.tyzx-host.my.id:2563/listUsers?key=${widget.keyToken}'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    if (filteredList.isEmpty) return [];
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "http://nayahaikall.tyzx-host.my.id:2563/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat!");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _fetchUsers();
      } else {
        String msg = data['message'] ?? 'Gagal membuat akun.';
        if (data['invalidDay'] == true) {
          msg += " (Max 30 hari)";
        }
        _alert("Gagal", msg);
      }
    } catch (e) {
      _alert("Error", "Koneksi error");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "http://nayahaikall.tyzx-host.my.id:2563/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (e) {
      _alert("Error", "Koneksi error");
    }
    setState(() => isLoading = false);
  }

  Future<void> _deleteUser(String username) async {
    // Konfirmasi sebelum menghapus
    bool? confirm = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: deepBlue,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: BorderSide(color: accentBlue.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.warning, color: Colors.red),
            SizedBox(width: 10),
            Text("Konfirmasi Hapus", style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text("Yakin ingin menghapus user $username?", style: TextStyle(color: putihAbu)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("Batal", style: TextStyle(color: putihAbu)),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Colors.red, Colors.red.shade800]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text("Hapus", style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "http://nayahaikall.tyzx-host.my.id:2563/deleteUser?key=${widget.keyToken}&username=$username"));
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User $username berhasil dihapus!");
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (e) {
      _alert("Error", "Koneksi error saat menghapus user.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: deepBlue,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: BorderSide(color: accentBlue.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: lightBlue),
            SizedBox(width: 10),
            Text(title, style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(message, style: TextStyle(color: putihAbu)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                borderRadius: BorderRadius.circular(22),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK", style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String hint = "",
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: putih),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: Colors.white38),
          labelStyle: TextStyle(color: lightBlue),
          prefixIcon: Icon(icon, color: accentBlue),
          filled: true,
          fillColor: cardGlass,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: accentBlue, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 25),
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [cardGlass, deepBlue.withOpacity(0.5)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderGlass, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: primaryBlue.withOpacity(0.3),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Icon(icon, color: putih),
              ),
              SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  color: putih,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardGlass, deepBlue.withOpacity(0.3)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: putih),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(color: putih, fontWeight: FontWeight.bold, fontSize: 16),
                ),
                SizedBox(height: 4),
                Text(
                  "ROLE: MEMBER | EXP: ${user['expiredDate']}",
                  style: TextStyle(color: putihAbu, fontSize: 13),
                ),
              ],
            ),
          ),
          // TOMBOL HAPUS USER (MERAH)
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Colors.red.shade700, Colors.red.shade900]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: IconButton(
              icon: Icon(FontAwesomeIcons.trash, color: putih, size: 18),
              onPressed: () => _deleteUser(user['username']),
              tooltip: 'Hapus User',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return ElevatedButton(
          onPressed: () => setState(() => currentPage = page),
          style: ElevatedButton.styleFrom(
            backgroundColor: currentPage == page ? accentBlue : Colors.transparent,
            foregroundColor: currentPage == page ? putih : putihAbu,
            padding: EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(22),
              side: BorderSide(color: borderGlass),
            ),
          ),
          child: Text("$page", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.5,
            colors: [deepBlue, bgDark, const Color(0xFF050814)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(color: accentBlue.withOpacity(0.5), blurRadius: 20, spreadRadius: 5),
                    ],
                  ),
                  child: Icon(Icons.storefront, color: putih, size: 50),
                ),
                SizedBox(height: 20),
                Text(
                  "RESELLER DASHBOARD",
                  style: TextStyle(
                    color: putih,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                    shadows: [Shadow(color: accentBlue.withOpacity(0.8), blurRadius: 15, offset: Offset(0, 2))],
                  ),
                ),
                Text("MANAGEMENT PANEL", style: TextStyle(color: lightBlue, fontSize: 14, letterSpacing: 2)),
                SizedBox(height: 10),
                Container(
                  width: 80,
                  height: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                    borderRadius: BorderRadius.circular(22),
                  ),
                ),
                SizedBox(height: 40),

                // CREATE MEMBER
                _buildGlassCard(
                  title: "CREATE MEMBER",
                  icon: FontAwesomeIcons.userPlus,
                  children: [
                    _buildInput(label: "Username Baru", controller: createUsernameController, icon: FontAwesomeIcons.user),
                    _buildInput(label: "Password", controller: createPasswordController, icon: FontAwesomeIcons.lock),
                    _buildInput(label: "Durasi (Hari)", controller: createDayController, icon: FontAwesomeIcons.calendarDay, type: TextInputType.number, hint: "Maksimal 30 hari"),
                    SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [BoxShadow(color: accentBlue.withOpacity(0.4), blurRadius: 10, offset: Offset(0, 4))],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _createAccount,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent),
                        child: isLoading ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: putih)) : Text("CREATE ACCOUNT", style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),

                // EXTEND DURATION
                _buildGlassCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(label: "Username Target", controller: editUsernameController, icon: FontAwesomeIcons.userEdit, hint: "Username member"),
                    _buildInput(label: "Tambah Hari", controller: editDayController, icon: FontAwesomeIcons.calendarPlus, type: TextInputType.number, hint: "Maksimal 30 hari"),
                    SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [lightBlue, primaryBlue]),
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [BoxShadow(color: accentBlue.withOpacity(0.4), blurRadius: 10, offset: Offset(0, 4))],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _editUser,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent),
                        child: isLoading ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: putih)) : Text("ADD DAYS", style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),

                // MEMBER LIST
                _buildGlassCard(
                  title: "MEMBER LIST",
                  icon: FontAwesomeIcons.users,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: deepBlue.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: borderGlass),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: deepBlue,
                          style: TextStyle(color: putih),
                          items: roleOptions.map((role) {
                            return DropdownMenuItem(value: role, child: Text(role.toUpperCase(), style: TextStyle(color: putih)));
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              selectedRole = val;
                              _filterAndPaginate();
                            }
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    isLoading
                        ? Center(child: CircularProgressIndicator(color: accentBlue))
                        : filteredList.isEmpty
                            ? Center(child: Padding(padding: EdgeInsets.all(40), child: Text("Tidak ada member", style: TextStyle(color: putihAbu))))
                            : Column(
                                children: [
                                  ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                                  SizedBox(height: 20),
                                  _buildPagination(),
                                ],
                              ),
                  ],
                ),
                SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}