import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';

// ═══════════════════════════════════════════════════════════════
//  NEBULA DARK PREMIUM — GLOBAL COLOR SYSTEM
// ═══════════════════════════════════════════════════════════════
class AppColors {
  // ── Core Background ──────────────────────────────────────────
  static const bg          = Color(0xFF060811);
  static const bgDeep      = Color(0xFF03040A);
  static const surface     = Color(0xFF0C0F1E);
  static const surfaceAlt  = Color(0xFF101527);
  static const card        = Color(0xFF131929);
  static const cardHover   = Color(0xFF182035);
  static const border      = Color(0xFF1C2540);
  static const borderGlow  = Color(0xFF2A3860);
  static const borderActive= Color(0xFF3D5A8A);

  // ── Neon Accent Palette ───────────────────────────────────────
  static const cyan        = Color(0xFF00E5FF);
  static const cyanDim     = Color(0xFF00B4CC);
  static const cyanDark    = Color(0xFF007A8A);
  static const violet      = Color(0xFF7C3AED);
  static const violetBright= Color(0xFF9D5CF6);
  static const violetGlow  = Color(0xFFBB86FC);
  static const electric    = Color(0xFF4FC3F7);
  static const azure       = Color(0xFF1E90FF);
  static const indigo      = Color(0xFF3F51B5);

  // ── Status Colors ─────────────────────────────────────────────
  static const success     = Color(0xFF00E676);
  static const successDim  = Color(0xFF00C853);
  static const warning     = Color(0xFFFFAB00);
  static const danger      = Color(0xFFFF1744);
  static const dangerDim   = Color(0xFFD50000);
  static const gold        = Color(0xFFFFD700);
  static const goldDim     = Color(0xFFFFC107);

  // ── Text Scale ────────────────────────────────────────────────
  static const textPrimary = Color(0xFFE8F0FE);
  static const textSub     = Color(0xFF8899CC);
  static const textMuted   = Color(0xFF3D4F7A);
  static const textDim     = Color(0xFF1E2A48);

  // ── Gradients ─────────────────────────────────────────────────
  static const LinearGradient heroGrad = LinearGradient(
    colors: [Color(0xFF0C0F1E), Color(0xFF0D1530), Color(0xFF111A3E)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
  static const LinearGradient cyanGrad = LinearGradient(
    colors: [Color(0xFF00E5FF), Color(0xFF00B4CC), Color(0xFF007A8A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient violetGrad = LinearGradient(
    colors: [Color(0xFF7C3AED), Color(0xFF9D5CF6), Color(0xFFBB86FC)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient glowGrad = LinearGradient(
    colors: [Color(0xFF00E5FF), Color(0xFF7C3AED)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
  static const LinearGradient cardGrad = LinearGradient(
    colors: [Color(0xFF131929), Color(0xFF0F1424)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ═══════════════════════════════════════════════════════════════
//  PREMIUM THEME
// ═══════════════════════════════════════════════════════════════
class AppTheme {
  static const _fontMono    = 'ShareTechMono';
  static const _fontDisplay = 'Orbitron';

  static ThemeData build() => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    fontFamily: _fontMono,
    scaffoldBackgroundColor: AppColors.bg,

    colorScheme: const ColorScheme.dark(
      brightness:              Brightness.dark,
      primary:                 AppColors.cyan,
      onPrimary:               AppColors.bg,
      primaryContainer:        AppColors.cyanDark,
      onPrimaryContainer:      AppColors.textPrimary,
      secondary:               AppColors.violet,
      onSecondary:             AppColors.textPrimary,
      secondaryContainer:      AppColors.indigo,
      onSecondaryContainer:    AppColors.textPrimary,
      tertiary:                AppColors.success,
      onTertiary:              AppColors.bg,
      error:                   AppColors.danger,
      onError:                 AppColors.textPrimary,
      surface:                 AppColors.surface,
      onSurface:               AppColors.textPrimary,
      surfaceContainerHighest: AppColors.card,
      outline:                 AppColors.border,
      outlineVariant:          AppColors.borderGlow,
      shadow:                  Colors.black,
      scrim:                   Color(0xE6060811),
      inverseSurface:          AppColors.textPrimary,
      onInverseSurface:        AppColors.bg,
      inversePrimary:          AppColors.cyanDark,
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor:        AppColors.surface,
      foregroundColor:        AppColors.textPrimary,
      elevation:              0,
      scrolledUnderElevation: 0,
      centerTitle:            false,
      titleTextStyle: TextStyle(
        fontFamily:    _fontDisplay,
        fontSize:      16,
        fontWeight:    FontWeight.w700,
        color:         AppColors.textPrimary,
        letterSpacing: 1.2,
      ),
      iconTheme:        IconThemeData(color: AppColors.cyan,     size: 22),
      actionsIconTheme: IconThemeData(color: AppColors.textSub,  size: 20),
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor:                    Colors.transparent,
        statusBarIconBrightness:           Brightness.light,
        statusBarBrightness:               Brightness.dark,
        systemNavigationBarColor:          AppColors.bg,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
    ),

    cardTheme: CardThemeData(
      color:        AppColors.card,
      elevation:    0,
      margin:       EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: AppColors.border, width: 1),
      ),
      clipBehavior: Clip.antiAlias,
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return AppColors.border;
          if (s.contains(WidgetState.pressed))  return AppColors.cyanDim;
          return AppColors.cyan;
        }),
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return AppColors.textMuted;
          return AppColors.bg;
        }),
        overlayColor:  WidgetStateProperty.all(AppColors.textPrimary.withOpacity(0.1)),
        elevation:     WidgetStateProperty.all(0),
        shadowColor:   WidgetStateProperty.all(Colors.transparent),
        padding:       WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _fontDisplay, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 1.2),
        ),
        animationDuration: const Duration(milliseconds: 150),
      ),
    ),

    outlinedButtonTheme: OutlinedButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return AppColors.textPrimary;
          return AppColors.cyan;
        }),
        side: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return const BorderSide(color: AppColors.cyan, width: 1.5);
          if (s.contains(WidgetState.focused)) return const BorderSide(color: AppColors.cyanDim, width: 1.5);
          return const BorderSide(color: AppColors.borderGlow, width: 1);
        }),
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return AppColors.cyan.withOpacity(0.08);
          return Colors.transparent;
        }),
        overlayColor: WidgetStateProperty.all(AppColors.cyan.withOpacity(0.06)),
        padding: WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _fontDisplay, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 1.0),
        ),
      ),
    ),

    textButtonTheme: TextButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return AppColors.textPrimary;
          return AppColors.cyanDim;
        }),
        overlayColor: WidgetStateProperty.all(AppColors.cyan.withOpacity(0.08)),
        padding: WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _fontMono, fontSize: 13, fontWeight: FontWeight.w500, letterSpacing: 0.4),
        ),
      ),
    ),

    inputDecorationTheme: InputDecorationTheme(
      filled:      true,
      fillColor:   AppColors.surface,
      hoverColor:  AppColors.card,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.border, width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.border, width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.cyan, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.danger, width: 1),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.danger, width: 1.5),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.textDim, width: 1),
      ),
      labelStyle:         const TextStyle(color: AppColors.textSub,  fontSize: 13),
      hintStyle:          const TextStyle(color: AppColors.textMuted, fontSize: 13),
      errorStyle:         const TextStyle(color: AppColors.danger,    fontSize: 11),
      prefixIconColor:    AppColors.textSub,
      suffixIconColor:    AppColors.textSub,
      floatingLabelStyle: const TextStyle(color: AppColors.cyan, fontSize: 12),
    ),

    chipTheme: ChipThemeData(
      backgroundColor:     AppColors.surface,
      selectedColor:       AppColors.cyanDark,
      disabledColor:       AppColors.border,
      deleteIconColor:     AppColors.textSub,
      labelStyle:          const TextStyle(color: AppColors.textPrimary, fontSize: 12, fontFamily: _fontMono),
      secondaryLabelStyle: const TextStyle(color: AppColors.cyan,        fontSize: 12, fontFamily: _fontMono),
      padding:             const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: const BorderSide(color: AppColors.borderGlow),
      ),
      side:           const BorderSide(color: AppColors.borderGlow),
      elevation:      0,
      pressElevation: 0,
      showCheckmark:  false,
    ),

    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor:      AppColors.surface,
      selectedItemColor:    AppColors.cyan,
      unselectedItemColor:  AppColors.textMuted,
      elevation:            0,
      type:                 BottomNavigationBarType.fixed,
      selectedLabelStyle:   TextStyle(fontSize: 10, fontFamily: _fontMono, fontWeight: FontWeight.w600),
      unselectedLabelStyle: TextStyle(fontSize: 10, fontFamily: _fontMono),
    ),

    navigationBarTheme: NavigationBarThemeData(
      backgroundColor:  AppColors.surface,
      indicatorColor:   AppColors.cyanDark.withOpacity(0.35),
      iconTheme: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return const IconThemeData(color: AppColors.cyan, size: 22);
        return const IconThemeData(color: AppColors.textMuted, size: 22);
      }),
      labelTextStyle: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) {
          return const TextStyle(color: AppColors.cyan, fontSize: 11, fontFamily: _fontMono, fontWeight: FontWeight.w600);
        }
        return const TextStyle(color: AppColors.textMuted, fontSize: 11, fontFamily: _fontMono);
      }),
      elevation:     0,
      overlayColor:  WidgetStateProperty.all(AppColors.cyan.withOpacity(0.06)),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
    ),

    drawerTheme: DrawerThemeData(
      backgroundColor:  AppColors.surfaceAlt,
      elevation:        0,
      surfaceTintColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight:    Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
    ),

    dialogTheme: DialogThemeData(
      backgroundColor: AppColors.card,
      elevation:       0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: AppColors.borderGlow, width: 1),
      ),
      titleTextStyle: const TextStyle(
        fontFamily:    _fontDisplay,
        fontSize:      16,
        fontWeight:    FontWeight.w700,
        color:         AppColors.textPrimary,
        letterSpacing: 0.8,
      ),
      contentTextStyle: const TextStyle(
        fontFamily: _fontMono,
        fontSize:   14,
        color:      AppColors.textSub,
        height:     1.6,
      ),
    ),

    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor:     AppColors.surfaceAlt,
      modalBackgroundColor: AppColors.surfaceAlt,
      elevation:           0,
      modalElevation:      0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      showDragHandle:  true,
      dragHandleColor: AppColors.borderGlow,
      dragHandleSize:  Size(40, 4),
      clipBehavior:    Clip.antiAlias,
    ),

    snackBarTheme: SnackBarThemeData(
      backgroundColor:  AppColors.card,
      contentTextStyle: const TextStyle(color: AppColors.textPrimary, fontFamily: _fontMono, fontSize: 13),
      actionTextColor:  AppColors.cyan,
      behavior:         SnackBarBehavior.floating,
      elevation:        0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: AppColors.borderGlow, width: 1),
      ),
    ),

    tabBarTheme: TabBarThemeData(
      labelColor:           AppColors.cyan,
      unselectedLabelColor: AppColors.textMuted,
      indicatorColor:       AppColors.cyan,
      indicatorSize:        TabBarIndicatorSize.label,
      labelStyle:           const TextStyle(fontFamily: _fontDisplay, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.8),
      unselectedLabelStyle: const TextStyle(fontFamily: _fontMono,    fontSize: 12),
      overlayColor:         WidgetStateProperty.all(AppColors.cyan.withOpacity(0.06)),
      dividerColor:         AppColors.border,
    ),

    listTileTheme: const ListTileThemeData(
      tileColor:         Colors.transparent,
      selectedTileColor: Color(0x1500E5FF),
      iconColor:         AppColors.textSub,
      selectedColor:     AppColors.cyan,
      textColor:         AppColors.textPrimary,
      subtitleTextStyle: TextStyle(color: AppColors.textSub, fontSize: 12),
      contentPadding:    EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
    ),

    dividerTheme: const DividerThemeData(
      color:     AppColors.border,
      thickness: 1,
      space:     1,
    ),

    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return AppColors.cyan;
        return AppColors.textMuted;
      }),
      trackColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return AppColors.cyanDark.withOpacity(0.6);
        return AppColors.border;
      }),
      trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      overlayColor:      WidgetStateProperty.all(AppColors.cyan.withOpacity(0.08)),
    ),

    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return AppColors.cyan;
        return Colors.transparent;
      }),
      checkColor:   WidgetStateProperty.all(AppColors.bg),
      side:         const BorderSide(color: AppColors.borderGlow, width: 1.5),
      shape:        RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      overlayColor: WidgetStateProperty.all(AppColors.cyan.withOpacity(0.08)),
    ),

    radioTheme: RadioThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return AppColors.cyan;
        return AppColors.textMuted;
      }),
      overlayColor: WidgetStateProperty.all(AppColors.cyan.withOpacity(0.08)),
    ),

    sliderTheme: SliderThemeData(
      activeTrackColor:    AppColors.cyan,
      inactiveTrackColor:  AppColors.border,
      thumbColor:          AppColors.cyan,
      overlayColor:        AppColors.cyan.withOpacity(0.12),
      valueIndicatorColor: AppColors.cyanDark,
      valueIndicatorTextStyle: const TextStyle(color: AppColors.bg, fontSize: 12, fontFamily: _fontMono),
      trackHeight:         3,
      thumbShape:          const RoundSliderThumbShape(enabledThumbRadius: 7),
    ),

    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color:              AppColors.cyan,
      linearTrackColor:   AppColors.border,
      circularTrackColor: AppColors.border,
      linearMinHeight:    3,
    ),

    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor:    AppColors.cyan,
      foregroundColor:    AppColors.bg,
      elevation:          0,
      focusElevation:     0,
      hoverElevation:     0,
      highlightElevation: 0,
      splashColor:        AppColors.textPrimary.withOpacity(0.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),

    iconTheme:        const IconThemeData(color: AppColors.cyanDim, size: 22),
    primaryIconTheme: const IconThemeData(color: AppColors.cyan,    size: 22),

    popupMenuTheme: PopupMenuThemeData(
      color:            AppColors.card,
      elevation:        0,
      shadowColor:      Colors.transparent,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: AppColors.borderGlow, width: 1),
      ),
      textStyle: const TextStyle(color: AppColors.textPrimary, fontFamily: _fontMono, fontSize: 13),
      labelTextStyle: WidgetStateProperty.all(
        const TextStyle(color: AppColors.textPrimary, fontFamily: _fontMono, fontSize: 13),
      ),
      iconColor: AppColors.textSub,
    ),

    tooltipTheme: TooltipThemeData(
      decoration: BoxDecoration(
        color:        AppColors.surface,
        borderRadius: BorderRadius.circular(8),
        border:       Border.all(color: AppColors.borderGlow),
      ),
      textStyle: const TextStyle(color: AppColors.textPrimary, fontSize: 11, fontFamily: _fontMono),
      padding:   const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    ),

    scrollbarTheme: ScrollbarThemeData(
      thumbColor:      WidgetStateProperty.all(AppColors.borderGlow),
      trackColor:      WidgetStateProperty.all(AppColors.surface),
      radius:          const Radius.circular(4),
      thickness:       WidgetStateProperty.all(3),
      crossAxisMargin: 2,
    ),

    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: _NebulaTransitionBuilder(),
        TargetPlatform.iOS:     _NebulaTransitionBuilder(),
        TargetPlatform.windows: _NebulaTransitionBuilder(),
        TargetPlatform.macOS:   _NebulaTransitionBuilder(),
        TargetPlatform.linux:   _NebulaTransitionBuilder(),
      },
    ),

    textTheme: const TextTheme(
      displayLarge:   TextStyle(fontFamily: _fontDisplay, fontSize: 48, fontWeight: FontWeight.w900, color: AppColors.textPrimary, letterSpacing: 2.0),
      displayMedium:  TextStyle(fontFamily: _fontDisplay, fontSize: 36, fontWeight: FontWeight.w800, color: AppColors.textPrimary, letterSpacing: 1.5),
      displaySmall:   TextStyle(fontFamily: _fontDisplay, fontSize: 28, fontWeight: FontWeight.w700, color: AppColors.textPrimary, letterSpacing: 1.2),
      headlineLarge:  TextStyle(fontFamily: _fontDisplay, fontSize: 24, fontWeight: FontWeight.w700, color: AppColors.textPrimary, letterSpacing: 1.0),
      headlineMedium: TextStyle(fontFamily: _fontDisplay, fontSize: 20, fontWeight: FontWeight.w600, color: AppColors.textPrimary, letterSpacing: 0.8),
      headlineSmall:  TextStyle(fontFamily: _fontDisplay, fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary, letterSpacing: 0.6),
      titleLarge:     TextStyle(fontFamily: _fontMono, fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.textPrimary, letterSpacing: 0.3),
      titleMedium:    TextStyle(fontFamily: _fontMono, fontSize: 15, fontWeight: FontWeight.w500, color: AppColors.textPrimary, letterSpacing: 0.2),
      titleSmall:     TextStyle(fontFamily: _fontMono, fontSize: 13, fontWeight: FontWeight.w500, color: AppColors.textSub),
      bodyLarge:      TextStyle(fontFamily: _fontMono, fontSize: 15, fontWeight: FontWeight.w400, color: AppColors.textPrimary, height: 1.6),
      bodyMedium:     TextStyle(fontFamily: _fontMono, fontSize: 13, fontWeight: FontWeight.w400, color: AppColors.textPrimary, height: 1.6),
      bodySmall:      TextStyle(fontFamily: _fontMono, fontSize: 11, fontWeight: FontWeight.w400, color: AppColors.textSub,     height: 1.5),
      labelLarge:     TextStyle(fontFamily: _fontMono, fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary, letterSpacing: 0.5),
      labelMedium:    TextStyle(fontFamily: _fontMono, fontSize: 11, fontWeight: FontWeight.w500, color: AppColors.textSub,     letterSpacing: 0.4),
      labelSmall:     TextStyle(fontFamily: _fontMono, fontSize: 10, fontWeight: FontWeight.w500, color: AppColors.textMuted,   letterSpacing: 0.6),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════
//  NEBULA PAGE TRANSITION — Fade + Scale
// ═══════════════════════════════════════════════════════════════
class _NebulaTransitionBuilder extends PageTransitionsBuilder {
  const _NebulaTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final inCurve  = CurvedAnimation(parent: animation,          curve: Curves.easeOutExpo);
    final outCurve = CurvedAnimation(parent: secondaryAnimation,  curve: Curves.easeInCubic);

    return FadeTransition(
      opacity: inCurve,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.025), end: Offset.zero).animate(inCurve),
        child: FadeTransition(
          opacity: Tween<double>(begin: 1.0, end: 0.80).animate(outCurve),
          child: ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 0.96).animate(outCurve),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  PREMIUM SHARED WIDGETS
// ═══════════════════════════════════════════════════════════════

/// Tombol Utama Premium — Neon Cyan Gradient dengan glow effect
class NeonButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool isLoading;
  final double? width;
  final Color? color;

  const NeonButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.isLoading = false,
    this.width,
    this.color,
  });

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween<double>(begin: 1.0, end: 0.96).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final baseColor = widget.color ?? AppColors.cyan;
    return GestureDetector(
      onTapDown: (_) { setState(() => _pressed = true); _ctrl.forward(); },
      onTapUp: (_)   { setState(() => _pressed = false); _ctrl.reverse(); widget.onTap?.call(); },
      onTapCancel: () { setState(() => _pressed = false); _ctrl.reverse(); },
      child: ScaleTransition(
        scale: _scale,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width:  widget.width,
          height: 50,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: _pressed
                  ? [baseColor.withOpacity(0.7), baseColor.withOpacity(0.5)]
                  : [baseColor, baseColor.withOpacity(0.75)],
            ),
            borderRadius: BorderRadius.circular(12),
            boxShadow: _pressed ? [] : [
              BoxShadow(
                color:       baseColor.withOpacity(0.35),
                blurRadius:  16,
                offset:      const Offset(0, 4),
                spreadRadius: 0,
              ),
            ],
          ),
          child: widget.isLoading
              ? Center(child: SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(AppColors.bg),
                  ),
                ))
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (widget.icon != null) ...[
                      Icon(widget.icon, size: 16, color: AppColors.bg),
                      const SizedBox(width: 8),
                    ],
                    Text(
                      widget.label,
                      style: const TextStyle(
                        fontFamily:    'Orbitron',
                        fontSize:      12,
                        fontWeight:    FontWeight.w700,
                        color:         AppColors.bg,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

/// Tombol Outline Premium — Ghost button
class GhostButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final Color? color;
  final double? width;

  const GhostButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.color,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.cyan;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width:  width,
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: c.withOpacity(0.5), width: 1.5),
          color: c.withOpacity(0.05),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 16, color: c),
              const SizedBox(width: 8),
            ],
            Text(
              label,
              style: TextStyle(
                fontFamily:    'Orbitron',
                fontSize:      11,
                fontWeight:    FontWeight.w600,
                color:         c,
                letterSpacing: 1.0,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Premium Card dengan glow border
class PremiumCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Color? glowColor;
  final bool showGlow;
  final double radius;

  const PremiumCard({
    super.key,
    required this.child,
    this.padding,
    this.glowColor,
    this.showGlow = false,
    this.radius = 16,
  });

  @override
  Widget build(BuildContext context) {
    final gc = glowColor ?? AppColors.cyan;
    return Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: const LinearGradient(
          colors: [AppColors.card, AppColors.surface],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(
          color: showGlow ? gc.withOpacity(0.4) : AppColors.border,
          width: showGlow ? 1.5 : 1.0,
        ),
        boxShadow: showGlow ? [
          BoxShadow(
            color:       gc.withOpacity(0.12),
            blurRadius:  20,
            spreadRadius: 0,
          ),
        ] : [],
      ),
      child: child,
    );
  }
}

/// Background Nebula — star field + gradient mesh
class NebulaBackground extends StatelessWidget {
  final Widget child;
  const NebulaBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Base gradient
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.bgDeep, AppColors.bg, AppColors.surface],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        // Nebula orb top-right
        Positioned(
          top: -80, right: -60,
          child: Container(
            width: 300, height: 300,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  AppColors.violet.withOpacity(0.12),
                  AppColors.cyan.withOpacity(0.04),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        // Nebula orb bottom-left
        Positioned(
          bottom: -60, left: -40,
          child: Container(
            width: 260, height: 260,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  AppColors.cyan.withOpacity(0.08),
                  AppColors.azure.withOpacity(0.04),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        // Dot grid overlay
        Opacity(
          opacity: 0.03,
          child: CustomPaint(
            painter: _DotGridPainter(),
            child: const SizedBox.expand(),
          ),
        ),
        child,
      ],
    );
  }
}

class _DotGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = AppColors.cyan..strokeWidth = 1;
    const spacing = 28.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 1, paint);
      }
    }
  }
  @override
  bool shouldRepaint(_) => false;
}

// ═══════════════════════════════════════════════════════════════
//  ROUTE BUILDER
// ═══════════════════════════════════════════════════════════════
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  Widget page;
  switch (settings.name) {
    case '/':
      page = LandingPage();
    case '/login':
      page = const LoginPage();
    case '/dashboard':
      page = DashboardPage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        sessionKey:  args['key']         as String,
        expiredDate: args['expiredDate'] as String,
        listBug:  List<Map<String, dynamic>>.from(args['listBug']  ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news:     List<Map<String, dynamic>>.from(args['news']     ?? []),
      );
    case '/home':
      page = HomePage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        expiredDate: args['expiredDate'] as String,
        sessionKey:  args['sessionKey']  as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
      );
    case '/seller':
      page = SellerPage(keyToken: args!['keyToken'] as String);
    case '/admin':
      page = AdminPage(sessionKey: args!['sessionKey'] as String);
    case '/owner':
      page = OwnerPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );
    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration:        const Duration(milliseconds: 340),
    reverseTransitionDuration: const Duration(milliseconds: 280),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final inCurve  = CurvedAnimation(parent: animation,         curve: Curves.easeOutExpo);
      final outCurve = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInCubic);
      return FadeTransition(
        opacity: inCurve,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.025), end: Offset.zero).animate(inCurve),
          child: FadeTransition(
            opacity: Tween<double>(begin: 1.0, end: 0.80).animate(outCurve),
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 0.96).animate(outCurve),
              child: child,
            ),
          ),
        ),
      );
    },
  );
}

// ═══════════════════════════════════════════════════════════════
//  404 PAGE — PREMIUM NEBULA STYLE
// ═══════════════════════════════════════════════════════════════
class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  State<_NotFoundPage> createState() => _NotFoundPageState();
}

class _NotFoundPageState extends State<_NotFoundPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>   _fade;
  late final Animation<Offset>   _slide;
  late final Animation<double>   _glow;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _glow  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1, curve: Curves.easeOut)));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: NebulaBackground(
        child: Center(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slide,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: _glow,
                      builder: (_, child) => Container(
                        width: 96, height: 96,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color:  AppColors.surface,
                          border: Border.all(color: AppColors.borderGlow, width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color:       AppColors.cyan.withOpacity(0.20 * _glow.value),
                              blurRadius:  48,
                              spreadRadius: 8,
                            ),
                          ],
                        ),
                        child: child,
                      ),
                      child: const Icon(Icons.explore_off_rounded, color: AppColors.textSub, size: 36),
                    ),
                    const SizedBox(height: 32),
                    ShaderMask(
                      shaderCallback: (b) => const LinearGradient(
                        colors: [AppColors.cyan, AppColors.violetBright],
                      ).createShader(b),
                      child: const Text(
                        '404',
                        style: TextStyle(
                          fontFamily:    'Orbitron',
                          fontSize:      80,
                          fontWeight:    FontWeight.w900,
                          color:         Colors.white,
                          letterSpacing: 4,
                          height:        1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'PAGE NOT FOUND',
                      style: TextStyle(
                        fontFamily:    'Orbitron',
                        fontSize:      13,
                        fontWeight:    FontWeight.w600,
                        color:         AppColors.textSub,
                        letterSpacing: 3,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color:        AppColors.surface,
                        borderRadius: BorderRadius.circular(8),
                        border:       Border.all(color: AppColors.border),
                      ),
                      child: Text(
                        '"${widget.routeName}"',
                        style: const TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize:   12,
                          color:      AppColors.textMuted,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),
                    NeonButton(
                      label: 'BACK TO HOME',
                      icon:  Icons.arrow_back_rounded,
                      onTap: () => Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false),
                      width: 200,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  ENTRY POINT
// ═══════════════════════════════════════════════════════════════
void main() {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:                    Colors.transparent,
    statusBarIconBrightness:           Brightness.light,
    statusBarBrightness:               Brightness.dark,
    systemNavigationBarColor:          AppColors.bg,
    systemNavigationBarDividerColor:   Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const _LightStarApp());
}

// ═══════════════════════════════════════════════════════════════
//  ROOT APP
// ═══════════════════════════════════════════════════════════════
class _LightStarApp extends StatelessWidget {
  const _LightStarApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title:           '𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧',
      theme:           AppTheme.build(),
      initialRoute:    '/',
      onGenerateRoute: _generateRoute,
      navigatorObservers: [dashboardRouteObserver],
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear(
              mq.textScaler.scale(1.0).clamp(0.85, 1.2),
            ),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}
