import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart';

// ─── Palette ──────────────────────────────────────────────────────────────────
// _C removed - using AppColors

// ─── Data Model ──────────────────────────────────────────────────────────────
class PuisiData {
  final String judul;
  final String isi;
  final String penulis;
  final String kategori;

  const PuisiData({
    required this.judul,
    required this.isi,
    required this.penulis,
    required this.kategori,
  });
}

// ─── Puisi Percintaan ────────────────────────────────────────────────────────
const List<PuisiData> _puisiPercintaan = [
  PuisiData(
    judul:    'Surat Tanpa Perangko',
    isi:      'Kutulis namamu di tepi langit,\n'
              'dengan tinta embun pagi yang sejuk.\n'
              'Tak perlu perangko, tak perlu alamat,\n'
              'sebab hatiku tahu jalan menuju hatimu.\n\n'
              'Setiap malam aku titipkan rinduku\n'
              'pada bintang yang paling terang.\n'
              'Semoga cahayanya sampai padamu\n'
              'sebelum fajar mengusir malam.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Gravitasi',
    isi:      'Aku tidak tahu kapan aku jatuh cinta padamu,\n'
              'mungkin saat senyummu mengalahkan matahari,\n'
              'atau saat tawamu menjadi melodi\n'
              'yang terus berputar di kepalaku.\n\n'
              'Seperti bumi yang tak bisa lepas dari matahari,\n'
              'aku tak bisa lepas dari bayanganmu.\n'
              'Inilah gravitasiku,\n'
              'dan aku rela tertarik selamanya.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Rumah',
    isi:      'Aku telah mendatangi banyak tempat,\n'
              'melihat banyak keindahan di dunia.\n'
              'Tapi tidak ada yang terasa seperti rumah\n'
              'sampai aku menemukan dirimu.\n\n'
              'Kamu bukan sekadar tempat tinggal,\n'
              'kamu adalah tempat pulang.\n'
              'Di mana lelahku terobati,\n'
              'dan jiwaku menemukan damai.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Diam yang Berbicara',
    isi:      'Di antara kata-kata yang terucap,\n'
              'ada seribu perasaan yang kusimpan.\n'
              'Bukan karena tak berani,\n'
              'tapi karena rasaku terlalu dalam untuk diucapkan.\n\n'
              'Tatapanku sudah berkata lebih dari cukup,\n'
              'semoga kamu membacanya dengan hatimu.\n'
              'Bahwa aku di sini, selalu,\n'
              'mencintaimu dalam diam yang berbicara keras.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Bintang Terdekat',
    isi:      'Jutaan bintang menghiasi langit malam,\n'
              'namun mataku hanya mencari satu.\n'
              'Yang bersinar bukan karena paling terang,\n'
              'tapi karena cahayanya menyentuh jiwaku.\n\n'
              'Itulah kamu, bintang terdekatku,\n'
              'yang selalu menunjukkan arah pulang.\n'
              'Tak perlu kompas, tak perlu peta,\n'
              'cukup kamu, aku sudah di rumah.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Rindu Musim Hujan',
    isi:      'Setiap hujan turun aku mengingatmu,\n'
              'seperti petrichor yang memeluk bumi.\n'
              'Rindu ini datang diam-diam,\n'
              'tapi perginya selalu lama sekali.\n\n'
              'Semoga di ujung hujan ini\n'
              'ada pelangi yang menghubungkan kita.\n'
              'Dan saat langit cerah kembali,\n'
              'kamu sudah ada di sini, bersamaku.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Percakapan Hati',
    isi:      'Hatiku berbicara padamu setiap malam,\n'
              'menceritakan hal-hal yang lisanku tak sanggup.\n'
              'Tentang betapa indahnya dunia saat kamu ada,\n'
              'dan betapa sunyinya ketika kamu tiada.\n\n'
              'Semoga hatimu mendengar percakapan itu,\n'
              'dan menjawabnya dengan kehadiran.\n'
              'Karena tidak ada yang lebih aku inginkan\n'
              'selain kamu tetap di sini, bersamaku.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Setia',
    isi:      'Cintaku bukan yang paling puitis,\n'
              'tapi ia tulus dan tidak berpura-pura.\n'
              'Cintaku bukan yang paling sempurna,\n'
              'tapi ia setia menemanimu di tiap musim.\n\n'
              'Di saat kamu di puncak kebahagiaanmu,\n'
              'aku akan bertepuk tangan paling keras.\n'
              'Di saat kamu di lembah kesedihanmu,\n'
              'aku akan duduk di sampingmu, diam namun ada.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Pertama Kali',
    isi:      'Pertama kali mataku bertemu matamu,\n'
              'waktu seolah berhenti sejenak.\n'
              'Seolah semesta berbisik padaku:\n'
              '"Dia. Dialah yang kamu cari."\n\n'
              'Dan sejak hari itu,\n'
              'namamu menjadi doaku.\n'
              'Wajahmu menjadi lukisan di benakku.\n'
              'Dan cintamu menjadi alasanku untuk terus ada.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'percintaan',
  ),
  PuisiData(
    judul:    'Selalu Ada',
    isi:      'Aku tidak berjanji untuk tidak pernah menyakitimu,\n'
              'sebab aku hanya manusia yang tak sempurna.\n'
              'Tapi aku berjanji satu hal dengan sepenuh hati:\n'
              'aku akan selalu ada dan selalu mencoba.\n\n'
              'Mencoba menjadi lebih baik untukmu,\n'
              'mencoba memahami kamu lebih dalam.\n'
              'Karena kamu layak mendapatkan seseorang\n'
              'yang tidak menyerah saat keadaan sulit.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
];

// ─── Puisi Persahabatan ──────────────────────────────────────────────────────
const List<PuisiData> _puisiPersahabatan = [
  PuisiData(
    judul:    'Sahabat Sejati',
    isi:      'Sahabat bukan yang selalu ada saat senang,\n'
              'tapi yang tetap bertahan saat badai datang.\n'
              'Yang tidak pergi saat kamu di titik terendah,\n'
              'dan yang ikut bersuka saat kamu di puncak.\n\n'
              'Kamu adalah sahabat seperti itu bagiku,\n'
              'yang hadir bukan karena terpaksa.\n'
              'Dan untuk itu aku bersyukur setiap hari,\n'
              'bahwa semesta mempertemukan kita.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Tertawa Bersama',
    isi:      'Ada keajaiban dalam tawa yang kita bagikan,\n'
              'di sudut warung, di tepi jalan, di mana saja.\n'
              'Tidak peduli seberapa remeh topik pembicaraan,\n'
              'bersamamu, semua menjadi berharga.\n\n'
              'Semoga kita terus tertawa bersama,\n'
              'melewati hari demi hari yang berlalu.\n'
              'Sebab tawa bersamamu adalah obat,\n'
              'yang tidak bisa digantikan apapun.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Perjalanan Kita',
    isi:      'Kita memulai perjalanan ini tanpa peta,\n'
              'hanya langkah yang saling menguatkan.\n'
              'Pernah tersesat, pernah beda arah,\n'
              'namun selalu kembali ke satu titik: bersama.\n\n'
              'Tidak semua perjalanan butuh tujuan pasti,\n'
              'yang penting ada kawan yang setia.\n'
              'Dan aku bersyukur perjalanan hidupku\n'
              'ditemani oleh jiwa sebaik dirimu.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Cermin Jiwa',
    isi:      'Kamu adalah cermin yang jujur untukku,\n'
              'yang tidak hanya menampilkan keindahan.\n'
              'Tapi juga menunjukkan kekuranganku\n'
              'dengan cara yang tidak menyakitkan.\n\n'
              'Itulah yang membuatmu istimewa,\n'
              'sahabat yang membuat aku tumbuh.\n'
              'Bukan yang selalu memuji,\n'
              'tapi yang selalu mendorongku menjadi lebih baik.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Jarak Tak Berarti',
    isi:      'Meski kini kita terpisah jarak dan waktu,\n'
              'persahabatan kita tidak pernah pudar.\n'
              'Seperti bintang di langit yang berbeda,\n'
              'tapi bersinar dari galaksi yang sama.\n\n'
              'Kapanpun kita bertemu kembali,\n'
              'seolah waktu tidak pernah berlalu.\n'
              'Itulah keajaiban persahabatan sejati,\n'
              'yang tidak bisa dilemahkan oleh jarak manapun.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Hadir di Saat Gelap',
    isi:      'Ketika duniaku terasa gelap dan sepi,\n'
              'kamu datang membawa lentera kecil.\n'
              'Tidak menjanjikan segalanya akan baik,\n'
              'tapi menemani sambil mengatakan: aku di sini.\n\n'
              'Dan ternyata itulah yang aku butuhkan,\n'
              'bukan jawaban, bukan solusi.\n'
              'Hanya kehadiran seorang sahabat\n'
              'yang membuatku merasa tidak sendirian.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Kita Saling Memilih',
    isi:      'Keluarga dipilihkan semesta untukmu,\n'
              'tapi sahabat, itulah pilihanmu sendiri.\n'
              'Dan di antara sekian banyak orang di dunia,\n'
              'aku bersyukur kita saling memilih satu sama lain.\n\n'
              'Pilihan yang tidak pernah kusesali,\n'
              'bahkan semakin aku syukuri seiring waktu.\n'
              'Sebab memilikimu sebagai sahabat\n'
              'adalah salah satu anugerah terbaikku.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Kenangan yang Menghangatkan',
    isi:      'Di hari-hari yang dingin dan melelahkan,\n'
              'aku menghangatkan diri dengan kenangan kita.\n'
              'Tawa-tawa kecil yang pernah kita ciptakan,\n'
              'dan petualangan konyol yang tak terlupakan.\n\n'
              'Kenangan itu adalah hartaku,\n'
              'yang tidak bisa dicuri siapapun.\n'
              'Dan aku berharap kita terus menciptakan\n'
              'kenangan baru yang sama indahnya.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Tanpa Syarat',
    isi:      'Persahabatanmu tidak datang dengan syarat,\n'
              'kamu menerimaku apa adanya.\n'
              'Dengan semua keanehan dan kekuranganku,\n'
              'kamu tetap ada tanpa pertanyaan.\n\n'
              'Itulah mengapa aku menghargaimu,\n'
              'lebih dari yang bisa aku ungkapkan.\n'
              'Karena di dunia yang penuh perhitungan,\n'
              'kamu hadir dengan cinta yang tanpa syarat.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'persahabatan',
  ),
  PuisiData(
    judul:    'Dua Jiwa Satu Visi',
    isi:      'Berbeda latar, berbeda cara pandang,\n'
              'namun hati kita berbicara bahasa yang sama.\n'
              'Perbedaan itu bukan pemisah kita,\n'
              'justru itulah yang membuat kita saling melengkapi.\n\n'
              'Kamu membawa warna yang aku tidak punya,\n'
              'dan aku membawa cahaya yang kamu butuhkan.\n'
              'Bersama kita bukan sekadar dua orang,\n'
              'tapi dua jiwa yang membentuk satu kekuatan.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
];

// ─── Puisi Motivasi ──────────────────────────────────────────────────────────
const List<PuisiData> _puisiMotivasi = [
  PuisiData(
    judul:    'Bangkit',
    isi:      'Setiap jatuh bukan akhir dari segalanya,\n'
              'tapi awal dari kebangkitan yang lebih kuat.\n'
              'Bumi yang keras di bawahmu itu\n'
              'adalah pijakan untuk melompat lebih tinggi.\n\n'
              'Bangkitlah, meski lututmu masih gemetar.\n'
              'Melangkahlah, meski jalanmu masih buram.\n'
              'Sebab keberhasilan bukan milik yang tak pernah jatuh,\n'
              'tapi milik mereka yang terus bangkit.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Bukan Tentang Kecepatan',
    isi:      'Hidup bukan perlombaan sprint,\n'
              'ia adalah maraton panjang yang membutuhkan nafas.\n'
              'Tidak apa berlari lambat,\n'
              'yang penting kamu tidak berhenti.\n\n'
              'Jangan bandingkan langkahmu dengan orang lain,\n'
              'sebab jalanmu berbeda dengan mereka.\n'
              'Yang terpenting adalah kamu terus maju,\n'
              'satu langkah kecil setiap harinya.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Dirimu adalah Karya',
    isi:      'Kamu bukan produk jadi yang harus sempurna,\n'
              'kamu adalah karya yang terus berkembang.\n'
              'Setiap hari adalah sapuan kuas baru,\n'
              'yang menyempurnakan lukisan hidupmu.\n\n'
              'Jangan terlalu keras pada dirimu sendiri,\n'
              'bahkan seniman terbaik pun pernah salah goresan.\n'
              'Yang membedakan mereka adalah mereka tidak berhenti,\n'
              'mereka terus melukis hingga jadi mahakarya.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Sebelum Fajar',
    isi:      'Sebelum fajar, langit selalu paling gelap.\n'
              'Sebelum sukses, ujian selalu paling berat.\n'
              'Sebelum pelangi, hujan selalu paling deras.\n'
              'Bertahanlah, cahaya itu sedang dalam perjalanan.\n\n'
              'Kamu sudah sejauh ini, jangan berhenti sekarang.\n'
              'Setiap tetes keringatmu adalah investasi.\n'
              'Dan satu hari nanti, saat fajar itu tiba,\n'
              'kamu akan bersyukur tidak menyerah dulu.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Benih dan Pohon',
    isi:      'Pohon raksasa berawal dari benih kecil,\n'
              'yang ditanam dengan sabar dan penuh harap.\n'
              'Mimpimu hari ini adalah benih itu,\n'
              'rawatlah setiap hari tanpa henti.\n\n'
              'Tidak semua benih tumbuh dengan cepat,\n'
              'beberapa butuh musim lebih panjang.\n'
              'Tapi selama kamu tidak berhenti menyiramnya,\n'
              'suatu saat ia pasti akan tumbuh menjangkau langit.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Kepada Dirimu yang Lelah',
    isi:      'Wahai dirimu yang lelah dan hampir menyerah,\n'
              'aku ingin kamu tahu satu hal:\n'
              'Lelahmu adalah bukti bahwa kamu sudah berjuang,\n'
              'dan itu jauh lebih berharga dari diam.\n\n'
              'Istirahatlah jika memang perlu,\n'
              'tapi jangan pernah berhenti bermimpi.\n'
              'Sebab dunia ini membutuhkan cahayamu,\n'
              'dan hanya kamu yang bisa memberikannya.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Kunci Tanpa Gembok',
    isi:      'Kamu memiliki kunci yang luar biasa,\n'
              'tapi kamu sibuk mencari gemboknya.\n'
              'Kunci itu adalah potensimu,\n'
              'dan gembok itu adalah takdirmu yang menanti.\n\n'
              'Jangan simpan kunci itu dalam saku,\n'
              'gunakanlah, coba setiap pintu yang ada.\n'
              'Satu pintu yang terbuka sudah cukup\n'
              'untuk mengubah seluruh hidupmu.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Berani Bermimpi',
    isi:      'Orang-orang mengatakan mimpimu terlalu besar,\n'
              'bahwa kamu terlalu tinggi mendongak ke langit.\n'
              'Tapi ingatlah: mereka yang mengubah dunia\n'
              'adalah mereka yang dulu dianggap gila.\n\n'
              'Tetaplah berani bermimpi besar,\n'
              'sebab mimpi kecil hanya menghasilkan usaha kecil.\n'
              'Dan ketika impianmu menjadi nyata,\n'
              'dunia akan tahu: kamu tidak gila, kamu visioner.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Proses adalah Hadiah',
    isi:      'Kamu terlalu fokus pada tujuan,\n'
              'hingga lupa menikmati perjalanannya.\n'
              'Padahal di sinilah karaktermu dibentuk,\n'
              'di dalam proses yang terasa berat itu.\n\n'
              'Setiap rintangan adalah guru terbaikmu,\n'
              'setiap kegagalan adalah pelajaran berharga.\n'
              'Jadi syukuri prosesmu, nikmati setiap langkahnya,\n'
              'sebab proses itulah hadiah sesungguhnya.',
    penulis:  '— 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 𝙋𝙍𝙊𝙅𝙀𝘾𝙏',
    kategori: 'motivasi',
  ),
  PuisiData(
    judul:    'Hari Ini Milikmu',
    isi:      'Kemarin sudah berlalu, kamu tak bisa kembali.\n'
              'Esok belum tiba, kamu tak perlu takut.\n'
              'Yang kamu miliki hanyalah hari ini,\n'
              'maka manfaatkanlah sebaik mungkin.\n\n'
              'Tanamkan satu kebaikan hari ini,\n'
              'ambil satu langkah menuju impianmu.\n'
              'Karena kesuksesan besar tidak terjadi sekaligus,\n'
              'ia adalah hasil dari hari-hari kecil yang konsisten.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
];

// ─── Semua Puisi ─────────────────────────────────────────────────────────────
const List<PuisiData> _semuaPuisi = [
  ..._puisiPercintaan,
  ..._puisiPersahabatan,
  ..._puisiMotivasi,
];

// ─── Page ─────────────────────────────────────────────────────────────────────
class PuisiPage extends StatefulWidget {
  const PuisiPage({super.key});

  @override
  State<PuisiPage> createState() => _PuisiPageState();
}

class _PuisiPageState extends State<PuisiPage> with TickerProviderStateMixin {
  String _selectedKategori = 'semua';
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  late Animation<Offset>  _headerSlide;
  final _random = Random();

  final List<Map<String, dynamic>> _tabs = [
    {'id': 'semua',         'label': 'Semua',          'icon': Icons.auto_stories_rounded,    'color': AppColors.cyan},
    {'id': 'percintaan',    'label': 'Percintaan',      'icon': Icons.favorite_rounded,        'color': const Color(0xFFEC4899)},
    {'id': 'persahabatan',  'label': 'Persahabatan',    'icon': Icons.people_rounded,          'color': AppColors.cyanDim},
    {'id': 'motivasi',      'label': 'Motivasi',        'icon': Icons.emoji_events_rounded,    'color': AppColors.warning},
  ];

  List<PuisiData> get _filteredPuisi {
    if (_selectedKategori == 'semua') return _semuaPuisi;
    if (_selectedKategori == 'percintaan') return _puisiPercintaan;
    if (_selectedKategori == 'persahabatan') return _puisiPersahabatan;
    return _puisiMotivasi;
  }

  Color get _activeColor {
    final tab = _tabs.firstWhere((t) => t['id'] == _selectedKategori,
        orElse: () => _tabs[0]);
    return tab['color'] as Color;
  }

  @override
  void initState() {
    super.initState();
    _headerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _headerFade  = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide = Tween<Offset>(begin: const Offset(0, -0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOutCubic));
    _headerCtrl.forward();
  }

  @override
  void dispose() {
    _headerCtrl.dispose();
    super.dispose();
  }

  void _copyPuisi(PuisiData puisi) {
    final text = '${puisi.judul}\n\n${puisi.isi}\n\n${puisi.penulis}';
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Row(children: [
        Icon(Icons.check_circle_rounded, color: Colors.white, size: 16),
        SizedBox(width: 8),
        Text('Puisi disalin!', style: TextStyle(
            color: Colors.white, fontWeight: FontWeight.w600)),
      ]),
      backgroundColor: AppColors.success,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      duration: const Duration(seconds: 2),
    ));
  }

  void _showPuisiDetail(PuisiData puisi) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _PuisiDetailSheet(puisi: puisi, onCopy: () => _copyPuisi(puisi)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = _filteredPuisi;
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header
            FadeTransition(
              opacity: _headerFade,
              child: SlideTransition(
                position: _headerSlide,
                child: _buildHeader(),
              ),
            ),
            // ── Tab Bar
            _buildTabBar(),
            const SizedBox(height: 4),
            // ── List
            Expanded(
              child: list.isEmpty
                  ? _buildEmpty()
                  : ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                      itemCount: list.length,
                      itemBuilder: (_, i) => _StaggerItem(
                        index: i,
                        child: _PuisiCard(
                          puisi: list[i],
                          onTap: () => _showPuisiDetail(list[i]),
                          onCopy: () => _copyPuisi(list[i]),
                          accentColor: _activeColor,
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.border),
          boxShadow: [
            BoxShadow(color: AppColors.borderGlow.withOpacity(0.1),
                blurRadius: 20, offset: const Offset(0, 6)),
          ],
        ),
        child: Row(children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFEC4899), Color(0xFFA78BFA)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(color: const Color(0xFFEC4899).withOpacity(0.3), blurRadius: 12),
              ],
            ),
            child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ShaderMask(
              shaderCallback: (b) => const LinearGradient(
                colors: [Color(0xFFEC4899), Color(0xFFA78BFA)],
              ).createShader(b),
              child: const Text('Puisi',
                  style: TextStyle(color: Colors.white, fontSize: 17,
                      fontWeight: FontWeight.w800, letterSpacing: -0.3)),
            ),
            const Text('Percintaan · Persahabatan · Motivasi',
                style: TextStyle(color: AppColors.textSub, fontSize: 11)),
          ]),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: AppColors.border),
            ),
            child: Text('${_semuaPuisi.length} puisi',
                style: const TextStyle(color: AppColors.textSub, fontSize: 11,
                    fontWeight: FontWeight.w600)),
          ),
          const SizedBox(width: 8),
          // Back button
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppColors.border),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: AppColors.textSub, size: 15),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildTabBar() {
    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        physics: const BouncingScrollPhysics(),
        itemCount: _tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final tab = _tabs[i];
          final isActive = _selectedKategori == tab['id'];
          final color = tab['color'] as Color;
          return GestureDetector(
            onTap: () => setState(() => _selectedKategori = tab['id'] as String),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: isActive ? color.withOpacity(0.15) : AppColors.card,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(
                  color: isActive ? color.withOpacity(0.4) : AppColors.border,
                  width: isActive ? 1.5 : 1.0,
                ),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(tab['icon'] as IconData,
                    color: isActive ? color : AppColors.textSub, size: 14),
                const SizedBox(width: 6),
                Text(tab['label'] as String,
                    style: TextStyle(
                      color: isActive ? color : AppColors.textSub,
                      fontSize: 12,
                      fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                    )),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.auto_stories_rounded, color: AppColors.textSub.withOpacity(0.3), size: 56),
        const SizedBox(height: 12),
        const Text('Belum ada puisi', style: TextStyle(color: AppColors.textSub, fontSize: 14)),
      ]),
    );
  }
}

// ─── Puisi Card ───────────────────────────────────────────────────────────────
class _PuisiCard extends StatefulWidget {
  final PuisiData puisi;
  final VoidCallback onTap;
  final VoidCallback onCopy;
  final Color accentColor;

  const _PuisiCard({
    required this.puisi,
    required this.onTap,
    required this.onCopy,
    required this.accentColor,
  });

  @override
  State<_PuisiCard> createState() => _PuisiCardState();
}

class _PuisiCardState extends State<_PuisiCard> {
  bool _pressed = false;

  Color get _categoryColor {
    switch (widget.puisi.kategori) {
      case 'percintaan':   return const Color(0xFFEC4899);
      case 'persahabatan': return AppColors.cyanDim;
      case 'motivasi':     return AppColors.warning;
      default:             return AppColors.cyan;
    }
  }

  String get _categoryLabel {
    switch (widget.puisi.kategori) {
      case 'percintaan':   return '💕 Percintaan';
      case 'persahabatan': return '🤝 Persahabatan';
      case 'motivasi':     return '⚡ Motivasi';
      default:             return widget.puisi.kategori;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _categoryColor;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(
            color: _pressed ? color.withOpacity(0.07) : AppColors.card,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: _pressed ? color.withOpacity(0.35) : AppColors.border,
              width: _pressed ? 1.5 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(_pressed ? 0.1 : 0.04),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // ── Top Row
              Row(children: [
                // Category badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: color.withOpacity(0.25)),
                  ),
                  child: Text(_categoryLabel,
                      style: TextStyle(color: color, fontSize: 10,
                          fontWeight: FontWeight.w700)),
                ),
                const Spacer(),
                // Copy button
                GestureDetector(
                  onTap: widget.onCopy,
                  child: Container(
                    width: 32, height: 32,
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(9),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: const Icon(Icons.copy_rounded,
                        color: AppColors.textSub, size: 14),
                  ),
                ),
              ]),

              const SizedBox(height: 12),

              // ── Judul
              Text(widget.puisi.judul,
                  style: TextStyle(
                    color: color,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.2,
                  )),

              const SizedBox(height: 8),

              // ── Preview Isi (2 baris pertama)
              Text(
                widget.puisi.isi.split('\n').take(2).join('\n'),
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 13,
                  height: 1.6,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),

              const SizedBox(height: 10),

              // ── Bottom Row
              Row(children: [
                Text(widget.puisi.penulis,
                    style: const TextStyle(
                        color: AppColors.textSub, fontSize: 11,
                        fontStyle: FontStyle.italic)),
                const Spacer(),
                Text('Baca Selengkapnya',
                    style: TextStyle(color: color, fontSize: 11,
                        fontWeight: FontWeight.w600)),
                const SizedBox(width: 3),
                Icon(Icons.arrow_forward_ios_rounded, color: color, size: 10),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

// ─── Puisi Detail Sheet ───────────────────────────────────────────────────────
class _PuisiDetailSheet extends StatelessWidget {
  final PuisiData puisi;
  final VoidCallback onCopy;

  const _PuisiDetailSheet({required this.puisi, required this.onCopy});

  Color get _color {
    switch (puisi.kategori) {
      case 'percintaan':   return const Color(0xFFEC4899);
      case 'persahabatan': return AppColors.cyanDim;
      case 'motivasi':     return AppColors.warning;
      default:             return AppColors.cyan;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _color;
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.80,
      ),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top:   BorderSide(color: AppColors.borderGlow),
          left:  BorderSide(color: AppColors.border),
          right: BorderSide(color: AppColors.border),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            margin: const EdgeInsets.only(top: 12, bottom: 4),
            width: 36, height: 4,
            decoration: BoxDecoration(
              color: AppColors.border,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // Shimmer accent
          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, color, Colors.transparent],
              ),
            ),
          ),

          Flexible(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Category badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(9),
                      border: Border.all(color: color.withOpacity(0.3)),
                    ),
                    child: Text(
                      puisi.kategori[0].toUpperCase() + puisi.kategori.substring(1),
                      style: TextStyle(color: color, fontSize: 11,
                          fontWeight: FontWeight.w700),
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Judul
                  Text(puisi.judul,
                      style: TextStyle(
                        color: color,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.5,
                        height: 1.2,
                      )),

                  const SizedBox(height: 16),

                  // Divider
                  Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [color.withOpacity(0.4), Colors.transparent],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Isi puisi
                  Text(puisi.isi,
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 14.5,
                        height: 1.9,
                        fontStyle: FontStyle.italic,
                        letterSpacing: 0.1,
                      )),

                  const SizedBox(height: 20),

                  // Penulis
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(puisi.penulis,
                        style: const TextStyle(
                            color: AppColors.textSub, fontSize: 12,
                            fontStyle: FontStyle.italic)),
                  ),

                  const SizedBox(height: 20),

                  // Copy button
                  SizedBox(
                    width: double.infinity,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        onCopy();
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [color.withOpacity(0.8), color],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(22),
                          boxShadow: [
                            BoxShadow(
                              color: color.withOpacity(0.3),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.copy_rounded, color: Colors.white, size: 16),
                            SizedBox(width: 8),
                            Text('Salin Puisi',
                                style: TextStyle(color: Colors.white,
                                    fontSize: 14, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Stagger Item ─────────────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index * 60).clamp(0, 420)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 18 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}
