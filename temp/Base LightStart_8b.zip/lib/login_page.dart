import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'main.dart';
import 'splash.dart';

const String baseUrl = 'http://nayahaikall.tyzx-host.my.id:2563';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userCtrl  = TextEditingController();
  final passCtrl  = TextEditingController();
  final _formKey  = GlobalKey<FormState>();

  bool   _isLoading   = false;
  bool   _obscurePass = true;
  String? _androidId;
  String? _errorMsg;

  late AnimationController _auroraCtrl, _entranceCtrl, _logoCtrl, _btnCtrl, _shakeCtrl, _pulseCtrl;
  late Animation<double> _fade, _logoGlow, _btnPulse, _shake, _pulse;
  late Animation<Offset>  _slide;

  @override
  void initState() {
    super.initState();

    _auroraCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _logoCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..repeat(reverse: true);
    _btnCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _shakeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 480));
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);

    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.07), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic));
    _logoGlow = Tween<double>(begin: 0.25, end: 1.0)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOut));
    _btnPulse = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));
    _shake = Tween<double>(begin: -1, end: 1)
        .animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.elasticIn));
    _pulse = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _getDeviceId();
    Future.delayed(const Duration(milliseconds: 160), () {
      if (mounted) _entranceCtrl.forward();
    });
  }

  @override
  void dispose() {
    userCtrl.dispose(); passCtrl.dispose();
    _auroraCtrl.dispose(); _entranceCtrl.dispose(); _logoCtrl.dispose();
    _btnCtrl.dispose(); _shakeCtrl.dispose(); _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _getDeviceId() async {
    try {
      final info = DeviceInfoPlugin();
      final android = await info.androidInfo;
      if (mounted) setState(() => _androidId = android.id);
      await _tryAutoLogin();
    } catch (_) {
      await _tryAutoLogin();
    }
  }

  Future<void> _tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey  = prefs.getString('key');
    if (savedUser == null || savedPass == null || savedKey == null) return;
    try {
      final aid = _androidId ?? 'unknown';
      final res = await http.get(Uri.parse(
          '$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$aid&key=$savedKey'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SplashScreen(
          username:    savedUser,
          password:    savedPass,
          role:        data['role']        ?? 'member',
          expiredDate: data['expiredDate'] ?? '-',
          sessionKey:  data['key']         ?? savedKey,
          listBug:     _parseList(data['listBug']),
          listDoos:    _parseList(data['listDDoS']),
          news:        _parseList(data['news']),
        )));
      }
    } catch (_) {}
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  Future<void> _doLogin() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() { _isLoading = true; _errorMsg = null; });

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    try {
      final resp = await http.post(
        Uri.parse('$baseUrl/validate'),
        body: {
          'username': username,
          'password': password,
          'androidId': _androidId ?? 'unknown',
        },
      ).timeout(const Duration(seconds: 12));

      final data = jsonDecode(resp.body);

      if (data['expired'] == true) {
        setState(() => _errorMsg = 'Masa akses habis. Silakan perpanjang.');
        _shakeCtrl.forward(from: 0);
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') || msg.contains('another')) {
          setState(() => _errorMsg = 'Akun sedang login di perangkat lain.');
        } else {
          setState(() => _errorMsg = 'Username atau password salah.');
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', username);
        await prefs.setString('password', password);
        await prefs.setString('key',      data['key'] ?? '');

        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SplashScreen(
          username:    username,
          password:    password,
          role:        data['role']        ?? 'member',
          expiredDate: data['expiredDate'] ?? '-',
          sessionKey:  data['key']         ?? '',
          listBug:     _parseList(data['listBug']),
          listDoos:    _parseList(data['listDDoS']),
          news:        _parseList(data['news']),
        )));
      }
    } catch (e) {
      setState(() => _errorMsg = 'Koneksi gagal. Periksa internet.');
      _shakeCtrl.forward(from: 0);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _launch(String url) async {
    final u = Uri.parse(url);
    if (await canLaunchUrl(u)) await launchUrl(u, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.bg,
    body: Stack(children: [
      AnimatedBuilder(
        animation: _auroraCtrl,
        builder: (_, __) => CustomPaint(
          painter: _LoginAuroraPainter(_auroraCtrl.value),
          child: const SizedBox.expand(),
        ),
      ),
      SafeArea(
        child: FadeTransition(
          opacity: _fade,
          child: SlideTransition(
            position: _slide,
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
                child: Column(children: [
                  _buildLogo(),
                  const SizedBox(height: 32),
                  _buildLoginCard(),
                  const SizedBox(height: 20),
                  _buildFooter(),
                ]),
              ),
            ),
          ),
        ),
      ),
    ]),
  );

  Widget _buildLogo() => Column(children: [
    AnimatedBuilder(
      animation: _logoCtrl,
      builder: (_, child) => Container(
        width: 88, height: 88,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [Color(0xFF141830), Color(0xFF0A0D1C)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: AppColors.cyan.withOpacity(0.35 + 0.3 * _logoGlow.value),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(color: AppColors.cyan.withOpacity(0.3 * _logoGlow.value), blurRadius: 36, spreadRadius: 4),
            BoxShadow(color: AppColors.violet.withOpacity(0.18 * _logoGlow.value), blurRadius: 56, spreadRadius: 8),
          ],
        ),
        child: child,
      ),
      child: ClipOval(child: Image.asset('assets/images/logo.png', fit: BoxFit.cover)),
    ),
    const SizedBox(height: 18),
    ShaderMask(
      shaderCallback: (b) => const LinearGradient(
        colors: [AppColors.cyan, AppColors.violetBright],
      ).createShader(b),
      child: const Text('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧', style: TextStyle(
        fontFamily: 'Orbitron', fontSize: 28, fontWeight: FontWeight.w900,
        color: Colors.white, letterSpacing: 6,
      )),
    ),
    const SizedBox(height: 5),
    const Text('SECURE  ACCESS  PORTAL', style: TextStyle(
      fontFamily: 'ShareTechMono', fontSize: 9,
      color: AppColors.textSub, letterSpacing: 3.5,
    )),
  ]);

  Widget _buildLoginCard() => AnimatedBuilder(
    animation: _shake,
    builder: (_, child) => Transform.translate(
      offset: Offset(_shake.value * 7 * (1 - _shakeCtrl.value), 0),
      child: child,
    ),
    child: Container(
      padding: const EdgeInsets.all(26),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFF111627), Color(0xFF0C0F1E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: AppColors.borderGlow, width: 1),
        boxShadow: [
          BoxShadow(color: AppColors.cyan.withOpacity(0.05), blurRadius: 40, spreadRadius: 0),
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30, offset: const Offset(0, 10)),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Header
          Row(children: [
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  colors: [AppColors.cyan.withOpacity(0.15), AppColors.cyan.withOpacity(0.05)],
                ),
                border: Border.all(color: AppColors.cyan.withOpacity(0.3)),
              ),
              child: const Icon(Icons.lock_open_rounded, color: AppColors.cyan, size: 20),
            ),
            const SizedBox(width: 14),
            const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('LOGIN AKUN', style: TextStyle(
                fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.w800,
                color: AppColors.textPrimary, letterSpacing: 1.5,
              )),
              SizedBox(height: 3),
              Text('Masukkan kredensial kamu', style: TextStyle(
                fontFamily: 'ShareTechMono', fontSize: 10, color: AppColors.textSub,
              )),
            ]),
          ]),

          const SizedBox(height: 8),
          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(vertical: 18),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent, AppColors.borderGlow, Colors.transparent,
              ]),
            ),
          ),

          // Error
          if (_errorMsg != null) ...[
            AnimatedBuilder(
              animation: _pulseCtrl,
              builder: (_, child) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: AppColors.danger.withOpacity(0.07),
                  border: Border.all(
                    color: AppColors.danger.withOpacity(0.3 + _pulse.value * 0.35),
                    width: 1,
                  ),
                ),
                child: child,
              ),
              child: Row(children: [
                const Icon(Icons.error_outline_rounded, color: AppColors.danger, size: 16),
                const SizedBox(width: 9),
                Expanded(child: Text(_errorMsg!, style: const TextStyle(
                  fontFamily: 'ShareTechMono', fontSize: 12, color: AppColors.danger,
                ))),
              ]),
            ),
            const SizedBox(height: 18),
          ],

          // Username
          _PremiumField(
            controller: userCtrl,
            label: 'USERNAME',
            hint: 'Masukkan username',
            icon: Icons.person_rounded,
            accentColor: AppColors.cyan,
            validator: (v) => (v == null || v.isEmpty) ? 'Username wajib diisi' : null,
          ),
          const SizedBox(height: 14),

          // Password
          _PremiumField(
            controller: passCtrl,
            label: 'PASSWORD',
            hint: 'Masukkan password',
            icon: Icons.key_rounded,
            accentColor: AppColors.violetBright,
            obscure: _obscurePass,
            suffix: IconButton(
              icon: Icon(
                _obscurePass ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                color: AppColors.textMuted, size: 18,
              ),
              onPressed: () => setState(() => _obscurePass = !_obscurePass),
            ),
            validator: (v) => (v == null || v.isEmpty) ? 'Password wajib diisi' : null,
            onSubmit: (_) => _doLogin(),
          ),
          const SizedBox(height: 26),

          // Login button — premium upgrade
          AnimatedBuilder(
            animation: _btnCtrl,
            builder: (_, __) => GestureDetector(
              onTap: _isLoading ? null : _doLogin,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: double.infinity, height: 58,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: _isLoading
                      ? const LinearGradient(colors: [AppColors.border, AppColors.surfaceAlt])
                      : LinearGradient(
                          colors: const [Color(0xFF00B4CC), Color(0xFF00E5FF), Color(0xFF006680)],
                          begin: Alignment.topLeft, end: Alignment.bottomRight,
                        ),
                  boxShadow: _isLoading ? [] : [
                    BoxShadow(
                      color: AppColors.cyan.withOpacity(0.55 * _btnPulse.value),
                      blurRadius: 34, offset: const Offset(0, 8),
                    ),
                    BoxShadow(
                      color: AppColors.cyan.withOpacity(0.20 * _btnPulse.value),
                      blurRadius: 70, offset: const Offset(0, 4),
                    ),
                    BoxShadow(
                      color: AppColors.violet.withOpacity(0.15 * _btnPulse.value),
                      blurRadius: 50, spreadRadius: 4,
                    ),
                  ],
                  border: Border.all(
                    color: _isLoading
                        ? AppColors.border
                        : AppColors.cyan.withOpacity(0.5 + 0.3 * _btnPulse.value),
                    width: 1.2,
                  ),
                ),
                child: _isLoading
                    ? Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
                        SizedBox(width: 20, height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            valueColor: AlwaysStoppedAnimation(AppColors.textSub),
                          ),
                        ),
                        SizedBox(width: 12),
                        Text('AUTHENTICATING...', style: TextStyle(
                          fontFamily: 'Orbitron', fontSize: 11,
                          color: AppColors.textSub, letterSpacing: 1.5,
                        )),
                      ])
                    : Stack(alignment: Alignment.center, children: [
                        // Shimmer effect
                        ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: ShaderMask(
                            shaderCallback: (b) => LinearGradient(
                              begin: Alignment(_btnPulse.value * 3 - 2, 0),
                              end: Alignment(_btnPulse.value * 3 - 1.5, 0),
                              colors: [Colors.transparent, Colors.white.withOpacity(0.15), Colors.transparent],
                            ).createShader(b),
                            child: Container(color: Colors.white),
                          ),
                        ),
                        const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.login_rounded, size: 22, color: AppColors.bg),
                          SizedBox(width: 10),
                          Text('MASUK SEKARANG', style: TextStyle(
                            fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900,
                            color: AppColors.bg, letterSpacing: 2,
                          )),
                        ]),
                      ]),
              ),
            ),
          ),
        ]),
      ),
    ),
  );

  Widget _buildFooter() => Column(children: [
    const Text('Belum punya akun?', style: TextStyle(
      fontFamily: 'ShareTechMono', fontSize: 12, color: AppColors.textSub,
    )),
    const SizedBox(height: 10),
    GestureDetector(
      onTap: () => _launch('https://t.me/@kizz_Real05'),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            colors: [AppColors.violet.withOpacity(0.15), AppColors.violetBright.withOpacity(0.05)],
          ),
          border: Border.all(color: AppColors.violet.withOpacity(0.35)),
        ),
        child: const Text('BUY HERE', style: TextStyle(
          fontFamily: 'Orbitron', fontSize: 11,
          color: AppColors.violetBright, letterSpacing: 2,
        )),
      ),
    ),
  ]);
}

// ── Premium Input Field ───────────────────────────────────────
class _PremiumField extends StatefulWidget {
  final TextEditingController controller;
  final String label, hint;
  final IconData icon;
  final Color accentColor;
  final bool obscure;
  final Widget? suffix;
  final String? Function(String?)? validator;
  final void Function(String)? onSubmit;

  const _PremiumField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    required this.accentColor,
    this.obscure = false,
    this.suffix,
    this.validator,
    this.onSubmit,
  });

  @override
  State<_PremiumField> createState() => _PremiumFieldState();
}

class _PremiumFieldState extends State<_PremiumField> {
  bool _focused = false;

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Container(
        width: 4, height: 12,
        margin: const EdgeInsets.only(right: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(2),
          gradient: LinearGradient(
            colors: [widget.accentColor, widget.accentColor.withOpacity(0.3)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
      ),
      Text(widget.label, style: TextStyle(
        fontFamily: 'Orbitron', fontSize: 9,
        color: _focused ? widget.accentColor : AppColors.textSub,
        letterSpacing: 2.5,
      )),
    ]),
    const SizedBox(height: 8),
    Focus(
      onFocusChange: (f) => setState(() => _focused = f),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(13),
          boxShadow: _focused ? [
            BoxShadow(color: widget.accentColor.withOpacity(0.18), blurRadius: 20, spreadRadius: 0),
          ] : [],
        ),
        child: TextFormField(
          controller: widget.controller,
          obscureText: widget.obscure,
          onFieldSubmitted: widget.onSubmit,
          style: const TextStyle(
            fontFamily: 'ShareTechMono', fontSize: 14, color: AppColors.textPrimary,
          ),
          decoration: InputDecoration(
            hintText: widget.hint,
            hintStyle: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 13, color: AppColors.textMuted),
            prefixIcon: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              child: Icon(widget.icon, size: 18, color: _focused ? widget.accentColor : AppColors.textMuted),
            ),
            suffixIcon: widget.suffix,
            filled: true,
            fillColor: const Color(0xFF0A0D18),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(13),
              borderSide: const BorderSide(color: AppColors.border, width: 1),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(13),
              borderSide: BorderSide(color: widget.accentColor, width: 1.5),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(13),
              borderSide: const BorderSide(color: AppColors.danger),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(13),
              borderSide: const BorderSide(color: AppColors.danger, width: 1.5),
            ),
            errorStyle: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11, color: AppColors.danger),
          ),
          validator: widget.validator,
        ),
      ),
    ),
  ]);
}

// ── Aurora Background ─────────────────────────────────────────
class _LoginAuroraPainter extends CustomPainter {
  final double t;
  _LoginAuroraPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final a = t * 2 * math.pi;
    final cx = size.width / 2;

    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..shader = const LinearGradient(
        colors: [Color(0xFF03040A), Color(0xFF060811), Color(0xFF080D18)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    void _blob(double ox, double oy, double r, Color c) {
      canvas.drawCircle(
        Offset(ox, oy), r,
        Paint()..shader = RadialGradient(colors: [c, Colors.transparent])
            .createShader(Rect.fromCircle(center: Offset(ox, oy), radius: r)),
      );
    }

    _blob(cx + math.cos(a) * 60, size.height * 0.22 + math.sin(a) * 30, 200, AppColors.violet.withOpacity(0.10));
    _blob(cx - math.cos(a * 0.8) * 45, size.height * 0.75 + math.sin(a) * 20, 170, AppColors.cyan.withOpacity(0.07));

    final dot = Paint()..color = AppColors.cyan.withOpacity(0.016);
    const s = 28.0;
    for (double x = 0; x < size.width; x += s) {
      for (double y = 0; y < size.height; y += s) {
        canvas.drawCircle(Offset(x, y), 1, dot);
      }
    }
  }

  @override
  bool shouldRepaint(_LoginAuroraPainter old) => old.t != t;
}
