import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart';

// ─── Palette Quran ───────────────────────────────────────────────────────────
class _QC {
  static const bg        = Color(0xFF060B14);
  static const surface   = Color(0xFF0C1424);
  static const card      = Color(0xFF0F1E35);
  static const border    = Color(0xFF1A3050);
  static const gold      = Color(0xFFD4AF37);
  static const goldLight = Color(0xFFEDD97A);
  static const goldDim   = Color(0xFF8C7000);
  static const green     = AppColors.success;
  static const teal      = Color(0xFF14B8A6);
  static const text      = Color(0xFFDEEEFB);
  static const textSub   = Color(0xFF6A92B8);
  static const textDim   = Color(0xFF2E4E6E);

  static const LinearGradient goldGrad = LinearGradient(
    colors: [Color(0xFF8C7000), Color(0xFFD4AF37), Color(0xFFEDD97A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient greenGrad = LinearGradient(
    colors: [Color(0xFF064E3B), Color(0xFF065F46), Color(0xFF059669)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Model Data Ayat ─────────────────────────────────────────────────────────
class QuranAyat {
  final int nomor;
  final String arab;
  final String latin;
  final String arti;

  const QuranAyat({
    required this.nomor,
    required this.arab,
    required this.latin,
    required this.arti,
  });
}

// ─── Model Data Surat ────────────────────────────────────────────────────────
class QuranSurah {
  final int nomor;
  final String nama;
  final String namaLatin;
  final String arti;
  final String tempatTurun;
  final int jumlahAyat;
  final String deskripsi;
  final List<QuranAyat> ayat;

  const QuranSurah({
    required this.nomor,
    required this.nama,
    required this.namaLatin,
    required this.arti,
    required this.tempatTurun,
    required this.jumlahAyat,
    required this.deskripsi,
    required this.ayat,
  });
}

// ─── Data Surat Al-Quran ─────────────────────────────────────────────────────
final List<QuranSurah> allQuranSurah = [

  // ══════════════════════════════════════════════════
  // 1. AL-FATIHAH
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 1,
    nama: 'الفاتحة',
    namaLatin: 'Al-Fatihah',
    arti: 'Pembukaan',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 7,
    deskripsi: 'Al-Fatihah adalah surat pembuka Al-Quran. Surat ini disebut juga Ummul Quran (Induk Al-Quran) karena ia merangkum seluruh isi Al-Quran. Surat ini wajib dibaca dalam setiap rakaat shalat.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', latin: "Bismillāhir-raḥmānir-raḥīm", arti: 'Dengan nama Allah Yang Maha Pengasih, Maha Penyayang.'),
      QuranAyat(nomor: 2, arab: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', latin: "Al-ḥamdu lillāhi rabbil-'ālamīn", arti: 'Segala puji bagi Allah, Tuhan seluruh alam.'),
      QuranAyat(nomor: 3, arab: 'الرَّحْمَٰنِ الرَّحِيمِ', latin: "Ar-raḥmānir-raḥīm", arti: 'Yang Maha Pengasih, Maha Penyayang.'),
      QuranAyat(nomor: 4, arab: 'مَالِكِ يَوْمِ الدِّينِ', latin: "Māliki yaumid-dīn", arti: 'Pemilik hari pembalasan.'),
      QuranAyat(nomor: 5, arab: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ', latin: "Iyyāka na'budu wa iyyāka nasta'īn", arti: 'Hanya kepada Engkaulah kami menyembah dan hanya kepada Engkaulah kami mohon pertolongan.'),
      QuranAyat(nomor: 6, arab: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', latin: "Ihdinaṣ-ṣirāṭal-mustaqīm", arti: 'Tunjukilah kami jalan yang lurus.'),
      QuranAyat(nomor: 7, arab: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ', latin: "Ṣirāṭallażīna an'amta 'alaihim gairil-magḍụbi 'alaihim wa laḍ-ḍāllīn", arti: '(yaitu) jalan orang-orang yang telah Engkau beri nikmat kepadanya; bukan (jalan) mereka yang dimurkai, dan bukan (pula jalan) mereka yang sesat.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 2. AL-BAQARAH (Sebagian ayat pilihan bermakna)
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 2,
    nama: 'البقرة',
    namaLatin: 'Al-Baqarah',
    arti: 'Sapi Betina',
    tempatTurun: 'Madaniyah',
    jumlahAyat: 286,
    deskripsi: 'Al-Baqarah adalah surat terpanjang dalam Al-Quran. Mengandung Ayat Kursi yang merupakan ayat teragung dalam Al-Quran. Surat ini mengandung banyak hukum-hukum Islam, kisah Bani Israil, dan petunjuk bagi kehidupan manusia.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'الم', latin: "Alif Lām Mīm", arti: 'Alif Lam Mim.'),
      QuranAyat(nomor: 2, arab: 'ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِلْمُتَّقِينَ', latin: "Żālikal-kitābu lā raiba fīh, hudal lil-muttaqīn", arti: 'Kitab (Al-Quran) ini tidak ada keraguan padanya; petunjuk bagi mereka yang bertakwa.'),
      QuranAyat(nomor: 255, arab: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ', latin: "Allāhu lā ilāha illā huw, al-ḥayyul-qayyụm, lā ta'khużuhū sinatuw wa lā naụm, lahū mā fis-samāwāti wa mā fil-arḍ", arti: 'Allah, tidak ada tuhan selain Dia. Yang Mahahidup, Yang terus menerus mengurus (makhluk-Nya), tidak mengantuk dan tidak tidur. Milik-Nya apa yang ada di langit dan apa yang ada di bumi.'),
      QuranAyat(nomor: 256, arab: 'لَا إِكْرَاهَ فِي الدِّينِ ۖ قَد تَّبَيَّنَ الرُّشْدُ مِنَ الْغَيِّ', latin: "Lā ikrāha fid-dīn, qat tabayyanar-rusydu minal-gayy", arti: 'Tidak ada paksaan dalam (menganut) agama (Islam), sesungguhnya telah jelas (perbedaan) antara jalan yang benar dengan jalan yang sesat.'),
      QuranAyat(nomor: 286, arab: 'لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا', latin: "Lā yukallifullāhu nafsan illā wus'ahā", arti: 'Allah tidak membebani seseorang melainkan sesuai dengan kesanggupannya.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 3. ALI IMRAN (Ayat pilihan)
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 3,
    nama: 'آل عمران',
    namaLatin: "Ali 'Imran",
    arti: 'Keluarga Imran',
    tempatTurun: 'Madaniyah',
    jumlahAyat: 200,
    deskripsi: "Surat ini berisi tentang keluarga Imran, kisah Nabi Isa AS dan Maryam, serta pelajaran dari Perang Uhud. Surat ini juga memuat banyak hujjah tentang keesaan Allah dan kenabian Muhammad SAW.",
    ayat: [
      QuranAyat(nomor: 1, arab: 'الم', latin: "Alif Lām Mīm", arti: 'Alif Lam Mim.'),
      QuranAyat(nomor: 2, arab: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ', latin: "Allāhu lā ilāha illā huwal-ḥayyul-qayyụm", arti: 'Allah, tidak ada tuhan selain Dia. Yang Mahahidup lagi terus menerus mengurus makhluk-Nya.'),
      QuranAyat(nomor: 159, arab: 'فَبِمَا رَحْمَةٍ مِنَ اللَّهِ لِنتَ لَهُمْ ۖ وَلَوْ كُنتَ فَظًّا غَلِيظَ الْقَلْبِ لَانفَضُّوا مِنْ حَوْلِكَ', latin: "Fabimā raḥmatim minallāhi linta lahum, walau kunta faẓẓan galīẓal-qalbi lanfaḍḍụ min ḥaulik", arti: 'Maka berkat rahmat Allah engkau (Muhammad) berlaku lemah lembut terhadap mereka. Sekiranya engkau bersikap keras dan berhati kasar, tentulah mereka menjauhkan diri dari sekitarmu.'),
      QuranAyat(nomor: 190, arab: 'إِنَّ فِي خَلْقِ السَّمَاوَاتِ وَالْأَرْضِ وَاخْتِلَافِ اللَّيْلِ وَالنَّهَارِ لَآيَاتٍ لِأُولِي الْأَلْبَابِ', latin: "Inna fī khalqis-samāwāti wal-arḍi wakhtilāfil-laili wan-nahāri la'āyātil li'ulil-albāb", arti: 'Sesungguhnya dalam penciptaan langit dan bumi, dan pergantian malam dan siang terdapat tanda-tanda (kebesaran Allah) bagi orang yang berakal.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 18. AL-KAHF (Ayat pilihan)
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 18,
    nama: 'الكهف',
    namaLatin: 'Al-Kahf',
    arti: 'Gua',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 110,
    deskripsi: 'Surat Al-Kahf sangat dianjurkan untuk dibaca setiap hari Jumat. Memuat empat kisah besar: Ashabul Kahfi, Pemilik Dua Kebun, Nabi Musa dan Khidir, serta Dzulqarnain. Surat ini memberikan perlindungan dari fitnah Dajjal.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'الْحَمْدُ لِلَّهِ الَّذِي أَنزَلَ عَلَىٰ عَبْدِهِ الْكِتَابَ وَلَمْ يَجْعَل لَّهُ عِوَجًا', latin: "Al-ḥamdu lillāhillażī anzala 'alā 'abdihil-kitāba wa lam yaj'al lahū 'iwajā", arti: 'Segala puji bagi Allah yang telah menurunkan Kitab (Al-Quran) kepada hamba-Nya dan Dia tidak menjadikannya bengkok.'),
      QuranAyat(nomor: 10, arab: 'إِذْ أَوَى الْفِتْيَةُ إِلَى الْكَهْفِ فَقَالُوا رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا', latin: "Iż awal-fityatu ilal-kahfi fa qālụ rabbanā ātinā mil ladunka raḥmataw wa hayyi' lanā min amrinā rasyadā", arti: '(Ingatlah) ketika pemuda-pemuda itu berlindung ke dalam gua lalu mereka berdoa, "Ya Tuhan kami, berikanlah rahmat kepada kami dari sisi-Mu dan sempurnakanlah petunjuk yang lurus bagi kami dalam urusan kami."'),
      QuranAyat(nomor: 28, arab: 'وَاصْبِرْ نَفْسَكَ مَعَ الَّذِينَ يَدْعُونَ رَبَّهُم بِالْغَدَاةِ وَالْعَشِيِّ يُرِيدُونَ وَجْهَهُ', latin: "Waṣbir nafsaka ma'allażīna yad'ụna rabbahum bil-gadāti wal-'asyiyyi yurīdụna wajhah", arti: 'Dan bersabarlah engkau (Muhammad) bersama orang yang menyeru Tuhannya pada pagi dan senja hari dengan mengharap keridaan-Nya.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 36. YASIN
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 36,
    nama: 'يس',
    namaLatin: 'Yasin',
    arti: 'Yasin',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 83,
    deskripsi: 'Yasin disebut sebagai "Jantung Al-Quran". Sangat dianjurkan membacanya di malam Jumat dan untuk orang yang sedang sakaratul maut. Memuat bukti-bukti keesaan Allah, hari kebangkitan, dan kisah penolakan kaum terhadap rasul-rasul Allah.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'يس', latin: "Yā Sīn", arti: 'Yaa Siin.'),
      QuranAyat(nomor: 2, arab: 'وَالْقُرْآنِ الْحَكِيمِ', latin: "Wal-qur'ānil-ḥakīm", arti: 'Demi Al-Quran yang penuh hikmah.'),
      QuranAyat(nomor: 3, arab: 'إِنَّكَ لَمِنَ الْمُرْسَلِينَ', latin: "Innaka laminal-mursalīn", arti: 'Sungguh, engkau (Muhammad) adalah salah seorang dari rasul-rasul.'),
      QuranAyat(nomor: 12, arab: 'إِنَّا نَحْنُ نُحْيِي الْمَوْتَىٰ وَنَكْتُبُ مَا قَدَّمُوا وَآثَارَهُمْ ۚ وَكُلَّ شَيْءٍ أَحْصَيْنَاهُ فِي إِمَامٍ مُبِينٍ', latin: "Innā naḥnu nuḥyil-mautā wa naktubu mā qaddamụ wa āṡārahum, wa kulla syai'in aḥṣaināhu fī imāmim mubīn", arti: 'Sungguh, Kamilah yang menghidupkan orang-orang yang mati, dan Kamilah yang mencatat apa yang telah mereka kerjakan dan bekas-bekas yang mereka tinggalkan. Dan segala sesuatu Kami kumpulkan dalam Kitab yang jelas (Lauh Mahfuzh).'),
      QuranAyat(nomor: 58, arab: 'سَلَامٌ قَوْلًا مِن رَّبٍّ رَّحِيمٍ', latin: "Salāmun qaulam mir rabbir raḥīm", arti: '(Kepada mereka dikatakan), "Salam," sebagai ucapan selamat dari Tuhan Yang Maha Penyayang.'),
      QuranAyat(nomor: 82, arab: 'إِنَّمَا أَمْرُهُ إِذَا أَرَادَ شَيْئًا أَن يَقُولَ لَهُ كُن فَيَكُونُ', latin: "Innamā amruhū iżā arāda syai'an ay yaqụla lahū kun fa yakụn", arti: 'Sesungguhnya urusan-Nya apabila Dia menghendaki sesuatu Dia hanya berkata kepadanya, "Jadilah!" Maka jadilah sesuatu itu.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 55. AR-RAHMAN
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 55,
    nama: 'الرحمن',
    namaLatin: 'Ar-Rahman',
    arti: 'Yang Maha Pengasih',
    tempatTurun: 'Madaniyah',
    jumlahAyat: 78,
    deskripsi: 'Surat Ar-Rahman dikenal sebagai "Pengantin Al-Quran". Berulang kali menyebutkan ayat "Maka nikmat Tuhanmu yang manakah yang kamu dustakan?" sebanyak 31 kali. Menggambarkan keindahan surga dan nikmat Allah yang tak terhitung.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'الرَّحْمَٰنُ', latin: "Ar-raḥmān", arti: 'Yang Maha Pengasih.'),
      QuranAyat(nomor: 2, arab: 'عَلَّمَ الْقُرْآنَ', latin: "Allamal-qur'ān", arti: 'Yang telah mengajarkan Al-Quran.'),
      QuranAyat(nomor: 3, arab: 'خَلَقَ الْإِنسَانَ', latin: "Khalaqal-insān", arti: 'Dia menciptakan manusia.'),
      QuranAyat(nomor: 4, arab: 'عَلَّمَهُ الْبَيَانَ', latin: "Allamahul-bayān", arti: 'Mengajarnya pandai berbicara.'),
      QuranAyat(nomor: 13, arab: 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', latin: "Fa bi'ayyi ālā'i rabbikumā tukażżibān", arti: 'Maka nikmat Tuhanmu yang manakah yang kamu dustakan?'),
      QuranAyat(nomor: 60, arab: 'هَلْ جَزَاءُ الْإِحْسَانِ إِلَّا الْإِحْسَانُ', latin: "Hal jazā'ul-iḥsāni illal-iḥsān", arti: 'Tidak ada balasan untuk kebaikan selain kebaikan (pula).'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 56. AL-WAQI'AH
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 56,
    nama: 'الواقعة',
    namaLatin: "Al-Waqi'ah",
    arti: 'Hari Kiamat',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 96,
    deskripsi: "Surat Al-Waqi'ah sangat dianjurkan untuk dibaca setiap malam karena menghindarkan dari kemiskinan. Memuat gambaran tentang hari kiamat, pengelompokan manusia menjadi tiga golongan: Sabiqun (yang terdepan), Ashhabul Yamin (golongan kanan), dan Ashhabul Syimal (golongan kiri).",
    ayat: [
      QuranAyat(nomor: 1, arab: 'إِذَا وَقَعَتِ الْوَاقِعَةُ', latin: "Iżā waqa'atil-wāqi'ah", arti: 'Apabila terjadi hari Kiamat.'),
      QuranAyat(nomor: 2, arab: 'لَيْسَ لِوَقْعَتِهَا كَاذِبَةٌ', latin: "Laisa liwaq'atihā kāżibah", arti: 'Tidak ada seorang pun yang dapat mendustakan terjadinya (hari itu).'),
      QuranAyat(nomor: 3, arab: 'خَافِضَةٌ رَّافِعَةٌ', latin: "Khāfiḍatur rāfi'ah", arti: '(Kejadian itu) merendahkan (satu golongan) dan meninggikan (golongan yang lain).'),
      QuranAyat(nomor: 95, arab: 'إِنَّ هَٰذَا لَهُوَ حَقُّ الْيَقِينِ', latin: "Inna hāżā lahuwa ḥaqqul-yaqīn", arti: 'Sungguh, ini adalah suatu keyakinan yang benar.'),
      QuranAyat(nomor: 96, arab: 'فَسَبِّحْ بِاسْمِ رَبِّكَ الْعَظِيمِ', latin: "Fasabbiḥ bismi rabbikal-'aẓīm", arti: 'Maka bertasbihlah dengan (menyebut) nama Tuhanmu Yang Mahaagung.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 67. AL-MULK
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 67,
    nama: 'الملك',
    namaLatin: 'Al-Mulk',
    arti: 'Kerajaan',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 30,
    deskripsi: 'Al-Mulk dikenal sebagai "Al-Mani\'ah" (Pelindung). Membaca surat ini setiap malam akan memberikan syafaat di akhirat. Nabi SAW sangat menganjurkan membacanya setiap malam sebelum tidur. Memuat kebesaran Allah sebagai Penguasa segala kerajaan.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ', latin: "Tabārakallażī biyadihil-mulku wa huwa 'alā kulli syai'in qadīr", arti: 'Mahasuci Allah yang menguasai (segala) kerajaan, dan Dia Mahakuasa atas segala sesuatu.'),
      QuranAyat(nomor: 2, arab: 'الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا', latin: "Allażī khalaqal-mauta wal-ḥayāta liyabluwakum ayyukum aḥsanu 'amalā", arti: 'Yang menciptakan mati dan hidup, untuk menguji kamu, siapa di antara kamu yang lebih baik amalnya. Dan Dia Mahaperkasa, Maha Pengampun.'),
      QuranAyat(nomor: 3, arab: 'الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ', latin: "Allażī khalaqa sab'a samāwātin ṭibāqā, mā tarā fī khalqir-raḥmāni min tafāwut", arti: 'Yang menciptakan tujuh langit berlapis-lapis. Tidak akan kamu lihat sesuatu yang tidak seimbang pada ciptaan Tuhan Yang Maha Pengasih.'),
      QuranAyat(nomor: 15, arab: 'هُوَ الَّذِي جَعَلَ لَكُمُ الْأَرْضَ ذَلُولًا فَامْشُوا فِي مَنَاكِبِهَا وَكُلُوا مِن رِّزْقِهِ', latin: "Huwal-lażī ja'ala lakumul-arḍa żalụlan famsy fī manākibihā wa kulụ mir rizqih", arti: 'Dialah yang menjadikan bumi untuk kamu yang mudah dijelajahi, maka jelajahilah di segala penjurunya dan makanlah sebagian dari rezeki-Nya.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 93. AD-DHUHA
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 93,
    nama: 'الضحى',
    namaLatin: 'Ad-Dhuha',
    arti: 'Waktu Dhuha',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 11,
    deskripsi: 'Surat Ad-Dhuha turun sebagai penghibur bagi Nabi Muhammad SAW ketika wahyu sempat berhenti. Allah menegaskan bahwa Dia tidak meninggalkan Nabi. Surat ini penuh dengan penghiburan dan mengingatkan nikmat-nikmat Allah.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'وَالضُّحَىٰ', latin: "Waḍ-ḍuḥā", arti: 'Demi waktu dhuha (ketika matahari naik sepenggalah).'),
      QuranAyat(nomor: 2, arab: 'وَاللَّيْلِ إِذَا سَجَىٰ', latin: "Wal-laili iżā sajā", arti: 'Dan demi malam apabila telah sunyi.'),
      QuranAyat(nomor: 3, arab: 'مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ', latin: "Mā wadda'aka rabbuka wa mā qalā", arti: 'Tuhanmu tidak meninggalkan engkau (Muhammad) dan tidak (pula) membencimu.'),
      QuranAyat(nomor: 4, arab: 'وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ', latin: "Walal-ākhiratu khairul laka minal-ụlā", arti: 'Dan sungguh, yang kemudian itu lebih baik bagimu dari yang permulaan.'),
      QuranAyat(nomor: 5, arab: 'وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ', latin: "Wa lasaufa yu'ṭīka rabbuka fatarḍā", arti: 'Dan sungguh, kelak Tuhanmu pasti memberikan karunia-Nya kepadamu, sehingga engkau menjadi puas.'),
      QuranAyat(nomor: 6, arab: 'أَلَمْ يَجِدْكَ يَتِيمًا فَآوَىٰ', latin: "Alam yajidka yatīman fa'āwā", arti: 'Bukankah Dia mendapatimu sebagai seorang yatim, lalu Dia melindungi(mu)?'),
      QuranAyat(nomor: 7, arab: 'وَوَجَدَكَ ضَالًّا فَهَدَىٰ', latin: "Wa wajadaka ḍāllan fahadā", arti: 'Dan Dia mendapatimu sebagai seorang yang bingung, lalu Dia memberikan petunjuk.'),
      QuranAyat(nomor: 8, arab: 'وَوَجَدَكَ عَائِلًا فَأَغْنَىٰ', latin: "Wa wajadaka 'ā'ilan fa'agnā", arti: 'Dan Dia mendapatimu sebagai seorang yang kekurangan, lalu Dia memberikan kecukupan.'),
      QuranAyat(nomor: 9, arab: 'فَأَمَّا الْيَتِيمَ فَلَا تَقْهَرْ', latin: "Fa'ammal-yatīma falā taq-har", arti: 'Maka terhadap anak yatim janganlah engkau berlaku sewenang-wenang.'),
      QuranAyat(nomor: 10, arab: 'وَأَمَّا السَّائِلَ فَلَا تَنْهَرْ', latin: "Wa ammas-sā'ila falā tan-har", arti: 'Dan terhadap orang yang meminta-minta janganlah engkau menghardik(nya).'),
      QuranAyat(nomor: 11, arab: 'وَأَمَّا بِنِعْمَةِ رَبِّكَ فَحَدِّثْ', latin: "Wa ammā bini'mati rabbika faḥaddiṡ", arti: 'Dan terhadap nikmat Tuhanmu maka hendaklah engkau menyebut-nyebutnya (bersyukur).'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 94. ASY-SYARH
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 94,
    nama: 'الشرح',
    namaLatin: 'Asy-Syarh',
    arti: 'Kelapangan',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 8,
    deskripsi: 'Surat Asy-Syarh atau Al-Insyirah berisi tentang kelapangan dada yang Allah berikan kepada Nabi Muhammad SAW. Mengandung kabar gembira bahwa setelah kesulitan pasti ada kemudahan.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ', latin: "Alam nasyraḥ laka ṣadrak", arti: 'Bukankah Kami telah melapangkan dadamu (Muhammad)?'),
      QuranAyat(nomor: 2, arab: 'وَوَضَعْنَا عَنكَ وِزْرَكَ', latin: "Wa waḍa'nā 'anka wizrak", arti: 'Dan Kami pun telah menurunkan bebanmu darimu.'),
      QuranAyat(nomor: 3, arab: 'الَّذِي أَنقَضَ ظَهْرَكَ', latin: "Allażī anqaḍa ẓahrak", arti: 'Yang memberatkan punggungmu.'),
      QuranAyat(nomor: 4, arab: 'وَرَفَعْنَا لَكَ ذِكْرَكَ', latin: "Wa rafa'nā laka żikrak", arti: 'Dan Kami tinggikan sebutan (nama)mu bagimu.'),
      QuranAyat(nomor: 5, arab: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا', latin: "Fa inna ma'al-'usri yusrā", arti: 'Maka sesungguhnya beserta kesulitan ada kemudahan.'),
      QuranAyat(nomor: 6, arab: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا', latin: "Inna ma'al-'usri yusrā", arti: 'Sesungguhnya beserta kesulitan itu ada kemudahan.'),
      QuranAyat(nomor: 7, arab: 'فَإِذَا فَرَغْتَ فَانصَبْ', latin: "Fa'iżā faragta fanṣab", arti: 'Maka apabila engkau telah selesai (dari sesuatu urusan), tetaplah bekerja keras (untuk urusan yang lain).'),
      QuranAyat(nomor: 8, arab: 'وَإِلَىٰ رَبِّكَ فَارْغَبْ', latin: "Wa ilā rabbika farġab", arti: 'Dan hanya kepada Tuhanmulah engkau berharap.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 112. AL-IKHLAS
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 112,
    nama: 'الإخلاص',
    namaLatin: 'Al-Ikhlas',
    arti: 'Ikhlas',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 4,
    deskripsi: 'Al-Ikhlas setara dengan sepertiga Al-Quran. Surat ini memuat inti akidah Islam yaitu keesaan Allah (Tauhid). Membacanya tiga kali setara dengan membaca seluruh Al-Quran. Surat ini menjadi pondasi keimanan seorang Muslim.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'قُلْ هُوَ اللَّهُ أَحَدٌ', latin: "Qul huwallāhu aḥad", arti: 'Katakanlah (Muhammad), "Dialah Allah, Yang Maha Esa."'),
      QuranAyat(nomor: 2, arab: 'اللَّهُ الصَّمَدُ', latin: "Allāhuṣ-ṣamad", arti: 'Allah tempat meminta segala sesuatu.'),
      QuranAyat(nomor: 3, arab: 'لَمْ يَلِدْ وَلَمْ يُولَدْ', latin: "Lam yalid wa lam yụlad", arti: '(Allah) tidak beranak dan tidak pula diperanakkan.'),
      QuranAyat(nomor: 4, arab: 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ', latin: "Wa lam yakul lahū kufuwan aḥad", arti: 'Dan tidak ada sesuatu yang setara dengan Dia.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 113. AL-FALAQ
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 113,
    nama: 'الفلق',
    namaLatin: 'Al-Falaq',
    arti: 'Waktu Subuh',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 5,
    deskripsi: 'Al-Falaq adalah surat perlindungan yang diajarkan Nabi SAW untuk dibaca setiap pagi dan petang. Surat ini memohon perlindungan Allah dari kejahatan makhluk-Nya, kegelapan malam, dan sihir.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ', latin: "Qul a'ụżu birabbil-falaq", arti: 'Katakanlah, "Aku berlindung kepada Tuhan yang menguasai subuh (fajar)."'),
      QuranAyat(nomor: 2, arab: 'مِن شَرِّ مَا خَلَقَ', latin: "Min syarri mā khalaq", arti: 'Dari kejahatan (makhluk yang) Dia ciptakan.'),
      QuranAyat(nomor: 3, arab: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ', latin: "Wa min syarri gāsiqin iżā waqab", arti: 'Dan dari kejahatan malam apabila telah gelap gulita.'),
      QuranAyat(nomor: 4, arab: 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ', latin: "Wa min syarrin-naffāṡāti fil-'uqad", arti: 'Dan dari kejahatan (perempuan-perempuan) penyihir yang meniup pada buhul-buhul (talinya).'),
      QuranAyat(nomor: 5, arab: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ', latin: "Wa min syarri ḥāsidin iżā ḥasad", arti: 'Dan dari kejahatan orang yang dengki apabila dia dengki.'),
    ],
  ),

  // ══════════════════════════════════════════════════
  // 114. AN-NAS
  // ══════════════════════════════════════════════════
  QuranSurah(
    nomor: 114,
    nama: 'الناس',
    namaLatin: 'An-Nas',
    arti: 'Manusia',
    tempatTurun: 'Makkiyah',
    jumlahAyat: 6,
    deskripsi: 'An-Nas adalah surat terakhir dalam Al-Quran. Merupakan surat perlindungan dari bisikan setan, baik dari golongan jin maupun manusia. Dibaca bersama Al-Falaq dan Al-Ikhlas setiap pagi, petang, dan sebelum tidur.',
    ayat: [
      QuranAyat(nomor: 1, arab: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ', latin: "Qul a'ụżu birabbin-nās", arti: 'Katakanlah, "Aku berlindung kepada Tuhannya manusia."'),
      QuranAyat(nomor: 2, arab: 'مَلِكِ النَّاسِ', latin: "Malikin-nās", arti: 'Raja manusia.'),
      QuranAyat(nomor: 3, arab: 'إِلَٰهِ النَّاسِ', latin: "Ilāhin-nās", arti: 'Sembahan manusia.'),
      QuranAyat(nomor: 4, arab: 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ', latin: "Min syarril-waswāsil-khannās", arti: 'Dari kejahatan (bisikan) setan yang bersembunyi.'),
      QuranAyat(nomor: 5, arab: 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ', latin: "Allażī yuwaswisu fī ṣudụrin-nās", arti: 'Yang membisikkan (kejahatan) ke dalam dada manusia.'),
      QuranAyat(nomor: 6, arab: 'مِنَ الْجِنَّةِ وَالنَّاسِ', latin: "Minal-jinnati wan-nās", arti: 'Dari (golongan) jin dan manusia.'),
    ],
  ),
];

// ─── Halaman Utama Al-Quran ───────────────────────────────────────────────────
class AllQuranPage extends StatefulWidget {
  const AllQuranPage({super.key});

  @override
  State<AllQuranPage> createState() => _AllQuranPageState();
}

class _AllQuranPageState extends State<AllQuranPage>
    with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  late Animation<Offset> _headerSlide;

  String _search = '';
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
    _headerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _headerFade = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide = Tween<Offset>(begin: const Offset(0, -0.3), end: Offset.zero)
        .animate(CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _headerCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  List<QuranSurah> get _filtered {
    if (_search.isEmpty) return allQuranSurah;
    final q = _search.toLowerCase();
    return allQuranSurah.where((s) =>
      s.namaLatin.toLowerCase().contains(q) ||
      s.arti.toLowerCase().contains(q) ||
      s.nomor.toString().contains(q)
    ).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _QC.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _QuranBg(controller: _bgCtrl)),
          SafeArea(
            child: Column(
              children: [
                // ── Header
                SlideTransition(
                  position: _headerSlide,
                  child: FadeTransition(
                    opacity: _headerFade,
                    child: _buildHeader(context),
                  ),
                ),
                // ── Search
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: _buildSearch(),
                ),
                // ── List
                Expanded(
                  child: _filtered.isEmpty
                    ? _buildEmpty()
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                        itemCount: _filtered.length,
                        itemBuilder: (ctx, i) => _SurahCard(
                          surah: _filtered[i],
                          onTap: () => _openSurah(_filtered[i]),
                        ),
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: _QC.surface,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: _QC.border),
              ),
              child: const Icon(Icons.arrow_back_ios_rounded, color: _QC.gold, size: 18),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (r) => _QC.goldGrad.createShader(r),
                  child: const Text(
                    'Al-Quran Al-Karim',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                Text(
                  '${allQuranSurah.length} Surat Pilihan',
                  style: const TextStyle(color: _QC.textSub, fontSize: 12),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: _QC.goldGrad,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Icon(Icons.menu_book_rounded, color: Colors.black, size: 20),
          ),
        ],
      ),
    );
  }

  Widget _buildSearch() {
    return Container(
      decoration: BoxDecoration(
        color: _QC.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _QC.border),
      ),
      child: TextField(
        controller: _searchCtrl,
        onChanged: (v) => setState(() => _search = v),
        style: const TextStyle(color: _QC.text, fontSize: 14),
        decoration: const InputDecoration(
          hintText: 'Cari surat...',
          hintStyle: TextStyle(color: _QC.textSub),
          prefixIcon: Icon(Icons.search_rounded, color: _QC.gold, size: 20),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.search_off_rounded, color: _QC.textDim, size: 48),
          const SizedBox(height: 12),
          Text('Surat "$_search" tidak ditemukan',
              style: const TextStyle(color: _QC.textSub, fontSize: 14)),
        ],
      ),
    );
  }

  void _openSurah(QuranSurah surah) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => SurahDetailPage(surah: surah),
    ));
  }
}

// ─── Card Surat ───────────────────────────────────────────────────────────────
class _SurahCard extends StatelessWidget {
  final QuranSurah surah;
  final VoidCallback onTap;

  const _SurahCard({required this.surah, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _QC.card,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _QC.border),
        ),
        child: Row(
          children: [
            // Nomor
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                gradient: _QC.goldGrad,
                borderRadius: BorderRadius.circular(22),
              ),
              child: Center(
                child: Text(
                  '${surah.nomor}',
                  style: const TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(surah.namaLatin,
                      style: const TextStyle(
                          color: _QC.text, fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(surah.arti,
                      style: const TextStyle(color: _QC.textSub, fontSize: 12)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      _badge(surah.tempatTurun, _QC.teal),
                      const SizedBox(width: 6),
                      _badge('${surah.jumlahAyat} Ayat', _QC.gold),
                    ],
                  ),
                ],
              ),
            ),
            // Arab
            Text(
              surah.nama,
              style: const TextStyle(
                color: _QC.gold,
                fontSize: 22,
                fontFamily: 'serif',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600)),
    );
  }
}

// ─── Halaman Detail Surat ─────────────────────────────────────────────────────
class SurahDetailPage extends StatefulWidget {
  final QuranSurah surah;
  const SurahDetailPage({super.key, required this.surah});

  @override
  State<SurahDetailPage> createState() => _SurahDetailPageState();
}

class _SurahDetailPageState extends State<SurahDetailPage>
    with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  bool _showLatin = true;
  bool _showArti = true;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.surah;
    return Scaffold(
      backgroundColor: _QC.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _QuranBg(controller: _bgCtrl)),
          SafeArea(
            child: Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 40, height: 40,
                          decoration: BoxDecoration(
                            color: _QC.surface,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: _QC.border),
                          ),
                          child: const Icon(Icons.arrow_back_ios_rounded, color: _QC.gold, size: 18),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ShaderMask(
                              shaderCallback: (r) => _QC.goldGrad.createShader(r),
                              child: Text(s.namaLatin,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold)),
                            ),
                            Text(s.arti,
                                style: const TextStyle(color: _QC.textSub, fontSize: 12)),
                          ],
                        ),
                      ),
                      // Toggle Latin
                      _toggleBtn(
                        icon: Icons.translate_rounded,
                        active: _showLatin,
                        onTap: () => setState(() => _showLatin = !_showLatin),
                      ),
                      const SizedBox(width: 6),
                      // Toggle Arti
                      _toggleBtn(
                        icon: Icons.subtitles_rounded,
                        active: _showArti,
                        onTap: () => setState(() => _showArti = !_showArti),
                      ),
                    ],
                  ),
                ),

                // Info Banner
                _buildInfoBanner(s),

                // Ayat List
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    itemCount: s.ayat.length,
                    itemBuilder: (ctx, i) => _AyatCard(
                      ayat: s.ayat[i],
                      showLatin: _showLatin,
                      showArti: _showArti,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _toggleBtn({required IconData icon, required bool active, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          color: active ? _QC.gold.withOpacity(0.2) : _QC.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: active ? _QC.gold : _QC.border),
        ),
        child: Icon(icon, color: active ? _QC.gold : _QC.textSub, size: 16),
      ),
    );
  }

  Widget _buildInfoBanner(QuranSurah s) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0A1F0A), Color(0xFF0F2F1A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _QC.gold.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(
            s.nama,
            style: const TextStyle(color: _QC.gold, fontSize: 28, fontFamily: 'serif'),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            s.deskripsi,
            style: const TextStyle(color: _QC.textSub, fontSize: 12, height: 1.6),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _infoPill(Icons.location_on_rounded, s.tempatTurun),
              const SizedBox(width: 8),
              _infoPill(Icons.format_list_numbered_rounded, '${s.jumlahAyat} Ayat'),
              const SizedBox(width: 8),
              _infoPill(Icons.tag_rounded, 'Surat ke-${s.nomor}'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoPill(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _QC.gold.withOpacity(0.12),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _QC.gold.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _QC.gold, size: 12),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(color: _QC.gold, fontSize: 11, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

// ─── Card Ayat ────────────────────────────────────────────────────────────────
class _AyatCard extends StatelessWidget {
  final QuranAyat ayat;
  final bool showLatin;
  final bool showArti;

  const _AyatCard({required this.ayat, required this.showLatin, required this.showArti});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _QC.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _QC.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Nomor ayat
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: _QC.surface,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            ),
            child: Row(
              children: [
                Container(
                  width: 28, height: 28,
                  decoration: BoxDecoration(
                    gradient: _QC.goldGrad,
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Center(
                    child: Text('${ayat.nomor}',
                        style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 12)),
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: '${ayat.arab}\n${ayat.latin}\n${ayat.arti}'));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Ayat disalin!'),
                        backgroundColor: _QC.green,
                        duration: Duration(seconds: 1),
                      ),
                    );
                  },
                  child: const Icon(Icons.copy_rounded, color: _QC.textSub, size: 16),
                ),
              ],
            ),
          ),
          // Arab
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
            child: Text(
              ayat.arab,
              style: const TextStyle(
                color: _QC.goldLight,
                fontSize: 24,
                height: 1.8,
                fontFamily: 'serif',
              ),
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
            ),
          ),
          // Latin
          if (showLatin)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
              child: Text(
                ayat.latin,
                style: const TextStyle(
                  color: _QC.teal,
                  fontSize: 13,
                  fontStyle: FontStyle.italic,
                  height: 1.5,
                ),
              ),
            ),
          // Arti
          if (showArti)
            Container(
              margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _QC.gold.withOpacity(0.06),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: _QC.gold.withOpacity(0.15)),
              ),
              child: Text(
                '"${ayat.arti}"',
                style: const TextStyle(color: _QC.text, fontSize: 13, height: 1.6),
              ),
            ),
        ],
      ),
    );
  }
}

// ─── Animated Background ──────────────────────────────────────────────────────
class _QuranBg extends StatelessWidget {
  final AnimationController controller;
  const _QuranBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return CustomPaint(
          painter: _QuranBgPainter(controller.value),
        );
      },
    );
  }
}

class _QuranBgPainter extends CustomPainter {
  final double t;
  _QuranBgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();

    // Base
    paint.color = const Color(0xFF060B14);
    canvas.drawRect(Offset.zero & size, paint);

    // Orb 1 - gold
    paint.shader = RadialGradient(
      colors: [const Color(0xFFD4AF37).withOpacity(0.08), Colors.transparent],
    ).createShader(Rect.fromCircle(
      center: Offset(
        size.width * (0.2 + 0.1 * math.sin(t * 2 * math.pi)),
        size.height * (0.2 + 0.05 * math.cos(t * 2 * math.pi)),
      ),
      radius: size.width * 0.5,
    ));
    canvas.drawCircle(
      Offset(size.width * 0.2, size.height * 0.2),
      size.width * 0.5,
      paint,
    );

    // Orb 2 - green
    paint.shader = RadialGradient(
      colors: [const Color(0xFF059669).withOpacity(0.06), Colors.transparent],
    ).createShader(Rect.fromCircle(
      center: Offset(size.width * 0.8, size.height * 0.7),
      radius: size.width * 0.4,
    ));
    canvas.drawCircle(Offset(size.width * 0.8, size.height * 0.7), size.width * 0.4, paint);
  }

  @override
  bool shouldRepaint(_QuranBgPainter old) => old.t != t;
}
