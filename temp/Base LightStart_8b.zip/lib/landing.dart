import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'main.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  late AnimationController _auroraCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _floatCtrl;
  late AnimationController _shimmerCtrl;
  late AnimationController _glowCtrl;

  late Animation<double> _fade;
  late Animation<Offset>  _slideUp;
  late Animation<double>  _float;
  late Animation<double>  _shimmer;
  late Animation<double>  _glow;

  @override
  void initState() {
    super.initState();

    _auroraCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
    _floatCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 3200))..repeat(reverse: true);
    _shimmerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))..repeat();
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);

    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slideUp = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic));
    _float = Tween<double>(begin: -6.0, end: 6.0)
        .animate(CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut));
    _shimmer = Tween<double>(begin: -1.0, end: 2.5).animate(
        CurvedAnimation(parent: _shimmerCtrl, curve: Curves.linear));
    _glow = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    Future.delayed(const Duration(milliseconds: 150), () {
      if (mounted) _entranceCtrl.forward();
    });
  }

  @override
  void dispose() {
    _auroraCtrl.dispose();
    _entranceCtrl.dispose();
    _floatCtrl.dispose();
    _shimmerCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _launch(String url) async {
    final u = Uri.parse(url);
    if (await canLaunchUrl(u)) await launchUrl(u, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(children: [
        // Aurora background
        AnimatedBuilder(
          animation: _auroraCtrl,
          builder: (_, __) => CustomPaint(
            painter: _AuroraPainter(_auroraCtrl.value),
            child: const SizedBox.expand(),
          ),
        ),
        // Main
        SafeArea(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slideUp,
              child: Column(children: [
                _buildTopBar(),
                Expanded(child: _buildBody()),
                _buildBottom(),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildTopBar() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(children: [
          AnimatedBuilder(
            animation: _glowCtrl,
            builder: (_, __) => Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.success,
                boxShadow: [
                  BoxShadow(color: AppColors.success.withOpacity(0.6 * _glow.value), blurRadius: 10, spreadRadius: 2),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          const Text('SYSTEM ONLINE', style: TextStyle(
            fontFamily: 'Orbitron', fontSize: 9,
            color: AppColors.success, letterSpacing: 2.5,
          )),
        ]),
        _GlassChip(label: 'V10', color: AppColors.cyanDim),
      ],
    ),
  );

  Widget _buildBody() => SingleChildScrollView(
    physics: const BouncingScrollPhysics(),
    padding: const EdgeInsets.symmetric(horizontal: 22),
    child: Column(children: [
      const SizedBox(height: 36),
      // Floating logo
      AnimatedBuilder(
        animation: _floatCtrl,
        builder: (_, child) => Transform.translate(
          offset: Offset(0, _float.value),
          child: child,
        ),
        child: AnimatedBuilder(
          animation: _glowCtrl,
          builder: (_, child) => Container(
            width: 112, height: 112,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFF1A2040), Color(0xFF0D1230)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: AppColors.cyan.withOpacity(0.4 + 0.3 * _glow.value),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.cyan.withOpacity(0.3 * _glow.value),
                  blurRadius: 40, spreadRadius: 4,
                ),
                BoxShadow(
                  color: AppColors.violet.withOpacity(0.2 * _glow.value),
                  blurRadius: 60, spreadRadius: 8,
                ),
              ],
            ),
            child: child,
          ),
          child: ClipOval(
            child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
          ),
        ),
      ),
      const SizedBox(height: 28),
      // Title gradient
      ShaderMask(
        shaderCallback: (b) => const LinearGradient(
          colors: [Color(0xFF00E5FF), Color(0xFFBB86FC), Color(0xFF00E5FF)],
          stops: [0.0, 0.5, 1.0],
        ).createShader(b),
        child: const Text(
          '𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧',
          style: TextStyle(
            fontFamily: 'Orbitron', fontSize: 38,
            fontWeight: FontWeight.w900, color: Colors.white,
            letterSpacing: 8,
          ),
        ),
      ),
      const SizedBox(height: 6),
      const Text(
        'PROJECT  V10',
        style: TextStyle(
          fontFamily: 'Orbitron', fontSize: 10,
          color: AppColors.textSub, letterSpacing: 5,
        ),
      ),
      const SizedBox(height: 12),
      // Divider glow
      Container(
        height: 1,
        margin: const EdgeInsets.symmetric(horizontal: 30),
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [
            Colors.transparent, AppColors.cyan, AppColors.violetBright, Colors.transparent,
          ]),
        ),
      ),
      const SizedBox(height: 20),
      // Tagline glass card
      _GlassCard(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
        child: const Text(
          'PREMIUM · POWERFUL · GACORR',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'ShareTechMono', fontSize: 11,
            color: AppColors.textSub, letterSpacing: 2.5,
          ),
        ),
      ),
      const SizedBox(height: 32),
      // Feature pills
      Wrap(
        alignment: WrapAlignment.center,
        spacing: 8, runSpacing: 8,
        children: const [
          _AuroraPill(icon: Icons.smart_toy_rounded,      label: 'AI POWERED',   colors: [Color(0xFF7C3AED), Color(0xFF9D5CF6)]),
          _AuroraPill(icon: Icons.security_rounded,       label: 'SECURITY',     colors: [Color(0xFF00B4CC), Color(0xFF00E5FF)]),
          _AuroraPill(icon: Icons.gamepad_rounded,        label: 'GAME ZONE',    colors: [Color(0xFF00C853), Color(0xFF00E676)]),
          _AuroraPill(icon: Icons.analytics_rounded,      label: 'ANALYTICS',    colors: [Color(0xFFFFAB00), Color(0xFFFFD700)]),
          _AuroraPill(icon: Icons.movie_rounded,          label: 'HIBURAN',      colors: [Color(0xFFE91E63), Color(0xFFFF4081)]),
          _AuroraPill(icon: Icons.bug_report_rounded,     label: 'BUG TOOLS',    colors: [Color(0xFFFF1744), Color(0xFFFF5252)]),
          _AuroraPill(icon: Icons.phone_android_rounded,  label: 'RAT CONTROL',  colors: [Color(0xFF00E5FF), Color(0xFF9D5CF6)]),
        ],
      ),
      const SizedBox(height: 36),
      // CTA Primary
      AnimatedBuilder(
        animation: _shimmerCtrl,
        builder: (_, __) => _ShimmerButton(
          label: 'MASUK SEKARANG',
          icon: Icons.login_rounded,
          shimmerValue: _shimmer.value,
          onTap: () => Navigator.pushNamed(context, '/login'),
        ),
      ),
      const SizedBox(height: 12),
      // CTA Ghost
      _GhostButton(
        label: 'INFO & PANDUAN',
        icon: Icons.info_outline_rounded,
        onTap: () => _launch('https://t.me/@kizz_Real05'),
      ),
      const SizedBox(height: 28),
      // Stats
      Row(children: [
        Expanded(child: _AuroraStatCard(value: '999+', label: 'USERS',    icon: Icons.people_rounded,      grad: const [Color(0xFF00B4CC), Color(0xFF00E5FF)])),
        const SizedBox(width: 10),
        Expanded(child: _AuroraStatCard(value: '50+',  label: 'FEATURES', icon: Icons.auto_awesome_rounded, grad: const [Color(0xFF7C3AED), Color(0xFF9D5CF6)])),
        const SizedBox(width: 10),
        Expanded(child: _AuroraStatCard(value: '24/7', label: 'ACTIVE',   icon: Icons.bolt_rounded,         grad: const [Color(0xFF00C853), Color(0xFF00E676)])),
      ]),
      const SizedBox(height: 16),
    ]),
  );

  Widget _buildBottom() => Padding(
    padding: const EdgeInsets.fromLTRB(22, 8, 22, 24),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _SocialBtn(icon: FontAwesomeIcons.telegram,  color: const Color(0xFF2AABEE), onTap: () => _launch('https://t.me/@kizz_Real05')),
        const SizedBox(width: 18),
        _SocialBtn(icon: FontAwesomeIcons.whatsapp,  color: const Color(0xFF25D366), onTap: () => _launch('https://wa.me/62')),
        const SizedBox(width: 18),
        _SocialBtn(icon: FontAwesomeIcons.instagram, color: const Color(0xFFE1306C), onTap: () => _launch('https://instagram.com')),
      ],
    ),
  );
}

// ── Shimmer CTA Button ────────────────────────────────────────
class _ShimmerButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final double shimmerValue;
  final VoidCallback onTap;
  const _ShimmerButton({required this.label, required this.icon, required this.shimmerValue, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: double.infinity, height: 56,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(
          colors: [Color(0xFF00B4CC), Color(0xFF00E5FF), Color(0xFF007A8A)],
        ),
        boxShadow: [
          BoxShadow(color: AppColors.cyan.withOpacity(0.45), blurRadius: 28, offset: const Offset(0, 8)),
          BoxShadow(color: AppColors.cyan.withOpacity(0.15), blurRadius: 60, offset: const Offset(0, 4)),
        ],
      ),
      child: Stack(alignment: Alignment.center, children: [
        // Shimmer overlay
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: ShaderMask(
            shaderCallback: (b) => LinearGradient(
              begin: Alignment(shimmerValue - 1, 0),
              end: Alignment(shimmerValue, 0),
              colors: [Colors.transparent, Colors.white.withOpacity(0.18), Colors.transparent],
            ).createShader(b),
            child: Container(color: Colors.white),
          ),
        ),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 20, color: AppColors.bg),
          const SizedBox(width: 10),
          Text(label, style: const TextStyle(
            fontFamily: 'Orbitron', fontSize: 13,
            fontWeight: FontWeight.w800, color: AppColors.bg, letterSpacing: 2,
          )),
        ]),
      ]),
    ),
  );
}

// ── Ghost Button ─────────────────────────────────────────────
class _GhostButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _GhostButton({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: double.infinity, height: 54,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderGlow, width: 1.5),
        color: AppColors.surface.withOpacity(0.5),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 18, color: AppColors.textSub),
        const SizedBox(width: 9),
        Text(label, style: const TextStyle(
          fontFamily: 'Orbitron', fontSize: 12,
          fontWeight: FontWeight.w700, color: AppColors.textSub, letterSpacing: 1.5,
        )),
      ]),
    ),
  );
}

// ── Glass Card ────────────────────────────────────────────────
class _GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  const _GlassCard({required this.child, this.padding});

  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(14),
      color: const Color(0xFF0C0F1E).withOpacity(0.8),
      border: Border.all(color: AppColors.borderGlow, width: 1),
      boxShadow: [
        BoxShadow(color: AppColors.cyan.withOpacity(0.04), blurRadius: 20),
      ],
    ),
    child: child,
  );
}

// ── Glass Chip ────────────────────────────────────────────────
class _GlassChip extends StatelessWidget {
  final String label;
  final Color color;
  const _GlassChip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      color: color.withOpacity(0.1),
      border: Border.all(color: color.withOpacity(0.3)),
    ),
    child: Text(label, style: TextStyle(
      fontFamily: 'Orbitron', fontSize: 10, color: color, letterSpacing: 1.5,
    )),
  );
}

// ── Aurora Pill ───────────────────────────────────────────────
class _AuroraPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final List<Color> colors;
  const _AuroraPill({required this.icon, required this.label, required this.colors});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(30),
      gradient: LinearGradient(
        colors: [colors[0].withOpacity(0.12), colors[1].withOpacity(0.06)],
      ),
      border: Border.all(color: colors[0].withOpacity(0.35), width: 1),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      ShaderMask(
        shaderCallback: (b) => LinearGradient(colors: colors).createShader(b),
        child: Icon(icon, size: 13, color: Colors.white),
      ),
      const SizedBox(width: 6),
      ShaderMask(
        shaderCallback: (b) => LinearGradient(colors: colors).createShader(b),
        child: Text(label, style: const TextStyle(
          fontFamily: 'Orbitron', fontSize: 9,
          color: Colors.white, letterSpacing: 1.2, fontWeight: FontWeight.w700,
        )),
      ),
    ]),
  );
}

// ── Aurora Stat Card ─────────────────────────────────────────
class _AuroraStatCard extends StatelessWidget {
  final String value, label;
  final IconData icon;
  final List<Color> grad;
  const _AuroraStatCard({required this.value, required this.label, required this.icon, required this.grad});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 16),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(16),
      gradient: LinearGradient(
        colors: [grad[0].withOpacity(0.12), grad[1].withOpacity(0.04)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      border: Border.all(color: grad[0].withOpacity(0.25), width: 1),
      boxShadow: [
        BoxShadow(color: grad[0].withOpacity(0.08), blurRadius: 16),
      ],
    ),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      ShaderMask(
        shaderCallback: (b) => LinearGradient(colors: grad).createShader(b),
        child: Icon(icon, size: 20, color: Colors.white),
      ),
      const SizedBox(height: 7),
      ShaderMask(
        shaderCallback: (b) => LinearGradient(colors: grad).createShader(b),
        child: Text(value, style: const TextStyle(
          fontFamily: 'Orbitron', fontSize: 17,
          fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1,
        )),
      ),
      const SizedBox(height: 3),
      Text(label, style: const TextStyle(
        fontFamily: 'ShareTechMono', fontSize: 9,
        color: AppColors.textSub, letterSpacing: 2,
      )),
    ]),
  );
}

// ── Social Button ─────────────────────────────────────────────
class _SocialBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _SocialBtn({required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 48, height: 48,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withOpacity(0.1),
        border: Border.all(color: color.withOpacity(0.35), width: 1),
        boxShadow: [BoxShadow(color: color.withOpacity(0.2), blurRadius: 14)],
      ),
      child: Icon(icon, size: 20, color: color),
    ),
  );
}

// ── Aurora Painter ────────────────────────────────────────────
class _AuroraPainter extends CustomPainter {
  final double t;
  _AuroraPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final a = t * 2 * math.pi;
    final cx = size.width / 2;

    // Base
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..shader = const LinearGradient(
        colors: [Color(0xFF03040A), Color(0xFF060811), Color(0xFF080D18)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    // Aurora blobs
    void _blob(double ox, double oy, double r, Color c) {
      canvas.drawCircle(
        Offset(ox, oy), r,
        Paint()..shader = RadialGradient(
          colors: [c, Colors.transparent],
        ).createShader(Rect.fromCircle(center: Offset(ox, oy), radius: r)),
      );
    }

    _blob(cx + math.cos(a) * 70, size.height * 0.18 + math.sin(a) * 30, 240,
        AppColors.violet.withOpacity(0.09));
    _blob(cx - math.cos(a * 0.7) * 50, size.height * 0.5 + math.sin(a * 0.5) * 40, 180,
        AppColors.cyan.withOpacity(0.06));
    _blob(cx + math.cos(a * 0.4) * 40, size.height * 0.82 + math.sin(a) * 20, 200,
        AppColors.violetBright.withOpacity(0.05));

    // Dot grid
    final dot = Paint()..color = AppColors.cyan.withOpacity(0.018);
    const s = 30.0;
    for (double x = 0; x < size.width; x += s) {
      for (double y = 0; y < size.height; y += s) {
        canvas.drawCircle(Offset(x, y), 1, dot);
      }
    }
  }

  @override
  bool shouldRepaint(_AuroraPainter old) => old.t != t;
}
