import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────────────────────────────────────
// WORDLE INDONESIA — Tebak 5 Huruf
// ─────────────────────────────────────────────────────────────────────────────

class WordleGamePage extends StatefulWidget {
  const WordleGamePage({super.key});
  @override
  State<WordleGamePage> createState() => _WordleGamePageState();
}

class _WordleGamePageState extends State<WordleGamePage> with TickerProviderStateMixin {
  static const _wordList = [
    'MAKAN','MINUM','TIDUR','JALAN','RUMAH','BUNGA','POHON','ANGIN',
    'HUJAN','PANAS','DINGIN','SIANG','MALAM','PAGI','SENJA','BUKU',
    'TULIS','BACA','PIKIR','RASA','CINTA','RINDU','SAYANG','KASIH',
    'PERGI','PULANG','DATANG','DUDUK','BERDIRI','LARI','TERBANG',
    'BESAR','KECIL','TINGGI','RENDAH','TERANG','GELAP','KERAS','LUNAK',
    'MANIS','PAHIT','ASAM','ASIN','PEDAS','HAMBAR','CANTIK','BAGUS',
    'INDAH','JELEK','BAIK','JAHAT','BENAR','SALAH','TEPAT','CEPAT',
  ];

  static const _fiveLetterWords = [
    'MAKAN','MINUM','TIDUR','JALAN','RUMAH','BUNGA','POHON','ANGIN',
    'HUJAN','PANAS','SIANG','MALAM','BUKU','TULIS','BACA','PIKIR',
    'RASA','CINTA','RINDU','SAYANG','KASIH','PERGI','BESAR','KECIL',
    'TINGGI','TERANG','GELAP','KERAS','LUNAK','MANIS','PAHIT','ASAM',
    'ASIN','PEDAS','CANTIK','BAGUS','INDAH','JELEK','BAIK','BENAR',
    'SALAH','TEPAT','CEPAT','BUMI','LANGIT','LAUT','SUNGAI','GUNUNG',
    'HUTAN','PADANG','PANTAI','PASIR','BATU','TANAH','AIR','API',
  ];

  late String _targetWord;
  late List<String> _guesses;
  late String _currentGuess;
  bool _gameOver = false;
  bool _won = false;
  int _currentRow = 0;
  Map<String, Color> _letterColors = {};

  late AnimationController _shakeCtrl;
  late AnimationController _bounceCtrl;

  @override
  void initState() {
    super.initState();
    _shakeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _bounceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _startGame();
  }

  @override
  void dispose() {
    _shakeCtrl.dispose();
    _bounceCtrl.dispose();
    super.dispose();
  }

  void _startGame() {
    final fives = _fiveLetterWords.where((w) => w.length == 5).toList();
    _targetWord = fives[Random().nextInt(fives.length)];
    _guesses = List.filled(6, '');
    _currentGuess = '';
    _gameOver = false;
    _won = false;
    _currentRow = 0;
    _letterColors = {};
    setState(() {});
  }

  void _onKey(String key) {
    if (_gameOver) return;
    if (key == 'DEL') {
      if (_currentGuess.isNotEmpty) {
        setState(() => _currentGuess = _currentGuess.substring(0, _currentGuess.length - 1));
      }
    } else if (key == 'ENTER') {
      _submitGuess();
    } else if (_currentGuess.length < 5) {
      setState(() => _currentGuess += key);
    }
  }

  void _submitGuess() {
    if (_currentGuess.length != 5) {
      _shakeCtrl.forward(from: 0);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Masukkan 5 huruf dulu!'),
          duration: Duration(seconds: 1), backgroundColor: Color(0xFF374151)),
      );
      return;
    }

    setState(() {
      _guesses[_currentRow] = _currentGuess;
      // Update letter colors
      for (int i = 0; i < 5; i++) {
        final letter = _currentGuess[i];
        if (_targetWord[i] == letter) {
          _letterColors[letter] = Color(0xFF00E676);
        } else if (_targetWord.contains(letter)) {
          if (_letterColors[letter] != Color(0xFF00E676)) {
            _letterColors[letter] = Color(0xFFFFAB00);
          }
        } else {
          _letterColors[letter] ??= const Color(0xFF374151);
        }
      }

      if (_currentGuess == _targetWord) {
        _won = true;
        _gameOver = true;
      } else if (_currentRow == 5) {
        _gameOver = true;
      }

      _currentRow++;
      _currentGuess = '';
    });
  }

  Color _cellColor(int row, int col) {
    if (row >= _currentRow) return const Color(0xFF1F2937);
    final guess = _guesses[row];
    if (guess.isEmpty) return const Color(0xFF1F2937);
    final letter = guess[col];
    if (_targetWord[col] == letter) return Color(0xFF00E676);
    if (_targetWord.contains(letter)) return Color(0xFFFFAB00);
    return const Color(0xFF374151);
  }

  Color _cellBorder(int row, int col) {
    if (row == _currentRow && col < _currentGuess.length) return const Color(0xFF9CA3AF);
    if (row < _currentRow) return Colors.transparent;
    return const Color(0xFF374151);
  }

  String _cellLetter(int row, int col) {
    if (row == _currentRow && col < _currentGuess.length) return _currentGuess[col];
    if (row < _currentRow && _guesses[row].isNotEmpty) return _guesses[row][col];
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF111827),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F172A),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('🟩 WORDLE', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 22, letterSpacing: 2)),
        actions: [
          TextButton(onPressed: () => setState(_startGame),
            child: const Text('New', style: TextStyle(color: const Color(0xFF00E676), fontWeight: FontWeight.w700))),
        ],
      ),
      body: Column(children: [
        if (_gameOver)
          AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            color: _won ? const Color(0xFF166534) : const Color(0xFF7F1D1D),
            child: Row(children: [
              Text(_won ? '🎉 Benar! Kata: $_targetWord' : '❌ Jawaban: $_targetWord',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              const Spacer(),
              GestureDetector(
                onTap: () => setState(_startGame),
                child: const Text('Main Lagi →',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
              ),
            ]),
          ),
        // Grid
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(6, (row) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (col) {
                    final letter = _cellLetter(row, col);
                    final revealed = row < _currentRow;
                    return AnimatedContainer(
                      duration: Duration(milliseconds: revealed ? 200 + col * 100 : 50),
                      width: 52, height: 52,
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      decoration: BoxDecoration(
                        color: _cellColor(row, col),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _cellBorder(row, col), width: 2),
                      ),
                      child: Center(
                        child: Text(letter,
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: letter.isEmpty ? 0 : 22,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              )),
            ),
          ),
        ),
        // Keyboard
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 0, 8, 16),
          child: Column(children: [
            _keyRow(['Q','W','E','R','T','Y','U','I','O','P']),
            const SizedBox(height: 6),
            _keyRow(['A','S','D','F','G','H','J','K','L']),
            const SizedBox(height: 6),
            _keyRow(['ENTER','Z','X','C','V','B','N','M','DEL']),
          ]),
        ),
      ]),
    );
  }

  Widget _keyRow(List<String> keys) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: keys.map((k) {
        final isWide = k == 'ENTER' || k == 'DEL';
        Color bg = _letterColors[k] ?? const Color(0xFF374151);
        return GestureDetector(
          onTap: () => _onKey(k),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: isWide ? 56 : 32,
            height: 44,
            margin: const EdgeInsets.symmetric(horizontal: 2),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Center(
              child: Text(k == 'DEL' ? '⌫' : k,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: isWide ? 10 : 13,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
