import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────────────────────────────────────
// FLAPPY BIRD GAME
// ─────────────────────────────────────────────────────────────────────────────

class FlappyBirdPage extends StatefulWidget {
  const FlappyBirdPage({super.key});
  @override
  State<FlappyBirdPage> createState() => _FlappyBirdPageState();
}

class _FlappyBirdPageState extends State<FlappyBirdPage>
    with SingleTickerProviderStateMixin {
  // ── Constants ───────────────────────────────────────────────────────────
  static const double _gravity     = 0.45;
  static const double _jumpForce   = -8.5;
  static const double _pipeWidth   = 60.0;
  static const double _pipeGap     = 170.0;
  static const double _pipeSpeed   = 3.2;
  static const double _birdX       = 0.25; // fraction of screen width
  static const double _birdSize    = 36.0;

  // ── State ────────────────────────────────────────────────────────────────
  double _birdY      = 0.0; // pixels from top
  double _velocity   = 0.0;
  int    _score      = 0;
  int    _bestScore  = 0;
  bool   _isRunning  = false;
  bool   _isDead     = false;
  bool   _started    = false;

  final List<_Pipe> _pipes = [];
  Timer? _gameLoop;
  double _screenW = 0;
  double _screenH = 0;

  @override
  void dispose() {
    _gameLoop?.cancel();
    super.dispose();
  }

  void _startGame() {
    setState(() {
      _birdY    = 0;
      _velocity = 0;
      _score    = 0;
      _pipes.clear();
      _isDead   = false;
      _isRunning = true;
      _started  = true;
    });
    _pipes.add(_Pipe(_screenW + 50, _screenH));
    _gameLoop?.cancel();
    _gameLoop = Timer.periodic(const Duration(milliseconds: 16), _tick);
  }

  void _jump() {
    if (!_started) { _startGame(); return; }
    if (_isDead)   { _startGame(); return; }
    HapticFeedback.lightImpact();
    setState(() => _velocity = _jumpForce);
  }

  void _tick(Timer t) {
    if (!_isRunning || !mounted) return;
    setState(() {
      // Bird physics
      _velocity += _gravity;
      _birdY    += _velocity;

      // Move pipes
      for (final p in _pipes) {
        p.x -= _pipeSpeed;
      }

      // Spawn pipe
      if (_pipes.isEmpty || _pipes.last.x < _screenW - 220) {
        _pipes.add(_Pipe(_screenW + _pipeWidth, _screenH));
      }

      // Remove off-screen pipes + score
      _pipes.removeWhere((p) {
        if (p.x + _pipeWidth < _birdX * _screenW - _birdSize / 2 && !p.scored) {
          p.scored = true;
          _score++;
          if (_score > _bestScore) _bestScore = _score;
        }
        return p.x < -_pipeWidth - 10;
      });

      // Collision
      final birdLeft   = _birdX * _screenW - _birdSize / 2 + 4;
      final birdRight  = _birdX * _screenW + _birdSize / 2 - 4;
      final birdTop    = _birdY + 4;
      final birdBottom = _birdY + _birdSize - 4;

      // Floor / ceiling
      if (_birdY < -_birdSize || _birdY + _birdSize > _screenH) {
        _die();
        return;
      }

      for (final p in _pipes) {
        final pLeft  = p.x;
        final pRight = p.x + _pipeWidth;
        if (birdRight > pLeft && birdLeft < pRight) {
          if (birdTop < p.topHeight || birdBottom > p.topHeight + _pipeGap) {
            _die();
            return;
          }
        }
      }
    });
  }

  void _die() {
    HapticFeedback.heavyImpact();
    _gameLoop?.cancel();
    setState(() { _isDead = true; _isRunning = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF060811),
      appBar: AppBar(
        backgroundColor: Color(0xFF0C0F1E),
        foregroundColor: Colors.white,
        title: const Text('🐦 Flappy Bird',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text('Best: $_bestScore',
                  style: const TextStyle(color: Color(0xFFFACC15),
                      fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
      body: LayoutBuilder(builder: (ctx, cons) {
        _screenW = cons.maxWidth;
        _screenH = cons.maxHeight;
        return GestureDetector(
          onTap: _jump,
          child: Stack(children: [
            // Background stars
            ...List.generate(20, (i) {
              final rng = Random(i * 99);
              return Positioned(
                left: rng.nextDouble() * _screenW,
                top:  rng.nextDouble() * _screenH,
                child: Container(
                  width: rng.nextDouble() * 3 + 1,
                  height: rng.nextDouble() * 3 + 1,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white24,
                  ),
                ),
              );
            }),

            // Pipes
            for (final p in _pipes) ...[
              // Top pipe
              Positioned(
                left: p.x, top: 0,
                child: _PipeWidget(width: _pipeWidth, height: p.topHeight, isTop: true),
              ),
              // Bottom pipe
              Positioned(
                left: p.x,
                top: p.topHeight + _pipeGap,
                child: _PipeWidget(
                    width: _pipeWidth,
                    height: _screenH - p.topHeight - _pipeGap,
                    isTop: false),
              ),
            ],

            // Bird
            if (_started)
              Positioned(
                left: _birdX * _screenW - _birdSize / 2,
                top:  _birdY,
                child: Transform.rotate(
                  angle: (_velocity * 0.04).clamp(-0.6, 0.6),
                  child: Container(
                    width: _birdSize, height: _birdSize,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const RadialGradient(
                        colors: [Color(0xFFFDE68A), const Color(0xFFFFAB00)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xFFFFAB00).withOpacity(0.6),
                          blurRadius: 12,
                        )
                      ],
                    ),
                    child: const Center(
                      child: Text('🐦', style: TextStyle(fontSize: 20)),
                    ),
                  ),
                ),
              ),

            // Score
            if (_started)
              Positioned(
                top: 20, left: 0, right: 0,
                child: Text('$_score',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 42,
                        fontWeight: FontWeight.w900,
                        shadows: [Shadow(color: Colors.black54, blurRadius: 8)])),
              ),

            // Start screen
            if (!_started)
              Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('🐦', style: TextStyle(fontSize: 72)),
                  const SizedBox(height: 16),
                  const Text('FLAPPY BIRD',
                      style: TextStyle(color: Colors.white, fontSize: 28,
                          fontWeight: FontWeight.w900, letterSpacing: 2)),
                  const SizedBox(height: 8),
                  Text('Tap layar untuk mulai',
                      style: TextStyle(color: Colors.white.withOpacity(0.6),
                          fontSize: 15)),
                ]),
              ),

            // Dead overlay
            if (_isDead)
              Center(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 40),
                  padding: const EdgeInsets.all(28),
                  decoration: BoxDecoration(
                    color: Color(0xFF0C0F1E).withOpacity(0.95),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.4)),
                  ),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('💥 GAME OVER',
                        style: TextStyle(color: Colors.white, fontSize: 22,
                            fontWeight: FontWeight.w900)),
                    const SizedBox(height: 12),
                    Text('Score: $_score',
                        style: const TextStyle(color: Color(0xFFFACC15),
                            fontSize: 32, fontWeight: FontWeight.w800)),
                    Text('Best: $_bestScore',
                        style: const TextStyle(color: Color(0xFF3B82F6),
                            fontSize: 16)),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF3B82F6),
                        foregroundColor: Colors.white,
                        minimumSize: const Size(160, 46),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: _startGame,
                      child: const Text('Main Lagi',
                          style: TextStyle(fontWeight: FontWeight.w700,
                              fontSize: 16)),
                    ),
                  ]),
                ),
              ),
          ]),
        );
      }),
    );
  }
}

class _Pipe {
  double x;
  final double topHeight;
  bool scored = false;

  _Pipe(this.x, double screenH)
      : topHeight = 80 + Random().nextDouble() * (screenH - 80 - 170 - 80);
}

class _PipeWidget extends StatelessWidget {
  final double width;
  final double height;
  final bool isTop;
  const _PipeWidget(
      {required this.width, required this.height, required this.isTop});

  @override
  Widget build(BuildContext context) {
    if (height <= 0) return const SizedBox.shrink();
    return SizedBox(
      width: width,
      height: height,
      child: Stack(children: [
        // Pipe body
        Positioned.fill(
          top: isTop ? 12 : 0,
          bottom: isTop ? 0 : 12,
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [const Color(0xFF00E676), Color(0xFF15803D)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              border: Border.symmetric(
                vertical: BorderSide(
                    color: const Color(0xFF86EFAC).withOpacity(0.4), width: 2),
              ),
            ),
          ),
        ),
        // Cap
        Positioned(
          left: -4,
          right: -4,
          top: isTop ? null : 0,
          bottom: isTop ? 0 : null,
          child: Container(
            height: 14,
            decoration: BoxDecoration(
              color: const Color(0xFF16A34A),
              borderRadius: isTop
                  ? const BorderRadius.only(
                      bottomLeft: Radius.circular(4),
                      bottomRight: Radius.circular(4))
                  : const BorderRadius.only(
                      topLeft: Radius.circular(4),
                      topRight: Radius.circular(4)),
              border: Border.all(
                  color: const Color(0xFF86EFAC).withOpacity(0.4), width: 2),
            ),
          ),
        ),
      ]),
    );
  }
}
