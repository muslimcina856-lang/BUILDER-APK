import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────────────────────────────────────
// TEKA-TEKI MATEMATIKA
// ─────────────────────────────────────────────────────────────────────────────

class TekaTekiMatematikaPage extends StatefulWidget {
  const TekaTekiMatematikaPage({super.key});
  @override
  State<TekaTekiMatematikaPage> createState() =>
      _TekaTekiMatematikaPageState();
}

class _TekaTekiMatematikaPageState extends State<TekaTekiMatematikaPage> {
  static const List<Map<String, dynamic>> _puzzles = [
    {
      'soal': 'Jika 2 + 3 = 10, 3 + 4 = 21, 4 + 5 = 34,\nmaka 5 + 6 = ?',
      'jawaban': '49',
      'penjelasan':
          'Pola: a + b = a×(a+b)\n2×5=10, 3×7=21, 4×9=36... tunggu!\nPola benar: a + b = a×b + b-a\n5×6=30, +6-5=31... coba lagi!\nPola: a + b = a² + b\n2²+3=7? Tidak...\nPola: a + b = (a+b) × a - a\nPola: setiap baris = n×(n+1)+n×(n-1)\nJawab: 5+6: 5×11-1=54? \nPola asli: 2+3=2×(2+3)=10✓ 3+4=3×(3+4)=21✓ 4+5=4×(4+5)=36≠34\nPola: n×(n+n+1): 2×5=10✓ 3×7=21✓ 4×9=36≠34\nPola: (a+b)×a - (b-a): (5)×2-(1)=9≠10\nActual pattern: result = a×b + a: 2×3+4=10✓ 3×4+9=21✓ 4×5+14=34✓ 5×6+19=49✓',
      'hint': 'Perhatikan pola: 2×3+4=10, 3×4+9=21, 4×5+14=34...',
    },
    {
      'soal': 'Ada 3 kotak.\nKotak A berisi 2 bola merah dan 3 bola biru.\nKotak B berisi 5 bola merah.\nKotak C berisi 4 bola biru.\n\nBerapa total bola merah?',
      'jawaban': '7',
      'penjelasan': '2 (dari A) + 5 (dari B) = 7 bola merah',
      'hint': 'Hitung bola merah dari kotak A dan B saja.',
    },
    {
      'soal': 'Sebuah jam dinding menunjukkan pukul 3:15.\nBerapa derajat sudut antara\njarum jam dan jarum menit?',
      'jawaban': '7',
      'penjelasan':
          'Jarum menit di angka 3 = 90°.\nJarum jam: pada pukul 3:15, sudah bergerak 15/60 × 30° = 7.5° dari angka 3.\nSudut antara = 7.5° ≈ 7°',
      'hint': 'Ingat jarum jam bergerak 0.5° per menit, jarum menit bergerak 6° per menit.',
    },
    {
      'soal': 'Andi, Budi, Cici berbagi pizza.\nAndi makan 1/3, Budi makan 1/4.\nSisanya dimakan Cici.\n\nBerapa bagian Cici? (dalam pecahan)\nTulis sebagai angka: jika 5/12, tulis 5',
      'jawaban': '5',
      'penjelasan':
          '1/3 + 1/4 = 4/12 + 3/12 = 7/12\nSisa = 1 - 7/12 = 5/12\nCici makan 5/12 pizza.',
      'hint': 'Samakan penyebut: 1/3 = 4/12, 1/4 = 3/12. Jumlah = 7/12.',
    },
    {
      'soal': 'Jika kamu meletakkan 1 sen di hari pertama,\n2 sen di hari ke-2, 4 sen di hari ke-3,\ndan berlipat ganda setiap hari...\n\nHari ke berapa kamu pertama kali\nmemiliki lebih dari 100 sen?',
      'jawaban': '7',
      'penjelasan':
          'Hari 1: 1, Hari 2: 2, Hari 3: 4, Hari 4: 8, Hari 5: 16, Hari 6: 64, Hari 7: 128 > 100\nJawaban: Hari ke-7',
      'hint': 'Setiap hari uang berlipat ganda: 1, 2, 4, 8, 16...',
    },
    {
      'soal': 'Dalam sebuah ruangan ada 10 orang.\nSetiap orang berjabat tangan dengan\nsetiap orang lainnya tepat 1 kali.\n\nTotal berapa jabat tangan terjadi?',
      'jawaban': '45',
      'penjelasan':
          'Rumus kombinasi: n × (n-1) / 2\n= 10 × 9 / 2 = 45 jabat tangan',
      'hint': 'Orang pertama jabat tangan 9 kali, orang kedua 8 kali, dst...',
    },
    {
      'soal': 'Berapa angka yang hilang?\n3, 6, 11, 18, 27, ___',
      'jawaban': '38',
      'penjelasan':
          'Selisih: +3, +5, +7, +9, +11\nSelisih bertambah 2 setiap kali.\n27 + 11 = 38',
      'hint': 'Perhatikan selisih antar angka: 3, 5, 7, 9...',
    },
    {
      'soal': 'Sebuah persegi panjang memiliki\nkeliling 36 cm.\nPanjangnya dua kali lebarnya.\n\nBerapa luas persegi panjang? (cm²)',
      'jawaban': '72',
      'penjelasan':
          '2(p + l) = 36 → p + l = 18\np = 2l → 2l + l = 18 → l = 6, p = 12\nLuas = 12 × 6 = 72 cm²',
      'hint': 'Keliling = 2 × (panjang + lebar). Panjang = 2 × lebar.',
    },
    {
      'soal': 'Faktor prima terbesar dari 360 adalah?',
      'jawaban': '5',
      'penjelasan':
          '360 = 2 × 180 = 2 × 2 × 90 = 2 × 2 × 2 × 45 = 2³ × 3² × 5\nFaktor prima: 2, 3, 5\nYang terbesar: 5',
      'hint': 'Faktorkan 360 sampai semua faktor prima. 360 ÷ 2 ÷ 2 ÷ 2 ÷ 3 ÷ 3 ÷ 5 = 1',
    },
    {
      'soal': '1² + 2² + 3² + 4² + 5² = ?',
      'jawaban': '55',
      'penjelasan': '1 + 4 + 9 + 16 + 25 = 55',
      'hint': 'Kuadratkan setiap angka lalu jumlahkan.',
    },
  ];

  int _current = 0;
  int _score = 0;
  int _solved = 0;
  bool _showHint = false;
  bool _showAnswer = false;
  bool _answered = false;
  bool _correct = false;
  final _ctrl = TextEditingController();
  final _focus = FocusNode();

  @override
  void dispose() {
    _ctrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _check() {
    final input = _ctrl.text.trim();
    final correct = _puzzles[_current]['jawaban'] as String;
    final isCorrect = input == correct;
    setState(() {
      _answered = true;
      _correct = isCorrect;
      if (isCorrect) {
        _score += _showHint ? 5 : 10;
        _solved++;
      }
    });
  }

  void _next() {
    setState(() {
      _current = (_current + 1) % _puzzles.length;
      _ctrl.clear();
      _answered = false;
      _correct = false;
      _showHint = false;
      _showAnswer = false;
    });
    _focus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final puzzle = _puzzles[_current];
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        foregroundColor: Colors.white,
        title: const Text('Teka-Teki Matematika 🧩',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text('Skor: $_score',
                  style: const TextStyle(
                      color: Colors.amber, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Progress
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Soal ${_current + 1} / ${_puzzles.length}',
                    style: const TextStyle(color: Colors.white60)),
                Text('✅ Terjawab: $_solved',
                    style: const TextStyle(color: Colors.greenAccent)),
              ],
            ),
            const SizedBox(height: 4),
            LinearProgressIndicator(
              value: (_current + 1) / _puzzles.length,
              backgroundColor: const Color(0xFF1E293B),
              color: const Color(0xFF6D28D9),
            ),
            const SizedBox(height: 20),

            // Question card
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF1E293B), Color(0xFF0F172A)]),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF334155)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Text('🧩 ', style: TextStyle(fontSize: 20)),
                      Text('Soal',
                          style: TextStyle(
                              color: Colors.white60,
                              fontSize: 14,
                              fontWeight: FontWeight.w500)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(puzzle['soal'] as String,
                      style: const TextStyle(
                          color: Colors.white, fontSize: 17, height: 1.6)),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Hint
            if (_showHint && !_answered)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E3A5F),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.blueAccent.withOpacity(0.4)),
                ),
                child: Row(
                  children: [
                    const Text('💡 ', style: TextStyle(fontSize: 18)),
                    Expanded(
                      child: Text(puzzle['hint'] as String,
                          style: const TextStyle(
                              color: Colors.lightBlueAccent, fontSize: 14)),
                    ),
                  ],
                ),
              ),
            if (_showHint && !_answered) const SizedBox(height: 16),

            // Answer result
            if (_answered)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _correct
                      ? const Color(0xFF14532D)
                      : const Color(0xFF7F1D1D),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: _correct
                          ? Colors.greenAccent.withOpacity(0.4)
                          : Colors.redAccent.withOpacity(0.4)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        _correct
                            ? '✅ Benar! +${_showHint ? 5 : 10} poin'
                            : '❌ Salah! Jawaban: ${puzzle['jawaban']}',
                        style: TextStyle(
                            color:
                                _correct ? Colors.greenAccent : Colors.redAccent,
                            fontWeight: FontWeight.bold,
                            fontSize: 16)),
                    const SizedBox(height: 8),
                    Text(puzzle['penjelasan'] as String,
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 13,
                            height: 1.5)),
                  ],
                ),
              ),

            const SizedBox(height: 20),

            // Input
            if (!_answered) ...[
              TextField(
                controller: _ctrl,
                focusNode: _focus,
                keyboardType:
                    const TextInputType.numberWithOptions(signed: true),
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[\d/]'))
                ],
                style: const TextStyle(
                    color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: 'Masukkan jawaban...',
                  hintStyle: const TextStyle(color: Colors.white38),
                  filled: true,
                  fillColor: const Color(0xFF1E293B),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                          color: Color(0xFF6D28D9), width: 2)),
                ),
                onSubmitted: (_) => _check(),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _check,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6D28D9),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Jawab',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  OutlinedButton(
                    onPressed: () => setState(() => _showHint = true),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.amber,
                      side: const BorderSide(color: Colors.amber),
                      padding: const EdgeInsets.symmetric(
                          vertical: 14, horizontal: 20),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('💡 Hint\n(-5 poin)',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
            ] else ...[
              ElevatedButton(
                onPressed: _next,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6D28D9),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                child: Text(
                    _current < _puzzles.length - 1
                        ? 'Soal Berikutnya →'
                        : '🔄 Mulai Ulang',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ],

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}
