import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────────────────────────────────────
// BRICK BREAKER GAME
// ─────────────────────────────────────────────────────────────────────────────

class BrickBreakerPage extends StatefulWidget {
  const BrickBreakerPage({super.key});
  @override
  State<BrickBreakerPage> createState() => _BrickBreakerPageState();
}

class _BrickBreakerPageState extends State<BrickBreakerPage> {
  // ── Layout constants (fractions resolved after first layout) ─────────────
  static const double _paddleH   = 14.0;
  static const double _paddleW   = 90.0;
  static const double _ballSize  = 14.0;
  static const double _brickRows = 5;
  static const double _brickCols = 7;
  static const double _brickH    = 26.0;
  static const double _brickGap  = 6.0;

  // ── State ────────────────────────────────────────────────────────────────
  double _sw = 0, _sh = 0;          // screen size
  double _paddleX = 0;              // paddle center X
  double _ballX   = 0, _ballY = 0;  // ball top-left
  double _vx = 3.5, _vy = -3.5;    // ball velocity

  int  _score    = 0;
  int  _best     = 0;
  int  _lives    = 3;
  bool _running  = false;
  bool _gameOver = false;
  bool _won      = false;
  bool _started  = false;

  late List<List<bool>> _bricks; // true = alive
  Timer? _loop;

  @override
  void dispose() { _loop?.cancel(); super.dispose(); }

  void _initLevel() {
    _bricks = List.generate(
        _brickRows.toInt(), (_) => List.filled(_brickCols.toInt(), true));
  }

  void _startGame() {
    _initLevel();
    _paddleX = _sw / 2;
    _ballX   = _sw / 2 - _ballSize / 2;
    _ballY   = _sh - 80 - _ballSize;
    _vx      = (Random().nextBool() ? 1 : -1) * 3.5;
    _vy      = -4.0;
    _score   = 0;
    _lives   = 3;
    _gameOver = false;
    _won      = false;
    _started  = true;
    _running  = true;
    setState(() {});
    _loop?.cancel();
    _loop = Timer.periodic(const Duration(milliseconds: 16), _tick);
  }

  void _nextLevel() {
    _initLevel();
    _paddleX = _sw / 2;
    _ballX   = _sw / 2 - _ballSize / 2;
    _ballY   = _sh - 80 - _ballSize;
    final speed = 3.5 + (_score / 50) * 0.5;
    _vx      = (Random().nextBool() ? 1 : -1) * speed;
    _vy      = -speed;
    _running = true;
    setState(() {});
    _loop?.cancel();
    _loop = Timer.periodic(const Duration(milliseconds: 16), _tick);
  }

  void _tick(Timer t) {
    if (!_running || !mounted) return;
    setState(() {
      _ballX += _vx;
      _ballY += _vy;

      // Wall collisions
      if (_ballX <= 0)        { _ballX = 0; _vx = _vx.abs(); }
      if (_ballX + _ballSize >= _sw) { _ballX = _sw - _ballSize; _vx = -_vx.abs(); }
      if (_ballY <= 0)        { _ballY = 0; _vy = _vy.abs(); }

      // Paddle collision
      final paddleTop  = _sh - 60 - _paddleH;
      final paddleLeft = _paddleX - _paddleW / 2;
      if (_ballY + _ballSize >= paddleTop &&
          _ballY + _ballSize <= paddleTop + _paddleH + 4 &&
          _ballX + _ballSize >= paddleLeft &&
          _ballX <= paddleLeft + _paddleW) {
        _vy = -_vy.abs();
        // Add angle based on hit position
        final hitPos = (_ballX + _ballSize / 2 - _paddleLeft) / _paddleW;
        _vx = (hitPos - 0.5) * 9;
        HapticFeedback.selectionClick();
      }

      // Brick collisions
      final brickTotalW = _brickCols * ((_sw - 24) / _brickCols);
      final brickStartX = 12.0;
      const brickStartY = 60.0;
      final brickW = (_sw - 24) / _brickCols - _brickGap;

      bool hitBrick = false;
      for (int r = 0; r < _brickRows.toInt() && !hitBrick; r++) {
        for (int c = 0; c < _brickCols.toInt() && !hitBrick; c++) {
          if (!_bricks[r][c]) continue;
          final bx = brickStartX + c * (brickW + _brickGap);
          final by = brickStartY + r * (_brickH + _brickGap);
          if (_ballX + _ballSize > bx &&
              _ballX < bx + brickW &&
              _ballY + _ballSize > by &&
              _ballY < by + _brickH) {
            _bricks[r][c] = false;
            _score += 10;
            if (_score > _best) _best = _score;
            HapticFeedback.lightImpact();
            // Determine bounce direction
            final overlapL = (_ballX + _ballSize) - bx;
            final overlapR = (bx + brickW) - _ballX;
            final overlapT = (_ballY + _ballSize) - by;
            final overlapB = (by + _brickH) - _ballY;
            final minH = min(overlapL, overlapR);
            final minV = min(overlapT, overlapB);
            if (minH < minV) { _vx = -_vx; }
            else             { _vy = -_vy; }
            hitBrick = true;
          }
        }
      }

      // Win check
      if (_bricks.every((row) => row.every((b) => !b))) {
        _loop?.cancel();
        _running = false;
        _won = true;
      }

      // Ball out of bounds (bottom)
      if (_ballY > _sh) {
        _lives--;
        HapticFeedback.heavyImpact();
        if (_lives <= 0) {
          _loop?.cancel();
          _running  = false;
          _gameOver = true;
        } else {
          _ballX = _sw / 2 - _ballSize / 2;
          _ballY = _sh - 80 - _ballSize;
          _vy    = -4.0;
          _vx    = (Random().nextBool() ? 1 : -1) * 3.5;
        }
      }
    });
  }

  double get _paddleLeft => _paddleX - _paddleW / 2;

  void _movePaddle(DragUpdateDetails d) {
    setState(() {
      _paddleX = (_paddleX + d.delta.dx)
          .clamp(_paddleW / 2, _sw - _paddleW / 2);
    });
  }

  Color _brickColor(int row) {
    const colors = [
      const Color(0xFFFF1744),
      const Color(0xFFFFAB00),
      const Color(0xFF00E676),
      Color(0xFF3B82F6),
      Color(0xFF8B5CF6),
    ];
    return colors[row % colors.length];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF060811),
      appBar: AppBar(
        backgroundColor: Color(0xFF0C0F1E),
        foregroundColor: Colors.white,
        title: const Text('🧱 Brick Breaker',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text('Best: $_best',
                  style: const TextStyle(
                      color: Color(0xFFFACC15), fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
      body: LayoutBuilder(builder: (ctx, cons) {
        if (_sw == 0) {
          _sw      = cons.maxWidth;
          _sh      = cons.maxHeight;
          _paddleX = _sw / 2;
          _ballX   = _sw / 2 - _ballSize / 2;
          _ballY   = _sh - 80 - _ballSize;
        }
        return GestureDetector(
          onTap: !_started || _gameOver || _won ? null : null,
          onHorizontalDragUpdate: _running ? _movePaddle : null,
          onPanUpdate: _running ? _movePaddle : null,
          child: Stack(children: [
            // Stars bg
            ...List.generate(15, (i) {
              final rng = Random(i * 77);
              return Positioned(
                left: rng.nextDouble() * _sw,
                top:  rng.nextDouble() * _sh,
                child: Container(
                  width: rng.nextDouble() * 2 + 1,
                  height: rng.nextDouble() * 2 + 1,
                  decoration: const BoxDecoration(
                      shape: BoxShape.circle, color: Colors.white12),
                ),
              );
            }),

            // Bricks
            if (_started)
              for (int r = 0; r < _brickRows.toInt(); r++)
                for (int c = 0; c < _brickCols.toInt(); c++)
                  if (_bricks[r][c])
                    Positioned(
                      left: 12 + c * ((_sw - 24) / _brickCols),
                      top:  60 + r * (_brickH + _brickGap),
                      width: (_sw - 24) / _brickCols - _brickGap,
                      height: _brickH,
                      child: Container(
                        decoration: BoxDecoration(
                          color: _brickColor(r),
                          borderRadius: BorderRadius.circular(6),
                          boxShadow: [
                            BoxShadow(
                                color: _brickColor(r).withOpacity(0.5),
                                blurRadius: 6)
                          ],
                        ),
                      ),
                    ),

            // Ball
            if (_started)
              Positioned(
                left: _ballX, top: _ballY,
                child: Container(
                  width: _ballSize, height: _ballSize,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.white.withOpacity(0.8), blurRadius: 10)
                    ],
                  ),
                ),
              ),

            // Paddle
            if (_started)
              Positioned(
                left: _paddleLeft,
                top:  _sh - 60 - _paddleH,
                child: Container(
                  width: _paddleW, height: _paddleH,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF3B82F6), Color(0xFF8B5CF6)],
                    ),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xFF3B82F6).withOpacity(0.6),
                          blurRadius: 12)
                    ],
                  ),
                ),
              ),

            // Score + Lives HUD
            if (_started)
              Positioned(
                bottom: 16, left: 0, right: 0,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Score: $_score',
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 15)),
                      const SizedBox(width: 24),
                      Row(children: List.generate(
                          3,
                          (i) => Icon(Icons.favorite_rounded,
                              color: i < _lives
                                  ? Color(0xFFFF1744)
                                  : Colors.white24,
                              size: 18))),
                    ]),
              ),

            // Start screen
            if (!_started)
              Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('🧱', style: TextStyle(fontSize: 64)),
                  const SizedBox(height: 12),
                  const Text('BRICK BREAKER',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2)),
                  const SizedBox(height: 8),
                  Text('Geser layar untuk kendalikan paddle',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 13)),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF3B82F6),
                        foregroundColor: Colors.white,
                        minimumSize: const Size(160, 46),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14))),
                    onPressed: _startGame,
                    child: const Text('MAIN',
                        style: TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 16)),
                  ),
                ]),
              ),

            // Game Over overlay
            if (_gameOver)
              _Overlay(
                emoji: '💥',
                title: 'GAME OVER',
                score: _score,
                best: _best,
                onRetry: () => setState(_startGame),
              ),

            // Win overlay
            if (_won)
              _Overlay(
                emoji: '🎉',
                title: 'LEVEL CLEAR!',
                score: _score,
                best: _best,
                retryLabel: 'Level Baru',
                onRetry: () => setState(_nextLevel),
              ),

            // Drag hint
            if (_started && _running)
              const Positioned(
                bottom: 42, left: 0, right: 0,
                child: Text('← Geser untuk pindah paddle →',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white24, fontSize: 11)),
              ),
          ]),
        );
      }),
    );
  }
}

class _Overlay extends StatelessWidget {
  final String emoji, title, retryLabel;
  final int score, best;
  final VoidCallback onRetry;

  const _Overlay({
    required this.emoji,
    required this.title,
    required this.score,
    required this.best,
    required this.onRetry,
    this.retryLabel = 'Main Lagi',
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black54,
      child: Center(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 40),
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: Color(0xFF0C0F1E),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
                color: const Color(0xFF3B82F6).withOpacity(0.4)),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(emoji, style: const TextStyle(fontSize: 48)),
            const SizedBox(height: 8),
            Text(title,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            Text('Score: $score',
                style: const TextStyle(
                    color: Color(0xFFFACC15),
                    fontSize: 30,
                    fontWeight: FontWeight.w800)),
            Text('Best: $best',
                style: const TextStyle(
                    color: Color(0xFF3B82F6), fontSize: 15)),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF3B82F6),
                  foregroundColor: Colors.white,
                  minimumSize: const Size(160, 46),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14))),
              onPressed: onRetry,
              child: Text(retryLabel,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 16)),
            ),
          ]),
        ),
      ),
    );
  }
}
