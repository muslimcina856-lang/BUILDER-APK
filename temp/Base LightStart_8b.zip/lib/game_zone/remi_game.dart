import 'dart:math';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// REMI (KARTU) GAME — Indonesian Card Game vs AI
// ─────────────────────────────────────────────────────────────────────────────

enum Suit { spade, heart, diamond, club }

class PlayingCard {
  final Suit suit;
  final int value; // 1=A, 2-10, 11=J, 12=Q, 13=K

  const PlayingCard({required this.suit, required this.value});

  String get label {
    if (value == 1) return 'A';
    if (value == 11) return 'J';
    if (value == 12) return 'Q';
    if (value == 13) return 'K';
    return '$value';
  }

  String get suitSymbol {
    switch (suit) {
      case Suit.spade: return '♠';
      case Suit.heart: return '♥';
      case Suit.diamond: return '♦';
      case Suit.club: return '♣';
    }
  }

  Color get suitColor {
    return (suit == Suit.heart || suit == Suit.diamond) ? Color(0xFFFF1744) : const Color(0xFF1A1A2E);
  }

  int get points {
    if (value >= 10) return 10;
    return value;
  }
}

List<PlayingCard> _buildFullDeck() {
  final deck = <PlayingCard>[];
  for (final suit in Suit.values) {
    for (int v = 1; v <= 13; v++) {
      deck.add(PlayingCard(suit: suit, value: v));
    }
  }
  deck.shuffle(Random());
  return deck;
}

class RemiGamePage extends StatefulWidget {
  const RemiGamePage({super.key});
  @override
  State<RemiGamePage> createState() => _RemiGamePageState();
}

class _RemiGamePageState extends State<RemiGamePage> with TickerProviderStateMixin {
  late List<PlayingCard> _deck;
  late List<PlayingCard> _playerHand;
  late List<PlayingCard> _aiHand;
  late List<PlayingCard> _discardPile;
  bool _playerTurn = true;
  bool _gameOver = false;
  String _message = '';
  int _playerScore = 0;
  int _aiScore = 0;
  int _round = 1;
  Set<int> _selectedCards = {};
  bool _aiThinking = false;

  // Meld detection
  List<List<PlayingCard>> _playerMelds = [];

  @override
  void initState() {
    super.initState();
    _startRound();
  }

  void _startRound() {
    _deck = _buildFullDeck();
    _playerHand = [];
    _aiHand = [];
    _discardPile = [];
    _selectedCards = {};
    _playerMelds = [];
    _gameOver = false;
    _aiThinking = false;

    // Deal 10 cards each
    for (int i = 0; i < 10; i++) {
      _playerHand.add(_deck.removeLast());
      _aiHand.add(_deck.removeLast());
    }
    _discardPile.add(_deck.removeLast());
    _playerTurn = true;
    _message = 'Round $_round — Ambil dari deck atau tumpukan buang';
    setState(() {});
  }

  void _sortHand() {
    _playerHand.sort((a, b) {
      if (a.suit.index != b.suit.index) return a.suit.index.compareTo(b.suit.index);
      return a.value.compareTo(b.value);
    });
    setState(() {});
  }

  void _drawFromDeck() {
    if (!_playerTurn || _gameOver || _aiThinking) return;
    if (_deck.isEmpty) return;
    setState(() {
      _playerHand.add(_deck.removeLast());
      _message = 'Kamu ambil dari deck. Sekarang buang 1 kartu!';
    });
  }

  void _drawFromDiscard() {
    if (!_playerTurn || _gameOver || _aiThinking) return;
    if (_discardPile.isEmpty) return;
    setState(() {
      _playerHand.add(_discardPile.removeLast());
      _message = 'Kamu ambil dari buangan. Sekarang buang 1 kartu!';
    });
  }

  void _toggleSelect(int idx) {
    if (!_playerTurn) return;
    setState(() {
      if (_selectedCards.contains(idx)) {
        _selectedCards.remove(idx);
      } else {
        _selectedCards.add(idx);
      }
    });
  }

  void _discardSelected() {
    if (!_playerTurn || _gameOver) return;
    if (_selectedCards.length != 1) {
      setState(() => _message = '❌ Pilih tepat 1 kartu untuk dibuang!');
      return;
    }
    final idx = _selectedCards.first;
    if (_playerHand.length <= 10) {
      setState(() => _message = '⚠️ Ambil kartu dulu sebelum buang!');
      return;
    }
    setState(() {
      _discardPile.add(_playerHand.removeAt(idx));
      _selectedCards = {};
    });

    // Check win
    if (_checkWin(_playerHand)) {
      setState(() {
        _gameOver = true;
        _playerScore++;
        _message = '🎉 Remi! Kamu menang round $_round!';
      });
      return;
    }

    _playerTurn = false;
    setState(() => _message = '🤖 AI sedang berpikir...');
    Future.delayed(const Duration(milliseconds: 1400), _aiTurn);
  }

  bool _checkWin(List<PlayingCard> hand) {
    if (hand.length != 10) return false;
    // Simple: check if all cards form valid melds (sets of 3 or runs of 3+)
    return _findBestMelds(List.from(hand));
  }

  bool _findBestMelds(List<PlayingCard> cards) {
    if (cards.isEmpty) return true;
    if (cards.length < 3) return false;

    final sorted = List<PlayingCard>.from(cards)
      ..sort((a, b) => a.suit.index != b.suit.index
          ? a.suit.index.compareTo(b.suit.index)
          : a.value.compareTo(b.value));

    // Try sets (same value, different suit)
    for (int i = 0; i < sorted.length - 2; i++) {
      final group = sorted.where((c) => c.value == sorted[i].value).toList();
      if (group.length >= 3) {
        final meld = group.sublist(0, 3);
        final rest = sorted.where((c) => !meld.contains(c)).toList();
        if (_findBestMelds(rest)) return true;
      }
    }

    // Try runs (same suit, consecutive)
    for (int i = 0; i < sorted.length - 2; i++) {
      final same = sorted.where((c) => c.suit == sorted[i].suit).toList();
      if (same.length >= 3) {
        same.sort((a, b) => a.value.compareTo(b.value));
        for (int j = 0; j <= same.length - 3; j++) {
          if (same[j + 1].value == same[j].value + 1 &&
              same[j + 2].value == same[j + 1].value + 1) {
            final meld = [same[j], same[j + 1], same[j + 2]];
            final rest = sorted.where((c) => !meld.contains(c)).toList();
            if (_findBestMelds(rest)) return true;
          }
        }
      }
    }
    return false;
  }

  int _calculateDeadwood(List<PlayingCard> hand) {
    // Sum of unmelded cards
    return hand.fold(0, (sum, c) => sum + c.points);
  }

  void _aiTurn() {
    if (!mounted || _gameOver) return;
    final rng = Random();

    // AI: pick up if discard pile top is useful
    bool drawDiscard = false;
    if (_discardPile.isNotEmpty) {
      final top = _discardPile.last;
      // Check if it forms a set
      final sameVal = _aiHand.where((c) => c.value == top.value).length;
      final sameSuit = _aiHand.where((c) => c.suit == top.suit &&
          (c.value == top.value - 1 || c.value == top.value + 1)).length;
      if (sameVal >= 2 || sameSuit >= 2) drawDiscard = true;
    }

    if (drawDiscard && _discardPile.isNotEmpty) {
      _aiHand.add(_discardPile.removeLast());
    } else if (_deck.isNotEmpty) {
      _aiHand.add(_deck.removeLast());
    }

    // Discard highest deadwood card
    _aiHand.sort((a, b) => b.points.compareTo(a.points));
    int discardIdx = 0;
    // Don't discard part of a potential meld
    for (int i = 0; i < _aiHand.length; i++) {
      final c = _aiHand[i];
      final sameVal = _aiHand.where((x) => x.value == c.value).length;
      final adjSuit = _aiHand.where((x) => x.suit == c.suit &&
          (x.value == c.value - 1 || x.value == c.value + 1)).length;
      if (sameVal < 2 && adjSuit < 1) { discardIdx = i; break; }
    }

    setState(() {
      _discardPile.add(_aiHand.removeAt(discardIdx));
      _message = 'AI sudah buang kartu. Giliran kamu!';
    });

    if (_checkWin(_aiHand)) {
      setState(() {
        _gameOver = true;
        _aiScore++;
        _message = '🤖 AI Remi! AI menang round $_round!';
      });
      return;
    }

    setState(() { _playerTurn = true; _aiThinking = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D3B1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF062D10),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text('🃏 Remi — Round $_round',
          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(child: Text('😎 $_playerScore  🤖 $_aiScore',
              style: const TextStyle(fontWeight: FontWeight.w700, color: const Color(0xFFFFAB00)))),
          ),
        ],
      ),
      body: Column(children: [
        // AI hand
        _buildAiArea(),
        // Message + controls
        _buildMiddleArea(),
        // Player hand
        _buildPlayerArea(),
      ]),
    );
  }

  Widget _buildAiArea() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      color: const Color(0xFF062D10),
      child: Row(children: [
        const Text('🤖 AI', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, fontSize: 13)),
        const Spacer(),
        SizedBox(
          height: 65,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            shrinkWrap: true,
            reverse: true,
            itemCount: _aiHand.length,
            itemBuilder: (_, i) => Container(
              width: 36, height: 55,
              margin: const EdgeInsets.only(left: 3),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                gradient: const LinearGradient(colors: [Color(0xFF1B4332), Color(0xFF081C11)]),
                border: Border.all(color: const Color(0xFF2D6A4F), width: 1),
              ),
              child: const Center(child: Text('🂠', style: TextStyle(fontSize: 22))),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Text('${_aiHand.length}', style: const TextStyle(color: Colors.white54, fontSize: 12)),
      ]),
    );
  }

  Widget _buildMiddleArea() {
    return Expanded(
      child: Container(
        color: const Color(0xFF0D3B1A),
        child: Column(children: [
          // Message
          Container(
            margin: const EdgeInsets.all(10),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.black38,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white10),
            ),
            child: Text(_message,
              style: const TextStyle(color: Colors.white70, fontSize: 12),
              textAlign: TextAlign.center,
              maxLines: 2,
            ),
          ),
          // Deck + Discard
          Expanded(
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              // Deck
              GestureDetector(
                onTap: _playerTurn ? _drawFromDeck : null,
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 64, height: 95,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF1B4332), Color(0xFF081C11)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight,
                      ),
                      border: Border.all(color: const Color(0xFF40916C), width: 2),
                      boxShadow: [BoxShadow(color: const Color(0xFF40916C).withOpacity(0.4), blurRadius: 12)],
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Text('🂠', style: TextStyle(fontSize: 32)),
                      Text('${_deck.length}', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                    ]),
                  ),
                  const SizedBox(height: 4),
                  const Text('DECK', style: TextStyle(color: Color(0xFF40916C), fontSize: 10, fontWeight: FontWeight.w700)),
                ]),
              ),
              const SizedBox(width: 24),
              // Discard
              GestureDetector(
                onTap: _playerTurn ? _drawFromDiscard : null,
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  if (_discardPile.isNotEmpty)
                    _buildPlayingCard(_discardPile.last, size: 1.2, selected: false)
                  else
                    Container(
                      width: 64 * 1.2, height: 95 * 1.2,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.white24, width: 2, style: BorderStyle.solid),
                      ),
                      child: const Center(child: Text('Kosong', style: TextStyle(color: Colors.white30, fontSize: 10))),
                    ),
                  const SizedBox(height: 4),
                  const Text('BUANGAN', style: TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.w700)),
                ]),
              ),
            ]),
          ),
          // Buttons
          if (_playerTurn && !_gameOver)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF40916C),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    icon: const Icon(Icons.sort, size: 16),
                    label: const Text('Urutkan', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                    onPressed: _sortHand,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _selectedCards.length == 1 ? Color(0xFFFF1744) : const Color(0xFF374151),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    icon: const Icon(Icons.delete_outline, size: 16),
                    label: const Text('Buang', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                    onPressed: _discardSelected,
                  ),
                ),
              ]),
            ),
          if (_gameOver)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF40916C),
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 44),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.refresh),
                label: Text('Round ${_round + 1}', style: const TextStyle(fontWeight: FontWeight.w800)),
                onPressed: () { setState(() { _round++; _startRound(); }); },
              ),
            ),
        ]),
      ),
    );
  }

  Widget _buildPlayerArea() {
    return Container(
      padding: const EdgeInsets.all(10),
      color: const Color(0xFF062D10),
      child: Column(children: [
        Row(children: [
          const Text('😎 Kartu Kamu', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700, fontSize: 13)),
          const Spacer(),
          if (_selectedCards.isNotEmpty)
            Text('${_selectedCards.length} dipilih',
              style: const TextStyle(color: const Color(0xFFFFAB00), fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 8),
        SizedBox(
          height: 100,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _playerHand.length,
            itemBuilder: (_, i) => GestureDetector(
              onTap: () => _toggleSelect(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                transform: Matrix4.translationValues(0, _selectedCards.contains(i) ? -12 : 0, 0),
                child: _buildPlayingCard(_playerHand[i],
                  size: 0.9, selected: _selectedCards.contains(i)),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildPlayingCard(PlayingCard card, {double size = 1.0, bool selected = false}) {
    final w = 54.0 * size;
    final h = 80.0 * size;
    return Container(
      width: w, height: h,
      margin: const EdgeInsets.only(right: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8 * size),
        border: Border.all(
          color: selected ? Color(0xFFFFAB00) : Colors.grey.shade300,
          width: selected ? 2.5 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: selected ? Color(0xFFFFAB00).withOpacity(0.5) : Colors.black38,
            blurRadius: selected ? 12 : 4,
            offset: const Offset(1, 2),
          ),
        ],
      ),
      child: Stack(children: [
        Positioned(
          top: 3, left: 4,
          child: Column(children: [
            Text(card.label, style: TextStyle(color: card.suitColor, fontWeight: FontWeight.w900, fontSize: 10 * size, height: 1.1)),
            Text(card.suitSymbol, style: TextStyle(color: card.suitColor, fontSize: 9 * size, height: 1)),
          ]),
        ),
        Center(child: Text(card.suitSymbol,
          style: TextStyle(color: card.suitColor, fontSize: 22 * size))),
        Positioned(
          bottom: 3, right: 4,
          child: RotatedBox(quarterTurns: 2, child: Column(children: [
            Text(card.label, style: TextStyle(color: card.suitColor, fontWeight: FontWeight.w900, fontSize: 10 * size, height: 1.1)),
            Text(card.suitSymbol, style: TextStyle(color: card.suitColor, fontSize: 9 * size, height: 1)),
          ])),
        ),
      ]),
    );
  }
}
