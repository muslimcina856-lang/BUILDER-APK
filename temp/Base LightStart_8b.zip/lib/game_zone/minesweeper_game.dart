import 'dart:math';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// MINESWEEPER — Ranjau Darat Classic
// ─────────────────────────────────────────────────────────────────────────────

class MinesweeperPage extends StatefulWidget {
  const MinesweeperPage({super.key});
  @override
  State<MinesweeperPage> createState() => _MinesweeperPageState();
}

class _Cell {
  bool isMine = false;
  bool isRevealed = false;
  bool isFlagged = false;
  int adjacentMines = 0;
}

class _MinesweeperPageState extends State<MinesweeperPage> with SingleTickerProviderStateMixin {
  static const int _rows = 12;
  static const int _cols = 9;
  static const int _mines = 15;

  late List<List<_Cell>> _grid;
  bool _gameOver = false;
  bool _won = false;
  bool _firstTap = true;
  int _flagsLeft = _mines;
  int _revealed = 0;
  bool _flagMode = false;
  late AnimationController _explodeCtrl;

  @override
  void initState() {
    super.initState();
    _explodeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _initGrid();
  }

  @override
  void dispose() {
    _explodeCtrl.dispose();
    super.dispose();
  }

  void _initGrid() {
    _grid = List.generate(_rows, (_) => List.generate(_cols, (_) => _Cell()));
    _gameOver = false;
    _won = false;
    _firstTap = true;
    _flagsLeft = _mines;
    _revealed = 0;
    _flagMode = false;
    setState(() {});
  }

  void _placeMines(int safeRow, int safeCol) {
    final rng = Random();
    int placed = 0;
    while (placed < _mines) {
      final r = rng.nextInt(_rows);
      final c = rng.nextInt(_cols);
      if (_grid[r][c].isMine) continue;
      if ((r - safeRow).abs() <= 1 && (c - safeCol).abs() <= 1) continue;
      _grid[r][c].isMine = true;
      placed++;
    }
    // Count adjacents
    for (int r = 0; r < _rows; r++) {
      for (int c = 0; c < _cols; c++) {
        if (!_grid[r][c].isMine) {
          _grid[r][c].adjacentMines = _countAdjacentMines(r, c);
        }
      }
    }
  }

  int _countAdjacentMines(int row, int col) {
    int count = 0;
    for (int dr = -1; dr <= 1; dr++) {
      for (int dc = -1; dc <= 1; dc++) {
        final nr = row + dr; final nc = col + dc;
        if (nr >= 0 && nr < _rows && nc >= 0 && nc < _cols && _grid[nr][nc].isMine) count++;
      }
    }
    return count;
  }

  void _tap(int row, int col) {
    if (_gameOver || _grid[row][col].isRevealed || _grid[row][col].isFlagged) return;

    if (_flagMode) { _toggleFlag(row, col); return; }

    if (_firstTap) {
      _placeMines(row, col);
      _firstTap = false;
    }

    if (_grid[row][col].isMine) {
      setState(() {
        _grid[row][col].isRevealed = true;
        _gameOver = true;
        _won = false;
        // Reveal all mines
        for (int r = 0; r < _rows; r++) {
          for (int c = 0; c < _cols; c++) {
            if (_grid[r][c].isMine) _grid[r][c].isRevealed = true;
          }
        }
      });
      _explodeCtrl.forward(from: 0);
      return;
    }

    _reveal(row, col);
    _checkWin();
  }

  void _reveal(int row, int col) {
    if (row < 0 || row >= _rows || col < 0 || col >= _cols) return;
    if (_grid[row][col].isRevealed || _grid[row][col].isFlagged || _grid[row][col].isMine) return;
    setState(() {
      _grid[row][col].isRevealed = true;
      _revealed++;
    });
    if (_grid[row][col].adjacentMines == 0) {
      for (int dr = -1; dr <= 1; dr++) {
        for (int dc = -1; dc <= 1; dc++) {
          _reveal(row + dr, col + dc);
        }
      }
    }
  }

  void _toggleFlag(int row, int col) {
    if (_grid[row][col].isRevealed) return;
    setState(() {
      if (_grid[row][col].isFlagged) {
        _grid[row][col].isFlagged = false;
        _flagsLeft++;
      } else if (_flagsLeft > 0) {
        _grid[row][col].isFlagged = true;
        _flagsLeft--;
      }
    });
  }

  void _checkWin() {
    if (_revealed == _rows * _cols - _mines) {
      setState(() { _gameOver = true; _won = true; });
    }
  }

  Color _cellNumberColor(int n) {
    const colors = [
      Colors.transparent,
      Color(0xFF3B82F6),   // 1
      const Color(0xFF00E676),   // 2
      const Color(0xFFFF1744),   // 3
      Color(0xFF8B5CF6),   // 4
      Color(0xFFF97316),   // 5
      Color(0xFF06B6D4),   // 6
      const Color(0xFFFFAB00),   // 7
      Color(0xFF6B7280),   // 8
    ];
    return n < colors.length ? colors[n] : Colors.white;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF111827),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F172A),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('💣 Minesweeper', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          TextButton(onPressed: () => setState(_initGrid),
            child: const Text('Reset', style: TextStyle(color: const Color(0xFFFF1744), fontWeight: FontWeight.w700))),
        ],
      ),
      body: Column(children: [
        // Status bar
        Container(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          color: const Color(0xFF1F2937),
          child: Row(children: [
            _statusChip('💣 $_flagsLeft', Color(0xFFFF1744)),
            const Spacer(),
            if (_gameOver)
              Text(_won ? '🎉 MENANG!' : '💥 GAME OVER!',
                style: TextStyle(
                  color: _won ? Color(0xFF00E676) : Color(0xFFFF1744),
                  fontWeight: FontWeight.w900, fontSize: 16,
                ))
            else
              Text('🔍 $_revealed/${_rows * _cols - _mines}',
                style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
            const Spacer(),
            GestureDetector(
              onTap: () => setState(() => _flagMode = !_flagMode),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: _flagMode ? Color(0xFFFFAB00) : const Color(0xFF374151),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: _flagMode ? const Color(0xFFFBBF24) : const Color(0xFF4B5563),
                  ),
                ),
                child: Text(_flagMode ? '🚩 Flag ON' : '🚩 Flag',
                  style: TextStyle(
                    color: _flagMode ? Colors.black : Colors.white70,
                    fontSize: 12, fontWeight: FontWeight.w700,
                  )),
              ),
            ),
          ]),
        ),
        // Grid
        Expanded(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(_rows, (r) => Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_cols, (c) {
                    final cell = _grid[r][c];
                    return GestureDetector(
                      onTap: () => _tap(r, c),
                      onLongPress: () { _toggleFlag(r, c); },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 100),
                        width: 33, height: 33,
                        margin: const EdgeInsets.all(1),
                        decoration: BoxDecoration(
                          color: cell.isRevealed
                              ? (cell.isMine ? const Color(0xFF7F1D1D) : const Color(0xFF1F2937))
                              : const Color(0xFF374151),
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                            color: cell.isRevealed
                                ? const Color(0xFF111827)
                                : const Color(0xFF4B5563),
                            width: 1,
                          ),
                          boxShadow: !cell.isRevealed ? [
                            BoxShadow(
                              color: Colors.black38,
                              blurRadius: 2,
                              offset: const Offset(1, 1),
                            ),
                          ] : null,
                        ),
                        child: Center(child: _cellContent(cell)),
                      ),
                    );
                  }),
                )),
              ),
            ),
          ),
        ),
        // Hint
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Text('Tap = Buka  |  Long Press = Flag  |  Tombol 🚩 = Mode Flag',
            style: const TextStyle(color: Colors.white38, fontSize: 10),
            textAlign: TextAlign.center),
        ),
      ]),
    );
  }

  Widget _cellContent(_Cell cell) {
    if (!cell.isRevealed) {
      return cell.isFlagged
          ? const Text('🚩', style: TextStyle(fontSize: 16))
          : const SizedBox();
    }
    if (cell.isMine) return const Text('💣', style: TextStyle(fontSize: 16));
    if (cell.adjacentMines == 0) return const SizedBox();
    return Text(
      '${cell.adjacentMines}',
      style: TextStyle(
        color: _cellNumberColor(cell.adjacentMines),
        fontWeight: FontWeight.w900,
        fontSize: 15,
      ),
    );
  }

  Widget _statusChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13)),
    );
  }
}
