import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// MEMORY CARD PAGE — Flip & Match
// ─────────────────────────────────────────────────────────────────────────────

class MemoryCardPage extends StatefulWidget {
  const MemoryCardPage({super.key});
  @override
  State<MemoryCardPage> createState() => _MemoryCardPageState();
}

class _CardModel {
  final String emoji;
  bool isFlipped;
  bool isMatched;
  _CardModel({required this.emoji, this.isFlipped = false, this.isMatched = false});
}

class _MemoryCardPageState extends State<MemoryCardPage>
    with SingleTickerProviderStateMixin {

  static const _emojis = ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼',
                           '🐨','🐯','🦁','🐮','🐷','🐸','🐵','🐔'];

  late List<_CardModel> _cards;
  List<int> _flippedIndices = [];
  bool _checking = false;
  int _moves = 0;
  int _matches = 0;
  bool _gameOver = false;
  int _timeElapsed = 0;
  Timer? _timer;
  int _difficulty = 4; // 4x4 grid = 16 cards (8 pairs)

  @override
  void initState() {
    super.initState();
    _initGame();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _initGame() {
    _timer?.cancel();
    final count = (_difficulty * _difficulty) ~/ 2;
    final used = _emojis.take(count).toList();
    final all = [...used, ...used]..shuffle(Random());
    _cards = all.map((e) => _CardModel(emoji: e)).toList();
    _flippedIndices = [];
    _checking = false;
    _moves = 0;
    _matches = 0;
    _gameOver = false;
    _timeElapsed = 0;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && !_gameOver) setState(() => _timeElapsed++);
    });
  }

  void _onTap(int idx) {
    if (_checking) return;
    if (_cards[idx].isFlipped || _cards[idx].isMatched) return;
    if (_flippedIndices.length >= 2) return;

    setState(() => _cards[idx].isFlipped = true);
    _flippedIndices.add(idx);

    if (_flippedIndices.length == 2) {
      _moves++;
      _checking = true;
      Future.delayed(const Duration(milliseconds: 800), _checkMatch);
    }
  }

  void _checkMatch() {
    final a = _flippedIndices[0];
    final b = _flippedIndices[1];
    setState(() {
      if (_cards[a].emoji == _cards[b].emoji) {
        _cards[a].isMatched = true;
        _cards[b].isMatched = true;
        _matches++;
        if (_matches == (_difficulty * _difficulty) ~/ 2) {
          _gameOver = true;
          _timer?.cancel();
        }
      } else {
        _cards[a].isFlipped = false;
        _cards[b].isFlipped = false;
      }
      _flippedIndices.clear();
      _checking = false;
    });
  }

  String _formatTime(int s) {
    final m = s ~/ 60;
    final sec = s % 60;
    return '${m.toString().padLeft(2, '0')}:${sec.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF060811),
      appBar: AppBar(
        backgroundColor: Color(0xFF0C0F1E),
        foregroundColor: Colors.white,
        title: const Text('🃏 Memory Card',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => setState(_initGame),
          ),
        ],
      ),
      body: Column(children: [
        // Stats bar
        Container(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          color: Color(0xFF131929),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _statChip(Icons.touch_app_rounded, '$_moves', 'Giliran', const Color(0xFF1E88E5)),
            _statChip(Icons.check_circle_outline_rounded, '$_matches/${(_difficulty * _difficulty) ~/ 2}', 'Match', Color(0xFF00E676)),
            _statChip(Icons.timer_outlined, _formatTime(_timeElapsed), 'Waktu', Color(0xFFFFAB00)),
          ]),
        ),
        // Difficulty selector
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(children: [
            const Text('Difficulty: ', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ...[[2, '2x2'], [3, '3x4'], [4, '4x4']].map((d) {
              final val = d[0] as int;
              final isSelected = _difficulty == val;
              return Padding(
                padding: const EdgeInsets.only(left: 8),
                child: GestureDetector(
                  onTap: () => setState(() { _difficulty = val; _initGame(); }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: isSelected ? const Color(0xFF1E88E5) : Color(0xFF131929),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: isSelected ? const Color(0xFF1E88E5) : Color(0xFF1C2540)),
                    ),
                    child: Text(d[1] as String,
                        style: TextStyle(
                            color: isSelected ? Colors.white : Colors.white54,
                            fontSize: 11, fontWeight: FontWeight.w600)),
                  ),
                ),
              );
            }),
          ]),
        ),
        // Game grid
        Expanded(
          child: _gameOver
              ? _buildWin()
              : Padding(
                  padding: const EdgeInsets.all(12),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: _difficulty,
                      mainAxisSpacing: 8,
                      crossAxisSpacing: 8,
                    ),
                    itemCount: _cards.length,
                    itemBuilder: (_, i) => _buildCard(i),
                  ),
                ),
        ),
      ]),
    );
  }

  Widget _buildCard(int i) {
    final card = _cards[i];
    final isRevealed = card.isFlipped || card.isMatched;

    return GestureDetector(
      onTap: () => _onTap(i),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          color: card.isMatched
              ? const Color(0xFF166534)
              : isRevealed
                  ? const Color(0xFF1A2354)
                  : Color(0xFF131929),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: card.isMatched
                ? Color(0xFF00E676)
                : isRevealed
                    ? const Color(0xFF1E88E5)
                    : Color(0xFF1C2540),
            width: 1.5,
          ),
          boxShadow: isRevealed ? [
            BoxShadow(
              color: (card.isMatched ? Color(0xFF00E676) : const Color(0xFF1E88E5))
                  .withOpacity(0.4),
              blurRadius: 12,
            ),
          ] : null,
        ),
        child: Center(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 200),
            child: isRevealed
                ? Text(card.emoji,
                    key: const ValueKey('emoji'),
                    style: const TextStyle(fontSize: 32))
                : const Icon(Icons.help_outline_rounded,
                    key: ValueKey('back'),
                    color: Color(0xFF1E88E5), size: 28),
          ),
        ),
      ),
    );
  }

  Widget _buildWin() {
    final rating = _moves <= (_difficulty * _difficulty) ~/ 2 + 4
        ? '⭐⭐⭐'
        : _moves <= (_difficulty * _difficulty)
            ? '⭐⭐'
            : '⭐';
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('🎉', style: TextStyle(fontSize: 64)),
        const SizedBox(height: 12),
        const Text('SELESAI!', style: TextStyle(
            color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Text(rating, style: const TextStyle(fontSize: 32)),
        const SizedBox(height: 12),
        Text('Waktu: ${_formatTime(_timeElapsed)}',
            style: const TextStyle(color: Colors.white70, fontSize: 16)),
        Text('Total Giliran: $_moves',
            style: const TextStyle(color: Colors.white70, fontSize: 16)),
        const SizedBox(height: 24),
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF1E88E5),
            foregroundColor: Colors.white,
            minimumSize: const Size(180, 50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          icon: const Icon(Icons.refresh_rounded),
          label: const Text('Main Lagi',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          onPressed: () => setState(_initGame),
        ),
      ]),
    );
  }

  Widget _statChip(IconData icon, String value, String label, Color color) {
    return Column(children: [
      Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 4),
        Text(value, style: TextStyle(
            color: color, fontWeight: FontWeight.w800, fontSize: 16)),
      ]),
      Text(label, style: const TextStyle(color: Colors.white54, fontSize: 10)),
    ]);
  }
}
