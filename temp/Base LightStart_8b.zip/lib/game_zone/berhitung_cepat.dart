import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// BERHITUNG CEPAT GAME
// ─────────────────────────────────────────────────────────────────────────────

class BerhitungCepatPage extends StatefulWidget {
  const BerhitungCepatPage({super.key});
  @override
  State<BerhitungCepatPage> createState() => _BerhitungCepatPageState();
}

class _BerhitungCepatPageState extends State<BerhitungCepatPage>
    with SingleTickerProviderStateMixin {
  static const int _timeLimit = 30;
  final _rng = Random();

  int _num1 = 0, _num2 = 0;
  String _op = '+';
  int _answer = 0;
  List<int> _choices = [];

  int _score = 0;
  int _best = 0;
  int _timeLeft = _timeLimit;
  int _streak = 0;
  bool _started = false;
  bool _finished = false;
  Timer? _timer;

  late AnimationController _flashCtrl;
  late Animation<Color?> _flashAnim;
  Color _bgFlash = Colors.transparent;

  @override
  void initState() {
    super.initState();
    _flashCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 300));
    _generateQuestion();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _flashCtrl.dispose();
    super.dispose();
  }

  void _generateQuestion() {
    final ops = ['+', '-', '×'];
    _op = ops[_rng.nextInt(3)];
    switch (_op) {
      case '+':
        _num1 = _rng.nextInt(50) + 1;
        _num2 = _rng.nextInt(50) + 1;
        _answer = _num1 + _num2;
        break;
      case '-':
        _num1 = _rng.nextInt(50) + 10;
        _num2 = _rng.nextInt(_num1) + 1;
        _answer = _num1 - _num2;
        break;
      case '×':
        _num1 = _rng.nextInt(10) + 1;
        _num2 = _rng.nextInt(10) + 1;
        _answer = _num1 * _num2;
        break;
    }

    // Generate 4 choices including the correct one
    final Set<int> choiceSet = {_answer};
    while (choiceSet.length < 4) {
      final wrong = _answer + _rng.nextInt(21) - 10;
      if (wrong != _answer && wrong > 0) choiceSet.add(wrong);
    }
    _choices = choiceSet.toList()..shuffle();
    setState(() {});
  }

  void _startGame() {
    _score = 0;
    _streak = 0;
    _timeLeft = _timeLimit;
    _finished = false;
    _started = true;
    _generateQuestion();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() {
        _timeLeft--;
        if (_timeLeft <= 0) {
          t.cancel();
          _finished = true;
          if (_score > _best) _best = _score;
        }
      });
    });
    setState(() {});
  }

  void _onChoiceTap(int val) {
    if (!_started || _finished) return;
    if (val == _answer) {
      _streak++;
      final bonus = _streak >= 3 ? 20 : 10;
      _score += bonus;
      _bgFlash = Colors.greenAccent.withOpacity(0.3);
    } else {
      _streak = 0;
      _bgFlash = Colors.redAccent.withOpacity(0.3);
    }
    _flashCtrl.forward(from: 0).then((_) {
      setState(() => _bgFlash = Colors.transparent);
    });
    _generateQuestion();
  }

  @override
  Widget build(BuildContext context) {
    final pct = _timeLeft / _timeLimit;
    final timerColor = pct > 0.5
        ? Colors.greenAccent
        : pct > 0.25
            ? Colors.orange
            : Colors.redAccent;

    return Scaffold(
      backgroundColor: Color.lerp(const Color(0xFF0F172A), _bgFlash, 0.5)!,
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        foregroundColor: Colors.white,
        title: const Text('Berhitung Cepat ⚡',
            style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: !_started && !_finished
            ? _buildStart()
            : _finished
                ? _buildFinish()
                : _buildGame(timerColor, pct),
      ),
    );
  }

  Widget _buildStart() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('⚡', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 16),
            const Text('Berhitung Cepat',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('Jawab sebanyak mungkin\ndalam $_timeLimit detik!',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white60, fontSize: 16)),
            const SizedBox(height: 8),
            const Text('Streak 3+ = bonus poin! 🔥',
                style: TextStyle(color: Colors.amber, fontSize: 14)),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _startGame,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6D28D9),
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('MULAI', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            if (_best > 0) ...[
              const SizedBox(height: 16),
              Text('Rekor terbaik: $_best poin',
                  style: const TextStyle(color: Colors.amber)),
            ],
          ],
        ),
      );

  Widget _buildFinish() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('⏱️', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 16),
            const Text('Waktu Habis!',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Color(0xFF6D28D9), Color(0xFF4C1D95)]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  const Text('Skor Kamu',
                      style: TextStyle(color: Colors.white60)),
                  Text('$_score',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 48,
                          fontWeight: FontWeight.bold)),
                  const Divider(color: Colors.white30),
                  Text('Rekor: $_best',
                      style: const TextStyle(color: Colors.amber)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: _startGame,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6D28D9),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 32, vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Main Lagi'),
                ),
              ],
            ),
          ],
        ),
      );

  Widget _buildGame(Color timerColor, double pct) => Column(
        children: [
          // Timer & Score
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      const Text('SKOR',
                          style:
                              TextStyle(color: Colors.white54, fontSize: 11)),
                      Text('$_score',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      const Text('WAKTU',
                          style:
                              TextStyle(color: Colors.white54, fontSize: 11)),
                      Text('$_timeLeft',
                          style: TextStyle(
                              color: timerColor,
                              fontSize: 24,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
              if (_streak >= 2) ...[
                const SizedBox(width: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      const Text('🔥 STREAK',
                          style:
                              TextStyle(color: Colors.white54, fontSize: 11)),
                      Text('$_streak',
                          style: const TextStyle(
                              color: Colors.amber,
                              fontSize: 24,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),
          // Progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: pct,
              backgroundColor: const Color(0xFF1E293B),
              color: timerColor,
              minHeight: 8,
            ),
          ),
          const Spacer(),
          // Question
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFF1E293B), Color(0xFF0F172A)]),
              borderRadius: BorderRadius.circular(20),
              border:
                  Border.all(color: const Color(0xFF334155), width: 1),
            ),
            child: Text(
              '$_num1  $_op  $_num2  =  ?',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 36,
                  fontWeight: FontWeight.bold),
            ),
          ),
          const Spacer(),
          // Choices
          GridView.count(
            shrinkWrap: true,
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 2.2,
            physics: const NeverScrollableScrollPhysics(),
            children: _choices
                .map((c) => ElevatedButton(
                      onPressed: () => _onChoiceTap(c),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF334155),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: Text('$c',
                          style: const TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold)),
                    ))
                .toList(),
          ),
          const SizedBox(height: 20),
        ],
      );
}
