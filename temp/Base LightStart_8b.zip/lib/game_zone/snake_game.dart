import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────────────────────────────────────
// SNAKE GAME PAGE
// ─────────────────────────────────────────────────────────────────────────────

class SnakeGamePage extends StatefulWidget {
  const SnakeGamePage({super.key});
  @override
  State<SnakeGamePage> createState() => _SnakeGamePageState();
}

class _SnakeGamePageState extends State<SnakeGamePage> {
  static const int cols = 20;
  static const int rows = 20;

  List<Offset> snake = [];
  Offset food = const Offset(10, 10);
  Offset direction = const Offset(1, 0);
  Offset nextDir = const Offset(1, 0);
  bool running = false;
  bool gameOver = false;
  int score = 0;
  int highScore = 0;
  Timer? _timer;
  final rng = Random();
  int _speed = 200; // ms

  @override
  void initState() {
    super.initState();
    _resetGame();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _resetGame() {
    _timer?.cancel();
    snake = [
      const Offset(10, 10),
      const Offset(9, 10),
      const Offset(8, 10),
    ];
    direction = const Offset(1, 0);
    nextDir = const Offset(1, 0);
    _spawnFood();
    score = 0;
    running = false;
    gameOver = false;
    _speed = 200;
  }

  void _spawnFood() {
    Offset pos;
    do {
      pos = Offset(rng.nextInt(cols).toDouble(), rng.nextInt(rows).toDouble());
    } while (snake.contains(pos));
    food = pos;
  }

  void _startGame() {
    running = true;
    _timer?.cancel();
    _timer = Timer.periodic(Duration(milliseconds: _speed), (_) => _tick());
  }

  void _tick() {
    if (!running || !mounted) return;
    setState(() {
      direction = nextDir;
      final head = snake.first;
      final newHead = Offset(
        (head.dx + direction.dx) % cols,
        (head.dy + direction.dy) % rows,
      );
      // Wall wrap (allow) — check self collision
      if (snake.contains(newHead)) {
        running = false;
        gameOver = true;
        if (score > highScore) highScore = score;
        _timer?.cancel();
        return;
      }
      snake.insert(0, newHead);
      if (newHead == food) {
        score++;
        _spawnFood();
        // Speed up every 5 points
        if (score % 5 == 0 && _speed > 80) {
          _speed -= 20;
          _timer?.cancel();
          _timer = Timer.periodic(Duration(milliseconds: _speed), (_) => _tick());
        }
      } else {
        snake.removeLast();
      }
    });
  }

  void _changeDir(Offset newDir) {
    // Prevent reversing
    if (newDir.dx == -direction.dx && newDir.dy == -direction.dy) return;
    nextDir = newDir;
    if (!running && !gameOver) {
      _startGame();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF060811),
      appBar: AppBar(
        backgroundColor: Color(0xFF0C0F1E),
        foregroundColor: Colors.white,
        title: const Text('🐍 Snake Game',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text('🏆 $highScore',
                  style: const TextStyle(
                      color: const Color(0xFFFFAB00),
                      fontWeight: FontWeight.w700, fontSize: 14)),
            ),
          ),
        ],
      ),
      body: Column(children: [
        // Score bar
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 8),
          color: Color(0xFF131929),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Skor: ', style: TextStyle(color: Colors.white70, fontSize: 14)),
            Text('$score', style: const TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(width: 20),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF1E88E5).withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF1E88E5).withOpacity(0.5)),
              ),
              child: Text(
                'Speed: ${((400 - _speed) / 300 * 100).round()}%',
                style: const TextStyle(color: Color(0xFF1E88E5), fontSize: 11),
              ),
            ),
          ]),
        ),
        // Game board
        Expanded(
          child: GestureDetector(
            onVerticalDragUpdate: (d) {
              if (d.primaryDelta! < -5) _changeDir(const Offset(0, -1));
              if (d.primaryDelta! > 5) _changeDir(const Offset(0, 1));
            },
            onHorizontalDragUpdate: (d) {
              if (d.primaryDelta! < -5) _changeDir(const Offset(-1, 0));
              if (d.primaryDelta! > 5) _changeDir(const Offset(1, 0));
            },
            child: Center(
              child: AspectRatio(
                aspectRatio: cols / rows,
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: LayoutBuilder(builder: (_, constraints) {
                    final cellW = constraints.maxWidth / cols;
                    final cellH = constraints.maxHeight / rows;
                    return Stack(children: [
                      // Grid background
                      CustomPaint(
                        size: Size(constraints.maxWidth, constraints.maxHeight),
                        painter: _GridPainter(cols, rows),
                      ),
                      // Snake
                      ...snake.asMap().entries.map((e) {
                        final i = e.key;
                        final pos = e.value;
                        final isHead = i == 0;
                        return Positioned(
                          left: pos.dx * cellW + 1,
                          top: pos.dy * cellH + 1,
                          width: cellW - 2,
                          height: cellH - 2,
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 50),
                            decoration: BoxDecoration(
                              color: isHead
                                  ? Color(0xFF00E676)
                                  : Color.lerp(Color(0xFF00E676),
                                      const Color(0xFF166534),
                                      i / snake.length)!,
                              borderRadius: BorderRadius.circular(3),
                              boxShadow: isHead ? [
                                BoxShadow(
                                  color: Color(0xFF00E676).withOpacity(0.8),
                                  blurRadius: 8,
                                ),
                              ] : null,
                            ),
                            child: isHead
                                ? Center(
                                    child: Text(
                                      direction.dx == 1 ? '😊' :
                                      direction.dx == -1 ? '😊' :
                                      direction.dy == 1 ? '😊' : '😊',
                                      style: TextStyle(fontSize: cellW * 0.6),
                                    ),
                                  )
                                : null,
                          ),
                        );
                      }),
                      // Food
                      Positioned(
                        left: food.dx * cellW + 1,
                        top: food.dy * cellH + 1,
                        width: cellW - 2,
                        height: cellH - 2,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFFF1744),
                            borderRadius: BorderRadius.circular(cellW / 2),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFFFF1744).withOpacity(0.8),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text('🍎', style: TextStyle(fontSize: cellW * 0.55)),
                          ),
                        ),
                      ),
                      // Overlay
                      if (!running || gameOver)
                        Container(
                          color: Colors.black54,
                          child: Center(
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              if (gameOver) ...[
                                const Text('💀 GAME OVER',
                                    style: TextStyle(color: const Color(0xFFFF1744),
                                        fontSize: 28, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 8),
                                Text('Skor: $score',
                                    style: const TextStyle(color: Colors.white,
                                        fontSize: 18, fontWeight: FontWeight.w700)),
                                const SizedBox(height: 16),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF1E88E5),
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12)),
                                  ),
                                  onPressed: () => setState(_resetGame),
                                  child: const Text('Main Lagi',
                                      style: TextStyle(fontWeight: FontWeight.w800)),
                                ),
                              ] else ...[
                                const Text('🐍 SNAKE GAME',
                                    style: TextStyle(color: Colors.white,
                                        fontSize: 24, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 12),
                                const Text('Swipe atau tekan D-pad\nuntuk mulai',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(color: Colors.white70, fontSize: 14)),
                                const SizedBox(height: 16),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xFF00E676),
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12)),
                                  ),
                                  onPressed: _startGame,
                                  child: const Text('MULAI',
                                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                                ),
                              ],
                            ]),
                          ),
                        ),
                    ]);
                  }),
                ),
              ),
            ),
          ),
        ),
        // D-PAD Controls
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(children: [
            _dpadBtn(Icons.keyboard_arrow_up_rounded, const Offset(0, -1)),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _dpadBtn(Icons.keyboard_arrow_left_rounded, const Offset(-1, 0)),
              const SizedBox(width: 56),
              _dpadBtn(Icons.keyboard_arrow_right_rounded, const Offset(1, 0)),
            ]),
            _dpadBtn(Icons.keyboard_arrow_down_rounded, const Offset(0, 1)),
          ]),
        ),
      ]),
    );
  }

  Widget _dpadBtn(IconData icon, Offset dir) {
    return GestureDetector(
      onTap: () => _changeDir(dir),
      child: Container(
        width: 52, height: 52,
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: Color(0xFF131929),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF1E88E5).withOpacity(0.5), width: 1.5),
          boxShadow: [BoxShadow(
              color: const Color(0xFF1E88E5).withOpacity(0.2), blurRadius: 8)],
        ),
        child: Icon(icon, color: const Color(0xFF1E88E5), size: 28),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final int cols, rows;
  _GridPainter(this.cols, this.rows);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF1C2540).withOpacity(0.3)
      ..strokeWidth = 0.5;

    final cw = size.width / cols;
    final ch = size.height / rows;

    for (int i = 0; i <= cols; i++) {
      canvas.drawLine(Offset(i * cw, 0), Offset(i * cw, size.height), paint);
    }
    for (int i = 0; i <= rows; i++) {
      canvas.drawLine(Offset(0, i * ch), Offset(size.width, i * ch), paint);
    }

    // Border
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()
        ..color = const Color(0xFF1E88E5).withOpacity(0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
