import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────────────────────────────────────
// 2048 GAME
// ─────────────────────────────────────────────────────────────────────────────

class Game2048Page extends StatefulWidget {
  const Game2048Page({super.key});
  @override
  State<Game2048Page> createState() => _Game2048PageState();
}

class _Game2048PageState extends State<Game2048Page> {
  static const int _size = 4;

  late List<List<int>> _board;
  int  _score    = 0;
  int  _best     = 0;
  bool _gameOver = false;
  bool _won      = false;

  @override
  void initState() {
    super.initState();
    _newGame();
  }

  void _newGame() {
    _board = List.generate(_size, (_) => List.filled(_size, 0));
    _score    = 0;
    _gameOver = false;
    _won      = false;
    _addRandom();
    _addRandom();
    setState(() {});
  }

  void _addRandom() {
    final empty = <List<int>>[];
    for (int r = 0; r < _size; r++)
      for (int c = 0; c < _size; c++)
        if (_board[r][c] == 0) empty.add([r, c]);
    if (empty.isEmpty) return;
    final pos = empty[Random().nextInt(empty.length)];
    _board[pos[0]][pos[1]] = Random().nextInt(10) < 9 ? 2 : 4;
  }

  // Returns new row after merge (left direction)
  List<int> _mergeRow(List<int> row) {
    final filtered = row.where((v) => v != 0).toList();
    final result   = <int>[];
    int i = 0;
    while (i < filtered.length) {
      if (i + 1 < filtered.length && filtered[i] == filtered[i + 1]) {
        final merged = filtered[i] * 2;
        result.add(merged);
        _score += merged;
        if (merged == 2048) _won = true;
        i += 2;
      } else {
        result.add(filtered[i]);
        i++;
      }
    }
    while (result.length < _size) result.add(0);
    return result;
  }

  bool _move(String dir) {
    final before = _board.map((r) => List<int>.from(r)).toList();

    for (int r = 0; r < _size; r++) {
      for (int c = 0; c < _size; c++) {
        // copy intentional
      }
    }

    switch (dir) {
      case 'left':
        for (int r = 0; r < _size; r++) {
          _board[r] = _mergeRow(_board[r]);
        }
        break;
      case 'right':
        for (int r = 0; r < _size; r++) {
          _board[r] = _mergeRow(_board[r].reversed.toList()).reversed.toList();
        }
        break;
      case 'up':
        for (int c = 0; c < _size; c++) {
          final col = List.generate(_size, (r) => _board[r][c]);
          final merged = _mergeRow(col);
          for (int r = 0; r < _size; r++) _board[r][c] = merged[r];
        }
        break;
      case 'down':
        for (int c = 0; c < _size; c++) {
          final col = List.generate(_size, (r) => _board[r][c]).reversed.toList();
          final merged = _mergeRow(col).reversed.toList();
          for (int r = 0; r < _size; r++) _board[r][c] = merged[r];
        }
        break;
    }

    // Check if board changed
    bool changed = false;
    for (int r = 0; r < _size; r++)
      for (int c = 0; c < _size; c++)
        if (_board[r][c] != before[r][c]) changed = true;

    return changed;
  }

  bool _hasMovesLeft() {
    for (int r = 0; r < _size; r++)
      for (int c = 0; c < _size; c++) {
        if (_board[r][c] == 0) return true;
        if (c + 1 < _size && _board[r][c] == _board[r][c + 1]) return true;
        if (r + 1 < _size && _board[r][c] == _board[r + 1][c]) return true;
      }
    return false;
  }

  void _handleSwipe(DragEndDetails det) {
    if (_gameOver) return;
    final dx = det.velocity.pixelsPerSecond.dx;
    final dy = det.velocity.pixelsPerSecond.dy;
    String dir;
    if (dx.abs() > dy.abs()) {
      dir = dx > 0 ? 'right' : 'left';
    } else {
      dir = dy > 0 ? 'down' : 'up';
    }
    HapticFeedback.selectionClick();
    setState(() {
      final moved = _move(dir);
      if (moved) {
        _addRandom();
        if (_score > _best) _best = _score;
        if (!_hasMovesLeft()) _gameOver = true;
      }
    });
  }

  Color _tileColor(int val) {
    const map = {
      0:    Color(0xFF1A2040),
      2:    Color(0xFF3B82F6),
      4:    Color(0xFF2563EB),
      8:    Color(0xFF7C3AED),
      16:   Color(0xFF9333EA),
      32:   Color(0xFFEC4899),
      64:   const Color(0xFFFF1744),
      128:  const Color(0xFFFFAB00),
      256:  Color(0xFF10B981),
      512:  Color(0xFF06B6D4),
      1024: Color(0xFF8B5CF6),
      2048: Color(0xFFFCD34D),
    };
    return map[val] ?? const Color(0xFF6D28D9);
  }

  double _fontSize(int val) {
    if (val >= 1000) return 18;
    if (val >= 100)  return 22;
    return 26;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF060811),
      appBar: AppBar(
        backgroundColor: Color(0xFF0C0F1E),
        foregroundColor: Colors.white,
        title: const Text('🔢 2048',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => setState(_newGame),
          ),
        ],
      ),
      body: Column(children: [
        // Score bar
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Row(children: [
            _ScoreBox(label: 'SCORE', value: _score),
            const SizedBox(width: 12),
            _ScoreBox(label: 'BEST', value: _best),
            const Spacer(),
            GestureDetector(
              onTap: () => setState(_newGame),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFF3B82F6),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text('NEW',
                    style: TextStyle(color: Colors.white,
                        fontWeight: FontWeight.w800, fontSize: 13)),
              ),
            ),
          ]),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text('← Swipe untuk gerak →',
              style: TextStyle(color: Colors.white38, fontSize: 12)),
        ),
        const SizedBox(height: 8),
        // Board
        Expanded(
          child: Center(
            child: GestureDetector(
              onHorizontalDragEnd: _handleSwipe,
              onVerticalDragEnd:   _handleSwipe,
              child: AspectRatio(
                aspectRatio: 1,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Stack(children: [
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF0D1A3A),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: Color(0xFF1C2540), width: 1.5),
                      ),
                      padding: const EdgeInsets.all(8),
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: _size,
                          mainAxisSpacing: 8,
                          crossAxisSpacing: 8,
                        ),
                        itemCount: _size * _size,
                        itemBuilder: (_, idx) {
                          final r = idx ~/ _size;
                          final c = idx % _size;
                          final val = _board[r][c];
                          return AnimatedContainer(
                            duration: const Duration(milliseconds: 100),
                            decoration: BoxDecoration(
                              color: _tileColor(val),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: val > 0
                                  ? [BoxShadow(
                                      color: _tileColor(val).withOpacity(0.5),
                                      blurRadius: 8)]
                                  : null,
                            ),
                            child: Center(
                              child: val == 0
                                  ? null
                                  : Text('$val',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w900,
                                          fontSize: _fontSize(val),
                                          shadows: const [
                                            Shadow(
                                                color: Colors.black38,
                                                blurRadius: 4)
                                          ])),
                            ),
                          );
                        },
                      ),
                    ),
                    // Game Over overlay
                    if (_gameOver && !_won)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('😔 GAME OVER',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 26,
                                        fontWeight: FontWeight.w900)),
                                const SizedBox(height: 16),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF3B82F6),
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(12)),
                                  ),
                                  onPressed: () => setState(_newGame),
                                  child: const Text('Coba Lagi',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700)),
                                ),
                              ]),
                        ),
                      ),
                    // Win overlay
                    if (_won)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('🎉 2048!',
                                    style: TextStyle(
                                        color: Color(0xFFFCD34D),
                                        fontSize: 36,
                                        fontWeight: FontWeight.w900)),
                                const SizedBox(height: 8),
                                const Text('Kamu Menang!',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 18)),
                                const SizedBox(height: 16),
                                Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.center,
                                    children: [
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor:
                                              const Color(0xFF3B82F6),
                                          foregroundColor: Colors.white,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12)),
                                        ),
                                        onPressed: () {
                                          setState(() => _won = false);
                                        },
                                        child: const Text('Lanjut',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w700)),
                                      ),
                                      const SizedBox(width: 10),
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor:
                                              const Color(0xFF10B981),
                                          foregroundColor: Colors.white,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12)),
                                        ),
                                        onPressed: () => setState(_newGame),
                                        child: const Text('Baru',
                                            style: TextStyle(
                                                fontWeight: FontWeight.w700)),
                                      ),
                                    ]),
                              ]),
                        ),
                      ),
                  ]),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
      ]),
    );
  }
}

class _ScoreBox extends StatelessWidget {
  final String label;
  final int value;
  const _ScoreBox({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1A3A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Color(0xFF1C2540)),
      ),
      child: Column(children: [
        Text(label,
            style: const TextStyle(
                color: Color(0xFF7B8DB3), fontSize: 10,
                fontWeight: FontWeight.w700, letterSpacing: 1)),
        Text('$value',
            style: const TextStyle(
                color: Colors.white, fontSize: 20,
                fontWeight: FontWeight.w800)),
      ]),
    );
  }
}
