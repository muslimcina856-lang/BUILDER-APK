import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────────────────────────────────────
// TEBAK KATA (WORDLE-STYLE) - hanya kata 5 huruf
// ─────────────────────────────────────────────────────────────────────────────

class TebakKataPage extends StatefulWidget {
  const TebakKataPage({super.key});
  @override
  State<TebakKataPage> createState() => _TebakKataPageState();
}

class _TebakKataPageState extends State<TebakKataPage> {
  static const int _maxGuesses = 6;
  static const int _wordLen = 5;

  // Semua kata tepat 5 huruf
  static const List<String> _words = [
    'PINTU', 'LAMPU', 'BUNGA', 'RUMAH', 'POHON',
    'ANGIN', 'HUJAN', 'SINAR', 'GELAP', 'PANAS',
    'MERAH', 'HITAM', 'PUTIH', 'HIJAU', 'PERAK',
    'DALAM', 'BAWAH', 'INGIN', 'MALAM', 'SIANG',
    'PAGAR', 'PAPAN', 'TANAM', 'TAMAN', 'KAPAL',
    'PASAR', 'JALAN', 'SAWAH', 'DANAU', 'MACAN',
    'SINGA', 'GAJAH', 'LEMBU', 'BEBEK', 'BENAR',
    'SALAH', 'CEPAT', 'KERAS', 'LUNAK', 'BESAR',
    'KECIL', 'PANJANG', 'INDAH', 'MAHAL', 'MURAH',
    'SENANG', 'SEDIH', 'MARAH', 'TAKUT', 'BERANI',
  ];

  late String _target;
  List<String> _guesses = [];
  String _current = '';
  bool _won = false;
  bool _lost = false;
  int _score = 0;
  int _wins = 0;

  // Key state: 0=unknown, 1=wrong, 2=misplaced, 3=correct
  final Map<String, int> _keyState = {};

  final FocusNode _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _newGame();
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  void _newGame() {
    final valid = _words.where((w) => w.length == _wordLen).toList();
    _target = valid[Random().nextInt(valid.length)];
    _guesses = [];
    _current = '';
    _won = false;
    _lost = false;
    _keyState.clear();
    setState(() {});
    Future.delayed(
        const Duration(milliseconds: 100), () => _focus.requestFocus());
  }

  void _onKey(String char) {
    if (_won || _lost) return;
    if (char == '⌫') {
      if (_current.isNotEmpty) {
        setState(() => _current = _current.substring(0, _current.length - 1));
      }
      return;
    }
    if (char == 'ENTER') {
      _submitGuess();
      return;
    }
    if (_current.length < _wordLen) {
      setState(() => _current += char);
    }
  }

  void _submitGuess() {
    if (_current.length != _wordLen) return;
    final guess = _current.toUpperCase();
    setState(() {
      _guesses.add(guess);
      _current = '';

      for (int i = 0; i < _wordLen; i++) {
        final ch = guess[i];
        if (_target[i] == ch) {
          _keyState[ch] = 3;
        } else if (_target.contains(ch)) {
          final cur = _keyState[ch] ?? 0;
          if (cur < 2) _keyState[ch] = 2;
        } else {
          final cur = _keyState[ch] ?? 0;
          if (cur == 0) _keyState[ch] = 1;
        }
      }

      if (guess == _target) {
        _won = true;
        final bonus = (_maxGuesses - _guesses.length + 1) * 20;
        _score += bonus;
        _wins++;
      } else if (_guesses.length >= _maxGuesses) {
        _lost = true;
      }
    });
  }

  Color _tileColor(int guessIdx, int charIdx) {
    if (guessIdx >= _guesses.length) return const Color(0xFF1E293B);
    final guess = _guesses[guessIdx];
    if (charIdx >= guess.length) return const Color(0xFF1E293B);
    final ch = guess[charIdx];
    if (_target[charIdx] == ch) return Color(0xFF00E676);
    if (_target.contains(ch)) return Color(0xFFFFAB00);
    return const Color(0xFF374151);
  }

  Color _keyColor(String key) {
    switch (_keyState[key] ?? 0) {
      case 3:
        return Color(0xFF00E676);
      case 2:
        return Color(0xFFFFAB00);
      case 1:
        return const Color(0xFF374151);
      default:
        return const Color(0xFF475569);
    }
  }

  static const List<String> _row1 = [
    'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'
  ];
  static const List<String> _row2 = [
    'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'
  ];
  static const List<String> _row3 = [
    'ENT', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '⌫'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        foregroundColor: Colors.white,
        title: const Text('Tebak Kata 🔤',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Center(
                child: Text('🏆 $_wins menang',
                    style: const TextStyle(color: Colors.amber))),
          ),
          IconButton(
              icon: const Icon(Icons.refresh_rounded), onPressed: _newGame),
        ],
      ),
      body: GestureDetector(
        onTap: () => _focus.requestFocus(),
        child: Focus(
          focusNode: _focus,
          onKeyEvent: (node, event) {
            if (event is KeyDownEvent) {
              final label = event.logicalKey.keyLabel.toUpperCase();
              if (label.length == 1 && RegExp(r'[A-Z]').hasMatch(label)) {
                _onKey(label);
                return KeyEventResult.handled;
              }
              if (event.logicalKey == LogicalKeyboardKey.backspace) {
                _onKey('⌫');
                return KeyEventResult.handled;
              }
              if (event.logicalKey == LogicalKeyboardKey.enter) {
                _onKey('ENTER');
                return KeyEventResult.handled;
              }
            }
            return KeyEventResult.ignored;
          },
          child: Column(
            children: [
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text('Skor: $_score',
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 14)),
                    Text('Tebakan: ${_guesses.length}/$_maxGuesses',
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 14)),
                  ],
                ),
              ),
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: List.generate(_maxGuesses, (gi) {
                      final isCurrentRow =
                          gi == _guesses.length && !_won && !_lost;
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: List.generate(_wordLen, (ci) {
                            String char = '';
                            Color bg = const Color(0xFF1E293B);
                            Color border = const Color(0xFF334155);
                            if (gi < _guesses.length) {
                              char = _guesses[gi][ci];
                              bg = _tileColor(gi, ci);
                              border = bg;
                            } else if (isCurrentRow &&
                                ci < _current.length) {
                              char = _current[ci];
                              border = Colors.white54;
                            }
                            return Container(
                              width: 52,
                              height: 52,
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 3),
                              decoration: BoxDecoration(
                                color: bg,
                                border: Border.all(color: border, width: 2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              alignment: Alignment.center,
                              child: Text(char,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold)),
                            );
                          }),
                        ),
                      );
                    }),
                  ),
                ),
              ),
              if (_won || _lost)
                Container(
                  margin: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 4),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _won
                        ? const Color(0xFF14532D)
                        : const Color(0xFF7F1D1D),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Text(
                            _won
                                ? '🎉 Menang! Kata: $_target'
                                : '😔 Kalah! Kata: $_target',
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(width: 12),
                      TextButton(
                        onPressed: _newGame,
                        child: const Text('Main Lagi',
                            style: TextStyle(color: Colors.amber)),
                      ),
                    ],
                  ),
                ),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  children: [
                    _buildKeyRow(_row1),
                    const SizedBox(height: 6),
                    _buildKeyRow(_row2),
                    const SizedBox(height: 6),
                    _buildKeyRow(_row3),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildKeyRow(List<String> keys) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: keys.map((k) {
          final isWide = k == 'ENT' || k == '⌫';
          return GestureDetector(
            onTap: () {
              if (k == 'ENT') {
                _onKey('ENTER');
              } else {
                _onKey(k);
              }
            },
            child: Container(
              width: isWide ? 48 : 30,
              height: 44,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(
                color: _keyColor(k),
                borderRadius: BorderRadius.circular(6),
              ),
              alignment: Alignment.center,
              child: Text(k,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: k.length > 1 ? 10 : 14,
                      fontWeight: FontWeight.bold)),
            ),
          );
        }).toList(),
      );
}
