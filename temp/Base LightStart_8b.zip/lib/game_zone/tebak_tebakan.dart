import 'dart:async';
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
// TEBAK-TEBAKAN PAGE — Quiz Game
// ─────────────────────────────────────────────────────────────────────────────

class TebakTebakanPage extends StatefulWidget {
  const TebakTebakanPage({super.key});
  @override
  State<TebakTebakanPage> createState() => _TebakTebakanPageState();
}

class _TebakTebakanPageState extends State<TebakTebakanPage>
    with SingleTickerProviderStateMixin {

  final List<Map<String, dynamic>> _allQuestions = [
    {'q': 'Ibu kota Indonesia?', 'a': ['Jakarta', 'Surabaya', 'Bandung', 'Medan'], 'correct': 0},
    {'q': 'Berapakah 12 × 12?', 'a': ['124', '144', '132', '148'], 'correct': 1},
    {'q': 'Warna bendera Indonesia?', 'a': ['Merah Putih', 'Biru Putih', 'Merah Biru', 'Kuning Hijau'], 'correct': 0},
    {'q': 'Siapa penemu bola lampu?', 'a': ['Newton', 'Edison', 'Tesla', 'Einstein'], 'correct': 1},
    {'q': 'Planet terbesar di tata surya?', 'a': ['Mars', 'Saturnus', 'Jupiter', 'Neptunus'], 'correct': 2},
    {'q': 'Bahasa pemrograman Flutter?', 'a': ['Python', 'Kotlin', 'Dart', 'Swift'], 'correct': 2},
    {'q': 'Berapa sisi segitiga?', 'a': ['2', '3', '4', '5'], 'correct': 1},
    {'q': 'Gunung tertinggi di Indonesia?', 'a': ['Rinjani', 'Semeru', 'Jayawijaya', 'Bromo'], 'correct': 2},
    {'q': 'Presiden pertama Indonesia?', 'a': ['Soeharto', 'Soekarno', 'Habibie', 'Gus Dur'], 'correct': 1},
    {'q': 'Simbol kimia emas?', 'a': ['Ag', 'Fe', 'Au', 'Cu'], 'correct': 2},
    {'q': 'Hewan dengan garis hitam putih?', 'a': ['Harimau', 'Zebra', 'Panda', 'Macan'], 'correct': 1},
    {'q': 'Berapa angka romawi X?', 'a': ['5', '10', '15', '20'], 'correct': 1},
    {'q': 'Lagu kebangsaan Indonesia?', 'a': ['Garuda Pancasila', 'Indonesia Raya', 'Tanah Air', 'Bagimu Negeri'], 'correct': 1},
    {'q': 'Kota yang disebut "Kota Kembang"?', 'a': ['Yogyakarta', 'Semarang', 'Bandung', 'Solo'], 'correct': 2},
    {'q': 'Hewan terbesar di darat?', 'a': ['Jerapah', 'Kuda nil', 'Gajah', 'Badak'], 'correct': 2},
  ];

  late List<Map<String, dynamic>> _questions;
  int _currentQ = 0;
  int _score = 0;
  int? _selectedAnswer;
  bool _answered = false;
  bool _gameOver = false;
  int _timeLeft = 15;
  Timer? _timer;

  late AnimationController _animCtrl;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _scaleAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.elasticOut);
    _questions = List.from(_allQuestions)..shuffle();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _animCtrl.dispose();
    super.dispose();
  }

  void _startTimer() {
    _timer?.cancel();
    _timeLeft = 15;
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _timeLeft--);
      if (_timeLeft <= 0) {
        t.cancel();
        if (!_answered) {
          setState(() => _answered = true);
          Future.delayed(const Duration(milliseconds: 1200), _nextQuestion);
        }
      }
    });
  }

  void _answer(int idx) {
    if (_answered) return;
    _timer?.cancel();
    _animCtrl.forward(from: 0);
    final correct = _questions[_currentQ]['correct'] as int;
    setState(() {
      _selectedAnswer = idx;
      _answered = true;
      if (idx == correct) _score++;
    });
    Future.delayed(const Duration(milliseconds: 1000), _nextQuestion);
  }

  void _nextQuestion() {
    if (!mounted) return;
    if (_currentQ + 1 >= _questions.length) {
      setState(() => _gameOver = true);
      return;
    }
    setState(() {
      _currentQ++;
      _selectedAnswer = null;
      _answered = false;
    });
    _startTimer();
  }

  void _restart() {
    _questions = List.from(_allQuestions)..shuffle();
    setState(() {
      _currentQ = 0; _score = 0;
      _selectedAnswer = null; _answered = false; _gameOver = false;
    });
    _startTimer();
  }

  Color _btnColor(int idx) {
    if (!_answered) return Color(0xFF131929);
    final correct = _questions[_currentQ]['correct'] as int;
    if (idx == correct) return const Color(0xFF166534);
    if (idx == _selectedAnswer) return const Color(0xFF7F1D1D);
    return Color(0xFF131929);
  }

  Color _btnBorder(int idx) {
    if (!_answered) return Color(0xFF1C2540);
    final correct = _questions[_currentQ]['correct'] as int;
    if (idx == correct) return Color(0xFF00E676);
    if (idx == _selectedAnswer) return Color(0xFFFF1744);
    return Color(0xFF1C2540);
  }

  @override
  Widget build(BuildContext context) {
    if (_gameOver) return _buildResult();

    final q = _questions[_currentQ];
    final answers = q['a'] as List<String>;
    final labels = ['A', 'B', 'C', 'D'];

    return Scaffold(
      backgroundColor: Color(0xFF060811),
      appBar: AppBar(
        backgroundColor: Color(0xFF0C0F1E),
        foregroundColor: Colors.white,
        title: const Text('🧠 Tebak-Tebakan',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text('⭐ $_score',
                  style: const TextStyle(
                      color: const Color(0xFFFFAB00),
                      fontWeight: FontWeight.w800, fontSize: 16)),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          // Progress bar
          Row(children: [
            Text('${_currentQ + 1}/${_questions.length}',
                style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(width: 10),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: (_currentQ + 1) / _questions.length,
                  backgroundColor: Color(0xFF1C2540),
                  valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF1E88E5)),
                  minHeight: 8,
                ),
              ),
            ),
          ]),
          const SizedBox(height: 16),
          // Timer
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.timer_outlined,
                color: _timeLeft <= 5 ? Color(0xFFFF1744) : const Color(0xFF1E88E5),
                size: 20),
            const SizedBox(width: 6),
            Text('$_timeLeft detik',
                style: TextStyle(
                    color: _timeLeft <= 5 ? Color(0xFFFF1744) : Colors.white70,
                    fontWeight: FontWeight.w700, fontSize: 14)),
          ]),
          const SizedBox(height: 20),
          // Question
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [const Color(0xFF131929), Color(0xFF1A2354)]),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Color(0xFF1C2540), width: 1.5),
              boxShadow: [BoxShadow(
                  color: const Color(0xFF1E88E5).withOpacity(0.2),
                  blurRadius: 20)],
            ),
            child: Text(q['q'] as String,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.white, fontSize: 18,
                    fontWeight: FontWeight.w700, height: 1.4)),
          ),
          const SizedBox(height: 24),
          // Answer buttons
          ...List.generate(answers.length, (i) {
            final isCorrect = i == (q['correct'] as int);
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ScaleTransition(
                scale: _answered && isCorrect ? _scaleAnim : const AlwaysStoppedAnimation(1.0),
                child: GestureDetector(
                  onTap: () => _answer(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                    decoration: BoxDecoration(
                      color: _btnColor(i),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _btnBorder(i), width: 1.5),
                    ),
                    child: Row(children: [
                      Container(
                        width: 28, height: 28,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF1E88E5).withOpacity(0.2),
                          border: Border.all(color: const Color(0xFF1E88E5), width: 1),
                        ),
                        child: Center(
                          child: Text(labels[i],
                              style: const TextStyle(
                                  color: Color(0xFF1E88E5),
                                  fontWeight: FontWeight.w800, fontSize: 12)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(answers[i],
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14, fontWeight: FontWeight.w600)),
                      ),
                      if (_answered && isCorrect)
                        const Icon(Icons.check_circle_rounded,
                            color: const Color(0xFF00E676), size: 20),
                      if (_answered && i == _selectedAnswer && !isCorrect)
                        const Icon(Icons.cancel_rounded,
                            color: const Color(0xFFFF1744), size: 20),
                    ]),
                  ),
                ),
              ),
            );
          }),
        ]),
      ),
    );
  }

  Widget _buildResult() {
    final pct = (_score / _questions.length * 100).round();
    final emoji = pct >= 80 ? '🏆' : pct >= 60 ? '😊' : pct >= 40 ? '😐' : '😢';
    final msg = pct >= 80 ? 'Luar Biasa!' : pct >= 60 ? 'Bagus!' : pct >= 40 ? 'Lumayan' : 'Belajar Lagi!';

    return Scaffold(
      backgroundColor: Color(0xFF060811),
      appBar: AppBar(
        backgroundColor: Color(0xFF0C0F1E),
        foregroundColor: Colors.white,
        title: const Text('Hasil', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(emoji, style: const TextStyle(fontSize: 80)),
            const SizedBox(height: 16),
            Text(msg, style: const TextStyle(
                color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text('$_score / ${_questions.length} Benar ($pct%)',
                style: const TextStyle(
                    color: const Color(0xFFFFAB00),
                    fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Text(
              pct >= 80 ? 'Kamu jenius!' : pct >= 60 ? 'Terus belajar ya!' : 'Coba lagi, kamu pasti bisa!',
              style: const TextStyle(color: Colors.white60, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1E88E5),
                foregroundColor: Colors.white,
                minimumSize: const Size(200, 52),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Main Lagi',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              onPressed: _restart,
            ),
          ]),
        ),
      ),
    );
  }
}
