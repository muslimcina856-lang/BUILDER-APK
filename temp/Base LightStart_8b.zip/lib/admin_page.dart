import 'main.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AdminPage extends StatefulWidget {
  final String sessionKey;
  final String? currentUserRole;

  const AdminPage({
    super.key, 
    required this.sessionKey,
    this.currentUserRole = 'admin',
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late String sessionKey;
  late String currentUserRole;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> allRoles = ['high admin', 'admin', 'reseller', 'vip', 'member'];
  
  List<String> get availableRolesToCreate {
    if (currentUserRole == 'high admin') {
      return ['high admin', 'admin', 'reseller', 'vip', 'member'];
    } else {
      return ['reseller', 'vip', 'member'];
    }
  }

  List<String> get visibleRoles {
    if (currentUserRole == 'high admin') {
      return ['high admin', 'admin', 'reseller', 'vip', 'member'];
    } else {
      return ['reseller', 'vip', 'member'];
    }
  }

  String selectedRole = 'member';
  int currentPage = 1;
  int itemsPerPage = 25;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  // TEMA BIRU PEKAT
  final Color bgDark = AppColors.bg;
  final Color primaryBlue = AppColors.border;
  final Color accentBlue = const Color(0xFF2D4ED8);
  final Color lightBlue = AppColors.cyanDim;
  final Color deepBlue = AppColors.surface;
  final Color putih = Colors.white;
  final Color putihAbu = Colors.white70;
  final Color cardGlass = AppColors.card.withOpacity(0.7);
  final Color borderGlass = AppColors.border.withOpacity(0.5);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    currentUserRole = widget.currentUserRole?.toLowerCase() ?? 'admin';
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://nayahaikall.tyzx-host.my.id:2563/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => visibleRoles.contains(u['role']?.toString().toLowerCase()))
          .toList();
      
      if (selectedRole.isNotEmpty && visibleRoles.contains(selectedRole)) {
        filteredList = filteredList
            .where((u) => u['role']?.toString().toLowerCase() == selectedRole)
            .toList();
      }
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    if (filteredList.isEmpty) return [];
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  bool _canDeleteRole(String targetRole) {
    if (currentUserRole == 'high admin') {
      return ['high admin', 'admin', 'reseller', 'vip', 'member'].contains(targetRole);
    } else {
      return ['reseller', 'vip', 'member'].contains(targetRole);
    }
  }

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    final targetUser = fullUserList.firstWhere(
      (u) => u['username'] == username,
      orElse: () => null,
    );
    
    if (targetUser != null) {
      String targetRole = targetUser['role']?.toString().toLowerCase() ?? '';
      if (!_canDeleteRole(targetRole)) {
        _alert("Akses Ditolak", "Anda tidak memiliki izin untuk menghapus user dengan role $targetRole.");
        return;
      }
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://nayahaikall.tyzx-host.my.id:2563/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    if (!availableRolesToCreate.contains(newUserRole)) {
      _alert("Akses Ditolak", "Anda tidak memiliki izin untuk membuat akun dengan role ${newUserRole.toUpperCase()}.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://nayahaikall.tyzx-host.my.id:2563/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = availableRolesToCreate.isNotEmpty ? availableRolesToCreate.first : 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: deepBlue,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: BorderSide(color: accentBlue.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: lightBlue),
            SizedBox(width: 10),
            Text(title, style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(message, style: TextStyle(color: putihAbu)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                borderRadius: BorderRadius.circular(22),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK", style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String getRoleDisplayName(String role) {
    switch (role.toLowerCase()) {
      case 'high admin': return 'HIGH ADMIN';
      case 'admin': return 'ADMIN';
      case 'reseller': return 'RESELLER';
      case 'vip': return 'VIP';
      case 'member': return 'MEMBER';
      default: return role.toUpperCase();
    }
  }

  Color getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'high admin': return const Color(0xFFFF6B35);
      case 'admin': return accentBlue;
      case 'reseller': return const Color(0xFF4ADE80);
      case 'vip': return const Color(0xFFA78BFA);
      default: return lightBlue;
    }
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: putih),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: lightBlue, fontWeight: FontWeight.w500),
          prefixIcon: Icon(icon, color: accentBlue),
          filled: true,
          fillColor: cardGlass,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: accentBlue, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 25),
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [cardGlass, deepBlue.withOpacity(0.5)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderGlass, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: primaryBlue.withOpacity(0.3),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Icon(icon, color: putih),
              ),
              SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  color: putih,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    String userRole = user['role']?.toString().toLowerCase() ?? '';
    bool canDelete = _canDeleteRole(userRole);
    Color roleColor = getRoleColor(userRole);
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardGlass, deepBlue.withOpacity(0.3)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: putih),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(color: putih, fontWeight: FontWeight.bold, fontSize: 16),
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: roleColor,
                      ),
                    ),
                    SizedBox(width: 6),
                    Text(
                      getRoleDisplayName(user['role']),
                      style: TextStyle(color: roleColor, fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                    SizedBox(width: 12),
                    Text(
                      "Exp: ${user['expiredDate']}",
                      style: TextStyle(color: putihAbu, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (canDelete)
            Container(
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.2),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.redAccent.withOpacity(0.5)),
              ),
              child: IconButton(
                icon: Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: deepBlue,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                        side: BorderSide(color: accentBlue.withOpacity(0.5)),
                      ),
                      title: Text("Konfirmasi", style: TextStyle(color: putih, fontWeight: FontWeight.bold)),
                      content: Text("Hapus user '${user['username']}'?", style: TextStyle(color: putihAbu)),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context, false),
                          child: Text("Batal", style: TextStyle(color: putihAbu)),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(context, true),
                          child: Text("Hapus", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    deleteController.text = user['username'];
                    _deleteUser();
                  }
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return ElevatedButton(
          onPressed: () => setState(() => currentPage = page),
          style: ElevatedButton.styleFrom(
            backgroundColor: currentPage == page ? accentBlue : Colors.transparent,
            foregroundColor: currentPage == page ? putih : putihAbu,
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(22),
              side: BorderSide(color: borderGlass),
            ),
          ),
          child: Text("$page", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isHighAdmin = currentUserRole == 'high admin';
    final titleText = isHighAdmin ? "HIGH ADMIN" : "ADMIN";
    final titleColor = isHighAdmin ? const Color(0xFFFF6B35) : putih;
    
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.5,
            colors: [deepBlue, bgDark, const Color(0xFF050814)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Icon
                Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [AppColors.border, Color(0xFF2D4ED8)]),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: accentBlue.withOpacity(0.5),
                        blurRadius: 20,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: Icon(Icons.admin_panel_settings, color: putih, size: 50),
                ),
                const SizedBox(height: 20),
                
                // TITLE
                Text(
                  titleText,
                  style: TextStyle(
                    color: titleColor,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                    shadows: [
                      Shadow(
                        color: titleColor.withOpacity(0.8),
                        blurRadius: 15,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
                
                // Badge untuk HIGH ADMIN
                if (isHighAdmin)
                  Container(
                    margin: const EdgeInsets.only(top: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFFFF6B35), Color(0xFFCC5500)]),
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: Colors.white, size: 14),
                        SizedBox(width: 6),
                        Text("CREATE ACCOUNT", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                
                const Text(
                  "MANAGEMENT PANEL",
                  style: TextStyle(color: AppColors.cyanDim, fontSize: 14, letterSpacing: 2),
                ),
                const SizedBox(height: 10),
                Container(
                  width: 80,
                  height: 3,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [AppColors.border, Color(0xFF2D4ED8)]),
                    borderRadius: BorderRadius.circular(22),
                  ),
                ),
                const SizedBox(height: 40),

                // ========== DELETE USER ==========
                _buildGlassCard(
                  title: "DELETE USER",
                  icon: FontAwesomeIcons.userSlash,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: deleteController,
                      icon: FontAwesomeIcons.user,
                    ),
                    const SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Colors.redAccent, AppColors.border]),
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _deleteUser,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                        ),
                        child: isLoading
                            ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: putih))
                            : const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.delete, size: 18, color: Colors.white),
                                  SizedBox(width: 8),
                                  Text("DELETE ACCOUNT", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),

                // ========== CREATE ACCOUNT (INI YANG HILANG) ==========
                if (availableRolesToCreate.isNotEmpty)
                  _buildGlassCard(
                    title: "CREATE ACCOUNT",
                    icon: FontAwesomeIcons.userPlus,
                    children: [
                      _buildInput(
                        label: "Username",
                        controller: createUsernameController,
                        icon: FontAwesomeIcons.user,
                      ),
                      _buildInput(
                        label: "Password",
                        controller: createPasswordController,
                        icon: FontAwesomeIcons.lock,
                      ),
                      _buildInput(
                        label: "Durasi (Hari)",
                        controller: createDayController,
                        icon: FontAwesomeIcons.calendarDay,
                        type: TextInputType.number,
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: deepBlue.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: borderGlass),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: newUserRole,
                            dropdownColor: deepBlue,
                            style: TextStyle(color: putih),
                            items: availableRolesToCreate.map((role) {
                              return DropdownMenuItem(
                                value: role,
                                child: Row(
                                  children: [
                                    Container(
                                      width: 10, height: 10,
                                      decoration: BoxDecoration(shape: BoxShape.circle, color: getRoleColor(role)),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(getRoleDisplayName(role), style: TextStyle(color: putih)),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        height: 50,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [AppColors.border, Color(0xFF2D4ED8)]),
                          borderRadius: BorderRadius.circular(22),
                        ),
                        child: ElevatedButton(
                          onPressed: isLoading ? null : _createAccount,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                          ),
                          child: isLoading
                              ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: putih))
                              : const Text("CREATE ACCOUNT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),

                // ========== USER LIST (INI YANG HILANG) ==========
                if (visibleRoles.isNotEmpty)
                  _buildGlassCard(
                    title: "USER MANAGEMENT",
                    icon: FontAwesomeIcons.users,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: deepBlue.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: borderGlass),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selectedRole,
                            dropdownColor: deepBlue,
                            style: TextStyle(color: putih),
                            items: visibleRoles.map((role) {
                              return DropdownMenuItem(
                                value: role,
                                child: Row(
                                  children: [
                                    Container(
                                      width: 10, height: 10,
                                      decoration: BoxDecoration(shape: BoxShape.circle, color: getRoleColor(role)),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(getRoleDisplayName(role), style: TextStyle(color: putih)),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (val) {
                              if (val != null) {
                                selectedRole = val;
                                _filterAndPaginate();
                              }
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      isLoading
                          ? Center(child: CircularProgressIndicator(color: accentBlue))
                          : filteredList.isEmpty
                              ? Center(
                                  child: Padding(
                                    padding: const EdgeInsets.all(40),
                                    child: Text("Tidak ada pengguna", style: TextStyle(color: putihAbu)),
                                  ),
                                )
                              : Column(
                                  children: [
                                    ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                                    const SizedBox(height: 20),
                                    _buildPagination(),
                                  ],
                                ),
                    ],
                  ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}