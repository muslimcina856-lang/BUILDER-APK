import 'dart:math';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'main.dart';

// ─── WARNA KONSISTEN DENGAN APP ───────────────────────────────────────────────
const Color _kBg      = Color(0xFF0A1628);
const Color _kSurface = Color(0xFF0D2240);
const Color _kCard    = Color(0xFF112244);
const Color _kBlue    = Color(0xFF2196F3);
const Color _kBlueLt  = Color(0xFF64B5F6);
const Color _kBlueDk  = Color(0xFF1565C0);
const Color _kText    = AppColors.textPrimary;
const Color _kTextSub = Color(0xFF7B9CBF);
const Color _kBorder  = Color(0xFF1A3A5C);

class MusikPage extends StatefulWidget {
  final AudioPlayer? sharedPlayer;
  final int? initialTrack;
  const MusikPage({super.key, this.sharedPlayer, this.initialTrack});
  @override State<MusikPage> createState() => _MusikPageState();
}

class _MusikPageState extends State<MusikPage>
    with SingleTickerProviderStateMixin {
  late AudioPlayer _player;
  final _searchCtrl = TextEditingController();

  bool _playing = false;
  bool _shuffle = false;
  bool _repeat  = false;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;

  List<Map<String, dynamic>> _results  = [];
  bool   _searching = false;
  String _errMsg    = '';
  Map<String, dynamic>? _nowPlaying;

  final List<String> _genres = [
    'Top Hits', 'Lo-Fi', 'Pop', 'Hip-Hop',
    'R&B', 'Electronic', 'Acoustic', 'K-Pop', 'Indonesia',
  ];

  @override
  void initState() {
    super.initState();
    _player = widget.sharedPlayer ?? AudioPlayer();
    _player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _playing = s == PlayerState.playing);
    });
    _player.onPositionChanged.listen((d) {
      if (mounted) setState(() => _pos = d);
    });
    _player.onDurationChanged.listen((d) {
      if (mounted) setState(() => _dur = d);
    });
    _player.onPlayerComplete.listen((_) => _nextTrack());
    _search('top hits 2024');
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    if (widget.sharedPlayer == null) _player.dispose();
    super.dispose();
  }

  Future<void> _search(String query) async {
    if (query.trim().isEmpty) return;
    setState(() { _searching = true; _errMsg = ''; });
    try {
      final url = Uri.parse(
        'https://itunes.apple.com/search'
        '?term=${Uri.encodeComponent(query)}'
        '&media=music&limit=25&entity=song',
      );
      final res  = await http.get(url).timeout(const Duration(seconds: 12));
      final data = jsonDecode(res.body);
      final list = (data['results'] as List).map((t) => {
        'title'    : t['trackName']      ?? '',
        'artist'   : t['artistName']     ?? '',
        'album'    : t['collectionName'] ?? '',
        'img'      : t['artworkUrl100']  ?? '',
        'preview'  : t['previewUrl']     ?? '',
        'itunesUrl': t['trackViewUrl']   ?? '',
      }).where((t) => (t['preview'] as String).isNotEmpty).toList();
      setState(() { _results = list; _searching = false; });
    } catch (e) {
      setState(() { _errMsg = 'Gagal memuat, coba lagi'; _searching = false; });
    }
  }

  Future<void> _play(Map<String, dynamic> track) async {
    final url = track['preview'] as String;
    if (url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Preview tidak tersedia'),
        backgroundColor: _kBlueDk,
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }
    setState(() { _nowPlaying = track; _pos = Duration.zero; });
    await _player.stop();
    await _player.play(UrlSource(url));
  }

  void _togglePlay() {
    if (_playing) _player.pause();
    else if (_nowPlaying != null) _player.resume();
  }

  void _nextTrack() {
    if (_results.isEmpty || _nowPlaying == null) return;
    final idx = _results.indexWhere((t) => t['title'] == _nowPlaying!['title']);
    if (idx < 0) return;
    int next;
    if (_shuffle) {
      do { next = Random().nextInt(_results.length); }
      while (next == idx && _results.length > 1);
    } else if (_repeat) {
      next = idx;
    } else {
      next = (idx + 1) % _results.length;
    }
    _play(_results[next]);
  }

  void _prevTrack() {
    if (_results.isEmpty || _nowPlaying == null) return;
    final idx = _results.indexWhere((t) => t['title'] == _nowPlaying!['title']);
    if (idx < 0) return;
    _play(_results[(idx - 1 + _results.length) % _results.length]);
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _albumArt(String url, {double size = 46}) => ClipRRect(
    borderRadius: BorderRadius.circular(size * 0.2),
    child: url.isNotEmpty
        ? Image.network(url, width: size, height: size, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _artFallback(size))
        : _artFallback(size),
  );

  Widget _artFallback(double size) => Container(
    width: size, height: size, color: _kCard,
    child: Icon(Icons.music_note_rounded, color: _kTextSub, size: size * 0.45),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kBg,
        elevation: 0,
        iconTheme: const IconThemeData(color: _kBlue),
        title: Row(children: [
          Icon(Icons.music_note_rounded, color: _kBlue, size: 22),
          const SizedBox(width: 8),
          const Text('Smoty Play',
              style: TextStyle(
                  color: _kBlue,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  letterSpacing: 0.8)),
        ]),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 14),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _kBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: _kBlue.withOpacity(0.3)),
            ),
            child: const Text('30s Preview',
                style: TextStyle(color: _kBlueLt, fontSize: 10)),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _kBlue.withOpacity(0.2)),
        ),
      ),
      body: SafeArea(child: Column(children: [

        // ── Search Bar ──────────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _searchCtrl,
                style: const TextStyle(color: _kText, fontSize: 13),
                onSubmitted: _search,
                decoration: InputDecoration(
                  hintText: 'Cari lagu, artis, album...',
                  hintStyle: const TextStyle(color: Colors.grey),
                  prefixIcon: const Icon(Icons.search, color: Colors.grey),
                  suffixIcon: _searchCtrl.text.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear, color: Colors.grey),
                          onPressed: () {
                            _searchCtrl.clear();
                            setState(() {});
                          })
                      : null,
                  filled: true,
                  fillColor: _kSurface,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(22),
                      borderSide: BorderSide(color: _kBlue.withOpacity(0.3))),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(22),
                      borderSide: BorderSide(color: _kBlue.withOpacity(0.3))),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(22),
                      borderSide: const BorderSide(color: _kBlue)),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => _search(_searchCtrl.text),
              child: Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color: _kBlue,
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: [
                    BoxShadow(
                        color: _kBlue.withOpacity(0.35),
                        blurRadius: 8,
                        offset: const Offset(0, 2)),
                  ],
                ),
                child: const Icon(Icons.search, color: Colors.white, size: 18),
              ),
            ),
          ]),
        ),

        // ── Genre Chips ─────────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
          child: SizedBox(
            height: 30,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: _genres.map((g) => GestureDetector(
                onTap: () { _searchCtrl.text = g; _search(g); },
                child: Container(
                  margin: const EdgeInsets.only(right: 7),
                  padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 5),
                  decoration: BoxDecoration(
                    color: _kSurface,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: _kBlue.withOpacity(0.35)),
                  ),
                  child: Text(g,
                      style: const TextStyle(
                          color: _kBlueLt, fontSize: 11)),
                ),
              )).toList(),
            ),
          ),
        ),

        // ── Now Playing bar ─────────────────────────────────────────────────
        if (_nowPlaying != null) _buildNowPlaying(),

        // ── Daftar Lagu ─────────────────────────────────────────────────────
        Expanded(child: _searching
          ? const Center(child: CircularProgressIndicator(color: _kBlue))
          : _errMsg.isNotEmpty
            ? Center(child: Column(
                mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.wifi_off_rounded, color: _kTextSub, size: 48),
                const SizedBox(height: 10),
                Text(_errMsg, style: const TextStyle(color: Colors.grey)),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => _search('top hits 2024'),
                  child: const Text('Coba Lagi', style: TextStyle(color: _kBlue)),
                ),
              ]))
            : _results.isEmpty
              ? Center(child: Column(
                  mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.music_note_rounded, color: _kBlue.withOpacity(0.4), size: 60),
                  const SizedBox(height: 12),
                  const Text('Cari lagu favoritmu',
                      style: TextStyle(color: Colors.grey, fontSize: 14)),
                ]))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 10, 14, 24),
                  itemCount: _results.length,
                  itemBuilder: (_, i) => _buildTrackTile(_results[i], i),
                ),
        ),
      ])),
    );
  }

  Widget _buildTrackTile(Map<String, dynamic> t, int i) {
    final isActive = _nowPlaying != null && _nowPlaying!['title'] == t['title'];
    final isPlay   = isActive && _playing;

    return GestureDetector(
      onTap: () => _play(t),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: isActive ? _kBlue.withOpacity(0.15) : _kSurface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: isActive ? _kBlue.withOpacity(0.5) : _kBorder,
          ),
        ),
        child: Row(children: [
          // Nomor / equalizer
          SizedBox(
            width: 24,
            child: isPlay
              ? const Icon(Icons.equalizer_rounded, color: _kBlue, size: 18)
              : Text('${i + 1}',
                  style: TextStyle(
                      color: isActive ? _kBlue : _kTextSub, fontSize: 11),
                  textAlign: TextAlign.center),
          ),
          const SizedBox(width: 10),
          _albumArt(t['img'] as String),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t['title'] as String,
                style: TextStyle(
                  color: isActive ? _kBlue : _kText,
                  fontSize: 13,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                ),
                maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(t['artist'] as String,
                style: const TextStyle(color: Colors.grey, fontSize: 11),
                maxLines: 1, overflow: TextOverflow.ellipsis),
          ])),
          isPlay
              ? const Icon(Icons.pause_circle_filled_rounded, color: _kBlue, size: 24)
              : const Icon(Icons.play_circle_outline_rounded, color: Colors.grey, size: 22),
        ]),
      ),
    );
  }

  Widget _buildNowPlaying() {
    final t = _nowPlaying!;
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _kSurface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _kBlue.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(
              color: _kBlue.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 2)),
        ],
      ),
      child: Column(children: [
        Row(children: [
          _albumArt(t['img'] as String, size: 54),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t['title'] as String,
                style: const TextStyle(
                    color: _kText, fontWeight: FontWeight.bold, fontSize: 13),
                maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(t['artist'] as String,
                style: const TextStyle(color: Colors.grey, fontSize: 11),
                maxLines: 1, overflow: TextOverflow.ellipsis),
          ])),
          const SizedBox(width: 8),
          // Controls
          Row(children: [
            GestureDetector(
              onTap: () => setState(() => _shuffle = !_shuffle),
              child: Icon(Icons.shuffle_rounded,
                  color: _shuffle ? _kBlue : _kTextSub, size: 18)),
            const SizedBox(width: 6),
            GestureDetector(
              onTap: _prevTrack,
              child: const Icon(Icons.skip_previous_rounded,
                  color: _kText, size: 24)),
            const SizedBox(width: 6),
            GestureDetector(
              onTap: _togglePlay,
              child: Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: _kBlue, shape: BoxShape.circle,
                  boxShadow: [BoxShadow(
                      color: _kBlue.withOpacity(0.4),
                      blurRadius: 10, spreadRadius: 1)],
                ),
                child: Icon(
                  _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: Colors.white, size: 22),
              ),
            ),
            const SizedBox(width: 6),
            GestureDetector(
              onTap: _nextTrack,
              child: const Icon(Icons.skip_next_rounded,
                  color: _kText, size: 24)),
            const SizedBox(width: 6),
            GestureDetector(
              onTap: () => setState(() => _repeat = !_repeat),
              child: Icon(Icons.repeat_rounded,
                  color: _repeat ? _kBlue : _kTextSub, size: 18)),
          ]),
        ]),

        const SizedBox(height: 10),

        // Progress slider
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            activeTrackColor  : _kBlue,
            inactiveTrackColor: _kBorder,
            thumbColor        : Colors.white,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
            overlayShape: SliderComponentShape.noThumb,
            trackHeight: 2.5,
          ),
          child: Slider(
            value: _dur.inSeconds > 0
                ? (_pos.inSeconds / _dur.inSeconds).clamp(0.0, 1.0)
                : 0.0,
            onChanged: (v) {
              if (_dur.inSeconds > 0) {
                _player.seek(Duration(seconds: (v * _dur.inSeconds).toInt()));
              }
            },
          ),
        ),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(_fmt(_pos),
                style: const TextStyle(color: Colors.grey, fontSize: 10)),
            Text(_fmt(_dur),
                style: const TextStyle(color: Colors.grey, fontSize: 10)),
          ]),
        ),
      ]),
    );
  }
}
