import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shimmer/shimmer.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'main.dart';

// ─── WARNA ────────────────────────────────────────────────────────────────────
const Color _kBg      = Color(0xFF0A1628);
const Color _kSurface = Color(0xFF0D2240);
const Color _kBlue    = Color(0xFF2196F3);
const Color _kBlueDk  = Color(0xFF1565C0);
const Color _kBlueMd  = AppColors.azure;

// ─── HELPERS ─────────────────────────────────────────────────────────────────
String _ytThumb(String id) => 'https://img.youtube.com/vi/$id/mqdefault.jpg';

// URL watch biasa — bukan embed, ini yang pasti bisa diputar
String _ytWatch(String id) => 'https://www.youtube.com/watch?v=$id';

// Chrome headers persis seperti anime.dart — biar YouTube kira ini browser beneran
Map<String, String> _chromeHeaders() => {
  'User-Agent'     : 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36',
  'Accept'         : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
  'Accept-Encoding': 'gzip, deflate, br',
  'Referer'        : 'https://www.youtube.com/',
};

// ─── DATA ─────────────────────────────────────────────────────────────────────
// Video ID diverifikasi tersedia dan public di YouTube
final List<Map<String, dynamic>> _list = [
  // ── DONGHUA ──
  {
    'title'  : 'Battle Through the Heavens',
    'genre'  : 'Action · Cultivation',
    'ep'     : '40+',
    'tag'    : 'Donghua',
    'videoId': 'OvdCBGnxBQs',   // Playlist BTTH official
    'img'    : _ytThumb('OvdCBGnxBQs'),
  },
  {
    'title'  : 'Soul Land (Douluo Dalu)',
    'genre'  : 'Adventure · Fantasy',
    'ep'     : '200+',
    'tag'    : 'Donghua',
    'videoId': 'qKHiCXGbJI4',   // Soul Land EP1
    'img'    : _ytThumb('qKHiCXGbJI4'),
  },
  {
    'title'  : "The King's Avatar",
    'genre'  : 'E-Sports · Action',
    'ep'     : '24',
    'tag'    : 'Donghua',
    'videoId': 'Mu6xiLRMYBQ',   // King's Avatar EP1
    'img'    : _ytThumb('Mu6xiLRMYBQ'),
  },
  {
    'title'  : 'Martial Universe',
    'genre'  : 'Martial Arts · Fantasy',
    'ep'     : '40+',
    'tag'    : 'Donghua',
    'videoId': 'X7kEL-TS1IA',   // Martial Universe
    'img'    : _ytThumb('X7kEL-TS1IA'),
  },
  {
    'title'  : 'Perfect World',
    'genre'  : 'Cultivation · Fantasy',
    'ep'     : '50+',
    'tag'    : 'Donghua',
    'videoId': 'Z9vHbg5YIKU',   // Perfect World
    'img'    : _ytThumb('Z9vHbg5YIKU'),
  },
  {
    'title'  : "Heaven Official's Blessing",
    'genre'  : 'Romance · Fantasy',
    'ep'     : '24',
    'tag'    : 'Donghua',
    'videoId': 'ICx6OPQGvoo',   // TGCF EP1
    'img'    : _ytThumb('ICx6OPQGvoo'),
  },
  {
    'title'  : 'Swallowed Star',
    'genre'  : 'Sci-Fi · Action',
    'ep'     : '100+',
    'tag'    : 'Donghua',
    'videoId': 'FTmNDBMrHi4',   // Swallowed Star
    'img'    : _ytThumb('FTmNDBMrHi4'),
  },
  {
    'title'  : 'The Daily Life of the Immortal King',
    'genre'  : 'Comedy · Cultivation',
    'ep'     : '50+',
    'tag'    : 'Donghua',
    'videoId': 'b4gG7BWUP8s',   // Immortal King
    'img'    : _ytThumb('b4gG7BWUP8s'),
  },
  {
    'title'  : 'A Will Eternal',
    'genre'  : 'Comedy · Cultivation',
    'ep'     : '40+',
    'tag'    : 'Donghua',
    'videoId': '7U6lqJTl7mI',
    'img'    : _ytThumb('7U6lqJTl7mI'),
  },
  {
    'title'  : 'Stellar Transformations',
    'genre'  : 'Sci-Fi · Cultivation',
    'ep'     : '44+',
    'tag'    : 'Donghua',
    'videoId': 'P3bFsXsH1Hk',
    'img'    : _ytThumb('P3bFsXsH1Hk'),
  },
  // ── DRAMA CHINA ──
  {
    'title'  : 'The Untamed (陈情令)',
    'genre'  : 'Romance · Wuxia',
    'ep'     : '50',
    'tag'    : 'Drama',
    'videoId': 'aOvQ0PKqBrI',   // The Untamed EP1
    'img'    : _ytThumb('aOvQ0PKqBrI'),
  },
  {
    'title'  : 'Word of Honor (山河令)',
    'genre'  : 'Action · Bromance',
    'ep'     : '36',
    'tag'    : 'Drama',
    'videoId': 'P7SL3dFjxnQ',
    'img'    : _ytThumb('P7SL3dFjxnQ'),
  },
  {
    'title'  : 'Love Between Fairy and Devil',
    'genre'  : 'Romance · Fantasy',
    'ep'     : '36',
    'tag'    : 'Drama',
    'videoId': 'xpWJHLmNkuA',
    'img'    : _ytThumb('xpWJHLmNkuA'),
  },
  {
    'title'  : 'Eternal Love (三生三世)',
    'genre'  : 'Romance · Xianxia',
    'ep'     : '58',
    'tag'    : 'Drama',
    'videoId': 'eMXpOnOe_PY',
    'img'    : _ytThumb('eMXpOnOe_PY'),
  },
  {
    'title'  : 'Ashes of Love (香蜜沉沉烬如霜)',
    'genre'  : 'Romance · Fantasy',
    'ep'     : '63',
    'tag'    : 'Drama',
    'videoId': '9dCmQv3OroA',
    'img'    : _ytThumb('9dCmQv3OroA'),
  },
  {
    'title'  : 'Nirvana in Fire (琅琊榜)',
    'genre'  : 'Political · Wuxia',
    'ep'     : '54',
    'tag'    : 'Drama',
    'videoId': '0gIV4DFbhCo',
    'img'    : _ytThumb('0gIV4DFbhCo'),
  },
  {
    'title'  : 'Lost You Forever (长相思)',
    'genre'  : 'Romance · Xianxia',
    'ep'     : '39',
    'tag'    : 'Drama',
    'videoId': 'HXMTGJtY-1o',
    'img'    : _ytThumb('HXMTGJtY-1o'),
  },
  {
    'title'  : 'Go Go Squid! (亲爱的，热爱的)',
    'genre'  : 'Romance · E-Sports',
    'ep'     : '41',
    'tag'    : 'Drama',
    'videoId': 'oKBDxBWLBGY',
    'img'    : _ytThumb('oKBDxBWLBGY'),
  },
  {
    'title'  : 'You Are My Glory (你是我的荣耀)',
    'genre'  : 'Romance · Modern',
    'ep'     : '32',
    'tag'    : 'Drama',
    'videoId': 'lHj7KgRNFxg',
    'img'    : _ytThumb('lHj7KgRNFxg'),
  },
  {
    'title'  : 'The Story of Ming Lan (知否)',
    'genre'  : 'Historical · Romance',
    'ep'     : '73',
    'tag'    : 'Drama',
    'videoId': 'q0zPpQkjhJo',
    'img'    : _ytThumb('q0zPpQkjhJo'),
  },
];

const _tags = ['Semua', 'Donghua', 'Drama'];

// ═════════════════════════════════════════════════════════════════════════════
// DRACIN PAGE
// ═════════════════════════════════════════════════════════════════════════════
class DracinPage extends StatefulWidget {
  const DracinPage({super.key});
  @override State<DracinPage> createState() => _DracinPageState();
}

class _DracinPageState extends State<DracinPage> {
  String _q            = '';
  String _tag          = 'Semua';
  bool   _imagesLoaded = false;
  final  _ctrl         = TextEditingController();

  List<Map<String, dynamic>> get _filtered => _list.where((d) {
    final matchQ = _q.isEmpty ||
        (d['title'] as String).toLowerCase().contains(_q.toLowerCase()) ||
        (d['genre'] as String).toLowerCase().contains(_q.toLowerCase());
    final matchT = _tag == 'Semua' || d['tag'] == _tag;
    return matchQ && matchT;
  }).toList();

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) setState(() => _imagesLoaded = true);
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kBg,
        title: const Text('Dracin',
            style: TextStyle(color: _kBlue, fontWeight: FontWeight.bold, letterSpacing: 1)),
        iconTheme: const IconThemeData(color: _kBlue),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _kBlue.withOpacity(0.2)),
        ),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
          child: TextField(
            controller: _ctrl,
            onChanged: (v) => setState(() => _q = v),
            style: const TextStyle(color: _kBlue),
            decoration: InputDecoration(
              hintText: 'Cari judul atau genre...',
              hintStyle: const TextStyle(color: Colors.grey),
              prefixIcon: const Icon(Icons.search, color: Colors.grey),
              suffixIcon: _ctrl.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear, color: Colors.grey),
                      onPressed: () { _ctrl.clear(); setState(() => _q = ''); })
                  : null,
              filled: true, fillColor: _kSurface,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(22),
                  borderSide: BorderSide(color: _kBlue.withOpacity(0.3))),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(22),
                  borderSide: BorderSide(color: _kBlue.withOpacity(0.3))),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(22),
                  borderSide: const BorderSide(color: _kBlue)),
            ),
          ),
        ),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            ..._tags.map((t) {
              final active = t == _tag;
              return GestureDetector(
                onTap: () => setState(() => _tag = t),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: active ? _kBlue : _kSurface,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: active ? _kBlue : _kBlue.withOpacity(0.3)),
                  ),
                  child: Text(t, style: TextStyle(
                    color: active ? Colors.white : Colors.grey,
                    fontSize: 12,
                    fontWeight: active ? FontWeight.bold : FontWeight.normal,
                  )),
                ),
              );
            }),
            const Spacer(),
            Text('${_filtered.length} judul',
                style: TextStyle(color: Colors.grey.shade600, fontSize: 11)),
          ]),
        ),

        Expanded(
          child: _filtered.isEmpty
              ? const Center(child: Column(
                  mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.search_off_rounded, color: Colors.grey, size: 55),
                  SizedBox(height: 12),
                  Text('Tidak ditemukan', style: TextStyle(color: Colors.grey, fontSize: 14)),
                ]))
              : GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 0.57),
                  itemCount: _filtered.length,
                  itemBuilder: (_, i) => _buildCard(_filtered[i]),
                ),
        ),
      ]),
    );
  }

  Widget _buildCard(Map<String, dynamic> d) {
    final isDrama = d['tag'] == 'Drama';
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(
        builder: (_) => _DracinPlayerPage(film: d),
      )),
      child: Container(
        decoration: BoxDecoration(
          color: _kSurface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _kBlue.withOpacity(0.2)),
          boxShadow: [BoxShadow(
            color: _kBlue.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))],
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Stack(fit: StackFit.expand, children: [
              !_imagesLoaded
                  ? Shimmer.fromColors(
                      baseColor: _kSurface,
                      highlightColor: const Color(0xFF1A3A5C),
                      child: Container(color: _kSurface))
                  : Image.network(
                      d['img'] as String,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: _kSurface,
                        alignment: Alignment.center,
                        child: const Icon(Icons.live_tv_rounded, color: Colors.grey, size: 32),
                      ),
                    ),
              Positioned(
                bottom: 0, left: 0, right: 0,
                child: Container(height: 55, decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, _kBg.withOpacity(0.9)],
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  ),
                )),
              ),
              Positioned(top: 8, left: 8, child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: isDrama ? _kBlueMd : _kBlueDk,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(d['tag'] as String,
                    style: const TextStyle(color: Colors.white, fontSize: 8,
                        fontWeight: FontWeight.bold)),
              )),
              Positioned(top: 8, right: 8, child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _kBlue.withOpacity(0.5)),
                ),
                child: Text('EP ${d["ep"]}',
                    style: const TextStyle(color: Colors.white, fontSize: 8,
                        fontWeight: FontWeight.bold)),
              )),
              Center(child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _kBlue.withOpacity(0.85),
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(
                    color: _kBlue.withOpacity(0.4), blurRadius: 12, spreadRadius: 2)],
                ),
                child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 26),
              )),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d['title'] as String,
                  style: const TextStyle(color: Colors.white,
                      fontWeight: FontWeight.w600, fontSize: 11),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 4),
              Text(d['genre'] as String,
                  style: TextStyle(color: Colors.grey.shade500, fontSize: 9),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// PLAYER PAGE — WebView dengan Chrome headers persis seperti anime.dart
// ═════════════════════════════════════════════════════════════════════════════
class _DracinPlayerPage extends StatefulWidget {
  final Map<String, dynamic> film;
  const _DracinPlayerPage({required this.film});
  @override State<_DracinPlayerPage> createState() => _DracinPlayerPageState();
}

class _DracinPlayerPageState extends State<_DracinPlayerPage> {
  late WebViewController _wvCtrl;
  bool _loading      = true;
  bool _hasError     = false;
  bool _isFullscreen = false;

  @override
  void initState() {
    super.initState();
    _initWebView();
  }

  void _initWebView() {
    final videoId  = widget.film['videoId'] as String;
    final watchUrl = _ytWatch(videoId);

    _wvCtrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setUserAgent(
        'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36',
      )
      ..addJavaScriptChannel('FullScreen', onMessageReceived: (msg) {
        if (msg.message == 'enter') _enterFullscreen();
        else if (msg.message == 'exit') _exitFullscreen();
      })
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (p) {
          if (p == 100) {
            setState(() => _loading = false);
            _injectAutoPlay();
            _injectFullscreenDetect();
          }
        },
        onPageStarted: (_) => setState(() { _loading = true; _hasError = false; }),
        onPageFinished: (_) {
          setState(() => _loading = false);
          _injectAutoPlay();
          _injectFullscreenDetect();
        },
        onWebResourceError: (err) {
          if (err.isForMainFrame == true) {
            setState(() { _loading = false; _hasError = true; });
          }
        },
        onNavigationRequest: (req) {
          // Izinkan semua URL dari YouTube ecosystem
          if (req.url.contains('youtube.com') ||
              req.url.contains('youtu.be') ||
              req.url.contains('ytimg.com') ||
              req.url.contains('ggpht.com') ||
              req.url.contains('googlevideo.com') ||
              req.url.contains('googleapis.com') ||
              req.url.contains('gstatic.com') ||
              req.url == 'about:blank') {
            return NavigationDecision.navigate;
          }
          return NavigationDecision.prevent;
        },
      ))
      ..loadRequest(
        Uri.parse(watchUrl),
        headers: _chromeHeaders(),
      );
  }

  // Auto-click play button dan skip ads jika ada
  void _injectAutoPlay() {
    _wvCtrl.runJavaScript('''
      try {
        // Click tombol play jika ada
        var playBtn = document.querySelector('.ytp-play-button');
        if (playBtn && playBtn.getAttribute('data-title-no-tooltip') === 'Play') {
          playBtn.click();
        }
        // Skip ad jika muncul
        var skipBtn = document.querySelector('.ytp-skip-ad-button, .videoAdUiSkipButton');
        if (skipBtn) skipBtn.click();
        // Hide YouTube header/footer untuk mode immersive
        var ytHeader = document.querySelector('ytm-app');
        if (ytHeader) {
          ytHeader.style.setProperty('--ytm-app-bottom-sheet-background', 'transparent');
        }
      } catch(e) {}
    ''');
  }

  // Deteksi fullscreen dari YouTube player
  void _injectFullscreenDetect() {
    _wvCtrl.runJavaScript('''
      try {
        document.addEventListener('fullscreenchange', function() {
          if (document.fullscreenElement) {
            FullScreen.postMessage('enter');
          } else {
            FullScreen.postMessage('exit');
          }
        });
        document.addEventListener('webkitfullscreenchange', function() {
          if (document.webkitFullscreenElement) {
            FullScreen.postMessage('enter');
          } else {
            FullScreen.postMessage('exit');
          }
        });
      } catch(e) {}
    ''');
  }

  void _enterFullscreen() {
    setState(() => _isFullscreen = true);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  void _exitFullscreen() {
    setState(() => _isFullscreen = false);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> _openExternal() async {
    final videoId = widget.film['videoId'] as String;
    final uri     = Uri.parse(_ytWatch(videoId));
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDrama = widget.film['tag'] == 'Drama';
    final title   = widget.film['title'] as String;
    final genre   = widget.film['genre'] as String;
    final ep      = widget.film['ep'] as String;
    final tag     = widget.film['tag'] as String;

    return Scaffold(
      backgroundColor: _kBg,
      appBar: _isFullscreen ? null : AppBar(
        backgroundColor: _kBg,
        iconTheme: const IconThemeData(color: _kBlue),
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: const TextStyle(color: Colors.white,
                  fontSize: 14, fontWeight: FontWeight.bold),
              maxLines: 1, overflow: TextOverflow.ellipsis),
          Text('$tag · EP $ep',
              style: const TextStyle(color: Colors.grey, fontSize: 11)),
        ]),
        actions: [
          // Tombol buka di YouTube app
          IconButton(
            icon: const Icon(Icons.open_in_new_rounded, color: _kBlue, size: 20),
            tooltip: 'Buka di YouTube',
            onPressed: _openExternal,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _kBlue.withOpacity(0.2)),
        ),
      ),
      body: Column(children: [
        // ── VIDEO AREA ────────────────────────────────────────────────────
        AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height: _isFullscreen
              ? MediaQuery.of(context).size.height
              : MediaQuery.of(context).size.width * 9 / 16 + 80,
          color: Colors.black,
          child: Stack(children: [
            WebViewWidget(controller: _wvCtrl),

            // Loading bar
            if (_loading)
              Positioned(
                top: 0, left: 0, right: 0,
                child: LinearProgressIndicator(
                  color: _kBlue, backgroundColor: Colors.black,
                  minHeight: 2,
                ),
              ),

            // Error state
            if (_hasError && !_loading)
              Container(
                color: Colors.black87,
                child: Center(
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.wifi_off_rounded, color: Colors.redAccent, size: 40),
                    const SizedBox(height: 10),
                    const Text('Gagal memuat video',
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                    const SizedBox(height: 6),
                    const Text('Pastikan internet aktif',
                        style: TextStyle(color: Colors.grey, fontSize: 11)),
                    const SizedBox(height: 16),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      ElevatedButton.icon(
                        onPressed: () { setState(() { _hasError = false; }); _initWebView(); },
                        icon: const Icon(Icons.refresh_rounded, size: 16),
                        label: const Text('Retry'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _kBlue, foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton.icon(
                        onPressed: _openExternal,
                        icon: const Icon(Icons.open_in_new_rounded, size: 16),
                        label: const Text('Buka YT'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red, foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                        ),
                      ),
                    ]),
                  ]),
                ),
              ),
          ]),
        ),

        // ── INFO & EPISODE ────────────────────────────────────────────────
        if (!_isFullscreen)
          Expanded(
            child: SingleChildScrollView(
              child: Column(children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  color: _kSurface,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: isDrama ? _kBlueMd : _kBlueDk,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(tag, style: const TextStyle(
                            color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black45,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: _kBlue.withOpacity(0.4)),
                        ),
                        child: Text('EP $ep', style: const TextStyle(
                            color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                      const Spacer(),
                      // Tombol buka di YouTube
                      GestureDetector(
                        onTap: _openExternal,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Row(children: [
                            Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 14),
                            SizedBox(width: 4),
                            Text('YouTube', style: TextStyle(
                                color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                          ]),
                        ),
                      ),
                    ]),
                    const SizedBox(height: 10),
                    Text(title, style: const TextStyle(
                        color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(genre, style: TextStyle(color: Colors.grey.shade400, fontSize: 12)),
                  ]),
                ),

                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Row(children: [
                    const Icon(Icons.playlist_play_rounded, color: _kBlue, size: 20),
                    const SizedBox(width: 8),
                    const Text('Episode Lain',
                        style: TextStyle(color: _kBlue, fontSize: 14, fontWeight: FontWeight.bold)),
                  ]),
                ),

                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  child: Column(
                    children: _list
                        .where((d) => d['title'] != widget.film['title'])
                        .take(6)
                        .map((d) => _buildRelatedCard(d))
                        .toList(),
                  ),
                ),
              ]),
            ),
          ),
      ]),
    );
  }

  Widget _buildRelatedCard(Map<String, dynamic> d) {
    final isDrama = d['tag'] == 'Drama';
    return GestureDetector(
      onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => _DracinPlayerPage(film: d),
      )),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: _kSurface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _kBlue.withOpacity(0.15)),
        ),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: SizedBox(
              width: 90, height: 56,
              child: Stack(fit: StackFit.expand, children: [
                Image.network(
                  d['img'] as String,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: _kSurface,
                    child: const Icon(Icons.live_tv_rounded, color: Colors.grey, size: 20),
                  ),
                ),
                Center(child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: _kBlue.withOpacity(0.8), shape: BoxShape.circle),
                  child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 16),
                )),
              ]),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d['title'] as String,
                  style: const TextStyle(color: Colors.white,
                      fontSize: 12, fontWeight: FontWeight.w600),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 4),
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: isDrama ? _kBlueMd : _kBlueDk,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(d['tag'] as String,
                      style: const TextStyle(color: Colors.white,
                          fontSize: 8, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 6),
                Flexible(child: Text(d['genre'] as String,
                    style: TextStyle(color: Colors.grey.shade500, fontSize: 9),
                    maxLines: 1, overflow: TextOverflow.ellipsis)),
              ]),
            ]),
          ),
          const Icon(Icons.chevron_right_rounded, color: Colors.grey, size: 18),
        ]),
      ),
    );
  }
}
