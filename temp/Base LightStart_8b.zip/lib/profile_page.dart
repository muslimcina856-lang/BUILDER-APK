import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'main.dart';
import 'change_password_page.dart';

class ProfilePage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  const ProfilePage({super.key, required this.username, required this.password,
      required this.role, required this.expiredDate, required this.sessionKey});
  @override State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with TickerProviderStateMixin {
  File? _profileImage;
  final _picker = ImagePicker();
  late AnimationController _bgCtrl, _entranceCtrl, _avatarCtrl;
  late Animation<double> _fade, _avatarGlow;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _bgCtrl     = AnimationController(vsync:this, duration:const Duration(seconds:16))..repeat();
    _entranceCtrl = AnimationController(vsync:this, duration:const Duration(milliseconds:900));
    _avatarCtrl = AnimationController(vsync:this, duration:const Duration(milliseconds:2000))..repeat(reverse:true);
    _fade  = CurvedAnimation(parent:_entranceCtrl, curve:Curves.easeOut);
    _slide = Tween<Offset>(begin:const Offset(0,.04), end:Offset.zero)
        .animate(CurvedAnimation(parent:_entranceCtrl, curve:Curves.easeOutCubic));
    _avatarGlow = Tween<double>(begin:.4, end:1.0)
        .animate(CurvedAnimation(parent:_avatarCtrl, curve:Curves.easeInOut));
    _loadProfileImage();
    Future.delayed(const Duration(milliseconds:150), () { if(mounted) _entranceCtrl.forward(); });
  }

  @override
  void dispose() {
    _bgCtrl.dispose(); _entranceCtrl.dispose(); _avatarCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_${widget.username}');
    if (path!=null && path.isNotEmpty && mounted) setState(()=>_profileImage=File(path));
  }

  String _censor(String t, {bool pass=false}) {
    if (t.isEmpty) return 'N/A';
    if (pass) return '••••••••';
    if (t.length<=2) return '${t[0]}••';
    return '${t.substring(0,2)}${'•'*(t.length-2)}';
  }

  Future<void> _showImagePicker() => showModalBottomSheet(
    context:context,
    backgroundColor:AppColors.surfaceAlt,
    shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(24))),
    builder:(_)=>SafeArea(child:Padding(padding:const EdgeInsets.all(20),
      child:Column(mainAxisSize:MainAxisSize.min, children:[
        Container(width:40, height:4, margin:const EdgeInsets.only(bottom:20),
          decoration:BoxDecoration(color:AppColors.borderGlow, borderRadius:BorderRadius.circular(2))),
        const Text('FOTO PROFIL', style:TextStyle(fontFamily:'Orbitron', fontSize:13,
          fontWeight:FontWeight.w800, color:AppColors.textPrimary, letterSpacing:2)),
        const SizedBox(height:20),
        Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly, children:[
          _PickerBtn(icon:Icons.camera_alt_rounded, label:'Kamera',
            color:AppColors.cyan, onTap:(){ Navigator.pop(context); _pick(ImageSource.camera); }),
          _PickerBtn(icon:Icons.photo_library_rounded, label:'Galeri',
            color:AppColors.violetBright, onTap:(){ Navigator.pop(context); _pick(ImageSource.gallery); }),
        ]),
        const SizedBox(height:8),
      ]),
    )),
  );

  Future<void> _pick(ImageSource src) async {
    try {
      final f = await _picker.pickImage(source:src, imageQuality:70);
      if (f!=null) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', f.path);
        if (mounted) setState(()=>_profileImage=File(f.path));
      }
    } catch (_) {}
  }

  Color get _rColor {
    switch (widget.role.toLowerCase()) {
      case 'high owner': return const Color(0xFFFFD700);
      case 'owner':      return const Color(0xFFFFA500);
      case 'high admin': return AppColors.cyan;
      case 'admin':      return AppColors.electric;
      case 'reseller':   return AppColors.violetBright;
      default:           return AppColors.success;
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor:AppColors.bg,
    body:Stack(children:[
      // BG
      AnimatedBuilder(animation:_bgCtrl, builder:(_,__)=>CustomPaint(
        painter:_ProfBg(_bgCtrl.value), child:const SizedBox.expand())),
      SafeArea(child:FadeTransition(opacity:_fade, child:SlideTransition(position:_slide,
        child:CustomScrollView(slivers:[
          // AppBar
          SliverAppBar(
            backgroundColor:Colors.transparent,
            elevation:0,
            pinned:true,
            leading:GestureDetector(onTap:()=>Navigator.pop(context),
              child:Container(margin:const EdgeInsets.all(10),
                decoration:BoxDecoration(borderRadius:BorderRadius.circular(10),
                  border:Border.all(color:AppColors.borderGlow), color:AppColors.card),
                child:const Icon(Icons.arrow_back_ios_new_rounded, color:AppColors.cyan, size:16))),
            title:const Text('MY PROFILE', style:TextStyle(
              fontFamily:'Orbitron', fontSize:14, fontWeight:FontWeight.w800,
              color:AppColors.textPrimary, letterSpacing:2)),
            centerTitle:true,
          ),
          SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.symmetric(horizontal:20),
            child:Column(children:[
              const SizedBox(height:20),
              // Avatar
              Center(child:GestureDetector(onTap:_showImagePicker,
                child:AnimatedBuilder(animation:_avatarCtrl, builder:(_,child)=>Container(
                  width:110, height:110,
                  decoration:BoxDecoration(shape:BoxShape.circle,
                    gradient:LinearGradient(colors:[_rColor, _rColor.withOpacity(.6)],
                      begin:Alignment.topLeft, end:Alignment.bottomRight),
                    boxShadow:[BoxShadow(color:_rColor.withOpacity(.4*_avatarGlow.value), blurRadius:30, spreadRadius:4)],
                    border:Border.all(color:_rColor.withOpacity(.6), width:2.5)),
                  child:child),
                  child:Stack(children:[
                    ClipOval(child:_profileImage!=null
                        ? Image.file(_profileImage!, fit:BoxFit.cover, width:110, height:110)
                        : const SizedBox(width:110, height:110,
                            child:Icon(FontAwesomeIcons.userAstronaut, size:44, color:Colors.white70))),
                    Positioned(bottom:4, right:4, child:Container(
                      padding:const EdgeInsets.all(6),
                      decoration:BoxDecoration(color:AppColors.cyan, shape:BoxShape.circle,
                        border:Border.all(color:AppColors.bg, width:2.5),
                        boxShadow:[BoxShadow(color:AppColors.cyan.withOpacity(.5), blurRadius:10)]),
                      child:const Icon(Icons.camera_alt_rounded, size:14, color:AppColors.bg))),
                  ])),
              )),
              const SizedBox(height:16),
              ShaderMask(
                shaderCallback:(b)=>LinearGradient(colors:[_rColor, AppColors.cyan]).createShader(b),
                child:Text(widget.username.toUpperCase(), style:const TextStyle(
                  fontFamily:'Orbitron', fontSize:22, fontWeight:FontWeight.w900,
                  color:Colors.white, letterSpacing:1))),
              const SizedBox(height:6),
              Container(padding:const EdgeInsets.symmetric(horizontal:16, vertical:5),
                decoration:BoxDecoration(
                  borderRadius:BorderRadius.circular(20),
                  color:_rColor.withOpacity(.12),
                  border:Border.all(color:_rColor.withOpacity(.4))),
                child:Text(widget.role.toUpperCase(), style:TextStyle(
                  fontFamily:'Orbitron', fontSize:10, color:_rColor,
                  fontWeight:FontWeight.w800, letterSpacing:2))),
              const SizedBox(height:30),
              // Info grid
              Row(children:[
                Expanded(child:_InfoCard(icon:Icons.person_rounded, label:'USERNAME',
                    value:_censor(widget.username), color:AppColors.cyan)),
                const SizedBox(width:12),
                Expanded(child:_InfoCard(icon:Icons.lock_rounded, label:'PASSWORD',
                    value:_censor(widget.password, pass:true), color:AppColors.violetBright)),
              ]),
              const SizedBox(height:12),
              Row(children:[
                Expanded(child:_InfoCard(icon:Icons.shield_rounded, label:'ROLE',
                    value:widget.role.toUpperCase(), color:_rColor)),
                const SizedBox(width:12),
                Expanded(child:_InfoCard(icon:Icons.calendar_month_rounded, label:'EXPIRED',
                    value:widget.expiredDate, color:AppColors.warning)),
              ]),
              const SizedBox(height:12),
              _InfoCard(icon:Icons.vpn_key_rounded, label:'SESSION KEY',
                  value:widget.sessionKey.length>8
                      ? '${widget.sessionKey.substring(0,8)}••••••••'
                      : widget.sessionKey,
                  color:AppColors.success),
              const SizedBox(height:30),
              // Change password button — premium
              GestureDetector(
                onTap:()=>Navigator.push(context, MaterialPageRoute(
                    builder:(_)=>ChangePasswordPage(username:widget.username, sessionKey:widget.sessionKey))),
                child:Container(
                  width:double.infinity, height:58,
                  decoration:BoxDecoration(
                    borderRadius:BorderRadius.circular(16),
                    gradient:const LinearGradient(
                      colors:[Color(0xFF00B4CC), Color(0xFF00E5FF), Color(0xFF006680)],
                      begin:Alignment.topLeft, end:Alignment.bottomRight,
                    ),
                    border:Border.all(color:AppColors.cyan.withOpacity(0.5), width:1.2),
                    boxShadow:[
                      BoxShadow(color:AppColors.cyan.withOpacity(.45), blurRadius:28, offset:const Offset(0,8)),
                      BoxShadow(color:AppColors.violet.withOpacity(.15), blurRadius:50, spreadRadius:2),
                    ]),
                  child:const Row(mainAxisAlignment:MainAxisAlignment.center, children:[
                    Icon(Icons.lock_reset_rounded, color:AppColors.bg, size:22),
                    SizedBox(width:10),
                    Text('GANTI PASSWORD', style:TextStyle(
                      fontFamily:'Orbitron', fontSize:13, fontWeight:FontWeight.w900,
                      color:AppColors.bg, letterSpacing:2)),
                  ]),
                ),
              ),
              const SizedBox(height:40),
            ])),
          ),
        ]),
      ))),
    ]),
  );
}

// ── Info Card ─────────────────────────────────────────────────────────────
class _InfoCard extends StatelessWidget {
  final IconData icon; final String label, value; final Color color;
  const _InfoCard({required this.icon, required this.label, required this.value, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding:const EdgeInsets.all(14),
    decoration:BoxDecoration(
      borderRadius:BorderRadius.circular(14),
      gradient:const LinearGradient(colors:[AppColors.card, AppColors.surface],
        begin:Alignment.topLeft, end:Alignment.bottomRight),
      border:Border.all(color:color.withOpacity(.2))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
      Row(children:[
        Container(padding:const EdgeInsets.all(6),
          decoration:BoxDecoration(borderRadius:BorderRadius.circular(8),
            color:color.withOpacity(.12)),
          child:Icon(icon, color:color, size:14)),
        const SizedBox(width:8),
        Text(label, style:const TextStyle(fontFamily:'ShareTechMono', fontSize:9,
          color:AppColors.textSub, letterSpacing:1.5)),
      ]),
      const SizedBox(height:8),
      Text(value, style:const TextStyle(fontFamily:'ShareTechMono', fontSize:13,
        color:AppColors.textPrimary, fontWeight:FontWeight.w700),
        overflow:TextOverflow.ellipsis, maxLines:1),
    ]),
  );
}

// ── Picker Btn ────────────────────────────────────────────────────────────
class _PickerBtn extends StatelessWidget {
  final IconData icon; final String label; final Color color; final VoidCallback onTap;
  const _PickerBtn({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(onTap:onTap,
    child:Container(width:120, padding:const EdgeInsets.symmetric(vertical:16),
      decoration:BoxDecoration(borderRadius:BorderRadius.circular(16),
        color:color.withOpacity(.1), border:Border.all(color:color.withOpacity(.4))),
      child:Column(mainAxisSize:MainAxisSize.min, children:[
        Icon(icon, color:color, size:28),
        const SizedBox(height:8),
        Text(label, style:TextStyle(fontFamily:'ShareTechMono', fontSize:12,
          color:color, fontWeight:FontWeight.w600)),
      ])));
}

// ── Background ────────────────────────────────────────────────────────────
class _ProfBg extends CustomPainter {
  final double t;
  _ProfBg(this.t);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0,0,size.width,size.height),
      Paint()..shader=const LinearGradient(
        colors:[AppColors.bgDeep, AppColors.bg, AppColors.surface],
        begin:Alignment.topCenter, end:Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0,0,size.width,size.height)));
    final a = t*2*math.pi;
    final cx=size.width/2;
    canvas.drawCircle(Offset(cx+math.cos(a)*50, size.height*.25),200,
      Paint()..shader=RadialGradient(colors:[AppColors.violet.withOpacity(.08),Colors.transparent])
          .createShader(Rect.fromCircle(center:Offset(cx,size.height*.25),radius:200)));
    canvas.drawCircle(Offset(cx,size.height*.75),160,
      Paint()..shader=RadialGradient(colors:[AppColors.cyan.withOpacity(.05),Colors.transparent])
          .createShader(Rect.fromCircle(center:Offset(cx,size.height*.75),radius:160)));
  }
  @override bool shouldRepaint(_ProfBg o)=>o.t!=t;
}
