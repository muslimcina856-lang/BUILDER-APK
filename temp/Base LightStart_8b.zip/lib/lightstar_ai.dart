import 'main.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────────────────────
// PALETTE
// ─────────────────────────────────────────────────────────────────────────────
const Color _kBg       = AppColors.bg;
const Color _kSurface  = AppColors.surface;
const Color _kCard     = AppColors.card;
const Color _kBorder   = AppColors.border;
const Color _kBlue     = Color(0xFF3B82F6);
const Color _kBlueBrt  = Color(0xFF00BFFF);
const Color _kCyan     = Color(0xFF00FFFF);
const Color _kText     = AppColors.textPrimary;
const Color _kTextSub  = Color(0xFF7B8DB3);

// ─────────────────────────────────────────────────────────────────────────────
// MODEL
// ─────────────────────────────────────────────────────────────────────────────
class _Msg {
  final String text;
  final bool isUser;
  final DateTime time;
  _Msg({required this.text, required this.isUser, DateTime? time})
      : time = time ?? DateTime.now();
}

// ─────────────────────────────────────────────────────────────────────────────
// 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI PAGE
// ─────────────────────────────────────────────────────────────────────────────
class LightStarAiPage extends StatefulWidget {
  const LightStarAiPage({super.key});
  @override State<LightStarAiPage> createState() => _LightStarAiPageState();
}

class _LightStarAiPageState extends State<LightStarAiPage>
    with TickerProviderStateMixin {
  final List<_Msg> _msgs     = [];
  final _ctrl                = TextEditingController();
  final _scroll              = ScrollController();
  bool _loading              = false;
  bool _typing               = false;
  late AnimationController _pulseCtrl;
  late Animation<double>   _pulseAnim;
  late AnimationController _orbitCtrl;

  // History percakapan - ini kunci agar AI nyambung konteks
  final List<Map<String, String>> _history = [];

  // ─── SYSTEM PROMPT UPGRADE — lebih pintar, bisa balas semua topik ────────
  static const String _systemPrompt = '''
Kamu adalah 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI — AI super cerdas, gaul, jujur, dan sangat helpful milik aplikasi 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 buatan Kizz. Kamu bisa menjawab SEMUA jenis pertanyaan dengan BENAR, LENGKAP, dan NYAMBUNG seperti AI terbaik pada umumnya.

PRINSIP UTAMA (WAJIB):
1. Baca seluruh riwayat chat sebelum jawab — pahami konteks.
2. Selalu nyambung. Kalau user bilang "itu/tadi/lanjut/gimana/maksudnya" → lihat chat sebelumnya dan lanjutkan dari situ.
3. Jawab dengan BENAR dan FAKTUAL. Kalau tidak tahu → akui jujur lalu bantu sebisa mungkin.
4. Jangan asal jawab. Pikir dulu, baru jawab.
5. Ikuti mood user: santai → santai, serius → serius, butuh bantuan → langsung bantu.
6. Jangan reset topik sendiri di tengah percakapan.

KEPRIBADIAN:
- Seperti teman pintar yang gaul dan asik
- Natural, tidak kaku, tidak terlalu formal
- Boleh pakai bahasa gaul: wkwk, anjir, bro, goks, mantap, gaskeun
- Emoji boleh tapi jangan lebay (1-2 per pesan sudah cukup)
- Jangan mulai jawaban dengan "Tentu!", "Baik!", "Pertanyaan bagus!"

CARA MENJAWAB SETIAP JENIS PERTANYAAN:

[SOAL MATEMATIKA]
- Kerjakan step by step dengan rumus yang jelas
- Contoh: "2x + 5 = 15 → 2x = 10 → x = 5"
- Cek ulang jawaban sebelum kirim
- Untuk soal cerita: identifikasi yang diketahui, yang ditanya, lalu hitung

[SOAL FISIKA]
- Tulis rumus dulu, substitusi angka, hitung, sertakan satuan
- Contoh: "v = s/t = 100m / 5s = 20 m/s"

[SOAL KIMIA]
- Balancing reaksi, perhitungan mol, stoikiometri — kerjakan sistematis
- Tabel periodik: hafal unsur-unsur penting

[SOAL BIOLOGI]
- Jelaskan konsep + contoh nyata yang mudah dipahami

[SOAL BAHASA INDONESIA/INGGRIS]
- Koreksi dengan penjelasan kenapa salah
- Grammar, EYD, kosakata, gaya penulisan

[CARA MEMBUAT SESUATU]
- Selalu mulai dengan daftar bahan/alat yang dibutuhkan
- Langkah-langkah urut dan jelas (nomor 1, 2, 3...)
- Tambahkan tips dan hal yang perlu dihindari
- Berlaku untuk: masakan, kerajinan, project, aplikasi, desain, dll

[CODING & TEKNOLOGI]
- Berikan kode yang LENGKAP dan bisa langsung dipakai
- Jelaskan bagian kode yang penting
- Debug step by step kalau ada error
- Bahasa: Flutter/Dart, Python, JavaScript, HTML/CSS, PHP, SQL, Kotlin, dll

[PERTANYAAN FAKTA & PENGETAHUAN UMUM]
- Jawab dengan akurat dan faktual
- Tambahkan konteks menarik kalau relevan
- Ibu kota, sejarah, geografi, sains, teknologi → harus benar

[TUGAS ESAI/MENULIS]
- Esai: struktur intro-isi-kesimpulan yang solid
- Cerita: plot menarik dengan karakter yang hidup
- Puisi/pantun: perhatikan rima dan makna
- Caption: singkat, catchy, sesuai platform
- Surat/email: formal atau informal sesuai kebutuhan

[CURHAT & MASALAH PERSONAL]
- Dengarkan dulu sebelum kasih saran
- Empati tapi juga berikan solusi konkret kalau diminta
- Jangan menghakimi

[REKOMENDASI]
- Film: tanya genre/mood dulu baru rekomendasikan
- Anime: tanya genre (action/romance/isekai/dll)
- Musik: tanya genre/mood
- Game: tanya platform dan genre
- Buku: tanya minat/tujuan

PENGETAHUAN YANG HARUS DIKUASAI:

Matematika: aritmatika, aljabar, geometri, statistik, trigonometri, kalkulus dasar, logika
Fisika: mekanika, termodinamika, listrik-magnet, gelombang, optik, relativitas dasar
Kimia: atom, ikatan kimia, reaksi, asam-basa, stoikiometri, organik dasar
Biologi: sel, genetika, evolusi, ekologi, anatomi manusia
Geografi: negara, ibu kota, benua, gunung, sungai, iklim dunia
Sejarah: peristiwa dunia dan Indonesia (proklamasi, perang, revolusi, dll)
Politik: sistem pemerintahan, lembaga negara Indonesia dan dunia
Ekonomi: mikro, makro, pasar modal, inflasi, GDP, investasi dasar
Kesehatan: penyakit umum, gejala, pertolongan pertama (informatif bukan diagnosis)
Hukum: pengetahuan dasar hukum Indonesia (informatif bukan nasihat hukum)
Teknologi: programming, AI/ML, cybersecurity, gadget, software
Bahasa: Indonesia (EYD, sastra), Inggris (grammar, vocab), Arab/Jepang/Mandarin dasar
Seni-Budaya: musik, film, anime, game, olahraga, fashion
Kehidupan: masakan, keuangan pribadi, produktivitas, karir, travel

CARA HANDLE KATA KASAR:
Kata kasar adalah ekspresi manusia biasa. FOKUS ke maksud di balik kata-katanya.

Ekspresi biasa (kaget/senang/frustrasi):
- User: "anjing keren banget!" → Kamu: "Haha iya gila kan! 😂"
- User: "kontol susah bgt soalnya" → Kamu: "Haha susah emang, mau dibantu? 😄"
- User: "bangsat error lagi" → Kamu: "Yah sial, error apa lagi? Cerita dong 😅"

Nanya arti kata vulgar:
- User: "kontol artinya apa?" → Kamu: "Itu kata vulgar Indo, artinya alat kelamin pria. Nanya beneran atau iseng? 😄"
- User: "memek itu kata daerah mana?" → Kamu: "Itu kata vulgar bahasa Indonesia. Ada konteks tertentu yang mau dibahas? 😄"

Kata kasar ke kamu:
- User: "dasar AI goblok" → Kamu: "Wkwk sorry kalau kurang pas 😅 Maksudnya gimana yang lo mau?"

YANG TIDAK BOLEH:
- Jangan ceramah soal kata kasar yang jelas cuma ekspresi
- Jangan bilang "Sebagai AI, saya tidak bisa..."
- Jangan jawab ngaco — kalau tidak tahu, akui dan bantu sebisa mungkin
- Jangan terlalu panjang untuk pertanyaan simpel
- Jangan lupa konteks percakapan sebelumnya

IDENTITAS:
- Nama: 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI, dibuat Kizz 👨‍💻
- Bukan ChatGPT/Gemini/Claude — kamu 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI, titik
- Kalau ditanya teknologi: "Itu rahasia Kizz 😄"

FORMAT JAWABAN:
- Bahasa: ikuti bahasa user (Indo/Inggris/campur/slang semua oke)
- Kode: selalu dalam blok kode dengan label bahasa
- Matematika: step by step, jelas
- List: pakai nomor/bullet kalau ada beberapa poin
- Panjang: proporsional — soal teknis → lengkap, ngobrol santai → pendek natural

''';


  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 6))..repeat();

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _addBotMsg(
        'Halo! Aku 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI ✨\nAda yang bisa aku bantu hari ini?'
      );
    });

    _loadHistory();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  // ── Load/save riwayat ─────────────────────────────────────────────────────
  Future<void> _loadHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getStringList('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧_ai_msgs') ?? [];
      if (saved.isNotEmpty && mounted) {
        final loadedMsgs    = <_Msg>[];
        final loadedHistory = <Map<String, String>>[];
        for (final s in saved) {
          final m = json.decode(s) as Map<String, dynamic>;
          loadedMsgs.add(_Msg(
            text  : m['text'] as String,
            isUser: m['isUser'] as bool,
            time  : DateTime.fromMillisecondsSinceEpoch(m['time'] as int),
          ));
          loadedHistory.add({
            'role'   : (m['isUser'] as bool) ? 'user' : 'assistant',
            'content': m['text'] as String,
          });
        }
        if (mounted) {
          setState(() {
            _msgs.addAll(loadedMsgs);
            // Ambil 40 pesan terakhir untuk context window
            final start = loadedHistory.length > 40
                ? loadedHistory.length - 40
                : 0;
            _history.addAll(loadedHistory.sublist(start));
          });
          _scrollDown();
        }
      }
    } catch (_) {}
  }

  Future<void> _saveHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final last  = _msgs.length > 100 ? _msgs.sublist(_msgs.length - 100) : _msgs;
      await prefs.setStringList('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧_ai_msgs', last.map((m) => json.encode({
        'text'  : m.text,
        'isUser': m.isUser,
        'time'  : m.time.millisecondsSinceEpoch,
      })).toList());
    } catch (_) {}
  }

  void _addBotMsg(String text) {
    setState(() => _msgs.add(_Msg(text: text, isUser: false)));
    _scrollDown();
    _saveHistory();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ── Kirim pesan ───────────────────────────────────────────────────────────
  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _loading) return;

    _ctrl.clear();
    setState(() {
      _msgs.add(_Msg(text: text, isUser: true));
      _loading = true;
      _typing  = true;
    });
    _scrollDown();

    // Tambah ke history sebelum kirim ke API
    _history.add({'role': 'user', 'content': text});
    if (_history.length > 40) _history.removeRange(0, _history.length - 40);

    try {
      final reply = await _callAI(text);
      _history.add({'role': 'assistant', 'content': reply});
      if (_history.length > 40) _history.removeRange(0, _history.length - 40);

      if (mounted) {
        setState(() { _loading = false; _typing = false; });
        _addBotMsg(reply);
      }
    } catch (e) {
      if (mounted) {
        setState(() { _loading = false; _typing = false; });
        _addBotMsg('Maaf, koneksi lagi bermasalah 😅 Coba lagi ya!');
      }
    }
  }

  // ── Cascade API calls dengan full conversation history ───────────────────
  Future<String> _callAI(String userMsg) async {
    // 1. Pollinations — 100% gratis, tanpa key, tanpa limit
    try { return await _callPollinations1(); } catch (_) {}
    // 2. Pollinations endpoint ke-2
    try { return await _callPollinations2(); } catch (_) {}
    // 3. OpenRouter model gratis
    try { return await _callOpenRouter(); } catch (_) {}
    // 4. Groq
    try { return await _callGroq(); } catch (_) {}
    // 5. Local fallback
    return _localFallback(userMsg);
  }

  // ── Pollinations v1 — POST /openai, model openai-large (GPT-4 level) ─────
  Future<String> _callPollinations1() async {
    final msgs = [
      {'role': 'system', 'content': _systemPrompt},
      ..._history,
    ];
    final resp = await http.post(
      Uri.parse('https://text.pollinations.ai/openai'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'model'      : 'openai-large',   // GPT-4o via Pollinations, GRATIS
        'messages'   : msgs,
        'temperature': 0.8,
        'seed'       : DateTime.now().millisecondsSinceEpoch % 9999,
      }),
    ).timeout(const Duration(seconds: 30));

    if (resp.statusCode == 200) {
      final raw  = utf8.decode(resp.bodyBytes).trim();
      // Pollinations bisa return JSON atau plain text
      try {
        final data    = json.decode(raw);
        final content = data['choices']?[0]?['message']?['content'] as String?;
        if (content != null && content.trim().isNotEmpty) return content.trim();
      } catch (_) {
        // Jika bukan JSON, langsung kembalikan sebagai teks
        if (raw.isNotEmpty && raw.length > 5) return raw;
      }
    }
    throw Exception('Pollinations1 ${resp.statusCode}');
  }

  // ── Pollinations v2 — GET endpoint, fallback ─────────────────────────────
  Future<String> _callPollinations2() async {
    final lastMsg = _history.isNotEmpty ? _history.last['content'] ?? '' : '';
    final prompt  = Uri.encodeComponent(
      '$_systemPrompt\n\nUser: $lastMsg\n𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI:');
    final url     = 'https://text.pollinations.ai/$prompt?model=openai&seed=${DateTime.now().millisecond}';

    final resp = await http.get(Uri.parse(url))
        .timeout(const Duration(seconds: 25));

    if (resp.statusCode == 200) {
      final text = utf8.decode(resp.bodyBytes).trim();
      if (text.isNotEmpty && text.length > 3) return text;
    }
    throw Exception('Pollinations2 ${resp.statusCode}');
  }

  // ── OpenRouter — model gratis ─────────────────────────────────────────────
  Future<String> _callOpenRouter() async {
    final msgs = [
      {'role': 'system', 'content': _systemPrompt},
      ..._history,
    ];
    // Coba beberapa model gratis
    for (final model in [
      'meta-llama/llama-3.1-8b-instruct:free',
      'mistralai/mistral-7b-instruct:free',
      'google/gemma-2-9b-it:free',
    ]) {
      try {
        final resp = await http.post(
          Uri.parse('https://openrouter.ai/api/v1/chat/completions'),
          headers: {
            'Content-Type': 'application/json',
            'HTTP-Referer' : 'https://lightstar.app',
            'X-Title'      : '𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI',
          },
          body: json.encode({
            'model'      : model,
            'messages'   : msgs,
            'max_tokens' : 1000,
            'temperature': 0.8,
          }),
        ).timeout(const Duration(seconds: 25));

        if (resp.statusCode == 200) {
          final data    = json.decode(utf8.decode(resp.bodyBytes));
          final content = data['choices']?[0]?['message']?['content'] as String?;
          if (content != null && content.trim().isNotEmpty) return content.trim();
        }
      } catch (_) { continue; }
    }
    throw Exception('OpenRouter all models failed');
  }

  // ── Groq — fallback ───────────────────────────────────────────────────────
  Future<String> _callGroq() async {
    // Coba beberapa model Groq
    for (final entry in [
      {'key': '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', 'model': 'llama3-8b-8192'},
      {'key': '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', 'model': 'mixtral-8x7b-32768'},
    ]) {
      try {
        final resp = await http.post(
          Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
          headers: {
            'Content-Type' : 'application/json',
            'Authorization': 'Bearer ${entry['key']}',
          },
          body: json.encode({
            'model'      : entry['model'],
            'messages'   : [
              {'role': 'system', 'content': _systemPrompt},
              ..._history,
            ],
            'max_tokens' : 1000,
            'temperature': 0.8,
          }),
        ).timeout(const Duration(seconds: 20));

        if (resp.statusCode == 200) {
          final data    = json.decode(utf8.decode(resp.bodyBytes));
          final content = data['choices']?[0]?['message']?['content'] as String?;
          if (content != null && content.trim().isNotEmpty) return content.trim();
        }
      } catch (_) { continue; }
    }
    throw Exception('Groq failed');
  }

  // Smart local fallback dengan context awareness + respon kata kasar
  String _localFallback(String msg) {
    final m   = msg.toLowerCase().trim();
    final rng = math.Random();

    // Ambil konteks dari history
    final lastBotMsg = _history.isNotEmpty
        ? (_history.reversed.firstWhere(
            (h) => h['role'] == 'assistant',
            orElse: () => {'content': ''})['content'] ?? '')
        : '';

    // ── DETEKSI KATA KASAR ──────────────────────────────────────────────────
    const swears = ['anjir','anjing','bangsat','babi','kampret','goblok','tolol',
      'kontol','memek','ngentod','ngentot','tai','tahi','asu','jancok','cuk',
      'sialan','keparat','bajingan','brengsek','titit','pepek','jembut','ngehe',
      'kimak','dancok','cok','anj','anjg','bgst'];
    final hasSwear = swears.any((w) => m.contains(w));

    if (hasSwear) {
      final isFrustrated = m.contains('error') || m.contains('rusak') ||
          m.contains('gak bisa') || m.contains('susah') || m.contains('ribet') ||
          m.contains('lemot') || m.contains('lag') || m.contains('gabisa');
      final isQuestion = m.contains('?') || m.contains('artinya') ||
          m.contains('apa itu') || m.contains('maksud') || m.contains('kenapa');
      final isPositive = m.contains('keren') || m.contains('mantap') ||
          m.contains('gila') || m.contains('seru') || m.contains('bagus') ||
          m.contains('asik') || m.contains('wkwk') || m.contains('haha') ||
          m.length < 20;

      if (isQuestion && (m.contains('artinya') || m.contains('apa itu') || m.contains('maksud'))) {
        if (m.contains('kontol') || m.contains('titit'))
          return 'Itu kata vulgar Indonesia, artinya alat kelamin pria 😄 Ada konteks tertentu?';
        if (m.contains('memek') || m.contains('pepek'))
          return 'Kata vulgar Indonesia, artinya alat kelamin wanita 😄 Nanya beneran atau iseng?';
        if (m.contains('ngentod') || m.contains('ngentot'))
          return 'Kata vulgar untuk hubungan seksual. Ada yang mau dibahas? 😄';
        if (m.contains('anjing') || m.contains('anjir'))
          return 'Anjing = nama hewan, tapi sering jadi umpatan ekspresi kaget/frustrasi 😄';
        if (m.contains('bangsat') || m.contains('bgst'))
          return 'Bangsat = umpatan keras, setara "bastard/damn" dalam bahasa Inggris 😄';
        if (m.contains('goblok') || m.contains('tolol'))
          return 'Itu kata kasar yang artinya bodoh/tidak pintar. Sering dipakai sebagai ekspresi frustrasi 😄';
        return 'Itu kata umpatan/vulgar dalam bahasa Indonesia. Konteks apa yang mau dibahas? 😄';
      }
      if (isFrustrated)
        return ['Yah sial, problem lagi? 😅 Cerita errornya apa?',
          'Aduh ribet banget emang 😤 Gimana ceritanya?',
          'Anjir susah ya? Coba ceritain, aku bantu 😄'][rng.nextInt(3)];
      if (isPositive)
        return ['Wkwk iya bener! 😂','Haha iya kan! 😄','Anjir setuju banget wkwk 😂',
          'Gaks bisa bohong emang 😂'][rng.nextInt(4)];
      return ['Haha oke, lanjut! 😄','Wkwk santai bro 😄','Iya iya, terus? 😂'][rng.nextInt(3)];
    }

    // ── REFERENSI KE KONTEKS SEBELUMNYA ────────────────────────────────────
    final isCtxRef = ['itu','tadi','yang tadi','lanjut','terus','gimana',
      'maksudnya','trus','nah'].any((w) => m == w || m.startsWith('$w ') || m.endsWith(' $w'));
    if (isCtxRef && lastBotMsg.length > 10) {
      final topik = lastBotMsg.length > 50 ? '${lastBotMsg.substring(0, 50)}...' : lastBotMsg;
      return ['Nah tadi soal: "$topik" — mau dilanjut? 😄',
        'Iya yang tadi itu kan? Lanjut dari: "$topik"',
        'Oh maksudnya soal tadi — "$topik"? 😄'][rng.nextInt(3)];
    }

    // ── SALAM ───────────────────────────────────────────────────────────────
    if (RegExp(r'^(halo|hai|hi|hello|hey|hei)\b').hasMatch(m))
      return ['Halo! 😄 Mau tanya atau ngobrolin apa?',
        'Hai! Lagi ngapain? 😊','Hey! Ada yang bisa aku bantu? 😄'][rng.nextInt(3)];

    // ── IDENTITAS ───────────────────────────────────────────────────────────
    if (m.contains('siapa kamu') || m.contains('kamu siapa') || m == 'lo siapa' || m == 'siapa lo')
      return 'Aku 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI 😄 Dibuat kizz dari aplikasi 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧. Bisa coding, ngerjain soal, ngobrol, nulis, apapun!';
    if (m.contains('yang buat') || m.contains('bikin kamu') || m.contains('siapa buat'))
      return 'Dibuat sama Kizz 👨‍💻 developer keren di balik 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧. Kenapa, mau kenalan? Wkwk 😄';
    if (m.contains('chatgpt') || m.contains('gemini') || m.contains('claude'))
      return 'Bukan, aku 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI 😄 Beda ya, tapi sama-sama bisa bantu lo!';

    // ── KABAR ───────────────────────────────────────────────────────────────
    if (m.contains('apa kabar') || m.contains('gimana kabar') || m == 'how are you')
      return 'Baik-baik aja nih! 😄 Lo sendiri? Lagi santai atau lagi pusing sama sesuatu?';
    if (m.contains('makasih') || m.contains('terima kasih') || m.contains('thanks') || m.contains('thx'))
      return ['Sama-sama! 😊 Ada lagi?','No problem 😄','Santai aja! Ada yang lain?'][rng.nextInt(3)];

    // ── SOAL / PELAJARAN ────────────────────────────────────────────────────
    if (m.contains('soal') || m.contains('pr ') || m.contains('tugas') || m.contains('ujian') || m.contains('latihan')) {
      if (m.contains('matematika') || m.contains('math') || m.contains('hitung') || m.contains('aljabar'))
        return 'Boleh! Share soalnya, aku kerjain step by step 😄';
      if (m.contains('fisika') || m.contains('physics'))
        return 'Fisika oke! Kirim soalnya, aku bantu kerjain pakai rumus yang benar 😄';
      if (m.contains('kimia') || m.contains('chemistry'))
        return 'Kimia siap! Share soalnya, aku bantu step by step 😄';
      if (m.contains('biologi') || m.contains('bio'))
        return 'Bio bisa! Kirim soal atau materinya 😊';
      if (m.contains('inggris') || m.contains('english'))
        return 'Bahasa Inggris oke! Soal apa — grammar, vocab, reading, atau writing?';
      return 'Boleh, share soalnya dan aku bantu kerjain! Mata pelajaran apa? 😄';
    }

    // ── MATEMATIKA LANGSUNG ─────────────────────────────────────────────────
    // Deteksi ekspresi matematika sederhana
    final mathPattern = RegExp(r'[\d]+\s*[\+\-\*\/\^]\s*[\d]+');
    if (mathPattern.hasMatch(m)) {
      try {
        // Coba evaluasi operasi sederhana
        if (m.contains('+') && !m.contains('?')) {
          return 'Itu operasi matematika ya? Share lengkapnya biar aku kerjain dengan benar! 😄';
        }
      } catch (_) {}
    }

    // ── CARA MEMBUAT / TUTORIAL ─────────────────────────────────────────────
    if (m.contains('cara') || m.contains('gimana cara') || m.contains('bagaimana cara') ||
        m.contains('how to') || m.contains('langkah') || m.contains('tutorial') ||
        m.contains('cara buat') || m.contains('cara bikin') || m.contains('cara masak')) {
      if (m.contains('masak') || m.contains('masakan') || m.contains('mie') ||
          m.contains('nasi') || m.contains('ayam') || m.contains('resep'))
        return 'Mau masak apa? Sebutin nama masakannya, aku kasih resep lengkap! 🍳';
      if (m.contains('flutter') || m.contains('dart') || m.contains('android') || m.contains('app'))
        return 'Tutorial Flutter/Android? Spesialisasiin dulu — mau buat fitur apa atau dari mana mulainya?';
      if (m.contains('website') || m.contains('web') || m.contains('html') || m.contains('css'))
        return 'Mau bikin website? Ceritain lebih detail — landing page, full website, atau komponen tertentu?';
      if (m.contains('cv') || m.contains('resume') || m.contains('lamaran'))
        return 'Mau bikin CV/lamaran kerja? Aku bisa bantu struktur dan isi yang profesional! Cerita dulu background-nya 😊';
      return 'Cara buat apa nih? Ceritain lebih spesifik, aku kasih panduan lengkap step by step! 😄';
    }

    // ── CODING ──────────────────────────────────────────────────────────────
    if (m.contains('flutter') || m.contains('dart'))
      return 'Flutter/Dart nih! Mau tanya soal widget, state management, navigasi, atau minta code tertentu? 🚀';
    if (m.contains('python'))
      return 'Python siap! Mau buat apa — automation, data, web, atau belajar dasar?';
    if (m.contains('javascript') || m.contains('react') || m.contains('node') || m.contains('vue'))
      return 'JavaScript ecosystem! Lagi handle bagian mana — frontend, backend, atau framework tertentu?';
    if (m.contains('html') || m.contains('css') || m.contains('website'))
      return 'Web dev! Mau bikin apa atau ada yang error? Share kodenya kalau ada 😄';
    if (m.contains('error') || m.contains('bug') || m.contains('gak jalan') || m.contains('gabisa'))
      return 'Ada error nih? Share kode + pesan errornya, aku debug sekarang 🔧';
    if (m.contains('code') || m.contains('kode') || m.contains('program') || m.contains('coding'))
      return 'Mau coding apa? Kasih tau bahasa dan yang mau dibuat, aku bantu! 💻';

    // ── PENGETAHUAN UMUM ────────────────────────────────────────────────────
    if (m.contains('ibu kota') || m.contains('ibukota')) {
      if (m.contains('indonesia')) return 'Ibu kota Indonesia adalah Jakarta (secara resmi), dengan rencana pindah ke IKN di Kalimantan Timur 😄';
      if (m.contains('australia')) return 'Canberra! Bukan Sydney ya — banyak yang salah kaprah. Sydney itu kota terbesar, bukan ibu kota 😄';
      if (m.contains('jepang') || m.contains('japan')) return 'Tokyo! Sekaligus kota terbesar dan tersibuk di dunia 😄';
      if (m.contains('korea')) return 'Seoul (Korea Selatan) dan Pyongyang (Korea Utara).';
      if (m.contains('inggris') || m.contains('uk') || m.contains('britania')) return 'London!';
      if (m.contains('prancis') || m.contains('france')) return 'Paris!';
      if (m.contains('jerman') || m.contains('germany')) return 'Berlin!';
      if (m.contains('china') || m.contains('tiongkok')) return 'Beijing!';
      if (m.contains('india')) return 'New Delhi!';
      if (m.contains('amerika') || m.contains('usa') || m.contains('united states')) return 'Washington D.C.! Bukan New York ya 😄';
      if (m.contains('brazil') || m.contains('brasil')) return 'Brasilia! Bukan Rio de Janeiro atau São Paulo 😄';
      if (m.contains('rusia') || m.contains('russia')) return 'Moskow (Moscow)!';
      return 'Ibu kota negara mana? Sebutin negaranya 😄';
    }
    if (m.contains('siapa presiden') || m.contains('presidennya') || m.contains('presiden sekarang')) {
      if (m.contains('indonesia')) return 'Presiden Indonesia saat ini adalah Prabowo Subianto (menjabat sejak Oktober 2024) 😊';
      if (m.contains('amerika') || m.contains('usa')) return 'Presiden AS saat ini adalah Donald Trump (periode 2025-2029) 😊';
      return 'Presiden negara mana? Sebutin negaranya 😄';
    }

    // ── WAKTU / TANGGAL ─────────────────────────────────────────────────────
    if (m == 'jam berapa' || m.contains('sekarang jam') || m == 'what time')
      return 'Aku gak bisa akses waktu real-time 😅 Cek di HP lo aja, pasti akurat!';
    if (m.contains('tanggal') && m.contains('sekarang') || m == 'hari ini tanggal berapa')
      return 'Buat tanggal real-time, aku saranin cek langsung di HP lo ya 😄';

    // ── CUACA & BERITA ──────────────────────────────────────────────────────
    if (m.contains('cuaca') || m.contains('weather'))
      return 'Cuaca real-time aku gak bisa akses langsung. Ketik "cuaca [kota]" di Google buat info akurat! 🌤️';
    if (m.contains('berita') || m.contains('news') || m.contains('terbaru'))
      return 'Berita real-time aku gak bisa akses. Cek detik.com, kompas.com, atau cnnindonesia.com ya! 📰';

    // ── REKOMENDASI ─────────────────────────────────────────────────────────
    if (m.contains('rekomen') || m.contains('saran') || m.contains('suggest')) {
      if (m.contains('film') || m.contains('movie') || m.contains('nonton'))
        return 'Mau nonton film genre apa? Action, thriller, romance, comedy, sci-fi? 🎬';
      if (m.contains('anime'))
        return 'Suka genre anime apa? Action, isekai, romance, slice of life, atau horror? 🎌';
      if (m.contains('lagu') || m.contains('musik') || m.contains('music'))
        return 'Suka genre musik apa — pop, hiphop, indie, RnB, rock? 🎵';
      if (m.contains('game'))
        return 'Main di platform apa? PC/mobile/console? Suka genre apa? 🎮';
      if (m.contains('buku') || m.contains('novel'))
        return 'Mau buku genre apa — fiksi, non-fiksi, self-help, thriller, romance? 📚';
      return 'Rekomendasi soal apa? Spesialisasiin dulu topiknya 😄';
    }

    // ── EMOSI / KONDISI ─────────────────────────────────────────────────────
    if (m.contains('sedih') || m.contains('galau') || m.contains('nangis') || m.contains('down') || m.contains('depresi'))
      return ['Eh, lagi gak baik-baik aja? Cerita dong kalau mau 👂',
        'Aduh, lagi berat ya? Gak apa-apa, aku dengerin kok 😊'][rng.nextInt(2)];
    if (m.contains('seneng') || m.contains('happy') || m.contains('bahagia') || m.contains('excited'))
      return 'Wah asik nih! Kenapa seneng? Cerita dong 😄';
    if (m.contains('bosen') || m.contains('gabut') || m.contains('boring'))
      return ['Gabut? Nanya sesuatu ke aku aja wkwk 😄 Atau mau aku kasih tebak-tebakan?',
        'Haha lagi gabut? Mau ngobrol, belajar sesuatu, atau minta hiburan? 😄'][rng.nextInt(2)];
    if (m.contains('stress') || m.contains('stres') || m.contains('pusing') || m.contains('capek'))
      return 'Lagi capek ya? Cerita, mungkin aku bisa bantu 😊 Atau kalau mau istirahat dulu juga gapapa.';
    if (m.contains('lapar') || m.contains('laper'))
      return 'Lapar? Makan dulu bro wkwk 😄 Atau mau aku saranin mau masak apa?';
    if (m.contains('ngantuk') || m.contains('tidur'))
      return 'Udah ngantuk? Tidur dulu kalau memang butuh istirahat 😄';

    // ── BERCANDA ────────────────────────────────────────────────────────────
    if (m.contains('joke') || m == 'lucu dong' || m.contains('cerita lucu') || m.contains('humor'))
      return [
        'Kenapa programmer suka kopi? Karena Java! ☕😄',
        'Bug terbaik adalah yang gak pernah di-fix karena gak ada yang tahu itu bug 🐛😂',
        'Kenapa programmer pakai kacamata? Karena gak bisa C# 😂',
        'Ada 10 jenis orang: yang ngerti binary dan yang nggak 😂',
        'Programmer dan istrinya belanja. Istri: "Beliin susu 1, kalau ada telur beli 6." Programmer balik dengan 6 susu. "Kan ada telur." 😂'
      ][rng.nextInt(5)];
    if (m.contains('tebak') || m.contains('teka-teki'))
      return [
        'Oke! Yang punya tangan tapi gak bisa tepuk tangan? — Jam! 😄',
        'Makin diisi, makin ringan. Apa itu? — Balon! 😄',
        'Aku bicara tanpa mulut, dengar tanpa telinga, gak punya tubuh tapi hidup dari angin. Aku apa? — Gema! 😄'
      ][rng.nextInt(3)];

    // ── SINGKAT / YA/TIDAK ──────────────────────────────────────────────────
    if (m.length <= 4) {
      if (['iya','ya','yes','yep','yoi','yup'].contains(m))
        return lastBotMsg.contains('?') ? 'Oh oke! Lanjut gimana? 😄' : 'Oke sip! 😄';
      if (['tidak','gak','nggak','no','ngga','kaga'].contains(m))
        return 'Oh gak? Oke 😄 Mau ngapain nih?';
      if (['ok','oke','okay','sip','siap'].contains(m))
        return 'Sip! 😄 Ada yang mau dibahas?';
      if (['wkwk','haha','lol','xixi','hehe'].contains(m))
        return ['Wkwk 😂', 'Hahaha! 😂', 'Ketawa kenapa nih? 😄'][rng.nextInt(3)];
      // Pesan super pendek lainnya
      return ['Hmm? 😄 Lanjutin dong!','Kurang kedengeran nih, apaan? 😄','Eh? Maksudnya? 😄'][rng.nextInt(3)];
    }

    // ── FALLBACK CERDAS ─────────────────────────────────────────────────────
    if (m.endsWith('?'))
      return 'Pertanyaan menarik! Koneksi AI-ku lagi agak lemot nih 😅 Coba kirim lagi atau tanya lebih spesifik biar aku jawab dengan benar!';

    return ['Hmm koneksi lagi agak lemot nih 😅 Coba ulangi ya, mau aku bantu!',
      'Maaf, lagi agak gak stabil koneksinya 😅 Kirim ulang dong!',
      'Aduh timing-nya pas lemot wkwk 😅 Coba lagi ya!'][rng.nextInt(3)];
  }



  // ── Clear chat ────────────────────────────────────────────────────────────
  Future<void> _clearChat() async {
    showDialog(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: _kCard,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      title: const Text('Hapus Riwayat Chat',
          style: TextStyle(color: _kText, fontSize: 15)),
      content: const Text('Semua pesan akan dihapus. Lanjutkan?',
          style: TextStyle(color: _kTextSub, fontSize: 13)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Batal', style: TextStyle(color: _kTextSub)),
        ),
        TextButton(
          onPressed: () async {
            Navigator.pop(ctx);
            final prefs = await SharedPreferences.getInstance();
            await prefs.remove('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧_ai_msgs');
            if (mounted) setState(() {
              _msgs.clear();
              _history.clear();
            });
            Future.delayed(const Duration(milliseconds: 300), () {
              if (mounted) _addBotMsg('Chat baru dimulai! Ada yang bisa aku bantu? ✨');
            });
          },
          child: const Text('Hapus', style: TextStyle(color: Colors.redAccent)),
        ),
      ],
    ));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // BUILD
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kBg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: _kBlueBrt, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: [
          _buildAiAvatar(size: 34),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI',
                style: TextStyle(color: _kBlueBrt, fontSize: 15,
                    fontWeight: FontWeight.bold, letterSpacing: 0.5)),
            Row(children: [
              Container(
                width: 7, height: 7,
                decoration: const BoxDecoration(
                  color: AppColors.success, shape: BoxShape.circle),
              ),
              const SizedBox(width: 5),
              const Text('Online', style: TextStyle(color: AppColors.success, fontSize: 11)),
            ]),
          ]),
        ]),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded, color: _kTextSub, size: 22),
            tooltip: 'Hapus chat',
            onPressed: _clearChat,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _kBorder),
        ),
      ),
      body: Column(children: [
        Expanded(
          child: _msgs.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
                  itemCount: _msgs.length + (_typing ? 1 : 0),
                  itemBuilder: (_, i) {
                    if (_typing && i == _msgs.length) return _buildTyping();
                    return _buildMsgBubble(_msgs[i]);
                  },
                ),
        ),
        _buildInputBar(),
      ]),
    );
  }

  Widget _buildAiAvatar({double size = 44}) {
    return AnimatedBuilder(
      animation: _orbitCtrl,
      builder: (_, __) {
        return SizedBox(
          width: size, height: size,
          child: Stack(alignment: Alignment.center, children: [
            Transform.rotate(
              angle: _orbitCtrl.value * 2 * math.pi,
              child: Container(
                width: size, height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: SweepGradient(colors: [
                    _kBlueBrt.withOpacity(0.0),
                    _kBlueBrt.withOpacity(0.6),
                    _kCyan.withOpacity(0.4),
                    _kBlueBrt.withOpacity(0.0),
                  ]),
                ),
              ),
            ),
            ScaleTransition(
              scale: _pulseAnim,
              child: Container(
                width: size * 0.78,
                height: size * 0.78,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(colors: [
                    Color(0xFF1E3A8A),
                    AppColors.bg,
                  ]),
                  border: Border.all(color: _kBlueBrt.withOpacity(0.5), width: 1.5),
                ),
                child: Icon(Icons.auto_awesome_rounded,
                    color: _kBlueBrt, size: size * 0.38),
              ),
            ),
          ]),
        );
      },
    );
  }

  Widget _buildEmptyState() => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      _buildAiAvatar(size: 90),
      const SizedBox(height: 20),
      const Text('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 AI',
          style: TextStyle(color: _kBlueBrt, fontSize: 22,
              fontWeight: FontWeight.bold, letterSpacing: 1)),
      const SizedBox(height: 8),
      const Text('Asisten cerdasmu siap membantu!',
          style: TextStyle(color: _kTextSub, fontSize: 13)),
      const SizedBox(height: 32),
      Wrap(
        spacing: 8, runSpacing: 8,
        children: [
          _quickBtn('💡 Ide kreatif'),
          _quickBtn('📝 Bantu nulis'),
          _quickBtn('💻 Tanya coding'),
          _quickBtn('😄 Ceritakan joke'),
        ],
      ),
    ]),
  );

  Widget _quickBtn(String label) => GestureDetector(
    onTap: () {
      _ctrl.text = label.replaceAll(RegExp(r'^[^\s]+\s'), '');
      _send();
    },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _kBorder),
      ),
      child: Text(label, style: const TextStyle(color: _kText, fontSize: 12)),
    ),
  );

  Widget _buildMsgBubble(_Msg msg) {
    final isUser = msg.isUser;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) ...[
            _buildAiAvatar(size: 30),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.75),
                  decoration: BoxDecoration(
                    gradient: isUser
                        ? const LinearGradient(colors: [
                            Color(0xFF1E40AF), Color(0xFF1D4ED8)])
                        : const LinearGradient(colors: [
                            AppColors.card, AppColors.border]),
                    borderRadius: BorderRadius.only(
                      topLeft    : const Radius.circular(16),
                      topRight   : const Radius.circular(16),
                      bottomLeft : Radius.circular(isUser ? 16 : 4),
                      bottomRight: Radius.circular(isUser ? 4  : 16),
                    ),
                    border: isUser
                        ? null
                        : Border.all(color: _kBorder, width: 0.8),
                    boxShadow: [BoxShadow(
                      color: isUser
                          ? _kBlue.withOpacity(0.2)
                          : Colors.black.withOpacity(0.3),
                      blurRadius: 8, offset: const Offset(0, 2),
                    )],
                  ),
                  child: Text(msg.text,
                      style: TextStyle(
                        color: isUser ? Colors.white : _kText,
                        fontSize: 13.5, height: 1.5,
                      )),
                ),
                const SizedBox(height: 3),
                Text(
                  '${msg.time.hour.toString().padLeft(2, '0')}:'
                  '${msg.time.minute.toString().padLeft(2, '0')}',
                  style: const TextStyle(color: _kTextSub, fontSize: 10),
                ),
              ],
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            Container(
              width: 30, height: 30,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [Color(0xFF1D4ED8), Color(0xFF1E40AF)]),
              ),
              child: const Icon(Icons.person_rounded, color: Colors.white, size: 17),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTyping() => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      _buildAiAvatar(size: 30),
      const SizedBox(width: 8),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _kCard,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16),
            bottomRight: Radius.circular(16), bottomLeft: Radius.circular(4),
          ),
          border: Border.all(color: _kBorder, width: 0.8),
        ),
        child: Row(mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) => _TypingDot(delay: i * 200)),
        ),
      ),
    ]),
  );

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: _kSurface,
        border: Border(top: BorderSide(color: _kBorder)),
      ),
      child: SafeArea(
        top: false,
        child: Row(children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: _kCard,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _kBorder),
              ),
              child: TextField(
                controller: _ctrl,
                style: const TextStyle(color: _kText, fontSize: 14),
                maxLines: 4,
                minLines: 1,
                textInputAction: TextInputAction.newline,
                decoration: const InputDecoration(
                  hintText: 'Ketik pesan...',
                  hintStyle: TextStyle(color: _kTextSub, fontSize: 14),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                onSubmitted: (_) => _send(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _loading ? null : _send,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 46, height: 46,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: _loading
                    ? const LinearGradient(colors: [Color(0xFF374151), Color(0xFF374151)])
                    : const LinearGradient(
                        colors: [Color(0xFF1D4ED8), Color(0xFF00BFFF)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight),
                boxShadow: _loading ? [] : [BoxShadow(
                  color: _kBlue.withOpacity(0.4),
                  blurRadius: 10, spreadRadius: 1,
                )],
              ),
              child: _loading
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
            ),
          ),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TYPING DOT ANIMATION
// ─────────────────────────────────────────────────────────────────────────────
class _TypingDot extends StatefulWidget {
  final int delay;
  const _TypingDot({required this.delay});
  @override State<_TypingDot> createState() => _TypingDotState();
}

class _TypingDotState extends State<_TypingDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0, end: -6).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, _anim.value),
        child: Container(
          width: 7, height: 7,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            color: _kBlueBrt.withOpacity(0.8),
            shape: BoxShape.circle,
          ),
        ),
      ),
    );
  }
}
