import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'main.dart';

const _baseUrl = 'http://nayahaikall.tyzx-host.my.id:2563';

bool _canGlobal(String r) {
  final l = r.toLowerCase();
  return l == 'high owner' || l == 'owner' || l == 'high admin' || l == 'vip';
}

class HomePage extends StatefulWidget {
  final String username, password, sessionKey, role, expiredDate;
  final List<Map<String, dynamic>> listBug;
  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final _targetCtrl    = TextEditingController();
  final _bugScrollCtrl = ScrollController();
  String  _selectedBugId = '';
  String  _bugMode    = 'number';
  String  _senderType = 'private';
  bool    _isSending  = false;
  String? _responseMsg;
  List<String> _globalSenders = [];
  bool _loadingSenders = false;

  late AnimationController _auroraCtrl, _entranceCtrl, _btnCtrl, _resultCtrl, _pulseCtrl, _glowCtrl;
  late Animation<double> _fade, _btnGlow, _resultFade, _pulse, _glow;
  late Animation<Offset>  _resultSlide;

  VideoPlayerController? _vCtrl;
  ChewieController?      _chewieCtrl;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    if (widget.listBug.isNotEmpty) _selectedBugId = widget.listBug[0]['bug_id'] ?? '';

    _auroraCtrl   = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _btnCtrl      = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _resultCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _pulseCtrl    = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _glowCtrl     = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);

    _fade        = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);
    _btnGlow     = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));
    _resultFade  = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));
    _pulse       = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _glow        = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _initVideo();
    _loadGlobalSenders();
  }

  @override
  void dispose() {
    _auroraCtrl.dispose(); _entranceCtrl.dispose(); _btnCtrl.dispose();
    _resultCtrl.dispose(); _pulseCtrl.dispose(); _glowCtrl.dispose();
    _targetCtrl.dispose(); _bugScrollCtrl.dispose();
    _vCtrl?.dispose(); _chewieCtrl?.dispose();
    super.dispose();
  }

  void _initVideo() {
    _vCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _chewieCtrl = ChewieController(
            videoPlayerController: _vCtrl!,
            autoPlay: true, looping: true, showControls: false,
          );
          _videoReady = true;
        });
      });
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _loadingSenders = true);
    try {
      final r = await http.get(Uri.parse(
          '$_baseUrl/getActiveSenders?key=${widget.sessionKey}'
      )).timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && d['senders'] != null && mounted)
        setState(() => _globalSenders = List<String>.from(d['senders']));
    } catch (_) {}
    finally { if (mounted) setState(() => _loadingSenders = false); }
  }

  Future<void> _sendBug() async {
    final raw = _targetCtrl.text.trim();
    if (_bugMode == 'number' && _formatPhone(raw) == null) {
      _showAlert('Nomor Tidak Valid', 'Gunakan format: +62812xxxxxxxx'); return;
    }
    if (_bugMode == 'group' && !_validGroup(raw)) {
      _showAlert('Link Tidak Valid', 'Masukkan link grup WA yang valid.\nhttps://chat.whatsapp.com/XXX'); return;
    }
    if (_senderType == 'global' && !_canGlobal(widget.role)) {
      _showAlert('Akses Ditolak', 'Sender Global hanya untuk High Owner, Owner, High Admin & VIP!'); return;
    }
    if (_selectedBugId.isEmpty) { _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.'); return; }

    setState(() => _isSending = true);
    _resultCtrl.reset();
    HapticFeedback.mediumImpact();

    try {
      final enc = Uri.encodeComponent(raw);
      final url = Uri.parse('$_baseUrl/sendBug?key=${widget.sessionKey}&target=$enc&bug=$_selectedBugId'
          '${_senderType == "global" ? "&senderMode=global" : ""}');
      final res  = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == false)         _setResp('error',   'Session tidak valid. Login ulang.');
      else if (data['cooldown'] == true)  _setResp('warning', 'Cooldown aktif! Tunggu ${data['wait'] ?? 0}s lagi.');
      else if (data['sended'] == true)  {
        HapticFeedback.lightImpact();
        final target = _bugMode == 'group' ? 'grup target' : raw;
        _targetCtrl.clear();
        setState(() => _responseMsg = null);
        if (mounted) _showSuccessDialog(target);
      }
      else                                _setResp('error',   'Gagal kirim. Server maintenance.');
    } catch (e) {
      _setResp('error', e.toString().contains('Timeout') ? 'Request timeout!' : 'Koneksi error!');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _setResp(String t, String m) {
    if (!mounted) return;
    setState(() => _responseMsg = '$t|$m');
    _resultCtrl.forward(from: 0);
  }

  String? _formatPhone(String s) {
    final c = s.replaceAll(RegExp(r'[^\d+]'), '');
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }
  bool _validGroup(String s) => s.startsWith('https://') && s.contains('chat.whatsapp.com');

  void _showSuccessDialog(String target) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.75),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, a, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: a, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: a, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0D1120),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.success.withOpacity(0.35), width: 1.5),
            boxShadow: [
              BoxShadow(color: AppColors.success.withOpacity(0.15), blurRadius: 40, spreadRadius: 4),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // ── Ikon centang hijau ────────────────────────────────
            Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.success,
                boxShadow: [
                  BoxShadow(color: AppColors.success.withOpacity(0.5), blurRadius: 18, spreadRadius: 2),
                ],
              ),
              child: const Icon(Icons.check_rounded, color: Colors.white, size: 30),
            ),
            const SizedBox(height: 16),
            // ── Judul ─────────────────────────────────────────────
            const Text('Bug Terkirim', style: TextStyle(
              fontFamily: 'Orbitron', fontSize: 18,
              fontWeight: FontWeight.w900, color: AppColors.textPrimary,
              letterSpacing: 0.5,
            )),
            const SizedBox(height: 6),
            const Text('Bug berhasil dikirim ke target:', style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 12,
              color: AppColors.textSub,
            )),
            const SizedBox(height: 12),
            // ── Nomor target ──────────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: AppColors.surface.withOpacity(0.6),
                border: Border.all(color: AppColors.borderGlow),
              ),
              child: Row(children: [
                const Icon(Icons.smartphone_rounded, color: AppColors.textSub, size: 18),
                const SizedBox(width: 12),
                Text(target, style: const TextStyle(
                  fontFamily: 'ShareTechMono', fontSize: 14,
                  color: AppColors.textPrimary, fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                )),
              ]),
            ),
            const SizedBox(height: 16),
            // ── Tombol SELESAI ────────────────────────────────────
            GestureDetector(
              onTap: () => Navigator.pop(ctx),
              child: Container(
                width: double.infinity, height: 46,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF00C853), Color(0xFF00E676)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(color: AppColors.success.withOpacity(0.4), blurRadius: 20, offset: const Offset(0, 6)),
                  ],
                ),
                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('SELESAI', style: TextStyle(
                    fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.w900,
                    color: Colors.white, letterSpacing: 2,
                  )),
                  SizedBox(width: 8),
                  Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 18),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            // ── Copyright ─────────────────────────────────────────
            const Text('© 𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧 Project', style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 9,
              color: AppColors.textMuted, letterSpacing: 1,
            )),
          ]),
        ),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context, barrierDismissible: true, barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 280),
      transitionBuilder: (_, a, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: a, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: a, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.warning.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: AppColors.warning.withOpacity(0.1), blurRadius: 40)],
          ),
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 56, height: 56,
              decoration: BoxDecoration(shape: BoxShape.circle,
                color: AppColors.warning.withOpacity(0.12),
                border: Border.all(color: AppColors.warning.withOpacity(0.4))),
              child: const Icon(Icons.warning_amber_rounded, color: AppColors.warning, size: 26)),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontFamily: 'Orbitron', fontSize: 15,
              fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            const SizedBox(height: 9),
            Text(msg, textAlign: TextAlign.center, style: const TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 13, color: AppColors.textSub, height: 1.5)),
            const SizedBox(height: 22),
            _ActionBtn(label: 'OK', colors: const [AppColors.warning, Color(0xFFE65100)],
              onTap: () => Navigator.pop(ctx), fullWidth: true),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.bg,
    body: Stack(children: [
      AnimatedBuilder(
        animation: _auroraCtrl,
        builder: (_, __) => CustomPaint(
          painter: _HomeAuroraPainter(_auroraCtrl.value),
          child:   const SizedBox.expand(),
        ),
      ),
      SafeArea(
        child: FadeTransition(
          opacity: _fade,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 44),
            child: Column(children: [
              _buildHeader(),
              const SizedBox(height: 8),
              _buildVideoCard(),
              const SizedBox(height: 12),
              _buildModeToggle(),
              const SizedBox(height: 8),
              _buildTargetInput(),
              const SizedBox(height: 13),
              _buildBugSelector(),
              const SizedBox(height: 13),
              _buildSenderCard(),
              // ── Tampilkan list nomor global jika mode global dipilih ──
              if (_senderType == 'global' && _canGlobal(widget.role)) ...[
                const SizedBox(height: 6),
                _buildGlobalSenderList(),
              ],
              const SizedBox(height: 26),
              _buildSendButton(),
              if (_responseMsg != null) ...[
                const SizedBox(height: 8),
                _buildResultBanner(),
              ],
              const SizedBox(height: 16),
            ]),
          ),
        ),
      ),
    ]),
  );

  Widget _buildHeader() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      gradient: const LinearGradient(
        colors: [Color(0xFF111627), Color(0xFF0C0F1E)],
        begin: Alignment.topLeft, end: Alignment.bottomRight,
      ),
      border: Border.all(color: AppColors.borderGlow, width: 1),
      boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.04), blurRadius: 24)],
    ),
    child: Row(children: [
      Container(width: 50, height: 50,
        decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: const LinearGradient(colors: [Color(0xFF00B4CC), Color(0xFF00E5FF)]),
          boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.5), blurRadius: 16)]),
        child: const Icon(Icons.bug_report_rounded, color: AppColors.bg, size: 24)),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.username.toUpperCase(), style: const TextStyle(
          fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
        const SizedBox(height: 5),
        Row(children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              gradient: LinearGradient(colors: [
                AppColors.success.withOpacity(0.15), AppColors.success.withOpacity(0.05),
              ]),
              border: Border.all(color: AppColors.success.withOpacity(0.35))),
            child: Text(widget.role.toUpperCase(), style: const TextStyle(
              fontFamily: 'Orbitron', fontSize: 8, color: AppColors.success,
              fontWeight: FontWeight.w800, letterSpacing: 1))),
          const SizedBox(width: 9),
          Text('EXP: ${widget.expiredDate}', style: const TextStyle(
            fontFamily: 'ShareTechMono', fontSize: 10, color: AppColors.textMuted)),
        ]),
      ])),
      AnimatedBuilder(
        animation: _pulseCtrl,
        builder: (_, __) => Container(width: 44, height: 44,
          decoration: BoxDecoration(shape: BoxShape.circle,
            gradient: LinearGradient(colors: [
              AppColors.danger.withOpacity(0.15 + 0.10 * _pulse.value),
              AppColors.danger.withOpacity(0.05),
            ]),
            border: Border.all(
              color: AppColors.danger.withOpacity(0.35 + 0.25 * _pulse.value), width: 1),
            boxShadow: [BoxShadow(
              color: AppColors.danger.withOpacity(0.3 * _pulse.value), blurRadius: 14)]),
          child: const Icon(Icons.flash_on_rounded, color: AppColors.danger, size: 22)),
      ),
    ]),
  );

  Widget _buildVideoCard() => ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Container(height: 180,
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderGlow)),
      child: _videoReady && _chewieCtrl != null
          ? Chewie(controller: _chewieCtrl!)
          : Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              const SizedBox(width: 24, height: 24,
                child: CircularProgressIndicator(color: AppColors.cyan, strokeWidth: 2)),
              const SizedBox(height: 12),
              const Text('LOADING VIDEO...', style: TextStyle(
                fontFamily: 'Orbitron', fontSize: 9, color: AppColors.textSub, letterSpacing: 2)),
            ])),
    ),
  );

  Widget _buildModeToggle() => Container(
    padding: const EdgeInsets.all(5),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      color: const Color(0xFF0A0D18),
      border: Border.all(color: AppColors.border)),
    child: Row(children: [
      Expanded(child: _TabBtn(
        label: 'NOMOR',
        icon: Icons.smartphone_rounded,
        active: _bugMode == 'number',
        onTap: () => setState(() => _bugMode = 'number'))),
      Expanded(child: _TabBtn(
        label: 'GRUP',
        icon: Icons.groups_rounded,
        active: _bugMode == 'group',
        onTap: () => setState(() => _bugMode = 'group'))),
    ]),
  );

  Widget _buildTargetInput() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _FieldLabel(
      icon: Icons.gps_fixed_rounded,
      label: _bugMode == 'number' ? 'TARGET NOMOR' : 'TARGET GRUP',
      color: AppColors.cyan,
    ),
    const SizedBox(height: 8),
    Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: AppColors.cyan.withOpacity(0.06), blurRadius: 18)],
      ),
      child: TextField(
        controller: _targetCtrl,
        style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 14, color: AppColors.textPrimary),
        keyboardType: _bugMode == 'number' ? TextInputType.phone : TextInputType.url,
        decoration: InputDecoration(
          hintText: _bugMode == 'number' ? '+62812xxxxxxxx' : 'https://chat.whatsapp.com/...',
          hintStyle: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 13, color: AppColors.textMuted),
          prefixIcon: Icon(_bugMode == 'number' ? Icons.smartphone_rounded : Icons.group_rounded,
            color: AppColors.cyan, size: 20),
          suffixIcon: _targetCtrl.text.isNotEmpty
              ? GestureDetector(
                  onTap: () => setState(() => _targetCtrl.clear()),
                  child: const Icon(Icons.close_rounded, color: AppColors.textMuted, size: 18))
              : null,
          filled: true,
          fillColor: const Color(0xFF0A0D18),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppColors.border)),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppColors.cyan, width: 1.5)),
        ),
        onChanged: (_) => setState(() {}),
      ),
    ),
  ]);

  Widget _buildBugSelector() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      _FieldLabel(icon: Icons.rocket_launch_rounded, label: 'ATTACK BUG', color: AppColors.danger),
      const Spacer(),
      Text('${widget.listBug.length} bug ready', style: const TextStyle(
        fontFamily: 'ShareTechMono', fontSize: 10, color: AppColors.textMuted)),
    ]),
    const SizedBox(height: 11),
    SizedBox(
      height: 100,
      child: PageView.builder(
        controller: PageController(viewportFraction: 0.72),
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: widget.listBug.length,
        onPageChanged: (i) {
          final id = widget.listBug[i]['bug_id'] ?? '';
          setState(() => _selectedBugId = id);
        },
        itemBuilder: (_, i) {
          final b      = widget.listBug[i];
          final id     = b['bug_id'] ?? '';
          final nm     = b['bug_name'] ?? 'Bug \${i + 1}';
          final active = id == _selectedBugId;
          return GestureDetector(
            onTap: () => setState(() => _selectedBugId = id),
            child: AnimatedScale(
              scale: active ? 1.0 : 0.88,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutBack,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: active
                    ? const LinearGradient(
                        colors: [Color(0xFFFF1744), Color(0xFFD32F2F), Color(0xFF8B0000)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight)
                    : LinearGradient(colors: [
                        const Color(0xFF0F1220),
                        AppColors.surface.withOpacity(0.8),
                      ]),
                  border: Border.all(
                    color: active ? AppColors.danger : AppColors.borderGlow,
                    width: active ? 1.5 : 1),
                  boxShadow: active ? [
                    BoxShadow(color: AppColors.danger.withOpacity(0.5), blurRadius: 20, offset: const Offset(0,6)),
                    BoxShadow(color: AppColors.danger.withOpacity(0.2), blurRadius: 40),
                  ] : [
                    BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Skull icon
                    Icon(
                      Icons.dangerous_rounded,
                      size: active ? 28 : 22,
                      color: active ? Colors.white : AppColors.textMuted,
                    ),
                    const SizedBox(height: 8),
                    Text(nm,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: active ? 13 : 11,
                        fontWeight: FontWeight.w700,
                        color: active ? Colors.white : AppColors.textSub,
                        letterSpacing: 0.5,
                      )),

                  ],
                ),
              ),
            ),
          );
        },
      ),
    ),
  ]);

  Widget _buildSenderCard() {
    final canGlobal = _canGlobal(widget.role);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(
          colors: [Color(0xFF111627), Color(0xFF0C0F1E)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        border: Border.all(color: AppColors.borderGlow)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _FieldLabel(icon: Icons.send_rounded, label: 'MODE SENDER', color: AppColors.violetBright),
        const SizedBox(height: 12),
        Row(children: [
          // ── PRIVATE BUTTON ───────────────────────────────────────
          Expanded(child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => setState(() => _senderType = 'private'),
            child: _SenderOption(
              label: 'PRIVATE',
              sub: 'Sender pribadi',
              icon: Icons.person_rounded,
              active: _senderType == 'private',
              color: AppColors.cyan,
            ),
          )),
          const SizedBox(width: 10),
          // ── GLOBAL BUTTON ────────────────────────────────────────
          Expanded(child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              if (!canGlobal) {
                _showAlert('Akses Ditolak', 'Sender Global hanya untuk High Owner, Owner, High Admin & VIP!');
                return;
              }
              setState(() => _senderType = 'global');
              if (_globalSenders.isEmpty) _loadGlobalSenders();
            },
            child: Opacity(
              opacity: canGlobal ? 1.0 : 0.45,
              child: _SenderOption(
                label: 'GLOBAL',
                sub: canGlobal
                    ? (_loadingSenders ? 'Loading...' : '${_globalSenders.length} sender aktif')
                    : 'Role tidak cukup',
                icon: Icons.public_rounded,
                active: _senderType == 'global',
                color: AppColors.violetBright,
              ),
            ),
          )),
        ]),
      ]),
    );
  }

  // ── List Nomor Sender Global ──────────────────────────────────
  Widget _buildGlobalSenderList() => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      gradient: LinearGradient(colors: [
        AppColors.violet.withOpacity(0.08),
        AppColors.bg,
      ]),
      border: Border.all(color: AppColors.violet.withOpacity(0.3)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(Icons.list_alt_rounded, color: AppColors.violetBright, size: 14),
        const SizedBox(width: 7),
        const Text('DAFTAR SENDER GLOBAL', style: TextStyle(
          fontFamily: 'Orbitron', fontSize: 8,
          color: AppColors.violetBright, letterSpacing: 1.8)),
        const Spacer(),
        GestureDetector(
          onTap: _loadGlobalSenders,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.violet.withOpacity(0.4)),
              color: AppColors.violet.withOpacity(0.08),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.refresh_rounded, color: AppColors.violetBright, size: 12),
              const SizedBox(width: 4),
              const Text('Refresh', style: TextStyle(
                fontFamily: 'ShareTechMono', fontSize: 9, color: AppColors.violetBright)),
            ]),
          ),
        ),
      ]),
      const SizedBox(height: 12),
      if (_loadingSenders)
        const Center(child: SizedBox(
          width: 20, height: 20,
          child: CircularProgressIndicator(color: AppColors.violetBright, strokeWidth: 2),
        ))
      else if (_globalSenders.isEmpty)
        Center(child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text('Tidak ada sender global aktif', style: TextStyle(
            fontFamily: 'ShareTechMono', fontSize: 11,
            color: AppColors.textMuted.withOpacity(0.6))),
        ))
      else
        _buildSenderListCompact(),
    ]),
  );

  Widget _buildSenderListCompact() {
    final first = _globalSenders[0];
    final more  = _globalSenders.length - 1;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Nomor pertama
      Row(children: [
        Container(width: 7, height: 7,
          decoration: BoxDecoration(
            shape: BoxShape.circle, color: AppColors.success,
            boxShadow: [BoxShadow(color: AppColors.success.withOpacity(0.8), blurRadius: 5)],
          )),
        const SizedBox(width: 10),
        Text(first, style: const TextStyle(
          fontFamily: 'ShareTechMono', fontSize: 13,
          color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
      ]),
      // Teks lainnya
      if (more > 0) ...[
        const SizedBox(height: 6),
        GestureDetector(
          onTap: _showAllSenders,
          child: Row(children: [
            const SizedBox(width: 17),
            Text('+ $more lainnya', style: const TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 11,
              color: AppColors.violetBright,
              decoration: TextDecoration.underline,
              decorationColor: AppColors.violetBright,
            )),
          ]),
        ),
      ],
    ]);
  }

  void _showAllSenders() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        decoration: const BoxDecoration(
          color: Color(0xFF0C0F1E),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: AppColors.borderGlow)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 36, height: 4,
            decoration: BoxDecoration(
              color: AppColors.border,
              borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          Row(children: [
            Icon(Icons.list_alt_rounded, color: AppColors.violetBright, size: 16),
            const SizedBox(width: 8),
            const Text('SEMUA SENDER GLOBAL', style: TextStyle(
              fontFamily: 'Orbitron', fontSize: 10,
              color: AppColors.violetBright, letterSpacing: 2)),
            const Spacer(),
            Text('${_globalSenders.length} aktif', style: const TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 10, color: AppColors.textMuted)),
          ]),
          const SizedBox(height: 8),
          ..._globalSenders.asMap().entries.map((e) => Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: AppColors.surface.withOpacity(0.5),
              border: Border.all(color: AppColors.violet.withOpacity(0.2)),
            ),
            child: Row(children: [
              Container(width: 7, height: 7,
                decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.success,
                  boxShadow: [BoxShadow(color: AppColors.success.withOpacity(0.7), blurRadius: 5)])),
              const SizedBox(width: 10),
              Expanded(child: Text(e.value, style: const TextStyle(
                fontFamily: 'ShareTechMono', fontSize: 12, color: AppColors.textSub))),
              Text('#${e.key + 1}', style: const TextStyle(
                fontFamily: 'Orbitron', fontSize: 8, color: AppColors.textMuted)),
            ]),
          )),
        ]),
      ),
    );
  }

  Widget _buildSendButton() => AnimatedBuilder(
    animation: _btnCtrl,
    builder: (_, __) => GestureDetector(
      onTap: _isSending ? null : _sendBug,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity, height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: _isSending
              ? const LinearGradient(colors: [AppColors.border, AppColors.surfaceAlt])
              : const LinearGradient(
                  colors: [AppColors.danger, Color(0xFFD32F2F), Color(0xFFB71C1C)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
          boxShadow: _isSending ? [] : [
            BoxShadow(
              color: AppColors.danger.withOpacity(0.5 * _btnGlow.value),
              blurRadius: 30, offset: const Offset(0, 8)),
            BoxShadow(
              color: AppColors.danger.withOpacity(0.2 * _btnGlow.value),
              blurRadius: 60, offset: const Offset(0, 4)),
          ],
          border: Border.all(
            color: _isSending ? AppColors.border : AppColors.danger.withOpacity(0.6), width: 1),
        ),
        child: _isSending
            ? const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                SizedBox(width: 20, height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation(Colors.white))),
                SizedBox(width: 12),
                Text('MENGIRIM BUG...', style: TextStyle(
                  fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.w800,
                  color: Colors.white, letterSpacing: 1.5)),
              ])
            : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22),
                SizedBox(width: 10),
                Text('KIRIM BUG SEKARANG', style: TextStyle(
                  fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.w900,
                  color: Colors.white, letterSpacing: 1.5)),
              ]),
      ),
    ),
  );

  Widget _buildResultBanner() {
    final parts = _responseMsg!.split('|');
    final type  = parts[0];
    final msg   = parts.length > 1 ? parts[1] : '';
    final color = type == 'success' ? AppColors.success
        : type == 'warning' ? AppColors.warning : AppColors.danger;
    final icon  = type == 'success' ? Icons.check_circle_rounded
        : type == 'warning' ? Icons.warning_rounded : Icons.error_rounded;
    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(colors: [
              color.withOpacity(0.12), color.withOpacity(0.03),
            ]),
            border: Border.all(color: color.withOpacity(0.4)),
            boxShadow: [BoxShadow(color: color.withOpacity(0.12), blurRadius: 20)]),
          child: Row(children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 12),
            Expanded(child: Text(msg, style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 12,
              color: color, fontWeight: FontWeight.w600))),
          ]),
        ),
      ),
    );
  }
}

// ── Reusable Widgets ──────────────────────────────────────────
class _FieldLabel extends StatelessWidget {
  final IconData icon;
  final String   label;
  final Color    color;
  const _FieldLabel({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, color: color, size: 13),
    const SizedBox(width: 6),
    Text(label, style: TextStyle(
      fontFamily: 'Orbitron', fontSize: 9, color: color.withOpacity(0.8), letterSpacing: 2)),
  ]);
}

class _TabBtn extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool   active;
  final VoidCallback onTap;
  const _TabBtn({required this.label, required this.active, required this.onTap, this.icon});

  @override
  Widget build(BuildContext context) => GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      height: 48, alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: active ? const LinearGradient(
          colors: [Color(0xFF00B4CC), Color(0xFF00E5FF), Color(0xFF006680)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ) : null,
        boxShadow: active ? [
          BoxShadow(color: AppColors.cyan.withOpacity(0.45), blurRadius: 16),
        ] : [],
        border: active ? Border.all(color: AppColors.cyan.withOpacity(0.5), width: 1) : null,
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[
          Icon(icon, size: 16,
            color: active ? AppColors.bg : AppColors.textSub),
          const SizedBox(width: 7),
        ],
        Text(label, style: TextStyle(
          fontFamily: 'Orbitron', fontSize: 10, fontWeight: FontWeight.w800,
          letterSpacing: 1.2,
          color: active ? AppColors.bg : AppColors.textSub)),
      ]),
    ),
  );
}

class _SenderOption extends StatelessWidget {
  final String label, sub;
  final IconData icon;
  final bool   active;
  final Color  color;
  const _SenderOption({
    required this.label,
    required this.sub,
    required this.icon,
    required this.active,
    required this.color,
  });

  @override
  Widget build(BuildContext context) => AnimatedContainer(
    duration: const Duration(milliseconds: 200),
    padding: const EdgeInsets.symmetric(vertical: 14),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(14),
      gradient: active ? LinearGradient(colors: [
        color.withOpacity(0.18), color.withOpacity(0.06),
      ]) : null,
      color: active ? null : const Color(0xFF0A0D18),
      border: Border.all(color: active ? color : AppColors.border, width: active ? 1.8 : 1),
      boxShadow: active ? [BoxShadow(color: color.withOpacity(0.28), blurRadius: 16)] : []),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: active ? color : AppColors.textMuted, size: 22),
      const SizedBox(height: 6),
      Text(label, style: TextStyle(fontFamily: 'Orbitron', fontSize: 9,
        color: active ? color : AppColors.textSub, fontWeight: FontWeight.w800, letterSpacing: 1)),
      const SizedBox(height: 2),
      Text(sub, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 9,
        color: active ? color.withOpacity(0.7) : AppColors.textMuted), textAlign: TextAlign.center),
    ]),
  );
}

class _ActionBtn extends StatelessWidget {
  final String         label;
  final List<Color>    colors;
  final VoidCallback   onTap;
  final bool           fullWidth;
  const _ActionBtn({required this.label, required this.colors, required this.onTap, this.fullWidth = false});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: fullWidth ? double.infinity : null,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        gradient: LinearGradient(colors: colors),
        boxShadow: [BoxShadow(color: colors[0].withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 5))]),
      child: Text(label, textAlign: TextAlign.center, style: const TextStyle(
        fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.w800,
        color: Colors.white, letterSpacing: 1.5)),
    ),
  );
}

// ── Aurora Background ─────────────────────────────────────────
class _HomeAuroraPainter extends CustomPainter {
  final double t;
  _HomeAuroraPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final a  = t * 2 * math.pi;
    final cx = size.width / 2;

    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..shader = const LinearGradient(
        colors: [Color(0xFF03040A), Color(0xFF060811), Color(0xFF080C16)],
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    void _blob(double ox, double oy, double r, Color c) {
      canvas.drawCircle(Offset(ox, oy), r,
        Paint()..shader = RadialGradient(colors: [c, Colors.transparent])
            .createShader(Rect.fromCircle(center: Offset(ox, oy), radius: r)));
    }

    _blob(cx + math.cos(a) * 65, size.height * 0.25 + math.sin(a) * 25, 210,
        AppColors.danger.withOpacity(0.06));
    _blob(cx - math.cos(a * 0.8) * 50, size.height * 0.72, 180,
        AppColors.violet.withOpacity(0.05));

    final dot = Paint()..color = AppColors.cyan.withOpacity(0.015);
    const s = 32.0;
    for (double x = 0; x < size.width; x += s)
      for (double y = 0; y < size.height; y += s)
        canvas.drawCircle(Offset(x, y), 1, dot);
  }

  @override
  bool shouldRepaint(_HomeAuroraPainter o) => o.t != t;
}
