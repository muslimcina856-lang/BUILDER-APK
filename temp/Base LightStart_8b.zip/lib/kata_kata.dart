import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'main.dart';

// ─── Palette ──────────────────────────────────────────────────────────────────
// _C removed - using AppColors

// ─── Data Model ──────────────────────────────────────────────────────────────
class KataKataData {
  final String teks;
  final String penulis;
  final String kategori;

  const KataKataData({
    required this.teks,
    required this.penulis,
    required this.kategori,
  });
}

// ─── Kata-kata Percintaan ─────────────────────────────────────────────────────
const List<KataKataData> _kataPercintaan = [
  KataKataData(
    teks:     'Cinta bukan tentang seberapa lama kamu bersama seseorang, tapi tentang seberapa kuat kamu memegang mereka ketika semua orang lain mencoba memisahkan.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Jatuh cinta adalah satu hal terindah yang bisa kamu lakukan, dan juga yang paling menakutkan sekaligus.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Kamu tidak mencintai seseorang karena mereka sempurna, kamu mencintai mereka meskipun mereka tidak sempurna.',
    penulis:  '— Sam Keen',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Cinta sejati tidak membuatmu menjadi orang lain, ia membuatmu menjadi dirimu yang sebenarnya.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Di antara jutaan bintang di langit, hatiku memilih kamu. Bukan karena kebetulan, tapi karena kamulah cahaya yang selalu aku cari.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Cinta adalah ketika kebahagiaan orang lain menjadi lebih penting dari kebahagiaanmu sendiri.',
    penulis:  '— H. Jackson Brown Jr.',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Setiap kali aku melihatmu, aku jatuh cinta lagi dari awal. Dan rasanya selalu lebih indah dari sebelumnya.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Kamu adalah alasan mengapa aku percaya bahwa cinta yang sesungguhnya itu nyata dan bukan sekedar dongeng.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Bukan jarak yang memisahkan kita, tapi hati yang tak mau bersatu. Dan aku bersyukur hati kita selalu mencari satu sama lain.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Mencintaimu adalah hal terbaik yang pernah aku lakukan. Bukan karena kamu sempurna, tapi karena bersamamu aku merasa utuh.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Rindu itu aneh. Bukan karena jauh, tapi karena hati sudah terlanjur dekat.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Cinta yang tulus tidak pernah menuntut, ia hanya memberi tanpa mengharap kembali.',
    penulis:  '— Rabindranath Tagore',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Ketika kamu mencintai seseorang, kamu melihat kebaikan dalam diri mereka yang bahkan mereka sendiri belum melihatnya.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Tempat ternyaman di dunia adalah pelukan orang yang kamu cintai dan mencintaimu.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
  KataKataData(
    teks:     'Satu senyummu cukup untuk membuat hariku menjadi sempurna, betapa ajaibnya kamu bagiku.',
    penulis:  '— Anonim',
    kategori: 'percintaan',
  ),
];

// ─── Kata-kata Persahabatan ───────────────────────────────────────────────────
const List<KataKataData> _kataSahabat = [
  KataKataData(
    teks:     'Sahabat sejati adalah mereka yang datang saat semua orang pergi. Yang tetap berdiri di sampingmu ketika dunia membelakangimu.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Persahabatan adalah satu jiwa dalam dua tubuh yang berbeda.',
    penulis:  '— Aristoteles',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Teman yang baik adalah harta yang lebih berharga dari emas. Mereka ada bukan karena butuh, tapi karena memilih.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Jangan hitung berapa lama kamu kenal seseorang, tapi hitunglah berapa banyak momen yang kamu lalui bersama dengan tulus.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Sahabat terbaik adalah yang bisa membuat kamu tertawa saat kamu hampir lupa cara tersenyum.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Dalam hidup, bukan seberapa banyak teman yang kamu punya. Tapi seberapa banyak teman yang tetap ada saat kamu butuh.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Persahabatan sejati tidak terputus oleh jarak, tidak memudar karena waktu, dan tidak hancur oleh perbedaan.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Kamu tahu seseorang adalah sahabat sejatimu ketika keheningan di antara kalian pun terasa nyaman.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Teman yang jujur lebih berharga dari seribu teman yang hanya memuji. Kejujuran adalah fondasi persahabatan yang sejati.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Kita tidak memilih sahabat kita secara kebetulan. Mereka adalah cerminan dari siapa kita dan siapa yang kita inginkan.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Bersama sahabat, bahkan momen paling biasa bisa menjadi kenangan yang tak terlupakan.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Sahabat adalah orang yang mengetahui lagumu dan bisa menyanyikannya kembali untukmu saat kamu lupa liriknya.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
  KataKataData(
    teks:     'Satu sahabat setia lebih baik dari sepuluh orang yang hanya ada di saat senang.',
    penulis:  '— Anonim',
    kategori: 'persahabatan',
  ),
];

// ─── Kata-kata Motivasi ───────────────────────────────────────────────────────
const List<KataKataData> _kataMotivasi = [
  KataKataData(
    teks:     'Jangan takut untuk bermimpi besar. Mimpi adalah awal dari setiap pencapaian luar biasa dalam hidupmu.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Kegagalan bukan akhir dari segalanya. Itu hanyalah tikungan di jalan menuju kesuksesanmu.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Satu-satunya cara untuk melakukan pekerjaan yang luar biasa adalah dengan mencintai apa yang kamu lakukan.',
    penulis:  '— Steve Jobs',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Hari ini keras, esok lebih keras, tapi lusa akan menjadi indah. Banyak orang menyerah di esok hari dan tidak pernah melihat lusa.',
    penulis:  '— Jack Ma',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Perjalanan seribu mil dimulai dengan satu langkah. Jangan menunggu sempurna, mulailah sekarang.',
    penulis:  '— Lao Tzu',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Orang sukses bukan yang tidak pernah gagal, tapi yang tidak pernah berhenti mencoba meski berkali-kali jatuh.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Masa depanmu dimulai dari keputusan yang kamu buat hari ini. Buat keputusan yang akan kamu banggakan.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Jangan bandingkan perjalananmu dengan orang lain. Setiap orang memiliki waktunya masing-masing untuk bersinar.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Kesuksesan adalah milik mereka yang terlalu sibuk bekerja keras untuk mengeluh tentang kegagalan.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Percayalah pada prosesmu. Setiap titik keringat dan air mata adalah investasi untuk versi terbaik dirimu.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Kamu lebih kuat dari yang kamu pikirkan, lebih berani dari yang kamu rasakan, dan lebih cerdas dari yang kamu bayangkan.',
    penulis:  '— A.A. Milne',
    kategori: 'motivasi',
  ),
  KataKataData(
    teks:     'Berhentilah berharap dan mulailah bekerja. Mimpi tidak akan menjadi kenyataan tanpa tindakanmu.',
    penulis:  '— Anonim',
    kategori: 'motivasi',
  ),
];

// ─── Kata-kata Kehidupan ──────────────────────────────────────────────────────
const List<KataKataData> _kataKehidupan = [
  KataKataData(
    teks:     'Hiduplah seakan-akan hari ini adalah hari terakhirmu. Belajarlah seakan-akan kamu akan hidup selamanya.',
    penulis:  '— Mahatma Gandhi',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Hidup itu seperti bersepeda. Untuk menjaga keseimbangan, kamu harus terus bergerak maju.',
    penulis:  '— Albert Einstein',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Bukan tentang seberapa banyak yang kamu miliki, tapi seberapa banyak kamu bersyukur atas apa yang ada.',
    penulis:  '— Anonim',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Hal terpenting dalam hidup bukanlah menemukan dirimu sendiri, tapi menciptakan dirimu sendiri.',
    penulis:  '— George Bernard Shaw',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Setiap hari adalah kesempatan baru untuk menjadi lebih baik dari hari sebelumnya. Gunakan dengan bijak.',
    penulis:  '— Anonim',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Jangan pernah menyesal atas pilihanmu. Pilihlah, lakukan yang terbaik, dan jadikan pelajaran untuk ke depan.',
    penulis:  '— Anonim',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Hidup yang tidak dievaluasi tidak layak untuk dijalani. Tapi hidup yang terus dievaluasi tanpa tindakan juga sia-sia.',
    penulis:  '— Socrates (adaptasi)',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Kebahagiaan sejati bukan ditemukan di luar sana. Ia tumbuh dari dalam dirimu sendiri.',
    penulis:  '— Anonim',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Hidup terlalu singkat untuk dihabiskan dengan marah, menyesal, dan membenci. Pilih damai, pilih bahagia.',
    penulis:  '— Anonim',
    kategori: 'kehidupan',
  ),
  KataKataData(
    teks:     'Yang membuat hidup berarti bukan seberapa lama kamu hidup, tapi seberapa bermakna kamu hidup untuk orang lain.',
    penulis:  '— Anonim',
    kategori: 'kehidupan',
  ),
];

// ─── Page ─────────────────────────────────────────────────────────────────────
class KataKataPage extends StatefulWidget {
  const KataKataPage({super.key});

  @override
  State<KataKataPage> createState() => _KataKataPageState();
}

class _KataKataPageState extends State<KataKataPage>
    with SingleTickerProviderStateMixin {
  int _tabIndex = 0;
  late AnimationController _bgCtrl;

  final _tabLabels = ['Cinta', 'Sahabat', 'Motivasi', 'Kehidupan'];
  final _tabColors = [const Color(0xFFEC4899), AppColors.cyanDim, AppColors.warning, AppColors.violetBright];
  final _tabIcons  = [
    Icons.favorite_rounded,
    Icons.people_rounded,
    Icons.rocket_launch_rounded,
    Icons.self_improvement_rounded,
  ];

  List<KataKataData> get _currentList {
    switch (_tabIndex) {
      case 0: return _kataPercintaan;
      case 1: return _kataSahabat;
      case 2: return _kataMotivasi;
      case 3: return _kataKehidupan;
      default: return _kataPercintaan;
    }
  }

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 16))
      ..repeat();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    super.dispose();
  }

  void _copyKata(KataKataData k) {
    Clipboard.setData(ClipboardData(text: '"${k.teks}"\n${k.penulis}'));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Row(children: [
        Icon(Icons.copy_rounded, color: Colors.white, size: 16),
        SizedBox(width: 8),
        Text('Kata-kata disalin!',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
      ]),
      backgroundColor: AppColors.cyanDim,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      duration: const Duration(seconds: 2),
    ));
  }

  void _showRandom() {
    final r = Random();
    final k = _currentList[r.nextInt(_currentList.length)];
    final accent = _tabColors[_tabIndex];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _RandomKataSheet(
          kata: k, color: accent, onCopy: () => _copyKata(k)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accent = _tabColors[_tabIndex];

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(accent),
                _buildTabs(),
                Expanded(child: _buildList(accent)),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showRandom,
        backgroundColor: accent,
        icon: const Icon(Icons.shuffle_rounded, color: Colors.white),
        label: const Text('Kata Acak',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      ),
    );
  }

  Widget _buildHeader(Color accent) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.border),
          boxShadow: [
            BoxShadow(color: accent.withOpacity(0.08),
                blurRadius: 20, offset: const Offset(0, 6)),
          ],
        ),
        child: Row(children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppColors.border),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: AppColors.textPrimary, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [accent.withOpacity(0.8), accent],
                  begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [BoxShadow(color: accent.withOpacity(0.3), blurRadius: 10)],
            ),
            child: const Icon(Icons.format_quote_rounded,
                color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ShaderMask(
              shaderCallback: (b) => AppColors.glowGrad.createShader(b),
              child: const Text('Kata-Kata',
                  style: TextStyle(color: Colors.white, fontSize: 17,
                      fontWeight: FontWeight.w800)),
            ),
            const Text('Kata Bijak & Inspiratif',
                style: TextStyle(color: AppColors.textSub, fontSize: 11)),
          ]),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: accent.withOpacity(0.25)),
            ),
            child: Text('${_currentList.length} kata',
                style: TextStyle(color: accent, fontSize: 10,
                    fontWeight: FontWeight.w700)),
          ),
        ]),
      ),
    );
  }

  Widget _buildTabs() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(children: List.generate(_tabLabels.length, (i) {
        final sel = _tabIndex == i;
        final c   = _tabColors[i];
        return GestureDetector(
          onTap: () => setState(() => _tabIndex = i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            margin: EdgeInsets.only(right: i < _tabLabels.length - 1 ? 8 : 0),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: sel ? c.withOpacity(0.15) : AppColors.card,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: sel ? c.withOpacity(0.5) : AppColors.border,
                width: sel ? 1.5 : 1.0,
              ),
            ),
            child: Row(children: [
              Icon(_tabIcons[i], color: sel ? c : AppColors.textSub, size: 16),
              const SizedBox(width: 6),
              Text(_tabLabels[i],
                  style: TextStyle(
                    color: sel ? c : AppColors.textSub,
                    fontSize: 12,
                    fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                  )),
            ]),
          ),
        );
      })),
    );
  }

  Widget _buildList(Color accent) {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
      itemCount: _currentList.length,
      itemBuilder: (_, i) {
        final k = _currentList[i];
        return _KataCard(
          kata: k, index: i, accent: accent,
          onCopy: () => _copyKata(k),
        );
      },
    );
  }
}

// ─── Kata Card ────────────────────────────────────────────────────────────────
class _KataCard extends StatefulWidget {
  final KataKataData kata;
  final int index;
  final Color accent;
  final VoidCallback onCopy;

  const _KataCard({required this.kata, required this.index,
      required this.accent, required this.onCopy});

  @override
  State<_KataCard> createState() => _KataCardState();
}

class _KataCardState extends State<_KataCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + (widget.index * 60).clamp(0, 500)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 20 * (1 - v)), child: ch),
      ),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) => setState(() => _pressed = false),
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: _pressed
                ? widget.accent.withOpacity(0.08)
                : AppColors.card,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: _pressed
                  ? widget.accent.withOpacity(0.4)
                  : AppColors.border,
              width: _pressed ? 1.5 : 1.0,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.accent.withOpacity(_pressed ? 0.12 : 0.04),
                blurRadius: _pressed ? 16 : 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.format_quote_rounded,
                  color: widget.accent.withOpacity(0.7), size: 28),
              const Spacer(),
              GestureDetector(
                onTap: widget.onCopy,
                child: Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Icon(Icons.copy_rounded,
                      color: AppColors.textSub, size: 15),
                ),
              ),
            ]),
            const SizedBox(height: 10),
            Text(widget.kata.teks,
                style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  height: 1.6,
                  fontWeight: FontWeight.w500,
                )),
            const SizedBox(height: 12),
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  widget.accent.withOpacity(0.3),
                  Colors.transparent,
                ]),
              ),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Container(
                width: 4, height: 4,
                decoration: BoxDecoration(
                  color: widget.accent,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(widget.kata.penulis,
                  style: TextStyle(
                    color: widget.accent.withOpacity(0.8),
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.italic,
                  )),
            ]),
          ]),
        ),
      ),
    );
  }
}

// ─── Random Kata Sheet ────────────────────────────────────────────────────────
class _RandomKataSheet extends StatelessWidget {
  final KataKataData kata;
  final Color color;
  final VoidCallback onCopy;

  const _RandomKataSheet({required this.kata, required this.color,
      required this.onCopy});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 32),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 30)],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 36, height: 4,
            decoration: BoxDecoration(color: AppColors.border,
                borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 20),
        Icon(Icons.format_quote_rounded, color: color, size: 36),
        const SizedBox(height: 16),
        Text(kata.teks,
            style: const TextStyle(
              color: AppColors.textPrimary, fontSize: 15,
              height: 1.6, fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center),
        const SizedBox(height: 16),
        Container(height: 1, decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              Colors.transparent, color.withOpacity(0.4), Colors.transparent]))),
        const SizedBox(height: 12),
        Text(kata.penulis,
            style: TextStyle(color: color, fontSize: 13,
                fontWeight: FontWeight.w700, fontStyle: FontStyle.italic)),
        const SizedBox(height: 20),
        GestureDetector(
          onTap: () { Navigator.pop(context); onCopy(); },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.copy_rounded, color: color, size: 16),
              const SizedBox(width: 8),
              Text('Salin Kata-Kata',
                  style: TextStyle(color: color, fontWeight: FontWeight.w700,
                      fontSize: 14)),
            ]),
          ),
        ),
      ]),
    );
  }
}

// ─── Animated BG ─────────────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: controller,
        builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
      );
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = AppColors.border.withOpacity(0.26)
      ..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        AppColors.borderGlow.withOpacity(0.1 + sin(t * pi * 2) * 0.03),
        Colors.transparent,
      ], radius: 0.9).createShader(
          Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}
