import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'main.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;
  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _auroraCtrl;
  late AnimationController _logoCtrl;
  late AnimationController _textCtrl;
  late AnimationController _barCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _scanCtrl;
  late AnimationController _shimmerCtrl;

  late Animation<double> _logoScale;
  late Animation<double> _logoFade;
  late Animation<double> _logoGlow;
  late Animation<double> _textFade;
  late Animation<Offset>  _textSlide;
  late Animation<double>  _barProgress;
  late Animation<double>  _scanLine;
  late Animation<double>  _bottomFade;
  late Animation<double>  _shimmer;

  VideoPlayerController? _vCtrl;
  bool _videoReady = false;
  bool _navigated  = false;

  // ── Video splash.mp4 = 19.35 detik
  // ── Total splash duration = ~19 detik (sync dengan video)
  static const int _splashMs = 18500; // navigate after 18.5s
  static const int _barDurationMs = 16000; // bar fills in 16s

  @override
  void initState() {
    super.initState();

    _auroraCtrl   = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
    _logoCtrl     = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _textCtrl     = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _barCtrl      = AnimationController(vsync: this, duration: const Duration(milliseconds: _barDurationMs));
    _particleCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 9))..repeat();
    _glowCtrl     = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))..repeat(reverse: true);
    _scanCtrl     = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
    _shimmerCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))..repeat();

    _logoScale   = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeOutBack));
    _logoFade    = CurvedAnimation(parent: _logoCtrl, curve: Curves.easeOut);
    _logoGlow    = Tween<double>(begin: 0.15, end: 1.0)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
    _textFade    = CurvedAnimation(parent: _textCtrl, curve: Curves.easeOut);
    _textSlide   = Tween<Offset>(begin: const Offset(0, 0.10), end: Offset.zero)
        .animate(CurvedAnimation(parent: _textCtrl, curve: Curves.easeOutCubic));
    _barProgress = _barCtrl; // langsung tanpa curve, ikut posisi video 1:1
    _scanLine    = Tween<double>(begin: 0.0, end: 1.0).animate(_scanCtrl);
    _bottomFade  = CurvedAnimation(parent: _textCtrl, curve: Curves.easeOut);
    _shimmer     = Tween<double>(begin: -2.0, end: 3.0)
        .animate(CurvedAnimation(parent: _shimmerCtrl, curve: Curves.linear));

    _initVideo();
    _startSequence();
  }

  void _startSequence() async {
    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted) return;
    _logoCtrl.forward();

    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    _textCtrl.forward();

    // Fallback: kalau video gagal load sama sekali, navigate setelah _splashMs
    await Future.delayed(const Duration(milliseconds: _splashMs));
    if (mounted && !_videoReady) _navigate();
  }

  void _initVideo() {
    try {
      _vCtrl = VideoPlayerController.asset('assets/videos/splash.mp4')
        ..initialize().then((_) {
          if (!mounted) return;
          setState(() => _videoReady = true);
          _vCtrl!.play();
          _vCtrl!.setLooping(false);
          _vCtrl!.addListener(_onVideoUpdate);
        });
    } catch (_) {}
  }

  void _onVideoUpdate() {
    if (!mounted || _vCtrl == null) return;
    final v = _vCtrl!.value;
    if (!v.isInitialized) return;
    // Update bar progress ikut posisi video
    final total = v.duration.inMilliseconds;
    final pos   = v.position.inMilliseconds;
    if (total > 0) {
      final pct = (pos / total).clamp(0.0, 1.0);
      _barCtrl.value = pct; // set langsung, bukan forward()
    }
    // Navigate saat video selesai
    if (!v.isPlaying && pos >= v.duration.inMilliseconds - 300) {
      _navigate();
    }
  }

  void _navigate() {
    if (_navigated || !mounted) return;
    _navigated = true;
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 800),
      pageBuilder: (_, __, ___) => DashboardPage(
        username:    widget.username,
        password:    widget.password,
        role:        widget.role,
        expiredDate: widget.expiredDate,
        sessionKey:  widget.sessionKey,
        listBug:     widget.listBug,
        listDoos:    widget.listDoos,
        news:        widget.news,
      ),
      transitionsBuilder: (_, a, __, child) => FadeTransition(
        opacity: CurvedAnimation(parent: a, curve: Curves.easeOut),
        child: child,
      ),
    ));
  }

  @override
  void dispose() {
    _auroraCtrl.dispose();
    _logoCtrl.dispose();
    _textCtrl.dispose();
    _barCtrl.dispose();
    _particleCtrl.dispose();
    _glowCtrl.dispose();
    _scanCtrl.dispose();
    _shimmerCtrl.dispose();
    _vCtrl?.removeListener(_onVideoUpdate);
    _vCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: AppColors.bgDeep,
      body: Stack(children: [
          // ── VIDEO BACKGROUND ────────────────────────────────────────
          if (_videoReady && _vCtrl != null)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width:  _vCtrl!.value.size.width,
                  height: _vCtrl!.value.size.height,
                  child:  VideoPlayer(_vCtrl!),
                ),
              ),
            )
          else
            AnimatedBuilder(
              animation: _auroraCtrl,
              builder: (_, __) => CustomPaint(
                painter: _SplashAuroraPainter(_auroraCtrl.value),
                child:   const SizedBox.expand(),
              ),
            ),

          // ── OVERLAY GRADIENT (jika video aktif) ──────────────────────
          if (_videoReady)
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end:   Alignment.bottomCenter,
                    colors: [
                      AppColors.bgDeep.withOpacity(0.35),
                      AppColors.bgDeep.withOpacity(0.55),
                      AppColors.bgDeep.withOpacity(0.80),
                    ],
                  ),
                ),
              ),
            ),

          // ── PARTICLES ────────────────────────────────────────────────
          AnimatedBuilder(
            animation: _particleCtrl,
            builder: (_, __) => CustomPaint(
              painter: _SplashParticlePainter(_particleCtrl.value),
              child:   const SizedBox.expand(),
            ),
          ),

          // ── SCAN LINE ────────────────────────────────────────────────
          AnimatedBuilder(
            animation: _scanLine,
            builder: (_, __) => Positioned(
              top:   _scanLine.value * size.height,
              left:  0, right: 0,
              child: Container(
                height: 2,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    Colors.transparent,
                    AppColors.cyan.withOpacity(0.08),
                    AppColors.cyan.withOpacity(0.28),
                    AppColors.cyan.withOpacity(0.08),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
          ),

          // ── CENTER CONTENT ───────────────────────────────────────────
          Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              // ── LOGO ─────────────────────────────────────────────────
              ScaleTransition(
                scale: _logoScale,
                child: FadeTransition(
                  opacity: _logoFade,
                  child: AnimatedBuilder(
                    animation: _glowCtrl,
                    builder: (_, child) => Container(
                      width: 130, height: 130,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            const Color(0xFF182040),
                            const Color(0xFF0C1020),
                          ],
                          begin: Alignment.topLeft,
                          end:   Alignment.bottomRight,
                        ),
                        border: Border.all(
                          color: AppColors.cyan.withOpacity(0.25 + 0.40 * _logoGlow.value),
                          width: 2.0,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color:      AppColors.cyan.withOpacity(0.45 * _logoGlow.value),
                            blurRadius: 60, spreadRadius: 8,
                          ),
                          BoxShadow(
                            color:      AppColors.violet.withOpacity(0.25 * _logoGlow.value),
                            blurRadius: 80, spreadRadius: 12,
                          ),
                          BoxShadow(
                            color:      Colors.black.withOpacity(0.6),
                            blurRadius: 24, spreadRadius: 0,
                          ),
                        ],
                      ),
                      child: child,
                    ),
                    child: ClipOval(
                      child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 36),

              // ── TITLE ────────────────────────────────────────────────
              FadeTransition(
                opacity: _textFade,
                child: SlideTransition(
                  position: _textSlide,
                  child: Column(children: [
                    // Shimmer title
                    AnimatedBuilder(
                      animation: _shimmerCtrl,
                      builder: (_, child) {
                        return ShaderMask(
                          shaderCallback: (b) => LinearGradient(
                            colors: const [
                              Color(0xFF00B4CC),
                              Color(0xFFFFFFFF),
                              Color(0xFFBB86FC),
                              Color(0xFF00E5FF),
                            ],
                            stops: [0.0, _shimmer.value - 0.5, _shimmer.value, 1.0]
                                .map((s) => s.clamp(0.0, 1.0)).toList(),
                          ).createShader(b),
                          child: child!,
                        );
                      },
                      child: const Text('𝙀𝙧𝙚𝙘𝙩𝙪𝙨𝘾𝙧𝙖𝙨𝙝𝙚𝙧', style: TextStyle(
                        fontFamily:    'Orbitron',
                        fontSize:      40,
                        fontWeight:    FontWeight.w900,
                        color:         Colors.white,
                        letterSpacing: 8,
                      )),
                    ),
                    const SizedBox(height: 8),
                    // Version badge
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.violet.withOpacity(0.5)),
                        color: AppColors.violet.withOpacity(0.08),
                      ),
                      child: const Text('PROJECT  V10', style: TextStyle(
                        fontFamily: 'Orbitron', fontSize: 9,
                        color: AppColors.violetBright, letterSpacing: 4,
                      )),
                    ),
                    const SizedBox(height: 14),
                    // Neon divider
                    Container(
                      height: 1.5, width: 200,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(colors: [
                          Colors.transparent,
                          AppColors.cyan,
                          AppColors.violetBright,
                          Colors.transparent,
                        ]),
                      ),
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 50),

              // ── PROGRESS BAR ─────────────────────────────────────────
              FadeTransition(
                opacity: _textFade,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 52),
                  child: AnimatedBuilder(
                    animation: _barCtrl,
                    builder: (_, __) {
                      final pct = _barProgress.value;
                      final barW = size.width - 104;
                      return Column(children: [
                        // Labels
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              pct < 0.25
                                  ? 'BOOT SEQUENCE...'
                                  : pct < 0.50
                                      ? 'LOADING CORE...'
                                      : pct < 0.75
                                          ? 'LOADING MODULES...'
                                          : 'ALMOST READY...',
                              style: const TextStyle(
                                fontFamily: 'Orbitron', fontSize: 7,
                                color: AppColors.textSub, letterSpacing: 1.5,
                              ),
                            ),
                            Text(
                              '${(pct * 100).round()}%',
                              style: const TextStyle(
                                fontFamily: 'Orbitron', fontSize: 10,
                                color: AppColors.cyan, fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        // Track
                        Stack(clipBehavior: Clip.none, children: [
                          // BG track
                          Container(
                            height: 5,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: AppColors.border,
                            ),
                          ),
                          // Fill
                          Container(
                            height: 5,
                            width: barW * pct,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              gradient: const LinearGradient(
                                colors: [AppColors.cyan, AppColors.violet, AppColors.violetBright],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color:      AppColors.cyan.withOpacity(0.7),
                                  blurRadius: 12, spreadRadius: 0,
                                ),
                              ],
                            ),
                          ),
                          // Tip dot
                          if (pct > 0.01)
                            Positioned(
                              left: barW * pct - 6,
                              top: -3.5,
                              child: Container(
                                width: 12, height: 12,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color:      AppColors.cyan,
                                      blurRadius: 14, spreadRadius: 3,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                        ]),
                      ]);
                    },
                  ),
                ),
              ),
              const SizedBox(height: 28),

              // ── WELCOME BADGE ────────────────────────────────────────
              FadeTransition(
                opacity: _bottomFade,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: LinearGradient(colors: [
                      AppColors.surface.withOpacity(0.85),
                      AppColors.surfaceAlt.withOpacity(0.7),
                    ]),
                    border: Border.all(color: AppColors.cyan.withOpacity(0.25), width: 1.5),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.cyan.withOpacity(0.08),
                        blurRadius: 20,
                      ),
                    ],
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      width: 6, height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.success,
                        boxShadow: [BoxShadow(color: AppColors.success.withOpacity(0.8), blurRadius: 6)],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'WELCOME,  ${widget.username.toUpperCase()}',
                      style: const TextStyle(
                        fontFamily: 'ShareTechMono', fontSize: 12,
                        color: AppColors.textSub, letterSpacing: 2,
                      ),
                    ),
                  ]),
                ),
              ),
            ]),
          ),

          // ── SKIP HINT ────────────────────────────────────────────────
          Positioned(
            bottom: 40, left: 0, right: 0,
            child: FadeTransition(
              opacity: _textFade,
              child: GestureDetector(
                onTap: _navigate,
                behavior: HitTestBehavior.opaque,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 12),
                  child: Column(children: [
                    Container(
                      width: 32, height: 1,
                      color: AppColors.borderGlow,
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.cyan.withOpacity(0.25)),
                        color: AppColors.surface.withOpacity(0.4),
                      ),
                      child: const Text('TAP TO SKIP', textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Orbitron', fontSize: 7,
                          color: AppColors.textSub, letterSpacing: 4,
                        )),
                    ),
                  ]),
                ),
              ),
            ),
          ),

          // ── CORNER BRACKETS ──────────────────────────────────────────
          Positioned(top: 48, left: 20, child: _CornerBracket(flip: false)),
          Positioned(top: 48, right: 20, child: _CornerBracket(flip: true)),
          Positioned(bottom: 60, left: 20, child: _CornerBracket(flip: false, vertical: true)),
          Positioned(bottom: 60, right: 20, child: _CornerBracket(flip: true, vertical: true)),
        ]),
    );
  }
}

// ── Corner Bracket Widget ──────────────────────────────────────
class _CornerBracket extends StatelessWidget {
  final bool flip;
  final bool vertical;
  const _CornerBracket({required this.flip, this.vertical = false});

  @override
  Widget build(BuildContext context) {
    return Transform.flip(
      flipX: flip,
      flipY: vertical,
      child: SizedBox(width: 20, height: 20,
        child: CustomPaint(painter: _BracketPainter()),
      ),
    );
  }
}

class _BracketPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = AppColors.cyan.withOpacity(0.4)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.square;
    final path = Path()
      ..moveTo(0, size.height)
      ..lineTo(0, 0)
      ..lineTo(size.width, 0);
    canvas.drawPath(path, p);
  }
  @override bool shouldRepaint(_) => false;
}

// ── Aurora Background Painter ──────────────────────────────────
class _SplashAuroraPainter extends CustomPainter {
  final double t;
  _SplashAuroraPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final a  = t * 2 * math.pi;
    final cx = size.width / 2;
    final cy = size.height / 2;

    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..shader = const LinearGradient(
        colors: [Color(0xFF02030A), Color(0xFF050710), Color(0xFF060A14)],
        begin: Alignment.topCenter,
        end:   Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    void _blob(double ox, double oy, double r, Color c) {
      canvas.drawCircle(
        Offset(ox, oy), r,
        Paint()..shader = RadialGradient(colors: [c, Colors.transparent])
            .createShader(Rect.fromCircle(center: Offset(ox, oy), radius: r)),
      );
    }

    _blob(cx + math.cos(a) * 80,      cy * 0.50 + math.sin(a) * 40,       280, AppColors.violet.withOpacity(0.12));
    _blob(cx - math.cos(a * 0.7) * 60, cy * 0.48 + math.sin(a * 0.5) * 50, 220, AppColors.cyan.withOpacity(0.08));
    _blob(cx + math.cos(a * 0.4) * 45, cy * 1.42 + math.sin(a) * 30,       240, AppColors.violetBright.withOpacity(0.07));

    final dot = Paint()..color = AppColors.cyan.withOpacity(0.018);
    const s = 28.0;
    for (double x = 0; x < size.width; x += s)
      for (double y = 0; y < size.height; y += s)
        canvas.drawCircle(Offset(x, y), 1, dot);
  }

  @override
  bool shouldRepaint(_SplashAuroraPainter old) => old.t != t;
}

// ── Particle Painter ────────────────────────────────────────────
class _SplashParticlePainter extends CustomPainter {
  final double t;
  static final _rng = math.Random(77);
  static final _ps  = List.generate(45, (_) => _SP(_rng));
  _SplashParticlePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint();
    for (final pt in _ps) {
      final x  = (pt.x * size.width  + t * pt.speed * size.width  * 0.15) % size.width;
      final y  = (pt.y * size.height + t * pt.speed * size.height * 0.06) % size.height;
      final op = (math.sin(t * 2 * math.pi * pt.f + pt.ph) * 0.5 + 0.5) * 0.7;
      p.color  = pt.cyan
          ? AppColors.cyan.withOpacity(op * 0.6)
          : AppColors.violetBright.withOpacity(op * 0.45);
      canvas.drawCircle(Offset(x, y), pt.r, p);
    }
  }

  @override
  bool shouldRepaint(_SplashParticlePainter old) => old.t != t;
}

class _SP {
  final double x, y, speed, r, f, ph;
  final bool cyan;
  _SP(math.Random rng)
      : x     = rng.nextDouble(),
        y     = rng.nextDouble(),
        speed = rng.nextDouble() * 0.025 + 0.005,
        r     = rng.nextDouble() * 2.2  + 0.4,
        f     = rng.nextDouble() * 2    + 0.5,
        ph    = rng.nextDouble() * 2 * math.pi,
        cyan  = rng.nextBool();
}
