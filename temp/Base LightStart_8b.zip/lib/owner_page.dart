import 'main.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String currentUserRole;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
    this.currentUserRole = 'owner',
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late String sessionKey;
  late String currentUserRole;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  // Daftar role berdasarkan hierarki (dari tertinggi ke terendah)
  final List<String> allRoles = ['high owner', 'owner', 'high admin', 'admin', 'reseller', 'vip', 'member'];
  
  // Helper untuk mendapatkan level role
  int getRoleLevel(String role) {
    switch (role.toLowerCase()) {
      case 'high owner': return 7;
      case 'owner': return 6;
      case 'high admin': return 5;
      case 'admin': return 4;
      case 'reseller': return 3;
      case 'vip': return 2;
      case 'member': return 1;
      default: return 1;
    }
  }
  
  // Role yang bisa dipilih untuk create account berdasarkan role pengguna
  List<String> get availableRolesToCreate {
    final creatorLevel = getRoleLevel(currentUserRole);
    
    switch (currentUserRole.toLowerCase()) {
      case 'high owner':
        return [...allRoles];
      case 'owner':
        return allRoles.where((r) => r != 'high owner').toList();
      case 'high admin':
        return allRoles.where((r) => r != 'high owner' && r != 'owner').toList();
      case 'admin':
        return ['reseller', 'vip', 'member'];
      case 'reseller':
        return ['member'];
      default:
        return [];
    }
  }

  // Role yang bisa dilihat di user list
  List<String> get visibleRoles {
    switch (currentUserRole.toLowerCase()) {
      case 'high owner':
        return [...allRoles];
      case 'owner':
        return allRoles.where((r) => r != 'high owner').toList();
      case 'high admin':
        return allRoles.where((r) => r != 'high owner' && r != 'owner').toList();
      case 'admin':
        return ['reseller', 'vip', 'member'];
      case 'reseller':
        return ['member'];
      default:
        return [];
    }
  }

  String selectedRole = 'member';
  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  // ─── TEMA BIRU PEKAT ──────────────────────────────────────────────────────
  final Color bgDark = AppColors.bg;
  final Color primaryBlue = AppColors.border;
  final Color accentBlue = const Color(0xFF2D4ED8);
  final Color lightBlue = AppColors.cyanDim;
  final Color deepBlue = AppColors.surface;
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade300;
  final Color cardGlass = AppColors.card.withOpacity(0.7);
  final Color borderGlass = AppColors.border.withOpacity(0.5);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    currentUserRole = widget.currentUserRole.toLowerCase();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://nayahaikall.tyzx-host.my.id:2563/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => visibleRoles.contains(u['role']?.toString().toLowerCase()))
          .toList();
      
      if (selectedRole.isNotEmpty && visibleRoles.contains(selectedRole)) {
        filteredList = filteredList
            .where((u) => u['role']?.toString().toLowerCase() == selectedRole)
            .toList();
      }
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    if (filteredList.isEmpty) return [];
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    final targetUser = fullUserList.firstWhere(
      (u) => u['username'] == username,
      orElse: () => null,
    );
    
    if (targetUser != null) {
      String targetRole = targetUser['role']?.toString().toLowerCase() ?? '';
      if (!_canDeleteRole(targetRole)) {
        _alert("Akses Ditolak", "Anda tidak memiliki izin untuk menghapus user dengan role $targetRole.");
        return;
      }
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://nayahaikall.tyzx-host.my.id:2563/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  bool _canDeleteRole(String targetRole) {
    targetRole = targetRole.toLowerCase();
    switch (currentUserRole) {
      case 'high owner':
        return true;
      case 'owner':
        return targetRole != 'high owner';
      case 'high admin':
        return targetRole != 'high owner' && targetRole != 'owner';
      case 'admin':
        return targetRole == 'reseller' || targetRole == 'vip' || targetRole == 'member';
      case 'reseller':
        return targetRole == 'member';
      default:
        return false;
    }
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    if (!availableRolesToCreate.contains(newUserRole)) {
      _alert("Akses Ditolak", "Anda tidak memiliki izin untuk membuat akun dengan role ${newUserRole.toUpperCase()}.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://nayahaikall.tyzx-host.my.id:2563/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = availableRolesToCreate.isNotEmpty ? availableRolesToCreate.first : 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://nayahaikall.tyzx-host.my.id:2563/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: deepBlue,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: BorderSide(color: accentBlue.withOpacity(0.5)),
        ),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: lightBlue),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                borderRadius: BorderRadius.circular(22),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  "OK",
                  style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String getRoleDisplayName(String role) {
    switch (role.toLowerCase()) {
      case 'high owner': return 'HIGH OWNER';
      case 'owner': return 'OWNER';
      case 'high admin': return 'HIGH ADMIN';
      case 'admin': return 'ADMIN';
      case 'reseller': return 'RESELLER';
      case 'vip': return 'VIP';
      case 'member': return 'MEMBER';
      default: return role.toUpperCase();
    }
  }
  
  Color getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'high owner': return AppColors.gold;
      case 'owner': return const Color(0xFFFBBF24);
      case 'high admin': return const Color(0xFFFF6B35);
      case 'admin': return accentBlue;
      case 'reseller': return const Color(0xFF4ADE80);
      case 'vip': return const Color(0xFFA78BFA);
      default: return lightBlue;
    }
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: lightBlue, fontWeight: FontWeight.w500),
          prefixIcon: Icon(icon, color: accentBlue),
          filled: true,
          fillColor: cardGlass,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(22),
            borderSide: BorderSide(color: accentBlue, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 25),
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [cardGlass, deepBlue.withOpacity(0.5)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderGlass, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: primaryBlue.withOpacity(0.3),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Icon(icon, color: primaryWhite),
              ),
              SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  color: primaryWhite,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                  shadows: [
                    Shadow(
                      color: primaryBlue.withOpacity(0.5),
                      blurRadius: 5,
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 24),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    String userRole = user['role']?.toString().toLowerCase() ?? '';
    bool canDelete = _canDeleteRole(userRole);
    Color roleColor = getRoleColor(userRole);
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardGlass, deepBlue.withOpacity(0.3)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: primaryWhite),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(
                    color: primaryWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: roleColor,
                      ),
                    ),
                    SizedBox(width: 6),
                    Text(
                      "ROLE: ${getRoleDisplayName(user['role'])}",
                      style: TextStyle(color: roleColor, fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                    SizedBox(width: 12),
                    Text(
                      "EXP: ${user['expiredDate']}",
                      style: TextStyle(color: textGrey, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (canDelete)
            Container(
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.2),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.redAccent.withOpacity(0.5)),
              ),
              child: IconButton(
                icon: Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: deepBlue,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                        side: BorderSide(color: accentBlue.withOpacity(0.5)),
                      ),
                      title: Text("Konfirmasi", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
                      content: Text("Hapus user '${user['username']}'?", style: TextStyle(color: textGrey)),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context, false),
                          child: Text("Batal", style: TextStyle(color: textGrey)),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(context, true),
                          child: Text("Hapus", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  );
                  if (confirm == true) {
                    deleteController.text = user['username'];
                    _deleteUser();
                  }
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return ElevatedButton(
          onPressed: () => setState(() => currentPage = page),
          style: ElevatedButton.styleFrom(
            backgroundColor: currentPage == page ? accentBlue : Colors.transparent,
            foregroundColor: currentPage == page ? primaryWhite : textGrey,
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(22),
              side: BorderSide(color: borderGlass),
            ),
          ),
          child: Text("$page", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Tentukan apakah user adalah HIGH OWNER untuk menampilkan badge
    final isHighOwner = currentUserRole.toLowerCase() == 'high owner';
    
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.5,
            colors: [deepBlue, bgDark, const Color(0xFF050814)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Icon dengan efek glow
                Container(
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: accentBlue.withOpacity(0.5),
                        blurRadius: 20,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: Icon(
                    isHighOwner ? Icons.security_rounded : Icons.workspace_premium,
                    color: primaryWhite, 
                    size: 50
                  ),
                ),
                SizedBox(height: 20),
                
                // Title
                Text(
                  isHighOwner ? "OWNER DASHBOARD" : getRoleDisplayName(currentUserRole),
                  style: TextStyle(
                    color: isHighOwner ? AppColors.gold : primaryWhite,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 3,
                    shadows: [
                      Shadow(
                        color: (isHighOwner ? AppColors.gold : accentBlue).withOpacity(0.8),
                        blurRadius: 15,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
                
                // High Owner Badge
                if (isHighOwner)
                  Container(
                    margin: EdgeInsets.only(top: 8),
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [AppColors.gold, const Color(0xFFB8860B)]),
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: Colors.white, size: 14),
                        SizedBox(width: 6),
                        Text(
                          "create account",
                          style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                
                Text(
                  "MANAGEMENT PANEL",
                  style: TextStyle(
                    color: lightBlue,
                    fontSize: 14,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  width: 80,
                  height: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                    borderRadius: BorderRadius.circular(22),
                  ),
                ),
                SizedBox(height: 40),

                // DELETE USER CARD
                _buildGlassCard(
                  title: "DELETE USER",
                  icon: FontAwesomeIcons.userSlash,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: deleteController,
                      icon: FontAwesomeIcons.user,
                    ),
                    SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [Colors.redAccent, primaryBlue]),
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.red.withOpacity(0.4),
                            blurRadius: 10,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _deleteUser,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(22),
                          ),
                        ),
                        child: isLoading
                            ? SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: primaryWhite,
                                ),
                              )
                            : Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.delete, size: 18, color: primaryWhite),
                                  SizedBox(width: 8),
                                  Text(
                                    "DELETE ACCOUNT",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1,
                                      color: primaryWhite,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),

                // CREATE ACCOUNT CARD (hanya jika available)
                if (availableRolesToCreate.isNotEmpty)
                  _buildGlassCard(
                    title: "CREATE ACCOUNT",
                    icon: FontAwesomeIcons.userPlus,
                    children: [
                      _buildInput(
                        label: "Username",
                        controller: createUsernameController,
                        icon: FontAwesomeIcons.user,
                      ),
                      _buildInput(
                        label: "Password",
                        controller: createPasswordController,
                        icon: FontAwesomeIcons.lock,
                      ),
                      _buildInput(
                        label: "Durasi (Hari)",
                        controller: createDayController,
                        icon: FontAwesomeIcons.calendarDay,
                        type: TextInputType.number,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: deepBlue.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: borderGlass),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: newUserRole,
                            dropdownColor: deepBlue,
                            style: TextStyle(color: primaryWhite),
                            items: availableRolesToCreate.map((role) {
                              return DropdownMenuItem(
                                value: role,
                                child: Row(
                                  children: [
                                    Container(
                                      width: 10,
                                      height: 10,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: getRoleColor(role),
                                      ),
                                    ),
                                    SizedBox(width: 8),
                                    Text(getRoleDisplayName(role), style: TextStyle(color: primaryWhite)),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (val) =>
                                setState(() => newUserRole = val ?? 'member'),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Container(
                        height: 50,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [primaryBlue, accentBlue]),
                          borderRadius: BorderRadius.circular(22),
                          boxShadow: [
                            BoxShadow(
                              color: accentBlue.withOpacity(0.4),
                              blurRadius: 10,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: isLoading ? null : _createAccount,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(22),
                            ),
                          ),
                          child: isLoading
                              ? SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: primaryWhite,
                                  ),
                                )
                              : Text(
                                  "CREATE ACCOUNT",
                                  style: TextStyle(
                                    color: primaryWhite,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                        ),
                      ),
                    ],
                  ),

                // EXTEND DURATION CARD
                _buildGlassCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: editUsernameController,
                      icon: FontAwesomeIcons.userEdit,
                    ),
                    _buildInput(
                      label: "Tambah Hari",
                      controller: editDayController,
                      icon: FontAwesomeIcons.calendarPlus,
                      type: TextInputType.number,
                    ),
                    SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [lightBlue, primaryBlue]),
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [
                          BoxShadow(
                            color: accentBlue.withOpacity(0.4),
                            blurRadius: 10,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _editUser,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(22),
                          ),
                        ),
                        child: isLoading
                            ? SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: primaryWhite,
                                ),
                              )
                            : Text(
                                "ADD DAYS",
                                style: TextStyle(
                                  color: primaryWhite,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),

                // USER LIST CARD
                if (visibleRoles.isNotEmpty)
                  _buildGlassCard(
                    title: "USER LIST",
                    icon: FontAwesomeIcons.users,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: deepBlue.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: borderGlass),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selectedRole,
                            dropdownColor: deepBlue,
                            style: TextStyle(color: primaryWhite),
                            items: visibleRoles.map((role) {
                              return DropdownMenuItem(
                                value: role,
                                child: Row(
                                  children: [
                                    Container(
                                      width: 10,
                                      height: 10,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: getRoleColor(role),
                                      ),
                                    ),
                                    SizedBox(width: 8),
                                    Text(getRoleDisplayName(role), style: TextStyle(color: primaryWhite)),
                                  ],
                                ),
                              );
                            }).toList(),
                            onChanged: (val) {
                              if (val != null) {
                                selectedRole = val;
                                _filterAndPaginate();
                              }
                            },
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      isLoading
                          ? Center(
                              child: CircularProgressIndicator(
                                color: accentBlue,
                              ),
                            )
                          : filteredList.isEmpty
                              ? Center(
                                  child: Padding(
                                    padding: EdgeInsets.all(40),
                                    child: Text(
                                      "Tidak ada Pengguna",
                                      style: TextStyle(color: textGrey),
                                    ),
                                  ),
                                )
                              : Column(
                                  children: [
                                    ..._getCurrentPageData()
                                        .map((u) => _buildUserItem(u))
                                        .toList(),
                                    SizedBox(height: 20),
                                    _buildPagination(),
                                  ],
                                ),
                    ],
                  ),
                SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}