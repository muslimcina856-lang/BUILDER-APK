import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'package:markdown/markdown.dart' as md;
import 'package:just_audio/just_audio.dart';
import 'package:open_filex/open_filex.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../app.dart';
import '../../config/app_config.dart';
import '../../models/app_models.dart';
import '../../services/media_export_service.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _composer = TextEditingController();
  final _scroll = ScrollController();
  final _speech = SpeechToText();

  bool _listening = false;
  int _lastMessageCount = 0;
  int _lastEventCount = 0;
  // Jangan paksa scroll ke bawah semasa berfikir jika pengguna sedang baca atas.
  bool _nearBottom = true;
  bool _showJumpDown = false;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _composer.dispose();
    _scroll.dispose();
    _speech.stop();
    super.dispose();
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final pos = _scroll.position;
    final near = pos.pixels >= pos.maxScrollExtent - 120;
    if (near != _nearBottom || (!near) != _showJumpDown) {
      setState(() {
        _nearBottom = near;
        _showJumpDown = !near;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    if (state.messages.length != _lastMessageCount ||
        state.activeRunEvents.length != _lastEventCount) {
      _lastMessageCount = state.messages.length;
      _lastEventCount = state.activeRunEvents.length;
      // Hanya auto-turun jika pengguna memang di bahagian bawah.
      if (_nearBottom) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _scrollToBottom();
        });
      } else if (!_showJumpDown) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) setState(() => _showJumpDown = true);
        });
      }
    }

    return SafeArea(
      child: Column(
        children: <Widget>[
          _ChatHeader(
            provider: state.selectedProvider,
            onTapModel: () => _showProviderModelPicker(context),
            onNewSession: () => state.newSession(reason: 'Sesi baharu dimulakan.'),
          ),
          Expanded(
            child: Stack(
              children: <Widget>[
                CustomScrollView(
                  controller: _scroll,
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  slivers: <Widget>[
                    if (state.messages.isEmpty)
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: _EmptyChat(
                          hasProvider: state.hasProvider,
                          sessionNotice: state.sessionNotice,
                          onOpenProvider: () => state.selectTab(1),
                          onSuggestion: (value) {
                            _composer.text = value;
                            _composer.selection = TextSelection.collapsed(
                              offset: value.length,
                            );
                          },
                        ),
                      )
                    else
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                        sliver: SliverList.separated(
                          itemCount: state.messages.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 14),
                          itemBuilder: (context, index) => _MessageCard(
                            key: ValueKey<String>(state.messages[index].id),
                            message: state.messages[index],
                          ),
                        ),
                      ),
                    if (state.isSending)
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(14, 2, 14, 18),
                        sliver: SliverToBoxAdapter(
                          child: _LiveProcessCard(
                            events: state.activeRunEvents,
                            detail: state.runDetail,
                            followUpCount: state.followUpQueue.length,
                            startedAt: state.runStartedAt,
                          ),
                        ),
                      ),
                    const SliverToBoxAdapter(child: SizedBox(height: 8)),
                  ],
                ),
                if (_showJumpDown)
                  Positioned(
                    right: 14,
                    bottom: 12,
                    child: Material(
                      color: const Color(0xEE1A2230),
                      elevation: 4,
                      shape: const CircleBorder(),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: () {
                          _scrollToBottom();
                          setState(() {
                            _nearBottom = true;
                            _showJumpDown = false;
                          });
                        },
                        child: const SizedBox(
                          width: 42,
                          height: 42,
                          child: Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: Colors.white,
                            size: 26,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          _Composer(
            controller: _composer,
            attachments: state.pendingAttachments,
            listening: _listening,
            sending: state.isSending,
            onAttach: () => _pickAttachments(context),
            onRemoveAttachment: state.removePendingAttachment,
            onVoice: _toggleListening,
            onSend: () => _submit(context),
            onStop: state.stopCurrentRun,
          ),
        ],
      ),
    );
  }

  Future<void> _pickAttachments(BuildContext context) async {
    try {
      await AppScope.read(context).pickAttachments();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    }
  }

  Future<void> _submit(BuildContext context) async {
    final state = AppScope.read(context);
    final text = _composer.text;
    if (text.trim().isEmpty && state.pendingAttachments.isEmpty) return;
    _composer.clear();
    await state.sendMessage(text);
  }

  Future<void> _toggleListening() async {
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    final ready = await _speech.initialize(
      onError: (_) {
        if (mounted) setState(() => _listening = false);
      },
      onStatus: (status) {
        if (mounted && status == 'notListening') {
          setState(() => _listening = false);
        }
      },
    );
    if (!ready) return;
    if (mounted) setState(() => _listening = true);
    await _speech.listen(
      localeId: 'ms_MY',
      partialResults: true,
      onResult: (result) {
        _composer.text = result.recognizedWords;
        _composer.selection = TextSelection.collapsed(
          offset: _composer.text.length,
        );
        if (result.finalResult && mounted) {
          setState(() => _listening = false);
        }
      },
    );
  }

  Future<void> _showProviderModelPicker(BuildContext context) async {
    final state = AppScope.read(context);
    if (state.providers.isEmpty) {
      state.selectTab(1);
      return;
    }
    final selection = await showModalBottomSheet<_ProviderModelSelection>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: AppTheme.surface,
      builder: (_) => _ProviderModelSheet(state: state),
    );
    if (selection == null) return;
    // Tunggu route bottom sheet selesai dinyahaktif sebelum state global
    // memberitahu seluruh aplikasi. Ini mengelakkan dependent inherited widget
    // tertinggal semasa animasi penutupan route.
    await WidgetsBinding.instance.endOfFrame;

    final provider = state.providers.firstWhere(
      (item) => item.id == selection.providerId,
      orElse: () => state.providers.first,
    );
    final models = <String>{
      ...selection.models,
      selection.model,
    }.toList();
    await state.saveProvider(
      provider.copyWith(
        model: selection.model,
        availableModels: models,
        updatedAt: DateTime.now(),
      ),
    );
    await state.selectProvider(provider.id);
  }

  void _scrollToBottom() {
    if (!_scroll.hasClients) return;
    _scroll.animateTo(
      _scroll.position.maxScrollExtent,
      duration: const Duration(milliseconds: 340),
      curve: Curves.easeOutCubic,
    );
  }
}

class _ProviderModelSelection {
  const _ProviderModelSelection({
    required this.providerId,
    required this.model,
    required this.models,
  });

  final String providerId;
  final String model;
  final List<String> models;
}

class _ProviderModelSheet extends StatefulWidget {
  const _ProviderModelSheet({required this.state});

  final AppState state;

  @override
  State<_ProviderModelSheet> createState() => _ProviderModelSheetState();
}

class _ProviderModelSheetState extends State<_ProviderModelSheet> {
  late String _providerId;
  final TextEditingController _manual = TextEditingController();
  List<String> _models = const <String>[];
  late String _selectedModel;
  bool _loading = false;
  String _status = '';

  AppState get appState => widget.state;

  ProviderConfig get _provider => appState.providers.firstWhere(
        (item) => item.id == _providerId,
        orElse: () => appState.providers.first,
      );

  @override
  void initState() {
    super.initState();
    _providerId = appState.selectedProviderId.isEmpty
        ? appState.providers.first.id
        : appState.selectedProviderId;
    _models = appState.chatModelsFor(_provider);
    _selectedModel = _provider.model;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _refresh();
    });
  }

  @override
  void dispose() {
    _manual.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    if (_loading || !mounted) return;
    final provider = _provider;
    setState(() {
      _loading = true;
      _status = 'Menyemak model terus daripada provider…';
    });
    try {
      final key = await appState.providerKey(provider.id);
      if (provider.authStyle != AuthStyle.none && key.isEmpty) {
        if (!mounted) return;
        setState(() {
          _models = appState.chatModelsFor(provider);
          _status = 'API key belum disimpan. Menggunakan senarai local.';
        });
        return;
      }
      final live = await appState.refreshModels(provider, key);
      if (!mounted) return;
      var nextModel = _selectedModel;
      if (live.isNotEmpty && !live.contains(nextModel)) {
        nextModel = live.first;
      }
      if (!mounted) return;
      setState(() {
        _models = live.isEmpty ? appState.chatModelsFor(provider) : live;
        _selectedModel = nextModel;
        _status = live.isEmpty
            ? 'Provider tidak memulangkan senarai model chat.'
            : '${live.length} model chat disahkan · ${nextModel.isEmpty ? 'pilih satu' : nextModel}';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _models = appState.chatModelsFor(provider);
        _status = 'Gagal menyegar: $error';
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _changeProvider(String value) async {
    if (value == _providerId || !mounted) return;
    setState(() {
      _providerId = value;
      _models = appState.chatModelsFor(_provider);
      _selectedModel = _provider.model;
      _status = '';
      _manual.clear();
    });
    await _refresh();
  }

  void _selectModel(String model) {
    final value = model.trim();
    if (value.isEmpty) return;
    Navigator.of(context).pop(
      _ProviderModelSelection(
        providerId: _providerId,
        model: value,
        models: List<String>.from(_models),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = _provider;
    final selectedModel = _selectedModel;
    return FractionallySizedBox(
      heightFactor: .86,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          18,
          8,
          18,
          MediaQuery.viewInsetsOf(context).bottom + 18,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: Container(
                width: 42,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.outline,
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: <Widget>[
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Provider & model',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'Senarai model disahkan terus daripada provider.',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton.filledTonal(
                  tooltip: 'Segarkan model',
                  onPressed: _loading ? null : _refresh,
                  icon: _loading
                      ? const SizedBox.square(
                          dimension: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.refresh_rounded),
                ),
              ],
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              key: ValueKey<String>(_providerId),
              initialValue: _providerId,
              decoration: const InputDecoration(
                labelText: 'Provider',
                prefixIcon: Icon(Icons.key_rounded),
              ),
              isExpanded: true,
              items: appState.providers
                  .map(
                    (item) => DropdownMenuItem<String>(
                      value: item.id,
                      child: Text(
                        item.name,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  )
                  .toList(),
              onChanged: _loading
                  ? null
                  : (value) {
                      if (value != null) _changeProvider(value);
                    },
            ),
            if (_status.isNotEmpty) ...<Widget>[
              const SizedBox(height: 10),
              Text(
                _status,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: _status.startsWith('Gagal')
                      ? AppTheme.danger
                      : AppTheme.textSecondary,
                  fontSize: 12.5,
                  height: 1.35,
                ),
              ),
            ],
            const SizedBox(height: 12),
            Expanded(
              child: _models.isEmpty
                  ? Center(
                      child: Text(
                        _loading
                            ? 'Mendapatkan model…'
                            : 'Tiada model chat dikesan. Masukkan Model ID manual.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: AppTheme.textSecondary),
                      ),
                    )
                  : ListView.separated(
                      itemCount: _models.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 7),
                      itemBuilder: (context, index) {
                        final model = _models[index];
                        final selected = model == selectedModel;
                        return Material(
                          color: selected
                              ? AppTheme.purple.withValues(alpha: .12)
                              : AppTheme.surfaceHigh,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(
                              color: selected
                                  ? AppTheme.purpleLight
                                  : AppTheme.outline,
                            ),
                          ),
                          child: ListTile(
                            leading: Icon(
                              selected
                                  ? Icons.check_circle_rounded
                                  : Icons.circle_outlined,
                              color: selected
                                  ? AppTheme.purpleLight
                                  : AppTheme.textSecondary,
                            ),
                            title: Text(
                              model,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onTap: () => _selectModel(model),
                          ),
                        );
                      },
                    ),
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _manual,
                    textInputAction: TextInputAction.done,
                    decoration: const InputDecoration(
                      labelText: 'Model ID manual',
                      hintText: 'model-id',
                    ),
                    onSubmitted: _selectModel,
                  ),
                ),
                const SizedBox(width: 10),
                IconButton.filled(
                  tooltip: 'Gunakan model manual',
                  onPressed: () => _selectModel(_manual.text),
                  icon: const Icon(Icons.arrow_forward_rounded),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ChatHeader extends StatelessWidget {
  const _ChatHeader({
    required this.provider,
    required this.onTapModel,
    required this.onNewSession,
  });

  final ProviderConfig? provider;
  final VoidCallback onTapModel;
  final VoidCallback onNewSession;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 10, 8),
      child: Row(
        children: <Widget>[
          Container(
            width: 46,
            height: 46,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              gradient: const LinearGradient(
                colors: <Color>[Color(0xFF332653), Color(0xFF141728)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: AppTheme.purple.withValues(alpha: .18),
                  blurRadius: 22,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                AppConfig.iconAsset,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: onTapModel,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      'Ai MultiAgent',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -.35,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            provider == null
                                ? 'Pilih provider & model'
                                : '${provider!.name} · ${provider!.model.isEmpty ? 'pilih model' : provider!.model}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 13,
                            ),
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          size: 17,
                          color: AppTheme.textSecondary,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Sesi baharu',
            onPressed: onNewSession,
            icon: const Icon(Icons.add_comment_outlined),
          ),
        ],
      ),
    );
  }
}

class _EmptyChat extends StatelessWidget {
  const _EmptyChat({
    required this.hasProvider,
    required this.sessionNotice,
    required this.onOpenProvider,
    required this.onSuggestion,
  });

  final bool hasProvider;
  final String sessionNotice;
  final VoidCallback onOpenProvider;
  final ValueChanged<String> onSuggestion;

  @override
  Widget build(BuildContext context) {
    final suggestions = <(IconData, String, String)>[
      (
        Icons.travel_explore_rounded,
        'Selidik web',
        'Cari maklumat terkini dan ringkaskan sumber penting.',
      ),
      (
        Icons.download_rounded,
        'Proses pautan',
        'Buka pautan ini di browser latar, analisis kandungan dan berikan hasil.',
      ),
      (
        Icons.description_outlined,
        'Analisis fail',
        'Analisis fail yang saya lampirkan dan sediakan ringkasan teratur.',
      ),
      (
        Icons.auto_awesome_rounded,
        'Bina skill',
        'Cipta satu skill local yang boleh membantu tugasan berulang ini.',
      ),
    ];
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 78,
                height: 78,
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF40306A), Color(0xFF111522)],
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.purple.withValues(alpha: .22),
                      blurRadius: 34,
                      offset: const Offset(0, 12),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(21),
                  child: Image.asset(
                    AppConfig.iconAsset,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Apa yang mahu diselesaikan?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.55,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Satu model utama menyelaras carian, browser latar, fail, terminal, skills dan sub-agent secara automatik.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  height: 1.5,
                ),
              ),
              if (sessionNotice.isNotEmpty) ...<Widget>[
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 13,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceHigh,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    sessionNotice,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
              if (!hasProvider) ...<Widget>[
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: onOpenProvider,
                  icon: const Icon(Icons.key_rounded),
                  label: const Text('Tambah provider'),
                ),
              ],
              const SizedBox(height: 24),
              LayoutBuilder(
                builder: (context, constraints) {
                  final oneColumn = constraints.maxWidth < 500;
                  final width = oneColumn
                      ? constraints.maxWidth
                      : (constraints.maxWidth - 10) / 2;
                  return Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: suggestions
                        .map(
                          (item) => SizedBox(
                            width: width,
                            child: _SuggestionCard(
                              icon: item.$1,
                              title: item.$2,
                              prompt: item.$3,
                              onTap: () => onSuggestion(item.$3),
                            ),
                          ),
                        )
                        .toList(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  const _SuggestionCard({
    required this.icon,
    required this.title,
    required this.prompt,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String prompt;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: Color(0xFF202638)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: <Widget>[
              Container(
                width: 39,
                height: 39,
                decoration: BoxDecoration(
                  color: AppTheme.purple.withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(icon, size: 20, color: AppTheme.purpleLight),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      prompt,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({required this.message, super.key});

  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    if (message.role == MessageRole.tool ||
        message.role == MessageRole.system) {
      return const SizedBox.shrink();
    }
    final isUser = message.role == MessageRole.user;
    final maxWidth = MediaQuery.sizeOf(context).width * (isUser ? .84 : .94);
    final processEvents = message.runEvents.where((event) {
      final title = event.title.toLowerCase();
      return !title.contains('memahami') &&
          !title.contains('menyusun') &&
          title != 'berfikir';
    }).toList(growable: false);
    final durationMs = (message.metadata['durationMs'] as num?)?.toInt();
    final messageBody = Padding(
      padding: EdgeInsets.fromLTRB(
        isUser ? 15 : 2,
        isUser ? 14 : 2,
        isUser ? 15 : 2,
        isUser ? 13 : 4,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (!isUser && processEvents.isNotEmpty) ...<Widget>[
            _CompletedProcessCard(
              events: processEvents,
              durationMs: durationMs,
            ),
            const SizedBox(height: 8),
          ],
          if (message.attachments.isNotEmpty)
            _AttachmentGrid(
              attachments: message.attachments,
              compact: isUser,
            ),
          if (message.attachments.isNotEmpty &&
              message.content.trim().isNotEmpty)
            const SizedBox(height: 10),
          if (message.content.trim().isNotEmpty)
            if (isUser)
              _ExpandableUserText(text: message.content)
            else
              _RichChatContent(data: message.content),
          if (!isUser && message.content.trim().isNotEmpty)
            _MessageCopyBar(text: message.content),
          if (message.artifacts.isNotEmpty) ...<Widget>[
            if (message.content.trim().isNotEmpty)
              const SizedBox(height: 14),
            _ArtifactList(artifacts: message.artifacts),
          ],
        ],
      ),
    );
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: maxWidth.clamp(280.0, 760.0).toDouble(),
        ),
        // Seperti ChatGPT: mesej pengguna kekal sebagai gelembung ringkas,
        // manakala jawapan pembantu mengalir terus tanpa kad atau bingkai.
        child: isUser
            ? DecoratedBox(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF7650EC), Color(0xFF9256FF)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(21),
                    topRight: Radius.circular(21),
                    bottomLeft: Radius.circular(21),
                    bottomRight: Radius.circular(7),
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: Colors.black.withValues(alpha: .1),
                      blurRadius: 18,
                      offset: const Offset(0, 7),
                    ),
                  ],
                ),
                child: messageBody,
              )
            : messageBody,
      ),
    );
  }
}

class _ExpandableUserText extends StatefulWidget {
  const _ExpandableUserText({required this.text});

  final String text;

  @override
  State<_ExpandableUserText> createState() => _ExpandableUserTextState();
}

class _ExpandableUserTextState extends State<_ExpandableUserText> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final long = widget.text.length > 1200 || '\n'.allMatches(widget.text).length > 24;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SelectableText(
          widget.text,
          maxLines: long && !_expanded ? 24 : null,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 15.5,
            height: 1.45,
          ),
        ),
        if (long) ...<Widget>[
          const SizedBox(height: 8),
          TextButton.icon(
            style: TextButton.styleFrom(
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              visualDensity: VisualDensity.compact,
            ),
            onPressed: () => setState(() => _expanded = !_expanded),
            icon: Icon(
              _expanded
                  ? Icons.keyboard_arrow_up_rounded
                  : Icons.keyboard_arrow_down_rounded,
              size: 18,
            ),
            label: Text(_expanded ? 'Ringkaskan' : 'Lihat penuh'),
          ),
        ],
      ],
    );
  }
}

/// Paparan kaya: markdown + jadual + code copy + mermaid/graf dalam chat.
class _RichChatContent extends StatelessWidget {
  const _RichChatContent({required this.data});

  final String data;

  static final RegExp _fence = RegExp(
    r'```([a-zA-Z0-9_+-]*)\s*\n([\s\S]*?)```',
    multiLine: true,
  );

  @override
  Widget build(BuildContext context) {
    final parts = <Widget>[];
    var cursor = 0;
    for (final match in _fence.allMatches(data)) {
      if (match.start > cursor) {
        final md = data.substring(cursor, match.start).trim();
        if (md.isNotEmpty) parts.add(_MarkdownAnswer(data: md));
      }
      final lang = (match.group(1) ?? '').trim().toLowerCase();
      final body = (match.group(2) ?? '').trimRight();
      if (lang == 'mermaid' || lang == 'mmd') {
        parts.add(_MermaidBlock(source: body));
      } else if (lang == 'chart' || lang == 'bar') {
        parts.add(_SimpleBarChartBlock(source: body));
      } else {
        // Kekalkan fence sebagai markdown code supaya ada butang salin.
        parts.add(
          _MarkdownAnswer(
            data: '```$lang\n$body\n```',
          ),
        );
      }
      cursor = match.end;
    }
    if (cursor < data.length) {
      final md = data.substring(cursor).trim();
      if (md.isNotEmpty) parts.add(_MarkdownAnswer(data: md));
    }
    if (parts.isEmpty) return _MarkdownAnswer(data: data);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        for (var i = 0; i < parts.length; i++) ...<Widget>[
          if (i > 0) const SizedBox(height: 10),
          parts[i],
        ],
      ],
    );
  }
}

class _MermaidBlock extends StatefulWidget {
  const _MermaidBlock({required this.source});

  final String source;

  @override
  State<_MermaidBlock> createState() => _MermaidBlockState();
}

class _MermaidBlockState extends State<_MermaidBlock> {
  WebViewController? _controller;
  bool _failed = false;
  double _height = 220;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void didUpdateWidget(covariant _MermaidBlock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.source != widget.source) _init();
  }

  Future<void> _init() async {
    try {
      final html = _mermaidHtml(widget.source);
      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF0B0E16))
        ..setNavigationDelegate(
          NavigationDelegate(
            onPageFinished: (_) async {
              try {
                final raw = await _controller?.runJavaScriptReturningResult(
                  'document.body.scrollHeight',
                );
                final h = double.tryParse(raw?.toString() ?? '') ?? 220;
                if (mounted && h > 80) {
                  setState(() => _height = h.clamp(160, 640));
                }
              } catch (_) {}
            },
          ),
        );
      _controller = controller;
      await controller.loadHtmlString(html, baseUrl: 'https://cdn.jsdelivr.net/');
      if (mounted) setState(() => _failed = false);
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  static String _mermaidHtml(String source) {
    final escaped = source
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;');
    return '''
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<script type="module">
  import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs';
  mermaid.initialize({ startOnLoad: true, theme: 'dark', securityLevel: 'loose' });
</script>
<style>
  body { margin: 0; padding: 12px; background: #0B0E16; color: #E8ECF5; }
  .mermaid { display: flex; justify-content: center; }
</style>
</head>
<body>
<pre class="mermaid">$escaped</pre>
</body>
</html>
''';
  }

  @override
  Widget build(BuildContext context) {
    if (_failed || _controller == null) {
      return _CopyableCodeBlock(code: '```mermaid\n${widget.source}\n```');
    }
    return Container(
      height: _height,
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppTheme.outline),
      ),
      clipBehavior: Clip.antiAlias,
      child: WebViewWidget(controller: _controller!),
    );
  }
}

/// Format mudah: setiap baris `label|nilai` atau `label: nilai`
class _SimpleBarChartBlock extends StatelessWidget {
  const _SimpleBarChartBlock({required this.source});

  final String source;

  @override
  Widget build(BuildContext context) {
    final rows = <({String label, double value})>[];
    for (final line in source.split('\n')) {
      final t = line.trim();
      if (t.isEmpty) continue;
      final parts = t.contains('|')
          ? t.split('|')
          : t.contains(':')
              ? t.split(':')
              : t.split(RegExp(r'\s+'));
      if (parts.length < 2) continue;
      final label = parts.first.trim();
      final value = double.tryParse(parts.sublist(1).join(' ').trim());
      if (label.isEmpty || value == null) continue;
      rows.add((label: label, value: value));
    }
    if (rows.isEmpty) {
      return _CopyableCodeBlock(code: source);
    }
    final maxV = rows.map((e) => e.value.abs()).fold<double>(1, (a, b) => a > b ? a : b);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Column(
        children: <Widget>[
          for (final row in rows.take(16))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: <Widget>[
                  SizedBox(
                    width: 72,
                    child: Text(
                      row.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: (row.value.abs() / maxV).clamp(0.0, 1.0),
                        minHeight: 12,
                        backgroundColor: const Color(0xFF1A2230),
                        color: AppTheme.purpleLight,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    row.value.toString(),
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _MarkdownAnswer extends StatelessWidget {
  const _MarkdownAnswer({required this.data});

  final String data;

  @override
  Widget build(BuildContext context) {
    final base = MarkdownStyleSheet.fromTheme(Theme.of(context));
    return MarkdownBody(
      data: data,
      selectable: true,
      builders: <String, MarkdownElementBuilder>{
        'pre': _CodeBlockBuilder(),
      },
      styleSheet: base.copyWith(
        p: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 15.5,
          height: 1.52,
        ),
        h1: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 23,
          fontWeight: FontWeight.w900,
          height: 1.25,
        ),
        h2: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 20,
          fontWeight: FontWeight.w900,
          height: 1.3,
        ),
        h3: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 17.5,
          fontWeight: FontWeight.w800,
          height: 1.35,
        ),
        strong: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w800,
        ),
        em: const TextStyle(
          color: AppTheme.textPrimary,
          fontStyle: FontStyle.italic,
        ),
        a: const TextStyle(
          color: AppTheme.cyan,
          decoration: TextDecoration.none,
          fontWeight: FontWeight.w700,
        ),
        code: const TextStyle(
          color: Color(0xFFD9CEFF),
          backgroundColor: AppTheme.surfaceHigh,
          fontFamily: 'monospace',
          fontSize: 13.2,
        ),
        codeblockPadding: const EdgeInsets.all(14),
        codeblockDecoration: BoxDecoration(
          color: const Color(0xFF0B0E16),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: AppTheme.outline),
        ),
        blockquotePadding: const EdgeInsets.fromLTRB(14, 10, 12, 10),
        blockquoteDecoration: BoxDecoration(
          color: AppTheme.purple.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(12),
          border: const Border(
            left: BorderSide(color: AppTheme.purpleLight, width: 3),
          ),
        ),
        horizontalRuleDecoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: AppTheme.outline, width: .8),
          ),
        ),
        listBullet: const TextStyle(
          color: AppTheme.purpleLight,
          fontWeight: FontWeight.w900,
        ),
      ),
      onTapLink: (text, href, title) async {
        if (href == null) return;
        final uri = Uri.tryParse(href);
        if (uri != null) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      },
    );
  }
}

class _CodeBlockBuilder extends MarkdownElementBuilder {
  @override
  Widget? visitElementAfter(md.Element element, TextStyle? preferredStyle) {
    final text = element.textContent;
    return _CopyableCodeBlock(code: text);
  }
}

class _CopyableCodeBlock extends StatefulWidget {
  const _CopyableCodeBlock({required this.code});

  final String code;

  @override
  State<_CopyableCodeBlock> createState() => _CopyableCodeBlockState();
}

class _CopyableCodeBlockState extends State<_CopyableCodeBlock> {
  bool _copied = false;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.code));
    if (!mounted) return;
    setState(() => _copied = true);
    Future<void>.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Stack(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 42, 14),
            child: SelectableText(
              widget.code.trimRight(),
              style: const TextStyle(
                color: Color(0xFFD9CEFF),
                fontFamily: 'monospace',
                fontSize: 13.2,
                height: 1.45,
              ),
            ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: IconButton(
              tooltip: _copied ? 'Disalin' : 'Salin kod',
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
              padding: EdgeInsets.zero,
              iconSize: 16,
              onPressed: _copy,
              icon: Icon(
                _copied ? Icons.check_rounded : Icons.copy_rounded,
                color: _copied ? AppTheme.success : AppTheme.textMuted,
                size: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageCopyBar extends StatefulWidget {
  const _MessageCopyBar({required this.text});

  final String text;

  @override
  State<_MessageCopyBar> createState() => _MessageCopyBarState();
}

class _MessageCopyBarState extends State<_MessageCopyBar> {
  bool _copied = false;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.text));
    if (!mounted) return;
    setState(() => _copied = true);
    Future<void>.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 2),
      child: Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: _copy,
          style: TextButton.styleFrom(
            foregroundColor: AppTheme.textMuted,
            visualDensity: VisualDensity.compact,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            minimumSize: const Size(0, 28),
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          icon: Icon(
            _copied ? Icons.check_rounded : Icons.copy_rounded,
            size: 14,
            color: _copied ? AppTheme.success : AppTheme.textMuted,
          ),
          label: Text(
            _copied ? 'Disalin' : 'Salin',
            style: const TextStyle(fontSize: 12),
          ),
        ),
      ),
    );
  }
}

class _AttachmentGrid extends StatelessWidget {
  const _AttachmentGrid({
    required this.attachments,
    required this.compact,
  });

  final List<ChatAttachment> attachments;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: attachments
          .map(
            (attachment) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _AttachmentPreview(
                key: ValueKey<String>(attachment.id),
                attachment: attachment,
                compact: compact,
              ),
            ),
          )
          .toList(),
    );
  }
}

class _AttachmentPreview extends StatelessWidget {
  const _AttachmentPreview({
    required this.attachment,
    required this.compact,
    super.key,
  });

  final ChatAttachment attachment;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return switch (attachment.kind) {
      AttachmentKind.image => _ImagePreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
          mimeType: attachment.mimeType,
        ),
      AttachmentKind.video => _VideoPreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
          mimeType: attachment.mimeType,
        ),
      AttachmentKind.audio => _AudioPreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
          mimeType: attachment.mimeType,
        ),
      _ => _FileCard(
          title: attachment.name,
          subtitle:
              '${attachment.mimeType} · ${_formatBytes(attachment.sizeBytes)}',
          path: attachment.path,
          url: attachment.sourceUrl ?? '',
          compact: compact,
        ),
    };
  }
}

class _ArtifactList extends StatelessWidget {
  const _ArtifactList({required this.artifacts});

  final List<ChatArtifact> artifacts;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: artifacts
          .map(
            (artifact) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _ArtifactCard(
                key: ValueKey<String>(artifact.id),
                artifact: artifact,
              ),
            ),
          )
          .toList(),
    );
  }
}

class _ArtifactCard extends StatelessWidget {
  const _ArtifactCard({required this.artifact, super.key});

  final ChatArtifact artifact;

  @override
  Widget build(BuildContext context) {
    return switch (artifact.kind) {
      ArtifactKind.image => _ImagePreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
          mimeType: artifact.mimeType,
        ),
      ArtifactKind.video => _VideoPreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
          mimeType: artifact.mimeType,
        ),
      ArtifactKind.audio => _AudioPreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
          mimeType: artifact.mimeType,
        ),
      ArtifactKind.webpage || ArtifactKind.html => _HtmlPreview(
          title: artifact.title,
          subtitle: artifact.subtitle,
          html: artifact.html,
          url: artifact.url,
        ),
      ArtifactKind.searchResults => _SearchResultsCard(artifact: artifact),
      ArtifactKind.file => _FileCard(
          title: artifact.title,
          subtitle: artifact.subtitle.isEmpty
              ? artifact.mimeType
              : artifact.subtitle,
          path: artifact.localPath,
          url: artifact.url,
          compact: false,
        ),
    };
  }
}

final MediaExportService _mediaExportService = MediaExportService();

class _ImagePreview extends StatefulWidget {
  const _ImagePreview({
    required this.path,
    required this.url,
    required this.title,
    this.mimeType = '',
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_ImagePreview> createState() => _ImagePreviewState();
}

class _ImagePreviewState extends State<_ImagePreview> {
  bool _saving = false;

  ImageProvider? _provider() {
    final localFile = widget.path.isNotEmpty ? File(widget.path) : null;
    if (localFile?.existsSync() ?? false) return FileImage(localFile!);
    final remoteUri = _validRemoteUri(widget.url);
    return remoteUri == null ? null : NetworkImage(remoteUri.toString());
  }

  @override
  Widget build(BuildContext context) {
    final provider = _provider();
    if (provider == null) return _MediaError(title: widget.title);
    return Material(
      color: Colors.black,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => _FullImagePreviewPage(
              path: widget.path,
              url: widget.url,
              title: widget.title,
              mimeType: _mediaMime(
                widget.mimeType,
                widget.path,
                widget.url,
                fallback: 'image/png',
              ),
            ),
          ),
        ),
        child: Stack(
          children: <Widget>[
            SizedBox(
              width: double.infinity,
              height: 420,
              child: Image(
                image: provider,
                fit: BoxFit.contain,
                alignment: Alignment.center,
                errorBuilder: (_, __, ___) => _MediaError(title: widget.title),
              ),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: _MediaToolbar(
                saving: _saving,
                onExpand: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => _FullImagePreviewPage(
                      path: widget.path,
                      url: widget.url,
                      title: widget.title,
                      mimeType: _mediaMime(
                        widget.mimeType,
                        widget.path,
                        widget.url,
                        fallback: 'image/png',
                      ),
                    ),
                  ),
                ),
                onSave: _save,
              ),
            ),
            Positioned(
              left: 8,
              right: 8,
              bottom: 8,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: .66),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  child: Row(
                    children: <Widget>[
                      const Icon(Icons.zoom_out_map_rounded, color: Colors.white70, size: 16),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Text(
                          widget.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const Text(
                        'Tekan untuk pratonton penuh',
                        style: TextStyle(color: Colors.white70, fontSize: 10.5),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: _mediaMime(
        widget.mimeType,
        widget.path,
        widget.url,
        fallback: 'image/png',
      ),
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _FullImagePreviewPage extends StatefulWidget {
  const _FullImagePreviewPage({
    required this.path,
    required this.url,
    required this.title,
    required this.mimeType,
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_FullImagePreviewPage> createState() => _FullImagePreviewPageState();
}

class _FullImagePreviewPageState extends State<_FullImagePreviewPage> {
  bool _saving = false;

  ImageProvider? _provider() {
    final file = widget.path.isNotEmpty ? File(widget.path) : null;
    if (file?.existsSync() ?? false) return FileImage(file!);
    final uri = _validRemoteUri(widget.url);
    return uri == null ? null : NetworkImage(uri.toString());
  }

  @override
  Widget build(BuildContext context) {
    final provider = _provider();
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: <Widget>[
          IconButton(
            tooltip: 'Simpan ke peranti',
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded),
          ),
        ],
      ),
      body: provider == null
          ? _MediaError(title: widget.title)
          : SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) => InteractiveViewer(
                  constrained: false,
                  alignment: Alignment.topCenter,
                  minScale: .5,
                  maxScale: 8,
                  boundaryMargin: const EdgeInsets.all(120),
                  child: Image(
                    image: provider,
                    width: constraints.maxWidth,
                    fit: BoxFit.fitWidth,
                    alignment: Alignment.topCenter,
                    errorBuilder: (_, __, ___) => _MediaError(title: widget.title),
                  ),
                ),
              ),
            ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: widget.mimeType,
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _VideoPreview extends StatefulWidget {
  const _VideoPreview({
    required this.path,
    required this.url,
    required this.title,
    this.mimeType = '',
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_VideoPreview> createState() => _VideoPreviewState();
}

class _VideoPreviewState extends State<_VideoPreview>
    with WidgetsBindingObserver {
  VideoPlayerController? _controller;
  Future<void>? _initialize;
  String? _error;
  bool _saving = false;
  bool _lastPlaying = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = _videoController(widget.path, widget.url);
    if (_controller == null) {
      _error = 'Sumber video tidak sah.';
      return;
    }
    _controller!.addListener(_onControllerChanged);
    _initialize = _controller!.initialize().then((_) async {
      await _controller?.setLooping(false);
      await _controller?.setVolume(1);
      if (mounted) setState(() {});
    }).catchError((Object error) {
      if (mounted) setState(() => _error = error.toString());
    });
  }

  void _onControllerChanged() {
    final playing = _controller?.value.isPlaying ?? false;
    if (playing == _lastPlaying || !mounted) return;
    _lastPlaying = playing;
    setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      _controller?.pause();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.removeListener(_onControllerChanged);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (controller == null || _error != null) {
      return _MediaError(title: widget.title);
    }
    return FutureBuilder<void>(
      future: _initialize,
      builder: (context, snapshot) {
        if (snapshot.hasError) return _MediaError(title: widget.title);
        if (snapshot.connectionState != ConnectionState.done ||
            !controller.value.isInitialized) {
          return Container(
            height: 190,
            decoration: BoxDecoration(
              color: const Color(0xFF090C13),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Center(child: _BufferOrb()),
          );
        }
        final ratio = controller.value.aspectRatio > 0
            ? controller.value.aspectRatio
            : 16 / 9;
        return LayoutBuilder(
          builder: (context, constraints) {
            final height = (constraints.maxWidth / ratio).clamp(190.0, 440.0);
            return ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: ColoredBox(
                color: Colors.black,
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      width: double.infinity,
                      height: height,
                      child: Stack(
                        alignment: Alignment.center,
                        children: <Widget>[
                          Positioned.fill(
                            child: FittedBox(
                              fit: BoxFit.contain,
                              child: SizedBox(
                                width: controller.value.size.width,
                                height: controller.value.size.height,
                                child: VideoPlayer(controller),
                              ),
                            ),
                          ),
                          Positioned.fill(
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap: () async {
                                  if (controller.value.isPlaying) {
                                    await controller.pause();
                                  } else {
                                    await controller.play();
                                  }
                                  if (mounted) setState(() {});
                                },
                              ),
                            ),
                          ),
                          AnimatedOpacity(
                            opacity: controller.value.isPlaying ? 0 : 1,
                            duration: const Duration(milliseconds: 180),
                            child: IgnorePointer(
                              child: Container(
                                width: 58,
                                height: 58,
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: .62),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.play_arrow_rounded,
                                  color: Colors.white,
                                  size: 35,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            top: 8,
                            left: 8,
                            right: 8,
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      color: Colors.black.withValues(alpha: .62),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                                      child: Text(
                                        widget.title,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                _MediaToolbar(
                                  saving: _saving,
                                  onExpand: _openFullScreen,
                                  onSave: _save,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    VideoProgressIndicator(
                      controller,
                      allowScrubbing: true,
                      colors: const VideoProgressColors(
                        playedColor: AppTheme.purpleLight,
                        bufferedColor: Color(0xFF7A7290),
                        backgroundColor: Color(0xFF252937),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 6),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _openFullScreen() async {
    await _controller?.pause();
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _FullVideoPreviewPage(
          path: widget.path,
          url: widget.url,
          title: widget.title,
          mimeType: _mediaMime(
            widget.mimeType,
            widget.path,
            widget.url,
            fallback: 'video/mp4',
          ),
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: _mediaMime(
        widget.mimeType,
        widget.path,
        widget.url,
        fallback: 'video/mp4',
      ),
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _FullVideoPreviewPage extends StatefulWidget {
  const _FullVideoPreviewPage({
    required this.path,
    required this.url,
    required this.title,
    required this.mimeType,
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_FullVideoPreviewPage> createState() => _FullVideoPreviewPageState();
}

class _FullVideoPreviewPageState extends State<_FullVideoPreviewPage>
    with WidgetsBindingObserver {
  VideoPlayerController? _controller;
  Future<void>? _initialize;
  String? _error;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = _videoController(widget.path, widget.url);
    if (_controller == null) {
      _error = 'Sumber video tidak sah.';
      return;
    }
    _initialize = _controller!.initialize().then((_) async {
      await _controller?.setLooping(false);
      await _controller?.setVolume(1);
      if (mounted) setState(() {});
    }).catchError((Object error) {
      if (mounted) setState(() => _error = error.toString());
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _controller?.pause();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: <Widget>[
          IconButton(
            tooltip: 'Simpan ke peranti',
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded),
          ),
        ],
      ),
      body: controller == null || _error != null
          ? _MediaError(title: widget.title)
          : FutureBuilder<void>(
              future: _initialize,
              builder: (context, snapshot) {
                if (snapshot.hasError) return _MediaError(title: widget.title);
                if (snapshot.connectionState != ConnectionState.done ||
                    !controller.value.isInitialized) {
                  return const Center(child: _BufferOrb());
                }
                return SafeArea(
                  child: Column(
                    children: <Widget>[
                      Expanded(
                        child: Center(
                          child: AspectRatio(
                            aspectRatio: controller.value.aspectRatio > 0
                                ? controller.value.aspectRatio
                                : 16 / 9,
                            child: VideoPlayer(controller),
                          ),
                        ),
                      ),
                      VideoProgressIndicator(
                        controller,
                        allowScrubbing: true,
                        colors: const VideoProgressColors(
                          playedColor: AppTheme.purpleLight,
                          bufferedColor: Color(0xFF7A7290),
                          backgroundColor: Color(0xFF252937),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
                        child: FilledButton.icon(
                          onPressed: () async {
                            if (controller.value.isPlaying) {
                              await controller.pause();
                            } else {
                              await controller.play();
                            }
                            if (mounted) setState(() {});
                          },
                          icon: Icon(
                            controller.value.isPlaying
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                          ),
                          label: Text(
                            controller.value.isPlaying ? 'Jeda' : 'Mainkan',
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: widget.mimeType,
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _AudioPreview extends StatefulWidget {
  const _AudioPreview({
    required this.path,
    required this.url,
    required this.title,
    this.mimeType = '',
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_AudioPreview> createState() => _AudioPreviewState();
}

class _AudioPreviewState extends State<_AudioPreview>
    with WidgetsBindingObserver {
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<Duration?>? _durationSub;
  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<PlayerState>? _stateSub;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  bool _playing = false;
  bool _ready = false;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _durationSub = _player.durationStream.listen((value) {
      if (mounted && value != null) setState(() => _duration = value);
    });
    _positionSub = _player.positionStream.listen((value) {
      if (mounted) setState(() => _position = value);
    });
    _stateSub = _player.playerStateStream.listen((value) {
      if (!mounted) return;
      setState(() {
        _playing = value.playing;
        if (value.processingState == ProcessingState.completed) {
          _playing = false;
        }
      });
    });
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _player.pause();
  }

  Future<void> _load() async {
    try {
      if (widget.path.isNotEmpty && File(widget.path).existsSync()) {
        await _player.setFilePath(widget.path);
      } else {
        final uri = _validRemoteUri(widget.url);
        if (uri == null) throw const FormatException('Sumber audio tidak sah.');
        await _player.setUrl(uri.toString());
      }
      if (mounted) setState(() => _ready = true);
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _durationSub?.cancel();
    _positionSub?.cancel();
    _stateSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final maxMs = _duration.inMilliseconds <= 0
        ? 1.0
        : _duration.inMilliseconds.toDouble();
    final value = _position.inMilliseconds.clamp(0, maxMs.toInt()).toDouble();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Row(
        children: <Widget>[
          IconButton.filled(
            onPressed: !_ready || _error != null
                ? null
                : () async {
                    if (_playing) {
                      await _player.pause();
                    } else {
                      if (_position >= _duration && _duration > Duration.zero) {
                        await _player.seek(Duration.zero);
                      }
                      await _player.play();
                    }
                  },
            icon: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                if (_error != null)
                  const Text(
                    'Audio tidak dapat dimainkan.',
                    style: TextStyle(color: AppTheme.danger, fontSize: 12),
                  )
                else
                  Slider(
                    value: value,
                    max: maxMs,
                    min: 0,
                    onChanged: _ready
                        ? (next) => _player.seek(Duration(milliseconds: next.round()))
                        : null,
                  ),
                Text(
                  '${_formatDuration(_position)} / ${_formatDuration(_duration)}',
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Simpan ke peranti',
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded),
          ),
        ],
      ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: _mediaMime(
        widget.mimeType,
        widget.path,
        widget.url,
        fallback: 'audio/mpeg',
      ),
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _MediaToolbar extends StatelessWidget {
  const _MediaToolbar({
    required this.saving,
    required this.onExpand,
    required this.onSave,
  });

  final bool saving;
  final VoidCallback onExpand;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: .66),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          IconButton(
            tooltip: 'Pratonton penuh',
            onPressed: onExpand,
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.fullscreen_rounded, color: Colors.white),
          ),
          IconButton(
            tooltip: 'Simpan ke peranti',
            onPressed: saving ? null : onSave,
            visualDensity: VisualDensity.compact,
            icon: saving
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

VideoPlayerController? _videoController(String path, String? url) {
  final local = path.isNotEmpty ? File(path) : null;
  if (local?.existsSync() ?? false) return VideoPlayerController.file(local!);
  final uri = _validRemoteUri(url);
  return uri == null ? null : VideoPlayerController.networkUrl(uri);
}

Uri? _validRemoteUri(String? value) {
  final uri = Uri.tryParse(value?.trim() ?? '');
  if (uri == null ||
      !<String>{'http', 'https'}.contains(uri.scheme) ||
      uri.host.isEmpty) {
    return null;
  }
  return uri;
}

String _mediaMime(
  String declared,
  String path,
  String? url, {
  required String fallback,
}) {
  if (declared.trim().isNotEmpty) return declared.trim();
  final source = path.isNotEmpty ? path : (url ?? '');
  final clean = source.split('?').first.toLowerCase();
  if (clean.endsWith('.png')) return 'image/png';
  if (clean.endsWith('.jpg') || clean.endsWith('.jpeg')) return 'image/jpeg';
  if (clean.endsWith('.webp')) return 'image/webp';
  if (clean.endsWith('.gif')) return 'image/gif';
  if (clean.endsWith('.mp4') || clean.endsWith('.m4v')) return 'video/mp4';
  if (clean.endsWith('.webm')) return 'video/webm';
  if (clean.endsWith('.mov')) return 'video/quicktime';
  if (clean.endsWith('.mp3')) return 'audio/mpeg';
  if (clean.endsWith('.m4a')) return 'audio/mp4';
  if (clean.endsWith('.wav')) return 'audio/wav';
  if (clean.endsWith('.ogg') || clean.endsWith('.opus')) return 'audio/ogg';
  return fallback;
}

class _FileCard extends StatelessWidget {
  const _FileCard({
    required this.title,
    required this.subtitle,
    required this.path,
    required this.url,
    required this.compact,
  });

  final String title;
  final String subtitle;
  final String path;
  final String url;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: compact
          ? Colors.white.withValues(alpha: .1)
          : const Color(0xFF0B0E16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
        side: BorderSide(
          color: compact
              ? Colors.white.withValues(alpha: .15)
              : AppTheme.outline,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: () async {
          if (path.isNotEmpty && File(path).existsSync()) {
            await OpenFilex.open(path);
            return;
          }
          final uri = Uri.tryParse(url);
          if (uri != null) {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: compact
                      ? Colors.white.withValues(alpha: .12)
                      : AppTheme.purple.withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  _fileIcon(title),
                  color: compact ? Colors.white : AppTheme.purpleLight,
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    if (subtitle.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: compact
                              ? Colors.white70
                              : AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Icon(
                Icons.open_in_new_rounded,
                size: 18,
                color: compact ? Colors.white70 : AppTheme.textSecondary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HtmlPreview extends StatefulWidget {
  const _HtmlPreview({
    required this.title,
    required this.subtitle,
    required this.html,
    required this.url,
  });

  final String title;
  final String subtitle;
  final String html;
  final String url;

  @override
  State<_HtmlPreview> createState() => _HtmlPreviewState();
}

class _HtmlPreviewState extends State<_HtmlPreview> {
  WebViewController? _controller;
  bool _loaded = false;
  bool _expanded = false;

  void _ensureController() {
    if (_controller != null || widget.html.trim().isEmpty) return;
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.disabled)
      ..setBackgroundColor(const Color(0xFFFCFCFC))
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (_) => NavigationDecision.prevent,
          onPageFinished: (_) {
            if (mounted) setState(() => _loaded = true);
          },
        ),
      )
      ..loadHtmlString(_document(widget.html));
  }

  void _togglePreview() {
    if (!_expanded) _ensureController();
    setState(() => _expanded = !_expanded);
  }

  String _document(String content) => '''
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:-apple-system,BlinkMacSystemFont,Roboto,Arial,sans-serif;margin:16px;color:#171923;background:#fff;line-height:1.5;overflow-wrap:anywhere}
img{max-width:100%;height:auto} video,audio,source,track{display:none!important} table{border-collapse:collapse;max-width:100%;display:block;overflow:auto} td,th{border:1px solid #ddd;padding:7px} a{color:#5d36c9} pre{white-space:pre-wrap;background:#f4f3f8;padding:12px;border-radius:10px} button,input,textarea,select{display:none!important}
</style>
</head>
<body>$content</body>
</html>
''';

  @override
  Widget build(BuildContext context) {
    final hasPreview = widget.html.trim().isNotEmpty;
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.outline),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(13, 11, 9, 10),
            child: Row(
              children: <Widget>[
                const Icon(
                  Icons.language_rounded,
                  size: 20,
                  color: AppTheme.cyan,
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        widget.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      if (widget.subtitle.isNotEmpty)
                        Text(
                          widget.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 11,
                          ),
                        ),
                    ],
                  ),
                ),
                if (hasPreview)
                  IconButton(
                    tooltip: _expanded ? 'Tutup pratonton' : 'Pratonton halaman',
                    onPressed: _togglePreview,
                    icon: Icon(
                      _expanded
                          ? Icons.expand_less_rounded
                          : Icons.preview_rounded,
                      size: 20,
                    ),
                  ),
                if (widget.url.isNotEmpty)
                  IconButton(
                    tooltip: 'Buka di browser luar',
                    onPressed: () async {
                      final uri = Uri.tryParse(widget.url);
                      if (uri != null) {
                        await launchUrl(
                          uri,
                          mode: LaunchMode.externalApplication,
                        );
                      }
                    },
                    icon: const Icon(Icons.open_in_new_rounded, size: 19),
                  ),
              ],
            ),
          ),
          if (_expanded && _controller != null)
            SizedBox(
              height: 360,
              child: Stack(
                children: <Widget>[
                  WebViewWidget(controller: _controller!),
                  if (!_loaded)
                    const Positioned.fill(
                      child: ColoredBox(
                        color: Color(0xFF0B0E16),
                        child: Center(child: _BufferOrb()),
                      ),
                    ),
                ],
              ),
            )
          else
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: Row(
                children: <Widget>[
                  const Icon(
                    Icons.volume_off_rounded,
                    size: 17,
                    color: AppTheme.textSecondary,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      hasPreview
                          ? 'Pratonton halaman ditutup secara lalai dan tidak memainkan audio atau video.'
                          : widget.url.isEmpty
                              ? 'Pratonton halaman tidak tersedia.'
                              : widget.url,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  if (hasPreview)
                    TextButton(
                      onPressed: _togglePreview,
                      child: const Text('Pratonton'),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _SearchResultsCard extends StatelessWidget {
  const _SearchResultsCard({required this.artifact});

  final ChatArtifact artifact;

  @override
  Widget build(BuildContext context) {
    final results = (artifact.data['results'] as List? ?? const <dynamic>[])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .take(8)
        .toList();
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(
                Icons.travel_explore_rounded,
                color: AppTheme.cyan,
                size: 21,
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  artifact.title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          if (artifact.subtitle.isNotEmpty) ...<Widget>[
            const SizedBox(height: 3),
            Text(
              artifact.subtitle,
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 12,
              ),
            ),
          ],
          if (results.isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            ...results.map(
              (result) => InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () async {
                  final uri = Uri.tryParse(result['url']?.toString() ?? '');
                  if (uri != null) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        width: 25,
                        height: 25,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceHigh,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '${result['rank'] ?? ''}',
                          style: const TextStyle(
                            color: AppTheme.purpleLight,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              result['title']?.toString() ?? 'Hasil',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              result['display_url']?.toString() ??
                                  result['url']?.toString() ??
                                  '',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppTheme.cyan,
                                fontSize: 11,
                              ),
                            ),
                            if ((result['snippet']?.toString() ?? '')
                                .isNotEmpty) ...<Widget>[
                              const SizedBox(height: 3),
                              Text(
                                result['snippet'].toString(),
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: AppTheme.textSecondary,
                                  fontSize: 12,
                                  height: 1.35,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _CompletedProcessCard extends StatefulWidget {
  const _CompletedProcessCard({required this.events, this.durationMs});

  final List<RunEvent> events;
  final int? durationMs;

  @override
  State<_CompletedProcessCard> createState() => _CompletedProcessCardState();
}

class _CompletedProcessCardState extends State<_CompletedProcessCard> {
  // Selepas task siap: tertutup sendiri. Tekan untuk buka semula.
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final failed = widget.events.any(
      (item) => item.state == RunEventState.failed,
    );
    final durationSeconds = widget.durationMs == null
        ? null
        : (widget.durationMs! / 1000).round().clamp(1, 99999);
    final label = durationSeconds == null
        ? 'Berfikir'
        : 'Berfikir selama ${durationSeconds}s';
    // Gaya ChatGPT: teks sahaja, berada sebelum jawapan dan tiada kotak.
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        InkWell(
          onTap: () => setState(() => _expanded = !_expanded),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  failed ? '$label (ada ralat)' : label,
                  style: TextStyle(
                    color: failed ? AppTheme.warning : AppTheme.textMuted,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Icon(
                  _expanded
                      ? Icons.keyboard_arrow_up_rounded
                      : Icons.keyboard_arrow_down_rounded,
                  size: 18,
                  color: AppTheme.textMuted,
                ),
              ],
            ),
          ),
        ),
        if (_expanded)
          Padding(
            padding: const EdgeInsets.only(top: 6, bottom: 4),
            child: _RunTimeline(events: widget.events),
          ),
      ],
    );
  }
}

class _LiveProcessCard extends StatefulWidget {
  const _LiveProcessCard({
    required this.events,
    required this.detail,
    this.followUpCount = 0,
    this.startedAt,
  });

  final List<RunEvent> events;
  final String detail;
  final int followUpCount;
  final DateTime? startedAt;

  @override
  State<_LiveProcessCard> createState() => _LiveProcessCardState();
}

class _LiveProcessCardState extends State<_LiveProcessCard> {
  // Semasa agent berjalan: terbuka secara lalai. Tekan untuk tutup.
  // Bila siap diganti kad selesai yang tertutup (boleh dibuka semula).
  bool _expanded = true;
  Timer? _tick;
  int _elapsedSec = 0;

  @override
  void initState() {
    super.initState();
    _elapsedSec = _computeElapsed();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _elapsedSec = _computeElapsed());
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  int _computeElapsed() {
    final start = widget.startedAt;
    if (start == null) return 0;
    return DateTime.now().difference(start).inSeconds.clamp(0, 99999);
  }

  @override
  Widget build(BuildContext context) {
    final events = widget.events;
    final header = _elapsedSec > 0
        ? 'Sedang berfikir… ${_elapsedSec}s'
        : 'Sedang berfikir…';

    // Gaya ChatGPT: teks kelabu sahaja, tiada kad/kotak.
    return InkWell(
      onTap: () => setState(() => _expanded = !_expanded),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(2, 4, 2, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  header,
                  style: const TextStyle(
                    color: AppTheme.textMuted,
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                  ),
                ),
                if (widget.events.isNotEmpty)
                  Icon(
                    _expanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    size: 18,
                    color: AppTheme.textMuted,
                  ),
              ],
            ),
              if (_expanded) ...<Widget>[
                const SizedBox(height: 10),
                if (events.isEmpty)
                  Text(
                    widget.detail.isNotEmpty
                        ? widget.detail
                        : 'Memahami permintaan',
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 12.5,
                    ),
                  )
                else
                  ...List<Widget>.generate(events.length, (index) {
                    final event = events[index];
                    return _ThinkingStep(
                      icon: _iconForEvent(event),
                      title: event.title,
                      detail: event.detail,
                      isLast: index == events.length - 1,
                      running: event.state == RunEventState.running,
                      failed: event.state == RunEventState.failed,
                      done: event.state == RunEventState.success,
                    );
                  }),
                if (widget.followUpCount > 0) ...<Widget>[
                  const SizedBox(height: 6),
                  Text(
                    '${widget.followUpCount} susulan dalam barisan',
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 12,
                    ),
                  ),
                ],
              ],
            ],
          ),
        ),
    );
  }

  IconData _iconForEvent(RunEvent event) {
    final t = event.title.toLowerCase();
    if (event.state == RunEventState.failed) return Icons.error_outline_rounded;
    if (t.contains('memahami') || t.contains('rancang') || t.contains('plan')) {
      return Icons.lightbulb_outline_rounded;
    }
    if (t.contains('shell') || t.contains('terminal') || t.contains('cmd')) {
      return Icons.terminal_rounded;
    }
    if (t.contains('browser') || t.contains('web') || t.contains('carian')) {
      return Icons.language_rounded;
    }
    if (t.contains('windows') || t.contains('pc ')) {
      return Icons.desktop_windows_outlined;
    }
    if (t.contains('fail') || t.contains('file') || t.contains('baca')) {
      return Icons.description_outlined;
    }
    if (t.contains('tulis') || t.contains('hasil') || t.contains('jawab')) {
      return Icons.edit_note_rounded;
    }
    return Icons.circle_outlined;
  }
}

class _ThinkingStep extends StatefulWidget {
  const _ThinkingStep({
    required this.icon,
    required this.title,
    this.detail = '',
    required this.isLast,
    this.running = false,
    this.failed = false,
    this.done = false,
  });

  final IconData icon;
  final String title;
  final String detail;
  final bool isLast;
  final bool running;
  final bool failed;
  final bool done;

  @override
  State<_ThinkingStep> createState() => _ThinkingStepState();
}

class _ThinkingStepState extends State<_ThinkingStep> {
  late bool _open;

  @override
  void initState() {
    super.initState();
    // Arahan shell / command panjang: terbuka supaya user terus nampak.
    _open = _looksLikeCommand || widget.detail.trim().length > 80;
  }

  bool get _looksLikeCommand {
    final d = widget.detail.trim();
    if (d.isEmpty) return false;
    final lower = d.toLowerCase();
    final title = widget.title.toLowerCase();
    if (title.contains('shell') ||
        title.contains('terminal') ||
        title.contains('cmd') ||
        title.contains('exe')) {
      return true;
    }
    return lower.startsWith('apk ') ||
        lower.startsWith('wine ') ||
        lower.startsWith('python') ||
        lower.startsWith('cd ') ||
        lower.startsWith('git ') ||
        lower.startsWith('curl ') ||
        lower.startsWith('wget ') ||
        lower.startsWith('sh ') ||
        lower.startsWith('bash ') ||
        lower.contains('&&') ||
        lower.contains('|') ||
        lower.contains('--') ||
        lower.startsWith('http');
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.failed
        ? AppTheme.danger
        : widget.running
            ? AppTheme.textSecondary
            : AppTheme.textMuted;
    final detail = widget.detail.trim();
    final canExpand = detail.length > 60 || _looksLikeCommand;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          SizedBox(
            width: 28,
            child: Column(
              children: <Widget>[
                Icon(widget.icon, size: 18, color: color),
                if (!widget.isLast)
                  Expanded(
                    child: Container(
                      width: 1.5,
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      color: const Color(0xFF2A3344),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: widget.isLast ? 0 : 14),
              child: InkWell(
                onTap: canExpand ? () => setState(() => _open = !_open) : null,
                borderRadius: BorderRadius.circular(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            widget.title,
                            style: TextStyle(
                              color: color,
                              fontSize: 13.5,
                              fontWeight:
                                  widget.running ? FontWeight.w600 : FontWeight.w500,
                              height: 1.3,
                            ),
                          ),
                        ),
                        if (canExpand)
                          Icon(
                            _open
                                ? Icons.keyboard_arrow_up_rounded
                                : Icons.keyboard_arrow_down_rounded,
                            size: 16,
                            color: AppTheme.textMuted,
                          ),
                      ],
                    ),
                    if (detail.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: _open || !canExpand
                            ? Container(
                                width: double.infinity,
                                padding: _looksLikeCommand
                                    ? const EdgeInsets.fromLTRB(8, 6, 8, 6)
                                    : EdgeInsets.zero,
                                decoration: _looksLikeCommand
                                    ? BoxDecoration(
                                        color: const Color(0xFF12171F),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: const Color(0xFF243044),
                                        ),
                                      )
                                    : null,
                                child: Text(
                                  detail,
                                  style: TextStyle(
                                    color: AppTheme.textMuted,
                                    fontSize: 12,
                                    height: 1.4,
                                    fontFamily:
                                        _looksLikeCommand ? 'monospace' : null,
                                  ),
                                ),
                              )
                            : Text(
                                detail,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: AppTheme.textMuted,
                                  fontSize: 12,
                                  height: 1.35,
                                ),
                              ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RunTimeline extends StatelessWidget {
  const _RunTimeline({required this.events});

  final List<RunEvent> events;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: events
          .map(
            (event) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: _RunEventIcon(event: event),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          event.title,
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        if (event.detail.isNotEmpty)
                          Text(
                            event.detail,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 11.5,
                              height: 1.35,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
    );
  }
}

class _RunEventIcon extends StatelessWidget {
  const _RunEventIcon({required this.event});

  final RunEvent event;

  @override
  Widget build(BuildContext context) {
    return switch (event.state) {
      RunEventState.running => const SizedBox(
          width: 15,
          height: 15,
          child: CircularProgressIndicator(strokeWidth: 1.8),
        ),
      RunEventState.success => const Icon(
          Icons.check_circle_rounded,
          size: 16,
          color: AppTheme.success,
        ),
      RunEventState.failed => const Icon(
          Icons.error_rounded,
          size: 16,
          color: AppTheme.danger,
        ),
      RunEventState.waiting => const Icon(
          Icons.hourglass_top_rounded,
          size: 16,
          color: AppTheme.warning,
        ),
      RunEventState.info => const Icon(
          Icons.circle_rounded,
          size: 9,
          color: AppTheme.cyan,
        ),
    };
  }
}

class _Composer extends StatelessWidget {
  const _Composer({
    required this.controller,
    required this.attachments,
    required this.listening,
    required this.sending,
    required this.onAttach,
    required this.onRemoveAttachment,
    required this.onVoice,
    required this.onSend,
    required this.onStop,
  });

  final TextEditingController controller;
  final List<ChatAttachment> attachments;
  final bool listening;
  final bool sending;
  final VoidCallback onAttach;
  final Future<void> Function(ChatAttachment attachment) onRemoveAttachment;
  final VoidCallback onVoice;
  final VoidCallback onSend;
  final VoidCallback onStop;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
        decoration: const BoxDecoration(
          color: Color(0xFF090C14),
          border: Border(
            top: BorderSide(color: Color(0xFF171D2A), width: .8),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (attachments.isNotEmpty) ...<Widget>[
              SizedBox(
                height: 68,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: attachments.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final item = attachments[index];
                    return Container(
                      width: 190,
                      padding: const EdgeInsets.fromLTRB(9, 8, 5, 8),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceHigh,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: AppTheme.outline),
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: AppTheme.purple.withValues(alpha: .12),
                              borderRadius: BorderRadius.circular(11),
                            ),
                            child: Icon(
                              _attachmentIcon(item.kind),
                              size: 19,
                              color: AppTheme.purpleLight,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              item.name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            tooltip: 'Buang',
                            onPressed: sending
                                ? null
                                : () => onRemoveAttachment(item),
                            icon: const Icon(Icons.close_rounded, size: 18),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
            ],
            Container(
              decoration: BoxDecoration(
                color: AppTheme.surfaceHigh,
                borderRadius: BorderRadius.circular(23),
                border: Border.all(color: const Color(0xFF282F41)),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: Colors.black.withValues(alpha: .14),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 4),
                    child: IconButton(
                      tooltip: 'Lampirkan fail',
                      onPressed: sending ? null : onAttach,
                      icon: const Icon(Icons.add_rounded),
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 6,
                      textCapitalization: TextCapitalization.sentences,
                      keyboardType: TextInputType.multiline,
                      textInputAction: TextInputAction.newline,
                      decoration: InputDecoration(
                        hintText: sending ? 'Tulis susulan…' : 'Tulis arahan…',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding:
                            const EdgeInsets.fromLTRB(5, 15, 8, 15),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: IconButton(
                      tooltip: listening ? 'Henti suara' : 'Input suara',
                      onPressed: onVoice,
                      icon: Icon(
                        listening
                            ? Icons.graphic_eq_rounded
                            : Icons.mic_none_rounded,
                        color: listening
                            ? AppTheme.danger
                            : AppTheme.textSecondary,
                      ),
                    ),
                  ),
                  if (sending)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: IconButton(
                        tooltip: 'Hentikan AI',
                        onPressed: onStop,
                        icon: const Icon(
                          Icons.stop_circle_outlined,
                          color: AppTheme.danger,
                        ),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 4, 5, 4),
                    child: IconButton.filled(
                      tooltip: sending ? 'Hantar susulan' : 'Hantar',
                      onPressed: onSend,
                      style: IconButton.styleFrom(
                        backgroundColor: AppTheme.surfaceHighest,
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: AppTheme.outline),
                      ),
                      icon: const Icon(Icons.arrow_upward_rounded),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BufferOrb extends StatefulWidget {
  const _BufferOrb({this.size = 40});

  final double size;

  @override
  State<_BufferOrb> createState() => _BufferOrbState();
}

class _BufferOrbState extends State<_BufferOrb>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1300),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) => CustomPaint(
          painter: _OrbPainter(progress: _controller.value),
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  const _OrbPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.shortestSide * .34;
    final glow = Paint()
      ..shader = const RadialGradient(
        colors: <Color>[
          Color(0xFFB9A2FF),
          Color(0x668E63FF),
          Color(0x008E63FF),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius * 1.5));
    canvas.drawCircle(center, radius * 1.5, glow);

    for (var i = 0; i < 3; i++) {
      final phase = (progress + i / 3) % 1;
      final angle = phase * 6.283185307179586;
      final point = Offset(
        center.dx + radius * math.cos(angle),
        center.dy + radius * math.sin(angle),
      );
      final dot = Paint()
        ..color = Color.lerp(
              AppTheme.purpleLight,
              AppTheme.cyan,
              i / 2,
            ) ??
            AppTheme.purpleLight;
      canvas.drawCircle(point, size.shortestSide * .09, dot);
    }
    canvas.drawCircle(
      center,
      size.shortestSide * .12,
      Paint()..color = Colors.white.withValues(alpha: .9),
    );
  }

  @override
  bool shouldRepaint(covariant _OrbPainter oldDelegate) =>
      oldDelegate.progress != progress;
}



class _MediaError extends StatelessWidget {
  const _MediaError({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceHigh,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Row(
        children: <Widget>[
          const Icon(
            Icons.broken_image_outlined,
            color: AppTheme.danger,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title.isEmpty ? 'Media' : title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                const Text(
                  'Media tidak dapat dipaparkan.',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

IconData _fileIcon(String name) {
  final extension = name.toLowerCase().split('.').last;
  return switch (extension) {
    'png' || 'jpg' || 'jpeg' || 'gif' || 'webp' || 'bmp' || 'svg' =>
      Icons.image_outlined,
    'mp4' || 'mkv' || 'mov' || 'avi' || 'webm' || 'm4v' =>
      Icons.movie_outlined,
    'mp3' || 'wav' || 'm4a' || 'aac' || 'flac' || 'ogg' =>
      Icons.audio_file_outlined,
    'pdf' => Icons.picture_as_pdf_outlined,
    'doc' || 'docx' || 'odt' || 'rtf' || 'txt' || 'md' =>
      Icons.description_outlined,
    'xls' || 'xlsx' || 'ods' || 'csv' => Icons.table_chart_outlined,
    'ppt' || 'pptx' || 'odp' => Icons.slideshow_outlined,
    'zip' || 'rar' || '7z' || 'tar' || 'gz' || 'xz' =>
      Icons.folder_zip_outlined,
    'dart' || 'kt' || 'java' || 'py' || 'js' || 'ts' || 'html' ||
    'css' || 'json' || 'xml' || 'yaml' || 'yml' || 'sh' || 'rs' ||
    'go' || 'c' || 'cpp' || 'h' => Icons.code_rounded,
    _ => Icons.insert_drive_file_outlined,
  };
}

IconData _attachmentIcon(AttachmentKind kind) {
  return switch (kind) {
    AttachmentKind.image => Icons.image_outlined,
    AttachmentKind.video => Icons.movie_outlined,
    AttachmentKind.audio => Icons.audio_file_outlined,
    AttachmentKind.document => Icons.description_outlined,
    AttachmentKind.archive => Icons.folder_zip_outlined,
    AttachmentKind.code => Icons.code_rounded,
    AttachmentKind.other => Icons.attach_file_rounded,
  };
}

String _formatBytes(int bytes) {
  if (bytes >= 1024 * 1024 * 1024) {
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
  if (bytes >= 1024 * 1024) {
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
  if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '$bytes B';
}

String _formatDuration(Duration value) {
  final minutes = value.inMinutes.remainder(60).toString().padLeft(2, '0');
  final seconds = value.inSeconds.remainder(60).toString().padLeft(2, '0');
  if (value.inHours > 0) {
    return '${value.inHours}:$minutes:$seconds';
  }
  return '$minutes:$seconds';
}

