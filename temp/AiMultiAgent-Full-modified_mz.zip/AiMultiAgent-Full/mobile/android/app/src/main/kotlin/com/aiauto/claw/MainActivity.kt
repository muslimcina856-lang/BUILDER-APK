package com.aiauto.claw

import android.app.UiModeManager
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import android.webkit.WebSettings
import io.flutter.FlutterInjector
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

class MainActivity : FlutterActivity() {
    private val deviceChannelName = "com.aiauto.claw/device"
    private val browserChannelName = "com.aiauto.claw/browser"
    private val mediaChannelName = "com.aiauto.claw/media"
    private val saveFileRequestCode = 7104
    private var browserEngine: BackgroundBrowserEngine? = null
    private var pendingSaveResult: MethodChannel.Result? = null
    private var pendingSaveSource: File? = null

    override fun onResume() {
        super.onResume()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        browserEngine?.silenceMedia()
    }

    override fun onPause() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        browserEngine?.silenceMedia()
        super.onPause()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, deviceChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getDeviceInfo", "getRuntimeContext" -> result.success(runtimeContext())
                    "copyBundledAsset" -> copyBundledAsset(call, result)
                    "startExecutionKeepAlive" -> {
                        val maxDurationMs = call.argument<Number>("maxDurationMs")?.toLong()
                            ?: 30L * 60L * 1000L
                        try {
                            ExecutionKeepAliveService.start(this, maxDurationMs)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error(
                                "foreground_service_start_failed",
                                error.message ?: error.javaClass.simpleName,
                                null,
                            )
                        }
                    }
                    "stopExecutionKeepAlive" -> {
                        ExecutionKeepAliveService.stop(this)
                        result.success(null)
                    }
                    "openNotificationSettings" -> {
                        try {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            }
                            startActivity(intent)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error("settings_unavailable", error.message, null)
                        }
                    }
                    "openAppSettings" -> {
                        try {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:$packageName"),
                            )
                            startActivity(intent)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error("settings_unavailable", error.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        browserEngine = BackgroundBrowserEngine(this)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, browserChannelName)
            .setMethodCallHandler { call, result ->
                browserEngine?.handle(call, result)
                    ?: result.error("browser_unavailable", "Enjin browser tidak tersedia.", null)
            }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, mediaChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "saveFile" -> beginSaveFile(call, result)
                    else -> result.notImplemented()
                }
            }
    }

    private fun copyBundledAsset(call: MethodCall, result: MethodChannel.Result) {
        val assetPath = call.argument<String>("assetPath").orEmpty()
        val destinationPath = call.argument<String>("destinationPath").orEmpty()
        val expectedSha256 = call.argument<String>("expectedSha256").orEmpty().lowercase()
        val maxBytes = call.argument<Number>("maxBytes")?.toLong() ?: 0L
        val destination = File(destinationPath)
        if (assetPath.isBlank() ||
            !Regex("^[0-9a-f]{64}$").matches(expectedSha256) ||
            maxBytes <= 0L ||
            !isPrivateAppFile(destination)) {
            result.error("invalid_asset_copy", "Parameter salinan runtime tidak sah.", null)
            return
        }

        Thread {
            val temporary = File(destination.parentFile, "${destination.name}.part")
            try {
                destination.parentFile?.mkdirs()
                if (temporary.exists()) temporary.delete()
                val key = FlutterInjector.instance()
                    .flutterLoader()
                    .getLookupKeyForAsset(assetPath)
                val digest = MessageDigest.getInstance("SHA-256")
                var total = 0L
                assets.open(key).use { input ->
                    FileOutputStream(temporary).use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            total += count
                            if (total > maxBytes) {
                                throw IllegalStateException("Asset runtime melebihi had keselamatan.")
                            }
                            digest.update(buffer, 0, count)
                            output.write(buffer, 0, count)
                        }
                        output.fd.sync()
                    }
                }
                val actual = digest.digest().joinToString("") { "%02x".format(it) }
                if (total <= 0L || actual != expectedSha256) {
                    throw IllegalStateException("SHA-256 runtime bawaan APK tidak sepadan.")
                }
                if (destination.exists() && !destination.delete()) {
                    throw IllegalStateException("Fail runtime lama tidak boleh diganti.")
                }
                if (!temporary.renameTo(destination)) {
                    throw IllegalStateException("Fail runtime sementara tidak boleh diaktifkan.")
                }
                runOnUiThread {
                    result.success(mapOf("bytes" to total, "sha256" to actual))
                }
            } catch (error: Throwable) {
                temporary.delete()
                runOnUiThread {
                    result.error(
                        "asset_copy_failed",
                        error.message ?: error.javaClass.simpleName,
                        null,
                    )
                }
            }
        }.start()
    }

    private fun beginSaveFile(call: MethodCall, result: MethodChannel.Result) {
        if (pendingSaveResult != null) {
            result.error("save_busy", "Pemilih lokasi simpan sedang digunakan.", null)
            return
        }
        val rawPath = call.argument<String>("path").orEmpty()
        val source = File(rawPath)
        if (!source.isFile || !isPrivateAppFile(source)) {
            result.error("invalid_source", "Fail sumber tidak sah atau berada di luar storan aplikasi.", null)
            return
        }
        val fileName = call.argument<String>("fileName")
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: source.name
        val mimeType = call.argument<String>("mimeType")
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: "application/octet-stream"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mimeType
            putExtra(Intent.EXTRA_TITLE, fileName)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        pendingSaveResult = result
        pendingSaveSource = source
        try {
            startActivityForResult(intent, saveFileRequestCode)
        } catch (error: Throwable) {
            clearPendingSave()
            result.error("save_picker_unavailable", error.message ?: error.javaClass.simpleName, null)
        }
    }

    private fun isPrivateAppFile(file: File): Boolean {
        val sourcePath = file.canonicalFile.path
        val roots = listOf(filesDir, cacheDir, noBackupFilesDir)
        return roots.any { root ->
            val rootPath = root.canonicalFile.path
            sourcePath == rootPath || sourcePath.startsWith("$rootPath${File.separator}")
        }
    }

    @Deprecated("Deprecated in Android API but required for ACTION_CREATE_DOCUMENT result handling.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != saveFileRequestCode) return
        val callback = pendingSaveResult ?: return
        val source = pendingSaveSource
        val target = data?.data
        if (resultCode != Activity.RESULT_OK || source == null || target == null) {
            clearPendingSave()
            callback.success(mapOf("success" to false, "cancelled" to true))
            return
        }
        Thread {
            try {
                val output = contentResolver.openOutputStream(target, "w")
                    ?: throw IllegalStateException("Lokasi simpan tidak dapat dibuka.")
                FileInputStream(source).use { input ->
                    output.use { destination -> input.copyTo(destination, DEFAULT_BUFFER_SIZE) }
                }
                runOnUiThread {
                    clearPendingSave()
                    callback.success(
                        mapOf(
                            "success" to true,
                            "cancelled" to false,
                            "uri" to target.toString(),
                        ),
                    )
                }
            } catch (error: Throwable) {
                runOnUiThread {
                    clearPendingSave()
                    callback.error("save_failed", error.message ?: error.javaClass.simpleName, null)
                }
            }
        }.start()
    }

    private fun clearPendingSave() {
        pendingSaveResult = null
        pendingSaveSource = null
    }

    private fun runtimeContext(): Map<String, Any?> {
        val uiModeManager = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val deviceType = when (uiModeManager.currentModeType) {
            Configuration.UI_MODE_TYPE_TELEVISION -> "android-tv"
            Configuration.UI_MODE_TYPE_CAR -> "android-auto"
            Configuration.UI_MODE_TYPE_WATCH -> "android-watch"
            else -> if (resources.configuration.smallestScreenWidthDp >= 600) {
                "android-tablet"
            } else {
                "android-phone"
            }
        }
        val packageInfo = packageManager.getPackageInfo(packageName, 0)
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            packageInfo.versionCode.toLong()
        }
        return mapOf(
            "platform" to "android",
            "deviceType" to deviceType,
            "manufacturer" to Build.MANUFACTURER,
            "brand" to Build.BRAND,
            "model" to Build.MODEL,
            "androidRelease" to Build.VERSION.RELEASE,
            "sdk" to Build.VERSION.SDK_INT,
            "primaryAbi" to Build.SUPPORTED_ABIS.firstOrNull(),
            "supportedAbis" to Build.SUPPORTED_ABIS.toList(),
            "builtInLinuxGuestAbi" to if (BuildConfig.FULL_LINUX_EDITION) "arm64-v8a" else null,
            "packageName" to packageName,
            "versionName" to packageInfo.versionName,
            "versionCode" to versionCode,
            "applicationTargetSdk" to applicationInfo.targetSdkVersion,
            "fullEdition" to BuildConfig.FULL_LINUX_EDITION,
            "embeddedBrowserAvailable" to true,
            "embeddedBrowserEngine" to "Android System WebView/Chromium",
            "embeddedBrowserUserAgent" to WebSettings.getDefaultUserAgent(this),
            "browserDefaultMode" to "desktop-emulation",
            "remotePcAccess" to false,
            "remotePcNote" to
                "Aplikasi tidak boleh melihat PC jauh atau tab browser sedia ada tanpa sambungan MCP/companion yang dipasang dan diberi akses oleh pengguna.",
        )
    }

    override fun onDestroy() {
        pendingSaveResult?.error("activity_destroyed", "Aktiviti ditutup sebelum fail sempat disimpan.", null)
        clearPendingSave()
        browserEngine?.destroy()
        browserEngine = null
        super.onDestroy()
    }
}
