# Cyber Basic — ALZZXNXX
Flutter Android cybersecurity learning/utility app.

20+ modules: password generator/strength, ASCII/text/templates, SHA-256,
Base64, Hex, JSON, URL analyzer, UUID, token, timestamp, file analyzer,
file vault/integrity, cybersecurity lessons, TikTok learning searches,
roadmap, CTF checklist, device info, notes, activity, settings and about.

File analysis is heuristic only and is NOT an antivirus. Storage is accessed only
after the user explicitly selects a file.

Build with Flutter stable + JDK 17:
flutter pub get
flutter analyze
flutter build apk --debug
