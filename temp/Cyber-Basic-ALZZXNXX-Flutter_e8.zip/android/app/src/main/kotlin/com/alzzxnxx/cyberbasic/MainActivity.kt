package com.alzzxnxx.cyberbasic
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
