package com.aiuhdhub.app.utils

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext

object UhdUpscaleEngine {

    suspend fun upscaleImage(
        inputBitmap: Bitmap,
        scaleFactor: Float,
        denoiseLevel: Float, // 0.0 to 1.0
        sharpenIntensity: Float // 0.0 to 1.0
    ): Bitmap = withContext(Dispatchers.Default) {
        // 1. Hadkan saiz input untuk mengelakkan OutOfMemory dan memastikan kelajuan (Max 1200px)
        val maxInputDim = 1200
        val srcWidth = inputBitmap.width
        val srcHeight = inputBitmap.height
        
        val (tempWidth, tempHeight) = if (srcWidth > maxInputDim || srcHeight > maxInputDim) {
            val ratio = srcWidth.toFloat() / srcHeight.toFloat()
            if (srcWidth > srcHeight) {
                maxInputDim to (maxInputDim / ratio).toInt()
            } else {
                (maxInputDim * ratio).toInt() to maxInputDim
            }
        } else {
            srcWidth to srcHeight
        }

        val resizedSrc = Bitmap.createScaledBitmap(inputBitmap, tempWidth, tempHeight, true)

        // 2. Kira saiz output berdasarkan skala (2x, 3x, 4x)
        val targetWidth = (tempWidth * scaleFactor).toInt()
        val targetHeight = (tempHeight * scaleFactor).toInt()

        // Skalakan ke saiz sasaran dengan Dwilinar/Dwikubik (filter=true)
        val scaledBitmap = Bitmap.createScaledBitmap(resizedSrc, targetWidth, targetHeight, true)

        // 3. Wujudkan bitmap salinan untuk manipulasi piksel
        val outputBitmap = scaledBitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        val width = outputBitmap.width
        val height = outputBitmap.height

        // 4. Jalankan Pemprosesan Penajaman (Sharpening Convolution) & Denoising secara selari (Multi-threaded)
        if (sharpenIntensity > 0f || denoiseLevel > 0f) {
            val srcPixels = IntArray(width * height)
            val destPixels = IntArray(width * height)
            outputBitmap.getPixels(srcPixels, 0, width, 0, 0, width, height)

            // Bahagikan kerja kepada beberapa thread berdasarkan baris imej (Coroutines)
            val numCores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
            val chunkSize = (height / numCores).coerceAtLeast(1)
            
            val deferreds = (0 until numCores).map { coreIndex ->
                async(Dispatchers.Default) {
                    val startY = coreIndex * chunkSize
                    val endY = if (coreIndex == numCores - 1) height else (coreIndex + 1) * chunkSize
                    
                    val k = sharpenIntensity * 0.4f // Hadkan penajaman maksima supaya natural
                    val d = denoiseLevel * 0.5f // Faktor denoising

                    for (y in startY until endY) {
                        for (x in 0 until width) {
                            val idx = y * width + x

                            // Untuk piksel sempadan, kekalkan piksel asal
                            if (x == 0 || x == width - 1 || y == 0 || y == height - 1) {
                                destPixels[idx] = srcPixels[idx]
                                continue
                            }

                            // Dapatkan nilai piksel semasa dan jiran terdekat (untuk sharpening kernel)
                            val center = srcPixels[idx]
                            val left = srcPixels[idx - 1]
                            val right = srcPixels[idx + 1]
                            val top = srcPixels[idx - width]
                            val bottom = srcPixels[idx + width]

                            // Extract RGB
                            val cR = (center shr 16) and 0xFF
                            val cG = (center shr 8) and 0xFF
                            val cB = center and 0xFF
                            val cA = (center shr 24) and 0xFF

                            var rR = cR.toFloat()
                            var rG = cG.toFloat()
                            var rB = cB.toFloat()

                            // A. Apply Denoise (Bilateral/Blur Ringkas untuk melembutkan hingar)
                            if (d > 0f) {
                                val lR = (left shr 16) and 0xFF
                                val lG = (left shr 8) and 0xFF
                                val lB = left and 0xFF

                                val rR_ = (right shr 16) and 0xFF
                                val rG_ = (right shr 8) and 0xFF
                                val rB_ = right and 0xFF

                                val tR = (top shr 16) and 0xFF
                                val tG = (top shr 8) and 0xFF
                                val tB = top and 0xFF

                                val bR = (bottom shr 16) and 0xFF
                                val bG = (bottom shr 8) and 0xFF
                                val bB = bottom and 0xFF

                                // Purata berwujud (Denoising)
                                val avgR = (cR + lR + rR_ + tR + bR) / 5f
                                val avgG = (cG + lG + rG_ + tG + bG) / 5f
                                val avgB = (cB + lB + rB_ + tB + bB) / 5f

                                rR = rR * (1f - d) + avgR * d
                                rG = rG * (1f - d) + avgG * d
                                rB = rB * (1f - d) + avgB * d
                            }

                            // B. Apply Sharpen (Convolution 3x3 laplacian)
                            if (k > 0f) {
                                val lR = (left shr 16) and 0xFF
                                val lG = (left shr 8) and 0xFF
                                val lB = left and 0xFF

                                val rR_ = (right shr 16) and 0xFF
                                val rG_ = (right shr 8) and 0xFF
                                val rB_ = right and 0xFF

                                val tR = (top shr 16) and 0xFF
                                val tG = (top shr 8) and 0xFF
                                val tB = top and 0xFF

                                val bR = (bottom shr 16) and 0xFF
                                val bG = (bottom shr 8) and 0xFF
                                val bB = bottom and 0xFF

                                // Kira beza untuk menajamkan sempadan objek
                                val diffR = (4 * rR - (lR + rR_ + tR + bR))
                                val diffG = (4 * rG - (lG + rG_ + tG + bG))
                                val diffB = (4 * rB - (lB + rB_ + tB + bB))

                                rR = (rR + diffR * k).coerceIn(0f, 255f)
                                rG = (rG + diffG * k).coerceIn(0f, 255f)
                                rB = (rB + diffB * k).coerceIn(0f, 255f)
                            }

                            destPixels[idx] = (cA shl 24) or (rR.toInt() shl 16) or (rG.toInt() shl 8) or rB.toInt()
                        }
                    }
                }
            }
            deferreds.awaitAll()
            outputBitmap.setPixels(destPixels, 0, width, 0, 0, width, height)
        }

        // 5. Apply Color Enhancement (Vibrancy & Contrast) melalui hardware-accelerated Canvas & Paint
        val finalBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(finalBitmap)
        val paint = Paint()

        // Bina matriks warna untuk mempertingkatkan kontras (1.05x) dan ketepuan (1.1x) untuk "AI UHD Look"
        val contrast = 1.06f
        val saturation = 1.12f
        val brightness = 2f // Sedikit mencerahkan bayang (shadows)

        val cm = ColorMatrix().apply {
            // Skala ketepuan warna
            setSaturation(saturation)
            
            // Adjust Contrast
            val scale = contrast
            val translate = (-.5f * scale + .5f) * 255f + brightness
            postConcat(ColorMatrix(floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )))
        }

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(outputBitmap, 0f, 0f, paint)

        // Bersihkan memori intermediate
        scaledBitmap.recycle()
        outputBitmap.recycle()
        if (resizedSrc != inputBitmap) {
            resizedSrc.recycle()
        }

        finalBitmap
    }
}
