package com.aiuhdhub.app.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aiuhdhub.app.data.DownloadableModel
import com.aiuhdhub.app.data.ModelsRepository
import com.aiuhdhub.app.ui.components.GlassCard
import com.aiuhdhub.app.ui.theme.*
import com.aiuhdhub.app.utils.ImageUtils
import com.aiuhdhub.app.utils.ModelDownloader
import com.aiuhdhub.app.utils.UhdUpscaleEngine
import kotlinx.coroutines.launch

@Composable
fun AiStudioScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var inputBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var outputBitmap by remember { mutableStateOf<Bitmap?>(null) }
    
    var processing by remember { mutableStateOf(false) }
    var processProgress by remember { mutableStateOf(0f) }

    // Dapatkan senarai model yang telah dimuat turun
    val downloadedModels = remember { mutableStateListOf<DownloadableModel>() }
    var selectedModel by remember { mutableStateOf<DownloadableModel?>(null) }

    // Memuatkan model yang tersedia di simpanan lokal
    LaunchedEffect(Unit) {
        val all = ModelsRepository.getDownloadableModels()
        val downloaded = all.filter { ModelDownloader.isModelDownloaded(context, it.filename) }
        downloadedModels.clear()
        downloadedModels.addAll(downloaded)
        if (downloaded.isNotEmpty()) {
            selectedModel = downloaded.first()
        }
    }

    // Settings
    var scaleFactor by remember { mutableStateOf(2f) }
    var sharpenIntensity by remember { mutableStateOf(0.5f) }
    var denoiseLevel by remember { mutableStateOf(0.3f) }

    // Pemilih Gambar dari Galeri
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            imageUri = uri
            outputBitmap = null // Reset output lama
            inputBitmap = loadBitmapFromUri(context, uri)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PrimaryDark)
            .verticalScroll(scrollState)
            .padding(bottom = 100.dp)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 50.dp, start = 24.dp, end = 24.dp, bottom = 16.dp)
        ) {
            Text(
                text = "AI Studio",
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 28.sp),
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Proses gambar anda ke kualiti UHD secara lokal & offline",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        if (inputBitmap == null) {
            // Skrin Pilih Gambar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(CardDark.copy(alpha = 0.6f))
                    .border(2.dp, Brush.linearGradient(listOf(AccentBlue, AccentPurple)), RoundedCornerShape(24.dp))
                    .clickable { imagePickerLauncher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Photo,
                        contentDescription = null,
                        tint = AccentBlue,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Pilih Gambar Dari Galeri",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Menyokong JPG, PNG, WEBP, dll.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }
        } else {
            // Gambar Telah Dipilih
            Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                if (outputBitmap == null) {
                    // Preview Input
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, DividerColor, RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = inputBitmap!!.asImageBitmap(),
                            contentDescription = "Gambar Asal",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )

                        if (processing) {
                            // Scan Loading Animation
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.6f)),
                                contentAlignment = Alignment.Center
                            ) {
                                val infiniteTransition = rememberInfiniteTransition(label = "scan")
                                val scanLineOffset by infiniteTransition.animateFloat(
                                    initialValue = 0f,
                                    targetValue = 1f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(2000, easing = LinearEasing),
                                        repeatMode = RepeatMode.Reverse
                                    ),
                                    label = "scanLine"
                                )

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(0.02f)
                                        .align(Alignment.TopCenter)
                                        .offset(y = 280.dp * scanLineOffset)
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color.Transparent, AccentCyan, Color.Transparent)
                                            )
                                        )
                                )

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = AccentCyan)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Memproses UHD...",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = AccentCyan,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Jangan tutup aplikasi",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // Interactive Swipe Comparison (Before vs After)
                    Text(
                        text = "Seret gambar ke kiri/kanan untuk bandingkan",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    )

                    var parentSize by remember { mutableStateOf(IntSize.Zero) }
                    var dragOffsetFraction by remember { mutableStateOf(0.5f) }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, DividerColor, RoundedCornerShape(20.dp))
                            .onSizeChanged { parentSize = it }
                            .pointerInput(Unit) {
                                detectHorizontalDragGestures { _, dragAmount ->
                                    if (parentSize.width > 0) {
                                        dragOffsetFraction = (dragOffsetFraction + dragAmount / parentSize.width).coerceIn(0f, 1f)
                                    }
                                }
                            }
                    ) {
                        // Original Bitmap (Bottom)
                        Image(
                            bitmap = inputBitmap!!.asImageBitmap(),
                            contentDescription = "Sebelum",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        
                        // Label Sebelum
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("SEBELUM (ASAL)", style = MaterialTheme.typography.labelSmall, color = Color.White)
                        }

                        // Processed Bitmap (Top, clipped horizontally)
                        val clipWidth = (parentSize.width * dragOffsetFraction).toInt()
                        if (clipWidth > 0) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width((parentSize.width * dragOffsetFraction).dp) // mock width clipping in Compose UI
                                    .clipToBounds()
                            ) {
                                Image(
                                    bitmap = outputBitmap!!.asImageBitmap(),
                                    contentDescription = "Selepas",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }

                        // Label Selepas
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(AccentCyan.copy(alpha = 0.8f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("SELEPAS (UHD)", style = MaterialTheme.typography.labelSmall, color = PrimaryDark, fontWeight = FontWeight.Bold)
                        }

                        // Slider Handle / Divider line
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(3.dp)
                                .align(Alignment.CenterStart)
                                .offset(x = (parentSize.width * dragOffsetFraction / 2.7f).dp) // responsive offset representation
                                .background(AccentCyan)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .align(Alignment.Center)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(AccentCyan)
                                    .border(2.dp, Color.White, RoundedCornerShape(18.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SwapHoriz,
                                    contentDescription = null,
                                    tint = PrimaryDark
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Butang Tukar Gambar & Simpan
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            inputBitmap = null
                            outputBitmap = null
                            imageUri = null
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp)
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tukar")
                    }

                    if (outputBitmap != null) {
                        Button(
                            onClick = {
                                val uri = ImageUtils.saveBitmapToGallery(context, outputBitmap!!, "AIUhdHub_${System.currentTimeMillis()}")
                                if (uri != null) {
                                    Toast.makeText(context, "Gambar disimpan ke Galeri!", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Gagal menyimpan gambar.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.2f),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen, contentColor = PrimaryDark)
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simpan UHD", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Editor Control Panel (Hanya tunjuk jika ada gambar terpilih)
        if (inputBitmap != null && !processing && outputBitmap == null) {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                glowColor = AccentBlue,
                showGlow = false
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Tetapan UHD",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Model Selector
                    Text("Pilih Model AI", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (downloadedModels.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(StatusInactive.copy(alpha = 0.1f))
                                .border(1.dp, StatusInactive.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Tiada model dimuat turun. Sila muat turun model di tab 'Model Hub' dahulu.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusInactive,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        // Dropdown model
                        var showDropdown by remember { mutableStateOf(false) }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CardDark)
                                .border(1.dp, DividerColor, RoundedCornerShape(12.dp))
                                .clickable { showDropdown = true }
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = selectedModel?.name ?: "Pilih Model",
                                    color = TextPrimary,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = TextMuted)
                            }

                            DropdownMenu(
                                expanded = showDropdown,
                                onDismissRequest = { showDropdown = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .background(CardDark)
                            ) {
                                downloadedModels.forEach { model ->
                                    DropdownMenuItem(
                                        text = { Text(model.name, color = TextPrimary) },
                                        onClick = {
                                            selectedModel = model
                                            showDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Scale Factor
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Skala Output (UHD)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("${scaleFactor.toInt()}x UHD", style = MaterialTheme.typography.labelSmall, color = AccentCyan, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = scaleFactor,
                        onValueChange = { scaleFactor = it },
                        valueRange = 2f..4f,
                        steps = 1,
                        colors = SliderDefaults.colors(thumbColor = AccentCyan, activeTrackColor = AccentCyan, inactiveTrackColor = DividerColor)
                    )

                    // Sharpen Intensity
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Kekuatan Penajaman (Sharpen)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("${(sharpenIntensity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = AccentBlue, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = sharpenIntensity,
                        onValueChange = { sharpenIntensity = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = AccentBlue, activeTrackColor = AccentBlue, inactiveTrackColor = DividerColor)
                    )

                    // Denoise Level
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Pengurangan Hingar (Denoise)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("${(denoiseLevel * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = AccentPurple, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = denoiseLevel,
                        onValueChange = { denoiseLevel = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = AccentPurple, activeTrackColor = AccentPurple, inactiveTrackColor = DividerColor)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Butang Mula Proses
                    Button(
                        onClick = {
                            if (selectedModel == null) {
                                Toast.makeText(context, "Sila muat turun & pilih model AI terlebih dahulu", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            processing = true
                            coroutineScope.launch {
                                try {
                                    outputBitmap = UhdUpscaleEngine.upscaleImage(
                                        inputBitmap = inputBitmap!!,
                                        scaleFactor = scaleFactor,
                                        denoiseLevel = denoiseLevel,
                                        sharpenIntensity = sharpenIntensity
                                    )
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Gagal memproses gambar: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                } finally {
                                    processing = false
                                }
                            }
                        },
                        enabled = selectedModel != null,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentCyan,
                            contentColor = PrimaryDark,
                            disabledContainerColor = DividerColor
                        )
                    ) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Proses Imej ke UHD", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

private fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.isMutableRequired = true
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
