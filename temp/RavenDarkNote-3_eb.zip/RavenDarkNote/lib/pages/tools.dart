import 'package:flutter/material.dart';
import '../widgets/tool_card.dart';
import '../tools/calculator.dart';
import '../tools/password_generator.dart';
import '../tools/text_counter.dart';
import '../tools/case_converter.dart';
import '../tools/json_formatter.dart';
import '../tools/qr_generator.dart';
import '../tools/qr_scanner.dart';
import '../tools/hash_tool.dart';
import '../tools/ip_checker.dart';
import '../tools/device_info_page.dart';
import '../tools/stopwatch_tool.dart';
import '../tools/timer_tool.dart';
import '../tools/unit_converter.dart';
import '../tools/base64_tool.dart';
import '../tools/uuid_generator.dart';
import '../tools/bmi_calculator.dart';

class ToolsPage extends StatelessWidget {
  const ToolsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = [
      {'title': 'Kalkulator', 'icon': Icons.calculate_rounded, 'page': const CalculatorPage()},
      {'title': 'Password Generator', 'icon': Icons.password_rounded, 'page': const PasswordGeneratorPage()},
      {'title': 'Text Counter', 'icon': Icons.text_fields_rounded, 'page': const TextCounterPage()},
      {'title': 'Case Converter', 'icon': Icons.text_format_rounded, 'page': const CaseConverterPage()},
      {'title': 'JSON Formatter', 'icon': Icons.data_object_rounded, 'page': const JsonFormatterPage()},
      {'title': 'Base64 Encode/Decode', 'icon': Icons.code_rounded, 'page': const Base64ToolPage()},
      {'title': 'UUID Generator', 'icon': Icons.fingerprint, 'page': const UuidGeneratorPage()},
      {'title': 'QR Generator', 'icon': Icons.qr_code_rounded, 'page': const QrGeneratorPage()},
      {'title': 'QR Scanner', 'icon': Icons.qr_code_scanner_rounded, 'page': const QrScannerPage()},
      {'title': 'Hash Generator', 'icon': Icons.tag_rounded, 'page': const HashToolPage()},
      {'title': 'BMI Calculator', 'icon': Icons.monitor_weight_rounded, 'page': const BmiCalculatorPage()},
      {'title': 'Unit Converter', 'icon': Icons.swap_horiz_rounded, 'page': const UnitConverterPage()},
      {'title': 'Stopwatch', 'icon': Icons.timer_outlined, 'page': const StopwatchToolPage()},
      {'title': 'Timer', 'icon': Icons.hourglass_bottom_rounded, 'page': const TimerToolPage()},
      {'title': 'IP Checker', 'icon': Icons.public_rounded, 'page': const IpCheckerPage()},
      {'title': 'Device Info', 'icon': Icons.phone_android_rounded, 'page': const DeviceInfoPage()},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tools'),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: tools.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (ctx, i) {
          final t = tools[i];
          return ToolCard(
            title: t['title'] as String,
            icon: t['icon'] as IconData,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => t['page'] as Widget),
              );
            },
          );
        },
      ),
    );
  }
}
