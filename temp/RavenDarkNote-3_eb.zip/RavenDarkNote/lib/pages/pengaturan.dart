import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../widgets/theme_button.dart';

class PengaturanPage extends StatefulWidget {
  final void Function(String theme, String color)? onThemeChanged;

  const PengaturanPage({super.key, this.onThemeChanged});

  @override
  State<PengaturanPage> createState() => _PengaturanPageState();
}

class _PengaturanPageState extends State<PengaturanPage> {
  String _theme = 'dark';
  String _color = 'purple';
  String _version = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final info = await PackageInfo.fromPlatform();
    if (mounted) {
      setState(() {
        _theme = prefs.getString('theme') ?? 'dark';
        _color = prefs.getString('seed_color') ?? 'purple';
        _version = '${info.version}+${info.buildNumber}';
      });
    }
  }

  Future<void> _setTheme(String theme) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme', theme);
    setState(() => _theme = theme);
    widget.onThemeChanged?.call(theme, _color);
  }

  Future<void> _setColor(String color) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('seed_color', color);
    setState(() => _color = color);
    widget.onThemeChanged?.call(_theme, color);
  }

  Future<void> _exportBackup() async {
    final prefs = await SharedPreferences.getInstance();
    final data = {
      'theme': prefs.getString('theme'),
      'seed_color': prefs.getString('seed_color'),
      'catatan_list': prefs.getString('catatan_list'),
      'tabungan_list': prefs.getString('tabungan_list'),
      'exported_at': DateTime.now().toIso8601String(),
      'app': 'Raven DarkNote',
    };
    final json = const JsonEncoder.withIndent('  ').convert(data);
    await Clipboard.setData(ClipboardData(text: json));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Backup JSON disalin ke clipboard')),
      );
    }
  }

  Future<void> _importBackup() async {
    final ctrl = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Restore Backup'),
        content: TextField(
          controller: ctrl,
          maxLines: 8,
          decoration: InputDecoration(
            hintText: 'Tempel JSON backup di sini',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Restore'),
          ),
        ],
      ),
    );
    if (result != true) return;
    try {
      final map = jsonDecode(ctrl.text) as Map<String, dynamic>;
      final prefs = await SharedPreferences.getInstance();
      if (map['theme'] != null) await prefs.setString('theme', map['theme'] as String);
      if (map['seed_color'] != null) await prefs.setString('seed_color', map['seed_color'] as String);
      if (map['catatan_list'] != null) await prefs.setString('catatan_list', map['catatan_list'] as String);
      if (map['tabungan_list'] != null) await prefs.setString('tabungan_list', map['tabungan_list'] as String);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Backup berhasil di-restore. Restart aplikasi untuk melihat perubahan tema.')),
        );
        _load();
        widget.onThemeChanged?.call(
          prefs.getString('theme') ?? 'dark',
          prefs.getString('seed_color') ?? 'purple',
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal restore: $e')),
        );
      }
    }
  }

  void _showDonate() {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: Image.asset(
                'assets/donate.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 200,
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                  child: Center(
                    child: Icon(
                      Icons.favorite,
                      size: 64,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Text(
                    'Dukung Pengembangan',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Terima kasih atas dukungan Anda!\nScan QR atau transfer untuk donasi.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Tutup'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showCaraPakai() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cara Pakai'),
        content: const SingleChildScrollView(
          child: Text(
            '1. Tabungan\n'
            'Tambah target tabungan, isi nama, target uang, dan saldo. Progress otomatis terhitung.\n\n'
            '2. Catatan\n'
            'Buat catatan dengan judul dan isi. Gunakan pencarian untuk menemukan catatan.\n\n'
            '3. Tools\n'
            'Kumpulan utilitas offline: kalkulator, password, QR, hash, dan lainnya.\n\n'
            '4. Pengaturan\n'
            'Ubah tema, warna, backup/restore data JSON.\n\n'
            'Semua data disimpan offline di perangkat Anda.',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Mengerti')),
        ],
      ),
    );
  }

  void _showTentang() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tentang'),
        content: const Text(
          'Raven DarkNote\n\n'
          'Aplikasi catatan dan tabungan offline dengan desain dark premium.\n\n'
          'Dikembangkan dengan Flutter.\n'
          'Tidak menggunakan Firebase.\n'
          'Semua data tersimpan lokal.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tutup')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pengaturan'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Tema',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ThemeButton(
                label: 'System',
                isSelected: _theme == 'system',
                onTap: () => _setTheme('system'),
              ),
              ThemeButton(
                label: 'Dark',
                isSelected: _theme == 'dark',
                onTap: () => _setTheme('dark'),
              ),
              ThemeButton(
                label: 'Light',
                isSelected: _theme == 'light',
                onTap: () => _setTheme('light'),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            'Warna',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ThemeButton(
                label: 'Purple',
                isSelected: _color == 'purple',
                onTap: () => _setColor('purple'),
                color: const Color(0xFF7C3AED),
              ),
              ThemeButton(
                label: 'Blue',
                isSelected: _color == 'blue',
                onTap: () => _setColor('blue'),
                color: const Color(0xFF3B82F6),
              ),
              ThemeButton(
                label: 'Red',
                isSelected: _color == 'red',
                onTap: () => _setColor('red'),
                color: const Color(0xFFEF4444),
              ),
              ThemeButton(
                label: 'Green',
                isSelected: _color == 'green',
                onTap: () => _setColor('green'),
                color: const Color(0xFF22C55E),
              ),
              ThemeButton(
                label: 'Orange',
                isSelected: _color == 'orange',
                onTap: () => _setColor('orange'),
                color: const Color(0xFFF97316),
              ),
            ],
          ),
          const SizedBox(height: 32),
          const Divider(),
          const SizedBox(height: 8),
          ListTile(
            leading: Icon(Icons.backup_rounded, color: Theme.of(context).colorScheme.primary),
            title: const Text('Backup Data'),
            subtitle: const Text('Salin JSON ke clipboard'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _exportBackup,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          ListTile(
            leading: Icon(Icons.restore_rounded, color: Theme.of(context).colorScheme.primary),
            title: const Text('Restore Data'),
            subtitle: const Text('Tempel JSON backup'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _importBackup,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          ListTile(
            leading: Icon(Icons.favorite, color: Theme.of(context).colorScheme.primary),
            title: const Text('Donate'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _showDonate,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          ListTile(
            leading: Icon(Icons.help_outline, color: Theme.of(context).colorScheme.primary),
            title: const Text('Cara Pakai'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _showCaraPakai,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          ListTile(
            leading: Icon(Icons.info_outline, color: Theme.of(context).colorScheme.primary),
            title: const Text('Tentang'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _showTentang,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          ListTile(
            leading: Icon(Icons.phone_android_rounded, color: Theme.of(context).colorScheme.primary),
            title: const Text('Versi APK'),
            subtitle: Text(_version.isEmpty ? 'Memuat...' : _version),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        ],
      ),
    );
  }
}
