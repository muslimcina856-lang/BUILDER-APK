import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PasswordGeneratorPage extends StatefulWidget {
  const PasswordGeneratorPage({super.key});

  @override
  State<PasswordGeneratorPage> createState() => _PasswordGeneratorPageState();
}

class _PasswordGeneratorPageState extends State<PasswordGeneratorPage> {
  int _length = 16;
  bool _upper = true;
  bool _lower = true;
  bool _number = true;
  bool _symbol = true;
  String _password = '';

  void _generate() {
    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const number = '0123456789';
    const symbol = '!@#\$%^&*()_+-=[]{}|;:,.<>?';

    String chars = '';
    if (_upper) chars += upper;
    if (_lower) chars += lower;
    if (_number) chars += number;
    if (_symbol) chars += symbol;

    if (chars.isEmpty) {
      setState(() => _password = '');
      return;
    }

    final rnd = Random.secure();
    final result = List.generate(_length, (_) => chars[rnd.nextInt(chars.length)]).join();
    setState(() => _password = result);
  }

  @override
  void initState() {
    super.initState();
    _generate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Password Generator')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
              ),
            ),
            child: SelectableText(
              _password.isEmpty ? '—' : _password,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w500, letterSpacing: 1.2),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _generate,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Generate'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: _password.isEmpty
                    ? null
                    : () {
                        Clipboard.setData(ClipboardData(text: _password));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Password disalin')),
                        );
                      },
                icon: const Icon(Icons.copy),
                label: const Text('Salin'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),
          Text('Panjang: $_length', style: const TextStyle(fontWeight: FontWeight.w500)),
          Slider(
            value: _length.toDouble(),
            min: 4,
            max: 64,
            divisions: 60,
            label: '$_length',
            onChanged: (v) {
              setState(() => _length = v.toInt());
              _generate();
            },
          ),
          SwitchListTile(
            title: const Text('Huruf Besar (A-Z)'),
            value: _upper,
            onChanged: (v) {
              setState(() => _upper = v);
              _generate();
            },
          ),
          SwitchListTile(
            title: const Text('Huruf Kecil (a-z)'),
            value: _lower,
            onChanged: (v) {
              setState(() => _lower = v);
              _generate();
            },
          ),
          SwitchListTile(
            title: const Text('Angka (0-9)'),
            value: _number,
            onChanged: (v) {
              setState(() => _number = v);
              _generate();
            },
          ),
          SwitchListTile(
            title: const Text('Simbol (!@#...)'),
            value: _symbol,
            onChanged: (v) {
              setState(() => _symbol = v);
              _generate();
            },
          ),
        ],
      ),
    );
  }
}
