import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Base64ToolPage extends StatefulWidget {
  const Base64ToolPage({super.key});

  @override
  State<Base64ToolPage> createState() => _Base64ToolPageState();
}

class _Base64ToolPageState extends State<Base64ToolPage> {
  final _ctrl = TextEditingController();
  String _result = '';
  String? _error;

  void _encode() {
    try {
      setState(() {
        _result = base64Encode(utf8.encode(_ctrl.text));
        _error = null;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _result = '';
      });
    }
  }

  void _decode() {
    try {
      setState(() {
        _result = utf8.decode(base64Decode(_ctrl.text.trim()));
        _error = null;
      });
    } catch (e) {
      setState(() {
        _error = 'Base64 tidak valid';
        _result = '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Base64 Encode/Decode')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: _ctrl,
            maxLines: 5,
            decoration: InputDecoration(
              labelText: 'Input',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _encode,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Encode'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: _decode,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Decode'),
                ),
              ),
            ],
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.redAccent)),
          ],
          if (_result.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(14),
              ),
              child: SelectableText(_result),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: _result));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Disalin')),
                );
              },
              icon: const Icon(Icons.copy),
              label: const Text('Salin'),
            ),
          ],
        ],
      ),
    );
  }
}
