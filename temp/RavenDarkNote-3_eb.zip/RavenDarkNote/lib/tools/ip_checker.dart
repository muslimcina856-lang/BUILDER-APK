import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class IpCheckerPage extends StatefulWidget {
  const IpCheckerPage({super.key});

  @override
  State<IpCheckerPage> createState() => _IpCheckerPageState();
}

class _IpCheckerPageState extends State<IpCheckerPage> {
  bool _loading = false;
  Map<String, dynamic>? _data;
  String? _error;

  Future<void> _check() async {
    setState(() {
      _loading = true;
      _error = null;
      _data = null;
    });
    try {
      final res = await http.get(Uri.parse('https://ipapi.co/json/')).timeout(
        const Duration(seconds: 10),
      );
      if (res.statusCode == 200) {
        setState(() {
          _data = jsonDecode(res.body) as Map<String, dynamic>;
          _loading = false;
        });
      } else {
        setState(() {
          _error = 'Gagal: HTTP ${res.statusCode}';
          _loading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Gagal terhubung: $e';
        _loading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _check();
  }

  Widget _row(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value ?? '—',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('IP Checker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loading ? null : _check,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(_error!, textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _check,
                        child: const Text('Coba Lagi'),
                      ),
                    ],
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(20),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            Icons.public,
                            size: 48,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                          const SizedBox(height: 12),
                          Text(
                            _data?['ip']?.toString() ?? '—',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          _row('Kota', _data?['city']?.toString()),
                          _row('Region', _data?['region']?.toString()),
                          _row('Negara', _data?['country_name']?.toString()),
                          _row('Kode Negara', _data?['country_code']?.toString()),
                          _row('Timezone', _data?['timezone']?.toString()),
                          _row('ISP', _data?['org']?.toString()),
                          _row('ASN', _data?['asn']?.toString()),
                          _row('Latitude', _data?['latitude']?.toString()),
                          _row('Longitude', _data?['longitude']?.toString()),
                        ],
                      ),
                    ),
                  ],
                ),
    );
  }
}
