import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';

class DeviceInfoPage extends StatefulWidget {
  const DeviceInfoPage({super.key});

  @override
  State<DeviceInfoPage> createState() => _DeviceInfoPageState();
}

class _DeviceInfoPageState extends State<DeviceInfoPage> {
  Map<String, String> _info = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final deviceInfo = DeviceInfoPlugin();
    final map = <String, String>{};

    try {
      if (Platform.isAndroid) {
        final android = await deviceInfo.androidInfo;
        map['Brand'] = android.brand;
        map['Model'] = android.model;
        map['Device'] = android.device;
        map['Manufacturer'] = android.manufacturer;
        map['Product'] = android.product;
        map['Android Version'] = android.version.release;
        map['SDK'] = android.version.sdkInt.toString();
        map['Board'] = android.board;
        map['Hardware'] = android.hardware;
        map['Is Physical'] = android.isPhysicalDevice.toString();
        map['Fingerprint'] = android.fingerprint;
      } else if (Platform.isIOS) {
        final ios = await deviceInfo.iosInfo;
        map['Name'] = ios.name;
        map['Model'] = ios.model;
        map['System Name'] = ios.systemName;
        map['System Version'] = ios.systemVersion;
        map['Is Physical'] = ios.isPhysicalDevice.toString();
      } else {
        map['Platform'] = Platform.operatingSystem;
        map['Version'] = Platform.operatingSystemVersion;
      }
    } catch (e) {
      map['Error'] = e.toString();
    }

    if (mounted) {
      setState(() {
        _info = map;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Device Info')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: _info.entries.map((e) {
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 120,
                        child: Text(
                          e.key,
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          e.value,
                          style: const TextStyle(fontSize: 14),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
    );
  }
}
