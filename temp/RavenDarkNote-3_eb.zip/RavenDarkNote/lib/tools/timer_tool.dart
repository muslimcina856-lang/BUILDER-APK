import 'dart:async';
import 'package:flutter/material.dart';

class TimerToolPage extends StatefulWidget {
  const TimerToolPage({super.key});

  @override
  State<TimerToolPage> createState() => _TimerToolPageState();
}

class _TimerToolPageState extends State<TimerToolPage> {
  int _totalSeconds = 300;
  int _remaining = 300;
  Timer? _timer;
  bool _running = false;

  void _start() {
    if (_remaining <= 0) return;
    _running = true;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_remaining <= 1) {
        _timer?.cancel();
        setState(() {
          _remaining = 0;
          _running = false;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Timer selesai!')),
          );
        }
      } else {
        setState(() => _remaining--);
      }
    });
    setState(() {});
  }

  void _pause() {
    _timer?.cancel();
    setState(() => _running = false);
  }

  void _reset() {
    _timer?.cancel();
    setState(() {
      _remaining = _totalSeconds;
      _running = false;
    });
  }

  String _format(int secs) {
    final h = secs ~/ 3600;
    final m = (secs % 3600) ~/ 60;
    final s = secs % 60;
    if (h > 0) {
      return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
    }
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = _totalSeconds > 0 ? _remaining / _totalSeconds : 0.0;
    return Scaffold(
      appBar: AppBar(title: const Text('Timer')),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 220,
                    height: 220,
                    child: CircularProgressIndicator(
                      value: progress,
                      strokeWidth: 10,
                      backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.15),
                    ),
                  ),
                  Text(
                    _format(_remaining),
                    style: TextStyle(
                      fontSize: 42,
                      fontWeight: FontWeight.w300,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (!_running)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  Text('Atur waktu: ${_format(_totalSeconds)}'),
                  Slider(
                    value: _totalSeconds.toDouble(),
                    min: 30,
                    max: 3600,
                    divisions: 117,
                    label: _format(_totalSeconds),
                    onChanged: (v) {
                      setState(() {
                        _totalSeconds = v.toInt();
                        _remaining = _totalSeconds;
                      });
                    },
                  ),
                ],
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                FloatingActionButton(
                  heroTag: 'treset',
                  onPressed: _reset,
                  backgroundColor: Colors.redAccent,
                  child: const Icon(Icons.refresh, color: Colors.white),
                ),
                FloatingActionButton.large(
                  heroTag: 'tstart',
                  onPressed: _running ? _pause : _start,
                  child: Icon(_running ? Icons.pause : Icons.play_arrow, size: 36),
                ),
              ],
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
