import 'package:flutter/material.dart';

class UnitConverterPage extends StatefulWidget {
  const UnitConverterPage({super.key});

  @override
  State<UnitConverterPage> createState() => _UnitConverterPageState();
}

class _UnitConverterPageState extends State<UnitConverterPage> {
  String _category = 'Panjang';
  String _from = 'Meter';
  String _to = 'Kilometer';
  final _ctrl = TextEditingController(text: '1');
  String _result = '';

  final Map<String, Map<String, double>> _units = {
    'Panjang': {
      'Meter': 1,
      'Kilometer': 0.001,
      'Centimeter': 100,
      'Millimeter': 1000,
      'Mile': 0.000621371,
      'Yard': 1.09361,
      'Foot': 3.28084,
      'Inch': 39.3701,
    },
    'Berat': {
      'Kilogram': 1,
      'Gram': 1000,
      'Milligram': 1000000,
      'Pound': 2.20462,
      'Ounce': 35.274,
      'Ton': 0.001,
    },
    'Suhu': {
      'Celsius': 0,
      'Fahrenheit': 0,
      'Kelvin': 0,
    },
    'Volume': {
      'Liter': 1,
      'Milliliter': 1000,
      'Gallon (US)': 0.264172,
      'Cup': 4.22675,
      'Fluid Ounce': 33.814,
    },
    'Data': {
      'Byte': 1,
      'Kilobyte': 1 / 1024,
      'Megabyte': 1 / (1024 * 1024),
      'Gigabyte': 1 / (1024 * 1024 * 1024),
      'Terabyte': 1 / (1024 * 1024 * 1024 * 1024),
    },
  };

  @override
  void initState() {
    super.initState();
    _convert();
    _ctrl.addListener(_convert);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _convert() {
    final value = double.tryParse(_ctrl.text);
    if (value == null) {
      setState(() => _result = '');
      return;
    }

    if (_category == 'Suhu') {
      double celsius;
      if (_from == 'Celsius') {
        celsius = value;
      } else if (_from == 'Fahrenheit') {
        celsius = (value - 32) * 5 / 9;
      } else {
        celsius = value - 273.15;
      }

      double result;
      if (_to == 'Celsius') {
        result = celsius;
      } else if (_to == 'Fahrenheit') {
        result = celsius * 9 / 5 + 32;
      } else {
        result = celsius + 273.15;
      }
      setState(() => _result = result.toStringAsFixed(4));
      return;
    }

    final fromFactor = _units[_category]![_from]!;
    final toFactor = _units[_category]![_to]!;
    final base = value / fromFactor;
    final result = base * toFactor;
    setState(() {
      _result = result % 1 == 0
          ? result.toInt().toString()
          : result.toStringAsFixed(6).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
    });
  }

  void _onCategoryChanged(String? cat) {
    if (cat == null) return;
    setState(() {
      _category = cat;
      final keys = _units[cat]!.keys.toList();
      _from = keys[0];
      _to = keys.length > 1 ? keys[1] : keys[0];
    });
    _convert();
  }

  @override
  Widget build(BuildContext context) {
    final unitList = _units[_category]!.keys.toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Unit Converter')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          DropdownButtonFormField<String>(
            value: _category,
            decoration: InputDecoration(
              labelText: 'Kategori',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
            items: _units.keys
                .map((k) => DropdownMenuItem(value: k, child: Text(k)))
                .toList(),
            onChanged: _onCategoryChanged,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _ctrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: 'Nilai',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _from,
                  decoration: InputDecoration(
                    labelText: 'Dari',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  items: unitList
                      .map((u) => DropdownMenuItem(value: u, child: Text(u, style: const TextStyle(fontSize: 13))))
                      .toList(),
                  onChanged: (v) {
                    setState(() => _from = v!);
                    _convert();
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: IconButton(
                  icon: const Icon(Icons.swap_horiz),
                  onPressed: () {
                    setState(() {
                      final tmp = _from;
                      _from = _to;
                      _to = tmp;
                    });
                    _convert();
                  },
                ),
              ),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _to,
                  decoration: InputDecoration(
                    labelText: 'Ke',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  items: unitList
                      .map((u) => DropdownMenuItem(value: u, child: Text(u, style: const TextStyle(fontSize: 13))))
                      .toList(),
                  onChanged: (v) {
                    setState(() => _to = v!);
                    _convert();
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
              ),
            ),
            child: Column(
              children: [
                Text(
                  'Hasil',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  _result.isEmpty ? '—' : '$_result $_to',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
