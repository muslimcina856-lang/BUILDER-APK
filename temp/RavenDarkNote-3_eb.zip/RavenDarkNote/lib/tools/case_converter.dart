import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CaseConverterPage extends StatefulWidget {
  const CaseConverterPage({super.key});

  @override
  State<CaseConverterPage> createState() => _CaseConverterPageState();
}

class _CaseConverterPageState extends State<CaseConverterPage> {
  final _ctrl = TextEditingController();
  String _result = '';

  void _convert(String type) {
    final text = _ctrl.text;
    setState(() {
      switch (type) {
        case 'upper':
          _result = text.toUpperCase();
          break;
        case 'lower':
          _result = text.toLowerCase();
          break;
        case 'title':
          _result = text
              .split(' ')
              .map((w) => w.isEmpty
                  ? w
                  : '${w[0].toUpperCase()}${w.substring(1).toLowerCase()}')
              .join(' ');
          break;
        case 'sentence':
          _result = text.isEmpty
              ? text
              : '${text[0].toUpperCase()}${text.substring(1).toLowerCase()}';
          break;
        case 'camel':
          final words = text.toLowerCase().split(RegExp(r'[\s_-]+'));
          _result = words.isEmpty
              ? ''
              : words.first +
                  words.skip(1).map((w) => w.isEmpty ? w : '${w[0].toUpperCase()}${w.substring(1)}').join();
          break;
        case 'snake':
          _result = text
              .replaceAllMapped(RegExp(r'[A-Z]'), (m) => '_${m.group(0)!.toLowerCase()}')
              .replaceAll(RegExp(r'[\s-]+'), '_')
              .replaceAll(RegExp(r'^_'), '')
              .toLowerCase();
          break;
        case 'kebab':
          _result = text
              .replaceAllMapped(RegExp(r'[A-Z]'), (m) => '-${m.group(0)!.toLowerCase()}')
              .replaceAll(RegExp(r'[\s_]+'), '-')
              .replaceAll(RegExp(r'^-'), '')
              .toLowerCase();
          break;
        case 'invert':
          _result = text.split('').map((c) {
            if (c.toUpperCase() == c && c.toLowerCase() != c) return c.toLowerCase();
            if (c.toLowerCase() == c && c.toUpperCase() != c) return c.toUpperCase();
            return c;
          }).join();
          break;
      }
    });
  }

  Widget _btn(String label, String type) {
    return ElevatedButton(
      onPressed: () => _convert(type),
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: Text(label, style: const TextStyle(fontSize: 13)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Case Converter')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: _ctrl,
            maxLines: 4,
            decoration: InputDecoration(
              labelText: 'Teks Asli',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 2.8,
            children: [
              _btn('UPPERCASE', 'upper'),
              _btn('lowercase', 'lower'),
              _btn('Title Case', 'title'),
              _btn('Sentence case', 'sentence'),
              _btn('camelCase', 'camel'),
              _btn('snake_case', 'snake'),
              _btn('kebab-case', 'kebab'),
              _btn('InVeRt', 'invert'),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
              ),
            ),
            child: SelectableText(
              _result.isEmpty ? 'Hasil akan muncul di sini' : _result,
              style: TextStyle(
                fontSize: 15,
                color: _result.isEmpty
                    ? Theme.of(context).colorScheme.onSurface.withOpacity(0.4)
                    : Theme.of(context).colorScheme.onSurface,
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_result.isNotEmpty)
            ElevatedButton.icon(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: _result));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Hasil disalin')),
                );
              },
              icon: const Icon(Icons.copy),
              label: const Text('Salin Hasil'),
            ),
        ],
      ),
    );
  }
}
