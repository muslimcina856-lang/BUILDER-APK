import 'package:flutter/material.dart';

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String _display = '0';
  String _operand = '';
  double? _first;
  String? _operator;

  void _input(String value) {
    setState(() {
      if (_display == '0' && value != '.') {
        _display = value;
      } else if (value == '.' && _display.contains('.')) {
        return;
      } else {
        _display += value;
      }
    });
  }

  void _setOperator(String op) {
    setState(() {
      _first = double.tryParse(_display);
      _operator = op;
      _operand = _display;
      _display = '0';
    });
  }

  void _calculate() {
    if (_first == null || _operator == null) return;
    final second = double.tryParse(_display) ?? 0;
    double result = 0;
    switch (_operator) {
      case '+':
        result = _first! + second;
        break;
      case '-':
        result = _first! - second;
        break;
      case '×':
        result = _first! * second;
        break;
      case '÷':
        result = second != 0 ? _first! / second : 0;
        break;
    }
    setState(() {
      _display = result % 1 == 0 ? result.toInt().toString() : result.toStringAsFixed(8).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
      _first = null;
      _operator = null;
      _operand = '';
    });
  }

  void _clear() {
    setState(() {
      _display = '0';
      _first = null;
      _operator = null;
      _operand = '';
    });
  }

  void _backspace() {
    setState(() {
      if (_display.length > 1) {
        _display = _display.substring(0, _display.length - 1);
      } else {
        _display = '0';
      }
    });
  }

  Widget _btn(String label, {Color? color, VoidCallback? onTap, int flex = 1}) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: Material(
          color: color ?? Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(16),
            child: Container(
              height: 64,
              alignment: Alignment.center,
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w500,
                  color: color != null ? Colors.white : Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      appBar: AppBar(title: const Text('Kalkulator')),
      body: Column(
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              alignment: Alignment.bottomRight,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (_operand.isNotEmpty)
                    Text(
                      '$_operand $_operator',
                      style: TextStyle(
                        fontSize: 18,
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                      ),
                    ),
                  Text(
                    _display,
                    style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w300),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Row(children: [
                  _btn('C', color: Colors.redAccent, onTap: _clear),
                  _btn('⌫', onTap: _backspace),
                  _btn('%', onTap: () {
                    setState(() {
                      final v = double.tryParse(_display) ?? 0;
                      _display = (v / 100).toString();
                    });
                  }),
                  _btn('÷', color: primary, onTap: () => _setOperator('÷')),
                ]),
                Row(children: [
                  _btn('7', onTap: () => _input('7')),
                  _btn('8', onTap: () => _input('8')),
                  _btn('9', onTap: () => _input('9')),
                  _btn('×', color: primary, onTap: () => _setOperator('×')),
                ]),
                Row(children: [
                  _btn('4', onTap: () => _input('4')),
                  _btn('5', onTap: () => _input('5')),
                  _btn('6', onTap: () => _input('6')),
                  _btn('-', color: primary, onTap: () => _setOperator('-')),
                ]),
                Row(children: [
                  _btn('1', onTap: () => _input('1')),
                  _btn('2', onTap: () => _input('2')),
                  _btn('3', onTap: () => _input('3')),
                  _btn('+', color: primary, onTap: () => _setOperator('+')),
                ]),
                Row(children: [
                  _btn('0', onTap: () => _input('0'), flex: 2),
                  _btn('.', onTap: () => _input('.')),
                  _btn('=', color: primary, onTap: _calculate),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
