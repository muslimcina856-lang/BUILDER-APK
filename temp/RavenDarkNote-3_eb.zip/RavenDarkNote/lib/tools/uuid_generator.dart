import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class UuidGeneratorPage extends StatefulWidget {
  const UuidGeneratorPage({super.key});

  @override
  State<UuidGeneratorPage> createState() => _UuidGeneratorPageState();
}

class _UuidGeneratorPageState extends State<UuidGeneratorPage> {
  String _uuid = '';

  String _generate() {
    final rnd = Random.secure();
    final bytes = List<int>.generate(16, (_) => rnd.nextInt(256));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    final hex = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    return '${hex.substring(0, 8)}-${hex.substring(8, 12)}-${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}';
  }

  @override
  void initState() {
    super.initState();
    _uuid = _generate();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('UUID Generator')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(16),
              ),
              child: SelectableText(
                _uuid,
                style: const TextStyle(fontSize: 16, fontFamily: 'monospace'),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => setState(() => _uuid = _generate()),
                    icon: const Icon(Icons.refresh),
                    label: const Text('Generate'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: _uuid));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('UUID disalin')),
                    );
                  },
                  icon: const Icon(Icons.copy),
                  label: const Text('Salin'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
