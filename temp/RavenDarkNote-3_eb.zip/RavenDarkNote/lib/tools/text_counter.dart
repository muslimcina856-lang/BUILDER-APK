import 'package:flutter/material.dart';

class TextCounterPage extends StatefulWidget {
  const TextCounterPage({super.key});

  @override
  State<TextCounterPage> createState() => _TextCounterPageState();
}

class _TextCounterPageState extends State<TextCounterPage> {
  final _ctrl = TextEditingController();
  int _chars = 0;
  int _charsNoSpace = 0;
  int _words = 0;
  int _lines = 0;
  int _sentences = 0;

  @override
  void initState() {
    super.initState();
    _ctrl.addListener(_count);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _count() {
    final text = _ctrl.text;
    setState(() {
      _chars = text.length;
      _charsNoSpace = text.replaceAll(RegExp(r'\s'), '').length;
      _words = text.trim().isEmpty
          ? 0
          : text.trim().split(RegExp(r'\s+')).length;
      _lines = text.isEmpty ? 0 : text.split('\n').length;
      _sentences = text.trim().isEmpty
          ? 0
          : text.split(RegExp(r'[.!?]+')).where((s) => s.trim().isNotEmpty).length;
    });
  }

  Widget _stat(String label, int value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color ?? const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Text(
            '$value',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Text Counter')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.3,
              children: [
                _stat('Karakter', _chars),
                _stat('Tanpa Spasi', _charsNoSpace),
                _stat('Kata', _words),
                _stat('Baris', _lines),
                _stat('Kalimat', _sentences),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: TextField(
                controller: _ctrl,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                decoration: InputDecoration(
                  hintText: 'Tulis atau tempel teks di sini...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                  contentPadding: const EdgeInsets.all(16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
