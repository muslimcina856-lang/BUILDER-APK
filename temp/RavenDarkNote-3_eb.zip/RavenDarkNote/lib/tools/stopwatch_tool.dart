import 'dart:async';
import 'package:flutter/material.dart';

class StopwatchToolPage extends StatefulWidget {
  const StopwatchToolPage({super.key});

  @override
  State<StopwatchToolPage> createState() => _StopwatchToolPageState();
}

class _StopwatchToolPageState extends State<StopwatchToolPage> {
  final Stopwatch _stopwatch = Stopwatch();
  Timer? _timer;
  String _display = '00:00:00.00';
  final List<String> _laps = [];

  void _start() {
    _stopwatch.start();
    _timer = Timer.periodic(const Duration(milliseconds: 30), (_) {
      setState(() {
        _display = _format(_stopwatch.elapsed);
      });
    });
  }

  void _stop() {
    _stopwatch.stop();
    _timer?.cancel();
    setState(() {});
  }

  void _reset() {
    _stopwatch.reset();
    _timer?.cancel();
    setState(() {
      _display = '00:00:00.00';
      _laps.clear();
    });
  }

  void _lap() {
    if (_stopwatch.isRunning) {
      setState(() {
        _laps.insert(0, _format(_stopwatch.elapsed));
      });
    }
  }

  String _format(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    final ms = ((d.inMilliseconds % 1000) ~/ 10).toString().padLeft(2, '0');
    return '$h:$m:$s.$ms';
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final running = _stopwatch.isRunning;
    return Scaffold(
      appBar: AppBar(title: const Text('Stopwatch')),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Text(
                _display,
                style: TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.w300,
                  fontFeatures: const [FontFeature.tabularFigures()],
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                FloatingActionButton(
                  heroTag: 'reset',
                  onPressed: _reset,
                  backgroundColor: Colors.redAccent,
                  child: const Icon(Icons.refresh, color: Colors.white),
                ),
                FloatingActionButton.large(
                  heroTag: 'startstop',
                  onPressed: running ? _stop : _start,
                  child: Icon(running ? Icons.pause : Icons.play_arrow, size: 36),
                ),
                FloatingActionButton(
                  heroTag: 'lap',
                  onPressed: _lap,
                  child: const Icon(Icons.flag),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: _laps.isEmpty
                ? Center(
                    child: Text(
                      'Belum ada putaran',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    itemCount: _laps.length,
                    itemBuilder: (_, i) {
                      return ListTile(
                        leading: Text(
                          '#${_laps.length - i}',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        title: Text(
                          _laps[i],
                          style: const TextStyle(
                            fontSize: 18,
                            fontFeatures: [FontFeature.tabularFigures()],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
