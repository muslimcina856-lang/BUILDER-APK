import 'dart:convert';
import '../models/catatan_model.dart';
import 'storage_service.dart';

class CatatanService {
  static const String _key = 'catatan_list';

  static Future<List<CatatanModel>> getAll() async {
    final data = StorageService.getString(_key);
    if (data == null || data.isEmpty) return [];
    final List<dynamic> list = jsonDecode(data);
    return list.map((e) => CatatanModel.fromJson(e as Map<String, dynamic>)).toList()
      ..sort((a, b) => b.tanggal.compareTo(a.tanggal));
  }

  static Future<void> saveAll(List<CatatanModel> list) async {
    final data = jsonEncode(list.map((e) => e.toJson()).toList());
    await StorageService.setString(_key, data);
  }

  static Future<void> add(CatatanModel catatan) async {
    final list = await getAll();
    list.add(catatan);
    await saveAll(list);
  }

  static Future<void> update(CatatanModel catatan) async {
    final list = await getAll();
    final index = list.indexWhere((e) => e.id == catatan.id);
    if (index != -1) {
      list[index] = catatan;
      await saveAll(list);
    }
  }

  static Future<void> delete(String id) async {
    final list = await getAll();
    list.removeWhere((e) => e.id == id);
    await saveAll(list);
  }
}
