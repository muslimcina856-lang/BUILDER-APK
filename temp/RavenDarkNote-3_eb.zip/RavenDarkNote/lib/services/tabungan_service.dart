import 'dart:convert';
import '../models/tabungan_model.dart';
import 'storage_service.dart';

class TabunganService {
  static const String _key = 'tabungan_list';

  static Future<List<TabunganModel>> getAll() async {
    final data = StorageService.getString(_key);
    if (data == null || data.isEmpty) return [];
    final List<dynamic> list = jsonDecode(data);
    return list.map((e) => TabunganModel.fromJson(e as Map<String, dynamic>)).toList();
  }

  static Future<void> saveAll(List<TabunganModel> list) async {
    final data = jsonEncode(list.map((e) => e.toJson()).toList());
    await StorageService.setString(_key, data);
  }

  static Future<void> add(TabunganModel tabungan) async {
    final list = await getAll();
    list.add(tabungan);
    await saveAll(list);
  }

  static Future<void> update(TabunganModel tabungan) async {
    final list = await getAll();
    final index = list.indexWhere((e) => e.id == tabungan.id);
    if (index != -1) {
      list[index] = tabungan;
      await saveAll(list);
    }
  }

  static Future<void> delete(String id) async {
    final list = await getAll();
    list.removeWhere((e) => e.id == id);
    await saveAll(list);
  }

  static Future<void> reset(String id) async {
    final list = await getAll();
    final index = list.indexWhere((e) => e.id == id);
    if (index != -1) {
      list[index] = list[index].copyWith(saldo: 0);
      await saveAll(list);
    }
  }
}
