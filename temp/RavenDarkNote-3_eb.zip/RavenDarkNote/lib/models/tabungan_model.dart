class TabunganModel {
  final String id;
  final String nama;
  final double target;
  final double saldo;

  TabunganModel({
    required this.id,
    required this.nama,
    required this.target,
    required this.saldo,
  });

  double get progress => target > 0 ? (saldo / target).clamp(0.0, 1.0) : 0.0;

  double get persentase => progress * 100;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nama': nama,
      'target': target,
      'saldo': saldo,
    };
  }

  factory TabunganModel.fromJson(Map<String, dynamic> json) {
    return TabunganModel(
      id: json['id'] as String,
      nama: json['nama'] as String,
      target: (json['target'] as num).toDouble(),
      saldo: (json['saldo'] as num).toDouble(),
    );
  }

  TabunganModel copyWith({
    String? id,
    String? nama,
    double? target,
    double? saldo,
  }) {
    return TabunganModel(
      id: id ?? this.id,
      nama: nama ?? this.nama,
      target: target ?? this.target,
      saldo: saldo ?? this.saldo,
    );
  }
}
