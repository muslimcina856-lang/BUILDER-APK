class CatatanModel {
  final String id;
  final String judul;
  final String isi;
  final DateTime tanggal;

  CatatanModel({
    required this.id,
    required this.judul,
    required this.isi,
    required this.tanggal,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'judul': judul,
      'isi': isi,
      'tanggal': tanggal.toIso8601String(),
    };
  }

  factory CatatanModel.fromJson(Map<String, dynamic> json) {
    return CatatanModel(
      id: json['id'] as String,
      judul: json['judul'] as String,
      isi: json['isi'] as String,
      tanggal: DateTime.parse(json['tanggal'] as String),
    );
  }

  CatatanModel copyWith({
    String? id,
    String? judul,
    String? isi,
    DateTime? tanggal,
  }) {
    return CatatanModel(
      id: id ?? this.id,
      judul: judul ?? this.judul,
      isi: isi ?? this.isi,
      tanggal: tanggal ?? this.tanggal,
    );
  }
}
