# Raven DarkNote

Aplikasi Flutter Android offline: Catatan, Tabungan, dan Tools premium dengan tema Dark.

## Package
`com.raven.darknote`

## Fitur
- Dashboard dengan video banner (autoplay + loop)
- Tabungan (target, progress, CRUD)
- Catatan (CRUD + pencarian)
- 13 Tools lengkap
- Tema System / Dark / Light + warna Purple / Blue / Red
- Penyimpanan offline SharedPreferences

## Assets
Ganti file berikut dengan yang asli:
- `assets/banner.mp4` — video banner
- `assets/icon.png` — ikon aplikasi
- `assets/donate.jpg` — gambar donasi

## Build
```bash
flutter pub get
flutter build apk --release
```

## Dependencies
shared_preferences, video_player, url_launcher, qr_flutter, mobile_scanner, device_info_plus, package_info_plus, http, crypto, path_provider, intl
