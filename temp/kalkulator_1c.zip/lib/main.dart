import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: CyberCalc(),
  ));
}

class CyberCalc extends StatefulWidget {
  const CyberCalc({super.key});

  @override
  State<CyberCalc> createState() => _CyberCalcState();
}

class _CyberCalcState extends State<CyberCalc> {
  String _out = "0";
  String _exp = "";
  double n1 = 0;
  double n2 = 0;
  String op = "";

  void _press(String txt) {
    if (txt == "CLEAR") {
      _out = "0"; _exp = ""; n1 = 0; n2 = 0; op = "";
    } else if (txt == "+" || txt == "-" || txt == "×" || txt == "÷") {
      n1 = double.tryParse(_out) ?? 0;
      op = txt;
      _exp = "${n1.toStringAsFixed(n1 % 1 == 0 ? 0 : 1)} $op ";
      _out = "0";
    } else if (txt == "=") {
      n2 = double.tryParse(_out) ?? 0;
      _exp += n2.toStringAsFixed(n2 % 1 == 0 ? 0 : 1);
      if (op == "+") _out = (n1 + n2).toString();
      if (op == "-") _out = (n1 - n2).toString();
      if (op == "×") _out = (n1 * n2).toString();
      if (op == "÷") _out = n2 != 0 ? (n1 / n2).toString() : "ERROR";
      double res = double.tryParse(_out) ?? 0;
      _out = res % 1 == 0 ? res.toStringAsFixed(0) : res.toStringAsFixed(2);
      op = "";
    } else {
      _out = (_out == "0") ? txt : _out + txt;
    }
    setState(() {});
  }

  Widget _btn(String txt, Color clr) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(5),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF111622),
            padding: const EdgeInsets.all(20),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: clr, width: 1.5),
            ),
          ),
          onPressed: () => _press(txt),
          child: Text(txt, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: clr, fontFamily: 'monospace')),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF05070B),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111622),
        title: const Text('DANFIUEL CYBER CALC', style: TextStyle(color: Color(0xFF00FF66), fontFamily: 'monospace', fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(20),
              alignment: Alignment.bottomRight,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(_exp, style: const TextStyle(fontSize: 20, color: Colors.grey, fontFamily: 'monospace')),
                  const SizedBox(height: 5),
                  Text(_out, style: const TextStyle(fontSize: 45, fontWeight: FontWeight.bold, color: Color(0xFF00FF66), fontFamily: 'monospace')),
                ],
              ),
            ),
          ),
          const Divider(color: Color(0xFF00FF66), thickness: 1),
          Column(
            children: [
              Row(children: [_btn("7", Colors.white), _btn("8", Colors.white), _btn("9", Colors.white), _btn("÷", Colors.orange)]),
              Row(children: [_btn("4", Colors.white), _btn("5", Colors.white), _btn("6", Colors.white), _btn("×", Colors.orange)]),
              Row(children: [_btn("1", Colors.white), _btn("2", Colors.white), _btn("3", Colors.white), _btn("-", Colors.orange)]),
              Row(children: [_btn(".", Colors.white), _btn("0", Colors.white), _btn("00", Colors.white), _btn("+", Colors.orange)]),
              Row(children: [_btn("CLEAR", Colors.redAccent), _btn("=", Colors.cyanAccent)]),
              const SizedBox(height: 10),
            ],
          )
        ],
      ),
    );
  }
}
