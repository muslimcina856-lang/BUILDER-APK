package com.example.prankapp;

import android.content.Context;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout root;
    private TextView mainText, subText, icon;
    private Button closeButton;
    private Handler handler = new Handler(Looper.getMainLooper());

    private boolean[] flickerState = {true};
    private final int FLICKER_DURATION_MS = 600000; // durasi efek "serem" diperpanjang
    private final int FLICKER_INTERVAL_MS = 150;  // kecepatan kedip

    private MediaPlayer mediaPlayer;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean hasFlash = false;
    private Runnable flickerRunnableRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = 1.0f;
        getWindow().setAttributes(lp);

        root = findViewById(R.id.root_layout);
        mainText = findViewById(R.id.main_text);
        subText = findViewById(R.id.sub_text);
        icon = findViewById(R.id.warning_icon);
        closeButton = findViewById(R.id.close_button);

        try {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(800);
                }
            }
        } catch (Exception ignored) {}

        setupFlashlight();

        // request camera permission untuk flash (Android 9+)
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            if (checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.CAMERA}, 100);
            }
        }

        playAlarmSound();
        startFlicker();
        startFlashBlink();

        handler.postDelayed(this::revealPrank, FLICKER_DURATION_MS);
    }

    private void playAlarmSound() {
        try {
            Uri alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_NOTIFICATION);
            }
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE);
            }
            if (alarmUri != null) {
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
                mediaPlayer.setDataSource(this, alarmUri);
                mediaPlayer.setLooping(true);
                mediaPlayer.prepare();

                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                if (am != null) {
                    int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
                    am.setStreamVolume(AudioManager.STREAM_ALARM, max, 0);
                }

                mediaPlayer.start();
            }
        } catch (Exception ignored) {}
    }

    private void stopAlarmSound() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception ignored) {}
    }

    private void setupFlashlight() {
        try {
            cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager != null) {
                for (String id : cameraManager.getCameraIdList()) {
                    Boolean flashAvailable = cameraManager.getCameraCharacteristics(id)
                            .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (flashAvailable != null && flashAvailable) {
                        cameraId = id;
                        hasFlash = true;
                        break;
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void setFlash(boolean on) {
        if (!hasFlash || cameraManager == null || cameraId == null) return;
        try {
            cameraManager.setTorchMode(cameraId, on);
        } catch (CameraAccessException ignored) {}
    }

    private void startFlashBlink() {
        if (!hasFlash) return;
        Runnable flashRunnable = new Runnable() {
            boolean on = false;
            @Override
            public void run() {
                on = !on;
                setFlash(on);
                if (flickerRunnableRef != null) {
                    handler.postDelayed(this, FLICKER_INTERVAL_MS);
                } else {
                    setFlash(false);
                }
            }
        };
        handler.post(flashRunnable);
    }

    private void startFlicker() {
        Runnable flickerRunnable = new Runnable() {
            @Override
            public void run() {
                if (flickerState[0]) {
                    root.setBackgroundColor(Color.parseColor("#B71C1C"));
                } else {
                    root.setBackgroundColor(Color.parseColor("#FF1744"));
                }
                flickerState[0] = !flickerState[0];
                handler.postDelayed(this, FLICKER_INTERVAL_MS);
            }
        };
        handler.post(flickerRunnable);
        flickerRunnableRef = flickerRunnable;
    }

    private void revealPrank() {
        handler.removeCallbacks(flickerRunnableRef);
        flickerRunnableRef = null;
        setFlash(false);
        stopAlarmSound();

        root.setBackgroundColor(Color.parseColor("#2E7D32"));
        icon.setText("😂");
        mainText.setText("JK! Cuma Prank!");
        subText.setText("Santai, HP kamu aman kok 😄");
        closeButton.setVisibility(View.VISIBLE);
        closeButton.setOnClickListener(v -> finish());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        setFlash(false);
        stopAlarmSound();
        handler.removeCallbacksAndMessages(null);
    }
}
