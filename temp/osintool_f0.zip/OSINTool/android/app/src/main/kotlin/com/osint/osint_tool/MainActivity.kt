package com.osint.osint_tool

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
