import 'package:flutter_test/flutter_test.dart';
import 'package:osint_tool/main.dart';

void main() {
  testWidgets('App renders', (WidgetTester tester) async {
    await tester.pumpWidget(const OsintApp());
    expect(find.text('OSINT Tool'), findsOneWidget);
  });
}
