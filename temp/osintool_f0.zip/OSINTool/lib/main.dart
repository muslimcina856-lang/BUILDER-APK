import 'package:flutter/material.dart';
import 'theme.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const OsintApp());
}

class OsintApp extends StatelessWidget {
  const OsintApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OSINT Tool',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.dark,
      home: const HomeScreen(),
    );
  }
}
