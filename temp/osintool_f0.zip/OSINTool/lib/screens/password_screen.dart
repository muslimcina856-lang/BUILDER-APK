import 'dart:math';
import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class PasswordScreen extends StatefulWidget {
  const PasswordScreen({super.key});
  @override
  State<PasswordScreen> createState() => _PasswordScreenState();
}

class _PasswordScreenState extends State<PasswordScreen> {
  String _password = '';
  int _length = 16;
  bool _upper = true, _lower = true, _digits = true, _symbols = true;

  void _generate() {
    String chars = '';
    if (_upper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (_lower) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (_digits) chars += '0123456789';
    if (_symbols) chars += '!@#\$%^&*()-_=+[]{}|;:,.<>?/~`';
    if (chars.isEmpty) { setState(() => _password = 'Select at least one'); return; }
    final rng = Random.secure();
    setState(() => _password = List.generate(_length, (_) => chars[rng.nextInt(chars.length)]).join());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Password Generator')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_password.isNotEmpty) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    SelectableText(_password, style: const TextStyle(fontSize: 18, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    _pwStrength(),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
          SectionCard(title: 'Options', subtitle: 'Customize your password', icon: Icons.tune, children: [
            Row(children: [
              Text('Length: $_length'),
              Expanded(child: Slider(value: _length.toDouble(), min: 4, max: 64, divisions: 60, onChanged: (v) => setState(() => _length = v.round()))),
            ]),
            CheckboxListTile(value: _upper, onChanged: (v) => setState(() => _upper = v!), title: const Text('Uppercase', style: TextStyle(fontSize: 13)), dense: true),
            CheckboxListTile(value: _lower, onChanged: (v) => setState(() => _lower = v!), title: const Text('Lowercase', style: TextStyle(fontSize: 13)), dense: true),
            CheckboxListTile(value: _digits, onChanged: (v) => setState(() => _digits = v!), title: const Text('Digits', style: TextStyle(fontSize: 13)), dense: true),
            CheckboxListTile(value: _symbols, onChanged: (v) => setState(() => _symbols = v!), title: const Text('Symbols', style: TextStyle(fontSize: 13)), dense: true),
          ]),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: _generate, icon: const Icon(Icons.refresh), label: const Text('Generate'))),
        ],
      ),
    );
  }

  Widget _pwStrength() {
    int score = 0;
    if (_upper) score += 26;
    if (_lower) score += 26;
    if (_digits) score += 10;
    if (_symbols) score += 32;
    double bits = log(score) / ln2 * _length;
    String label = bits < 40 ? 'Weak' : (bits < 60 ? 'Medium' : (bits < 80 ? 'Strong' : 'Very Strong'));
    Color c = bits < 40 ? Colors.red : (bits < 60 ? Colors.orange : (bits < 80 ? Colors.yellow : Colors.green));
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(color: c.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(12)),
      child: Text(label, style: TextStyle(color: c, fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}
