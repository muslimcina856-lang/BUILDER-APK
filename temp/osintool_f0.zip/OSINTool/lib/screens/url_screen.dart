import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class UrlScreen extends StatefulWidget {
  const UrlScreen({super.key});
  @override
  State<UrlScreen> createState() => _UrlScreenState();
}

class _UrlScreenState extends State<UrlScreen> {
  final _ctrl = TextEditingController();
  String _result = '';
  bool _encode = true;

  void _convert() {
    try {
      if (_encode) {
        _result = Uri.encodeComponent(_ctrl.text);
      } else {
        _result = Uri.decodeComponent(_ctrl.text);
      }
    } catch (e) {
      _result = 'Error: ${e.toString()}';
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('URL Tools')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: InputDecoration(
              hintText: _encode ? 'Enter URL/text to encode...' : 'Enter encoded URL to decode...',
              prefixIcon: const Icon(Icons.link),
            ),
            maxLines: 3,
            onChanged: (_) => _convert(),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () { setState(() => _encode = true); _convert(); },
                  icon: const Icon(Icons.lock, size: 16),
                  label: const Text('Encode'),
                  style: _encode ? null : ElevatedButton.styleFrom(backgroundColor: Colors.grey[800]),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () { setState(() => _encode = false); _convert(); },
                  icon: const Icon(Icons.lock_open, size: 16),
                  label: const Text('Decode'),
                  style: !_encode ? null : ElevatedButton.styleFrom(backgroundColor: Colors.grey[800]),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (_result.isNotEmpty)
            SectionCard(
              title: _encode ? 'URL Encoded' : 'URL Decoded',
              subtitle: '${_result.length} chars',
              icon: Icons.output,
              children: [
                SelectableText(_result, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
              ],
            ),
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
