import 'package:flutter/material.dart';
import '../widgets/section_card.dart';
import '../services.dart';

class DnsScreen extends StatefulWidget {
  const DnsScreen({super.key});
  @override
  State<DnsScreen> createState() => _DnsScreenState();
}

class _DnsScreenState extends State<DnsScreen> {
  final _ctrl = TextEditingController();
  String _type = 'A';
  List<Map<String, dynamic>>? _records;
  bool _loading = false;

  Future<void> _lookup() async {
    setState(() => _loading = true);
    _records = await DnsService.lookup(_ctrl.text.trim(), _type);
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('DNS Lookup')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'e.g. google.com',
              prefixIcon: Icon(Icons.dns),
            ),
            onSubmitted: (_) => _lookup(),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _type,
            decoration: const InputDecoration(labelText: 'Record Type'),
            items: ['A', 'AAAA', 'MX', 'TXT', 'NS', 'CNAME', 'SOA'].map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
            onChanged: (v) => setState(() => _type = v!),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _lookup,
              icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
              label: Text(_loading ? 'Looking up...' : 'Lookup'),
            ),
          ),
          if (_records != null) ...[
            const SizedBox(height: 20),
            SectionCard(
              title: '$_type Records',
              subtitle: '${_records!.length} result(s)',
              icon: Icons.dns,
              children: _records!.isEmpty
                  ? [const ResultRow(label: 'Info', value: 'No records found')]
                  : _records!.asMap().entries.map((e) => ResultRow(
                      label: '${e.key + 1}. ${e.value['type'] ?? ''}',
                      value: e.value['data'] ?? e.value['rdata'] ?? '',
                    )).toList(),
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
