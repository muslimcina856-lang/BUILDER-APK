import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class HashScreen extends StatefulWidget {
  const HashScreen({super.key});
  @override
  State<HashScreen> createState() => _HashScreenState();
}

class _HashScreenState extends State<HashScreen> {
  final _ctrl = TextEditingController();
  Map<String, String>? _hashes;

  void _generate() {
    final input = _ctrl.text.trim();
    if (input.isEmpty) return;
    final bytes = utf8.encode(input);
    setState(() => _hashes = {
      'MD5': md5.convert(bytes).toString(),
      'SHA1': sha1.convert(bytes).toString(),
      'SHA256': sha256.convert(bytes).toString(),
      'SHA512': sha512.convert(bytes).toString(),
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hash Generator')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'Enter text to hash...',
              prefixIcon: Icon(Icons.fingerprint),
            ),
            maxLines: 3,
            onSubmitted: (_) => _generate(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _generate,
              icon: const Icon(Icons.play_arrow),
              label: const Text('Generate Hashes'),
            ),
          ),
          if (_hashes != null) ...[
            const SizedBox(height: 20),
            SectionCard(
              title: 'Hash Results',
              subtitle: '${_ctrl.text.length} chars input',
              icon: Icons.fingerprint,
              children: _hashes!.entries.map((e) => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 8),
                  Text(e.key, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12, color: Colors.grey[400])),
                  const SizedBox(height: 4),
                  SelectableText(e.value, style: const TextStyle(fontSize: 11, fontFamily: 'monospace')),
                ],
              )).toList(),
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
