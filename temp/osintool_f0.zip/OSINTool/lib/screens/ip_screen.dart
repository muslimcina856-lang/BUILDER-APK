import 'package:flutter/material.dart';
import '../widgets/section_card.dart';
import '../services.dart';

class IpScreen extends StatefulWidget {
  const IpScreen({super.key});
  @override
  State<IpScreen> createState() => _IpScreenState();
}

class _IpScreenState extends State<IpScreen> {
  final _ctrl = TextEditingController();
  Map<String, dynamic>? _data;
  bool _loading = false;

  Future<void> _lookup() async {
    setState(() => _loading = true);
    _data = await IpService.lookup(_ctrl.text.trim());
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('IP Lookup')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: InputDecoration(
              hintText: 'Enter IP address...',
              prefixIcon: const Icon(Icons.wifi_tethering),
              suffixIcon: _ctrl.text.isNotEmpty
                  ? IconButton(icon: const Icon(Icons.clear), onPressed: () { _ctrl.clear(); setState(() => _data = null); })
                  : null,
            ),
            onSubmitted: (_) => _lookup(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _lookup,
              icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
              label: Text(_loading ? 'Looking up...' : 'Lookup'),
            ),
          ),
          if (_data != null) ...[
            const SizedBox(height: 20),
            SectionCard(
              title: 'IP: ${_data!['query']}',
              subtitle: _data!['status'] == 'success' ? _data!['country'] ?? '' : 'Failed',
              icon: Icons.location_on,
              children: [
                if (_data!['status'] == 'fail') ...[
                  const ResultRow(label: 'Error', value: 'Invalid IP or rate limited'),
                ] else ...[
                  ResultRow(label: 'Country', value: '${_data!['country'] ?? ''} (${_data!['countryCode'] ?? ''})'),
                  ResultRow(label: 'Region', value: '${_data!['regionName'] ?? ''}, ${_data!['city'] ?? ''}'),
                  ResultRow(label: 'ZIP', value: _data!['zip'] ?? '-'),
                  ResultRow(label: 'ISP', value: _data!['isp'] ?? '-'),
                  ResultRow(label: 'Organization', value: _data!['org'] ?? '-'),
                  ResultRow(label: 'ASN', value: _data!['as'] ?? '-'),
                  ResultRow(label: 'Timezone', value: _data!['timezone'] ?? '-'),
                  ResultRow(label: 'Lat/Lon', value: '${_data!['lat'] ?? '-'}, ${_data!['lon'] ?? '-'}'),
                  ResultRow(label: 'Mobile', value: _data!['mobile'] == true ? 'Yes' : 'No'),
                  ResultRow(label: 'Proxy', value: _data!['proxy'] == true ? 'Yes' : 'No'),
                  ResultRow(label: 'Hosting', value: _data!['hosting'] == true ? 'Yes' : 'No'),
                ],
              ],
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
