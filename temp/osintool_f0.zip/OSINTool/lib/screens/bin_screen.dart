import 'package:flutter/material.dart';
import '../widgets/section_card.dart';
import '../services.dart';

class BinScreen extends StatefulWidget {
  const BinScreen({super.key});
  @override
  State<BinScreen> createState() => _BinScreenState();
}

class _BinScreenState extends State<BinScreen> {
  final _ctrl = TextEditingController();
  Map<String, dynamic>? _data;
  bool _loading = false;

  Future<void> _lookup() async {
    final bin = _ctrl.text.trim().replaceAll(' ', '');
    setState(() => _loading = true);
    _data = await BinService.lookup(bin);
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('BIN Checker')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'e.g. 414720',
              prefixIcon: Icon(Icons.credit_card),
            ),
            keyboardType: TextInputType.number,
            maxLength: 8,
            onSubmitted: (_) => _lookup(),
          ),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _lookup,
              icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
              label: Text(_loading ? 'Checking...' : 'Check BIN'),
            ),
          ),
          if (_data != null) ...[
            const SizedBox(height: 20),
            SectionCard(
              title: 'BIN: ${_ctrl.text.trim()}',
              subtitle: _data!['scheme'] ?? 'Unknown',
              icon: Icons.credit_card,
              color: Colors.green,
              children: [
                ResultRow(label: 'Scheme', value: _data!['scheme'] ?? '-'),
                ResultRow(label: 'Type', value: _data!['type'] ?? '-'),
                ResultRow(label: 'Brand', value: _data!['brand'] ?? '-'),
                ResultRow(label: 'Prepaid', value: _data!['prepaid'] == true ? 'Yes' : 'No'),
                ResultRow(label: 'Country', value: _data!['country']?['name'] ?? '-'),
                ResultRow(label: 'Currency', value: _data!['country']?['currency'] ?? '-'),
                ResultRow(label: 'Bank', value: _data!['bank']?['name'] ?? '-'),
                ResultRow(label: 'Bank URL', value: _data!['bank']?['url'] ?? '-'),
                ResultRow(label: 'Bank Phone', value: _data!['bank']?['phone'] ?? '-'),
              ],
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
