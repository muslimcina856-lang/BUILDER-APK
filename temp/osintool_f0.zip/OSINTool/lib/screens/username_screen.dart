import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services.dart';
import '../platforms.dart';

class UsernameScreen extends StatefulWidget {
  const UsernameScreen({super.key});
  @override
  State<UsernameScreen> createState() => _UsernameScreenState();
}

class _UsernameScreenState extends State<UsernameScreen> {
  final _ctrl = TextEditingController();
  List<Map<String, dynamic>>? _results;
  bool _loading = false;
  String? _selectedCategory;

  Future<void> _search() async {
    final username = _ctrl.text.trim();
    if (username.isEmpty) return;
    setState(() => _loading = true);

    if (_selectedCategory != null && _selectedCategory != 'All') {
      _results = await SocialService.searchCategory(username, _selectedCategory!);
    } else {
      _results = await SocialService.searchAll(username);
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final cats = ['All', ...platforms.map((p) => p.category).toSet()];
    return Scaffold(
      appBar: AppBar(title: const Text('Username Search')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(hintText: 'Enter username...', prefixIcon: Icon(Icons.person_search)),
            onSubmitted: (_) => _search(),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _selectedCategory ?? 'All',
            decoration: const InputDecoration(labelText: 'Category'),
            items: cats.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _selectedCategory = v),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _search,
              icon: _loading
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.search),
              label: Text(_loading ? 'Searching ${platforms.length} platforms...' : 'Search All Platforms'),
            ),
          ),
          if (_results != null) ...[
            const SizedBox(height: 20),
            Text('Found ${_results!.length} profiles',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text('Searched ${platforms.length} platforms',
                style: TextStyle(color: Colors.grey[500], fontSize: 12)),
            const SizedBox(height: 12),
            ..._results!.map((r) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: Container(
                  width: 8, height: 40,
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                title: Text(r['platform'], style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                subtitle: Text(r['category'], style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                trailing: IconButton(
                  icon: const Icon(Icons.open_in_new, size: 18),
                  onPressed: () async {
                    final uri = Uri.parse(r['url']);
                    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
                  },
                ),
              ),
            )),
          ],
          if (!_loading && _results == null)
            Padding(
              padding: const EdgeInsets.only(top: 40),
              child: Center(
                child: Column(
                  children: [
                    Icon(Icons.person_search, size: 64, color: Colors.grey[700]),
                    const SizedBox(height: 12),
                    Text('Search across ${platforms.length} platforms', style: TextStyle(color: Colors.grey[500])),
                    Text('SOCIAL · TECH · FORUMS · CREATIVE · BUSINESS · DATING · CRYPTO · ACADEMIC',
                        style: TextStyle(color: Colors.grey[700], fontSize: 10)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
