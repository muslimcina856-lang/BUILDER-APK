import 'package:flutter/material.dart';
import '../services.dart';

class SubdomainScreen extends StatefulWidget {
  const SubdomainScreen({super.key});
  @override
  State<SubdomainScreen> createState() => _SubdomainScreenState();
}

class _SubdomainScreenState extends State<SubdomainScreen> {
  final _ctrl = TextEditingController();
  List<String>? _subs;
  bool _loading = false;

  Future<void> _search() async {
    setState(() => _loading = true);
    _subs = await DnsService.subdomains(_ctrl.text.trim());
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Subdomain Enum')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(hintText: 'e.g. example.com', prefixIcon: Icon(Icons.dns)),
            onSubmitted: (_) => _search(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _search,
              icon: _loading
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.search),
              label: Text(_loading ? 'Enumerating...' : 'Enumerate Subdomains'),
            ),
          ),
          if (_subs != null) ...[
            const SizedBox(height: 20),
            Text('Found ${_subs!.length} subdomains',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            ..._subs!.map((s) => Card(
              margin: const EdgeInsets.only(bottom: 4),
              child: ListTile(
                dense: true,
                leading: const Icon(Icons.arrow_right, size: 16),
                title: Text(s, style: const TextStyle(fontSize: 12, fontFamily: 'monospace')),
              ),
            )),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
