import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class UuidScreen extends StatefulWidget {
  const UuidScreen({super.key});
  @override
  State<UuidScreen> createState() => _UuidScreenState();
}

class _UuidScreenState extends State<UuidScreen> {
  String _uuid = '';

  void _generate() {
    final rng = Random.secure();
    final bytes = List<int>.generate(16, (_) => rng.nextInt(256));
    bytes[6] = (bytes[6] & 0x0F) | 0x40;
    bytes[8] = (bytes[8] & 0x3F) | 0x80;
    _uuid = '${_hex4(bytes[0], bytes[1], bytes[2], bytes[3])}-${_hex4(bytes[4], bytes[5])}-${_hex4(bytes[6], bytes[7])}-${_hex4(bytes[8], bytes[9])}-${_hex6(bytes[10], bytes[11], bytes[12], bytes[13], bytes[14], bytes[15])}'.toUpperCase();
    setState(() {});
  }

  String _hex4(int a, int b, [int? c, int? d]) {
    final list = [a, b]; if (c != null) list.add(c); if (d != null) list.add(d);
    return list.map((n) => n.toRadixString(16).padLeft(2, '0')).join();
  }
  String _hex6(int a, int b, int c, int d, int e, int f) {
    return [a,b,c,d,e,f].map((n) => n.toRadixString(16).padLeft(2, '0')).join();
  }

  @override
  void initState() { super.initState(); _generate(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('UUID Generator')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Icon(Icons.tag, size: 48, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(height: 16),
                  SelectableText(_uuid, style: const TextStyle(fontSize: 16, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('UUID v4', style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton.icon(
                        onPressed: _generate,
                        icon: const Icon(Icons.refresh, size: 18),
                        label: const Text('Generate New'),
                      ),
                      const SizedBox(width: 12),
                      OutlinedButton.icon(
                        onPressed: () => Clipboard.setData(ClipboardData(text: _uuid)),
                        icon: const Icon(Icons.copy, size: 18),
                        label: const Text('Copy'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
