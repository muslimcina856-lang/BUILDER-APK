import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'ip_screen.dart';
import 'dns_screen.dart';
import 'mac_screen.dart';
import 'bin_screen.dart';
import 'phone_screen.dart';
import 'email_screen.dart';
import 'breach_screen.dart';
import 'username_screen.dart';
import 'hash_screen.dart';
import 'hash_id_screen.dart';
import 'base64_screen.dart';
import 'password_screen.dart';
import 'uuid_screen.dart';
import 'qr_screen.dart';
import 'url_screen.dart';
import 'multi_screen.dart';
import 'dork_screen.dart';
import 'subdomain_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _page = 0;
  String _publicIp = '';

  @override
  void initState() {
    super.initState();
    _fetchPublicIp();
  }

  Future<void> _fetchPublicIp() async {
    try {
      final res = await http.get(Uri.parse('https://api.ipify.org?format=json'));
      if (res.statusCode == 200) setState(() => _publicIp = jsonDecode(res.body)['ip']);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final ct = t.colorScheme.primary;

    final pages = [
      _buildHome(t, ct),
      _buildCategory(t, ct, Icons.language, 'Network Tools', [
        _CatItem('IP Lookup', Icons.wifi_tethering, 'Geolocation, ISP, ASN & more', 'ip'),
        _CatItem('DNS Lookup', Icons.dns, 'A, AAAA, MX, TXT records', 'dns'),
        _CatItem('MAC Lookup', Icons.memory, 'Find device vendor by MAC', 'mac'),
        _CatItem('Subdomain Enum', Icons.account_tree, 'Discover subdomains via crt.sh', 'subdomain'),
      ]),
      _buildCategory(t, ct, Icons.person, 'Identity Tools', [
        _CatItem('Phone Info', Icons.phone, 'Parse & validate phone numbers', 'phone'),
        _CatItem('Email Check', Icons.email, 'Validate email addresses', 'email'),
        _CatItem('BIN Checker', Icons.credit_card, 'Credit card BIN/IIN lookup', 'bin'),
        _CatItem('Username Search', Icons.person_search, 'Search across 150+ platforms', 'username'),
        _CatItem('Breach Check', Icons.shield, 'Check data breaches', 'breach'),
        _CatItem('Multi-Source', Icons.hub, 'Aggregate across multiple sources', 'multi'),
      ]),
      _buildCategory(t, ct, Icons.build, 'Utility Tools', [
        _CatItem('Google Dorking', Icons.search, 'Pre-built dork queries', 'dork'),
        _CatItem('Hash Generator', Icons.fingerprint, 'MD5, SHA1, SHA256, SHA512', 'hash'),
        _CatItem('Hash Identifier', Icons.manage_search, 'Identify hash type by format', 'hashid'),
        _CatItem('Base64', Icons.abc, 'Encode & decode Base64', 'base64'),
        _CatItem('Password Gen', Icons.password, 'Strong random passwords', 'password'),
        _CatItem('UUID Gen', Icons.tag, 'Generate UUID v4', 'uuid'),
        _CatItem('QR Code', Icons.qr_code, 'Generate QR codes', 'qr'),
        _CatItem('URL Tools', Icons.link, 'Encode, decode & analyze URLs', 'url'),
      ]),
    ];

    return Scaffold(
      appBar: _page == 0 ? null : AppBar(title: Text(_titles[_page])),
      body: pages[_page],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _page,
        onDestinationSelected: (i) => setState(() => _page = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.language_outlined), selectedIcon: Icon(Icons.language), label: 'Network'),
          NavigationDestination(icon: Icon(Icons.person_outlined), selectedIcon: Icon(Icons.person), label: 'Identity'),
          NavigationDestination(icon: Icon(Icons.build_outlined), selectedIcon: Icon(Icons.build), label: 'Tools'),
        ],
      ),
    );
  }

  final _titles = ['', 'Network', 'Identity', 'Tools'];

  Widget _buildHome(ThemeData t, Color ct) {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(top: 60, bottom: 20),
      child: Column(
        children: [
          Icon(Icons.public, size: 64, color: ct),
          const SizedBox(height: 16),
          Text('OSINT Tool', style: t.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('Open Source Intelligence Toolkit', style: TextStyle(color: Colors.grey[500])),
          const SizedBox(height: 24),
          if (_publicIp.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
              decoration: BoxDecoration(
                color: ct.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: ct.withValues(alpha: 0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.wifi, size: 18),
                  const SizedBox(width: 10),
                  Text('Your IP: $_publicIp', style: TextStyle(fontWeight: FontWeight.w600, color: ct)),
                ],
              ),
            ),
          const SizedBox(height: 32),
          _buildQuickGrid(t, ct),
        ],
      ),
    );
  }

  Widget _buildQuickGrid(ThemeData t, Color ct) {
    final items = [
      ('IP Lookup', Icons.wifi_tethering, 'ip'), ('DNS Lookup', Icons.dns, 'dns'),
      ('MAC Lookup', Icons.memory, 'mac'), ('BIN Checker', Icons.credit_card, 'bin'),
      ('Phone Info', Icons.phone, 'phone'), ('Email Check', Icons.email, 'email'),
      ('User Search', Icons.person_search, 'username'), ('Breach Check', Icons.shield, 'breach'),
      ('Multi-Source', Icons.hub, 'multi'), ('Google Dork', Icons.search, 'dork'),
      ('Hash Gen', Icons.fingerprint, 'hash'), ('Hash ID', Icons.manage_search, 'hashid'),
      ('Base64', Icons.abc, 'base64'), ('Password', Icons.password, 'password'),
      ('UUID', Icons.tag, 'uuid'), ('QR Code', Icons.qr_code, 'qr'),
      ('URL Tools', Icons.link, 'url'), ('Subdomain', Icons.account_tree, 'subdomain'),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 12),
            child: Text('Quick Access', style: t.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
          ),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: items.map((e) => _QuickButton(
              label: e.$1, icon: e.$2, color: ct,
              onTap: () => _navigate(e.$3),
            )).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildCategory(ThemeData t, Color ct, IconData icon, String title, List<_CatItem> items) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: items.length,
      separatorBuilder: (_, _) => const SizedBox(height: 8),
      itemBuilder: (ctx, i) {
        final item = items[i];
        return Card(
          child: ListTile(
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: ct.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(item.icon, color: ct),
            ),
            title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text(item.subtitle, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _navigate(item.tag),
          ),
        );
      },
    );
  }

  void _navigate(String tag) {
    final routes = <String, Widget>{
      'ip': const IpScreen(),
      'dns': const DnsScreen(),
      'mac': const MacScreen(),
      'bin': const BinScreen(),
      'phone': const PhoneScreen(),
      'email': const EmailScreen(),
      'breach': const BreachScreen(),
      'username': const UsernameScreen(),
      'hash': const HashScreen(),
      'hashid': const HashIdScreen(),
      'base64': const Base64Screen(),
      'password': const PasswordScreen(),
      'uuid': const UuidScreen(),
      'qr': const QrScreen(),
      'url': const UrlScreen(),
      'multi': const MultiScreen(),
      'dork': const DorkScreen(),
      'subdomain': const SubdomainScreen(),
    };
    if (routes.containsKey(tag)) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => routes[tag]!));
    }
  }
}

class _QuickButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _QuickButton({required this.label, required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color.withValues(alpha: 0.1),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 6),
              Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: color)),
            ],
          ),
        ),
      ),
    );
  }
}

class _CatItem {
  final String title, subtitle, tag;
  final IconData icon;
  _CatItem(this.title, this.icon, this.subtitle, this.tag);
}
