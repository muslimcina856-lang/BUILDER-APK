import 'package:flutter/material.dart';
import '../widgets/section_card.dart';
import '../services.dart';

class BreachScreen extends StatefulWidget {
  const BreachScreen({super.key});
  @override
  State<BreachScreen> createState() => _BreachScreenState();
}

class _BreachScreenState extends State<BreachScreen> {
  final _ctrl = TextEditingController();
  List<dynamic>? _breaches;
  bool _loading = false;

  Future<void> _check() async {
    setState(() => _loading = true);
    _breaches = await BreachService.check(_ctrl.text.trim());
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Breach Check')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'Enter email address...',
              prefixIcon: Icon(Icons.shield),
            ),
            keyboardType: TextInputType.emailAddress,
            onSubmitted: (_) => _check(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _check,
              icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
              label: Text(_loading ? 'Checking...' : 'Check Breaches'),
            ),
          ),
          if (_breaches != null) ...[
            const SizedBox(height: 20),
            _breaches!.isEmpty
                ? Card(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        children: [
                          Icon(Icons.check_circle, size: 48, color: Colors.green),
                          const SizedBox(height: 12),
                          const Text('No breaches found!', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 4),
                          Text('This email appears safe.', style: TextStyle(color: Colors.grey[500])),
                        ],
                      ),
                    ),
                  )
                : SectionCard(
                    title: 'Breaches Found',
                    subtitle: '${_breaches!.length} breach(es)',
                    icon: Icons.warning_amber,
                    color: Colors.red,
                    children: _breaches!.map((b) {
                      if (b is Map) {
                        return ResultRow(
                          label: b['name'] ?? 'Unknown',
                          value: b['domain'] ?? b['date'] ?? '',
                        );
                      }
                      return ResultRow(label: '$b', value: '');
                    }).toList(),
                  ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
