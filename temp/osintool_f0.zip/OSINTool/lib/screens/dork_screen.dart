import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services.dart';

class DorkScreen extends StatefulWidget {
  const DorkScreen({super.key});
  @override
  State<DorkScreen> createState() => _DorkScreenState();
}

class _DorkScreenState extends State<DorkScreen> {
  String? _selectedCat;
  List<Map<String, String>>? _queries;

  @override
  void initState() {
    super.initState();
    _queries = GoogleDorkService.getQueries(null);
  }

  @override
  Widget build(BuildContext context) {
    final cats = GoogleDorkService.categories.keys.toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Google Dorking')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Google Dork Queries', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text('${_queries?.length ?? 0} queries across ${cats.length} categories',
              style: TextStyle(color: Colors.grey[500], fontSize: 12)),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                ChoiceChip(label: const Text('All'), selected: _selectedCat == null, onSelected: (_) {
                  setState(() { _selectedCat = null; _queries = GoogleDorkService.getQueries(null); });
                }),
                const SizedBox(width: 8),
                ...cats.map((c) => Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(c, style: const TextStyle(fontSize: 12)),
                    selected: _selectedCat == c,
                    onSelected: (_) {
                      setState(() { _selectedCat = c; _queries = GoogleDorkService.getQueries(c); });
                    },
                  ),
                )),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ...(_queries ?? []).map((q) => Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              title: Text(q['query']!, style: const TextStyle(fontSize: 12, fontFamily: 'monospace')),
              subtitle: Text(q['category']!, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
              trailing: IconButton(
                icon: const Icon(Icons.copy, size: 18),
                onPressed: () => Clipboard.setData(ClipboardData(text: q['query']!)),
              ),
              onTap: () async {
                final url = Uri.parse('https://google.com/search?q=${Uri.encodeComponent(q['query']!)}');
                if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
              },
            ),
          )),
        ],
      ),
    );
  }
}
