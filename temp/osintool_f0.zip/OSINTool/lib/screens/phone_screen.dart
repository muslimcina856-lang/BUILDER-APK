import 'package:flutter/material.dart';
import '../widgets/section_card.dart';
import '../services.dart';

class PhoneScreen extends StatefulWidget {
  const PhoneScreen({super.key});
  @override
  State<PhoneScreen> createState() => _PhoneScreenState();
}

class _PhoneScreenState extends State<PhoneScreen> {
  final _ctrl = TextEditingController();
  Map<String, dynamic>? _data;

  void _parse() {
    setState(() => _data = PhoneService.parse(_ctrl.text.trim()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Phone Info')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'e.g. +1234567890',
              prefixIcon: Icon(Icons.phone),
            ),
            keyboardType: TextInputType.phone,
            onSubmitted: (_) => _parse(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _parse,
              icon: const Icon(Icons.search),
              label: const Text('Parse'),
            ),
          ),
          if (_data != null) ...[
            const SizedBox(height: 20),
            SectionCard(
              title: _data!['raw'],
              subtitle: _data!['valid'] == true ? 'Valid number' : 'Invalid number',
              icon: Icons.phone,
              color: _data!['valid'] == true ? Colors.green : Colors.red,
              children: [
                ResultRow(label: 'Country', value: _data!['country']),
                ResultRow(label: 'Country Code', value: _data!['code']),
                ResultRow(label: 'Local Number', value: _data!['local']),
                ResultRow(label: 'Length', value: '${_data!['length']} digits'),
                ResultRow(label: 'Valid', value: _data!['valid'] ? 'Yes' : 'No', valueColor: _data!['valid'] ? Colors.green : Colors.red),
                ResultRow(label: 'Type', value: _data!['possible_carrier']),
              ],
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
