import 'package:flutter/material.dart';
import '../widgets/section_card.dart';
import '../services.dart';

class MultiScreen extends StatefulWidget {
  const MultiScreen({super.key});
  @override
  State<MultiScreen> createState() => _MultiScreenState();
}

class _MultiScreenState extends State<MultiScreen> {
  final _ctrl = TextEditingController();
  String _type = 'Email';
  Map<String, dynamic>? _results;
  bool _loading = false;

  Future<void> _search() async {
    final q = _ctrl.text.trim();
    if (q.isEmpty) return;
    setState(() => _loading = true);
    _results = {};

    if (_type == 'Email') {
      final breaches = await BreachService.check(q);
      _results!['breaches'] = breaches;
      final domain = q.split('@').lastOrNull ?? '';
      final dns = await DnsService.lookup(domain, 'MX');
      _results!['dns'] = dns;
    } else if (_type == 'IP') {
      final ip = await IpService.lookup(q);
      _results!['ip'] = ip;
    } else if (_type == 'Domain') {
      final dns = await DnsService.lookup(q, 'A');
      _results!['dns'] = dns;
      final subs = await DnsService.subdomains(q);
      _results!['subdomains'] = subs;
    }

    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Multi-Source Search')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: InputDecoration(
              hintText: 'Search across multiple sources...',
              prefixIcon: const Icon(Icons.hub),
            ),
            onSubmitted: (_) => _search(),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _type,
            decoration: const InputDecoration(labelText: 'Type'),
            items: ['Email', 'IP', 'Domain', 'Phone'].map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
            onChanged: (v) => setState(() => _type = v!),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _search,
              icon: _loading
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.hub),
              label: Text(_loading ? 'Aggregating sources...' : 'Aggregate Sources'),
            ),
          ),
          if (_results != null && _results!.isNotEmpty) ...[
            const SizedBox(height: 20),
            for (final entry in _results!.entries)
              if (entry.value != null && entry.value is List && entry.value.isNotEmpty)
                SectionCard(
                  title: entry.key.toUpperCase(),
                  subtitle: '${entry.value.length} result(s)',
                  icon: Icons.list,
                  children: (entry.value as List).take(20).map((item) {
                    if (item is Map) {
                      return ResultRow(
                        label: item['source'] ?? item['name'] ?? item['type'] ?? '',
                        value: item['count']?.toString() ?? item['date'] ?? item['data'] ?? item.toString(),
                      );
                    }
                    return ResultRow(label: item.toString(), value: '');
                  }).toList(),
                ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
