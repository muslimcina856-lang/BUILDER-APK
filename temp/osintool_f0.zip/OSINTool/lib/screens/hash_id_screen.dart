import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class HashIdScreen extends StatefulWidget {
  const HashIdScreen({super.key});
  @override
  State<HashIdScreen> createState() => _HashIdScreenState();
}

class _HashIdScreenState extends State<HashIdScreen> {
  final _ctrl = TextEditingController();
  List<String>? _result;

  static final _patterns = [
    _Pattern(32, RegExp(r'^[0-9a-f]{32}$', caseSensitive: false), 'MD5, MD4, MD2, RIPEMD-128'),
    _Pattern(40, RegExp(r'^[0-9a-f]{40}$', caseSensitive: false), 'SHA1, RIPEMD-160, HAVAL-160'),
    _Pattern(56, RegExp(r'^[0-9a-f]{56}$', caseSensitive: false), 'SHA224, SHA3-224'),
    _Pattern(64, RegExp(r'^[0-9a-f]{64}$', caseSensitive: false), 'SHA256, SHA3-256, BLAKE2s-256, SKEIN-256'),
    _Pattern(96, RegExp(r'^[0-9a-f]{96}$', caseSensitive: false), 'SHA384, SHA3-384'),
    _Pattern(128, RegExp(r'^[0-9a-f]{128}$', caseSensitive: false), 'SHA512, SHA3-512, BLAKE2b-512'),
    _Pattern(16, RegExp(r'^[0-9a-f]{16}$', caseSensitive: false), 'MySQL3, NTLM'),
    _Pattern(8, RegExp(r'^[0-9a-f]{8}$', caseSensitive: false), 'CRC32, Adler32'),
    _Pattern(0, RegExp(r'^\$2[ayb]\$.{56}$'), 'bcrypt'),
    _Pattern(0, RegExp(r'^\$5\$.{43}$'), 'SHA256-Crypt'),
    _Pattern(0, RegExp(r'^\$6\$.{86}$'), 'SHA512-Crypt'),
    _Pattern(0, RegExp(r'^[A-Za-z0-9+/]{20,}={0,2}$'), 'Base64 (decoded may be a hash)'),
  ];

  void _identify() {
    final hash = _ctrl.text.trim();
    if (hash.isEmpty) { setState(() => _result = null); return; }

    final matches = <String>[];
    for (final p in _patterns) {
      if (p.regex.hasMatch(hash)) {
        matches.add(p.name);
      }
    }

    if (RegExp(r'^[0-9a-f]+$', caseSensitive: false).hasMatch(hash)) {
      matches.add('Hex encoding (${hash.length} chars = ${hash.length * 4} bits)');
    }

    setState(() => _result = matches.isEmpty ? ['Unknown hash type'] : matches.toSet().toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hash Identifier')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'Paste hash to identify...',
              prefixIcon: Icon(Icons.manage_search),
            ),
            maxLines: 3,
            onSubmitted: (_) => _identify(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _identify,
              icon: const Icon(Icons.search),
              label: const Text('Identify'),
            ),
          ),
          if (_result != null) ...[
            const SizedBox(height: 20),
            SectionCard(
              title: 'Input: ${_ctrl.text.length} chars',
              subtitle: '${_result!.length} possible match(es)',
              icon: Icons.manage_search,
              color: _result!.first == 'Unknown hash type' ? Colors.red : Colors.green,
              children: _result!.map((r) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Icon(Icons.check_circle, size: 16, color: _result!.first == 'Unknown hash type' ? Colors.red : Colors.green),
                    const SizedBox(width: 10),
                    Expanded(child: Text(r, style: const TextStyle(fontSize: 13))),
                  ],
                ),
              )).toList(),
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}

class _Pattern {
  final int length;
  final RegExp regex;
  final String name;
  _Pattern(this.length, this.regex, this.name);
}
