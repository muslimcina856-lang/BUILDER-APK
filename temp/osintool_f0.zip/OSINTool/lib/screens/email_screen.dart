import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class EmailScreen extends StatefulWidget {
  const EmailScreen({super.key});
  @override
  State<EmailScreen> createState() => _EmailScreenState();
}

class _EmailScreenState extends State<EmailScreen> {
  final _ctrl = TextEditingController();
  Map<String, dynamic>? _data;

  void _check() {
    final email = _ctrl.text.trim();
    final parts = email.split('@');
    if (parts.length != 2) {
      setState(() => _data = {'valid': false, 'error': 'Invalid email format'});
      return;
    }
    final local = parts[0];
    final domain = parts[1];
    final disposable = ['mailinator.com', 'temp-mail.org', 'guerrillamail.com', '10minutemail.com',
      'yopmail.com', 'throwaway.email', 'sharklasers.com', 'trashmail.com', 'mailnator.com',
      'getnada.com', 'tempmail.net', 'fakeinbox.com', 'dispostable.com', 'mailexpire.com'];
    setState(() => _data = {
      'valid': RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$').hasMatch(email),
      'local': local,
      'domain': domain,
      'tld': domain.split('.').last,
      'disposable': disposable.contains(domain.toLowerCase()),
      'hasMx': true,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Email Check')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'e.g. user@example.com',
              prefixIcon: Icon(Icons.email),
            ),
            keyboardType: TextInputType.emailAddress,
            onSubmitted: (_) => _check(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _check,
              icon: const Icon(Icons.search),
              label: const Text('Analyze'),
            ),
          ),
          if (_data != null) ...[
            const SizedBox(height: 20),
            SectionCard(
              title: _ctrl.text.trim(),
              subtitle: _data!['valid'] ? 'Valid format' : 'Invalid format',
              icon: Icons.email,
              color: _data!['valid'] ? Colors.green : Colors.red,
              children: [
                ResultRow(label: 'Valid Format', value: _data!['valid'] ? 'Yes' : 'No'),
                ResultRow(label: 'Local Part', value: _data!['local'] ?? '-'),
                ResultRow(label: 'Domain', value: _data!['domain'] ?? '-'),
                ResultRow(label: 'TLD', value: '${_data!['tld'] ?? '-'}'),
                ResultRow(label: 'Disposable', value: _data!['disposable'] ? 'Yes (temp email)' : 'No'),
              ],
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
