import 'package:flutter/material.dart';
import '../widgets/section_card.dart';
import '../services.dart';

class MacScreen extends StatefulWidget {
  const MacScreen({super.key});
  @override
  State<MacScreen> createState() => _MacScreenState();
}

class _MacScreenState extends State<MacScreen> {
  final _ctrl = TextEditingController();
  Map<String, dynamic>? _data;
  bool _loading = false;

  Future<void> _lookup() async {
    setState(() => _loading = true);
    _data = await MacService.lookup(_ctrl.text.trim());
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('MAC Lookup')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'e.g. 00:1A:2B:3C:4D:5E',
              prefixIcon: Icon(Icons.memory),
            ),
            onSubmitted: (_) => _lookup(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _lookup,
              icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
              label: Text(_loading ? 'Looking up...' : 'Lookup'),
            ),
          ),
          if (_data != null) ...[
            const SizedBox(height: 20),
            SectionCard(
              title: _ctrl.text.trim(),
              subtitle: 'Vendor Information',
              icon: Icons.memory,
              children: _data!.entries.map((e) => ResultRow(label: _cap(e.key), value: '${e.value}')).toList(),
            ),
          ],
        ],
      ),
    );
  }

  String _cap(String s) => s[0].toUpperCase() + s.substring(1);

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
