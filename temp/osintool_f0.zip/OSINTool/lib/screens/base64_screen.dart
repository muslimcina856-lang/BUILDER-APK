import 'dart:convert';
import 'package:flutter/material.dart';
import '../widgets/section_card.dart';

class Base64Screen extends StatefulWidget {
  const Base64Screen({super.key});
  @override
  State<Base64Screen> createState() => _Base64ScreenState();
}

class _Base64ScreenState extends State<Base64Screen> {
  final _ctrl = TextEditingController();
  String _result = '';
  bool _encode = true;

  void _convert() {
    try {
      if (_encode) {
        _result = base64Encode(utf8.encode(_ctrl.text));
      } else {
        _result = utf8.decode(base64Decode(_ctrl.text));
      }
    } catch (e) {
      _result = 'Error: ${e.toString()}';
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Base64 Encoder/Decoder')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _ctrl,
            decoration: InputDecoration(
              hintText: _encode ? 'Enter text to encode...' : 'Enter Base64 to decode...',
              prefixIcon: const Icon(Icons.abc),
            ),
            maxLines: 4,
            onChanged: (_) => _convert(),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () { setState(() => _encode = true); _convert(); },
                  icon: const Icon(Icons.lock, size: 16),
                  label: const Text('Encode'),
                  style: _encode ? null : ElevatedButton.styleFrom(backgroundColor: Colors.grey[800]),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () { setState(() => _encode = false); _convert(); },
                  icon: const Icon(Icons.lock_open, size: 16),
                  label: const Text('Decode'),
                  style: !_encode ? null : ElevatedButton.styleFrom(backgroundColor: Colors.grey[800]),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (_result.isNotEmpty)
            SectionCard(
              title: _encode ? 'Base64 Output' : 'Decoded Output',
              subtitle: '${_result.length} chars',
              icon: Icons.output,
              children: [
                SelectableText(_result, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
              ],
            ),
        ],
      ),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
}
