import 'dart:convert';
import 'package:crypto/crypto.dart' as crypto;
import 'package:http/http.dart' as http;
import 'platforms.dart';

class IpService {
  static Future<Map<String, dynamic>?> lookup(String ip) async {
    try {
      final res = await http.get(Uri.parse('http://ip-api.com/json/$ip?fields=66846719'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://ipapi.co/$ip/json/'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }
}

class DnsService {
  static Future<List<Map<String, dynamic>>?> lookup(String domain, String type) async {
    try {
      final res = await http.get(Uri.parse('https://dns.google/resolve?name=$domain&type=$type'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final answers = List<Map<String, dynamic>>.from(data['Answer'] ?? []);
        if (answers.isNotEmpty) return answers;
      }
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://cloudflare-dns.com/dns-query?name=$domain&type=$type'),
          headers: {'Accept': 'application/dns-json'});
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return List<Map<String, dynamic>>.from(data['Answer'] ?? []);
      }
    } catch (_) {}
    return null;
  }

  static Future<List<String>?> subdomains(String domain) async {
    try {
      final res = await http.get(Uri.parse('https://crt.sh/?q=%25.$domain&output=json'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        final subs = data.map((e) => e['name_value']?.toString() ?? '').where((s) => s.isNotEmpty).toSet().toList();
        if (subs.isNotEmpty) return subs;
      }
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://api.securitytrails.com/v1/domain/$domain/subdomains'),
          headers: {'APIKEY': '', 'Accept': 'application/json'});
      if (res.statusCode == 200) return List<String>.from(jsonDecode(res.body)['subdomains']?.map((s) => '$s.$domain') ?? []);
    } catch (_) {}
    return null;
  }
}

class MacService {
  static Future<Map<String, dynamic>?> lookup(String mac) async {
    try {
      final res = await http.get(Uri.parse('https://api.macvendors.com/$mac'));
      if (res.statusCode == 200) return {'company': res.body};
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://www.macvendorlookup.com/api/v2/$mac'));
      if (res.statusCode == 200 && jsonDecode(res.body) is List && jsonDecode(res.body).isNotEmpty) {
        return jsonDecode(res.body)[0];
      }
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://macaddress.io/api/v1?apiKey=&output=json&search=$mac'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }
}

class BinService {
  static Future<Map<String, dynamic>?> lookup(String bin) async {
    try {
      final res = await http.get(Uri.parse('https://lookup.binlist.net/$bin'),
          headers: {'Accept': 'application/json'});
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://bincheck.io/api/v1/check/$bin'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://binlist.io/lookup/$bin'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }
}

class SocialService {
  static Future<List<Map<String, dynamic>>> searchAll(String username) async {
    final results = <Map<String, dynamic>>[];
    for (final p in platforms) {
      try {
        final url = p.url.replaceFirst('{}', Uri.encodeComponent(username));
        final res = await http.head(Uri.parse(url)).timeout(const Duration(seconds: 8));
        if (res.statusCode != 404 && res.statusCode != 403) {
          results.add({
            'platform': p.name,
            'url': url,
            'category': p.category,
            'status': res.statusCode,
          });
        }
      } catch (_) {}
    }
    return results;
  }

  static Future<List<Map<String, dynamic>>> searchCategory(String username, String category) async {
    final filtered = platforms.where((p) => p.category == category).toList();
    final results = <Map<String, dynamic>>[];
    for (final p in filtered) {
      try {
        final url = p.url.replaceFirst('{}', Uri.encodeComponent(username));
        final res = await http.head(Uri.parse(url)).timeout(const Duration(seconds: 8));
        if (res.statusCode != 404 && res.statusCode != 403) {
          results.add({'platform': p.name, 'url': url, 'category': p.category, 'status': res.statusCode});
        }
      } catch (_) {}
    }
    return results;
  }
}

class PhoneService {
  static const countryCodes = {
    '1': 'US/CA', '44': 'UK', '91': 'India', '81': 'Japan',
    '86': 'China', '49': 'Germany', '33': 'France', '39': 'Italy',
    '7': 'RU/KZ', '55': 'Brazil', '61': 'Australia', '82': 'South Korea',
    '31': 'Netherlands', '34': 'Spain', '41': 'Switzerland', '46': 'Sweden',
    '47': 'Norway', '45': 'Denmark', '358': 'Finland', '48': 'Poland',
    '30': 'Greece', '351': 'Portugal', '353': 'Ireland', '43': 'Austria',
    '32': 'Belgium', '420': 'Czech', '36': 'Hungary', '40': 'Romania',
    '359': 'Bulgaria', '60': 'Malaysia', '62': 'Indonesia', '63': 'Philippines',
    '64': 'NZ', '65': 'Singapore', '66': 'Thailand', '84': 'Vietnam',
    '852': 'HK', '886': 'Taiwan', '971': 'UAE', '966': 'Saudi',
    '972': 'Israel', '90': 'Turkey', '98': 'Iran', '92': 'Pakistan',
    '880': 'Bangladesh', '234': 'Nigeria', '27': 'SA', '20': 'Egypt',
    '212': 'Morocco', '54': 'Argentina', '56': 'Chile', '57': 'Colombia',
    '51': 'Peru', '52': 'Mexico', '58': 'Venezuela', '593': 'Ecuador',
    '591': 'Bolivia', '595': 'Paraguay', '598': 'Uruguay', '506': 'Costa Rica',
    '507': 'Panama', '502': 'Guatemala', '503': 'El Salvador', '504': 'Honduras',
    '505': 'Nicaragua', '501': 'Belize', '53': 'Cuba', '809': 'Dominican Republic',
    '787': 'Puerto Rico', '673': 'Brunei', '95': 'Myanmar',
    '855': 'Cambodia', '856': 'Laos', '670': 'Timor-Leste',
  };

  static Map<String, dynamic> parse(String number) {
    String cleaned = number.replaceAll(RegExp(r'[^\d+]'), '');
    String? country;
    String code = '';
    for (final entry in countryCodes.entries) {
      if (cleaned.contains('+${entry.key}') || cleaned.startsWith(entry.key)) {
        if (entry.key.length > code.length) {
          code = entry.key;
          country = entry.value;
        }
      }
    }
    String local = cleaned.replaceAll('+$code', '').replaceAll(code, '');
    int len = local.length;
    return {
      'raw': number,
      'country': country ?? 'Unknown',
      'code': '+$code',
      'local': local,
      'length': len,
      'valid': len >= 6 && len <= 15,
      'possible_carrier': len == 10 ? 'Mobile (likely)' : (len >= 11 ? 'Landline (likely)' : 'Short code'),
    };
  }

  static Future<Map<String, dynamic>?> onlineCheck(String number) async {
    try {
      final cleaned = number.replaceAll(RegExp(r'[^\d]'), '');
      final res = await http.get(Uri.parse('https://phonevalidation.abstractapi.com/v1/?api_key=&phone=$cleaned'));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return null;
  }
}

class BreachService {
  static Future<List<Map<String, dynamic>>> check(String email) async {
    final results = <Map<String, dynamic>>[];
    try {
      final hash = crypto.sha1.convert(utf8.encode(email)).toString().toUpperCase();
      final prefix = hash.substring(0, 5);
      final suffix = hash.substring(5);
      final res = await http.get(Uri.parse('https://api.pwnedpasswords.com/range/$prefix'));
      if (res.statusCode == 200 && res.body.contains(suffix)) {
        final lines = res.body.split('\n');
        for (final line in lines) {
          if (line.startsWith(suffix)) {
            results.add({'source': 'Have I Been Pwned', 'count': line.split(':').last.trim(), 'type': 'Password breach'});
          }
        }
      }
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://leak-check.net/api/v1/breach?email=$email'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['breaches'] is List) {
          for (final b in data['breaches']) {
            results.add({'source': 'Leak-Check', 'name': b['name'] ?? 'Unknown', 'date': b['date'] ?? ''});
          }
        }
      }
    } catch (_) {}
    try {
      final res = await http.get(Uri.parse('https://emailrep.io/$email'),
          headers: {'Accept': 'application/json'});
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['breaches'] == true) {
          results.add({'source': 'EmailRep.io', 'type': 'Found in breaches', 'details': data['details']?.toString() ?? ''});
        }
        results.add({'source': 'EmailRep.io', 'reputation': '${data['reputation'] ?? 'unknown'}'});
      }
    } catch (_) {}
    return results;
  }
}

class GoogleDorkService {
  static const categories = {
    'Admin Panels': [
      'inurl:admin intitle:login',
      'inurl:admin/login.php',
      'inurl:/admin/ intitle:admin',
      'site:*/admin/ intitle:login',
      'intitle:"admin panel"',
      'inurl:admin intitle:control',
    ],
    'Configuration Files': [
      'filetype:env DB_PASSWORD',
      'filetype:sql "INSERT INTO"',
      'filetype:xml config',
      'filetype:ini "DB_HOST"',
      'filetype:env "API_KEY"',
      'filetype:json "password"',
    ],
    'Database Files': [
      'filetype:sql "create table"',
      'filetype:sql "INSERT INTO" password',
      'filetype:sql dump',
      'filetype:db "users"',
      'filetype:mdb "admin"',
      'filetype:sql "user" "pass"',
      'filetype:sql "DROP TABLE"',
    ],
    'Login Pages': [
      'intitle:"login" "sign in"',
      'inurl:login redirection',
      'intitle:login inurl:admin',
      'inurl:/account/login',
      'inurl:signin intitle:sign',
      'inurl:login.php?redirect',
    ],
    'Email & Documents': [
      'filetype:xls email domain',
      'filetype:pdf "email" "@"',
      'filetype:csv "email"',
      'filetype:pdf "confidential"',
      'filetype:docx "private"',
      'filetype:xlsx "salary"',
    ],
    'Cameras & IoT': [
      'intitle:"webcam" "live"',
      'intitle:"Live View / - AXIS"',
      'inurl:view/view.shtml',
      'intitle:"webcam 7" -www',
      'intitle:snapfish camera',
      'intitle:"ip camera"',
      'inurl:"cgi-bin/view"',
    ],
    'Vulnerable Files': [
      'filetype:php inurl:config',
      'filetype:bak inurl:config',
      'filetype:old inurl:config',
      'filetype:swp inurl:config',
      'filetype:log "password"',
      'filetype:log "error"',
    ],
    'Social Media OSINT': [
      'site:facebook.com "live" "photos"',
      'site:instagram.com "username"',
      'site:twitter.com "location"',
      'site:linkedin.com "email"',
      'site:reddit.com "user" "info"',
      'site:tiktok.com "bio" "link"',
    ],
  };

  static List<Map<String, String>> getQueries(String? category) {
    final queries = <Map<String, String>>[];
    for (final cat in categories.entries) {
      if (category != null && cat.key != category) continue;
      for (final q in cat.value) {
        queries.add({'query': q, 'category': cat.key});
      }
    }
    return queries;
  }
}
