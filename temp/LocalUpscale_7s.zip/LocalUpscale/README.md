# LocalUpscale

Aplikasi Android offline AI image upscaler.

## Ciri-ciri
- First launch → auto download AI model (ada progress)
- Selepas download, terus offline
- Pilih gambar + skala 2x / 3x / 4x
- Preview hasil
- Simpan ke Gallery
- Dark theme Material 3
- Support share dari app lain

## Cara Build
1. Buka folder `LocalUpscale` di Android Studio
2. Sync Gradle
3. Run

## Package
`com.localupscale.app`
