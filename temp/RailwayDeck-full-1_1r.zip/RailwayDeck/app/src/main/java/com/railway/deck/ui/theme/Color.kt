package com.railway.deck.ui.theme

import androidx.compose.ui.graphics.Color

val Charcoal = Color(0xFF0F0F0F)
val CharcoalElevated = Color(0xFF1A1A1A)
val CharcoalCard = Color(0xFF1E1E1E)

val GreenStatus = Color(0xFF4ADE80)      // Running
val OrangeStatus = Color(0xFFFBBF24)     // Building
val RedStatus = Color(0xFFEF4444)        // Failed / Crashed
val GreyStatus = Color(0xFF6B7280)       // Stopped

val TextPrimary = Color(0xFFF5F5F5)
val TextSecondary = Color(0xFFA3A3A3)
val TextMuted = Color(0xFF737373)

val Accent = Color(0xFF4ADE80)
val Border = Color(0xFF2A2A2A)
