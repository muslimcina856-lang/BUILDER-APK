package com.railway.deck.data.api

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Railway Public GraphQL API client.
 * Auth: Bearer API token
 */
class RailwayApi(private val tokenProvider: () -> String?) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val endpoint = "https://backboard.railway.com/graphql/v2"
    private val jsonMedia = "application/json".toMediaType()

    data class Project(
        val id: String,
        val name: String,
        val description: String? = null
    )

    data class Service(
        val id: String,
        val name: String
    )

    data class Environment(
        val id: String,
        val name: String
    )

    data class Deployment(
        val id: String,
        val status: String,
        val createdAt: String?,
        val url: String? = null
    )

    data class ProjectDetail(
        val project: Project,
        val services: List<Service>,
        val environments: List<Environment>
    )

    private fun execute(query: String, variables: JSONObject? = null): Result<JSONObject> {
        val token = tokenProvider()
            ?: return Result.failure(Exception("Tiada API token aktif"))
        return try {
            val payload = JSONObject()
                .put("query", query)
            if (variables != null) payload.put("variables", variables)

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMedia))
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return Result.failure(Exception("HTTP ${response.code}: $body"))
            }
            val json = JSONObject(body)
            if (json.has("errors")) {
                val msg = json.getJSONArray("errors").optJSONObject(0)?.optString("message")
                    ?: "GraphQL error"
                return Result.failure(Exception(msg))
            }
            Result.success(json.getJSONObject("data"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun meEmail(): Result<String?> {
        val q = """query { me { email } }"""
        return execute(q).mapCatching { it.optJSONObject("me")?.optString("email") }
    }

    fun listProjects(): Result<List<Project>> {
        val q = """
            query {
              projects {
                edges {
                  node { id name description }
                }
              }
            }
        """.trimIndent()
        return execute(q).mapCatching { data ->
            val edges = data.optJSONObject("projects")?.optJSONArray("edges") ?: JSONArray()
            buildList {
                for (i in 0 until edges.length()) {
                    val n = edges.getJSONObject(i).getJSONObject("node")
                    add(
                        Project(
                            id = n.getString("id"),
                            name = n.optString("name"),
                            description = n.optString("description").takeIf { it.isNotBlank() }
                        )
                    )
                }
            }
        }
    }

    fun getProject(projectId: String): Result<ProjectDetail> {
        val q = """
            query project(${'$'}id: String!) {
              project(id: ${'$'}id) {
                id name description
                services { edges { node { id name } } }
                environments { edges { node { id name } } }
              }
            }
        """.trimIndent()
        val vars = JSONObject().put("id", projectId)
        return execute(q, vars).mapCatching { data ->
            val p = data.getJSONObject("project")
            val services = p.optJSONObject("services")?.optJSONArray("edges") ?: JSONArray()
            val envs = p.optJSONObject("environments")?.optJSONArray("edges") ?: JSONArray()
            ProjectDetail(
                project = Project(p.getString("id"), p.optString("name"), p.optString("description")),
                services = (0 until services.length()).map {
                    val n = services.getJSONObject(it).getJSONObject("node")
                    Service(n.getString("id"), n.optString("name"))
                },
                environments = (0 until envs.length()).map {
                    val n = envs.getJSONObject(it).getJSONObject("node")
                    Environment(n.getString("id"), n.optString("name"))
                }
            )
        }
    }

    fun listDeployments(
        projectId: String,
        serviceId: String,
        environmentId: String?,
        first: Int = 10
    ): Result<List<Deployment>> {
        val q = """
            query deployments(${'$'}input: DeploymentListInput!, ${'$'}first: Int) {
              deployments(input: ${'$'}input, first: ${'$'}first) {
                edges {
                  node { id status createdAt url staticUrl }
                }
              }
            }
        """.trimIndent()
        val input = JSONObject()
            .put("projectId", projectId)
            .put("serviceId", serviceId)
        if (!environmentId.isNullOrBlank()) input.put("environmentId", environmentId)
        val vars = JSONObject().put("input", input).put("first", first)
        return execute(q, vars).mapCatching { data ->
            val edges = data.optJSONObject("deployments")?.optJSONArray("edges") ?: JSONArray()
            (0 until edges.length()).map {
                val n = edges.getJSONObject(it).getJSONObject("node")
                Deployment(
                    id = n.getString("id"),
                    status = n.optString("status"),
                    createdAt = n.optString("createdAt"),
                    url = n.optString("url").ifBlank { n.optString("staticUrl") }.ifBlank { null }
                )
            }
        }
    }

    fun getVariables(
        projectId: String,
        environmentId: String,
        serviceId: String?
    ): Result<Map<String, String>> {
        val q = """
            query variables(
              ${'$'}projectId: String!,
              ${'$'}environmentId: String!,
              ${'$'}serviceId: String
            ) {
              variables(
                projectId: ${'$'}projectId,
                environmentId: ${'$'}environmentId,
                serviceId: ${'$'}serviceId
              )
            }
        """.trimIndent()
        val vars = JSONObject()
            .put("projectId", projectId)
            .put("environmentId", environmentId)
        if (!serviceId.isNullOrBlank()) vars.put("serviceId", serviceId)
        return execute(q, vars).mapCatching { data ->
            val obj = data.opt("variables")
            if (obj is JSONObject) {
                obj.keys().asSequence().associateWith { obj.optString(it) }
            } else emptyMap()
        }
    }

    fun upsertVariable(
        projectId: String,
        environmentId: String,
        serviceId: String?,
        name: String,
        value: String
    ): Result<Unit> {
        val q = """
            mutation variableUpsert(${'$'}input: VariableUpsertInput!) {
              variableUpsert(input: ${'$'}input)
            }
        """.trimIndent()
        val input = JSONObject()
            .put("projectId", projectId)
            .put("environmentId", environmentId)
            .put("name", name)
            .put("value", value)
        if (!serviceId.isNullOrBlank()) input.put("serviceId", serviceId)
        val vars = JSONObject().put("input", input)
        return execute(q, vars).map { }
    }

    fun deleteVariable(
        projectId: String,
        environmentId: String,
        serviceId: String?,
        name: String
    ): Result<Unit> {
        val q = """
            mutation variableDelete(${'$'}input: VariableDeleteInput!) {
              variableDelete(input: ${'$'}input)
            }
        """.trimIndent()
        val input = JSONObject()
            .put("projectId", projectId)
            .put("environmentId", environmentId)
            .put("name", name)
        if (!serviceId.isNullOrBlank()) input.put("serviceId", serviceId)
        val vars = JSONObject().put("input", input)
        return execute(q, vars).map { }
    }

    /** Redeploy / trigger deploy for service instance */
    fun deployService(serviceId: String, environmentId: String): Result<Unit> {
        val q = """
            mutation serviceInstanceDeployV2(
              ${'$'}serviceId: String!,
              ${'$'}environmentId: String!
            ) {
              serviceInstanceDeployV2(
                serviceId: ${'$'}serviceId,
                environmentId: ${'$'}environmentId
              )
            }
        """.trimIndent()
        val vars = JSONObject()
            .put("serviceId", serviceId)
            .put("environmentId", environmentId)
        return execute(q, vars).map { }
    }

    fun deploymentRestart(deploymentId: String): Result<Unit> {
        val q = """
            mutation deploymentRestart(${'$'}id: String!) {
              deploymentRestart(id: ${'$'}id)
            }
        """.trimIndent()
        val vars = JSONObject().put("id", deploymentId)
        return execute(q, vars).map { }
    }
}
