package com.railway.deck.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color.Black,
    secondary = GreenStatus,
    background = Charcoal,
    surface = CharcoalElevated,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = CharcoalCard,
    outline = Border
)

@Composable
fun RailwayDeckTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
