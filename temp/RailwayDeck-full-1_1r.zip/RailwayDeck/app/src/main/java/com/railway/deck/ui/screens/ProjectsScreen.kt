package com.railway.deck.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.railway.deck.ui.theme.*
import com.railway.deck.ui.viewmodel.ProjectsViewModel

@Composable
fun ProjectsScreen(
    navController: NavController,
    viewModel: ProjectsViewModel = hiltViewModel()
) {
    val projects by viewModel.projects.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val error by viewModel.error.collectAsState()
    val detail by viewModel.detail.collectAsState()
    val deployments by viewModel.deployments.collectAsState()
    val variables by viewModel.variables.collectAsState()

    var selectedProjectId by remember { mutableStateOf<String?>(null) }
    var selectedServiceId by remember { mutableStateOf<String?>(null) }
    var selectedEnvId by remember { mutableStateOf<String?>(null) }
    var showVars by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { viewModel.loadProjects() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Projects", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (selectedProjectId == null) "Dari Railway API" else "Project detail",
                    color = TextSecondary, fontSize = 13.sp
                )
            }
            IconButton(onClick = {
                if (selectedProjectId == null) viewModel.loadProjects()
                else viewModel.loadProject(selectedProjectId!!)
            }) {
                Icon(Icons.Default.Refresh, null, tint = Accent)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (loading) {
            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
        }

        if (error != null) {
            Text(error!!, color = RedStatus, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))
        }
        if (statusMsg != null) {
            Text(statusMsg!!, color = Accent, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))
        }

        when {
            selectedProjectId == null -> {
                if (projects.isEmpty() && !loading) {
                    Text("Tiada project / token tak boleh akses", color = TextSecondary)
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(projects, key = { it.id }) { p ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                            modifier = Modifier.fillMaxWidth().clickable {
                                selectedProjectId = p.id
                                viewModel.loadProject(p.id)
                            }
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(p.name, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                if (!p.description.isNullOrBlank()) {
                                    Text(p.description!!, color = TextSecondary, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
            else -> {
                val d = detail
                TextButton(onClick = {
                    selectedProjectId = null
                    selectedServiceId = null
                    showVars = false
                }) { Text("← Kembali", color = Accent) }

                if (d != null) {
                    Text(d.project.name, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Environments", color = TextSecondary, fontSize = 12.sp)
                    d.environments.forEach { env ->
                        val selected = selectedEnvId == env.id
                        Text(
                            text = if (selected) "● ${env.name}" else "○ ${env.name}",
                            color = if (selected) Accent else TextPrimary,
                            modifier = Modifier
                                .clickable { selectedEnvId = env.id }
                                .padding(vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Services", color = TextSecondary, fontSize = 12.sp)
                    d.services.forEach { svc ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    selectedServiceId = svc.id
                                    val env = selectedEnvId ?: d.environments.firstOrNull()?.id
                                    selectedEnvId = env
                                    if (env != null) {
                                        viewModel.loadDeployments(d.project.id, svc.id, env)
                                    }
                                }
                        ) {
                            Row(
                                Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(svc.name, color = TextPrimary, fontWeight = FontWeight.Medium)
                                if (selectedServiceId == svc.id) {
                                    Text("selected", color = Accent, fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    if (selectedServiceId != null && selectedEnvId != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    viewModel.redeploy(selectedServiceId!!, selectedEnvId!!) { ok, err ->
                                        statusMsg = if (ok) "Redeploy dicetuskan" else err
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
                            ) { Text("Redeploy") }

                            OutlinedButton(onClick = {
                                showVars = true
                                viewModel.loadVariables(d.project.id, selectedEnvId!!, selectedServiceId)
                            }) { Text("Variables", color = TextPrimary) }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Deployments", color = TextSecondary, fontSize = 12.sp)
                        deployments.forEach { dep ->
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    Modifier.padding(12.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(dep.status, color = statusColor(dep.status), fontWeight = FontWeight.Medium)
                                        Text(dep.createdAt ?: dep.id.take(8), color = TextMuted, fontSize = 11.sp)
                                    }
                                    TextButton(onClick = {
                                        viewModel.restartDeployment(dep.id) { ok, err ->
                                            statusMsg = if (ok) "Restart OK" else err
                                        }
                                    }) { Text("Restart", color = Accent, fontSize = 12.sp) }
                                }
                            }
                        }
                    }

                    if (showVars) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Variables", color = TextSecondary, fontSize = 12.sp)
                        variables.forEach { (k, v) ->
                            Text("$k = ${v.take(40)}${if (v.length > 40) "…" else ""}",
                                color = TextPrimary, fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 2.dp))
                        }
                        if (variables.isEmpty()) Text("Tiada / gagal load", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun statusColor(status: String): Color {
    return when (status.uppercase()) {
        "SUCCESS", "ACTIVE", "RUNNING" -> GreenStatus
        "BUILDING", "DEPLOYING", "INITIALIZING" -> OrangeStatus
        "FAILED", "CRASHED", "REMOVED" -> RedStatus
        else -> TextPrimary
    }
}
