package com.railway.deck.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.railway.deck.ui.theme.*
import com.railway.deck.ui.viewmodel.AccountsViewModel
import com.railway.deck.ui.viewmodel.ProjectsViewModel

@Composable
fun HomeScreen(
    navController: NavController,
    accountsVm: AccountsViewModel = hiltViewModel(),
    projectsVm: ProjectsViewModel = hiltViewModel()
) {
    val activeAccount by accountsVm.activeAccount.collectAsState()
    val accounts by accountsVm.accounts.collectAsState()
    val projects by projectsVm.projects.collectAsState()
    val loading by projectsVm.loading.collectAsState()
    var showAccountMenu by remember { mutableStateOf(false) }

    LaunchedEffect(activeAccount?.id) {
        if (activeAccount != null) projectsVm.loadProjects()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Railway Deck", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Box {
                    Row(
                        modifier = Modifier.clickable { showAccountMenu = true }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeAccount?.let {
                                "${it.email} · ${it.workspaceName ?: it.alias}"
                            } ?: "Belum login",
                            color = if (activeAccount != null) Accent else TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        if (accounts.isNotEmpty()) {
                            Icon(Icons.Default.KeyboardArrowDown, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }
                    }
                    DropdownMenu(
                        expanded = showAccountMenu,
                        onDismissRequest = { showAccountMenu = false },
                        modifier = Modifier.background(CharcoalCard)
                    ) {
                        accounts.forEach { account ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "${account.email} / ${account.workspaceName ?: account.alias}",
                                        color = if (account.isActive) Accent else TextPrimary,
                                        fontSize = 13.sp
                                    )
                                },
                                onClick = {
                                    accountsVm.setActiveAccount(account.id)
                                    showAccountMenu = false
                                }
                            )
                        }
                        Divider(color = Border)
                        DropdownMenuItem(
                            text = { Text("+ Add Account", color = Accent) },
                            onClick = {
                                showAccountMenu = false
                                navController.navigate("login")
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(Modifier.weight(1f), "Projects", if (loading) "…" else "${projects.size}")
            StatCard(Modifier.weight(1f), "Running", "—", GreenStatus)
            StatCard(Modifier.weight(1f), "Failed", "—", RedStatus)
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text("Quick Actions", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickAction(Modifier.weight(1f), "Deploy", Icons.Default.CloudUpload) {
                navController.navigate("deploy")
            }
            QuickAction(Modifier.weight(1f), "Projects", Icons.Default.Add) {
                navController.navigate("projects")
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
        Text("Recent Projects", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(12.dp))

        if (activeAccount == null) {
            InfoCard("Belum login — tambah API token dulu")
        } else if (projects.isEmpty() && !loading) {
            InfoCard("Tiada project atau token tak boleh akses")
        } else {
            projects.take(5).forEach { p ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clickable { navController.navigate("projects") }
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(p.name, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(modifier: Modifier, title: String, value: String, valueColor: Color = TextPrimary) {
    Card(modifier = modifier, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = CharcoalCard)) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = valueColor, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(title, color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuickAction(modifier: Modifier, text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CharcoalCard, contentColor = TextPrimary)
    ) {
        Icon(icon, null, tint = Accent)
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 13.sp)
    }
}

@Composable
private fun InfoCard(msg: String) {
    Box(
        Modifier.fillMaxWidth().background(CharcoalCard, RoundedCornerShape(12.dp)).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(msg, color = TextSecondary, fontSize = 13.sp)
    }
}
