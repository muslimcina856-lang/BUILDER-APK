package com.railway.deck.data.model

data class Account(
    val id: String,
    val email: String,
    val workspaceId: String?,
    val workspaceName: String?,
    val alias: String,
    val isMaster: Boolean,
    val parentEmail: String? = null,
    val isActive: Boolean = false,
    val isTokenValid: Boolean = true
)
