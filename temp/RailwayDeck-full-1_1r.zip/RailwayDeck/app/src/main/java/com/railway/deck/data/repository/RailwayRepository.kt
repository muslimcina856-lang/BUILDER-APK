package com.railway.deck.data.repository

import com.railway.deck.auth.AccountManager
import com.railway.deck.data.api.RailwayApi
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RailwayRepository @Inject constructor(
    private val accountManager: AccountManager
) {
    private val api = RailwayApi { accountManager.getActiveToken() }

    suspend fun listProjects() = api.listProjects()
    suspend fun getProject(id: String) = api.getProject(id)
    suspend fun listDeployments(projectId: String, serviceId: String, envId: String?) =
        api.listDeployments(projectId, serviceId, envId)
    suspend fun getVariables(projectId: String, envId: String, serviceId: String?) =
        api.getVariables(projectId, envId, serviceId)
    suspend fun upsertVariable(projectId: String, envId: String, serviceId: String?, name: String, value: String) =
        api.upsertVariable(projectId, envId, serviceId, name, value)
    suspend fun deleteVariable(projectId: String, envId: String, serviceId: String?, name: String) =
        api.deleteVariable(projectId, envId, serviceId, name)
    suspend fun deployService(serviceId: String, envId: String) =
        api.deployService(serviceId, envId)
    suspend fun restartDeployment(deploymentId: String) =
        api.deploymentRestart(deploymentId)
}
