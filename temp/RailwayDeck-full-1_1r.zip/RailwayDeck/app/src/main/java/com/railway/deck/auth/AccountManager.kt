package com.railway.deck.auth

import com.railway.deck.data.model.Account
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AccountManager @Inject constructor(
    private val tokenStore: TokenStore
) {
    fun getAllAccountsFlat(): List<Account> {
        val activeId = tokenStore.getActiveAccountId()
        return tokenStore.getAccountIds().map { id ->
            val email = tokenStore.getEmail(id) ?: ""
            Account(
                id = id,
                email = email,
                workspaceId = tokenStore.getWorkspaceId(id),
                workspaceName = tokenStore.getWorkspaceName(id),
                alias = tokenStore.getAlias(id) ?: email,
                isMaster = false,
                parentEmail = email,
                isActive = id == activeId,
                isTokenValid = tokenStore.isTokenValid(id)
            )
        }.sortedWith(compareBy({ it.email }, { it.workspaceName ?: "" }))
    }

    fun getGroupedAccounts(): List<Pair<String, List<Account>>> {
        return getAllAccountsFlat()
            .groupBy { it.email }
            .toList()
            .sortedBy { it.first }
    }

    fun getActiveAccount(): Account? {
        val id = tokenStore.getActiveAccountId() ?: return null
        return getAllAccountsFlat().find { it.id == id }
    }

    fun setActiveAccount(id: String) {
        tokenStore.setActiveAccountId(id)
    }

    fun getActiveToken(): String? {
        val id = tokenStore.getActiveAccountId() ?: return null
        return tokenStore.getToken(id)
    }

    fun exists(email: String, workspaceId: String?): Boolean {
        val id = tokenStore.makeId(email, workspaceId)
        return tokenStore.getAccountIds().contains(id)
    }

    fun addAccount(
        email: String,
        workspaceId: String?,
        workspaceName: String?,
        apiToken: String,
        alias: String? = null
    ): Result<String> {
        if (exists(email, workspaceId)) {
            return Result.failure(
                IllegalStateException("Akaun ini sudah wujud (email + workspace sama). Tak boleh tambah semula.")
            )
        }
        val id = tokenStore.saveAccount(email, workspaceId, workspaceName, apiToken, alias)
        setActiveAccount(id)
        return Result.success(id)
    }

    fun removeWorkspace(id: String) {
        tokenStore.removeAccount(id)
        ensureActiveExists()
    }

    fun removeMasterAccount(email: String) {
        val ids = tokenStore.getAccountIds()
            .filter { tokenStore.getEmail(it) == email.trim().lowercase() }
        ids.forEach { tokenStore.removeAccount(it) }
        ensureActiveExists()
    }

    fun updateToken(id: String, apiToken: String): Result<Unit> {
        val verify = verifyToken(apiToken)
        if (verify.isFailure) {
            return Result.failure(verify.exceptionOrNull() ?: Exception("Token tidak sah"))
        }
        tokenStore.updateToken(id, apiToken)
        tokenStore.setTokenValid(id, true)
        return Result.success(Unit)
    }

    fun markTokenInvalid(id: String) {
        tokenStore.setTokenValid(id, false)
    }

    /** Semak semua token (background) */
    fun revalidateAll() {
        tokenStore.getAccountIds().forEach { id ->
            val token = tokenStore.getToken(id) ?: return@forEach
            val ok = verifyToken(token).isSuccess
            tokenStore.setTokenValid(id, ok)
        }
    }

    private fun ensureActiveExists() {
        val active = tokenStore.getActiveAccountId()
        val remaining = tokenStore.getAccountIds()
        if (active == null || active !in remaining) {
            if (remaining.isNotEmpty()) setActiveAccount(remaining.first())
            else tokenStore.clearActiveAccount()
        }
    }

    fun hasAnyAccount(): Boolean = tokenStore.getAccountIds().isNotEmpty()

    companion object {
        fun verifyToken(token: String): Result<String?> {
            return try {
                val client = OkHttpClient()
                val body = """{"query":"query { me { email } }"}"""
                    .toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url("https://backboard.railway.com/graphql/v2")
                    .addHeader("Authorization", "Bearer $token")
                    .addHeader("Content-Type", "application/json")
                    .post(body)
                    .build()
                val response = client.newCall(request).execute()
                val text = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return Result.failure(Exception("HTTP ${response.code}"))
                }
                val json = JSONObject(text)
                if (json.has("errors")) {
                    val msg = json.getJSONArray("errors").optJSONObject(0)?.optString("message")
                        ?: "Token tidak sah"
                    return Result.failure(Exception(msg))
                }
                val email = json.optJSONObject("data")?.optJSONObject("me")?.optString("email")
                Result.success(email)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
}
