package com.railway.deck.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.railway.deck.auth.AccountManager
import com.railway.deck.data.api.RailwayApi
import com.railway.deck.data.repository.RailwayRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class ProjectsViewModel @Inject constructor(
    private val repo: RailwayRepository,
    private val accountManager: AccountManager
) : ViewModel() {

    private val _projects = MutableStateFlow<List<RailwayApi.Project>>(emptyList())
    val projects: StateFlow<List<RailwayApi.Project>> = _projects.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _detail = MutableStateFlow<RailwayApi.ProjectDetail?>(null)
    val detail: StateFlow<RailwayApi.ProjectDetail?> = _detail.asStateFlow()

    private val _deployments = MutableStateFlow<List<RailwayApi.Deployment>>(emptyList())
    val deployments: StateFlow<List<RailwayApi.Deployment>> = _deployments.asStateFlow()

    private val _variables = MutableStateFlow<Map<String, String>>(emptyMap())
    val variables: StateFlow<Map<String, String>> = _variables.asStateFlow()

    fun loadProjects() {
        viewModelScope.launch {
            if (accountManager.getActiveToken() == null) {
                _error.value = "Tiada akaun aktif"
                return@launch
            }
            _loading.value = true
            _error.value = null
            val result = withContext(Dispatchers.IO) { repo.listProjects() }
            _loading.value = false
            if (result.isSuccess) {
                _projects.value = result.getOrDefault(emptyList())
            } else {
                _error.value = result.exceptionOrNull()?.message
                // mark token invalid if auth error
                val msg = result.exceptionOrNull()?.message?.lowercase() ?: ""
                if (msg.contains("unauthorized") || msg.contains("not authorized") || msg.contains("401")) {
                    accountManager.getActiveAccount()?.id?.let { accountManager.markTokenInvalid(it) }
                }
            }
        }
    }

    fun loadProject(id: String) {
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            val result = withContext(Dispatchers.IO) { repo.getProject(id) }
            _loading.value = false
            if (result.isSuccess) _detail.value = result.getOrNull()
            else _error.value = result.exceptionOrNull()?.message
        }
    }

    fun loadDeployments(projectId: String, serviceId: String, envId: String?) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { repo.listDeployments(projectId, serviceId, envId) }
            if (result.isSuccess) _deployments.value = result.getOrDefault(emptyList())
            else _error.value = result.exceptionOrNull()?.message
        }
    }

    fun loadVariables(projectId: String, envId: String, serviceId: String?) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { repo.getVariables(projectId, envId, serviceId) }
            if (result.isSuccess) _variables.value = result.getOrDefault(emptyMap())
            else _error.value = result.exceptionOrNull()?.message
        }
    }

    fun redeploy(serviceId: String, envId: String, onDone: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { repo.deployService(serviceId, envId) }
            onDone(result.isSuccess, result.exceptionOrNull()?.message)
        }
    }

    fun restartDeployment(id: String, onDone: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { repo.restartDeployment(id) }
            onDone(result.isSuccess, result.exceptionOrNull()?.message)
        }
    }

    fun upsertVariable(
        projectId: String, envId: String, serviceId: String?,
        name: String, value: String, onDone: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { repo.upsertVariable(projectId, envId, serviceId, name, value) }
            if (result.isSuccess) loadVariables(projectId, envId, serviceId)
            onDone(result.isSuccess, result.exceptionOrNull()?.message)
        }
    }
}
