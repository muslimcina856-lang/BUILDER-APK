package com.railway.deck.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.railway.deck.auth.AccountManager
import com.railway.deck.data.model.Account
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AccountsViewModel @Inject constructor(
    private val accountManager: AccountManager
) : ViewModel() {

    private val _accounts = MutableStateFlow<List<Account>>(emptyList())
    val accounts: StateFlow<List<Account>> = _accounts.asStateFlow()

    private val _grouped = MutableStateFlow<List<Pair<String, List<Account>>>>(emptyList())
    val grouped: StateFlow<List<Pair<String, List<Account>>>> = _grouped.asStateFlow()

    private val _activeAccount = MutableStateFlow<Account?>(null)
    val activeAccount: StateFlow<Account?> = _activeAccount.asStateFlow()

    init {
        refresh()
        revalidateTokens()
    }

    fun refresh() {
        viewModelScope.launch {
            _accounts.value = accountManager.getAllAccountsFlat()
            _grouped.value = accountManager.getGroupedAccounts()
            _activeAccount.value = accountManager.getActiveAccount()
        }
    }

    fun revalidateTokens() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                accountManager.revalidateAll()
            }
            refresh()
        }
    }

    fun setActiveAccount(id: String) {
        accountManager.setActiveAccount(id)
        refresh()
    }

    fun removeWorkspace(id: String) {
        accountManager.removeWorkspace(id)
        refresh()
    }

    fun removeMasterAccount(email: String) {
        accountManager.removeMasterAccount(email)
        refresh()
    }

    fun addAccount(
        email: String,
        workspaceId: String?,
        workspaceName: String?,
        apiToken: String
    ): Boolean {
        val result = accountManager.addAccount(email, workspaceId, workspaceName, apiToken)
        if (result.isSuccess) {
            refresh()
            return true
        }
        return false
    }

    fun updateToken(id: String, apiToken: String, onDone: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                accountManager.updateToken(id, apiToken)
            }
            if (result.isSuccess) {
                refresh()
                onDone(true, null)
            } else {
                onDone(false, result.exceptionOrNull()?.message)
            }
        }
    }
}
