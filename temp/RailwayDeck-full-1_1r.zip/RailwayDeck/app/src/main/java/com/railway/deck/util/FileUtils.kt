package com.railway.deck.util

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object FileUtils {

    /**
     * Unzip ZIP file ke folder temporary.
     * Digunakan bila user pilih ZIP.
     */
    fun unzip(context: Context, zipUri: Uri, targetDir: File): Boolean {
        return try {
            if (!targetDir.exists()) targetDir.mkdirs()

            context.contentResolver.openInputStream(zipUri)?.use { inputStream ->
                ZipInputStream(BufferedInputStream(inputStream)).use { zis ->
                    var entry: ZipEntry? = zis.nextEntry
                    while (entry != null) {
                        val file = File(targetDir, entry.name)

                        // Security: elak zip slip
                        if (!file.canonicalPath.startsWith(targetDir.canonicalPath)) {
                            throw SecurityException("Zip slip detected: ${entry.name}")
                        }

                        if (entry.isDirectory) {
                            file.mkdirs()
                        } else {
                            file.parentFile?.mkdirs()
                            FileOutputStream(file).use { fos ->
                                zis.copyTo(fos)
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Compress folder jadi ZIP (untuk upload).
     * Auto ignore: .git, node_modules, __pycache__, .gradle, .idea, dll
     */
    fun zipFolder(sourceDir: File, outputZip: File): Boolean {
        val ignore = setOf(
            ".git", "node_modules", "__pycache__", ".gradle", ".idea",
            ".DS_Store", "build", "dist", ".next", "target"
        )

        return try {
            ZipOutputStream(FileOutputStream(outputZip)).use { zos ->
                sourceDir.walkTopDown()
                    .filter { it.isFile }
                    .filter { file ->
                        val relative = file.relativeTo(sourceDir).path
                        ignore.none { relative.startsWith(it) || relative.contains("/$it/") }
                    }
                    .forEach { file ->
                        val entryName = file.relativeTo(sourceDir).path
                        zos.putNextEntry(ZipEntry(entryName))
                        FileInputStream(file).use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
