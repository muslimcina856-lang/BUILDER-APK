package com.railway.deck.auth

import android.net.Uri
import com.railway.deck.BuildConfig
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.ResponseTypeValues
import net.openid.appauth.CodeVerifierUtil

object AuthConfig {
    // Railway OAuth endpoints (sama seperti yang digunakan oleh CLI)
    private const val AUTHORIZATION_ENDPOINT = "https://railway.com/oauth/authorize"
    private const val TOKEN_ENDPOINT = "https://railway.com/oauth/token"

    val serviceConfig = AuthorizationServiceConfiguration(
        Uri.parse(AUTHORIZATION_ENDPOINT),
        Uri.parse(TOKEN_ENDPOINT)
    )

    fun createAuthRequest(): AuthorizationRequest {
        val codeVerifier = CodeVerifierUtil.generateRandomCodeVerifier()
        val codeChallenge = CodeVerifierUtil.deriveCodeVerifierChallenge(codeVerifier)

        return AuthorizationRequest.Builder(
            serviceConfig,
            BuildConfig.RAILWAY_CLIENT_ID,          // WAJIB ganti dengan Client ID kau
            ResponseTypeValues.CODE,
            Uri.parse(BuildConfig.RAILWAY_REDIRECT_URI)
        )
            .setCodeVerifier(codeVerifier, codeChallenge, "S256")
            .setScopes(
                "openid",
                "email",
                "profile",
                "offline_access",
                "workspace:member",
                "project:member"
            )
            .build()
    }
}
