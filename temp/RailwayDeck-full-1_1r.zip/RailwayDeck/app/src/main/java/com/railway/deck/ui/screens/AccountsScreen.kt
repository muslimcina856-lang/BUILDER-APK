package com.railway.deck.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.railway.deck.data.model.Account
import com.railway.deck.ui.theme.*
import com.railway.deck.ui.viewmodel.AccountsViewModel

@Composable
fun AccountsScreen(
    navController: NavController,
    viewModel: AccountsViewModel = hiltViewModel()
) {
    val grouped by viewModel.grouped.collectAsState()

    var confirmWorkspaceId by remember { mutableStateOf<String?>(null) }
    var confirmWorkspaceLabel by remember { mutableStateOf("") }
    var confirmMasterEmail by remember { mutableStateOf<String?>(null) }

    // Re-auth dialog
    var reauthAccount by remember { mutableStateOf<Account?>(null) }
    var reauthToken by remember { mutableStateOf("") }
    var reauthError by remember { mutableStateOf<String?>(null) }
    var reauthLoading by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(16.dp)
    ) {
        Text("Railway Accounts", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("✓ token OK · ✗ token tak boleh akses", color = TextSecondary, fontSize = 13.sp)

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { navController.navigate("login") },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Add Account / Workspace", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (grouped.isEmpty()) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Belum ada akaun", color = TextPrimary, fontWeight = FontWeight.Medium)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                items(grouped, key = { it.first }) { (email, workspaces) ->
                    MasterGroup(
                        email = email,
                        workspaces = workspaces,
                        onSelect = { acc ->
                            if (acc.isTokenValid) {
                                viewModel.setActiveAccount(acc.id)
                            } else {
                                reauthAccount = acc
                                reauthToken = ""
                                reauthError = null
                            }
                        },
                        onDeleteWorkspace = { id, label ->
                            confirmWorkspaceId = id
                            confirmWorkspaceLabel = label
                        },
                        onDeleteMaster = { confirmMasterEmail = it }
                    )
                }
            }
        }
    }

    // Confirm padam workspace
    if (confirmWorkspaceId != null) {
        AlertDialog(
            onDismissRequest = { confirmWorkspaceId = null },
            title = { Text("Padam workspace?") },
            text = { Text("Workspace \"$confirmWorkspaceLabel\" akan dikeluarkan.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmWorkspaceId?.let { viewModel.removeWorkspace(it) }
                    confirmWorkspaceId = null
                }) { Text("Padam", color = RedStatus) }
            },
            dismissButton = {
                TextButton(onClick = { confirmWorkspaceId = null }) { Text("Batal") }
            },
            containerColor = CharcoalCard,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary
        )
    }

    // Confirm padam master
    if (confirmMasterEmail != null) {
        AlertDialog(
            onDismissRequest = { confirmMasterEmail = null },
            title = { Text("Padam seluruh akaun?") },
            text = { Text("Semua workspace di bawah $confirmMasterEmail akan keluar.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmMasterEmail?.let { viewModel.removeMasterAccount(it) }
                    confirmMasterEmail = null
                }) { Text("Padam Semua", color = RedStatus) }
            },
            dismissButton = {
                TextButton(onClick = { confirmMasterEmail = null }) { Text("Batal") }
            },
            containerColor = CharcoalCard,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary
        )
    }

    // Dialog masukkan API token baru
    if (reauthAccount != null) {
        val acc = reauthAccount!!
        AlertDialog(
            onDismissRequest = { if (!reauthLoading) reauthAccount = null },
            title = { Text("Token tak boleh akses") },
            text = {
                Column {
                    Text(
                        "Workspace: ${acc.workspaceName ?: acc.alias}\n" +
                                "Masukkan API token baru untuk akses semula.",
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = reauthToken,
                        onValueChange = { reauthToken = it },
                        label = { Text("API Token") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (reauthError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(reauthError!!, color = RedStatus, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !reauthLoading && reauthToken.isNotBlank(),
                    onClick = {
                        reauthLoading = true
                        reauthError = null
                        viewModel.updateToken(acc.id, reauthToken.trim()) { ok, err ->
                            reauthLoading = false
                            if (ok) {
                                viewModel.setActiveAccount(acc.id)
                                reauthAccount = null
                            } else {
                                reauthError = err ?: "Token tidak sah"
                            }
                        }
                    }
                ) {
                    Text(if (reauthLoading) "Semak..." else "Simpan", color = Accent)
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !reauthLoading,
                    onClick = { reauthAccount = null }
                ) { Text("Batal") }
            },
            containerColor = CharcoalCard,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary
        )
    }
}

@Composable
private fun MasterGroup(
    email: String,
    workspaces: List<Account>,
    onSelect: (Account) -> Unit,
    onDeleteWorkspace: (id: String, label: String) -> Unit,
    onDeleteMaster: (email: String) -> Unit
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Accent.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, null, tint = Accent, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = email,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { onDeleteMaster(email) }) {
                Text("Logout akaun", color = RedStatus, fontSize = 12.sp)
            }
        }

        workspaces.forEach { acc ->
            val label = acc.workspaceName ?: acc.alias
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (acc.isActive) Accent.copy(alpha = 0.12f) else CharcoalCard
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, bottom = 8.dp)
                    .clickable { onSelect(acc) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Tick / Pangkah
                    Icon(
                        imageVector = if (acc.isTokenValid) Icons.Default.Check else Icons.Default.Close,
                        contentDescription = null,
                        tint = if (acc.isTokenValid) GreenStatus else RedStatus,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(label, color = TextPrimary, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        Text(
                            text = when {
                                !acc.isTokenValid -> "Token tak boleh akses — tekan untuk update"
                                acc.isActive -> "Active"
                                else -> "Tekan untuk pilih"
                            },
                            color = if (!acc.isTokenValid) RedStatus else if (acc.isActive) Accent else TextMuted,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = { onDeleteWorkspace(acc.id, label) }) {
                        Icon(Icons.Default.Delete, null, tint = RedStatus)
                    }
                }
            }
        }
    }
}
