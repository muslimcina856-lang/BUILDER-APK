package com.railway.deck.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.railway.deck.linux.EmbeddedLinuxEnv
import com.railway.deck.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showLinuxSetup by remember { mutableStateOf(false) }
    var cliOutput by remember { mutableStateOf<String?>(null) }
    val env = remember { EmbeddedLinuxEnv(context) }
    val ready = remember { mutableStateOf(env.isReady()) }

    if (showLinuxSetup) {
        LinuxSetupScreen(
            onReady = {
                showLinuxSetup = false
                ready.value = true
            },
            onSkip = { showLinuxSetup = false }
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(16.dp)
    ) {
        Text("Settings", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(20.dp))

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Embedded Linux (experimental)", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(
                    "Alpine + proot + Railway CLI dalam storage app.\nBukan Termux. Untuk cuba railway up / upload.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    if (ready.value) "Status: READY" else "Status: belum setup",
                    color = if (ready.value) GreenStatus else OrangeStatus,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { showLinuxSetup = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (ready.value) "Setup semula" else "Setup Embedded Linux")
                }
                if (ready.value) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                env.railway(listOf("version"))
                            }
                            cliOutput = if (r.success) r.output else (r.error ?: r.output)
                        }
                    }) {
                        Text("Test: railway version", color = TextPrimary)
                    }
                }
            }
        }

        if (cliOutput != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Text("Output:", color = TextSecondary, fontSize = 12.sp)
            Text(cliOutput!!, color = TextPrimary, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text(
            "Nota: Ini experimental. Kalau proot/CLI gagal pada device kau, guna API Token + GitHub atau Deploy Bridge.",
            color = TextMuted,
            fontSize = 12.sp
        )
    }
}
