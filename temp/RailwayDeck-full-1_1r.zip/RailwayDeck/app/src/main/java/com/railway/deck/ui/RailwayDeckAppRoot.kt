package com.railway.deck.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.railway.deck.ui.screens.*
import com.railway.deck.ui.theme.Accent
import com.railway.deck.ui.theme.Charcoal
import com.railway.deck.ui.theme.CharcoalElevated
import com.railway.deck.ui.theme.TextSecondary
import com.railway.deck.ui.viewmodel.AccountsViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Home : Screen("home", "Home", Icons.Filled.Home)
    data object Projects : Screen("projects", "Projects", Icons.Outlined.Folder)
    data object Deploy : Screen("deploy", "Deploy", Icons.Filled.Upload)
    data object Accounts : Screen("accounts", "Accounts", Icons.Filled.AccountCircle)
    data object Settings : Screen("settings", "Settings", Icons.Filled.Settings)
}

@Composable
fun RailwayDeckAppRoot(
    accountsViewModel: AccountsViewModel = hiltViewModel()
) {
    val accounts by accountsViewModel.accounts.collectAsState()
    val hasAccount = accounts.isNotEmpty()
    // On first load accounts might be empty until refresh; also check manager via size after refresh
    var checked by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        accountsViewModel.refresh()
        checked = true
    }

    val navController = rememberNavController()
    val startDest = if (hasAccount) Screen.Home.route else "login"

    // Before accounts loaded, avoid flash — show nothing heavy
    if (!checked && !hasAccount) {
        // still allow nav after first composition with login start
    }

    val items = listOf(
        Screen.Home,
        Screen.Projects,
        Screen.Deploy,
        Screen.Accounts,
        Screen.Settings
    )

    // If no account, only show login (no bottom bar)
    if (!hasAccount) {
        NavHost(
            navController = navController,
            startDestination = "login"
        ) {
            composable("login") {
                LoginScreen(
                    navController = navController,
                    isFirstLaunch = true,
                    onLoginSuccess = {
                        accountsViewModel.refresh()
                    }
                )
            }
        }
        return
    }

    Scaffold(
        containerColor = Charcoal,
        bottomBar = {
            NavigationBar(
                containerColor = CharcoalElevated,
                contentColor = TextSecondary
            ) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                items.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        icon = { Icon(imageVector = screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent,
                            selectedTextColor = Accent,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(navController) }
            composable(Screen.Projects.route) { ProjectsScreen(navController) }
            composable(Screen.Deploy.route) { DeployScreen(navController) }
            composable(Screen.Accounts.route) { AccountsScreen(navController) }
            composable(Screen.Settings.route) { SettingsScreen(navController) }
            composable("login") {
                LoginScreen(navController = navController, isFirstLaunch = false)
            }
        }
    }
}
