package com.railway.deck.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.railway.deck.ui.theme.*

@Composable
fun DeployScreen(navController: NavController) {
    var selectedSource by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(16.dp)
    ) {
        Text(
            text = "Deploy from Phone",
            color = TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Pilih folder atau ZIP → Upload ke Railway",
            color = TextSecondary,
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Source selection
        Text(
            text = "1. Source",
            color = TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SourceButton(
                modifier = Modifier.weight(1f),
                title = "Choose Folder",
                subtitle = "Pilih folder project",
                icon = Icons.Default.FolderOpen,
                selected = selectedSource == "folder",
                onClick = { selectedSource = "folder" }
            )
            SourceButton(
                modifier = Modifier.weight(1f),
                title = "Choose ZIP",
                subtitle = "ZIP akan di-unzip dulu",
                icon = Icons.Default.UploadFile,
                selected = selectedSource == "zip",
                onClick = { selectedSource = "zip" }
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Info
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Cara kerja",
                    color = TextPrimary,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• Folder → scan + compress → upload\n" +
                            "• ZIP → unzip dulu → scan → upload\n" +
                            "• Auto ignore: .git, node_modules, __pycache__, dll\n" +
                            "• Ikut .gitignore / .railwayignore jika ada",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Deploy button
        Button(
            onClick = {
                // TODO: Launch SAF picker → process folder/ZIP → upload via Deploy Bridge
            },
            enabled = selectedSource != null,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Accent,
                contentColor = Color.Black,
                disabledContainerColor = CharcoalCard,
                disabledContentColor = TextMuted
            )
        ) {
            Text(
                text = if (selectedSource == null) "Pilih source dulu" else "Teruskan →",
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )
        }
    }
}

@Composable
private fun SourceButton(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (selected) Accent.copy(alpha = 0.15f) else CharcoalCard
    val border = if (selected) Accent else Border

    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = bg,
            contentColor = TextPrimary
        ),
        border = BorderStroke(1.dp, border)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = if (selected) Accent else TextSecondary)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            Text(text = subtitle, color = TextMuted, fontSize = 11.sp)
        }
    }
}
