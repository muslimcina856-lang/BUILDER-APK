package com.railway.deck

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RailwayDeckApp : Application()
