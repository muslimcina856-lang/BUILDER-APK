package com.railway.deck.auth

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TokenStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "railway_deck_secure_tokens",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    /** id format: email|workspaceId  atau  email|__personal__ */
    fun makeId(email: String, workspaceId: String?): String {
        val ws = workspaceId?.takeIf { it.isNotBlank() } ?: "__personal__"
        return "${email.trim().lowercase()}|$ws"
    }

    fun saveAccount(
        email: String,
        workspaceId: String?,
        workspaceName: String?,
        apiToken: String,
        alias: String? = null
    ): String {
        val id = makeId(email, workspaceId)
        val displayAlias = alias
            ?: workspaceName?.takeIf { it.isNotBlank() }
            ?: email

        prefs.edit()
            .putString("token_$id", apiToken)
            .putString("email_$id", email.trim().lowercase())
            .putString("ws_id_$id", workspaceId)
            .putString("ws_name_$id", workspaceName)
            .putString("alias_$id", displayAlias)
            .putBoolean("valid_$id", true)
            .apply()

        val ids = getAccountIds().toMutableSet()
        ids.add(id)
        prefs.edit().putStringSet("account_ids", ids).apply()

        // Track emails for master grouping
        val emails = getEmails().toMutableSet()
        emails.add(email.trim().lowercase())
        prefs.edit().putStringSet("emails", emails).apply()

        return id
    }

    fun getToken(id: String): String? = prefs.getString("token_$id", null)
    fun getEmail(id: String): String? = prefs.getString("email_$id", null)
    fun getWorkspaceId(id: String): String? = prefs.getString("ws_id_$id", null)
    fun getWorkspaceName(id: String): String? = prefs.getString("ws_name_$id", null)
    fun getAlias(id: String): String? = prefs.getString("alias_$id", null)

    fun isTokenValid(id: String): Boolean =
        prefs.getBoolean("valid_$id", true)

    fun setTokenValid(id: String, valid: Boolean) {
        prefs.edit().putBoolean("valid_$id", valid).apply()
    }

    fun updateToken(id: String, apiToken: String) {
        prefs.edit()
            .putString("token_$id", apiToken)
            .putBoolean("valid_$id", true)
            .apply()
    }

    fun getAccountIds(): Set<String> =
        prefs.getStringSet("account_ids", emptySet()) ?: emptySet()

    fun getEmails(): Set<String> =
        prefs.getStringSet("emails", emptySet()) ?: emptySet()

    fun setActiveAccountId(id: String) {
        prefs.edit().putString("active_account_id", id).apply()
    }

    fun getActiveAccountId(): String? =
        prefs.getString("active_account_id", null)

    fun clearActiveAccount() {
        prefs.edit().remove("active_account_id").apply()
    }

    fun removeAccount(id: String) {
        val email = getEmail(id)
        prefs.edit()
            .remove("token_$id")
            .remove("email_$id")
            .remove("ws_id_$id")
            .remove("ws_name_$id")
            .remove("alias_$id")
            .remove("valid_$id")
            .apply()

        val ids = getAccountIds().toMutableSet()
        ids.remove(id)
        prefs.edit().putStringSet("account_ids", ids).apply()

        // If no more accounts for this email, remove email from set
        if (email != null) {
            val stillHas = ids.any { getEmail(it) == email }
            if (!stillHas) {
                val emails = getEmails().toMutableSet()
                emails.remove(email)
                prefs.edit().putStringSet("emails", emails).apply()
            }
        }

        if (getActiveAccountId() == id) clearActiveAccount()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
