package com.railway.deck.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.railway.deck.linux.EmbeddedLinuxEnv
import com.railway.deck.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LinuxSetupScreen(onReady: () -> Unit, onSkip: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("Embedded Linux (experimental)") }
    var error by remember { mutableStateOf<String?>(null) }
    var running by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Embedded Linux", color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            "Download Alpine + proot + Railway CLI\ndalam storage app (bukan Termux)",
            color = TextSecondary,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "⚠️ Experimental — boleh gagal pada sesetengah device",
            color = OrangeStatus,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = Accent,
            trackColor = CharcoalCard
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(status, color = TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)
        if (error != null) {
            Text(error!!, color = RedStatus, fontSize = 12.sp, textAlign = TextAlign.Center)
        }

        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = {
                running = true
                error = null
                scope.launch {
                    val env = EmbeddedLinuxEnv(context)
                    val result = withContext(Dispatchers.IO) {
                        env.ensureReady { p, msg ->
                            progress = p
                            status = msg
                        }
                    }
                    running = false
                    if (result.isSuccess) {
                        status = "Siap"
                        onReady()
                    } else {
                        error = result.exceptionOrNull()?.message ?: "Gagal"
                    }
                }
            },
            enabled = !running,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
        ) {
            Text(if (running) "Downloading..." else "Setup Embedded Linux")
        }

        Spacer(modifier = Modifier.height(8.dp))
        TextButton(onClick = onSkip) {
            Text("Langkau — guna API Token je", color = TextSecondary)
        }
    }
}
