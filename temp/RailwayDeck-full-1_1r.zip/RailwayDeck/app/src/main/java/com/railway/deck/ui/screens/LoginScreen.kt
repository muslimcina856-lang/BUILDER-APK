package com.railway.deck.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.railway.deck.auth.AccountManager
import com.railway.deck.linux.EmbeddedLinuxEnv
import com.railway.deck.ui.theme.*
import com.railway.deck.ui.viewmodel.AccountsViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LoginScreen(
    navController: NavController,
    isFirstLaunch: Boolean = false,
    onLoginSuccess: (() -> Unit)? = null,
    viewModel: AccountsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val env = remember { EmbeddedLinuxEnv(context) }

    var status by remember { mutableStateOf("Login guna Railway CLI (embedded)") }
    var error by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var loginUrl by remember { mutableStateOf<String?>(null) }
    var showHelp by remember { mutableStateOf(false) }
    var detectedEmail by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = if (isFirstLaunch) "Login Railway" else "Add Account",
                color = TextPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { showHelp = true }) {
                Icon(Icons.Default.HelpOutline, "Help", tint = Accent)
            }
        }
        Text(
            "Guna Railway CLI dalam app\nEmail & workspace diisi automatik",
            color = TextSecondary,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = {
                error = null
                isLoading = true
                status = "Sediakan Embedded Linux (jika belum)..."
                scope.launch {
                    val setup = withContext(Dispatchers.IO) {
                        if (!env.isReady()) env.ensureReady { _, msg -> status = msg }
                        else Result.success(Unit)
                    }
                    if (setup.isFailure) {
                        isLoading = false
                        error = setup.exceptionOrNull()?.message ?: "Setup gagal"
                        status = "Gagal setup"
                        return@launch
                    }

                    status = "Menjalankan: railway login --browserless..."
                    val result = withContext(Dispatchers.IO) {
                        env.railwayLoginBrowserless(300)
                    }
                    val out = result.output
                    loginUrl = Regex("https://[^\\s]+").find(out)?.value

                    if (loginUrl != null) {
                        status = "Selesaikan login di browser, kemudian tekan langkah 2"
                        try {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(loginUrl))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {}
                    } else if (result.success) {
                        status = "CLI OK — baca token..."
                        finishCliLogin(env, viewModel, onLoginSuccess, isFirstLaunch, navController) { e, s, em ->
                            error = e; status = s; detectedEmail = em
                        }
                    } else {
                        error = (result.error ?: out).ifBlank {
                            "Login CLI gagal. Embedded proot/CLI mungkin tak jalan pada device ini."
                        }
                        status = "Gagal"
                    }
                    isLoading = false
                }
            },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
        ) {
            Text(
                if (isLoading) "Working..." else "1. Login with Railway CLI",
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = {
                isLoading = true
                error = null
                status = "Baca token + email dari CLI..."
                scope.launch {
                    finishCliLogin(env, viewModel, onLoginSuccess, isFirstLaunch, navController) { e, s, em ->
                        error = e; status = s; detectedEmail = em
                    }
                    isLoading = false
                }
            },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("2. Saya dah login — teruskan", color = TextPrimary)
        }

        if (loginUrl != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Text("Link login:", color = TextSecondary, fontSize = 12.sp)
            Text(loginUrl!!, color = Accent, fontSize = 11.sp)
            TextButton(onClick = {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("login", loginUrl))
                Toast.makeText(context, "Link disalin", Toast.LENGTH_SHORT).show()
            }) { Text("Salin link", color = Accent) }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(status, color = TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)
        if (detectedEmail != null) {
            Text("Email: $detectedEmail", color = GreenStatus, fontSize = 13.sp)
        }
        if (error != null) {
            Text(error!!, color = RedStatus, fontSize = 12.sp, textAlign = TextAlign.Center)
        }

        Spacer(modifier = Modifier.height(20.dp))
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Cara kerja", color = TextPrimary, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                Text(
                    "1. Embedded Linux setup (sekali)\n" +
                            "2. railway login --browserless\n" +
                            "3. Browser → Allow\n" +
                            "4. App baca token + email sendiri\n\n" +
                            "⚠️ CLI dalam proot = experimental",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }
        }
    }

    if (showHelp) {
        AlertDialog(
            onDismissRequest = { showHelp = false },
            title = { Text("CLI Login") },
            text = {
                Text(
                    "App jalankan Railway CLI (bundled) dalam Linux terisolasi.\n" +
                            "Selepas Allow, tekan \"Saya dah login\".",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { showHelp = false }) { Text("OK", color = Accent) }
            },
            containerColor = CharcoalCard,
            titleContentColor = TextPrimary
        )
    }
}

private suspend fun finishCliLogin(
    env: EmbeddedLinuxEnv,
    viewModel: AccountsViewModel,
    onLoginSuccess: (() -> Unit)?,
    isFirstLaunch: Boolean,
    navController: NavController,
    done: (error: String?, status: String, email: String?) -> Unit
) {
    val who = withContext(Dispatchers.IO) { env.railwayWhoami() }
    var email = Regex("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}").find(who.output)?.value

    val token = withContext(Dispatchers.IO) { env.readCliAccessToken() }
    if (token.isNullOrBlank()) {
        done(
            "Token CLI belum jumpa dalam config. Pastikan login selesai, atau proot gagal tulis fail.",
            "Token tiada",
            email
        )
        return
    }

    val verified = withContext(Dispatchers.IO) { AccountManager.verifyToken(token) }
    if (verified.isSuccess) {
        email = verified.getOrNull()?.ifBlank { null } ?: email
    }
    if (email.isNullOrBlank()) email = "cli-user@railway.local"

    val ok = viewModel.addAccount(
        email = email!!,
        workspaceId = null,
        workspaceName = "CLI",
        apiToken = token
    )
    if (ok) {
        onLoginSuccess?.invoke()
        if (!isFirstLaunch) {
            try { navController.popBackStack() } catch (_: Exception) {}
        }
        done(null, "Login berjaya", email)
    } else {
        done("Akaun (email+workspace) sudah wujud", "Sudah wujud", email)
    }
}
