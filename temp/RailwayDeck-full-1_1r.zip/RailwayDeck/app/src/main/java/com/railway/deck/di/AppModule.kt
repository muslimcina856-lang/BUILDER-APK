package com.railway.deck.di

import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * Hilt module.
 * TokenStore dan AccountManager sudah ada @Inject constructor + @Singleton,
 * jadi Hilt boleh provide terus tanpa @Provides tambahan.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule
