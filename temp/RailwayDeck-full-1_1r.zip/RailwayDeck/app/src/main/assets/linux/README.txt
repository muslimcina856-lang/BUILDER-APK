Bundled for Embedded Linux (experimental):
- alpine-aarch64.tar.gz  (~3.8MB)
- railway.tar.gz         (~8MB)  Railway CLI aarch64 musl
- proot-aarch64          (~0.8MB)
- proot-x86_64           (~0.9MB)

Extract on first Setup to app private storage.
