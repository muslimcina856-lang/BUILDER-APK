plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.dagger.hilt.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.railway.deck"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.railway.deck"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Wajib untuk AppAuth library (elak error appAuthRedirectScheme)
        manifestPlaceholders["appAuthRedirectScheme"] = "railwaydeck"

        // Railway OAuth - user perlu ganti dengan Client ID sendiri
        buildConfigField("String", "RAILWAY_CLIENT_ID", "\"YOUR_RAILWAY_CLIENT_ID\"")
        buildConfigField("String", "RAILWAY_REDIRECT_URI", "\"railwaydeck://oauth/callback\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Compose BOM
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.3")

    // Hilt
    implementation("com.google.dagger:hilt-android:2.52")
    ksp("com.google.dagger:hilt-compiler:2.52")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")

    // AppAuth for Railway OAuth (sama macam CLI)
    implementation("net.openid:appauth:0.11.1")

    // Network
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")

    // Apollo GraphQL (Railway API)
    implementation("com.apollographql.apollo:apollo-runtime:4.0.0")

    // Security
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    // Fix R8 missing errorprone annotations (Tink)
    implementation("com.google.errorprone:error_prone_annotations:2.28.0")
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Image / Coil
    implementation("io.coil-kt:coil-compose:2.7.0")

    // WorkManager (background upload)
    implementation("androidx.work:work-runtime-ktx:2.10.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
