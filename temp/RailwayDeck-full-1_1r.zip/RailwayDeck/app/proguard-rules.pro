# Railway Deck ProGuard / R8 rules

-keepattributes *Annotation*
-keep class com.railway.deck.** { *; }

# Fix missing errorprone annotations (dari security-crypto / Tink)
-dontwarn com.google.errorprone.annotations.**
-dontwarn com.google.errorprone.annotations.CanIgnoreReturnValue
-dontwarn com.google.errorprone.annotations.CheckReturnValue
-dontwarn com.google.errorprone.annotations.Immutable
-dontwarn com.google.errorprone.annotations.RestrictedApi

# Tink / security-crypto
-dontwarn com.google.crypto.tink.**
-keep class com.google.crypto.tink.** { *; }

# AppAuth
-dontwarn net.openid.appauth.**
-keep class net.openid.appauth.** { *; }

# OkHttp / Retrofit
-dontwarn okhttp3.**
-dontwarn retrofit2.**
-keep class okhttp3.** { *; }
-keep class retrofit2.** { *; }
