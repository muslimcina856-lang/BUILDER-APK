# Railway Deck

Unofficial Railway Android client.

## Auth
- API Token login (primary)
- Multi-account email + workspace

## Railway API
- Projects, services, environments
- Deployments, redeploy, restart
- Variables

## Embedded Linux (experimental) — pilihan B
Settings → Setup Embedded Linux

Download ke **storage dalam app** (bukan Termux):
1. Alpine minirootfs
2. proot
3. Railway CLI

Kemudian app cuba jalankan:
```
proot -r rootfs ... /usr/local/bin/railway ...
```

**WARNING:** Experimental. Boleh gagal (SELinux, linker, proot binary 404, tiada `tar`, dll).

## Upload source
Dengan embedded env yang berjaya + `railway login` dalam env itu, `railway up` secara teori boleh.
Secara praktikal masih high risk — Deploy Bridge lebih stabil untuk production.

## Build
Android Studio → Sync → Run
