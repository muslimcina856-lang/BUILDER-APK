/**
 * Railway Deck Deploy Bridge
 * 
 * Tugas:
 * - Terima ZIP dari Android
 * - Unzip (kalau perlu)
 * - Upload source ke Railway (via adapter / CLI equivalent)
 * - Padam temporary file selepas siap
 * 
 * Prinsip: zero permanent source retention
 */

import Fastify from 'fastify'
import cors from '@fastify/cors'
import multipart from '@fastify/multipart'
import { v4 as uuidv4 } from 'uuid'
import fs from 'fs-extra'
import path from 'path'

const app = Fastify({ logger: true })

await app.register(cors, { origin: true })
await app.register(multipart, {
  limits: {
    fileSize: 500 * 1024 * 1024 // 500 MB limit
  }
})

const TEMP_DIR = path.join(process.cwd(), 'tmp')
await fs.ensureDir(TEMP_DIR)

// Health check
app.get('/health', async () => {
  return { status: 'ok', service: 'railway-deck-deploy-bridge' }
})

/**
 * POST /v1/uploads
 * Android minta temporary upload session
 */
app.post('/v1/uploads', async (request, reply) => {
  const jobId = uuidv4()
  const jobDir = path.join(TEMP_DIR, jobId)
  await fs.ensureDir(jobDir)

  // Dalam production: generate presigned URL ke Railway Bucket / S3
  // Untuk MVP: kita terima direct upload dulu
  return {
    jobId,
    uploadUrl: `/v1/uploads/${jobId}`,
    expiresIn: 3600
  }
})

/**
 * POST /v1/uploads/:jobId
 * Terima ZIP dari Android
 */
app.post('/v1/uploads/:jobId', async (request, reply) => {
  const { jobId } = request.params as { jobId: string }
  const jobDir = path.join(TEMP_DIR, jobId)

  if (!await fs.pathExists(jobDir)) {
    return reply.code(404).send({ error: 'Job not found' })
  }

  const data = await request.file()
  if (!data) {
    return reply.code(400).send({ error: 'No file uploaded' })
  }

  const zipPath = path.join(jobDir, 'source.zip')
  await fs.writeFile(zipPath, await data.toBuffer())

  return {
    jobId,
    status: 'UPLOADED',
    message: 'ZIP received. Ready for deploy.'
  }
})

/**
 * POST /v1/deployments
 * Mulakan deployment
 * Body: { jobId, projectId, serviceId, environmentId, token (short-lived) }
 */
app.post('/v1/deployments', async (request, reply) => {
  const body = request.body as any
  const { jobId, projectId, serviceId } = body

  // TODO:
  // 1. Unzip source.zip
  // 2. Call Railway deploy adapter / CLI equivalent
  // 3. Stream build log
  // 4. Padam jobDir selepas selesai

  return {
    jobId,
    status: 'QUEUED',
    message: 'Deployment queued (adapter belum diimplement penuh)'
  }
})

/**
 * GET /v1/jobs/:id
 */
app.get('/v1/jobs/:id', async (request, reply) => {
  const { id } = request.params as { id: string }
  // TODO: return real status
  return {
    jobId: id,
    status: 'PREPARING'
  }
})

/**
 * DELETE /v1/jobs/:id
 * Padam temporary files
 */
app.delete('/v1/jobs/:id', async (request, reply) => {
  const { id } = request.params as { id: string }
  const jobDir = path.join(TEMP_DIR, id)
  await fs.remove(jobDir)
  return { deleted: true }
})

const port = Number(process.env.PORT) || 3000
app.listen({ port, host: '0.0.0.0' }).then(() => {
  console.log(`Railway Deck Deploy Bridge running on port ${port}`)
})
