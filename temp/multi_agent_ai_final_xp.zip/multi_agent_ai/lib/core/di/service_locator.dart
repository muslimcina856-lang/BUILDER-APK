import 'package:get_it/get_it.dart';
import '../../data/repositories/provider_repository.dart';
import '../../data/repositories/chat_repository.dart';
import '../../data/repositories/skill_repository.dart';
import '../../data/services/fallback_manager.dart';
import '../../data/services/shell_service.dart';

final sl = GetIt.instance;

void setupServiceLocator() {
  sl.registerLazySingleton<ProviderRepository>(() => ProviderRepository());
  sl.registerLazySingleton<ChatRepository>(() => ChatRepository());
  sl.registerLazySingleton<SkillRepository>(() => SkillRepository());
  sl.registerLazySingleton<FallbackManager>(() => FallbackManager());
  sl.registerLazySingleton<ShellService>(() => ShellService());
}
