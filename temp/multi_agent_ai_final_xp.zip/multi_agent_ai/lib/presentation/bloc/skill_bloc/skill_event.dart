part of 'skill_bloc.dart';

abstract class SkillEvent extends Equatable {
  const SkillEvent();
  @override
  List<Object?> get props => [];
}

class LoadSkills extends SkillEvent {}

class AddSkill extends SkillEvent {
  final String name;
  final String content;
  const AddSkill({required this.name, required this.content});
  @override
  List<Object?> get props => [name, content];
}

class UpdateSkill extends SkillEvent {
  final SkillModel skill;
  const UpdateSkill(this.skill);
  @override
  List<Object?> get props => [skill];
}

class DeleteSkill extends SkillEvent {
  final String skillId;
  final String skillName;
  const DeleteSkill({required this.skillId, required this.skillName});
  @override
  List<Object?> get props => [skillId, skillName];
}

class SearchSkills extends SkillEvent {
  final String query;
  const SearchSkills(this.query);
  @override
  List<Object?> get props => [query];
}
