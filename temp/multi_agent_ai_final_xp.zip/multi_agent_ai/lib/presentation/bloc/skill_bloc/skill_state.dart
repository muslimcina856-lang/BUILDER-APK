part of 'skill_bloc.dart';

abstract class SkillState extends Equatable {
  const SkillState();
  @override
  List<Object?> get props => [];
}

class SkillInitial extends SkillState {}

class SkillLoading extends SkillState {}

class SkillsLoaded extends SkillState {
  final List<SkillModel> skills;
  const SkillsLoaded({required this.skills});
  @override
  List<Object?> get props => [skills];
}

class SkillError extends SkillState {
  final String message;
  const SkillError({required this.message});
  @override
  List<Object?> get props => [message];
}
