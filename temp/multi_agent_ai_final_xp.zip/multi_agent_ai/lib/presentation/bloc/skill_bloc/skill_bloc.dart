import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';
import '../../../data/models/skill_model.dart';
import '../../../data/repositories/skill_repository.dart';

part 'skill_event.dart';
part 'skill_state.dart';

class SkillBloc extends Bloc<SkillEvent, SkillState> {
  final SkillRepository _repo;
  final Uuid _uuid = const Uuid();

  SkillBloc({required SkillRepository repo})
      : _repo = repo,
        super(SkillInitial()) {
    on<LoadSkills>(_onLoadSkills);
    on<AddSkill>(_onAddSkill);
    on<UpdateSkill>(_onUpdateSkill);
    on<DeleteSkill>(_onDeleteSkill);
    on<SearchSkills>(_onSearchSkills);
  }

  Future<void> _onLoadSkills(
      LoadSkills event, Emitter<SkillState> emit) async {
    emit(SkillLoading());
    try {
      await _repo.ensureDefaultSkill();
      final skills = await _repo.getAll();
      emit(SkillsLoaded(skills: skills));
    } catch (e) {
      emit(SkillError(message: 'Failed to load skills: $e'));
    }
  }

  Future<void> _onAddSkill(
      AddSkill event, Emitter<SkillState> emit) async {
    try {
      final existing = await _repo.getByName(event.name);
      if (existing != null) {
        emit(SkillError(message: 'Skill dengan nama "${event.name}" sudah wujud.'));
        return;
      }
      final skill = SkillModel(
        id: _uuid.v4(),
        name: event.name,
        content: event.content,
      );
      await _repo.save(skill);
      final skills = await _repo.getAll();
      emit(SkillsLoaded(skills: skills));
    } catch (e) {
      emit(SkillError(message: 'Failed to add skill: $e'));
    }
  }

  Future<void> _onUpdateSkill(
      UpdateSkill event, Emitter<SkillState> emit) async {
    try {
      await _repo.save(event.skill);
      final skills = await _repo.getAll();
      emit(SkillsLoaded(skills: skills));
    } catch (e) {
      emit(SkillError(message: 'Failed to update skill: $e'));
    }
  }

  Future<void> _onDeleteSkill(
      DeleteSkill event, Emitter<SkillState> emit) async {
    try {
      if (event.skillName == 'Skill Creator') {
        emit(SkillError(message: 'Skill "Skill Creator" tidak boleh dipadam.'));
        return;
      }
      await _repo.delete(event.skillId);
      final skills = await _repo.getAll();
      emit(SkillsLoaded(skills: skills));
    } catch (e) {
      emit(SkillError(message: 'Failed to delete skill: $e'));
    }
  }

  Future<void> _onSearchSkills(
      SearchSkills event, Emitter<SkillState> emit) async {
    try {
      final skills = await _repo.search(event.query);
      emit(SkillsLoaded(skills: skills));
    } catch (e) {
      emit(SkillError(message: 'Search failed: $e'));
    }
  }
}
