part of 'chat_bloc.dart';

abstract class ChatState extends Equatable {
  const ChatState();
  @override
  List<Object?> get props => [];
}

class ChatInitial extends ChatState {}

class ChatLoading extends ChatState {}

class ChatsLoaded extends ChatState {
  final List<ChatModel> chats;
  final ChatModel? currentChat;
  final bool isTyping;
  final String? selectedModelId;
  final String? selectedSkillId;

  const ChatsLoaded({
    required this.chats,
    this.currentChat,
    this.isTyping = false,
    this.selectedModelId,
    this.selectedSkillId,
  });

  @override
  List<Object?> get props =>
      [chats, currentChat, isTyping, selectedModelId, selectedSkillId];
}

class ChatError extends ChatState {
  final String message;
  const ChatError({required this.message});
  @override
  List<Object?> get props => [message];
}
