part of 'chat_bloc.dart';

abstract class ChatEvent extends Equatable {
  const ChatEvent();
  @override
  List<Object?> get props => [];
}

class LoadChats extends ChatEvent {}

class SearchChats extends ChatEvent {
  final String query;
  const SearchChats(this.query);
  @override
  List<Object?> get props => [query];
}

class CreateChat extends ChatEvent {
  final String modelId;
  final String? title;
  final String? skillId;
  final String? instructionOverride;

  const CreateChat({
    required this.modelId,
    this.title,
    this.skillId,
    this.instructionOverride,
  });
  @override
  List<Object?> get props => [modelId, title, skillId, instructionOverride];
}

class SelectChat extends ChatEvent {
  final String chatId;
  const SelectChat(this.chatId);
  @override
  List<Object?> get props => [chatId];
}

class SendMessage extends ChatEvent {
  final String content;
  final String modelId;
  final String? skillId;
  final String? instructionOverride;

  const SendMessage({
    required this.content,
    required this.modelId,
    this.skillId,
    this.instructionOverride,
  });
  @override
  List<Object?> get props =>
      [content, modelId, skillId, instructionOverride];
}

class DeleteChat extends ChatEvent {
  final String chatId;
  const DeleteChat(this.chatId);
  @override
  List<Object?> get props => [chatId];
}

class DeleteAllChats extends ChatEvent {}
