part of 'provider_bloc.dart';

abstract class ProviderState extends Equatable {
  const ProviderState();
  @override
  List<Object?> get props => [];
}

class ProviderInitial extends ProviderState {}

class ProviderLoading extends ProviderState {}

class ProvidersLoaded extends ProviderState {
  final List<ProviderModel> providers;
  const ProvidersLoaded({required this.providers});
  @override
  List<Object?> get props => [providers];
}

class ProviderError extends ProviderState {
  final String message;
  const ProviderError({required this.message});
  @override
  List<Object?> get props => [message];
}

class ConnectionTesting extends ProviderState {}

class ConnectionTestResult extends ProviderState {
  final bool success;
  final String message;
  const ConnectionTestResult({required this.success, required this.message});
  @override
  List<Object?> get props => [success, message];
}
