import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';
import '../../../data/models/provider_model.dart';
import '../../../data/models/api_key_model.dart';
import '../../../data/models/model_model.dart';
import '../../../data/repositories/provider_repository.dart';
import '../../../data/services/fallback_manager.dart';

part 'provider_event.dart';
part 'provider_state.dart';

class ProviderBloc extends Bloc<ProviderEvent, ProviderState> {
  final ProviderRepository _repo;
  final FallbackManager _fallbackManager;
  final Uuid _uuid = const Uuid();

  ProviderBloc({
    required ProviderRepository repo,
    required FallbackManager fallbackManager,
  })  : _repo = repo,
        _fallbackManager = fallbackManager,
        super(ProviderInitial()) {
    on<LoadProviders>(_onLoadProviders);
    on<AddProvider>(_onAddProvider);
    on<UpdateProvider>(_onUpdateProvider);
    on<DeleteProvider>(_onDeleteProvider);
    on<TestConnection>(_onTestConnection);
  }

  Future<void> _onLoadProviders(
      LoadProviders event, Emitter<ProviderState> emit) async {
    emit(ProviderLoading());
    try {
      final providers = await _repo.getAll();
      emit(ProvidersLoaded(providers: providers));
    } catch (e) {
      emit(ProviderError(message: 'Failed to load providers: $e'));
    }
  }

  Future<void> _onAddProvider(
      AddProvider event, Emitter<ProviderState> emit) async {
    try {
      final providerId = _uuid.v4();
      final provider = ProviderModel(
        id: providerId,
        name: event.name,
        baseUrl: event.baseUrl,
        extraHeaders: event.extraHeaders,
      );

      final apiKeys = <ApiKeyModel>[];
      for (int i = 0; i < event.apiKeys.length; i++) {
        apiKeys.add(ApiKeyModel(
          id: _uuid.v4(),
          providerId: providerId,
          key: event.apiKeys[i],
          priority: i,
        ));
      }

      final models = <ModelModel>[];
      for (int i = 0; i < event.models.length; i++) {
        models.add(ModelModel(
          id: _uuid.v4(),
          providerId: providerId,
          name: event.models[i],
          isDefault: i == 0,
        ));
      }

      await _repo.save(provider.copyWith(apiKeys: apiKeys, models: models));
      final providers = await _repo.getAll();
      emit(ProvidersLoaded(providers: providers));
    } catch (e) {
      emit(ProviderError(message: 'Failed to add provider: $e'));
    }
  }

  Future<void> _onUpdateProvider(
      UpdateProvider event, Emitter<ProviderState> emit) async {
    try {
      await _repo.save(event.provider);
      final providers = await _repo.getAll();
      emit(ProvidersLoaded(providers: providers));
    } catch (e) {
      emit(ProviderError(message: 'Failed to update provider: $e'));
    }
  }

  Future<void> _onDeleteProvider(
      DeleteProvider event, Emitter<ProviderState> emit) async {
    try {
      await _repo.delete(event.providerId);
      final providers = await _repo.getAll();
      emit(ProvidersLoaded(providers: providers));
    } catch (e) {
      emit(ProviderError(message: 'Failed to delete provider: $e'));
    }
  }

  Future<void> _onTestConnection(
      TestConnection event, Emitter<ProviderState> emit) async {
    emit(ConnectionTesting());
    try {
      final success = await _fallbackManager.testConnection(
        providerName: event.providerName,
        apiKey: event.apiKey,
        baseUrl: event.baseUrl,
        model: event.model,
      );
      if (success) {
        emit(ConnectionTestResult(success: true, message: 'Sambungan berjaya!'));
      } else {
        emit(ConnectionTestResult(
            success: false, message: 'Sambungan gagal. Sila semak URL dan kunci.'));
      }
    } catch (e) {
      emit(ConnectionTestResult(success: false, message: 'Ralat: $e'));
    }
  }
}
