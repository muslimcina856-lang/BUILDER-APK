part of 'provider_bloc.dart';

abstract class ProviderEvent extends Equatable {
  const ProviderEvent();
  @override
  List<Object?> get props => [];
}

class LoadProviders extends ProviderEvent {}

class AddProvider extends ProviderEvent {
  final String name;
  final String baseUrl;
  final String extraHeaders;
  final List<String> apiKeys;
  final List<String> models;

  const AddProvider({
    required this.name,
    required this.baseUrl,
    this.extraHeaders = '',
    required this.apiKeys,
    required this.models,
  });
  @override
  List<Object?> get props => [name, baseUrl, extraHeaders, apiKeys, models];
}

class UpdateProvider extends ProviderEvent {
  final ProviderModel provider;
  const UpdateProvider(this.provider);
  @override
  List<Object?> get props => [provider];
}

class DeleteProvider extends ProviderEvent {
  final String providerId;
  const DeleteProvider(this.providerId);
  @override
  List<Object?> get props => [providerId];
}

class TestConnection extends ProviderEvent {
  final String providerName;
  final String apiKey;
  final String baseUrl;
  final String? model;

  const TestConnection({
    required this.providerName,
    required this.apiKey,
    required this.baseUrl,
    this.model,
  });
  @override
  List<Object?> get props => [providerName, apiKey, baseUrl, model];
}
