import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '../bloc/chat_bloc/chat_bloc.dart';
import '../bloc/provider_bloc/provider_bloc.dart';
import '../bloc/skill_bloc/skill_bloc.dart';
import '../widgets/model_selector.dart';
import '../widgets/skill_selector.dart';
import 'chat_detail_page.dart';
import 'provider_page.dart';
import 'skill_page.dart';
import 'settings_page.dart';
import '../../data/models/chat_model.dart';
import '../../core/constants/strings.dart';
import '../../core/constants/constants.dart';
import '../../core/themes/app_theme.dart';

class ChatListPage extends StatefulWidget {
  const ChatListPage({super.key});

  @override
  State<ChatListPage> createState() => _ChatListPageState();
}

class _ChatListPageState extends State<ChatListPage> {
  int _currentIndex = 0;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    context.read<ChatBloc>().add(LoadChats());
    context.read<ProviderBloc>().add(LoadProviders());
    context.read<SkillBloc>().add(LoadSkills());
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          _buildChatListTab(),
          const ProviderPage(),
          const SkillPage(),
          const SettingsPage(),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBottomNav() {
    return NavigationBar(
      selectedIndex: _currentIndex,
      onDestinationSelected: (i) => setState(() => _currentIndex = i),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.chat_outlined), label: 'Chat'),
        NavigationDestination(
            icon: Icon(Icons.cloud_outlined), label: 'Provider'),
        NavigationDestination(
            icon: Icon(Icons.psychology_outlined), label: 'Skill'),
        NavigationDestination(
            icon: Icon(Icons.settings_outlined), label: 'Tetapan'),
      ],
    );
  }

  Widget _buildChatListTab() {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.appTitle),
        actions: [
          BlocBuilder<ChatBloc, ChatState>(
            builder: (context, state) {
              if (state is ChatsLoaded && state.chats.isNotEmpty) {
                return IconButton(
                  icon: const Icon(Icons.delete_sweep_outlined),
                  onPressed: () => _confirmDeleteAll(context),
                  tooltip: 'Padam semua chat',
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          _buildSearchBar(),
          Expanded(child: _buildChatList()),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showNewChatSheet(context),
        icon: const Icon(Icons.add),
        label: const Text(AppStrings.newChat),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: TextField(
        controller: _searchController,
        decoration: InputDecoration(
          hintText: AppStrings.search,
          prefixIcon: const Icon(Icons.search, size: 20),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear, size: 18),
                  onPressed: () {
                    _searchController.clear();
                    context.read<ChatBloc>().add(LoadChats());
                  },
                )
              : null,
          filled: true,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        ),
        onChanged: (v) {
          setState(() {});
          context.read<ChatBloc>().add(SearchChats(v));
        },
      ),
    );
  }

  Widget _buildChatList() {
    return BlocBuilder<ChatBloc, ChatState>(
      builder: (context, state) {
        if (state is ChatLoading) {
          return const Center(child: CircularProgressIndicator());
        }
        if (state is ChatError) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 48, color: AppTheme.errorColor),
                const SizedBox(height: 16),
                Text(state.message, textAlign: TextAlign.center),
              ],
            ),
          );
        }
        if (state is ChatsLoaded) {
          if (state.chats.isEmpty) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.chat_bubble_outline,
                      size: 64, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text(AppStrings.noChats,
                      style: TextStyle(
                          fontSize: 16, color: Colors.grey[500])),
                  const SizedBox(height: 24),
                  BlocBuilder<ProviderBloc, ProviderState>(
                    builder: (ctx, pState) {
                      if (pState is ProvidersLoaded &&
                          pState.providers.isEmpty) {
                        return ElevatedButton.icon(
                          onPressed: () => setState(() => _currentIndex = 1),
                          icon: const Icon(Icons.add),
                          label: const Text(AppStrings.addProviderBtn),
                        );
                      }
                      return ElevatedButton.icon(
                        onPressed: () => _showNewChatSheet(context),
                        icon: const Icon(Icons.add),
                        label: const Text(AppStrings.newChat),
                      );
                    },
                  ),
                ],
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.only(top: 4, bottom: 80),
            itemCount: state.chats.length,
            itemBuilder: (context, index) {
              final chat = state.chats[index];
              return _ChatListTile(
                chat: chat,
                onTap: () {
                  context.read<ChatBloc>().add(SelectChat(chat.id));
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => BlocProvider.value(
                        value: context.read<ChatBloc>(),
                        child: const ChatDetailPage(),
                      ),
                    ),
                  );
                },
                onDelete: () {
                  context.read<ChatBloc>().add(DeleteChat(chat.id));
                },
              );
            },
          );
        }
        return const SizedBox.shrink();
      },
    );
  }

  void _confirmDeleteAll(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Semua Chat'),
        content:
            const Text('Anda pasti mahu memadamkan semua sejarah chat?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text(AppStrings.cancel)),
          TextButton(
            onPressed: () {
              context.read<ChatBloc>().add(DeleteAllChats());
              Navigator.pop(ctx);
            },
            child: const Text(AppStrings.delete,
                style: TextStyle(color: AppTheme.errorColor)),
          ),
        ],
      ),
    );
  }

  void _showNewChatSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => const _NewChatSheet(),
    );
  }
}

class _ChatListTile extends StatelessWidget {
  final ChatModel chat;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _ChatListTile({
    required this.chat,
    required this.onTap,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final dateStr = DateFormat('dd/MM/yy HH:mm').format(chat.updatedAt);

    return Dismissible(
      key: Key(chat.id),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDelete(),
      background: Container(
        color: AppTheme.errorColor,
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child:
            const Icon(Icons.delete_outline, color: Colors.white),
      ),
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: AppTheme.primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.chat_outlined,
              color: AppTheme.primaryColor, size: 20),
        ),
        title: Text(
          chat.title.length > 50
              ? '${chat.title.substring(0, 50)}...'
              : chat.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15),
        ),
        subtitle: Text(
          dateStr,
          style: TextStyle(
              fontSize: 12,
              color: isDark ? Colors.grey[400] : Colors.grey[600]),
        ),
        trailing: Icon(Icons.chevron_right,
            size: 20, color: isDark ? Colors.grey[600] : Colors.grey[400]),
        onTap: onTap,
      ),
    );
  }
}

class _NewChatSheet extends StatefulWidget {
  const _NewChatSheet();

  @override
  State<_NewChatSheet> createState() => _NewChatSheetState();
}

class _NewChatSheetState extends State<_NewChatSheet> {
  String? _selectedModelId;
  String? _selectedSkillId;
  String? _instructionOverride;

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.4,
      maxChildSize: 0.9,
      expand: false,
      builder: (context, scrollController) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Mula Chat Baru',
                      style: TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w600)),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                controller: scrollController,
                children: [
                  BlocBuilder<ProviderBloc, ProviderState>(
                    builder: (context, state) {
                      if (state is ProvidersLoaded) {
                        return ModelSelector(
                          providers: state.providers,
                          selectedModelId: _selectedModelId,
                          onSelected: (id) =>
                              setState(() => _selectedModelId = id),
                        );
                      }
                      return const Center(child: CircularProgressIndicator());
                    },
                  ),
                  const Divider(),
                  BlocBuilder<SkillBloc, SkillState>(
                    builder: (context, state) {
                      if (state is SkillsLoaded) {
                        return SkillSelector(
                          skills: state.skills,
                          selectedSkillId: _selectedSkillId,
                          onSelected: (id) =>
                              setState(() => _selectedSkillId = id),
                        );
                      }
                      return const SizedBox.shrink();
                    },
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _selectedModelId == null
                        ? null
                        : () {
                            Navigator.pop(context);
                            _startChat(context);
                          },
                    child: const Text('Mula Chat'),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  void _startChat(BuildContext context) {
    context.read<ChatBloc>().add(CreateChat(
          modelId: _selectedModelId!,
          skillId: _selectedSkillId,
          instructionOverride: _instructionOverride,
        ));
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BlocProvider.value(
          value: context.read<ChatBloc>(),
          child: const ChatDetailPage(),
        ),
      ),
    );
  }
}
