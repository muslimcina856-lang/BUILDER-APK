import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/chat_bloc/chat_bloc.dart';
import '../widgets/chat_bubble.dart';
import '../../core/constants/strings.dart';
import '../../core/themes/app_theme.dart';
import '../../data/models/message_model.dart';
import 'package:intl/intl.dart';

class ChatDetailPage extends StatefulWidget {
  const ChatDetailPage({super.key});

  @override
  State<ChatDetailPage> createState() => _ChatDetailPageState();
}

class _ChatDetailPageState extends State<ChatDetailPage> {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ChatBloc, ChatState>(
      listener: (context, state) {
        if (state is ChatsLoaded) {
          _scrollToBottom();
        }
      },
      builder: (context, state) {
        if (state is! ChatsLoaded) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final chat = state.currentChat;
        final messages = chat?.messages ?? [];

        return Scaffold(
          appBar: AppBar(
            title: Text(
              chat?.title ?? AppStrings.newChat,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            actions: [
              if (chat != null)
                IconButton(
                  icon: const Icon(Icons.delete_outline, size: 20),
                  onPressed: () async {
                    context.read<ChatBloc>().add(DeleteChat(chat.id));
                    Navigator.pop(context);
                  },
                ),
            ],
          ),
          body: Column(
            children: [
              Expanded(
                child: messages.isEmpty
                    ? _buildEmptyState(state)
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        itemCount: messages.length,
                        itemBuilder: (context, index) {
                          final msg = messages[index];
                          final time = DateFormat('HH:mm').format(msg.timestamp);
                          return ChatBubble(
                            message: msg.content,
                            isUser: msg.role == 'user',
                            time: time,
                            modelName:
                                msg.role == 'assistant' ? state.selectedModelId : null,
                          );
                        },
                      ),
              ),
              if (state.isTyping)
                Container(
                  padding: const EdgeInsets.all(12),
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey[900]
                      : Colors.grey[100],
                  child: Row(
                    children: [
                      SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.primaryColor,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(AppStrings.typing,
                          style: TextStyle(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.grey[400]
                                  : Colors.grey[600])),
                    ],
                  ),
                ),
              _buildInputBar(state),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmptyState(ChatsLoaded state) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.chat_outlined,
              size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text('Hantar mesej untuk memulakan perbualan',
              style: TextStyle(fontSize: 16, color: Colors.grey[500])),
          const SizedBox(height: 8),
          Text(state.selectedModelId ?? 'Pilih model dahulu',
              style: TextStyle(
                  fontSize: 13,
                  color: AppTheme.primaryColor,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildInputBar(ChatsLoaded state) {
    return Container(
      padding: EdgeInsets.only(
        left: 12,
        right: 8,
        top: 8,
        bottom: MediaQuery.of(context).padding.bottom + 8,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.grey[800]!
                : Colors.grey[200]!,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _messageController,
              textInputAction: TextInputAction.send,
              minLines: 1,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: 'Taip mesej atau !sh ls ...',
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
              onSubmitted: (_) => _sendMessage(state),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(
            onPressed: () => _sendMessage(state),
            icon: const Icon(Icons.send_rounded, size: 20),
            style: IconButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _sendMessage(ChatsLoaded state) {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    _messageController.clear();
    context.read<ChatBloc>().add(SendMessage(
          content: text,
          modelId: state.selectedModelId ?? '',
          skillId: state.selectedSkillId,
          instructionOverride: state.currentChat?.instructionOverride,
        ));
    _scrollToBottom();
  }
}
