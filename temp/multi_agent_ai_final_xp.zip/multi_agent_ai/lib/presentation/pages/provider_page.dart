import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/provider_bloc/provider_bloc.dart';
import '../../data/models/provider_model.dart';
import '../../core/constants/strings.dart';
import '../../core/themes/app_theme.dart';

class ProviderPage extends StatefulWidget {
  const ProviderPage({super.key});

  @override
  State<ProviderPage> createState() => _ProviderPageState();
}

class _ProviderPageState extends State<ProviderPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.providers),
      ),
      body: BlocBuilder<ProviderBloc, ProviderState>(
        builder: (context, state) {
          if (state is ProviderLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state is ProviderError) {
            return Center(child: Text(state.message));
          }
          if (state is ProvidersLoaded) {
            if (state.providers.isEmpty) {
              return Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.cloud_off, size: 64, color: Colors.grey[400]),
                    const SizedBox(height: 16),
                    Text('Tiada provider AI',
                        style: TextStyle(fontSize: 16, color: Colors.grey[500])),
                    const SizedBox(height: 8),
                    Text('Tambah provider untuk memulakan.',
                        style: TextStyle(fontSize: 13, color: Colors.grey[500])),
                    const SizedBox(height: 24),
                    ElevatedButton.icon(
                      onPressed: () => _showAddProviderSheet(context),
                      icon: const Icon(Icons.add),
                      label: const Text(AppStrings.addProviderBtn),
                    ),
                  ],
                ),
              );
            }
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                ...state.providers.map((p) => _ProviderCard(provider: p)),
              ],
            );
          }
          return const SizedBox.shrink();
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddProviderSheet(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showAddProviderSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => const _AddProviderSheet(),
    );
  }
}

class _ProviderCard extends StatelessWidget {
  final ProviderModel provider;

  const _ProviderCard({required this.provider});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.cloud_outlined,
                      color: AppTheme.primaryColor, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(provider.name,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w600)),
                      Text(provider.baseUrl,
                          style: TextStyle(
                              fontSize: 12,
                              color: isDark
                                  ? Colors.grey[400]
                                  : Colors.grey[600]),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
                switch (provider.isActive) {
                  true => Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text('Aktif',
                          style: TextStyle(
                              fontSize: 11, color: Colors.green)),
                    ),
                  false => Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text('Tidak Aktif',
                          style: TextStyle(
                              fontSize: 11, color: Colors.grey[600])),
                    ),
                },
              ],
            ),
            const SizedBox(height: 12),
            if (provider.models.isNotEmpty) ...[
              Text('Model:',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.grey[400] : Colors.grey[600])),
              const SizedBox(height: 4),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: provider.models
                    .map((m) => Chip(
                          label: Text(m.name, style: const TextStyle(fontSize: 12)),
                          materialTapTargetSize:
                              MaterialTapTargetSize.shrinkWrap,
                          visualDensity: VisualDensity.compact,
                        ))
                    .toList(),
              ),
            ],
            if (provider.apiKeys.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('${provider.apiKeys.length} kunci API',
                  style: TextStyle(
                      fontSize: 12,
                      color: isDark ? Colors.grey[400] : Colors.grey[600])),
            ],
          ],
        ),
      ),
    );
  }
}

class _AddProviderSheet extends StatefulWidget {
  const _AddProviderSheet();

  @override
  State<_AddProviderSheet> createState() => _AddProviderSheetState();
}

class _AddProviderSheetState extends State<_AddProviderSheet> {
  final _nameController = TextEditingController();
  final _urlController = TextEditingController();
  final _apiKeysController = TextEditingController();
  final _modelsController = TextEditingController();
  final _headersController = TextEditingController();
  bool _isTesting = false;

  @override
  void dispose() {
    _nameController.dispose();
    _urlController.dispose();
    _apiKeysController.dispose();
    _modelsController.dispose();
    _headersController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Tambah Provider AI',
                      style: TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w600)),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                controller: scrollController,
                padding: const EdgeInsets.all(16),
                children: [
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Nama Provider',
                      hintText: 'Contoh: DeepSeek, OpenAI',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _urlController,
                    decoration: const InputDecoration(
                      labelText: 'URL Asas',
                      hintText: 'https://api.deepseek.com/v1',
                    ),
                    keyboardType: TextInputType.url,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _modelsController,
                    decoration: const InputDecoration(
                      labelText: 'Model (pisahkan dengan koma)',
                      hintText: 'deepseek-chat, deepseek-reasoner',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _apiKeysController,
                    decoration: const InputDecoration(
                      labelText: 'Kunci API (satu setiap baris)',
                      hintText: 'sk-xxx1\nsk-xxx2',
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _headersController,
                    decoration: const InputDecoration(
                      labelText: 'Header Tambahan (JSON, pilihan)',
                      hintText: '{"X-Custom": "value"}',
                    ),
                  ),
                  const SizedBox(height: 16),
                  BlocConsumer<ProviderBloc, ProviderState>(
                    listener: (context, state) {
                      if (state is ConnectionTestResult) {
                        setState(() => _isTesting = false);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(state.message),
                            backgroundColor:
                                state.success ? Colors.green : Colors.red,
                          ),
                        );
                      }
                    },
                    builder: (context, state) {
                      final canTest = _nameController.text.isNotEmpty &&
                          _apiKeysController.text.isNotEmpty &&
                          _urlController.text.isNotEmpty;
                      return OutlinedButton.icon(
                        onPressed: canTest && !_isTesting
                            ? () {
                                setState(() => _isTesting = true);
                                context.read<ProviderBloc>().add(TestConnection(
                                      providerName: _nameController.text,
                                      apiKey: _apiKeysController.text
                                          .split('\n')
                                          .first
                                          .trim(),
                                      baseUrl: _urlController.text,
                                    ));
                              }
                            : null,
                        icon: _isTesting
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2),
                              )
                            : const Icon(Icons.wifi_find),
                        label: Text(_isTesting
                            ? 'Menguji...'
                            : AppStrings.testConnection),
                      );
                    },
                  ),
                ],
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _validate() ? _saveProvider : null,
                    child: const Text(AppStrings.save),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  bool _validate() {
    return _nameController.text.trim().length >= 3 &&
        _urlController.text.trim().isNotEmpty &&
        _apiKeysController.text.trim().isNotEmpty &&
        _modelsController.text.trim().isNotEmpty;
  }

  void _saveProvider() {
    final keys = _apiKeysController.text
        .split('\n')
        .map((k) => k.trim())
        .where((k) => k.isNotEmpty)
        .toList();
    final models = _modelsController.text
        .split(',')
        .map((m) => m.trim())
        .where((m) => m.isNotEmpty)
        .toList();

    context.read<ProviderBloc>().add(AddProvider(
          name: _nameController.text.trim(),
          baseUrl: _urlController.text.trim(),
          extraHeaders: _headersController.text.trim(),
          apiKeys: keys,
          models: models,
        ));
    Navigator.pop(context);
  }
}
