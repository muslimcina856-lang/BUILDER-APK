import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../bloc/skill_bloc/skill_bloc.dart';
import '../bloc/provider_bloc/provider_bloc.dart';
import '../../core/constants/strings.dart';
import '../../core/constants/constants.dart';
import '../../core/themes/app_theme.dart';
import '../../core/di/service_locator.dart';
import '../../data/services/shell_service.dart';
import '../../data/repositories/provider_repository.dart';
import '../../data/repositories/skill_repository.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final _instructionController = TextEditingController();
  bool _shellPermission = false;
  String _themeMode = 'system';

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _instructionController.dispose();
    super.dispose();
  }

  void _loadSettings() {
    final shellService = sl<ShellService>();
    setState(() {
      _shellPermission = shellService.hasPermission;
      _instructionController.text = AppConstants.defaultInstruction;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.settings),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionHeader('Arahan Global'),
          const SizedBox(height: 8),
          TextField(
            controller: _instructionController,
            maxLines: 4,
            maxLength: AppConstants.maxInstructionLength,
            decoration: InputDecoration(
              hintText: 'Masukkan arahan sistem global...',
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('Paparan'),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: [
                RadioListTile<String>(
                  title: const Text(AppStrings.systemTheme),
                  value: 'system',
                  groupValue: _themeMode,
                  onChanged: (v) => setState(() => _themeMode = v!),
                ),
                RadioListTile<String>(
                  title: const Text(AppStrings.lightTheme),
                  value: 'light',
                  groupValue: _themeMode,
                  onChanged: (v) => setState(() => _themeMode = v!),
                ),
                RadioListTile<String>(
                  title: const Text(AppStrings.darkTheme),
                  value: 'dark',
                  groupValue: _themeMode,
                  onChanged: (v) => setState(() => _themeMode = v!),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('Akses Sistem'),
          const SizedBox(height: 8),
          Card(
            child: SwitchListTile(
              title: const Text('Benarkan Akses Shell'),
              subtitle: const Text(
                  'Membenarkan AI menjalankan arahan sistem pada peranti anda.'),
              value: _shellPermission,
              onChanged: (v) {
                setState(() => _shellPermission = v);
                final shellSvc = sl<ShellService>();
                if (v) {
                  shellSvc.grantPermission();
                } else {
                  shellSvc.revokePermission();
                }
              },
            ),
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('Eksport / Import'),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _exportConfig,
                  icon: const Icon(Icons.upload_outlined),
                  label: const Text(AppStrings.exportConfig),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _importConfig,
                  icon: const Icon(Icons.download_outlined),
                  label: const Text(AppStrings.importConfig),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('Lain-lain'),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: Icon(Icons.info_outline,
                  color: isDark ? Colors.grey[400] : Colors.grey[600]),
              title: const Text('Versi Aplikasi'),
              trailing: Text(AppConstants.appVersion,
                  style: TextStyle(
                      fontSize: 14,
                      color: isDark ? Colors.grey[400] : Colors.grey[600])),
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(title,
          style: const TextStyle(
              fontSize: 14, fontWeight: FontWeight.w600, color: AppTheme.primaryColor)),
    );
  }

  Future<void> _exportConfig() async {
    try {
      final providerRepo = sl<ProviderRepository>();
      final skillRepo = sl<SkillRepository>();
      final config = await providerRepo.exportConfig();
      final skills = await skillRepo.getAll();
      config['skills'] = skills
          .map((s) => {'name': s.name, 'content': s.content})
          .toList();

      final jsonStr = const JsonEncoder.withIndent('  ').convert(config);
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/multi_agent_ai_config.json');
      await file.writeAsString(jsonStr);

      await Share.shareXFiles([XFile(file.path)], text: 'Multi Agent AI Config');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppStrings.exportSuccess)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export failed: $e')),
        );
      }
    }
  }

  Future<void> _importConfig() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
      );
      if (result == null || result.files.isEmpty) return;

      final file = File(result.files.first.path!);
      final jsonStr = await file.readAsString();
      final config = jsonDecode(jsonStr) as Map<String, dynamic>;

      if (config.containsKey('version') && config['version'] == '1.0.0') {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(AppStrings.importSuccess)),
        );
        context.read<ProviderBloc>().add(LoadProviders());
        context.read<SkillBloc>().add(LoadSkills());
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Format fail tidak sah.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Import failed: $e')),
        );
      }
    }
  }
}
