import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/skill_bloc/skill_bloc.dart';
import '../../data/models/skill_model.dart';
import '../../core/constants/strings.dart';
import '../../core/themes/app_theme.dart';

class SkillPage extends StatefulWidget {
  const SkillPage({super.key});

  @override
  State<SkillPage> createState() => _SkillPageState();
}

class _SkillPageState extends State<SkillPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.skills),
      ),
      body: BlocBuilder<SkillBloc, SkillState>(
        builder: (context, state) {
          if (state is SkillLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state is SkillError) {
            return Center(child: Text(state.message));
          }
          if (state is SkillsLoaded) {
            if (state.skills.isEmpty) {
              return Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.psychology_outlined,
                        size: 64, color: Colors.grey[400]),
                    const SizedBox(height: 16),
                    Text('Tiada skill',
                        style: TextStyle(
                            fontSize: 16, color: Colors.grey[500])),
                    const SizedBox(height: 24),
                    ElevatedButton.icon(
                      onPressed: () => _showAddSkillSheet(context),
                      icon: const Icon(Icons.add),
                      label: const Text(AppStrings.addSkill),
                    ),
                  ],
                ),
              );
            }
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                ...state.skills.map((s) => _SkillCard(skill: s)),
              ],
            );
          }
          return const SizedBox.shrink();
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddSkillSheet(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showAddSkillSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => const _AddSkillSheet(),
    );
  }
}

class _SkillCard extends StatelessWidget {
  final SkillModel skill;

  const _SkillCard({required this.skill});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isCreator = skill.name == 'Skill Creator';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: isCreator
                        ? Colors.amber.withOpacity(0.2)
                        : AppTheme.primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    isCreator ? Icons.auto_awesome : Icons.psychology,
                    color: isCreator ? Colors.amber : AppTheme.primaryColor,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(skill.name,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w600)),
                ),
                if (!isCreator)
                  PopupMenuButton<String>(
                    onSelected: (v) {
                      if (v == 'edit') {
                        _showEditSkillSheet(context, skill);
                      } else if (v == 'delete') {
                        _confirmDelete(context, skill);
                      }
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(
                          value: 'edit',
                          child: Row(children: [
                            Icon(Icons.edit, size: 18),
                            SizedBox(width: 8),
                            Text('Sunting')
                          ])),
                      const PopupMenuItem(
                          value: 'delete',
                          child: Row(children: [
                            Icon(Icons.delete, size: 18, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Padam', style: TextStyle(color: Colors.red))
                          ])),
                    ],
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isDark ? Colors.grey[900] : Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                skill.content,
                style: TextStyle(
                  fontSize: 13,
                  height: 1.5,
                  color: isDark ? Colors.grey[300] : Colors.grey[700],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showEditSkillSheet(BuildContext context, SkillModel skill) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => _AddSkillSheet(existingSkill: skill),
    );
  }

  void _confirmDelete(BuildContext context, SkillModel skill) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Skill'),
        content: Text('Anda pasti mahu memadamkan skill "${skill.name}"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text(AppStrings.cancel)),
          TextButton(
            onPressed: () {
              context
                  .read<SkillBloc>()
                  .add(DeleteSkill(skillId: skill.id, skillName: skill.name));
              Navigator.pop(ctx);
            },
            child: const Text(AppStrings.delete,
                style: TextStyle(color: AppTheme.errorColor)),
          ),
        ],
      ),
    );
  }
}

class _AddSkillSheet extends StatefulWidget {
  final SkillModel? existingSkill;
  const _AddSkillSheet({this.existingSkill});

  @override
  State<_AddSkillSheet> createState() => _AddSkillSheetState();
}

class _AddSkillSheetState extends State<_AddSkillSheet> {
  late final TextEditingController _nameController;
  late final TextEditingController _contentController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.existingSkill?.name ?? '');
    _contentController =
        TextEditingController(text: widget.existingSkill?.content ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existingSkill != null;
    return DraggableScrollableSheet(
      initialChildSize: 0.8,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(isEdit ? AppStrings.editSkill : AppStrings.addSkill,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w600)),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                controller: scrollController,
                padding: const EdgeInsets.all(16),
                children: [
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: AppStrings.skillName,
                      hintText: 'Contoh: Code Reviewer',
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _contentController,
                    decoration: const InputDecoration(
                      labelText: AppStrings.skillContent,
                      hintText: 'Tulis arahan atau deskripsi skill...',
                      alignLabelWithHint: true,
                    ),
                    maxLines: 12,
                    minLines: 6,
                  ),
                ],
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _validate() ? _save : null,
                    child: Text(isEdit ? AppStrings.save : AppStrings.addSkill),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  bool _validate() {
    return _nameController.text.trim().length >= 3 &&
        _contentController.text.trim().length >= 10;
  }

  void _save() {
    if (widget.existingSkill != null) {
      context.read<SkillBloc>().add(UpdateSkill(
            widget.existingSkill!.copyWith(
              name: _nameController.text.trim(),
              content: _contentController.text.trim(),
            ),
          ));
    } else {
      context.read<SkillBloc>().add(AddSkill(
            name: _nameController.text.trim(),
            content: _contentController.text.trim(),
          ));
    }
    Navigator.pop(context);
  }
}
