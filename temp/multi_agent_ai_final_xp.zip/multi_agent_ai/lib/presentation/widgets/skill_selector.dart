import 'package:flutter/material.dart';
import '../../data/models/skill_model.dart';

class SkillSelector extends StatelessWidget {
  final List<SkillModel> skills;
  final String? selectedSkillId;
  final ValueChanged<String?> onSelected;

  const SkillSelector({
    super.key,
    required this.skills,
    this.selectedSkillId,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 16, top: 16, bottom: 8),
          child: Text('Pilih Skill (Pilihan)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ChoiceChip(
            label: const Text('Tiada Skill'),
            selected: selectedSkillId == null,
            onSelected: (_) => onSelected(null),
          ),
        ),
        const SizedBox(height: 8),
        ...skills.map((skill) => ListTile(
              dense: true,
              leading: Icon(
                skill.name == 'Skill Creator'
                    ? Icons.auto_awesome
                    : Icons.psychology,
                size: 20,
                color: Theme.of(context).primaryColor,
              ),
              title: Text(skill.name, style: const TextStyle(fontSize: 14)),
              subtitle: Text(
                skill.content.length > 60
                    ? '${skill.content.substring(0, 60)}...'
                    : skill.content,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 11,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.grey[400]
                        : Colors.grey[600]),
              ),
              trailing: Radio<String?>(
                value: skill.id,
                groupValue: selectedSkillId,
                onChanged: onSelected,
              ),
              onTap: () => onSelected(skill.id),
            )),
      ],
    );
  }
}
