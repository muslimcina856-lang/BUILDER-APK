import 'package:flutter/material.dart';
import '../../core/themes/app_theme.dart';

Widget _buildCodeBlock(String code, bool isDark) {
  return Container(
    width: double.infinity,
    margin: const EdgeInsets.symmetric(vertical: 4),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: isDark ? Colors.black87 : const Color(0xFF1E1E1E),
      borderRadius: BorderRadius.circular(8),
    ),
    child: SelectableText(
      code,
      style: const TextStyle(
        fontFamily: 'monospace',
        fontSize: 13,
        height: 1.4,
        color: Color(0xFFF8F8F2),
      ),
    ),
  );
}

Widget _buildRegularText(String text, bool isUser, bool isDark) {
  return SelectableText(
    text,
    style: TextStyle(
      fontSize: 15,
      height: 1.5,
      color: isUser ? Colors.white : (isDark ? Colors.white : AppTheme.textLight),
    ),
  );
}

List<InlineSpan> _parseInlineCode(String text, bool isUser, bool isDark) {
  final spans = <InlineSpan>[];
  final regex = RegExp(r'`([^`]+)`');
  int lastEnd = 0;
  final baseColor = isUser
      ? Colors.white
      : (isDark ? Colors.white : AppTheme.textLight);

  for (final match in regex.allMatches(text)) {
    if (match.start > lastEnd) {
      spans.add(TextSpan(
        text: text.substring(lastEnd, match.start),
        style: TextStyle(fontSize: 15, color: baseColor),
      ));
    }
    spans.add(WidgetSpan(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: isDark ? Colors.white12 : Colors.black12,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(
          match.group(1)!,
          style: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    ));
    lastEnd = match.end;
  }

  if (lastEnd < text.length) {
    spans.add(TextSpan(
      text: text.substring(lastEnd),
      style: TextStyle(fontSize: 15, color: baseColor),
    ));
  }

  return spans;
}

Widget _buildMessageContent(String message, bool isUser, bool isDark) {
  if (isUser) {
    return _buildRegularText(message, isUser, isDark);
  }

  final codeBlockRegex = RegExp(r'```(\w*)\n([\s\S]*?)```');
  if (!codeBlockRegex.hasMatch(message)) {
    return RichText(
      text: TextSpan(children: _parseInlineCode(message, isUser, isDark)),
    );
  }

  final children = <Widget>[];
  int lastEnd = 0;

  for (final match in codeBlockRegex.allMatches(message)) {
    if (match.start > lastEnd) {
      final text = message.substring(lastEnd, match.start);
      children.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: RichText(
          text: TextSpan(children: _parseInlineCode(text, isUser, isDark)),
        ),
      ));
    }
    final code = match.group(2)!;
    children.add(_buildCodeBlock(code, isDark));
    lastEnd = match.end;
  }

  if (lastEnd < message.length) {
    final text = message.substring(lastEnd);
    children.add(Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: RichText(
        text: TextSpan(children: _parseInlineCode(text, isUser, isDark)),
      ),
    ));
  }

  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: children,
  );
}

class ChatBubble extends StatelessWidget {
  final String message;
  final bool isUser;
  final String time;
  final String? modelName;

  const ChatBubble({
    super.key,
    required this.message,
    required this.isUser,
    required this.time,
    this.modelName,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isUser)
            Container(
              width: 32,
              height: 32,
              margin: const EdgeInsets.only(right: 8, top: 4),
              decoration: BoxDecoration(
                color: AppTheme.primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.smart_toy_outlined,
                  size: 18, color: AppTheme.primaryColor),
            ),
          Flexible(
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: isUser
                    ? AppTheme.primaryColor
                    : isDark
                        ? AppTheme.bubbleAIDark
                        : AppTheme.bubbleAI,
                borderRadius: BorderRadius.circular(16).copyWith(
                  bottomRight: isUser ? const Radius.circular(4) : null,
                  bottomLeft: !isUser ? const Radius.circular(4) : null,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (modelName != null && !isUser)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(modelName!,
                          style: TextStyle(
                              fontSize: 11,
                              color: AppTheme.primaryColor,
                              fontWeight: FontWeight.w600)),
                    ),
                  _buildMessageContent(message, isUser, isDark),
                  const SizedBox(height: 4),
                  Text(
                    time,
                    style: TextStyle(
                      fontSize: 11,
                      color: isUser
                          ? Colors.white.withOpacity(0.7)
                          : (isDark ? AppTheme.subtleDark : AppTheme.subtleLight),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isUser)
            Container(
              width: 32,
              height: 32,
              margin: const EdgeInsets.only(left: 8, top: 4),
              decoration: BoxDecoration(
                color: AppTheme.primaryColor,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.person, size: 18, color: Colors.white),
            ),
        ],
      ),
    );
  }
}
