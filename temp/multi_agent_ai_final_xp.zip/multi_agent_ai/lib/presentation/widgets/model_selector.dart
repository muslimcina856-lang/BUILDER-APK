import 'package:flutter/material.dart';
import '../../data/models/provider_model.dart';

class ModelSelector extends StatelessWidget {
  final List<ProviderModel> providers;
  final String? selectedModelId;
  final ValueChanged<String> onSelected;

  const ModelSelector({
    super.key,
    required this.providers,
    this.selectedModelId,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final activeProviders =
        providers.where((p) => p.isActive && p.models.isNotEmpty).toList();

    if (activeProviders.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Text('Tiada model tersedia. Sila tambah provider.'),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 16, top: 16, bottom: 8),
          child: Text('Pilih Model AI',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        ),
        ...activeProviders.map((provider) => _ProviderGroup(
              provider: provider,
              selectedModelId: selectedModelId,
              onSelected: onSelected,
            )),
      ],
    );
  }
}

class _ProviderGroup extends StatelessWidget {
  final ProviderModel provider;
  final String? selectedModelId;
  final ValueChanged<String> onSelected;

  const _ProviderGroup({
    required this.provider,
    this.selectedModelId,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(
            children: [
              Icon(Icons.cloud_outlined,
                  size: 14, color: isDark ? Colors.grey[400] : Colors.grey[600]),
              const SizedBox(width: 6),
              Text(provider.name,
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.grey[400] : Colors.grey[600])),
            ],
          ),
        ),
        ...provider.models.map((model) => ListTile(
              dense: true,
              leading: Radio<String>(
                value: model.id,
                groupValue: selectedModelId,
                onChanged: (v) {
                  if (v != null) onSelected(v);
                },
              ),
              title: Text(model.name, style: const TextStyle(fontSize: 14)),
              subtitle: model.isDefault
                  ? Text('Default',
                      style: TextStyle(
                          fontSize: 11, color: Theme.of(context).primaryColor))
                  : null,
              onTap: () => onSelected(model.id),
            )),
        const Divider(height: 1),
      ],
    );
  }
}
