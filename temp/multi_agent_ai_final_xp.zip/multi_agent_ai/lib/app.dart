import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'core/themes/app_theme.dart';
import 'core/di/service_locator.dart';
import 'presentation/bloc/chat_bloc/chat_bloc.dart';
import 'presentation/bloc/provider_bloc/provider_bloc.dart';
import 'presentation/bloc/skill_bloc/skill_bloc.dart';
import 'presentation/pages/chat_list_page.dart';

class MultiAgentAIApp extends StatelessWidget {
  const MultiAgentAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multi Agent AI',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      home: MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (_) => ChatBloc(
              chatRepo: sl(),
              providerRepo: sl(),
              skillRepo: sl(),
              fallbackManager: sl(),
              shellService: sl(),
            ),
          ),
          BlocProvider(
            create: (_) => ProviderBloc(
              repo: sl(),
              fallbackManager: sl(),
            ),
          ),
          BlocProvider(
            create: (_) => SkillBloc(repo: sl()),
          ),
        ],
        child: const ChatListPage(),
      ),
    );
  }
}
