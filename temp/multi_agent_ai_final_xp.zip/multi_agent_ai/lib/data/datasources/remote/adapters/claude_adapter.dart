import 'package:dio/dio.dart';
import '../api_client.dart';

class ClaudeAdapter {
  final ApiClient _client;
  ClaudeAdapter() : _client = ApiClient();

  Future<String> sendMessage({
    required String apiKey,
    required String model,
    required List<Map<String, String>> messages,
    double temperature = 0.7,
    int maxTokens = 2000,
  }) async {
    try {
      final systemMessage = messages
          .where((m) => m['role'] == 'system')
          .map((m) => m['content'])
          .join('\n');
      final conversationMessages = messages
          .where((m) => m['role'] != 'system')
          .map((m) => {'role': m['role']!, 'content': m['content']!})
          .toList();

      final body = <String, dynamic>{
        'model': model,
        'messages': conversationMessages,
        'max_tokens': maxTokens,
        'temperature': temperature,
      };
      if (systemMessage.isNotEmpty) {
        body['system'] = systemMessage;
      }

      final response = await _client.post(
        'https://api.anthropic.com/v1/messages',
        data: body,
        headers: {
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
      );
      return response.data['content'][0]['text'] as String;
    } on DioException catch (e) {
      if (e.response != null) {
        final statusCode = e.response!.statusCode;
        if (statusCode == 401 || statusCode == 429) rethrow;
        throw Exception('Claude API error: ${e.response?.data['error']?['message'] ?? e.message}');
      }
      rethrow;
    }
  }

  static String get defaultUrl => 'https://api.anthropic.com/v1';
  static List<String> get defaultModels => [
        'claude-3-5-sonnet-20241022',
        'claude-3-5-haiku-20241022',
        'claude-3-opus-20240229',
      ];
}
