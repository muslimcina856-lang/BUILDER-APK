import 'package:dio/dio.dart';
import '../api_client.dart';

class GeminiAdapter {
  final ApiClient _client;
  GeminiAdapter() : _client = ApiClient();

  Future<String> sendMessage({
    required String apiKey,
    required String model,
    required List<Map<String, String>> messages,
    double temperature = 0.7,
    int maxTokens = 2000,
  }) async {
    try {
      final systemMessages =
          messages.where((m) => m['role'] == 'system').map((m) => m['content']).join('\n');

      final contents = <Map<String, dynamic>>[];
      for (final msg in messages) {
        if (msg['role'] == 'system') continue;
        final role = msg['role'] == 'assistant' ? 'model' : 'user';
        contents.add({
          'role': role,
          'parts': [{'text': msg['content']}],
        });
      }

      if (systemMessages.isNotEmpty && contents.isNotEmpty) {
        contents.first['parts'] = [
          {'text': 'System instruction: $systemMessages\n\n${contents.first['parts'][0]['text']}'}
        ];
      }

      final response = await _client.post(
        'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey',
        data: {
          'contents': contents,
          'generationConfig': {
            'temperature': temperature,
            'maxOutputTokens': maxTokens,
          },
        },
      );
      return response.data['candidates'][0]['content']['parts'][0]['text'] as String;
    } on DioException catch (e) {
      if (e.response != null) {
        final statusCode = e.response!.statusCode;
        if (statusCode == 401 || statusCode == 429) rethrow;
        throw Exception('Gemini API error: ${e.response?.data['error']?['message'] ?? e.message}');
      }
      rethrow;
    }
  }

  static String get defaultUrl => 'https://generativelanguage.googleapis.com/v1beta';
  static List<String> get defaultModels => [
        'gemini-1.5-pro',
        'gemini-1.5-flash',
        'gemini-2.0-flash',
      ];
}
