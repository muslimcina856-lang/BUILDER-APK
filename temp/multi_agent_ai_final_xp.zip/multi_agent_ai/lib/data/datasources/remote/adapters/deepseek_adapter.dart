import 'package:dio/dio.dart';
import '../api_client.dart';

class DeepSeekAdapter {
  final ApiClient _client;
  DeepSeekAdapter() : _client = ApiClient();

  Future<String> sendMessage({
    required String apiKey,
    required String model,
    required List<Map<String, String>> messages,
    double temperature = 0.7,
    int maxTokens = 2000,
  }) async {
    try {
      final response = await _client.post(
        'https://api.deepseek.com/v1/chat/completions',
        data: {
          'model': model,
          'messages': messages,
          'temperature': temperature,
          'max_tokens': maxTokens,
        },
        headers: {
          'Authorization': 'Bearer $apiKey',
        },
      );
      return response.data['choices'][0]['message']['content'] as String;
    } on DioException catch (e) {
      if (e.response != null) {
        final statusCode = e.response!.statusCode;
        if (statusCode == 401 || statusCode == 429) {
          rethrow;
        }
        throw Exception(
            'DeepSeek API error: ${e.response?.data['error']?['message'] ?? e.message}');
      }
      rethrow;
    }
  }

  static String get defaultUrl => 'https://api.deepseek.com/v1';
  static List<String> get defaultModels => [
        'deepseek-chat',
        'deepseek-reasoner',
        'deepseek-v3',
      ];
}
