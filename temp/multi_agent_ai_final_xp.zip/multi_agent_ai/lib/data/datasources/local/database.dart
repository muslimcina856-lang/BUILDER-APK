import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../models/provider_model.dart';
import '../../models/api_key_model.dart';
import '../../models/model_model.dart';
import '../../models/chat_model.dart';
import '../../models/message_model.dart';
import '../../models/skill_model.dart';

class AppDatabase {
  static Database? _database;

  static Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  static Future<Database> _initDatabase() async {
    final path = join(await getDatabasesPath(), 'multi_agent_ai.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: _createTables,
    );
  }

  static Future<void> _createTables(Database db, int version) async {
    await db.execute('''
      CREATE TABLE providers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        baseUrl TEXT NOT NULL,
        extraHeaders TEXT DEFAULT '',
        isActive INTEGER DEFAULT 1,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE api_keys (
        id TEXT PRIMARY KEY,
        providerId TEXT NOT NULL,
        key TEXT NOT NULL,
        priority INTEGER DEFAULT 0,
        FOREIGN KEY (providerId) REFERENCES providers(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE models (
        id TEXT PRIMARY KEY,
        providerId TEXT NOT NULL,
        name TEXT NOT NULL,
        isDefault INTEGER DEFAULT 0,
        FOREIGN KEY (providerId) REFERENCES providers(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE chats (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        modelId TEXT NOT NULL,
        skillId TEXT,
        instructionOverride TEXT,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE messages (
        id TEXT PRIMARY KEY,
        chatId TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (chatId) REFERENCES chats(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE skills (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        content TEXT NOT NULL,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute(
        'CREATE INDEX idx_messages_chat_id ON messages(chatId)');
    await db.execute(
        'CREATE INDEX idx_messages_content ON messages(content)');
    await db.execute(
        'CREATE INDEX idx_chats_updated ON chats(updatedAt)');
    await db.execute(
        'CREATE INDEX idx_api_keys_provider ON api_keys(providerId)');
    await db.execute(
        'CREATE INDEX idx_models_provider ON models(providerId)');
  }
}
