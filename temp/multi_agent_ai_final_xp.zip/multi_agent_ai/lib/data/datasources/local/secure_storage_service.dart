import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  final FlutterSecureStorage _storage;
  SecureStorageService() : _storage = const FlutterSecureStorage();

  Future<void> saveApiKey(String providerId, String key) async =>
      _storage.write(key: 'api_key_$providerId', value: key);

  Future<String?> getApiKey(String providerId) async =>
      _storage.read(key: 'api_key_$providerId');

  Future<void> deleteApiKey(String providerId) async =>
      _storage.delete(key: 'api_key_$providerId');

  Future<void> saveAllApiKeys(Map<String, String> keys) async {
    for (final entry in keys.entries) {
      await _storage.write(key: 'api_key_${entry.key}', value: entry.value);
    }
  }

  Future<Map<String, String>> getAllApiKeys(List<String> providerIds) async {
    final map = <String, String>{};
    for (final id in providerIds) {
      final key = await _storage.read(key: 'api_key_$id');
      if (key != null) map[id] = key;
    }
    return map;
  }

  Future<void> clearAll() async => _storage.deleteAll();

  Future<void> saveThemeMode(String mode) async =>
      _storage.write(key: 'theme_mode', value: mode);

  Future<String?> getThemeMode() async =>
      _storage.read(key: 'theme_mode');

  Future<void> saveInstruction(String instruction) async =>
      _storage.write(key: 'global_instruction', value: instruction);

  Future<String?> getInstruction() async =>
      _storage.read(key: 'global_instruction');
}
