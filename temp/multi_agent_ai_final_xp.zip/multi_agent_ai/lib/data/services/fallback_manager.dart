import 'package:dio/dio.dart';
import '../models/api_key_model.dart';
import '../datasources/remote/adapters/deepseek_adapter.dart';
import '../datasources/remote/adapters/openai_adapter.dart';
import '../datasources/remote/adapters/gemini_adapter.dart';
import '../datasources/remote/adapters/claude_adapter.dart';

class FallbackManager {
  String? _lastError;

  String? get lastError => _lastError;

  Future<String> sendWithFallback({
    required List<ApiKeyModel> apiKeys,
    required String providerName,
    required String model,
    required List<Map<String, String>> messages,
    double temperature = 0.7,
    int maxTokens = 2000,
  }) async {
    _lastError = null;

    final sortedKeys = List<ApiKeyModel>.from(apiKeys)
      ..sort((a, b) => a.priority.compareTo(b.priority));

    for (final apiKeyModel in sortedKeys) {
      try {
        final result = await _sendToProvider(
          providerName: providerName,
          apiKey: apiKeyModel.key,
          model: model,
          messages: messages,
          temperature: temperature,
          maxTokens: maxTokens,
        );
        return result;
      } on DioException catch (e) {
        final statusCode = e.response?.statusCode;
        if (statusCode == 401 || statusCode == 429) {
          _lastError = 'Key ${apiKeyModel.priority + 1} failed (HTTP $statusCode)';
          continue;
        }
        rethrow;
      } catch (e) {
        _lastError = e.toString();
        rethrow;
      }
    }

    throw Exception('All API keys failed for $providerName');
  }

  Future<String> _sendToProvider({
    required String providerName,
    required String apiKey,
    required String model,
    required List<Map<String, String>> messages,
    required double temperature,
    required int maxTokens,
  }) async {
    final lower = providerName.toLowerCase();
    if (lower.contains('deepseek')) {
      return DeepSeekAdapter().sendMessage(
          apiKey: apiKey, model: model, messages: messages, temperature: temperature, maxTokens: maxTokens);
    } else if (lower.contains('openai')) {
      return OpenAIAdapter().sendMessage(
          apiKey: apiKey, model: model, messages: messages, temperature: temperature, maxTokens: maxTokens);
    } else if (lower.contains('gemini')) {
      return GeminiAdapter().sendMessage(
          apiKey: apiKey, model: model, messages: messages, temperature: temperature, maxTokens: maxTokens);
    } else if (lower.contains('claude') || lower.contains('anthropic')) {
      return ClaudeAdapter().sendMessage(
          apiKey: apiKey, model: model, messages: messages, temperature: temperature, maxTokens: maxTokens);
    }
    return OpenAIAdapter().sendMessage(
        apiKey: apiKey, model: model, messages: messages, temperature: temperature, maxTokens: maxTokens);
  }

  Future<bool> testConnection({
    required String providerName,
    required String apiKey,
    required String baseUrl,
    String? model,
  }) async {
    try {
      final adapter = _getAdapter(providerName, baseUrl);
      await adapter.sendMessage(
        apiKey: apiKey,
        model: model ?? _defaultModel(providerName),
        messages: [{'role': 'user', 'content': 'Hi'}],
        maxTokens: 5,
      );
      return true;
    } catch (_) {
      return false;
    }
  }

  dynamic _getAdapter(String providerName, String baseUrl) {
    final lower = providerName.toLowerCase();
    if (lower.contains('deepseek')) return DeepSeekAdapter();
    if (lower.contains('openai')) return OpenAIAdapter();
    if (lower.contains('gemini')) return GeminiAdapter();
    if (lower.contains('claude') || lower.contains('anthropic')) return ClaudeAdapter();
    return OpenAIAdapter();
  }

  String _defaultModel(String providerName) {
    final lower = providerName.toLowerCase();
    if (lower.contains('deepseek')) return 'deepseek-chat';
    if (lower.contains('openai')) return 'gpt-4o-mini';
    if (lower.contains('gemini')) return 'gemini-1.5-flash';
    if (lower.contains('claude')) return 'claude-3-5-haiku-20241022';
    return 'gpt-4o-mini';
  }
}
