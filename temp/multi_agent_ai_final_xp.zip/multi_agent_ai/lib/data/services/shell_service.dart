import 'dart:io';
import 'package:process_run/process_run.dart';

class ShellResult {
  final String stdout;
  final String stderr;
  final int exitCode;
  final Duration duration;

  ShellResult({
    required this.stdout,
    required this.stderr,
    required this.exitCode,
    this.duration = Duration.zero,
  });

  bool get isSuccess => exitCode == 0;
  String get fullOutput => stdout.isNotEmpty ? stdout : stderr;
}

class ShellService {
  bool _permissionGranted = false;
  String _workingDirectory = '/';

  bool get hasPermission => _permissionGranted;
  String get workingDirectory => _workingDirectory;

  void grantPermission() => _permissionGranted = true;
  void revokePermission() => _permissionGranted = false;

  /// Execute arbitrary shell command with no artificial restrictions.
  /// User has full control over what runs.
  Future<ShellResult> execute(String command) async {
    if (!_permissionGranted) {
      return ShellResult(
        stdout: '',
        stderr: 'Akses shell tidak dibenarkan. Sila benarkan di Tetapan.',
        exitCode: -1,
      );
    }

    final start = DateTime.now();
    try {
      final runner = Shell(workingDirectory: _workingDirectory);
      final results = await runner.run(command);
      final result = results.last;
      final elapsed = DateTime.now().difference(start);
      return ShellResult(
        stdout: result.stdout.toString(),
        stderr: result.stderr.toString(),
        exitCode: result.exitCode,
        duration: elapsed,
      );
    } catch (e) {
      return ShellResult(
        stdout: '',
        stderr: 'Execution error: $e',
        exitCode: -1,
        duration: DateTime.now().difference(start),
      );
    }
  }

  /// Run a command with specific arguments (safer than shell parsing)
  Future<ShellResult> runExecutable(
    String executable,
    List<String> arguments, {
    String? workingDirectory,
  }) async {
    if (!_permissionGranted) {
      return ShellResult(
        stdout: '',
        stderr: 'Akses shell tidak dibenarkan.',
        exitCode: -1,
      );
    }

    final start = DateTime.now();
    try {
      final runner = Shell(workingDirectory: workingDirectory ?? _workingDirectory);
      final cmd = [executable, ...arguments].join(' ');
      final results = await runner.run(cmd);
      final result = results.last;
      return ShellResult(
        stdout: result.stdout.toString(),
        stderr: result.stderr.toString(),
        exitCode: result.exitCode,
        duration: DateTime.now().difference(start),
      );
    } catch (e) {
      return ShellResult(
        stdout: '',
        stderr: 'Execution error: $e',
        exitCode: -1,
        duration: DateTime.now().difference(start),
      );
    }
  }

  /// List directory contents
  Future<ShellResult> listDirectory(String path) async {
    return runExecutable('ls', ['-la', path]);
  }

  /// Read file contents
  Future<ShellResult> readFile(String path) async {
    return runExecutable('cat', [path]);
  }

  /// Write content to file (overwrites)
  Future<ShellResult> writeFile(String path, String content) async {
    if (!_permissionGranted) {
      return ShellResult(stdout: '', stderr: 'Akses tidak dibenarkan.', exitCode: -1);
    }
    try {
      final file = File(path);
      await file.writeAsString(content);
      return ShellResult(
        stdout: '✓ Fail ditulis: $path (${content.length} bytes)',
        stderr: '',
        exitCode: 0,
      );
    } catch (e) {
      return ShellResult(stdout: '', stderr: 'Write error: $e', exitCode: 1);
    }
  }

  /// Append content to file
  Future<ShellResult> appendFile(String path, String content) async {
    try {
      final file = File(path);
      await file.writeAsString(content, mode: FileMode.append);
      return ShellResult(
        stdout: '✓ Fail dikemaskini: $path (+${content.length} bytes)',
        stderr: '',
        exitCode: 0,
      );
    } catch (e) {
      return ShellResult(stdout: '', stderr: 'Append error: $e', exitCode: 1);
    }
  }

  /// Delete file or directory
  Future<ShellResult> deletePath(String path) async {
    return runExecutable('rm', ['-rf', path]);
  }

  /// Create directory
  Future<ShellResult> createDirectory(String path) async {
    return runExecutable('mkdir', ['-p', path]);
  }

  /// Copy file/directory
  Future<ShellResult> copyPath(String source, String destination) async {
    return runExecutable('cp', ['-r', source, destination]);
  }

  /// Move file/directory
  Future<ShellResult> movePath(String source, String destination) async {
    return runExecutable('mv', [source, destination]);
  }

  /// Get file info
  Future<ShellResult> fileInfo(String path) async {
    return runExecutable('stat', [path]);
  }

  /// Search in files
  Future<ShellResult> grep(String pattern, String path) async {
    return runExecutable('grep', ['-rn', pattern, path]);
  }

  /// Find files
  Future<ShellResult> findFiles(String path, String name) async {
    return runExecutable('find', [path, '-name', name]);
  }

  /// Run a script file
  Future<ShellResult> runScript(String path, {List<String>? args}) async {
    return runExecutable('sh', [path, ...?args]);
  }

  /// Run Python script
  Future<ShellResult> runPython(String code) async {
    final tempDir = Directory.systemTemp;
    final scriptFile = File('${tempDir.path}/_agent_script_${DateTime.now().millisecondsSinceEpoch}.py');
    await scriptFile.writeAsString(code);
    final result = await runExecutable('python3', [scriptFile.path]);
    await scriptFile.delete();
    return result;
  }

  /// Run Node.js script
  Future<ShellResult> runNode(String code) async {
    final tempDir = Directory.systemTemp;
    final scriptFile = File('${tempDir.path}/_agent_script_${DateTime.now().millisecondsSinceEpoch}.js');
    await scriptFile.writeAsString(code);
    final result = await runExecutable('node', [scriptFile.path]);
    await scriptFile.delete();
    return result;
  }

  /// Get system info
  Future<ShellResult> systemInfo() async {
    return runExecutable('uname', ['-a']);
  }

  /// Get disk usage
  Future<ShellResult> diskUsage() async {
    return runExecutable('df', ['-h']);
  }

  /// Get memory info
  Future<ShellResult> memoryInfo() async {
    return runExecutable('free', ['-h']);
  }

  /// List running processes
  Future<ShellResult> listProcesses() async {
    return runExecutable('ps', ['aux']);
  }

  /// Kill process by PID
  Future<ShellResult> killProcess(int pid, {bool force = false}) async {
    return runExecutable('kill', [force ? '-9' : '-15', pid.toString()]);
  }

  /// Network: ping host
  Future<ShellResult> ping(String host, {int count = 4}) async {
    return runExecutable('ping', ['-c', count.toString(), host]);
  }

  /// Network: curl request
  Future<ShellResult> curl(String url, {List<String>? extraArgs}) async {
    return runExecutable('curl', ['-s', '-L', url, ...?extraArgs]);
  }

  /// Network: download file
  Future<ShellResult> download(String url, String outputPath) async {
    return runExecutable('curl', ['-s', '-L', '-o', outputPath, url]);
  }

  /// Install package (apt)
  Future<ShellResult> aptInstall(String package) async {
    return runExecutable('apt', ['install', '-y', package]);
  }

  /// Install pip package
  Future<ShellResult> pipInstall(String package) async {
    return runExecutable('pip3', ['install', package]);
  }

  /// Install npm package
  Future<ShellResult> npmInstall(String package, {bool global = false}) async {
    final args = ['install'];
    if (global) args.add('-g');
    args.add(package);
    return runExecutable('npm', args);
  }

  /// Get environment variables
  Future<ShellResult> envVars() async {
    return runExecutable('env', []);
  }

  /// Change working directory (for subsequent commands)
  void changeDirectory(String path) {
    _workingDirectory = path;
  }

  /// Execute multiple commands in sequence
  Future<List<ShellResult>> executeBatch(List<String> commands) async {
    final results = <ShellResult>[];
    for (final cmd in commands) {
      results.add(await execute(cmd));
    }
    return results;
  }

  /// Execute with pipe support
  Future<ShellResult> executePiped(List<String> commands) async {
    final fullCommand = commands.join(' | ');
    return execute(fullCommand);
  }

  /// Run command with timeout
  Future<ShellResult> executeWithTimeout(String command, Duration timeout) async {
    return runExecutable('timeout', [timeout.inSeconds.toString(), 'sh', '-c', command]);
  }
}
