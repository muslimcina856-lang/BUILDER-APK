import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';
import '../datasources/local/database.dart';
import '../models/skill_model.dart';
import '../../core/constants/constants.dart';

class SkillRepository {
  final Uuid _uuid = const Uuid();

  Future<List<SkillModel>> getAll() async {
    final db = await AppDatabase.database;
    final maps = await db.query('skills', orderBy: 'createdAt DESC');
    return maps.map((m) => SkillModel.fromMap(m)).toList();
  }

  Future<SkillModel?> getById(String id) async {
    final db = await AppDatabase.database;
    final maps =
        await db.query('skills', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return SkillModel.fromMap(maps.first);
  }

  Future<SkillModel?> getByName(String name) async {
    final db = await AppDatabase.database;
    final maps =
        await db.query('skills', where: 'name = ?', whereArgs: [name]);
    if (maps.isEmpty) return null;
    return SkillModel.fromMap(maps.first);
  }

  Future<void> save(SkillModel skill) async {
    final db = await AppDatabase.database;
    await db.insert('skills', skill.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> delete(String id) async {
    final db = await AppDatabase.database;
    await db.delete('skills', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> ensureDefaultSkill() async {
    final existing = await getByName(AppConstants.defaultSkillName);
    if (existing == null) {
      await save(SkillModel(
        id: _uuid.v4(),
        name: AppConstants.defaultSkillName,
        content: AppConstants.defaultSkillContent,
      ));
    }
  }

  Future<List<SkillModel>> search(String query) async {
    final db = await AppDatabase.database;
    final likeQuery = '%$query%';
    final maps = await db.query('skills',
        where: 'name LIKE ? OR content LIKE ?',
        whereArgs: [likeQuery, likeQuery],
        orderBy: 'createdAt DESC');
    return maps.map((m) => SkillModel.fromMap(m)).toList();
  }
}
