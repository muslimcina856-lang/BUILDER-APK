import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';
import '../datasources/local/database.dart';
import '../datasources/local/secure_storage_service.dart';
import '../models/provider_model.dart';
import '../models/api_key_model.dart';
import '../models/model_model.dart';

class ProviderRepository {
  final SecureStorageService _secureStorage;
  final Uuid _uuid = const Uuid();

  static const _secureKeyPrefix = '__secure__';

  ProviderRepository() : _secureStorage = SecureStorageService();

  Future<List<ProviderModel>> getAll() async {
    final db = await AppDatabase.database;
    final providerMaps = await db.query('providers', orderBy: 'createdAt DESC');
    final providers = <ProviderModel>[];

    for (final pm in providerMaps) {
      final id = pm['id'] as String;
      final keyMaps = await db.query('api_keys',
          where: 'providerId = ?', whereArgs: [id], orderBy: 'priority ASC');
      final modelMaps = await db.query('models',
          where: 'providerId = ?', whereArgs: [id]);

      final apiKeys = <ApiKeyModel>[];
      for (final km in keyMaps) {
        final keyId = km['id'] as String;
        var keyValue = km['key'] as String;
        if (keyValue == _secureKeyPrefix) {
          keyValue = await _secureStorage.getApiKey(keyId) ?? '';
        }
        apiKeys.add(ApiKeyModel(
          id: keyId,
          providerId: km['providerId'] as String,
          key: keyValue,
          priority: (km['priority'] as int?) ?? 0,
        ));
      }

      providers.add(ProviderModel(
        id: id,
        name: pm['name'] as String,
        baseUrl: pm['baseUrl'] as String,
        extraHeaders: (pm['extraHeaders'] as String?) ?? '',
        isActive: (pm['isActive'] as int?) == 1,
        apiKeys: apiKeys,
        models: modelMaps.map((m) => ModelModel.fromMap(m)).toList(),
        createdAt: DateTime.parse(pm['createdAt'] as String),
      ));
    }
    return providers;
  }

  Future<ProviderModel?> getById(String id) async {
    final all = await getAll();
    try {
      return all.firstWhere((p) => p.id == id);
    } catch (_) {
      return null;
    }
  }

  Future<void> save(ProviderModel provider) async {
    final db = await AppDatabase.database;
    final batch = db.batch();
    batch.insert('providers', provider.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);

    for (final key in provider.apiKeys) {
      final keyMap = key.toMap();
      if (key.key.isNotEmpty) {
        await _secureStorage.saveApiKey(key.id, key.key);
        keyMap['key'] = _secureKeyPrefix;
      }
      batch.insert('api_keys', keyMap,
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    for (final model in provider.models) {
      batch.insert('models', model.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  Future<void> delete(String id) async {
    final db = await AppDatabase.database;
    final keyMaps = await db.query('api_keys',
        where: 'providerId = ?', whereArgs: [id]);
    for (final km in keyMaps) {
      await _secureStorage.deleteApiKey(km['id'] as String);
    }
    await db.delete('api_keys', where: 'providerId = ?', whereArgs: [id]);
    await db.delete('models', where: 'providerId = ?', whereArgs: [id]);
    await db.delete('providers', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> addApiKey(ApiKeyModel key) async {
    final db = await AppDatabase.database;
    final keyMap = key.toMap();
    if (key.key.isNotEmpty) {
      await _secureStorage.saveApiKey(key.id, key.key);
      keyMap['key'] = _secureKeyPrefix;
    }
    await db.insert('api_keys', keyMap,
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteApiKey(String id) async {
    final db = await AppDatabase.database;
    await _secureStorage.deleteApiKey(id);
    await db.delete('api_keys', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> addModel(ModelModel model) async {
    final db = await AppDatabase.database;
    await db.insert('models', model.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteModel(String id) async {
    final db = await AppDatabase.database;
    await db.delete('models', where: 'id = ?', whereArgs: [id]);
  }

  Future<Map<String, dynamic>> exportConfig() async {
    final providers = await getAll();
    return {
      'providers': providers
          .map((p) => {
                'name': p.name,
                'baseUrl': p.baseUrl,
                'models': p.models.map((m) => m.name).toList(),
              })
          .toList(),
      'exportedAt': DateTime.now().toIso8601String(),
      'version': '1.0.0',
    };
  }

  Future<String?> getApiKeyForProvider(String providerId) async {
    return _secureStorage.getApiKey(providerId);
  }
}
