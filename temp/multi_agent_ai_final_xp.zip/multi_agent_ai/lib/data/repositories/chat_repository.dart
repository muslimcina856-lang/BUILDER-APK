import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';
import '../datasources/local/database.dart';
import '../models/chat_model.dart';
import '../models/message_model.dart';

class ChatRepository {
  final Uuid _uuid = const Uuid();

  Future<List<ChatModel>> getAll({String? searchQuery}) async {
    final db = await AppDatabase.database;
    List<Map<String, dynamic>> chatMaps;

    if (searchQuery != null && searchQuery.isNotEmpty) {
      final likeQuery = '%$searchQuery%';
      chatMaps = await db.rawQuery('''
        SELECT DISTINCT c.* FROM chats c
        LEFT JOIN messages m ON m.chatId = c.id
        WHERE c.title LIKE ? OR m.content LIKE ?
        ORDER BY c.updatedAt DESC
      ''', [likeQuery, likeQuery]);
    } else {
      chatMaps = await db.query('chats', orderBy: 'updatedAt DESC');
    }

    final chats = <ChatModel>[];
    for (final cm in chatMaps) {
      final id = cm['id'] as String;
      final messageMaps = await db.query('messages',
          where: 'chatId = ?', whereArgs: [id], orderBy: 'timestamp ASC');
      chats.add(ChatModel(
        id: id,
        title: cm['title'] as String,
        modelId: cm['modelId'] as String,
        skillId: cm['skillId'] as String?,
        instructionOverride: cm['instructionOverride'] as String?,
        createdAt: DateTime.parse(cm['createdAt'] as String),
        updatedAt: DateTime.parse(cm['updatedAt'] as String),
        messages: messageMaps.map((m) => MessageModel.fromMap(m)).toList(),
      ));
    }
    return chats;
  }

  Future<ChatModel?> getById(String id) async {
    final db = await AppDatabase.database;
    final chatMaps = await db.query('chats', where: 'id = ?', whereArgs: [id]);
    if (chatMaps.isEmpty) return null;

    final cm = chatMaps.first;
    final messageMaps = await db.query('messages',
        where: 'chatId = ?', whereArgs: [id], orderBy: 'timestamp ASC');
    return ChatModel(
      id: cm['id'] as String,
      title: cm['title'] as String,
      modelId: cm['modelId'] as String,
      skillId: cm['skillId'] as String?,
      instructionOverride: cm['instructionOverride'] as String?,
      createdAt: DateTime.parse(cm['createdAt'] as String),
      updatedAt: DateTime.parse(cm['updatedAt'] as String),
      messages: messageMaps.map((m) => MessageModel.fromMap(m)).toList(),
    );
  }

  Future<ChatModel> createChat({
    required String modelId,
    String? title,
    String? skillId,
    String? instructionOverride,
  }) async {
    final db = await AppDatabase.database;
    final now = DateTime.now();
    final chat = ChatModel(
      id: _uuid.v4(),
      title: title ?? 'Chat Baru',
      modelId: modelId,
      skillId: skillId,
      instructionOverride: instructionOverride,
      createdAt: now,
      updatedAt: now,
    );
    await db.insert('chats', chat.toMap());
    return chat;
  }

  Future<void> updateTitle(String chatId, String title) async {
    final db = await AppDatabase.database;
    await db.update('chats', {
      'title': title,
      'updatedAt': DateTime.now().toIso8601String(),
    }, where: 'id = ?', whereArgs: [chatId]);
  }

  Future<MessageModel> addMessage({
    required String chatId,
    required String role,
    required String content,
  }) async {
    final db = await AppDatabase.database;
    final message = MessageModel(
      id: _uuid.v4(),
      chatId: chatId,
      role: role,
      content: content,
    );
    await db.insert('messages', message.toMap());

    final firstWord = content.length > 50
        ? '${content.substring(0, 50)}...'
        : content;
    await db.update('chats', {
      'title': firstWord.replaceAll('\n', ' '),
      'updatedAt': DateTime.now().toIso8601String(),
    }, where: 'id = ?', whereArgs: [chatId]);

    return message;
  }

  Future<void> deleteChat(String id) async {
    final db = await AppDatabase.database;
    await db.delete('messages', where: 'chatId = ?', whereArgs: [id]);
    await db.delete('chats', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteAll() async {
    final db = await AppDatabase.database;
    await db.delete('messages');
    await db.delete('chats');
  }

  Future<void> deleteMessagesForChat(String chatId) async {
    final db = await AppDatabase.database;
    await db.delete('messages', where: 'chatId = ?', whereArgs: [chatId]);
  }
}
