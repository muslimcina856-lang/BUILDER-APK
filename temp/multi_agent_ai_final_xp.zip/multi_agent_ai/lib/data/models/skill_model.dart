class SkillModel {
  final String id;
  final String name;
  final String content;
  final DateTime createdAt;

  SkillModel({
    required this.id,
    required this.name,
    required this.content,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'content': content,
        'createdAt': createdAt.toIso8601String(),
      };

  factory SkillModel.fromMap(Map<String, dynamic> map) => SkillModel(
        id: map['id'] as String,
        name: map['name'] as String,
        content: map['content'] as String,
        createdAt: map['createdAt'] != null
            ? DateTime.parse(map['createdAt'] as String)
            : DateTime.now(),
      );

  SkillModel copyWith({
    String? id,
    String? name,
    String? content,
    DateTime? createdAt,
  }) =>
      SkillModel(
        id: id ?? this.id,
        name: name ?? this.name,
        content: content ?? this.content,
        createdAt: createdAt ?? this.createdAt,
      );
}
