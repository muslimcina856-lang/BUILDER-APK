class MessageModel {
  final String id;
  final String chatId;
  final String role;
  final String content;
  final DateTime timestamp;

  MessageModel({
    required this.id,
    required this.chatId,
    required this.role,
    required this.content,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'chatId': chatId,
        'role': role,
        'content': content,
        'timestamp': timestamp.toIso8601String(),
      };

  factory MessageModel.fromMap(Map<String, dynamic> map) => MessageModel(
        id: map['id'] as String,
        chatId: map['chatId'] as String,
        role: map['role'] as String,
        content: map['content'] as String,
        timestamp: DateTime.parse(map['timestamp'] as String),
      );

  MessageModel copyWith({
    String? id,
    String? chatId,
    String? role,
    String? content,
    DateTime? timestamp,
  }) =>
      MessageModel(
        id: id ?? this.id,
        chatId: chatId ?? this.chatId,
        role: role ?? this.role,
        content: content ?? this.content,
        timestamp: timestamp ?? this.timestamp,
      );
}
