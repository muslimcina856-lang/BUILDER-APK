class ModelModel {
  final String id;
  final String providerId;
  final String name;
  final bool isDefault;

  ModelModel({
    required this.id,
    required this.providerId,
    required this.name,
    this.isDefault = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'providerId': providerId,
        'name': name,
        'isDefault': isDefault ? 1 : 0,
      };

  factory ModelModel.fromMap(Map<String, dynamic> map) => ModelModel(
        id: map['id'] as String,
        providerId: map['providerId'] as String,
        name: map['name'] as String,
        isDefault: (map['isDefault'] as int?) == 1,
      );

  ModelModel copyWith({
    String? id,
    String? providerId,
    String? name,
    bool? isDefault,
  }) =>
      ModelModel(
        id: id ?? this.id,
        providerId: providerId ?? this.providerId,
        name: name ?? this.name,
        isDefault: isDefault ?? this.isDefault,
      );
}
