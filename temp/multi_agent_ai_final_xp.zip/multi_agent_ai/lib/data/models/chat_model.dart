import 'message_model.dart';

class ChatModel {
  final String id;
  final String title;
  final String modelId;
  final String? skillId;
  final String? instructionOverride;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<MessageModel> messages;

  ChatModel({
    required this.id,
    required this.title,
    required this.modelId,
    this.skillId,
    this.instructionOverride,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<MessageModel>? messages,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now(),
        messages = messages ?? [];

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'modelId': modelId,
        'skillId': skillId,
        'instructionOverride': instructionOverride,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory ChatModel.fromMap(Map<String, dynamic> map) => ChatModel(
        id: map['id'] as String,
        title: map['title'] as String,
        modelId: map['modelId'] as String,
        skillId: map['skillId'] as String?,
        instructionOverride: map['instructionOverride'] as String?,
        createdAt: DateTime.parse(map['createdAt'] as String),
        updatedAt: DateTime.parse(map['updatedAt'] as String),
      );

  ChatModel copyWith({
    String? id,
    String? title,
    String? modelId,
    String? skillId,
    String? instructionOverride,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<MessageModel>? messages,
  }) =>
      ChatModel(
        id: id ?? this.id,
        title: title ?? this.title,
        modelId: modelId ?? this.modelId,
        skillId: skillId ?? this.skillId,
        instructionOverride: instructionOverride ?? this.instructionOverride,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        messages: messages ?? this.messages,
      );
}
