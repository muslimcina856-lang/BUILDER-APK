class ApiKeyModel {
  final String id;
  final String providerId;
  final String key;
  final int priority;

  ApiKeyModel({
    required this.id,
    required this.providerId,
    required this.key,
    this.priority = 0,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'providerId': providerId,
        'key': key,
        'priority': priority,
      };

  factory ApiKeyModel.fromMap(Map<String, dynamic> map) => ApiKeyModel(
        id: map['id'] as String,
        providerId: map['providerId'] as String,
        key: map['key'] as String,
        priority: (map['priority'] as int?) ?? 0,
      );

  ApiKeyModel copyWith({
    String? id,
    String? providerId,
    String? key,
    int? priority,
  }) =>
      ApiKeyModel(
        id: id ?? this.id,
        providerId: providerId ?? this.providerId,
        key: key ?? this.key,
        priority: priority ?? this.priority,
      );
}
