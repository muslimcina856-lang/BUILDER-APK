import 'api_key_model.dart';
import 'model_model.dart';

class ProviderModel {
  final String id;
  final String name;
  final String baseUrl;
  final String extraHeaders;
  final bool isActive;
  final List<ApiKeyModel> apiKeys;
  final List<ModelModel> models;
  final DateTime createdAt;

  ProviderModel({
    required this.id,
    required this.name,
    required this.baseUrl,
    this.extraHeaders = '',
    this.isActive = true,
    List<ApiKeyModel>? apiKeys,
    List<ModelModel>? models,
    DateTime? createdAt,
  })  : apiKeys = apiKeys ?? [],
        models = models ?? [],
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'baseUrl': baseUrl,
        'extraHeaders': extraHeaders,
        'isActive': isActive ? 1 : 0,
        'createdAt': createdAt.toIso8601String(),
      };

  factory ProviderModel.fromMap(Map<String, dynamic> map) => ProviderModel(
        id: map['id'] as String,
        name: map['name'] as String,
        baseUrl: map['baseUrl'] as String,
        extraHeaders: (map['extraHeaders'] as String?) ?? '',
        isActive: (map['isActive'] as int?) == 1,
        createdAt: map['createdAt'] != null
            ? DateTime.parse(map['createdAt'] as String)
            : DateTime.now(),
      );

  ProviderModel copyWith({
    String? id,
    String? name,
    String? baseUrl,
    String? extraHeaders,
    bool? isActive,
    List<ApiKeyModel>? apiKeys,
    List<ModelModel>? models,
    DateTime? createdAt,
  }) =>
      ProviderModel(
        id: id ?? this.id,
        name: name ?? this.name,
        baseUrl: baseUrl ?? this.baseUrl,
        extraHeaders: extraHeaders ?? this.extraHeaders,
        isActive: isActive ?? this.isActive,
        apiKeys: apiKeys ?? this.apiKeys,
        models: models ?? this.models,
        createdAt: createdAt ?? this.createdAt,
      );
}
