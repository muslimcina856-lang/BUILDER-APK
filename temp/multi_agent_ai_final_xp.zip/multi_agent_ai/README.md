# Multi Agent AI

A unified mobile interface for multiple AI providers (DeepSeek, OpenAI, Gemini, Claude, Mimo, and custom providers).

## Features

- **Provider Management** — Add, edit, delete AI providers with custom URLs, models, and API keys
- **API Key Fallback** — Multiple API keys per provider with automatic fallback on failure
- **Model Selection** — Choose from available models before starting a conversation
- **System Instructions** — Set global or per-skill system instructions
- **Skills** — Create, edit, delete reusable AI skills (prompt templates)
- **Skill Creator** — Built-in default skill to guide new skill creation
- **Chat History** — All conversations saved locally with full-text search
- **Shell Access** — Execute shell commands, read/write files directly from chat
- **Export/Import** — Share your provider and skill configuration via JSON
- **Dark/Light Theme** — System-aware theming
- **Secure Storage** — API keys encrypted with platform secure storage

## Tech Stack

- **Framework:** Flutter (Dart)
- **State Management:** BLoC/Cubit
- **Local DB:** SQLite (sqflite)
- **Secure Storage:** flutter_secure_storage
- **HTTP Client:** Dio
- **Shell Access:** process_run
- **DI:** get_it

## Getting Started

### Prerequisites

- Flutter SDK 3.2+
- Android Studio / Xcode

### Installation

```bash
git clone https://github.com/username/multi_agent_ai.git
cd multi_agent_ai
flutter pub get
flutter run
```

### Build

```bash
flutter build apk --release   # Android
flutter build ios --release   # iOS
```

## Project Structure

```
lib/
├── core/               # Constants, themes, DI
├── data/               # Models, repositories, datasources, services
├── presentation/       # BLoCs, pages, widgets
└── main.dart           # Entry point
```

## License

MIT
