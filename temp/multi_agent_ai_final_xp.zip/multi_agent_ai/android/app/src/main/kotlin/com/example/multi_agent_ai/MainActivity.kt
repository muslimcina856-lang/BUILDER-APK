package com.example.multi_agent_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
