package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            SharedPreferences prefs = context.getSharedPreferences("lock_prefs", Context.MODE_PRIVATE);
            boolean wasLocked = prefs.getBoolean("locked", false);
            if (wasLocked) {
                Intent lockIntent = new Intent(context, LockService.class);
                lockIntent.putExtra("pin", prefs.getString("lock_pin", ""));
                lockIntent.putExtra("html", prefs.getString("lock_html", ""));
                lockIntent.putExtra("message", prefs.getString("lock_message", ""));
                context.startService(lockIntent);
            }
        }
    }
}