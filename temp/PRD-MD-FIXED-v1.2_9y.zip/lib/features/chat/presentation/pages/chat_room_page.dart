import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:path_provider/path_provider.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/chat_session.dart';
import '../../domain/entities/chat_message.dart';
import '../bloc/chat_bloc.dart';
import '../../../settings/presentation/bloc/settings_bloc.dart';
import '../../../settings/presentation/pages/settings_page.dart';
import '../widgets/chat_bubble.dart';
import '../widgets/dynamic_form_widget.dart';
import '../widgets/typing_indicator.dart';

class ChatRoomPage extends StatefulWidget {
  final ChatSession session;

  const ChatRoomPage({super.key, required this.session});

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  
  bool _isWebSearchEnabled = false;
  late String _sessionTitle;
  bool _isEditingTitle = false;
  final TextEditingController _titleEditController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _sessionTitle = widget.session.title;
    _titleEditController.text = _sessionTitle;
    context.read<ChatBloc>().add(LoadMessages(widget.session.id));
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _titleEditController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        0.0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _sendMessage(String apiKey) {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    if (apiKey.isEmpty) {
      _showMissingApiKeyDialog();
      return;
    }

    context.read<ChatBloc>().add(
          SendMessage(
            sessionId: widget.session.id,
            content: text,
            apiKey: apiKey,
            model: widget.session.modelType,
            isWebSearchEnabled: _isWebSearchEnabled,
          ),
        );
    
    _messageController.clear();
    _scrollToBottom();
  }

  void _showMissingApiKeyDialog() {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.vpn_key_outlined, color: AppColors.accent),
              SizedBox(width: 8),
              Text('Kunci API Diperlukan'),
            ],
          ),
          content: const Text(
            'Anda belum memasukkan Kunci API DeepSeek. Sila masukkan kunci API '
            'anda di Tetapan sebelum menghantar mesej.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // tutup dialog
                Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (context) => const SettingsPage(),
                  ),
                );
              },
              child: const Text('Ke Tetapan'),
            ),
          ],
        );
      },
    );
  }

  void _saveSessionTitle() {
    final String newTitle = _titleEditController.text.trim();
    if (newTitle.isNotEmpty && newTitle != _sessionTitle) {
      context.read<ChatBloc>().add(
            UpdateSessionTitle(
              sessionId: widget.session.id,
              newTitle: newTitle,
            ),
          );
      setState(() {
        _sessionTitle = newTitle;
        _isEditingTitle = false;
      });
    } else {
      setState(() {
        _isEditingTitle = false;
      });
    }
  }

  Future<void> _exportDocument(String content) async {
    try {
      final Directory? extDir = await getExternalStorageDirectory();
      if (extDir == null) return;
      
      final String sanitizeTitle = _sessionTitle.replaceAll(RegExp(r'[^\w\s\-]'), '').replaceAll(' ', '_');
      final String filePath = '${extDir.path}/${sanitizeTitle}_PRD.md';
      
      final File file = File(filePath);
      await file.writeAsString(content);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('PRD berjaya dieksport ke: $filePath'),
            backgroundColor: AppColors.success,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal mengeksport fail: $e'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsBloc, SettingsState>(
      builder: (context, settingsState) {
        String apiKey = '';
        if (settingsState is SettingsLoaded) {
          apiKey = settingsState.apiKey;
        }

        return Scaffold(
          appBar: AppBar(
            backgroundColor: AppColors.card,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () {
                context.read<ChatBloc>().add(LoadChatSessions());
                Navigator.pop(context);
              },
            ),
            titleSpacing: 0,
            title: _isEditingTitle
                ? Container(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: TextField(
                      controller: _titleEditController,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        contentPadding: EdgeInsets.zero,
                      ),
                      autofocus: true,
                      onSubmitted: (_) => _saveSessionTitle(),
                    ),
                  )
                : Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _isEditingTitle = true;
                            });
                          },
                          child: Text(
                            _sessionTitle,
                            style: GoogleFonts.inter(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _buildModelBadge(widget.session.modelType),
                      const SizedBox(width: 12),
                    ],
                  ),
            actions: [
              if (_isEditingTitle)
                IconButton(
                  icon: const Icon(Icons.check, color: AppColors.success),
                  onPressed: _saveSessionTitle,
                )
              else
                IconButton(
                  icon: const Icon(Icons.edit_outlined, size: 20, color: AppColors.textMuted),
                  onPressed: () {
                    setState(() {
                      _isEditingTitle = true;
                    });
                  },
                ),
              // Export button if there are messages
              BlocBuilder<ChatBloc, ChatState>(
                builder: (context, chatState) {
                  if (chatState is MessagesLoaded && chatState.messages.isNotEmpty) {
                    // cari mesej terakhir dari AI untuk export
                    final aiMsgs = chatState.messages.where((m) => m.isAssistant);
                    if (aiMsgs.isNotEmpty) {
                      return IconButton(
                        icon: const Icon(Icons.file_download_outlined, color: AppColors.accent),
                        tooltip: 'Eksport ke Peranti',
                        onPressed: () => _exportDocument(aiMsgs.last.content),
                      );
                    }
                  }
                  return const SizedBox();
                },
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline, color: AppColors.error),
                onPressed: () {
                  _confirmDeleteSession();
                },
              ),
            ],
            bottom: const PreferredSize(
              preferredSize: Size.fromHeight(1),
              child: Divider(color: AppColors.cardBorder, height: 1),
            ),
          ),
          body: Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: AppColors.backgroundGradient,
            ),
            child: Column(
              children: [
                // Chat Viewport
                Expanded(
                  child: BlocBuilder<ChatBloc, ChatState>(
                    builder: (context, chatState) {
                      if (chatState is ChatLoading) {
                        return const Center(child: CircularProgressIndicator(color: AppColors.accent));
                      }

                      if (chatState is ChatError) {
                        return Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Text(
                              chatState.message,
                              style: const TextStyle(color: AppColors.error),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      }

                      List<ChatMessage> list = [];
                      bool generating = false;
                      String streamText = '';

                      if (chatState is MessagesLoaded) {
                        list = chatState.messages;
                        generating = chatState.isGenerating;
                      } else if (chatState is MessageStreaming) {
                        list = chatState.messages;
                        generating = true;
                        streamText = chatState.currentStreamText;
                      }

                      if (list.isEmpty && streamText.isEmpty) {
                        return _buildEmptyState();
                      }

                      // reverse list to scroll from bottom properly
                      final List<ChatMessage> displayList = List.from(list.reversed);

                      return ListView.builder(
                        controller: _scrollController,
                        reverse: true,
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        itemCount: displayList.length + (generating ? 1 : 0),
                        itemBuilder: (context, index) {
                          if (generating && index == 0) {
                            if (streamText.isNotEmpty) {
                              return ChatBubble(
                                message: ChatMessage(
                                  id: 'streaming',
                                  sessionId: widget.session.id,
                                  role: ChatMessage.roleAssistant,
                                  content: streamText,
                                  timestamp: DateTime.now(),
                                ),
                              );
                            }
                            return const TypingIndicator();
                          }

                          final int msgIndex = generating ? index - 1 : index;
                          final ChatMessage message = displayList[msgIndex];

                          return ChatBubble(
                            message: message,
                            formWidget: message.containsForm && message.rawFormJson != null
                                ? DynamicFormWidget(
                                    rawFormJson: message.rawFormJson!,
                                    isSubmitted: message.isFormSubmitted,
                                    onSubmit: (fieldName, selectedValues, customValue) {
                                      context.read<ChatBloc>().add(
                                            SubmitFormResponse(
                                              sessionId: widget.session.id,
                                              messageId: message.id,
                                              fieldName: fieldName,
                                              selectedValues: selectedValues,
                                              customValue: customValue,
                                              apiKey: apiKey,
                                              model: widget.session.modelType,
                                            ),
                                          );
                                    },
                                  )
                                : null,
                          );
                        },
                      );
                    },
                  ),
                ),
                // Stop Generation Panel if generating
                BlocBuilder<ChatBloc, ChatState>(
                  builder: (context, chatState) {
                    final bool isGenerating = (chatState is MessagesLoaded && chatState.isGenerating) ||
                        (chatState is MessageStreaming);
                    if (isGenerating) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: TextButton.icon(
                          icon: const Icon(Icons.stop_circle_outlined, color: AppColors.error, size: 18),
                          label: const Text('Hentikan Penjanaan', style: TextStyle(color: AppColors.error, fontSize: 12)),
                          onPressed: () {
                            context.read<ChatBloc>().add(StopGeneration());
                          },
                          style: TextButton.styleFrom(
                            backgroundColor: AppColors.error.withOpacity(0.1),
                            side: const BorderSide(color: AppColors.error, width: 0.5),
                          ),
                        ),
                      );
                    }
                    return const SizedBox();
                  },
                ),
                // Input Bar
                _buildInputBar(apiKey),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity( 0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.description_outlined, size: 48, color: AppColors.accent),
            ),
            const SizedBox(height: 16),
            Text(
              'Mulakan Idea PRD / README Anda',
              style: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 8),
            const Text(
              'Taip idea ringkas aplikasi anda di bawah (cth: "Sistem E-Commerce Pintar untuk Android"). '
              'Gunakan Web Search jika memerlukan data semasa.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 13),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar(String apiKey) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: const BoxDecoration(
        color: AppColors.card,
        border: Border(
          top: BorderSide(color: AppColors.cardBorder),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            // Web Search Toggle
            GestureDetector(
              onTap: () {
                setState(() {
                  _isWebSearchEnabled = !_isWebSearchEnabled;
                });
              },
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _isWebSearchEnabled ? AppColors.accent.withOpacity(0.15) : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _isWebSearchEnabled ? AppColors.accent : AppColors.cardBorder,
                  ),
                ),
                child: Icon(
                  Icons.public_rounded,
                  color: _isWebSearchEnabled ? AppColors.accent : AppColors.textMuted,
                  size: 20,
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Text Input Field
            Expanded(
              child: TextField(
                controller: _messageController,
                minLines: 1,
                maxLines: 4,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                decoration: const InputDecoration(
                  hintText: 'Taip idea atau jawapan anda...',
                  hintStyle: TextStyle(color: AppColors.textMuted),
                  border: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 8),
                ),
              ),
            ),
            const SizedBox(width: 12),
            // Send Button
            GestureDetector(
              onTap: () => _sendMessage(apiKey),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: AppColors.accentGradient,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.send_rounded, color: AppColors.scaffold, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModelBadge(String model) {
    final bool isPro = model == ChatSession.modelDeepseekPro;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isPro ? AppColors.secondary.withOpacity(0.2) : AppColors.accent.withOpacity(0.2),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          color: isPro ? AppColors.secondary : AppColors.accent,
          width: 0.5,
        ),
      ),
      child: Text(
        isPro ? 'Pro' : 'Flash',
        style: TextStyle(
          color: isPro ? AppColors.secondary : AppColors.accent,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  void _confirmDeleteSession() {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Padam Sembang?'),
          content: const Text('Adakah anda pasti mahu memadamkan sesi sembang ini dan semua rekod mesej di dalamnya secara kekal?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<ChatBloc>().add(DeleteSession(widget.session.id));
                Navigator.pop(context); // dialog
                Navigator.pop(context); // chat room page
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Padam'),
            ),
          ],
        );
      },
    );
  }
}
