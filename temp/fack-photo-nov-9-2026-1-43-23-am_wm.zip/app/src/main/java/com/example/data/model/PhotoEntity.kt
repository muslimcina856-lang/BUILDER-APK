package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photos")
data class PhotoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val caption: String,
    val authorName: String,
    val authorAvatarColor: Long = 0xFF8B5CF6,
    val category: String,
    val genderTag: String = "General", // "Boys", "Girls", "Group", "General"
    val imageUri: String,
    val drawableResName: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val stickerStamp: String = "",
    val filterEffect: String = "Normal",
    val frameStyle: String = "None", // "Neon Blue (Boys)", "Pink Glam (Girls)", "Golden King", "None"
    val commentsCount: Int = 0,
    val isFavorite: Boolean = false
)
