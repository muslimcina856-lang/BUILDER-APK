package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.components.FunStickerBadge
import com.example.ui.components.PhotoFilterOverlay
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.VibrantCoral
import com.example.ui.viewmodel.StudioUiState
import java.io.File

@Composable
fun StudioScreen(
    studioState: StudioUiState,
    onImageSelected: (Uri?) -> Unit,
    onHeadlineChanged: (String) -> Unit,
    onSubTextChanged: (String) -> Unit,
    onAuthorChanged: (String) -> Unit,
    onGenderChanged: (String) -> Unit,
    onStickerChanged: (String) -> Unit,
    onBannerColorChanged: (Long) -> Unit,
    onPublishMeme: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        onImageSelected(uri)
    }

    val boysHeadlines = listOf(
        "BREAKING: Boy Attitude Level Reaches 1000%!",
        "OP CHAD: Single Look Freezes The Whole College!",
        "GANGSTER ENTRY: Police Confirm Overpowered Swagger!",
        "WANTED: For Being Way Too Handsome!"
    )

    val girlsHeadlines = listOf(
        "BREAKING: Slay Queen Turns Entire City Heads!",
        "ALERT: 100% Barbie Vibes Cause Heavy Traffic!",
        "CUTE & DANGEROUS: One Smile Stole 10,000 Hearts!",
        "DRAMA QUEEN: Declared Official Royal Highness!"
    )

    val activeHeadlines = if (studioState.genderTag == "Girls") girlsHeadlines else boysHeadlines

    val boysStickers = listOf(
        "ATTITUDE KING 👑",
        "OP CHAD 🔥",
        "GANGSTER BOY 🕶️",
        "RIDER BOY 🏍️",
        "MOST HANDSOME 🏆"
    )

    val girlsStickers = listOf(
        "SLAY QUEEN 💅",
        "BARBIE VIBES 💖",
        "CUTE & DANGEROUS ✨",
        "GIRL CRUSH #1 🌟",
        "DRAMA QUEEN 👑"
    )

    val activeStickers = if (studioState.genderTag == "Girls") girlsStickers else boysStickers

    val bannerColors = listOf(
        Pair("Blue Thunder", 0xFF0284C7),
        Pair("Hot Pink", 0xFFDB2777),
        Pair("Red Alert", 0xFFEF4444),
        Pair("Neon Violet", 0xFF8B5CF6),
        Pair("Amber Gold", 0xFFF59E0B)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("studio_lazy_column"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(VibrantCoral, NeonViolet))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "OP Studio",
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Text(
                    text = "Create OP breaking news, boy attitude memes & slay queen posters!",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Gender Mode Selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val modeList = listOf(
                    Triple("Boys", "👦 Boys OP Memes", Color(0xFF0284C7)),
                    Triple("Girls", "👧 Girls OP Slay", Color(0xFFDB2777)),
                    Triple("Group", "🎭 Viral Pranks", Color(0xFF8B5CF6))
                )

                modeList.forEach { (mode, label, color) ->
                    val isSelected = studioState.genderTag == mode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) color else MaterialTheme.colorScheme.surface)
                            .border(
                                1.5.dp,
                                if (isSelected) color else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onGenderChanged(mode) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontFamily = OutfitFontFamily,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 11.sp,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Live Fake News / Meme Preview Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("studio_preview_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LIVE OP MEME PREVIEW",
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    // Photo box with news overlay
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(4f / 3f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E1B2E))
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    ) {
                        if (studioState.selectedImagePath != null || studioState.selectedImageUri != null) {
                            val model = studioState.selectedImagePath?.let { File(it) } ?: studioState.selectedImageUri
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(model)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = "Studio Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clickable {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(42.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Tap to choose photo for ${studioState.genderTag} meme",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Top News Banner
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(studioState.bannerColor))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (studioState.genderTag == "Boys") "⚡ OP BOY SPECIAL" else if (studioState.genderTag == "Girls") "💅 SLAY QUEEN EXCLUSIVE" else "🔴 FACK PHOTO EXCLUSIVE",
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                color = Color.White,
                                letterSpacing = 0.5.sp
                            )

                            Text(
                                text = "JUST IN",
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = Color.White
                            )
                        }

                        // Stamp badge
                        if (studioState.stickerStamp.isNotBlank()) {
                            FunStickerBadge(
                                stickerStamp = studioState.stickerStamp,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 34.dp, end = 10.dp)
                            )
                        }

                        // Bottom Breaking News Ticker Overlay
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color(0xCC000000),
                                            Color(0xFF0F0F14)
                                        )
                                    )
                                )
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(Color(studioState.bannerColor), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (studioState.genderTag == "Boys") "🔥 ATTITUDE ALERT" else if (studioState.genderTag == "Girls") "✨ SLAY ALERT" else "BREAKING NEWS",
                                    fontFamily = OutfitFontFamily,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.sp,
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = studioState.headlineText,
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.White,
                                maxLines = 2
                            )

                            if (studioState.subText.isNotBlank()) {
                                Text(
                                    text = studioState.subText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFE2E8F0),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("studio_pick_photo_button")
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (studioState.selectedImagePath != null) "Change Photo" else "Pick Photo from Phone")
                    }
                }
            }
        }

        // Headlines & Customization Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Customize Headlines & Badges",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Quick headline suggestions
                    Text(
                        text = "OP ${studioState.genderTag} Presets:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        activeHeadlines.forEach { preset ->
                            SuggestionChip(
                                onClick = { onHeadlineChanged(preset) },
                                label = { Text(preset, fontSize = 11.sp) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            )
                        }
                    }

                    // Headline Input
                    OutlinedTextField(
                        value = studioState.headlineText,
                        onValueChange = onHeadlineChanged,
                        label = { Text("News Headline") },
                        placeholder = { Text("Enter funny headline") },
                        singleLine = false,
                        maxLines = 2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("studio_headline_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                    )

                    // Subtext Input
                    OutlinedTextField(
                        value = studioState.subText,
                        onValueChange = onSubTextChanged,
                        label = { Text("Sub-Headline / Quote") },
                        placeholder = { Text("e.g. Eyewitnesses are stunned!") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("studio_subtext_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                    )

                    // Uploader / Creator Name
                    OutlinedTextField(
                        value = studioState.authorName,
                        onValueChange = onAuthorChanged,
                        label = { Text("Creator / Channel Name") },
                        placeholder = { Text("e.g. OP Media, Rahul") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("studio_creator_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                    )

                    // Banner Color Selection
                    Text(
                        text = "Banner Color Theme:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        bannerColors.forEach { (name, colorVal) ->
                            val isSelected = colorVal == studioState.bannerColor
                            FilterChip(
                                selected = isSelected,
                                onClick = { onBannerColorChanged(colorVal) },
                                label = { Text(name, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                shape = RoundedCornerShape(16.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(colorVal),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    // Sticker badge selector
                    Text(
                        text = "Stamp Badge:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        activeStickers.forEach { sticker ->
                            val isSelected = sticker == studioState.stickerStamp
                            FilterChip(
                                selected = isSelected,
                                onClick = { onStickerChanged(sticker) },
                                label = { Text(sticker, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                shape = RoundedCornerShape(16.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (studioState.genderTag == "Girls") Color(0xFFDB2777) else Color(0xFF0284C7),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }

        // Publish to Sab Ka Feed Button
        item {
            Button(
                onClick = onPublishMeme,
                enabled = !studioState.isPublishing && (studioState.selectedImagePath != null || studioState.selectedImageUri != null),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (studioState.genderTag == "Girls") Color(0xFFDB2777) else if (studioState.genderTag == "Boys") Color(0xFF0284C7) else VibrantCoral,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("publish_studio_meme_button")
            ) {
                if (studioState.isPublishing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color.White,
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Publishing OP Meme...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(
                        imageVector = Icons.Default.Publish,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Publish ${studioState.genderTag} Meme to Feed",
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}
