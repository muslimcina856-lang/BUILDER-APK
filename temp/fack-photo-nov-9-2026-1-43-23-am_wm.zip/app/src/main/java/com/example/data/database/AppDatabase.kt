package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.CommentDao
import com.example.data.dao.PhotoDao
import com.example.data.model.CommentEntity
import com.example.data.model.PhotoEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [PhotoEntity::class, CommentEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun photoDao(): PhotoDao
    abstract fun commentDao(): CommentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fack_photo_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.photoDao(), database.commentDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(photoDao: PhotoDao, commentDao: CommentDao) {
            val initialPhotos = listOf(
                PhotoEntity(
                    id = 1,
                    title = "City Street Squad! 🌟",
                    caption = "When the entire group finally shows up on time! Candid moment at the cafe street.",
                    authorName = "Rahul Sharma",
                    authorAvatarColor = 0xFF8B5CF6,
                    category = "Friends",
                    genderTag = "Boys",
                    imageUri = "drawable://sample_friends_photo_1794167118287",
                    drawableResName = "sample_friends_photo_1794167118287",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                    likesCount = 84,
                    isLiked = true,
                    stickerStamp = "ATTITUDE KING 👑",
                    filterEffect = "Vibrant",
                    frameStyle = "Neon Blue (Boys)",
                    commentsCount = 2,
                    isFavorite = true
                ),
                PhotoEntity(
                    id = 2,
                    title = "Sarah's 24th Birthday Bash! 🎂🎉",
                    caption = "Rainbow cake, confetti everywhere and the best memories with everyone! 🎈",
                    authorName = "Priya Verma",
                    authorAvatarColor = 0xFFF43F5E,
                    category = "Party",
                    genderTag = "Girls",
                    imageUri = "drawable://sample_party_photo_1794167133034",
                    drawableResName = "sample_party_photo_1794167133034",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 3,
                    likesCount = 92,
                    isLiked = false,
                    stickerStamp = "SLAY QUEEN 💅",
                    filterEffect = "Warm Sunset",
                    frameStyle = "Pink Glam (Girls)",
                    commentsCount = 3,
                    isFavorite = false
                ),
                PhotoEntity(
                    id = 3,
                    title = "Summit Reached! 🏔️✨",
                    caption = "Hiked 14km before sunrise. View from the peak is surreal! 100% real no filter.",
                    authorName = "Aman Khan",
                    authorAvatarColor = 0xFF06B6D4,
                    category = "Travel",
                    genderTag = "Boys",
                    imageUri = "drawable://sample_adventure_photo_1794167147514",
                    drawableResName = "sample_adventure_photo_1794167147514",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 18,
                    likesCount = 76,
                    isLiked = true,
                    stickerStamp = "OP CHAD 🔥",
                    filterEffect = "Normal",
                    frameStyle = "Golden King",
                    commentsCount = 1,
                    isFavorite = true
                )
            )
            photoDao.insertAll(initialPhotos)

            val initialComments = listOf(
                CommentEntity(
                    photoId = 1,
                    authorName = "Sneha",
                    text = "Arey wah! Perfect picture sab ka ek saath! 🔥",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 30
                ),
                CommentEntity(
                    photoId = 1,
                    authorName = "Vikram",
                    text = "Bhai full OP attitude! 😂🔥",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 15
                ),
                CommentEntity(
                    photoId = 2,
                    authorName = "Kavita",
                    text = "Happy Birthday Sarah!! Slaying as always 💅✨",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 2
                ),
                CommentEntity(
                    photoId = 2,
                    authorName = "Rahul Sharma",
                    text = "Super fun party! Great click! 🥳",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60
                ),
                CommentEntity(
                    photoId = 3,
                    authorName = "Priya Verma",
                    text = "Bhai breathtaking view! Outstanding trek! 👏",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 12
                )
            )
            commentDao.insertAll(initialComments)
        }
    }
}
