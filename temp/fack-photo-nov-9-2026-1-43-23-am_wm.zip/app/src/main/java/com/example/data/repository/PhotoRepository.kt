package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.data.dao.CommentDao
import com.example.data.dao.PhotoDao
import com.example.data.database.AppDatabase
import com.example.data.model.CommentEntity
import com.example.data.model.PhotoEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

class PhotoRepository(
    private val context: Context,
    private val photoDao: PhotoDao,
    private val commentDao: CommentDao
) {
    val allPhotos: Flow<List<PhotoEntity>> = photoDao.getAllPhotos()
    val favoritePhotos: Flow<List<PhotoEntity>> = photoDao.getFavoritePhotos()
    val boysTotalLikes: Flow<Int?> = photoDao.getBoysTotalLikes()
    val girlsTotalLikes: Flow<Int?> = photoDao.getGirlsTotalLikes()

    fun getPhotosByCategoryOrGender(category: String, gender: String): Flow<List<PhotoEntity>> {
        return when {
            gender == "Boys" -> photoDao.getPhotosByGender("Boys")
            gender == "Girls" -> photoDao.getPhotosByGender("Girls")
            category != "All" -> photoDao.getPhotosByCategory(category)
            else -> photoDao.getAllPhotos()
        }
    }

    fun searchPhotos(query: String): Flow<List<PhotoEntity>> {
        return photoDao.searchPhotos(query)
    }

    fun getPhotoById(id: Long): Flow<PhotoEntity?> {
        return photoDao.getPhotoById(id)
    }

    fun getCommentsForPhoto(photoId: Long): Flow<List<CommentEntity>> {
        return commentDao.getCommentsForPhoto(photoId)
    }

    suspend fun checkAndSeedInitialData() {
        withContext(Dispatchers.IO) {
            val count = photoDao.getPhotoCount()
            if (count == 0) {
                AppDatabase.populateInitialData(photoDao, commentDao)
            }
        }
    }

    suspend fun saveImageFromUri(uri: Uri): String = withContext(Dispatchers.IO) {
        val photosDir = File(context.filesDir, "photos")
        if (!photosDir.exists()) {
            photosDir.mkdirs()
        }
        val file = File(photosDir, "fack_photo_${UUID.randomUUID()}.jpg")

        var inputStream: InputStream? = null
        var outputStream: FileOutputStream? = null
        try {
            inputStream = context.contentResolver.openInputStream(uri)
            outputStream = FileOutputStream(file)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
            file.absolutePath
        } finally {
            inputStream?.close()
            outputStream?.close()
        }
    }

    suspend fun saveBitmapToFile(bitmap: Bitmap): String = withContext(Dispatchers.IO) {
        val photosDir = File(context.filesDir, "photos")
        if (!photosDir.exists()) {
            photosDir.mkdirs()
        }
        val file = File(photosDir, "fack_photo_${UUID.randomUUID()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        file.absolutePath
    }

    suspend fun uploadPhoto(
        title: String,
        caption: String,
        authorName: String,
        category: String,
        genderTag: String = "General",
        imagePath: String,
        stickerStamp: String = "",
        filterEffect: String = "Normal",
        frameStyle: String = "None"
    ): Long = withContext(Dispatchers.IO) {
        val avatarColors = listOf(
            0xFF8B5CF6, 0xFF06B6D4, 0xFFF43F5E, 0xFF10B981,
            0xFFF59E0B, 0xFFEC4899, 0xFF3B82F6, 0xFF6366F1
        )
        val colorIndex = (authorName.hashCode() and 0x7FFFFFFF) % avatarColors.size
        val entity = PhotoEntity(
            title = title.ifBlank { "New OP Photo Click" },
            caption = caption,
            authorName = authorName.ifBlank { "Anonymous Creator" },
            authorAvatarColor = avatarColors[colorIndex],
            category = category,
            genderTag = genderTag,
            imageUri = "file://$imagePath",
            drawableResName = null,
            timestamp = System.currentTimeMillis(),
            likesCount = 1,
            isLiked = true,
            stickerStamp = stickerStamp,
            filterEffect = filterEffect,
            frameStyle = frameStyle,
            commentsCount = 0,
            isFavorite = false
        )
        photoDao.insertPhoto(entity)
    }

    suspend fun toggleLike(photo: PhotoEntity) = withContext(Dispatchers.IO) {
        val newIsLiked = !photo.isLiked
        val newCount = if (newIsLiked) photo.likesCount + 1 else maxOf(0, photo.likesCount - 1)
        photoDao.updateLike(photo.id, newIsLiked, newCount)
    }

    suspend fun toggleFavorite(photo: PhotoEntity) = withContext(Dispatchers.IO) {
        photoDao.updateFavorite(photo.id, !photo.isFavorite)
    }

    suspend fun addComment(photoId: Long, authorName: String, text: String): Long = withContext(Dispatchers.IO) {
        val comment = CommentEntity(
            photoId = photoId,
            authorName = authorName.ifBlank { "Viewer" },
            text = text,
            timestamp = System.currentTimeMillis()
        )
        val id = commentDao.insertComment(comment)
        photoDao.incrementCommentsCount(photoId)
        id
    }

    suspend fun deletePhoto(photo: PhotoEntity) = withContext(Dispatchers.IO) {
        if (photo.imageUri.startsWith("file://")) {
            val path = photo.imageUri.removePrefix("file://")
            val file = File(path)
            if (file.exists()) {
                file.delete()
            }
        }
        photoDao.deletePhoto(photo)
    }
}
