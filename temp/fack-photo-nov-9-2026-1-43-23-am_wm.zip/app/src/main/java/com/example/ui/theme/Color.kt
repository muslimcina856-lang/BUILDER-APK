package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon / Electric Palette for Fack Photo
val NeonViolet = Color(0xFF8B5CF6)
val NeonVioletDark = Color(0xFF6D28D9)
val NeonCyan = Color(0xFF06B6D4)
val NeonCyanLight = Color(0xFF22D3EE)
val VibrantCoral = Color(0xFFF43F5E)
val AmberGold = Color(0xFFF59E0B)
val EmeraldGreen = Color(0xFF10B981)

// Dark Theme Colors
val DarkBackground = Color(0xFF0F111A)
val DarkSurface = Color(0xFF171926)
val DarkSurfaceVariant = Color(0xFF23263B)
val DarkSurfaceBorder = Color(0xFF2E334D)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkOnSurface = Color(0xFFE2E8F0)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceBorder = Color(0xFFE2E8F0)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOnSurfaceVariant = Color(0xFF64748B)

// Fun Stamp badge colors
val StampGold = Color(0xFFFBBF24)
val StampRed = Color(0xFFEF4444)
val StampPurple = Color(0xFFA855F7)
val StampBlue = Color(0xFF3B82F6)
