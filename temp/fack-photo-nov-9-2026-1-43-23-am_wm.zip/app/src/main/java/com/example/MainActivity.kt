package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.PhotoDetailDialog
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.FeedScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.screens.UploadScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.PhotoViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: PhotoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                FackPhotoApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun FackPhotoApp(viewModel: PhotoViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val photos by viewModel.photos.collectAsStateWithLifecycle()
    val favoritePhotos by viewModel.favoritePhotos.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedGenderFilter by viewModel.selectedGenderFilter.collectAsStateWithLifecycle()
    val boysTotalLikes by viewModel.boysTotalLikes.collectAsStateWithLifecycle()
    val girlsTotalLikes by viewModel.girlsTotalLikes.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedPhotoForDetail by viewModel.selectedPhotoForDetail.collectAsStateWithLifecycle()
    val photoComments by viewModel.photoComments.collectAsStateWithLifecycle()
    val uploadState by viewModel.uploadState.collectAsStateWithLifecycle()
    val studioState by viewModel.studioState.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.userFeedbackMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedbackMessage()
        }
    }

    // Handle back button when on sub-screens
    BackHandler(enabled = currentScreen != AppScreen.FEED) {
        viewModel.navigateTo(AppScreen.FEED)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_bottom_nav"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                // Feed Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.FEED,
                    onClick = { viewModel.navigateTo(AppScreen.FEED) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.FEED) Icons.Default.PhotoLibrary else Icons.Outlined.PhotoLibrary,
                            contentDescription = "Feed"
                        )
                    },
                    label = {
                        Text(
                            text = "Sab Ka Feed",
                            fontWeight = if (currentScreen == AppScreen.FEED) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_feed")
                )

                // Upload Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.UPLOAD,
                    onClick = { viewModel.navigateTo(AppScreen.UPLOAD) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.UPLOAD) Icons.Default.CloudUpload else Icons.Outlined.CloudUpload,
                            contentDescription = "Upload"
                        )
                    },
                    label = {
                        Text(
                            text = "Upload",
                            fontWeight = if (currentScreen == AppScreen.UPLOAD) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_upload")
                )

                // Fack Studio Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.STUDIO,
                    onClick = { viewModel.navigateTo(AppScreen.STUDIO) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.STUDIO) Icons.Default.Campaign else Icons.Outlined.Campaign,
                            contentDescription = "Studio"
                        )
                    },
                    label = {
                        Text(
                            text = "Studio",
                            fontWeight = if (currentScreen == AppScreen.STUDIO) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_studio")
                )

                // Favorites Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.FAVORITES,
                    onClick = { viewModel.navigateTo(AppScreen.FAVORITES) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.FAVORITES) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Saved"
                        )
                    },
                    label = {
                        Text(
                            text = "Saved",
                            fontWeight = if (currentScreen == AppScreen.FAVORITES) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_saved")
                )
            }
        }
    ) { innerPadding ->
        when (currentScreen) {
            AppScreen.FEED -> {
                FeedScreen(
                    photos = photos,
                    selectedCategory = selectedCategory,
                    selectedGenderFilter = selectedGenderFilter,
                    searchQuery = searchQuery,
                    boysTotalLikes = boysTotalLikes,
                    girlsTotalLikes = girlsTotalLikes,
                    onCategorySelected = { viewModel.selectCategory(it) },
                    onGenderFilterSelected = { viewModel.selectGenderFilter(it) },
                    onSearchQueryChanged = { viewModel.updateSearchQuery(it) },
                    onPhotoClick = { viewModel.openPhotoDetail(it) },
                    onLikeClick = { viewModel.toggleLike(it) },
                    onFavoriteClick = { viewModel.toggleFavorite(it) },
                    onNavigateToUpload = { viewModel.navigateTo(AppScreen.UPLOAD) },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            AppScreen.UPLOAD -> {
                UploadScreen(
                    uploadState = uploadState,
                    onImageSelected = { viewModel.setUploadImageUri(it) },
                    onTitleChanged = { viewModel.updateUploadTitle(it) },
                    onCaptionChanged = { viewModel.updateUploadCaption(it) },
                    onAuthorChanged = { viewModel.updateUploadAuthor(it) },
                    onCategoryChanged = { viewModel.updateUploadCategory(it) },
                    onGenderChanged = { viewModel.updateUploadGender(it) },
                    onStickerChanged = { viewModel.updateUploadSticker(it) },
                    onFilterChanged = { viewModel.updateUploadFilter(it) },
                    onFrameChanged = { viewModel.updateUploadFrame(it) },
                    onSubmitUpload = { viewModel.submitUpload() },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            AppScreen.STUDIO -> {
                StudioScreen(
                    studioState = studioState,
                    onImageSelected = { viewModel.setStudioImageUri(it) },
                    onHeadlineChanged = { viewModel.updateStudioHeadline(it) },
                    onSubTextChanged = { viewModel.updateStudioSubText(it) },
                    onAuthorChanged = { viewModel.updateStudioAuthor(it) },
                    onGenderChanged = { viewModel.updateStudioGender(it) },
                    onStickerChanged = { viewModel.updateStudioSticker(it) },
                    onBannerColorChanged = { viewModel.updateStudioBannerColor(it) },
                    onPublishMeme = { viewModel.publishStudioMeme() },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            AppScreen.FAVORITES -> {
                FavoritesScreen(
                    favoritePhotos = favoritePhotos,
                    onPhotoClick = { viewModel.openPhotoDetail(it) },
                    onLikeClick = { viewModel.toggleLike(it) },
                    onFavoriteClick = { viewModel.toggleFavorite(it) },
                    onNavigateToFeed = { viewModel.navigateTo(AppScreen.FEED) },
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }

    // Full Photo Detail Dialog
    selectedPhotoForDetail?.let { photo ->
        PhotoDetailDialog(
            photo = photo,
            comments = photoComments,
            onDismiss = { viewModel.closePhotoDetail() },
            onLikeClick = { viewModel.toggleLike(photo) },
            onFavoriteClick = { viewModel.toggleFavorite(photo) },
            onDeleteClick = { viewModel.deletePhoto(photo) },
            onAddComment = { author, text -> viewModel.addComment(photo.id, author, text) }
        )
    }
}
