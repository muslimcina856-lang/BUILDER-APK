package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.CommentEntity
import com.example.data.model.PhotoEntity
import com.example.data.repository.PhotoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    FEED,
    UPLOAD,
    STUDIO,
    FAVORITES
}

data class UploadUiState(
    val selectedImageUri: Uri? = null,
    val selectedImagePath: String? = null,
    val title: String = "",
    val caption: String = "",
    val authorName: String = "",
    val category: String = "Friends",
    val genderTag: String = "Boys", // "Boys", "Girls", "Group"
    val stickerStamp: String = "ATTITUDE KING 👑",
    val filterEffect: String = "Normal",
    val frameStyle: String = "Neon Blue (Boys)",
    val isUploading: Boolean = false,
    val uploadSuccess: Boolean = false,
    val errorMessage: String? = null
)

data class StudioUiState(
    val selectedImageUri: Uri? = null,
    val selectedImagePath: String? = null,
    val headlineText: String = "BREAKING NEWS: Most OP Attitude Spotted!",
    val subText: String = "100% Verified Chad & Legend Level",
    val authorName: String = "OP Studio",
    val genderTag: String = "Boys",
    val stickerStamp: String = "ATTITUDE KING 👑",
    val bannerColor: Long = 0xFF0284C7,
    val isPublishing: Boolean = false,
    val publishSuccess: Boolean = false
)

class PhotoViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PhotoRepository

    init {
        val database = AppDatabase.getInstance(application, viewModelScope)
        repository = PhotoRepository(application, database.photoDao(), database.commentDao())
        viewModelScope.launch {
            repository.checkAndSeedInitialData()
        }
    }

    private val _currentScreen = MutableStateFlow(AppScreen.FEED)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedGenderFilter = MutableStateFlow("All") // "All", "Boys", "Girls"
    val selectedGenderFilter: StateFlow<String> = _selectedGenderFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Boys vs Girls likes battle
    val boysTotalLikes: StateFlow<Int> = repository.boysTotalLikes
        .map { it ?: 0 }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val girlsTotalLikes: StateFlow<Int> = repository.girlsTotalLikes
        .map { it ?: 0 }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val photos: StateFlow<List<PhotoEntity>> = combine(
        _selectedCategory,
        _selectedGenderFilter,
        _searchQuery
    ) { category, gender, query ->
        Triple(category, gender, query)
    }.flatMapLatest { (category, gender, query) ->
        if (query.isNotBlank()) {
            repository.searchPhotos(query)
        } else {
            repository.getPhotosByCategoryOrGender(category, gender)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favoritePhotos: StateFlow<List<PhotoEntity>> = repository.favoritePhotos.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Detail photo view
    private val _selectedPhotoForDetail = MutableStateFlow<PhotoEntity?>(null)
    val selectedPhotoForDetail: StateFlow<PhotoEntity?> = _selectedPhotoForDetail.asStateFlow()

    private val _photoComments = MutableStateFlow<List<CommentEntity>>(emptyList())
    val photoComments: StateFlow<List<CommentEntity>> = _photoComments.asStateFlow()

    // Upload state
    private val _uploadState = MutableStateFlow(UploadUiState())
    val uploadState: StateFlow<UploadUiState> = _uploadState.asStateFlow()

    // Studio state
    private val _studioState = MutableStateFlow(StudioUiState())
    val studioState: StateFlow<StudioUiState> = _studioState.asStateFlow()

    // Status feedback message
    private val _userFeedbackMessage = MutableStateFlow<String?>(null)
    val userFeedbackMessage: StateFlow<String?> = _userFeedbackMessage.asStateFlow()

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun selectGenderFilter(gender: String) {
        _selectedGenderFilter.value = gender
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearFeedbackMessage() {
        _userFeedbackMessage.value = null
    }

    fun openPhotoDetail(photo: PhotoEntity) {
        _selectedPhotoForDetail.value = photo
        viewModelScope.launch {
            repository.getCommentsForPhoto(photo.id).collect { comments ->
                _photoComments.value = comments
            }
        }
    }

    fun closePhotoDetail() {
        _selectedPhotoForDetail.value = null
        _photoComments.value = emptyList()
    }

    fun toggleLike(photo: PhotoEntity) {
        viewModelScope.launch {
            repository.toggleLike(photo)
            if (_selectedPhotoForDetail.value?.id == photo.id) {
                val newLiked = !photo.isLiked
                val newCount = if (newLiked) photo.likesCount + 1 else maxOf(0, photo.likesCount - 1)
                _selectedPhotoForDetail.value = photo.copy(isLiked = newLiked, likesCount = newCount)
            }
        }
    }

    fun toggleFavorite(photo: PhotoEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(photo)
            if (_selectedPhotoForDetail.value?.id == photo.id) {
                _selectedPhotoForDetail.value = photo.copy(isFavorite = !photo.isFavorite)
            }
        }
    }

    fun addComment(photoId: Long, authorName: String, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.addComment(photoId, authorName, text.trim())
            _selectedPhotoForDetail.value?.let { current ->
                if (current.id == photoId) {
                    _selectedPhotoForDetail.value = current.copy(commentsCount = current.commentsCount + 1)
                }
            }
        }
    }

    fun deletePhoto(photo: PhotoEntity) {
        viewModelScope.launch {
            repository.deletePhoto(photo)
            if (_selectedPhotoForDetail.value?.id == photo.id) {
                closePhotoDetail()
            }
            _userFeedbackMessage.value = "Photo deleted from Fack Photo"
        }
    }

    // Upload operations
    fun setUploadImageUri(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            try {
                val localPath = repository.saveImageFromUri(uri)
                _uploadState.value = _uploadState.value.copy(
                    selectedImageUri = uri,
                    selectedImagePath = localPath,
                    errorMessage = null
                )
            } catch (e: Exception) {
                _uploadState.value = _uploadState.value.copy(
                    errorMessage = "Could not load image: ${e.localizedMessage}"
                )
            }
        }
    }

    fun updateUploadTitle(title: String) {
        _uploadState.value = _uploadState.value.copy(title = title)
    }

    fun updateUploadCaption(caption: String) {
        _uploadState.value = _uploadState.value.copy(caption = caption)
    }

    fun updateUploadAuthor(name: String) {
        _uploadState.value = _uploadState.value.copy(authorName = name)
    }

    fun updateUploadCategory(category: String) {
        _uploadState.value = _uploadState.value.copy(category = category)
    }

    fun updateUploadGender(gender: String) {
        val defaultStamp = when (gender) {
            "Boys" -> "ATTITUDE KING 👑"
            "Girls" -> "SLAY QUEEN 💅"
            else -> "VERIFIED LEGEND"
        }
        val defaultFrame = when (gender) {
            "Boys" -> "Neon Blue (Boys)"
            "Girls" -> "Pink Glam (Girls)"
            else -> "Golden King"
        }
        _uploadState.value = _uploadState.value.copy(
            genderTag = gender,
            stickerStamp = defaultStamp,
            frameStyle = defaultFrame
        )
    }

    fun updateUploadSticker(sticker: String) {
        _uploadState.value = _uploadState.value.copy(stickerStamp = sticker)
    }

    fun updateUploadFilter(filter: String) {
        _uploadState.value = _uploadState.value.copy(filterEffect = filter)
    }

    fun updateUploadFrame(frame: String) {
        _uploadState.value = _uploadState.value.copy(frameStyle = frame)
    }

    fun submitUpload() {
        val state = _uploadState.value
        val path = state.selectedImagePath
        if (path.isNullOrBlank()) {
            _uploadState.value = state.copy(errorMessage = "Please select a photo to upload!")
            return
        }

        viewModelScope.launch {
            _uploadState.value = state.copy(isUploading = true, errorMessage = null)
            try {
                repository.uploadPhoto(
                    title = state.title.ifBlank { "${state.genderTag} OP Click" },
                    caption = state.caption,
                    authorName = state.authorName.ifBlank { "Anonymous Creator" },
                    category = state.category,
                    genderTag = state.genderTag,
                    imagePath = path,
                    stickerStamp = state.stickerStamp,
                    filterEffect = state.filterEffect,
                    frameStyle = state.frameStyle
                )
                _uploadState.value = UploadUiState(uploadSuccess = true)
                _userFeedbackMessage.value = "OP Photo uploaded successfully to Sab Ka Feed!"
                _currentScreen.value = AppScreen.FEED
            } catch (e: Exception) {
                _uploadState.value = state.copy(
                    isUploading = false,
                    errorMessage = "Failed to upload photo: ${e.localizedMessage}"
                )
            }
        }
    }

    fun resetUploadState() {
        _uploadState.value = UploadUiState()
    }

    // Studio / Meme operations
    fun setStudioImageUri(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            try {
                val localPath = repository.saveImageFromUri(uri)
                _studioState.value = _studioState.value.copy(
                    selectedImageUri = uri,
                    selectedImagePath = localPath
                )
            } catch (e: Exception) {
                _userFeedbackMessage.value = "Error loading photo for studio"
            }
        }
    }

    fun updateStudioHeadline(text: String) {
        _studioState.value = _studioState.value.copy(headlineText = text)
    }

    fun updateStudioSubText(text: String) {
        _studioState.value = _studioState.value.copy(subText = text)
    }

    fun updateStudioAuthor(name: String) {
        _studioState.value = _studioState.value.copy(authorName = name)
    }

    fun updateStudioGender(gender: String) {
        val (stamp, color, headline) = when (gender) {
            "Boys" -> Triple("ATTITUDE KING 👑", 0xFF0284C7, "BREAKING: Boy Attitude Level Reaches 1000%!")
            "Girls" -> Triple("SLAY QUEEN 💅", 0xFFDB2777, "BREAKING: Slay Queen Turns Entire City Heads!")
            else -> Triple("BUSTED! FAKE CANDID", 0xFFEF4444, "BREAKING NEWS: Spotted Being Awesome!")
        }
        _studioState.value = _studioState.value.copy(
            genderTag = gender,
            stickerStamp = stamp,
            bannerColor = color,
            headlineText = headline
        )
    }

    fun updateStudioSticker(sticker: String) {
        _studioState.value = _studioState.value.copy(stickerStamp = sticker)
    }

    fun updateStudioBannerColor(color: Long) {
        _studioState.value = _studioState.value.copy(bannerColor = color)
    }

    fun publishStudioMeme() {
        val state = _studioState.value
        val path = state.selectedImagePath
        if (path.isNullOrBlank()) {
            _userFeedbackMessage.value = "Please select a photo first!"
            return
        }

        viewModelScope.launch {
            _studioState.value = state.copy(isPublishing = true)
            try {
                val captionCombined = "${state.headlineText}\n${state.subText}"
                val frame = if (state.genderTag == "Boys") "Neon Blue (Boys)" else if (state.genderTag == "Girls") "Pink Glam (Girls)" else "Golden King"
                repository.uploadPhoto(
                    title = "Breaking: " + state.headlineText.take(25),
                    caption = captionCombined,
                    authorName = state.authorName.ifBlank { "Fack Studio" },
                    category = "Meme & Prank",
                    genderTag = state.genderTag,
                    imagePath = path,
                    stickerStamp = state.stickerStamp,
                    filterEffect = "Vibrant",
                    frameStyle = frame
                )
                _studioState.value = StudioUiState(publishSuccess = true)
                _userFeedbackMessage.value = "OP Meme published to Sab Ka Feed!"
                _currentScreen.value = AppScreen.FEED
            } catch (e: Exception) {
                _studioState.value = state.copy(isPublishing = false)
                _userFeedbackMessage.value = "Failed to publish: ${e.localizedMessage}"
            }
        }
    }
}
