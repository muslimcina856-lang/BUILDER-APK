package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.OutfitFontFamily

@Composable
fun PhotoFilterOverlay(
    filterEffect: String,
    frameStyle: String = "None",
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        // Base tone effect
        when (filterEffect) {
            "Warm Sunset" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0x33FF7A00),
                                    Color(0x11FF007A),
                                    Color(0x447A00FF)
                                )
                            )
                        )
                )
            }
            "Vibrant" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0x2200E5FF),
                                    Color(0x339D00FF)
                                )
                            )
                        )
                )
            }
            "Noir" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x55000000))
                )
            }
            "Cyber Neon" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0x33A855F7),
                                    Color(0x2206B6D4)
                                )
                            )
                        )
                )
            }
            "Vintage" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x33B45309))
                )
            }
            else -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0x66000000)
                                )
                            )
                        )
                )
            }
        }

        // OP Frame Style Border
        when (frameStyle) {
            "Neon Blue (Boys)" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(
                            3.dp,
                            Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFF2563EB))),
                            RoundedCornerShape(12.dp)
                        )
                )
            }
            "Pink Glam (Girls)" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(
                            3.dp,
                            Brush.linearGradient(listOf(Color(0xFFFF007F), Color(0xFFE879F9))),
                            RoundedCornerShape(12.dp)
                        )
                )
            }
            "Golden King" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(
                            3.dp,
                            Brush.linearGradient(listOf(Color(0xFFFBBF24), Color(0xFFD97706))),
                            RoundedCornerShape(12.dp)
                        )
                )
            }
            "Cyber Neon" -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(
                            3.dp,
                            Brush.linearGradient(listOf(Color(0xFFA855F7), Color(0xFF06B6D4))),
                            RoundedCornerShape(12.dp)
                        )
                )
            }
        }
    }
}

@Composable
fun FunStickerBadge(
    stickerStamp: String,
    modifier: Modifier = Modifier
) {
    if (stickerStamp.isBlank() || stickerStamp == "NONE") return

    val (bgColor, textColor, borderColor, icon) = when {
        // OP Boys Badges
        stickerStamp.contains("ATTITUDE KING") -> Quadruple(
            Color(0xFF0284C7),
            Color.White,
            Color(0xFF38BDF8),
            Icons.Default.FlashOn
        )
        stickerStamp.contains("OP CHAD") || stickerStamp.contains("CHAD") -> Quadruple(
            Color(0xFFEA580C),
            Color.White,
            Color(0xFFFDBA74),
            Icons.Default.LocalFireDepartment
        )
        stickerStamp.contains("GANGSTER") -> Quadruple(
            Color(0xFF0F172A),
            Color(0xFF38BDF8),
            Color(0xFF38BDF8),
            Icons.Default.Shield
        )
        stickerStamp.contains("RIDER") -> Quadruple(
            Color(0xFF16A34A),
            Color.White,
            Color(0xFF86EFAC),
            Icons.Default.TwoWheeler
        )
        stickerStamp.contains("HANDSOME") -> Quadruple(
            Color(0xFF2563EB),
            Color.White,
            Color(0xFF93C5FD),
            Icons.Default.Diamond
        )

        // OP Girls Badges
        stickerStamp.contains("SLAY QUEEN") -> Quadruple(
            Color(0xFFDB2777),
            Color.White,
            Color(0xFFF472B6),
            Icons.Default.AutoAwesome
        )
        stickerStamp.contains("BARBIE") -> Quadruple(
            Color(0xFFEC4899),
            Color.White,
            Color(0xFFFBCFE8),
            Icons.Default.Favorite
        )
        stickerStamp.contains("DANGEROUS") || stickerStamp.contains("CUTE") -> Quadruple(
            Color(0xFF9333EA),
            Color.White,
            Color(0xFFC084FC),
            Icons.Default.Star
        )
        stickerStamp.contains("CRUSH") -> Quadruple(
            Color(0xFFF43F5E),
            Color.White,
            Color(0xFFFDA4AF),
            Icons.Default.Favorite
        )
        stickerStamp.contains("DRAMA QUEEN") -> Quadruple(
            Color(0xFFE11D48),
            Color.White,
            Color(0xFFFECDD3),
            Icons.Default.LocalFireDepartment
        )

        // General Badges
        stickerStamp.contains("LEGEND") -> Quadruple(
            Color(0xFFEAB308),
            Color(0xFF0F172A),
            Color(0xFFFEF08A),
            Icons.Default.Star
        )
        stickerStamp.contains("BUSTED") || stickerStamp.contains("CANDID") -> Quadruple(
            Color(0xFFEF4444),
            Color.White,
            Color(0xFFFCA5A5),
            Icons.Default.Warning
        )
        stickerStamp.contains("REAL") -> Quadruple(
            Color(0xFF10B981),
            Color.White,
            Color(0xFFA7F3D0),
            Icons.Default.CheckCircle
        )
        stickerStamp.contains("PARTY") -> Quadruple(
            Color(0xFFF43F5E),
            Color.White,
            Color(0xFFFECDD3),
            Icons.Default.Celebration
        )
        else -> Quadruple(
            Color(0xFF3B82F6),
            Color.White,
            Color(0xFFBFDBFE),
            Icons.Default.Star
        )
    }

    Box(
        modifier = modifier
            .rotate(-4f)
            .background(bgColor, RoundedCornerShape(8.dp))
            .border(1.5.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = stickerStamp,
                fontFamily = OutfitFontFamily,
                fontWeight = FontWeight.Black,
                fontSize = 10.sp,
                color = textColor,
                letterSpacing = 0.5.sp
            )
        }
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
