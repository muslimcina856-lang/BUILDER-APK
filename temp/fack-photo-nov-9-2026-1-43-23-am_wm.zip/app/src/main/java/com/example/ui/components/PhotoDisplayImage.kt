package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.PhotoEntity
import java.io.File

@Composable
fun PhotoDisplayImage(
    photo: PhotoEntity,
    contentScale: ContentScale = ContentScale.Crop,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val imageModel = remember(photo) {
        when {
            photo.drawableResName != null -> {
                when (photo.drawableResName) {
                    "sample_friends_photo_1794167118287" -> R.drawable.sample_friends_photo_1794167118287
                    "sample_party_photo_1794167133034" -> R.drawable.sample_party_photo_1794167133034
                    "sample_adventure_photo_1794167147514" -> R.drawable.sample_adventure_photo_1794167147514
                    else -> {
                        val resId = context.resources.getIdentifier(
                            photo.drawableResName,
                            "drawable",
                            context.packageName
                        )
                        if (resId != 0) resId else R.drawable.ic_launcher_foreground
                    }
                }
            }
            photo.imageUri.startsWith("file://") -> {
                File(photo.imageUri.removePrefix("file://"))
            }
            else -> {
                photo.imageUri
            }
        }
    }

    SubcomposeAsyncImage(
        model = ImageRequest.Builder(context)
            .data(imageModel)
            .crossfade(true)
            .build(),
        contentDescription = photo.title,
        contentScale = contentScale,
        modifier = modifier,
        loading = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(28.dp),
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 2.5.dp
                )
            }
        },
        error = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.BrokenImage,
                    contentDescription = "Image Error",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(36.dp)
                )
            }
        }
    )
}
