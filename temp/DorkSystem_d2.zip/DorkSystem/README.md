# DorkSystem

Aplikasi Android untuk mencari link Group & Channel media sosial menggunakan Google Dorking.

## Ciri-ciri
- Pilih platform: Telegram, WhatsApp, Discord, Facebook Groups, atau Semua
- Auto bina Google Dork query
- WebView interaktif (boleh solve CAPTCHA dengan jari)
- Extract link automatik ke senarai bersih
- Copy satu / copy semua
- Buka link terus
- History carian
- Tema ikut system (Dark/Light)

## Cara Install & Jalankan

1. Buka **Android Studio** (versi terbaru disyorkan)
2. Pilih **Open** → pilih folder `DorkSystem` ini
3. Tunggu Gradle sync selesai
4. Sambungkan telefon Android (USB Debugging ON) atau guna Emulator
5. Tekan **Run** (▶)

### Nota penting
- App ini **tidak** bypass CAPTCHA secara automatik. Kau perlu solve sendiri dalam WebView.
- Google mungkin keluar CAPTCHA kerap untuk dork advanced. Itu normal.
- Guna secara bertanggungjawab. Jangan spam atau langgar ToS laman web.
- Link yang dijumpai mungkin sudah expired / private.

## Struktur
- `SearchFragment` : WebView + dork search
- `ResultsFragment` : Senarai link
- `HistoryFragment` : Sejarah carian
- `DorkHelper` : Generator query Google Dork

Dibuat untuk kegunaan peribadi / penyelidikan.
