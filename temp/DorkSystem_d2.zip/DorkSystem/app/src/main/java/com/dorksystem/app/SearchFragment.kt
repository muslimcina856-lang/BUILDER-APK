package com.dorksystem.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.dorksystem.app.databinding.FragmentSearchBinding
import java.net.URLEncoder

class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by activityViewModels()

    private var currentSite: DorkHelper.SiteOption = DorkHelper.ALL_SITES[0]

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupPlatformSpinner()
        setupWebView()
        setupButtons()
    }

    private fun setupPlatformSpinner() {
        val names = DorkHelper.getDisplayNames()
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, names)
        binding.spinnerPlatform.setAdapter(adapter)
        binding.spinnerPlatform.setText(names[0], false)
        currentSite = DorkHelper.ALL_SITES[0]

        binding.spinnerPlatform.setOnItemClickListener { _, _, position, _ ->
            currentSite = DorkHelper.ALL_SITES[position]
            // Tunjuk / sembunyi custom domain field
            if (currentSite.domain == "__custom__") {
                binding.customDomainLayout.visibility = View.VISIBLE
            } else {
                binding.customDomainLayout.visibility = View.GONE
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webSettings: WebSettings = binding.webview.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.loadWithOverviewMode = true
        webSettings.useWideViewPort = true
        webSettings.builtInZoomControls = true
        webSettings.displayZoomControls = false
        webSettings.setSupportZoom(true)
        // Buang "wv" supaya nampak macam browser biasa (kurang kena detect sebagai WebView)
        webSettings.userAgentString = webSettings.userAgentString.replace("; wv", "")

        binding.webview.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return false
            }
        }
        binding.webview.webChromeClient = WebChromeClient()
    }

    private fun setupButtons() {
        binding.btnSearch.setOnClickListener { doSearch() }
        binding.btnExtract.setOnClickListener { extractLinks() }

        binding.etKeyword.setOnEditorActionListener { _, _, _ ->
            doSearch()
            true
        }
    }

    private fun doSearch() {
        val keyword = binding.etKeyword.text?.toString()?.trim() ?: ""
        if (keyword.isEmpty()) {
            Toast.makeText(requireContext(), "Sila masukkan keyword", Toast.LENGTH_SHORT).show()
            return
        }

        // Ambil site semasa dari text (lebih selamat)
        val selectedName = binding.spinnerPlatform.text.toString()
        currentSite = DorkHelper.findByDisplayName(selectedName) ?: DorkHelper.ALL_SITES[0]

        val customDomain = binding.etCustomDomain.text?.toString()?.trim() ?: ""
        if (currentSite.domain == "__custom__" && customDomain.isEmpty()) {
            Toast.makeText(requireContext(), "Sila masukkan domain custom", Toast.LENGTH_SHORT).show()
            return
        }

        val dork = DorkHelper.buildDork(currentSite, keyword, customDomain)
        if (dork.isEmpty()) return

        val encoded = URLEncoder.encode(dork, "UTF-8")
        val url = "https://www.google.com/search?q=$encoded&num=100&filter=0&hl=en"

        viewModel.lastPlatform = currentSite.displayName
        viewModel.lastKeyword = keyword
        viewModel.addHistory(currentSite.displayName, keyword)
        viewModel.clearLinks()

        // Force clean load supaya boleh search berulang kali
        binding.webview.stopLoading()
        binding.webview.loadUrl("about:blank")
        binding.webview.postDelayed({
            binding.webview.loadUrl(url)
        }, 180)

        Toast.makeText(
            requireContext(),
            "Loading… Solve CAPTCHA jika keluar, kemudian tekan Extract",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun extractLinks() {
        val customDomain = binding.etCustomDomain.text?.toString()?.trim() ?: ""
        val patterns = DorkHelper.getLinkPatterns(currentSite, customDomain)

        if (patterns.isEmpty()) {
            Toast.makeText(requireContext(), "Tiada pattern untuk extract", Toast.LENGTH_SHORT).show()
            return
        }

        val js = """
            (function() {
                var links = [];
                var anchors = document.querySelectorAll('a[href]');
                var patterns = ${patterns.joinToString(prefix = "[", postfix = "]") { "\"$it\"" }};
                for (var i = 0; i < anchors.length; i++) {
                    var href = anchors[i].href;
                    if (!href) continue;
                    for (var j = 0; j < patterns.length; j++) {
                        if (href.indexOf(patterns[j]) !== -1) {
                            var clean = href.split('&')[0].split('?')[0];
                            if (links.indexOf(clean) === -1) {
                                links.push(clean);
                            }
                            break;
                        }
                    }
                }
                return JSON.stringify(links);
            })();
        """.trimIndent()

        binding.webview.evaluateJavascript(js) { result ->
            try {
                var clean = result ?: "[]"
                if (clean.startsWith("\"") && clean.endsWith("\"")) {
                    clean = clean.substring(1, clean.length - 1)
                        .replace("\\\"", "\"")
                        .replace("\\\\", "\\")
                }
                val arr = org.json.JSONArray(clean)
                val list = mutableListOf<String>()
                for (i in 0 until arr.length()) {
                    list.add(arr.getString(i))
                }
                viewModel.setLinks(list)
                Toast.makeText(requireContext(), "${list.size} link dijumpai", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.resultsFragment)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(
                    requireContext(),
                    "Gagal extract. Pastikan page dah load siap / CAPTCHA dah solve.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
