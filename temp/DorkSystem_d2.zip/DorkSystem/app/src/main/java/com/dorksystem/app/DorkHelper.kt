package com.dorksystem.app

object DorkHelper {

    data class SiteOption(
        val displayName: String,
        val domain: String,          // used in site: query
        val linkPatterns: List<String> // used when extracting links
    )

    // Senarai pilihan sebanyak mungkin (ikut extension + lebih)
    val ALL_SITES = listOf(
        SiteOption("Telegram", "t.me", listOf("t.me/", "telegram.me/")),
        SiteOption("WhatsApp", "chat.whatsapp.com", listOf("chat.whatsapp.com/", "wa.me/")),
        SiteOption("Discord", "discord.gg", listOf("discord.gg/", "discord.com/invite/")),
        SiteOption("Facebook", "facebook.com", listOf("facebook.com/", "fb.com/")),
        SiteOption("Facebook Groups", "facebook.com/groups", listOf("facebook.com/groups/")),
        SiteOption("Instagram", "instagram.com", listOf("instagram.com/")),
        SiteOption("Twitter / X", "x.com", listOf("x.com/", "twitter.com/")),
        SiteOption("TikTok", "tiktok.com", listOf("tiktok.com/")),
        SiteOption("Reddit", "reddit.com", listOf("reddit.com/")),
        SiteOption("LinkedIn", "linkedin.com", listOf("linkedin.com/")),
        SiteOption("YouTube", "youtube.com", listOf("youtube.com/", "youtu.be/")),
        SiteOption("GitHub", "github.com", listOf("github.com/")),
        SiteOption("Shopee", "shopee.com.my", listOf("shopee.com.my/", "shopee.com/")),
        SiteOption("Lazada", "lazada.com.my", listOf("lazada.com.my/", "lazada.com/")),
        SiteOption("Mudah.my", "mudah.my", listOf("mudah.my/")),
        SiteOption("Carousell", "carousell.com", listOf("carousell.com/", "carousell.com.my/")),
        SiteOption("Semua (Social)", "__all_social__", listOf(
            "t.me/", "telegram.me/", "chat.whatsapp.com/", "wa.me/",
            "discord.gg/", "discord.com/invite/",
            "facebook.com/groups/", "instagram.com/",
            "x.com/", "twitter.com/", "tiktok.com/", "reddit.com/"
        )),
        SiteOption("+ Custom Website", "__custom__", emptyList())
    )

    fun getDisplayNames(): List<String> = ALL_SITES.map { it.displayName }

    fun findByDisplayName(name: String): SiteOption? {
        return ALL_SITES.find { it.displayName == name }
    }

    fun buildDork(site: SiteOption, keyword: String, customDomain: String = ""): String {
        val k = keyword.trim().replace("\"", "")
        if (k.isEmpty()) return ""

        return when {
            site.domain == "__custom__" -> {
                val domain = customDomain.trim()
                    .removePrefix("https://")
                    .removePrefix("http://")
                    .removePrefix("www.")
                if (domain.isEmpty()) k else "site:$domain $k"
            }
            site.domain == "__all_social__" -> {
                """"$k" (site:t.me OR site:chat.whatsapp.com OR site:discord.gg OR site:facebook.com/groups OR site:instagram.com OR site:x.com OR site:tiktok.com OR site:reddit.com)"""
            }
            else -> "site:${site.domain} $k"
        }
    }

    fun getLinkPatterns(site: SiteOption, customDomain: String = ""): List<String> {
        return when {
            site.domain == "__custom__" -> {
                val domain = customDomain.trim()
                    .removePrefix("https://")
                    .removePrefix("http://")
                    .removePrefix("www.")
                if (domain.isEmpty()) emptyList() else listOf(domain)
            }
            else -> site.linkPatterns
        }
    }
}
