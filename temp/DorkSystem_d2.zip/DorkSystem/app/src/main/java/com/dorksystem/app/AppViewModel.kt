package com.dorksystem.app

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

data class HistoryItem(
    val platform: String,
    val keyword: String,
    val timestamp: Long = System.currentTimeMillis()
)

class AppViewModel : ViewModel() {

    private val _links = MutableLiveData<List<String>>(emptyList())
    val links: LiveData<List<String>> = _links

    private val _history = MutableLiveData<List<HistoryItem>>(emptyList())
    val history: LiveData<List<HistoryItem>> = _history

    var lastPlatform: String = "Telegram"
    var lastKeyword: String = ""

    fun setLinks(newLinks: List<String>) {
        _links.value = newLinks.distinct().filter { it.isNotBlank() }
    }

    fun addHistory(platform: String, keyword: String) {
        val current = _history.value?.toMutableList() ?: mutableListOf()
        current.add(0, HistoryItem(platform, keyword))
        if (current.size > 50) current.removeLast()
        _history.value = current
    }

    fun clearHistory() {
        _history.value = emptyList()
    }

    fun clearLinks() {
        _links.value = emptyList()
    }
}
