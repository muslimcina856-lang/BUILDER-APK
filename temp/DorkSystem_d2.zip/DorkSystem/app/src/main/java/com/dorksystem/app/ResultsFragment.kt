package com.dorksystem.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dorksystem.app.databinding.FragmentResultsBinding
import com.dorksystem.app.databinding.ItemLinkBinding

class ResultsFragment : Fragment() {

    private var _binding: FragmentResultsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentResultsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvLinks.layoutManager = LinearLayoutManager(requireContext())

        viewModel.links.observe(viewLifecycleOwner) { links ->
            if (links.isEmpty()) {
                binding.tvEmpty.visibility = View.VISIBLE
                binding.rvLinks.visibility = View.GONE
                binding.tvCount.text = "0 link dijumpai"
            } else {
                binding.tvEmpty.visibility = View.GONE
                binding.rvLinks.visibility = View.VISIBLE
                binding.tvCount.text = "${links.size} link dijumpai"
                binding.rvLinks.adapter = LinkAdapter(links)
            }
        }

        binding.btnCopyAll.setOnClickListener {
            val links = viewModel.links.value ?: emptyList()
            if (links.isEmpty()) {
                Toast.makeText(requireContext(), "Tiada link", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val text = links.joinToString("\n")
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("links", text))
            Toast.makeText(requireContext(), getString(R.string.copied), Toast.LENGTH_SHORT).show()
        }

        binding.btnExport.setOnClickListener {
            val links = viewModel.links.value ?: emptyList()
            if (links.isEmpty()) {
                Toast.makeText(requireContext(), "Tiada link untuk export", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val text = links.joinToString("\n")
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "DorkSystem Links")
                putExtra(Intent.EXTRA_TEXT, text)
                putExtra(Intent.EXTRA_TITLE, "dorksystem_links.txt")
            }
            startActivity(Intent.createChooser(intent, "Export / Share as TXT"))
        }
    }

    inner class LinkAdapter(private val items: List<String>) :
        RecyclerView.Adapter<LinkAdapter.ViewHolder>() {

        inner class ViewHolder(val binding: ItemLinkBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val b = ItemLinkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(b)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val link = items[position]
            holder.binding.tvLink.text = link

            holder.binding.btnCopy.setOnClickListener {
                val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("link", link))
                Toast.makeText(requireContext(), getString(R.string.copied), Toast.LENGTH_SHORT).show()
            }

            holder.binding.btnOpen.setOnClickListener {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link))
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Tidak boleh buka link", Toast.LENGTH_SHORT).show()
                }
            }
        }

        override fun getItemCount() = items.size
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
