# Keep WebView related
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
