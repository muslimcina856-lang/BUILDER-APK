# Build hotfix — 4 Ogos 2026

- Membetulkan kompilasi Dart dalam `linux_workspace_service.dart`: `FileSystemEntity.delete(...)` yang tidak wujud diganti dengan helper `_deleteEntity(...)`.
- Helper memadam berdasarkan jenis entiti sebenar (`File`, `Directory` atau `Link`) dan tidak mengikuti symlink.
- Menambah semakan regresi source supaya penggunaan semula API statik yang tidak sah itu menggagalkan validasi sebelum build Flutter.

# Linux completion — 4 Ogos 2026

- Menyiapkan Alpine Linux 3.24.1 ARM64 + PRoot 0.15 sebagai asset terbina yang dijana dan disahkan sebelum build debug/release.
- AI menerima kontrak Linux pada setiap tugasan: `apk`, `/workspace`, `/root`, terminal tanpa stdin interaktif, guest root tanpa `sudo`, serta aliran status/start/poll/stop.
- Terminal memasang runtime automatik sebelum arahan pertama, mengehadkan output, maksimum 8 job serentak dan 64 job terakhir, menerima UTF-8 rosak tanpa crash, serta menghentikan semua proses ketika larian dibatalkan, sesi/reset berubah atau had latar belakang tamat.
- Menambah pemasangan transaksi yang tahan process-kill: staging, backup, pemulihan permulaan, health check, rollback, dan pemeliharaan projek/home/cache/snapshot pengguna ketika naik taraf.
- Membetulkan health check supaya benar-benar menjalankan `apk --version` dan mengesahkan `apk-tools`.
- Menolak runtime pack dengan path traversal, nama entri berganda, symlink keluar sandbox/storan Android, jenis fail asing, CRC rosak, saiz/entri melampau, manifest salah, permission PRoot salah atau ELF bukan AArch64.
- Menghentikan job aktif sebelum pemasangan/import/reset runtime dan membersihkan ralat UI selepas import pemulihan berjaya.
- Build Full gagal jika runtime tidak sah, tidak dijana atau tidak terkandung dalam APK dan AAB; R8 `mapping.txt` kekal wajib.

# Build fix — 3 Ogos 2026

- Build debug Full kini menyediakan dan mengesahkan runtime Linux yang sama seperti release sebelum menghasilkan APK ARM64.
- Membetulkan health check Linux supaya menjalankan `apk --version` sebelum mengesahkan output `apk-tools`.
- Tambah import `AppState` yang hilang pada `home_shell.dart`.
- Pulihkan widget fallback `_MediaError` untuk imej dan video yang gagal dimuatkan.
- Pulihkan pemetaan ikon `_fileIcon` dan `_attachmentIcon`.
- Tambah alias warna `AppTheme.error` untuk tindakan destruktif Linux Workspace.
- Tambah semakan regresi sumber bagi semua simbol di atas.

# Changelog

## 1.0.0+1 — Dual Edition Final

- Menggantikan ikon edisi Full dengan ikon premium tanpa teks.
- Menetapkan Standard kepada target API 36 dan Full sideload kepada compatibility target API 28.
- Menambah dashboard Linux Workspace Full, terminal manual dan paparan proses AI bersama.
- Mengasingkan seluruh rootfs Alpine, pakej apk, projek, cache dan screenshot dalam storan internal private aplikasi.
- Membuang bind `/sys` serta menghadkan bind device PRoot kepada device asas sahaja.
- Membina dan membundel Alpine ARM64 + PRoot secara automatik, memasangnya sebelum terminal pertama, mengesahkan health check dan mengekalkan import File Picker sebagai pemulihan.
- Menambah screenshot browser Chromium tersembunyi sebagai artifact imej dalam chat.
- Menambah staging, rollback, semakan symlink dan pemulihan permission ketika memasang runtime.

## 1.0.0+1 — Dual Edition

- Menambah edisi Standard (`com.aiauto.claw`) dan Full (`com.aiauto.claw.full`).
- Menambah entry point, nama launcher dan ikon tanpa teks yang berasingan.
- Menambah Linux Workspace private dalam storan dalaman aplikasi.
- Menyekat package manager sistem pada edisi Standard dan membenarkannya pada edisi Full.
- Menambah skrip build APK/AAB mengikut flavor dan workflow CI dua edisi.
- Memastikan tiada permission akses storan luaran luas.

## 1.0.0+1 — Versi 1

- Mengekalkan versi paparan aplikasi sebagai `1.0.0`.
- Menggunakan `versionCode`/build number `1` sebagai build pertama aplikasi.
- Membetulkan ikon Material yang tidak wujud.
- Menambah pelaksanaan lengkap Skill Creator.
- Membetulkan pemeriksaan atribut HTML yang menyebabkan kompilasi gagal.
- Menggunakan UI chat premium, orchestrator model utama dan sub-agent dinamik.
- Menyokong provider BYOK, browser latar belakang, DuckDuckGo, media, fail, skills, automasi dan terminal.
- Mengunci `compileSdk` kepada API 36; edisi Standard menyasarkan API 36 dan Full menggunakan compatibility target 28 untuk PRoot.
- Membuang `mimo-v2-flash` daripada pilihan chat selepas endpoint MiMo menolaknya.
- Menapis model ASR/TTS daripada pemilih model chat dan menyegar model terus daripada provider.
- Memindahkan lifecycle `AppScope` ke atas Navigator dan menggunakan akses state tanpa dependency dalam callback async.
- Menambah key stabil pada mesej/media untuk mengelakkan state widget berpindah ketika senarai chat berubah.
- Menambah migrasi automatik konfigurasi MiMo lama serta fallback model satu kali.
