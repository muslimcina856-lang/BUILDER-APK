#!/usr/bin/env python3
"""Semakan tekstual ringan apabila Flutter/Dart SDK tidak tersedia."""
from __future__ import annotations

import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []
PAIRS = {')': '(', ']': '[', '}': '{'}


def scan_delimiters(path: Path) -> None:
    text = path.read_text(encoding='utf-8')
    if '\x00' in text:
        ERRORS.append(f'{path.relative_to(ROOT)} mengandungi NUL')
        return
    if any(marker in text for marker in ('<<<<<<<', '=======\n', '>>>>>>>')):
        ERRORS.append(f'{path.relative_to(ROOT)} mengandungi conflict marker')
    stack: list[tuple[str, int]] = []
    i = 0
    line = 1
    length = len(text)
    while i < length:
        char = text[i]
        if char == '\n':
            line += 1
            i += 1
            continue
        if text.startswith('//', i):
            end = text.find('\n', i + 2)
            i = length if end < 0 else end
            continue
        if text.startswith('/*', i):
            end = text.find('*/', i + 2)
            if end < 0:
                ERRORS.append(f'{path.relative_to(ROOT)} komen blok tidak ditutup pada baris {line}')
                return
            line += text.count('\n', i, end + 2)
            i = end + 2
            continue
        raw = False
        quote_index = i
        if char in ('r', 'R') and i + 1 < length and text[i + 1] in ('\'', '"'):
            raw = True
            quote_index = i + 1
        if text[quote_index] in ('\'', '"'):
            quote = text[quote_index]
            triple = text.startswith(quote * 3, quote_index)
            i = quote_index + (3 if triple else 1)
            while i < length:
                if text[i] == '\n':
                    line += 1
                if not raw and text[i] == '\\':
                    i += 2
                    continue
                if triple and text.startswith(quote * 3, i):
                    i += 3
                    break
                if not triple and text[i] == quote:
                    i += 1
                    break
                i += 1
            else:
                ERRORS.append(f'{path.relative_to(ROOT)} string tidak ditutup berhampiran baris {line}')
                return
            continue
        if char in '([{':
            stack.append((char, line))
        elif char in ')]}':
            if not stack or stack[-1][0] != PAIRS[char]:
                ERRORS.append(f'{path.relative_to(ROOT)} delimiter {char} tidak sepadan pada baris {line}')
                return
            stack.pop()
        i += 1
    if stack:
        symbol, start = stack[-1]
        ERRORS.append(f'{path.relative_to(ROOT)} delimiter {symbol} tidak ditutup dari baris {start}')


def parse_yaml(path: Path) -> None:
    try:
        yaml.safe_load(path.read_text(encoding='utf-8'))
    except Exception as error:
        ERRORS.append(f'{path.relative_to(ROOT)} YAML tidak sah: {error}')


FORBIDDEN_SOURCE_PATTERNS = {
    'FileSystemEntity.delete(': (
        'API statik Dart yang tidak wujud; gunakan File, Directory atau Link.'
    ),
}


def scan_forbidden_patterns(path: Path) -> None:
    text = path.read_text(encoding='utf-8')
    for pattern, reason in FORBIDDEN_SOURCE_PATTERNS.items():
        if pattern in text:
            ERRORS.append(
                f'{path.relative_to(ROOT)} mengandungi `{pattern}`: {reason}'
            )


for extension in ('*.dart', '*.kt', '*.kts'):
    for source in sorted(ROOT.rglob(extension)):
        if any(part in {'.dart_tool', 'build', '.cache'} for part in source.parts):
            continue
        scan_delimiters(source)
        scan_forbidden_patterns(source)

for yaml_path in (
    ROOT / 'mobile/pubspec.yaml',
    ROOT / '.github/workflows/android-release-check.yml',
):
    parse_yaml(yaml_path)

if ERRORS:
    print('SEMAKAN STRUKTUR SOURCE GAGAL')
    for error in ERRORS:
        print(f'- {error}')
    sys.exit(1)
print('SEMAKAN STRUKTUR SOURCE LULUS')
print('- Delimiter Dart/Kotlin, conflict marker dan YAML diperiksa')
