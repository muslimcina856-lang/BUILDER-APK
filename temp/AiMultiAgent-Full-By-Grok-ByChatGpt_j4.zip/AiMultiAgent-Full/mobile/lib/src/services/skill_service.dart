import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'local_database.dart';

class SkillService {
  SkillService(this.database, {http.Client? client}) : _client = client ?? http.Client();
  final LocalDatabase database;
  final http.Client _client;
  static const _uuid = Uuid();

  Future<List<SkillDefinition>> loadSkills() async {
    final saved = (await database.listObjects('skill'))
        .map(SkillDefinition.fromJson)
        .toList();
    final byId = <String, SkillDefinition>{
      for (final skill in saved) skill.id: skill,
    };
    for (final builtIn in _builtInSkills()) {
      final previous = byId[builtIn.id];
      final value = previous == null
          ? builtIn
          : SkillDefinition(
              id: builtIn.id,
              name: builtIn.name,
              description: builtIn.description,
              instructions: builtIn.instructions,
              toolIds: builtIn.toolIds,
              enabled: previous.enabled,
              sourcePath: previous.sourcePath,
              isBuiltIn: true,
            );
      byId[builtIn.id] = value;
      await database.saveObject('skill', value.id, value.toJson());
    }
    return _repairDuplicateNames(byId.values.toList());
  }

  /// Nama skill ialah identiti yang dilihat pengguna. Normalisasi ini sengaja
  /// case-insensitive dan merapatkan ruang supaya "Research" dan
  /// " research  " tidak boleh menjadi dua skill berasingan.
  String _normalizedSkillName(String value) =>
      value.trim().replaceAll(RegExp(r'\s+'), ' ').toLowerCase();

  Future<List<SkillDefinition>> _repairDuplicateNames(
    List<SkillDefinition> values,
  ) async {
    final used = <String, SkillDefinition>{
      for (final skill in values.where((item) => item.isBuiltIn))
        _normalizedSkillName(skill.name): skill,
    };
    final repaired = <SkillDefinition>[];
    for (final skill in values) {
      if (skill.isBuiltIn) {
        repaired.add(skill);
        continue;
      }
      final key = _normalizedSkillName(skill.name);
      final previous = used[key];
      if (previous == null) {
        used[key] = skill;
        repaired.add(skill);
        continue;
      }
      if (!previous.isBuiltIn && _sameSkillContent(previous, skill)) {
        // Data lama pernah membenarkan create berulang dengan UUID berlainan.
        // Buang salinan yang benar-benar sama sahaja; kandungan berbeza tidak
        // pernah dipadam secara senyap.
        if (skill.sourcePath.isNotEmpty &&
            skill.sourcePath == previous.sourcePath) {
          await database.deleteObject('skill', skill.id);
        } else {
          await delete(skill);
        }
        continue;
      }
      var suffix = 2;
      var nextName = '${skill.name.trim()} ($suffix)';
      while (used.containsKey(_normalizedSkillName(nextName))) {
        suffix++;
        nextName = '${skill.name.trim()} ($suffix)';
      }
      final renamed = SkillDefinition(
        id: skill.id,
        name: nextName,
        description: skill.description,
        instructions: skill.instructions,
        triggers: skill.triggers,
        toolIds: skill.toolIds,
        enabled: skill.enabled,
        sourcePath: skill.sourcePath,
        isBuiltIn: false,
      );
      await database.saveObject('skill', renamed.id, renamed.toJson());
      used[_normalizedSkillName(nextName)] = renamed;
      repaired.add(renamed);
    }
    return repaired;
  }

  bool _sameSkillContent(SkillDefinition left, SkillDefinition right) =>
      left.description == right.description &&
      left.instructions == right.instructions &&
      _sameStringList(left.triggers, right.triggers) &&
      _sameStringList(left.toolIds, right.toolIds);

  bool _sameStringList(List<String> left, List<String> right) {
    if (left.length != right.length) return false;
    for (var index = 0; index < left.length; index++) {
      if (left[index] != right[index]) return false;
    }
    return true;
  }

  Future<void> _ensureUniqueName(
    String name, {
    String excludeId = '',
  }) async {
    final normalized = _normalizedSkillName(name);
    if (normalized.isEmpty) {
      throw const FormatException('Nama skill diperlukan.');
    }
    SkillDefinition? collision;
    for (final skill in await loadSkills()) {
      if (skill.id != excludeId &&
          _normalizedSkillName(skill.name) == normalized) {
        collision = skill;
        break;
      }
    }
    if (collision != null) {
      throw StateError(
        'Nama skill "${name.trim()}" sudah digunakan oleh "${collision.name}". '
        'Nama skill mesti unik dan tidak boleh diduplikasi.',
      );
    }
  }

  Future<void> _ensureNewId(String id) async {
    if (await database.getObject('skill', id) != null) {
      throw StateError(
        'ID skill "$id" sudah wujud. Pemasangan tidak boleh menimpa skill sedia ada.',
      );
    }
  }

  Future<SkillDefinition> importZip(String zipPath) async => importBytes(
        await File(zipPath).readAsBytes(),
        sourceLabel: zipPath,
      );

  Future<SkillDefinition> importUrl(String rawUrl) async {
    final uri = Uri.tryParse(rawUrl.trim());
    if (uri == null || !<String>{'http', 'https'}.contains(uri.scheme) || uri.host.isEmpty) {
      throw const FormatException('URL skill tidak sah.');
    }
    final response = await _client.get(uri).timeout(AppConfig.defaultTimeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException('Muat turun skill gagal: HTTP ${response.statusCode}.');
    }
    if (response.bodyBytes.length > AppConfig.maxSkillArchiveBytes) {
      throw const FileSystemException('Arkib skill melebihi had 50 MB.');
    }
    return importBytes(response.bodyBytes, sourceLabel: uri.toString());
  }

  Future<SkillDefinition> importBytes(List<int> bytes, {required String sourceLabel}) async {
    if (bytes.length > AppConfig.maxSkillArchiveBytes) {
      throw const FileSystemException('Arkib skill melebihi had 50 MB.');
    }
    final archive = ZipDecoder().decodeBytes(bytes, verify: true);
    final skillsRoot = Directory(p.join((await getApplicationDocumentsDirectory()).path, 'skills'));
    await skillsRoot.create(recursive: true);
    final root = Directory(p.join(skillsRoot.path, _uuid.v4()));
    await root.create(recursive: true);

    var extractedBytes = 0;
    for (final entry in archive) {
      final normalizedName = p.normalize(entry.name.replaceAll('\\', '/'));
      if (normalizedName.startsWith('../') || p.isAbsolute(normalizedName)) continue;
      final target = p.normalize(p.join(root.path, normalizedName));
      if (!p.isWithin(root.path, target)) continue;
      if (entry.isFile) {
        final content = entry.readBytes();
        if (content == null) {
          throw const FileSystemException('Kandungan fail skill tidak dapat dibaca.');
        }
        extractedBytes += content.length;
        if (extractedBytes > AppConfig.maxSkillArchiveBytes * 4) {
          await root.delete(recursive: true);
          throw const FileSystemException('Arkib skill mengembang melebihi had keselamatan.');
        }
        final output = File(target);
        await output.parent.create(recursive: true);
        await output.writeAsBytes(content, flush: true);
      } else {
        await Directory(target).create(recursive: true);
      }
    }

    // 1) skill.json (format rasmi app)
    final manifest = await _findManifest(root);
    if (manifest != null) {
      final data =
          Map<String, dynamic>.from(jsonDecode(await manifest.readAsString()) as Map);
      final instructionFile = File(
        p.join(
          manifest.parent.path,
          data['instructionsFile']?.toString() ?? 'instructions.md',
        ),
      );
      final instructions = data['instructions']?.toString() ??
          (await instructionFile.exists()
              ? await instructionFile.readAsString()
              : '');
      final skill = SkillDefinition(
        id: data['id']?.toString().trim().isNotEmpty == true
            ? data['id'].toString()
            : _uuid.v4(),
        name: data['name']?.toString() ?? 'Imported Skill',
        description:
            data['description']?.toString() ?? 'Dipasang daripada $sourceLabel',
        instructions: instructions,
        triggers: const <String>[],
        toolIds: (data['tools'] as List? ?? const <dynamic>[])
            .map((item) => item.toString())
            .toList(),
        enabled: data['enabled'] as bool? ?? true,
        sourcePath: manifest.parent.path,
      );
      try {
        await _ensureNewId(skill.id);
        await save(skill);
      } catch (_) {
        await root.delete(recursive: true);
        rethrow;
      }
      return skill;
    }

    // 2) SKILL.md (Agent Skills) — auto-convert
    final skillMd = await _findSkillMarkdown(root);
    if (skillMd != null) {
      final parsed = _parseSkillMarkdown(await skillMd.readAsString());
      final skill = SkillDefinition(
        id: _safeSkillId(parsed['id']?.toString() ?? p.basename(skillMd.parent.path)),
        name: (parsed['name'] as String?)?.isNotEmpty == true
            ? parsed['name'] as String
            : 'Imported Skill',
        description: (parsed['description'] as String?)?.isNotEmpty == true
            ? parsed['description'] as String
            : 'Dipasang daripada SKILL.md ($sourceLabel)',
        instructions: parsed['instructions']?.toString() ?? '',
        triggers: const <String>[],
        toolIds: List<String>.from(parsed['tools'] as List? ?? const <String>[]),
        enabled: true,
        sourcePath: skillMd.parent.path,
      );
      if (skill.instructions.trim().isEmpty) {
        await root.delete(recursive: true);
        throw const FormatException(
          'SKILL.md dijumpai tetapi tiada arahan yang boleh dibaca.',
        );
      }
      try {
        await _ensureNewId(skill.id);
        await save(skill);
      } catch (_) {
        await root.delete(recursive: true);
        rethrow;
      }
      return skill;
    }

    await root.delete(recursive: true);
    throw const FormatException(
      'ZIP ini bukan skill pack: tiada skill.json mahupun SKILL.md. '
      'Repo biasa (cth. GitHub source) bukan skill — gunakan skill_create '
      'dengan ringkasan README/SKILL.md, atau ZIP yang mengandungi skill.json.',
    );
  }

  Future<SkillDefinition> createFromTool(Map<String, dynamic> arguments) async {
    var name = arguments['name']?.toString().trim() ?? '';
    if (name.isEmpty) {
      name = arguments['title']?.toString().trim() ?? '';
    }
    if (name.isEmpty) {
      name = arguments['skill_name']?.toString().trim() ?? '';
    }
    var description = arguments['description']?.toString().trim() ?? '';
    var instructions = arguments['instructions']?.toString().trim() ??
        arguments['content']?.toString().trim() ??
        arguments['body']?.toString().trim() ??
        '';
    if (description.isEmpty && instructions.isNotEmpty) {
      description = instructions.length > 160
          ? '${instructions.substring(0, 160).trim()}…'
          : instructions;
    }
    if (name.isEmpty && description.isNotEmpty) {
      name = description.length > 48
          ? description.substring(0, 48).trim()
          : description;
    }
    if (name.isEmpty) {
      throw const FormatException(
        'Nama skill diperlukan. Hantar name, title, atau description.',
      );
    }
    if (instructions.isEmpty) {
      throw const FormatException(
        'Arahan skill diperlukan (instructions). Jangan henti — isi instructions dan cuba skill_create lagi.',
      );
    }

    await _ensureUniqueName(name);

    final requestedId = arguments['id']?.toString().trim() ?? '';
    final id = requestedId.isEmpty ? _uuid.v4() : _safeSkillId(requestedId);
    final toolIds = (arguments['tool_ids'] as List? ?? const <dynamic>[])
        .map((item) => item.toString().trim())
        .where((item) => item.isNotEmpty)
        .toSet()
        .toList(growable: false);

    final existingJson = await database.getObject('skill', id);
    final existing = existingJson == null ? null : SkillDefinition.fromJson(existingJson);
    if (existing != null) {
      throw StateError(
        'ID skill "$id" sudah wujud. skill_create tidak boleh menimpa skill; '
        'gunakan skill_update supaya pengguna boleh mengesahkan perubahannya.',
      );
    }

    // Jika model tak senaraikan tool, biarkan kosong — runtime tetap boleh
    // pilih tool global; skill hanya arahan/konteks.
    final skill = SkillDefinition(
      id: id,
      name: name,
      description: description,
      instructions: instructions,
      triggers: const <String>[],
      toolIds: toolIds,
      enabled: arguments['enabled'] as bool? ?? existing?.enabled ?? true,
      sourcePath: existing?.sourcePath ?? '',
      isBuiltIn: false,
    );
    await save(skill);
    return skill;
  }

  Future<SkillDefinition> updateFromTool(
    Map<String, dynamic> arguments,
  ) async {
    final current = await _resolveSkill(arguments);
    if (current.isBuiltIn) {
      throw StateError('Skill terbina dalam tidak boleh diubah oleh AI.');
    }
    final updated = _updatedSkill(current, arguments);
    await _ensureUniqueName(updated.name, excludeId: current.id);
    await save(updated);
    return updated;
  }

  Future<SkillDefinition> deleteFromTool(
    Map<String, dynamic> arguments,
  ) async {
    final skill = await _resolveSkill(arguments);
    if (skill.isBuiltIn) {
      throw StateError('Skill terbina dalam tidak boleh dipadam.');
    }
    await delete(skill);
    return skill;
  }

  Future<String> mutationPreview(
    String toolId,
    Map<String, dynamic> arguments,
  ) async {
    final current = await _resolveSkill(arguments);
    if (current.isBuiltIn) {
      return 'Skill terbina dalam "${current.name}" dilindungi dan tindakan ini akan ditolak.';
    }
    if (toolId == 'skill_delete') {
      return 'AI mahu memadam skill "${current.name}".\n\n'
          'Maklumat yang akan dibuang:\n'
          '• Penerangan: ${_previewText(current.description)}\n'
          '• Arahan: ${current.instructions.length} aksara\n'
          '• Tools: ${current.toolIds.isEmpty ? 'automatik' : current.toolIds.join(', ')}\n\n'
          'Selepas diluluskan, skill ini tidak lagi tersedia kepada model.';
    }
    final updated = _updatedSkill(current, arguments);
    await _ensureUniqueName(updated.name, excludeId: current.id);
    final changes = <String>[];
    if (current.name != updated.name) {
      changes.add('• Nama: "${current.name}" → "${updated.name}"');
    }
    if (current.description != updated.description) {
      changes.add(
        '• Penerangan:\n  Sebelum: ${_previewText(current.description)}\n'
        '  Selepas: ${_previewText(updated.description)}',
      );
    }
    if (current.instructions != updated.instructions) {
      changes.add(
        '• Arahan: ${current.instructions.length} → '
        '${updated.instructions.length} aksara\n'
        '  Sebelum: ${_previewText(current.instructions)}\n'
        '  Selepas: ${_previewText(updated.instructions)}',
      );
    }
    if (!_sameStringList(current.toolIds, updated.toolIds)) {
      changes.add(
        '• Tools: ${current.toolIds.isEmpty ? 'automatik' : current.toolIds.join(', ')} '
        '→ ${updated.toolIds.isEmpty ? 'automatik' : updated.toolIds.join(', ')}',
      );
    }
    if (current.enabled != updated.enabled) {
      changes.add(
        '• Status: ${current.enabled ? 'aktif' : 'mati'} → '
        '${updated.enabled ? 'aktif' : 'mati'}',
      );
    }
    return 'AI mahu mengemas kini skill "${current.name}".\n\n'
        'Perbezaan yang dicadangkan:\n${changes.join('\n')}';
  }

  Future<SkillDefinition> _resolveSkill(
    Map<String, dynamic> arguments,
  ) async {
    final id = arguments['id']?.toString().trim() ?? '';
    final name = arguments['name']?.toString().trim() ?? '';
    if (id.isEmpty && name.isEmpty) {
      throw const FormatException('Berikan id atau name skill sedia ada.');
    }
    final normalizedName = _normalizedSkillName(name);
    final matches = (await loadSkills()).where((skill) {
      return (id.isNotEmpty && skill.id == id) ||
          (name.isNotEmpty &&
              _normalizedSkillName(skill.name) == normalizedName);
    }).toList(growable: false);
    if (matches.isEmpty) {
      throw StateError('Skill "${id.isNotEmpty ? id : name}" tidak ditemui.');
    }
    return matches.first;
  }

  SkillDefinition _updatedSkill(
    SkillDefinition current,
    Map<String, dynamic> arguments,
  ) {
    final requestedName = arguments['new_name']?.toString().trim();
    final requestedDescription = arguments['description']?.toString().trim();
    final requestedInstructions = arguments['instructions']?.toString().trim();
    final nextName = requestedName == null ? current.name : requestedName;
    final nextDescription = requestedDescription == null
        ? current.description
        : requestedDescription;
    final nextInstructions = requestedInstructions == null
        ? current.instructions
        : requestedInstructions;
    if (nextName.isEmpty || nextDescription.isEmpty || nextInstructions.isEmpty) {
      throw const FormatException(
        'Nama, penerangan dan arahan skill tidak boleh dikosongkan.',
      );
    }
    final nextTools = arguments.containsKey('tool_ids')
        ? (arguments['tool_ids'] as List? ?? const <dynamic>[])
            .map((item) => item.toString().trim())
            .where((item) => item.isNotEmpty)
            .toSet()
            .toList(growable: false)
        : current.toolIds;
    final updated = SkillDefinition(
      id: current.id,
      name: nextName,
      description: nextDescription,
      instructions: nextInstructions,
      triggers: current.triggers,
      toolIds: nextTools,
      enabled: arguments['enabled'] as bool? ?? current.enabled,
      sourcePath: current.sourcePath,
      isBuiltIn: false,
    );
    if (current.name == updated.name &&
        current.description == updated.description &&
        current.instructions == updated.instructions &&
        _sameStringList(current.toolIds, updated.toolIds) &&
        current.enabled == updated.enabled) {
      throw const FormatException('Tiada perubahan skill diberikan.');
    }
    return updated;
  }

  String _previewText(String value, {int limit = 220}) {
    final compact = value.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (compact.length <= limit) return compact;
    return '${compact.substring(0, limit)}…';
  }

  String _safeSkillId(String raw) {
    final normalized = raw
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9_-]+'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^[_-]+|[_-]+$'), '');
    if (normalized.isEmpty) return _uuid.v4();
    return normalized.length <= 80 ? normalized : normalized.substring(0, 80);
  }

  Future<String> prepareScriptSandbox(String skillId) async {
    final json = await database.getObject('skill', skillId);
    if (json == null) throw StateError('Skill $skillId tidak ditemui.');
    final skill = SkillDefinition.fromJson(json);
    if (skill.sourcePath.isEmpty) throw StateError('Skill ini tidak mempunyai folder skrip (skill arahan-sahaja). Guna terminal_start, bukan skill_run_script.');
    final source = Directory(skill.sourcePath);
    if (!await source.exists()) throw StateError('Folder skill tidak ditemui.');
    final appRoot = await getApplicationDocumentsDirectory();
    final allowedRoot = p.join(appRoot.path, 'skills');
    final normalizedSource = p.normalize(source.path);
    if (!p.isWithin(allowedRoot, normalizedSource)) throw const FileSystemException('Folder skill di luar sandbox aplikasi.');

    final supportRoot = await getApplicationSupportDirectory();
    final workspaceRoot = Directory(p.join(supportRoot.path, 'linux', 'workspace'));
    await workspaceRoot.create(recursive: true);
    final workspace = Directory(p.join(workspaceRoot.path, '.skill_runs', skillId));
    if (await workspace.exists()) await workspace.delete(recursive: true);
    await _copyDirectory(source, workspace);
    return p.relative(workspace.path, from: workspaceRoot.path);
  }

  Future<void> _copyDirectory(Directory source, Directory destination) async {
    await destination.create(recursive: true);
    await for (final entity in source.list(recursive: false, followLinks: false)) {
      final target = p.join(destination.path, p.basename(entity.path));
      if (entity is Directory) {
        await _copyDirectory(entity, Directory(target));
      } else if (entity is File) {
        await entity.copy(target);
      }
    }
  }

  Future<File?> _findManifest(Directory root) async {
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is File && p.basename(entity.path) == 'skill.json') {
        return entity;
      }
    }
    return null;
  }

  /// Cari SKILL.md / skill.md (format Agent Skills).
  Future<File?> _findSkillMarkdown(Directory root) async {
    File? fallback;
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is! File) continue;
      final base = p.basename(entity.path);
      if (base == 'SKILL.md') return entity; // utamakan exact case
      if (base.toLowerCase() == 'skill.md') fallback ??= entity;
    }
    return fallback;
  }

  /// Parse SKILL.md: YAML frontmatter (---) + badan markdown.
  Map<String, dynamic> _parseSkillMarkdown(String raw) {
    var name = '';
    var description = '';
    var id = '';
    final tools = <String>[];
    var body = raw.trim();

    if (body.startsWith('---')) {
      final end = body.indexOf('\n---', 3);
      if (end > 0) {
        final fm = body.substring(3, end).trim();
        body = body.substring(end + 4).trim();
        for (final line in fm.split('\n')) {
          final idx = line.indexOf(':');
          if (idx <= 0) continue;
          final key = line.substring(0, idx).trim().toLowerCase();
          var val = line.substring(idx + 1).trim();
          if ((val.startsWith('"') && val.endsWith('"')) ||
              (val.startsWith("'") && val.endsWith("'"))) {
            val = val.substring(1, val.length - 1);
          }
          switch (key) {
            case 'name':
            case 'title':
              name = val;
            case 'description':
            case 'desc':
              description = val;
            case 'id':
            case 'slug':
              id = val;
            case 'tools':
            case 'tool_ids':
              // name: [a, b] atau a, b
              final cleaned = val
                  .replaceAll('[', '')
                  .replaceAll(']', '')
                  .replaceAll('"', '')
                  .replaceAll("'", '');
              tools.addAll(
                cleaned
                    .split(RegExp(r'[, ]+'))
                    .map((s) => s.trim())
                    .where((s) => s.isNotEmpty),
              );
          }
        }
      }
    }

    // Tajuk markdown # ...
    if (name.isEmpty) {
      final heading = RegExp(r'^#\s+(.+)$', multiLine: true).firstMatch(body);
      if (heading != null) name = heading.group(1)!.trim();
    }
    if (name.isEmpty) name = 'Skill dari SKILL.md';
    if (description.isEmpty) {
      // Ayat pertama bukan heading
      for (final line in body.split('\n')) {
        final t = line.trim();
        if (t.isEmpty || t.startsWith('#')) continue;
        description = t.length > 160 ? '${t.substring(0, 160)}…' : t;
        break;
      }
    }
    if (description.isEmpty) {
      description = 'Skill diimport daripada SKILL.md';
    }

    return <String, dynamic>{
      'id': id,
      'name': name,
      'description': description,
      'instructions': body,
      'tools': tools,
    };
  }

  Future<void> save(SkillDefinition skill) async {
    await _ensureUniqueName(skill.name, excludeId: skill.id);
    await database.saveObject('skill', skill.id, skill.toJson());
  }

  Future<void> delete(SkillDefinition skill) async {
    await database.deleteObject('skill', skill.id);
    if (skill.sourcePath.isNotEmpty) {
      final directory = Directory(skill.sourcePath);
      if (await directory.exists()) await directory.delete(recursive: true);
    }
  }

  List<SkillDefinition> _builtInSkills() => const <SkillDefinition>[
        SkillDefinition(
          id: 'skill_creator',
          name: 'Skill Creator',
          description:
              'Membina skill local baharu berdasarkan tujuan dan aliran kerja yang diperlukan.',
          instructions:
              'Apabila satu aliran kerja berulang memerlukan skill khusus, gunakan tool skill_create. '
              'LARANGAN KERAS: nama skill mesti unik; jangan cipta salinan atau menukar nama '
              'secara automatik apabila nama sudah digunakan. Untuk ubah maklumat gunakan '
              'skill_update, dan untuk padam gunakan skill_delete; kedua-duanya akan menunggu '
              'pengesahan pengguna. Tulis tujuan, arahan langkah demi langkah dan tools yang '
              'benar-benar diperlukan. Tiada trigger manual; model menentukan masa penggunaan '
              'berdasarkan nama, penerangan dan arahan skill.',
          toolIds: <String>[
            'skill_create',
            'skill_update',
            'skill_delete',
            'file_write',
            'file_read',
          ],
          isBuiltIn: true,
        ),
        SkillDefinition(
          id: 'web_research',
          name: 'Web Research',
          description:
              'Mencari beberapa sumber, membaca halaman sebenar dan menghasilkan ringkasan bersumber.',
          instructions:
              'Gunakan web_search dahulu. Buka hasil penting dengan browser_open, baca kandungan sebenar dan bandingkan sumber sebelum membuat kesimpulan.',
          toolIds: <String>[
            'web_search',
            'browser_open',
            'browser_read',
            'browser_click',
          ],
          isBuiltIn: true,
        ),
        SkillDefinition(
          id: 'document_writer',
          name: 'Document Writer',
          description:
              'Menyediakan teks tersusun dan menyimpan hasil ke fail tempatan.',
          instructions:
              'Susun kandungan dengan tajuk yang jelas. Gunakan file_write hanya selepas kandungan siap.',
          toolIds: <String>['file_write', 'file_read', 'file_list'],
          isBuiltIn: true,
        ),
        SkillDefinition(
          id: 'local_memory',
          name: 'Local Memory',
          description:
              'Mencari dan menyimpan fakta pengguna dalam pangkalan data tempatan.',
          instructions:
              'Gunakan memory_search sebelum menganggap fakta peribadi. Simpan apabila pengguna meminta atau fakta jelas berguna.',
          toolIds: <String>['memory_search', 'memory_add', 'memory_delete'],
          isBuiltIn: true,
        ),
        SkillDefinition(
          id: 'sandbox_automation',
          name: 'Sandbox Automation',
          description:
              'Menjalankan skrip skill dan terminal di workspace sandbox aplikasi.',
          instructions:
              'Gunakan skill_run_script untuk skrip pakej skill atau terminal_start untuk arahan workspace. Pantau stdout, stderr dan status dengan terminal_poll.',
          toolIds: <String>[
            'skill_run_script',
            'terminal_start',
            'terminal_poll',
            'terminal_stop',
          ],
          isBuiltIn: true,
        ),
      ];

  void dispose() => _client.close();
}
