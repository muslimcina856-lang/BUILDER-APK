import 'dart:async';

import 'package:uuid/uuid.dart';

import '../models/app_models.dart';
import 'local_database.dart';

class PermissionManager {
  PermissionManager(
    this.database, {
    this.backgroundAllowedTools = const <String>{},
    this.backgroundMode = false,
  });

  final LocalDatabase database;
  final Set<String> backgroundAllowedTools;
  final bool backgroundMode;
  static const _uuid = Uuid();
  static const Set<String> alwaysConfirmTools = <String>{
    'skill_update',
    'skill_delete',
  };

  final List<PermissionRule> _rules = <PermissionRule>[];
  PermissionRequest? _pending;
  Completer<PermissionDecision>? _completer;
  bool _allowAllRiskyForSession = false;
  void Function()? onChanged;

  PermissionRequest? get pending => _pending;
  List<PermissionRule> get rules => List<PermissionRule>.unmodifiable(_rules);
  bool get allowAllRiskyForSession => _allowAllRiskyForSession;

  Future<void> initialize() async {
    _rules
      ..clear()
      ..addAll((await database.listObjects('permission_rule')).map(PermissionRule.fromJson));
    onChanged?.call();
  }

  PermissionPolicy policyFor(String toolId, String scope) {
    PermissionRule? exact;
    PermissionRule? toolWide;
    PermissionRule? scopeWide;
    PermissionRule? global;
    for (final rule in _rules) {
      if (rule.toolId == toolId && rule.scope == scope) exact = rule;
      if (rule.toolId == toolId && rule.scope == '*') toolWide = rule;
      if (rule.toolId == '*' && rule.scope == scope) scopeWide = rule;
      if (rule.toolId == '*' && rule.scope == '*') global = rule;
    }
    return (exact ?? toolWide ?? scopeWide ?? global)?.policy ?? PermissionPolicy.ask;
  }

  bool isAlwaysAllowed(String toolId, {String scope = '*'}) =>
      policyFor(toolId, scope) == PermissionPolicy.alwaysAllow;

  Future<PermissionDecision> request({
    required ToolDefinition tool,
    required String scope,
    required String description,
  }) async {
    // Dasar aplikasi: semua tool lain dibenarkan automatik. Mutasi skill ini
    // sengaja tidak menghormati pilihan sesi/sentiasa supaya kad muncul setiap
    // kali dan AI benar-benar menunggu keputusan pengguna.
    if (!alwaysConfirmTools.contains(tool.id)) {
      return PermissionDecision.allowAlways;
    }

    if (_pending != null) return PermissionDecision.deny;
    _pending = PermissionRequest(
      id: _uuid.v4(),
      tool: tool,
      scope: scope,
      description: description,
      risk: tool.risk,
    );
    _completer = Completer<PermissionDecision>();
    onChanged?.call();

    final decision = await _completer!.future;
    _pending = null;
    _completer = null;
    onChanged?.call();
    return decision;
  }

  void resolve(PermissionDecision decision) {
    final completer = _completer;
    if (completer != null && !completer.isCompleted) completer.complete(decision);
  }

  Future<void> setPolicy(
    String toolId, {
    String scope = '*',
    required PermissionPolicy policy,
  }) async {
    final id = '$toolId::$scope';
    _rules.removeWhere((rule) => rule.id == id);
    if (policy == PermissionPolicy.ask) {
      await database.deleteObject('permission_rule', id);
    } else {
      final rule = PermissionRule(
        id: id,
        toolId: toolId,
        scope: scope,
        policy: policy,
        updatedAt: DateTime.now(),
      );
      _rules.add(rule);
      await database.saveObject('permission_rule', id, rule.toJson());
    }
    onChanged?.call();
  }

  Future<void> revoke(String ruleId) async {
    _rules.removeWhere((rule) => rule.id == ruleId);
    await database.deleteObject('permission_rule', ruleId);
    onChanged?.call();
  }


  void grantSessionAllRisky() {
    _allowAllRiskyForSession = true;
    onChanged?.call();
  }

  void clearSessionPermissions() {
    _allowAllRiskyForSession = false;
    cancelPending();
    onChanged?.call();
  }

  void cancelPending() {
    if (_completer != null && !_completer!.isCompleted) {
      _completer!.complete(PermissionDecision.deny);
    }
    _pending = null;
    _completer = null;
    onChanged?.call();
  }
}
