import 'package:flutter/material.dart';

import '../app.dart';
import '../config/app_config.dart';
import '../models/app_models.dart';
import '../state/app_state.dart';
import '../theme/app_theme.dart';
import 'screens/automations_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/linux_workspace_screen.dart';
import 'screens/more_screen.dart';
import 'screens/providers_screen.dart';
import 'screens/skills_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  String? _showingPermissionId;

  List<Widget> get _pages => AppConfig.isFullEdition
      ? const <Widget>[
          ChatScreen(),
          ProvidersScreen(),
          LinuxWorkspaceScreen(),
          AutomationsScreen(),
          MoreScreen(),
        ]
      : const <Widget>[
          ChatScreen(),
          ProvidersScreen(),
          AutomationsScreen(),
          SkillsScreen(),
          MoreScreen(),
        ];

  List<NavigationDestination> get _destinations => AppConfig.isFullEdition
      ? const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline_rounded),
            selectedIcon: Icon(Icons.chat_bubble_rounded),
            label: 'Chat',
          ),
          NavigationDestination(
            icon: Icon(Icons.key_outlined),
            selectedIcon: Icon(Icons.key_rounded),
            label: 'Provider',
          ),
          NavigationDestination(
            icon: Icon(Icons.desktop_windows_outlined),
            selectedIcon: Icon(Icons.desktop_windows_rounded),
            label: 'Workspace',
          ),
          NavigationDestination(
            icon: Icon(Icons.schedule_outlined),
            selectedIcon: Icon(Icons.schedule_rounded),
            label: 'Automasi',
          ),
          NavigationDestination(
            icon: Icon(Icons.grid_view_outlined),
            selectedIcon: Icon(Icons.grid_view_rounded),
            label: 'Lagi',
          ),
        ]
      : const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline_rounded),
            selectedIcon: Icon(Icons.chat_bubble_rounded),
            label: 'Chat',
          ),
          NavigationDestination(
            icon: Icon(Icons.key_outlined),
            selectedIcon: Icon(Icons.key_rounded),
            label: 'Provider',
          ),
          NavigationDestination(
            icon: Icon(Icons.schedule_outlined),
            selectedIcon: Icon(Icons.schedule_rounded),
            label: 'Automasi',
          ),
          NavigationDestination(
            icon: Icon(Icons.auto_awesome_outlined),
            selectedIcon: Icon(Icons.auto_awesome_rounded),
            label: 'Skills',
          ),
          NavigationDestination(
            icon: Icon(Icons.grid_view_outlined),
            selectedIcon: Icon(Icons.grid_view_rounded),
            label: 'Lagi',
          ),
        ];

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    _schedulePermissionDialog(state.pendingPermission, state);
    final selected = state.selectedTab.clamp(0, _pages.length - 1).toInt();

    return Scaffold(
      body: IndexedStack(index: selected, children: _pages),
      bottomNavigationBar: DecoratedBox(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppTheme.outlineSoft)),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: Color(0x66000000),
              blurRadius: 28,
              offset: Offset(0, -8),
            ),
          ],
        ),
        child: NavigationBar(
          selectedIndex: selected,
          onDestinationSelected: state.selectTab,
          destinations: _destinations,
        ),
      ),
    );
  }

  void _schedulePermissionDialog(PermissionRequest? request, AppState state) {
    if (request == null || request.id == _showingPermissionId) return;
    _showingPermissionId = request.id;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final decision = await showModalBottomSheet<PermissionDecision>(
        context: context,
        isDismissible: false,
        enableDrag: false,
        isScrollControlled: true,
        useSafeArea: true,
        builder: (_) => _RiskApprovalSheet(request: request),
      );
      if (!mounted) return;
      state.resolvePermission(
        decision ?? PermissionDecision.deny,
      );
      _showingPermissionId = null;
    });
  }
}

class _RiskApprovalSheet extends StatelessWidget {
  const _RiskApprovalSheet({required this.request});

  final PermissionRequest request;

  @override
  Widget build(BuildContext context) {
    final isSkillMutation = request.tool.id == 'skill_update' ||
        request.tool.id == 'skill_delete';
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        4,
        20,
        20 + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: <Color>[
                        Color(0x33FFC86B),
                        Color(0x22FF718A),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0x55FFC86B)),
                  ),
                  child: Icon(
                    isSkillMutation
                        ? Icons.extension_rounded
                        : Icons.warning_amber_rounded,
                    color: isSkillMutation
                        ? AppTheme.purpleLight
                        : AppTheme.warning,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        isSkillMutation
                            ? 'Sahkan perubahan skill'
                            : 'Sahkan tindakan berisiko',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        request.tool.name,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.surfaceHigh,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.outline),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(request.description),
                  const SizedBox(height: 12),
                  Row(
                    children: <Widget>[
                      const Icon(
                        Icons.tune_rounded,
                        size: 16,
                        color: AppTheme.textMuted,
                      ),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Text(
                          request.scope,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Text(
              isSkillMutation
                  ? 'AI sedang menunggu jawapan anda. Kad ini akan muncul setiap kali AI mahu mengemas kini atau memadam skill.'
                  : 'Dialog ini hanya muncul untuk pemadaman, penimpaan atau operasi destruktif yang dikesan. Pilihan “Sentiasa” disimpan pada peranti dan boleh ditarik balik dalam Tetapan.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 20),
            if (isSkillMutation)
              Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(
                        context,
                        PermissionDecision.deny,
                      ),
                      child: const Text('Batal'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => Navigator.pop(
                        context,
                        PermissionDecision.allowOnce,
                      ),
                      child: const Text('Benarkan'),
                    ),
                  ),
                ],
              )
            else ...<Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(
                        context,
                        PermissionDecision.deny,
                      ),
                      child: const Text('Tolak'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(
                        context,
                        PermissionDecision.allowOnce,
                      ),
                      child: const Text('Sekali'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(
                        context,
                        PermissionDecision.allowSession,
                      ),
                      child: const Text('Sesi ini'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => Navigator.pop(
                        context,
                        PermissionDecision.allowAlways,
                      ),
                      child: const Text('Sentiasa'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
