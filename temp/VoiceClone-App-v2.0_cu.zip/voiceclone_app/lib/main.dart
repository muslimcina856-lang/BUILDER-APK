import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/constants/app_strings.dart';
import 'core/theme/app_theme.dart';
import 'features/voice_profile/presentation/bloc/settings_bloc.dart';
import 'features/voice_profile/presentation/bloc/voice_profile_bloc.dart';
import 'features/voice_profile/presentation/bloc/tts_extra_bloc.dart';
import 'features/voice_profile/presentation/pages/splash_page.dart';

void main() {
  runApp(const VoiceCloneApp());
}

class VoiceCloneApp extends StatelessWidget {
  const VoiceCloneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<SettingsBloc>(
          create: (_) => SettingsBloc()..add(LoadSettings()),
        ),
        BlocProvider<VoiceProfileBloc>(
          create: (_) => VoiceProfileBloc(),
        ),
        BlocProvider<TtsExtraBloc>(
          create: (_) => TtsExtraBloc(),
        ),
      ],
      child: MaterialApp(
        title: AppStrings.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme(),
        home: const SplashPage(),
      ),
    );
  }
}
