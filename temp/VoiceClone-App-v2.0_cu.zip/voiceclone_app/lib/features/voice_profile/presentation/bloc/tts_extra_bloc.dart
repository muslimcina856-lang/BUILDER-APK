import 'dart:io';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../../../../core/utils/api_config.dart';
import '../../../../core/utils/mimo_voiceclone_client.dart';
import '../../../../core/utils/secure_config_store.dart';
import '../../../../services/database_service.dart';
import '../../domain/entities/voice_profile.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class TtsExtraEvent extends Equatable {
  const TtsExtraEvent();
  @override
  List<Object?> get props => [];
}

class LoadTtsExtraResults extends TtsExtraEvent {}

/// Menjana pertuturan (atau sekadar preview ringkas) menggunakan satu
/// suara siap-sedia (preset voice).
class GeneratePresetVoice extends TtsExtraEvent {
  final String voiceId;
  final String text;
  final String styleInstruction;

  /// `true` jika ini panggilan preview cepat (teks pendek automatik),
  /// bukan penjanaan penuh yang disimpan sebagai hasil kekal.
  final bool isPreview;

  const GeneratePresetVoice({
    required this.voiceId,
    required this.text,
    this.styleInstruction = '',
    this.isPreview = false,
  });

  @override
  List<Object?> get props => [voiceId, text, styleInstruction, isPreview];
}

class DeletePresetVoiceResult extends TtsExtraEvent {
  final String resultId;
  final String outputFilePath;
  const DeletePresetVoiceResult({required this.resultId, required this.outputFilePath});
  @override
  List<Object?> get props => [resultId, outputFilePath];
}

/// Menjana suara baharu daripada penerangan teks (voice design).
class GenerateVoiceDesign extends TtsExtraEvent {
  final String voiceDescription;
  final String text;
  final bool optimizeTextPreview;

  const GenerateVoiceDesign({
    required this.voiceDescription,
    required this.text,
    this.optimizeTextPreview = false,
  });

  @override
  List<Object?> get props => [voiceDescription, text, optimizeTextPreview];
}

class DeleteVoiceDesignResult extends TtsExtraEvent {
  final String resultId;
  final String outputFilePath;
  const DeleteVoiceDesignResult({required this.resultId, required this.outputFilePath});
  @override
  List<Object?> get props => [resultId, outputFilePath];
}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class TtsExtraState extends Equatable {
  const TtsExtraState();
  @override
  List<Object?> get props => [];
}

class TtsExtraInitial extends TtsExtraState {}

class TtsExtraLoaded extends TtsExtraState {
  final List<VoiceCloneResult> presetResults;
  final List<VoiceDesignResult> designResults;
  final bool isGeneratingPreset;
  final bool isGeneratingDesign;

  /// ID suara siap-sedia yang sedang dijana pratontonnya (untuk indikator
  /// loading khusus butang preview yang sedang ditekan).
  final String? previewingVoiceId;

  const TtsExtraLoaded({
    required this.presetResults,
    required this.designResults,
    this.isGeneratingPreset = false,
    this.isGeneratingDesign = false,
    this.previewingVoiceId,
  });

  TtsExtraLoaded copyWith({
    List<VoiceCloneResult>? presetResults,
    List<VoiceDesignResult>? designResults,
    bool? isGeneratingPreset,
    bool? isGeneratingDesign,
    String? previewingVoiceId,
    bool clearPreviewingVoiceId = false,
  }) {
    return TtsExtraLoaded(
      presetResults: presetResults ?? this.presetResults,
      designResults: designResults ?? this.designResults,
      isGeneratingPreset: isGeneratingPreset ?? this.isGeneratingPreset,
      isGeneratingDesign: isGeneratingDesign ?? this.isGeneratingDesign,
      previewingVoiceId:
          clearPreviewingVoiceId ? null : (previewingVoiceId ?? this.previewingVoiceId),
    );
  }

  @override
  List<Object?> get props =>
      [presetResults, designResults, isGeneratingPreset, isGeneratingDesign, previewingVoiceId];
}

class TtsExtraError extends TtsExtraState {
  final String message;
  const TtsExtraError(this.message);
  @override
  List<Object?> get props => [message];
}

/// Dipancarkan sebaik penjanaan preview berjaya, membawa laluan fail
/// sementara untuk dimainkan segera oleh UI tanpa perlu menunggu senarai
/// reload (preview tidak disimpan sebagai hasil kekal).
class PresetVoicePreviewReady extends TtsExtraState {
  final String voiceId;
  final String outputFilePath;
  const PresetVoicePreviewReady({required this.voiceId, required this.outputFilePath});
  @override
  List<Object?> get props => [voiceId, outputFilePath];
}

class PresetVoiceGenerated extends TtsExtraState {
  final VoiceCloneResult result;
  const PresetVoiceGenerated(this.result);
  @override
  List<Object?> get props => [result];
}

class VoiceDesignGenerated extends TtsExtraState {
  final VoiceDesignResult result;
  const VoiceDesignGenerated(this.result);
  @override
  List<Object?> get props => [result];
}

// -----------------------------------------------------------------------------
// BLOC
// -----------------------------------------------------------------------------
class TtsExtraBloc extends Bloc<TtsExtraEvent, TtsExtraState> {
  final DatabaseService _dbService;
  final SecureConfigStore _configStore;
  final Uuid _uuid = const Uuid();

  TtsExtraBloc({
    DatabaseService? dbService,
    SecureConfigStore? configStore,
  })  : _dbService = dbService ?? DatabaseService(),
        _configStore = configStore ?? SecureConfigStore(),
        super(TtsExtraInitial()) {
    on<LoadTtsExtraResults>(_onLoadResults);
    on<GeneratePresetVoice>(_onGeneratePresetVoice);
    on<DeletePresetVoiceResult>(_onDeletePresetVoiceResult);
    on<GenerateVoiceDesign>(_onGenerateVoiceDesign);
    on<DeleteVoiceDesignResult>(_onDeleteVoiceDesignResult);
  }

  Future<void> _onLoadResults(
      LoadTtsExtraResults event, Emitter<TtsExtraState> emit) async {
    try {
      final List<VoiceCloneResult> presetResults = await _loadPresetResults();
      final List<VoiceDesignResult> designResults = await _loadDesignResults();
      emit(TtsExtraLoaded(presetResults: presetResults, designResults: designResults));
    } catch (e) {
      emit(TtsExtraError('Gagal memuatkan hasil: $e'));
    }
  }

  Future<List<VoiceCloneResult>> _loadPresetResults() async {
    final List<Map<String, dynamic>> rows = await _dbService.getAllPresetVoiceResults();
    return rows.map((row) {
      return VoiceCloneResult.fromJson({
        'id': row['id'],
        'voiceProfileId': row['voice_id'],
        'text': row['text'],
        'outputFilePath': row['output_file_path'],
        'createdAt': row['created_at'],
      });
    }).toList();
  }

  Future<List<VoiceDesignResult>> _loadDesignResults() async {
    final List<Map<String, dynamic>> rows = await _dbService.getAllVoiceDesignResults();
    return rows.map((row) => VoiceDesignResult.fromJson({
          'id': row['id'],
          'voiceDescription': row['voice_description'],
          'text': row['text'],
          'outputFilePath': row['output_file_path'],
          'createdAt': row['created_at'],
        })).toList();
  }

  Future<ApiConfig?> _requireConfig(Emitter<TtsExtraState> emit) async {
    final ApiConfig config = await _configStore.getConfig();
    if (!config.hasKey) {
      emit(const TtsExtraError(
        'Kunci API MiMo AI belum dimasukkan. Sila pergi ke Tetapan.',
      ));
      return null;
    }
    return config;
  }

  Future<String> _saveAudioToFile(List<int> audioBytes, String subfolder) async {
    final Directory appDir = await getApplicationDocumentsDirectory();
    final Directory outDir = Directory('${appDir.path}/$subfolder');
    if (!await outDir.exists()) {
      await outDir.create(recursive: true);
    }
    final String outputPath = '${outDir.path}/${_uuid.v4()}.wav';
    await File(outputPath).writeAsBytes(audioBytes);
    return outputPath;
  }

  Future<void> _onGeneratePresetVoice(
      GeneratePresetVoice event, Emitter<TtsExtraState> emit) async {
    final TtsExtraState currentState = state;
    final TtsExtraLoaded baseState = currentState is TtsExtraLoaded
        ? currentState
        : const TtsExtraLoaded(presetResults: [], designResults: []);

    if (event.isPreview) {
      emit(baseState.copyWith(previewingVoiceId: event.voiceId));
    } else {
      emit(baseState.copyWith(isGeneratingPreset: true));
    }

    final ApiConfig? config = await _requireConfig(emit);
    if (config == null) {
      emit(baseState.copyWith(isGeneratingPreset: false, clearPreviewingVoiceId: true));
      return;
    }

    final MimoVoiceCloneClient client = MimoVoiceCloneClient(
      apiKey: config.apiKey,
      baseUrl: config.baseUrl,
    );

    try {
      final List<int> audioBytes = await client.synthesizePresetVoice(
        text: event.text,
        voiceId: event.voiceId,
        styleInstruction: event.styleInstruction,
      );

      final String outputPath = await _saveAudioToFile(audioBytes, 'preset_voice_previews');

      if (event.isPreview) {
        // Preview tidak disimpan sebagai hasil kekal dalam pangkalan
        // data — hanya dimainkan sekali untuk membolehkan pengguna
        // mendengar suara sebelum memilihnya.
        emit(PresetVoicePreviewReady(voiceId: event.voiceId, outputFilePath: outputPath));
        emit(baseState.copyWith(clearPreviewingVoiceId: true));
        return;
      }

      final VoiceCloneResult result = VoiceCloneResult(
        id: _uuid.v4(),
        voiceProfileId: event.voiceId,
        text: event.text.trim(),
        outputFilePath: outputPath,
        createdAt: DateTime.now(),
      );

      await _dbService.savePresetVoiceResult({
        'id': result.id,
        'voice_id': result.voiceProfileId,
        'text': result.text,
        'output_file_path': result.outputFilePath,
        'created_at': result.createdAt.toIso8601String(),
      });

      emit(PresetVoiceGenerated(result));

      final List<VoiceCloneResult> presetResults = await _loadPresetResults();
      emit(baseState.copyWith(presetResults: presetResults, isGeneratingPreset: false));
    } on MimoVoiceCloneException catch (e) {
      emit(TtsExtraError(e.message));
      emit(baseState.copyWith(isGeneratingPreset: false, clearPreviewingVoiceId: true));
    } catch (e) {
      emit(TtsExtraError('Ralat menjana suara: $e'));
      emit(baseState.copyWith(isGeneratingPreset: false, clearPreviewingVoiceId: true));
    } finally {
      client.dispose();
    }
  }

  Future<void> _onDeletePresetVoiceResult(
      DeletePresetVoiceResult event, Emitter<TtsExtraState> emit) async {
    try {
      await _dbService.deletePresetVoiceResult(event.resultId);
      final File outputFile = File(event.outputFilePath);
      if (await outputFile.exists()) {
        await outputFile.delete();
      }
      add(LoadTtsExtraResults());
    } catch (e) {
      emit(TtsExtraError('Gagal memadam hasil: $e'));
      add(LoadTtsExtraResults());
    }
  }

  Future<void> _onGenerateVoiceDesign(
      GenerateVoiceDesign event, Emitter<TtsExtraState> emit) async {
    final TtsExtraState currentState = state;
    final TtsExtraLoaded baseState = currentState is TtsExtraLoaded
        ? currentState
        : const TtsExtraLoaded(presetResults: [], designResults: []);

    emit(baseState.copyWith(isGeneratingDesign: true));

    final ApiConfig? config = await _requireConfig(emit);
    if (config == null) {
      emit(baseState.copyWith(isGeneratingDesign: false));
      return;
    }

    final MimoVoiceCloneClient client = MimoVoiceCloneClient(
      apiKey: config.apiKey,
      baseUrl: config.baseUrl,
    );

    try {
      final List<int> audioBytes = await client.synthesizeVoiceDesign(
        voiceDescription: event.voiceDescription,
        text: event.text,
        optimizeTextPreview: event.optimizeTextPreview,
      );

      final String outputPath = await _saveAudioToFile(audioBytes, 'voice_design_outputs');

      final VoiceDesignResult result = VoiceDesignResult(
        id: _uuid.v4(),
        voiceDescription: event.voiceDescription.trim(),
        text: event.text.trim(),
        outputFilePath: outputPath,
        createdAt: DateTime.now(),
      );

      await _dbService.saveVoiceDesignResult({
        'id': result.id,
        'voice_description': result.voiceDescription,
        'text': result.text,
        'output_file_path': result.outputFilePath,
        'created_at': result.createdAt.toIso8601String(),
      });

      emit(VoiceDesignGenerated(result));

      final List<VoiceDesignResult> designResults = await _loadDesignResults();
      emit(baseState.copyWith(designResults: designResults, isGeneratingDesign: false));
    } on MimoVoiceCloneException catch (e) {
      emit(TtsExtraError(e.message));
      emit(baseState.copyWith(isGeneratingDesign: false));
    } catch (e) {
      emit(TtsExtraError('Ralat menjana suara: $e'));
      emit(baseState.copyWith(isGeneratingDesign: false));
    } finally {
      client.dispose();
    }
  }

  Future<void> _onDeleteVoiceDesignResult(
      DeleteVoiceDesignResult event, Emitter<TtsExtraState> emit) async {
    try {
      await _dbService.deleteVoiceDesignResult(event.resultId);
      final File outputFile = File(event.outputFilePath);
      if (await outputFile.exists()) {
        await outputFile.delete();
      }
      add(LoadTtsExtraResults());
    } catch (e) {
      emit(TtsExtraError('Gagal memadam hasil: $e'));
      add(LoadTtsExtraResults());
    }
  }
}
