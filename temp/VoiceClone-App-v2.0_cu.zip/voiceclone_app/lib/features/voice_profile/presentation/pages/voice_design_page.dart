import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/voice_profile.dart';
import '../bloc/tts_extra_bloc.dart';

/// Skrin Reka Suara: menjana suara sintetik baharu daripada penerangan
/// teks (cth "lelaki muda, garau dan bertenaga"), tanpa memerlukan
/// sebarang sampel audio.
///
/// PENTING: Setakat dokumentasi rasmi MiMo AI, penerangan suara hanya
/// difahami dalam Bahasa Cina atau English — bukan Bahasa Melayu.
class VoiceDesignPage extends StatefulWidget {
  const VoiceDesignPage({super.key});

  @override
  State<VoiceDesignPage> createState() => _VoiceDesignPageState();
}

class _VoiceDesignPageState extends State<VoiceDesignPage> {
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _textController = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();

  bool _optimizeTextPreview = false;
  bool _isPlaying = false;
  String? _currentlyPlayingPath;

  @override
  void initState() {
    super.initState();
    context.read<TtsExtraBloc>().add(LoadTtsExtraResults());

    _audioPlayer.playerStateStream.listen((playerState) {
      if (!mounted) return;
      setState(() {
        _isPlaying = playerState.playing && playerState.processingState != ProcessingState.completed;
      });
    });
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    _textController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _handleGenerate() {
    final String description = _descriptionController.text.trim();
    if (description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sila terangkan suara yang anda mahukan.')),
      );
      return;
    }

    final String text = _textController.text.trim();
    if (text.isEmpty && !_optimizeTextPreview) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Sila masukkan teks, atau aktifkan "Jana teks contoh automatik".'),
        ),
      );
      return;
    }

    context.read<TtsExtraBloc>().add(
          GenerateVoiceDesign(
            voiceDescription: description,
            text: text,
            optimizeTextPreview: _optimizeTextPreview,
          ),
        );
  }

  Future<void> _playAudio(String filePath) async {
    try {
      if (_currentlyPlayingPath == filePath && _isPlaying) {
        await _audioPlayer.pause();
        return;
      }
      if (_currentlyPlayingPath != filePath) {
        await _audioPlayer.setFilePath(filePath);
        _currentlyPlayingPath = filePath;
      }
      await _audioPlayer.play();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memainkan audio: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  void _confirmDeleteResult(VoiceDesignResult result) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Padam Hasil Ini?'),
          content: const Text('Fail audio yang dijana akan dipadam secara kekal.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Batal')),
            ElevatedButton(
              onPressed: () {
                context.read<TtsExtraBloc>().add(
                      DeleteVoiceDesignResult(
                        resultId: result.id,
                        outputFilePath: result.outputFilePath,
                      ),
                    );
                Navigator.pop(dialogContext);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Padam'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<TtsExtraBloc, TtsExtraState>(
      listener: (context, state) {
        if (state is TtsExtraError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.message), backgroundColor: AppColors.error),
          );
        } else if (state is VoiceDesignGenerated) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Suara baharu berjaya direka!'), backgroundColor: AppColors.success),
          );
        }
      },
      builder: (context, state) {
        List<VoiceDesignResult> results = [];
        bool isGenerating = false;

        if (state is TtsExtraLoaded) {
          results = state.designResults;
          isGenerating = state.isGeneratingDesign;
        }

        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.accent.withOpacity(0.25)),
              ),
              child: Text(
                'Nota: Penerangan suara hanya difahami dalam Bahasa Cina atau '
                'English setakat ini — bukan Bahasa Melayu.',
                style: GoogleFonts.inter(fontSize: 12, color: AppColors.textMuted, height: 1.4),
              ),
            ),
            TextField(
              controller: _descriptionController,
              maxLines: 3,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Penerangan Suara',
                hintText: 'cth: A young energetic male voice with a slight rasp...',
              ),
            ),
            const SizedBox(height: 16),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Jana teks contoh automatik', style: TextStyle(color: Colors.white, fontSize: 14)),
              subtitle: const Text(
                'Model akan mencipta ayat contoh sendiri berdasarkan penerangan suara',
                style: TextStyle(color: AppColors.textMuted, fontSize: 12),
              ),
              value: _optimizeTextPreview,
              activeColor: AppColors.accent,
              onChanged: (val) => setState(() => _optimizeTextPreview = val),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _textController,
              maxLines: 4,
              enabled: !_optimizeTextPreview,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Teks Untuk Disebut',
                hintText: _optimizeTextPreview
                    ? 'Tidak diperlukan — model akan menjana teks contoh'
                    : 'Taip ayat yang mahu disebut menggunakan suara baharu ini...',
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: isGenerating ? null : _handleGenerate,
                icon: isGenerating
                    ? const SizedBox(
                        width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Icon(Icons.auto_fix_high_rounded),
                label: Text(isGenerating ? 'Sedang Mereka Suara...' : 'Reka Suara'),
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
              ),
            ),
            if (results.isNotEmpty) ...[
              const SizedBox(height: 28),
              Text(
                'Hasil Terdahulu',
                style: GoogleFonts.inter(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
              ),
              const SizedBox(height: 12),
              ...results.map((result) => _buildResultCard(result)),
            ],
          ],
        );
      },
    );
  }

  Widget _buildResultCard(VoiceDesignResult result) {
    final bool isCurrentlyPlaying = _currentlyPlayingPath == result.outputFilePath && _isPlaying;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _playAudio(result.outputFilePath),
            child: Container(
              width: 40, height: 40,
              alignment: Alignment.center,
              decoration: const BoxDecoration(gradient: AppColors.accentGradient, shape: BoxShape.circle),
              child: Icon(
                isCurrentlyPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  result.voiceDescription,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: AppColors.accent, fontSize: 11, fontWeight: FontWeight.bold),
                ),
                Text(
                  result.text,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.textMuted, size: 20),
            onPressed: () => _confirmDeleteResult(result),
          ),
        ],
      ),
    );
  }
}
