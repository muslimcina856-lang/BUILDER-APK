import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/mimo_voiceclone_client.dart';
import '../../domain/entities/voice_profile.dart';
import '../bloc/tts_extra_bloc.dart';

/// Skrin Suara Siap-Sedia: senarai suara siap-sedia (built-in) MiMo AI
/// dengan pilihan mendengar pratonton (preview) setiap suara, dan
/// penjanaan pertuturan penuh menggunakan suara terpilih.
///
/// PENTING: Setakat dokumentasi rasmi MiMo AI, hanya suara Cina dan
/// English disokong — tiada suara Bahasa Melayu.
class PresetVoicePage extends StatefulWidget {
  const PresetVoicePage({super.key});

  @override
  State<PresetVoicePage> createState() => _PresetVoicePageState();
}

class _PresetVoicePageState extends State<PresetVoicePage> {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _styleController = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();

  String? _selectedVoiceId = kMimoPresetVoices.first.id;
  bool _isPlaying = false;
  String? _currentlyPlayingPath;

  @override
  void initState() {
    super.initState();
    context.read<TtsExtraBloc>().add(LoadTtsExtraResults());

    _audioPlayer.playerStateStream.listen((playerState) {
      if (!mounted) return;
      setState(() {
        _isPlaying = playerState.playing && playerState.processingState != ProcessingState.completed;
      });
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    _styleController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _handlePreview(String voiceId) {
    // Teks contoh pendek untuk pratonton pantas — sepadan dengan bahasa
    // suara berkenaan supaya sebutan kedengaran natural.
    final bool isEnglish = kMimoPresetVoices
        .firstWhere((v) => v.id == voiceId)
        .language ==
        'English';
    final String previewText = isEnglish
        ? 'Hi there, this is a quick preview of my voice.'
        : '你好，这是我的声音预览。';

    context.read<TtsExtraBloc>().add(
          GeneratePresetVoice(voiceId: voiceId, text: previewText, isPreview: true),
        );
  }

  void _handleGenerate() {
    final String text = _textController.text.trim();
    if (text.isEmpty || _selectedVoiceId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sila pilih suara dan masukkan teks yang mahu disebut.')),
      );
      return;
    }

    context.read<TtsExtraBloc>().add(
          GeneratePresetVoice(
            voiceId: _selectedVoiceId!,
            text: text,
            styleInstruction: _styleController.text.trim(),
          ),
        );
  }

  Future<void> _playAudio(String filePath) async {
    try {
      if (_currentlyPlayingPath == filePath && _isPlaying) {
        await _audioPlayer.pause();
        return;
      }
      if (_currentlyPlayingPath != filePath) {
        await _audioPlayer.setFilePath(filePath);
        _currentlyPlayingPath = filePath;
      }
      await _audioPlayer.play();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memainkan audio: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  void _confirmDeleteResult(VoiceCloneResult result) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Padam Hasil Ini?'),
          content: const Text('Fail audio yang dijana akan dipadam secara kekal.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Batal')),
            ElevatedButton(
              onPressed: () {
                context.read<TtsExtraBloc>().add(
                      DeletePresetVoiceResult(
                        resultId: result.id,
                        outputFilePath: result.outputFilePath,
                      ),
                    );
                Navigator.pop(dialogContext);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Padam'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<TtsExtraBloc, TtsExtraState>(
      listener: (context, state) {
        if (state is TtsExtraError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.message), backgroundColor: AppColors.error),
          );
        } else if (state is PresetVoicePreviewReady) {
          _playAudio(state.outputFilePath);
        } else if (state is PresetVoiceGenerated) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Suara berjaya dijana!'), backgroundColor: AppColors.success),
          );
        }
      },
      builder: (context, state) {
        List<VoiceCloneResult> results = [];
        bool isGenerating = false;
        String? previewingVoiceId;

        if (state is TtsExtraLoaded) {
          results = state.presetResults;
          isGenerating = state.isGeneratingPreset;
          previewingVoiceId = state.previewingVoiceId;
        }

        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.accent.withOpacity(0.25)),
              ),
              child: Text(
                'Nota: Suara siap-sedia MiMo AI setakat ini hanya menyokong '
                'Bahasa Cina dan English — belum ada suara Bahasa Melayu.',
                style: GoogleFonts.inter(fontSize: 12, color: AppColors.textMuted, height: 1.4),
              ),
            ),
            Text(
              'Pilih Suara',
              style: GoogleFonts.inter(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
            ),
            const SizedBox(height: 12),
            ...kMimoPresetVoices.map((voice) {
              final bool selected = _selectedVoiceId == voice.id;
              final bool isPreviewingThis = previewingVoiceId == voice.id;

              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: selected ? AppColors.accent.withOpacity(0.12) : AppColors.card,
                  borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                  border: Border.all(color: selected ? AppColors.accent : AppColors.cardBorder),
                ),
                child: ListTile(
                  onTap: () => setState(() => _selectedVoiceId = voice.id),
                  leading: Icon(
                    selected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                    color: selected ? AppColors.accent : AppColors.textMuted,
                  ),
                  title: Text(voice.displayName, style: const TextStyle(color: Colors.white)),
                  subtitle: Text(
                    '${voice.language} · ${voice.gender}',
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                  ),
                  trailing: IconButton(
                    icon: isPreviewingThis
                        ? const SizedBox(
                            width: 18, height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.play_circle_outline, color: AppColors.accent),
                    tooltip: 'Dengar pratonton',
                    onPressed: isPreviewingThis ? null : () => _handlePreview(voice.id),
                  ),
                ),
              );
            }),
            const SizedBox(height: 20),
            TextField(
              controller: _textController,
              maxLines: 4,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Teks Untuk Disebut',
                hintText: 'Taip ayat yang mahu disebut menggunakan suara terpilih...',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _styleController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Arahan Gaya (Pilihan)',
                hintText: 'cth: Sebut dengan nada gembira dan pantas...',
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: isGenerating ? null : _handleGenerate,
                icon: isGenerating
                    ? const SizedBox(
                        width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Icon(Icons.auto_awesome_rounded),
                label: Text(isGenerating ? 'Sedang Menjana...' : 'Jana Suara'),
                style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
              ),
            ),
            if (results.isNotEmpty) ...[
              const SizedBox(height: 28),
              Text(
                'Hasil Terdahulu',
                style: GoogleFonts.inter(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
              ),
              const SizedBox(height: 12),
              ...results.map((result) => _buildResultCard(result)),
            ],
          ],
        );
      },
    );
  }

  Widget _buildResultCard(VoiceCloneResult result) {
    final bool isCurrentlyPlaying = _currentlyPlayingPath == result.outputFilePath && _isPlaying;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _playAudio(result.outputFilePath),
            child: Container(
              width: 40, height: 40,
              alignment: Alignment.center,
              decoration: const BoxDecoration(gradient: AppColors.accentGradient, shape: BoxShape.circle),
              child: Icon(
                isCurrentlyPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  result.voiceProfileId,
                  style: const TextStyle(color: AppColors.accent, fontSize: 11, fontWeight: FontWeight.bold),
                ),
                Text(
                  result.text,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.textMuted, size: 20),
            onPressed: () => _confirmDeleteResult(result),
          ),
        ],
      ),
    );
  }
}
