import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Singleton SQLite database service untuk aplikasi Klon Suara.
///
/// Menguruskan jadual: voice_profiles, voice_clone_results,
/// preset_voice_results, voice_design_results.
class DatabaseService {
  static const int _dbVersion = 1;

  // Singleton
  DatabaseService._internal();
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;

  Database? _db;

  Future<Database> get database async {
    if (_db != null && _db!.isOpen) return _db!;
    _db = await _initDatabase();
    return _db!;
  }

  Future<Database> _initDatabase() async {
    final String dbPath = await getDatabasesPath();
    final String path = join(dbPath, 'voiceclone_app.db');

    return openDatabase(
      path,
      version: _dbVersion,
      onCreate: _onCreate,
      onConfigure: (Database db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    final Batch batch = db.batch();

    batch.execute('''
      CREATE TABLE voice_profiles (
        id            TEXT PRIMARY KEY,
        name          TEXT NOT NULL,
        audio_base64  TEXT NOT NULL,
        mime_type     TEXT NOT NULL,
        source        TEXT NOT NULL DEFAULT 'upload',
        created_at    TEXT NOT NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE voice_clone_results (
        id                TEXT PRIMARY KEY,
        voice_profile_id  TEXT NOT NULL,
        text              TEXT NOT NULL,
        output_file_path  TEXT NOT NULL,
        created_at        TEXT NOT NULL,
        FOREIGN KEY (voice_profile_id) REFERENCES voice_profiles(id) ON DELETE CASCADE
      )
    ''');

    batch.execute('''
      CREATE TABLE preset_voice_results (
        id                TEXT PRIMARY KEY,
        voice_id          TEXT NOT NULL,
        text              TEXT NOT NULL,
        output_file_path  TEXT NOT NULL,
        created_at        TEXT NOT NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE voice_design_results (
        id                 TEXT PRIMARY KEY,
        voice_description  TEXT NOT NULL,
        text               TEXT NOT NULL,
        output_file_path   TEXT NOT NULL,
        created_at         TEXT NOT NULL
      )
    ''');

    batch.execute(
        'CREATE INDEX idx_voice_results_profile ON voice_clone_results(voice_profile_id)');

    await batch.commit(noResult: true);
  }

  // ---------------------------------------------------------------------------
  // Voice Profiles – CRUD
  // ---------------------------------------------------------------------------

  Future<void> saveVoiceProfile(Map<String, dynamic> profileMap) async {
    final Database db = await database;
    await db.insert(
      'voice_profiles',
      profileMap,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getAllVoiceProfiles() async {
    final Database db = await database;
    return db.query('voice_profiles', orderBy: 'created_at DESC');
  }

  /// Memadam satu profil suara mengikut id. Turut memadam semua hasil
  /// penjanaan yang berkaitan (ON DELETE CASCADE).
  Future<int> deleteVoiceProfile(String id) async {
    final Database db = await database;
    return db.delete('voice_profiles', where: 'id = ?', whereArgs: <dynamic>[id]);
  }

  // ---------------------------------------------------------------------------
  // Voice Clone Results – CRUD
  // ---------------------------------------------------------------------------

  Future<void> saveVoiceCloneResult(Map<String, dynamic> resultMap) async {
    final Database db = await database;
    await db.insert(
      'voice_clone_results',
      resultMap,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getAllVoiceCloneResults() async {
    final Database db = await database;
    return db.query('voice_clone_results', orderBy: 'created_at DESC');
  }

  Future<int> deleteVoiceCloneResult(String id) async {
    final Database db = await database;
    return db.delete(
      'voice_clone_results',
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  // ---------------------------------------------------------------------------
  // Preset Voice Results – CRUD
  // ---------------------------------------------------------------------------

  Future<void> savePresetVoiceResult(Map<String, dynamic> resultMap) async {
    final Database db = await database;
    await db.insert(
      'preset_voice_results',
      resultMap,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getAllPresetVoiceResults() async {
    final Database db = await database;
    return db.query('preset_voice_results', orderBy: 'created_at DESC');
  }

  Future<int> deletePresetVoiceResult(String id) async {
    final Database db = await database;
    return db.delete(
      'preset_voice_results',
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  // ---------------------------------------------------------------------------
  // Voice Design Results – CRUD
  // ---------------------------------------------------------------------------

  Future<void> saveVoiceDesignResult(Map<String, dynamic> resultMap) async {
    final Database db = await database;
    await db.insert(
      'voice_design_results',
      resultMap,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getAllVoiceDesignResults() async {
    final Database db = await database;
    return db.query('voice_design_results', orderBy: 'created_at DESC');
  }

  Future<int> deleteVoiceDesignResult(String id) async {
    final Database db = await database;
    return db.delete(
      'voice_design_results',
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  /// Memadam semua data (digunakan oleh fungsi "Padam Semua Data").
  Future<void> clearAllData() async {
    final Database db = await database;
    await db.delete('voice_clone_results');
    await db.delete('voice_profiles');
    await db.delete('preset_voice_results');
    await db.delete('voice_design_results');
  }

  Future<void> close() async {
    final Database? db = _db;
    if (db != null && db.isOpen) {
      await db.close();
      _db = null;
    }
  }
}
