import 'dart:convert';

import 'package:dio/dio.dart';

/// Model ID rasmi untuk sintesis suara klon (voice cloning) MiMo AI.
///
/// Rujukan: https://mimo.mi.com/docs/en-US/quick-start/usage-guide/audio/speech-synthesis-v2.5
const String kMimoVoiceCloneModel = 'mimo-v2.5-tts-voiceclone';

/// Model ID untuk sintesis menggunakan suara siap-sedia (built-in voices).
const String kMimoPresetVoiceModel = 'mimo-v2.5-tts';

/// Model ID untuk reka bentuk suara baharu daripada penerangan teks.
const String kMimoVoiceDesignModel = 'mimo-v2.5-tts-voicedesign';

/// Satu suara siap-sedia (built-in voice) yang disokong secara rasmi
/// oleh model [kMimoPresetVoiceModel].
class MimoPresetVoice {
  final String id;
  final String displayName;
  final String language;
  final String gender;

  const MimoPresetVoice({
    required this.id,
    required this.displayName,
    required this.language,
    required this.gender,
  });
}

/// Senarai penuh suara siap-sedia (built-in voices) mengikut dokumentasi
/// rasmi MiMo AI (dikemas kini 10 Jun 2026).
///
/// PENTING: Tiada suara Bahasa Melayu disenaraikan secara rasmi setakat
/// dokumentasi ini — hanya Chinese dan English disokong. Rujukan:
/// https://mimo.mi.com/docs/en-US/quick-start/usage-guide/audio/speech-synthesis-v2.5
const List<MimoPresetVoice> kMimoPresetVoices = [
  MimoPresetVoice(id: '冰糖', displayName: '冰糖 (Bīng Táng)', language: 'Cina', gender: 'Perempuan'),
  MimoPresetVoice(id: '茉莉', displayName: '茉莉 (Mò Lì)', language: 'Cina', gender: 'Perempuan'),
  MimoPresetVoice(id: '苏打', displayName: '苏打 (Sū Dǎ)', language: 'Cina', gender: 'Lelaki'),
  MimoPresetVoice(id: '白桦', displayName: '白桦 (Bái Huà)', language: 'Cina', gender: 'Lelaki'),
  MimoPresetVoice(id: 'Mia', displayName: 'Mia', language: 'English', gender: 'Perempuan'),
  MimoPresetVoice(id: 'Chloe', displayName: 'Chloe', language: 'English', gender: 'Perempuan'),
  MimoPresetVoice(id: 'Milo', displayName: 'Milo', language: 'English', gender: 'Lelaki'),
  MimoPresetVoice(id: 'Dean', displayName: 'Dean', language: 'English', gender: 'Lelaki'),
];

/// Base URL lalai untuk kunci API pay-as-you-go (format `sk-xxxxx`).
///
/// PENTING: Kunci Token Plan (format `tp-xxxxx`) menggunakan Base URL
/// BERLAINAN yang disediakan pada halaman Token Plan pengguna sendiri —
/// ia TIDAK sama dengan Base URL lalai ini, dan kedua-dua jenis kunci
/// tidak boleh dicampur dengan Base URL yang salah. Ini disahkan
/// daripada dokumentasi rasmi: https://mimo.mi.com/docs/en-US/quick-start/faq/api-integration
const String kMimoDefaultBaseUrl = 'https://api.xiaomimimo.com/v1';

/// Client API untuk fungsi Text-to-Speech MiMo AI, merangkumi ketiga-tiga
/// model rasmi: Voice Clone ([synthesize]), Suara Siap-Sedia
/// ([synthesizePresetVoice]), dan Reka Suara ([synthesizeVoiceDesign]).
/// Dibina terus daripada dokumentasi rasmi Xiaomi MiMo untuk memastikan
/// setiap medan permintaan dan pengendalian ralat betul-betul tepat.
///
/// Ciri utama untuk mengurangkan isu "kunci API tidak digunakan":
/// - Base URL BOLEH DIKONFIGUR (bukan hardcode) — kunci Token Plan
///   (`tp-xxxxx`) memerlukan Base URL berlainan daripada kunci
///   pay-as-you-go (`sk-xxxxx`).
/// - Menghantar KEDUA-DUA header `api-key` DAN `Authorization: Bearer`
///   pada setiap permintaan — dokumentasi rasmi mengesahkan kedua-duanya
///   disokong, jadi menghantar kedua-duanya memaksimumkan keserasian
///   tanpa risiko satu header tidak dikenali oleh sesetengah endpoint.
/// - Mesej ralat diekstrak terus daripada badan respons pelayan, bukan
///   mesej generik yang tidak membantu.
class MimoVoiceCloneClient {
  final Dio _dio;
  final String _apiKey;
  final String _baseUrl;

  /// Mencipta client baharu.
  ///
  /// [apiKey] – Kunci API MiMo AI (format `sk-xxxxx` atau `tp-xxxxx`).
  /// [baseUrl] – Base URL API. Jika tidak dinyatakan, guna
  /// [kMimoDefaultBaseUrl] (sesuai untuk kunci `sk-xxxxx`). Untuk kunci
  /// `tp-xxxxx` (Token Plan), pengguna MESTI membekalkan Base URL yang
  /// disalin daripada halaman Token Plan mereka sendiri.
  MimoVoiceCloneClient({
    required String apiKey,
    String? baseUrl,
    Dio? dio,
  })  : _apiKey = apiKey.trim(),
        _baseUrl = (baseUrl == null || baseUrl.trim().isEmpty)
            ? kMimoDefaultBaseUrl
            : _normalizeBaseUrl(baseUrl.trim()),
        _dio = dio ??
            Dio(
              BaseOptions(
                connectTimeout: const Duration(seconds: 30),
                // Sintesis suara klon boleh ambil masa lebih lama
                // daripada panggilan chat biasa.
                receiveTimeout: const Duration(minutes: 3),
                headers: <String, dynamic>{
                  'Content-Type': 'application/json',
                },
              ),
            );

  /// Membuang sebarang `/` berlebihan di hujung Base URL supaya
  /// penggabungan laluan endpoint (`/chat/completions`) sentiasa betul
  /// tidak kira sama ada pengguna menaip Base URL dengan atau tanpa `/`
  /// di hujungnya.
  static String _normalizeBaseUrl(String url) {
    String normalized = url;
    while (normalized.endsWith('/')) {
      normalized = normalized.substring(0, normalized.length - 1);
    }
    return normalized;
  }

  /// Header authentication yang dihantar pada SETIAP permintaan.
  ///
  /// Menghantar kedua-dua `api-key` dan `Authorization: Bearer` secara
  /// serentak. Dokumentasi rasmi MiMo mengesahkan platform menerima
  /// sama ada satu daripada kedua-dua header ini; menghantar kedua-duanya
  /// tidak menyebabkan konflik dan memastikan permintaan tetap disahkan
  /// walaupun satu daripada header itu diabaikan oleh sesetengah endpoint
  /// atau versi platform.
  Map<String, dynamic> get _authHeaders => <String, dynamic>{
        'api-key': _apiKey,
        'Authorization': 'Bearer $_apiKey',
      };

  /// Menguji sama ada kunci API dan Base URL yang dibekalkan sah dan
  /// boleh disambung, dengan menghantar permintaan chat minimum
  /// menggunakan model teks ringan.
  ///
  /// Memulangkan [MimoTestResult] yang mengandungi status kejayaan dan,
  /// jika gagal, mesej ralat yang jelas untuk dipaparkan kepada pengguna.
  Future<MimoTestResult> testConnection() async {
    if (_apiKey.isEmpty) {
      return const MimoTestResult(
        success: false,
        message: 'Kunci API tidak boleh kosong.',
      );
    }

    try {
      final Response<Map<String, dynamic>> response =
          await _dio.post<Map<String, dynamic>>(
        '$_baseUrl/chat/completions',
        data: <String, dynamic>{
          'model': 'mimo-v2.5',
          'messages': <Map<String, String>>[
            <String, String>{'role': 'user', 'content': 'Hi'},
          ],
          'stream': false,
          'max_completion_tokens': 5,
        },
        options: Options(
          headers: _authHeaders,
          receiveTimeout: const Duration(seconds: 20),
        ),
      );

      if (response.statusCode == 200) {
        return const MimoTestResult(success: true, message: 'Kunci API sah.');
      }

      return MimoTestResult(
        success: false,
        message: 'Pelayan memulangkan status ${response.statusCode}.',
      );
    } on DioException catch (e) {
      return MimoTestResult(
        success: false,
        message: _mapDioErrorToMessage(e),
      );
    } catch (e) {
      return MimoTestResult(
        success: false,
        message: 'Ralat tidak dijangka: $e',
      );
    }
  }

  /// Menjana audio suara klon menggunakan model [kMimoVoiceCloneModel].
  ///
  /// [text] – Teks yang perlu disebut. Mengikut dokumentasi rasmi, teks
  /// ini WAJIB diletakkan pada `role: assistant` dan TIDAK BOLEH
  /// diletakkan pada `role: user`.
  /// [referenceAudioBase64] – Sampel audio rujukan (suara asal untuk
  /// diklon) sebagai base64 TULEN, tanpa sebarang prefix data URI.
  /// [referenceMimeType] – MIME type sampel audio rujukan. Nilai yang
  /// disokong secara rasmi: `audio/mpeg` (atau `audio/mp3`), `audio/wav`.
  /// [styleInstruction] – Arahan gaya pertuturan pilihan dalam bahasa
  /// natural (cth "sebut dengan nada gembira"), diletakkan pada
  /// `role: user` mengikut spesifikasi rasmi. Boleh dibiarkan kosong.
  /// [outputFormat] – Format audio output. `wav` digunakan untuk
  /// panggilan bukan-strim (non-streaming), yang mana kaedah ini
  /// sentiasa gunakan — streaming untuk model voiceclone belum
  /// disokong sepenuhnya oleh MiMo AI setakat dokumentasi terkini.
  ///
  /// Melontar [MimoVoiceCloneException] jika permintaan gagal, dengan
  /// mesej yang telah diekstrak daripada respons pelayan sebenar apabila
  /// boleh, bukan mesej generik.
  Future<List<int>> synthesize({
    required String text,
    required String referenceAudioBase64,
    required String referenceMimeType,
    String styleInstruction = '',
    String outputFormat = 'wav',
  }) async {
    if (_apiKey.isEmpty) {
      throw const MimoVoiceCloneException(
        'Kunci API MiMo AI tidak boleh kosong. Sila masukkan kunci API di Tetapan.',
      );
    }

    final String trimmedText = text.trim();
    if (trimmedText.isEmpty) {
      throw const MimoVoiceCloneException('Teks untuk disebut tidak boleh kosong.');
    }

    if (referenceAudioBase64.isEmpty) {
      throw const MimoVoiceCloneException(
        'Sampel audio rujukan tidak sah atau kosong.',
      );
    }

    // Format WAJIB mengikut dokumentasi rasmi:
    // data:{MIME_TYPE};base64,{BASE64_AUDIO}
    final String voiceDataUri =
        'data:$referenceMimeType;base64,$referenceAudioBase64';

    final Map<String, dynamic> payload = <String, dynamic>{
      'model': kMimoVoiceCloneModel,
      'messages': <Map<String, String>>[
        // role: user adalah PILIHAN — digunakan untuk arahan gaya
        // natural language, atau kosong jika tiada arahan khas.
        <String, String>{
          'role': 'user',
          'content': styleInstruction.trim(),
        },
        // role: assistant WAJIB mengandungi teks sebenar untuk disebut.
        // Teks TIDAK BOLEH diletakkan pada role: user mengikut
        // dokumentasi rasmi.
        <String, String>{
          'role': 'assistant',
          'content': trimmedText,
        },
      ],
      'audio': <String, String>{
        'format': outputFormat,
        'voice': voiceDataUri,
      },
    };

    return _postSynthesisRequest(payload);
  }

  /// Menjana pertuturan menggunakan salah satu suara siap-sedia
  /// (built-in voice) MiMo AI, mengikut model [kMimoPresetVoiceModel].
  ///
  /// [text] – Teks yang perlu disebut, diletakkan pada `role: assistant`.
  /// [voiceId] – ID suara siap-sedia (rujuk [kMimoPresetVoices]), cth
  /// `"Chloe"` atau `"冰糖"`.
  /// [styleInstruction] – Arahan gaya pertuturan pilihan (natural
  /// language), diletakkan pada `role: user`. Boleh dibiarkan kosong.
  /// [outputFormat] – Format audio output (`wav` lalai untuk panggilan
  /// bukan-strim).
  Future<List<int>> synthesizePresetVoice({
    required String text,
    required String voiceId,
    String styleInstruction = '',
    String outputFormat = 'wav',
  }) async {
    if (_apiKey.isEmpty) {
      throw const MimoVoiceCloneException(
        'Kunci API MiMo AI tidak boleh kosong. Sila masukkan kunci API di Tetapan.',
      );
    }

    final String trimmedText = text.trim();
    if (trimmedText.isEmpty) {
      throw const MimoVoiceCloneException('Teks untuk disebut tidak boleh kosong.');
    }

    final Map<String, dynamic> payload = <String, dynamic>{
      'model': kMimoPresetVoiceModel,
      'messages': <Map<String, String>>[
        <String, String>{
          'role': 'user',
          'content': styleInstruction.trim(),
        },
        <String, String>{
          'role': 'assistant',
          'content': trimmedText,
        },
      ],
      'audio': <String, String>{
        'format': outputFormat,
        'voice': voiceId,
      },
    };

    return _postSynthesisRequest(payload);
  }

  /// Menjana suara baharu daripada penerangan teks (voice design),
  /// mengikut model [kMimoVoiceDesignModel]. Tiada sampel audio
  /// diperlukan — model mencipta timbre baharu berdasarkan deskripsi.
  ///
  /// [voiceDescription] – Penerangan suara yang dikehendaki dalam bahasa
  /// natural (Cina atau English disokong secara rasmi), diletakkan pada
  /// `role: user`. cth "muda, lelaki, garau dan bertenaga".
  /// [text] – Teks yang perlu disebut menggunakan suara yang direka,
  /// diletakkan pada `role: assistant`. Jika [optimizeTextPreview]
  /// bernilai `true`, medan ini boleh dibiarkan kosong dan model akan
  /// menjana teks contoh yang sepadan dengan penerangan suara secara
  /// automatik.
  /// [optimizeTextPreview] – Jika `true`, membenarkan teks contoh
  /// dijana secara automatik oleh model apabila [text] kosong.
  /// [outputFormat] – Format audio output (`wav` lalai).
  Future<List<int>> synthesizeVoiceDesign({
    required String voiceDescription,
    String text = '',
    bool optimizeTextPreview = false,
    String outputFormat = 'wav',
  }) async {
    if (_apiKey.isEmpty) {
      throw const MimoVoiceCloneException(
        'Kunci API MiMo AI tidak boleh kosong. Sila masukkan kunci API di Tetapan.',
      );
    }

    final String trimmedDescription = voiceDescription.trim();
    if (trimmedDescription.isEmpty) {
      throw const MimoVoiceCloneException(
        'Penerangan suara tidak boleh kosong. Sila terangkan suara yang anda mahukan.',
      );
    }

    final String trimmedText = text.trim();
    if (trimmedText.isEmpty && !optimizeTextPreview) {
      throw const MimoVoiceCloneException(
        'Teks untuk disebut tidak boleh kosong, melainkan pilihan "Jana teks contoh automatik" diaktifkan.',
      );
    }

    final Map<String, dynamic> payload = <String, dynamic>{
      'model': kMimoVoiceDesignModel,
      'messages': <Map<String, String>>[
        <String, String>{
          'role': 'user',
          'content': trimmedDescription,
        },
        if (trimmedText.isNotEmpty)
          <String, String>{
            'role': 'assistant',
            'content': trimmedText,
          },
      ],
      'audio': <String, dynamic>{
        'format': outputFormat,
        'optimize_text_preview': optimizeTextPreview,
      },
    };

    return _postSynthesisRequest(payload);
  }

  /// Kaedah dalaman dikongsi untuk menghantar permintaan sintesis dan
  /// memproses respons, digunakan oleh [synthesizePresetVoice] dan
  /// [synthesizeVoiceDesign] untuk mengelakkan pertindanan kod.
  Future<List<int>> _postSynthesisRequest(Map<String, dynamic> payload) async {
    try {
      final Response<Map<String, dynamic>> response =
          await _dio.post<Map<String, dynamic>>(
        '$_baseUrl/chat/completions',
        data: payload,
        options: Options(headers: _authHeaders),
      );

      final Map<String, dynamic>? body = response.data;
      if (body == null) {
        throw const MimoVoiceCloneException(
          'Tiada data diterima daripada pelayan MiMo AI.',
        );
      }

      final List<dynamic>? choices = body['choices'] as List<dynamic>?;
      if (choices == null || choices.isEmpty) {
        throw const MimoVoiceCloneException(
          'Tiada audio dijana oleh model. Sila cuba semula.',
        );
      }

      final Map<String, dynamic> choice =
          choices.first as Map<String, dynamic>;
      final Map<String, dynamic>? message =
          choice['message'] as Map<String, dynamic>?;
      final Map<String, dynamic>? audio =
          message?['audio'] as Map<String, dynamic>?;
      final String? audioDataBase64 = audio?['data'] as String?;

      if (audioDataBase64 == null || audioDataBase64.isEmpty) {
        throw const MimoVoiceCloneException(
          'Respons pelayan tidak mengandungi data audio yang sah. '
          'Sila semak status akaun/kredit anda di Console MiMo AI.',
        );
      }

      return base64Decode(audioDataBase64);
    } on DioException catch (e) {
      throw MimoVoiceCloneException(_mapDioErrorToMessage(e));
    } on FormatException {
      throw const MimoVoiceCloneException(
        'Data audio yang diterima daripada pelayan tidak dapat dihuraikan (base64 tidak sah).',
      );
    }
  }

  /// Melepaskan sumber Dio.
  void dispose() {
    _dio.close(force: true);
  }

  /// Memetakan [DioException] kepada mesej ralat yang jelas dan berguna
  /// dalam Bahasa Melayu, mengekstrak mesej sebenar daripada badan
  /// respons pelayan apabila tersedia — bukan mesej generik "ralat
  /// tidak dijangka" yang tidak membantu pengguna mengenal pasti punca.
  String _mapDioErrorToMessage(DioException e) {
    final int? statusCode = e.response?.statusCode;
    final String? serverMessage = _extractServerErrorMessage(e.response?.data);

    switch (statusCode) {
      case 400:
        return serverMessage != null
            ? 'Permintaan tidak sah: $serverMessage'
            : 'Permintaan tidak sah (400). Sila semak format sampel audio anda.';
      case 401:
        return 'Kunci API tidak sah, telah tamat tempoh, atau Base URL yang '
            'digunakan tidak sepadan dengan jenis kunci anda. Jika kunci anda '
            'bermula dengan "tp-" (Token Plan), pastikan Base URL yang '
            'dimasukkan di Tetapan adalah Base URL daripada halaman Token '
            'Plan anda sendiri, BUKAN Base URL lalai.';
      case 402:
        return 'Kredit akaun MiMo AI telah habis.';
      case 403:
        return serverMessage != null
            ? 'Akses ditolak: $serverMessage'
            : 'Akses ditolak (403). Kunci API mungkin tidak mempunyai kebenaran untuk model klon suara.';
      case 404:
        return 'Endpoint atau model tidak dijumpai (404). Sila semak Base URL yang dimasukkan di Tetapan.';
      case 413:
        return 'Sampel audio terlalu besar (413). Saiz base64 tidak boleh melebihi 10MB — cuba guna sampel audio yang lebih pendek.';
      case 422:
        return serverMessage != null
            ? 'Data tidak sah: $serverMessage'
            : 'Data yang dihantar tidak sah (422). Sila semak format fail audio (.mp3 / .wav sahaja disokong).';
      case 429:
        return 'Had kadar API telah dicapai. Sila tunggu sebentar sebelum cuba lagi.';
      case 500:
        return 'Ralat pelayan MiMo AI (500). Sila cuba lagi kemudian.';
      case 502:
        return 'Pelayan MiMo AI tidak tersedia (502). Sila cuba lagi kemudian.';
      case 503:
        return 'Perkhidmatan MiMo AI sedang penyelenggaraan (503).';
      default:
        if (e.type == DioExceptionType.connectionTimeout ||
            e.type == DioExceptionType.sendTimeout ||
            e.type == DioExceptionType.receiveTimeout) {
          return 'Sambungan tamat masa. Sila semak sambungan internet anda dan cuba lagi.';
        }
        if (e.type == DioExceptionType.connectionError) {
          return 'Gagal menyambung ke pelayan. Sila semak sambungan internet anda '
              'dan pastikan Base URL di Tetapan adalah betul.';
        }
        if (serverMessage != null) {
          return 'Ralat daripada pelayan${statusCode != null ? ' ($statusCode)' : ''}: $serverMessage';
        }
        if (e.message != null && e.message!.isNotEmpty) {
          return 'Ralat rangkaian: ${e.message}';
        }
        return 'Ralat tidak dijangka${statusCode != null ? ' (kod $statusCode)' : ''}. '
            'Sila semak kunci API, Base URL, dan sambungan internet anda.';
    }
  }

  /// Cuba mengekstrak mesej ralat manusiawi daripada badan respons ralat
  /// API. Menyokong struktur biasa gaya OpenAI-compatible:
  /// `{"error": {"message": "..."}}`, `{"error": "..."}`, atau
  /// `{"message": "..."}`. Memulangkan `null` jika tiada struktur
  /// yang dikenali dijumpai.
  String? _extractServerErrorMessage(dynamic responseData) {
    if (responseData == null) return null;

    try {
      Map<String, dynamic>? data;

      if (responseData is Map<String, dynamic>) {
        data = responseData;
      } else if (responseData is String && responseData.trim().isNotEmpty) {
        final dynamic decoded = jsonDecode(responseData);
        if (decoded is Map<String, dynamic>) data = decoded;
      }

      if (data == null) return null;

      final dynamic errorField = data['error'];
      if (errorField is Map<String, dynamic>) {
        final String? msg = errorField['message'] as String?;
        if (msg != null && msg.isNotEmpty) return msg;
      } else if (errorField is String && errorField.isNotEmpty) {
        return errorField;
      }

      final String? topLevelMessage = data['message'] as String?;
      if (topLevelMessage != null && topLevelMessage.isNotEmpty) {
        return topLevelMessage;
      }
    } catch (_) {
      // Badan respons tidak dapat dihurai — abaikan dan kembalikan null.
    }

    return null;
  }
}

/// Hasil ujian sambungan kunci API.
class MimoTestResult {
  final bool success;
  final String message;
  const MimoTestResult({required this.success, required this.message});
}

/// Dilontar apabila sintesis suara klon MiMo AI gagal.
class MimoVoiceCloneException implements Exception {
  final String message;
  const MimoVoiceCloneException(this.message);
  @override
  String toString() => message;
}
