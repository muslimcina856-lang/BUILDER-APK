import 'dart:io';

import 'package:flutter/services.dart';

class NativePickedFile {
  const NativePickedFile({
    required this.path,
    required this.name,
    required this.size,
  });

  final String path;
  final String name;
  final int size;

  Future<List<int>> readAsBytes() => File(path).readAsBytes();
}

class NativeBridge {
  const NativeBridge._();

  static const MethodChannel _channel = MethodChannel(
    'com.earlxz.forgedeck/native',
  );

  static Future<NativePickedFile?> pickFile({bool zipOnly = false}) async {
    if (!Platform.isAndroid) {
      throw UnsupportedError('Pemilih fail native hanya tersedia pada Android.');
    }

    final result = await _channel.invokeMapMethod<String, dynamic>(
      'pickFile',
      <String, dynamic>{
        'mimeType': zipOnly ? 'application/zip' : '*/*',
      },
    );
    if (result == null) return null;

    final path = result['path'] as String?;
    final name = result['name'] as String?;
    final rawSize = result['size'];
    if (path == null || path.isEmpty || name == null || name.isEmpty) {
      throw const FormatException('Maklumat fail yang dipilih tidak lengkap.');
    }

    return NativePickedFile(
      path: path,
      name: name,
      size: rawSize is int ? rawSize : int.tryParse('$rawSize') ?? 0,
    );
  }

  static Future<Map<String, dynamic>> requestLegacyStoragePermission() async {
    if (!Platform.isAndroid) {
      return <String, dynamic>{
        'required': false,
        'granted': true,
        'permanentlyDenied': false,
      };
    }
    return await _channel.invokeMapMethod<String, dynamic>(
          'requestLegacyStoragePermission',
        ) ??
        <String, dynamic>{
          'required': false,
          'granted': true,
          'permanentlyDenied': false,
        };
  }

  static Future<void> openAppSettings() async {
    if (!Platform.isAndroid) return;
    await _channel.invokeMethod<void>('openAppSettings');
  }

  static Future<String?> secureRead(String key) {
    return _channel.invokeMethod<String>('secureRead', <String, dynamic>{
      'key': key,
    });
  }

  static Future<void> secureWrite(String key, String value) {
    return _channel.invokeMethod<void>('secureWrite', <String, dynamic>{
      'key': key,
      'value': value,
    });
  }

  static Future<void> secureDelete(String key) {
    return _channel.invokeMethod<void>('secureDelete', <String, dynamic>{
      'key': key,
    });
  }

  static Future<void> secureDeleteAll() {
    return _channel.invokeMethod<void>('secureDeleteAll');
  }
}
