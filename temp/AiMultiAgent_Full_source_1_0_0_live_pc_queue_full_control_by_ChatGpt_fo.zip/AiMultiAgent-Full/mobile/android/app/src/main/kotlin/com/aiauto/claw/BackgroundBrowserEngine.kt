package com.aiauto.claw

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

class BackgroundBrowserEngine(
    private val activity: Activity,
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    private var pendingResult: MethodChannel.Result? = null
    private var pendingDone = AtomicBoolean(false)
    private var timeoutRunnable: Runnable? = null
    private var desktopMode: Boolean = true

    fun handle(call: MethodCall, result: MethodChannel.Result) {
        activity.runOnUiThread {
            try {
                when (call.method) {
                    "open" -> open(
                        url = call.argument<String>("url").orEmpty(),
                        desktop = call.argument<Boolean>("desktopMode") ?: true,
                        result = result,
                    )
                    "read", "snapshot" -> snapshot(result)
                    "click" -> click(
                        selector = call.argument<String>("selector").orEmpty(),
                        text = call.argument<String>("text").orEmpty(),
                        result = result,
                    )
                    "fill" -> fill(
                        selector = call.argument<String>("selector").orEmpty(),
                        value = call.argument<String>("value").orEmpty(),
                        result = result,
                    )
                    "submit" -> submit(
                        selector = call.argument<String>("selector").orEmpty(),
                        result = result,
                    )
                    "back" -> navigate("back", result)
                    "forward" -> navigate("forward", result)
                    "reload" -> navigate("reload", result)
                    "clearCookies" -> clearCookies(result)
                    "clearSessionData" -> clearSessionData(result)
                    "cancel" -> cancelCurrent(result)
                    "screenshot" -> screenshot(result)
                    else -> result.notImplemented()
                }
            } catch (error: Throwable) {
                result.error("browser_error", error.message ?: error.javaClass.simpleName, null)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView(): WebView {
        val existing = webView
        if (existing != null) return existing

        val created = WebView(activity)
        created.setBackgroundColor(Color.TRANSPARENT)
        created.alpha = 0.01f
        created.translationX = -10000f
        created.translationY = -10000f
        created.layoutParams = ViewGroup.LayoutParams(1080, 1920)
        created.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = true
            blockNetworkImage = false
            allowContentAccess = false
            allowFileAccess = false
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = mobileUserAgent()
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                offscreenPreRaster = true
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                safeBrowsingEnabled = true
            }
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(created, true)
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                created,
                MUTE_MEDIA_SCRIPT,
                setOf("*"),
            )
        }
        created.webChromeClient = WebChromeClient()
        created.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                silenceMedia(view)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?,
            ): Boolean = false

            override fun onPageFinished(view: WebView, url: String) {
                silenceMedia(view)
                if (pendingResult != null) {
                    mainHandler.postDelayed({ snapshotPending() }, 450L)
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: android.webkit.WebResourceError,
            ) {
                if (request.isForMainFrame) {
                    finishError("load_error", error.description?.toString() ?: "Gagal memuat halaman")
                }
            }
        }
        val root = activity.window.decorView as? ViewGroup
        root?.addView(created)
        webView = created
        return created
    }

    private fun open(
        url: String,
        desktop: Boolean,
        result: MethodChannel.Result,
    ) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            result.error("invalid_url", "URL HTTP/HTTPS tidak sah.", null)
            return
        }
        desktopMode = desktop
        val view = ensureWebView()
        view.settings.userAgentString = if (desktopMode) desktopUserAgent() else mobileUserAgent()
        silenceMedia(view)
        beginPending(result, 120_000L)
        view.loadUrl(url)
    }

    private fun snapshot(result: MethodChannel.Result) {
        val view = ensureWebView()
        if (view.url.isNullOrBlank()) {
            result.error("empty_page", "Tiada halaman aktif dalam browser latar belakang.", null)
            return
        }
        beginPending(result, 60_000L)
        snapshotPending()
    }

    private fun click(selector: String, text: String, result: MethodChannel.Result) {
        val selectorJson = JSONObject.quote(selector)
        val textJson = JSONObject.quote(text)
        val script = """
            (() => {
              const selector = $selectorJson;
              const wanted = $textJson.trim().toLowerCase();
              let element = selector ? document.querySelector(selector) : null;
              if (!element && wanted) {
                const nodes = Array.from(document.querySelectorAll('a,button,input[type=button],input[type=submit],[role=button]'));
                element = nodes.find((node) => ((node.innerText || node.value || node.getAttribute('aria-label') || '').trim().toLowerCase()).includes(wanted));
              }
              if (!element) return JSON.stringify({success:false,error:'Elemen tidak ditemui'});
              element.scrollIntoView({block:'center',inline:'center'});
              element.click();
              return JSON.stringify({success:true,action:'click'});
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 700L)
    }

    private fun fill(selector: String, value: String, result: MethodChannel.Result) {
        if (selector.isBlank()) {
            result.error("missing_selector", "CSS selector diperlukan.", null)
            return
        }
        val selectorJson = JSONObject.quote(selector)
        val valueJson = JSONObject.quote(value)
        val script = """
            (() => {
              const element = document.querySelector($selectorJson);
              if (!element) return JSON.stringify({success:false,error:'Input tidak ditemui'});
              const value = $valueJson;
              const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
              const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
              if (descriptor && descriptor.set) descriptor.set.call(element, value); else element.value = value;
              element.dispatchEvent(new Event('input', {bubbles:true}));
              element.dispatchEvent(new Event('change', {bubbles:true}));
              return JSON.stringify({success:true,action:'fill'});
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 150L)
    }

    private fun submit(selector: String, result: MethodChannel.Result) {
        val selectorJson = JSONObject.quote(selector)
        val script = """
            (() => {
              const selector = $selectorJson;
              let form = selector ? document.querySelector(selector) : document.querySelector('form');
              if (form && form.tagName !== 'FORM') form = form.closest('form');
              if (!form) return JSON.stringify({success:false,error:'Borang tidak ditemui'});
              if (form.requestSubmit) form.requestSubmit(); else form.submit();
              return JSON.stringify({success:true,action:'submit'});
            })();
        """.trimIndent()
        evaluateAction(script, result, waitAfterMs = 900L)
    }

    private fun navigate(action: String, result: MethodChannel.Result) {
        val view = ensureWebView()
        beginPending(result, 60_000L)
        when (action) {
            "back" -> if (view.canGoBack()) view.goBack() else snapshotPending()
            "forward" -> if (view.canGoForward()) view.goForward() else snapshotPending()
            else -> view.reload()
        }
    }

    private fun clearCookies(result: MethodChannel.Result) {
        CookieManager.getInstance().removeAllCookies {
            CookieManager.getInstance().flush()
            result.success(mapOf("success" to true))
        }
    }

    private fun cancelCurrent(result: MethodChannel.Result) {
        try {
            webView?.stopLoading()
            if (pendingResult != null) {
                finishError("browser_cancelled", "Tindakan browser dihentikan pengguna.")
            }
            result.success(mapOf("success" to true))
        } catch (error: Throwable) {
            result.error("browser_cancel_error", error.message ?: error.javaClass.simpleName, null)
        }
    }

    private fun clearSessionData(result: MethodChannel.Result) {
        try {
            webView?.apply {
                stopLoading()
                loadUrl("about:blank")
                clearHistory()
                clearCache(true)
            }
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            val directory = File(activity.filesDir, "browser-captures")
            if (directory.exists()) {
                directory.listFiles()?.forEach { file ->
                    runCatching { file.delete() }
                }
            }
            result.success(mapOf("success" to true))
        } catch (error: Throwable) {
            result.error("browser_clear_error", error.message ?: error.javaClass.simpleName, null)
        }
    }

    private fun screenshot(result: MethodChannel.Result) {
        val view = ensureWebView()
        if (view.url.isNullOrBlank()) {
            result.error("empty_page", "Tiada halaman aktif untuk screenshot.", null)
            return
        }
        silenceMedia(view)
        view.evaluateJavascript(FULL_PAGE_SIZE_SCRIPT) { raw ->
            try {
                val dimensions = decodeJavascriptObject(raw)
                captureFullPageScreenshot(view, dimensions, result)
            } catch (error: Throwable) {
                result.error("screenshot_dimensions_error", error.message, null)
            }
        }
    }

    private fun captureFullPageScreenshot(
        view: WebView,
        dimensions: JSONObject,
        result: MethodChannel.Result,
    ) {
        val originalScrollX = view.scrollX
        val originalScrollY = view.scrollY
        val viewportWidth = max(1, view.width)
        val viewportHeight = max(1, view.height)
        val documentWidthCss = max(1, dimensions.optInt("width", viewportWidth))
        val documentHeightCss = max(1, dimensions.optInt("height", viewportHeight))
        val viewportWidthCss = max(
            1,
            dimensions.optInt("viewportWidth", documentWidthCss),
        )
        val heightFromWebView = max(
            viewportHeight,
            ceil(view.contentHeight.toDouble() * view.scale.toDouble()).toInt(),
        )
        val heightFromJavascript = max(
            viewportHeight,
            ceil(
                documentHeightCss.toDouble() * viewportWidth.toDouble() /
                    viewportWidthCss.toDouble(),
            ).toInt(),
        )
        val contentHeightPx = max(heightFromWebView, heightFromJavascript)
        val preferredWidth = 1080
        val maxOutputHeight = 16_000
        val maxOutputPixels = 16_000_000L

        var outputScale = min(1.0, preferredWidth.toDouble() / viewportWidth.toDouble())
        outputScale = min(
            outputScale,
            maxOutputHeight.toDouble() / contentHeightPx.toDouble(),
        )
        outputScale = min(
            outputScale,
            sqrt(
                maxOutputPixels.toDouble() /
                    (viewportWidth.toDouble() * contentHeightPx.toDouble()),
            ),
        )
        val outputWidth = max(1, (viewportWidth * outputScale).roundToInt())
        val outputHeight = max(1, (contentHeightPx * outputScale).roundToInt())

        val outputBitmap = try {
            Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
        } catch (error: Throwable) {
            result.error("screenshot_memory_error", error.message, null)
            return
        }
        val outputCanvas = Canvas(outputBitmap).apply { drawColor(Color.WHITE) }
        val scrollPositions = mutableListOf<Int>()
        var offset = 0
        while (offset < contentHeightPx) {
            scrollPositions.add(offset)
            if (offset + viewportHeight >= contentHeightPx) break
            offset = min(offset + viewportHeight, max(0, contentHeightPx - viewportHeight))
            if (scrollPositions.last() == offset) break
        }

        captureScreenshotTile(
            view = view,
            outputBitmap = outputBitmap,
            outputCanvas = outputCanvas,
            outputScale = outputScale,
            scrollPositions = scrollPositions,
            index = 0,
            originalScrollX = originalScrollX,
            originalScrollY = originalScrollY,
            documentWidthCss = documentWidthCss,
            documentHeightCss = documentHeightCss,
            result = result,
        )
    }

    private fun captureScreenshotTile(
        view: WebView,
        outputBitmap: Bitmap,
        outputCanvas: Canvas,
        outputScale: Double,
        scrollPositions: List<Int>,
        index: Int,
        originalScrollX: Int,
        originalScrollY: Int,
        documentWidthCss: Int,
        documentHeightCss: Int,
        result: MethodChannel.Result,
    ) {
        if (index >= scrollPositions.size) {
            finishFullPageScreenshot(
                view = view,
                bitmap = outputBitmap,
                originalScrollX = originalScrollX,
                originalScrollY = originalScrollY,
                documentWidthCss = documentWidthCss,
                documentHeightCss = documentHeightCss,
                result = result,
            )
            return
        }

        val scrollY = scrollPositions[index]
        view.scrollTo(0, scrollY)
        silenceMedia(view)
        mainHandler.postDelayed({
            try {
                val tileWidth = max(1, view.width)
                val tileHeight = max(1, view.height)
                val tile = Bitmap.createBitmap(
                    tileWidth,
                    tileHeight,
                    Bitmap.Config.ARGB_8888,
                )
                val tileCanvas = Canvas(tile).apply { drawColor(Color.WHITE) }
                view.draw(tileCanvas)

                val destinationTop = (scrollY * outputScale).roundToInt()
                    .coerceIn(0, outputBitmap.height)
                val destinationBottom = ((scrollY + tileHeight) * outputScale)
                    .roundToInt()
                    .coerceIn(destinationTop, outputBitmap.height)
                if (destinationBottom > destinationTop) {
                    val sourceHeight = min(
                        tileHeight,
                        ceil(
                            (destinationBottom - destinationTop).toDouble() /
                                outputScale,
                        ).toInt(),
                    )
                    outputCanvas.drawBitmap(
                        tile,
                        android.graphics.Rect(0, 0, tileWidth, sourceHeight),
                        android.graphics.Rect(
                            0,
                            destinationTop,
                            outputBitmap.width,
                            destinationBottom,
                        ),
                        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG),
                    )
                }
                tile.recycle()
                captureScreenshotTile(
                    view = view,
                    outputBitmap = outputBitmap,
                    outputCanvas = outputCanvas,
                    outputScale = outputScale,
                    scrollPositions = scrollPositions,
                    index = index + 1,
                    originalScrollX = originalScrollX,
                    originalScrollY = originalScrollY,
                    documentWidthCss = documentWidthCss,
                    documentHeightCss = documentHeightCss,
                    result = result,
                )
            } catch (error: Throwable) {
                outputBitmap.recycle()
                restoreBrowserViewport(view, originalScrollX, originalScrollY)
                result.error("screenshot_error", error.message, null)
            }
        }, 140L)
    }

    private fun finishFullPageScreenshot(
        view: WebView,
        bitmap: Bitmap,
        originalScrollX: Int,
        originalScrollY: Int,
        documentWidthCss: Int,
        documentHeightCss: Int,
        result: MethodChannel.Result,
    ) {
        try {
            val directory = File(activity.filesDir, "browser-captures")
            if (!directory.exists() && !directory.mkdirs()) {
                throw IllegalStateException("Folder screenshot tidak dapat dibuat.")
            }
            val file = File(directory, "web-${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                    throw IllegalStateException("Gagal mengekod screenshot browser.")
                }
            }
            result.success(
                mapOf(
                    "success" to true,
                    "path" to file.absolutePath,
                    "mime" to "image/png",
                    "width" to bitmap.width,
                    "height" to bitmap.height,
                    "documentWidth" to documentWidthCss,
                    "documentHeight" to documentHeightCss,
                    "fullPage" to true,
                    "scaled" to (
                        bitmap.width != view.width ||
                            bitmap.height != max(view.height, documentHeightCss)
                        ),
                    "url" to (view.url ?: ""),
                    "title" to view.title.orEmpty(),
                ),
            )
        } catch (error: Throwable) {
            result.error("screenshot_error", error.message, null)
        } finally {
            bitmap.recycle()
            restoreBrowserViewport(view, originalScrollX, originalScrollY)
        }
    }

    private fun restoreBrowserViewport(view: WebView, scrollX: Int, scrollY: Int) {
        view.scrollTo(scrollX, scrollY)
        silenceMedia(view)
    }

    private fun evaluateAction(
        script: String,
        result: MethodChannel.Result,
        waitAfterMs: Long,
    ) {
        val view = ensureWebView()
        view.evaluateJavascript(script) { raw ->
            try {
                val actionResult = decodeJavascriptObject(raw)
                if (actionResult.optBoolean("success", false)) {
                    beginPending(result, 60_000L)
                    mainHandler.postDelayed({ snapshotPending() }, waitAfterMs)
                } else {
                    result.success(jsonObjectToMap(actionResult))
                }
            } catch (error: Throwable) {
                result.error("javascript_error", error.message, null)
            }
        }
    }

    private fun beginPending(result: MethodChannel.Result, timeoutMs: Long) {
        if (pendingResult != null) {
            finishError("browser_busy", "Browser sedang menyelesaikan tindakan sebelumnya.")
        }
        pendingResult = result
        pendingDone = AtomicBoolean(false)
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = Runnable {
            finishError("browser_timeout", "Browser latar belakang melebihi had masa.")
        }.also { mainHandler.postDelayed(it, timeoutMs) }
    }

    private fun snapshotPending() {
        val result = pendingResult ?: return
        val view = webView ?: run {
            finishError("browser_missing", "Enjin browser belum tersedia.")
            return
        }
        silenceMedia(view)
        view.evaluateJavascript(SNAPSHOT_SCRIPT) { raw ->
            if (pendingDone.getAndSet(true)) return@evaluateJavascript
            try {
                val objectValue = decodeJavascriptObject(raw)
                val map = jsonObjectToMap(objectValue).toMutableMap()
                map["success"] = true
                map["engine"] = "android-system-webview-chromium"
                map["canGoBack"] = view.canGoBack()
                map["canGoForward"] = view.canGoForward()
                map["desktopMode"] = desktopMode
                clearPending()
                result.success(map)
            } catch (error: Throwable) {
                clearPending()
                result.error("snapshot_error", error.message, null)
            }
        }
    }

    private fun finishError(code: String, message: String) {
        val result = pendingResult ?: return
        if (pendingDone.getAndSet(true)) return
        clearPending()
        result.error(code, message, null)
    }

    private fun clearPending() {
        timeoutRunnable?.let(mainHandler::removeCallbacks)
        timeoutRunnable = null
        pendingResult = null
    }

    private fun decodeJavascriptObject(raw: String?): JSONObject {
        if (raw.isNullOrBlank() || raw == "null") return JSONObject()
        val first = JSONTokener(raw).nextValue()
        val jsonText = when (first) {
            is String -> first
            is JSONObject -> return first
            else -> first.toString()
        }
        return JSONObject(jsonText)
    }

    private fun jsonObjectToMap(value: JSONObject): Map<String, Any?> {
        val output = mutableMapOf<String, Any?>()
        val keys = value.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            output[key] = jsonValue(value.opt(key))
        }
        return output
    }

    private fun jsonValue(value: Any?): Any? = when (value) {
        null, JSONObject.NULL -> null
        is JSONObject -> jsonObjectToMap(value)
        is JSONArray -> (0 until value.length()).map { jsonValue(value.opt(it)) }
        else -> value
    }

    fun silenceMedia() {
        activity.runOnUiThread {
            webView?.let(::silenceMedia)
        }
    }

    private fun silenceMedia(view: WebView) {
        try {
            view.evaluateJavascript(MUTE_MEDIA_SCRIPT, null)
        } catch (_: Throwable) {
            // Halaman mungkin belum mempunyai konteks JavaScript. Percubaan seterusnya
            // dibuat pada onPageFinished dan sebelum setiap snapshot/screenshot.
        }
    }

    fun destroy() {
        activity.runOnUiThread {
            timeoutRunnable?.let(mainHandler::removeCallbacks)
            timeoutRunnable = null
            pendingResult = null
            webView?.let { view ->
                (view.parent as? ViewGroup)?.removeView(view)
                view.stopLoading()
                view.clearHistory()
                view.removeAllViews()
                view.destroy()
            }
            webView = null
        }
    }

    private fun desktopUserAgent(): String =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/138 Safari/537.36 AiMultiAgent/1.0.0"

    private fun mobileUserAgent(): String =
        "Mozilla/5.0 (Linux; Android ${android.os.Build.VERSION.RELEASE}; ${android.os.Build.MODEL}) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138 Mobile Safari/537.36 AiMultiAgent/1.0.0"

    companion object {
        private val MUTE_MEDIA_SCRIPT = """
            (() => {
              const silence = (node) => {
                if (!node) return;
                try { node.muted = true; } catch (_) {}
                try { node.volume = 0; } catch (_) {}
                try { node.autoplay = false; } catch (_) {}
                try { node.removeAttribute('autoplay'); } catch (_) {}
              };

              const mediaPrototype = window.HTMLMediaElement && window.HTMLMediaElement.prototype;
              if (mediaPrototype && !mediaPrototype.__aiMultiAgentSilentPlay) {
                const originalPlay = mediaPrototype.play;
                Object.defineProperty(mediaPrototype, '__aiMultiAgentSilentPlay', {value:true});
                mediaPrototype.play = function(...args) {
                  silence(this);
                  return originalPlay.apply(this, args);
                };
              }

              if (!window.__aiMultiAgentAudioContexts) {
                window.__aiMultiAgentAudioContexts = [];
                for (const key of ['AudioContext', 'webkitAudioContext']) {
                  const NativeContext = window[key];
                  if (!NativeContext || NativeContext.__aiMultiAgentWrapped) continue;
                  const SilentContext = function(...args) {
                    const context = new NativeContext(...args);
                    window.__aiMultiAgentAudioContexts.push(context);
                    try { context.suspend(); } catch (_) {}
                    if (context.resume) {
                      context.resume = () => Promise.resolve(context.suspend()).then(() => context);
                    }
                    return context;
                  };
                  SilentContext.prototype = NativeContext.prototype;
                  Object.setPrototypeOf(SilentContext, NativeContext);
                  Object.defineProperty(SilentContext, '__aiMultiAgentWrapped', {value:true});
                  try { window[key] = SilentContext; } catch (_) {}
                }
              }

              const silenceAll = () => {
                document.querySelectorAll('video,audio').forEach(silence);
                for (const context of window.__aiMultiAgentAudioContexts || []) {
                  try { context.suspend(); } catch (_) {}
                }
              };
              silenceAll();

              if (!window.__aiMultiAgentMediaSilencer && document.documentElement) {
                window.__aiMultiAgentMediaSilencer = new MutationObserver((records) => {
                  for (const record of records) {
                    for (const node of record.addedNodes || []) {
                      if (!node || node.nodeType !== 1) continue;
                      if (node.matches && node.matches('video,audio')) silence(node);
                      if (node.querySelectorAll) node.querySelectorAll('video,audio').forEach(silence);
                    }
                  }
                });
                window.__aiMultiAgentMediaSilencer.observe(
                  document.documentElement,
                  {childList:true,subtree:true}
                );
                document.addEventListener('play', (event) => silence(event.target), true);
                document.addEventListener('volumechange', (event) => silence(event.target), true);
              }
              return true;
            })();
        """.trimIndent()

        private val FULL_PAGE_SIZE_SCRIPT = """
            (() => {
              const root = document.documentElement;
              const body = document.body;
              const width = Math.max(
                root ? root.scrollWidth : 0,
                root ? root.offsetWidth : 0,
                body ? body.scrollWidth : 0,
                body ? body.offsetWidth : 0,
                window.innerWidth || 0
              );
              const height = Math.max(
                root ? root.scrollHeight : 0,
                root ? root.offsetHeight : 0,
                body ? body.scrollHeight : 0,
                body ? body.offsetHeight : 0,
                window.innerHeight || 0
              );
              return JSON.stringify({
                width,
                height,
                viewportWidth: window.innerWidth || width,
                viewportHeight: window.innerHeight || height
              });
            })();
        """.trimIndent()

        private val SNAPSHOT_SCRIPT = """
            (() => {
              const clean = (value) => (value || '').replace(/\s+/g, ' ').trim();
              const links = Array.from(document.querySelectorAll('a[href]')).slice(0, 80).map((node, index) => ({
                index,
                text: clean(node.innerText || node.getAttribute('aria-label') || ''),
                url: node.href || ''
              })).filter((item) => item.url);
              const forms = Array.from(document.forms).slice(0, 15).map((form, index) => ({
                index,
                id: form.id || '',
                name: form.name || '',
                action: form.action || location.href,
                method: (form.method || 'get').toUpperCase(),
                fields: Array.from(form.elements).slice(0, 30).map((field) => ({
                  tag: field.tagName ? field.tagName.toLowerCase() : '',
                  type: field.type || '',
                  name: field.name || '',
                  id: field.id || '',
                  placeholder: field.placeholder || '',
                  value: field.type === 'password' ? '[REDACTED]' : (field.value || '')
                }))
              }));
              const text = clean(document.body ? document.body.innerText : '').slice(0, 32000);
              const html = (document.documentElement ? document.documentElement.outerHTML : '').slice(0, 80000);
              return JSON.stringify({
                url: location.href,
                title: document.title || '',
                text,
                html,
                links,
                forms
              });
            })();
        """.trimIndent()
    }
}
