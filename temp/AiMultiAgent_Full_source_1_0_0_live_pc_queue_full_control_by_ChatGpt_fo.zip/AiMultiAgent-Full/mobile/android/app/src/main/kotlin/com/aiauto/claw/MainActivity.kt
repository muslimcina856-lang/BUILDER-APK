package com.aiauto.claw

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream

class MainActivity : FlutterActivity() {
    private val deviceChannelName = "com.aiauto.claw/device"
    private val browserChannelName = "com.aiauto.claw/browser"
    private val mediaChannelName = "com.aiauto.claw/media"
    private val saveFileRequestCode = 7104
    private var browserEngine: BackgroundBrowserEngine? = null
    private var pendingSaveResult: MethodChannel.Result? = null
    private var pendingSaveSource: File? = null

    override fun onResume() {
        super.onResume()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        browserEngine?.silenceMedia()
    }

    override fun onPause() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        browserEngine?.silenceMedia()
        super.onPause()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, deviceChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "startExecutionKeepAlive" -> {
                        val maxDurationMs = call.argument<Number>("maxDurationMs")?.toLong()
                            ?: 30L * 60L * 1000L
                        try {
                            ExecutionKeepAliveService.start(this, maxDurationMs)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error(
                                "foreground_service_start_failed",
                                error.message ?: error.javaClass.simpleName,
                                null,
                            )
                        }
                    }
                    "stopExecutionKeepAlive" -> {
                        ExecutionKeepAliveService.stop(this)
                        result.success(null)
                    }
                    "openNotificationSettings" -> {
                        try {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                            }
                            startActivity(intent)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error("settings_unavailable", error.message, null)
                        }
                    }
                    "openAppSettings" -> {
                        try {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:$packageName"),
                            )
                            startActivity(intent)
                            result.success(null)
                        } catch (error: Throwable) {
                            result.error("settings_unavailable", error.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        browserEngine = BackgroundBrowserEngine(this)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, browserChannelName)
            .setMethodCallHandler { call, result ->
                browserEngine?.handle(call, result)
                    ?: result.error("browser_unavailable", "Enjin browser tidak tersedia.", null)
            }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, mediaChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "saveFile" -> beginSaveFile(call, result)
                    else -> result.notImplemented()
                }
            }
    }

    private fun beginSaveFile(call: MethodCall, result: MethodChannel.Result) {
        if (pendingSaveResult != null) {
            result.error("save_busy", "Pemilih lokasi simpan sedang digunakan.", null)
            return
        }
        val rawPath = call.argument<String>("path").orEmpty()
        val source = File(rawPath)
        if (!source.isFile || !isPrivateAppFile(source)) {
            result.error("invalid_source", "Fail sumber tidak sah atau berada di luar storan aplikasi.", null)
            return
        }
        val fileName = call.argument<String>("fileName")
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: source.name
        val mimeType = call.argument<String>("mimeType")
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: "application/octet-stream"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mimeType
            putExtra(Intent.EXTRA_TITLE, fileName)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        pendingSaveResult = result
        pendingSaveSource = source
        try {
            startActivityForResult(intent, saveFileRequestCode)
        } catch (error: Throwable) {
            clearPendingSave()
            result.error("save_picker_unavailable", error.message ?: error.javaClass.simpleName, null)
        }
    }

    private fun isPrivateAppFile(file: File): Boolean {
        val sourcePath = file.canonicalFile.path
        val roots = listOf(filesDir, cacheDir, noBackupFilesDir)
        return roots.any { root ->
            val rootPath = root.canonicalFile.path
            sourcePath == rootPath || sourcePath.startsWith("$rootPath${File.separator}")
        }
    }

    @Deprecated("Deprecated in Android API but required for ACTION_CREATE_DOCUMENT result handling.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != saveFileRequestCode) return
        val callback = pendingSaveResult ?: return
        val source = pendingSaveSource
        val target = data?.data
        if (resultCode != Activity.RESULT_OK || source == null || target == null) {
            clearPendingSave()
            callback.success(mapOf("success" to false, "cancelled" to true))
            return
        }
        Thread {
            try {
                val output = contentResolver.openOutputStream(target, "w")
                    ?: throw IllegalStateException("Lokasi simpan tidak dapat dibuka.")
                FileInputStream(source).use { input ->
                    output.use { destination -> input.copyTo(destination, DEFAULT_BUFFER_SIZE) }
                }
                runOnUiThread {
                    clearPendingSave()
                    callback.success(
                        mapOf(
                            "success" to true,
                            "cancelled" to false,
                            "uri" to target.toString(),
                        ),
                    )
                }
            } catch (error: Throwable) {
                runOnUiThread {
                    clearPendingSave()
                    callback.error("save_failed", error.message ?: error.javaClass.simpleName, null)
                }
            }
        }.start()
    }

    private fun clearPendingSave() {
        pendingSaveResult = null
        pendingSaveSource = null
    }


    override fun onDestroy() {
        pendingSaveResult?.error("activity_destroyed", "Aktiviti ditutup sebelum fail sempat disimpan.", null)
        clearPendingSave()
        browserEngine?.destroy()
        browserEngine = null
        super.onDestroy()
    }
}
