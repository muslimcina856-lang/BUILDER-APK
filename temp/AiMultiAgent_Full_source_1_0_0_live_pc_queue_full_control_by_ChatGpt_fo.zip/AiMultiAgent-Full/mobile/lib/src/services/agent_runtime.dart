import 'dart:async';
import 'dart:convert';

import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'local_database.dart';
import 'permission_manager.dart';
import 'provider_service.dart';
import 'tool_engine.dart';

class RunControl {
  bool _cancelled = false;
  bool _paused = false;
  Completer<void>? _resumeCompleter;

  bool get cancelled => _cancelled;
  bool get paused => _paused;

  void cancel() {
    _cancelled = true;
    resume();
  }

  void pause() {
    if (_cancelled || _paused) return;
    _paused = true;
    _resumeCompleter = Completer<void>();
  }

  void resume() {
    _paused = false;
    final completer = _resumeCompleter;
    _resumeCompleter = null;
    if (completer != null && !completer.isCompleted) completer.complete();
  }

  Future<void> waitIfPaused() async {
    while (_paused && !_cancelled) {
      final completer = _resumeCompleter;
      if (completer == null) return;
      await completer.future;
    }
  }
}

/// Menyelaras model, tools, skills dan sub-agent dinamik.
///
/// UI hanya menerima status operasi yang boleh diperhati (model, tool,
/// sub-agent, hasil). Pemikiran dalaman model tidak direkod atau dipaparkan.
class AgentRuntime {
  AgentRuntime({
    required this.providerService,
    required this.toolEngine,
    required this.permissionManager,
    required this.database,
  });

  final ProviderService providerService;
  final ToolEngine toolEngine;
  final PermissionManager permissionManager;
  final LocalDatabase database;

  static const Uuid _uuid = Uuid();

  Future<ChatMessage> run({
    required String sessionId,
    required ProviderConfig provider,
    required String apiKey,
    required AgentProfile agent,
    required List<SkillDefinition> skills,
    required List<ChatMessage> history,
    required String userInput,
    List<ChatAttachment> userAttachments = const <ChatAttachment>[],
    List<AgentProfile> agents = const <AgentProfile>[],
    List<ProviderConfig> providers = const <ProviderConfig>[],
    Future<String> Function(String providerId)? apiKeyResolver,
    RunControl? control,
    int depth = 0,
    void Function(RunStatus status, String detail)? onProgress,
    void Function(RunEvent event)? onEvent,
  }) async {
    // Parameter legacy ini dikekalkan supaya data lama/worker lama masih serasi.
    // Sub-agent baharu sentiasa menggunakan provider/model yang dipilih pengguna.
    final _ = (agents, providers, apiKeyResolver);
    final runControl = control ?? RunControl();
    final activeSkills = skills.where((item) => item.enabled).toList();
    final selectedTools = _selectTools(agent, activeSkills)
      ..add(_delegateAgentDefinition());
    final artifacts = <ChatArtifact>[];
    final runtimeContext = await toolEngine.runtimeContextSnapshot();

    final messages = <ChatMessage>[
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.system,
        content: _systemPrompt(
          agent,
          activeSkills,
          selectedTools,
          runtimeContext,
        ),
        createdAt: DateTime.now(),
      ),
      ...history.where((message) => message.role != MessageRole.system),
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.user,
        content: userInput,
        createdAt: DateTime.now(),
        metadata: <String, dynamic>{
          if (userAttachments.isNotEmpty)
            'attachments':
                userAttachments.map((item) => item.toJson()).toList(),
        },
      ),
    ];

    var step = 0;
    while (!runControl.cancelled) {
      await runControl.waitIfPaused();
      if (runControl.cancelled) break;
      final modelEventId = 'model:$depth:$step';
      final firstTurn = step == 0;
      final modelTitle = firstTurn
          ? (depth == 0
              ? 'Memahami permintaan'
              : '${agent.name} memproses subtugas')
          : 'Menyusun hasil';
      _emit(
        onEvent,
        RunEvent(
          id: modelEventId,
          title: modelTitle,
          detail: '${provider.name} · ${agent.modelOverride ?? provider.model}',
          state: RunEventState.running,
          createdAt: DateTime.now(),
          agentRole: agent.name,
        ),
      );
      onProgress?.call(
        firstTurn ? RunStatus.planning : RunStatus.runningTool,
        modelTitle,
      );

      ModelTurn turn;
      try {
        turn = await providerService.complete(
          config: provider,
          apiKey: apiKey,
          messages: messages,
          tools: selectedTools,
          modelOverride: agent.modelOverride,
        );
        _emit(
          onEvent,
          RunEvent(
            id: modelEventId,
            title: modelTitle,
            detail: turn.toolCalls.isEmpty
                ? 'Respons akhir diterima'
                : '${turn.toolCalls.length} tindakan dipilih',
            state: RunEventState.success,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
      } catch (error) {
        _emit(
          onEvent,
          RunEvent(
            id: modelEventId,
            title: modelTitle,
            detail: error.toString(),
            state: RunEventState.failed,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
        rethrow;
      }

      if (runControl.cancelled) break;
      if (turn.toolCalls.isEmpty) {
        final text = turn.text.trim().isEmpty
            ? 'Model tidak memulangkan jawapan teks.'
            : turn.text.trim();
        _emit(
          onEvent,
          RunEvent(
            id: 'final:$depth',
            title: depth == 0 ? 'Jawapan siap' : '${agent.name} selesai',
            detail: artifacts.isEmpty
                ? 'Selesai'
                : '${artifacts.length} hasil dilampirkan',
            state: RunEventState.success,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
        onProgress?.call(RunStatus.completed, 'Selesai');
        return ChatMessage(
          id: _uuid.v4(),
          sessionId: sessionId,
          role: MessageRole.assistant,
          content: text,
          createdAt: DateTime.now(),
          metadata: <String, dynamic>{
            'agentId': agent.id,
            'agentName': agent.name,
            'providerId': provider.id,
            'model': agent.modelOverride ?? provider.model,
            'steps': step + 1,
            'delegationDepth': depth,
            if (artifacts.isNotEmpty)
              'artifacts': artifacts.map((item) => item.toJson()).toList(),
          },
        );
      }

      messages.add(
        ChatMessage(
          id: _uuid.v4(),
          sessionId: sessionId,
          role: MessageRole.assistant,
          content: turn.text,
          createdAt: DateTime.now(),
          metadata: <String, dynamic>{
            'toolCalls': turn.toolCalls
                .map(
                  (call) => <String, dynamic>{
                    'id': call.id,
                    'name': call.name,
                    'arguments': call.arguments,
                  },
                )
                .toList(),
          },
        ),
      );

      for (final call in turn.toolCalls) {
        await runControl.waitIfPaused();
        if (runControl.cancelled) break;
        final definition = call.name == 'delegate_agent'
            ? selectedTools.firstWhereOrNull(
                (item) => item.id == 'delegate_agent',
              )
            : toolEngine.definition(call.name);
        if (definition == null ||
            !selectedTools.any((item) => item.id == call.name)) {
          final unavailable = ToolResult(
            success: false,
            output: 'Tool ${call.name} tidak tersedia.',
          );
          messages.add(_toolMessage(sessionId, call, unavailable));
          _emitToolResult(
            onEvent: onEvent,
            eventId: 'tool:${call.id}',
            title: call.name,
            result: unavailable,
            agentName: agent.name,
          );
          continue;
        }

        final isDelegation = call.name == 'delegate_agent';
        final eventId = isDelegation ? 'agent:${call.id}' : 'tool:${call.id}';
        final title = isDelegation
            ? (call.arguments['role']?.toString().trim().isNotEmpty == true
                ? call.arguments['role'].toString().trim()
                : 'Sub-agent')
            : definition.name;
        _emit(
          onEvent,
          RunEvent(
            id: eventId,
            title: title,
            detail: _eventDetail(call.name, call.arguments),
            state: RunEventState.running,
            createdAt: DateTime.now(),
            toolId: call.name,
            agentRole: agent.name,
          ),
        );

        late ToolResult result;
        if (isDelegation) {
          onProgress?.call(RunStatus.runningTool, '$title sedang bekerja');
          result = await _delegate(
            sessionId: sessionId,
            call: call,
            provider: provider,
            apiKey: apiKey,
            skills: activeSkills,
            control: runControl,
            depth: depth,
            onProgress: onProgress,
            onEvent: onEvent,
          );
        } else {
          final scope = toolEngine.permissionScope(call.name, call.arguments);
          if (await toolEngine.requiresPermission(call.name, call.arguments)) {
            _emit(
              onEvent,
              RunEvent(
                id: eventId,
                title: title,
                detail: 'Menunggu kelulusan tindakan berisiko',
                state: RunEventState.waiting,
                createdAt: DateTime.now(),
                toolId: call.name,
                agentRole: agent.name,
              ),
            );
            onProgress?.call(
              RunStatus.waitingPermission,
              'Menunggu kelulusan untuk ${definition.name}',
            );
            final decision = await permissionManager.request(
              tool: definition,
              scope: scope,
              description:
                  toolEngine.permissionDescription(call.name, call.arguments),
            );
            if (decision == PermissionDecision.deny) {
              result = const ToolResult(
                success: false,
                output: 'Pengguna menolak tindakan berisiko ini.',
              );
              messages.add(_toolMessage(sessionId, call, result));
              await _logTool(
                sessionId: sessionId,
                toolId: call.name,
                scope: scope,
                result: result,
              );
              _emitToolResult(
                onEvent: onEvent,
                eventId: eventId,
                title: title,
                result: result,
                agentName: agent.name,
                toolId: call.name,
              );
              continue;
            }
          }
          onProgress?.call(RunStatus.runningTool, title);
          result = await toolEngine.execute(call.name, call.arguments);
          await _logTool(
            sessionId: sessionId,
            toolId: call.name,
            scope: scope,
            result: result,
          );
        }

        _collectArtifacts(result.data, artifacts);
        messages.add(_toolMessage(sessionId, call, result));
        _emitToolResult(
          onEvent: onEvent,
          eventId: eventId,
          title: title,
          result: result,
          agentName: agent.name,
          toolId: call.name,
        );
      }
      step++;
    }

    return ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.assistant,
      content: 'Tugasan dihentikan.',
      createdAt: DateTime.now(),
      metadata: <String, dynamic>{
        'cancelled': true,
        if (artifacts.isNotEmpty)
          'artifacts': artifacts.map((item) => item.toJson()).toList(),
      },
    );
  }

  Future<ToolResult> _delegate({
    required String sessionId,
    required ToolCall call,
    required ProviderConfig provider,
    required String apiKey,
    required List<SkillDefinition> skills,
    required RunControl control,
    required int depth,
    required void Function(RunStatus status, String detail)? onProgress,
    required void Function(RunEvent event)? onEvent,
  }) async {
    final role = call.arguments['role']?.toString().trim() ?? '';
    final task = call.arguments['task']?.toString().trim() ?? '';
    final expected =
        call.arguments['expected_output']?.toString().trim() ?? '';
    final requestedTools = (call.arguments['tool_ids'] as List? ??
            const <dynamic>[])
        .map((item) => item.toString())
        .where((item) => toolEngine.definition(item) != null)
        .toList();
    if (task.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'Subtugas tidak boleh kosong.',
      );
    }

    final name = role.isEmpty ? 'Sub-agent' : role;
    final subAgent = AgentProfile(
      id: 'sub_${_uuid.v4()}',
      name: name,
      description: 'Sub-agent dinamik untuk satu subtugas.',
      systemPrompt: [
        'Fokus hanya pada subtugas yang diberikan.',
        if (expected.isNotEmpty) 'Hasil yang diperlukan: $expected',
        'Pulangkan dapatan yang padat kepada orchestrator utama.',
      ].join('\n'),
      iconCode: 0xf1b3,
      toolIds: requestedTools,
      enabled: true,
      isBuiltIn: false,
    );

    final response = await run(
      sessionId: '$sessionId/sub/${_uuid.v4()}',
      provider: provider,
      apiKey: apiKey,
      agent: subAgent,
      skills: skills,
      history: const <ChatMessage>[],
      userInput: task,
      control: control,
      depth: depth + 1,
      onProgress: onProgress,
      onEvent: onEvent,
    );
    return ToolResult(
      success: !control.cancelled,
      output: response.content,
      data: <String, dynamic>{
        'role': name,
        'provider_id': provider.id,
        'model': provider.model,
        'depth': depth + 1,
        if (response.artifacts.isNotEmpty)
          'artifacts': response.artifacts.map((item) => item.toJson()).toList(),
      },
    );
  }

  ToolDefinition _delegateAgentDefinition() {
    return const ToolDefinition(
      id: 'delegate_agent',
      name: 'Cipta sub-agent',
      category: 'Multi-Agent',
      risk: ToolRisk.readOnly,
      description:
          'Cipta sub-agent dinamik di latar belakang untuk menyelesaikan satu subtugas menggunakan provider dan model yang sama.',
      parameters: <String, dynamic>{
        'type': 'object',
        'properties': <String, dynamic>{
          'role': <String, dynamic>{
            'type': 'string',
            'description':
                'Nama peranan khusus, contoh Penyelidik Web atau Penganalisis Dokumen.',
          },
          'task': <String, dynamic>{
            'type': 'string',
            'description': 'Subtugas lengkap beserta konteks penting.',
          },
          'expected_output': <String, dynamic>{
            'type': 'string',
            'description': 'Bentuk hasil yang perlu dipulangkan.',
          },
          'tool_ids': <String, dynamic>{
            'type': 'array',
            'items': <String, dynamic>{'type': 'string'},
            'description':
                'Pilihan tool khusus. Kosong bermaksud semua tool tersedia.',
          },
        },
        'required': <String>['role', 'task'],
      },
    );
  }

  List<ToolDefinition> _selectTools(
    AgentProfile agent,
    List<SkillDefinition> skills,
  ) {
    final ids = <String>{...agent.toolIds};
    for (final skill in skills) {
      ids.addAll(skill.toolIds);
    }
    if (ids.isEmpty || agent.id == 'orchestrator') {
      return <ToolDefinition>[...toolEngine.definitions];
    }
    return toolEngine.definitions
        .where((item) => ids.contains(item.id))
        .toList(growable: true);
  }

  String _systemPrompt(
    AgentProfile agent,
    List<SkillDefinition> skills,
    List<ToolDefinition> tools,
    Map<String, dynamic> runtimeContext,
  ) {
    final skillText = skills.isEmpty
        ? 'Tiada skill aktif.'
        : skills
            .map(
              (skill) =>
                  'SKILL ${skill.name}\nTujuan: ${skill.description}\nArahan:\n${skill.instructions}\nTools: ${skill.toolIds.join(', ')}',
            )
            .join('\n\n');
    return '''
Anda ialah ${agent.name} dalam Ai MultiAgent.

Peranan:
${agent.systemPrompt}

Arahan operasi:
- Jawab dalam bahasa pengguna kecuali diminta sebaliknya.
- Tentukan sendiri bila tool, skill atau sub-agent diperlukan; tiada kata kunci pemicu.
- Gunakan hasil tool sebenar dan jangan mendakwa tindakan berjaya sebelum hasil diterima.
- Untuk web, gunakan web_search kemudian browser_open/browser_read bagi sumber penting. Browser latar menggunakan mod desktop/PC secara lalai. Jangan kata tiada akses browser sebelum mencuba tool tersebut.
- Untuk URL gambar, video atau audio langsung yang hendak dihantar kepada pengguna, gunakan media_preview supaya media boleh dipratonton/dimainkan sebelum pengguna memilih Simpan. Jangan gunakan browser_download terlebih dahulu kecuali pengguna memang meminta fail dimuat turun ke workspace.
- browser_screenshot sudah melampirkan PNG penuh halaman terus ke chat. Screenshot browser hendaklah full-page secara lalai, bukan crop viewport. Selepas screenshot berjaya, jangan panggil media_preview untuk path fail screenshot atau URL halaman; terus jawab pengguna bahawa screenshot tersedia.
- Apabila pengguna bertanya cara menggunakan aplikasi atau sesuatu fungsi, panggil app_usage_guide dan jawab berdasarkan panduan itu.
- AI tidak dibenarkan mengetahui, meminta, mengesan atau meneka spesifikasi/perincian peranti host. runtime_info hanya menerangkan sandbox Shell, PC Windows dan browser yang dibenarkan; ia tidak memberikan model telefon, SoC, RAM host, storan host, bateri, versi OS host atau path host. Jika pengguna bertanya tentang peranti host, jelaskan bahawa maklumat itu sengaja tidak tersedia kepada AI. Jangan cuba /sdcard, /storage, /data, /system, /sys, /proc/cpuinfo, /proc/meminfo, arahan host atau teknik fingerprinting lain. Bezakan browser sandbox daripada akses kepada PC jauh/tab browser pengguna.
- Semua pelaksanaan proses oleh AI mesti berlaku di dalam Shell sandbox atau PC Windows sandbox. File-tool hanya boleh menggunakan path relatif dalam /workspace. Jangan cuba path host, path mutlak host, traversal ../, symlink, pseudo-filesystem host atau sebarang cara untuk keluar daripada sandbox. Cubaan seperti itu bukan strategi pemulihan dan tidak boleh digunakan walaupun tugasan gagal.
- Untuk tugasan Windows dalam edisi Full, utamakan PC Windows local. Drive yang dibenarkan kepada AI ialah C:\\ (prefix Wine), W:\\ (workspace) dan A:\\ (lampiran); drive Z:\\ root sengaja tidak tersedia. Semak windows_runtime_status; jika belum siap, panggil windows_install. Gunakan windows_run_cmd untuk cmd.exe atau windows_run_exe bagi fail .exe dalam /workspace, lampiran chat atau aplikasi yang sudah dipasang dalam drive C: Wine, kemudian windows_poll sehingga running=false. Untuk aplikasi GUI yang masih berjalan, gunakan windows_screenshot bagi melihat keseluruhan desktop 1280×720 yang dirender, windows_list_windows untuk mendapatkan window_id, dan windows_ui_action untuk gerak tetikus/klik/double-click/klik kanan/scroll/drag/taip/kekunci/fokus. Ambil screenshot penuh desktop semula selepas tindakan penting untuk mengesahkan hasil.
- PC Windows local ialah lapisan keserasian Wine WoW64 + Box64 pada ARM64, bukan kernel/VM Windows penuh. Jangan jamin semua aplikasi Windows serasi. Jika tugasan benar-benar memerlukan Windows penuh/peranti jauh dan server PC Windows melalui MCP telah dikonfigurasi, gunakan mcp_list_tools/mcp_call sebagai pilihan tambahan.
- Untuk terminal Shell, panggil linux_workspace_status dahulu apabila keadaan Linux belum diketahui. Gunakan terminal_start, ambil job_id, kemudian terminal_poll berulang kali sehingga running=false supaya stdout, stderr dan exit_code sebenar diperiksa.
- ${AppConfig.isFullEdition ? 'Full mempunyai Alpine Linux ARM64 terbina dalam melalui PRoot. Runtime dipasang automatik pada arahan pertama. Pengurus pakej ialah apk, bukan apt/dpkg. Untuk memasang pakej gunakan contoh: apk update && apk add --no-cache git python3. Workspace projek ialah /workspace dan home ialah /root.' : 'Edisi Standard tidak mempunyai PRoot/rootfs. Jangan cuba apt, dpkg atau apk; gunakan tools native yang dibundel.'}
- Terminal tool tidak menyediakan stdin interaktif. Gunakan arahan non-interaktif, flag seperti --yes/--no-input apabila disokong, elakkan editor interaktif, dan jangan gunakan sudo kerana shell guest sudah beridentiti root.
- Shell memberi root di dalam guest PRoot sahaja, bukan root host. Ia tiada systemd, kernel sendiri atau desktop GUI. Jangan cuba mengenal pasti host melalui Shell dan jangan dakwa Shell itu PC jauh atau VM penuh.
- Jika terminal gagal, laporkan stderr/exit_code sebenar dan cuba pembetulan yang selamat; jangan terus mendakwa Linux tidak tersedia sebelum memanggil linux_workspace_status atau terminal_start.
- Gunakan delegate_agent untuk membahagikan kerja kompleks. Gabungkan hasil sub-agent dalam jawapan akhir.
- Jangan tukar provider atau model; gunakan pilihan pengguna.
- Hanya operasi destruktif akan dikendalikan oleh dialog kelulusan aplikasi.
- Jangan keluarkan chain-of-thought. UI memaparkan status operasi secara berasingan.

Konteks sandbox yang dibenarkan kepada AI pada permulaan tugasan:
${const JsonEncoder.withIndent('  ').convert(runtimeContext)}

Tools tersedia: ${tools.map((item) => item.id).join(', ')}

Skills aktif:
$skillText
'''.trim();
  }

  ChatMessage _toolMessage(
    String sessionId,
    ToolCall call,
    ToolResult result,
  ) {
    return ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.tool,
      name: call.name,
      toolCallId: call.id,
      content: _toolResultForModel(call.name, result),
      createdAt: DateTime.now(),
    );
  }

  String _toolResultForModel(String toolId, ToolResult result) {
    final safeData = _modelSafeValue(result.data, key: 'data');
    var output = _hideHostDetails(result.output.trim());
    if (output.length > 14000) {
      output = '${output.substring(0, 14000)}…';
    }
    return jsonEncode(<String, dynamic>{
      'success': result.success,
      'tool': toolId,
      'output': output,
      'data': safeData,
    });
  }

  dynamic _modelSafeValue(
    dynamic value, {
    required String key,
    int depth = 0,
  }) {
    if (depth > 6) return '[dipendekkan]';
    final normalizedKey = key.toLowerCase();
    if (<String>{'artifact', 'artifacts', 'html', 'base64', 'datauri'}
        .contains(normalizedKey)) {
      return null;
    }
    if (value is String) {
      final limit = normalizedKey == 'text' ? 16000 : 8000;
      final safe = _hideHostDetails(value);
      return safe.length <= limit ? safe : '${safe.substring(0, limit)}…';
    }
    if (value is Map) {
      final output = <String, dynamic>{};
      for (final entry in value.entries) {
        final childKey = entry.key.toString();
        final child = _modelSafeValue(
          entry.value,
          key: childKey,
          depth: depth + 1,
        );
        if (child != null) output[childKey] = child;
      }
      return output;
    }
    if (value is List) {
      final limit = switch (normalizedKey) {
        'links' => 40,
        'forms' => 10,
        'fields' => 20,
        _ => 30,
      };
      return value
          .take(limit)
          .map(
            (item) => _modelSafeValue(
              item,
              key: key,
              depth: depth + 1,
            ),
          )
          .where((item) => item != null)
          .toList();
    }
    return value;
  }

  String _hideHostDetails(String value) {
    var text = value;
    text = text.replaceAll(
      RegExp(r'/data/(?:user/\d+|data)/[^\s]+'),
      '[HOST_PATH_HIDDEN]',
    );
    text = text.replaceAll(
      RegExp(r'/(?:sdcard|storage|mnt/media_rw|system|vendor|product|apex|sys)(?:/[^\s]*)?'),
      '[HOST_PATH_HIDDEN]',
    );
    text = text.replaceAll(
      RegExp(r'/proc/(?:cpuinfo|meminfo|version|device-tree(?:/[^\s]*)?|sys/kernel(?:/[^\s]*)?)'),
      '[HOST_PATH_HIDDEN]',
    );
    return text;
  }

  Future<void> _logTool({
    required String sessionId,
    required String toolId,
    required String scope,
    required ToolResult result,
  }) async {
    await database.logTool(
      sessionId: sessionId,
      toolId: toolId,
      scope: scope,
      success: result.success,
      summary: _redactedSummary(result.output),
    );
  }

  String _redactedSummary(String value) {
    var text = _hideHostDetails(value)
        .replaceAll(
          RegExp(
            r'(api[_-]?key|authorization|token|secret|password)["\s:=]+[^,\s"}]+',
            caseSensitive: false,
          ),
          r'$1=[REDACTED]',
        )
        .replaceAll(
          RegExp(
            r'bearer\s+[A-Za-z0-9._~+/-]+=*',
            caseSensitive: false,
          ),
          'Bearer [REDACTED]',
        );
    if (text.length > 1200) text = '${text.substring(0, 1200)}…';
    return text;
  }

  void _collectArtifacts(
    Map<String, dynamic> data,
    List<ChatArtifact> output,
  ) {
    final rawArtifact = data['artifact'];
    if (rawArtifact is Map) {
      _addArtifact(
        ChatArtifact.fromJson(Map<String, dynamic>.from(rawArtifact)),
        output,
      );
    }
    for (final raw in data['artifacts'] as List? ?? const <dynamic>[]) {
      if (raw is Map) {
        _addArtifact(
          ChatArtifact.fromJson(Map<String, dynamic>.from(raw)),
          output,
        );
      }
    }
  }

  void _addArtifact(ChatArtifact artifact, List<ChatArtifact> output) {
    if (artifact.id.isEmpty || output.any((item) => item.id == artifact.id)) {
      return;
    }
    output.add(artifact);
  }

  void _emit(
    void Function(RunEvent event)? callback,
    RunEvent event,
  ) {
    callback?.call(event);
  }

  void _emitToolResult({
    required void Function(RunEvent event)? onEvent,
    required String eventId,
    required String title,
    required ToolResult result,
    required String agentName,
    String? toolId,
  }) {
    final detail = _hideHostDetails(_toolEventDetail(toolId, result));
    _emit(
      onEvent,
      RunEvent(
        id: eventId,
        title: title,
        detail: detail.isEmpty
            ? (result.success ? 'Selesai' : 'Gagal')
            : (detail.length > 150 ? '${detail.substring(0, 150)}…' : detail),
        state: result.success ? RunEventState.success : RunEventState.failed,
        createdAt: DateTime.now(),
        toolId: toolId,
        agentRole: agentName,
      ),
    );
  }

  String _toolEventDetail(String? toolId, ToolResult result) {
    final data = result.data;
    switch (toolId) {
      case 'browser_open':
      case 'browser_read':
      case 'open_url':
      case 'browser_follow_link':
      case 'browser_click':
      case 'browser_fill':
      case 'browser_submit_form':
        final title = data['title']?.toString().trim() ?? '';
        final url = data['url']?.toString().trim() ?? '';
        if (title.isNotEmpty && url.isNotEmpty) return '$title · $url';
        if (url.isNotEmpty) return url;
        return result.success ? 'Halaman browser selesai diproses' : _hideHostDetails(result.output);
      case 'browser_screenshot':
        final width = data['width'];
        final height = data['height'];
        if (width != null && height != null) {
          return 'Screenshot penuh ${width}×$height tersedia';
        }
        return result.success ? 'Screenshot penuh tersedia' : _hideHostDetails(result.output);
      case 'media_preview':
        final kind = data['kind']?.toString() ?? 'media';
        return 'Pratonton $kind tersedia tanpa simpanan automatik';
      case 'browser_download':
        final path = data['path']?.toString() ?? '';
        final bytes = data['bytes'];
        return path.isNotEmpty
            ? 'Disimpan: $path${bytes == null ? '' : ' · $bytes bait'}'
            : _hideHostDetails(result.output);
      case 'app_usage_guide':
        return 'Panduan cara guna aplikasi dibaca';
      case 'terminal_start':
      case 'terminal_poll':
      case 'terminal_stop':
        final exitCode = data['exit_code'];
        final running = data['running'];
        if (running == true) return 'Proses terminal sedang berjalan';
        if (exitCode != null) return 'Terminal selesai dengan exit code $exitCode';
        break;
      case 'windows_run_cmd':
      case 'windows_run_exe':
      case 'windows_poll':
      case 'windows_stop':
        final exitCode = data['exit_code'];
        final running = data['running'];
        if (running == true) return 'Proses Windows sedang berjalan';
        if (exitCode != null) return 'Windows selesai dengan exit code $exitCode';
        break;
      case 'windows_screenshot':
        return result.success
            ? 'Screenshot PC Windows ${data['width'] ?? 1280}×${data['height'] ?? 720} tersedia'
            : _hideHostDetails(result.output);
      case 'windows_list_windows':
        return result.success ? 'Senarai tetingkap Windows dibaca' : _hideHostDetails(result.output);
      case 'windows_ui_action':
        return result.success ? 'Tindakan GUI Windows selesai' : _hideHostDetails(result.output);
      case 'windows_install':
        return result.success ? 'PC Windows local siap digunakan' : _hideHostDetails(result.output);
    }
    return _hideHostDetails(result.output).replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  String _eventDetail(String toolId, Map<String, dynamic> arguments) {
    switch (toolId) {
      case 'web_search':
        return arguments['query']?.toString() ?? 'Carian web';
      case 'browser_open':
      case 'open_url':
        return arguments['url']?.toString() ?? 'Membuka halaman';
      case 'browser_download':
        return arguments['filename']?.toString() ??
            arguments['url']?.toString() ??
            'Memuat turun fail';
      case 'file_read':
      case 'file_write':
      case 'file_delete':
        return arguments['path']?.toString() ?? 'Workspace local';
      case 'terminal_start':
        final command = _hideHostDetails(arguments['command']?.toString() ?? '');
        return command.length > 90 ? '${command.substring(0, 90)}…' : command;
      case 'windows_run_cmd':
        final command = _hideHostDetails(arguments['command']?.toString() ?? '');
        return command.length > 90 ? '${command.substring(0, 90)}…' : command;
      case 'windows_run_exe':
        return _hideHostDetails(arguments['path']?.toString() ?? 'Menjalankan EXE');
      case 'windows_install':
        return 'Menyediakan PC Windows local';
      case 'windows_screenshot':
        return 'Mengambil screenshot PC Windows';
      case 'windows_list_windows':
        return 'Membaca tetingkap PC Windows';
      case 'windows_ui_action':
        return 'Mengawal GUI PC Windows: ${arguments['action'] ?? ''}';
      case 'delegate_agent':
        final task = arguments['task']?.toString() ?? '';
        return task.length > 120 ? '${task.substring(0, 120)}…' : task;
      default:
        return 'Berjalan di latar belakang';
    }
  }
}

extension _FirstWhereOrNull<E> on Iterable<E> {
  E? firstWhereOrNull(bool Function(E item) test) {
    for (final item in this) {
      if (test(item)) return item;
    }
    return null;
  }
}
