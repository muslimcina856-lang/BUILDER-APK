import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'linux_workspace_service.dart';

class _RollingTextBuffer {
  _RollingTextBuffer(this.maxChars);

  final int maxChars;
  String _value = '';
  bool _truncated = false;

  void write(Object? chunk) {
    final text = chunk?.toString() ?? '';
    if (text.isEmpty) return;
    final combined = '$_value$text';
    if (combined.length <= maxChars) {
      _value = combined;
      return;
    }
    _value = combined.substring(combined.length - maxChars);
    _truncated = true;
  }

  @override
  String toString() => _truncated ? '… output awal dipotong …\n$_value' : _value;
}

class TerminalJob {
  TerminalJob({
    required this.id,
    required this.command,
    required this.workingDirectory,
    required this.startedAt,
    required this.process,
  });

  final String id;
  final String command;
  final String workingDirectory;
  final DateTime startedAt;
  final Process process;
  final _RollingTextBuffer stdout = _RollingTextBuffer(AppConfig.maxToolOutputChars);
  final _RollingTextBuffer stderr = _RollingTextBuffer(AppConfig.maxToolOutputChars);
  int? exitCode;
  DateTime? finishedAt;

  bool get running => exitCode == null;

  Map<String, dynamic> snapshot() => <String, dynamic>{
        'job_id': id,
        'command': command,
        'working_directory': workingDirectory,
        'running': running,
        'exit_code': exitCode,
        'started_at': startedAt.toIso8601String(),
        'finished_at': finishedAt?.toIso8601String(),
        'stdout': stdout.toString(),
        'stderr': stderr.toString(),
      };
}

class TerminalService {
  factory TerminalService() => _instance;
  TerminalService._();

  static final TerminalService _instance = TerminalService._();
  static const _uuid = Uuid();
  static const int _maxRetainedJobs = 64;
  static const int _maxConcurrentJobs = 8;
  static const Duration _gracefulStopTimeout = Duration(seconds: 2);
  static const Duration _forcedStopTimeout = Duration(seconds: 2);
  final Map<String, TerminalJob> _jobs = <String, TerminalJob>{};

  Iterable<TerminalJob> get jobs => _jobs.values;

  bool isDestructiveCommand(String command) {
    final normalized = command.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
    const destructivePatterns = <String>[
      ' rm ',
      'rm -',
      'rmdir ',
      'unlink ',
      'truncate ',
      'shred ',
      'dd if=',
      'mkfs',
      'format ',
      'reboot',
      'shutdown',
      'poweroff',
      'pm uninstall',
      'cmd package uninstall',
      'settings delete',
      'sqlite3 ',
      'drop table',
      'delete from',
      '> /',
      'chmod 000',
      'kill -9',
      'pkill ',
      'killall ',
    ];
    final padded = ' $normalized ';
    return destructivePatterns.any(padded.contains);
  }

  Future<ToolResult> start({
    required String command,
    String workingDirectory = '.',
    Map<String, String> environment = const <String, String>{},
  }) async {
    final text = command.trim();
    if (text.isEmpty) return const ToolResult(success: false, output: 'Arahan terminal kosong.');
    final hostBoundaryViolation = _androidHostBoundaryViolation(text);
    if (hostBoundaryViolation != null) {
      return ToolResult(success: false, output: hostBoundaryViolation);
    }
    if (AppConfig.isPlayEdition && _isSystemPackageInstall(text)) {
      return const ToolResult(
        success: false,
        output: 'Edisi Standard hanya menggunakan pakej native yang dibundel. Gunakan Ai MultiAgent Full untuk pengurus pakej Linux dan pemasangan binary ARM64 dalam Linux Workspace.',
      );
    }
    final runningJobs = _jobs.values.where((job) => job.running).length;
    if (runningJobs >= _maxConcurrentJobs) {
      return const ToolResult(
        success: false,
        output: 'Had 8 proses Linux serentak telah dicapai. Tunggu job selesai atau hentikan job yang tidak diperlukan.',
      );
    }
    _pruneCompletedJobs();
    if (_jobs.length >= _maxRetainedJobs) {
      return const ToolResult(
        success: false,
        output: 'Sejarah terminal penuh kerana semua job masih aktif. Hentikan job yang tidak diperlukan sebelum memulakan arahan baharu.',
      );
    }
    final root = await _workspace();
    final cwd = _safeDirectory(root, workingDirectory);
    await cwd.create(recursive: true);
    final relativeCwd = p.relative(cwd.path, from: root.path);
    LinuxCommandSpec? linux;
    if (AppConfig.isFullEdition) {
      try {
        linux = await LinuxWorkspaceService().commandSpec(
          command: text,
          relativeWorkingDirectory: relativeCwd,
          environment: environment,
          autoInstallBundledRuntime: true,
        );
      } on FileSystemException catch (error) {
        return ToolResult(
          success: false,
          output: 'Linux Workspace tidak dapat dimulakan: ${error.message}',
        );
      } on ProcessException catch (error) {
        return ToolResult(
          success: false,
          output: 'Pemeriksaan runtime Linux gagal memulakan proses: ${error.message}',
        );
      } on TimeoutException {
        return const ToolResult(
          success: false,
          output: 'Pemeriksaan runtime Linux tamat masa.',
        );
      } on OSError catch (error) {
        return ToolResult(
          success: false,
          output: 'Runtime Linux gagal disediakan: ${error.message}',
        );
      } catch (error) {
        return ToolResult(
          success: false,
          output: 'Runtime Linux gagal disediakan dengan selamat: $error',
        );
      }
      if (linux == null) {
        return const ToolResult(
          success: false,
          output: 'Runtime Linux bawaan APK tiada atau belum sah. Bina edisi Full melalui scripts/build_full.sh supaya Alpine ARM64 + PRoot dibundel secara automatik.',
        );
      }
    }
    final shell = Platform.isAndroid ? '/system/bin/sh' : '/bin/sh';
    Process process;
    try {
      process = await Process.start(
        linux?.executable ?? shell,
        linux?.arguments ?? <String>['-c', text],
        workingDirectory: linux?.hostWorkingDirectory ?? cwd.path,
        environment: linux?.environment ?? <String, String>{
          'HOME': root.path,
          'TMPDIR': p.join(root.path, '.tmp'),
          'PATH': Platform.environment['PATH'] ?? '/system/bin:/system/xbin',
          'LANG': 'C.UTF-8',
          ...environment,
        },
        includeParentEnvironment: false,
        runInShell: false,
      );
    } on ProcessException catch (error) {
      return ToolResult(
        success: false,
        output:
            'Proses terminal gagal dimulakan: ${error.message}. Semak runtime Shell ARM64.',
      );
    } on FileSystemException catch (error) {
      return ToolResult(
        success: false,
        output: 'Proses terminal gagal dimulakan: ${error.message}',
      );
    } on OSError catch (error) {
      return ToolResult(
        success: false,
        output: 'Proses terminal gagal dimulakan: ${error.message}',
      );
    }
    final job = TerminalJob(
      id: _uuid.v4(),
      command: text,
      workingDirectory: p.relative(cwd.path, from: root.path),
      startedAt: DateTime.now(),
      process: process,
    );
    _jobs[job.id] = job;
    process.stdout
        .transform(const Utf8Decoder(allowMalformed: true))
        .listen(
          job.stdout.write,
          onError: (Object error) => job.stderr.write('\n$error'),
        );
    process.stderr
        .transform(const Utf8Decoder(allowMalformed: true))
        .listen(
          job.stderr.write,
          onError: (Object error) => job.stderr.write('\n$error'),
        );
    unawaited(process.exitCode.then((code) {
      job.exitCode = code;
      job.finishedAt = DateTime.now();
    }));
    return ToolResult(
      success: true,
      output: jsonEncode(job.snapshot()),
      data: job.snapshot(),
    );
  }


  String? _androidHostBoundaryViolation(String command) {
    final normalized = command
        .replaceAll('\\', '/')
        .toLowerCase();
    const blockedPaths = <String>[
      '/sdcard',
      '/storage',
      '/mnt/media_rw',
      '/data/',
      '/system/',
      '/vendor/',
      '/product/',
      '/apex/',
      '/sys/',
      '/proc/cpuinfo',
      '/proc/meminfo',
      '/proc/version',
      '/proc/device-tree',
      '/proc/sys/kernel',
      '/dev/block',
      '/dev/input',
      '/dev/socket',
      '/dev/bus',
    ];
    if (blockedPaths.any(normalized.contains)) {
      return 'Akses di luar Shell sandbox tidak dibenarkan. Gunakan hanya /workspace atau /root.';
    }
    final hostCommand = RegExp(
      r'(^|[;&|]\s*)(getprop|setprop|dumpsys|pm|am|settings|cmd\s+package|uname|lscpu|lsmem|lsblk|lspci|lsusb|dmidecode|hwinfo)(\s|$)',
    );
    if (hostCommand.hasMatch(normalized)) {
      return 'Pemeriksaan host/peranti tidak dibenarkan melalui Shell. AI hanya dibenarkan menggunakan maklumat yang wujud di dalam sandbox.';
    }
    return null;
  }

  bool _isSystemPackageInstall(String command) {
    final normalized = command.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
    return RegExp(
      r'(^|[;&|]\s*)(sudo\s+)?(apt|apt-get|dpkg|pacman|apk|dnf|yum|zypper|emerge)\s+(install|add|-i|upgrade|dist-upgrade|full-upgrade)',
    ).hasMatch(normalized);
  }

  Future<ToolResult> poll(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) return const ToolResult(success: false, output: 'Job terminal tidak ditemui.');
    final snapshot = job.snapshot();
    return ToolResult(
      success: job.exitCode == null || job.exitCode == 0,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<ToolResult> stop(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) return const ToolResult(success: false, output: 'Job terminal tidak ditemui.');
    if (!job.running) return poll(jobId);
    await _stopJob(job);
    final snapshot = job.snapshot();
    return ToolResult(
      success: !job.running,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<void> stopAll() async {
    final running = _jobs.values.where((job) => job.running).toList(growable: false);
    await Future.wait(running.map(_stopJob));
  }

  Future<void> _stopJob(TerminalJob job) async {
    if (!job.running) return;
    final sent = job.process.kill(ProcessSignal.sigterm);
    if (!sent) job.process.kill(ProcessSignal.sigkill);
    try {
      final code = await job.process.exitCode.timeout(_gracefulStopTimeout);
      job.exitCode ??= code;
      job.finishedAt ??= DateTime.now();
      return;
    } on TimeoutException {
      job.process.kill(ProcessSignal.sigkill);
    }
    try {
      final code = await job.process.exitCode.timeout(_forcedStopTimeout);
      job.exitCode ??= code;
      job.finishedAt ??= DateTime.now();
    } on TimeoutException {
      job.stderr.write('\nProses tidak memberi respons selepas SIGKILL.');
    }
  }

  void _pruneCompletedJobs() {
    if (_jobs.length < _maxRetainedJobs) return;
    final completed = _jobs.values.where((job) => !job.running).toList()
      ..sort((a, b) => (a.finishedAt ?? a.startedAt).compareTo(b.finishedAt ?? b.startedAt));
    while (_jobs.length >= _maxRetainedJobs && completed.isNotEmpty) {
      _jobs.remove(completed.removeAt(0).id);
    }
  }

  Future<Directory> _workspace() async {
    final directory = Directory(p.join((await getApplicationSupportDirectory()).path, 'linux', 'workspace'));
    await directory.create(recursive: true);
    await Directory(p.join(directory.path, '.tmp')).create(recursive: true);
    return directory;
  }

  Directory _safeDirectory(Directory root, String relative) {
    final normalized = p.normalize(p.join(root.path, relative));
    if (normalized != root.path && !p.isWithin(root.path, normalized)) {
      throw const FileSystemException('Working directory di luar workspace tidak dibenarkan.');
    }
    return Directory(normalized);
  }

  void dispose() {
    unawaited(stopAll());
  }
}
