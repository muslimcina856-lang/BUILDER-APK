import 'dart:convert';
import 'dart:io';

import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;
import 'package:math_expressions/math_expressions.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../data/usage_guide.dart';
import '../models/app_models.dart';
import 'browser_session_service.dart';
import 'duckduckgo_search_service.dart';
import 'linux_workspace_service.dart';
import 'local_database.dart';
import 'mcp_service.dart';
import 'platform_bridge_service.dart';
import 'skill_service.dart';
import 'terminal_service.dart';
import 'windows_process_service.dart';
import 'windows_runtime_service.dart';

class _BrowserPage {
  const _BrowserPage({
    required this.id,
    required this.url,
    required this.title,
    required this.text,
    required this.html,
    required this.links,
  });

  final String id;
  final String url;
  final String title;
  final String text;
  final String html;
  final List<Map<String, String>> links;
}

class ToolEngine {
  ToolEngine(
    this.database, {
    http.Client? client,
    BrowserSessionService? browserSession,
    TerminalService? terminalService,
    LinuxWorkspaceService? linuxWorkspaceService,
    WindowsRuntimeService? windowsRuntimeService,
    WindowsProcessService? windowsProcessService,
    SkillService? skillService,
    McpService? mcpService,
    PlatformBridgeService? platformBridge,
    this.backgroundMode = false,
  })  : _client = client ?? http.Client(),
        browserSession = browserSession ?? BrowserSessionService(),
        terminalService = terminalService ?? TerminalService(),
        linuxWorkspaceService = linuxWorkspaceService ?? LinuxWorkspaceService(),
        windowsRuntimeService = windowsRuntimeService ?? WindowsRuntimeService(),
        windowsProcessService = windowsProcessService ?? WindowsProcessService(),
        skillService = skillService ?? SkillService(database),
        mcpService = mcpService ?? McpService(),
        platformBridge = platformBridge ?? PlatformBridgeService() {
    _searchService = DuckDuckGoSearchService(client: _client);
  }

  final LocalDatabase database;
  final http.Client _client;
  final BrowserSessionService browserSession;
  final TerminalService terminalService;
  final LinuxWorkspaceService linuxWorkspaceService;
  final WindowsRuntimeService windowsRuntimeService;
  final WindowsProcessService windowsProcessService;
  final SkillService skillService;
  final McpService mcpService;
  final PlatformBridgeService platformBridge;
  final bool backgroundMode;
  late final DuckDuckGoSearchService _searchService;
  static const _uuid = Uuid();
  final Map<String, _BrowserPage> _pages = <String, _BrowserPage>{};

  List<ToolDefinition> get definitions => <ToolDefinition>[
        const ToolDefinition(
          id: 'web_search',
          name: 'DuckDuckGo Search',
          category: 'Web',
          risk: ToolRisk.readOnly,
          description: 'Cari web menggunakan DuckDuckGo. Pulangkan hasil penuh dengan ranking, tajuk, URL, domain dan petikan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'query': <String, dynamic>{'type': 'string'},
              'max_results': <String, dynamic>{'type': 'integer', 'minimum': 1, 'maximum': 20},
              'region': <String, dynamic>{'type': 'string', 'description': 'Contoh wt-wt, my-en, us-en.'},
              'safe_search': <String, dynamic>{'type': 'string', 'enum': <String>['off', 'moderate', 'strict']},
              'time_range': <String, dynamic>{'type': 'string', 'description': 'Kosong, d, w, m atau y.'},
            },
            'required': <String>['query'],
          },
        ),
        const ToolDefinition(
          id: 'browser_open',
          name: 'Buka Browser Latar',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Buka URL dalam browser latar sandbox. Mod desktop diaktifkan secara lalai dan boleh ditutup untuk laman mudah alih.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'desktop_mode': <String, dynamic>{
                'type': 'boolean',
                'description': 'true untuk emulasi browser desktop/PC; false untuk paparan mudah alih.',
              },
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'browser_read',
          name: 'Baca Halaman Aktif',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Baca tajuk, URL, teks, HTML, pautan dan borang daripada halaman browser latar yang aktif.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'browser_screenshot',
          name: 'Screenshot Browser',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Ambil screenshot PNG penuh halaman browser latar dan paparkannya sebagai artifact imej dalam chat. Screenshot browser sentiasa cuba merangkumi keseluruhan halaman, bukan crop viewport sahaja.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'browser_follow_link',
          name: 'Ikut Pautan',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Buka pautan daripada page_id dan indeks hasil browser.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'page_id': <String, dynamic>{'type': 'string'},
              'link_index': <String, dynamic>{'type': 'integer'},
            },
            'required': <String>['page_id', 'link_index'],
          },
        ),
        const ToolDefinition(
          id: 'browser_click',
          name: 'Klik Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description: 'Klik elemen halaman latar menggunakan CSS selector atau teks butang/pautan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'selector': <String, dynamic>{'type': 'string'},
              'text': <String, dynamic>{'type': 'string'},
            },
          },
        ),
        const ToolDefinition(
          id: 'browser_fill',
          name: 'Isi Input Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description: 'Isi input pada halaman browser latar menggunakan CSS selector.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'selector': <String, dynamic>{'type': 'string'},
              'value': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['selector', 'value'],
          },
        ),
        const ToolDefinition(
          id: 'browser_submit_form',
          name: 'Hantar Borang Browser',
          category: 'Browser',
          risk: ToolRisk.externalWrite,
          description: 'Hantar borang dalam browser latar. Tindakan biasa berjalan terus; pemadaman data tetap melalui polisi risiko.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'selector': <String, dynamic>{'type': 'string'}},
          },
        ),
        const ToolDefinition(
          id: 'browser_download',
          name: 'Muat Turun Fail',
          category: 'Browser',
          risk: ToolRisk.localWrite,
          description: 'Muat turun URL ke folder workspace tempatan aplikasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'filename': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'media_preview',
          name: 'Pratonton Media URL',
          category: 'Media',
          risk: ToolRisk.readOnly,
          description:
              'Hantar gambar, video atau audio daripada URL HTTP/HTTPS terus sebagai pratonton chat tanpa menyimpan fail ke storan. Gunakan sebelum browser_download apabila pengguna mahu melihat atau memainkan media dahulu.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'kind': <String, dynamic>{
                'type': 'string',
                'enum': <String>['image', 'video', 'audio'],
              },
              'title': <String, dynamic>{'type': 'string'},
              'mime_type': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'open_url',
          name: 'Buka URL Latar',
          category: 'Browser',
          risk: ToolRisk.readOnly,
          description: 'Buka URL dalam browser latar dan pulangkan ringkasan halaman kepada chat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'url': <String, dynamic>{'type': 'string'},
              'desktop_mode': <String, dynamic>{
                'type': 'boolean',
                'description': 'true untuk emulasi browser desktop/PC.',
              },
            },
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'http_request',
          name: 'HTTP Request',
          category: 'Web',
          risk: ToolRisk.externalWrite,
          description: 'Hantar permintaan HTTP. Hanya operasi yang dikesan destruktif akan meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'method': <String, dynamic>{'type': 'string'},
              'url': <String, dynamic>{'type': 'string'},
              'headers': <String, dynamic>{'type': 'object'},
              'body': <String, dynamic>{},
            },
            'required': <String>['method', 'url'],
          },
        ),
        const ToolDefinition(
          id: 'file_list',
          name: 'Senarai Fail',
          category: 'Fail',
          risk: ToolRisk.readOnly,
          description: 'Senaraikan fail dalam workspace tempatan aplikasi.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{'path': <String, dynamic>{'type': 'string'}}},
        ),
        const ToolDefinition(
          id: 'file_read',
          name: 'Baca Fail',
          category: 'Fail',
          risk: ToolRisk.readOnly,
          description: 'Baca kandungan fail teks daripada workspace tempatan aplikasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'path': <String, dynamic>{'type': 'string'}},
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'file_write',
          name: 'Tulis Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Tulis fail dalam workspace. Fail baharu terus ditulis; penimpaan fail sedia ada meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'content': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['path', 'content'],
          },
        ),
        const ToolDefinition(
          id: 'file_copy',
          name: 'Salin Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Salin fail dalam workspace. Penimpaan destinasi meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'source': <String, dynamic>{'type': 'string'},
              'destination': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['source', 'destination'],
          },
        ),
        const ToolDefinition(
          id: 'file_move',
          name: 'Pindah Fail',
          category: 'Fail',
          risk: ToolRisk.localWrite,
          description: 'Pindah atau namakan semula fail. Penimpaan destinasi meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'source': <String, dynamic>{'type': 'string'},
              'destination': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['source', 'destination'],
          },
        ),
        const ToolDefinition(
          id: 'file_delete',
          name: 'Padam Fail',
          category: 'Fail',
          risk: ToolRisk.sensitive,
          description: 'Padam fail atau folder dalam workspace. Tindakan ini sentiasa dianggap berisiko.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'recursive': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'memory_search',
          name: 'Cari Memori',
          category: 'Memori',
          risk: ToolRisk.readOnly,
          description: 'Cari rekod memori tempatan berdasarkan kata kunci.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'query': <String, dynamic>{'type': 'string'}},
            'required': <String>['query'],
          },
        ),
        const ToolDefinition(
          id: 'memory_add',
          name: 'Tambah Memori',
          category: 'Memori',
          risk: ToolRisk.localWrite,
          description: 'Simpan fakta atau nota ke memori tempatan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'title': <String, dynamic>{'type': 'string'},
              'content': <String, dynamic>{'type': 'string'},
              'tags': <String, dynamic>{'type': 'array', 'items': <String, dynamic>{'type': 'string'}},
            },
            'required': <String>['title', 'content'],
          },
        ),
        const ToolDefinition(
          id: 'memory_delete',
          name: 'Padam Memori',
          category: 'Memori',
          risk: ToolRisk.sensitive,
          description: 'Padam satu rekod memori tempatan menggunakan ID.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'id': <String, dynamic>{'type': 'string'}},
            'required': <String>['id'],
          },
        ),
        const ToolDefinition(
          id: 'linux_workspace_status',
          name: 'Status Linux Workspace',
          category: 'Terminal',
          risk: ToolRisk.readOnly,
          description: 'Semak pemasangan automatik Alpine Linux ARM64 melalui PRoot, versi manifest, status kesihatan, storan private dan pengurus pakej apk.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'terminal_start',
          name: 'Terminal Latar Belakang',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description: 'Pasang runtime Alpine ARM64 bawaan jika perlu, jalankan arahan shell melalui PRoot dalam /workspace, dan pulangkan job_id. Gunakan apk untuk pakej; arahan destruktif meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'command': <String, dynamic>{'type': 'string'},
              'working_directory': <String, dynamic>{'type': 'string'},
              'environment': <String, dynamic>{'type': 'object'},
            },
            'required': <String>['command'],
          },
        ),
        const ToolDefinition(
          id: 'terminal_poll',
          name: 'Pantau Terminal',
          category: 'Terminal',
          risk: ToolRisk.readOnly,
          description: 'Baca stdout, stderr, status dan exit code job terminal supaya AI boleh melihat proses latar belakang.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'job_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['job_id'],
          },
        ),
        const ToolDefinition(
          id: 'terminal_stop',
          name: 'Hentikan Terminal',
          category: 'Terminal',
          risk: ToolRisk.localWrite,
          description: 'Hentikan job terminal latar belakang.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'job_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['job_id'],
          },
        ),
        const ToolDefinition(
          id: 'windows_runtime_status',
          name: 'Status PC Windows',
          category: 'Windows',
          risk: ToolRisk.readOnly,
          description: 'Semak status PC Windows local: Ubuntu ARM64, Box64, Wine WoW64, prefix Windows dan desktop headless.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'windows_install',
          name: 'Pasang PC Windows',
          category: 'Windows',
          risk: ToolRisk.localWrite,
          description: 'Muat turun dan sediakan PC Windows local pada penggunaan pertama. Ubuntu Base dan Wine disahkan checksum; Box64 dipasang daripada repository bertandatangan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'windows_run_cmd',
          name: 'Jalankan Windows CMD',
          category: 'Windows',
          risk: ToolRisk.localWrite,
          description: 'Jalankan arahan cmd.exe melalui Wine + Box64 dalam PC Windows local dan pulangkan job_id.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'command': <String, dynamic>{'type': 'string'},
              'working_directory': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['command'],
          },
        ),
        const ToolDefinition(
          id: 'windows_run_exe',
          name: 'Jalankan Windows EXE',
          category: 'Windows',
          risk: ToolRisk.localWrite,
          description: 'Jalankan fail .exe daripada /workspace, lampiran chat atau drive C: Wine melalui Wine + Box64 dan pulangkan job_id.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'path': <String, dynamic>{'type': 'string'},
              'arguments': <String, dynamic>{
                'type': 'array',
                'items': <String, dynamic>{'type': 'string'},
              },
              'working_directory': <String, dynamic>{'type': 'string'},
            },
            'required': <String>['path'],
          },
        ),
        const ToolDefinition(
          id: 'windows_poll',
          name: 'Pantau PC Windows',
          category: 'Windows',
          risk: ToolRisk.readOnly,
          description: 'Baca stdout, stderr, status dan exit code job Windows.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'job_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['job_id'],
          },
        ),
        const ToolDefinition(
          id: 'windows_stop',
          name: 'Hentikan PC Windows',
          category: 'Windows',
          risk: ToolRisk.localWrite,
          description: 'Hentikan job Windows yang sedang berjalan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'job_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['job_id'],
          },
        ),
        const ToolDefinition(
          id: 'windows_screenshot',
          name: 'Screenshot PC Windows',
          category: 'Windows',
          risk: ToolRisk.readOnly,
          description: 'Ambil screenshot desktop 1280x720 daripada proses Windows GUI yang sedang aktif dan lampirkan PNG ke chat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'windows_list_windows',
          name: 'Senarai Tetingkap Windows',
          category: 'Windows',
          risk: ToolRisk.readOnly,
          description: 'Senaraikan window_id dan tajuk tetingkap GUI Windows yang kelihatan pada desktop local.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{},
          },
        ),
        const ToolDefinition(
          id: 'windows_ui_action',
          name: 'Kawal GUI Windows',
          category: 'Windows',
          risk: ToolRisk.localWrite,
          description: 'Kawal PC Windows secara penuh dalam sandbox: tetikus, semua klik asas, mouse down/up, scroll, drag, taip, hotkey, clipboard, fokus serta urus tetingkap (aktif, minimum, maksimum, restore, tutup, gerak, resize, show desktop). Gunakan windows_screenshot sebelum/selepas tindakan untuk mengesahkan hasil.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'action': <String, dynamic>{
                'type': 'string',
                'enum': <String>[
                  'move',
                  'click',
                  'double_click',
                  'right_click',
                  'middle_click',
                  'mouse_down',
                  'mouse_up',
                  'scroll',
                  'drag',
                  'type',
                  'key',
                  'hotkey',
                  'focus',
                  'activate_window',
                  'minimize_window',
                  'maximize_window',
                  'restore_window',
                  'close_window',
                  'move_window',
                  'resize_window',
                  'show_desktop',
                  'clipboard_set',
                  'clipboard_get',
                ],
              },
              'x': <String, dynamic>{'type': 'integer', 'minimum': 0, 'maximum': 1279},
              'y': <String, dynamic>{'type': 'integer', 'minimum': 0, 'maximum': 719},
              'to_x': <String, dynamic>{'type': 'integer', 'minimum': 0, 'maximum': 1279},
              'to_y': <String, dynamic>{'type': 'integer', 'minimum': 0, 'maximum': 719},
              'button': <String, dynamic>{'type': 'integer', 'minimum': 1, 'maximum': 7},
              'scroll_y': <String, dynamic>{
                'type': 'integer',
                'minimum': -40,
                'maximum': 40,
                'description': 'Positif = scroll ke bawah, negatif = scroll ke atas.',
              },
              'scroll_x': <String, dynamic>{
                'type': 'integer',
                'minimum': -40,
                'maximum': 40,
                'description': 'Positif = scroll ke kanan, negatif = scroll ke kiri.',
              },
              'text': <String, dynamic>{'type': 'string'},
              'key': <String, dynamic>{'type': 'string'},
              'window_id': <String, dynamic>{'type': 'string'},
              'width': <String, dynamic>{'type': 'integer', 'minimum': 100, 'maximum': 1280},
              'height': <String, dynamic>{'type': 'integer', 'minimum': 100, 'maximum': 720},
            },
            'required': <String>['action'],
          },
        ),
        const ToolDefinition(
          id: 'skill_create',
          name: 'Cipta Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description: 'Cipta atau kemas kini skill local daripada nama, penerangan, arahan dan senarai tools. Skill Creator terbina dalam menggunakan tool ini apabila pengguna meminta kebolehan baharu.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'id': <String, dynamic>{'type': 'string', 'description': 'ID pilihan. Kosongkan untuk jana ID.'},
              'name': <String, dynamic>{'type': 'string'},
              'description': <String, dynamic>{'type': 'string'},
              'instructions': <String, dynamic>{'type': 'string'},
              'tool_ids': <String, dynamic>{
                'type': 'array',
                'items': <String, dynamic>{'type': 'string'},
              },
              'enabled': <String, dynamic>{'type': 'boolean'},
            },
            'required': <String>['name', 'description', 'instructions'],
          },
        ),
        const ToolDefinition(
          id: 'skill_install_url',
          name: 'Pasang Skill dari URL',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description: 'Muat turun, sahkan dan pasang arkib ZIP skill secara automatik ke storan aplikasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'url': <String, dynamic>{'type': 'string'}},
            'required': <String>['url'],
          },
        ),
        const ToolDefinition(
          id: 'skill_run_script',
          name: 'Jalankan Skrip Skill',
          category: 'Skills',
          risk: ToolRisk.localWrite,
          description: 'Salin skill ke sandbox workspace dan jalankan skrip melalui terminal latar belakang.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'skill_id': <String, dynamic>{'type': 'string'},
              'script': <String, dynamic>{'type': 'string'},
              'arguments': <String, dynamic>{'type': 'array', 'items': <String, dynamic>{'type': 'string'}},
            },
            'required': <String>['skill_id', 'script'],
          },
        ),
        const ToolDefinition(
          id: 'mcp_list_tools',
          name: 'Senarai Tools MCP Local',
          category: 'MCP',
          risk: ToolRisk.readOnly,
          description: 'Senaraikan tools daripada server MCP local yang telah dikonfigurasi.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'server_id': <String, dynamic>{'type': 'string'}},
            'required': <String>['server_id'],
          },
        ),
        const ToolDefinition(
          id: 'mcp_call',
          name: 'Panggil Tool MCP Local',
          category: 'MCP',
          risk: ToolRisk.externalWrite,
          description: 'Panggil tool pada server MCP local. Nama/argumen destruktif meminta kelulusan.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{
              'server_id': <String, dynamic>{'type': 'string'},
              'tool_name': <String, dynamic>{'type': 'string'},
              'arguments': <String, dynamic>{'type': 'object'},
            },
            'required': <String>['server_id', 'tool_name'],
          },
        ),
        const ToolDefinition(
          id: 'calculator',
          name: 'Kalkulator',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Kira ungkapan matematik asas dengan tepat.',
          parameters: <String, dynamic>{
            'type': 'object',
            'properties': <String, dynamic>{'expression': <String, dynamic>{'type': 'string'}},
            'required': <String>['expression'],
          },
        ),
        const ToolDefinition(
          id: 'app_usage_guide',
          name: 'Cara Guna Aplikasi',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Baca panduan rasmi cara menggunakan chat, browser, media, Linux Workspace, fail dan sub-agent dalam aplikasi.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'runtime_info',
          name: 'Konteks Sandbox',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Dapatkan konteks operasi sandbox: status Shell, PC Windows, browser latar dan laluan kerja yang dibenarkan.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
        const ToolDefinition(
          id: 'current_time',
          name: 'Masa Semasa',
          category: 'Utiliti',
          risk: ToolRisk.readOnly,
          description: 'Dapatkan tarikh dan masa semasa untuk tugasan.',
          parameters: <String, dynamic>{'type': 'object', 'properties': <String, dynamic>{}},
        ),
      ];

  ToolDefinition? definition(String id) {
    for (final item in definitions) {
      if (item.id == id) return item;
    }
    return null;
  }

  Future<bool> requiresPermission(String toolId, Map<String, dynamic> arguments) async {
    if (<String>{'memory_delete', 'file_delete'}.contains(toolId)) return true;
    if (toolId == 'file_write') return _workspaceEntityExists(arguments['path']?.toString() ?? '');
    if (toolId == 'file_copy' || toolId == 'file_move') {
      return _workspaceEntityExists(arguments['destination']?.toString() ?? '');
    }
    if (toolId == 'terminal_start') {
      return terminalService.isDestructiveCommand(arguments['command']?.toString() ?? '');
    }
    if (toolId == 'windows_run_cmd') {
      return windowsProcessService.isDestructiveCommand(
        arguments['command']?.toString() ?? '',
      );
    }
    if (toolId == 'http_request') {
      final method = arguments['method']?.toString().toUpperCase() ?? 'GET';
      return method == 'DELETE' || _looksDestructive('${arguments['url']} ${arguments['body']}');
    }
    if (toolId == 'mcp_call') {
      return _looksDestructive('${arguments['tool_name']} ${jsonEncode(arguments['arguments'] ?? const <String, dynamic>{})}');
    }
    return false;
  }

  String permissionScope(String toolId, Map<String, dynamic> arguments) {
    if (toolId == 'http_request') {
      return Uri.tryParse(arguments['url']?.toString() ?? '')?.host.toLowerCase() ?? 'web';
    }
    if (toolId.startsWith('file_')) {
      return arguments['path']?.toString() ?? arguments['destination']?.toString() ?? 'workspace';
    }
    if (toolId.startsWith('memory_')) return 'local-memory';
    if (toolId.startsWith('terminal_')) return 'terminal-sandbox';
    if (toolId.startsWith('windows_')) return 'windows-local';
    if (toolId.startsWith('mcp_')) return arguments['server_id']?.toString() ?? 'mcp-local';
    return '*';
  }

  String permissionDescription(String toolId, Map<String, dynamic> arguments) {
    switch (toolId) {
      case 'file_write':
        return 'Fail ${arguments['path']} sudah wujud dan akan ditimpa.';
      case 'file_copy':
      case 'file_move':
        return 'Destinasi ${arguments['destination']} sudah wujud dan akan diganti.';
      case 'file_delete':
        return 'Padam ${arguments['path']} daripada workspace tempatan.';
      case 'memory_delete':
        return 'Padam memori ${arguments['id']}.';
      case 'terminal_start':
        return 'Jalankan arahan terminal berisiko: ${arguments['command']}';
      case 'windows_run_cmd':
        return 'Jalankan arahan Windows berisiko: ${arguments['command']}';
      case 'http_request':
        return 'Hantar operasi HTTP destruktif ${arguments['method']} ke ${arguments['url']}.';
      case 'mcp_call':
        return 'Panggil tool MCP yang dikesan berisiko: ${arguments['tool_name']}.';
      default:
        return 'Jalankan tindakan berisiko $toolId.';
    }
  }

  Future<ToolResult> execute(String toolId, Map<String, dynamic> arguments) async {
    try {
      return switch (toolId) {
        'web_search' => _webSearch(arguments),
        'browser_open' => _browserOpen(
            arguments['url']?.toString() ?? '',
            desktopMode: arguments['desktop_mode'] as bool? ?? true,
          ),
        'browser_read' => _browserRead(),
        'browser_screenshot' => _browserScreenshot(),
        'browser_follow_link' => _browserFollow(arguments),
        'browser_click' => _browserAction('click', arguments),
        'browser_fill' => _browserAction('fill', arguments),
        'browser_submit_form' => _browserAction('submit', arguments),
        'browser_download' => _browserDownload(arguments),
        'media_preview' => _mediaPreview(arguments),
        'open_url' => _openUrl(arguments),
        'http_request' => _httpRequest(arguments),
        'file_list' => _fileList(arguments),
        'file_read' => _fileRead(arguments),
        'file_write' => _fileWrite(arguments),
        'file_copy' => _fileCopy(arguments),
        'file_move' => _fileMove(arguments),
        'file_delete' => _fileDelete(arguments),
        'memory_search' => _memorySearch(arguments),
        'memory_add' => _memoryAdd(arguments),
        'memory_delete' => _memoryDelete(arguments),
        'linux_workspace_status' => _linuxWorkspaceStatus(),
        'terminal_start' => terminalService.start(
            command: arguments['command']?.toString() ?? '',
            workingDirectory: arguments['working_directory']?.toString() ?? '.',
            environment: Map<String, String>.from(arguments['environment'] as Map? ?? const <String, String>{}),
          ),
        'terminal_poll' => terminalService.poll(arguments['job_id']?.toString() ?? ''),
        'terminal_stop' => terminalService.stop(arguments['job_id']?.toString() ?? ''),
        'windows_runtime_status' => _windowsRuntimeStatus(),
        'windows_install' => _windowsInstall(),
        'windows_run_cmd' => windowsProcessService.startCommand(
            command: arguments['command']?.toString() ?? '',
            workingDirectory: arguments['working_directory']?.toString() ?? '.',
          ),
        'windows_run_exe' => windowsProcessService.startExecutable(
            path: arguments['path']?.toString() ?? '',
            arguments: (arguments['arguments'] as List? ?? const <dynamic>[])
                .map((item) => item.toString())
                .toList(growable: false),
            workingDirectory: arguments['working_directory']?.toString() ?? '.',
          ),
        'windows_poll' => windowsProcessService.poll(arguments['job_id']?.toString() ?? ''),
        'windows_stop' => windowsProcessService.stop(arguments['job_id']?.toString() ?? ''),
        'windows_screenshot' => _windowsScreenshot(),
        'windows_list_windows' => windowsProcessService.listWindows(),
        'windows_ui_action' => windowsProcessService.uiAction(
            action: arguments['action']?.toString() ?? '',
            x: (arguments['x'] as num?)?.toInt(),
            y: (arguments['y'] as num?)?.toInt(),
            toX: (arguments['to_x'] as num?)?.toInt(),
            toY: (arguments['to_y'] as num?)?.toInt(),
            button: (arguments['button'] as num?)?.toInt(),
            scrollY: (arguments['scroll_y'] as num?)?.toInt(),
            scrollX: (arguments['scroll_x'] as num?)?.toInt(),
            width: (arguments['width'] as num?)?.toInt(),
            height: (arguments['height'] as num?)?.toInt(),
            text: arguments['text']?.toString() ?? '',
            key: arguments['key']?.toString() ?? '',
            windowId: arguments['window_id']?.toString() ?? '',
          ),
        'skill_create' => _skillCreate(arguments),
        'skill_install_url' => _skillInstall(arguments),
        'skill_run_script' => _skillRunScript(arguments),
        'mcp_list_tools' => _mcpListTools(arguments),
        'mcp_call' => _mcpCall(arguments),
        'calculator' => _calculator(arguments),
        'app_usage_guide' => Future<ToolResult>.value(
            ToolResult(
              success: true,
              output: UsageGuide.asPlainText(),
              data: UsageGuide.toMap(),
            ),
          ),
        'runtime_info' => _runtimeInfo(),
        'current_time' => Future<ToolResult>.value(ToolResult(success: true, output: DateTime.now().toIso8601String())),
        _ => Future<ToolResult>.value(ToolResult(success: false, output: 'Tool tidak dikenali: $toolId')),
      };
    } catch (error) {
      return ToolResult(success: false, output: error.toString());
    }
  }

  Future<Map<String, dynamic>> runtimeContextSnapshot() async {
    final linux = await linuxWorkspaceService.status();
    final windows = await windowsRuntimeService.status(includeSize: false);
    final mcpServers = (await database.listObjects('mcp_server'))
        .map(McpServerConfig.fromJson)
        .where((server) => server.enabled)
        .map(
          (server) => <String, dynamic>{
            'id': server.id,
            'name': server.name,
            'baseUrl': server.baseUrl,
            'transport': server.transport.name,
          },
        )
        .toList();
    return <String, dynamic>{
      'sandboxOnly': true,
      'browser': <String, dynamic>{
        'sessionActive': browserSession.isRunning,
        'currentUrl': browserSession.currentUrl,
        'desktopMode': browserSession.desktopMode,
        'completedActions': browserSession.completedActions,
        'fullPageScreenshot': true,
      },
      'configuredMcpServers': mcpServers,
      'windowsPcToolsRequireConfiguredMcp': false,
      'remoteWindowsPcToolsRequireConfiguredMcp': true,
      'localWindowsRuntime': <String, dynamic>{
        'availableInEdition': AppConfig.isFullEdition,
        'ready': windows.ready,
        'healthStatus': windows.healthStatus,
        'installedRuntimeVersion': windows.runtimeVersion,
        'expectedRuntimeVersion': AppConfig.isFullEdition
            ? WindowsRuntimeService.expectedRuntimeVersion
            : null,
        'guestBaseArchitecture': WindowsRuntimeService.expectedArchitecture,
        'compatibilityEngine': 'Wine WoW64 + Box64',
        'wineVersion': windows.wineVersion,
        'box64Version': windows.box64Version,
        'automaticInstallOnFirstWorkspaceEntry': AppConfig.isFullEdition,
        'automaticInstallOnFirstWindowsTool': AppConfig.isFullEdition,
        'exeFromWorkspace': true,
        'exeFromChatAttachments': true,
        'workspacePath': '/workspace',
        'attachmentsPath': '/attachments',
        'desktopDisplay': WindowsRuntimeService.displayName,
        'desktopWidth': WindowsRuntimeService.desktopWidth,
        'desktopHeight': WindowsRuntimeService.desktopHeight,
        'screenshotSupported': true,
        'screenshotMode': 'full_desktop',
        'guiControlSupported': true,
        'guiActions': <String>[
          'move',
          'click',
          'double_click',
          'right_click',
          'middle_click',
          'mouse_down',
          'mouse_up',
          'scroll',
          'drag',
          'type',
          'key',
          'hotkey',
          'focus',
          'activate_window',
          'minimize_window',
          'maximize_window',
          'restore_window',
          'close_window',
          'move_window',
          'resize_window',
          'show_desktop',
          'clipboard_set',
          'clipboard_get',
        ],
        'windowsWorkspacePath': 'W:\\',
        'windowsAttachmentsPath': 'A:\\',
        'fullWindowsKernelOrVm': false,
        'remotePcAccess': false,
      },
      'linuxWorkspace': <String, dynamic>{
        'availableInEdition': AppConfig.isFullEdition,
        'ready': linux.ready,
        'healthStatus': linux.healthStatus,
        'installedRuntimeVersion': linux.runtimeVersion,
        'expectedRuntimeVersion': AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedRuntimeVersion
            : null,
        'distribution': linux.distribution.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedDistribution
            : linux.distribution,
        'distributionVersion':
            linux.distributionVersion.isEmpty && AppConfig.isFullEdition
                ? LinuxWorkspaceService.expectedDistributionVersion
                : linux.distributionVersion,
        'guestArchitecture': linux.architecture.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedArchitecture
            : linux.architecture,
        'packageManager': linux.packageManager.isEmpty && AppConfig.isFullEdition
            ? LinuxWorkspaceService.expectedPackageManager
            : linux.packageManager,
        'automaticInstallOnFirstCommand': AppConfig.isFullEdition,
        'workspacePath': '/workspace',
        'homePath': '/root',
        'persistentWorkspace': true,
        'interactiveStdin': false,
        'maxConcurrentJobs': 8,
        'maxRetainedJobs': 64,
        'sudoRequired': false,
        'remotePcAccess': false,
      },
    };
  }

  Future<ToolResult> _runtimeInfo() async {
    final data = await runtimeContextSnapshot();
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(data),
      data: data,
    );
  }

  Future<ToolResult> _windowsRuntimeStatus() async {
    final status = await windowsRuntimeService.status();
    final data = <String, dynamic>{
      'edition': AppConfig.editionName,
      'ready': status.ready,
      'rootfs_ready': status.rootfsReady,
      'box64_ready': status.box64Ready,
      'wine_ready': status.wineReady,
      'prefix_ready': status.prefixReady,
      'manifest_valid': status.manifestValid,
      'health_status': status.healthStatus,
      'runtime_version': status.runtimeVersion,
      'expected_runtime_version': WindowsRuntimeService.expectedRuntimeVersion,
      'distribution': WindowsRuntimeService.expectedDistribution,
      'distribution_version': WindowsRuntimeService.expectedDistributionVersion,
      'guest_base_architecture': WindowsRuntimeService.expectedArchitecture,
      'box64_version': status.box64Version,
      'wine_version': status.wineVersion,
      'wine_mode': 'wow64',
      'workspace_path': '/workspace',
      'attachments_path': '/attachments',
      'allowed_windows_drives': <String>['C:', 'W:', 'A:'],
      'windows_root_drive_z_available': false,
      'display': WindowsRuntimeService.displayName,
      'desktop_size': '${WindowsRuntimeService.desktopWidth}x${WindowsRuntimeService.desktopHeight}',
      'automatic_install': AppConfig.isFullEdition,
      'used_bytes': status.usedBytes,
      'full_windows_kernel_or_vm': false,
      'remote_pc_access': false,
    };
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(data),
      data: data,
    );
  }

  Future<ToolResult> _windowsInstall() async {
    try {
      final status = await windowsRuntimeService.ensureReady();
      if (status.ready) {
        await windowsProcessService.activateDesktop();
      }
      final data = <String, dynamic>{
        'ready': status.ready,
        'health_status': status.healthStatus,
        'runtime_version': status.runtimeVersion,
        'box64_version': status.box64Version,
        'wine_version': status.wineVersion,
        'used_bytes': status.usedBytes,
      };
      return ToolResult(
        success: status.ready,
        output: status.ready
            ? 'PC Windows local siap digunakan melalui Wine WoW64 + Box64.'
            : 'PC Windows belum bersedia.',
        data: data,
      );
    } catch (error) {
      return ToolResult(
        success: false,
        output: 'Pemasangan PC Windows gagal: $error',
      );
    }
  }

  Future<ToolResult> _windowsScreenshot() async {
    final result = await windowsProcessService.screenshot();
    final path = result.data['path']?.toString() ?? '';
    if (!result.success || path.isEmpty) return result;
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: ArtifactKind.image,
      title: 'Screenshot PC Windows',
      subtitle: '${WindowsRuntimeService.desktopWidth}×${WindowsRuntimeService.desktopHeight} · Wine + Box64',
      localPath: path,
      mimeType: 'image/png',
      data: <String, dynamic>{
        'width': WindowsRuntimeService.desktopWidth,
        'height': WindowsRuntimeService.desktopHeight,
      },
    );
    return ToolResult(
      success: true,
      output: 'Screenshot penuh desktop PC Windows tersedia sebagai PNG.',
      data: <String, dynamic>{
        'mime': 'image/png',
        'width': WindowsRuntimeService.desktopWidth,
        'height': WindowsRuntimeService.desktopHeight,
        'fullDesktop': true,
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _linuxWorkspaceStatus() async {
    final status = await linuxWorkspaceService.status();
    final data = <String, dynamic>{
      'edition': AppConfig.editionName,
      'runtime_ready': status.runtimeReady,
      'rootfs_ready': status.rootfsReady,
      'manifest_valid': status.manifestValid,
      'ready': status.ready,
      'health_status': status.healthStatus,
      'runtime_version': status.runtimeVersion,
      'distribution': status.distribution,
      'distribution_version': status.distributionVersion,
      'guest_architecture': status.architecture,
      'package_manager': status.packageManager,
      'shell': '/bin/sh',
      'workspace_path': '/workspace',
      'home_path': '/root',
      'persistent_workspace': true,
      'interactive_stdin': false,
      'sudo_required': false,
      'automatic_install': AppConfig.isFullEdition,
      'bundled_asset': AppConfig.isFullEdition
          ? LinuxWorkspaceService.bundledRuntimeAsset
          : null,
      'used_bytes': status.usedBytes,
      'package_install_enabled': status.packageInstallEnabled,
      'storage': 'sandbox_private_storage',
      'remote_pc_access': false,
    };
    return ToolResult(
      success: true,
      output: const JsonEncoder.withIndent('  ').convert(data),
      data: data,
    );
  }

  Future<ToolResult> _webSearch(Map<String, dynamic> arguments) async {
    final response = await _searchService.search(
      query: arguments['query']?.toString() ?? '',
      maxResults: (arguments['max_results'] as num?)?.toInt() ?? 10,
      region: arguments['region']?.toString() ?? 'wt-wt',
      safeSearch: arguments['safe_search']?.toString() ?? 'moderate',
      timeRange: arguments['time_range']?.toString() ?? '',
    );
    final raw = response.toJson();
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: ArtifactKind.searchResults,
      title: 'Hasil carian: ${arguments['query']?.toString() ?? ''}',
      subtitle: '${response.results.length} hasil DuckDuckGo',
      data: raw,
    );
    return ToolResult(
      success: true,
      output: response.prettyJson(),
      data: <String, dynamic>{...raw, 'artifact': artifact.toJson()},
    );
  }

  Future<ToolResult> _browserOpen(
    String rawUrl, {
    bool desktopMode = true,
  }) async {
    final uri = _validatedHttpUri(rawUrl);
    if (backgroundMode) {
      return _browserOpenHttp(uri, desktopMode: desktopMode);
    }
    final result = await browserSession.execute(
      BrowserAction(
        type: 'open',
        arguments: <String, dynamic>{
          'url': uri.toString(),
          'desktopMode': desktopMode,
        },
      ),
    );
    return _storeBrowserPage(result);
  }

  Future<ToolResult> _browserRead() async {
    if (backgroundMode) {
      if (_pages.isEmpty) {
        return const ToolResult(
          success: false,
          output: 'Tiada halaman aktif dalam automasi background. Gunakan browser_open dengan URL.',
        );
      }
      final page = _pages.values.last;
      return _pageResult(page, mode: 'background-cache');
    }
    final result = await browserSession.execute(
      BrowserAction(type: 'read', arguments: const <String, dynamic>{}),
    );
    return _storeBrowserPage(result);
  }

  Future<ToolResult> _browserScreenshot() async {
    if (backgroundMode) {
      return const ToolResult(
        success: false,
        output: 'Screenshot WebView memerlukan proses aplikasi aktif.',
      );
    }
    final result = await browserSession.execute(
      const BrowserAction(type: 'screenshot', arguments: <String, dynamic>{}),
    );
    final path = result['path']?.toString() ?? '';
    if (path.isEmpty) {
      return ToolResult(
        success: false,
        output: result['error']?.toString() ?? 'Screenshot browser gagal.',
        data: result,
      );
    }
    final title = result['title']?.toString().trim() ?? '';
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: ArtifactKind.image,
      title: title.isEmpty ? 'Screenshot halaman web' : title,
      subtitle: result['url']?.toString() ?? '',
      localPath: path,
      mimeType: result['mime']?.toString() ?? 'image/png',
      data: <String, dynamic>{
        'width': result['width'],
        'height': result['height'],
      },
    );
    final data = <String, dynamic>{
      'url': result['url'],
      'title': result['title'],
      'mime': result['mime'] ?? 'image/png',
      'width': result['width'],
      'height': result['height'],
      'documentWidth': result['documentWidth'],
      'documentHeight': result['documentHeight'],
      'fullPage': true,
      'scaled': result['scaled'] == true,
      'artifact': artifact.toJson(),
    };
    return ToolResult(
      success: true,
      output: 'Screenshot penuh halaman telah disediakan sebagai gambar PNG.',
      data: data,
    );
  }

  Future<ToolResult> _browserAction(
    String type,
    Map<String, dynamic> arguments,
  ) async {
    if (backgroundMode) {
      return ToolResult(
        success: false,
        output: 'Interaksi DOM memerlukan proses aplikasi aktif. Browser masih tidak dipaparkan kepada pengguna.',
      );
    }
    final result = await browserSession.execute(
      BrowserAction(type: type, arguments: arguments),
    );
    if (result['url'] != null || result['html'] != null) {
      return _storeBrowserPage(result);
    }
    return ToolResult(
      success: result['success'] != false,
      output: const JsonEncoder.withIndent('  ').convert(result),
      data: result,
    );
  }

  ToolResult _storeBrowserPage(Map<String, dynamic> result) {
    final url = result['url']?.toString() ?? browserSession.currentUrl;
    final links = (result['links'] as List? ?? const <dynamic>[])
        .whereType<Map>()
        .map(
          (item) => <String, String>{
            'text': item['text']?.toString() ?? '',
            'url': item['url']?.toString() ?? '',
          },
        )
        .where((item) => item['url']!.isNotEmpty)
        .toList();
    final html = _sanitizeHtmlPreview(result['html']?.toString() ?? '', url);
    final page = _BrowserPage(
      id: _uuid.v4(),
      url: url,
      title: result['title']?.toString() ?? '',
      text: _clip(result['text']?.toString() ?? ''),
      html: html,
      links: links,
    );
    _pages[page.id] = page;
    return _pageResult(
      page,
      mode: result['mode']?.toString() ??
          result['engine']?.toString() ??
          'headless-webview',
      extra: <String, dynamic>{
        if (result['forms'] is List) 'forms': result['forms'],
      },
    );
  }

  ToolResult _pageResult(
    _BrowserPage page, {
    required String mode,
    Map<String, dynamic> extra = const <String, dynamic>{},
  }) {
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: ArtifactKind.webpage,
      title: page.title.isEmpty ? Uri.parse(page.url).host : page.title,
      subtitle: page.url,
      url: page.url,
      mimeType: 'text/html',
      html: page.html,
      data: <String, dynamic>{'pageId': page.id, 'mode': mode},
    );
    final data = <String, dynamic>{
      'page_id': page.id,
      'url': page.url,
      'title': page.title,
      'text': page.text,
      'links': page.links,
      'mode': mode,
      'artifact': artifact.toJson(),
      ...extra,
    };
    return ToolResult(
      success: true,
      output: page.title.isEmpty
          ? 'Halaman browser berjaya dibaca: ${page.url}'
          : 'Halaman browser berjaya dibaca: ${page.title} · ${page.url}',
      data: data,
    );
  }

  Future<ToolResult> _browserFollow(Map<String, dynamic> arguments) async {
    final page = _pages[arguments['page_id']?.toString()];
    if (page == null) {
      return const ToolResult(
        success: false,
        output: 'Page ID tidak ditemui atau sesi browser telah tamat.',
      );
    }
    final index = (arguments['link_index'] as num?)?.toInt() ?? -1;
    if (index < 0 || index >= page.links.length) {
      return ToolResult(
        success: false,
        output: 'Indeks pautan tidak sah. Julat 0-${page.links.length - 1}.',
      );
    }
    return _browserOpen(
      page.links[index]['url']!,
      desktopMode: browserSession.desktopMode,
    );
  }

  Future<ToolResult> _browserOpenHttp(
    Uri uri, {
    bool desktopMode = true,
  }) async {
    final response = await _client
        .get(uri, headers: _browserHeaders(desktop: desktopMode))
        .timeout(AppConfig.browserTimeout);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      return ToolResult(
        success: false,
        output: 'HTTP ${response.statusCode}',
      );
    }
    final contentType = response.headers['content-type'] ?? '';
    if (!contentType.contains('html')) {
      final body = _clip(response.body);
      return ToolResult(
        success: true,
        output: body,
        data: <String, dynamic>{
          'url': uri.toString(),
          'contentType': contentType,
        },
      );
    }
    final document = html_parser.parse(response.body);
    for (final node in document.querySelectorAll(
      'script,style,noscript,svg,object,embed,template',
    )) {
      node.remove();
    }
    final title = document.querySelector('title')?.text.trim() ?? uri.host;
    final text = document.body?.text.replaceAll(RegExp(r'\s+'), ' ').trim() ?? '';
    final links = <Map<String, String>>[];
    for (final anchor in document.querySelectorAll('a[href]')) {
      final href = anchor.attributes['href'];
      if (href == null || href.startsWith('#') || href.startsWith('javascript:')) {
        continue;
      }
      final resolved = uri.resolve(href);
      if (!<String>{'http', 'https'}.contains(resolved.scheme)) continue;
      final label = anchor.text.replaceAll(RegExp(r'\s+'), ' ').trim();
      links.add(<String, String>{
        'text': label.isEmpty ? resolved.toString() : label,
        'url': resolved.toString(),
      });
      if (links.length >= 160) break;
    }
    final page = _BrowserPage(
      id: _uuid.v4(),
      url: uri.toString(),
      title: title,
      text: _clip(text),
      html: _sanitizeHtmlPreview(document.outerHtml, uri.toString()),
      links: links,
    );
    _pages[page.id] = page;
    return _pageResult(
      page,
      mode: desktopMode ? 'background-http-desktop' : 'background-http-mobile',
      extra: <String, dynamic>{'desktopMode': desktopMode},
    );
  }

  Future<ToolResult> _browserDownload(
    Map<String, dynamic> arguments,
  ) async {
    final uri = _validatedHttpUri(arguments['url']?.toString() ?? '');
    final request = http.Request('GET', uri);
    request.headers.addAll(
      _browserHeaders(desktop: browserSession.desktopMode),
    );
    final streamed = await _client.send(request).timeout(AppConfig.browserTimeout);
    if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
      return ToolResult(
        success: false,
        output: 'HTTP ${streamed.statusCode}',
      );
    }
    final declared = streamed.contentLength;
    if (declared != null && declared > AppConfig.maxDownloadBytes) {
      return const ToolResult(
        success: false,
        output: 'Fail melebihi had muat turun 250 MB.',
      );
    }
    final filename = _safeFilename(
      arguments['filename']?.toString().trim().isNotEmpty == true
          ? arguments['filename'].toString()
          : p.basename(uri.path).isEmpty
              ? 'download.bin'
              : p.basename(uri.path),
    );
    final root = await _workspace();
    final file = File(p.join(root.path, filename));
    await file.parent.create(recursive: true);
    final sink = file.openWrite();
    var received = 0;
    try {
      await for (final chunk in streamed.stream) {
        received += chunk.length;
        if (received > AppConfig.maxDownloadBytes) {
          throw const FileSystemException(
            'Fail melebihi had muat turun 250 MB.',
          );
        }
        sink.add(chunk);
      }
      await sink.flush();
    } catch (_) {
      await sink.close();
      if (await file.exists()) await file.delete();
      rethrow;
    }
    await sink.close();
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: filename,
      subtitle: '$received bait',
      localPath: file.path,
      mimeType: streamed.headers['content-type'] ?? _mimeForPath(file.path),
      url: uri.toString(),
    );
    return ToolResult(
      success: true,
      output: 'Fail disimpan: ${p.relative(file.path, from: root.path)}',
      data: <String, dynamic>{
        'path': '/workspace/${p.relative(file.path, from: root.path).replaceAll('\\', '/')}',
        'bytes': received,
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _mediaPreview(Map<String, dynamic> arguments) async {
    final rawLocation = arguments['url']?.toString().trim() ?? '';
    final requestedKind = arguments['kind']?.toString().trim().toLowerCase() ?? '';
    var mimeType = arguments['mime_type']?.toString().trim() ?? '';
    ArtifactKind? kind = switch (requestedKind) {
      'image' => ArtifactKind.image,
      'video' => ArtifactKind.video,
      'audio' => ArtifactKind.audio,
      _ => null,
    };

    // Model kadangkala cuba memanggil media_preview selepas browser_screenshot
    // menggunakan path PNG tempatan. Screenshot itu sudah menjadi artifact
    // chat, jadi anggap panggilan tersebut berjaya tanpa cuba mentafsir path
    // Android sebagai URL HTTP/HTTPS dan tanpa menghasilkan lampiran pendua.
    final parsedLocation = Uri.tryParse(rawLocation);
    final isHttpLocation = parsedLocation != null &&
        <String>{'http', 'https'}.contains(parsedLocation.scheme) &&
        parsedLocation.host.isNotEmpty;
    if (!isHttpLocation) {
      final localPath = parsedLocation?.scheme == 'file'
          ? parsedLocation!.toFilePath()
          : rawLocation;
      final localResult = await _existingInternalMedia(localPath, kind, mimeType);
      if (localResult != null) return localResult;
      return const ToolResult(
        success: false,
        output: 'URL media mestilah HTTP/HTTPS atau path media dalaman aplikasi yang sah.',
      );
    }
    final uri = parsedLocation!;

    if (kind == null && mimeType.isNotEmpty) {
      if (mimeType.startsWith('image/')) kind = ArtifactKind.image;
      if (mimeType.startsWith('video/')) kind = ArtifactKind.video;
      if (mimeType.startsWith('audio/')) kind = ArtifactKind.audio;
    }
    if (kind == null) {
      final inferred = _artifactKindForPath(uri.path);
      if (<ArtifactKind>{
        ArtifactKind.image,
        ArtifactKind.video,
        ArtifactKind.audio,
      }.contains(inferred)) {
        kind = inferred;
      }
    }
    if (kind == null) {
      return const ToolResult(
        success: false,
        output:
            'Jenis media tidak dapat dikenal pasti. Berikan kind image, video atau audio bersama URL media langsung.',
      );
    }

    if (mimeType.isEmpty || mimeType == 'application/octet-stream') {
      mimeType = _mimeForPath(uri.path);
      if (mimeType == 'application/octet-stream') {
        mimeType = switch (kind) {
          ArtifactKind.image => 'image/jpeg',
          ArtifactKind.video => 'video/mp4',
          ArtifactKind.audio => 'audio/mpeg',
          _ => 'application/octet-stream',
        };
      }
    }
    final requestedTitle = arguments['title']?.toString().trim() ?? '';
    final basename = p.basename(uri.path).trim();
    final title = requestedTitle.isNotEmpty
        ? requestedTitle
        : basename.isNotEmpty
            ? basename
            : 'Media daripada ${uri.host}';
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: kind,
      title: title,
      subtitle: 'Pratonton URL · belum disimpan ke peranti',
      url: uri.toString(),
      mimeType: mimeType,
      data: const <String, dynamic>{'previewOnly': true},
    );
    return ToolResult(
      success: true,
      output:
          'Pratonton ${kind.name} telah dihantar tanpa memuat turun fail ke storan.',
      data: <String, dynamic>{
        'url': uri.toString(),
        'kind': kind.name,
        'mimeType': mimeType,
        'previewOnly': true,
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult?> _existingInternalMedia(
    String rawPath,
    ArtifactKind? requestedKind,
    String requestedMimeType,
  ) async {
    if (rawPath.isEmpty || !p.isAbsolute(rawPath)) return null;
    final file = File(p.normalize(rawPath));
    if (!await file.exists()) return null;

    final resolvedPath = await file.resolveSymbolicLinks();
    final roots = <Directory>[
      await getApplicationSupportDirectory(),
      await getApplicationDocumentsDirectory(),
      await getTemporaryDirectory(),
    ];
    var isInternal = false;
    for (final root in roots) {
      var resolvedRoot = p.normalize(root.path);
      try {
        resolvedRoot = p.normalize(await root.resolveSymbolicLinks());
      } on FileSystemException {
        // PathProvider mungkin memulangkan direktori yang belum diwujudkan.
      }
      if (resolvedPath == resolvedRoot || p.isWithin(resolvedRoot, resolvedPath)) {
        isInternal = true;
        break;
      }
    }
    if (!isInternal) return null;

    var kind = requestedKind;
    if (kind == null && requestedMimeType.isNotEmpty) {
      if (requestedMimeType.startsWith('image/')) kind = ArtifactKind.image;
      if (requestedMimeType.startsWith('video/')) kind = ArtifactKind.video;
      if (requestedMimeType.startsWith('audio/')) kind = ArtifactKind.audio;
    }
    final inferred = _artifactKindForPath(resolvedPath);
    if (kind == null && <ArtifactKind>{
      ArtifactKind.image,
      ArtifactKind.video,
      ArtifactKind.audio,
    }.contains(inferred)) {
      kind = inferred;
    }
    if (kind == null) return null;

    var mimeType = requestedMimeType;
    if (mimeType.isEmpty || mimeType == 'application/octet-stream') {
      mimeType = _mimeForPath(resolvedPath);
    }
    return ToolResult(
      success: true,
      output:
          'Media ${kind.name} tempatan sudah tersedia sebagai lampiran daripada langkah sebelumnya.',
      data: <String, dynamic>{
        'path': resolvedPath,
        'kind': kind.name,
        'mimeType': mimeType,
        'alreadyAvailable': true,
      },
    );
  }

  Future<ToolResult> _openUrl(Map<String, dynamic> arguments) async {
    return _browserOpen(
      arguments['url']?.toString() ?? '',
      desktopMode: arguments['desktop_mode'] as bool? ?? true,
    );
  }

  Future<ToolResult> _httpRequest(Map<String, dynamic> arguments) async {
    final method = arguments['method']?.toString().toUpperCase() ?? 'GET';
    final uri = _validatedHttpUri(arguments['url']?.toString() ?? '');
    final headers = Map<String, String>.from(arguments['headers'] as Map? ?? const <String, String>{});
    final bodyValue = arguments['body'];
    final body = bodyValue is String ? bodyValue : bodyValue == null ? null : jsonEncode(bodyValue);
    final request = http.Request(method, uri)..headers.addAll(headers);
    if (body != null) request.body = body;
    final streamed = await _client.send(request).timeout(AppConfig.defaultTimeout);
    final response = await http.Response.fromStream(streamed);
    final output = _clip(response.body);
    return ToolResult(
      success: response.statusCode >= 200 && response.statusCode < 400,
      output: output,
      data: <String, dynamic>{'statusCode': response.statusCode, 'headers': response.headers, 'body': output},
    );
  }

  Future<ToolResult> _fileList(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final directory = _safeWorkspaceDirectory(root, arguments['path']?.toString() ?? '.');
    if (!await directory.exists()) return const ToolResult(success: false, output: 'Folder tidak ditemui.');
    final values = <Map<String, dynamic>>[];
    await for (final entity in directory.list(followLinks: false)) {
      final type = await FileSystemEntity.type(entity.path, followLinks: false);
      if (type == FileSystemEntityType.link) {
        values.add(<String, dynamic>{
          'name': p.basename(entity.path),
          'path': p.relative(entity.path, from: root.path),
          'type': 'link',
          'bytes': 0,
        });
        continue;
      }
      try {
        final stat = await entity.stat();
        values.add(<String, dynamic>{
          'name': p.basename(entity.path),
          'path': p.relative(entity.path, from: root.path),
          'type': entity is Directory ? 'directory' : 'file',
          'bytes': stat.size,
          'modified': stat.modified.toIso8601String(),
        });
      } on FileSystemException {
        values.add(<String, dynamic>{
          'name': p.basename(entity.path),
          'path': p.relative(entity.path, from: root.path),
          'type': entity is Directory ? 'directory' : 'file',
          'unreadable': true,
        });
      }
    }
    return ToolResult(success: true, output: const JsonEncoder.withIndent('  ').convert(values), data: <String, dynamic>{'items': values});
  }

  Future<ToolResult> _fileRead(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final file = _safeWorkspaceFile(root, arguments['path']?.toString() ?? '');
    if (!await file.exists()) return const ToolResult(success: false, output: 'Fail tidak ditemui.');
    if (await file.length() > 4 * 1024 * 1024) return const ToolResult(success: false, output: 'Fail melebihi had bacaan teks 4 MB.');
    final content = await file.readAsString();
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: p.basename(file.path),
      subtitle: p.relative(file.path, from: root.path),
      localPath: file.path,
      mimeType: _mimeForPath(file.path),
    );
    return ToolResult(
      success: true,
      output: content,
      data: <String, dynamic>{
        'path': p.relative(file.path, from: root.path),
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _fileWrite(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final file = _safeWorkspaceFile(root, arguments['path']?.toString() ?? 'output.txt');
    await file.parent.create(recursive: true);
    await file.writeAsString(arguments['content']?.toString() ?? '', flush: true);
    final artifact = ChatArtifact(
      id: _uuid.v4(),
      kind: _artifactKindForPath(file.path),
      title: p.basename(file.path),
      subtitle: p.relative(file.path, from: root.path),
      localPath: file.path,
      mimeType: _mimeForPath(file.path),
    );
    return ToolResult(
      success: true,
      output: 'Fail disimpan: ${p.relative(file.path, from: root.path)}',
      data: <String, dynamic>{
        'path': p.relative(file.path, from: root.path).replaceAll('\\', '/'),
        'artifact': artifact.toJson(),
      },
    );
  }

  Future<ToolResult> _fileCopy(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final source = _safeWorkspaceFile(root, arguments['source']?.toString() ?? '');
    final destination = _safeWorkspaceFile(root, arguments['destination']?.toString() ?? '');
    if (!await source.exists()) return const ToolResult(success: false, output: 'Fail sumber tidak ditemui.');
    await destination.parent.create(recursive: true);
    await source.copy(destination.path);
    return ToolResult(success: true, output: 'Fail disalin ke ${p.relative(destination.path, from: root.path)}.');
  }

  Future<ToolResult> _fileMove(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final source = _safeWorkspaceFile(root, arguments['source']?.toString() ?? '');
    final destination = _safeWorkspaceFile(root, arguments['destination']?.toString() ?? '');
    if (!await source.exists()) return const ToolResult(success: false, output: 'Fail sumber tidak ditemui.');
    await destination.parent.create(recursive: true);
    if (await destination.exists()) await destination.delete();
    await source.rename(destination.path);
    return ToolResult(success: true, output: 'Fail dipindah ke ${p.relative(destination.path, from: root.path)}.');
  }

  Future<ToolResult> _fileDelete(Map<String, dynamic> arguments) async {
    final root = await _workspace();
    final relative = arguments['path']?.toString() ?? '';
    final normalized = p.normalize(p.join(root.path, relative));
    if (normalized == root.path || !p.isWithin(root.path, normalized)) {
      return const ToolResult(success: false, output: 'Pemadaman root atau akses di luar workspace tidak dibenarkan.');
    }
    final type = await FileSystemEntity.type(normalized, followLinks: false);
    if (type == FileSystemEntityType.notFound) return const ToolResult(success: false, output: 'Fail atau folder tidak ditemui.');
    if (type == FileSystemEntityType.directory) {
      await Directory(normalized).delete(recursive: arguments['recursive'] as bool? ?? false);
    } else {
      await File(normalized).delete();
    }
    return ToolResult(success: true, output: '$relative telah dipadam.');
  }

  Future<ToolResult> _memorySearch(Map<String, dynamic> arguments) async {
    final query = arguments['query']?.toString().toLowerCase() ?? '';
    final values = (await database.listObjects('memory'))
        .map(MemoryRecord.fromJson)
        .where((item) => '${item.title} ${item.content} ${item.tags.join(' ')}'.toLowerCase().contains(query))
        .take(50)
        .map((item) => item.toJson())
        .toList();
    return ToolResult(success: true, output: const JsonEncoder.withIndent('  ').convert(values), data: <String, dynamic>{'results': values});
  }

  Future<ToolResult> _memoryAdd(Map<String, dynamic> arguments) async {
    final record = MemoryRecord(
      id: _uuid.v4(),
      title: arguments['title']?.toString() ?? 'Memori',
      content: arguments['content']?.toString() ?? '',
      createdAt: DateTime.now(),
      tags: (arguments['tags'] as List? ?? const <dynamic>[]).map((item) => item.toString()).toList(),
    );
    await database.saveObject('memory', record.id, record.toJson());
    return ToolResult(success: true, output: 'Memori disimpan dengan ID ${record.id}.', data: record.toJson());
  }

  Future<ToolResult> _memoryDelete(Map<String, dynamic> arguments) async {
    final id = arguments['id']?.toString() ?? '';
    final existing = await database.getObject('memory', id);
    if (existing == null) return const ToolResult(success: false, output: 'Memori tidak ditemui.');
    await database.deleteObject('memory', id);
    return ToolResult(success: true, output: 'Memori $id dipadam.');
  }

  Future<ToolResult> _skillCreate(Map<String, dynamic> arguments) async {
    final skill = await skillService.createFromTool(arguments);
    return ToolResult(
      success: true,
      output: 'Skill ${skill.name} telah disimpan dan tersedia kepada model.',
      data: <String, dynamic>{
        ...skill.toJson(),
        'artifact': ChatArtifact(
          id: _uuid.v4(),
          kind: ArtifactKind.file,
          title: skill.name,
          subtitle: 'Skill local',
          data: skill.toJson(),
        ).toJson(),
      },
    );
  }

  Future<ToolResult> _skillInstall(Map<String, dynamic> arguments) async {
    final skill = await skillService.importUrl(arguments['url']?.toString() ?? '');
    return ToolResult(success: true, output: 'Skill ${skill.name} dipasang dan diaktifkan.', data: skill.toJson());
  }

  Future<ToolResult> _skillRunScript(Map<String, dynamic> arguments) async {
    final skillId = arguments['skill_id']?.toString() ?? '';
    final script = arguments['script']?.toString() ?? '';
    if (p.isAbsolute(script) || p.normalize(script).startsWith('../')) {
      return const ToolResult(success: false, output: 'Path skrip di luar sandbox tidak dibenarkan.');
    }
    final cwd = await skillService.prepareScriptSandbox(skillId);
    final args = (arguments['arguments'] as List? ?? const <dynamic>[]).map((item) => _shellQuote(item.toString())).join(' ');
    final command = '${_shellQuote(script)}${args.isEmpty ? '' : ' $args'}';
    return terminalService.start(command: command, workingDirectory: cwd);
  }

  Future<ToolResult> _mcpListTools(Map<String, dynamic> arguments) async {
    final server = await _mcpServer(arguments['server_id']?.toString() ?? '');
    final tools = await mcpService.listTools(server);
    return ToolResult(success: true, output: const JsonEncoder.withIndent('  ').convert(tools), data: <String, dynamic>{'server': server.toJson(), 'tools': tools});
  }

  Future<ToolResult> _mcpCall(Map<String, dynamic> arguments) async {
    final server = await _mcpServer(arguments['server_id']?.toString() ?? '');
    final result = await mcpService.callTool(
      server,
      name: arguments['tool_name']?.toString() ?? '',
      arguments: Map<String, dynamic>.from(arguments['arguments'] as Map? ?? const <String, dynamic>{}),
    );
    return ToolResult(success: result['isError'] != true, output: const JsonEncoder.withIndent('  ').convert(result), data: result);
  }

  Future<McpServerConfig> _mcpServer(String id) async {
    final json = await database.getObject('mcp_server', id);
    if (json == null) throw StateError('Server MCP $id tidak ditemui.');
    final server = McpServerConfig.fromJson(json);
    if (!server.enabled) throw StateError('Server MCP ${server.name} tidak aktif.');
    return server;
  }

  Future<ToolResult> _calculator(Map<String, dynamic> arguments) async {
    final expression = arguments['expression']?.toString() ?? '';
    final parsed = Parser().parse(expression);
    final value = parsed.evaluate(EvaluationType.REAL, ContextModel());
    return ToolResult(success: true, output: value.toString());
  }

  Future<bool> _workspaceEntityExists(String relative) async {
    final clean = p.normalize(relative.trim());
    if (clean.isEmpty) return false;
    if (p.isAbsolute(clean) || clean == '..' || clean.startsWith('../')) return false;
    final root = await _workspace();
    final normalized = p.normalize(p.join(root.path, clean));
    if (normalized == root.path || !p.isWithin(root.path, normalized)) return false;
    return FileSystemEntity.type(normalized, followLinks: false)
        .then((type) => type != FileSystemEntityType.notFound);
  }

  bool _looksDestructive(String value) {
    final text = value.toLowerCase();
    return <String>['delete', 'remove', 'destroy', 'drop', 'erase', 'wipe', 'reset', 'revoke', 'uninstall', 'truncate', 'padam', 'hapus']
        .any(text.contains);
  }

  Uri _validatedHttpUri(String raw) {
    final uri = Uri.tryParse(raw.trim());
    if (uri == null || !<String>{'http', 'https'}.contains(uri.scheme) || uri.host.isEmpty) {
      throw const FormatException('URL HTTP/HTTPS tidak sah.');
    }
    return uri;
  }

  Future<Directory> _workspace() async {
    final directory = Directory(p.join((await getApplicationSupportDirectory()).path, 'linux', 'workspace'));
    await directory.create(recursive: true);
    return directory;
  }

  Directory _safeWorkspaceDirectory(Directory root, String relative) {
    final clean = relative.trim().isEmpty ? '.' : p.normalize(relative.trim());
    if (p.isAbsolute(clean) || clean == '..' || clean.startsWith('../')) {
      throw const FileSystemException('Path mutlak atau akses di luar workspace tidak dibenarkan.');
    }
    final path = p.normalize(p.join(root.path, clean));
    if (path != root.path && !p.isWithin(root.path, path)) {
      throw const FileSystemException('Akses di luar workspace tidak dibenarkan.');
    }
    _assertNoWorkspaceSymlink(root, path);
    return Directory(path);
  }

  File _safeWorkspaceFile(Directory root, String relative) {
    final clean = p.normalize(relative.trim());
    if (clean.isEmpty || p.isAbsolute(clean) || clean == '..' || clean.startsWith('../')) {
      throw const FileSystemException('Path fail mesti relatif dan berada dalam workspace.');
    }
    final path = p.normalize(p.join(root.path, clean));
    if (!p.isWithin(root.path, path)) {
      throw const FileSystemException('Akses di luar workspace tidak dibenarkan.');
    }
    _assertNoWorkspaceSymlink(root, path);
    return File(path);
  }

  void _assertNoWorkspaceSymlink(Directory root, String targetPath) {
    final relative = p.relative(targetPath, from: root.path);
    if (relative == '.') return;
    var current = root.path;
    for (final segment in p.split(relative)) {
      if (segment.isEmpty || segment == '.') continue;
      current = p.join(current, segment);
      final type = FileSystemEntity.typeSync(current, followLinks: false);
      if (type == FileSystemEntityType.link) {
        throw const FileSystemException(
          'Akses melalui symlink tidak dibenarkan oleh file-tool workspace.',
        );
      }
      if (type == FileSystemEntityType.notFound) break;
    }
  }

  String _sanitizeHtmlPreview(String rawHtml, String baseUrl) {
    if (rawHtml.trim().isEmpty) return '';
    final document = html_parser.parse(rawHtml);
    for (final node in document.querySelectorAll(
      'script,noscript,iframe,object,embed,template,canvas,form,input,textarea,select,button,video,audio,source,track,meta[http-equiv="refresh"]',
    )) {
      node.remove();
    }
    final base = Uri.tryParse(baseUrl);
    for (final element in document.querySelectorAll('*')) {
      final unsafe = element.attributes.keys.where((name) {
        final normalizedName = name.toString().toLowerCase();
        return normalizedName.startsWith('on') || normalizedName == 'srcdoc';
      }).toList();
      for (final name in unsafe) {
        element.attributes.remove(name);
      }
      element.attributes.remove('autoplay');
      element.attributes.remove('srcdoc');
      if (base != null) {
        for (final attribute in const <String>['href', 'src', 'poster']) {
          final value = element.attributes[attribute];
          if (value == null || value.trim().isEmpty || value.startsWith('data:') || value.startsWith('#')) continue;
          final resolved = base.resolve(value);
          if (<String>{'http', 'https'}.contains(resolved.scheme)) {
            element.attributes[attribute] = resolved.toString();
          }
        }
      }
    }
    final output = document.outerHtml;
    if (output.length <= AppConfig.maxHtmlPreviewChars) return output;
    final title = document.querySelector('title')?.text.trim() ?? 'Pratonton halaman';
    final text = document.body?.text.replaceAll(RegExp(r'\s+'), ' ').trim() ?? '';
    final clipped = text.length <= AppConfig.maxHtmlPreviewChars
        ? text
        : '${text.substring(0, AppConfig.maxHtmlPreviewChars)}…';
    return '<article><h2>${const HtmlEscape().convert(title)}</h2><p>${const HtmlEscape().convert(clipped)}</p></article>';
  }

  ArtifactKind _artifactKindForPath(String path) {
    final extension = p.extension(path).toLowerCase();
    if (<String>{'.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.heic', '.svg'}.contains(extension)) {
      return ArtifactKind.image;
    }
    if (<String>{'.mp4', '.mkv', '.mov', '.webm', '.m4v', '.avi'}.contains(extension)) {
      return ArtifactKind.video;
    }
    if (<String>{'.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac', '.opus'}.contains(extension)) {
      return ArtifactKind.audio;
    }
    if (<String>{'.html', '.htm'}.contains(extension)) return ArtifactKind.html;
    return ArtifactKind.file;
  }

  String _mimeForPath(String path) {
    return switch (p.extension(path).toLowerCase()) {
      '.png' => 'image/png',
      '.jpg' || '.jpeg' => 'image/jpeg',
      '.gif' => 'image/gif',
      '.webp' => 'image/webp',
      '.svg' => 'image/svg+xml',
      '.mp4' || '.m4v' => 'video/mp4',
      '.webm' => 'video/webm',
      '.mp3' => 'audio/mpeg',
      '.wav' => 'audio/wav',
      '.m4a' => 'audio/mp4',
      '.ogg' || '.opus' => 'audio/ogg',
      '.pdf' => 'application/pdf',
      '.json' => 'application/json',
      '.html' || '.htm' => 'text/html',
      '.md' => 'text/markdown',
      '.txt' || '.log' => 'text/plain',
      '.csv' => 'text/csv',
      _ => 'application/octet-stream',
    };
  }

  String _safeFilename(String value) => value.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
  String _clip(String value) => value.length <= AppConfig.maxToolOutputChars ? value : '${value.substring(0, AppConfig.maxToolOutputChars)}…';
  String _shellQuote(String value) => "'${value.replaceAll("'", "'\\''")}'";

  Map<String, String> _browserHeaders({bool desktop = true}) =>
      <String, String>{
        'User-Agent': desktop
            ? 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Safari/537.36 AiMultiAgent/1.0.0'
            : 'Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/138 Mobile Safari/537.36 '
                'AiMultiAgent/1.0.0',
        'Accept':
            'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
      };

  void clearChatScopedState() {
    _pages.clear();
  }

  void dispose() {
    browserSession.dispose();
    terminalService.dispose();
    windowsProcessService.dispose();
    skillService.dispose();
    mcpService.dispose();
    _client.close();
  }
}
