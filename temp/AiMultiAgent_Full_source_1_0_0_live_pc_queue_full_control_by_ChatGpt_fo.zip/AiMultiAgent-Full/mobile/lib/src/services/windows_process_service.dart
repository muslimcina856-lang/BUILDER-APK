import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'windows_runtime_service.dart';

class _WindowsRollingTextBuffer {
  _WindowsRollingTextBuffer(this.maxChars);

  final int maxChars;
  String _value = '';
  bool _truncated = false;

  void write(Object? chunk) {
    final text = chunk?.toString() ?? '';
    if (text.isEmpty) return;
    final combined = '$_value$text';
    if (combined.length <= maxChars) {
      _value = combined;
      return;
    }
    _value = combined.substring(combined.length - maxChars);
    _truncated = true;
  }

  @override
  String toString() =>
      _truncated ? '… output awal dipotong …\n$_value' : _value;
}

class WindowsJob {
  WindowsJob({
    required this.id,
    required this.command,
    required this.workingDirectory,
    required this.startedAt,
    required this.process,
    required this.kind,
  });

  final String id;
  final String command;
  final String workingDirectory;
  final DateTime startedAt;
  final Process process;
  final String kind;
  final _WindowsRollingTextBuffer stdout =
      _WindowsRollingTextBuffer(AppConfig.maxToolOutputChars);
  final _WindowsRollingTextBuffer stderr =
      _WindowsRollingTextBuffer(AppConfig.maxToolOutputChars);
  int? exitCode;
  DateTime? finishedAt;

  bool get running => exitCode == null;

  Map<String, dynamic> snapshot() => <String, dynamic>{
        'job_id': id,
        'kind': kind,
        'command': command,
        'working_directory': workingDirectory,
        'running': running,
        'exit_code': exitCode,
        'started_at': startedAt.toIso8601String(),
        'finished_at': finishedAt?.toIso8601String(),
        'stdout': stdout.toString(),
        'stderr': stderr.toString(),
      };
}

class WindowsProcessService {
  factory WindowsProcessService() => _instance;
  WindowsProcessService._();

  static final WindowsProcessService _instance = WindowsProcessService._();
  static const Uuid _uuid = Uuid();
  static const int _maxRetainedJobs = 32;
  static const int _maxConcurrentJobs = 1;
  static const Duration _gracefulStopTimeout = Duration(seconds: 3);
  static const Duration _forcedStopTimeout = Duration(seconds: 2);

  final WindowsRuntimeService _runtime = WindowsRuntimeService();
  final Map<String, WindowsJob> _jobs = <String, WindowsJob>{};
  bool _aiControlPaused = false;

  void Function()? onDesktopActivity;

  Iterable<WindowsJob> get jobs => _jobs.values;
  bool get hasRunningJob => _jobs.values.any((job) => job.running);
  bool get aiControlPaused => _aiControlPaused;

  void setAiControlPaused(bool value) {
    _aiControlPaused = value;
  }

  void _markDesktopActivity() => onDesktopActivity?.call();

  bool isDestructiveCommand(String command) {
    final normalized = command.toLowerCase().replaceAll(RegExp(r'\s+'), ' ').trim();
    const patterns = <String>[
      ' del ',
      ' erase ',
      ' rmdir ',
      ' rd /s',
      ' format ',
      ' diskpart',
      ' bcdedit',
      ' reg delete',
      ' shutdown',
      ' cipher /w',
      ' taskkill /f',
    ];
    final padded = ' $normalized ';
    return patterns.any(padded.contains);
  }

  Future<ToolResult> startCommand({
    required String command,
    String workingDirectory = '.',
  }) async {
    final text = command.trim();
    if (text.isEmpty) {
      return const ToolResult(success: false, output: 'Arahan Windows kosong.');
    }
    final boundaryViolation = _sandboxBoundaryViolation(text);
    if (boundaryViolation != null) {
      return ToolResult(success: false, output: boundaryViolation);
    }
    return _start(
      displayCommand: text,
      guestCommand: _runtime.wrapWindowsCommand(text),
      workingDirectory: workingDirectory,
      kind: 'cmd',
    );
  }


  String? _sandboxBoundaryViolation(String command) {
    final normalized = command
        .replaceAll('\\', '/')
        .toLowerCase();
    const blocked = <String>[
      'z:/',
      '/sdcard',
      '/storage',
      '/mnt/media_rw',
      '/data/user',
      '/data/data',
      '/system/',
      '/vendor/',
      '/product/',
      '/apex/',
      'physicaldrive',
      '//./',
      '//?/globalroot',
    ];
    if (blocked.any(normalized.contains)) {
      return 'Akses di luar PC Windows sandbox tidak dibenarkan. Gunakan C:\\ untuk PC Windows, W:\\ untuk workspace atau A:\\ untuk lampiran.';
    }
    return null;
  }

  Future<ToolResult> startExecutable({
    required String path,
    List<String> arguments = const <String>[],
    String workingDirectory = '.',
  }) async {
    try {
      final resolved = await _runtime.resolveExecutablePath(path);
      final cleanArguments = arguments
          .map((value) => value.replaceAll('\u0000', ''))
          .toList(growable: false);
      return _start(
        displayCommand: '${resolved.guestPath} ${cleanArguments.join(' ')}'.trim(),
        guestCommand: _runtime.wrapWindowsExecutable(
          resolved.guestPath,
          cleanArguments,
        ),
        workingDirectory: workingDirectory,
        kind: 'exe',
      );
    } on FileSystemException catch (error) {
      return ToolResult(success: false, output: error.message);
    }
  }

  Future<ToolResult> _start({
    required String displayCommand,
    required String guestCommand,
    required String workingDirectory,
    required String kind,
  }) async {
    if (!AppConfig.isFullEdition) {
      return const ToolResult(
        success: false,
        output: 'PC Windows local hanya tersedia dalam Ai MultiAgent Full.',
      );
    }
    final runningJobs = _jobs.values.where((job) => job.running).length;
    if (runningJobs >= _maxConcurrentJobs) {
      return const ToolResult(
        success: false,
        output: 'Satu proses Windows sedang aktif. Pantau atau hentikan job itu dahulu.',
      );
    }
    _pruneCompletedJobs();
    try {
      await _runtime.ensureReady();
      final spec = await _runtime.commandSpec(
        command: guestCommand,
        relativeWorkingDirectory: workingDirectory,
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final job = WindowsJob(
        id: _uuid.v4(),
        command: displayCommand,
        workingDirectory: workingDirectory,
        startedAt: DateTime.now(),
        process: process,
        kind: kind,
      );
      _jobs[job.id] = job;
      _markDesktopActivity();
      process.stdout
          .transform(const Utf8Decoder(allowMalformed: true))
          .listen(
            job.stdout.write,
            onError: (Object error) => job.stderr.write('\n$error'),
          );
      process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .listen(
            job.stderr.write,
            onError: (Object error) => job.stderr.write('\n$error'),
          );
      unawaited(process.exitCode.then((code) {
        job.exitCode = code;
        job.finishedAt = DateTime.now();
      }));
      return ToolResult(
        success: true,
        output: jsonEncode(job.snapshot()),
        data: job.snapshot(),
      );
    } on FileSystemException catch (error) {
      return ToolResult(
        success: false,
        output: 'PC Windows tidak dapat dimulakan: ${error.message}',
      );
    } on ProcessException catch (error) {
      return ToolResult(
        success: false,
        output: 'Proses Windows gagal dimulakan: ${error.message}',
      );
    } on TimeoutException {
      return const ToolResult(
        success: false,
        output: 'Penyediaan PC Windows tamat masa.',
      );
    } catch (error) {
      return ToolResult(
        success: false,
        output: 'PC Windows gagal dimulakan dengan selamat: $error',
      );
    }
  }

  Future<ToolResult> poll(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) {
      return const ToolResult(success: false, output: 'Job Windows tidak ditemui.');
    }
    final snapshot = job.snapshot();
    return ToolResult(
      success: job.exitCode == null || job.exitCode == 0,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<ToolResult> stop(String jobId) async {
    final job = _jobs[jobId];
    if (job == null) {
      return const ToolResult(success: false, output: 'Job Windows tidak ditemui.');
    }
    if (!job.running) return poll(jobId);
    await _stopJob(job);
    final snapshot = job.snapshot();
    return ToolResult(
      success: !job.running,
      output: const JsonEncoder.withIndent('  ').convert(snapshot),
      data: snapshot,
    );
  }

  Future<ToolResult> activateDesktop() async {
    try {
      await _runtime.ensureReady();
      final result = await _runControl(
        _runtime.desktopBootstrapCommand(),
        action: 'activate_desktop',
      );
      if (result.success) _markDesktopActivity();
      return result;
    } catch (error) {
      return ToolResult(success: false, output: 'Desktop Windows gagal diaktifkan: $error');
    }
  }

  Future<ToolResult> listWindows() async {
    if (!_jobs.values.any((job) => job.running)) {
      return const ToolResult(
        success: false,
        output: 'Tiada proses Windows aktif untuk diperiksa.',
      );
    }
    const command = r'''
DISPLAY=:99
export DISPLAY
ids="$(xdotool search --onlyvisible --name '.*' 2>/dev/null || true)"
for id in $ids; do
  name="$(xdotool getwindowname "$id" 2>/dev/null || true)"
  printf '%s\t%s\n' "$id" "$name"
done
''';
    return _runControl(command, action: 'list_windows');
  }

  Future<ToolResult> uiAction({
    required String action,
    int? x,
    int? y,
    int? toX,
    int? toY,
    int? button,
    int? scrollY,
    int? scrollX,
    int? width,
    int? height,
    String text = '',
    String key = '',
    String windowId = '',
    bool userInitiated = false,
  }) async {
    if (!hasRunningJob) {
      return const ToolResult(
        success: false,
        output: 'Tiada proses Windows aktif untuk dikawal.',
      );
    }
    if (_aiControlPaused && !userInitiated) {
      return const ToolResult(
        success: false,
        output: 'Kawalan PC sedang dipegang pengguna. AI mesti tunggu sehingga kawalan dipulangkan.',
        data: <String, dynamic>{'paused_by_user': true},
      );
    }

    _markDesktopActivity();
    String command;
    bool validPoint(int px, int py) =>
        px >= 0 &&
        px < WindowsRuntimeService.desktopWidth &&
        py >= 0 &&
        py < WindowsRuntimeService.desktopHeight;
    String? validWindowId() {
      final clean = windowId.trim();
      return RegExp(r'^\d{1,20}$').hasMatch(clean) ? clean : null;
    }

    switch (action) {
      case 'move':
        final safeX = x ?? -1;
        final safeY = y ?? -1;
        if (!validPoint(safeX, safeY)) {
          return const ToolResult(success: false, output: 'Koordinat tetikus Windows tidak sah.');
        }
        command = 'DISPLAY=:99 xdotool mousemove --sync $safeX $safeY';
        break;
      case 'click':
      case 'double_click':
      case 'right_click':
      case 'middle_click':
        final safeX = x ?? -1;
        final safeY = y ?? -1;
        final safeButton = action == 'right_click'
            ? 3
            : action == 'middle_click'
                ? 2
                : (button ?? 1);
        if (!validPoint(safeX, safeY) || safeButton < 1 || safeButton > 7) {
          return const ToolResult(success: false, output: 'Koordinat atau butang mouse Windows tidak sah.');
        }
        final repeat = action == 'double_click' ? ' --repeat 2 --delay 120' : '';
        command = 'DISPLAY=:99 xdotool mousemove --sync $safeX $safeY click$repeat $safeButton';
        break;
      case 'mouse_down':
      case 'mouse_up':
        final safeX = x ?? -1;
        final safeY = y ?? -1;
        final safeButton = button ?? 1;
        if (!validPoint(safeX, safeY) || safeButton < 1 || safeButton > 7) {
          return const ToolResult(success: false, output: 'Koordinat atau butang mouse Windows tidak sah.');
        }
        final verb = action == 'mouse_down' ? 'mousedown' : 'mouseup';
        command = 'DISPLAY=:99 xdotool mousemove --sync $safeX $safeY $verb $safeButton';
        break;
      case 'scroll':
        final vertical = (scrollY ?? 0).clamp(-40, 40);
        final horizontal = (scrollX ?? 0).clamp(-40, 40);
        if (vertical == 0 && horizontal == 0) {
          return const ToolResult(success: false, output: 'scroll_y atau scroll_x mesti bukan sifar.');
        }
        final safeX = x ?? (WindowsRuntimeService.desktopWidth ~/ 2);
        final safeY = y ?? (WindowsRuntimeService.desktopHeight ~/ 2);
        if (!validPoint(safeX, safeY)) {
          return const ToolResult(success: false, output: 'Koordinat scroll Windows tidak sah.');
        }
        final parts = <String>[
          'DISPLAY=:99',
          'xdotool mousemove --sync $safeX $safeY',
        ];
        if (vertical != 0) {
          final wheel = vertical > 0 ? 5 : 4;
          parts.add('xdotool click --repeat ${vertical.abs()} --delay 30 $wheel');
        }
        if (horizontal != 0) {
          final wheel = horizontal > 0 ? 7 : 6;
          parts.add('xdotool click --repeat ${horizontal.abs()} --delay 30 $wheel');
        }
        command = parts.join('; ');
        break;
      case 'drag':
        final startX = x ?? -1;
        final startY = y ?? -1;
        final endX = toX ?? -1;
        final endY = toY ?? -1;
        final safeButton = button ?? 1;
        if (!validPoint(startX, startY) ||
            !validPoint(endX, endY) ||
            safeButton < 1 ||
            safeButton > 3) {
          return const ToolResult(success: false, output: 'Koordinat atau butang drag Windows tidak sah.');
        }
        command =
            'DISPLAY=:99 xdotool mousemove --sync $startX $startY mousedown $safeButton mousemove --sync $endX $endY mouseup $safeButton';
        break;
      case 'type':
        final clean = text.replaceAll('\u0000', '');
        if (clean.isEmpty || clean.length > 4000) {
          return const ToolResult(success: false, output: 'Teks untuk ditaip mesti 1 hingga 4000 aksara.');
        }
        command = 'DISPLAY=:99 xdotool type --clearmodifiers --delay 8 ${_shellQuote(clean)}';
        break;
      case 'key':
      case 'hotkey':
        final clean = key.trim();
        if (!RegExp(r'^[A-Za-z0-9_+:.,\-]{1,160}$').hasMatch(clean)) {
          return const ToolResult(success: false, output: 'Nama kekunci/hotkey xdotool tidak sah.');
        }
        command = 'DISPLAY=:99 xdotool key --clearmodifiers ${_shellQuote(clean)}';
        break;
      case 'focus':
      case 'activate_window':
        final id = validWindowId();
        if (id == null) {
          return const ToolResult(success: false, output: 'window_id mesti nombor daripada windows_list_windows.');
        }
        command = 'DISPLAY=:99 xdotool windowactivate --sync $id';
        break;
      case 'minimize_window':
        final id = validWindowId();
        if (id == null) return const ToolResult(success: false, output: 'window_id tidak sah.');
        command = 'DISPLAY=:99 xdotool windowminimize $id';
        break;
      case 'restore_window':
        final id = validWindowId();
        if (id == null) return const ToolResult(success: false, output: 'window_id tidak sah.');
        command = 'DISPLAY=:99 xdotool windowmap $id windowactivate --sync $id';
        break;
      case 'maximize_window':
        final id = validWindowId();
        if (id == null) return const ToolResult(success: false, output: 'window_id tidak sah.');
        command = 'DISPLAY=:99 xdotool windowmap $id windowactivate --sync $id key --clearmodifiers alt+F10';
        break;
      case 'close_window':
        final id = validWindowId();
        if (id == null) return const ToolResult(success: false, output: 'window_id tidak sah.');
        command = 'DISPLAY=:99 xdotool windowclose $id';
        break;
      case 'move_window':
        final id = validWindowId();
        final safeX = x ?? -1;
        final safeY = y ?? -1;
        if (id == null || !validPoint(safeX, safeY)) {
          return const ToolResult(success: false, output: 'window_id atau koordinat window tidak sah.');
        }
        command = 'DISPLAY=:99 xdotool windowmove --sync $id $safeX $safeY';
        break;
      case 'resize_window':
        final id = validWindowId();
        final safeWidth = width ?? 0;
        final safeHeight = height ?? 0;
        if (id == null || safeWidth < 100 || safeHeight < 100 ||
            safeWidth > WindowsRuntimeService.desktopWidth ||
            safeHeight > WindowsRuntimeService.desktopHeight) {
          return const ToolResult(success: false, output: 'window_id atau saiz window tidak sah.');
        }
        command = 'DISPLAY=:99 xdotool windowsize --sync $id $safeWidth $safeHeight';
        break;
      case 'show_desktop':
        command = 'DISPLAY=:99 xdotool key --clearmodifiers Super+d';
        break;
      case 'clipboard_set':
        final clean = text.replaceAll('\u0000', '');
        if (clean.length > 16000) {
          return const ToolResult(success: false, output: 'Clipboard dihadkan kepada 16000 aksara.');
        }
        command = "printf %s ${_shellQuote(clean)} | DISPLAY=:99 xclip -selection clipboard";
        break;
      case 'clipboard_get':
        command = 'DISPLAY=:99 xclip -selection clipboard -o 2>/dev/null || true';
        break;
      default:
        return const ToolResult(success: false, output: 'Action GUI Windows tidak dikenali.');
    }

    return _runControl(command, action: action);
  }

  Future<ToolResult> _runControl(
    String command, {
    required String action,
  }) async {
    try {
      final spec = await _runtime.commandSpec(
        command: command,
        relativeWorkingDirectory: '.',
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final stdoutFuture = process.stdout
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final stderrFuture = process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final exitCode = await process.exitCode.timeout(const Duration(seconds: 20));
      final stdout = await stdoutFuture;
      final stderr = await stderrFuture;
      final data = <String, dynamic>{
        'action': action,
        'exit_code': exitCode,
        'stdout': stdout,
        'stderr': stderr,
      };
      return ToolResult(
        success: exitCode == 0,
        output: exitCode == 0
            ? (stdout.trim().isEmpty ? 'Action GUI Windows selesai.' : stdout.trim())
            : 'Action GUI Windows gagal (exit $exitCode): $stderr',
        data: data,
      );
    } on TimeoutException {
      return const ToolResult(success: false, output: 'Action GUI Windows tamat masa.');
    } catch (error) {
      return ToolResult(success: false, output: 'Action GUI Windows gagal: $error');
    }
  }

  Future<ToolResult> screenshot({bool liveFrame = false}) async {
    _markDesktopActivity();
    try {
      await _runtime.ensureReady();
      final hostPath = await _runtime.screenshotHostPath(liveFrame: liveFrame);
      final linuxRoot = (await WindowsRuntimeService().commandSpec(
        command: 'true',
        relativeWorkingDirectory: '.',
      ));
      final workspaceHost = linuxRoot.hostWorkingDirectory;
      final relative = p.relative(hostPath, from: workspaceHost).replaceAll('\\', '/');
      final guestPath = '/workspace/$relative';
      final spec = await _runtime.commandSpec(
        command: '${_runtime.desktopBootstrapCommand()}\nDISPLAY=${WindowsRuntimeService.displayName} scrot -q 100 ${_shellQuote(guestPath)}',
        relativeWorkingDirectory: '.',
      );
      final process = await Process.start(
        spec.executable,
        spec.arguments,
        workingDirectory: spec.hostWorkingDirectory,
        environment: spec.environment,
        includeParentEnvironment: false,
        runInShell: false,
      );
      final stderrFuture = process.stderr
          .transform(const Utf8Decoder(allowMalformed: true))
          .join();
      final exitCode = await process.exitCode.timeout(const Duration(seconds: 20));
      final stderr = await stderrFuture;
      if (exitCode != 0 || !await File(hostPath).exists()) {
        return ToolResult(
          success: false,
          output: 'Screenshot Windows gagal (exit $exitCode): $stderr',
        );
      }
      final data = <String, dynamic>{
        'path': hostPath,
        'mime': 'image/png',
        'width': WindowsRuntimeService.desktopWidth,
        'height': WindowsRuntimeService.desktopHeight,
        'fullDesktop': true,
      };
      return ToolResult(
        success: true,
        output: 'Screenshot PC Windows tersedia.',
        data: data,
      );
    } on TimeoutException {
      return const ToolResult(success: false, output: 'Screenshot Windows tamat masa.');
    } catch (error) {
      return ToolResult(success: false, output: 'Screenshot Windows gagal: $error');
    }
  }


  Future<void> clearTransientScreenshots() => _runtime.clearTransientScreenshots();

  Future<void> stopAll() async {
    final running = _jobs.values.where((job) => job.running).toList(growable: false);
    await Future.wait(running.map(_stopJob));
    _markDesktopActivity();
  }

  Future<void> _stopJob(WindowsJob job) async {
    if (!job.running) return;
    final sent = job.process.kill(ProcessSignal.sigterm);
    if (!sent) job.process.kill(ProcessSignal.sigkill);
    try {
      final code = await job.process.exitCode.timeout(_gracefulStopTimeout);
      job.exitCode ??= code;
      job.finishedAt ??= DateTime.now();
      return;
    } on TimeoutException {
      job.process.kill(ProcessSignal.sigkill);
    }
    try {
      final code = await job.process.exitCode.timeout(_forcedStopTimeout);
      job.exitCode ??= code;
      job.finishedAt ??= DateTime.now();
    } on TimeoutException {
      job.stderr.write('\nProses Windows tidak memberi respons selepas SIGKILL.');
    }
  }

  void _pruneCompletedJobs() {
    if (_jobs.length < _maxRetainedJobs) return;
    final completed = _jobs.values.where((job) => !job.running).toList()
      ..sort((a, b) =>
          (a.finishedAt ?? a.startedAt).compareTo(b.finishedAt ?? b.startedAt));
    while (_jobs.length >= _maxRetainedJobs && completed.isNotEmpty) {
      _jobs.remove(completed.removeAt(0).id);
    }
  }

  void dispose() => unawaited(stopAll());

  static String _shellQuote(String value) =>
      "'${value.replaceAll("'", "'\\''").replaceAll('\u0000', '')}'";
}
