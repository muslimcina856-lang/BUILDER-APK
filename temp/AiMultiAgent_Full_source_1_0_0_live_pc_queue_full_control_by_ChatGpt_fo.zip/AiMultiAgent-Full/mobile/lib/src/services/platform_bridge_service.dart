import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../config/app_config.dart';

class PlatformBridgeService {
  static const MethodChannel _channel = MethodChannel('com.aiauto.claw/device');

  Future<void> startExecutionKeepAlive({
    Duration maxDuration = AppConfig.backgroundExecutionLimit,
  }) async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('startExecutionKeepAlive', <String, dynamic>{
        'maxDurationMs': maxDuration.inMilliseconds,
      });
    } on MissingPluginException {
      // Unit tests and unsupported platforms intentionally have no native bridge.
    } on PlatformException {
      // Sesetengah OEM menolak permulaan foreground service. Tugasan utama
      // masih boleh terus berjalan semasa proses aplikasi kekal hidup.
    }
  }

  Future<void> stopExecutionKeepAlive() async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('stopExecutionKeepAlive');
    } on MissingPluginException {
      // Unit tests and unsupported platforms intentionally have no native bridge.
    } on PlatformException {
      // Servis mungkin telah dihentikan oleh sistem atau OEM.
    }
  }

  Future<void> openNotificationSettings() async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('openNotificationSettings');
    } on MissingPluginException {
      // Tiada tetapan notifikasi native pada platform ini.
    } on PlatformException {
      // Sesetengah Android OEM tidak menyediakan halaman khusus aplikasi.
    }
  }

  Future<void> openAppSettings() async {
    if (kIsWeb || !Platform.isAndroid) return;
    try {
      await _channel.invokeMethod<void>('openAppSettings');
    } on MissingPluginException {
      // Tiada halaman tetapan aplikasi native pada platform ini.
    } on PlatformException {
      // Sesetengah OEM menyekat intent tetapan aplikasi.
    }
  }



}
