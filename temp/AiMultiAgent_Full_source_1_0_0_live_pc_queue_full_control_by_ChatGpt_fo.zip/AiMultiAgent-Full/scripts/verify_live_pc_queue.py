#!/usr/bin/env python3
"""Semakan statik queue chat, stop segera dan Live PC terapung."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.exists():
        ERRORS.append(f"Fail tiada: {rel}")
        return ""
    return path.read_text(encoding="utf-8")


def require(ok: bool, message: str) -> None:
    if not ok:
        ERRORS.append(message)


state = read("mobile/lib/src/state/app_state.dart")
chat = read("mobile/lib/src/ui/screens/chat_screen.dart")
agent = read("mobile/lib/src/services/agent_runtime.dart")
provider = read("mobile/lib/src/services/provider_service.dart")
windows = read("mobile/lib/src/services/windows_process_service.dart")
tools = read("mobile/lib/src/services/tool_engine.dart")
browser = read("mobile/lib/src/services/browser_session_service.dart")
native_browser = read("mobile/android/app/src/main/kotlin/com/aiauto/claw/BackgroundBrowserEngine.kt")

require("queuedTurns" in state and "_drainQueuedTurns" in state and "Barisan" in chat,
        "Mesej susulan belum mempunyai queue/barisan")
require("Tulis susulan — masuk barisan" in chat and "playlist_add_rounded" in chat,
        "Composer belum membenarkan susulan semasa run")
require("cancelActiveCompletion" in state and "cancelActiveAction" in state and
        "terminalService.stopAll" in state and "windowsProcessService.stopAll" in state,
        "Stop belum membatalkan model/browser/Shell/PC serentak")
require("cancelActiveCompletion" in provider and '"cancel"' in native_browser and
        "cancelActiveAction" in browser,
        "Pembatalan provider/browser belum lengkap")
require("clearMessages(oldSessionId)" in state and "deleteSession(oldSessionId)" in state and
        "clearSessionArtifacts" in state and "clearChatScopedState" in state and
        "clearTransientScreenshots" in state,
        "Chat baharu belum membersihkan bahan chat lama")
require("class _FloatingPcOverlay" in chat and "class _PcDesktopPage" in chat and
        "refreshLivePcFrame" in state and "onDesktopActivity" in windows,
        "Live PC terapung/paparan penuh belum lengkap")
require("takePcUserControl" in state and "releasePcUserControl" in state and
        "control.pause()" in state and "waitIfPaused" in agent and "userInitiated" in windows,
        "Pertukaran kawalan AI/pengguna belum menjeda AI")
for action in (
    "middle_click", "mouse_down", "mouse_up", "hotkey", "minimize_window",
    "maximize_window", "restore_window", "close_window", "move_window",
    "resize_window", "show_desktop", "clipboard_set", "clipboard_get",
):
    require(f"'{action}'" in tools and f"case '{action}':" in windows,
            f"Aksi PC belum lengkap: {action}")
require("class _NeutralActivityIndicator" in chat and
        "border: Border.all(color: const Color(0xFF2A313E))" in chat,
        "Loading chat neutral belum digunakan")

if ERRORS:
    print("SEMAKAN LIVE PC/QUEUE GAGAL")
    for item in ERRORS:
        print(f"- {item}")
    sys.exit(1)

print("SEMAKAN LIVE PC/QUEUE LULUS")
print("- Susulan masuk barisan dan composer kekal aktif")
print("- Stop membatalkan model/browser/Shell/PC")
print("- Live PC terapung + ambil alih/pulangkan kawalan disahkan")
print("- Aksi desktop lanjutan dan loading neutral disahkan")
