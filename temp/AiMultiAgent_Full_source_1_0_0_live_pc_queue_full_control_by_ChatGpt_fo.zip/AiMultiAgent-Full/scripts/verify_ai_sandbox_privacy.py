#!/usr/bin/env python3
"""Semakan statik supaya AI hanya melihat Shell/PC sandbox, bukan host device."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.exists():
        ERRORS.append(f"Fail tiada: {rel}")
        return ""
    return path.read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        ERRORS.append(message)


main = read("mobile/android/app/src/main/kotlin/com/aiauto/claw/MainActivity.kt")
tools = read("mobile/lib/src/services/tool_engine.dart")
agent = read("mobile/lib/src/services/agent_runtime.dart")
terminal = read("mobile/lib/src/services/terminal_service.dart")
linux = read("mobile/lib/src/services/linux_workspace_service.dart")
windows = read("mobile/lib/src/services/windows_runtime_service.dart")
winproc = read("mobile/lib/src/services/windows_process_service.dart")
browser = read("mobile/android/app/src/main/kotlin/com/aiauto/claw/BackgroundBrowserEngine.kt")
chat = read("mobile/lib/src/ui/screens/chat_screen.dart")

for forbidden in (
    "getRuntimeContext",
    "getDeviceInfo",
    "Build.MANUFACTURER",
    "Build.MODEL",
    "Build.SOC_MODEL",
    "BATTERY_PROPERTY_CAPACITY",
    "SUPPORTED_ABIS",
):
    require(forbidden not in main, f"Bridge native host masih mendedahkan {forbidden}")

require("platformBridge.runtimeContext()" not in tools,
        "runtime_info masih mengambil konteks native host")
require("hostDeviceInfoAvailableToAi" not in tools and
        "hostFilesystemAvailableToAi" not in tools and
        "hostDeviceInfoAccess" not in tools,
        "runtime_info masih mendedahkan konsep/medan peranti host")
require("AI tidak dibenarkan mengetahui" in agent and
        "Cubaan seperti itu bukan strategi pemulihan" in agent,
        "Prompt model belum melarang fingerprint/keluar sandbox dengan tegas")
require("/proc/cpuinfo" in terminal and "/proc/meminfo" in terminal and
        "lscpu" in terminal and "dmidecode" in terminal,
        "Terminal belum menyekat probe host yang biasa")
require("root.list(recursive: true" not in linux and
        "root.list(recursive: true" not in windows and
        "rootfs/dev" in linux and "rootfs/dev" in windows,
        "Kiraan saiz runtime masih boleh menyapu pseudo-filesystem host")
require("'[HOST_PATH_HIDDEN]'" in agent,
        "Redaksi path host untuk output model/chat tiada")

require("'fullPage': true" in tools and '"fullPage" to true' in browser,
        "Screenshot browser belum dijamin full-page")
require("'fullDesktop': true" in tools and "scrot -q 100" in winproc,
        "Screenshot PC Windows belum ditanda full-desktop")
require("InteractiveViewer(" in chat and "_FullImagePreviewPage" in chat and
        "Tekan untuk pratonton penuh" in chat,
        "Screenshot chat belum boleh dibuka/zoom secara penuh")
for action in ("move", "double_click", "right_click", "scroll", "drag"):
    require(f"'{action}'" in tools and f"case '{action}':" in winproc,
            f"Kawalan GUI Windows tiada: {action}")

if ERRORS:
    print("SEMAKAN PRIVASI SANDBOX AI GAGAL")
    for error in ERRORS:
        print(f"- {error}")
    sys.exit(1)

print("SEMAKAN PRIVASI SANDBOX AI LULUS")
print("- Bridge spesifikasi luar sandbox dibuang; runtime_info hanya Shell/PC/browser sandbox")
print("- Path/pseudo-filesystem host disekat dan error host dirahsiakan")
print("- Screenshot full-page/full-desktop + viewer penuh disahkan")
print("- Tetikus Windows termasuk scroll/drag/double/right-click disahkan")
