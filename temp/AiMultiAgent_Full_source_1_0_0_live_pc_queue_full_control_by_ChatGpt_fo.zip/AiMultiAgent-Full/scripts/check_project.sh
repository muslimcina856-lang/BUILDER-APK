#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

python3 scripts/verify_source.py
python3 scripts/verify_release_config.py
python3 scripts/check_source_text.py
python3 scripts/verify_windows_layer.py
python3 scripts/verify_ai_sandbox_privacy.py
python3 scripts/verify_live_pc_queue.py
if [[ -f mobile/assets/linux/full/runtime-pack.zip ]]; then
  python3 scripts/linux/prepare_bundled_runtime.py --verify-only
else
  echo "Runtime Linux belum dijana dalam source checkout; build_full.sh akan menjana dan membundelkannya sebelum Flutter build."
fi
python3 scripts/test_linux_runtime_builder.py
python3 scripts/test_duckduckgo_fixtures.py
python3 -m compileall -q scripts

for script in scripts/*.sh; do
  bash -n "$script"
done

if command -v flutter >/dev/null 2>&1; then
  pushd mobile >/dev/null
  flutter pub get
  dart format lib test
  flutter analyze
  flutter test
  popd >/dev/null
else
  echo "Flutter SDK tidak tersedia; analisis/build Flutter sebenar dilaksanakan oleh workflow CI yang disertakan."
fi
