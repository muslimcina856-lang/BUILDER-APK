# Windows PRoot runtime hotfix — 11 Ogos 2026

- Membetulkan kegagalan pemasangan PC Windows pada Android yang memulangkan `fchdir: Function not implemented` ketika trigger BusyBox berjalan.
- Membuang paksaan global `PROOT_NO_SECCOMP=1` daripada Shell dan PC Windows supaya PRoot boleh menggunakan mod seccomp normal pada kernel yang menyokongnya.
- Bootstrap Ubuntu Base tidak lagi menjalankan `apk add`; aplikasi memuat turun arkib Ubuntu terus, kemudian `/bin/busybox` sedia ada digunakan hanya untuk SHA-256 dan ekstrak.
- Shell Alpine, workspace pengguna dan fungsi AI lain tidak diubah.

# PC Windows local untuk AI — 10 Ogos 2026

- Menambah runtime PC Windows local yang berasingan daripada Shell: Ubuntu Base 24.04.4 ARM64 + Box64 + Wine WoW64, dimuat turun pada penggunaan pertama Workspace/tool Windows.
- Menambah tool AI `windows_runtime_status`, `windows_install`, `windows_run_cmd`, `windows_run_exe`, `windows_poll`, `windows_stop`, `windows_screenshot`, `windows_list_windows` dan `windows_ui_action`.
- AI kini boleh menjalankan `cmd.exe`, membuka `.exe` daripada `/workspace`, lampiran chat atau drive `C:` Wine, mengambil screenshot desktop 1280×720, fokus tetingkap, klik, menaip dan menghantar kekunci.
- Ubuntu Base dan Wine dipinkan dengan SHA-256; Box64 dicuba daripada repository bertandatangan dahulu, kemudian auto-fallback kepada Box64 0.4.4 yang dipin ke commit rasmi dan dibina dengan `BAD_SIGNAL=ON` untuk Android/PRoot jika probe Wine gagal.
- Proses Windows dihentikan bersama proses Shell apabila tugasan dibatalkan, sesi ditukar, had latar belakang dicapai atau data tempatan dipadam.
- Reset PC Windows tidak memadam Shell atau projek `/workspace`; reset Shell pula tidak memadam runtime Windows.
- UI `Linux Workspace` dinamakan `Workspace`; runtime Linux sedia ada kekal sebagai **Shell**.
- Lapisan Windows ini ialah Wine WoW64 + Box64, bukan kernel/VM Windows penuh, jadi keserasian aplikasi bergantung pada Wine/Box64.

# Pembaikan rakaman skrin & Cara Guna — 4 Ogos 2026

- Menambah halaman **Cara Guna** dalam tab Lagi serta tool `app_usage_guide` supaya AI menjawab soalan penggunaan berdasarkan panduan aplikasi; tiada halaman terma atau polisi keselamatan baharu ditambah.
- Membetulkan crash Linux Workspace apabila callback `setState` memulangkan `Future`.
- Menggantikan paparan screenshot `BoxFit.cover` dengan gambar penuh tanpa potongan, pratonton skrin penuh, zum/pan dan pilihan Simpan.
- Menambah tool `media_preview` serta pratonton gambar/video/audio URL terus tanpa simpanan automatik; video/audio mempunyai kawalan main/jeda, video skrin penuh dan pilihan Simpan selepas pengguna membuat keputusan.
- Menutup pratonton HTML secara lalai untuk mengelakkan kad putih/besar, mematikan JavaScript pada pratonton dan membuang elemen media daripada HTML yang dipaparkan.
- Menyenyapkan browser Chromium tersembunyi dari awal dokumen, termasuk HTML media dan Web Audio, supaya TikTok/YouTube tidak mengeluarkan bunyi di hadapan atau latar belakang.
- Menambah screenshot halaman penuh berjubin sebagai satu PNG, memendekkan payload browser kepada model dan menggantikan JSON mentah dalam kad proses dengan ringkasan mesra pengguna.
- Menambah konteks server MCP yang dikonfigurasi supaya tugasan Windows boleh diarahkan kepada PC Windows sebenar apabila Linux ARM64 tempatan tidak sesuai.
- Menggantikan semua aset ikon Full dengan ikon hitam-ungu premium baharu.

# Asset build hotfix — 4 Ogos 2026

- Membetulkan build panel yang memanggil `flutter build` secara terus dan gagal kerana `assets/linux/full/runtime-pack.zip` belum dijana.
- Menambah task Gradle `prepareBundledLinuxRuntime` dan `verifyBundledLinuxRuntime` sebagai dependency terus kepada semua task `compileFlutterBuild*`.
- Runtime kini disediakan dan disahkan sebelum Flutter memproses senarai asset dalam `pubspec.yaml`, untuk debug, release, AAB dan `flutter run`.
- Menambah fallback `curl`/`wget` apabila Python `urllib` gagal mewarisi konfigurasi rangkaian atau proxy panel build.
- Menambah semakan source, ujian fallback tanpa rangkaian dan ujian CI bagi build Flutter terus selepas asset runtime dipadam.

# Build hotfix — 4 Ogos 2026

- Membetulkan kompilasi Dart dalam `linux_workspace_service.dart`: `FileSystemEntity.delete(...)` yang tidak wujud diganti dengan helper `_deleteEntity(...)`.
- Helper memadam berdasarkan jenis entiti sebenar (`File`, `Directory` atau `Link`) dan tidak mengikuti symlink.
- Menambah semakan regresi source supaya penggunaan semula API statik yang tidak sah itu menggagalkan validasi sebelum build Flutter.

# Linux completion — 4 Ogos 2026

- Menyiapkan Alpine Linux 3.24.1 ARM64 + PRoot 0.15 sebagai asset terbina yang dijana dan disahkan sebelum build debug/release.
- AI menerima kontrak Linux pada setiap tugasan: `apk`, `/workspace`, `/root`, terminal tanpa stdin interaktif, guest root tanpa `sudo`, serta aliran status/start/poll/stop.
- Terminal memasang runtime automatik sebelum arahan pertama, mengehadkan output, maksimum 8 job serentak dan 64 job terakhir, menerima UTF-8 rosak tanpa crash, serta menghentikan semua proses ketika larian dibatalkan, sesi/reset berubah atau had latar belakang tamat.
- Menambah pemasangan transaksi yang tahan process-kill: staging, backup, pemulihan permulaan, health check, rollback, dan pemeliharaan projek/home/cache/snapshot pengguna ketika naik taraf.
- Membetulkan health check supaya benar-benar menjalankan `apk --version` dan mengesahkan `apk-tools`.
- Menolak runtime pack dengan path traversal, nama entri berganda, symlink keluar sandbox/storan Android, jenis fail asing, CRC rosak, saiz/entri melampau, manifest salah, permission PRoot salah atau ELF bukan AArch64.
- Menghentikan job aktif sebelum pemasangan/import/reset runtime dan membersihkan ralat UI selepas import pemulihan berjaya.
- Build Full gagal jika runtime tidak sah, tidak dijana atau tidak terkandung dalam APK dan AAB; R8 `mapping.txt` kekal wajib.

# Build fix — 3 Ogos 2026

- Build debug Full kini menyediakan dan mengesahkan runtime Linux yang sama seperti release sebelum menghasilkan APK ARM64.
- Membetulkan health check Linux supaya menjalankan `apk --version` sebelum mengesahkan output `apk-tools`.
- Tambah import `AppState` yang hilang pada `home_shell.dart`.
- Pulihkan widget fallback `_MediaError` untuk imej dan video yang gagal dimuatkan.
- Pulihkan pemetaan ikon `_fileIcon` dan `_attachmentIcon`.
- Tambah alias warna `AppTheme.error` untuk tindakan destruktif Linux Workspace.
- Tambah semakan regresi sumber bagi semua simbol di atas.

# Changelog

## 1.0.0+1 — Dual Edition Final

- Menggantikan ikon edisi Full dengan ikon premium tanpa teks.
- Menetapkan Standard kepada target API 36 dan Full sideload kepada compatibility target API 28.
- Menambah dashboard Linux Workspace Full, terminal manual dan paparan proses AI bersama.
- Mengasingkan seluruh rootfs Alpine, pakej apk, projek, cache dan screenshot dalam storan internal private aplikasi.
- Membuang bind `/sys` serta menghadkan bind device PRoot kepada device asas sahaja.
- Membina dan membundel Alpine ARM64 + PRoot secara automatik, memasangnya sebelum terminal pertama, mengesahkan health check dan mengekalkan import File Picker sebagai pemulihan.
- Menambah screenshot browser Chromium tersembunyi sebagai artifact imej dalam chat.
- Menambah staging, rollback, semakan symlink dan pemulihan permission ketika memasang runtime.

## 1.0.0+1 — Dual Edition

- Menambah edisi Standard (`com.aiauto.claw`) dan Full (`com.aiauto.claw.full`).
- Menambah entry point, nama launcher dan ikon tanpa teks yang berasingan.
- Menambah Linux Workspace private dalam storan dalaman aplikasi.
- Menyekat package manager sistem pada edisi Standard dan membenarkannya pada edisi Full.
- Menambah skrip build APK/AAB mengikut flavor dan workflow CI dua edisi.
- Memastikan tiada permission akses storan luaran luas.

## 1.0.0+1 — Versi 1

- Mengekalkan versi paparan aplikasi sebagai `1.0.0`.
- Menggunakan `versionCode`/build number `1` sebagai build pertama aplikasi.
- Membetulkan ikon Material yang tidak wujud.
- Menambah pelaksanaan lengkap Skill Creator.
- Membetulkan pemeriksaan atribut HTML yang menyebabkan kompilasi gagal.
- Menggunakan UI chat premium, orchestrator model utama dan sub-agent dinamik.
- Menyokong provider BYOK, browser latar belakang, DuckDuckGo, media, fail, skills, automasi dan terminal.
- Mengunci `compileSdk` kepada API 36; edisi Standard menyasarkan API 36 dan Full menggunakan compatibility target 28 untuk PRoot.
- Membuang `mimo-v2-flash` daripada pilihan chat selepas endpoint MiMo menolaknya.
- Menapis model ASR/TTS daripada pemilih model chat dan menyegar model terus daripada provider.
- Memindahkan lifecycle `AppScope` ke atas Navigator dan menggunakan akses state tanpa dependency dalam callback async.
- Menambah key stabil pada mesej/media untuk mengelakkan state widget berpindah ketika senarai chat berubah.
- Menambah migrasi automatik konfigurasi MiMo lama serta fallback model satu kali.
