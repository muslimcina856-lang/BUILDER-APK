#pragma once

#include "engine/Math.hpp"

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace pk {

enum class ResourceType : std::uint8_t { Wood, Stone, Herb };
enum class GameEvent : std::uint8_t {
    GatherWood,
    GatherStone,
    GatherHerb,
    Craft,
    Attack,
    EnemyHit,
    PlayerHit,
    TotemCorrect,
    TotemWrong,
    MysterySolved,
    Respawn
};

struct FrameInput {
    Vec2 movement{};
    float cameraYaw = 0.0F;
    bool attackPressed = false;
    bool interactPressed = false;
    bool craftPressed = false;
    bool recenterPressed = false;
    bool pausePressed = false;
};

struct PlayerState {
    Vec3 position{0.0F, 0.0F, 3.0F};
    float facing = 0.0F;
    float health = 100.0F;
    float stamina = 100.0F;
    int wood = 0;
    int stone = 0;
    int herbs = 0;
    int tools = 0;
    int relics = 0;
};

struct ResourceNode {
    Vec3 position{};
    ResourceType type = ResourceType::Wood;
    bool available = true;
    float respawnTimer = 0.0F;
};

struct EnemyState {
    Vec3 position{};
    Vec3 home{};
    float health = 100.0F;
    float attackCooldown = 0.0F;
    float respawnTimer = 0.0F;
    bool alive = true;
};

struct TotemState {
    Vec3 position{};
    int symbol = 0;
    bool active = false;
};

struct WorldSnapshot {
    PlayerState player{};
    float worldTime = 0.0F;
    int campLevel = 1;
    int puzzleProgress = 0;
    bool mysterySolved = false;
};

class GameWorld {
public:
    GameWorld();

    void reset();
    void update(float dt, const FrameInput& input);
    void restore(const WorldSnapshot& snapshot);
    [[nodiscard]] WorldSnapshot snapshot() const;
    [[nodiscard]] float terrainHeight(float x, float z) const;
    [[nodiscard]] std::vector<GameEvent> consumeEvents();

    [[nodiscard]] const PlayerState& player() const { return player_; }
    [[nodiscard]] const std::vector<ResourceNode>& resources() const { return resources_; }
    [[nodiscard]] const std::vector<EnemyState>& enemies() const { return enemies_; }
    [[nodiscard]] const std::array<TotemState, 3>& totems() const { return totems_; }
    [[nodiscard]] Vec3 campPosition() const { return campPosition_; }
    [[nodiscard]] float worldTime() const { return worldTime_; }
    [[nodiscard]] int campLevel() const { return campLevel_; }
    [[nodiscard]] int puzzleProgress() const { return puzzleProgress_; }
    [[nodiscard]] bool mysterySolved() const { return mysterySolved_; }
    [[nodiscard]] std::string objectiveText() const;

private:
    void updatePlayer(float dt, const FrameInput& input);
    void updateResources(float dt, const FrameInput& input);
    void updateEnemies(float dt, const FrameInput& input);
    void updateCrafting(const FrameInput& input);
    void updatePuzzle(const FrameInput& input);
    void respawnPlayer();
    void emit(GameEvent event) { events_.push_back(event); }

    PlayerState player_{};
    std::vector<ResourceNode> resources_{};
    std::vector<EnemyState> enemies_{};
    std::array<TotemState, 3> totems_{};
    Vec3 campPosition_{0.0F, 0.0F, 0.0F};
    float worldTime_ = 0.0F;
    float attackCooldown_ = 0.0F;
    int campLevel_ = 1;
    int puzzleProgress_ = 0;
    bool mysterySolved_ = false;
    std::vector<GameEvent> events_{};
};

}  // namespace pk
