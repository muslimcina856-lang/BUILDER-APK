#include "game/GameWorld.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace pk {

namespace {
constexpr float kIslandRadius = 31.0F;
constexpr float kInteractRange = 2.15F;
constexpr std::array<int, 3> kTotemOrder{1, 2, 0};
}

GameWorld::GameWorld() { reset(); }

void GameWorld::reset() {
    player_ = {};
    player_.position = {0.0F, terrainHeight(0.0F, 3.0F), 3.0F};
    campPosition_ = {0.0F, terrainHeight(0.0F, 0.0F), 0.0F};
    worldTime_ = 0.18F;
    attackCooldown_ = 0.0F;
    campLevel_ = 1;
    puzzleProgress_ = 0;
    mysterySolved_ = false;
    events_.clear();

    resources_ = {
        {{-5.0F, terrainHeight(-5.0F, 5.0F), 5.0F}, ResourceType::Wood},
        {{4.0F, terrainHeight(4.0F, 7.0F), 7.0F}, ResourceType::Wood},
        {{-10.0F, terrainHeight(-10.0F, -2.0F), -2.0F}, ResourceType::Wood},
        {{12.0F, terrainHeight(12.0F, 2.0F), 2.0F}, ResourceType::Wood},
        {{-3.0F, terrainHeight(-3.0F, -7.0F), -7.0F}, ResourceType::Stone},
        {{8.0F, terrainHeight(8.0F, -5.0F), -5.0F}, ResourceType::Stone},
        {{-14.0F, terrainHeight(-14.0F, 7.0F), 7.0F}, ResourceType::Stone},
        {{16.0F, terrainHeight(16.0F, -8.0F), -8.0F}, ResourceType::Stone},
        {{2.0F, terrainHeight(2.0F, 11.0F), 11.0F}, ResourceType::Herb},
        {{-8.0F, terrainHeight(-8.0F, 13.0F), 13.0F}, ResourceType::Herb},
        {{11.0F, terrainHeight(11.0F, 12.0F), 12.0F}, ResourceType::Herb},
        {{-17.0F, terrainHeight(-17.0F, -9.0F), -9.0F}, ResourceType::Herb}
    };

    enemies_.clear();
    for (const Vec3 p : std::array<Vec3, 5>{
             Vec3{-7.0F, 0.0F, 9.0F}, Vec3{10.0F, 0.0F, 10.0F},
             Vec3{-15.0F, 0.0F, -7.0F}, Vec3{17.0F, 0.0F, -3.0F},
             Vec3{2.0F, 0.0F, -17.0F}}) {
        Vec3 grounded = p;
        grounded.y = terrainHeight(p.x, p.z);
        enemies_.push_back({grounded, grounded});
    }

    totems_ = {{
        {{-18.0F, terrainHeight(-18.0F, 12.0F), 12.0F}, 0, false},
        {{18.0F, terrainHeight(18.0F, 13.0F), 13.0F}, 1, false},
        {{2.0F, terrainHeight(2.0F, -23.0F), -23.0F}, 2, false}
    }};
}

float GameWorld::terrainHeight(float x, float z) const {
    const float radial = std::sqrt(x * x + z * z);
    const float shore = std::max(0.0F, 1.0F - radial / 34.0F);
    const float hills = std::sin(x * 0.19F) * 0.65F + std::cos(z * 0.16F) * 0.5F +
                        std::sin((x + z) * 0.09F) * 0.7F;
    return -0.55F + shore * 1.25F + hills * shore;
}

void GameWorld::update(float dt, const FrameInput& input) {
    dt = std::min(dt, 0.05F);
    worldTime_ = std::fmod(worldTime_ + dt / 540.0F, 1.0F);
    attackCooldown_ = std::max(0.0F, attackCooldown_ - dt);
    updatePlayer(dt, input);
    updateResources(dt, input);
    updateCrafting(input);
    updatePuzzle(input);
    updateEnemies(dt, input);
    if (player_.health <= 0.0F) {
        respawnPlayer();
    }
}

void GameWorld::updatePlayer(float dt, const FrameInput& input) {
    Vec2 movement = input.movement;
    const float magnitude = length(movement);
    if (magnitude > 1.0F) movement = normalize(movement);

    const float sinYaw = std::sin(input.cameraYaw);
    const float cosYaw = std::cos(input.cameraYaw);
    const Vec3 cameraForward{sinYaw, 0.0F, cosYaw};
    const Vec3 cameraRight{cosYaw, 0.0F, -sinYaw};
    Vec3 direction = cameraRight * movement.x + cameraForward * movement.y;

    const bool moving = length(direction) > 0.05F;
    if (moving) {
        direction = normalize(direction);
        const float speed = player_.stamina > 5.0F ? 4.3F : 2.8F;
        Vec3 candidate = player_.position + direction * (speed * dt);
        const float radial = std::sqrt(candidate.x * candidate.x + candidate.z * candidate.z);
        if (radial > kIslandRadius) {
            const float factor = kIslandRadius / radial;
            candidate.x *= factor;
            candidate.z *= factor;
        }
        candidate.y = terrainHeight(candidate.x, candidate.z);
        player_.position = candidate;
        player_.facing = std::atan2(direction.x, direction.z);
        player_.stamina = std::max(0.0F, player_.stamina - 9.0F * dt * magnitude);
    } else {
        player_.stamina = std::min(100.0F, player_.stamina + 14.0F * dt);
    }
}

void GameWorld::updateResources(float dt, const FrameInput& input) {
    for (ResourceNode& resource : resources_) {
        if (!resource.available) {
            resource.respawnTimer -= dt;
            if (resource.respawnTimer <= 0.0F) resource.available = true;
        }
    }
    if (!input.interactPressed) return;

    ResourceNode* nearest = nullptr;
    float nearestDistance = kInteractRange;
    for (ResourceNode& resource : resources_) {
        const float d = distanceXZ(player_.position, resource.position);
        if (resource.available && d < nearestDistance) {
            nearest = &resource;
            nearestDistance = d;
        }
    }
    if (nearest == nullptr) return;

    nearest->available = false;
    nearest->respawnTimer = 55.0F;
    switch (nearest->type) {
        case ResourceType::Wood:
            player_.wood += 2;
            emit(GameEvent::GatherWood);
            break;
        case ResourceType::Stone:
            player_.stone += 2;
            emit(GameEvent::GatherStone);
            break;
        case ResourceType::Herb:
            player_.herbs += 1;
            emit(GameEvent::GatherHerb);
            break;
    }
}

void GameWorld::updateCrafting(const FrameInput& input) {
    if (!input.craftPressed || distanceXZ(player_.position, campPosition_) > 3.2F) return;
    if (player_.wood >= 3 && player_.stone >= 2) {
        player_.wood -= 3;
        player_.stone -= 2;
        ++player_.tools;
        campLevel_ = std::min(3, 1 + player_.tools / 2);
        emit(GameEvent::Craft);
    } else if (player_.herbs >= 2 && player_.health < 100.0F) {
        player_.herbs -= 2;
        player_.health = std::min(100.0F, player_.health + 45.0F);
        emit(GameEvent::Craft);
    }
}

void GameWorld::updatePuzzle(const FrameInput& input) {
    if (!input.interactPressed || mysterySolved_) return;
    for (TotemState& totem : totems_) {
        if (distanceXZ(player_.position, totem.position) >= kInteractRange) continue;
        if (totem.symbol == kTotemOrder[static_cast<std::size_t>(puzzleProgress_)]) {
            totem.active = true;
            ++puzzleProgress_;
            emit(GameEvent::TotemCorrect);
            if (puzzleProgress_ == 3) {
                mysterySolved_ = true;
                ++player_.relics;
                emit(GameEvent::MysterySolved);
            }
        } else {
            puzzleProgress_ = 0;
            for (TotemState& item : totems_) item.active = false;
            emit(GameEvent::TotemWrong);
        }
        break;
    }
}

void GameWorld::updateEnemies(float dt, const FrameInput& input) {
    if (input.attackPressed && attackCooldown_ <= 0.0F) {
        attackCooldown_ = 0.58F;
        emit(GameEvent::Attack);
        EnemyState* target = nullptr;
        float bestDistance = 2.4F;
        const Vec3 facing{std::sin(player_.facing), 0.0F, std::cos(player_.facing)};
        for (EnemyState& enemy : enemies_) {
            if (!enemy.alive) continue;
            const Vec3 toward = normalize(enemy.position - player_.position);
            const float d = distanceXZ(player_.position, enemy.position);
            if (d < bestDistance && dot(facing, toward) > 0.15F) {
                target = &enemy;
                bestDistance = d;
            }
        }
        if (target != nullptr) {
            target->health -= 34.0F + static_cast<float>(player_.tools) * 6.0F;
            emit(GameEvent::EnemyHit);
            if (target->health <= 0.0F) {
                target->alive = false;
                target->respawnTimer = 40.0F;
                ++player_.relics;
            }
        }
    }

    for (EnemyState& enemy : enemies_) {
        if (!enemy.alive) {
            enemy.respawnTimer -= dt;
            if (enemy.respawnTimer <= 0.0F) {
                enemy.alive = true;
                enemy.health = 100.0F;
                enemy.position = enemy.home;
            }
            continue;
        }
        enemy.attackCooldown = std::max(0.0F, enemy.attackCooldown - dt);
        const float d = distanceXZ(enemy.position, player_.position);
        if (d < 9.0F && d > 1.35F) {
            const Vec3 direction = normalize(player_.position - enemy.position);
            enemy.position += direction * (1.65F * dt);
            enemy.position.y = terrainHeight(enemy.position.x, enemy.position.z);
        } else if (d <= 1.35F && enemy.attackCooldown <= 0.0F) {
            player_.health -= 12.0F;
            enemy.attackCooldown = 1.25F;
            emit(GameEvent::PlayerHit);
        }
    }
}

void GameWorld::respawnPlayer() {
    player_.position = {campPosition_.x, campPosition_.y, campPosition_.z + 2.0F};
    player_.health = 100.0F;
    player_.stamina = 100.0F;
    player_.wood /= 2;
    player_.stone /= 2;
    emit(GameEvent::Respawn);
}

WorldSnapshot GameWorld::snapshot() const {
    return {player_, worldTime_, campLevel_, puzzleProgress_, mysterySolved_};
}

void GameWorld::restore(const WorldSnapshot& snapshotValue) {
    player_ = snapshotValue.player;
    worldTime_ = snapshotValue.worldTime;
    campLevel_ = std::clamp(snapshotValue.campLevel, 1, 3);
    puzzleProgress_ = std::clamp(snapshotValue.puzzleProgress, 0, 3);
    mysterySolved_ = snapshotValue.mysterySolved;
    player_.position.y = terrainHeight(player_.position.x, player_.position.z);
    for (TotemState& totem : totems_) totem.active = false;
    for (int step = 0; step < puzzleProgress_; ++step) {
        const int symbol = kTotemOrder[static_cast<std::size_t>(step)];
        for (TotemState& totem : totems_) {
            if (totem.symbol == symbol) totem.active = true;
        }
    }
}

std::vector<GameEvent> GameWorld::consumeEvents() {
    std::vector<GameEvent> result;
    result.swap(events_);
    return result;
}

std::string GameWorld::objectiveText() const {
    if (mysterySolved_) return "RAHSIA PULAU DITEMUI";
    if (puzzleProgress_ > 0) return "AKTIFKAN TOTEM SETERUSNYA";
    if (player_.tools == 0) return "KUMPUL 3 KAYU DAN 2 BATU";
    return "CARI TIGA TOTEM DALAM KABUS";
}

}  // namespace pk
