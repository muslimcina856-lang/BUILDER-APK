#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace pk {

constexpr float kPi = 3.14159265358979323846F;

struct Vec2 {
    float x = 0.0F;
    float y = 0.0F;
};

struct Vec3 {
    float x = 0.0F;
    float y = 0.0F;
    float z = 0.0F;
};

inline Vec2 operator+(Vec2 a, Vec2 b) { return {a.x + b.x, a.y + b.y}; }
inline Vec2 operator-(Vec2 a, Vec2 b) { return {a.x - b.x, a.y - b.y}; }
inline Vec2 operator*(Vec2 a, float s) { return {a.x * s, a.y * s}; }
inline Vec3 operator+(Vec3 a, Vec3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline Vec3 operator-(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline Vec3 operator*(Vec3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
inline Vec3 operator/(Vec3 a, float s) { return {a.x / s, a.y / s, a.z / s}; }
inline Vec3& operator+=(Vec3& a, Vec3 b) { a = a + b; return a; }

inline float dot(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline Vec3 cross(Vec3 a, Vec3 b) {
    return {a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x};
}
inline float length(Vec2 v) { return std::sqrt(v.x * v.x + v.y * v.y); }
inline float length(Vec3 v) { return std::sqrt(dot(v, v)); }
inline Vec2 normalize(Vec2 v) {
    const float n = length(v);
    return n > 0.0001F ? v * (1.0F / n) : Vec2{};
}
inline Vec3 normalize(Vec3 v) {
    const float n = length(v);
    return n > 0.0001F ? v / n : Vec3{};
}
inline float distanceXZ(Vec3 a, Vec3 b) {
    const float dx = a.x - b.x;
    const float dz = a.z - b.z;
    return std::sqrt(dx * dx + dz * dz);
}
inline float clamp(float v, float lo, float hi) { return std::clamp(v, lo, hi); }
inline float lerp(float a, float b, float t) { return a + (b - a) * t; }

struct Mat4 {
    std::array<float, 16> v{};

    static Mat4 identity() {
        Mat4 result;
        result.v = {1, 0, 0, 0,
                    0, 1, 0, 0,
                    0, 0, 1, 0,
                    0, 0, 0, 1};
        return result;
    }
};

inline Mat4 operator*(const Mat4& a, const Mat4& b) {
    Mat4 out;
    for (int col = 0; col < 4; ++col) {
        for (int row = 0; row < 4; ++row) {
            float sum = 0.0F;
            for (int k = 0; k < 4; ++k) {
                sum += a.v[static_cast<std::size_t>(k * 4 + row)] *
                       b.v[static_cast<std::size_t>(col * 4 + k)];
            }
            out.v[static_cast<std::size_t>(col * 4 + row)] = sum;
        }
    }
    return out;
}

inline Mat4 translation(Vec3 p) {
    Mat4 out = Mat4::identity();
    out.v[12] = p.x;
    out.v[13] = p.y;
    out.v[14] = p.z;
    return out;
}

inline Mat4 scale(Vec3 s) {
    Mat4 out = Mat4::identity();
    out.v[0] = s.x;
    out.v[5] = s.y;
    out.v[10] = s.z;
    return out;
}

inline Mat4 rotationY(float angle) {
    Mat4 out = Mat4::identity();
    const float c = std::cos(angle);
    const float s = std::sin(angle);
    out.v[0] = c;
    out.v[2] = -s;
    out.v[8] = s;
    out.v[10] = c;
    return out;
}

inline Mat4 perspective(float verticalFovRadians, float aspect, float nearPlane, float farPlane) {
    Mat4 out;
    const float f = 1.0F / std::tan(verticalFovRadians * 0.5F);
    out.v[0] = f / aspect;
    out.v[5] = f;
    out.v[10] = (farPlane + nearPlane) / (nearPlane - farPlane);
    out.v[11] = -1.0F;
    out.v[14] = (2.0F * farPlane * nearPlane) / (nearPlane - farPlane);
    return out;
}

inline Mat4 lookAt(Vec3 eye, Vec3 target, Vec3 up) {
    const Vec3 f = normalize(target - eye);
    const Vec3 s = normalize(cross(f, up));
    const Vec3 u = cross(s, f);
    Mat4 out = Mat4::identity();
    out.v[0] = s.x;
    out.v[4] = s.y;
    out.v[8] = s.z;
    out.v[1] = u.x;
    out.v[5] = u.y;
    out.v[9] = u.z;
    out.v[2] = -f.x;
    out.v[6] = -f.y;
    out.v[10] = -f.z;
    out.v[12] = -dot(s, eye);
    out.v[13] = -dot(u, eye);
    out.v[14] = dot(f, eye);
    return out;
}

inline std::uint32_t xorshift(std::uint32_t& state) {
    state ^= state << 13U;
    state ^= state >> 17U;
    state ^= state << 5U;
    return state;
}

}  // namespace pk
