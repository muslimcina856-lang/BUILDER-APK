#include "engine/SaveSystem.hpp"

#include <cstdio>
#include <fstream>
#include <utility>

namespace pk {

SaveSystem::SaveSystem(std::string directory)
    : savePath_(std::move(directory) + "/pulau_kabus.sav") {}

bool SaveSystem::load(WorldSnapshot& snapshot) const {
    std::ifstream file(savePath_);
    if (!file) return false;
    std::string magic;
    file >> magic;
    if (magic != "PKSAVE1") return false;
    int solved = 0;
    file >> snapshot.player.position.x >> snapshot.player.position.y >> snapshot.player.position.z
         >> snapshot.player.facing >> snapshot.player.health >> snapshot.player.stamina
         >> snapshot.player.wood >> snapshot.player.stone >> snapshot.player.herbs
         >> snapshot.player.tools >> snapshot.player.relics >> snapshot.worldTime
         >> snapshot.campLevel >> snapshot.puzzleProgress >> solved;
    snapshot.mysterySolved = solved != 0;
    return file.good() || file.eof();
}

bool SaveSystem::save(const WorldSnapshot& snapshot) const {
    const std::string temporary = savePath_ + ".tmp";
    {
        std::ofstream file(temporary, std::ios::trunc);
        if (!file) return false;
        file << "PKSAVE1\n"
             << snapshot.player.position.x << ' ' << snapshot.player.position.y << ' '
             << snapshot.player.position.z << ' ' << snapshot.player.facing << ' '
             << snapshot.player.health << ' ' << snapshot.player.stamina << ' '
             << snapshot.player.wood << ' ' << snapshot.player.stone << ' '
             << snapshot.player.herbs << ' ' << snapshot.player.tools << ' '
             << snapshot.player.relics << ' ' << snapshot.worldTime << ' '
             << snapshot.campLevel << ' ' << snapshot.puzzleProgress << ' '
             << (snapshot.mysterySolved ? 1 : 0) << '\n';
        if (!file.good()) return false;
    }
    return std::rename(temporary.c_str(), savePath_.c_str()) == 0;
}

}  // namespace pk
