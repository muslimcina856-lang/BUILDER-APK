#include "engine/AudioEngine.hpp"

#include "engine/Math.hpp"

#include <algorithm>
#include <cmath>

namespace pk {

AudioEngine::~AudioEngine() { stop(); }

bool AudioEngine::start() {
    if (stream_ != nullptr) return true;
    AAudioStreamBuilder* builder = nullptr;
    if (AAudio_createStreamBuilder(&builder) != AAUDIO_OK) return false;
    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setChannelCount(builder, 2);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setDataCallback(builder, &AudioEngine::dataCallback, this);
    const aaudio_result_t openResult = AAudioStreamBuilder_openStream(builder, &stream_);
    AAudioStreamBuilder_delete(builder);
    if (openResult != AAUDIO_OK || stream_ == nullptr) {
        stream_ = nullptr;
        return false;
    }
    sampleRate_ = AAudioStream_getSampleRate(stream_);
    if (AAudioStream_requestStart(stream_) != AAUDIO_OK) {
        AAudioStream_close(stream_);
        stream_ = nullptr;
        return false;
    }
    return true;
}

void AudioEngine::stop() {
    if (stream_ == nullptr) return;
    AAudioStream_requestStop(stream_);
    AAudioStream_close(stream_);
    stream_ = nullptr;
}

void AudioEngine::setTension(float value) {
    tension_.store(clamp(value, 0.0F, 1.0F), std::memory_order_relaxed);
}

void AudioEngine::trigger(GameEvent event) {
    switch (event) {
        case GameEvent::Attack:
        case GameEvent::EnemyHit:
        case GameEvent::PlayerHit:
            impactEnvelope_.store(1.0F, std::memory_order_relaxed);
            break;
        case GameEvent::GatherWood:
        case GameEvent::GatherStone:
        case GameEvent::GatherHerb:
        case GameEvent::Craft:
            gatherEnvelope_.store(1.0F, std::memory_order_relaxed);
            break;
        case GameEvent::TotemCorrect:
        case GameEvent::MysterySolved:
            mysteryEnvelope_.store(1.0F, std::memory_order_relaxed);
            break;
        default:
            break;
    }
}

aaudio_data_callback_result_t AudioEngine::dataCallback(
    AAudioStream*, void* userData, void* audioData, int32_t numFrames) {
    return static_cast<AudioEngine*>(userData)->render(static_cast<float*>(audioData), numFrames);
}

aaudio_data_callback_result_t AudioEngine::render(float* output, int32_t numFrames) {
    const float sampleRate = static_cast<float>(std::max(sampleRate_, 1));
    const float twoPi = 2.0F * kPi;
    const float tension = tension_.load(std::memory_order_relaxed);
    float impact = impactEnvelope_.load(std::memory_order_relaxed);
    float gather = gatherEnvelope_.load(std::memory_order_relaxed);
    float mystery = mysteryEnvelope_.load(std::memory_order_relaxed);

    for (int32_t frame = 0; frame < numFrames; ++frame) {
        noiseState_ = xorshift(noiseState_);
        const float noise = (static_cast<float>(noiseState_ & 0xFFFFU) / 32767.5F) - 1.0F;
        const float ambient = std::sin(ambientPhase_) * 0.035F +
                              std::sin(secondPhase_) * (0.018F + tension * 0.02F) +
                              noise * 0.004F;
        const float impactSound = std::sin(effectPhase_) * impact * 0.16F;
        const float gatherSound = std::sin(effectPhase_ * 1.71F) * gather * 0.10F;
        const float mysterySound = (std::sin(effectPhase_ * 0.55F) +
                                    std::sin(effectPhase_ * 0.82F)) * mystery * 0.07F;
        const float sample = clamp(ambient + impactSound + gatherSound + mysterySound, -0.7F, 0.7F);
        output[frame * 2] = sample;
        output[frame * 2 + 1] = sample * 0.96F;

        ambientPhase_ = std::fmod(ambientPhase_ + twoPi * 47.0F / sampleRate, twoPi);
        secondPhase_ = std::fmod(secondPhase_ + twoPi * (71.0F + tension * 17.0F) / sampleRate, twoPi);
        effectPhase_ = std::fmod(effectPhase_ + twoPi * 188.0F / sampleRate, twoPi);
        impact *= 0.9972F;
        gather *= 0.9984F;
        mystery *= 0.99915F;
    }
    impactEnvelope_.store(impact, std::memory_order_relaxed);
    gatherEnvelope_.store(gather, std::memory_order_relaxed);
    mysteryEnvelope_.store(mystery, std::memory_order_relaxed);
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

}  // namespace pk
