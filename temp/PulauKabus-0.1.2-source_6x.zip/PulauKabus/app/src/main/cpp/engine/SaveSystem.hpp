#pragma once

#include "game/GameWorld.hpp"

#include <string>

namespace pk {

class SaveSystem {
public:
    explicit SaveSystem(std::string directory);
    [[nodiscard]] bool load(WorldSnapshot& snapshot) const;
    [[nodiscard]] bool save(const WorldSnapshot& snapshot) const;

private:
    std::string savePath_;
};

}  // namespace pk
