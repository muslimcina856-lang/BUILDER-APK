#pragma once

#include "engine/Math.hpp"
#include "game/GameWorld.hpp"

#include <android/input.h>

#include <array>
#include <cstdint>

namespace pk {

class InputController {
public:
    void setViewport(int width, int height);
    bool handleEvent(AInputEvent* event);
    FrameInput consumeFrame();

    [[nodiscard]] float cameraYaw() const { return cameraYaw_; }
    [[nodiscard]] float cameraPitch() const { return cameraPitch_; }
    [[nodiscard]] Vec2 joystickVisual() const { return joystick_; }
    [[nodiscard]] bool joystickActive() const { return joystickPointer_ >= 0; }
    void recenterCamera(float playerFacing);

private:
    enum class Role : std::uint8_t { None, Joystick, Camera, Attack, Interact, Craft, Recenter, Pause };
    struct Pointer {
        int id = -1;
        Role role = Role::None;
        Vec2 start{};
        Vec2 last{};
    };

    Pointer* findPointer(int id);
    Pointer* allocatePointer(int id);
    Role roleForPosition(Vec2 normalized) const;
    void pointerDown(int id, float x, float y);
    void pointerMove(int id, float x, float y);
    void pointerUp(int id);
    Vec2 normalizeScreen(float x, float y) const;

    int width_ = 1;
    int height_ = 1;
    std::array<Pointer, 10> pointers_{};
    int joystickPointer_ = -1;
    Vec2 joystick_{};
    float cameraYaw_ = 0.0F;
    float cameraPitch_ = 0.34F;
    bool attackPressed_ = false;
    bool interactPressed_ = false;
    bool craftPressed_ = false;
    bool recenterPressed_ = false;
    bool pausePressed_ = false;
};

}  // namespace pk
