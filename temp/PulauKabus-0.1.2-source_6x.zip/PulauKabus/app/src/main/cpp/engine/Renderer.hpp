#pragma once

#include "engine/InputController.hpp"
#include "engine/Math.hpp"
#include "game/GameWorld.hpp"

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/native_window.h>

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace pk {

class Renderer {
public:
    Renderer() = default;
    ~Renderer();

    Renderer(const Renderer&) = delete;
    Renderer& operator=(const Renderer&) = delete;

    bool initialize(ANativeWindow* window, const GameWorld& world);
    void shutdown();
    void render(const GameWorld& world, const InputController& input, bool paused);
    [[nodiscard]] bool ready() const { return display_ != EGL_NO_DISPLAY; }
    [[nodiscard]] int width() const { return width_; }
    [[nodiscard]] int height() const { return height_; }

private:
    struct Vertex {
        Vec3 position{};
        Vec3 normal{};
    };
    struct Mesh {
        GLuint vao = 0;
        GLuint vbo = 0;
        GLuint ibo = 0;
        GLsizei indexCount = 0;
    };
    struct UiVertex {
        float x = 0.0F;
        float y = 0.0F;
        float r = 1.0F;
        float g = 1.0F;
        float b = 1.0F;
        float a = 1.0F;
    };

    bool createPrograms();
    GLuint compileShader(GLenum type, const char* source);
    Mesh uploadMesh(const std::vector<Vertex>& vertices, const std::vector<std::uint16_t>& indices);
    Mesh createCube();
    Mesh createOctahedron();
    Mesh createTerrain(const GameWorld& world);
    void destroyMesh(Mesh& mesh);
    void drawObject(const Mesh& mesh, const Mat4& viewProjection,
                    const Mat4& model, Vec3 color, float emissive = 0.0F);
    void drawWorld(const GameWorld& world, const InputController& input);
    void drawUi(const GameWorld& world, const InputController& input, bool paused);
    void addRect(float x, float y, float w, float h, std::array<float, 4> color);
    void addCircle(float x, float y, float radius, std::array<float, 4> color, int segments = 28);
    void addText(std::string text, float x, float y, float height,
                 std::array<float, 4> color, bool centered = false);
    static std::array<std::uint8_t, 7> glyph(char c);

    EGLDisplay display_ = EGL_NO_DISPLAY;
    EGLSurface surface_ = EGL_NO_SURFACE;
    EGLContext context_ = EGL_NO_CONTEXT;
    int width_ = 1;
    int height_ = 1;
    GLuint worldProgram_ = 0;
    GLuint uiProgram_ = 0;
    GLuint uiVao_ = 0;
    GLuint uiVbo_ = 0;
    Mesh cube_{};
    Mesh octahedron_{};
    Mesh terrain_{};
    std::vector<UiVertex> uiVertices_{};
    Vec3 cameraPosition_{};
};

}  // namespace pk
