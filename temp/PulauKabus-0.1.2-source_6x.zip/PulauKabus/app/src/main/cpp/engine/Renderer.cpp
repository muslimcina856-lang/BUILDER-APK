#include "engine/Renderer.hpp"

#include <android/log.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <sstream>

namespace pk {

namespace {
constexpr const char* kTag = "PulauKabus";
constexpr std::array<float, 4> kWhite{0.92F, 0.95F, 0.91F, 1.0F};
constexpr std::array<float, 4> kAmber{0.90F, 0.63F, 0.28F, 1.0F};
constexpr std::array<float, 4> kMist{0.42F, 0.59F, 0.58F, 0.75F};

const char* kWorldVertex = R"GLSL(#version 300 es
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
uniform mat4 uViewProjection;
uniform mat4 uModel;
out vec3 vWorldPosition;
out vec3 vNormal;
void main() {
    vec4 world = uModel * vec4(aPosition, 1.0);
    vWorldPosition = world.xyz;
    vNormal = normalize(mat3(uModel) * aNormal);
    gl_Position = uViewProjection * world;
})GLSL";

const char* kWorldFragment = R"GLSL(#version 300 es
precision mediump float;
in vec3 vWorldPosition;
in vec3 vNormal;
uniform vec3 uColor;
uniform vec3 uCameraPosition;
uniform vec3 uFogColor;
uniform float uEmissive;
out vec4 outColor;
void main() {
    vec3 lightDirection = normalize(vec3(-0.45, 0.82, 0.31));
    float diffuse = max(dot(normalize(vNormal), lightDirection), 0.0);
    float rim = pow(1.0 - max(dot(normalize(uCameraPosition-vWorldPosition), normalize(vNormal)), 0.0), 2.0);
    vec3 lit = uColor * (0.36 + diffuse * 0.66) + rim * uColor * 0.16 + uColor * uEmissive;
    float distanceToCamera = distance(vWorldPosition, uCameraPosition);
    float fog = smoothstep(13.0, 43.0, distanceToCamera);
    outColor = vec4(mix(lit, uFogColor, fog), 1.0);
})GLSL";

const char* kUiVertex = R"GLSL(#version 300 es
layout(location=0) in vec2 aPosition;
layout(location=1) in vec4 aColor;
out vec4 vColor;
void main() {
    vColor = aColor;
    gl_Position = vec4(aPosition, 0.0, 1.0);
})GLSL";

const char* kUiFragment = R"GLSL(#version 300 es
precision mediump float;
in vec4 vColor;
out vec4 outColor;
void main() { outColor = vColor; }
)GLSL";
}

Renderer::~Renderer() { shutdown(); }

bool Renderer::initialize(ANativeWindow* window, const GameWorld& world) {
    shutdown();
    if (window == nullptr) return false;
    display_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display_ == EGL_NO_DISPLAY || eglInitialize(display_, nullptr, nullptr) != EGL_TRUE) {
        display_ = EGL_NO_DISPLAY;
        return false;
    }
    const EGLint configAttributes[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 24, EGL_NONE
    };
    EGLConfig config = nullptr;
    EGLint configCount = 0;
    if (eglChooseConfig(display_, configAttributes, &config, 1, &configCount) != EGL_TRUE || configCount == 0) {
        shutdown();
        return false;
    }
    EGLint format = 0;
    eglGetConfigAttrib(display_, config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(window, 0, 0, format);
    surface_ = eglCreateWindowSurface(display_, config, window, nullptr);
    const EGLint contextAttributes[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    context_ = eglCreateContext(display_, config, EGL_NO_CONTEXT, contextAttributes);
    if (surface_ == EGL_NO_SURFACE || context_ == EGL_NO_CONTEXT ||
        eglMakeCurrent(display_, surface_, surface_, context_) != EGL_TRUE) {
        shutdown();
        return false;
    }
    eglQuerySurface(display_, surface_, EGL_WIDTH, &width_);
    eglQuerySurface(display_, surface_, EGL_HEIGHT, &height_);
    eglSwapInterval(display_, 1);
    if (!createPrograms()) {
        shutdown();
        return false;
    }

    cube_ = createCube();
    octahedron_ = createOctahedron();
    terrain_ = createTerrain(world);
    glGenVertexArrays(1, &uiVao_);
    glGenBuffers(1, &uiVbo_);
    glBindVertexArray(uiVao_);
    glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
    glBufferData(GL_ARRAY_BUFFER, 1024 * 1024, nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(UiVertex),
                          reinterpret_cast<void*>(offsetof(UiVertex, x)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, sizeof(UiVertex),
                          reinterpret_cast<void*>(offsetof(UiVertex, r)));
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    __android_log_print(ANDROID_LOG_INFO, kTag, "OpenGL ES renderer ready: %dx%d", width_, height_);
    return true;
}

void Renderer::shutdown() {
    if (display_ != EGL_NO_DISPLAY && context_ != EGL_NO_CONTEXT) {
        eglMakeCurrent(display_, surface_, surface_, context_);
        destroyMesh(cube_);
        destroyMesh(octahedron_);
        destroyMesh(terrain_);
        if (uiVbo_ != 0) glDeleteBuffers(1, &uiVbo_);
        if (uiVao_ != 0) glDeleteVertexArrays(1, &uiVao_);
        if (worldProgram_ != 0) glDeleteProgram(worldProgram_);
        if (uiProgram_ != 0) glDeleteProgram(uiProgram_);
    }
    uiVbo_ = uiVao_ = worldProgram_ = uiProgram_ = 0;
    if (display_ != EGL_NO_DISPLAY) {
        eglMakeCurrent(display_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context_ != EGL_NO_CONTEXT) eglDestroyContext(display_, context_);
        if (surface_ != EGL_NO_SURFACE) eglDestroySurface(display_, surface_);
        eglTerminate(display_);
    }
    display_ = EGL_NO_DISPLAY;
    surface_ = EGL_NO_SURFACE;
    context_ = EGL_NO_CONTEXT;
}

GLuint Renderer::compileShader(GLenum type, const char* source) {
    const GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    GLint compiled = GL_FALSE;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
    if (compiled != GL_TRUE) {
        std::array<char, 1024> log{};
        glGetShaderInfoLog(shader, static_cast<GLsizei>(log.size()), nullptr, log.data());
        __android_log_print(ANDROID_LOG_ERROR, kTag, "Shader error: %s", log.data());
        glDeleteShader(shader);
        return 0;
    }
    return shader;
}

bool Renderer::createPrograms() {
    auto link = [this](const char* vertexSource, const char* fragmentSource) -> GLuint {
        const GLuint vertex = compileShader(GL_VERTEX_SHADER, vertexSource);
        const GLuint fragment = compileShader(GL_FRAGMENT_SHADER, fragmentSource);
        if (vertex == 0 || fragment == 0) return 0;
        const GLuint program = glCreateProgram();
        glAttachShader(program, vertex);
        glAttachShader(program, fragment);
        glLinkProgram(program);
        glDeleteShader(vertex);
        glDeleteShader(fragment);
        GLint linked = GL_FALSE;
        glGetProgramiv(program, GL_LINK_STATUS, &linked);
        if (linked != GL_TRUE) {
            glDeleteProgram(program);
            return 0;
        }
        return program;
    };
    worldProgram_ = link(kWorldVertex, kWorldFragment);
    uiProgram_ = link(kUiVertex, kUiFragment);
    return worldProgram_ != 0 && uiProgram_ != 0;
}

Renderer::Mesh Renderer::uploadMesh(const std::vector<Vertex>& vertices,
                                    const std::vector<std::uint16_t>& indices) {
    Mesh mesh;
    glGenVertexArrays(1, &mesh.vao);
    glGenBuffers(1, &mesh.vbo);
    glGenBuffers(1, &mesh.ibo);
    glBindVertexArray(mesh.vao);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(vertices.size() * sizeof(Vertex)),
                 vertices.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 static_cast<GLsizeiptr>(indices.size() * sizeof(std::uint16_t)),
                 indices.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                          reinterpret_cast<void*>(offsetof(Vertex, position)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                          reinterpret_cast<void*>(offsetof(Vertex, normal)));
    glBindVertexArray(0);
    mesh.indexCount = static_cast<GLsizei>(indices.size());
    return mesh;
}

Renderer::Mesh Renderer::createCube() {
    const std::array<Vec3, 8> p{{{-0.5F,-0.5F,-0.5F},{0.5F,-0.5F,-0.5F},{0.5F,0.5F,-0.5F},{-0.5F,0.5F,-0.5F},
                                  {-0.5F,-0.5F,0.5F},{0.5F,-0.5F,0.5F},{0.5F,0.5F,0.5F},{-0.5F,0.5F,0.5F}}};
    const std::array<std::array<int, 4>, 6> faces{{{{0,3,2,1}},{{4,5,6,7}},{{0,4,7,3}},
                                                   {{1,2,6,5}},{{3,7,6,2}},{{0,1,5,4}}}};
    const std::array<Vec3, 6> normals{{{0,0,-1},{0,0,1},{-1,0,0},{1,0,0},{0,1,0},{0,-1,0}}};
    std::vector<Vertex> vertices;
    std::vector<std::uint16_t> indices;
    for (std::size_t face = 0; face < faces.size(); ++face) {
        const std::uint16_t base = static_cast<std::uint16_t>(vertices.size());
        for (int index : faces[face]) vertices.push_back({p[static_cast<std::size_t>(index)], normals[face]});
        indices.insert(indices.end(), {base, static_cast<std::uint16_t>(base+1), static_cast<std::uint16_t>(base+2),
                                       base, static_cast<std::uint16_t>(base+2), static_cast<std::uint16_t>(base+3)});
    }
    return uploadMesh(vertices, indices);
}

Renderer::Mesh Renderer::createOctahedron() {
    const std::array<Vec3, 6> p{{{0,0.75F,0},{0,-0.75F,0},{-0.62F,0,0},{0.62F,0,0},{0,0,-0.62F},{0,0,0.62F}}};
    const std::array<std::array<int,3>,8> faces{{{{0,4,3}},{{0,3,5}},{{0,5,2}},{{0,2,4}},
                                                 {{1,3,4}},{{1,5,3}},{{1,2,5}},{{1,4,2}}}};
    std::vector<Vertex> vertices;
    std::vector<std::uint16_t> indices;
    for (const auto& f : faces) {
        const Vec3 normal = normalize(cross(p[static_cast<std::size_t>(f[1])] - p[static_cast<std::size_t>(f[0])],
                                            p[static_cast<std::size_t>(f[2])] - p[static_cast<std::size_t>(f[0])]));
        const std::uint16_t base = static_cast<std::uint16_t>(vertices.size());
        for (int index : f) vertices.push_back({p[static_cast<std::size_t>(index)], normal});
        indices.insert(indices.end(), {base, static_cast<std::uint16_t>(base+1), static_cast<std::uint16_t>(base+2)});
    }
    return uploadMesh(vertices, indices);
}

Renderer::Mesh Renderer::createTerrain(const GameWorld& world) {
    constexpr int resolution = 48;
    constexpr float size = 68.0F;
    std::vector<Vertex> vertices;
    std::vector<std::uint16_t> indices;
    vertices.reserve(static_cast<std::size_t>((resolution + 1) * (resolution + 1)));
    for (int z = 0; z <= resolution; ++z) {
        for (int x = 0; x <= resolution; ++x) {
            const float px = -size * 0.5F + size * static_cast<float>(x) / static_cast<float>(resolution);
            const float pz = -size * 0.5F + size * static_cast<float>(z) / static_cast<float>(resolution);
            const float h = world.terrainHeight(px, pz);
            const float hx = world.terrainHeight(px + 0.2F, pz) - world.terrainHeight(px - 0.2F, pz);
            const float hz = world.terrainHeight(px, pz + 0.2F) - world.terrainHeight(px, pz - 0.2F);
            vertices.push_back({{px, h, pz}, normalize({-hx, 0.4F, -hz})});
        }
    }
    for (int z = 0; z < resolution; ++z) {
        for (int x = 0; x < resolution; ++x) {
            const std::uint16_t a = static_cast<std::uint16_t>(z * (resolution + 1) + x);
            const std::uint16_t b = static_cast<std::uint16_t>(a + 1);
            const std::uint16_t c = static_cast<std::uint16_t>(a + resolution + 1);
            const std::uint16_t d = static_cast<std::uint16_t>(c + 1);
            indices.insert(indices.end(), {a, c, b, b, c, d});
        }
    }
    return uploadMesh(vertices, indices);
}

void Renderer::destroyMesh(Mesh& mesh) {
    if (mesh.ibo != 0) glDeleteBuffers(1, &mesh.ibo);
    if (mesh.vbo != 0) glDeleteBuffers(1, &mesh.vbo);
    if (mesh.vao != 0) glDeleteVertexArrays(1, &mesh.vao);
    mesh = {};
}

void Renderer::drawObject(const Mesh& mesh, const Mat4& viewProjection,
                          const Mat4& model, Vec3 color, float emissive) {
    glUniformMatrix4fv(glGetUniformLocation(worldProgram_, "uViewProjection"), 1, GL_FALSE,
                       viewProjection.v.data());
    glUniformMatrix4fv(glGetUniformLocation(worldProgram_, "uModel"), 1, GL_FALSE, model.v.data());
    glUniform3f(glGetUniformLocation(worldProgram_, "uColor"), color.x, color.y, color.z);
    glUniform3f(glGetUniformLocation(worldProgram_, "uCameraPosition"),
                cameraPosition_.x, cameraPosition_.y, cameraPosition_.z);
    glUniform3f(glGetUniformLocation(worldProgram_, "uFogColor"), 0.31F, 0.43F, 0.45F);
    glUniform1f(glGetUniformLocation(worldProgram_, "uEmissive"), emissive);
    glBindVertexArray(mesh.vao);
    glDrawElements(GL_TRIANGLES, mesh.indexCount, GL_UNSIGNED_SHORT, nullptr);
}

void Renderer::render(const GameWorld& world, const InputController& input, bool paused) {
    if (!ready()) return;
    glViewport(0, 0, width_, height_);
    glClearColor(0.23F, 0.34F, 0.37F, 1.0F);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    drawWorld(world, input);
    drawUi(world, input, paused);
    eglSwapBuffers(display_, surface_);
}

void Renderer::drawWorld(const GameWorld& world, const InputController& input) {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glUseProgram(worldProgram_);
    const Vec3 target = world.player().position + Vec3{0.0F, 1.25F, 0.0F};
    const float pitch = input.cameraPitch();
    const float yaw = input.cameraYaw();
    const float horizontal = std::cos(pitch) * 7.4F;
    cameraPosition_ = target + Vec3{-std::sin(yaw) * horizontal,
                                     1.15F + std::sin(pitch) * 7.4F,
                                     -std::cos(yaw) * horizontal};
    cameraPosition_.y = std::max(cameraPosition_.y, world.terrainHeight(cameraPosition_.x, cameraPosition_.z) + 0.8F);
    const Mat4 view = lookAt(cameraPosition_, target, {0,1,0});
    const Mat4 projection = perspective(57.0F * kPi / 180.0F,
                                        static_cast<float>(width_) / static_cast<float>(height_), 0.1F, 75.0F);
    const Mat4 vp = projection * view;

    drawObject(terrain_, vp, Mat4::identity(), {0.19F, 0.37F, 0.28F});
    drawObject(cube_, vp, translation({0,-0.57F,0}) * scale({68,0.18F,68}), {0.12F,0.35F,0.43F});

    const Vec3 camp = world.campPosition();
    drawObject(cube_, vp, translation(camp + Vec3{2.0F,0.55F,0}) * scale({2.1F,0.15F,0.8F}), {0.34F,0.20F,0.11F});
    drawObject(cube_, vp, translation(camp + Vec3{2.0F,0.12F,0}) * scale({0.15F,0.9F,0.15F}), {0.25F,0.14F,0.08F});
    drawObject(octahedron_, vp, translation(camp + Vec3{0,0.42F,0}) * scale({0.55F,0.75F,0.55F}), {1.0F,0.38F,0.08F}, 0.75F);

    for (const ResourceNode& resource : world.resources()) {
        if (!resource.available) continue;
        if (resource.type == ResourceType::Wood) {
            drawObject(cube_, vp, translation(resource.position + Vec3{0,1.1F,0}) * scale({0.45F,2.2F,0.45F}), {0.30F,0.18F,0.09F});
            drawObject(octahedron_, vp, translation(resource.position + Vec3{0,2.65F,0}) * scale({1.65F,1.7F,1.65F}), {0.18F,0.46F,0.28F});
        } else if (resource.type == ResourceType::Stone) {
            drawObject(octahedron_, vp, translation(resource.position + Vec3{0,0.45F,0}) * scale({1.0F,0.75F,0.9F}), {0.38F,0.43F,0.42F});
        } else {
            for (int leaf = -1; leaf <= 1; ++leaf) {
                drawObject(octahedron_, vp,
                           translation(resource.position + Vec3{static_cast<float>(leaf)*0.24F,0.35F,0}) *
                           scale({0.22F,0.48F,0.22F}), {0.42F,0.66F,0.42F});
            }
        }
    }

    for (const EnemyState& enemy : world.enemies()) {
        if (!enemy.alive) continue;
        const float bob = std::sin(world.worldTime() * 700.0F + enemy.position.x) * 0.08F;
        drawObject(octahedron_, vp, translation(enemy.position + Vec3{0,1.0F+bob,0}) * scale({0.9F,1.4F,0.9F}), {0.08F,0.19F,0.20F});
        drawObject(octahedron_, vp, translation(enemy.position + Vec3{-0.3F,1.3F+bob,0.52F}) * scale({0.09F,0.09F,0.09F}), {0.84F,0.55F,0.25F}, 1.3F);
        drawObject(octahedron_, vp, translation(enemy.position + Vec3{0.3F,1.3F+bob,0.52F}) * scale({0.09F,0.09F,0.09F}), {0.84F,0.55F,0.25F}, 1.3F);
    }

    for (const TotemState& totem : world.totems()) {
        const Vec3 color = totem.active ? Vec3{0.30F,0.82F,0.75F} : Vec3{0.31F,0.36F,0.35F};
        drawObject(cube_, vp, translation(totem.position + Vec3{0,1.25F,0}) * scale({0.85F,2.5F,0.65F}), color, totem.active ? 0.6F : 0.0F);
        drawObject(octahedron_, vp, translation(totem.position + Vec3{0,2.8F,0}) * scale({0.65F,0.7F,0.65F}), color, totem.active ? 0.8F : 0.0F);
    }

    const PlayerState& player = world.player();
    const Mat4 playerRoot = translation(player.position) * rotationY(player.facing);
    drawObject(cube_, vp, playerRoot * translation({0,1.05F,0}) * scale({0.65F,1.25F,0.42F}), {0.62F,0.54F,0.40F});
    drawObject(octahedron_, vp, playerRoot * translation({0,2.0F,0}) * scale({0.47F,0.55F,0.47F}), {0.67F,0.48F,0.33F});
    drawObject(cube_, vp, playerRoot * translation({0,1.15F,-0.35F}) * scale({0.52F,0.72F,0.28F}), {0.25F,0.16F,0.10F});
    drawObject(cube_, vp, playerRoot * translation({0.52F,1.1F,0.18F}) * rotationY(-0.25F) * scale({0.07F,1.55F,0.07F}), {0.44F,0.27F,0.12F});

    // Ancient gate: the long-term visual objective visible through the fog.
    const Vec3 gate{0.0F, world.terrainHeight(0.0F, -27.0F), -27.0F};
    drawObject(cube_, vp, translation(gate + Vec3{-2.4F,2.2F,0}) * scale({1.2F,4.4F,1.2F}), {0.28F,0.33F,0.31F});
    drawObject(cube_, vp, translation(gate + Vec3{2.4F,2.2F,0}) * scale({1.2F,4.4F,1.2F}), {0.28F,0.33F,0.31F});
    drawObject(cube_, vp, translation(gate + Vec3{0,4.2F,0}) * scale({5.8F,1.0F,1.3F}), {0.28F,0.33F,0.31F});
}

void Renderer::addRect(float x, float y, float w, float h, std::array<float, 4> c) {
    const float left = x * 2.0F - 1.0F;
    const float right = (x + w) * 2.0F - 1.0F;
    const float top = 1.0F - y * 2.0F;
    const float bottom = 1.0F - (y + h) * 2.0F;
    const UiVertex a{left,top,c[0],c[1],c[2],c[3]};
    const UiVertex b{right,top,c[0],c[1],c[2],c[3]};
    const UiVertex d{left,bottom,c[0],c[1],c[2],c[3]};
    const UiVertex e{right,bottom,c[0],c[1],c[2],c[3]};
    uiVertices_.insert(uiVertices_.end(), {a,d,b,b,d,e});
}

void Renderer::addCircle(float x, float y, float radius, std::array<float, 4> c, int segments) {
    const float aspect = static_cast<float>(height_) / static_cast<float>(width_);
    for (int i = 0; i < segments; ++i) {
        const float a0 = 2.0F * kPi * static_cast<float>(i) / static_cast<float>(segments);
        const float a1 = 2.0F * kPi * static_cast<float>(i + 1) / static_cast<float>(segments);
        const auto make = [&](float px, float py) {
            return UiVertex{px * 2.0F - 1.0F, 1.0F - py * 2.0F, c[0],c[1],c[2],c[3]};
        };
        uiVertices_.push_back(make(x,y));
        uiVertices_.push_back(make(x + std::cos(a0)*radius*aspect, y + std::sin(a0)*radius));
        uiVertices_.push_back(make(x + std::cos(a1)*radius*aspect, y + std::sin(a1)*radius));
    }
}

std::array<std::uint8_t, 7> Renderer::glyph(char c) {
    switch (c) {
        case 'A': return {14,17,17,31,17,17,17}; case 'B': return {30,17,17,30,17,17,30};
        case 'C': return {14,17,16,16,16,17,14}; case 'D': return {30,17,17,17,17,17,30};
        case 'E': return {31,16,16,30,16,16,31}; case 'F': return {31,16,16,30,16,16,16};
        case 'G': return {14,17,16,23,17,17,15}; case 'H': return {17,17,17,31,17,17,17};
        case 'I': return {31,4,4,4,4,4,31}; case 'J': return {1,1,1,1,17,17,14};
        case 'K': return {17,18,20,24,20,18,17}; case 'L': return {16,16,16,16,16,16,31};
        case 'M': return {17,27,21,21,17,17,17}; case 'N': return {17,25,21,19,17,17,17};
        case 'O': return {14,17,17,17,17,17,14}; case 'P': return {30,17,17,30,16,16,16};
        case 'Q': return {14,17,17,17,21,18,13}; case 'R': return {30,17,17,30,20,18,17};
        case 'S': return {15,16,16,14,1,1,30}; case 'T': return {31,4,4,4,4,4,4};
        case 'U': return {17,17,17,17,17,17,14}; case 'V': return {17,17,17,17,17,10,4};
        case 'W': return {17,17,17,21,21,21,10}; case 'X': return {17,17,10,4,10,17,17};
        case 'Y': return {17,17,10,4,4,4,4}; case 'Z': return {31,1,2,4,8,16,31};
        case '0': return {14,17,19,21,25,17,14}; case '1': return {4,12,4,4,4,4,14};
        case '2': return {14,17,1,2,4,8,31}; case '3': return {30,1,1,14,1,1,30};
        case '4': return {2,6,10,18,31,2,2}; case '5': return {31,16,16,30,1,1,30};
        case '6': return {14,16,16,30,17,17,14}; case '7': return {31,1,2,4,8,8,8};
        case '8': return {14,17,17,14,17,17,14}; case '9': return {14,17,17,15,1,1,14};
        case ':': return {0,4,4,0,4,4,0}; default: return {0,0,0,0,0,0,0};
    }
}

void Renderer::addText(std::string text, float x, float y, float height,
                       std::array<float, 4> color, bool centered) {
    const float pixel = height / 7.0F;
    const float charWidth = pixel * 6.0F * static_cast<float>(height_) / static_cast<float>(width_);
    if (centered) x -= charWidth * static_cast<float>(text.size()) * 0.5F;
    for (char c : text) {
        const auto rows = glyph(c);
        for (int row = 0; row < 7; ++row) {
            for (int col = 0; col < 5; ++col) {
                if ((rows[static_cast<std::size_t>(row)] & (1U << static_cast<unsigned>(4-col))) != 0) {
                    addRect(x + static_cast<float>(col) * pixel * static_cast<float>(height_) / static_cast<float>(width_),
                            y + static_cast<float>(row) * pixel,
                            pixel * 0.82F * static_cast<float>(height_) / static_cast<float>(width_),
                            pixel * 0.82F, color);
                }
            }
        }
        x += charWidth;
    }
}

void Renderer::drawUi(const GameWorld& world, const InputController& input, bool paused) {
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    uiVertices_.clear();

    addRect(0.025F,0.035F,0.25F,0.085F,{0.02F,0.07F,0.08F,0.72F});
    addRect(0.04F,0.052F,0.19F,0.018F,{0.16F,0.16F,0.15F,0.9F});
    addRect(0.04F,0.052F,0.19F * world.player().health/100.0F,0.018F,{0.68F,0.20F,0.17F,0.95F});
    addRect(0.04F,0.082F,0.19F,0.012F,{0.13F,0.17F,0.16F,0.9F});
    addRect(0.04F,0.082F,0.19F * world.player().stamina/100.0F,0.012F,{0.35F,0.67F,0.50F,0.95F});

    std::ostringstream resources;
    resources << "KAYU " << world.player().wood << "  BATU " << world.player().stone
              << "  HERBA " << world.player().herbs;
    addText(resources.str(),0.03F,0.135F,0.026F,kWhite);
    addRect(0.26F,0.025F,0.48F,0.058F,{0.02F,0.07F,0.08F,0.68F});
    addText(world.objectiveText(),0.50F,0.043F,0.026F,kWhite,true);

    addCircle(0.16F,0.78F,0.105F,{0.06F,0.11F,0.12F,0.40F});
    const Vec2 stick = input.joystickVisual();
    addCircle(0.16F + stick.x*0.045F*static_cast<float>(height_)/static_cast<float>(width_),
              0.78F - stick.y*0.045F,0.047F,{0.65F,0.73F,0.68F,0.55F});

    addCircle(0.88F,0.68F,0.09F,{0.49F,0.18F,0.13F,0.67F});
    addCircle(0.74F,0.82F,0.075F,{0.26F,0.48F,0.43F,0.67F});
    addCircle(0.91F,0.47F,0.065F,{0.62F,0.43F,0.20F,0.67F});
    addCircle(0.93F,0.15F,0.055F,{0.16F,0.25F,0.27F,0.67F});
    addCircle(0.975F,0.055F,0.038F,{0.08F,0.14F,0.15F,0.72F});
    addText("SERANG",0.88F,0.667F,0.022F,kWhite,true);
    addText("AMBIL",0.74F,0.808F,0.020F,kWhite,true);
    addText("BINA",0.91F,0.458F,0.019F,kWhite,true);
    addText("360",0.93F,0.138F,0.021F,kMist,true);
    addText("II",0.975F,0.044F,0.021F,kWhite,true);

    if (distanceXZ(world.player().position, world.campPosition()) < 3.2F) {
        addRect(0.36F,0.88F,0.28F,0.052F,{0.02F,0.07F,0.08F,0.72F});
        addText("BINA: 3 KAYU 2 BATU",0.50F,0.894F,0.024F,kAmber,true);
    }

    if (paused) {
        addRect(0.0F,0.0F,1.0F,1.0F,{0.01F,0.04F,0.05F,0.66F});
        addRect(0.31F,0.32F,0.38F,0.27F,{0.03F,0.10F,0.11F,0.92F});
        addText("DIJEDA",0.50F,0.385F,0.052F,kWhite,true);
        addText("TEKAN II UNTUK SAMBUNG",0.50F,0.505F,0.025F,kAmber,true);
    }

    glUseProgram(uiProgram_);
    glBindVertexArray(uiVao_);
    glBindBuffer(GL_ARRAY_BUFFER, uiVbo_);
    glBufferSubData(GL_ARRAY_BUFFER, 0,
                    static_cast<GLsizeiptr>(uiVertices_.size() * sizeof(UiVertex)), uiVertices_.data());
    glDrawArrays(GL_TRIANGLES, 0, static_cast<GLsizei>(uiVertices_.size()));
    glBindVertexArray(0);
    glDisable(GL_BLEND);
}

}  // namespace pk
