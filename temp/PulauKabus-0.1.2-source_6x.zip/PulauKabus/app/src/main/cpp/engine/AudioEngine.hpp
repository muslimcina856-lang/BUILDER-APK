#pragma once

#include "game/GameWorld.hpp"

#include <aaudio/AAudio.h>

#include <atomic>

namespace pk {

class AudioEngine {
public:
    AudioEngine() = default;
    ~AudioEngine();

    AudioEngine(const AudioEngine&) = delete;
    AudioEngine& operator=(const AudioEngine&) = delete;

    bool start();
    void stop();
    void setTension(float value);
    void trigger(GameEvent event);

private:
    static aaudio_data_callback_result_t dataCallback(
        AAudioStream* stream, void* userData, void* audioData, int32_t numFrames);
    aaudio_data_callback_result_t render(float* output, int32_t numFrames);

    AAudioStream* stream_ = nullptr;
    int32_t sampleRate_ = 48000;
    std::atomic<float> tension_{0.0F};
    std::atomic<float> impactEnvelope_{0.0F};
    std::atomic<float> gatherEnvelope_{0.0F};
    std::atomic<float> mysteryEnvelope_{0.0F};
    float ambientPhase_ = 0.0F;
    float secondPhase_ = 0.0F;
    float effectPhase_ = 0.0F;
    std::uint32_t noiseState_ = 0x91A2B3C4U;
};

}  // namespace pk
