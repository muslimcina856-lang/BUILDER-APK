#include "engine/InputController.hpp"

#include <algorithm>
#include <cmath>

namespace pk {

namespace {
bool inCircle(Vec2 p, Vec2 center, float radius) {
    const Vec2 delta = p - center;
    return delta.x * delta.x + delta.y * delta.y <= radius * radius;
}
}

void InputController::setViewport(int width, int height) {
    width_ = std::max(width, 1);
    height_ = std::max(height, 1);
}

Vec2 InputController::normalizeScreen(float x, float y) const {
    return {x / static_cast<float>(width_), y / static_cast<float>(height_)};
}

InputController::Pointer* InputController::findPointer(int id) {
    for (Pointer& pointer : pointers_) {
        if (pointer.id == id) return &pointer;
    }
    return nullptr;
}

InputController::Pointer* InputController::allocatePointer(int id) {
    for (Pointer& pointer : pointers_) {
        if (pointer.id < 0) {
            pointer.id = id;
            return &pointer;
        }
    }
    return nullptr;
}

InputController::Role InputController::roleForPosition(Vec2 p) const {
    if (inCircle(p, {0.975F, 0.055F}, 0.045F)) return Role::Pause;
    if (inCircle(p, {0.88F, 0.68F}, 0.09F)) return Role::Attack;
    if (inCircle(p, {0.74F, 0.82F}, 0.075F)) return Role::Interact;
    if (inCircle(p, {0.91F, 0.47F}, 0.065F)) return Role::Craft;
    if (inCircle(p, {0.93F, 0.15F}, 0.055F)) return Role::Recenter;
    if (p.x < 0.43F && p.y > 0.38F) return Role::Joystick;
    return Role::Camera;
}

void InputController::pointerDown(int id, float x, float y) {
    Pointer* pointer = allocatePointer(id);
    if (pointer == nullptr) return;
    const Vec2 p = normalizeScreen(x, y);
    pointer->start = p;
    pointer->last = p;
    pointer->role = roleForPosition(p);
    switch (pointer->role) {
        case Role::Joystick:
            if (joystickPointer_ < 0) joystickPointer_ = id;
            else pointer->role = Role::Camera;
            break;
        case Role::Attack: attackPressed_ = true; break;
        case Role::Interact: interactPressed_ = true; break;
        case Role::Craft: craftPressed_ = true; break;
        case Role::Recenter: recenterPressed_ = true; break;
        case Role::Pause: pausePressed_ = true; break;
        default: break;
    }
}

void InputController::pointerMove(int id, float x, float y) {
    Pointer* pointer = findPointer(id);
    if (pointer == nullptr) return;
    const Vec2 current = normalizeScreen(x, y);
    if (pointer->role == Role::Joystick && joystickPointer_ == id) {
        Vec2 delta = current - pointer->start;
        delta.y = -delta.y;
        const float maxRadius = 0.11F;
        if (length(delta) > maxRadius) delta = normalize(delta) * maxRadius;
        joystick_ = delta * (1.0F / maxRadius);
    } else if (pointer->role == Role::Camera) {
        const Vec2 delta = current - pointer->last;
        cameraYaw_ -= delta.x * 4.2F;
        cameraPitch_ = clamp(cameraPitch_ - delta.y * 3.2F, -0.12F, 0.78F);
        if (cameraYaw_ > kPi) cameraYaw_ -= 2.0F * kPi;
        if (cameraYaw_ < -kPi) cameraYaw_ += 2.0F * kPi;
    }
    pointer->last = current;
}

void InputController::pointerUp(int id) {
    Pointer* pointer = findPointer(id);
    if (pointer == nullptr) return;
    if (pointer->role == Role::Joystick && joystickPointer_ == id) {
        joystickPointer_ = -1;
        joystick_ = {};
    }
    *pointer = {};
    pointer->id = -1;
}

bool InputController::handleEvent(AInputEvent* event) {
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_KEY) {
        const int32_t keyCode = AKeyEvent_getKeyCode(event);
        if (AKeyEvent_getAction(event) == AKEY_EVENT_ACTION_DOWN &&
            (keyCode == AKEYCODE_BACK || keyCode == AKEYCODE_MENU)) {
            pausePressed_ = true;
            return true;
        }
        return false;
    }
    if (AInputEvent_getType(event) != AINPUT_EVENT_TYPE_MOTION) return false;
    const std::uint32_t source = static_cast<std::uint32_t>(AInputEvent_getSource(event));
    if ((source & static_cast<std::uint32_t>(AINPUT_SOURCE_TOUCHSCREEN)) == 0U) return false;

    const int action = AMotionEvent_getAction(event);
    const int actionMasked = action & AMOTION_EVENT_ACTION_MASK;
    const int actionIndex = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >>
                            AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    const std::size_t pointerCount = AMotionEvent_getPointerCount(event);

    if (actionMasked == AMOTION_EVENT_ACTION_DOWN ||
        actionMasked == AMOTION_EVENT_ACTION_POINTER_DOWN) {
        const std::size_t index = static_cast<std::size_t>(actionIndex);
        pointerDown(AMotionEvent_getPointerId(event, index),
                    AMotionEvent_getX(event, index), AMotionEvent_getY(event, index));
    } else if (actionMasked == AMOTION_EVENT_ACTION_MOVE) {
        for (std::size_t index = 0; index < pointerCount; ++index) {
            pointerMove(AMotionEvent_getPointerId(event, index),
                        AMotionEvent_getX(event, index), AMotionEvent_getY(event, index));
        }
    } else if (actionMasked == AMOTION_EVENT_ACTION_UP ||
               actionMasked == AMOTION_EVENT_ACTION_POINTER_UP) {
        const std::size_t index = static_cast<std::size_t>(actionIndex);
        pointerUp(AMotionEvent_getPointerId(event, index));
    } else if (actionMasked == AMOTION_EVENT_ACTION_CANCEL) {
        for (Pointer& pointer : pointers_) {
            pointer = {};
            pointer.id = -1;
        }
        joystickPointer_ = -1;
        joystick_ = {};
    }
    return true;
}

FrameInput InputController::consumeFrame() {
    FrameInput result;
    result.movement = joystick_;
    result.cameraYaw = cameraYaw_;
    result.attackPressed = attackPressed_;
    result.interactPressed = interactPressed_;
    result.craftPressed = craftPressed_;
    result.recenterPressed = recenterPressed_;
    result.pausePressed = pausePressed_;
    attackPressed_ = false;
    interactPressed_ = false;
    craftPressed_ = false;
    recenterPressed_ = false;
    pausePressed_ = false;
    return result;
}

void InputController::recenterCamera(float playerFacing) {
    cameraYaw_ = playerFacing;
    cameraPitch_ = 0.34F;
}

}  // namespace pk
