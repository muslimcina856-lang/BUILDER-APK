#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")/.." && pwd)"
root_build="$project_dir/build.gradle.kts"
app_build="$project_dir/app/build.gradle.kts"
wrapper="$project_dir/gradle/wrapper/gradle-wrapper.properties"
main_cpp="$project_dir/app/src/main/cpp/main.cpp"
input_cpp="$project_dir/app/src/main/cpp/engine/InputController.cpp"
manifest="$project_dir/app/src/main/AndroidManifest.xml"

assert_contains() {
  local file="$1"
  local expected="$2"
  if ! grep -Fq "$expected" "$file"; then
    echo "GAGAL: $file tidak mengandungi: $expected" >&2
    exit 1
  fi
}

assert_not_contains() {
  local file="$1"
  local unexpected="$2"
  if grep -Fq "$unexpected" "$file"; then
    echo "GAGAL: $file masih mengandungi: $unexpected" >&2
    exit 1
  fi
}

assert_contains "$root_build" 'version "8.9.2"'
assert_contains "$app_build" 'compileSdk = 35'
assert_contains "$app_build" 'targetSdk = 35'
assert_contains "$app_build" 'JavaVersion.VERSION_17'
assert_contains "$app_build" 'ndkVersion = "27.0.12077973"'
assert_contains "$wrapper" 'gradle-8.11.1-bin.zip'
assert_contains "$main_cpp" '#include <android/window.h>'
assert_not_contains "$main_cpp" 'app_dummy();'
assert_contains "$input_cpp" 'const std::uint32_t source'
assert_not_contains "$manifest" 'android:extractNativeLibs'

echo "Konfigurasi binaan dan keserasian NDK 27 disahkan."
