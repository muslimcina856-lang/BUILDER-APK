#include "game/GameWorld.hpp"

#include <cassert>
#include <iostream>

using namespace pk;

int main() {
    GameWorld world;

    FrameInput move;
    move.movement = {0.0F, 1.0F};
    move.cameraYaw = 0.0F;
    const float initialZ = world.player().position.z;
    world.update(0.05F, move);
    assert(world.player().position.z > initialZ);

    WorldSnapshot state = world.snapshot();
    state.player.position = world.resources()[0].position;
    world.restore(state);
    FrameInput interact;
    interact.interactPressed = true;
    world.update(0.016F, interact);
    assert(world.player().wood == state.player.wood + 2);

    state = world.snapshot();
    state.player.position = world.campPosition();
    state.player.wood = 3;
    state.player.stone = 2;
    world.restore(state);
    FrameInput craft;
    craft.craftPressed = true;
    world.update(0.016F, craft);
    assert(world.player().tools == state.player.tools + 1);
    assert(world.player().wood == 0);
    assert(world.player().stone == 0);

    state = world.snapshot();
    const EnemyState& enemy = world.enemies()[0];
    state.player.position = enemy.position + Vec3{0.0F, 0.0F, -1.0F};
    state.player.facing = 0.0F;
    world.restore(state);
    const float healthBefore = world.enemies()[0].health;
    FrameInput attack;
    attack.attackPressed = true;
    world.update(0.016F, attack);
    assert(world.enemies()[0].health < healthBefore);

    GameWorld puzzleWorld;
    for (int symbol : {1, 2, 0}) {
        WorldSnapshot puzzle = puzzleWorld.snapshot();
        for (const TotemState& totem : puzzleWorld.totems()) {
            if (totem.symbol == symbol) puzzle.player.position = totem.position;
        }
        puzzleWorld.restore(puzzle);
        FrameInput use;
        use.interactPressed = true;
        puzzleWorld.update(0.016F, use);
    }
    assert(puzzleWorld.mysterySolved());
    assert(puzzleWorld.player().relics == 1);

    std::cout << "Semua ujian gameplay Pulau Kabus lulus.\n";
    return 0;
}
