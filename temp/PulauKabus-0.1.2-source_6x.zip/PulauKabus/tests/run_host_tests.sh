#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
build_dir="$project_dir/build-host"
mkdir -p "$build_dir"
g++ -std=c++20 -Wall -Wextra -Wpedantic -Werror \
  -I"$project_dir/app/src/main/cpp" \
  "$project_dir/app/src/main/cpp/game/GameWorld.cpp" \
  "$project_dir/tests/game_world_test.cpp" \
  -o "$build_dir/game_world_test"
"$build_dir/game_world_test"
