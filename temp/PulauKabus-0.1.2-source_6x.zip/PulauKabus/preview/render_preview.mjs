import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const sharp = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'sharp'));

const directory = path.dirname(new URL(import.meta.url).pathname);
await sharp(path.join(directory, 'concept-gameplay.png'))
  .resize(1600, 900, { fit: 'cover' })
  .composite([{ input: path.join(directory, 'hud.svg') }])
  .png()
  .toFile(path.join(directory, 'gameplay-screen.png'));
