# Reka Bentuk Permainan — Pulau Kabus

## Premis

Seorang pengembara terselamat daripada bot karam dan tiba di pulau yang diselubungi kabus. Kem ekspedisi lama, mesin batu dan makhluk kabus menunjukkan bahawa kejadian itu bukan kemalangan. Pemain perlu membina kem, mengaktifkan tiga totem mengikut turutan dan membuka pintu runtuhan di selatan pulau.

## Kitaran utama

1. Teroka kawasan baharu menggunakan kamera bebas 360 darjah.
2. Kumpul kayu, batu dan herba.
3. Kembali ke kem untuk membina alatan atau memulihkan kesihatan.
4. Lawan atau elakkan makhluk kabus.
5. Kenal pasti simbol dan turutan tiga totem.
6. Buka pintu runtuhan dan temui relik pulau.

## Keseimbangan

- Survival seimbang: sumber muncul semula dan kem tidak musnah.
- Kematian memulangkan pemain ke kem dengan separuh kayu dan batu.
- Stamina pulih apabila watak berhenti bergerak.
- Makhluk memberi relik dan muncul semula selepas tempoh tertentu.
- Teka-teki tersalah turutan akan menetapkan semula ketiga-tiga totem tanpa hukuman kekal.

## Arah visual

- Lukisan 3D bergaya dengan bentuk jelas dan tekstur seakan sapuan berus.
- Kabus biru-kehijauan, tumbuhan hijau lumut dan cahaya kem berwarna ambar.
- Siluet watak, makhluk, sumber dan totem mesti mudah dibaca pada skrin telefon.
- Geometri sederhana dan pencahayaan tunggal memastikan prestasi stabil.
