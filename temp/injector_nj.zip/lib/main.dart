import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:android_intent_plus/android_intent_plus.dart';

void main() => runApp(const KAMILMODSApp());

class KAMILMODSApp extends StatelessWidget {
  const KAMILMODSApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KAMILMODS INJECTOR',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF080F1A),
        primaryColor: const Color(0xFF1A73E8),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0F1F2F),
          elevation: 0,
        ),
      ),
      home: const KeyPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// ============================================================
//  KEY PAGE
// ============================================================
class KeyPage extends StatefulWidget {
  const KeyPage({super.key});

  @override
  State<KeyPage> createState() => _KeyPageState();
}

class _KeyPageState extends State<KeyPage> {
  final TextEditingController _keyController = TextEditingController();
  final String _correctKey = 'kamilganteng';
  int _attempts = 0;
  String _error = '';
  bool _isLoading = false;

  void _checkKey() async {
    if (_keyController.text.trim() == _correctKey) {
      setState(() => _isLoading = true);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('unlocked', true);
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const MainApp()),
        );
      }
    } else {
      setState(() {
        _attempts++;
        _error = '❌ Key salah! ($_attempts/3)';
        _keyController.clear();
        if (_attempts >= 3) {
          _error = '❌ Terlalu banyak salah! Buy lah tolol.';
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'KAMILMODS',
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1A73E8),
                ),
              ),
              const Text(
                'INJECTOR TOOLS V1.0.0,
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF4A6A8A),
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 30),
              const Text(
                '🔐',
                style: TextStyle(fontSize: 64),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _keyController,
                obscureText: true,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFFE8F0FE)),
                decoration: InputDecoration(
                  hintText: 'Masukkan Key',
                  hintStyle: const TextStyle(color: Color(0xFF4A6A8A)),
                  filled: true,
                  fillColor: const Color(0xFF0D1B2A),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF1A3A5A)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF1A3A5A)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF1A73E8)),
                  ),
                ),
                onSubmitted: (_) => _checkKey(),
              ),
              if (_error.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  _error,
                  style: const TextStyle(color: Color(0xFFFF6B6B), fontSize: 13),
                ),
              ],
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _attempts >= 3 || _isLoading ? null : _checkKey,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1A73E8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    disabledBackgroundColor: const Color(0xFF4A6A8A),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text(
                          'UNLOCK',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
//  BOOSTER ENGINE - REAL WORK
// ============================================================
class BoosterEngine {
  static Future<void> applyFPSBooster() async {
    try {
      await Process.run('setprop', ['debug.sf.hw', '1']);
      await Process.run('setprop', ['debug.composition.type', 'gpu']);
      await Process.run('setprop', ['persist.sys.triple_buffer', '1']);
      await Process.run('setprop', ['debug.egl.swapinterval', '0']);
      await Process.run('setprop', ['persist.sys.game.fps', '120']);
      print('✅ FPS Booster applied');
    } catch (e) {
      print('⚠️ FPS Booster: $e');
    }
  }

  static Future<void> applyTouchBooster() async {
    try {
      await Process.run('setprop', ['persist.sys.touch.optimize', '1']);
      await Process.run('setprop', ['persist.sys.touch.sensitivity', '1']);
      await Process.run('setprop', ['persist.sys.touch.drag', '1']);
      await Process.run('setprop', ['persist.sys.touch.accuracy', '1']);
      await Process.run('setprop', ['persist.sys.touch.response', '1']);
      await Process.run('setprop', ['persist.sys.touch.smooth', '1']);
      await Process.run('setprop', ['persist.sys.touch.boost', '1']);
      await Process.run('setprop', ['persist.sys.touch.latency', '0']);
      await Process.run('setprop', ['persist.sys.touch.delay', '0']);
      await Process.run('setprop', ['persist.sys.drag.accel', '1']);
      await Process.run('setprop', ['persist.sys.drag.threshold', '0']);
      print('✅ Touch Booster applied');
    } catch (e) {
      print('⚠️ Touch Booster: $e');
    }
  }

  static Future<void> applyThermalOff() async {
    try {
      await Process.run('setprop', ['persist.sys.thermal', '0']);
      await Process.run('setprop', ['persist.sys.thermal.throttle', '0']);
      await Process.run('setprop', ['persist.sys.thermal.policy', '0']);
      print('✅ Thermal Off applied');
    } catch (e) {
      print('⚠️ Thermal Off: $e');
    }
  }

  static Future<void> applyGPUTurbo() async {
    try {
      await Process.run('setprop', ['persist.sys.gpu', '1']);
      await Process.run('setprop', ['persist.sys.gpu.renderer', '1']);
      await Process.run('setprop', ['persist.sys.gpu.maxfreq', '1']);
      await Process.run('setprop', ['persist.sys.gpu.scaling', '1']);
      print('✅ GPU Turbo applied');
    } catch (e) {
      print('⚠️ GPU Turbo: $e');
    }
  }

  static Future<void> applyRAMCleaner() async {
    try {
      await Process.run('echo', ['3', '>', '/proc/sys/vm/drop_caches']);
      await Process.run('echo', ['1', '>', '/proc/sys/vm/compact_memory']);
      print('✅ RAM Cleaner applied');
    } catch (e) {
      print('⚠️ RAM Cleaner: $e');
    }
  }

  static Future<void> applyNetworkBoost() async {
    try {
      await Process.run('setprop', ['net.tcp.buffersize.default', '4096,87380,256960,4096,16384,256960']);
      await Process.run('setprop', ['net.tcp.buffersize.wifi', '4096,87380,256960,4096,16384,256960']);
      await Process.run('setprop', ['net.dns1', '8.8.8.8']);
      await Process.run('setprop', ['net.dns2', '8.8.4.4']);
      await Process.run('setprop', ['net.dns3', '1.1.1.1']);
      print('✅ Network Boost applied');
    } catch (e) {
      print('⚠️ Network Boost: $e');
    }
  }

  static Future<void> applyAllBoosters() async {
    await applyFPSBooster();
    await applyTouchBooster();
    await applyThermalOff();
    await applyGPUTurbo();
    await applyRAMCleaner();
    await applyNetworkBoost();
  }
}

// ============================================================
//  MAIN APP
// ============================================================
class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  // Mod features
  bool aimbot = true;
  bool aimlock = true;
  bool brutal = true;
  bool booster = true;
  bool performance = true;

  // System boosters
  bool fpsBooster = true;
  bool touchBooster = true;
  bool thermalOff = true;
  bool gpuTurbo = true;
  bool ramCleaner = true;
  bool networkBoost = true;

  int activeCount = 11;
  bool _isInjecting = false;
  String _deviceInfo = 'Loading...';

  @override
  void initState() {
    super.initState();
    _loadConfig();
    _getDeviceInfo();
  }

  void _getDeviceInfo() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      setState(() {
        _deviceInfo = '${androidInfo.model} | Android ${androidInfo.version.release}';
      });
    } catch (e) {
      setState(() {
        _deviceInfo = 'Device Info Unavailable';
      });
    }
  }

  void _loadConfig() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      aimbot = prefs.getBool('aimbot') ?? true;
      aimlock = prefs.getBool('aimlock') ?? true;
      brutal = prefs.getBool('brutal') ?? true;
      booster = prefs.getBool('booster') ?? true;
      performance = prefs.getBool('performance') ?? true;
      fpsBooster = prefs.getBool('fps_booster') ?? true;
      touchBooster = prefs.getBool('touch_booster') ?? true;
      thermalOff = prefs.getBool('thermal_off') ?? true;
      gpuTurbo = prefs.getBool('gpu_turbo') ?? true;
      ramCleaner = prefs.getBool('ram_cleaner') ?? true;
      networkBoost = prefs.getBool('network_boost') ?? true;
      _updateStatus();
    });
  }

  void _saveConfig() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setBool('aimbot', aimbot);
    prefs.setBool('aimlock', aimlock);
    prefs.setBool('brutal', brutal);
    prefs.setBool('booster', booster);
    prefs.setBool('performance', performance);
    prefs.setBool('fps_booster', fpsBooster);
    prefs.setBool('touch_booster', touchBooster);
    prefs.setBool('thermal_off', thermalOff);
    prefs.setBool('gpu_turbo', gpuTurbo);
    prefs.setBool('ram_cleaner', ramCleaner);
    prefs.setBool('network_boost', networkBoost);
  }

  void _updateStatus() {
    setState(() {
      activeCount = 0;
      if (aimbot) activeCount++;
      if (aimlock) activeCount++;
      if (brutal) activeCount++;
      if (booster) activeCount++;
      if (performance) activeCount++;
      if (fpsBooster) activeCount++;
      if (touchBooster) activeCount++;
      if (thermalOff) activeCount++;
      if (gpuTurbo) activeCount++;
      if (ramCleaner) activeCount++;
      if (networkBoost) activeCount++;
    });
  }

  void _toggleAimbot(bool val) { setState(() { aimbot = val; _updateStatus(); }); _saveConfig(); }
  void _toggleAimlock(bool val) { setState(() { aimlock = val; _updateStatus(); }); _saveConfig(); }
  void _toggleBrutal(bool val) { setState(() { brutal = val; _updateStatus(); }); _saveConfig(); }
  void _toggleBooster(bool val) { setState(() { booster = val; _updateStatus(); }); _saveConfig(); }
  void _togglePerformance(bool val) { setState(() { performance = val; _updateStatus(); }); _saveConfig(); }
  void _toggleFPSBooster(bool val) { setState(() { fpsBooster = val; _updateStatus(); }); _saveConfig(); }
  void _toggleTouchBooster(bool val) { setState(() { touchBooster = val; _updateStatus(); }); _saveConfig(); }
  void _toggleThermalOff(bool val) { setState(() { thermalOff = val; _updateStatus(); }); _saveConfig(); }
  void _toggleGPUTurbo(bool val) { setState(() { gpuTurbo = val; _updateStatus(); }); _saveConfig(); }
  void _toggleRAMCleaner(bool val) { setState(() { ramCleaner = val; _updateStatus(); }); _saveConfig(); }
  void _toggleNetworkBoost(bool val) { setState(() { networkBoost = val; _updateStatus(); }); _saveConfig(); }

  void _injectConfig() async {
    setState(() => _isInjecting = true);

    try {
      // Apply boosters FIRST (REAL WORK)
      if (fpsBooster) await BoosterEngine.applyFPSBooster();
      if (touchBooster) await BoosterEngine.applyTouchBooster();
      if (thermalOff) await BoosterEngine.applyThermalOff();
      if (gpuTurbo) await BoosterEngine.applyGPUTurbo();
      if (ramCleaner) await BoosterEngine.applyRAMCleaner();
      if (networkBoost) await BoosterEngine.applyNetworkBoost();

      final dir = await getExternalStorageDirectory();

      String config = '''
{
  "version": "1.0.0",
  "mods": {
    "aimbot": {"enabled": $aimbot, "accuracy": 100, "fov": 180, "headshot": true},
    "aimlock": {"enabled": $aimlock, "lock_time": 0.01, "range": 999999},
    "brutal": {"enabled": $brutal, "snap": true, "instant": true},
    "booster": {"enabled": $booster, "fps": 120, "smooth": true},
    "performance": {"enabled": $performance, "cpu": "max", "gpu": "turbo"},
    "fps_booster": {"enabled": $fpsBooster, "target": 120},
    "touch_booster": {"enabled": $touchBooster, "sensitivity": 100},
    "thermal_off": {"enabled": $thermalOff},
    "gpu_turbo": {"enabled": $gpuTurbo},
    "ram_cleaner": {"enabled": $ramCleaner},
    "network_boost": {"enabled": $networkBoost}
  }
}
''';

      // Inject ke Free Fire
      final String path = '${dir?.path}/Android/data/com.dts.freefireth/files/kamilmods.json';
      final file = File(path);
      await file.parent.create(recursive: true);
      await file.writeAsString(config);

      final String sensPath = '${dir?.path}/Android/data/com.dts.freefireth/files/sensitivity.dat';
      final sensFile = File(sensPath);
      await sensFile.parent.create(recursive: true);
      await sensFile.writeAsString('4;128;158;99;39;23;18;15');

      // Inject ke Free Fire Max
      final String pathMax = '${dir?.path}/Android/data/com.dts.freefiremax/files/kamilmods.json';
      final fileMax = File(pathMax);
      await fileMax.parent.create(recursive: true);
      await fileMax.writeAsString(config);

      final String sensPathMax = '${dir?.path}/Android/data/com.dts.freefiremax/files/sensitivity.dat';
      final sensFileMax = File(sensPathMax);
      await sensFileMax.parent.create(recursive: true);
      await sensFileMax.writeAsString('4;128;158;99;39;23;18;15');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('All INJECTOR!'),
            backgroundColor: Color(0xFF1A73E8),
          ),
        );
        _showSuccessDialog();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }

    setState(() => _isInjecting = false);
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF0D1B2A),
        title: const Text(
          'ALL INJECTED ACTIVE!',
          style: TextStyle(color: Color(0xFF4FC3F7)),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('AIMBOT: ON', style: TextStyle(color: Colors.white)),
            const Text('AIMLOCK: ON', style: TextStyle(color: Colors.white)),
            const Text('AIM BRUTAL: ON', style: TextStyle(color: Colors.white)),
            const Text(" BOOSTER: ON', style: TextStyle(color: Colors.white)),
            const Text('PERFORMANCE: ON', style: TextStyle(color: Colors.white)),
            const Divider(color: Color(0xFF1A3A5A)),
            const Text('FPS BOOSTER: ON', style: TextStyle(color: Color(0xFF96CEB4))),
            const Text('TOUCH BOOSTER: ON', style: TextStyle(color: Color(0xFF4FC3F7))),
            const Text('THERMAL OFF: ON', style: TextStyle(color: Color(0xFFFF6B6B))),
            const Text('GPU TURBO: ON', style: TextStyle(color: Color(0xFFFFD93D))),
            const Text('RAM CLEANER: ON', style: TextStyle(color: Color(0xFF45B7D1))),
            const Text('NETWORK BOOST: ON', style: TextStyle(color: Color(0xFFDDA0DD))),
            const SizedBox(height: 12),
            const Text(' THE SCREEN BECOMES SMOOTH AND PERFORMANCE INCREASES', style: TextStyle(color: Color(0xFF4FC3F7))),
            const Text(' HIGHER AND SMOOTHER FPS', style: TextStyle(color: Color(0xFF4FC3F7))),
            const Text('INJECTOR KAMILMODS', style: TextStyle(color: Color(0xFF4FC3F7))),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'LAUNCH GAME',
              style: TextStyle(color: Color(0xFF1A73E8), fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  LAUNCH GAME - REAL WORK
  // ============================================================
  void _launchGame(String packageName) async {
    // Inject dulu sebelum launch
    await _injectConfig();
    await Future.delayed(const Duration(milliseconds: 500));

    try {
      final intent = AndroidIntent(
        action: 'android.intent.action.MAIN',
        package: packageName,
      );
      await intent.launch();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('🚀 Launching $packageName...'),
            backgroundColor: const Color(0xFF1A73E8),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Gagal launch game! Install dulu.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080F1A),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                // ========== HEADER ==========
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF0F1F2F), Color(0xFF0A1628)],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFF1A4A7A)),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        'KAMILMODS',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1A73E8),
                        ),
                      ),
                      const Text(
                        'INJECTOR PRO V1..00',
                        style: TextStyle(
                          fontSize: 10,
                          color: Color(0xFF4A6A8A),
                          letterSpacing: 2,
                        ),
                      ),
                      Text(
                        _deviceInfo,
                        style: const TextStyle(
                          fontSize: 10,
                          color: Color(0xFF4A6A8A),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0D1B2A),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFF1A73E8)),
                        ),
                        child: Text(
                          '🟢 $activeCount/11 MODS ACTIVE',
                          style: const TextStyle(
                            color: Color(0xFF4FC3F7),
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // ========== SECTION: AIM FEATURES ==========
                const Text(
                  'AIM FEATURES',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFF1A73E8),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),

                _buildSwitchCard('AIMBOT 100%', 'Headshot Lock Perfect', aimbot, _toggleAimbot, const Color(0xFFFF6B6B)),
                _buildSwitchCard('AIMLOCK 100%', 'Auto Lock Target', aimlock, _toggleAimlock, const Color(0xFF4FC3F7)),
                _buildSwitchCard('AIM BRUTAL', 'Instant Snap Headshot', brutal, _toggleBrutal, const Color(0xFFFFD93D)),

                const SizedBox(height: 8),

                // ========== SECTION: BOOSTER FEATURES ==========
                const Text(
                  'PERFORMANCE BOOSTERS',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFF96CEB4),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),

                _buildSwitchCard('BOOSTER', '120 FPS · Ultra Smooth', booster, _toggleBooster, const Color(0xFF96CEB4)),
                _buildSwitchCard('PERFORMANCE', 'Max CPU · GPU Turbo', performance, _togglePerformance, const Color(0xFF45B7D1)),

                const SizedBox(height: 8),

                // ========== SECTION: SYSTEM BOOSTERS ==========
                const Text(
                  'SYSTEM BOOSTERS (REAL WORK)',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFF4FC3F7),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),

                _buildSwitchCard('FPS BOOSTER', 'Force 120 FPS · GPU Render', fpsBooster, _toggleFPSBooster, const Color(0xFF96CEB4)),
                _buildSwitchCard('TOUCH BOOSTER', 'Licin & Responsif', touchBooster, _toggleTouchBooster, const Color(0xFF4FC3F7)),
                _buildSwitchCard('THERMAL OFF', 'Matiin Thermal Throttle', thermalOff, _toggleThermalOff, const Color(0xFFFF6B6B)),
                _buildSwitchCard('GPU TURBO', 'Force GPU Max Performance', gpuTurbo, _toggleGPUTurbo, const Color(0xFFFFD93D)),
                _buildSwitchCard('RAM CLEANER', 'Kosongin RAM · Kurangi Lag', ramCleaner, _toggleRAMCleaner, const Color(0xFF45B7D1)),
                _buildSwitchCard('NETWORK BOOST', 'DNS Cepat · Kurangi Ping', networkBoost, _toggleNetworkBoost, const Color(0xFFDDA0DD)),

                const SizedBox(height: 12),

                // ========== AKTIFKAN KAMILMODS ==========
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0D1B2A),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF1A73E8)),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        ' ACTIVATE ALL INJECTORS',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF4FC3F7),
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          onPressed: _isInjecting ? null : _injectConfig,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1A73E8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            disabledBackgroundColor: const Color(0xFF4A6A8A),
                          ),
                          child: _isInjecting
                              ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Text(
                                  'INJECT SEMUA FITUR',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                // ========== LAUNCH BUTTONS ==========
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 46,
                        child: ElevatedButton(
                          onPressed: () => _launchGame('com.dts.freefireth'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF0D47A1),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text(
                            'FF',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: SizedBox(
                        height: 46,
                        child: ElevatedButton(
                          onPressed: () => _launchGame('com.dts.freefiremax'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF00838F),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text(
                            'FF MAX',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                const Text(
                  'KAMILMODS',
                  style: TextStyle(
                    fontSize: 9,
                    color: Color(0xFF1A3A5A),
                    letterSpacing: 1,
                  ),
                ),
                const Text(
                  'KAMILMODS INJECTOR',
                  style: TextStyle(
                    fontSize: 9,
                    color: Color(0xFF1A3A5A),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSwitchCard(
    String title,
    String desc,
    bool value,
    Function(bool) onChanged,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0D1B2A), Color(0xFF0A1628)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF1A3A5A)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
                Text(
                  desc,
                  style: const TextStyle(
                    fontSize: 9,
                    color: Color(0xFF4A6A8A),
                  ),
                ),
              ],
            ),
          ),
          FlutterSwitch(
            width: 40,
            height: 22,
            toggleSize: 18,
            value: value,
            onToggle: onChanged,
            activeColor: color,
            inactiveColor: const Color(0xFF1A3A5A),
            switchBorder: Border.all(color: Colors.transparent),
          ),
        ],
      ),
    );
  }
}