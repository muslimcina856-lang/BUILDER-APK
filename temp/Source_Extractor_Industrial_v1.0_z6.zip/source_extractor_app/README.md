# Source Extractor

Industrial Utility style Flutter app untuk extract full source (HTML + CSS + JS).

## Design Direction
- **Industrial Utility**
- Charcoal base + solid orange accent (#E85D04)
- Space Grotesk (headers) + JetBrains Mono (code)
- Radius 6–8px only
- Flat, visible borders, no glow / soft shadows
- Uppercase labels, strong hierarchy
- Avoided AI-slop patterns (no Inter, no cyan neon, no glassmorphism)

## Features
- Extract HTML / CSS / JS
- Download ZIP
- Share
- History
- Dark / Light mode
- Paste from clipboard
- Open original URL
- Syntax highlighting
- Search in code

## Run
```bash
flutter pub get
flutter run
```
