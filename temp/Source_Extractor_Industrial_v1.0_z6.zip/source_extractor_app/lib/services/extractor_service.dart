import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/extract_result.dart';

class ExtractorService {
  static Future<ExtractResult> extractFromUrl(String rawUrl) async {
    String url = rawUrl.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url';
    }

    final uri = Uri.tryParse(url);
    if (uri == null || !uri.hasAuthority) {
      throw Exception('URL tidak valid. Sila masukkan URL yang betul.');
    }

    try {
      final response = await http.get(
        uri,
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
          'Accept':
              'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9,ms;q=0.8',
          'Cache-Control': 'no-cache',
        },
      ).timeout(const Duration(seconds: 25));

      if (response.statusCode < 200 || response.statusCode >= 400) {
        throw Exception('Gagal load page (Status ${response.statusCode})');
      }

      final htmlRaw = response.body;
      final html = _beautifyHtml(htmlRaw);

      final results = await Future.wait([
        _extractCss(htmlRaw, uri),
        _extractJs(htmlRaw, uri),
      ]);

      final css = results[0];
      final js = results[1];

      return ExtractResult(
        url: url,
        html: html,
        css: css,
        js: js,
        extractedAt: DateTime.now(),
        htmlSize: utf8.encode(html).length,
        cssSize: utf8.encode(css).length,
        jsSize: utf8.encode(js).length,
      );
    } on http.ClientException catch (e) {
      throw Exception('Ralat rangkaian: ${e.message}');
    } catch (e) {
      if (e.toString().contains('TimeoutException')) {
        throw Exception('Timeout. Website ambil masa terlalu lama untuk load.');
      }
      rethrow;
    }
  }

  static Future<String> _extractCss(String html, Uri base) async {
    final buffer = StringBuffer();

    final styleRegex = RegExp(r'<style[^>]*>([\s\S]*?)</style>', caseSensitive: false);
    int styleCount = 0;
    for (final match in styleRegex.allMatches(html)) {
      final content = match.group(1)?.trim() ?? '';
      if (content.isNotEmpty) {
        styleCount++;
        buffer.writeln('/* ========== INLINE STYLE #$styleCount ========== */');
        buffer.writeln(content);
        buffer.writeln();
      }
    }

    final hrefs = <String>{};
    final linkRegex1 = RegExp(
      r'''<link[^>]*rel=["']stylesheet["'][^>]*href=["']([^"']+)["'][^>]*>''',
      caseSensitive: false,
    );
    final linkRegex2 = RegExp(
      r'''<link[^>]*href=["']([^"']+)["'][^>]*rel=["']stylesheet["'][^>]*>''',
      caseSensitive: false,
    );

    for (final m in linkRegex1.allMatches(html)) {
      hrefs.add(m.group(1)!);
    }
    for (final m in linkRegex2.allMatches(html)) {
      hrefs.add(m.group(1)!);
    }

    final importRegex = RegExp(r'''@import\s+(?:url\()?["']?([^"'\)]+)["']?\)?;''', caseSensitive: false);
    for (final m in importRegex.allMatches(html)) {
      hrefs.add(m.group(1)!);
    }

    for (final href in hrefs) {
      if (href.startsWith('data:')) continue;
      try {
        final cssUrl = _resolveUrl(href, base);
        buffer.writeln('/* ========== $cssUrl ========== */');
        final res = await http
            .get(Uri.parse(cssUrl), headers: {'User-Agent': 'Mozilla/5.0'})
            .timeout(const Duration(seconds: 10));
        if (res.statusCode == 200) {
          buffer.writeln(res.body);
        } else {
          buffer.writeln('/* Gagal fetch (Status ${res.statusCode}) */');
        }
      } catch (_) {
        buffer.writeln('/* Gagal fetch: $href */');
      }
      buffer.writeln();
    }

    final result = buffer.toString().trim();
    return result.isEmpty ? '/* Tiada CSS dijumpai */' : result;
  }

  static Future<String> _extractJs(String html, Uri base) async {
    final buffer = StringBuffer();

    final inlineRegex = RegExp(
      r'<script(?![^>]*\bsrc\b)[^>]*>([\s\S]*?)</script>',
      caseSensitive: false,
    );
    int i = 0;
    for (final match in inlineRegex.allMatches(html)) {
      final content = match.group(1)?.trim() ?? '';
      if (content.isNotEmpty) {
        i++;
        buffer.writeln('/* ========== INLINE SCRIPT #$i ========== */');
        buffer.writeln(content);
        buffer.writeln();
      }
    }

    final srcRegex = RegExp(
      r'''<script[^>]*\bsrc=["']([^"']+)["'][^>]*>''',
      caseSensitive: false,
    );
    final srcs = <String>{};
    for (final m in srcRegex.allMatches(html)) {
      srcs.add(m.group(1)!);
    }

    for (final src in srcs) {
      if (src.startsWith('data:')) continue;
      try {
        final jsUrl = _resolveUrl(src, base);
        buffer.writeln('/* ========== EXTERNAL: $jsUrl ========== */');
        final res = await http
            .get(Uri.parse(jsUrl), headers: {'User-Agent': 'Mozilla/5.0'})
            .timeout(const Duration(seconds: 10));
        if (res.statusCode == 200) {
          final body = res.body;
          if (body.length > 2 * 1024 * 1024) {
            buffer.writeln('/* File terlalu besar (${(body.length / 1024 / 1024).toStringAsFixed(1)} MB) - hanya 100KB pertama */');
            buffer.writeln(body.substring(0, 100 * 1024));
            buffer.writeln('\n/* ... truncated ... */');
          } else {
            buffer.writeln(body);
          }
        } else {
          buffer.writeln('/* Gagal fetch (Status ${res.statusCode}) */');
        }
      } catch (_) {
        buffer.writeln('/* Gagal fetch: $src */');
      }
      buffer.writeln();
    }

    final result = buffer.toString().trim();
    return result.isEmpty ? '/* Tiada JavaScript dijumpai */' : result;
  }

  static String _resolveUrl(String href, Uri base) {
    href = href.trim();
    if (href.startsWith('http://') || href.startsWith('https://')) return href;
    if (href.startsWith('//')) return '${base.scheme}:$href';
    if (href.startsWith('/')) return '${base.scheme}://${base.host}$href';
    final path = base.path.endsWith('/')
        ? base.path
        : (base.path.contains('.')
            ? base.path.substring(0, base.path.lastIndexOf('/') + 1)
            : '${base.path}/');
    return '${base.scheme}://${base.host}$path$href';
  }

  static String _beautifyHtml(String html) {
    return html
        .replaceAllMapped(RegExp(r'>(\s*)<'), (m) => '>\n<')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n');
  }
}
