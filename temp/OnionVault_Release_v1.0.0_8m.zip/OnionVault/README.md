# OnionVault – Release v1.0.0

Multi-profile privacy browser for Android with on-demand Tor.

**Package:** `com.onion.vault`  
**Version:** 1.0.0  
**Min SDK:** 26

## Features

- Fully isolated profiles (separate storage, cookies, cache)
- Tor starts only when a profile is opened
- Tor stops when the profile is closed
- App icon included (utilitarian industrial style)
- Release build ready (minify + shrink enabled)

## How to build Release APK

1. Open the project in Android Studio (Hedgehog or newer)
2. Sync Gradle
3. Build → Generate Signed Bundle / APK → APK → release
4. Or from terminal: `./gradlew assembleRelease`

## Important notes

- TorController is currently a **placeholder** (simulates bootstrap).  
  For real production Tor, integrate Tor Android library or control Orbot.
- WebView isolation structure is ready (per-profile data directory).
- App icon has been generated and placed in all mipmap densities (mdpi → xxxhdpi).

## Design

Utilitarian industrial style:  
Matte charcoal, muted olive accent, flat, high contrast, no neon, no glassmorphism.
