# OnionVault ProGuard rules
-keep class com.onion.vault.** { *; }
-dontwarn com.onion.vault.**
