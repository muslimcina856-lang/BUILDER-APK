package com.onion.vault.ui.browser

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.onion.vault.R
import com.onion.vault.tor.TorController

class BrowserActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var torController: TorController
    private var profileId: String = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)

        profileId = intent.getStringExtra("profile_id") ?: return finish()
        val profileName = intent.getStringExtra("profile_name") ?: "Profile"

        findViewById<TextView>(R.id.profile_label).text = profileName

        webView = findViewById(R.id.webview)
        val addressBar = findViewById<EditText>(R.id.address_bar)
        val btnGo = findViewById<ImageButton>(R.id.btn_go)
        val btnBack = findViewById<ImageButton>(R.id.btn_back)
        val btnClose = findViewById<ImageButton>(R.id.btn_close)

        // Isolated WebView settings
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()

        // In real implementation, set data directory to profile-specific path
        // webView.setDataDirectorySuffix(profileId)

        addressBar.setText("https://check.torproject.org")
        webView.loadUrl("https://check.torproject.org")

        btnGo.setOnClickListener {
            var url = addressBar.text.toString().trim()
            if (!url.startsWith("http")) {
                url = "https://$url"
            }
            webView.loadUrl(url)
        }

        btnBack.setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
        }

        btnClose.setOnClickListener {
            finish()
        }

        torController = TorController(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Stop Tor when leaving the profile
        torController.stop()
        webView.destroy()
    }
}
