package com.onion.vault.ui.loading

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.onion.vault.R
import com.onion.vault.tor.TorController
import com.onion.vault.ui.browser.BrowserActivity

class LoadingActivity : AppCompatActivity() {

    private lateinit var torController: TorController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loading)

        val profileId = intent.getStringExtra("profile_id") ?: return finish()
        val profileName = intent.getStringExtra("profile_name") ?: "Profile"

        findViewById<TextView>(R.id.loading_text).text =
            "TOR CIRCUIT STARTING — $profileName"

        torController = TorController(this)

        torController.startForProfile(
            profileId = profileId,
            onReady = {
                val intent = Intent(this, BrowserActivity::class.java)
                intent.putExtra("profile_id", profileId)
                intent.putExtra("profile_name", profileName)
                startActivity(intent)
                finish()
            },
            onError = { msg ->
                findViewById<TextView>(R.id.loading_text).text = "Error: $msg"
            }
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        // Do not stop Tor here – BrowserActivity will manage lifecycle
    }
}
