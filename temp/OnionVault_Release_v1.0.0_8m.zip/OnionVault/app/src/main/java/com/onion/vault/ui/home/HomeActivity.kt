package com.onion.vault.ui.home

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.onion.vault.R
import com.onion.vault.profile.ProfileManager
import com.onion.vault.ui.browser.BrowserActivity
import com.onion.vault.ui.create.CreateProfileActivity
import com.onion.vault.ui.loading.LoadingActivity
import com.onion.vault.ui.settings.SettingsActivity

class HomeActivity : AppCompatActivity() {

    private lateinit var profileManager: ProfileManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        profileManager = ProfileManager(this)

        val container = findViewById<LinearLayout>(R.id.profile_list_container)
        val btnCreate = findViewById<TextView>(R.id.btn_create)
        val btnSettings = findViewById<TextView>(R.id.btn_settings)

        btnCreate.setOnClickListener {
            startActivity(Intent(this, CreateProfileActivity::class.java))
        }

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        loadProfiles(container)
    }

    private fun loadProfiles(container: LinearLayout) {
        container.removeAllViews()
        val profiles = profileManager.getAllProfiles()

        for (profile in profiles) {
            val item = layoutInflater.inflate(R.layout.item_profile, container, false)

            item.findViewById<TextView>(R.id.profile_name).text = profile.name
            item.findViewById<TextView>(R.id.profile_status).text =
                if (profile.isActive) "Active • Exit: ${profile.exitNode} • Uptime: ${profile.uptime}"
                else "Inactive • Last used: ${profile.lastUsed.ifEmpty { "—" }}"

            item.setOnClickListener {
                val intent = Intent(this, LoadingActivity::class.java)
                intent.putExtra("profile_id", profile.id)
                intent.putExtra("profile_name", profile.name)
                startActivity(intent)
            }

            container.addView(item)
        }
    }

    override fun onResume() {
        super.onResume()
        val container = findViewById<LinearLayout>(R.id.profile_list_container)
        loadProfiles(container)
    }
}
