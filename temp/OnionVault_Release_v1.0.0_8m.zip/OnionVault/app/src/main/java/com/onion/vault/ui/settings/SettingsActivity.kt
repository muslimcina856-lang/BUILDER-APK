package com.onion.vault.ui.settings

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.onion.vault.R

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<TextView>(R.id.btn_back).setOnClickListener { finish() }

        findViewById<TextView>(R.id.btn_clear_data).setOnClickListener {
            Toast.makeText(this, "All profile data cleared (placeholder)", Toast.LENGTH_SHORT).show()
        }
    }
}
