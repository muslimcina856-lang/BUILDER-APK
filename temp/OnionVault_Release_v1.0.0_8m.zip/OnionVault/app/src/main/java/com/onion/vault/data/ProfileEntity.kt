package com.onion.vault.data

data class ProfileEntity(
    val id: String,
    val name: String,
    val iconRes: Int = 0,
    val isActive: Boolean = false,
    val exitNode: String = "",
    val uptime: String = "",
    val lastUsed: String = ""
)
