package com.onion.vault.ui.create

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.onion.vault.R
import com.onion.vault.profile.ProfileManager

class CreateProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create)

        val nameInput = findViewById<EditText>(R.id.input_name)
        val btnCreate = findViewById<TextView>(R.id.btn_create)
        val btnBack = findViewById<TextView>(R.id.btn_back)

        btnBack.setOnClickListener { finish() }

        btnCreate.setOnClickListener {
            val name = nameInput.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(this, "Enter a profile name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val manager = ProfileManager(this)
            manager.createProfile(name)

            Toast.makeText(this, "Profile created", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
