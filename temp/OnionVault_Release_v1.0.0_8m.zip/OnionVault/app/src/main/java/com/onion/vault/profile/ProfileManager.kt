package com.onion.vault.profile

import android.content.Context
import com.onion.vault.data.ProfileEntity
import java.io.File
import java.util.UUID

class ProfileManager(private val context: Context) {

    private val profilesDir = File(context.filesDir, "profiles")

    init {
        if (!profilesDir.exists()) {
            profilesDir.mkdirs()
        }
    }

    fun getAllProfiles(): List<ProfileEntity> {
        // Placeholder - in real app load from database or shared prefs
        return listOf(
            ProfileEntity(
                id = "1",
                name = "Primary",
                isActive = false,
                exitNode = "Amsterdam",
                uptime = "2h 17m"
            ),
            ProfileEntity(
                id = "2",
                name = "Work",
                isActive = false,
                exitNode = "Frankfurt",
                uptime = "1h 05m"
            ),
            ProfileEntity(
                id = "3",
                name = "Personal",
                isActive = false,
                exitNode = "Stockholm",
                uptime = "45m"
            )
        )
    }

    fun createProfile(name: String): ProfileEntity {
        val id = UUID.randomUUID().toString()
        val profileDir = File(profilesDir, id)
        profileDir.mkdirs()

        // Create isolated directories
        File(profileDir, "webview").mkdirs()
        File(profileDir, "cookies").mkdirs()
        File(profileDir, "cache").mkdirs()

        return ProfileEntity(
            id = id,
            name = name,
            isActive = false
        )
    }

    fun getProfileDataDir(profileId: String): File {
        return File(profilesDir, profileId)
    }

    fun deleteProfile(profileId: String) {
        val dir = File(profilesDir, profileId)
        if (dir.exists()) {
            dir.deleteRecursively()
        }
    }
}
