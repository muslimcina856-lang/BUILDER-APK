package com.onion.vault.tor

import android.content.Context
import android.util.Log

/**
 * Controls Tor lifecycle per profile.
 * In production this would integrate with Tor Android library or Orbot control port.
 * Currently a placeholder that simulates start/stop.
 */
class TorController(private val context: Context) {

    private var isRunning = false
    private var currentProfileId: String? = null

    fun startForProfile(profileId: String, onReady: () -> Unit, onError: (String) -> Unit) {
        if (isRunning && currentProfileId == profileId) {
            onReady()
            return
        }

        // Stop previous if any
        stop()

        currentProfileId = profileId
        isRunning = true

        Log.d("TorController", "Starting Tor circuit for profile: $profileId")

        // Simulate bootstrap delay
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (isRunning) {
                Log.d("TorController", "Tor circuit ready for profile: $profileId")
                onReady()
            }
        }, 2500)
    }

    fun stop() {
        if (isRunning) {
            Log.d("TorController", "Stopping Tor for profile: $currentProfileId")
            isRunning = false
            currentProfileId = null
        }
    }

    fun isActive(): Boolean = isRunning

    fun getCurrentProfileId(): String? = currentProfileId
}
