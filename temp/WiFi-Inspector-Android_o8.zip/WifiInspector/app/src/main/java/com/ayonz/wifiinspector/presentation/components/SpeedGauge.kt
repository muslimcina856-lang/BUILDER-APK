package com.ayonz.wifiinspector.presentation.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ayonz.wifiinspector.presentation.theme.NeonAmber
import com.ayonz.wifiinspector.presentation.theme.NeonCyan
import com.ayonz.wifiinspector.presentation.theme.NeonGreen
import com.ayonz.wifiinspector.presentation.theme.NeonRed
import kotlin.math.cos
import kotlin.math.sin

/**
 * Speedometer bergaya Speedtest.net: skala melengkung 0..maxMbps dengan jarum yang
 * beranimasi halus mengikuti kecepatan instan (real-time), dibangun murni dengan Canvas
 * (ringan, tanpa Lottie/library eksternal).
 */
@Composable
fun SpeedGauge(
    currentMbps: Double,
    maxMbps: Float = 300f,
    modifier: Modifier = Modifier,
    label: String = "Mbps"
) {
    val animatedValue by animateFloatAsState(
        targetValue = currentMbps.toFloat().coerceIn(0f, maxMbps),
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 60f),
        label = "gaugeNeedle"
    )

    val trackColorBase = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)
    val onSurface = MaterialTheme.colorScheme.onSurface

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 18.dp.toPx()
            val diameter = minOf(size.width, size.height) - strokeWidth
            val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            val startAngle = 135f
            val sweepAngle = 270f

            // Track dasar
            drawArc(
                color = trackColorBase,
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                topLeft = topLeft,
                size = androidx.compose.ui.geometry.Size(diameter, diameter),
                style = Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )

            // Gradasi warna hijau→kuning→merah sesuai progres kecepatan
            val progressSweep = sweepAngle * (animatedValue / maxMbps)
            drawArc(
                brush = androidx.compose.ui.graphics.Brush.sweepGradient(
                    listOf(NeonGreen, NeonCyan, NeonAmber, NeonRed)
                ),
                startAngle = startAngle,
                sweepAngle = progressSweep,
                useCenter = false,
                topLeft = topLeft,
                size = androidx.compose.ui.geometry.Size(diameter, diameter),
                style = Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )

            // Jarum indikator
            val center = Offset(size.width / 2f, size.height / 2f)
            val needleAngleDeg = startAngle + sweepAngle * (animatedValue / maxMbps)
            val needleAngleRad = Math.toRadians(needleAngleDeg.toDouble())
            val needleLength = diameter / 2f - strokeWidth
            val needleEnd = Offset(
                x = center.x + (needleLength * cos(needleAngleRad)).toFloat(),
                y = center.y + (needleLength * sin(needleAngleRad)).toFloat()
            )
            drawLine(
                color = onSurface,
                start = center,
                end = needleEnd,
                strokeWidth = 5.dp.toPx(),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
            drawCircle(color = onSurface, radius = 9.dp.toPx(), center = center)
            drawCircle(color = MaterialTheme.colorScheme.background, radius = 4.dp.toPx(), center = center)
        }

        androidx.compose.foundation.layout.Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            androidx.compose.material3.Text(
                text = "%.1f".format(currentMbps),
                style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.Bold,
                color = onSurface
            )
            androidx.compose.material3.Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
