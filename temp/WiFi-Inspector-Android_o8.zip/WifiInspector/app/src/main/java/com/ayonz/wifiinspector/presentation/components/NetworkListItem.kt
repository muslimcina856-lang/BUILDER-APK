package com.ayonz.wifiinspector.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayonz.wifiinspector.domain.model.SecurityType
import com.ayonz.wifiinspector.domain.model.WifiNetworkInfo
import com.ayonz.wifiinspector.presentation.theme.qualityColor
import com.ayonz.wifiinspector.presentation.theme.securityColor

@Composable
fun NetworkListItem(
    network: WifiNetworkInfo,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        cornerRadius = 18.dp,
        contentPadding = 14.dp
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (network.security == SecurityType.OPEN) Icons.Filled.LockOpen else Icons.Filled.Lock,
                contentDescription = null,
                tint = securityColor(network.security),
                modifier = Modifier
                    .clip(CircleShape)
                    .background(securityColor(network.security).copy(alpha = 0.12f))
                    .padding(8.dp)
                    .height(20.dp)
                    .width(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = network.ssid,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tag(text = network.band.label)
                    Spacer(Modifier.width(6.dp))
                    Tag(text = "Ch ${network.channel}")
                    Spacer(Modifier.width(6.dp))
                    Tag(text = network.security.label)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${network.signalLevelDbm} dBm",
                    style = MaterialTheme.typography.labelMedium,
                    color = qualityColor(network.quality)
                )
                Spacer(Modifier.height(4.dp))
                SignalBars(percent = network.signalPercent, quality = network.quality)
            }
        }
    }
}

@Composable
private fun Tag(text: String) {
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
