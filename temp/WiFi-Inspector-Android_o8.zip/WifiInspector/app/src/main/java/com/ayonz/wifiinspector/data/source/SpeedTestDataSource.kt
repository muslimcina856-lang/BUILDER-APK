package com.ayonz.wifiinspector.data.source

import com.ayonz.wifiinspector.domain.model.SpeedTestPhase
import com.ayonz.wifiinspector.domain.model.SpeedTestResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext
import kotlin.math.abs
import kotlin.random.Random

/**
 * Speed test nyata (bukan sekadar menampilkan URL): mengukur ping, jitter, kecepatan unduh,
 * dan kecepatan unggah menggunakan endpoint publik Cloudflare yang memang disediakan untuk
 * keperluan pengujian kecepatan (dipakai juga oleh speed.cloudflare.com). Progres dipancarkan
 * secara berkala lewat Flow agar UI (jarum speedometer, progress bar) bisa menganimasikan
 * kecepatan secara real-time, bukan hanya menunggu hasil akhir.
 */
class SpeedTestDataSource {

    private val latencyProbeUrl = "https://speed.cloudflare.com/__down?bytes=1000"
    private val downloadUrl = "https://speed.cloudflare.com/__down?bytes=26214400" // 25 MB
    private val uploadUrl = "https://speed.cloudflare.com/__up"
    private val uploadPayloadBytes = 8 * 1024 * 1024 // 8 MB

    fun runSpeedTest(): Flow<SpeedTestPhase> = flow {
        emit(SpeedTestPhase.MeasuringPing)

        val pingSamples = mutableListOf<Long>()
        repeat(5) {
            val t = measureLatencyOnce()
            if (t >= 0) pingSamples.add(t)
        }
        if (pingSamples.isEmpty()) {
            emit(SpeedTestPhase.Failed("Tidak dapat terhubung ke server uji. Periksa koneksi internet Anda."))
            return@flow
        }
        val pingMs = pingSamples.min()
        val latencyMs = pingSamples.average().toLong()
        val jitterMs = if (pingSamples.size > 1) {
            pingSamples.zipWithNext { a, b -> abs(a - b) }.average().toLong()
        } else 0L

        val downloadMbps = runDownloadPhase { progress, mbps ->
            emit(SpeedTestPhase.Downloading(progress, mbps))
        } ?: run {
            emit(SpeedTestPhase.Failed("Gagal mengukur kecepatan unduh. Periksa koneksi internet Anda."))
            return@flow
        }

        val uploadMbps = runUploadPhase { progress, mbps ->
            emit(SpeedTestPhase.Uploading(progress, mbps))
        } ?: run {
            emit(SpeedTestPhase.Failed("Gagal mengukur kecepatan unggah. Periksa koneksi internet Anda."))
            return@flow
        }

        val result = SpeedTestResult(
            downloadMbps = downloadMbps,
            uploadMbps = uploadMbps,
            pingMs = pingMs,
            jitterMs = jitterMs,
            latencyMs = latencyMs,
            timestampMillis = System.currentTimeMillis()
        )
        emit(SpeedTestPhase.Completed(result))
    }.flowOn(Dispatchers.IO)

    private suspend fun runDownloadPhase(onProgress: suspend (Float, Double) -> Unit): Double? {
        return try {
            val connection = (URL(downloadUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 20000
                requestMethod = "GET"
            }
            connection.connect()
            val totalExpected = uploadPayloadBytesForDownload()

            val startTime = System.nanoTime()
            var totalBytes = 0L
            var lastEmitTime = startTime
            var lastEmitBytes = 0L

            connection.inputStream.use { input ->
                val buffer = ByteArray(64 * 1024)
                var read: Int
                while (coroutineContext.isActive && input.read(buffer).also { read = it } != -1) {
                    totalBytes += read
                    val now = System.nanoTime()
                    val sinceLastEmitSec = (now - lastEmitTime) / 1_000_000_000.0
                    if (sinceLastEmitSec >= 0.2) {
                        val instMbps = ((totalBytes - lastEmitBytes) * 8.0) / sinceLastEmitSec / 1_000_000.0
                        val progress = (totalBytes.toFloat() / totalExpected).coerceIn(0f, 1f)
                        onProgress(progress, instMbps)
                        lastEmitTime = now
                        lastEmitBytes = totalBytes
                    }
                }
            }
            val elapsedSeconds = (System.nanoTime() - startTime) / 1_000_000_000.0
            connection.disconnect()

            if (elapsedSeconds <= 0 || totalBytes <= 0) return null
            val finalMbps = (totalBytes * 8.0) / elapsedSeconds / 1_000_000.0
            onProgress(1f, finalMbps)
            finalMbps
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun runUploadPhase(onProgress: suspend (Float, Double) -> Unit): Double? {
        return try {
            val payload = Random.nextBytes(uploadPayloadBytes)
            val connection = (URL(uploadUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 20000
                requestMethod = "POST"
                doOutput = true
                setChunkedStreamingMode(64 * 1024)
                setRequestProperty("Content-Type", "application/octet-stream")
            }
            connection.connect()

            val startTime = System.nanoTime()
            var sent = 0L
            var lastEmitTime = startTime
            var lastEmitBytes = 0L

            connection.outputStream.use { output ->
                val chunkSize = 64 * 1024
                var offset = 0
                while (coroutineContext.isActive && offset < payload.size) {
                    val len = minOf(chunkSize, payload.size - offset)
                    output.write(payload, offset, len)
                    offset += len
                    sent += len
                    val now = System.nanoTime()
                    val sinceLastEmitSec = (now - lastEmitTime) / 1_000_000_000.0
                    if (sinceLastEmitSec >= 0.2) {
                        val instMbps = ((sent - lastEmitBytes) * 8.0) / sinceLastEmitSec / 1_000_000.0
                        val progress = (sent.toFloat() / payload.size).coerceIn(0f, 1f)
                        onProgress(progress, instMbps)
                        lastEmitTime = now
                        lastEmitBytes = sent
                    }
                }
                output.flush()
            }
            // Pastikan request selesai diproses server (menunggu respons).
            connection.responseCode
            val elapsedSeconds = (System.nanoTime() - startTime) / 1_000_000_000.0
            connection.disconnect()

            if (elapsedSeconds <= 0 || sent <= 0) return null
            val finalMbps = (sent * 8.0) / elapsedSeconds / 1_000_000.0
            onProgress(1f, finalMbps)
            finalMbps
        } catch (e: Exception) {
            null
        }
    }

    private fun uploadPayloadBytesForDownload(): Long {
        // Nilai ini harus sinkron dengan angka "bytes" pada downloadUrl di atas.
        return 26_214_400L
    }

    private fun measureLatencyOnce(): Long {
        return try {
            val connection = (URL(latencyProbeUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                requestMethod = "GET"
            }
            val start = System.nanoTime()
            connection.connect()
            connection.responseCode
            val elapsed = (System.nanoTime() - start) / 1_000_000
            connection.disconnect()
            elapsed
        } catch (e: Exception) {
            -1L
        }
    }
}
