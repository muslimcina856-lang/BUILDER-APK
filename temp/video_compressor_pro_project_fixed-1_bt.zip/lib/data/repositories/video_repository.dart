import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import '../models/video_metadata.dart';

class VideoRepository {
  Future<File?> selectVideoFromGallery() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.video,
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        return File(result.files.first.path!);
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  Future<VideoMetadata?> getVideoMetadata(File videoFile) async {
    try {
      // Get file info
      final filename = videoFile.path.split('/').last;
      final fileSize = await videoFile.length();

      // TODO: Extract metadata using FFprobe
      // For now, return placeholder metadata
      return VideoMetadata(
        filename: filename,
        filePath: videoFile.path,
        fileSize: fileSize,
        duration: 165000, // placeholder: 2m 45s
        resolution: '1920x1080',
        bitrate: 8500,
        frameRate: 30.0,
      );
    } catch (e) {
      rethrow;
    }
  }

  Future<String?> getVideoThumbnail(String videoPath) async {
    try {
      final thumbnail = await VideoThumbnail.thumbnailFile(
        video: videoPath,
        thumbnailPath: (await _getTempDir()).path,
        imageFormat: ImageFormat.PNG,
        maxHeight: 200,
        quality: 75,
      );
      return thumbnail;
    } catch (e) {
      return null;
    }
  }

  Future<Directory> _getTempDir() async {
    final tempDir = Directory.systemTemp;
    return tempDir;
  }

  Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<int> getDirectorySize(String dirPath) async {
    try {
      final dir = Directory(dirPath);
      if (!await dir.exists()) return 0;

      int size = 0;
      final files = dir.listSync(recursive: true, followLinks: false);
      for (var file in files) {
        if (file is File) {
          size += await file.length();
        }
      }
      return size;
    } catch (e) {
      return 0;
    }
  }

  Future<String> getApplicationDocumentsDirectory() async {
    // Implementation will depend on the actual package used
    return '';
  }
}
