import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/theme/app_theme.dart';
import 'state/app_controller.dart';
import 'ui/screens/language_screen.dart';
import 'ui/screens/token_screen.dart';
import 'ui/screens/home_shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const CloudflareControlApp());
}

class CloudflareControlApp extends StatelessWidget {
  const CloudflareControlApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppController()..init(),
      child: Consumer<AppController>(
        builder: (context, controller, _) {
          return MaterialApp(
            title: 'Cloudflare Control',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: ThemeMode.system,
            locale: controller.locale,
            supportedLocales: const [
              Locale('ms'),
              Locale('en'),
            ],
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: _buildHome(controller),
          );
        },
      ),
    );
  }

  Widget _buildHome(AppController controller) {
    if (!controller.isInitialized) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (controller.locale == null) {
      return const LanguageScreen();
    }

    if (controller.accounts.isEmpty) {
      return const TokenScreen();
    }

    return const HomeShell();
  }
}
