import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/theme/app_theme.dart';
import '../../state/app_controller.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> with WidgetsBindingObserver {
  bool? _permissionGranted;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkPermission();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkPermission();
    }
  }

  Future<void> _checkPermission() async {
    final status = await Permission.notification.status;
    final granted = status.isGranted;

    if (mounted) {
      setState(() => _permissionGranted = granted);
    }

    // Auto-off all accounts if permission revoked
    if (!granted) {
      final app = context.read<AppController>();
      for (final account in app.accounts) {
        if (account.notificationsEnabled) {
          await app.toggleNotifications(account.id, false);
        }
      }
    }
  }

  Future<bool> _requestPermission() async {
    final status = await Permission.notification.request();
    final granted = status.isGranted;
    if (mounted) setState(() => _permissionGranted = granted);

    if (!granted && status.isPermanentlyDenied) {
      if (mounted) {
        final open = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Kebenaran Notifikasi'),
            content: const Text(
              'Notifikasi ditolak secara kekal. Buka tetapan aplikasi untuk benarkan notifikasi.',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Buka Tetapan'),
              ),
            ],
          ),
        );
        if (open == true) {
          await openAppSettings();
        }
      }
    }
    return granted;
  }

  Future<void> _onToggle(String accountId, bool value) async {
    if (value) {
      // Turning ON - need permission
      final granted = _permissionGranted == true
          ? true
          : await _requestPermission();

      if (!granted) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Kebenaran notifikasi diperlukan. Notifikasi kekal Off.'),
              backgroundColor: AppColors.warning,
            ),
          );
        }
        return; // stay off
      }
    }

    final app = context.read<AppController>();
    await app.toggleNotifications(accountId, value);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();

    if (app.accounts.isEmpty) {
      return const Center(child: Text('Tiada akaun'));
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'Notifikasi',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 8),
        const Text(
          'Hidupkan notifikasi untuk menerima makluman berkaitan akaun Cloudflare. Default adalah Off.',
          style: TextStyle(color: AppColors.muted, height: 1.5),
        ),
        const SizedBox(height: 12),
        if (_permissionGranted == false)
          Container(
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: AppColors.warning.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.notifications_off, color: AppColors.warning, size: 20),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Kebenaran notifikasi belum diberi.',
                    style: TextStyle(fontSize: 13),
                  ),
                ),
                TextButton(
                  onPressed: _requestPermission,
                  child: const Text('Minta'),
                ),
              ],
            ),
          ),
        const SizedBox(height: 8),
        ...app.accounts.map((account) {
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: SwitchListTile(
              title: Text(
                account.email,
                style: const TextStyle(fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
              subtitle: Text(
                account.notificationsEnabled ? 'Notifikasi aktif' : 'Notifikasi dimatikan',
                style: const TextStyle(fontSize: 13),
              ),
              value: account.notificationsEnabled,
              activeColor: AppColors.primary,
              onChanged: (value) => _onToggle(account.id, value),
            ),
          );
        }),
        const SizedBox(height: 20),
        const Text(
          'Nota: Notifikasi sebenar bergantung kepada sokongan Cloudflare API. Toggle ni simpan pilihan anda dan minta kebenaran sistem.',
          style: TextStyle(color: AppColors.muted, fontSize: 12),
        ),
      ],
    );
  }
}
