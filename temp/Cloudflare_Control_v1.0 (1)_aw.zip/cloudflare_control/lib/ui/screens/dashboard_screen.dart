import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool loading = true;
  Map<String, dynamic>? user;
  List<dynamic> zones = [];
  List<dynamic> workers = [];
  List<dynamic> r2Buckets = [];
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final api = CloudflareApi(account);
      final results = await Future.wait([
        api.getUser(),
        api.getZones(),
        api.getWorkers().catchError((_) => []),
        api.getR2Buckets().catchError((_) => []),
      ]);

      setState(() {
        user = results[0] as Map<String, dynamic>;
        zones = results[1] as List;
        workers = results[2] as List;
        r2Buckets = results[3] as List;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final account = app.activeAccount;

    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: _load, child: const Text('Cuba Lagi')),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Account card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFF6821F), Color(0xFFE06A00)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Akaun Aktif',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 6),
                Text(
                  account?.email ?? '-',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                if (user != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    user!['first_name'] != null
                        ? '${user!['first_name']} ${user!['last_name'] ?? ''}'
                        : '',
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(height: 24),
          const Text('Ringkasan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),

          // Stats
          Row(
            children: [
              Expanded(child: _StatCard(title: 'Domain', value: '${zones.length}', icon: Icons.language)),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Workers', value: '${workers.length}', icon: Icons.code)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _StatCard(title: 'R2 Buckets', value: '${r2Buckets.length}', icon: Icons.storage)),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Akaun', value: '${app.accounts.length}', icon: Icons.people_outline)),
            ],
          ),

          const SizedBox(height: 28),
          const Text('Domain', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),

          if (zones.isEmpty)
            const Text('Tiada domain', style: TextStyle(color: AppColors.muted))
          else
            ...zones.take(5).map((z) => Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: const Icon(Icons.language, color: AppColors.primary),
                    title: Text(z['name'] ?? ''),
                    subtitle: Text('Status: ${z['status']}'),
                  ),
                )),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _StatCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AppColors.primary, size: 22),
          const SizedBox(height: 12),
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(title, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
        ],
      ),
    );
  }
}
