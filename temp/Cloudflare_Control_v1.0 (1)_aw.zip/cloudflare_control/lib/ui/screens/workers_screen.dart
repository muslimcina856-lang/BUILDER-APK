import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class WorkersScreen extends StatefulWidget {
  const WorkersScreen({super.key});

  @override
  State<WorkersScreen> createState() => _WorkersScreenState();
}

class _WorkersScreenState extends State<WorkersScreen> {
  List<dynamic> workers = [];
  List<dynamic> pages = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final api = CloudflareApi(account);
      final w = await api.getWorkers().catchError((_) => <dynamic>[]);
      final p = await api.getPagesProjects().catchError((_) => <dynamic>[]);
      setState(() {
        workers = w;
        pages = p;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();
    final account = app.activeAccount;

    if (loading) return const Center(child: CircularProgressIndicator());

    if (error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: _load, child: const Text('Cuba Lagi')),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('Workers', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              TextButton.icon(
                onPressed: () {
                  final id = account?.id ?? '';
                  _openUrl('https://dash.cloudflare.com/$id/workers-and-pages');
                },
                icon: const Icon(Icons.open_in_new, size: 16),
                label: const Text('Buka di Dashboard'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (workers.isEmpty)
            const Padding(
              padding: EdgeInsets.only(bottom: 20),
              child: Text('Tiada Workers', style: TextStyle(color: AppColors.muted)),
            )
          else
            ...workers.map((w) {
              final name = w['id'] ?? w['name'] ?? '-';
              final modified = w['modified_on']?.toString() ?? '-';
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.code, color: AppColors.primary),
                  title: Text(name.toString()),
                  subtitle: Text('Modified: ${modified.length > 19 ? modified.substring(0, 19) : modified}'),
                  trailing: const Icon(Icons.open_in_new, size: 18, color: AppColors.muted),
                  onTap: () {
                    final id = account?.id ?? '';
                    _openUrl('https://dash.cloudflare.com/$id/workers/services/view/$name/production');
                  },
                ),
              );
            }),

          const SizedBox(height: 24),
          const Text('Pages Projects', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          if (pages.isEmpty)
            const Text('Tiada Pages project', style: TextStyle(color: AppColors.muted))
          else
            ...pages.map((p) {
              final name = p['name'] ?? '-';
              final subdomain = p['subdomain'] ?? '';
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: const Icon(Icons.web, color: AppColors.primary),
                  title: Text(name.toString()),
                  subtitle: Text(subdomain.toString()),
                  trailing: const Icon(Icons.open_in_new, size: 18, color: AppColors.muted),
                  onTap: () {
                    final id = account?.id ?? '';
                    _openUrl('https://dash.cloudflare.com/$id/pages/view/$name');
                  },
                ),
              );
            }),
        ],
      ),
    );
  }
}
