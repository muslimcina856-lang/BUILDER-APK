import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import 'firewall_screen.dart';

class SecurityScreen extends StatelessWidget {
  const SecurityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Security', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        const Text(
          'Urus firewall dan security settings domain anda.',
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 24),
        Card(
          child: ListTile(
            leading: const Icon(Icons.block, color: AppColors.primary),
            title: const Text('IP Access Rules', style: TextStyle(fontWeight: FontWeight.w600)),
            subtitle: const Text('Block / Allow / Challenge IP'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const FirewallScreen()),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'SSL, Security Level, Always HTTPS dan setting zone lain boleh diubah di Domain & DNS → pilih domain → icon Settings.',
          style: TextStyle(color: AppColors.muted, fontSize: 13, height: 1.4),
        ),
      ],
    );
  }
}
