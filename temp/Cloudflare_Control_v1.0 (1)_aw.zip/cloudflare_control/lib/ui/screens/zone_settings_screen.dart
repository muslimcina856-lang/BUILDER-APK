import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class ZoneSettingsScreen extends StatefulWidget {
  final String zoneId;
  final String zoneName;

  const ZoneSettingsScreen({super.key, required this.zoneId, required this.zoneName});

  @override
  State<ZoneSettingsScreen> createState() => _ZoneSettingsScreenState();
}

class _ZoneSettingsScreenState extends State<ZoneSettingsScreen> {
  bool loading = true;
  Map<String, dynamic> settings = {};
  String? error;

  final List<Map<String, String>> settingDefs = [
    {'id': 'ssl', 'title': 'SSL/TLS Mode', 'type': 'select'},
    {'id': 'always_use_https', 'title': 'Always Use HTTPS', 'type': 'toggle'},
    {'id': 'min_tls_version', 'title': 'Minimum TLS Version', 'type': 'select'},
    {'id': 'security_level', 'title': 'Security Level', 'type': 'select'},
    {'id': 'browser_check', 'title': 'Browser Integrity Check', 'type': 'toggle'},
    {'id': 'email_obfuscation', 'title': 'Email Address Obfuscation', 'type': 'toggle'},
    {'id': 'server_side_exclude', 'title': 'Server Side Exclude', 'type': 'toggle'},
    {'id': 'hotlink_protection', 'title': 'Hotlink Protection', 'type': 'toggle'},
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final api = CloudflareApi(account);
      final Map<String, dynamic> loaded = {};
      for (final s in settingDefs) {
        try {
          final res = await api.getZoneSetting(widget.zoneId, s['id']!);
          loaded[s['id']!] = res;
        } catch (_) {}
      }
      setState(() {
        settings = loaded;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _update(String settingId, dynamic value) async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.updateZoneSetting(widget.zoneId, settingId, value);
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Setting dikemaskini'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _purgeCache() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Purge Cache?'),
        content: const Text('Ini akan clear semua cache untuk domain ini.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Purge Everything'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.purgeEverything(widget.zoneId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cache berjaya di-purge'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.zoneName),
        actions: [
          IconButton(
            icon: const Icon(Icons.cleaning_services_outlined),
            tooltip: 'Purge Cache',
            onPressed: _purgeCache,
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text(error!))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    const Text('Zone Settings', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 12),
                    ...settingDefs.map((s) {
                      final data = settings[s['id']];
                      final value = data?['value'];
                      final editable = data?['editable'] != false;

                      if (s['type'] == 'toggle') {
                        final isOn = value == 'on' || value == true;
                        return Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: SwitchListTile(
                            title: Text(s['title']!),
                            value: isOn,
                            activeColor: AppColors.primary,
                            onChanged: editable
                                ? (v) => _update(s['id']!, v ? 'on' : 'off')
                                : null,
                          ),
                        );
                      }

                      // Select type
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          title: Text(s['title']!),
                          subtitle: Text(
                            value?.toString().toUpperCase() ?? '-',
                            style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600),
                          ),
                          trailing: editable ? const Icon(Icons.edit_outlined, size: 20) : null,
                          onTap: editable ? () => _showSelectDialog(s['id']!, s['title']!, value) : null,
                        ),
                      );
                    }),
                    const SizedBox(height: 20),
                    OutlinedButton.icon(
                      onPressed: _purgeCache,
                      icon: const Icon(Icons.cleaning_services_outlined),
                      label: const Text('Purge Everything Cache'),
                    ),
                  ],
                ),
    );
  }

  void _showSelectDialog(String settingId, String title, dynamic current) {
    List<String> options = [];
    if (settingId == 'ssl') {
      options = ['off', 'flexible', 'full', 'strict'];
    } else if (settingId == 'min_tls_version') {
      options = ['1.0', '1.1', '1.2', '1.3'];
    } else if (settingId == 'security_level') {
      options = ['off', 'essentially_off', 'low', 'medium', 'high', 'under_attack'];
    }

    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
            ),
            ...options.map((o) => ListTile(
                  title: Text(o.toUpperCase()),
                  trailing: current == o ? const Icon(Icons.check, color: AppColors.primary) : null,
                  onTap: () {
                    Navigator.pop(ctx);
                    _update(settingId, o);
                  },
                )),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}
