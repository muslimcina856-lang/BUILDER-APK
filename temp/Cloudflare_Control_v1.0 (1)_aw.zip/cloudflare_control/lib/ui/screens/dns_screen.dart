import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';
import 'zone_settings_screen.dart';

class DnsScreen extends StatefulWidget {
  const DnsScreen({super.key});

  @override
  State<DnsScreen> createState() => _DnsScreenState();
}

class _DnsScreenState extends State<DnsScreen> {
  List<dynamic> zones = [];
  bool loading = true;
  String? error;
  String? selectedZoneId;
  String? selectedZoneName;
  List<dynamic> records = [];
  bool loadingRecords = false;

  @override
  void initState() {
    super.initState();
    _loadZones();
  }

  Future<void> _loadZones() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final api = CloudflareApi(account);
      final data = await api.getZones();
      setState(() {
        zones = data;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  Future<void> _loadRecords(String zoneId, String zoneName) async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      selectedZoneId = zoneId;
      selectedZoneName = zoneName;
      loadingRecords = true;
      records = [];
    });

    try {
      final api = CloudflareApi(account);
      final data = await api.getDnsRecords(zoneId);
      setState(() {
        records = data;
        loadingRecords = false;
      });
    } catch (e) {
      setState(() {
        loadingRecords = false;
        error = e.toString();
      });
    }
  }

  Future<void> _createRecord() async {
    if (selectedZoneId == null) return;

    final typeController = TextEditingController(text: 'A');
    final nameController = TextEditingController();
    final contentController = TextEditingController();
    final ttlController = TextEditingController(text: '1'); // Auto

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Cipta DNS Record'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: 'A',
                items: ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'SRV', 'CAA']
                    .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                    .toList(),
                onChanged: (v) => typeController.text = v ?? 'A',
                decoration: const InputDecoration(labelText: 'Type'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Name', hintText: 'www atau @'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: contentController,
                decoration: const InputDecoration(labelText: 'Content', hintText: 'IP atau target'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ttlController,
                decoration: const InputDecoration(labelText: 'TTL', hintText: '1 = Auto'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Cipta')),
        ],
      ),
    );

    if (result != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createDnsRecord(selectedZoneId!, {
        'type': typeController.text,
        'name': nameController.text.trim(),
        'content': contentController.text.trim(),
        'ttl': int.tryParse(ttlController.text) ?? 1,
        'proxied': false,
      });
      await _loadRecords(selectedZoneId!, selectedZoneName!);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('DNS Record berjaya dicipta'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _deleteRecord(String recordId, String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Record?'),
        content: Text('Padam $name?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam'),
          ),
        ],
      ),
    );

    if (confirm != true || selectedZoneId == null) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.deleteDnsRecord(selectedZoneId!, recordId);
      await _loadRecords(selectedZoneId!, selectedZoneName!);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal padam: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }


  Future<void> _editRecord(Map<String, dynamic> record) async {
    if (selectedZoneId == null) return;
    final nameController = TextEditingController(text: record['name']?.toString() ?? '');
    final contentController = TextEditingController(text: record['content']?.toString() ?? '');
    final ttlController = TextEditingController(text: (record['ttl'] ?? 1).toString());
    bool proxied = record['proxied'] == true;
    final canProxy = record['type'] == 'A' || record['type'] == 'AAAA' || record['type'] == 'CNAME';

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: Text('Edit ${record['type']} Record'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Name')),
                const SizedBox(height: 12),
                TextField(controller: contentController, decoration: const InputDecoration(labelText: 'Content')),
                const SizedBox(height: 12),
                TextField(controller: ttlController, decoration: const InputDecoration(labelText: 'TTL', hintText: '1 = Auto'), keyboardType: TextInputType.number),
                if (canProxy) ...[
                  const SizedBox(height: 8),
                  SwitchListTile(
                    title: const Text('Proxied'),
                    value: proxied,
                    onChanged: (v) => setDialogState(() => proxied = v),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Simpan')),
          ],
        ),
      ),
    );

    if (result != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.updateDnsRecord(selectedZoneId!, record['id'], {
        'type': record['type'],
        'name': nameController.text.trim(),
        'content': contentController.text.trim(),
        'ttl': int.tryParse(ttlController.text) ?? 1,
        'proxied': canProxy ? proxied : false,
      });
      await _loadRecords(selectedZoneId!, selectedZoneName!);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Record dikemaskini'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _toggleProxy(Map<String, dynamic> record) async {
    if (selectedZoneId == null) return;
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    final newProxied = !(record['proxied'] == true);

    try {
      final api = CloudflareApi(account);
      await api.updateDnsRecord(selectedZoneId!, record['id'], {
        'type': record['type'],
        'name': record['name'],
        'content': record['content'],
        'ttl': record['ttl'] ?? 1,
        'proxied': newProxied,
      });
      await _loadRecords(selectedZoneId!, selectedZoneName!);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal toggle proxy: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }


  Future<void> _deleteZone(String zoneId, String zoneName) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Padam Domain?'),
        content: Text('Padam $zoneName dari Cloudflare? DNS records akan hilang. Tindakan ini tidak boleh diundur.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam Domain'),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.deleteZone(zoneId);
      setState(() {
        selectedZoneId = null;
        selectedZoneName = null;
        records = [];
      });
      await _loadZones();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Domain berjaya dipadam'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _createZone() async {
    final controller = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tambah Domain'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Domain name', hintText: 'contoh.com'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Tambah')),
        ],
      ),
    );
    if (result != true) return;
    final name = controller.text.trim().toLowerCase();
    if (name.isEmpty) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createZone(name);
      await _loadZones();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Domain berjaya ditambah. Update nameserver di registrar.'), backgroundColor: AppColors.success, duration: Duration(seconds: 4)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(error!, style: const TextStyle(color: AppColors.danger)),
            const SizedBox(height: 16),
            FilledButton(onPressed: _loadZones, child: const Text('Cuba Lagi')),
          ],
        ),
      );
    }

    // Show records if zone selected
    if (selectedZoneId != null) {
      return Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () => setState(() {
                    selectedZoneId = null;
                    selectedZoneName = null;
                    records = [];
                  }),
                ),
                Expanded(
                  child: Text(
                    selectedZoneName ?? '',
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.settings_outlined),
                  onPressed: () {
                    if (selectedZoneId != null && selectedZoneName != null) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ZoneSettingsScreen(
                            zoneId: selectedZoneId!,
                            zoneName: selectedZoneName!,
                          ),
                        ),
                      );
                    }
                  },
                  tooltip: 'Zone Settings',
                ),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: _createRecord,
                  tooltip: 'Cipta DNS Record',
                ),
              ],
            ),
          ),
          Expanded(
            child: loadingRecords
                ? const Center(child: CircularProgressIndicator())
                : records.isEmpty
                    ? const Center(child: Text('Tiada DNS record'))
                    : ListView.builder(
                        itemCount: records.length,
                        itemBuilder: (ctx, i) {
                          final r = records[i];
                          final proxied = r['proxied'] == true;
                          final canProxy = r['type'] == 'A' || r['type'] == 'AAAA' || r['type'] == 'CNAME';
                          return ListTile(
                            title: Text('${r['type']}  ${r['name']}'),
                            subtitle: Text(r['content'] ?? ''),
                            onTap: () => _editRecord(r),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (canProxy)
                                  IconButton(
                                    icon: Icon(
                                      Icons.cloud,
                                      color: proxied ? AppColors.primary : AppColors.muted,
                                    ),
                                    tooltip: proxied ? 'Proxied' : 'DNS only',
                                    onPressed: () => _toggleProxy(r),
                                  ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline, color: AppColors.danger),
                                  onPressed: () => _deleteRecord(r['id'], r['name']),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      );
    }

    // Show zones list
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: _createZone,
              icon: const Icon(Icons.add, size: 18),
              label: const Text('Tambah Domain'),
            ),
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _loadZones,
            child: zones.isEmpty
                ? const Center(child: Text('Tiada domain dijumpai'))
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: zones.length,
                    itemBuilder: (ctx, i) {
                      final z = zones[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: ListTile(
                          leading: const Icon(Icons.language, color: AppColors.primary),
                          title: Text(z['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text('Status: ${z['status'] ?? '-'} • Tekan lama untuk padam'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => _loadRecords(z['id'], z['name']),
                          onLongPress: () => _deleteZone(z['id'], z['name']),
                        ),
                      );
                    },
                  ),
          ),
        ),
      ],
    );
  }
}
