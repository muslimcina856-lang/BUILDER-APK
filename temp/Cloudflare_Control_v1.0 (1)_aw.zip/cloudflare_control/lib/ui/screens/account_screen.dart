import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  Map<String, dynamic>? user;
  List<dynamic> accounts = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final api = CloudflareApi(account);
      final u = await api.getUser();
      final a = await api.getAccounts();
      setState(() {
        user = u;
        accounts = a;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppController>();

    if (loading) return const Center(child: CircularProgressIndicator());

    if (error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: _load, child: const Text('Cuba Lagi')),
          ],
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Maklumat Pengguna', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _InfoRow('Email', user?['email'] ?? '-'),
                _InfoRow('Nama', '${user?['first_name'] ?? ''} ${user?['last_name'] ?? ''}'),
                _InfoRow('ID', user?['id'] ?? '-'),
                _InfoRow('Two-Factor', (user?['two_factor_authentication_enabled'] == true) ? 'Aktif' : 'Tidak aktif'),
              ],
            ),
          ),
        ),

        const SizedBox(height: 28),
        const Text('Akaun Cloudflare', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        ...accounts.map((a) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                title: Text(a['name'] ?? a['id'] ?? '-'),
                subtitle: Text('ID: ${a['id']}'),
              ),
            )),

        const SizedBox(height: 28),
        const Text('Akaun dalam App', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        ...app.accounts.map((a) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.account_circle, color: AppColors.primary),
                title: Text(a.email),
                subtitle: Text('Ditambah: ${a.addedAt.toString().substring(0, 16)}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline, color: AppColors.danger),
                  onPressed: () async {
                    final confirm = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Buang akaun?'),
                        content: Text('Buang ${a.email} dari app ini?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
                          FilledButton(
                            onPressed: () => Navigator.pop(ctx, true),
                            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                            child: const Text('Buang'),
                          ),
                        ],
                      ),
                    );
                    if (confirm == true) {
                      await app.removeAccount(a.id);
                    }
                  },
                ),
              ),
            )),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 100, child: Text(label, style: const TextStyle(color: AppColors.muted))),
          Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w500))),
        ],
      ),
    );
  }
}
