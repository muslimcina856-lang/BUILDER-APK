import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/network/cloudflare_api.dart';
import '../../state/app_controller.dart';

class FirewallScreen extends StatefulWidget {
  const FirewallScreen({super.key});

  @override
  State<FirewallScreen> createState() => _FirewallScreenState();
}

class _FirewallScreenState extends State<FirewallScreen> {
  List<dynamic> zones = [];
  bool loading = true;
  String? selectedZoneId;
  String? selectedZoneName;
  List<dynamic> rules = [];
  bool loadingRules = false;

  @override
  void initState() {
    super.initState();
    _loadZones();
  }

  Future<void> _loadZones() async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;
    setState(() => loading = true);
    try {
      final api = CloudflareApi(account);
      final data = await api.getZones();
      setState(() {
        zones = data;
        loading = false;
      });
    } catch (e) {
      setState(() => loading = false);
    }
  }

  Future<void> _loadRules(String zoneId, String zoneName) async {
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;
    setState(() {
      selectedZoneId = zoneId;
      selectedZoneName = zoneName;
      loadingRules = true;
      rules = [];
    });
    try {
      final api = CloudflareApi(account);
      final data = await api.getIpAccessRules(zoneId);
      setState(() {
        rules = data;
        loadingRules = false;
      });
    } catch (e) {
      setState(() => loadingRules = false);
    }
  }

  Future<void> _addRule() async {
    if (selectedZoneId == null) return;
    final ipController = TextEditingController();
    String mode = 'block';

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Tambah IP Rule'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: ipController,
                decoration: const InputDecoration(labelText: 'IP Address', hintText: '1.2.3.4'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: mode,
                decoration: const InputDecoration(labelText: 'Action'),
                items: const [
                  DropdownMenuItem(value: 'block', child: Text('Block')),
                  DropdownMenuItem(value: 'challenge', child: Text('Challenge')),
                  DropdownMenuItem(value: 'whitelist', child: Text('Allow (Whitelist)')),
                  DropdownMenuItem(value: 'js_challenge', child: Text('JS Challenge')),
                ],
                onChanged: (v) => setDialogState(() => mode = v ?? 'block'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Tambah')),
          ],
        ),
      ),
    );

    if (result != true) return;
    final ip = ipController.text.trim();
    if (ip.isEmpty) return;

    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;

    try {
      final api = CloudflareApi(account);
      await api.createIpAccessRule(selectedZoneId!, mode, ip);
      await _loadRules(selectedZoneId!, selectedZoneName!);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Rule berjaya ditambah'), backgroundColor: AppColors.success),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  Future<void> _deleteRule(String ruleId) async {
    if (selectedZoneId == null) return;
    final app = context.read<AppController>();
    final account = app.activeAccount;
    if (account == null) return;
    try {
      final api = CloudflareApi(account);
      await api.deleteIpAccessRule(selectedZoneId!, ruleId);
      await _loadRules(selectedZoneId!, selectedZoneName!);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e'), backgroundColor: AppColors.danger),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: selectedZoneId != null
          ? AppBar(
              backgroundColor: Colors.white,
              leading: IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => setState(() {
                  selectedZoneId = null;
                  selectedZoneName = null;
                  rules = [];
                }),
              ),
              title: Text(selectedZoneName ?? ''),
              actions: [
                IconButton(icon: const Icon(Icons.add), onPressed: _addRule, tooltip: 'Tambah IP Rule'),
              ],
            )
          : null,
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : selectedZoneId != null
              ? (loadingRules
                  ? const Center(child: CircularProgressIndicator())
                  : rules.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.shield_outlined, size: 56, color: AppColors.muted),
                              const SizedBox(height: 12),
                              const Text('Tiada IP Access Rule', style: TextStyle(color: AppColors.muted)),
                              const SizedBox(height: 20),
                              FilledButton.icon(
                                onPressed: _addRule,
                                icon: const Icon(Icons.add),
                                label: const Text('Tambah Rule'),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: rules.length,
                          itemBuilder: (ctx, i) {
                            final r = rules[i];
                            final config = r['configuration'] ?? {};
                            final mode = r['mode'] ?? '-';
                            final value = config['value'] ?? '-';
                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: ListTile(
                                leading: Icon(
                                  mode == 'block' ? Icons.block : Icons.verified_user_outlined,
                                  color: mode == 'block' ? AppColors.danger : AppColors.success,
                                ),
                                title: Text(value),
                                subtitle: Text('Action: $mode'),
                                trailing: IconButton(
                                  icon: const Icon(Icons.delete_outline, color: AppColors.danger),
                                  onPressed: () => _deleteRule(r['id']),
                                ),
                              ),
                            );
                          },
                        ))
              : RefreshIndicator(
                  onRefresh: _loadZones,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: zones.length,
                    itemBuilder: (ctx, i) {
                      final z = zones[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: const Icon(Icons.security, color: AppColors.primary),
                          title: Text(z['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: const Text('IP Access Rules'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => _loadRules(z['id'], z['name']),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
