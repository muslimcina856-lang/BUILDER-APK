# Cloudflare Control

Aplikasi Flutter untuk mengurus akaun Cloudflare menggunakan **Global API Key** sahaja.

## Maklumat Asas
- **Nama**: Cloudflare Control
- **Package**: `com.cloudflare.manager`
- **versionCode**: 1
- **versionName**: 1.0.0
- **Framework**: Flutter + Dart
- **Icon**: Cloud oren (assets/icon/app_icon.png)

## Ciri-ciri Lengkap

### Onboarding
- Pilih bahasa (Melayu / English) — boleh tukar di Settings
- Masukkan Global API Key + tutorial cara dapatkan
- Token disimpan encrypted, **tidak dipaparkan** dalam UI
- Multi-account (papar email sahaja, no duplicate)

### Dashboard
- Ringkasan domain, Workers, R2, bilangan akaun

### Domain & DNS
- Senarai domain (zones)
- **Tambah Domain** (Create Zone)
- **Padam Domain** (tekan lama)
- DNS Records: Create, **Edit** (tap record), Delete
- **Proxy toggle** (icon cloud) untuk A / AAAA / CNAME
- **Zone Settings**: SSL mode, Always HTTPS, Min TLS, Security Level, Browser Check, Hotlink Protection, Email Obfuscation
- **Purge Cache** (Everything)

### Email Routing
- **Destination Addresses**: Tambah email → Pending → Verify di Gmail → Verified
- **Routing Rules**: Create / Delete email address (pilih destination verified)
- **Catch-all** On/Off

### Storage
- R2: Create / Delete bucket
- KV: Create Namespace + List

### Security
- IP Access Rules: Block / Challenge / Allow / JS Challenge
- Link ke Zone Security Settings

### Workers & Pages
- List Workers scripts
- List Pages projects

### Account
- Maklumat user Cloudflare
- Senarai akaun dalam app + buang akaun

### Notifikasi
- On/Off per akaun (default Off)

### Settings
- Tukar bahasa
- Saluran Saya → https://t.me/earlstore2004
- Hubungi Kami → https://t.me/earlxz
- Padam semua akaun
- © 2026 Earlxz. All rights reserved.

## Cara Jalankan

```bash
cd cloudflare_control
flutter create . --project-name manager --org com.cloudflare
# (lengkapkan platform files jika perlu)

flutter pub get
flutter run
```

## Nota Penting
1. Hanya **Global API Key** diterima.
2. Email Routing: Enable dulu di dashboard Cloudflare + verify destination.
3. Selepas Create Zone, update nameserver di registrar.
4. Minimal Android permission (INTERNET sahaja).

© 2026 Earlxz. All rights reserved.
