package com.ituxx.app

import android.animation.Animator
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    // ====== KONFIGURASI DURASI SPLASH (ms) — bebas diubah ======
    private val FADE_IN_DURATION = 800L
    private val HOLD_DURATION = 1500L
    private val FADE_OUT_DURATION = 800L
    // =============================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val rootView = findViewById<android.view.View>(R.id.splashRoot)
        rootView.alpha = 0f

        // Fade in pas pertama muncul
        ObjectAnimator.ofFloat(rootView, "alpha", 0f, 1f).apply {
            duration = FADE_IN_DURATION
            start()
        }

        // Tunggu (fade in + hold), lalu fade out, baru pindah ke Login
        Handler(Looper.getMainLooper()).postDelayed({
            val fadeOut = ObjectAnimator.ofFloat(rootView, "alpha", 1f, 0f)
            fadeOut.duration = FADE_OUT_DURATION
            fadeOut.addListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {}
                override fun onAnimationEnd(animation: Animator) {
                    goToLogin()
                }
                override fun onAnimationCancel(animation: Animator) {}
                override fun onAnimationRepeat(animation: Animator) {}
            })
            fadeOut.start()
        }, FADE_IN_DURATION + HOLD_DURATION)
    }

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        finish()
    }
}
