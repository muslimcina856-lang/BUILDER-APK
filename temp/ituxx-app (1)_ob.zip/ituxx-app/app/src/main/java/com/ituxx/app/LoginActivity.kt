package com.ituxx.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.ituxx.app.databinding.ActivityLoginBinding

/**
 * ============================================================
 * LOGIN ACTIVITY — INI BARU SHELL/TEMPLATE.
 *
 * Developer (lo) wajib isi logic auth aslinya sendiri di sini,
 * misalnya panggil API backend (Node.js/Express yang udah lo
 * bikin), validasi response-nya, simpen token/session, dst.
 * ============================================================
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            val username = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.login_error_empty), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // =====================================================
            // TODO (DEVELOPER): Ganti baris di bawah ini dengan
            // proses login asli ke server lo. Contoh kerangka:
            //
            // showLoading(true)
            // ApiClient.login(username, password) { success, message ->
            //     showLoading(false)
            //     if (success) {
            //         goToVideoIntro()
            //     } else {
            //         Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            //     }
            // }
            // =====================================================

            // Sementara: langsung dianggap berhasil biar alur bisa dites
            goToVideoIntro()
        }
    }

    private fun goToVideoIntro() {
        startActivity(Intent(this, VideoIntroActivity::class.java))
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        finish()
    }
}
