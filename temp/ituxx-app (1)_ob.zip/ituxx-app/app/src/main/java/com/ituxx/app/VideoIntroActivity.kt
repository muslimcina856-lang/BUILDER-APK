package com.ituxx.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.ituxx.app.databinding.ActivityVideoIntroBinding

/**
 * Video intro yang tampil SEKALI setelah login sukses.
 * - Gabisa di-skip (tombol back dimatikan sampai video selesai)
 * - Pas video kelar -> fade halus -> pindah ke MainActivity
 *
 * Ganti file video di: app/src/main/res/raw/intro_video.mp4
 */
class VideoIntroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVideoIntroBinding
    private var videoFinished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVideoIntroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Matikan tombol back selama video belum selesai (gabisa di-skip)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (videoFinished) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
                // kalau belum selesai: diemin aja, gak ngapa-ngapain
            }
        })

        val videoUri = Uri.parse("android.resource://$packageName/${R.raw.intro_video}")
        binding.videoView.setVideoURI(videoUri)
        binding.videoView.setOnPreparedListener { it.start() }
        binding.videoView.setOnCompletionListener {
            videoFinished = true
            fadeToMain()
        }
    }

    private fun fadeToMain() {
        binding.root.animate()
            .alpha(0f)
            .setDuration(600)
            .withEndAction {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
            .start()
    }
}
