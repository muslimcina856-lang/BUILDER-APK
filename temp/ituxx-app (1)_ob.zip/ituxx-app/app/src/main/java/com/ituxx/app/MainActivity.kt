package com.ituxx.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * MAIN MENU — placeholder.
 * User akan desain sendiri tampilan & fitur menu utama di sini.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
