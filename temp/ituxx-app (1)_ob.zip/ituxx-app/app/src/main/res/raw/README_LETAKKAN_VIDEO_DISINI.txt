PENTING: Folder ini harus berisi file video bernama "intro_video.mp4"
(format mp4, h264). Taruh video intro lo di sini dengan nama itu PERSIS,
contoh: app/src/main/res/raw/intro_video.mp4

File .txt ini cuma placeholder dan harus dihapus setelah video asli
sudah ditaruh di folder ini.
