# ITUXX App — Template Splash → Login → Video Intro → Main Menu

Project Android Studio (Kotlin) siap pakai buat alur yang lo minta:

```
SplashActivity  ->  LoginActivity  ->  VideoIntroActivity  ->  MainActivity
(foto bundar      (developer isi      (video sekali,         (didesain
 fade halus)       logic login)        gabisa di-skip)        sendiri)
```

## ⚠️ Catatan penting

Project ini **belum di-compile jadi .apk**. Saya gak punya akses Android
SDK di environment saya buat compile langsung. Tapi tenang — ada cara
build APK-nya **TANPA install Android Studio sama sekali**, pakai
GitHub Actions (gratis, jalan di cloud-nya GitHub).

---

## 🚀 CARA BUILD TANPA ANDROID STUDIO (pakai GitHub, gratis)

Project ini udah dilengkapi file `.github/workflows/build-apk.yml` yang
bikin GitHub otomatis compile APK-nya buat lo. Lo cuma butuh akun
GitHub (gratis), gak perlu install apa-apa di laptop/HP.

### Langkah-langkah:

1. **Buat akun GitHub** (kalau belum punya) di https://github.com/signup

2. **Buat repository baru**:
   - Klik tombol **+** di kanan atas → **New repository**
   - Kasih nama bebas, misal `ituxx-app`
   - Pilih **Private** atau **Public** (bebas)
   - Klik **Create repository** (jangan centang "Add README")

3. **Upload semua file project**:
   - Extract zip ini dulu di komputer/HP lo
   - Di halaman repo yang baru dibuat, klik link
     **"uploading an existing file"**
   - Drag & drop / pilih SEMUA isi folder `ituxx-app` (termasuk folder
     `.github` yang tersembunyi — di file manager HP biasanya perlu
     diaktifin dulu "tampilkan file tersembunyi")
   - Commit perubahan

4. **Tunggu build otomatis jalan**:
   - Klik tab **Actions** di repo lo
   - Akan ada workflow run "Build APK" yang otomatis jalan (durasi ~2-3
     menit)
   - Tunggu sampai centang hijau ✅

5. **Download APK hasil build**:
   - Klik workflow run yang udah selesai (centang hijau)
   - Scroll ke bawah ke bagian **Artifacts**
   - Klik **app-debug-apk** buat download (isinya `app-debug.apk`)
   - Install APK itu di HP Android lo (mungkin perlu aktifin
     "Install dari sumber tidak dikenal" di setting HP)

Setiap kali lo edit file (ganti icon, video, logic login, dsb) dan
upload ulang/commit ke GitHub, workflow ini otomatis jalan lagi dan
generate APK baru — gak perlu Android Studio sama sekali.

---

## (Opsional) Cara build pakai Android Studio

Kalau suatu saat lo punya akses ke laptop yang support Android Studio:

### 1. Buka project
- Extract zip ini
- Buka folder `ituxx-app` lewat **Android Studio** (Open existing project)
- Tunggu Gradle sync selesai (butuh internet buat download dependency
  pertama kali)

### 2. Ganti icon app
Paling gampang: klik kanan folder `res` → **New > Image Asset** →
upload gambar lo → Android Studio otomatis generate semua ukuran +
adaptive icon. Atau manual ganti file PNG di:
```
app/src/main/res/mipmap-mdpi/ic_launcher.png
app/src/main/res/mipmap-hdpi/ic_launcher.png
app/src/main/res/mipmap-xhdpi/ic_launcher.png
app/src/main/res/mipmap-xxhdpi/ic_launcher.png
app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
```
(sekarang isinya placeholder logo "I" warna biru, generate otomatis)

### 3. Ganti foto & teks splash
- Foto bundar: ganti file `app/src/main/res/drawable/splash_photo.png`
  dengan foto lo (otomatis di-crop bundar sama kode-nya)
- Teks di bawah foto: edit `splash_text` di
  `app/src/main/res/values/strings.xml`
- Durasi fade in / hold / fade out: edit 3 variabel di atas
  `SplashActivity.kt`

### 4. Isi logic login
Buka `app/src/main/java/com/ituxx/app/LoginActivity.kt`.
Ada blok `// TODO (DEVELOPER): ...` — di situ lo ganti dengan request
ke backend lo sendiri (misal hit API Node.js/Express yang udah lo
bikin), cek hasilnya, baru lanjut ke video intro kalau sukses.
Layout form login ada di `res/layout/activity_login.xml`, bebas
diubah sesuai kebutuhan (tambah logo, lupa password, dll).

### 5. Pasang video intro
- Taruh file video dengan nama **`intro_video.mp4`** persis di:
  `app/src/main/res/raw/intro_video.mp4`
- Hapus file `README_LETAKKAN_VIDEO_DISINI.txt` di folder yang sama
- Video bakal otomatis fullscreen, autoplay, dan **gabisa di-skip**
  (tombol back dimatikan sampai video selesai). Begitu video kelar,
  layar fade halus ke Main Menu.

### 6. Desain Main Menu
`MainActivity.kt` + `res/layout/activity_main.xml` sekarang isinya
cuma placeholder teks. Ganti total sesuai desain main menu lo.

### 7. Build APK
Di Android Studio: **Build → Build Bundle(s)/APK(s) → Build APK(s)**
APK hasil build ada di `app/build/outputs/apk/debug/app-debug.apk`

## Struktur file penting

```
app/src/main/java/com/ituxx/app/
  SplashActivity.kt       <- animasi fade splash
  LoginActivity.kt         <- TODO: isi logic login asli
  VideoIntroActivity.kt    <- video non-skippable + fade ke main
  MainActivity.kt           <- TODO: desain main menu

app/src/main/res/
  layout/                  <- semua tampilan (xml)
  drawable/splash_photo.png <- foto bundar splash (ganti ini)
  raw/intro_video.mp4       <- video intro (taruh video lo di sini)
  mipmap-*/ic_launcher*.png <- icon app (ganti ini / pakai Image Asset)
  values/strings.xml        <- teks-teks app
  values/colors.xml          <- warna brand
```
