package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import android.util.Log
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.example.ui.theme.MyApplicationTheme
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.URISyntaxException
import java.text.SimpleDateFormat
import java.util.*

// Representation of state
enum class UiScreen {
    LOGIN,
    CHAT,
    GAMES,
    GALLERY
}

data class ChatMessage(
    val id: Long,
    val sender: String,
    val content: String,
    val type: String, // 'text' or 'media'
    val mediaUrl: String?,
    val timestamp: String
)

data class GameModel(
    val title: String,
    val imageUrl: String,
    val gameUrl: String
)

data class MediaItem(
    val type: String, // 'image' or 'video'
    val url: String,
    val isLocal: Boolean = false,
    val bitmap: Bitmap? = null
)

class MainActivity : ComponentActivity() {

    private lateinit var preferences: SharedPreferences
    private var socket: Socket? = null
    
    // Server endpoint URL
    private val serverBaseUrl = "https://abide-botanist-fondling.ngrok-free.dev/"

    // In-Memory state definitions
    private var screenState = mutableStateOf(UiScreen.LOGIN)
    private var currentUsername = mutableStateOf("")
    private var messageHistory = mutableStateListOf<ChatMessage>()
    private var galleryItems = mutableStateListOf<MediaItem>()
    private var partnerOnline = mutableStateOf(true) // assume relative status
    private var isAppInBackground = false

    // Calling simulations & Peer connection states
    private var activeCallState = mutableStateOf<String?>(null) // null, 'dialing', 'incoming', 'connected'
    private var isVideoCall = mutableStateOf(false)
    private var isMuted = mutableStateOf(false)
    private var isCameraOff = mutableStateOf(false)
    private var callPartner = mutableStateOf("")

    // PiP responsive state
    private var isPipMode = mutableStateOf(false)

    // Background messaging custom listeners
    companion object {
        const val BACKGROUND_CHANNEL_ID = "partner_messages"
        const val BACKGROUND_NOTIF_ID = 2002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        preferences = getSharedPreferences("ReplikaCintaStorage", MODE_PRIVATE)

        // Try automatic login if saved
        val savedUser = preferences.getString("saved_username", "")
        val savedPass = preferences.getString("saved_password", "")
        if (!savedUser.isNullOrEmpty() && !savedPass.isNullOrEmpty()) {
            currentUsername.value = savedUser
            startSocketConnection(savedUser, savedPass)
            screenState.value = UiScreen.CHAT
        }

        // Schedule Morning Alarm
        AlarmReceiver.scheduleDailyAlarm(this)

        setContent {
            MyApplicationTheme(darkTheme = true) {
                // Track standard lifecycle to toggle inside/outside background flag
                val lifecycleOwner = LocalLifecycleOwner.current
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        isAppInBackground = when (event) {
                            Lifecycle.Event.ON_STOP -> {
                                true
                            }
                            Lifecycle.Event.ON_START -> {
                                false
                            }
                            else -> isAppInBackground
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF130613) // romantic ambient dark background
                ) {
                    AppContent()
                }
            }
        }
    }

    @SuppressLint("MissingSuperCall")
    override fun onUserLeaveHint() {
        // If they exit during an active Video Call, automatically trigger floating Picture-in-Picture mode!
        if (activeCallState.value == "connected" && isVideoCall.value) {
            enterPictureInPictureModeUniversal()
        }
    }

    private fun enterPictureInPictureModeUniversal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val paramsBuilder = PictureInPictureParams.Builder()
                enterPictureInPictureMode(paramsBuilder.build())
            } catch (e: Exception) {
                Log.e("MainActivity", "Failed to enter PIP Mode", e)
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isPipMode.value = isInPictureInPictureMode
    }

    private fun postBackgroundNotification(context: Context, sender: String, content: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create Channel for Background Messages
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                BACKGROUND_CHANNEL_ID,
                "Partner Live Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifikasi live jika pasangan mengirim pesan baru"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, BACKGROUND_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_send)
            .setContentTitle("💌 Pesan dari $sender")
            .setContentText(if (content.startsWith("data:")) "[Kirim Gambar/Video]" else content)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(500, 500))
            .build()

        notificationManager.notify(BACKGROUND_NOTIF_ID, notification)
    }

    private fun startSocketConnection(username: String, pass: String) {
        try {
            val opts = IO.Options().apply {
                forceNew = true
                reconnection = true
                // Bypass potential ngrok warning block filters
                extraHeaders = mapOf("ngrok-skip-browser-warning" to listOf("true"))
            }
            socket = IO.socket(serverBaseUrl, opts)

            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("MainActivity", "Connected to socket server successfully")
                val loginObj = JSONObject().apply {
                    put("username", username)
                    put("password", pass)
                }
                socket?.emit("user-login", loginObj)
            }

            socket?.on("login-success") { args ->
                runOnUiThread {
                    Toast.makeText(this, "Selamat datang, $username! 💖", Toast.LENGTH_SHORT).show()
                }
            }

            socket?.on("login-error") { args ->
                runOnUiThread {
                    val data = args[0] as? JSONObject
                    val msg = data?.optString("message") ?: "Login gagal!"
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    // Hapus storage login otomatis jika gagal
                    preferences.edit().clear().apply()
                    screenState.value = UiScreen.LOGIN
                }
            }

            socket?.on("message-history") { args ->
                runOnUiThread {
                    messageHistory.clear()
                    val arr = args[0] as? JSONArray
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            messageHistory.add(parseMessageObject(obj))
                        }
                    }
                }
            }

            socket?.on("new-message") { args ->
                runOnUiThread {
                    val obj = args[0] as? JSONObject
                    if (obj != null) {
                        val msg = parseMessageObject(obj)
                        messageHistory.add(msg)

                        // If user is PIP or App is minimized/backgrounded, trigger system head-up notification!
                        if (isAppInBackground && msg.sender != currentUsername.value) {
                            postBackgroundNotification(this, msg.sender, msg.content)
                        }
                    }
                }
            }

            socket?.on("media-list") { args ->
                runOnUiThread {
                    val arr = args[0] as? JSONArray
                    if (arr != null) {
                        // Keep our local picked items and pull remote list items
                        val localItems = galleryItems.filter { it.isLocal }
                        galleryItems.clear()
                        galleryItems.addAll(localItems)
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            val type = obj.optString("type") ?: "image"
                            var url = obj.optString("url") ?: ""
                            // Build complete absolute ngrok url from relative endpoint
                            if (url.startsWith("/")) {
                                url = serverBaseUrl.removeSuffix("/") + url
                            }
                            galleryItems.add(MediaItem(type = type, url = url))
                        }
                    }
                }
            }

            socket?.on("user-online") { args ->
                runOnUiThread {
                    val user = args[0] as? String ?: ""
                    partnerOnline.value = true
                    Toast.makeText(this, "$user masuk online! 💖", Toast.LENGTH_SHORT).show()
                }
            }

            socket?.on("user-offline") { args ->
                runOnUiThread {
                    val user = args[0] as? String ?: ""
                    partnerOnline.value = false
                    Toast.makeText(this, "$user sedang offline 💔", Toast.LENGTH_SHORT).show()
                }
            }

            // WebRTC Call Sync Listeners
            socket?.on("incoming-call") { args ->
                runOnUiThread {
                    val data = args[0] as? JSONObject
                    if (data != null) {
                        val from = data.optString("from") ?: "Seseorang"
                        val type = data.optString("type") ?: "video"
                        callPartner.value = from
                        isVideoCall.value = type == "video"
                        activeCallState.value = "incoming"
                    }
                }
            }

            socket?.on("call-answered") {
                runOnUiThread {
                    activeCallState.value = "connected"
                    Toast.makeText(this, "Panggilan terhubung 📞", Toast.LENGTH_SHORT).show()
                }
            }

            socket?.on("call-ended") {
                runOnUiThread {
                    activeCallState.value = null
                    Toast.makeText(this, "Panggilan diakhiri", Toast.LENGTH_SHORT).show()
                }
            }

            socket?.connect()
        } catch (e: URISyntaxException) {
            Log.e("MainActivity", "Socket URL syntax issue", e)
        }
    }

    private fun parseMessageObject(obj: JSONObject): ChatMessage {
        return ChatMessage(
            id = obj.optLong("id", System.currentTimeMillis()),
            sender = obj.optString("sender"),
            content = obj.optString("content"),
            type = obj.optString("type", "text"),
            mediaUrl = obj.optString("mediaUrl", null).let { if (it == "null" || it.isEmpty()) null else it },
            timestamp = obj.optString("timestamp", "")
        )
    }

    private fun handleAttachFileResult(uri: Uri) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val context = this@MainActivity
                val contentResolver = context.contentResolver
                val fileMime = contentResolver.getType(uri) ?: "image/jpeg"
                val inputStream: InputStream? = contentResolver.openInputStream(uri)

                var fileName = "attachment"
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && nameIndex != -1) {
                        fileName = cursor.getString(nameIndex)
                    }
                }

                if (inputStream != null) {
                    val bytes = inputStream.readBytes()
                    val base64Encoded = Base64.encodeToString(bytes, Base64.DEFAULT)
                    val formattedBase64Url = "data:$fileMime;base64,$base64Encoded"

                    // Read local gallery dynamic bitmap so user instantly sees visual quality
                    val localBitmap = if (fileMime.contains("image")) {
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    } else null

                    withContext(Dispatchers.Main) {
                        // Emit base64 media block packet to the socket.io back-end
                        val type = if (fileMime.contains("video")) "video" else "image"
                        val packet = JSONObject().apply {
                            put("content", formattedBase64Url)
                            put("type", "media")
                            put("mediaUrl", formattedBase64Url)
                        }
                        socket?.emit("chat-message", packet)

                        // Save media to our immediate galleryItems (Offline / Client Cache list)
                        galleryItems.add(0, MediaItem(
                            type = type,
                            url = uri.toString(),
                            isLocal = true,
                            bitmap = localBitmap
                        ))
                    }
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error reading media attachment", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Gagal melampirkan media", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Main layout container routing
    @Composable
    fun AppContent() {
        val currentScreen by screenState
        val pipActive by isPipMode

        if (pipActive) {
            // PIP View Mode: rendering ONLY the active fullscreen calling session
            CallingView(isPip = true)
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                // Background Gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF260D27), // Romantic Dark Purple
                                    Color(0xFF140516)  // Pitch Dark Ambient Rose
                                )
                            )
                        )
                )

                // Navigation Stack based on active page
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        slideInHorizontally { width -> width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> -width } + fadeOut()
                    },
                    label = "Navigation"
                ) { screen ->
                    when (screen) {
                        UiScreen.LOGIN -> LoginScreen()
                        UiScreen.CHAT -> ChatViewScreen()
                        UiScreen.GAMES -> GamesMenuState()
                        UiScreen.GALLERY -> PhotoboothGalleryScreen()
                    }
                }

                // Call Modal overlay dynamically popping over any page
                if (activeCallState.value != null) {
                    CallingView(isPip = false)
                }
            }
        }
    }

    @Composable
    fun LoginScreen() {
        var userVal by remember { mutableStateOf("") }
        var passVal by remember { mutableStateOf("") }
        val infiniteTransition = rememberInfiniteTransition(label = "hearts")
        val heartScale by infiniteTransition.animateFloat(
            initialValue = 0.85f,
            targetValue = 1.15f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "heartScale"
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated Header Icon
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = "Love Icon",
                tint = Color(0xFFFF7E9F),
                modifier = Modifier
                    .size(90.dp)
                    .scale(heartScale)
                    .padding(bottom = 16.dp)
            )

            Text(
                text = "Replika Cinta 💖",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Serif
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Aplikasi Cinta Khusus Pipit Cantik & Geza",
                fontSize = 14.sp,
                color = Color(0xFFFFCBD6),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Glassmorphism login card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_card"),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0x3DFFA0B8)
                ),
                border = BorderStroke(1.dp, Color(0x52FFA5BC))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Silakan Masuk Tuan & Putri",
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = userVal,
                        onValueChange = { userVal = it },
                        label = { Text("Username (pipitcantik / geza)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFF7E9F),
                            unfocusedBorderColor = Color(0x52FFA5BC),
                            focusedLabelColor = Color(0xFFFF7E9F),
                            unfocusedLabelColor = Color(0xFFFFCBD6)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("username_input"),
                        shape = RoundedCornerShape(16.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = passVal,
                        onValueChange = { passVal = it },
                        label = { Text("Kata Sandi") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFF7E9F),
                            unfocusedBorderColor = Color(0x52FFA5BC),
                            focusedLabelColor = Color(0xFFFF7E9F),
                            unfocusedLabelColor = Color(0xFFFFCBD6)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("password_input"),
                        shape = RoundedCornerShape(16.dp)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            val userTr = userVal.trim().lowercase()
                            val passTr = passVal.trim()
                            if (userTr == "pipitcantik" || userTr == "geza") {
                                currentUsername.value = userTr
                                preferences.edit().apply {
                                    putString("saved_username", userTr)
                                    putString("saved_password", passTr)
                                    apply()
                                }
                                startSocketConnection(userTr, passTr)
                                screenState.value = UiScreen.CHAT
                            } else {
                                Toast.makeText(this@MainActivity, "Username harus pipitcantik atau geza!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFF527A)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("login_button"),
                        shape = RoundedCornerShape(25.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Selesai")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Mulai Kisah Cinta", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun ChatViewScreen() {
        var textInputState by remember { mutableStateOf("") }
        var showingMenuDropdown by remember { mutableStateOf(false) }
        val chatListState = rememberLazyListState()
        val kbCtrl = LocalSoftwareKeyboardController.current

        // Request system push notification handles
        val ctx = LocalContext.current
        val launcherNotificationPermission = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                Log.d("MainActivity", "Notification permission granted")
            }
        }

        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    launcherNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }

        // File attach content action register
        val fileSelectionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) {
                handleAttachFileResult(uri)
            }
        }

        // Auto Scroll to last chat message upon updates
        LaunchedEffect(messageHistory.size) {
            if (messageHistory.isNotEmpty()) {
                chatListState.animateScrollToItem(messageHistory.size - 1)
            }
        }

        val partnerNameStr = if (currentUsername.value == "pipitcantik") "Geza 💙" else "Pipit Cantik 🤍"
        val partnerAvatarUrl = if (currentUsername.value == "pipitcantik") {
            "https://i.pinimg.com/originals/5e/6e/48/5e6e4807c1f180142381c676a5a10af6.gif"
        } else {
            "https://i.pinimg.com/originals/23/c0/b7/23c0b79b62bef8d32e458e7dec28c3f5.gif"
        }

        Scaffold(
            topBar = {
                @OptIn(ExperimentalMaterial3Api::class)
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(44.dp)) {
                                AsyncImage(
                                    model = partnerAvatarUrl,
                                    contentDescription = "Partner avatar",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                        .border(2.dp, Color(0xFFFFB7C5), CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                // Active online sign
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .align(Alignment.BottomEnd)
                                        .clip(CircleShape)
                                        .background(if (partnerOnline.value) Color(0xFFc7f9cc) else Color(0xFFe63946))
                                        .border(1.dp, Color.Black, CircleShape)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = partnerNameStr,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = if (partnerOnline.value) "Online" else "Offline",
                                    fontSize = 11.sp,
                                    color = if (partnerOnline.value) Color(0xFFFFD5E0) else Color(0xFFC4B8C4)
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            callPartner.value = partnerNameStr
                            isVideoCall.value = false
                            activeCallState.value = "dialing"
                            socket?.emit("call-user", JSONObject().apply {
                                put("to", if (currentUsername.value == "pipitcantik") "geza" else "pipitcantik")
                                put("from", currentUsername.value)
                                put("type", "audio")
                            })
                        }) {
                            Icon(Icons.Default.Phone, contentDescription = "Phone Call", tint = Color.White)
                        }
                        IconButton(onClick = {
                            callPartner.value = partnerNameStr
                            isVideoCall.value = true
                            activeCallState.value = "dialing"
                            socket?.emit("call-user", JSONObject().apply {
                                put("to", if (currentUsername.value == "pipitcantik") "geza" else "pipitcantik")
                                put("from", currentUsername.value)
                                put("type", "video")
                            })
                        }) {
                            Icon(Icons.Default.VideoCall, contentDescription = "Video Call", tint = Color.White)
                        }
                        Box {
                            IconButton(onClick = { showingMenuDropdown = !showingMenuDropdown }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "Menu", tint = Color.White)
                            }
                            DropdownMenu(
                                expanded = showingMenuDropdown,
                                onDismissRequest = { showingMenuDropdown = false },
                                modifier = Modifier.background(Color(0xFF260D27))
                            ) {
                                DropdownMenuItem(
                                    text = { Text("🎮 Menu Game Romantis", color = Color.White) },
                                    onClick = {
                                        showingMenuDropdown = false
                                        screenState.value = UiScreen.GAMES
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("📸 Photobooth Gallery", color = Color.White) },
                                    onClick = {
                                        showingMenuDropdown = false
                                        screenState.value = UiScreen.GALLERY
                                    }
                                )
                                Divider(color = Color(0x3DFFA0B8))
                                DropdownMenuItem(
                                    text = { Text("🚪 Logout / Keluar", color = Color(0xFFFF527A)) },
                                    onClick = {
                                        showingMenuDropdown = false
                                        preferences.edit().clear().apply()
                                        socket?.disconnect()
                                        screenState.value = UiScreen.LOGIN
                                    }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF250C26)
                    )
                )
            },
            bottomBar = {
                // Inline entry messaging composer styling
                Surface(
                    color = Color(0xFF1D061E),
                    tonalElevation = 6.dp,
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { fileSelectionLauncher.launch("image/* video/*") },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = "Attach file icon",
                                tint = Color(0xFFFFCBD6),
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        OutlinedTextField(
                            value = textInputState,
                            onValueChange = { textInputState = it },
                            placeholder = { Text("Ketikan pesan termanis...", color = Color(0xFFFFCBD6), fontSize = 14.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFFF7E9F),
                                unfocusedBorderColor = Color(0x3DFFA0B8),
                                focusedContainerColor = Color(0x1AFFA0B8),
                                unfocusedContainerColor = Color(0x1AFFA0B8)
                            ),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(max = 120.dp)
                                .testTag("message_input"),
                            singleLine = false
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        FloatingActionButton(
                            onClick = {
                                val text = textInputState.trim()
                                if (text.isNotEmpty()) {
                                    val packet = JSONObject().apply {
                                        put("content", text)
                                        put("type", "text")
                                        put("mediaUrl", null)
                                    }
                                    socket?.emit("chat-message", packet)
                                    textInputState = ""
                                    kbCtrl?.hide()
                                }
                            },
                            containerColor = Color(0xFFFF527A),
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("send_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send Message", modifier = Modifier.size(20.dp))
                        }
                    }
                }
            },
            containerColor = Color(0xFF140516)
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (messageHistory.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FavoriteBorder,
                            contentDescription = "No messaging yet",
                            tint = Color(0x52FFA5BC),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Belum ada percakapan cinta hari ini.\nBagikan pesan romantis pertamamu!",
                            color = Color(0xFFFFCBD6),
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    LazyColumn(
                        state = chatListState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp),
                        contentPadding = PaddingValues(top = 10.dp, bottom = 12.dp)
                    ) {
                        items(messageHistory) { chat ->
                            val sentByMe = chat.sender == currentUsername.value
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = if (sentByMe) Arrangement.End else Arrangement.Start
                            ) {
                                if (!sentByMe) {
                                    AsyncImage(
                                        model = partnerAvatarUrl,
                                        contentDescription = "partner info",
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .border(1.dp, Color(0xFFFFB7C5), CircleShape)
                                            .align(Alignment.Top)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }

                                Column(
                                    horizontalAlignment = if (sentByMe) Alignment.End else Alignment.Start,
                                    modifier = Modifier.widthIn(max = 270.dp)
                                ) {
                                    // Bubble card container
                                    Card(
                                        shape = RoundedCornerShape(
                                            topStart = 16.dp,
                                            topEnd = 16.dp,
                                            bottomStart = if (sentByMe) 16.dp else 2.dp,
                                            bottomEnd = if (sentByMe) 2.dp else 16.dp
                                        ),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (sentByMe) Color(0xFFFFD5E0) else Color(0xFF2E1A2F)
                                        ),
                                        border = BorderStroke(
                                            width = 1.dp,
                                            color = if (sentByMe) Color(0xFFFFA5BC) else Color(0x28FFA5BC)
                                        )
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            if (chat.type == "media" || !chat.mediaUrl.isNullOrEmpty()) {
                                                val mUrl = chat.mediaUrl ?: chat.content
                                                val isVideo = mUrl.contains("video") || mUrl.contains("data:video") || mUrl.endsWith(".mp4")

                                                if (isVideo) {
                                                    // Stream and play video easily inside WebView or a clean custom player
                                                    Box(
                                                        modifier = Modifier
                                                            .width(220.dp)
                                                            .height(180.dp)
                                                            .clip(RoundedCornerShape(12.dp))
                                                            .background(Color.Black)
                                                    ) {
                                                        // Inline simple webview / custom block video preview
                                                        AndroidView(
                                                            factory = { context ->
                                                                WebView(context).apply {
                                                                    layoutParams = android.view.ViewGroup.LayoutParams(
                                                                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                                                        android.view.ViewGroup.LayoutParams.MATCH_PARENT
                                                                    )
                                                                    settings.mediaPlaybackRequiresUserGesture = false
                                                                    webViewClient = WebViewClient()
                                                                    val html = "<html><body style='margin:0;padding:0;background:#000;'><video width='100%' height='100%' controls autoplay loop muted><source src='$mUrl'></video></body></html>"
                                                                    loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                                                                }
                                                            },
                                                            modifier = Modifier.fillMaxSize()
                                                        )
                                                    }
                                                } else {
                                                    AsyncImage(
                                                        model = mUrl,
                                                        contentDescription = "shared photo",
                                                        modifier = Modifier
                                                            .width(200.dp)
                                                            .heightIn(max = 240.dp)
                                                            .clip(RoundedCornerShape(12.dp))
                                                            .border(1.dp, Color(0xFFFFE0E5), RoundedCornerShape(12.dp))
                                                    )
                                                }
                                            } else {
                                                Text(
                                                    text = chat.content,
                                                    color = if (sentByMe) Color(0xFF330C16) else Color.White,
                                                    fontSize = 14.5.sp,
                                                    lineHeight = 20.sp
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(4.dp))

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.End,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                val formattedTime = try {
                                                    val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
                                                    val date = parser.parse(chat.timestamp)
                                                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(date ?: Date())
                                                } catch (e: Exception) {
                                                    val now = Calendar.getInstance().time
                                                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
                                                }
                                                Text(
                                                    text = formattedTime,
                                                    color = if (sentByMe) Color(0x99330C16) else Color(0x99FFFFFF),
                                                    fontSize = 10.sp
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Favorite,
                                                    contentDescription = "love",
                                                    tint = Color(0xFFFF527A),
                                                    modifier = Modifier.size(10.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun GamesMenuState() {
        var activePlayingGame by remember { mutableStateOf<GameModel?>(null) }
        val gamesList = listOf(
            GameModel(
                title = "Knee Deep! [DEMO]",
                imageUrl = "https://img.itch.zone/aW1nLzI3MzM5MDk2LnBuZw==/315x250%23c/%2F26AU1.png",
                gameUrl = "https://html-classic.itch.zone/html/17289707/index.html?v=1777063917"
            ),
            GameModel(
                title = "Dermimi's!",
                imageUrl = "https://img.itch.zone/aW1nLzE5MTgzMDU2LmdpZg==/315x250%23c/HoG0v1.gif",
                gameUrl = "https://html-classic.itch.zone/html/17856518/index.html?v=1780945079"
            ),
            GameModel(
                title = "Chat Cowo Ganteng",
                imageUrl = "https://cdn.talkie-ai.com/talkie-user-img/135517845274740/154711439663309.jpeg?x-oss-process=image/resize,w_1024/format,webp",
                gameUrl = "https://www.talkie-ai.com/chat/cowok-ganteng-154699810677034#google_vignette"
            )
        )

        BackHandler {
            if (activePlayingGame != null) {
                activePlayingGame = null
            } else {
                screenState.value = UiScreen.CHAT
            }
        }

        if (activePlayingGame != null) {
            WebViewPlayer(game = activePlayingGame!!) {
                activePlayingGame = null
            }
        } else {
            Scaffold(
                topBar = {
                    @OptIn(ExperimentalMaterial3Api::class)
                    TopAppBar(
                        title = { Text("🎮 Menu Game Pasangan", color = Color.White, fontWeight = FontWeight.Bold) },
                        navigationIcon = {
                            IconButton(onClick = { screenState.value = UiScreen.CHAT }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF250C26))
                    )
                },
                containerColor = Color(0xFF140516)
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Main Bareng Pasangan 💖",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(gamesList) { game ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { activePlayingGame = game },
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, Color(0x3DFFA0B8)),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1A2F))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = game.imageUrl,
                                        contentDescription = game.title,
                                        modifier = Modifier
                                            .size(80.dp)
                                            .clip(RoundedCornerShape(12.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = game.title,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Klik untuk memainkan game",
                                            fontSize = 12.sp,
                                            color = Color(0xFFFFCBD6)
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.PlayCircle,
                                        contentDescription = "Play game",
                                        tint = Color(0xFFFF527A),
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    fun WebViewPlayer(game: GameModel, onBack: () -> Unit) {
        val webViewState = remember { mutableStateOf<WebView?>(null) }

        Scaffold(
            topBar = {
                @OptIn(ExperimentalMaterial3Api::class)
                TopAppBar(
                    title = {
                        Text(
                            text = game.title,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF250C26))
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                databaseEnabled = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                            }
                            webViewClient = WebViewClient()
                            webChromeClient = WebChromeClient()
                            loadUrl(game.gameUrl)
                            webViewState.value = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    @Composable
    fun PhotoboothGalleryScreen() {
        val launcherPhotoPick = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) {
                handleAttachFileResult(uri)
            }
        }

        BackHandler {
            screenState.value = UiScreen.CHAT
        }

        val designColors = listOf(
            Color(0xFF2E1330),
            Color(0xFF1E061F)
        )

        Scaffold(
            topBar = {
                @OptIn(ExperimentalMaterial3Api::class)
                TopAppBar(
                    title = { Text("📸 Photobooth Gallery", color = Color.White, fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { screenState.value = UiScreen.CHAT }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = { launcherPhotoPick.launch("image/* video/*") }) {
                            Icon(Icons.Default.AddAPhoto, contentDescription = "Upload Photo", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF250C26))
                )
            },
            containerColor = Color(0xFF140516)
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Brush.verticalGradient(designColors))
                    .padding(16.dp)
            ) {
                Text(
                    text = "Momen Indah Kita Berdua 💞",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Text(
                    text = "Klik tombol (+) untuk menambahkan foto baru",
                    fontSize = 12.sp,
                    color = Color(0xFFFFCBD6),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                if (galleryItems.isEmpty()) {
                    val fallbackCuteGallery = listOf(
                        MediaItem("image", "https://i.pinimg.com/originals/23/c0/b7/23c0b79b62bef8d32e458e7dec28c3f5.gif"),
                        MediaItem("image", "https://i.pinimg.com/originals/5e/6e/48/5e6e4807c1f180142381c676a5a10af6.gif")
                    )
                    LaunchedEffect(Unit) {
                        galleryItems.addAll(fallbackCuteGallery)
                    }
                }

                // Grid mapping manually using LazyColumn Rows for neat spacing
                val chunkedItems = galleryItems.chunked(2)
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(chunkedItems) { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            for (item in row) {
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(0.8f),
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, Color(0xFFFFB7C5)),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2E1A2F))
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(Color.Black),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (item.type == "video") {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = "Video preview sticker",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(48.dp)
                                                )
                                            } else {
                                                if (item.isLocal && item.bitmap != null) {
                                                    Image(
                                                        bitmap = item.bitmap.asImageBitmap(),
                                                        contentDescription = "local image preview",
                                                        modifier = Modifier.fillMaxSize(),
                                                        contentScale = ContentScale.Crop
                                                    )
                                                } else {
                                                    AsyncImage(
                                                        model = item.url,
                                                        contentDescription = "Gallery portrait",
                                                        modifier = Modifier.fillMaxSize(),
                                                        contentScale = ContentScale.Crop
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Favorite,
                                                contentDescription = "love icon",
                                                tint = Color(0xFFFF527A),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (item.isLocal) "Momen Baru" else "Momen Manis",
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                            // Empty box place holder for odd item rows
                            if (row.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun CallingView(isPip: Boolean) {
        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val pulseScale by infiniteTransition.animateFloat(
            initialValue = 0.95f,
            targetValue = 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(1000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseScale"
        )

        val textPulseAlpha by infiniteTransition.animateFloat(
            initialValue = 0.4f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(1000, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "textPulseAlpha"
        )

        val partnerAvatarUrl = if (currentUsername.value == "pipitcantik") {
            "https://i.pinimg.com/originals/5e/6e/48/5e6e4807c1f180142381c676a5a10af6.gif"
        } else {
            "https://i.pinimg.com/originals/23/c0/b7/23c0b79b62bef8d32e458e7dec28c3f5.gif"
        }

        val partnerNameStr = if (currentUsername.value == "pipitcantik") "Geza 💙" else "Pipit Cantik 🤍"

        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF19061B)
        ) {
            if (activeCallState.value == "connected" && isVideoCall.value) {
                // Video Connected screen: fully immersive video calling layout with overlap preview
                Box(modifier = Modifier.fillMaxSize()) {
                    // Fullscreen Main Stream placeholder (simulating romantic call partner stream)
                    AsyncImage(
                        model = partnerAvatarUrl,
                        contentDescription = "partner stream",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Small circular PIP overlapping Local user camera preview
                    if (!isPip && !isCameraOff.value) {
                        Card(
                            modifier = Modifier
                                .size(width = 100.dp, height = 140.dp)
                                .align(Alignment.TopEnd)
                                .padding(top = 40.dp, end = 16.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color.White),
                            elevation = CardDefaults.cardElevation(8.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                val myAvatar = if (currentUsername.value == "pipitcantik") {
                                    "https://i.pinimg.com/originals/23/c0/b7/23c0b79b62bef8d32e458e7dec28c3f5.gif"
                                } else {
                                    "https://i.pinimg.com/originals/5e/6e/48/5e6e4807c1f180142381c676a5a10af6.gif"
                                }
                                AsyncImage(
                                    model = myAvatar,
                                    contentDescription = "my stream",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0x7F000000))
                                        .padding(4.dp)
                                        .align(Alignment.BottomCenter)
                                ) {
                                    Text("Kamu", color = Color.White, fontSize = 10.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }

                    // Floating overlays inside safe areas
                    if (!isPip) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .statusBarsPadding()
                                .navigationBarsPadding(),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Top overlay details
                            Card(
                                modifier = Modifier.padding(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0x99000000)),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.VideoCall, contentDescription = "VC", tint = Color(0xFFFF527A))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Video Call: $partnerNameStr",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            // Controller Bottom Row Actions block
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xCC1A051B)),
                                shape = RoundedCornerShape(32.dp),
                                border = BorderStroke(1.dp, Color(0x40FFA5BC))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { isMuted.value = !isMuted.value },
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(if (isMuted.value) Color.Red else Color(0x28FFFFFF))
                                    ) {
                                        Icon(
                                            imageVector = if (isMuted.value) Icons.Default.MicOff else Icons.Default.Mic,
                                            contentDescription = "Mute mic",
                                            tint = Color.White
                                        )
                                    }

                                    FloatingActionButton(
                                        onClick = {
                                            socket?.emit("end-call", JSONObject().apply {
                                                put("to", if (currentUsername.value == "pipitcantik") "geza" else "pipitcantik")
                                            })
                                            activeCallState.value = null
                                        },
                                        containerColor = Color.Red,
                                        contentColor = Color.White,
                                        shape = CircleShape,
                                        modifier = Modifier.size(64.dp)
                                    ) {
                                        Icon(Icons.Default.CallEnd, contentDescription = "End Call", modifier = Modifier.size(32.dp))
                                    }

                                    IconButton(
                                        onClick = { isCameraOff.value = !isCameraOff.value },
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(if (isCameraOff.value) Color.Red else Color(0x28FFFFFF))
                                    ) {
                                        Icon(
                                            imageVector = if (isCameraOff.value) Icons.Default.VideocamOff else Icons.Default.Videocam,
                                            contentDescription = "Toggle Cam",
                                            tint = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Incoming or Dialing and generic Audio Voice call screens
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .statusBarsPadding()
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Title section
                    Text(
                        text = if (isVideoCall.value) "VIDEO CALL" else "AUDIO CALL",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFB7C5),
                        letterSpacing = 4.sp,
                        modifier = Modifier.padding(top = 16.dp)
                    )

                    // Profile core visual
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.scale(pulseScale)
                    ) {
                        AsyncImage(
                            model = partnerAvatarUrl,
                            contentDescription = "partner call avatar",
                            modifier = Modifier
                                .size(140.dp)
                                .clip(CircleShape)
                                .border(4.dp, Color(0xFFFF527A), CircleShape)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = partnerNameStr,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = when (activeCallState.value) {
                                "dialing" -> "Menghubungi..."
                                "incoming" -> "Panggilan Masuk..."
                                "connected" -> "Terhubung 00:15"
                                else -> "Panggilan..."
                            },
                            color = Color(0xFFFFCBD6),
                            fontSize = 14.sp,
                            modifier = Modifier.alpha(textPulseAlpha)
                        )
                    }

                    // Bottom controller area
                    when (activeCallState.value) {
                        "incoming" -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 32.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                FloatingActionButton(
                                    onClick = {
                                        socket?.emit("end-call", JSONObject().apply {
                                            put("to", if (currentUsername.value == "pipitcantik") "geza" else "pipitcantik")
                                        })
                                        activeCallState.value = null
                                    },
                                    containerColor = Color.Red,
                                    contentColor = Color.White,
                                    shape = CircleShape,
                                    modifier = Modifier.size(64.dp)
                                ) {
                                    Icon(Icons.Default.CallEnd, contentDescription = "Decline Call", modifier = Modifier.size(32.dp))
                                }

                                FloatingActionButton(
                                    onClick = {
                                        socket?.emit("answer-call", JSONObject().apply {
                                            put("to", if (currentUsername.value == "pipitcantik") "geza" else "pipitcantik")
                                        })
                                        activeCallState.value = "connected"
                                    },
                                    containerColor = Color.Green,
                                    contentColor = Color.White,
                                    shape = CircleShape,
                                    modifier = Modifier.size(64.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = "Accept Call", modifier = Modifier.size(32.dp))
                                }
                            }
                        }
                        else -> {
                            // Dialing or Voice Connected state: single end call toggle button
                            FloatingActionButton(
                                onClick = {
                                    socket?.emit("end-call", JSONObject().apply {
                                        put("to", if (currentUsername.value == "pipitcantik") "geza" else "pipitcantik")
                                    })
                                    activeCallState.value = null
                                },
                                containerColor = Color.Red,
                                contentColor = Color.White,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(64.dp)
                                    .padding(bottom = 16.dp)
                            ) {
                                Icon(Icons.Default.CallEnd, contentDescription = "End Call", modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
