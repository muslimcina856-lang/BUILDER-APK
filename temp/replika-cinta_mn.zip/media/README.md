# Media Folder for Couple Gallery

Halo Geza & Pipit Cantik! 💖

Kalian bisa menambahkan file foto (PNG, JPG, JPEG, GIF) atau video (MP4) ke dalam folder ini atau ke dalam folder `app/src/main/assets/media/`.

Semua file yang dimasukkan ke dalam folder `app/src/main/assets/media/` akan otomatis dideteksi dan ditampilkan di galeri diaplikasi secara dinamis!

Selain itu, kalian juga bisa menambahkan foto/video langsung lewat tombol klip kertas (+) di dalam chat aplikasi pada handphone kalian, yang kemudian akan otomatis dikonversi dan bisa tampil di kedua belah pihak secara realtime!
