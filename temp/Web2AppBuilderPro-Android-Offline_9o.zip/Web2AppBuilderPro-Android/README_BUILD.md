# Web2App Builder Pro - Android Offline App

Project ini membungkus builder Web2App sebagai aplikasi Android yang memuatkan `file:///android_asset/index.html`.
Ia tidak memerlukan Vercel atau hosting untuk membuka builder.

## Fungsi utama
- UI builder dimuatkan sepenuhnya daripada Android assets.
- `jszip.min.js` disimpan lokal, jadi proses generate ZIP tidak bergantung pada CDN.
- Upload icon menggunakan Android file chooser.
- Bila `Generate APK Project` ditekan, `AndroidFunction.saveProject(...)` menyimpan ZIP terus ke folder Download.
- Android 10+ menggunakan MediaStore; Android 8-9 menggunakan kebenaran storage legacy.

## Build
Buka folder ini dengan Android Studio, biarkan Gradle Sync selesai, kemudian:

`Build > Build Bundle(s) / APK(s) > Build APK(s)`

Konfigurasi wrapper app:
- Package: `com.web2app.builderpro`
- Min SDK: 26
- Target/Compile SDK: 35
- Version: 1.0.0

Nota: konfigurasi projek Android yang DIJANA oleh builder kekal seperti source asal versi kedua (Gradle 6.1.1 / AGP 3.6.4 / compile SDK 29 / min SDK 26).

## Pilihan build tanpa Android Studio
Folder `.github/workflows/build-apk.yml` turut disediakan. Jika project ini dimasukkan ke GitHub, workflow `Build Android APK` akan membina `app-debug.apk` dan meletakkannya sebagai Actions artifact. Ini hanya untuk build; builder APK yang terhasil tetap tidak memerlukan hosting.
