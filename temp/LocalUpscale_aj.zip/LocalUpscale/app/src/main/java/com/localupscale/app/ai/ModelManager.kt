package com.localupscale.app.ai

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

object ModelManager {

    private const val TAG = "ModelManager"
    private const val MODEL_NAME = "ai_upscale_model.tflite"

    // Quantized Real-ESRGAN x4plus (w8a8) ~17.6 MB — practical for mobile
    // Source: Qualcomm AI Hub / Hugging Face
    private const val MODEL_URL =
        "https://huggingface.co/qualcomm/Real-ESRGAN-x4plus/resolve/main/Real-ESRGAN-x4plus_w8a8.tflite"

    // Minimum expected size to consider model valid (approx 10MB)
    private const val MIN_MODEL_SIZE = 10_000_000L

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelReady(context: Context): Boolean {
        val file = getModelFile(context)
        return file.exists() && file.length() > MIN_MODEL_SIZE
    }

    /**
     * Download model with progress callback (0f - 1f)
     * Returns true if success
     */
    suspend fun downloadModel(
        context: Context,
        onProgress: (Float) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val target = getModelFile(context)

        // Already downloaded
        if (target.exists() && target.length() > MIN_MODEL_SIZE) {
            onProgress(1f)
            return@withContext true
        }

        // Delete incomplete file if any
        if (target.exists()) {
            target.delete()
        }

        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(180, TimeUnit.SECONDS)
                .followRedirects(true)
                .build()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "LocalUpscale/1.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Download failed: HTTP ${response.code}")
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val total = body.contentLength()
                var downloaded = 0L

                FileOutputStream(target).use { output ->
                    body.byteStream().use { input ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            output.write(buffer, 0, read)
                            downloaded += read
                            if (total > 0) {
                                onProgress((downloaded.toFloat() / total).coerceIn(0f, 1f))
                            } else {
                                // Unknown size — show approximate progress
                                onProgress((downloaded / (18_000_000f)).coerceIn(0f, 0.99f))
                            }
                        }
                    }
                }
            }

            val success = target.exists() && target.length() > MIN_MODEL_SIZE
            if (success) {
                Log.d(TAG, "Model downloaded successfully: ${target.length()} bytes")
                onProgress(1f)
            } else {
                Log.e(TAG, "Downloaded file too small or missing")
                target.delete()
            }
            success
        } catch (e: Exception) {
            Log.e(TAG, "Download failed", e)
            target.delete()
            false
        }
    }
}
