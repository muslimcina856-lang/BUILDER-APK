package com.localupscale.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.localupscale.app.ui.UpscaleScreen
import com.localupscale.app.ui.theme.LocalUpscaleTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LocalUpscaleTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    UpscaleScreen()
                }
            }
        }
    }
}
