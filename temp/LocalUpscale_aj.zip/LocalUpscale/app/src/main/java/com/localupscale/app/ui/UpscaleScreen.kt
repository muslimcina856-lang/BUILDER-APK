package com.localupscale.app.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localupscale.app.ai.ModelManager
import com.localupscale.app.ai.RealEsrganUpscaler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpscaleScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var resultBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var scaleFactor by remember { mutableStateOf(2) }

    var modelReady by remember { mutableStateOf(ModelManager.isModelReady(context)) }
    var isDownloading by remember { mutableStateOf(false) }
    var downloadProgress by remember { mutableStateOf(0f) }
    var downloadError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        if (!modelReady && !isDownloading) {
            isDownloading = true
            downloadError = null
            val success = ModelManager.downloadModel(context) { progress ->
                downloadProgress = progress
            }
            isDownloading = false
            modelReady = success
            if (!success) {
                downloadError = "Gagal download model. Cuba lagi."
            }
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                originalBitmap = loadBitmapFromUri(context, it)
                resultBitmap = null
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "LocalUpscale",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Text(
                            if (modelReady) "AI Model ready" else "Downloading model...",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            if (isDownloading || (!modelReady && downloadError == null)) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.CloudDownload,
                            contentDescription = null,
                            modifier = Modifier.size(40.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "Sedang download model AI...",
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { downloadProgress },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "${(downloadProgress * 100).toInt()}%",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            if (downloadError != null) {
                Text(
                    downloadError!!,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                Button(onClick = {
                    scope.launch {
                        isDownloading = true
                        downloadError = null
                        val success = ModelManager.downloadModel(context) { p ->
                            downloadProgress = p
                        }
                        isDownloading = false
                        modelReady = success
                        if (!success) downloadError = "Gagal download model. Cuba lagi."
                    }
                }) {
                    Text("Cuba Download Semula")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                        RoundedCornerShape(16.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                when {
                    isProcessing -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Sedang memproses AI...", color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    resultBitmap != null -> {
                        Image(
                            bitmap = resultBitmap!!.asImageBitmap(),
                            contentDescription = "Result",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    }
                    originalBitmap != null -> {
                        Image(
                            bitmap = originalBitmap!!.asImageBitmap(),
                            contentDescription = "Original",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    }
                    else -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Pilih gambar untuk upscale",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                "Skala Upscale",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                listOf(2, 3, 4).forEach { scale ->
                    FilterChip(
                        selected = scaleFactor == scale,
                        onClick = { scaleFactor = scale },
                        label = { Text("${scale}x") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { imagePicker.launch("image/*") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                enabled = modelReady
            ) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Pilih Gambar")
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    originalBitmap?.let { bmp ->
                        scope.launch {
                            isProcessing = true
                            try {
                                resultBitmap = withContext(Dispatchers.Default) {
                                    var result: android.graphics.Bitmap? = null
                                    try {
                                        val upscaler = RealEsrganUpscaler(context)
                                        if (upscaler.isModelLoaded()) {
                                            result = upscaler.upscale(bmp, scaleFactor)
                                        }
                                        upscaler.close()
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                    // Fallback to high-quality traditional if AI fails
                                    result ?: upscaleBitmap(bmp, scaleFactor)
                                }
                                if (resultBitmap == null) {
                                    Toast.makeText(context, "Gagal memproses gambar", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: OutOfMemoryError) {
                                Toast.makeText(context, "Memori tidak cukup. Cuba gambar lebih kecil.", Toast.LENGTH_LONG).show()
                                System.gc()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Gagal upscale", Toast.LENGTH_SHORT).show()
                                e.printStackTrace()
                            } finally {
                                isProcessing = false
                            }
                        }
                    } ?: Toast.makeText(context, "Pilih gambar dulu", Toast.LENGTH_SHORT).show()
                },
                enabled = originalBitmap != null && !isProcessing && modelReady,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            ) {
                Icon(Icons.Default.Tune, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (modelReady) "Upscale Sekarang" else "Tunggu model...")
            }

            if (resultBitmap != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        scope.launch {
                            val success = saveBitmapToGallery(context, resultBitmap!!)
                            Toast.makeText(
                                context,
                                if (success) "Berjaya disimpan ke Gallery" else "Gagal simpan",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Simpan ke Gallery")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                "LocalUpscale • First launch downloads model • Offline after that",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

private suspend fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
    return withContext(Dispatchers.IO) {
        try {
            // Decode with sampling first to avoid loading huge images into memory
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }

            val maxSide = 2048 // limit input size for stability
            var sampleSize = 1
            val w = options.outWidth
            val h = options.outHeight
            while (w / sampleSize > maxSide || h / sampleSize > maxSide) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

/**
 * Optimized & memory-safe upscale.
 * - Caps maximum output size to prevent OOM
 * - Uses high-quality filter
 * - Light sharpen without creating extra huge bitmaps when possible
 */
private fun upscaleBitmap(original: Bitmap, scale: Int): Bitmap {
    val maxOutputSide = 4096 // hard limit for stability on most phones

    var targetW = original.width * scale
    var targetH = original.height * scale

    // Scale down the target if it would be too large
    if (targetW > maxOutputSide || targetH > maxOutputSide) {
        val ratio = minOf(
            maxOutputSide.toFloat() / targetW,
            maxOutputSide.toFloat() / targetH
        )
        targetW = (targetW * ratio).toInt().coerceAtLeast(1)
        targetH = (targetH * ratio).toInt().coerceAtLeast(1)
    }

    // Create scaled bitmap
    val scaled = try {
        Bitmap.createScaledBitmap(original, targetW, targetH, true)
    } catch (e: OutOfMemoryError) {
        // Fallback: smaller size
        val fallbackW = (targetW * 0.6f).toInt().coerceAtLeast(1)
        val fallbackH = (targetH * 0.6f).toInt().coerceAtLeast(1)
        Bitmap.createScaledBitmap(original, fallbackW, fallbackH, true)
    }

    return try {
        applySharpen(scaled)
    } catch (e: OutOfMemoryError) {
        // If sharpen fails, just return the scaled version
        scaled
    }
}

private fun applySharpen(src: Bitmap): Bitmap {
    // Only sharpen if image is not extremely large
    if (src.width * src.height > 12_000_000) { // ~ round 3500x3500
        return src
    }

    val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(result)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    // Mild contrast boost / sharpen
    val matrix = ColorMatrix(floatArrayOf(
        1.12f, -0.04f, -0.04f, 0f, 0f,
        -0.04f, 1.12f, -0.04f, 0f, 0f,
        -0.04f, -0.04f, 1.12f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    ))
    paint.colorFilter = ColorMatrixColorFilter(matrix)
    canvas.drawBitmap(src, 0f, 0f, paint)

    // Recycle source if it is different instance (careful)
    if (src != result && !src.isRecycled) {
        // Don't recycle original that might still be used in UI
    }
    return result
}

private suspend fun saveBitmapToGallery(context: Context, bitmap: Bitmap): Boolean {
    return withContext(Dispatchers.IO) {
        try {
            val filename = "LocalUpscale_${System.currentTimeMillis()}.jpg"
            var outputStream: OutputStream? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/LocalUpscale"
                    )
                }
                val uri = context.contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                )
                uri?.let {
                    outputStream = context.contentResolver.openOutputStream(it)
                }
            } else {
                val imagesDir =
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val image = java.io.File(imagesDir, filename)
                outputStream = java.io.FileOutputStream(image)
            }

            outputStream?.use {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
