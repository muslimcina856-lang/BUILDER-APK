# LocalUpscale

Aplikasi Android offline AI image upscaler.

## Ciri-ciri
- First launch → auto download AI model (~17MB)
- Selepas download, terus offline
- Pilih gambar + skala 2x / 3x / 4x
- Optimized untuk elak crash (had saiz gambar)
- Preview hasil + simpan ke Gallery
- Dark theme Material 3

## Model
Menggunakan Real-ESRGAN x4plus (quantized) untuk tambah detail pada gambar kabur.

## Cara Build
1. Buka folder `LocalUpscale` di Android Studio
2. Sync Gradle
3. Run / Build APK

## Package
`com.localupscale.app`
