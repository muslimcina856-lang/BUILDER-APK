package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import java.text.NumberFormat
import java.util.Locale

object BudgetNotificationManager {
    private const val CHANNEL_ID = "financial_records_budget_alert_channel"
    private const val CHANNEL_NAME = "Financial Records Budget Alerts"
    private const val NOTIFICATION_ID_OVER = 8810
    private const val NOTIFICATION_ID_WARNING = 8811

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifikasi peringatan saat pengeluaran mendekati atau melebihi batas anggaran"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
                setSound(soundUri, audioAttributes)
            }

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun checkAndTriggerBudgetNotification(
        context: Context,
        currentExpense: Double,
        limitAmount: Double,
        categoryName: String = "ALL"
    ) {
        if (limitAmount <= 0) return

        val percentage = (currentExpense / limitAmount) * 100

        when {
            percentage >= 100 -> {
                triggerOverBudgetSoundAndNotification(context, currentExpense, limitAmount, categoryName)
            }
            percentage >= 80 -> {
                triggerApproachingBudgetNotification(context, currentExpense, limitAmount, percentage.toInt(), categoryName)
            }
        }
    }

    fun triggerApproachingBudgetNotification(
        context: Context,
        currentExpense: Double,
        limitAmount: Double,
        percentageInt: Int,
        categoryName: String = "ALL"
    ) {
        createNotificationChannel(context)

        val idrFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
        val formattedExpense = idrFormat.format(currentExpense)
        val formattedLimit = idrFormat.format(limitAmount)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            1,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val categoryText = if (categoryName == "ALL") "Anggaran Bulanan" else "Kategori $categoryName"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("⚠️ PENGELUARAN MENDEKATI BATAS ($percentageInt%)")
            .setContentText("$categoryText telah terpakai $percentageInt% ($formattedExpense dari $formattedLimit)")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Peringatan Anggaran: Total pengeluaran $categoryText Anda telah mencapai $percentageInt% ($formattedExpense) dari batas anggaran ($formattedLimit). Kelola sisa anggaran Anda secara bijak.")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVibrate(longArrayOf(0, 300, 150, 300))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_WARNING, notification)
    }

    fun triggerOverBudgetSoundAndNotification(
        context: Context,
        currentExpense: Double,
        limitAmount: Double,
        categoryName: String = "ALL"
    ) {
        createNotificationChannel(context)

        val idrFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
        val formattedExpense = idrFormat.format(currentExpense)
        val formattedLimit = idrFormat.format(limitAmount)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val categoryText = if (categoryName == "ALL") "Anggaran Bulanan" else "Kategori $categoryName"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("🚨 ANGGARAN MELEBIHI BATAS!")
            .setContentText("Total pengeluaran $categoryText $formattedExpense melebihi batas $formattedLimit")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Peringatan Kritis dari Financial Records: Total pengeluaran $categoryText Anda saat ini ($formattedExpense) telah melampaui batas anggaran sebesar $formattedLimit. Harap evaluasi pengeluaran Anda.")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 500, 250, 500))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_OVER, notification)

        // Play alert tone
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            toneGen.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 800)
        } catch (_: Exception) {}
    }
}

