package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.feedback.TelegramFeedbackManager
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun FeedbackDialog(
    userName: String,
    onDismiss: () -> Unit,
    onFeedbackSent: (String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("Saran & Masukan") }
    var rating by remember { mutableIntStateOf(5) }
    var messageText by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val categories = listOf("Saran & Masukan", "Laporan Bug", "Pertanyaan", "Apresiasi")
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = { if (!isSending) onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "💬",
                            fontSize = 20.sp
                        )
                        Column {
                            Text(
                                text = "UMPAN BALIK TELEGRAM",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = BentoElectricLime
                            )
                            Text(
                                text = "Kirim pesan langsung ke pengembang",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSending,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = MaterialTheme.colorScheme.onSurface)
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                // Rating Stars
                Text(
                    text = "Rating Pengalaman Anda:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    (1..5).forEach { star ->
                        Icon(
                            imageVector = if (star <= rating) Icons.Filled.Star else Icons.Outlined.Star,
                            contentDescription = "Star $star",
                            tint = if (star <= rating) NeoYellow else NeoGray,
                            modifier = Modifier
                                .size(32.dp)
                                .clickable { rating = star }
                        )
                    }
                }

                // Category Selection
                Text(
                    text = "Kategori Masukan:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(2).forEach { cat ->
                        val isSelected = selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BentoElectricLime,
                                selectedLabelColor = NeoBlack
                            )
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.drop(2).forEach { cat ->
                        val isSelected = selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BentoElectricLime,
                                selectedLabelColor = NeoBlack
                            )
                        )
                    }
                }

                // Message Text Field
                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it },
                    label = { Text("Pesan / Masukan Anda") },
                    placeholder = { Text("Tuliskan masukan atau kritik & saran Anda di sini...") },
                    minLines = 3,
                    maxLines = 5,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoElectricLime,
                        focusedLabelColor = BentoElectricLime
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                BrutalistButton(
                    onClick = {
                        if (isSending) return@BrutalistButton
                        if (messageText.isBlank()) {
                            errorMessage = "Silakan tuliskan pesan umpan balik terlebih dahulu."
                            return@BrutalistButton
                        }
                        isSending = true
                        errorMessage = null

                        scope.launch {
                            val result = TelegramFeedbackManager.sendFeedback(
                                userName = userName,
                                category = selectedCategory,
                                rating = rating,
                                message = messageText
                            )

                            isSending = false
                            if (result.isSuccess) {
                                onFeedbackSent("✓ Umpan balik berhasil terkirim ke Telegram Admin!")
                                onDismiss()
                            } else {
                                errorMessage = "Gagal mengirim: ${result.exceptionOrNull()?.message ?: "Koneksi bermasalah"}"
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = if (isSending) NeoGray else BentoElectricLime,
                    textColor = NeoBlack,
                    text = if (isSending) "MENGIRIM KE TELEGRAM..." else "🚀 KIRIM KE TELEGRAM BOT"
                )
            }
        }
    }
}
