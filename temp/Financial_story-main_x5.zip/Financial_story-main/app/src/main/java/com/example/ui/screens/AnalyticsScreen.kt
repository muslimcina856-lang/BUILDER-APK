package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryType
import com.example.data.model.TransactionType
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinancialUiState
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AnalyticsScreen(
    uiState: FinancialUiState,
    onExportCsv: () -> Unit,
    onExportPdf: () -> Unit,
    onSelectPrimaryCurrency: (String) -> Unit = {},
    onSelectSecondaryCurrency: (String) -> Unit = {},
    onRefreshRates: () -> Unit = {}
) {
    val expenses = remember(uiState.transactions) {
        uiState.transactions.filter { it.type == TransactionType.EXPENSE }
    }

    val totalIncome = remember(uiState.transactions) {
        uiState.transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    }
    val totalExpense = remember(expenses) {
        expenses.sumOf { it.amount }
    }

    // Daily Bar Chart entries
    val dailyEntries = remember(expenses) {
        val dateFormat = SimpleDateFormat("dd MMM", Locale("id", "ID"))
        val grouped = expenses.groupBy { dateFormat.format(Date(it.dateTimestamp)) }
        grouped.map { (dateStr, list) ->
            BarChartEntry(
                label = dateStr,
                amount = list.sumOf { it.amount },
                color = NeoPink
            )
        }.takeLast(7)
    }

    // Donut Chart Category breakdown
    val categoryEntries = remember(expenses) {
        val colors = listOf(NeoYellow, NeoLime, NeoPink, NeoCyan, NeoOrange, NeoPurple)
        val grouped = expenses.groupBy { it.category }
        grouped.entries.mapIndexed { index, (cat, list) ->
            DonutChartEntry(
                name = cat.label,
                amount = list.sumOf { it.amount },
                color = colors[index % colors.size]
            )
        }.sortedByDescending { it.amount }
    }

    val highestCategory = remember(categoryEntries) {
        categoryEntries.firstOrNull()
    }

    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "LAPORAN & GRAFIK VISUAL",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 22.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Pantau tren pengeluaran bulanan dengan grafik interaktif",
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Export Report Bar Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BrutalistButton(
                    onClick = onExportCsv,
                    backgroundColor = NeoYellow,
                    textColor = NeoBlack,
                    text = "📄 EKSPOR CSV",
                    modifier = Modifier.weight(1f)
                )

                BrutalistButton(
                    onClick = onExportPdf,
                    backgroundColor = NeoCyan,
                    textColor = NeoBlack,
                    text = "📊 LAPORAN PDF",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Financial Health Score Card
        item {
            FinancialHealthCard(uiState = uiState)
        }

        // Financial Simulator Card
        item {
            FinancialSimulatorCard()
        }

        // Multi-Currency Live Exchange Rates Card
        item {
            val totalBalance = uiState.accounts.sumOf { it.balance }
            MultiCurrencyExchangeCard(
                primaryCurrency = uiState.primaryCurrency,
                secondaryCurrency = uiState.secondaryCurrency,
                exchangeRates = uiState.exchangeRates,
                lastUpdatedText = uiState.exchangeRatesLastUpdated,
                isFetching = uiState.isFetchingExchangeRates,
                isLive = uiState.isExchangeRateLive,
                totalBalanceIdr = totalBalance,
                totalExpenseIdr = totalExpense,
                onSelectPrimaryCurrency = onSelectPrimaryCurrency,
                onSelectSecondaryCurrency = onSelectSecondaryCurrency,
                onRefreshRates = onRefreshRates
            )
        }

        // Highest Category Card
        item {
            BrutalistCard(
                backgroundColor = NeoPink,
                borderColor = NeoBlack
            ) {
                Text(
                    text = "KATEGORI PENGELUARAN TERBESAR",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                if (highestCategory != null) {
                    Text(
                        text = highestCategory.name.uppercase(),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = NeoYellow
                    )
                    Text(
                        text = "Total: ${idrFormat.format(highestCategory.amount)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                } else {
                    Text("Belum ada data pengeluaran.", color = Color.White)
                }
            }
        }

        // Main Interactive Spending Report Chart (Switchable between Pie & Bar)
        item {
            SpendingReportInteractiveCard(
                categoryEntries = categoryEntries,
                dailyEntries = dailyEntries
            )
        }

        // Detailed Donut Chart Category Breakdown
        item {
            BrutalistCard(
                backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                borderColor = MaterialTheme.colorScheme.outline
            ) {
                Text(
                    text = "PROPORSI KATEGORI PENGELUARAN (PIE / LINGKARAN)",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))
                InteractiveDonutChart(entries = categoryEntries)
            }
        }

        // Detailed Daily Bar Chart Trend
        item {
            BrutalistCard(
                backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                borderColor = MaterialTheme.colorScheme.outline
            ) {
                Text(
                    text = "TREN PENGELUARAN HARIAN (GRAFIK BATANG)",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                InteractiveBarChart(entries = dailyEntries)
            }
        }
    }
}
