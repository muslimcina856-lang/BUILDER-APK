package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Theme Accent Palette
val BentoElectricLime = Color(0xFFCCFF00)
val BentoHotPink = Color(0xFFFF0055)
val BentoZincDark = Color(0xFF09090D)
val BentoZincCard = Color(0xFF14141E)

// Neo-Brutalism High-Contrast Color Palette
val NeoYellow = Color(0xFFFFE600)
val NeoLime = Color(0xFFCCFF00)
val NeoPink = Color(0xFFFF0055)
val NeoCyan = Color(0xFF00F0FF)
val NeoOrange = Color(0xFFFF5500)
val NeoPurple = Color(0xFF9D00FF)

// Dark Theme Colors
val NeoDarkBackground = Color(0xFF0F0F14)
val NeoDarkSurface = Color(0xFF181822)
val NeoDarkCard = Color(0xFF232330)
val NeoDarkBorder = Color(0xFF3B3B4F)

// Light Theme Colors
val NeoLightBackground = Color(0xFFF6F3ED)
val NeoLightSurface = Color(0xFFFFFFFF)
val NeoLightCard = Color(0xFFFFFDE8)
val NeoLightBorder = Color(0xFF000000)

val NeoBlack = Color(0xFF000000)
val NeoWhite = Color(0xFFFFFFFF)
val NeoGray = Color(0xFF888899)
val NeoRedAlert = Color(0xFFFF2244)

