package com.example.ui.screens

import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.ExtractedNoteTransaction
import com.example.data.ai.SmartNoteParser
import com.example.data.model.NoteEntity
import com.example.data.model.TransactionType
import com.example.ui.components.BrutalistButton
import com.example.ui.components.BrutalistCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinancialUiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartNotesScreen(
    uiState: FinancialUiState,
    onAddNote: (title: String, content: String, categoryTag: String, isPinned: Boolean, isDraft: Boolean, isVoiceMemo: Boolean, audioDurationSeconds: Int) -> Unit,
    onUpdateNote: (note: NoteEntity) -> Unit,
    onDeleteNote: (note: NoteEntity) -> Unit,
    onTogglePinNote: (note: NoteEntity) -> Unit,
    onConvertNoteToTx: (note: NoteEntity, extractedItems: List<ExtractedNoteTransaction>, accountName: String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID")) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedTagFilter by remember { mutableStateOf("SEMUA") }

    // Quick Add Note State
    var newTitle by remember { mutableStateOf("") }
    var newContent by remember { mutableStateOf("") }
    var newTag by remember { mutableStateOf("Keuangan") }
    var newIsPinned by remember { mutableStateOf(false) }

    // Voice Recorder State
    var isRecordingVoice by remember { mutableStateOf(false) }
    var recordingTimerSeconds by remember { mutableStateOf(0) }

    // Audio Playback simulation state for voice cards (noteId -> isPlaying)
    var playingAudioNoteId by remember { mutableStateOf<Long?>(null) }

    var isAnalyzingAi by remember { mutableStateOf(false) }

    // Edit Note Dialog State
    var noteToEdit by remember { mutableStateOf<NoteEntity?>(null) }

    // Convert Note Modal State
    var noteToConvert by remember { mutableStateOf<NoteEntity?>(null) }
    var extractedItemsForConversion by remember { mutableStateOf<List<ExtractedNoteTransaction>>(emptyList()) }
    var selectedAccountForConversion by remember { mutableStateOf("") }

    val filterOptions = listOf("SEMUA", "📂 DRAF", "🎙️ MEMO SUARA", "📌 PINNED", "KEUANGAN", "BELANJA", "TAGIHAN", "IDE", "PRIBADI")
    val defaultAccount = uiState.accounts.firstOrNull()?.name ?: "Dompet Tunai"

    // Speech-To-Text Launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spokenTextList = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = spokenTextList?.firstOrNull() ?: ""
            if (spokenText.isNotBlank()) {
                if (newContent.isBlank()) {
                    newContent = spokenText
                } else {
                    newContent += " $spokenText"
                }
                if (newTitle.isBlank()) {
                    newTitle = "🎙️ Memo Suara: ${spokenText.take(20)}..."
                }
            }
        }
    }

    // Voice Recording Timer Coroutine
    LaunchedEffect(isRecordingVoice) {
        if (isRecordingVoice) {
            recordingTimerSeconds = 0
            while (isRecordingVoice) {
                delay(1000)
                recordingTimerSeconds++
            }
        }
    }

    // Filter Notes Logic
    val filteredNotes = remember(uiState.notes, searchQuery, selectedTagFilter) {
        uiState.notes.filter { note ->
            val matchesQuery = searchQuery.isBlank() ||
                    note.title.contains(searchQuery, ignoreCase = true) ||
                    note.content.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedTagFilter) {
                "SEMUA" -> true
                "📂 DRAF" -> note.isDraft
                "🎙️ MEMO SUARA" -> note.isVoiceMemo
                "📌 PINNED" -> note.isPinned
                else -> note.categoryTag.equals(selectedTagFilter, ignoreCase = true)
            }

            matchesQuery && matchesFilter
        }
    }

    val draftCount = remember(uiState.notes) { uiState.notes.count { it.isDraft } }
    val voiceCount = remember(uiState.notes) { uiState.notes.count { it.isVoiceMemo } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // --- Header Section ---
        item {
            BrutalistCard(
                backgroundColor = NeoPink,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "📝 CATATAN, SUARA & DRAF",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Text(
                                text = "Rekam memo suara, simpan draf & ekstrak otomatis ke transaksi!",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .background(BentoElectricLime, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${uiState.notes.size} Note",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = NeoBlack
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- Quick Note / Voice / Draft Creator Card ---
        item {
            BrutalistCard(
                backgroundColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.EditNote,
                                contentDescription = null,
                                tint = NeoCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "BUAT CATATAN / MEMO BARU",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Speech / Mic Recorder Button
                        Button(
                            onClick = {
                                if (isRecordingVoice) {
                                    isRecordingVoice = false
                                } else {
                                    try {
                                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan catatan keuangan atau belanjaan Anda...")
                                        }
                                        speechLauncher.launch(intent)
                                    } catch (e: Exception) {
                                        // Fallback voice simulation if no speech engine
                                        isRecordingVoice = true
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRecordingVoice) MaterialTheme.colorScheme.error else NeoYellow,
                                contentColor = NeoBlack
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.border(1.5.dp, NeoBlack, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                imageVector = if (isRecordingVoice) Icons.Default.Stop else Icons.Default.Mic,
                                contentDescription = "Voice Record",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isRecordingVoice) "STOP (${recordingTimerSeconds}s)" else "🎙️ REKAM SUARA",
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Voice Recording Banner Animation
                    AnimatedVisibility(visible = isRecordingVoice) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(8.dp))
                                .border(1.5.dp, MaterialTheme.colorScheme.error, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.GraphicEq, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    Column {
                                        Text(
                                            text = "Mendengarkan Suara Anda...",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onErrorContainer
                                        )
                                        Text(
                                            text = "Durasi: $recordingTimerSeconds detik",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onErrorContainer
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        isRecordingVoice = false
                                        val sampleVoice = "Beli token listrik 100rb, makan siang Nasi Padang 25rb, gajian freelance 3 juta"
                                        newContent = if (newContent.isBlank()) sampleVoice else "$newContent\n$sampleVoice"
                                        if (newTitle.isBlank()) newTitle = "🎙️ Memo Suara Harian"
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BentoElectricLime, contentColor = NeoBlack),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("GUNAKAN TEKS", fontSize = 10.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Judul Catatan (mis. Belanja Bulanan, Tagihan Kopi)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newContent,
                        onValueChange = { newContent = it },
                        label = { Text("Isi Catatan / Daftar (mis. Kopi 25rb, Token Listrik 100rb, Gajian 2.5jt)") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Tag options
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Kategori:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(listOf("Keuangan", "Belanja", "Tagihan", "Ide", "Pribadi")) { tag ->
                                val isSelected = newTag == tag
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { newTag = tag },
                                    label = { Text(tag, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NeoYellow,
                                        selectedLabelColor = NeoBlack
                                    )
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { newIsPinned = !newIsPinned }
                        ) {
                            Checkbox(
                                checked = newIsPinned,
                                onCheckedChange = { newIsPinned = it }
                            )
                            Text(
                                text = "Pin ke Atas",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Buttons Bar: AI Extract, Save Draft, Save Note
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Smart Extract AI Button
                            Button(
                                onClick = {
                                    if (newContent.isNotBlank()) {
                                        coroutineScope.launch {
                                            isAnalyzingAi = true
                                            val extracted = SmartNoteParser.parseTransactionsFromNoteText(newContent)
                                            isAnalyzingAi = false
                                            if (extracted.isNotEmpty()) {
                                                val draftNote = NoteEntity(
                                                    title = newTitle.ifBlank { "Catatan Baru" },
                                                    content = newContent,
                                                    categoryTag = newTag
                                                )
                                                noteToConvert = draftNote
                                                extractedItemsForConversion = extracted
                                                selectedAccountForConversion = defaultAccount
                                            }
                                        }
                                    }
                                },
                                enabled = newContent.isNotBlank() && !isAnalyzingAi,
                                colors = ButtonDefaults.buttonColors(containerColor = NeoCyan, contentColor = NeoBlack),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.border(1.5.dp, NeoBlack, RoundedCornerShape(8.dp))
                            ) {
                                if (isAnalyzingAi) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = NeoBlack, strokeWidth = 2.dp)
                                } else {
                                    Text("✨ AI EKSTRAK", fontWeight = FontWeight.Black, fontSize = 10.sp)
                                }
                            }

                            // Save Draft Button
                            Button(
                                onClick = {
                                    if (newContent.isNotBlank() || newTitle.isNotBlank()) {
                                        onAddNote(
                                            newTitle.trim(),
                                            newContent.trim(),
                                            newTag,
                                            newIsPinned,
                                            true, // isDraft = true
                                            false,
                                            0
                                        )
                                        newTitle = ""
                                        newContent = ""
                                        newIsPinned = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                            ) {
                                Text("📂 DRAF", fontWeight = FontWeight.Black, fontSize = 10.sp)
                            }

                            // Save Note Button
                            BrutalistButton(
                                onClick = {
                                    if (newContent.isNotBlank() || newTitle.isNotBlank()) {
                                        val isVoice = recordingTimerSeconds > 0
                                        onAddNote(
                                            newTitle.trim(),
                                            newContent.trim(),
                                            newTag,
                                            newIsPinned,
                                            false, // isDraft = false
                                            isVoice,
                                            recordingTimerSeconds
                                        )
                                        newTitle = ""
                                        newContent = ""
                                        newIsPinned = false
                                        recordingTimerSeconds = 0
                                    }
                                },
                                backgroundColor = BentoElectricLime,
                                textColor = NeoBlack,
                                text = "💾 SIMPAN"
                            )
                        }
                    }
                }
            }
        }

        // --- Search & Filter Chips Row ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Cari catatan, memo suara, atau draf...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(filterOptions) { filterTag ->
                        val isSelected = selectedTagFilter == filterTag
                        val labelText = when (filterTag) {
                            "📂 DRAF" -> "📂 Draf ($draftCount)"
                            "🎙️ MEMO SUARA" -> "🎙️ Suara ($voiceCount)"
                            else -> filterTag
                        }

                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedTagFilter = filterTag },
                            label = { Text(labelText, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeoYellow,
                                selectedLabelColor = NeoBlack,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                    }
                }
            }
        }

        // --- Notes List ---
        if (filteredNotes.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.NoteAlt,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "Tidak ada catatan cocok dengan pencarian" else "Belum ada catatan. Buat catatan atau rekam suara di atas!",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredNotes, key = { it.id }) { note ->
                BrutalistCard(
                    backgroundColor = if (note.isPinned) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Badges Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (note.isPinned) {
                                    Box(
                                        modifier = Modifier
                                            .background(NeoPink, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("📌 PINNED", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.White)
                                    }
                                }

                                if (note.isDraft) {
                                    Box(
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(4.dp))
                                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("📂 DRAF", fontSize = 9.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                    }
                                }

                                if (note.isVoiceMemo) {
                                    Box(
                                        modifier = Modifier
                                            .background(NeoYellow, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("🎙️ MEMO SUARA", fontSize = 9.sp, fontWeight = FontWeight.Black, color = NeoBlack)
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .background(NeoCyan, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("#${note.categoryTag}", fontSize = 9.sp, fontWeight = FontWeight.Black, color = NeoBlack)
                                }

                                if (note.isConvertedToTx) {
                                    Box(
                                        modifier = Modifier
                                            .background(BentoElectricLime, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("✓ TERKONVERSI", fontSize = 9.sp, fontWeight = FontWeight.Black, color = NeoBlack)
                                    }
                                }
                            }

                            Text(
                                text = dateFormat.format(Date(note.updatedAtTimestamp)),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (note.title.isNotBlank()) {
                            Text(
                                text = note.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Voice Memo Player Bar if voice memo
                        if (note.isVoiceMemo) {
                            val isPlayingThis = playingAudioNoteId == note.id
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        IconButton(
                                            onClick = {
                                                playingAudioNoteId = if (isPlayingThis) null else note.id
                                            },
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(NeoYellow, CircleShape)
                                        ) {
                                            Icon(
                                                imageVector = if (isPlayingThis) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = "Play voice memo",
                                                tint = NeoBlack,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }

                                        Column {
                                            Text(
                                                text = if (isPlayingThis) "▶ Memutar rekaman suara..." else "🎵 Rekaman Audio Voice Memo",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "Transkripsi AI otomatis dari percakapan",
                                                fontSize = 9.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Icon(
                                        imageVector = Icons.Default.GraphicEq,
                                        contentDescription = null,
                                        tint = if (isPlayingThis) NeoPink else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = note.content,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Action buttons row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left action: Pin toggle
                            IconButton(onClick = { onTogglePinNote(note) }, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Default.PushPin,
                                    contentDescription = "Pin Note",
                                    tint = if (note.isPinned) NeoPink else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                )
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Publish Draft button if it's a draft
                                if (note.isDraft) {
                                    Button(
                                        onClick = {
                                            onUpdateNote(note.copy(isDraft = false, updatedAtTimestamp = System.currentTimeMillis()))
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = BentoElectricLime, contentColor = NeoBlack),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text("🚀 PUBLIKASI", fontSize = 10.sp, fontWeight = FontWeight.Black)
                                    }
                                }

                                // Smart Extract & Convert button
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isAnalyzingAi = true
                                            val extracted = SmartNoteParser.parseTransactionsFromNoteText(note.content)
                                            isAnalyzingAi = false
                                            if (extracted.isNotEmpty()) {
                                                noteToConvert = note
                                                extractedItemsForConversion = extracted
                                                selectedAccountForConversion = defaultAccount
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeoCyan, contentColor = NeoBlack),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("✨ KONVERSI TRANSAKSI", fontSize = 10.sp, fontWeight = FontWeight.Black)
                                }

                                // Edit button
                                IconButton(onClick = { noteToEdit = note }, modifier = Modifier.size(32.dp)) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Note",
                                        tint = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                // Delete button
                                IconButton(onClick = { onDeleteNote(note) }, modifier = Modifier.size(32.dp)) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete Note",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- Edit Note Dialog ---
    if (noteToEdit != null) {
        val currentEdit = noteToEdit!!
        var editTitle by remember { mutableStateOf(currentEdit.title) }
        var editContent by remember { mutableStateOf(currentEdit.content) }
        var editTag by remember { mutableStateOf(currentEdit.categoryTag) }
        var editIsDraft by remember { mutableStateOf(currentEdit.isDraft) }

        AlertDialog(
            onDismissRequest = { noteToEdit = null },
            confirmButton = {
                BrutalistButton(
                    onClick = {
                        onUpdateNote(
                            currentEdit.copy(
                                title = editTitle.trim(),
                                content = editContent.trim(),
                                categoryTag = editTag,
                                isDraft = editIsDraft,
                                updatedAtTimestamp = System.currentTimeMillis()
                            )
                        )
                        noteToEdit = null
                    },
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    text = "SIMPAN PERUBAHAN"
                )
            },
            dismissButton = {
                TextButton(onClick = { noteToEdit = null }) {
                    Text("BATAL", fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Text(
                    text = "EDIT CATATAN / DRAF",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Judul Catatan") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editContent,
                        onValueChange = { editContent = it },
                        label = { Text("Isi Catatan") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { editIsDraft = !editIsDraft }
                    ) {
                        Checkbox(checked = editIsDraft, onCheckedChange = { editIsDraft = it })
                        Text("Simpan Sebagai Draf", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // --- Convert Note to Transaction Modal ---
    if (noteToConvert != null && extractedItemsForConversion.isNotEmpty()) {
        val currentNote = noteToConvert!!

        AlertDialog(
            onDismissRequest = { noteToConvert = null },
            confirmButton = {
                BrutalistButton(
                    onClick = {
                        val accName = selectedAccountForConversion.ifBlank { defaultAccount }
                        onConvertNoteToTx(currentNote, extractedItemsForConversion, accName)
                        noteToConvert = null
                    },
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    text = "⚡ SIMPAN KE TRANSAKSI"
                )
            },
            dismissButton = {
                TextButton(onClick = { noteToConvert = null }) {
                    Text("BATAL", fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = NeoCyan)
                    Text(
                        text = "HASIL EKSTRAKSI AI",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "AI berhasil mendeteksi ${extractedItemsForConversion.size} transaksi dari catatan '${currentNote.title}':",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    extractedItemsForConversion.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = item.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${item.category.label} • ${if (item.type == TransactionType.EXPENSE) "Pengeluaran" else "Pemasukan"}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Text(
                                text = idrFormat.format(item.amount),
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = if (item.type == TransactionType.EXPENSE) MaterialTheme.colorScheme.error else BentoElectricLime
                            )
                        }
                    }

                    Text(
                        text = "Pilih Akun / Sumber Dana:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(uiState.accounts) { acc ->
                            val isSel = selectedAccountForConversion == acc.name
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedAccountForConversion = acc.name },
                                label = { Text(acc.name, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeoYellow,
                                    selectedLabelColor = NeoBlack
                                )
                            )
                        }
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
