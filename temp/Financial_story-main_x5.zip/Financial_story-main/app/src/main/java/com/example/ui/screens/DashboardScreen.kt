package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountType
import com.example.data.model.CategoryType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinancialUiState
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    uiState: FinancialUiState,
    onNavigateToAddTransaction: () -> Unit,
    onNavigateToAccounts: () -> Unit,
    onNavigateToAnalytics: () -> Unit,
    onNavigateToNotes: () -> Unit = {},
    onDeleteTransaction: (TransactionEntity) -> Unit,
    onTriggerSync: () -> Unit,
    onUpdateUserName: (String) -> Unit = {},
    onSendFeedbackSuccess: (String) -> Unit = {},
    onQuickAddExpense: (title: String, amount: Double, category: CategoryType) -> Unit = { _, _, _ -> }
) {
    var showCreatorModal by remember { mutableStateOf(false) }
    var showEditNameModal by remember { mutableStateOf(false) }
    var showFeedbackModal by remember { mutableStateOf(false) }
    var showCalculatorModal by remember { mutableStateOf(false) }

    val userInitial = remember(uiState.userName) {
        uiState.userName.trim().take(1).uppercase().ifEmpty { "U" }
    }

    val totalIncome = remember(uiState.transactions) {
        uiState.transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    }
    val totalExpense = remember(uiState.transactions) {
        uiState.transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    }
    val totalBalance = remember(uiState.accounts) {
        uiState.accounts.sumOf { it.balance }
    }

    val overallBudget = remember(uiState.budgets) {
        uiState.budgets.find { it.categoryName == "ALL" }?.monthlyLimitAmount ?: 5000000.0
    }
    val budgetProgress = remember(totalExpense, overallBudget) {
        (totalExpense / overallBudget.coerceAtLeast(1.0)).coerceIn(0.0, 1.0).toFloat()
    }

    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Bento Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Profile Avatar with Electric Lime ring (Click to edit username)
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                            .border(2.5.dp, BentoElectricLime, CircleShape)
                            .clickable { showEditNameModal = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userInitial,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Column(
                        modifier = Modifier.clickable { showEditNameModal = true }
                    ) {
                        Text(
                            text = "HALO, ${uiState.userName.uppercase()}",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = BentoElectricLime,
                            letterSpacing = 1.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Financial Records",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "Ubah Nama",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Action Buttons: Calculator & Creator Credit Badge Button
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(NeoCyan)
                            .border(2.dp, NeoBlack, RoundedCornerShape(12.dp))
                            .clickable { showCalculatorModal = true }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Calculate, contentDescription = "Kalkulator", tint = NeoBlack, modifier = Modifier.size(16.dp))
                            Text(
                                text = "KALKULATOR",
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp,
                                color = NeoBlack
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(BentoElectricLime)
                            .border(2.dp, NeoBlack, RoundedCornerShape(12.dp))
                            .clickable { showCreatorModal = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.Code, contentDescription = null, tint = NeoBlack, modifier = Modifier.size(14.dp))
                            Text(
                                text = "momonpxl",
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                color = NeoBlack
                            )
                        }
                    }
                }
            }
        }

        // Hero Bento Card: Total Balance (Electric Lime Accent)
        item {
            BrutalistCard(
                backgroundColor = BentoElectricLime,
                borderColor = NeoBlack,
                shadowOffset = 5.dp,
                cornerRadius = 22.dp,
                borderWidth = 3.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL SALDO SAYA",
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        color = NeoBlack,
                        letterSpacing = 0.5.sp
                    )
                    Box(
                        modifier = Modifier
                            .background(NeoBlack, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "E2E ENCRYPTED",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 9.sp,
                            color = BentoElectricLime
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                AnimatedAmountText(
                    amount = totalBalance,
                    prefix = "Rp ",
                    color = NeoBlack,
                    fontSize = 32
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${uiState.accounts.size} Aset Terhubung • Real-time Sync",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = NeoBlack.copy(alpha = 0.8f)
                    )

                    BrutalistButton(
                        onClick = onNavigateToAddTransaction,
                        backgroundColor = NeoBlack,
                        textColor = BentoElectricLime,
                        borderColor = NeoBlack,
                        cornerRadius = 12.dp,
                        shadowOffset = 2.dp,
                        text = "+ TAMBAH"
                    )
                }
            }
        }

        // Bento Grid 2-Column Row (Budget Alert + Income/Expense Stats)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Left Column Bento Card: Budget Limit Alert
                BrutalistCard(
                    modifier = Modifier.weight(1f),
                    backgroundColor = BentoHotPink,
                    borderColor = NeoBlack,
                    cornerRadius = 20.dp,
                    shadowOffset = 3.dp
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = NeoWhite,
                        modifier = Modifier.size(28.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "ANGGARAN BULANAN",
                        fontWeight = FontWeight.Black,
                        fontSize = 10.sp,
                        color = NeoWhite.copy(alpha = 0.9f)
                    )

                    Text(
                        text = "${(budgetProgress * 100).toInt()}% TERPAKAI",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = NeoWhite
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(budgetProgress)
                                .fillMaxHeight()
                                .background(BentoElectricLime, RoundedCornerShape(4.dp))
                        )
                    }
                }

                // Right Column Bento Cards Stack (Income & Expense Stats)
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Income Mini Bento Tile
                    BrutalistCard(
                        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                        borderColor = MaterialTheme.colorScheme.outline,
                        cornerRadius = 16.dp,
                        shadowOffset = 2.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(BentoElectricLime, RoundedCornerShape(8.dp))
                                    .border(1.dp, NeoBlack, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = NeoBlack, modifier = Modifier.size(18.dp))
                            }
                            Column {
                                Text("PEMASUKAN", fontWeight = FontWeight.Black, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = idrFormat.format(totalIncome).take(11),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // Expense Mini Bento Tile
                    BrutalistCard(
                        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                        borderColor = MaterialTheme.colorScheme.outline,
                        cornerRadius = 16.dp,
                        shadowOffset = 2.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(BentoHotPink, RoundedCornerShape(8.dp))
                                    .border(1.dp, NeoBlack, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = NeoWhite, modifier = Modifier.size(18.dp))
                            }
                            Column {
                                Text("PENGELUARAN", fontWeight = FontWeight.Black, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = idrFormat.format(totalExpense).take(11),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Tagihan Rutin & Subskripsi Card
        item {
            RecurringBillsCard(
                onPayBill = { title, amount, category ->
                    onQuickAddExpense(title, amount, category)
                }
            )
        }

        // Smart Catatan AI Banner
        item {
            BrutalistCard(
                backgroundColor = NeoPink,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToNotes() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("📝 SMART CATATAN AI", fontWeight = FontWeight.Black, fontSize = 13.sp, color = Color.White)
                            Box(
                                modifier = Modifier
                                    .background(BentoElectricLime, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("${uiState.notes.size} Note", fontSize = 9.sp, fontWeight = FontWeight.Black, color = NeoBlack)
                            }
                        }
                        Text(
                            text = "Catat memo belanja & tagihan. AI siap mengekstrak jadi transaksi!",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(NeoYellow, RoundedCornerShape(8.dp))
                            .border(1.5.dp, NeoBlack, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("BUKA", fontWeight = FontWeight.Black, fontSize = 11.sp, color = NeoBlack)
                    }
                }
            }
        }

        // Target Tabungan Impian Card
        item {
            SavingsGoalsCard(
                onAddGoalDeposit = { goalTitle, amount ->
                    onQuickAddExpense(goalTitle, amount, CategoryType.INVESTMENT)
                }
            )
        }

        // Creator Credit Bento Card (Dibuat oleh momonpxl)
        item {
            CreatorCreditCard(
                onOpenFeedbackDialog = { showFeedbackModal = true }
            )
        }

        // Connected Accounts Horizontal Bento Row
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AKUN & E-WALLET SINKRON",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    TextButton(onClick = onNavigateToAccounts) {
                        Text("Kelola", fontWeight = FontWeight.Bold, color = BentoElectricLime)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(uiState.accounts) { acc ->
                        Box(
                            modifier = Modifier
                                .width(150.dp)
                                .background(
                                    when (acc.type) {
                                        AccountType.BANK -> NeoCyan
                                        AccountType.EWALLET -> BentoElectricLime
                                        AccountType.CASH -> NeoYellow
                                    },
                                    RoundedCornerShape(16.dp)
                                )
                                .border(2.dp, NeoBlack, RoundedCornerShape(16.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = acc.name.uppercase(),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = NeoBlack
                                )
                                Text(
                                    text = acc.accountNumber,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = NeoBlack
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = idrFormat.format(acc.balance).take(12),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    color = NeoBlack
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sync Trigger Bento Button
        item {
            BrutalistButton(
                onClick = onTriggerSync,
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = NeoCyan,
                textColor = NeoBlack,
                cornerRadius = 16.dp,
                text = if (uiState.isAutoSyncing) "MENYSINKRONKAN BANK..." else "⚡ TARIK SINKRONISASI BANK OTOMATIS"
            )
        }

        // Recent Transactions Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TRANSAKSI TERAKHIR",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                TextButton(onClick = onNavigateToAnalytics) {
                    Text("Grafik Analisis", fontWeight = FontWeight.Bold, color = BentoElectricLime)
                }
            }
        }

        // Recent Transactions List
        if (uiState.transactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Belum ada transaksi. Tekan tombol + untuk menambah.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            items(uiState.transactions.take(8), key = { it.id }) { tx ->
                TransactionItemRow(transaction = tx, onDelete = { onDeleteTransaction(tx) })
            }
        }
    }

    // Creator Modal Dialog
    if (showCreatorModal) {
        AlertDialog(
            onDismissRequest = { showCreatorModal = false },
            confirmButton = {
                BrutalistButton(
                    onClick = { showCreatorModal = false },
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    text = "TUTUP"
                )
            },
            title = {
                Text(
                    text = "INFO KREATOR APLIKASI",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Aplikasi Catatan Keuangan dengan tema Bento Grid ini dibuat dengan penuh perhatian oleh momonpxl.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    CreatorCreditCard(
                        onOpenFeedbackDialog = {
                            showCreatorModal = false
                            showFeedbackModal = true
                        }
                    )
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // Edit Username Dialog
    if (showEditNameModal) {
        EditUsernameDialog(
            currentName = uiState.userName,
            onDismiss = { showEditNameModal = false },
            onSaveName = { newName ->
                onUpdateUserName(newName)
                showEditNameModal = false
            }
        )
    }

    // Telegram Feedback Dialog
    if (showFeedbackModal) {
        FeedbackDialog(
            userName = uiState.userName,
            onDismiss = { showFeedbackModal = false },
            onFeedbackSent = { successMsg ->
                onSendFeedbackSuccess(successMsg)
            }
        )
    }

    // Quick Calculator Dialog
    if (showCalculatorModal) {
        QuickCalculatorDialog(
            onDismiss = { showCalculatorModal = false }
        )
    }
}
