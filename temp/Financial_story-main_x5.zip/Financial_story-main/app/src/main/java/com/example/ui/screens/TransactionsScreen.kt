package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.GeminiCategorySuggester
import com.example.data.model.CategoryType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinancialUiState
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionsScreen(
    uiState: FinancialUiState,
    onAddTransaction: (String, Double, TransactionType, CategoryType, String, String) -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTypeFilter by remember { mutableStateOf<TransactionType?>(null) }
    var selectedCategoryFilter by remember { mutableStateOf<CategoryType?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showCalcModal by remember { mutableStateOf(false) }

    val filteredTransactions = remember(uiState.transactions, searchQuery, selectedTypeFilter, selectedCategoryFilter) {
        uiState.transactions.filter { tx ->
            val matchesSearch = tx.title.contains(searchQuery, ignoreCase = true) ||
                    tx.accountName.contains(searchQuery, ignoreCase = true) ||
                    tx.notes.contains(searchQuery, ignoreCase = true)
            val matchesType = selectedTypeFilter == null || tx.type == selectedTypeFilter
            val matchesCategory = selectedCategoryFilter == null || tx.category == selectedCategoryFilter
            matchesSearch && matchesType && matchesCategory
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Title Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RIWAYAT TRANSAKSI",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 22.sp,
                color = MaterialTheme.colorScheme.onBackground
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { showCalcModal = true },
                    modifier = Modifier
                        .size(36.dp)
                        .background(NeoCyan, RoundedCornerShape(8.dp))
                        .border(2.dp, NeoBlack, RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Calculate, contentDescription = "Kalkulator", tint = NeoBlack)
                }

                BrutalistButton(
                    onClick = { showAddDialog = true },
                    backgroundColor = NeoLime,
                    textColor = NeoBlack,
                    text = "+ TAMBAH"
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Cari judul, akun, catatan...", fontWeight = FontWeight.Medium) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Filter Pills: All, Expense, Income
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BrutalistBadge(
                text = "SEMUA",
                isSelected = selectedTypeFilter == null,
                backgroundColor = NeoYellow,
                onClick = { selectedTypeFilter = null }
            )
            BrutalistBadge(
                text = "PENGELUARAN",
                isSelected = selectedTypeFilter == TransactionType.EXPENSE,
                backgroundColor = NeoPink,
                textColor = Color.White,
                onClick = { selectedTypeFilter = TransactionType.EXPENSE }
            )
            BrutalistBadge(
                text = "PEMASUKAN",
                isSelected = selectedTypeFilter == TransactionType.INCOME,
                backgroundColor = NeoLime,
                onClick = { selectedTypeFilter = TransactionType.INCOME }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Category Filter Row
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                BrutalistBadge(
                    text = "SEMUA KATEGORI",
                    isSelected = selectedCategoryFilter == null,
                    backgroundColor = NeoCyan,
                    onClick = { selectedCategoryFilter = null }
                )
            }
            items(CategoryType.values()) { cat ->
                BrutalistBadge(
                    text = cat.label,
                    isSelected = selectedCategoryFilter == cat,
                    backgroundColor = NeoYellow,
                    onClick = { selectedCategoryFilter = cat }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Transaction List
        if (filteredTransactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Tidak ada transaksi yang cocok.",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 100.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredTransactions, key = { it.id }) { tx ->
                    TransactionItemRow(transaction = tx, onDelete = { onDeleteTransaction(tx) })
                }
            }
        }
    }

    // Add Transaction Modal Dialog
    if (showAddDialog) {
        AddTransactionModalDialog(
            accountsList = uiState.accounts.map { it.name },
            onDismiss = { showAddDialog = false },
            onSubmit = { title, amount, type, category, account, notes ->
                onAddTransaction(title, amount, type, category, account, notes)
                showAddDialog = false
            }
        )
    }

    if (showCalcModal) {
        QuickCalculatorDialog(
            onDismiss = { showCalcModal = false }
        )
    }
}

@Composable
fun AddTransactionModalDialog(
    accountsList: List<String>,
    onDismiss: () -> Unit,
    onSubmit: (String, Double, TransactionType, CategoryType, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var selectedCategory by remember { mutableStateOf(CategoryType.FOOD) }
    var selectedAccount by remember { mutableStateOf(accountsList.firstOrNull() ?: "Bank BCA") }
    var notes by remember { mutableStateOf("") }
    var showInlineCalc by remember { mutableStateOf(false) }

    var isAiAnalyzing by remember { mutableStateOf(false) }
    var aiSuggestedCategory by remember { mutableStateOf<CategoryType?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val triggerGeminiCategoryAnalysis: (String) -> Unit = { query ->
        if (query.isNotBlank()) {
            isAiAnalyzing = true
            coroutineScope.launch {
                val suggested = GeminiCategorySuggester.suggestCategory(query)
                selectedCategory = suggested
                aiSuggestedCategory = suggested
                isAiAnalyzing = false
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {},
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "CATAT TRANSAKSI BARU",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Type selector
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BrutalistBadge(
                        text = "PENGELUARAN",
                        isSelected = selectedType == TransactionType.EXPENSE,
                        backgroundColor = NeoPink,
                        textColor = Color.White,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedType = TransactionType.EXPENSE }
                    )
                    BrutalistBadge(
                        text = "PEMASUKAN",
                        isSelected = selectedType == TransactionType.INCOME,
                        backgroundColor = NeoLime,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedType = TransactionType.INCOME }
                    )
                }

                // Judul
                OutlinedTextField(
                    value = title,
                    onValueChange = { newTitle ->
                        title = newTitle
                        if (newTitle.length > 3) {
                            triggerGeminiCategoryAnalysis(newTitle)
                        }
                    },
                    label = { Text("Judul Transaksi") },
                    placeholder = { Text("mis. Makan Siang, Bensin, Gaji") },
                    trailingIcon = {
                        IconButton(
                            onClick = { triggerGeminiCategoryAnalysis(title) },
                            enabled = !isAiAnalyzing && title.isNotBlank()
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Analisis Kategori AI Gemini",
                                tint = BentoElectricLime
                            )
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (isAiAnalyzing) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NeoCyan.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = NeoBlack)
                        Text("✨ Gemini AI sedang menganalisis kategori...", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    }
                } else if (aiSuggestedCategory != null) {
                    Text(
                        text = "✨ Disarankan oleh AI Gemini: ${aiSuggestedCategory?.label}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BentoElectricLime,
                        modifier = Modifier.padding(start = 2.dp)
                    )
                }

                // Jumlah (IDR)
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                    label = { Text("Jumlah (Rp)") },
                    placeholder = { Text("mis. 50000") },
                    trailingIcon = {
                        IconButton(onClick = { showInlineCalc = true }) {
                            Icon(Icons.Default.Calculate, contentDescription = "Buka Kalkulator", tint = BentoElectricLime)
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category Dropdown/Selector
                Text("Kategori:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(CategoryType.values()) { cat ->
                        BrutalistBadge(
                            text = cat.label,
                            isSelected = selectedCategory == cat,
                            backgroundColor = NeoYellow,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }

                // Account Selector
                Text("Sumber Akun:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(accountsList) { acc ->
                        BrutalistBadge(
                            text = acc,
                            isSelected = selectedAccount == acc,
                            backgroundColor = NeoCyan,
                            onClick = { selectedAccount = acc }
                        )
                    }
                }

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Tambahan (Opsional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("BATAL", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    BrutalistButton(
                        onClick = {
                            val amountVal = amountText.toDoubleOrNull() ?: 0.0
                            if (title.isNotBlank() && amountVal > 0) {
                                onSubmit(title, amountVal, selectedType, selectedCategory, selectedAccount, notes)
                            }
                        },
                        backgroundColor = NeoLime,
                        textColor = NeoBlack,
                        text = "SIMPAN"
                    )
                }
            }
        },
        modifier = Modifier
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
            .border(3.dp, NeoBlack, RoundedCornerShape(12.dp))
    )

    if (showInlineCalc) {
        QuickCalculatorDialog(
            onDismiss = { showInlineCalc = false },
            onApplyAmount = { calcAmount ->
                amountText = if (calcAmount % 1.0 == 0.0) {
                    calcAmount.toLong().toString()
                } else {
                    calcAmount.toInt().toString()
                }
                showInlineCalc = false
            }
        )
    }
}
