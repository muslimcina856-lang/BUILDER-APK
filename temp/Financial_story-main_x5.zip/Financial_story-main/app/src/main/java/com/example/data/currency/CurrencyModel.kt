package com.example.data.currency

import java.text.NumberFormat
import java.util.Locale

data class CurrencyInfo(
    val code: String,
    val name: String,
    val symbol: String,
    val flagEmoji: String
)

object CurrencyData {
    val SUPPORTED_CURRENCIES = listOf(
        CurrencyInfo("IDR", "Rupiah Indonesia", "Rp", "🇮🇩"),
        CurrencyInfo("USD", "US Dollar", "$", "🇺🇸"),
        CurrencyInfo("EUR", "Euro", "€", "🇪🇺"),
        CurrencyInfo("JPY", "Japanese Yen", "¥", "🇯🇵"),
        CurrencyInfo("SGD", "Singapore Dollar", "S$", "🇸🇬"),
        CurrencyInfo("MYR", "Malaysian Ringgit", "RM", "🇲🇾"),
        CurrencyInfo("GBP", "British Pound", "£", "🇬🇧"),
        CurrencyInfo("AUD", "Australian Dollar", "A$", "🇦🇺"),
        CurrencyInfo("CNY", "Chinese Yuan", "¥", "🇨🇳"),
        CurrencyInfo("KRW", "South Korean Won", "₩", "🇰🇷"),
        CurrencyInfo("SAR", "Saudi Riyal", "SR", "🇸🇦")
    )

    fun getCurrencyInfo(code: String): CurrencyInfo {
        return SUPPORTED_CURRENCIES.find { it.code.equals(code, ignoreCase = true) }
            ?: CurrencyInfo(code.uppercase(), code.uppercase(), "$code ", "🌐")
    }

    /**
     * Formats an amount with appropriate symbol and decimals based on currency
     */
    fun formatAmount(amount: Double, currencyCode: String): String {
        val info = getCurrencyInfo(currencyCode)
        return when (currencyCode.uppercase()) {
            "IDR" -> {
                val nf = NumberFormat.getNumberInstance(Locale("id", "ID"))
                "${info.symbol} ${nf.format(amount.toLong())}"
            }
            "JPY", "KRW" -> {
                val nf = NumberFormat.getNumberInstance(Locale.US)
                "${info.symbol}${nf.format(amount.toLong())}"
            }
            else -> {
                val nf = NumberFormat.getNumberInstance(Locale.US).apply {
                    maximumFractionDigits = 2
                    minimumFractionDigits = 2
                }
                "${info.symbol}${nf.format(amount)}"
            }
        }
    }

    /**
     * Converts an amount from `fromCurrency` to `toCurrency` using USD-based exchange rate map.
     */
    fun convert(
        amount: Double,
        fromCurrency: String,
        toCurrency: String,
        usdRates: Map<String, Double>
    ): Double {
        if (fromCurrency.equals(toCurrency, ignoreCase = true)) return amount
        
        val fromRate = usdRates[fromCurrency.uppercase()] ?: return amount
        val toRate = usdRates[toCurrency.uppercase()] ?: return amount

        if (fromRate == 0.0) return amount

        // Amount in USD = amount / fromRate
        val amountInUsd = amount / fromRate
        // Amount in target currency = amountInUsd * toRate
        return amountInUsd * toRate
    }
}
