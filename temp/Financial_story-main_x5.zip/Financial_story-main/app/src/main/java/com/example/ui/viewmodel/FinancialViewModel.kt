package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.FinancialDatabase
import com.example.data.exporter.ReportExporter
import com.example.data.model.*
import com.example.data.repository.FinancialRepository
import com.example.data.security.EncryptionManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

import com.example.data.currency.*

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

data class FinancialUiState(
    val userName: String = "momonpxl",
    val transactions: List<TransactionEntity> = emptyList(),
    val accounts: List<AccountEntity> = emptyList(),
    val budgets: List<BudgetLimitEntity> = emptyList(),
    val notes: List<NoteEntity> = emptyList(),
    val isDarkMode: Boolean = false,
    val isAutoSyncing: Boolean = false,
    val isE2eEncrypted: Boolean = true,
    val e2ePassphrase: String = "FINBRUTAL_SECRET_KEY_2026",
    val isRealtimeDeviceSynced: Boolean = true,
    val syncDeviceCode: String = "DEV-8821-X9",
    val popSuccessMessage: String? = null,
    val budgetExceededAlert: String? = null,
    val primaryCurrency: String = "IDR",
    val secondaryCurrency: String = "USD",
    val exchangeRates: Map<String, Double> = mapOf(
        "USD" to 1.0, "IDR" to 16250.0, "EUR" to 0.92, "JPY" to 155.0,
        "SGD" to 1.35, "MYR" to 4.68, "GBP" to 0.78, "AUD" to 1.52,
        "CNY" to 7.25, "KRW" to 1380.0, "SAR" to 3.75
    ),
    val exchangeRatesLastUpdated: String = "Belum Diperbarui",
    val isFetchingExchangeRates: Boolean = false,
    val isExchangeRateLive: Boolean = false
)

class FinancialViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FinancialRepository
    private val prefs = application.getSharedPreferences("financial_user_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(FinancialUiState())
    val uiState: StateFlow<FinancialUiState> = _uiState.asStateFlow()

    init {
        val savedName = prefs.getString("user_name", "momonpxl") ?: "momonpxl"
        val savedPrimary = prefs.getString("primary_currency", "IDR") ?: "IDR"
        val savedSecondary = prefs.getString("secondary_currency", "USD") ?: "USD"
        _uiState.update { 
            it.copy(
                userName = savedName,
                primaryCurrency = savedPrimary,
                secondaryCurrency = savedSecondary
            ) 
        }

        refreshExchangeRates()

        val database = FinancialDatabase.getDatabase(application)
        repository = FinancialRepository(
            transactionDao = database.transactionDao(),
            accountDao = database.accountDao(),
            budgetDao = database.budgetDao(),
            noteDao = database.noteDao()
        )

        viewModelScope.launch {
            repository.clearAllData()
        }

        // Observe flows
        viewModelScope.launch {
            combine(
                repository.allTransactions,
                repository.allAccounts,
                repository.allBudgets,
                repository.allNotes
            ) { txs, accs, bdgs, nts ->
                Quadruple(txs, accs, bdgs, nts)
            }.collect { (txs, accs, bdgs, nts) ->
                _uiState.update { currentState ->
                    currentState.copy(
                        transactions = txs,
                        accounts = accs,
                        budgets = bdgs,
                        notes = nts
                    )
                }
                checkBudgetExceededAlert(txs, bdgs)
            }
        }
    }

    private fun checkBudgetExceededAlert(txs: List<TransactionEntity>, bdgs: List<BudgetLimitEntity>) {
        val totalExpense = txs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        val overallBudget = bdgs.find { it.categoryName == "ALL" }?.monthlyLimitAmount ?: 5000000.0

        if (totalExpense >= overallBudget && overallBudget > 0) {
            val alertMsg = "Total pengeluaran Rp ${totalExpense.toInt()} telah melebihi batas anggaran Rp ${overallBudget.toInt()}!"
            _uiState.update { it.copy(budgetExceededAlert = alertMsg) }
        } else if (totalExpense >= overallBudget * 0.8 && overallBudget > 0) {
            val alertMsg = "Peringatan: Pengeluaran Rp ${totalExpense.toInt()} telah mencapai 80% dari batas anggaran Rp ${overallBudget.toInt()}."
            _uiState.update { it.copy(budgetExceededAlert = alertMsg) }
        }
    }

    fun toggleDarkMode() {
        _uiState.update { it.copy(isDarkMode = !it.isDarkMode) }
    }

    fun updateUserName(newName: String) {
        val trimmed = newName.trim().ifBlank { "momonpxl" }
        prefs.edit().putString("user_name", trimmed).apply()
        _uiState.update {
            it.copy(
                userName = trimmed,
                popSuccessMessage = "Nama pengguna berhasil diubah menjadi '$trimmed'!"
            )
        }
    }

    fun showCustomSuccessMessage(msg: String) {
        _uiState.update { it.copy(popSuccessMessage = msg) }
    }

    fun dismissSuccessPop() {
        _uiState.update { it.copy(popSuccessMessage = null) }
    }

    fun dismissBudgetAlert() {
        _uiState.update { it.copy(budgetExceededAlert = null) }
    }

    fun addTransaction(
        title: String,
        amount: Double,
        type: TransactionType,
        category: CategoryType,
        accountName: String,
        notes: String
    ) {
        viewModelScope.launch {
            val newTransaction = TransactionEntity(
                title = title,
                amount = amount,
                type = type,
                category = category,
                accountName = accountName,
                notes = notes,
                dateTimestamp = System.currentTimeMillis()
            )
            repository.insertTransaction(newTransaction)

            // Update widgets
            com.example.widget.QuickExpenseWidgetProvider.updateAllWidgets(getApplication())

            // Check budget notification alerts
            if (type == TransactionType.EXPENSE) {
                val currentTxs = _uiState.value.transactions + newTransaction
                val currentBudgets = _uiState.value.budgets
                
                // Overall budget
                val totalExpense = currentTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
                val overallBudget = currentBudgets.find { it.categoryName == "ALL" }?.monthlyLimitAmount ?: 5000000.0

                com.example.notification.BudgetNotificationManager.checkAndTriggerBudgetNotification(
                    getApplication(),
                    totalExpense,
                    overallBudget,
                    "ALL"
                )

                // Category-specific budget
                val categoryExpense = currentTxs.filter { it.type == TransactionType.EXPENSE && it.category == category }.sumOf { it.amount }
                val categoryBudget = currentBudgets.find { it.categoryName == category.name }?.monthlyLimitAmount ?: 0.0

                if (categoryBudget > 0) {
                    com.example.notification.BudgetNotificationManager.checkAndTriggerBudgetNotification(
                        getApplication(),
                        categoryExpense,
                        categoryBudget,
                        category.label
                    )
                }
            }

            _uiState.update {
                it.copy(popSuccessMessage = "Transaksi '$title' sebesar Rp ${amount.toInt()} berhasil disimpan!")
            }
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            _uiState.update {
                it.copy(popSuccessMessage = "Transaksi '${transaction.title}' berhasil dihapus.")
            }
        }
    }

    fun deleteAccount(account: AccountEntity) {
        viewModelScope.launch {
            repository.deleteAccount(account)
            _uiState.update {
                it.copy(popSuccessMessage = "Akun '${account.name}' berhasil dihapus.")
            }
        }
    }

    fun addAccount(name: String, accountNumber: String, type: AccountType, initialBalance: Double) {
        viewModelScope.launch {
            val id = "acc_" + System.currentTimeMillis()
            val newAcc = AccountEntity(
                accountId = id,
                name = name,
                accountNumber = accountNumber,
                type = type,
                balance = initialBalance,
                iconColorHex = "#00AED6"
            )
            repository.addOrUpdateAccount(newAcc)
            _uiState.update {
                it.copy(popSuccessMessage = "Akun '$name' berhasil ditambahkan.")
            }
        }
    }

    fun deleteBudget(categoryName: String) {
        viewModelScope.launch {
            repository.deleteBudget(categoryName)
            _uiState.update {
                it.copy(popSuccessMessage = "Batas Anggaran '$categoryName' berhasil dihapus.")
            }
        }
    }

    fun triggerAutoSync() {
        viewModelScope.launch {
            _uiState.update { it.copy(isAutoSyncing = true) }
            kotlinx.coroutines.delay(1200) // Realistic network sync animation
            val syncedCount = repository.triggerBankAutoSync()
            _uiState.update {
                it.copy(
                    isAutoSyncing = false,
                    popSuccessMessage = "Sinkronisasi otomatis selesai! $syncedCount transaksi baru diimpor dari Bank & E-Wallet."
                )
            }
        }
    }

    fun updateBudgetLimit(categoryName: String, amount: Double) {
        viewModelScope.launch {
            repository.setBudgetLimit(categoryName, amount)
            _uiState.update {
                it.copy(popSuccessMessage = "Batas anggaran $categoryName berhasil diperbarui ke Rp ${amount.toInt()}.")
            }
        }
    }

    fun refreshExchangeRates() {
        viewModelScope.launch {
            _uiState.update { it.copy(isFetchingExchangeRates = true) }
            val rateResult = CurrencyExchangeRepository.fetchLiveExchangeRates()
            _uiState.update {
                it.copy(
                    isFetchingExchangeRates = false,
                    exchangeRates = rateResult.rates,
                    exchangeRatesLastUpdated = rateResult.lastUpdatedText,
                    isExchangeRateLive = rateResult.isLive
                )
            }
        }
    }

    fun setPrimaryCurrency(code: String) {
        prefs.edit().putString("primary_currency", code).apply()
        _uiState.update {
            it.copy(
                primaryCurrency = code,
                popSuccessMessage = "Mata uang utama diubah ke $code"
            )
        }
    }

    fun setSecondaryCurrency(code: String) {
        prefs.edit().putString("secondary_currency", code).apply()
        _uiState.update {
            it.copy(
                secondaryCurrency = code,
                popSuccessMessage = "Mata uang sekunder diubah ke $code"
            )
        }
    }

    fun exportCsv() {
        viewModelScope.launch {
            val transactions = repository.getAllTransactionsSync().ifEmpty { _uiState.value.transactions }
            val uri = ReportExporter.exportCsvViaMediaStore(getApplication(), transactions)
            if (uri != null) {
                _uiState.update {
                    it.copy(popSuccessMessage = "File CSV (${transactions.size} transaksi) berhasil diekspor via MediaStore ke folder Download!")
                }
            } else {
                ReportExporter.shareCsvFile(getApplication(), transactions)
            }
        }
    }

    fun exportPdfReport() {
        ReportExporter.shareTextReport(getApplication(), _uiState.value.transactions)
    }

    fun clearAllDataAndReset() {
        viewModelScope.launch {
            repository.clearAllData()
            _uiState.update {
                it.copy(
                    popSuccessMessage = "Seluruh data transaksi, akun, dan anggaran telah dikosongkan! Siap untuk diluncurkan."
                )
            }
        }
    }

    // --- Smart Note Methods ---
    fun addNote(
        title: String,
        content: String,
        categoryTag: String = "Keuangan",
        isPinned: Boolean = false,
        isDraft: Boolean = false,
        isVoiceMemo: Boolean = false,
        audioDurationSeconds: Int = 0
    ) {
        viewModelScope.launch {
            val defaultTitle = if (isVoiceMemo) "🎙️ Memo Suara" else if (isDraft) "📝 Draft Catatan" else "Catatan Baru"
            val note = NoteEntity(
                title = title.ifBlank { defaultTitle },
                content = content,
                categoryTag = categoryTag,
                isPinned = isPinned,
                isDraft = isDraft,
                isVoiceMemo = isVoiceMemo,
                audioDurationSeconds = audioDurationSeconds,
                createdAtTimestamp = System.currentTimeMillis(),
                updatedAtTimestamp = System.currentTimeMillis()
            )
            repository.insertNote(note)
            val msg = if (isDraft) "Draft disimpan!" else if (isVoiceMemo) "Memo suara disimpan!" else "Catatan '${note.title}' berhasil disimpan!"
            _uiState.update {
                it.copy(popSuccessMessage = msg)
            }
        }
    }

    fun updateNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.updateNote(note.copy(updatedAtTimestamp = System.currentTimeMillis()))
            _uiState.update {
                it.copy(popSuccessMessage = "Catatan '${note.title}' berhasil diperbarui.")
            }
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.deleteNote(note)
            _uiState.update {
                it.copy(popSuccessMessage = "Catatan '${note.title}' berhasil dihapus.")
            }
        }
    }

    fun togglePinNote(note: NoteEntity) {
        viewModelScope.launch {
            val updated = note.copy(isPinned = !note.isPinned, updatedAtTimestamp = System.currentTimeMillis())
            repository.updateNote(updated)
            val msg = if (updated.isPinned) "Catatan dipin ke atas!" else "Pin catatan dilepas."
            _uiState.update { it.copy(popSuccessMessage = msg) }
        }
    }

    fun convertNoteToTransactions(note: NoteEntity, extractedItems: List<com.example.data.ai.ExtractedNoteTransaction>, accountName: String) {
        viewModelScope.launch {
            extractedItems.forEach { item ->
                val newTx = TransactionEntity(
                    title = item.title,
                    amount = item.amount,
                    type = item.type,
                    category = item.category,
                    accountName = accountName,
                    notes = "Dikonversi dari catatan '${note.title}'",
                    dateTimestamp = System.currentTimeMillis()
                )
                repository.insertTransaction(newTx)
            }
            repository.updateNote(note.copy(isConvertedToTx = true, updatedAtTimestamp = System.currentTimeMillis()))
            com.example.widget.QuickExpenseWidgetProvider.updateAllWidgets(getApplication())
            _uiState.update {
                it.copy(popSuccessMessage = "Berhasil mengonversi ${extractedItems.size} item dari catatan menjadi transaksi!")
            }
        }
    }
}
