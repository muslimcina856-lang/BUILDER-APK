package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val categoryTag: String = "Keuangan", // e.g. Keuangan, Belanja, Tagihan, Ide, Pribadi
    val isPinned: Boolean = false,
    val isDraft: Boolean = false,
    val isVoiceMemo: Boolean = false,
    val audioDurationSeconds: Int = 0,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val updatedAtTimestamp: Long = System.currentTimeMillis(),
    val extractedAmount: Double? = null,
    val isConvertedToTx: Boolean = false
)
