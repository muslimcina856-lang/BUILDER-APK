package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AccountType {
    BANK,
    EWALLET,
    CASH
}

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey
    val accountId: String, // e.g. "bca_01", "gopay_01"
    val name: String, // e.g. "Bank BCA", "Mandiri Utama", "GoPay", "OVO", "Dana", "Dompet Tunai"
    val accountNumber: String, // e.g. "**** 8821"
    val type: AccountType,
    val balance: Double,
    val isAutoSyncEnabled: Boolean = true,
    val lastSyncedTimestamp: Long = System.currentTimeMillis(),
    val iconColorHex: String = "#FFE600"
)
