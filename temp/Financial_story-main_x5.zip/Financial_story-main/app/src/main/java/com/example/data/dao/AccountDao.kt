package com.example.data.dao

import androidx.room.*
import com.example.data.model.AccountEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts")
    fun getAllAccounts(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts")
    suspend fun getAllAccountsSync(): List<AccountEntity>

    @Query("SELECT * FROM accounts WHERE accountId = :id")
    suspend fun getAccountById(id: String): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAccount(account: AccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(accounts: List<AccountEntity>)

    @Query("UPDATE accounts SET balance = balance + :amount, lastSyncedTimestamp = :timestamp WHERE name = :accountName")
    suspend fun updateBalance(accountName: String, amount: Double, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM accounts")
    suspend fun deleteAll()

    @Delete
    suspend fun deleteAccount(account: AccountEntity)

    @Query("DELETE FROM accounts WHERE accountId = :id")
    suspend fun deleteAccountById(id: String)
}
