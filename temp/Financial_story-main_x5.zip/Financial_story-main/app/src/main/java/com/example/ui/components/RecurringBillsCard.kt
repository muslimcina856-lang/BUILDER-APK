package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CategoryType
import com.example.data.model.TransactionType
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

data class RecurringBillItem(
    val id: String,
    val title: String,
    val amount: Double,
    val category: CategoryType,
    val dueDateText: String,
    var isPaidThisMonth: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecurringBillsCard(
    onPayBill: (title: String, amount: Double, category: CategoryType) -> Unit
) {
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    var bills by remember {
        mutableStateOf(emptyList<RecurringBillItem>())
    }

    var showAddBillModal by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newAmountText by remember { mutableStateOf("") }
    var newDueDateText by remember { mutableStateOf("") }

    val totalMonthlyBills = remember(bills) { bills.sumOf { it.amount } }

    BrutalistCard(
        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
        borderColor = MaterialTheme.colorScheme.outline
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Receipt, contentDescription = null, tint = BentoElectricLime)
                Text(
                    text = "TAGIHAN RUTIN & SUBSKRIPSI",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            BrutalistButton(
                onClick = { showAddBillModal = true },
                backgroundColor = BentoElectricLime,
                textColor = NeoBlack,
                text = "+ TAMBAH"
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (bills.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Belum ada tagihan rutin / subskripsi. Klik + TAMBAH untuk mendaftarkan tagihan baru.",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = "Total Tagihan: ${idrFormat.format(totalMonthlyBills)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = BentoElectricLime
                )
            }

            bills.forEach { bill ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                        .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = bill.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${idrFormat.format(bill.amount)} • ${bill.dueDateText}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (bill.isPaidThisMonth) {
                            Box(
                                modifier = Modifier
                                    .background(BentoElectricLime, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("✓ LUNAS", fontWeight = FontWeight.Black, fontSize = 10.sp, color = NeoBlack)
                            }
                        } else {
                            BrutalistButton(
                                onClick = {
                                    onPayBill(bill.title, bill.amount, bill.category)
                                    bills = bills.map { if (it.id == bill.id) it.copy(isPaidThisMonth = true) else it }
                                },
                                backgroundColor = NeoPink,
                                textColor = Color.White,
                                text = "BAYAR"
                            )
                        }

                        IconButton(
                            onClick = {
                                bills = bills.filter { it.id != bill.id }
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Hapus Tagihan",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddBillModal) {
        AlertDialog(
            onDismissRequest = { showAddBillModal = false },
            confirmButton = {
                BrutalistButton(
                    onClick = {
                        val amount = newAmountText.toDoubleOrNull() ?: 0.0
                        if (newTitle.isNotBlank() && amount > 0) {
                            val dueStr = if (newDueDateText.isBlank()) "Jatuh Tempo: Tiap Bulan" else "Jatuh Tempo: $newDueDateText"
                            val newBill = RecurringBillItem(
                                id = System.currentTimeMillis().toString(),
                                title = newTitle.trim(),
                                amount = amount,
                                category = CategoryType.BILLS,
                                dueDateText = dueStr
                            )
                            bills = bills + newBill
                            newTitle = ""
                            newAmountText = ""
                            newDueDateText = ""
                            showAddBillModal = false
                        }
                    },
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    text = "SIMPAN TAGIHAN"
                )
            },
            dismissButton = {
                TextButton(onClick = { showAddBillModal = false }) {
                    Text("BATAL", fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Text(
                    text = "TAMBAH TAGIHAN / SUBSKRIPSI BARU",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Nama Tagihan (mis. Listrik PLN, Spotify)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newAmountText,
                        onValueChange = { newAmountText = it.filter { c -> c.isDigit() } },
                        label = { Text("Nominal Tagihan Rp") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newDueDateText,
                        onValueChange = { newDueDateText = it },
                        label = { Text("Tanggal Jatuh Tempo (mis. Tgl 20)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
