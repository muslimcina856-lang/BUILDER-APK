package com.example.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.lifecycleScope
import com.example.data.ai.GeminiCategorySuggester
import com.example.data.db.FinancialDatabase
import com.example.data.model.CategoryType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.notification.BudgetNotificationManager
import com.example.ui.components.BrutalistButton
import com.example.ui.theme.*
import com.example.widget.QuickExpenseWidgetProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class QuickExpenseActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            FinBrutalTheme {
                QuickExpenseDialogContent(
                    onDismiss = { finish() },
                    onSaveExpense = { title, amount, categoryLabel ->
                        saveExpenseAndCheckBudget(title, amount, categoryLabel)
                    }
                )
            }
        }
    }

    private fun saveExpenseAndCheckBudget(title: String, amount: Double, categoryLabel: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = FinancialDatabase.getDatabase(applicationContext)
            val txDao = db.transactionDao()
            val budgetDao = db.budgetDao()

            val selectedCategory = CategoryType.entries.find { it.label.equals(categoryLabel, ignoreCase = true) }
                ?: CategoryType.FOOD

            val newTx = TransactionEntity(
                title = title.ifBlank { "Pengeluaran Cepat" },
                amount = amount,
                type = TransactionType.EXPENSE,
                category = selectedCategory,
                accountName = "CASH / TUNAI",
                notes = "Dicatat via Quick Expense Widget Financial Records",
                dateTimestamp = System.currentTimeMillis()
            )

            txDao.insertTransaction(newTx)

            // Check budget limit
            val allTxs = txDao.getAllTransactionsSync()
            val totalExpense = allTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
            val overallBudget = budgetDao.getAllBudgetsSync().find { it.categoryName == "ALL" }?.monthlyLimitAmount ?: 5000000.0

            if (totalExpense >= overallBudget && overallBudget > 0) {
                BudgetNotificationManager.triggerOverBudgetSoundAndNotification(applicationContext, totalExpense, overallBudget)
            }

            // Refresh Widget
            QuickExpenseWidgetProvider.updateAllWidgets(applicationContext)

            withContext(Dispatchers.Main) {
                Toast.makeText(
                    applicationContext,
                    "✓ Pengeluaran Rp ${amount.toInt()} berhasil dicatat!",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }
}

@Composable
fun QuickExpenseDialogContent(
    onDismiss: () -> Unit,
    onSaveExpense: (title: String, amount: Double, category: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(CategoryType.FOOD.label) }
    var isAiAnalyzing by remember { mutableStateOf(false) }
    var aiSuggestedCategory by remember { mutableStateOf<CategoryType?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val categories = remember { CategoryType.entries.map { it.label } }

    val triggerGeminiCategoryAnalysis: (String) -> Unit = { query ->
        if (query.isNotBlank()) {
            isAiAnalyzing = true
            coroutineScope.launch {
                val suggested = GeminiCategorySuggester.suggestCategory(query)
                selectedCategory = suggested.label
                aiSuggestedCategory = suggested
                isAiAnalyzing = false
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NeoDarkSurface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "⚡ QUICK EXPENSE",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = BentoElectricLime
                    )

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = NeoWhite)
                    }
                }

                Text(
                    text = "Catat pengeluaran secara cepat untuk aplikasi Financial records",
                    fontSize = 12.sp,
                    color = NeoGray
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { newTitle ->
                        title = newTitle
                        if (newTitle.length > 3) {
                            triggerGeminiCategoryAnalysis(newTitle)
                        }
                    },
                    label = { Text("Nama Pengeluaran", color = NeoWhite) },
                    placeholder = { Text("mis. Makan siang, Bensin, dll.", color = NeoGray) },
                    trailingIcon = {
                        IconButton(
                            onClick = { triggerGeminiCategoryAnalysis(title) },
                            enabled = !isAiAnalyzing && title.isNotBlank()
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Gemini Auto-Kategori",
                                tint = BentoElectricLime
                            )
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoElectricLime,
                        unfocusedBorderColor = NeoGray,
                        focusedTextColor = NeoWhite,
                        unfocusedTextColor = NeoWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (isAiAnalyzing) {
                    Text(
                        text = "✨ Gemini AI menganalisis kategori...",
                        fontSize = 11.sp,
                        color = BentoElectricLime
                    )
                } else if (aiSuggestedCategory != null) {
                    Text(
                        text = "✨ Kategori Gemini: ${aiSuggestedCategory?.label}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoElectricLime
                    )
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { char -> char.isDigit() } },
                    label = { Text("Jumlah (Rp)", color = NeoWhite) },
                    placeholder = { Text("15000", color = NeoGray) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BentoElectricLime,
                        unfocusedBorderColor = NeoGray,
                        focusedTextColor = NeoWhite,
                        unfocusedTextColor = NeoWhite
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Kategori:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = NeoWhite
                )

                // Category Selector Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(4).forEach { cat ->
                        val isSelected = selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BentoElectricLime,
                                selectedLabelColor = NeoBlack,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = NeoWhite
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                BrutalistButton(
                    onClick = {
                        val amountVal = amountText.toDoubleOrNull() ?: 0.0
                        if (amountVal > 0) {
                            onSaveExpense(title, amountVal, selectedCategory)
                        } else {
                            // Show error
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    text = "SIMPAN PENGELUARAN"
                )
            }
        }
    }
}
