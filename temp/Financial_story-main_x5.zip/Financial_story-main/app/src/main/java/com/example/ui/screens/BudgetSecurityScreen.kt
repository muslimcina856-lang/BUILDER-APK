package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinancialUiState
import java.text.NumberFormat
import java.util.Locale

@Composable
fun BudgetSecurityScreen(
    uiState: FinancialUiState,
    onUpdateBudget: (String, Double) -> Unit,
    onToggleDarkMode: () -> Unit,
    onExportCsv: () -> Unit,
    onExportPdf: () -> Unit,
    onUpdateUserName: (String) -> Unit = {},
    onSendFeedbackSuccess: (String) -> Unit = {},
    onSelectPrimaryCurrency: (String) -> Unit = {},
    onSelectSecondaryCurrency: (String) -> Unit = {},
    onRefreshRates: () -> Unit = {},
    onClearAllData: () -> Unit = {},
    onDeleteBudget: (String) -> Unit = {}
) {
    var budgetInput by remember { mutableStateOf("") }
    var showEditNameModal by remember { mutableStateOf(false) }
    var showFeedbackModal by remember { mutableStateOf(false) }

    val currentBudget = remember(uiState.budgets) {
        uiState.budgets.find { it.categoryName == "ALL" }?.monthlyLimitAmount ?: 5000000.0
    }

    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "ANGGARAN, KEAMANAN & PENGATURAN",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Custom User Name Settings Card
        item {
            BrutalistCard(
                backgroundColor = BentoElectricLime,
                borderColor = NeoBlack,
                shadowOffset = 4.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = NeoBlack, modifier = Modifier.size(24.dp))
                        Column {
                            Text(
                                text = "NAMA PENGGUNA SAYA",
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp,
                                color = NeoBlack.copy(alpha = 0.7f)
                            )
                            Text(
                                text = uiState.userName,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = NeoBlack
                            )
                        }
                    }

                    BrutalistButton(
                        onClick = { showEditNameModal = true },
                        backgroundColor = NeoBlack,
                        textColor = BentoElectricLime,
                        text = "✏️ UBAH"
                    )
                }
            }
        }

        // Dark Mode Switcher Card
        item {
            BrutalistCard(
                backgroundColor = if (uiState.isDarkMode) NeoDarkCard else NeoLightCard,
                borderColor = MaterialTheme.colorScheme.outline
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "MODE GELAP (DARK MODE)",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (uiState.isDarkMode) "Aktif (Kenyamanan Mata Malam Hari)" else "Non-Aktif (Mode Terang Kontras)",
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    BrutalistButton(
                        onClick = onToggleDarkMode,
                        backgroundColor = if (uiState.isDarkMode) NeoYellow else NeoDarkSurface,
                        textColor = if (uiState.isDarkMode) NeoBlack else NeoWhite,
                        text = if (uiState.isDarkMode) "☀️ LIGHT" else "🌙 DARK"
                    )
                }
            }
        }

        // Budget Limit Settings & Notification Card
        item {
            val context = androidx.compose.ui.platform.LocalContext.current

            BrutalistCard(
                backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                borderColor = MaterialTheme.colorScheme.outline
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = BentoElectricLime)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BATAS ANGGARAN & SYSTEM NOTIFIKASI",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Batas Anggaran Bulanan Saat Ini: ${idrFormat.format(currentBudget)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = "• Alert 80%: Peringatan otomatis saat pengeluaran mendekati batas.\n• Alert 100%: Peringatan kritis saat pengeluaran melebihi batas anggaran.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                )

                OutlinedTextField(
                    value = budgetInput,
                    onValueChange = { budgetInput = it.filter { c -> c.isDigit() } },
                    label = { Text("Set Batas Anggaran Baru (Rp)") },
                    placeholder = { Text("mis. 7500000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BrutalistButton(
                        onClick = {
                            val amount = budgetInput.toDoubleOrNull()
                            if (amount != null && amount > 0) {
                                onUpdateBudget("ALL", amount)
                                budgetInput = ""
                            }
                        },
                        backgroundColor = NeoLime,
                        textColor = NeoBlack,
                        text = "SIMPAN ANGGARAN",
                        modifier = Modifier.weight(1f)
                    )

                    BrutalistButton(
                        onClick = {
                            val currentTxsExpense = uiState.transactions.filter { it.type == com.example.data.model.TransactionType.EXPENSE }.sumOf { it.amount }
                            com.example.notification.BudgetNotificationManager.checkAndTriggerBudgetNotification(
                                context,
                                currentExpense = if (currentTxsExpense > 0) currentTxsExpense else currentBudget * 0.85,
                                limitAmount = currentBudget,
                                categoryName = "ALL"
                            )
                        },
                        backgroundColor = NeoYellow,
                        textColor = NeoBlack,
                        text = "🔔 UJI NOTIFIKASI",
                        modifier = Modifier.weight(1f)
                    )
                }

                if (uiState.budgets.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "DAFTAR ANGGARAN TERPASANG (${uiState.budgets.size})",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    uiState.budgets.forEach { b ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Kategori: ${b.categoryName} • ${idrFormat.format(b.monthlyLimitAmount)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            IconButton(
                                onClick = { onDeleteBudget(b.categoryName) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Hapus Anggaran",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }

        // End-to-End Encryption (E2EE) Card
        item {
            BrutalistCard(
                backgroundColor = NeoCyan,
                borderColor = NeoBlack
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = NeoBlack)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ENKRIPSI END-TO-END (E2EE)",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = NeoBlack
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Data disimpan menggunakan enkripsi AES-256 GCM pada penyimpanan lokal storage dan disinkronkan secara aman antar perangkat.",
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    color = NeoBlack
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Passphrase Key: ${uiState.e2ePassphrase.take(16)}...",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = NeoBlack
                )
            }
        }

        // Multi-Device Realtime Sync Card
        item {
            BrutalistCard(
                backgroundColor = NeoYellow,
                borderColor = NeoBlack
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Devices, contentDescription = null, tint = NeoBlack)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SINKRONISASI ANTAK PERANGKAT REAL-TIME",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = NeoBlack
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Status: Aktif • Kode Perangkat: ${uiState.syncDeviceCode}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = NeoBlack
                )
            }
        }

        // Multi-Currency Settings & Live Exchange Rates Card
        item {
            val totalBalance = uiState.accounts.sumOf { it.balance }
            val totalExpense = uiState.transactions
                .filter { it.type == com.example.data.model.TransactionType.EXPENSE }
                .sumOf { it.amount }

            MultiCurrencyExchangeCard(
                primaryCurrency = uiState.primaryCurrency,
                secondaryCurrency = uiState.secondaryCurrency,
                exchangeRates = uiState.exchangeRates,
                lastUpdatedText = uiState.exchangeRatesLastUpdated,
                isFetching = uiState.isFetchingExchangeRates,
                isLive = uiState.isExchangeRateLive,
                totalBalanceIdr = totalBalance,
                totalExpenseIdr = totalExpense,
                onSelectPrimaryCurrency = onSelectPrimaryCurrency,
                onSelectSecondaryCurrency = onSelectSecondaryCurrency,
                onRefreshRates = onRefreshRates
            )
        }

        // Export Data CSV & PDF Card
        item {
            BrutalistCard(
                backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                borderColor = MaterialTheme.colorScheme.outline
            ) {
                Text(
                    text = "EKSPOR LAPORAN & DATA STORAGE",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BrutalistButton(
                        onClick = onExportCsv,
                        backgroundColor = NeoYellow,
                        textColor = NeoBlack,
                        text = "EKSPOR CSV",
                        modifier = Modifier.weight(1f)
                    )

                    BrutalistButton(
                        onClick = onExportPdf,
                        backgroundColor = NeoLime,
                        textColor = NeoBlack,
                        text = "EKSPOR PDF",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                BrutalistButton(
                    onClick = onClearAllData,
                    backgroundColor = NeoRedAlert,
                    textColor = NeoWhite,
                    text = "🗑️ KOSONGKAN & RESET SEMUA DATA",
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Creator Credit Card (Dibuat oleh momonpxl)
        item {
            CreatorCreditCard(
                onOpenFeedbackDialog = { showFeedbackModal = true }
            )
        }
    }

    if (showEditNameModal) {
        EditUsernameDialog(
            currentName = uiState.userName,
            onDismiss = { showEditNameModal = false },
            onSaveName = { newName ->
                onUpdateUserName(newName)
                showEditNameModal = false
            }
        )
    }

    if (showFeedbackModal) {
        FeedbackDialog(
            userName = uiState.userName,
            onDismiss = { showFeedbackModal = false },
            onFeedbackSent = { successMsg ->
                onSendFeedbackSuccess(successMsg)
            }
        )
    }
}
