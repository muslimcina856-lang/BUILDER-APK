package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionType
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinancialUiState
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.pow

@Composable
fun FinancialHealthCard(uiState: FinancialUiState) {
    val totalIncome = remember(uiState.transactions) {
        uiState.transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    }
    val totalExpense = remember(uiState.transactions) {
        uiState.transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    }
    val overallBudget = remember(uiState.budgets) {
        uiState.budgets.find { it.categoryName == "ALL" }?.monthlyLimitAmount ?: 5000000.0
    }

    val savingRatio = if (totalIncome > 0) ((totalIncome - totalExpense) / totalIncome * 100).coerceIn(0.0, 100.0) else 0.0
    val budgetAdherence = if (overallBudget > 0) ((overallBudget - totalExpense) / overallBudget * 100).coerceIn(0.0, 100.0) else 50.0

    // Score calculation (0-100)
    val healthScore = remember(savingRatio, budgetAdherence, totalIncome, totalExpense) {
        var score = 50.0
        if (totalIncome > 0) {
            score += (savingRatio * 0.3)
        }
        score += (budgetAdherence * 0.2)
        score.toInt().coerceIn(10, 100)
    }

    val (statusLabel, statusColor, statusDesc) = when {
        healthScore >= 80 -> Triple("SANGAT SEHAT 🌟", BentoElectricLime, "Kondisi keuangan Anda sangat prima! Rasio tabungan & anggaran terjaga dengan baik.")
        healthScore >= 60 -> Triple("CUKUP SEHAT 👍", NeoCyan, "Keuangan cukup stabil. Pertahankan kontrol pengeluaran harian Anda.")
        healthScore >= 40 -> Triple("WASPADA ⚠️", NeoYellow, "Pengeluaran mendekati pemasukan. Pertimbangkan untuk memotong pos tidak mendesak.")
        else -> Triple("KRITIS 🚨", NeoPink, "Pengeluaran melebihi batas aman! Evaluasi ulang anggaran bulanan Anda segera.")
    }

    BrutalistCard(
        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
        borderColor = MaterialTheme.colorScheme.outline
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = BentoElectricLime)
                Text(
                    text = "SKOR KESEHATAN KEUANGAN",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Box(
                modifier = Modifier
                    .background(statusColor, RoundedCornerShape(8.dp))
                    .border(2.dp, NeoBlack, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "$healthScore / 100",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = NeoBlack
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = statusLabel,
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = statusColor
        )

        Text(
            text = statusDesc,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Progress breakdown
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Rasio Tabungan:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
            Text("${savingRatio.toInt()}%", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = BentoElectricLime)
        }

        LinearProgressIndicator(
            progress = { (savingRatio / 100).toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .border(1.dp, NeoBlack, RoundedCornerShape(3.dp)),
            color = BentoElectricLime,
            trackColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
fun FinancialSimulatorCard() {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Cicilan, 1: Investasi

    // Loan State
    var loanAmountText by remember { mutableStateOf("10000000") }
    var interestRateText by remember { mutableStateOf("10") }
    var durationMonthsText by remember { mutableStateOf("12") }

    // Investment State
    var monthlyTargetText by remember { mutableStateOf("1000000") }
    var returnRateText by remember { mutableStateOf("8") }
    var investYearsText by remember { mutableStateOf("3") }

    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    BrutalistCard(
        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
        borderColor = MaterialTheme.colorScheme.outline
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.Calculate, contentDescription = null, tint = BentoElectricLime)
            Text(
                text = "SIMULATOR & KALKULATOR KEUANGAN",
                fontWeight = FontWeight.Black,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                label = { Text("📱 Simulasi Cicilan", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BentoElectricLime,
                    selectedLabelColor = NeoBlack
                )
            )

            FilterChip(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                label = { Text("📈 Simulasi Investasi", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = BentoElectricLime,
                    selectedLabelColor = NeoBlack
                )
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (selectedTab == 0) {
            // Cicilan Mode
            OutlinedTextField(
                value = loanAmountText,
                onValueChange = { loanAmountText = it.filter { char -> char.isDigit() } },
                label = { Text("Jumlah Pinjaman / Harga Barang (Rp)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = interestRateText,
                    onValueChange = { interestRateText = it.filter { char -> char.isDigit() || char == '.' } },
                    label = { Text("Bunga %/Thn") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = durationMonthsText,
                    onValueChange = { durationMonthsText = it.filter { char -> char.isDigit() } },
                    label = { Text("Tenor (Bulan)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            val p = loanAmountText.toDoubleOrNull() ?: 0.0
            val r = (interestRateText.toDoubleOrNull() ?: 0.0) / 100 / 12
            val n = durationMonthsText.toIntOrNull() ?: 12

            val monthlyInstallment = if (r > 0 && n > 0 && p > 0) {
                (p * r * (1 + r).pow(n)) / ((1 + r).pow(n) - 1)
            } else if (n > 0 && p > 0) {
                p / n
            } else 0.0

            val totalPayment = monthlyInstallment * n

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BentoElectricLime, RoundedCornerShape(8.dp))
                    .border(2.dp, NeoBlack, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text("ESTIMASI CICILAN BULANAN:", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = NeoBlack)
                    Text(idrFormat.format(monthlyInstallment), fontWeight = FontWeight.Black, fontSize = 20.sp, color = NeoBlack)
                    Text("Total Pengembalian: ${idrFormat.format(totalPayment)} ($n Bulan)", fontSize = 11.sp, color = NeoBlack.copy(alpha = 0.8f))
                }
            }
        } else {
            // Investasi Mode
            OutlinedTextField(
                value = monthlyTargetText,
                onValueChange = { monthlyTargetText = it.filter { char -> char.isDigit() } },
                label = { Text("Investasi Rutin Bulanan (Rp)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = returnRateText,
                    onValueChange = { returnRateText = it.filter { char -> char.isDigit() || char == '.' } },
                    label = { Text("Estimasi Return %/Thn") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = investYearsText,
                    onValueChange = { investYearsText = it.filter { char -> char.isDigit() } },
                    label = { Text("Jangka Waktu (Tahun)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            val p = monthlyTargetText.toDoubleOrNull() ?: 0.0
            val r = (returnRateText.toDoubleOrNull() ?: 0.0) / 100 / 12
            val y = investYearsText.toIntOrNull() ?: 3
            val n = y * 12

            var futureValue = 0.0
            if (r > 0 && n > 0 && p > 0) {
                futureValue = p * (((1 + r).pow(n) - 1) / r) * (1 + r)
            } else if (n > 0 && p > 0) {
                futureValue = p * n
            }

            val totalCapital = p * n

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NeoCyan, RoundedCornerShape(8.dp))
                    .border(2.dp, NeoBlack, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text("ESTIMASI HASIL INVESTASI ($y TAHUN):", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = NeoBlack)
                    Text(idrFormat.format(futureValue), fontWeight = FontWeight.Black, fontSize = 20.sp, color = NeoBlack)
                    Text("Modal Terkumpul: ${idrFormat.format(totalCapital)} | Cuan: ${idrFormat.format((futureValue - totalCapital).coerceAtLeast(0.0))}", fontSize = 11.sp, color = NeoBlack.copy(alpha = 0.8f))
                }
            }
        }
    }
}
