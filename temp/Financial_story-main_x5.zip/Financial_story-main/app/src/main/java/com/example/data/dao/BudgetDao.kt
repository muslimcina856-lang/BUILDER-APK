package com.example.data.dao

import androidx.room.*
import com.example.data.model.BudgetLimitEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budget_limits")
    fun getAllBudgets(): Flow<List<BudgetLimitEntity>>

    @Query("SELECT * FROM budget_limits")
    suspend fun getAllBudgetsSync(): List<BudgetLimitEntity>

    @Query("SELECT * FROM budget_limits WHERE categoryName = :categoryName")
    suspend fun getBudgetByCategory(categoryName: String): BudgetLimitEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateBudget(budget: BudgetLimitEntity)

    @Query("DELETE FROM budget_limits")
    suspend fun deleteAll()

    @Delete
    suspend fun deleteBudget(budget: BudgetLimitEntity)

    @Query("DELETE FROM budget_limits WHERE categoryName = :categoryName")
    suspend fun deleteBudgetByCategory(categoryName: String)
}
