package com.example.data.ai

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.CategoryType
import com.example.data.model.TransactionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ExtractedNoteTransaction(
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val category: CategoryType
)

object SmartNoteParser {

    private const val TAG = "SmartNoteParser"
    private const val GEMINI_MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun parseTransactionsFromNoteText(text: String): List<ExtractedNoteTransaction> = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext emptyList()

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext fallbackRegexParse(text)
        }

        try {
            val prompt = """
                You are a smart financial note parser. Extract all financial transactions from the following user note text.
                
                For each transaction found, provide a JSON object with:
                - "title": short concise item title (string)
                - "amount": numeric value in IDR (number, e.g. 50000 for 50rb or 50.000)
                - "type": "EXPENSE" or "INCOME"
                - "category": ONE OF ["FOOD", "TRANSPORT", "SHOPPING", "BILLS", "ENTERTAINMENT", "HEALTH", "SALARY", "INVESTMENT", "TRANSFER", "OTHER"]

                Note text to parse:
                "$text"

                Return ONLY a JSON array of objects. Example format:
                [
                  {"title": "Kopi Starbucks", "amount": 45000, "type": "EXPENSE", "category": "FOOD"},
                  {"title": "Gajian Freelance", "amount": 1500000, "type": "INCOME", "category": "SALARY"}
                ]
            """.trimIndent()

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.1)
                })
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val url = "$BASE_URL/$GEMINI_MODEL:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBodyStr = response.body?.string() ?: ""
                    val responseJson = JSONObject(responseBodyStr)
                    val candidates = responseJson.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val firstCandidate = candidates.getJSONObject(0)
                        val content = firstCandidate.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val rawText = parts.getJSONObject(0).optString("text", "").trim()
                            val parsed = parseJsonArray(rawText)
                            if (parsed.isNotEmpty()) {
                                return@withContext parsed
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed Gemini smart note parse", e)
        }

        return@withContext fallbackRegexParse(text)
    }

    private fun parseJsonArray(rawJsonStr: String): List<ExtractedNoteTransaction> {
        val result = mutableListOf<ExtractedNoteTransaction>()
        try {
            val startIndex = rawJsonStr.indexOf("[")
            val endIndex = rawJsonStr.lastIndexOf("]")
            if (startIndex >= 0 && endIndex > startIndex) {
                val cleanJson = rawJsonStr.substring(startIndex, endIndex + 1)
                val jsonArray = JSONArray(cleanJson)
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val title = obj.optString("title", "Catatan")
                    val amount = obj.optDouble("amount", 0.0)
                    val typeStr = obj.optString("type", "EXPENSE").uppercase()
                    val catStr = obj.optString("category", "OTHER").uppercase()

                    if (amount > 0) {
                        val type = if (typeStr == "INCOME") TransactionType.INCOME else TransactionType.EXPENSE
                        val cat = CategoryType.values().find { it.name == catStr } ?: CategoryType.OTHER
                        result.add(ExtractedNoteTransaction(title, amount, type, cat))
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "JSON parse error on note", e)
        }
        return result
    }

    private suspend fun fallbackRegexParse(text: String): List<ExtractedNoteTransaction> {
        val results = mutableListOf<ExtractedNoteTransaction>()
        val lines = text.lines()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isBlank()) continue

            // Look for amount pattern e.g. 50rb, 50.000, 50000, 2.5jt, Rp 100k
            val amount = parseAmountFromLine(trimmed)
            if (amount > 0) {
                val isIncome = trimmed.contains("gaji", ignoreCase = true) ||
                        trimmed.contains("masuk", ignoreCase = true) ||
                        trimmed.contains("dapat", ignoreCase = true) ||
                        trimmed.contains("terima", ignoreCase = true) ||
                        trimmed.contains("bonus", ignoreCase = true)

                val type = if (isIncome) TransactionType.INCOME else TransactionType.EXPENSE
                val category = GeminiCategorySuggester.suggestCategory(trimmed)
                val title = trimmed.replace(Regex("""(?i)(rp\.?|\d+[\d\.,]*\s*(rb|k|jt|juta)?|\d+)"""), "").trim()
                    .removePrefix("-").removePrefix("*").removePrefix(".").trim()

                results.add(
                    ExtractedNoteTransaction(
                        title = if (title.isNotBlank()) title else "Transaksi Catatan",
                        amount = amount,
                        type = type,
                        category = category
                    )
                )
            }
        }
        return results
    }

    private fun parseAmountFromLine(line: String): Double {
        val lower = line.lowercase()
        // Check for 'jt' or 'juta' e.g. 2.5jt
        val jtMatch = Regex("""(\d+[\.,]?\d*)\s*(jt|juta)""").find(lower)
        if (jtMatch != null) {
            val num = jtMatch.groupValues[1].replace(",", ".").toDoubleOrNull() ?: 0.0
            return num * 1_000_000.0
        }

        // Check for 'rb' or 'k' e.g. 50rb, 100k
        val rbMatch = Regex("""(\d+[\.,]?\d*)\s*(rb|k)""").find(lower)
        if (rbMatch != null) {
            val num = rbMatch.groupValues[1].replace(",", ".").toDoubleOrNull() ?: 0.0
            return num * 1000.0
        }

        // Check for standard formatted currency e.g. 50.000 or 50000
        val numMatch = Regex("""(\d{1,3}(\.\d{3})+|\d{4,})""").find(lower)
        if (numMatch != null) {
            val cleanNum = numMatch.groupValues[1].replace(".", "").toDoubleOrNull() ?: 0.0
            if (cleanNum >= 100) return cleanNum
        }

        return 0.0
    }
}
