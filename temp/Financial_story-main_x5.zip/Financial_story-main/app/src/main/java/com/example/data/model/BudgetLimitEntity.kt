package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budget_limits")
data class BudgetLimitEntity(
    @PrimaryKey
    val categoryName: String, // e.g., "ALL", or "FOOD", "TRANSPORT", etc.
    val monthlyLimitAmount: Double,
    val alertThresholdPercent: Int = 80, // Notify when 80% or 100% exceeded
    val isNotificationEnabled: Boolean = true
)
