package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun QuickCalculatorDialog(
    onDismiss: () -> Unit,
    onApplyAmount: ((Double) -> Unit)? = null
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var displayExpression by remember { mutableStateOf("0") }
    var historyExpression by remember { mutableStateOf("") }
    var splitPeopleCount by remember { mutableIntStateOf(1) }

    fun onNumberClick(num: String) {
        if (displayExpression == "0" || displayExpression == "Error") {
            displayExpression = num
        } else {
            displayExpression += num
        }
    }

    fun onOperatorClick(op: String) {
        if (displayExpression.isNotEmpty() && !displayExpression.last().toString().matches(Regex("[+\\-*/]"))) {
            displayExpression += op
        }
    }

    fun onClear() {
        displayExpression = "0"
        historyExpression = ""
    }

    fun onDelete() {
        if (displayExpression.length > 1) {
            displayExpression = displayExpression.dropLast(1)
        } else {
            displayExpression = "0"
        }
    }

    fun calculateResult(): Double {
        return try {
            val expr = displayExpression.replace("×", "*").replace("÷", "/")
            val result = evaluateSimpleExpression(expr)
            result
        } catch (e: Exception) {
            Double.NaN
        }
    }

    fun onEqualClick() {
        val result = calculateResult()
        if (result.isNaN() || result.isInfinite()) {
            historyExpression = displayExpression
            displayExpression = "Error"
        } else {
            historyExpression = "$displayExpression ="
            displayExpression = if (result % 1.0 == 0.0) {
                result.toLong().toString()
            } else {
                String.format(Locale.US, "%.2f", result)
            }
        }
    }

    fun applyPercentage(pct: Double) {
        val currentVal = displayExpression.toDoubleOrNull() ?: calculateResult()
        if (!currentVal.isNaN()) {
            val res = currentVal * (pct / 100.0)
            historyExpression = "$currentVal × $pct%"
            displayExpression = if (res % 1.0 == 0.0) res.toLong().toString() else String.format(Locale.US, "%.2f", res)
        }
    }

    val numericValue = displayExpression.toDoubleOrNull() ?: calculateResult()
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Calculate, contentDescription = null, tint = BentoElectricLime)
                        Text(
                            text = "KALKULATOR KEUANGAN",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = BentoElectricLime
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = MaterialTheme.colorScheme.onSurface)
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                // Display Screen
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NeoBlack, RoundedCornerShape(12.dp))
                        .border(2.dp, BentoElectricLime, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = historyExpression.ifEmpty { " " },
                            fontSize = 12.sp,
                            color = Color.Gray,
                            maxLines = 1
                        )
                        Text(
                            text = displayExpression,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = BentoElectricLime,
                            textAlign = TextAlign.End,
                            maxLines = 1
                        )
                        if (!numericValue.isNaN() && numericValue > 0) {
                            Text(
                                text = "= ${idrFormat.format(numericValue)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeoCyan
                            )
                        }
                    }
                }

                // Quick Preset Actions (Diskon & Split Bill)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = false,
                        onClick = { applyPercentage(10.0) },
                        label = { Text("Pajak 10%", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { applyPercentage(20.0) },
                        label = { Text("Diskon 20%", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { applyPercentage(50.0) },
                        label = { Text("Diskon 50%", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    )
                }

                // Split Bill Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("👥 Patungan / Orang ($splitPeopleCount):", fontSize = 11.sp, fontWeight = FontWeight.Bold)

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SmallButton("-") { if (splitPeopleCount > 1) splitPeopleCount-- }
                        Text("$splitPeopleCount", fontWeight = FontWeight.Black, fontSize = 12.sp)
                        SmallButton("+") { splitPeopleCount++ }
                    }

                    val perPerson = if (!numericValue.isNaN() && splitPeopleCount > 0) numericValue / splitPeopleCount else 0.0
                    Text(idrFormat.format(perPerson), fontWeight = FontWeight.Black, fontSize = 12.sp, color = BentoElectricLime)
                }

                // Keyboard Grid
                val buttons = listOf(
                    listOf("C", "DEL", "%", "÷"),
                    listOf("7", "8", "9", "×"),
                    listOf("4", "5", "6", "-"),
                    listOf("1", "2", "3", "+"),
                    listOf("0", "00", ".", "=")
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    buttons.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            row.forEach { btn ->
                                val isOp = btn in listOf("÷", "×", "-", "+", "=")
                                val isAction = btn in listOf("C", "DEL", "%")

                                val bg = when {
                                    btn == "=" -> BentoElectricLime
                                    isOp -> NeoCyan
                                    isAction -> NeoPink
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                }
                                val txtColor = if (btn == "=" || isOp || isAction) NeoBlack else MaterialTheme.colorScheme.onSurface

                                KeyButton(
                                    text = btn,
                                    bgColor = bg,
                                    textColor = txtColor,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        if (btn == "=") {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        } else {
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        }
                                        when (btn) {
                                            "C" -> onClear()
                                            "DEL" -> onDelete()
                                            "=" -> onEqualClick()
                                            "%" -> {
                                                val valNum = displayExpression.toDoubleOrNull() ?: calculateResult()
                                                if (!valNum.isNaN()) {
                                                    displayExpression = (valNum / 100.0).toString()
                                                }
                                            }
                                            "÷", "×", "-", "+" -> onOperatorClick(btn)
                                            else -> onNumberClick(btn)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                // Copy & Apply Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BrutalistButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Calc Result", numericValue.toString())
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Hasil ${idrFormat.format(numericValue)} disalin ke clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        backgroundColor = NeoYellow,
                        textColor = NeoBlack,
                        text = "📋 SALIN"
                    )

                    if (onApplyAmount != null) {
                        BrutalistButton(
                            onClick = {
                                if (!numericValue.isNaN() && numericValue > 0) {
                                    onApplyAmount(numericValue)
                                    onDismiss()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            backgroundColor = BentoElectricLime,
                            textColor = NeoBlack,
                            text = "✓ GUNAKAN ANGKA"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(24.dp)
            .background(BentoElectricLime, RoundedCornerShape(4.dp))
            .border(1.dp, NeoBlack, RoundedCornerShape(4.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontWeight = FontWeight.Black, fontSize = 12.sp, color = NeoBlack)
    }
}

@Composable
private fun KeyButton(
    text: String,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(44.dp)
            .background(bgColor, RoundedCornerShape(8.dp))
            .border(1.5.dp, NeoBlack, RoundedCornerShape(8.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontWeight = FontWeight.Black,
            fontSize = 16.sp,
            color = textColor
        )
    }
}

private fun evaluateSimpleExpression(expression: String): Double {
    return object : Any() {
        var pos = -1
        var ch = 0

        fun nextChar() {
            ch = if (++pos < expression.length) expression[pos].code else -1
        }

        fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < expression.length) throw RuntimeException("Unexpected: " + ch.toChar())
            return x
        }

        fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                if (eat('+'.code)) x += parseTerm()
                else if (eat('-'.code)) x -= parseTerm()
                else return x
            }
        }

        fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                if (eat('*'.code)) x *= parseFactor()
                else if (eat('/'.code)) x /= parseFactor()
                else return x
            }
        }

        fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()

            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                eat(')'.code)
            } else if (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) {
                while (ch >= '0'.code && ch <= '9'.code || ch == '.'.code) nextChar()
                x = expression.substring(startPos, pos).toDouble()
            } else {
                throw RuntimeException("Unexpected: " + ch.toChar())
            }

            return x
        }
    }.parse()
}
