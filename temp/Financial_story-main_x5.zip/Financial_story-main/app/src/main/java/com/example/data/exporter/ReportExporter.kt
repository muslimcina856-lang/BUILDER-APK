package com.example.data.exporter

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportExporter {

    private val idrFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale("id", "ID"))

    fun generateCsvString(transactions: List<TransactionEntity>): String {
        val sb = StringBuilder()
        sb.append("ID,Tanggal,Judul,Tipe,Kategori,Akun,Jumlah (IDR),Catatan,E2EE Hash\n")
        transactions.forEach { t ->
            val dateStr = dateFormat.format(Date(t.dateTimestamp))
            val amountFormatted = String.format(Locale.US, "%.2f", t.amount)
            val titleClean = t.title.replace("\"", "\"\"").replace(",", " ")
            val notesClean = t.notes.replace("\"", "\"\"").replace(",", " ")
            sb.append("${t.id},\"$dateStr\",\"$titleClean\",${t.type.name},\"${t.category.label}\",\"${t.accountName}\",$amountFormatted,\"$notesClean\",\"${t.encryptedPayloadHash.take(12)}\"\n")
        }
        return sb.toString()
    }

    /**
     * Exports transaction records to a CSV file using Android's MediaStore API.
     * Inserts the generated CSV into the public Downloads store.
     */
    fun exportCsvViaMediaStore(context: Context, transactions: List<TransactionEntity>): Uri? {
        val csvContent = generateCsvString(transactions)
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "Laporan_Keuangan_$timeStamp.csv"

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FinBrutalReports")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val collectionUri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val itemUri = resolver.insert(collectionUri, contentValues)

                itemUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(csvContent.toByteArray(Charsets.UTF_8))
                    }

                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)

                    uri
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) {
                    downloadsDir.mkdirs()
                }
                val file = File(downloadsDir, fileName)
                file.writeText(csvContent, Charsets.UTF_8)
                Uri.fromFile(file)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareCsvFile(context: Context, transactions: List<TransactionEntity>) {
        try {
            val mediaUri = exportCsvViaMediaStore(context, transactions)
            
            val shareUri: Uri = if (mediaUri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                mediaUri
            } else {
                val csvContent = generateCsvString(transactions)
                val fileName = "Laporan_Keuangan_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.csv"
                val file = File(context.cacheDir, fileName)
                file.writeText(csvContent, Charsets.UTF_8)
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_SUBJECT, "Export Laporan Keuangan CSV")
                putExtra(Intent.EXTRA_STREAM, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Bagikan Laporan CSV"))
        } catch (e: Exception) {
            // Fallback to text intent if file provider or MediaStore sharing fails
            shareTextReport(context, transactions)
        }
    }

    fun generatePrintablePdfReportText(transactions: List<TransactionEntity>, totalIncome: Double, totalExpense: Double): String {
        val dateNow = SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(Date())
        val netBalance = totalIncome - totalExpense
        val sb = StringBuilder()
        sb.append("=========================================\n")
        sb.append("      LAPORAN KEUANGAN BULANAN - $dateNow\n")
        sb.append("      FinBrutal Financial Statement\n")
        sb.append("=========================================\n\n")
        sb.append("RINGKASAN:\n")
        sb.append("- Total Pemasukan : ${idrFormat.format(totalIncome)}\n")
        sb.append("- Total Pengeluaran: ${idrFormat.format(totalExpense)}\n")
        sb.append("- Arus Kas Bersih : ${idrFormat.format(netBalance)}\n")
        sb.append("- Total Transaksi : ${transactions.size} item\n\n")
        sb.append("RINCIAN TRANSAKSI:\n")
        sb.append("-----------------------------------------\n")
        transactions.take(50).forEachIndexed { index, t ->
            val dateStr = SimpleDateFormat("dd/MM/yy HH:mm", Locale("id", "ID")).format(Date(t.dateTimestamp))
            val typePrefix = if (t.type == TransactionType.INCOME) "(+)" else "(-)"
            sb.append("${index + 1}. [$dateStr] ${t.title} - ${t.category.label}\n")
            sb.append("   $typePrefix ${idrFormat.format(t.amount)} via ${t.accountName}\n")
        }
        sb.append("-----------------------------------------\n")
        sb.append("Status Enkripsi Data: E2EE AES-256 Validated\n")
        sb.append("Di-generate secara otomatis oleh Catatan Keuangan App\n")
        return sb.toString()
    }

    fun shareTextReport(context: Context, transactions: List<TransactionEntity>) {
        val totalIncome = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val totalExpense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        val report = generatePrintablePdfReportText(transactions, totalIncome, totalExpense)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Laporan Keuangan Bulanan")
            putExtra(Intent.EXTRA_TEXT, report)
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan Ringkasan Laporan"))
    }
}

