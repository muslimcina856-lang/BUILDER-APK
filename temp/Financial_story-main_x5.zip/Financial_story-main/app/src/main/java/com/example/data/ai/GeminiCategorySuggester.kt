package com.example.data.ai

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.CategoryType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiCategorySuggester {

    private const val TAG = "GeminiCategorySuggester"
    private const val GEMINI_MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun suggestCategory(description: String): CategoryType = withContext(Dispatchers.IO) {
        if (description.isBlank()) return@withContext fallbackKeywordMatch(description)

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            Log.d(TAG, "No valid Gemini API key set. Using heuristic fallback.")
            return@withContext fallbackKeywordMatch(description)
        }

        try {
            val prompt = """
                You are a smart financial advisor system.
                Classify the following transaction description into EXACTLY ONE of these category keys:
                - FOOD (for meals, restaurants, groceries, coffee, snacks)
                - TRANSPORT (for gas, fuel, gojek, grab, bus, train, parking, tolls)
                - SHOPPING (for clothes, online shopping, electronics, marketplace)
                - BILLS (for electricity, water, internet, phone bill, rent, utilities)
                - ENTERTAINMENT (for movies, games, streaming, games, lifestyle)
                - HEALTH (for doctor, pharmacy, medicine, hospital, gym)
                - SALARY (for salary, wage, bonus, income, client payment)
                - INVESTMENT (for stocks, mutual funds, gold, crypto, savings)
                - TRANSFER (for bank transfer, e-wallet topup, send money)
                - OTHER (if none of the above fit clearly)

                Transaction description: "$description"

                Reply WITH ONLY THE CATEGORY KEY STRING (e.g. FOOD, TRANSPORT, BILLS, etc.) and nothing else.
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            val partObj = JSONObject().apply {
                                put("text", prompt)
                            }
                            put(partObj)
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                val generationConfig = JSONObject().apply {
                    put("temperature", 0.1)
                }
                put("generationConfig", generationConfig)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val url = "$BASE_URL/$GEMINI_MODEL:generateContent?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Gemini API failed with code ${response.code}")
                    return@withContext fallbackKeywordMatch(description)
                }

                val responseBodyStr = response.body?.string() ?: ""
                val responseJson = JSONObject(responseBodyStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val resultText = parts.getJSONObject(0).optString("text", "").trim().uppercase()
                        for (cat in CategoryType.values()) {
                            if (resultText.contains(cat.name)) {
                                return@withContext cat
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error suggesting category via Gemini API", e)
        }

        return@withContext fallbackKeywordMatch(description)
    }

    private fun fallbackKeywordMatch(description: String): CategoryType {
        val lower = description.lowercase()
        return when {
            lower.contains("makan") || lower.contains("minum") || lower.contains("kopi") || lower.contains("nasi") || lower.contains("warung") || lower.contains("resto") || lower.contains("cafe") || lower.contains("indomaret") || lower.contains("alfamart") || lower.contains("food") -> CategoryType.FOOD
            lower.contains("bensin") || lower.contains("pertalite") || lower.contains("pertamax") || lower.contains("gojek") || lower.contains("grab") || lower.contains("parkir") || lower.contains("tol") || lower.contains("ojek") || lower.contains("taxi") -> CategoryType.TRANSPORT
            lower.contains("listrik") || lower.contains("pln") || lower.contains("pdam") || lower.contains("pulsa") || lower.contains("wifi") || lower.contains("indihome") || lower.contains("tagihan") -> CategoryType.BILLS
            lower.contains("baju") || lower.contains("sepatu") || lower.contains("tokopedia") || lower.contains("shopee") || lower.contains("lazada") || lower.contains("belanja") -> CategoryType.SHOPPING
            lower.contains("bioskop") || lower.contains("game") || lower.contains("steam") || lower.contains("netflix") || lower.contains("spotify") -> CategoryType.ENTERTAINMENT
            lower.contains("obat") || lower.contains("dokter") || lower.contains("apotek") || lower.contains("rumah sakit") -> CategoryType.HEALTH
            lower.contains("gaji") || lower.contains("bonus") || lower.contains("payroll") -> CategoryType.SALARY
            lower.contains("saham") || lower.contains("reksa") || lower.contains("crypto") || lower.contains("tabungan") || lower.contains("bibit") -> CategoryType.INVESTMENT
            lower.contains("transfer") || lower.contains("tf") || lower.contains("topup") || lower.contains("gopay") || lower.contains("ovo") || lower.contains("dana") -> CategoryType.TRANSFER
            else -> CategoryType.OTHER
        }
    }
}
