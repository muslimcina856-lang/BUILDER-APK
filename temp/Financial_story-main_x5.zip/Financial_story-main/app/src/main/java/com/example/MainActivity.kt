package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CategoryType
import com.example.data.model.TransactionType
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinancialViewModel

enum class NavigationTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Beranda", Icons.Default.Home),
    TRANSACTIONS("Transaksi", Icons.Default.ReceiptLong),
    NOTES("Catatan", Icons.Default.StickyNote2),
    ANALYTICS("Grafik", Icons.Default.BarChart),
    ACCOUNTS("Bank Sync", Icons.Default.AccountBalance),
    SETTINGS("Pengaturan", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: FinancialViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Create notification channel for local budget alerts
        com.example.notification.BudgetNotificationManager.createNotificationChannel(this)

        // Request POST_NOTIFICATIONS permission on Android 13+ (API 33+) if needed
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            FinBrutalTheme(darkTheme = uiState.isDarkMode) {
                val haptic = LocalHapticFeedback.current
    var currentTab by remember { mutableStateOf(NavigationTab.DASHBOARD) }
                var showAddModalByFab by remember { mutableStateOf(false) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = Color.Transparent,
                        contentWindowInsets = WindowInsets.safeDrawing,
                        floatingActionButton = {
                            Box(
                                modifier = Modifier.padding(bottom = 80.dp)
                            ) {
                                FloatingActionButton(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        showAddModalByFab = true
                                    },
                                    containerColor = NeoYellow,
                                    contentColor = NeoBlack,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .border(2.5.dp, NeoBlack, RoundedCornerShape(12.dp))
                                        .size(58.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Tambah Transaksi",
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            // Screen Routing
                            AnimatedContent(
                                targetState = currentTab,
                                label = "screen_tab_anim"
                            ) { tab ->
                                when (tab) {
                                    NavigationTab.DASHBOARD -> DashboardScreen(
                                        uiState = uiState,
                                        onNavigateToAddTransaction = { showAddModalByFab = true },
                                        onNavigateToAccounts = { currentTab = NavigationTab.ACCOUNTS },
                                        onNavigateToAnalytics = { currentTab = NavigationTab.ANALYTICS },
                                        onNavigateToNotes = { currentTab = NavigationTab.NOTES },
                                        onDeleteTransaction = { viewModel.deleteTransaction(it) },
                                        onTriggerSync = { viewModel.triggerAutoSync() },
                                        onUpdateUserName = { viewModel.updateUserName(it) },
                                        onSendFeedbackSuccess = { viewModel.showCustomSuccessMessage(it) },
                                        onQuickAddExpense = { title, amount, category ->
                                            viewModel.addTransaction(
                                                title = title,
                                                amount = amount,
                                                type = TransactionType.EXPENSE,
                                                category = category,
                                                accountName = "BANK / E-WALLET",
                                                notes = "Pembayaran tagihan rutin dari Dashboard"
                                            )
                                        }
                                    )

                                    NavigationTab.TRANSACTIONS -> TransactionsScreen(
                                        uiState = uiState,
                                        onAddTransaction = { title, amount, type, category, account, notes ->
                                            viewModel.addTransaction(title, amount, type, category, account, notes)
                                        },
                                        onDeleteTransaction = { viewModel.deleteTransaction(it) }
                                    )

                                    NavigationTab.NOTES -> SmartNotesScreen(
                                        uiState = uiState,
                                        onAddNote = { title, content, tag, isPinned, isDraft, isVoiceMemo, audioDuration ->
                                            viewModel.addNote(title, content, tag, isPinned, isDraft, isVoiceMemo, audioDuration)
                                        },
                                        onUpdateNote = { note -> viewModel.updateNote(note) },
                                        onDeleteNote = { note -> viewModel.deleteNote(note) },
                                        onTogglePinNote = { note -> viewModel.togglePinNote(note) },
                                        onConvertNoteToTx = { note, extracted, accName ->
                                            viewModel.convertNoteToTransactions(note, extracted, accName)
                                        }
                                    )

                                    NavigationTab.ANALYTICS -> AnalyticsScreen(
                                        uiState = uiState,
                                        onExportCsv = { viewModel.exportCsv() },
                                        onExportPdf = { viewModel.exportPdfReport() },
                                        onSelectPrimaryCurrency = { viewModel.setPrimaryCurrency(it) },
                                        onSelectSecondaryCurrency = { viewModel.setSecondaryCurrency(it) },
                                        onRefreshRates = { viewModel.refreshExchangeRates() }
                                    )

                                    NavigationTab.ACCOUNTS -> AccountsSyncScreen(
                                        uiState = uiState,
                                        onTriggerSync = { viewModel.triggerAutoSync() },
                                        onDeleteAccount = { viewModel.deleteAccount(it) },
                                        onAddAccount = { name, num, type, bal -> viewModel.addAccount(name, num, type, bal) }
                                    )

                                    NavigationTab.SETTINGS -> BudgetSecurityScreen(
                                        uiState = uiState,
                                        onUpdateBudget = { cat, amt -> viewModel.updateBudgetLimit(cat, amt) },
                                        onToggleDarkMode = { viewModel.toggleDarkMode() },
                                        onExportCsv = { viewModel.exportCsv() },
                                        onExportPdf = { viewModel.exportPdfReport() },
                                        onUpdateUserName = { viewModel.updateUserName(it) },
                                        onSendFeedbackSuccess = { viewModel.showCustomSuccessMessage(it) },
                                        onSelectPrimaryCurrency = { viewModel.setPrimaryCurrency(it) },
                                        onSelectSecondaryCurrency = { viewModel.setSecondaryCurrency(it) },
                                        onRefreshRates = { viewModel.refreshExchangeRates() },
                                        onClearAllData = { viewModel.clearAllDataAndReset() },
                                        onDeleteBudget = { viewModel.deleteBudget(it) }
                                    )
                                }
                            }

                            // Micro-Animation Success Banner Pop
                            TransactionSuccessPopBanner(
                                message = uiState.popSuccessMessage ?: "",
                                isVisible = uiState.popSuccessMessage != null,
                                onDismiss = { viewModel.dismissSuccessPop() }
                            )

                            // Budget Exceeded Alert Banner
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 90.dp)
                            ) {
                                BudgetAlertBanner(
                                    warningMessage = uiState.budgetExceededAlert ?: "",
                                    isVisible = uiState.budgetExceededAlert != null,
                                    onDismiss = { viewModel.dismissBudgetAlert() }
                                )
                            }
                        }
                    }

                    // Bottom Neo-Brutalist Navigation Bar
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .padding(12.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(12.dp)
                            )
                            .border(2.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                            .padding(vertical = 8.dp, horizontal = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            NavigationTab.values().forEach { tab ->
                                val isSelected = currentTab == tab
                                val bgColor = if (isSelected) NeoYellow else Color.Transparent
                                val textColor = if (isSelected) NeoBlack else MaterialTheme.colorScheme.onSurface

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(bgColor)
                                        .border(
                                            width = if (isSelected) 2.dp else 0.dp,
                                            color = if (isSelected) NeoBlack else Color.Transparent,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { 
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            currentTab = tab 
                                        }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        tint = textColor,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Text(
                                        text = tab.title.uppercase(),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 10.sp,
                                        color = textColor
                                    )
                                }
                            }
                        }
                    }

                    // FAB Quick Add Dialog
                    if (showAddModalByFab) {
                        AddTransactionModalDialog(
                            accountsList = uiState.accounts.map { it.name },
                            onDismiss = { showAddModalByFab = false },
                            onSubmit = { title, amount, type, category, account, notes ->
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.addTransaction(title, amount, type, category, account, notes)
                                showAddModalByFab = false
                            }
                        )
                    }
                }
            }
        }
    }
}

