package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

data class SavingsGoalItem(
    val id: String,
    val title: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val emoji: String = "🎯"
)

@Composable
fun SavingsGoalsCard(
    onAddGoalDeposit: (goalTitle: String, amount: Double) -> Unit
) {
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    var goals by remember {
        mutableStateOf(emptyList<SavingsGoalItem>())
    }

    var showAddGoalModal by remember { mutableStateOf(false) }
    var selectedGoalForTopUp by remember { mutableStateOf<SavingsGoalItem?>(null) }
    var topUpAmountText by remember { mutableStateOf("") }

    // Add Goal state
    var newTitle by remember { mutableStateOf("") }
    var newTargetText by remember { mutableStateOf("") }
    var newEmoji by remember { mutableStateOf("🎯") }

    BrutalistCard(
        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
        borderColor = MaterialTheme.colorScheme.outline
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Savings, contentDescription = null, tint = BentoElectricLime)
                Text(
                    text = "TARGET TABUNGAN IMPIAN",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            BrutalistButton(
                onClick = { showAddGoalModal = true },
                backgroundColor = BentoElectricLime,
                textColor = NeoBlack,
                text = "+ TAMBAH"
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (goals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Belum ada target tabungan impian. Klik + TAMBAH untuk membuat target baru.",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            goals.forEach { goal ->
                val progress = (goal.currentAmount / goal.targetAmount).coerceIn(0.0, 1.0).toFloat()
                val percentage = (progress * 100).toInt()

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                        .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(goal.emoji, fontSize = 18.sp)
                            Text(
                                text = goal.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Text(
                            text = "$percentage%",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = BentoElectricLime
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .border(1.dp, NeoBlack, RoundedCornerShape(4.dp)),
                        color = BentoElectricLime,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${idrFormat.format(goal.currentAmount)} / ${idrFormat.format(goal.targetAmount)}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            BrutalistButton(
                                onClick = {
                                    selectedGoalForTopUp = goal
                                    topUpAmountText = ""
                                },
                                backgroundColor = NeoCyan,
                                textColor = NeoBlack,
                                text = "💵 SETOR"
                            )

                            IconButton(
                                onClick = {
                                    goals = goals.filter { it.id != goal.id }
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Hapus Target",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Top-Up / Setor Tabungan
    if (selectedGoalForTopUp != null) {
        val activeGoal = selectedGoalForTopUp!!
        AlertDialog(
            onDismissRequest = { selectedGoalForTopUp = null },
            confirmButton = {
                BrutalistButton(
                    onClick = {
                        val amount = topUpAmountText.toDoubleOrNull() ?: 0.0
                        if (amount > 0) {
                            onAddGoalDeposit("Tabungan: ${activeGoal.title}", amount)
                            goals = goals.map {
                                if (it.id == activeGoal.id) {
                                    it.copy(currentAmount = it.currentAmount + amount)
                                } else it
                            }
                            selectedGoalForTopUp = null
                        }
                    },
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    text = "SIMPAN SETORAN"
                )
            },
            dismissButton = {
                TextButton(onClick = { selectedGoalForTopUp = null }) {
                    Text("BATAL", fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Text(
                    text = "SETOR DANA TABUNGAN",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Target: ${activeGoal.emoji} ${activeGoal.title}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Sisa Target: ${idrFormat.format((activeGoal.targetAmount - activeGoal.currentAmount).coerceAtLeast(0.0))}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = topUpAmountText,
                        onValueChange = { topUpAmountText = it.filter { c -> c.isDigit() } },
                        label = { Text("Jumlah Setoran (Rp)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BentoElectricLime,
                            focusedLabelColor = BentoElectricLime
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp)
        )
    }

    // Modal Tambah Target Baru
    if (showAddGoalModal) {
        AlertDialog(
            onDismissRequest = { showAddGoalModal = false },
            confirmButton = {
                BrutalistButton(
                    onClick = {
                        val target = newTargetText.toDoubleOrNull() ?: 0.0
                        if (newTitle.isNotBlank() && target > 0) {
                            val newGoal = SavingsGoalItem(
                                id = System.currentTimeMillis().toString(),
                                title = newTitle.trim(),
                                targetAmount = target,
                                currentAmount = 0.0,
                                emoji = newEmoji.ifBlank { "🎯" }
                            )
                            goals = goals + newGoal
                            newTitle = ""
                            newTargetText = ""
                            showAddGoalModal = false
                        }
                    },
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    text = "BUAT TARGET"
                )
            },
            dismissButton = {
                TextButton(onClick = { showAddGoalModal = false }) {
                    Text("BATAL", fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Text(
                    text = "BUAT TARGET TABUNGAN BARU",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Nama Target (mis. Beli Motor)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newTargetText,
                        onValueChange = { newTargetText = it.filter { c -> c.isDigit() } },
                        label = { Text("Total Target Rp") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newEmoji,
                        onValueChange = { newEmoji = it },
                        label = { Text("Emoji Ikon (mis. 🛵, 🏠, 🎓)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
