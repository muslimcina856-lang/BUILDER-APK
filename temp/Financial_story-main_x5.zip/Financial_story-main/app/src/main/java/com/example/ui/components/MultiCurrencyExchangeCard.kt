package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.currency.CurrencyData
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MultiCurrencyExchangeCard(
    primaryCurrency: String,
    secondaryCurrency: String,
    exchangeRates: Map<String, Double>,
    lastUpdatedText: String,
    isFetching: Boolean,
    isLive: Boolean,
    totalBalanceIdr: Double,
    totalExpenseIdr: Double,
    onSelectPrimaryCurrency: (String) -> Unit,
    onSelectSecondaryCurrency: (String) -> Unit,
    onRefreshRates: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    var calcInputAmountText by remember { mutableStateOf("100") }
    var calcFromCurrency by remember { mutableStateOf(secondaryCurrency) }
    var calcToCurrency by remember { mutableStateOf(primaryCurrency) }

    // Keep converter in sync if currencies change
    LaunchedEffect(primaryCurrency, secondaryCurrency) {
        calcFromCurrency = secondaryCurrency
        calcToCurrency = primaryCurrency
    }

    val primaryInfo = remember(primaryCurrency) { CurrencyData.getCurrencyInfo(primaryCurrency) }
    val secondaryInfo = remember(secondaryCurrency) { CurrencyData.getCurrencyInfo(secondaryCurrency) }

    // Convert live values
    val primaryBalance = CurrencyData.convert(totalBalanceIdr, "IDR", primaryCurrency, exchangeRates)
    val secondaryBalance = CurrencyData.convert(totalBalanceIdr, "IDR", secondaryCurrency, exchangeRates)

    val primaryExpense = CurrencyData.convert(totalExpenseIdr, "IDR", primaryCurrency, exchangeRates)
    val secondaryExpense = CurrencyData.convert(totalExpenseIdr, "IDR", secondaryCurrency, exchangeRates)

    // Calculate 1 Secondary in Primary
    val oneSecondaryInPrimary = CurrencyData.convert(1.0, secondaryCurrency, primaryCurrency, exchangeRates)

    // Converter computation
    val inputNum = calcInputAmountText.toDoubleOrNull() ?: 0.0
    val convertedNum = CurrencyData.convert(inputNum, calcFromCurrency, calcToCurrency, exchangeRates)

    BrutalistCard(
        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
        borderColor = MaterialTheme.colorScheme.outline,
        modifier = modifier
    ) {
        // Card Header & Refresh Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CurrencyExchange,
                    contentDescription = null,
                    tint = BentoElectricLime,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "KURS LIVE & DUAL CURRENCY",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isLive) "⚡ Open Exchange Rates API • $lastUpdatedText" else "🌐 $lastUpdatedText",
                        fontSize = 11.sp,
                        color = if (isLive) BentoElectricLime else NeoGray
                    )
                }
            }

            IconButton(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onRefreshRates()
                },
                enabled = !isFetching
            ) {
                if (isFetching) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = NeoYellow)
                } else {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Live Rates",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Currency Selector Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Primary Currency Picker
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Mata Uang Utama",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                CurrencyDropdownSelector(
                    selectedCode = primaryCurrency,
                    onSelected = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelectPrimaryCurrency(it)
                    }
                )
            }

            // Secondary Currency Picker
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Mata Uang Sekunder",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                CurrencyDropdownSelector(
                    selectedCode = secondaryCurrency,
                    onSelected = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelectSecondaryCurrency(it)
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Live Exchange Rate Highlight Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(NeoYellow, RoundedCornerShape(8.dp))
                .border(2.dp, NeoBlack, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "KURS HARI INI",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = NeoBlack
                    )
                    Text(
                        text = "1 ${secondaryInfo.code} ${secondaryInfo.flagEmoji} = ${CurrencyData.formatAmount(oneSecondaryInPrimary, primaryCurrency)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = NeoBlack
                    )
                }

                BrutalistBadge(
                    text = if (isLive) "LIVE API" else "FALLBACK",
                    backgroundColor = if (isLive) BentoElectricLime else NeoCyan,
                    textColor = NeoBlack
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Dual Currency Balance Summary
        Text(
            text = "RINGKASAN SALDO & PENGELUARAN (DUAL CURRENCY)",
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Balance Card
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Text("Total Saldo", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = CurrencyData.formatAmount(primaryBalance, primaryCurrency),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "≈ ${CurrencyData.formatAmount(secondaryBalance, secondaryCurrency)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BentoElectricLime
                    )
                }
            }

            // Expense Card
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Text("Pengeluaran Bulan Ini", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = CurrencyData.formatAmount(primaryExpense, primaryCurrency),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "≈ ${CurrencyData.formatAmount(secondaryExpense, secondaryCurrency)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeoRedAlert
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Live Currency Converter Calculator
        Text(
            text = "KALKULATOR KONVERSI KURS INSTAN",
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = calcInputAmountText,
                onValueChange = { calcInputAmountText = it },
                label = { Text("Jumlah", fontSize = 10.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )

            // Swap Button
            IconButton(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    val temp = calcFromCurrency
                    calcFromCurrency = calcToCurrency
                    calcToCurrency = temp
                },
                modifier = Modifier
                    .background(NeoCyan, RoundedCornerShape(8.dp))
                    .border(1.5.dp, NeoBlack, RoundedCornerShape(8.dp))
                    .size(42.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SwapHoriz,
                    contentDescription = "Tukar Mata Uang",
                    tint = NeoBlack
                )
            }

            // Output Display Box
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .background(BentoElectricLime, RoundedCornerShape(8.dp))
                    .border(2.dp, NeoBlack, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 10.dp)
            ) {
                Column {
                    Text(
                        text = "Hasil Konversi ($calcToCurrency)",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeoBlack
                    )
                    Text(
                        text = CurrencyData.formatAmount(convertedNum, calcToCurrency),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = NeoBlack
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CurrencyDropdownSelector(
    selectedCode: String,
    onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val info = remember(selectedCode) { CurrencyData.getCurrencyInfo(selectedCode) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        Box(
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${info.flagEmoji} ${info.code} (${info.symbol})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            }
        }

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            CurrencyData.SUPPORTED_CURRENCIES.forEach { item ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "${item.flagEmoji} ${item.code} - ${item.name}",
                            fontSize = 12.sp,
                            fontWeight = if (item.code == selectedCode) FontWeight.ExtraBold else FontWeight.Normal
                        )
                    },
                    onClick = {
                        onSelected(item.code)
                        expanded = false
                    }
                )
            }
        }
    }
}
