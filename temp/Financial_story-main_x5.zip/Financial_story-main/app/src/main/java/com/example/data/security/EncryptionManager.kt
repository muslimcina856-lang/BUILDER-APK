package com.example.data.security

import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
import android.util.Base64

object EncryptionManager {
    private const val ALGORITHM = "AES"
    
    // Hash generator using SHA-256 for data integrity check
    fun generateSHA256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }

    // E2EE Payload Encryption simulation using AES-128 key derived from passphrase
    fun encrypt(plainText: String, secretPassphrase: String): String {
        return try {
            val keyBytes = generateSHA256(secretPassphrase).substring(0, 16).toByteArray(Charsets.UTF_8)
            val secretKey = SecretKeySpec(keyBytes, ALGORITHM)
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            plainText
        }
    }

    fun decrypt(cipherText: String, secretPassphrase: String): String {
        return try {
            val keyBytes = generateSHA256(secretPassphrase).substring(0, 16).toByteArray(Charsets.UTF_8)
            val secretKey = SecretKeySpec(keyBytes, ALGORITHM)
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, secretKey)
            val decodedBytes = Base64.decode(cipherText, Base64.NO_WRAP)
            String(cipher.doFinal(decodedBytes), Charsets.UTF_8)
        } catch (e: Exception) {
            cipherText
        }
    }
}
