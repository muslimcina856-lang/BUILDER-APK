package com.example.feedback

import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object TelegramFeedbackManager {
    private const val BOT_TOKEN = "8445673250:AAHbv9fXof1J02MEt2Re-zB1Tm29FJD2PH8"
    private const val CHAT_ID = "7322704771"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun sendFeedback(
        userName: String,
        category: String,
        rating: Int,
        message: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val dateStr = SimpleDateFormat("dd MMMM yyyy HH:mm:ss", Locale("id", "ID")).format(Date())
            val stars = "⭐".repeat(rating)

            val textMessage = """
                📩 *UMPAN BALIK APLIKASI FINANCIAL RECORDS*
                
                👤 *Pengirim:* $userName
                📅 *Waktu:* $dateStr
                📌 *Kategori:* $category
                ⭐ *Rating:* $stars ($rating/5)
                📱 *Perangkat:* ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})
                
                💬 *Pesan Umpan Balik:*
                "$message"
            """.trimIndent()

            val formBody = FormBody.Builder()
                .add("chat_id", CHAT_ID)
                .add("text", textMessage)
                .add("parse_mode", "Markdown")
                .build()

            val request = Request.Builder()
                .url("https://api.telegram.org/bot$BOT_TOKEN/sendMessage")
                .post(formBody)
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success(true)
            } else {
                val errBody = response.body?.string() ?: "Unknown error"
                Result.failure(Exception("HTTP ${response.code}: $errBody"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
