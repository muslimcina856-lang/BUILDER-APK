package com.example.data.repository

import com.example.data.dao.AccountDao
import com.example.data.dao.BudgetDao
import com.example.data.dao.NoteDao
import com.example.data.dao.TransactionDao
import com.example.data.model.*
import com.example.data.security.EncryptionManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.Random

class FinancialRepository(
    private val transactionDao: TransactionDao,
    private val accountDao: AccountDao,
    private val budgetDao: BudgetDao,
    private val noteDao: NoteDao
) {
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allAccounts: Flow<List<AccountEntity>> = accountDao.getAllAccounts()
    val allBudgets: Flow<List<BudgetLimitEntity>> = budgetDao.getAllBudgets()
    val allNotes: Flow<List<NoteEntity>> = noteDao.getAllNotes()

    suspend fun insertNote(note: NoteEntity): Long = noteDao.insertNote(note)
    suspend fun updateNote(note: NoteEntity) = noteDao.updateNote(note)
    suspend fun deleteNote(note: NoteEntity) = noteDao.deleteNote(note)
    suspend fun deleteNoteById(id: Long) = noteDao.deleteNoteById(id)

    suspend fun getAllTransactionsSync(): List<TransactionEntity> = transactionDao.getAllTransactionsSync()

    suspend fun insertTransaction(transaction: TransactionEntity): Long {
        val payloadHash = EncryptionManager.generateSHA256("${transaction.title}_${transaction.amount}_${transaction.dateTimestamp}")
        val secureTransaction = transaction.copy(encryptedPayloadHash = payloadHash)
        val id = transactionDao.insertTransaction(secureTransaction)
        
        // Adjust balance in account
        val delta = if (transaction.type == TransactionType.INCOME) transaction.amount else -transaction.amount
        accountDao.updateBalance(transaction.accountName, delta)
        
        return id
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) {
        transactionDao.deleteTransaction(transaction)
        // Reverse account balance adjustment
        val delta = if (transaction.type == TransactionType.INCOME) -transaction.amount else transaction.amount
        accountDao.updateBalance(transaction.accountName, delta)
    }

    suspend fun deleteAccount(account: AccountEntity) {
        accountDao.deleteAccount(account)
    }

    suspend fun addOrUpdateAccount(account: AccountEntity) {
        accountDao.insertOrUpdateAccount(account)
    }

    suspend fun deleteBudget(categoryName: String) {
        budgetDao.deleteBudgetByCategory(categoryName)
    }

    suspend fun setBudgetLimit(categoryName: String, amount: Double) {
        budgetDao.insertOrUpdateBudget(
            BudgetLimitEntity(
                categoryName = categoryName,
                monthlyLimitAmount = amount,
                alertThresholdPercent = 80,
                isNotificationEnabled = true
            )
        )
    }

    suspend fun triggerBankAutoSync(): Int {
        val currentAccounts = allAccounts.first()
        val random = Random()
        var syncedCount = 0

        // Simulate auto-fetching transactions from linked Bank & E-Wallet APIs
        val mockSyncFeed = listOf(
            Triple("Cashback GoPay Promo", 15000.0, "GoPay" to CategoryType.SALARY),
            Triple("Kopi Janji Jiwa QRIS", 28000.0, "GoPay" to CategoryType.FOOD),
            Triple("Bensin Pertamax", 50000.0, "Bank BCA" to CategoryType.TRANSPORT),
            Triple("Tagihan Listrik PLN", 175000.0, "Bank Mandiri" to CategoryType.BILLS),
            Triple("Transfer Masuk Klien", 1250000.0, "Bank BCA" to CategoryType.SALARY),
            Triple("Supermarket Fresh", 142000.0, "OVO" to CategoryType.FOOD)
        )

        val selectedSample = mockSyncFeed.shuffled().take(2)
        selectedSample.forEach { item ->
            val isIncome = item.second > 200000.0
            val tType = if (isIncome) TransactionType.INCOME else TransactionType.EXPENSE
            val newTransaction = TransactionEntity(
                title = item.first,
                amount = item.second,
                type = tType,
                category = item.third.second,
                accountName = item.third.first,
                dateTimestamp = System.currentTimeMillis() - (random.nextInt(3600 * 24 * 3) * 1000L),
                notes = "Auto-Synced via Financial API Sync",
                isAutoSynced = true
            )
            insertTransaction(newTransaction)
            syncedCount++
        }

        // Update last synced timestamps on accounts
        currentAccounts.forEach { acc ->
            accountDao.insertOrUpdateAccount(
                acc.copy(lastSyncedTimestamp = System.currentTimeMillis())
            )
        }

        return syncedCount
    }

    suspend fun clearAllData() {
        transactionDao.deleteAll()
        budgetDao.deleteAll()
        accountDao.deleteAll()
        noteDao.deleteAll()
        val initialAccounts = listOf(
            AccountEntity("bca_01", "Bank BCA", "**** 8821", AccountType.BANK, 0.0, iconColorHex = "#005EAA"),
            AccountEntity("mandiri_01", "Bank Mandiri", "**** 4390", AccountType.BANK, 0.0, iconColorHex = "#003366"),
            AccountEntity("gopay_01", "GoPay", "0812****99", AccountType.EWALLET, 0.0, iconColorHex = "#00AED6"),
            AccountEntity("ovo_01", "OVO", "0812****99", AccountType.EWALLET, 0.0, iconColorHex = "#4C2A86"),
            AccountEntity("cash_01", "Dompet Tunai", "Saku", AccountType.CASH, 0.0, iconColorHex = "#FFE600")
        )
        accountDao.insertAll(initialAccounts)
    }

    suspend fun seedInitialDataIfEmpty() {
        val accounts = accountDao.getAllAccounts().first()
        if (accounts.isEmpty()) {
            val initialAccounts = listOf(
                AccountEntity("bca_01", "Bank BCA", "**** 8821", AccountType.BANK, 0.0, iconColorHex = "#005EAA"),
                AccountEntity("mandiri_01", "Bank Mandiri", "**** 4390", AccountType.BANK, 0.0, iconColorHex = "#003366"),
                AccountEntity("gopay_01", "GoPay", "0812****99", AccountType.EWALLET, 0.0, iconColorHex = "#00AED6"),
                AccountEntity("ovo_01", "OVO", "0812****99", AccountType.EWALLET, 0.0, iconColorHex = "#4C2A86"),
                AccountEntity("cash_01", "Dompet Tunai", "Saku", AccountType.CASH, 0.0, iconColorHex = "#FFE600")
            )
            accountDao.insertAll(initialAccounts)
        }
    }
}
