package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun CreatorCreditCard(
    modifier: Modifier = Modifier,
    onOpenFeedbackDialog: (() -> Unit)? = null
) {
    val context = LocalContext.current

    fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    BrutalistCard(
        modifier = modifier.fillMaxWidth(),
        backgroundColor = NeoDarkSurface,
        borderColor = NeoLime,
        shadowColor = NeoBlack,
        shadowOffset = 4.dp,
        cornerRadius = 20.dp,
        borderWidth = 2.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(NeoLime, CircleShape)
                            .border(2.dp, NeoBlack, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "M",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = NeoBlack
                        )
                    }

                    Column {
                        Text(
                            text = "DIBUAT OLEH",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 10.sp,
                            color = NeoGray,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "momonpxl",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = NeoWhite
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(NeoYellow, RoundedCornerShape(12.dp))
                        .border(1.5.dp, NeoBlack, RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "CREATOR",
                        fontWeight = FontWeight.Black,
                        fontSize = 10.sp,
                        color = NeoBlack
                    )
                }
            }

            Text(
                text = "Pengembang aplikasi & kreator konten. Dukung dan terhubung langsung di media sosial:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = NeoWhite.copy(alpha = 0.8f)
            )

            // Social Buttons Row in Bento Grid style
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // TikTok
                SocialChip(
                    label = "TikTok",
                    handle = "@momonpxl",
                    backgroundColor = NeoPink,
                    textColor = NeoWhite,
                    modifier = Modifier.weight(1f),
                    onClick = { openUrl("https://www.tiktok.com/@momonpxl") }
                )

                // Instagram
                SocialChip(
                    label = "Instagram",
                    handle = "@momonpxl",
                    backgroundColor = NeoPurple,
                    textColor = NeoWhite,
                    modifier = Modifier.weight(1f),
                    onClick = { openUrl("https://www.instagram.com/momonpxl") }
                )

                // Telegram
                SocialChip(
                    label = "Telegram",
                    handle = "@momonpxl",
                    backgroundColor = NeoCyan,
                    textColor = NeoBlack,
                    modifier = Modifier.weight(1f),
                    onClick = { openUrl("https://t.me/momonpxl") }
                )
            }

            if (onOpenFeedbackDialog != null) {
                BrutalistButton(
                    onClick = onOpenFeedbackDialog,
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    cornerRadius = 12.dp,
                    text = "💬 KIRIM UMPAN BALIK KE TELEGRAM BOT"
                )
            }
        }
    }
}

@Composable
fun SocialChip(
    label: String,
    handle: String,
    backgroundColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .border(2.dp, NeoBlack, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label.uppercase(),
                fontWeight = FontWeight.Black,
                fontSize = 10.sp,
                color = textColor
            )
            Text(
                text = handle,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                color = textColor.copy(alpha = 0.9f)
            )
        }
    }
}
