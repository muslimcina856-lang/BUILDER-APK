package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.R
import com.example.data.db.FinancialDatabase
import com.example.data.model.CategoryType
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.notification.BudgetNotificationManager
import com.example.ui.QuickExpenseActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class QuickExpenseWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_QUICK_10K = "com.example.widget.QUICK_10K"
        const val ACTION_QUICK_20K = "com.example.widget.QUICK_20K"
        const val ACTION_QUICK_50K = "com.example.widget.QUICK_50K"

        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, QuickExpenseWidgetProvider::class.java)
            val widgetIds = appWidgetManager.getAppWidgetIds(componentName)

            val provider = QuickExpenseWidgetProvider()
            provider.onUpdate(context, appWidgetManager, widgetIds)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = FinancialDatabase.getDatabase(context)
            val dao = db.transactionDao()
            val budgetDao = db.budgetDao()
            val accountDao = db.accountDao()

            // Calculate today's start timestamp
            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val startOfDay = calendar.timeInMillis

            val allTxs = dao.getAllTransactionsSync()
            val todayExpense = allTxs
                .filter { it.type == TransactionType.EXPENSE && it.dateTimestamp >= startOfDay }
                .sumOf { it.amount }

            val accounts = accountDao.getAllAccountsSync()
            val totalBalance = accounts.sumOf { it.balance }

            val idrFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
            val formattedToday = idrFormat.format(todayExpense)
            val formattedBalance = idrFormat.format(totalBalance)

            for (appWidgetId in appWidgetIds) {
                val views = RemoteViews(context.packageName, R.layout.quick_expense_widget)

                views.setTextViewText(R.id.widget_title, "⚡ FINANCIAL RECORDS")
                views.setTextViewText(R.id.widget_total_balance, formattedBalance)
                views.setTextViewText(R.id.widget_today_expense, formattedToday)

                // Intent for Quick Add Activity (Custom input)
                val customInputIntent = Intent(context, QuickExpenseActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val customPendingIntent = PendingIntent.getActivity(
                    context,
                    100,
                    customInputIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.btn_quick_add_header, customPendingIntent)
                views.setOnClickPendingIntent(R.id.btn_quick_custom, customPendingIntent)

                // Intent for +10k
                views.setOnClickPendingIntent(
                    R.id.btn_quick_10k,
                    getBroadcastPendingIntent(context, ACTION_QUICK_10K, 101)
                )

                // Intent for +20k
                views.setOnClickPendingIntent(
                    R.id.btn_quick_20k,
                    getBroadcastPendingIntent(context, ACTION_QUICK_20K, 102)
                )

                // Intent for +50k
                views.setOnClickPendingIntent(
                    R.id.btn_quick_50k,
                    getBroadcastPendingIntent(context, ACTION_QUICK_50K, 103)
                )

                appWidgetManager.updateAppWidget(appWidgetId, views)
            }
        }
    }

    private fun getBroadcastPendingIntent(context: Context, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, QuickExpenseWidgetProvider::class.java).apply {
            this.action = action
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        val amount = when (intent.action) {
            ACTION_QUICK_10K -> 10000.0
            ACTION_QUICK_20K -> 20000.0
            ACTION_QUICK_50K -> 50000.0
            else -> 0.0
        }

        if (amount > 0) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = FinancialDatabase.getDatabase(context)
                val txDao = db.transactionDao()
                val budgetDao = db.budgetDao()
                val accountDao = db.accountDao()

                val accounts = accountDao.getAllAccountsSync()
                val targetAccount = accounts.find { it.name.contains("Dompet", ignoreCase = true) || it.name.contains("Cash", ignoreCase = true) || it.name.contains("Tunai", ignoreCase = true) } ?: accounts.firstOrNull()
                val targetAccountName = targetAccount?.name ?: "Dompet Tunai"

                val newTx = TransactionEntity(
                    title = "Cepat dari Widget (${(amount/1000).toInt()}k)",
                    amount = amount,
                    type = TransactionType.EXPENSE,
                    category = CategoryType.FOOD,
                    accountName = targetAccountName,
                    notes = "Dicatat langsung dari Home Screen Widget Financial Records",
                    dateTimestamp = System.currentTimeMillis()
                )
                txDao.insertTransaction(newTx)
                accountDao.updateBalance(targetAccountName, -amount)

                // Check budget limit
                val allTxs = txDao.getAllTransactionsSync()
                val totalExpense = allTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
                val overallBudget = budgetDao.getAllBudgetsSync().find { it.categoryName == "ALL" }?.monthlyLimitAmount ?: 5000000.0

                if (totalExpense >= overallBudget && overallBudget > 0) {
                    BudgetNotificationManager.triggerOverBudgetSoundAndNotification(context, totalExpense, overallBudget)
                }

                // Update Widget UI
                updateAllWidgets(context)
            }
        }
    }
}
