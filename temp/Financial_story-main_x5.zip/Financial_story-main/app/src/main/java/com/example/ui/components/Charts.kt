package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

enum class ChartType {
    PIE, BAR
}

data class BarChartEntry(val label: String, val amount: Double, val color: Color)
data class DonutChartEntry(val name: String, val amount: Double, val color: Color)

@Composable
fun SpendingReportInteractiveCard(
    categoryEntries: List<DonutChartEntry>,
    dailyEntries: List<BarChartEntry>,
    modifier: Modifier = Modifier
) {
    var selectedChartType by remember { mutableStateOf(ChartType.PIE) }
    val haptic = LocalHapticFeedback.current
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    BrutalistCard(
        backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
        borderColor = MaterialTheme.colorScheme.outline,
        modifier = modifier
    ) {
        // Card Header & Chart Switcher Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ANALISIS GRAFIK VISUAL",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (selectedChartType == ChartType.PIE) "Modus Pie / Lingkaran Kategori" else "Modus Grafik Batang Harian",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Mode Selector Toggle (Pie vs Bar)
            Row(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                    .border(2.dp, NeoBlack, RoundedCornerShape(10.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // Pie Option
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedChartType == ChartType.PIE) BentoElectricLime else Color.Transparent)
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            selectedChartType = ChartType.PIE
                        }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PieChart,
                            contentDescription = "Pie Chart",
                            tint = NeoBlack,
                            modifier = Modifier.size(16.dp)
                        )
                        Text("PIE", fontWeight = FontWeight.Black, fontSize = 11.sp, color = NeoBlack)
                    }
                }

                // Bar Option
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedChartType == ChartType.BAR) NeoCyan else Color.Transparent)
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            selectedChartType = ChartType.BAR
                        }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = "Bar Chart",
                            tint = NeoBlack,
                            modifier = Modifier.size(16.dp)
                        )
                        Text("BATANG", fontWeight = FontWeight.Black, fontSize = 11.sp, color = NeoBlack)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        when (selectedChartType) {
            ChartType.PIE -> {
                InteractiveDonutChart(entries = categoryEntries)
            }
            ChartType.BAR -> {
                InteractiveBarChart(entries = dailyEntries)
            }
        }
    }
}

@Composable
fun InteractiveBarChart(
    entries: List<BarChartEntry>,
    modifier: Modifier = Modifier,
    barColor: Color = NeoCyan
) {
    if (entries.isEmpty()) {
        Box(
            modifier = modifier.fillMaxWidth().height(180.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Belum ada data grafik", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    val haptic = LocalHapticFeedback.current
    var selectedEntryIndex by remember { mutableStateOf<Int?>(null) }
    val maxAmount = remember(entries) { entries.maxOfOrNull { it.amount }?.coerceAtLeast(1.0) ?: 1.0 }

    val animationProgress = remember { Animatable(0f) }
    LaunchedEffect(entries) {
        animationProgress.snapTo(0f)
        animationProgress.animateTo(1f, animationSpec = tween(700))
    }

    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    Column(modifier = modifier) {
        if (selectedEntryIndex != null && selectedEntryIndex!! in entries.indices) {
            val selected = entries[selectedEntryIndex!!]
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .background(NeoYellow, shape = RoundedCornerShape(6.dp))
                    .border(2.dp, NeoBlack, shape = RoundedCornerShape(6.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📅 TANGGAL: ${selected.label}",
                        fontWeight = FontWeight.ExtraBold,
                        color = NeoBlack,
                        fontSize = 12.sp
                    )
                    Text(
                        text = idrFormat.format(selected.amount),
                        fontWeight = FontWeight.ExtraBold,
                        color = NeoBlack,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .pointerInput(entries) {
                    detectTapGestures { tapOffset ->
                        val barWidth = size.width / entries.size
                        val index = (tapOffset.x / barWidth).toInt().coerceIn(0, entries.lastIndex)
                        selectedEntryIndex = index
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                }
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val barWidth = (canvasWidth / entries.size) * 0.65f
            val spacing = (canvasWidth / entries.size) * 0.35f

            entries.forEachIndexed { index, entry ->
                val barHeight = ((entry.amount / maxAmount) * (canvasHeight - 30.dp.toPx()) * animationProgress.value).toFloat()
                val left = index * (barWidth + spacing) + spacing / 2
                val top = canvasHeight - barHeight - 20.dp.toPx()

                val isSelected = selectedEntryIndex == index
                val currentBarColor = if (isSelected) NeoYellow else entry.color

                // Drop shadow for brutalist bar
                drawRect(
                    color = NeoBlack,
                    topLeft = Offset(left + 4f, top + 4f),
                    size = Size(barWidth, barHeight)
                )

                // Fill bar
                drawRect(
                    color = currentBarColor,
                    topLeft = Offset(left, top),
                    size = Size(barWidth, barHeight)
                )

                // Black outline
                drawRect(
                    color = NeoBlack,
                    topLeft = Offset(left, top),
                    size = Size(barWidth, barHeight),
                    style = Stroke(width = 3f)
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            entries.forEach { entry ->
                Text(
                    text = entry.label.take(5),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun InteractiveDonutChart(
    entries: List<DonutChartEntry>,
    modifier: Modifier = Modifier
) {
    if (entries.isEmpty()) {
        Box(
            modifier = modifier.fillMaxWidth().height(180.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Belum ada data pengeluaran", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    val haptic = LocalHapticFeedback.current
    val totalAmount = remember(entries) { entries.sumOf { it.amount }.coerceAtLeast(1.0) }
    var selectedSliceIndex by remember { mutableStateOf<Int?>(null) }

    val animationProgress = remember { Animatable(0f) }
    LaunchedEffect(entries) {
        animationProgress.snapTo(0f)
        animationProgress.animateTo(1f, animationSpec = tween(800))
    }

    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }

    Column(modifier = modifier) {
        if (selectedSliceIndex != null && selectedSliceIndex!! in entries.indices) {
            val selected = entries[selectedSliceIndex!!]
            val pct = ((selected.amount / totalAmount) * 100).toInt()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .background(BentoElectricLime, shape = RoundedCornerShape(6.dp))
                    .border(2.dp, NeoBlack, shape = RoundedCornerShape(6.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🎯 ${selected.name} ($pct%)",
                        fontWeight = FontWeight.ExtraBold,
                        color = NeoBlack,
                        fontSize = 12.sp
                    )
                    Text(
                        text = idrFormat.format(selected.amount),
                        fontWeight = FontWeight.ExtraBold,
                        color = NeoBlack,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(170.dp)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    var startAngle = -90f
                    val strokeWidthPx = 36.dp.toPx()

                    entries.forEachIndexed { index, entry ->
                        val sweepAngle = ((entry.amount / totalAmount) * 360f * animationProgress.value).toFloat()
                        val isSelected = selectedSliceIndex == index
                        val extraScale = if (isSelected) 8f else 0f

                        // Draw Slice Arc
                        drawArc(
                            color = entry.color,
                            startAngle = startAngle,
                            sweepAngle = sweepAngle,
                            useCenter = false,
                            style = Stroke(width = strokeWidthPx + extraScale)
                        )

                        // Draw Stroke Outer Arc for brutalism
                        drawArc(
                            color = NeoBlack,
                            startAngle = startAngle,
                            sweepAngle = sweepAngle,
                            useCenter = false,
                            style = Stroke(width = 3f)
                        )

                        startAngle += sweepAngle
                    }
                }

                // Center Text
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "TOTAL",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = idrFormat.format(totalAmount).take(11),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                entries.take(5).forEachIndexed { index, entry ->
                    val percent = ((entry.amount / totalAmount) * 100).toInt()
                    val isSelected = selectedSliceIndex == index

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (isSelected) NeoYellow else MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(6.dp)
                            )
                            .border(1.dp, NeoBlack, RoundedCornerShape(6.dp))
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                selectedSliceIndex = if (isSelected) null else index
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(entry.color, CircleShape)
                                .border(1.dp, NeoBlack, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = entry.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isSelected) NeoBlack else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "$percent%",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp,
                            color = if (isSelected) NeoBlack else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

