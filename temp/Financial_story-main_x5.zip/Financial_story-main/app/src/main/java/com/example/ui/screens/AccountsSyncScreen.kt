package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinancialUiState
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.*
import com.example.data.model.AccountType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsSyncScreen(
    uiState: FinancialUiState,
    onTriggerSync: () -> Unit,
    onDeleteAccount: (AccountEntity) -> Unit = {},
    onAddAccount: (name: String, accountNumber: String, type: AccountType, initialBalance: Double) -> Unit = { _, _, _, _ -> }
) {
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }
    var showAddAccountDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SINKRONISASI BANK & EWALLET",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 22.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Otomatisasi pencatatan dari BCA, Mandiri, GoPay, OVO & Dana",
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            BrutalistCard(
                backgroundColor = NeoYellow,
                borderColor = NeoBlack
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("AUTO-SYNC FEED ENGINE", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = NeoBlack)
                        Text("Status: Terhubung & Enkripsi E2EE", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NeoBlack)
                    }
                    Icon(Icons.Default.Sync, contentDescription = null, tint = NeoBlack, modifier = Modifier.size(28.dp))
                }

                Spacer(modifier = Modifier.height(12.dp))

                BrutalistButton(
                    onClick = onTriggerSync,
                    backgroundColor = NeoCyan,
                    textColor = NeoBlack,
                    text = if (uiState.isAutoSyncing) "MENYSINKRONKAN API..." else "⚡ TARIK TRANSAKSI BARU SEKARANG",
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DAFTAR AKUN TERHUBUNG (${uiState.accounts.size})",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )

                IconButton(
                    onClick = { showAddAccountDialog = true },
                    modifier = Modifier
                        .background(BentoElectricLime, RoundedCornerShape(8.dp))
                        .border(1.5.dp, NeoBlack, RoundedCornerShape(8.dp))
                        .size(32.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah Akun", tint = NeoBlack)
                }
            }
        }

        if (uiState.accounts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Belum ada akun. Klik + untuk menambah akun baru.",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(uiState.accounts, key = { it.accountId }) { acc ->
                AccountItemCard(account = acc, onDelete = { onDeleteAccount(acc) })
            }
        }
    }

    if (showAddAccountDialog) {
        var accName by remember { mutableStateOf("") }
        var accNum by remember { mutableStateOf("") }
        var accBalanceText by remember { mutableStateOf("") }
        var selectedType by remember { mutableStateOf(AccountType.BANK) }

        AlertDialog(
            onDismissRequest = { showAddAccountDialog = false },
            title = { Text("Tambah Akun Baru", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = accName,
                        onValueChange = { accName = it },
                        label = { Text("Nama Akun / Bank / E-Wallet") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = accNum,
                        onValueChange = { accNum = it },
                        label = { Text("Nomor Rekening / HP") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = accBalanceText,
                        onValueChange = { accBalanceText = it },
                        label = { Text("Saldo Awal (IDR)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                BrutalistButton(
                    onClick = {
                        val bal = accBalanceText.toDoubleOrNull() ?: 0.0
                        if (accName.isNotBlank()) {
                            onAddAccount(accName, accNum.ifBlank { "Saku" }, selectedType, bal)
                            showAddAccountDialog = false
                        }
                    },
                    backgroundColor = BentoElectricLime,
                    textColor = NeoBlack,
                    text = "SIMPAN AKUN"
                )
            },
            dismissButton = {
                TextButton(onClick = { showAddAccountDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun AccountItemCard(
    account: AccountEntity,
    onDelete: () -> Unit = {}
) {
    val idrFormat = remember { NumberFormat.getCurrencyInstance(Locale("id", "ID")) }
    val lastSyncStr = remember(account.lastSyncedTimestamp) {
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(account.lastSyncedTimestamp))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
            .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = account.name,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Box(
                        modifier = Modifier
                            .background(NeoLime, RoundedCornerShape(4.dp))
                            .border(1.dp, NeoBlack, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("LINKED", fontWeight = FontWeight.ExtraBold, fontSize = 9.sp, color = NeoBlack)
                    }
                }

                Text(
                    text = "No. Rek/HP: ${account.accountNumber} • Sync: $lastSyncStr",
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = idrFormat.format(account.balance),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Hapus Akun",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}
