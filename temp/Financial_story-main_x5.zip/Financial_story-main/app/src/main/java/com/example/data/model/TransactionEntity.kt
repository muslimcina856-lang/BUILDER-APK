package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    EXPENSE,
    INCOME,
    TRANSFER
}

enum class CategoryType(val label: String, val iconName: String) {
    FOOD("Makanan & Minuman", "restaurant"),
    TRANSPORT("Transportasi", "directions_car"),
    SHOPPING("Belanja", "shopping_bag"),
    BILLS("Tagihan & Utilitas", "receipt_long"),
    ENTERTAINMENT("Hiburan & Gaya Hidup", "sports_esports"),
    HEALTH("Kesehatan", "medical_services"),
    SALARY("Gaji & Pendapatan", "payments"),
    INVESTMENT("Investasi & Tabungan", "trending_up"),
    TRANSFER("Transfer Bank / E-Wallet", "swap_horiz"),
    OTHER("Lain-Lain", "more_horiz")
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val category: CategoryType,
    val accountName: String, // e.g. "Bank BCA", "GoPay", "Tunai"
    val dateTimestamp: Long = System.currentTimeMillis(),
    val notes: String = "",
    val isAutoSynced: Boolean = false,
    val encryptedPayloadHash: String = "" // E2EE verification hash
)
