package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NeoDarkColorScheme = darkColorScheme(
    primary = NeoYellow,
    onPrimary = NeoBlack,
    primaryContainer = NeoLime,
    onPrimaryContainer = NeoBlack,
    secondary = NeoCyan,
    onSecondary = NeoBlack,
    tertiary = NeoPink,
    onTertiary = NeoWhite,
    background = NeoDarkBackground,
    onBackground = NeoWhite,
    surface = NeoDarkSurface,
    onSurface = NeoWhite,
    surfaceVariant = NeoDarkCard,
    onSurfaceVariant = NeoWhite,
    outline = NeoDarkBorder,
    error = NeoRedAlert,
    onError = NeoWhite
)

private val NeoLightColorScheme = lightColorScheme(
    primary = NeoYellow,
    onPrimary = NeoBlack,
    primaryContainer = NeoLime,
    onPrimaryContainer = NeoBlack,
    secondary = NeoCyan,
    onSecondary = NeoBlack,
    tertiary = NeoPink,
    onTertiary = NeoWhite,
    background = NeoLightBackground,
    onBackground = NeoBlack,
    surface = NeoLightSurface,
    onSurface = NeoBlack,
    surfaceVariant = NeoLightCard,
    onSurfaceVariant = NeoBlack,
    outline = NeoBlack,
    error = NeoRedAlert,
    onError = NeoWhite
)

@Composable
fun FinBrutalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NeoDarkColorScheme else NeoLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

