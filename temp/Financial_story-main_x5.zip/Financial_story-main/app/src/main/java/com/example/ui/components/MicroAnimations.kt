package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeoBlack
import com.example.ui.theme.NeoLime
import com.example.ui.theme.NeoRedAlert
import com.example.ui.theme.NeoYellow
import java.text.NumberFormat
import java.util.Locale

@Composable
fun AnimatedAmountText(
    amount: Double,
    prefix: String = "Rp ",
    modifier: Modifier = Modifier,
    color: Color = NeoBlack,
    fontSize: Int = 26
) {
    val animatedAmount by animateFloatAsState(
        targetValue = amount.toFloat(),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "amount_anim"
    )

    val formatter = remember { NumberFormat.getNumberInstance(Locale("id", "ID")) }
    val formattedString = formatter.format(animatedAmount.toDouble().coerceAtLeast(0.0))

    Text(
        text = "$prefix$formattedString",
        modifier = modifier,
        color = color,
        fontWeight = FontWeight.ExtraBold,
        fontSize = fontSize.sp,
        letterSpacing = (-0.5).sp
    )
}

@Composable
fun TransactionSuccessPopBanner(
    message: String,
    isVisible: Boolean,
    onDismiss: () -> Unit
) {
    LaunchedEffect(isVisible) {
        if (isVisible) {
            kotlinx.coroutines.delay(2800)
            onDismiss()
        }
    }

    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn() + expandVertically(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut()
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "banner_bounce")
        val rotation by infiniteTransition.animateFloat(
            initialValue = -1.5f,
            targetValue = 1.5f,
            animationSpec = infiniteRepeatable(
                animation = tween(150, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "shake"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .rotate(rotation)
                .background(NeoLime, shape = RoundedCornerShape(8.dp))
                .border(3.dp, NeoBlack, shape = RoundedCornerShape(8.dp))
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = NeoBlack,
                    modifier = Modifier.size(32.dp)
                )
                Column {
                    Text(
                        text = "BERHASIL!",
                        fontWeight = FontWeight.ExtraBold,
                        color = NeoBlack,
                        fontSize = 16.sp
                    )
                    Text(
                        text = message,
                        fontWeight = FontWeight.Bold,
                        color = NeoBlack,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun BudgetAlertBanner(
    warningMessage: String,
    isVisible: Boolean,
    onDismiss: () -> Unit
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
    ) {
        val infiniteScale = rememberInfiniteTransition(label = "alert_pulse")
        val pulseScale by infiniteScale.animateFloat(
            initialValue = 0.98f,
            targetValue = 1.02f,
            animationSpec = infiniteRepeatable(
                animation = tween(400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .scale(pulseScale)
                .background(NeoRedAlert, shape = RoundedCornerShape(8.dp))
                .border(3.dp, NeoBlack, shape = RoundedCornerShape(8.dp))
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Peringatan",
                    tint = NeoYellow,
                    modifier = Modifier.size(32.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "PERINGATAN ANGGARAN!",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = warningMessage,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
                BrutalistButton(
                    onClick = onDismiss,
                    backgroundColor = NeoYellow,
                    textColor = NeoBlack,
                    shadowOffset = 2.dp,
                    text = "OK"
                )
            }
        }
    }
}
