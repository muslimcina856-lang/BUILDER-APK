package com.example.data.currency

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class ExchangeRateResult(
    val baseCode: String = "USD",
    val rates: Map<String, Double>,
    val lastUpdatedText: String,
    val isLive: Boolean
)

object CurrencyExchangeRepository {

    private const val TAG = "CurrencyExchangeRepository"
    private const val API_URL = "https://open.er-api.com/v6/latest/USD"

    // Default fallback rates relative to 1 USD
    private val DEFAULT_FALLBACK_RATES = mapOf(
        "USD" to 1.0,
        "IDR" to 16250.0,
        "EUR" to 0.92,
        "JPY" to 155.0,
        "SGD" to 1.35,
        "MYR" to 4.68,
        "GBP" to 0.78,
        "AUD" to 1.52,
        "CNY" to 7.25,
        "KRW" to 1380.0,
        "SAR" to 3.75
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun fetchLiveExchangeRates(): ExchangeRateResult = withContext(Dispatchers.IO) {
        val currentTimeStr = SimpleDateFormat("HH:mm:ss 'WIB'", Locale.getDefault()).format(Date())

        try {
            val request = Request.Builder()
                .url(API_URL)
                .header("User-Agent", "FinBrutal/1.0")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBody = response.body?.string() ?: ""
                    val json = JSONObject(responseBody)
                    val result = json.optString("result", "")

                    if (result.equals("success", ignoreCase = true) || json.has("rates")) {
                        val ratesObj = json.optJSONObject("rates")
                        if (ratesObj != null) {
                            val ratesMap = mutableMapOf<String, Double>()
                            ratesMap["USD"] = 1.0

                            for (currency in CurrencyData.SUPPORTED_CURRENCIES) {
                                val code = currency.code
                                if (ratesObj.has(code)) {
                                    ratesMap[code] = ratesObj.getDouble(code)
                                } else {
                                    ratesMap[code] = DEFAULT_FALLBACK_RATES[code] ?: 1.0
                                }
                            }

                            Log.d(TAG, "Successfully fetched live rates from Open Exchange Rates API")
                            return@withContext ExchangeRateResult(
                                baseCode = "USD",
                                rates = ratesMap,
                                lastUpdatedText = "Update Live: $currentTimeStr",
                                isLive = true
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch live exchange rates, using fallback rates", e)
        }

        // Fallback result
        ExchangeRateResult(
            baseCode = "USD",
            rates = DEFAULT_FALLBACK_RATES,
            lastUpdatedText = "Offline Mode ($currentTimeStr)",
            isLive = false
        )
    }
}
