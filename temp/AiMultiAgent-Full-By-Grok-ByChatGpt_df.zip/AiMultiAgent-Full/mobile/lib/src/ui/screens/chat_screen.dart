import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'package:markdown/markdown.dart' as md;
import 'package:just_audio/just_audio.dart';
import 'package:archive/archive.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:speech_to_text/speech_to_text.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../app.dart';
import '../../config/app_config.dart';
import '../../models/app_models.dart';
import '../../services/media_export_service.dart';
import '../../services/terminal_service.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import 'skills_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _composer = TextEditingController();
  final _scroll = ScrollController();
  final _speech = SpeechToText();

  bool _listening = false;
  int _lastMessageCount = 0;
  int _lastEventCount = 0;
  // Jangan paksa scroll ke bawah semasa berfikir jika pengguna sedang baca atas.
  bool _nearBottom = true;
  bool _showJumpDown = false;
  int _composerLen = 0;
  bool _handlingPaste = false;
  ChatMessage? _editingMessage;
  final _editComposer = TextEditingController();
  final List<ChatAttachment> _editAttachments = <ChatAttachment>[];

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _composer.addListener(_onComposerChanged);
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _composer.removeListener(_onComposerChanged);
    _composer.dispose();
    _editComposer.dispose();
    _scroll.dispose();
    _speech.stop();
    super.dispose();
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final pos = _scroll.position;
    final near = pos.pixels >= pos.maxScrollExtent - 120;
    if (near != _nearBottom || (!near) != _showJumpDown) {
      setState(() {
        _nearBottom = near;
        _showJumpDown = !near;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    if (state.messages.length != _lastMessageCount ||
        state.activeRunEvents.length != _lastEventCount) {
      _lastMessageCount = state.messages.length;
      _lastEventCount = state.activeRunEvents.length;
      // Hanya auto-turun jika pengguna memang di bahagian bawah.
      if (_nearBottom) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _scrollToBottom();
        });
      } else if (!_showJumpDown) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) setState(() => _showJumpDown = true);
        });
      }
    }

    return SafeArea(
      child: Column(
        children: <Widget>[
          _ChatHeader(
            provider: state.selectedProvider,
            onTapModel: () => _showProviderModelPicker(context),
            onNewSession: () => state.newSession(reason: 'Sesi baharu dimulakan.'),
          ),
          Expanded(
            child: Stack(
              children: <Widget>[
                CustomScrollView(
                  controller: _scroll,
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  slivers: <Widget>[
                    if (state.messages.isEmpty)
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: _EmptyChat(
                          hasProvider: state.hasProvider,
                          sessionNotice: state.sessionNotice,
                          onOpenProvider: () => state.selectTab(1),
                          onSuggestion: (value) {
                            _composer.text = value;
                            _composer.selection = TextSelection.collapsed(
                              offset: value.length,
                            );
                          },
                        ),
                      )
                    else
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                        sliver: SliverList.separated(
                          itemCount: state.messages.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 14),
                          itemBuilder: (context, index) => _MessageCard(
                            key: ValueKey<String>(state.messages[index].id),
                            message: state.messages[index],
                            onEditUser: state.messages[index].role ==
                                    MessageRole.user
                                ? () => _editUserMessage(
                                      context,
                                      state.messages[index],
                                    )
                                : null,
                          ),
                        ),
                      ),
                    if (state.isSending && !state.isWritingFinalAnswer)
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(14, 2, 14, 8),
                        sliver: SliverToBoxAdapter(
                          child: _LiveProcessCard(
                            events: state.activeRunEvents,
                            detail: state.runDetail,
                            followUpCount: state.followUpQueue.length,
                            startedAt: state.runStartedAt,
                          ),
                        ),
                      ),
                    // Konsol per **mesej/turn**: job turn ini sahaja.
                    // Turn baru → terminalScopeStartedAt baru → konsol chat sebelum hilang.
                    if (state.isSending ||
                        TerminalService().jobs.any((j) =>
                            j.running &&
                            state.terminalScopeStartedAt != null &&
                            !j.startedAt
                                .isBefore(state.terminalScopeStartedAt!)))
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 18),
                        sliver: SliverToBoxAdapter(
                          child: _LiveTerminalConsole(
                            sessionStartedAt: state.terminalScopeStartedAt,
                          ),
                        ),
                      ),
                    const SliverToBoxAdapter(child: SizedBox(height: 8)),
                  ],
                ),
                if (_showJumpDown)
                  Positioned(
                    right: 14,
                    bottom: 12,
                    child: Material(
                      color: const Color(0xEE1A2230),
                      elevation: 4,
                      shape: const CircleBorder(),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: () {
                          _scrollToBottom();
                          setState(() {
                            _nearBottom = true;
                            _showJumpDown = false;
                          });
                        },
                        child: const SizedBox(
                          width: 42,
                          height: 42,
                          child: Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: Colors.white,
                            size: 26,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (_editingMessage != null)
            _EditMessagePanel(
              controller: _editComposer,
              attachments: _editAttachments,
              onClose: _cancelEdit,
              onAttach: () => _pickEditAttachments(context),
              onRemoveAttachment: (item) {
                setState(() => _editAttachments.removeWhere((a) => a.id == item.id));
              },
              onSend: () => _commitEdit(context),
            )
          else
            _Composer(
              controller: _composer,
              attachments: state.pendingAttachments,
              listening: _listening,
              sending: state.isSending,
              onAttach: () => _pickAttachments(context),
              onRemoveAttachment: state.removePendingAttachment,
              onVoice: _toggleListening,
              onSend: () => _submit(context),
              onStop: state.stopCurrentRun,
            ),
        ],
      ),
    );
  }

  Future<void> _pickAttachments(BuildContext context) async {
    try {
      await AppScope.read(context).pickAttachments();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    }
  }

  String _composerSnapshot = '';
  Future<void>? _pendingPasteImport;

  String _insertedChunk(String prev, String next) {
    if (prev.isEmpty) return next;
    if (next.startsWith(prev)) return next.substring(prev.length);
    if (next.endsWith(prev)) {
      return next.substring(0, next.length - prev.length);
    }
    var i = 0;
    while (i < prev.length && i < next.length && prev.codeUnitAt(i) == next.codeUnitAt(i)) {
      i++;
    }
    var j = 0;
    while (j < prev.length - i &&
        j < next.length - i &&
        prev.codeUnitAt(prev.length - 1 - j) == next.codeUnitAt(next.length - 1 - j)) {
      j++;
    }
    final end = next.length - j;
    if (end <= i) return next;
    return next.substring(i, end);
  }

  void _onComposerChanged() {
    if (_handlingPaste) return;
    final text = _composer.text;
    final prev = _composerSnapshot;
    final grew = text.length - prev.length;
    _composerLen = text.length;
    if (grew < 240) {
      _composerSnapshot = text;
      return;
    }
    final inserted = _insertedChunk(prev, text).trim();
    final long = inserted.length > 480 || '\n'.allMatches(inserted).length > 8;
    if (!long) {
      _composerSnapshot = text;
      return;
    }
    _handlingPaste = true;
    _composer.value = TextEditingValue(
      text: prev,
      selection: TextSelection.collapsed(offset: prev.length),
    );
    _composerSnapshot = prev;
    _composerLen = prev.length;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final operation = _importLongPaste(inserted);
      _pendingPasteImport = operation;
      operation.whenComplete(() {
        if (_pendingPasteImport == operation) _pendingPasteImport = null;
      });
    });
  }

  Future<void> _importLongPaste(String inserted) async {
    try {
      await AppScope.read(context).addPastedText(inserted);
    } catch (_) {
      // Jika import lampiran gagal, pulangkan teks paste ke composer supaya
      // kandungan pengguna tidak hilang. Kekalkan teks yang ditaip selepas paste.
      if (mounted) {
        final current = _composer.value;
        final offset = current.selection.isValid
            ? current.selection.end.clamp(0, current.text.length).toInt()
            : current.text.length;
        final recovered = current.text.replaceRange(offset, offset, inserted);
        _composer.value = TextEditingValue(
          text: recovered,
          selection: TextSelection.collapsed(offset: offset + inserted.length),
        );
      }
    } finally {
      if (mounted) {
        _handlingPaste = false;
        _composerSnapshot = _composer.text;
        _composerLen = _composer.text.length;
      }
    }
  }

  Future<void> _submit(BuildContext context) async {
    final pendingPaste = _pendingPasteImport;
    if (pendingPaste != null) await pendingPaste;
    if (!mounted) return;
    final state = AppScope.read(context);
    var text = _composer.text;
    if (text.trim().isEmpty && state.pendingAttachments.isEmpty) return;
    // Jangan campur isi paste ke teks nampak. Model baca fail lampiran.
    _composer.clear();
    _composerLen = 0;
    _composerSnapshot = '';
    await state.sendMessage(text);
  }

  void _cancelEdit() {
    setState(() {
      _editingMessage = null;
      _editComposer.clear();
      _editAttachments.clear();
    });
  }

  Future<void> _pickEditAttachments(BuildContext context) async {
    try {
      final state = AppScope.read(context);
      final imported = await state.attachmentService.pickAndImport(state.sessionId);
      if (!mounted || imported.isEmpty) return;
      setState(() => _editAttachments.addAll(imported));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    }
  }

  Future<void> _commitEdit(BuildContext context) async {
    final original = _editingMessage;
    if (original == null) return;
    final text = _editComposer.text;
    final files = List<ChatAttachment>.from(_editAttachments);
    if (text.trim().isEmpty && files.isEmpty) return;
    _cancelEdit();
    await AppScope.read(context).commitEditedUserMessage(
      original: original,
      text: text,
      attachments: files,
    );
  }

  Future<void> _editUserMessage(
    BuildContext context,
    ChatMessage message,
  ) async {
    setState(() {
      _editingMessage = message;
      _editComposer.value = TextEditingValue(
        text: message.content,
        selection: TextSelection.collapsed(offset: message.content.length),
      );
      _editAttachments
        ..clear()
        ..addAll(message.attachments);
    });
  }

  Future<void> _toggleListening() async {
    if (_listening) {
      await _speech.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    final ready = await _speech.initialize(
      onError: (_) {
        if (mounted) setState(() => _listening = false);
      },
      onStatus: (status) {
        if (mounted && status == 'notListening') {
          setState(() => _listening = false);
        }
      },
    );
    if (!ready) return;
    if (mounted) setState(() => _listening = true);
    await _speech.listen(
      localeId: 'ms_MY',
      partialResults: true,
      onResult: (result) {
        _composer.text = result.recognizedWords;
        _composer.selection = TextSelection.collapsed(
          offset: _composer.text.length,
        );
        if (result.finalResult && mounted) {
          setState(() => _listening = false);
        }
      },
    );
  }

  Future<void> _showProviderModelPicker(BuildContext context) async {
    final state = AppScope.read(context);
    if (state.providers.isEmpty) {
      state.selectTab(1);
      return;
    }
    final selection = await showModalBottomSheet<_ProviderModelSelection>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: AppTheme.surface,
      builder: (_) => _ProviderModelSheet(state: state),
    );
    if (selection == null) return;
    // Tunggu route bottom sheet selesai dinyahaktif sebelum state global
    // memberitahu seluruh aplikasi. Ini mengelakkan dependent inherited widget
    // tertinggal semasa animasi penutupan route.
    await WidgetsBinding.instance.endOfFrame;

    final provider = state.providers.firstWhere(
      (item) => item.id == selection.providerId,
      orElse: () => state.providers.first,
    );
    final models = <String>{
      ...selection.models,
      selection.model,
    }.toList();
    await state.saveProvider(
      provider.copyWith(
        model: selection.model,
        availableModels: models,
        updatedAt: DateTime.now(),
      ),
    );
    await state.selectProvider(provider.id);
  }

  void _scrollToBottom() {
    if (!_scroll.hasClients) return;
    _scroll.animateTo(
      _scroll.position.maxScrollExtent,
      duration: const Duration(milliseconds: 340),
      curve: Curves.easeOutCubic,
    );
  }
}

class _ProviderModelSelection {
  const _ProviderModelSelection({
    required this.providerId,
    required this.model,
    required this.models,
  });

  final String providerId;
  final String model;
  final List<String> models;
}

class _ProviderModelSheet extends StatefulWidget {
  const _ProviderModelSheet({required this.state});

  final AppState state;

  @override
  State<_ProviderModelSheet> createState() => _ProviderModelSheetState();
}

class _ProviderModelSheetState extends State<_ProviderModelSheet> {
  late String _providerId;
  final TextEditingController _manual = TextEditingController();
  List<String> _models = const <String>[];
  late String _selectedModel;
  bool _loading = false;
  String _status = '';

  AppState get appState => widget.state;

  ProviderConfig get _provider => appState.providers.firstWhere(
        (item) => item.id == _providerId,
        orElse: () => appState.providers.first,
      );

  @override
  void initState() {
    super.initState();
    _providerId = appState.selectedProviderId.isEmpty
        ? appState.providers.first.id
        : appState.selectedProviderId;
    _models = appState.chatModelsFor(_provider);
    _selectedModel = _provider.model;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _refresh();
    });
  }

  @override
  void dispose() {
    _manual.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    if (_loading || !mounted) return;
    final provider = _provider;
    setState(() {
      _loading = true;
      _status = 'Menyemak model terus daripada provider…';
    });
    try {
      final key = await appState.providerKey(provider.id);
      if (provider.authStyle != AuthStyle.none && key.isEmpty) {
        if (!mounted) return;
        setState(() {
          _models = appState.chatModelsFor(provider);
          _status = 'API key belum disimpan. Menggunakan senarai local.';
        });
        return;
      }
      final live = await appState.refreshModels(provider, key);
      if (!mounted) return;
      var nextModel = _selectedModel;
      if (live.isNotEmpty && !live.contains(nextModel)) {
        nextModel = live.first;
      }
      if (!mounted) return;
      setState(() {
        _models = live.isEmpty ? appState.chatModelsFor(provider) : live;
        _selectedModel = nextModel;
        _status = live.isEmpty
            ? 'Provider tidak memulangkan senarai model chat.'
            : '${live.length} model chat disahkan · ${nextModel.isEmpty ? 'pilih satu' : nextModel}';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _models = appState.chatModelsFor(provider);
        _status = 'Gagal menyegar: $error';
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _changeProvider(String value) async {
    if (value == _providerId || !mounted) return;
    setState(() {
      _providerId = value;
      _models = appState.chatModelsFor(_provider);
      _selectedModel = _provider.model;
      _status = '';
      _manual.clear();
    });
    await _refresh();
  }

  void _selectModel(String model) {
    final value = model.trim();
    if (value.isEmpty) return;
    Navigator.of(context).pop(
      _ProviderModelSelection(
        providerId: _providerId,
        model: value,
        models: List<String>.from(_models),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = _provider;
    final selectedModel = _selectedModel;
    return FractionallySizedBox(
      heightFactor: .86,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          18,
          8,
          18,
          MediaQuery.viewInsetsOf(context).bottom + 18,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: Container(
                width: 42,
                height: 4,
                decoration: BoxDecoration(
                  color: AppTheme.outline,
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: <Widget>[
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Provider & model',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'Senarai model disahkan terus daripada provider.',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton.filledTonal(
                  tooltip: 'Segarkan model',
                  onPressed: _loading ? null : _refresh,
                  icon: _loading
                      ? const SizedBox.square(
                          dimension: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.refresh_rounded),
                ),
              ],
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              key: ValueKey<String>(_providerId),
              initialValue: _providerId,
              decoration: const InputDecoration(
                labelText: 'Provider',
                prefixIcon: Icon(Icons.key_rounded),
              ),
              isExpanded: true,
              items: appState.providers
                  .map(
                    (item) => DropdownMenuItem<String>(
                      value: item.id,
                      child: Text(
                        item.name,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  )
                  .toList(),
              onChanged: _loading
                  ? null
                  : (value) {
                      if (value != null) _changeProvider(value);
                    },
            ),
            if (_status.isNotEmpty) ...<Widget>[
              const SizedBox(height: 10),
              Text(
                _status,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: _status.startsWith('Gagal')
                      ? AppTheme.danger
                      : AppTheme.textSecondary,
                  fontSize: 12.5,
                  height: 1.35,
                ),
              ),
            ],
            const SizedBox(height: 12),
            Expanded(
              child: _models.isEmpty
                  ? Center(
                      child: Text(
                        _loading
                            ? 'Mendapatkan model…'
                            : 'Tiada model chat dikesan. Masukkan Model ID manual.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: AppTheme.textSecondary),
                      ),
                    )
                  : ListView.separated(
                      itemCount: _models.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 7),
                      itemBuilder: (context, index) {
                        final model = _models[index];
                        final selected = model == selectedModel;
                        return Material(
                          color: selected
                              ? AppTheme.purple.withValues(alpha: .12)
                              : AppTheme.surfaceHigh,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(
                              color: selected
                                  ? AppTheme.purpleLight
                                  : AppTheme.outline,
                            ),
                          ),
                          child: ListTile(
                            leading: Icon(
                              selected
                                  ? Icons.check_circle_rounded
                                  : Icons.circle_outlined,
                              color: selected
                                  ? AppTheme.purpleLight
                                  : AppTheme.textSecondary,
                            ),
                            title: Text(
                              model,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onTap: () => _selectModel(model),
                          ),
                        );
                      },
                    ),
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _manual,
                    textInputAction: TextInputAction.done,
                    decoration: const InputDecoration(
                      labelText: 'Model ID manual',
                      hintText: 'model-id',
                    ),
                    onSubmitted: _selectModel,
                  ),
                ),
                const SizedBox(width: 10),
                IconButton.filled(
                  tooltip: 'Gunakan model manual',
                  onPressed: () => _selectModel(_manual.text),
                  icon: const Icon(Icons.arrow_forward_rounded),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ChatHeader extends StatelessWidget {
  const _ChatHeader({
    required this.provider,
    required this.onTapModel,
    required this.onNewSession,
  });

  final ProviderConfig? provider;
  final VoidCallback onTapModel;
  final VoidCallback onNewSession;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 10, 8),
      child: Row(
        children: <Widget>[
          Container(
            width: 46,
            height: 46,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              gradient: const LinearGradient(
                colors: <Color>[Color(0xFF332653), Color(0xFF141728)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: AppTheme.purple.withValues(alpha: .18),
                  blurRadius: 22,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                AppConfig.iconAsset,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: onTapModel,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      'Ai MultiAgent',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -.35,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            provider == null
                                ? 'Pilih provider & model'
                                : '${provider!.name} · ${provider!.model.isEmpty ? 'pilih model' : provider!.model}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 13,
                            ),
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          size: 17,
                          color: AppTheme.textSecondary,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Sesi baharu',
            onPressed: onNewSession,
            icon: const Icon(Icons.add_comment_outlined),
          ),
        ],
      ),
    );
  }
}

class _EmptyChat extends StatelessWidget {
  const _EmptyChat({
    required this.hasProvider,
    required this.sessionNotice,
    required this.onOpenProvider,
    required this.onSuggestion,
  });

  final bool hasProvider;
  final String sessionNotice;
  final VoidCallback onOpenProvider;
  final ValueChanged<String> onSuggestion;

  @override
  Widget build(BuildContext context) {
    final suggestions = <(IconData, String, String)>[
      (
        Icons.travel_explore_rounded,
        'Selidik web',
        'Cari maklumat terkini dan ringkaskan sumber penting.',
      ),
      (
        Icons.download_rounded,
        'Proses pautan',
        'Buka pautan ini di browser latar, analisis kandungan dan berikan hasil.',
      ),
      (
        Icons.description_outlined,
        'Analisis fail',
        'Analisis fail yang saya lampirkan dan sediakan ringkasan teratur.',
      ),
      (
        Icons.auto_awesome_rounded,
        'Bina skill',
        'Cipta satu skill local yang boleh membantu tugasan berulang ini.',
      ),
    ];
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                width: 78,
                height: 78,
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFF40306A), Color(0xFF111522)],
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.purple.withValues(alpha: .22),
                      blurRadius: 34,
                      offset: const Offset(0, 12),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(21),
                  child: Image.asset(
                    AppConfig.iconAsset,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Apa yang mahu diselesaikan?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.55,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Satu model utama menyelaras carian, browser latar, fail, terminal, skills dan sub-agent secara automatik.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppTheme.textSecondary,
                  height: 1.5,
                ),
              ),
              if (sessionNotice.isNotEmpty) ...<Widget>[
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 13,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceHigh,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    sessionNotice,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
              if (!hasProvider) ...<Widget>[
                const SizedBox(height: 18),
                FilledButton.icon(
                  onPressed: onOpenProvider,
                  icon: const Icon(Icons.key_rounded),
                  label: const Text('Tambah provider'),
                ),
              ],
              const SizedBox(height: 24),
              LayoutBuilder(
                builder: (context, constraints) {
                  final oneColumn = constraints.maxWidth < 500;
                  final width = oneColumn
                      ? constraints.maxWidth
                      : (constraints.maxWidth - 10) / 2;
                  return Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: suggestions
                        .map(
                          (item) => SizedBox(
                            width: width,
                            child: _SuggestionCard(
                              icon: item.$1,
                              title: item.$2,
                              prompt: item.$3,
                              onTap: () => onSuggestion(item.$3),
                            ),
                          ),
                        )
                        .toList(),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  const _SuggestionCard({
    required this.icon,
    required this.title,
    required this.prompt,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String prompt;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: Color(0xFF202638)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: <Widget>[
              Container(
                width: 39,
                height: 39,
                decoration: BoxDecoration(
                  color: AppTheme.purple.withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(icon, size: 20, color: AppTheme.purpleLight),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      prompt,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({
    required this.message,
    this.onEditUser,
    super.key,
  });

  final ChatMessage message;
  final VoidCallback? onEditUser;

  @override
  Widget build(BuildContext context) {
    if (message.role == MessageRole.tool ||
        message.role == MessageRole.system) {
      return const SizedBox.shrink();
    }
    final isUser = message.role == MessageRole.user;
    final maxWidth = MediaQuery.sizeOf(context).width * (isUser ? .84 : .94);
    final isFailedMessage = message.metadata['failed'] == true;
    final processEvents = message.runEvents.where((event) {
      final title = event.title.toLowerCase();
      if (!isFailedMessage && event.state == RunEventState.failed) {
        return false;
      }
      return !title.contains('memahami') &&
          !title.contains('menyusun') &&
          title != 'berfikir';
    }).toList(growable: false);
    final durationMs = (message.metadata['durationMs'] as num?)?.toInt();
    final messageBody = Padding(
      padding: EdgeInsets.fromLTRB(
        isUser ? 15 : 2,
        isUser ? 14 : 2,
        isUser ? 15 : 2,
        isUser ? 13 : 4,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (!isUser && processEvents.isNotEmpty) ...<Widget>[
            _CompletedProcessCard(
              events: processEvents,
              durationMs: durationMs,
            ),
            const SizedBox(height: 8),
          ],
          if (message.attachments.where((a) =>
                  !(isUser &&
                      a.kind == AttachmentKind.document &&
                      a.name.toLowerCase().contains('pasted')))
              .isNotEmpty)
            _AttachmentGrid(
              attachments: message.attachments
                  .where((a) =>
                      !(isUser &&
                          a.kind == AttachmentKind.document &&
                          a.name.toLowerCase().contains('pasted')))
                  .toList(),
              compact: isUser,
            ),
          if (message.attachments.isNotEmpty &&
              message.content.trim().isNotEmpty)
            const SizedBox(height: 10),
          if (message.content.trim().isNotEmpty)
            if (isUser)
              _UserPromptBody(
                text: message.content,
                attachments: message.attachments,
              )
            else
              _RichChatContent(data: message.content),
          if (!isUser && message.content.trim().isNotEmpty)
            _MessageCopyBar(text: message.content),
          if (message.artifacts.isNotEmpty) ...<Widget>[
            if (message.content.trim().isNotEmpty)
              const SizedBox(height: 14),
            _ArtifactList(artifacts: message.artifacts),
          ],
        ],
      ),
    );
    final bubble = isUser
        ? DecoratedBox(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: <Color>[Color(0xFF7650EC), Color(0xFF9256FF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(21),
                topRight: Radius.circular(21),
                bottomLeft: Radius.circular(21),
                bottomRight: Radius.circular(7),
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.black.withValues(alpha: .1),
                  blurRadius: 18,
                  offset: const Offset(0, 7),
                ),
              ],
            ),
            child: messageBody,
          )
        : messageBody;

    if (isUser) {
      return _UserMessageShell(
        maxWidth: maxWidth,
        bubble: bubble,
        copyText: message.content,
        onEdit: onEditUser,
      );
    }
    return Align(
      alignment: Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: maxWidth.clamp(280.0, 760.0).toDouble(),
        ),
        child: bubble,
      ),
    );
  }
}

class _UserMessageShell extends StatefulWidget {
  const _UserMessageShell({
    required this.maxWidth,
    required this.bubble,
    required this.copyText,
    this.onEdit,
  });

  final double maxWidth;
  final Widget bubble;
  final String copyText;
  final VoidCallback? onEdit;

  @override
  State<_UserMessageShell> createState() => _UserMessageShellState();
}

class _UserMessageShellState extends State<_UserMessageShell> {
  bool _showActions = false;

  void _toggle() => setState(() => _showActions = !_showActions);

  void _hide() {
    if (_showActions) setState(() => _showActions = false);
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: widget.maxWidth.clamp(280.0, 760.0).toDouble(),
        ),
        child: TapRegion(
          onTapOutside: (_) => _hide(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              GestureDetector(
                onTap: _toggle,
                onLongPress: _toggle,
                behavior: HitTestBehavior.translucent,
                child: widget.bubble,
              ),
              AnimatedSize(
                duration: const Duration(milliseconds: 180),
                curve: Curves.easeOutCubic,
                alignment: Alignment.topRight,
                child: _showActions
                    ? Padding(
                        padding: const EdgeInsets.only(top: 4, right: 2),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            IconButton(
                              visualDensity: VisualDensity.compact,
                              tooltip: 'Edit',
                              onPressed: widget.onEdit,
                              icon: const Icon(Icons.edit_outlined, size: 18),
                              color: AppTheme.textMuted,
                            ),
                            _CopyBurstButton(text: widget.copyText),
                          ],
                        ),
                      )
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CopyBurstButton extends StatefulWidget {
  const _CopyBurstButton({required this.text});

  final String text;

  @override
  State<_CopyBurstButton> createState() => _CopyBurstButtonState();
}

class _CopyBurstButtonState extends State<_CopyBurstButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spin;
  bool _copied = false;

  @override
  void initState() {
    super.initState();
    _spin = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    );
  }

  @override
  void dispose() {
    _spin.dispose();
    super.dispose();
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.text));
    if (!mounted) return;
    setState(() => _copied = false);
    await _spin.forward(from: 0);
    if (!mounted) return;
    setState(() => _copied = true);
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (mounted) setState(() => _copied = false);
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      visualDensity: VisualDensity.compact,
      tooltip: 'Salin',
      onPressed: _copy,
      icon: SizedBox(
        width: 22,
        height: 22,
        child: AnimatedBuilder(
          animation: _spin,
          builder: (context, _) {
            if (_copied) {
              return const Icon(
                Icons.check_rounded,
                size: 18,
                color: Color(0xFF5EE0A0),
              );
            }
            if (_spin.isAnimating || (_spin.value > 0 && _spin.value < 1)) {
              return CircularProgressIndicator(
                value: _spin.value,
                strokeWidth: 2.2,
                color: AppTheme.purpleLight,
              );
            }
            return const Icon(
              Icons.copy_rounded,
              size: 18,
              color: AppTheme.textMuted,
            );
          },
        ),
      ),
    );
  }
}

class _UserPromptBody extends StatelessWidget {
  const _UserPromptBody({required this.text, required this.attachments});

  final String text;
  final List<ChatAttachment> attachments;

  static bool isLongPaste(String text) {
    final t = text.trim();
    return t.length > 480 || '\n'.allMatches(t).length > 8;
  }

  @override
  Widget build(BuildContext context) {
    final pasted = attachments
        .where(
          (a) =>
              a.kind == AttachmentKind.document &&
              a.name.toLowerCase().contains('pasted'),
        )
        .toList();
    final typed = text.trim();
    if (pasted.isEmpty && !isLongPaste(typed)) {
      return SelectableText(
        typed,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 15.5,
          height: 1.45,
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (pasted.isNotEmpty)
          ...pasted.map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _PastedTextChip(
                label: item.name,
                fullText: typed,
                path: item.path,
              ),
            ),
          )
        else if (isLongPaste(typed))
          _PastedTextChip(label: 'pasted-text.txt', fullText: typed),
        if (typed.isNotEmpty && pasted.isNotEmpty) ...<Widget>[
          const SizedBox(height: 4),
          SelectableText(
            typed,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15.5,
              height: 1.45,
            ),
          ),
        ],
      ],
    );
  }
}

class _PastedTextChip extends StatefulWidget {
  const _PastedTextChip({
    required this.label,
    required this.fullText,
    this.path,
  });

  final String label;
  final String fullText;
  final String? path;

  @override
  State<_PastedTextChip> createState() => _PastedTextChipState();
}

class _PastedTextChipState extends State<_PastedTextChip> {
  bool _open = false;
  String _body = '';

  @override
  void initState() {
    super.initState();
    _body = widget.fullText;
    final path = widget.path;
    if (path != null && path.isNotEmpty) {
      File(path).readAsString().then((value) {
        if (mounted && value.trim().isNotEmpty) {
          setState(() => _body = value);
        }
      }).catchError((_) {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final preview = _body.trim().isEmpty ? widget.label : _body.trim();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Material(
          color: Colors.white.withValues(alpha: .14),
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => setState(() => _open = !_open),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .16),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(
                      Icons.description_outlined,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          widget.label.toLowerCase().contains('pasted')
                              ? 'pasted-text.txt'
                              : widget.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                          ),
                        ),
                        if (!_open && preview.isNotEmpty)
                          Text(
                            preview,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: .82),
                              fontSize: 12.5,
                              height: 1.3,
                            ),
                          ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Salin',
                    visualDensity: VisualDensity.compact,
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: preview));
                    },
                    icon: const Icon(Icons.copy_rounded, color: Colors.white, size: 18),
                  ),
                  Icon(
                    _open
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    color: Colors.white,
                  ),
                ],
              ),
            ),
          ),
        ),
        if (_open) ...<Widget>[
          const SizedBox(height: 8),
          SelectableText(
            preview,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14.5,
              height: 1.45,
            ),
          ),
        ],
      ],
    );
  }
}

/// Paparan kaya: markdown + jadual + code copy + mermaid/graf dalam chat.
class _RichChatContent extends StatelessWidget {
  const _RichChatContent({required this.data});

  final String data;

  static final RegExp _fence = RegExp(
    r'```([a-zA-Z0-9_+-]*)\s*\n([\s\S]*?)```',
    multiLine: true,
  );

  @override
  Widget build(BuildContext context) {
    final parts = <Widget>[];
    var cursor = 0;
    for (final match in _fence.allMatches(data)) {
      if (match.start > cursor) {
        final md = data.substring(cursor, match.start).trim();
        if (md.isNotEmpty) parts.add(_MarkdownAnswer(data: md));
      }
      final lang = (match.group(1) ?? '').trim().toLowerCase();
      final body = (match.group(2) ?? '').trimRight();
      if (lang == 'mermaid' || lang == 'mmd') {
        parts.add(_MermaidBlock(source: body));
      } else if (lang == 'chart' || lang == 'bar') {
        parts.add(_SimpleBarChartBlock(source: body));
      } else {
        // Kekalkan fence sebagai markdown code supaya ada butang salin.
        parts.add(
          _MarkdownAnswer(
            data: '```$lang\n$body\n```',
          ),
        );
      }
      cursor = match.end;
    }
    if (cursor < data.length) {
      final md = data.substring(cursor).trim();
      if (md.isNotEmpty) parts.add(_MarkdownAnswer(data: md));
    }
    if (parts.isEmpty) return _MarkdownAnswer(data: data);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        for (var i = 0; i < parts.length; i++) ...<Widget>[
          if (i > 0) const SizedBox(height: 10),
          parts[i],
        ],
      ],
    );
  }
}

class _MermaidBlock extends StatefulWidget {
  const _MermaidBlock({required this.source});

  final String source;

  @override
  State<_MermaidBlock> createState() => _MermaidBlockState();
}

class _MermaidBlockState extends State<_MermaidBlock> {
  WebViewController? _controller;
  bool _failed = false;
  double _height = 220;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void didUpdateWidget(covariant _MermaidBlock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.source != widget.source) _init();
  }

  Future<void> _init() async {
    try {
      final html = _mermaidHtml(widget.source);
      final controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF0B0E16))
        ..setNavigationDelegate(
          NavigationDelegate(
            onPageFinished: (_) async {
              try {
                final raw = await _controller?.runJavaScriptReturningResult(
                  'document.body.scrollHeight',
                );
                final h = double.tryParse(raw?.toString() ?? '') ?? 220;
                if (mounted && h > 80) {
                  setState(() => _height = h.clamp(160, 640));
                }
              } catch (_) {}
            },
          ),
        );
      _controller = controller;
      await controller.loadHtmlString(html, baseUrl: 'https://cdn.jsdelivr.net/');
      if (mounted) setState(() => _failed = false);
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  static String _mermaidHtml(String source) {
    final escaped = source
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;');
    return '''
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<script type="module">
  import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs';
  mermaid.initialize({ startOnLoad: true, theme: 'dark', securityLevel: 'loose' });
</script>
<style>
  body { margin: 0; padding: 12px; background: #0B0E16; color: #E8ECF5; }
  .mermaid { display: flex; justify-content: center; }
</style>
</head>
<body>
<pre class="mermaid">$escaped</pre>
</body>
</html>
''';
  }

  @override
  Widget build(BuildContext context) {
    if (_failed || _controller == null) {
      return _CopyableCodeBlock(code: '```mermaid\n${widget.source}\n```');
    }
    return Container(
      height: _height,
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppTheme.outline),
      ),
      clipBehavior: Clip.antiAlias,
      child: WebViewWidget(controller: _controller!),
    );
  }
}

/// Format mudah: setiap baris `label|nilai` atau `label: nilai`
class _SimpleBarChartBlock extends StatelessWidget {
  const _SimpleBarChartBlock({required this.source});

  final String source;

  @override
  Widget build(BuildContext context) {
    final rows = <({String label, double value})>[];
    for (final line in source.split('\n')) {
      final t = line.trim();
      if (t.isEmpty) continue;
      final parts = t.contains('|')
          ? t.split('|')
          : t.contains(':')
              ? t.split(':')
              : t.split(RegExp(r'\s+'));
      if (parts.length < 2) continue;
      final label = parts.first.trim();
      final value = double.tryParse(parts.sublist(1).join(' ').trim());
      if (label.isEmpty || value == null) continue;
      rows.add((label: label, value: value));
    }
    if (rows.isEmpty) {
      return _CopyableCodeBlock(code: source);
    }
    final maxV = rows.map((e) => e.value.abs()).fold<double>(1, (a, b) => a > b ? a : b);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Column(
        children: <Widget>[
          for (final row in rows.take(16))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: <Widget>[
                  SizedBox(
                    width: 72,
                    child: Text(
                      row.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: (row.value.abs() / maxV).clamp(0.0, 1.0),
                        minHeight: 12,
                        backgroundColor: const Color(0xFF1A2230),
                        color: AppTheme.purpleLight,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    row.value.toString(),
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _MarkdownAnswer extends StatelessWidget {
  const _MarkdownAnswer({required this.data});

  final String data;

  @override
  Widget build(BuildContext context) {
    final base = MarkdownStyleSheet.fromTheme(Theme.of(context));
    return MarkdownBody(
      data: data,
      selectable: true,
      builders: <String, MarkdownElementBuilder>{
        'pre': _CodeBlockBuilder(),
        'table': _HorizontalMarkdownTableBuilder(),
      },
      styleSheet: base.copyWith(
        p: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 15.5,
          height: 1.52,
        ),
        h1: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 23,
          fontWeight: FontWeight.w900,
          height: 1.25,
        ),
        h2: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 20,
          fontWeight: FontWeight.w900,
          height: 1.3,
        ),
        h3: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 17.5,
          fontWeight: FontWeight.w800,
          height: 1.35,
        ),
        strong: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w800,
        ),
        em: const TextStyle(
          color: AppTheme.textPrimary,
          fontStyle: FontStyle.italic,
        ),
        a: const TextStyle(
          color: AppTheme.cyan,
          decoration: TextDecoration.none,
          fontWeight: FontWeight.w700,
        ),
        code: const TextStyle(
          color: Color(0xFFD9CEFF),
          backgroundColor: AppTheme.surfaceHigh,
          fontFamily: 'monospace',
          fontSize: 13.2,
        ),
        codeblockPadding: const EdgeInsets.all(14),
        codeblockDecoration: BoxDecoration(
          color: const Color(0xFF0B0E16),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: AppTheme.outline),
        ),
        blockquotePadding: const EdgeInsets.fromLTRB(14, 10, 12, 10),
        blockquoteDecoration: BoxDecoration(
          color: AppTheme.purple.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(12),
          border: const Border(
            left: BorderSide(color: AppTheme.purpleLight, width: 3),
          ),
        ),
        horizontalRuleDecoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: AppTheme.outline, width: .8),
          ),
        ),
        listBullet: const TextStyle(
          color: AppTheme.purpleLight,
          fontWeight: FontWeight.w900,
        ),
      ),
      onTapLink: (text, href, title) async {
        if (href == null) return;
        final uri = Uri.tryParse(href);
        if (uri != null) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      },
    );
  }
}

class _HorizontalMarkdownTableBuilder extends MarkdownElementBuilder {
  @override
  Widget? visitElementAfter(md.Element element, TextStyle? preferredStyle) {
    final rows = <List<_MarkdownTableCell>>[];

    void collect(md.Node node) {
      if (node is! md.Element) return;
      if (node.tag == 'tr') {
        final cells = <_MarkdownTableCell>[];
        for (final child in node.children ?? const <md.Node>[]) {
          if (child is md.Element &&
              (child.tag == 'th' || child.tag == 'td')) {
            cells.add(
              _MarkdownTableCell(
                text: child.textContent.trim(),
                header: child.tag == 'th',
              ),
            );
          }
        }
        if (cells.isNotEmpty) rows.add(cells);
        return;
      }
      for (final child in node.children ?? const <md.Node>[]) {
        collect(child);
      }
    }

    collect(element);
    if (rows.isEmpty) return const SizedBox.shrink();
    return _HorizontalMarkdownTable(rows: rows);
  }
}

class _MarkdownTableCell {
  const _MarkdownTableCell({required this.text, required this.header});

  final String text;
  final bool header;
}

class _HorizontalMarkdownTable extends StatelessWidget {
  const _HorizontalMarkdownTable({required this.rows});

  final List<List<_MarkdownTableCell>> rows;

  @override
  Widget build(BuildContext context) {
    final columnCount = rows.fold<int>(
      0,
      (count, row) => math.max(count, row.length),
    );
    final baseWidths = List<double>.generate(columnCount, (column) {
      var longest = 0;
      for (final row in rows) {
        if (column >= row.length) continue;
        longest = math.max(longest, row[column].text.length);
      }
      return (longest * 7.2 + 30).clamp(136.0, 240.0).toDouble();
    });

    return LayoutBuilder(
      builder: (context, constraints) {
        final baseTotal = baseWidths.fold<double>(0, (a, b) => a + b);
        final viewport = constraints.maxWidth.isFinite
            ? constraints.maxWidth
            : baseTotal;
        final extra = baseTotal < viewport && columnCount > 0
            ? (viewport - baseTotal) / columnCount
            : 0.0;
        final widths = baseWidths.map((width) => width + extra).toList();
        final tableWidth = widths.fold<double>(0, (a, b) => a + b);

        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SizedBox(
              width: tableWidth,
              child: Table(
                columnWidths: <int, TableColumnWidth>{
                  for (var i = 0; i < widths.length; i++)
                    i: FixedColumnWidth(widths[i]),
                },
                border: TableBorder.all(
                  color: AppTheme.outline,
                  width: .8,
                  borderRadius: BorderRadius.circular(8),
                ),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: rows.map((row) {
                  final headerRow = row.any((cell) => cell.header);
                  return TableRow(
                    decoration: headerRow
                        ? const BoxDecoration(color: AppTheme.surfaceHigh)
                        : null,
                    children: List<Widget>.generate(columnCount, (column) {
                      final cell = column < row.length
                          ? row[column]
                          : const _MarkdownTableCell(text: '', header: false);
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                        child: SelectableText(
                          cell.text,
                          style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 14,
                            height: 1.35,
                            fontWeight: cell.header
                                ? FontWeight.w800
                                : FontWeight.w400,
                          ),
                        ),
                      );
                    }),
                  );
                }).toList(),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _CodeBlockBuilder extends MarkdownElementBuilder {
  @override
  Widget? visitElementAfter(md.Element element, TextStyle? preferredStyle) {
    final text = element.textContent;
    return _CopyableCodeBlock(code: text);
  }
}

class _CopyableCodeBlock extends StatefulWidget {
  const _CopyableCodeBlock({required this.code});

  final String code;

  @override
  State<_CopyableCodeBlock> createState() => _CopyableCodeBlockState();
}

class _CopyableCodeBlockState extends State<_CopyableCodeBlock> {
  bool _copied = false;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.code));
    if (!mounted) return;
    setState(() => _copied = true);
    Future<void>.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Stack(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 42, 14),
            child: SelectableText(
              widget.code.trimRight(),
              style: const TextStyle(
                color: Color(0xFFD9CEFF),
                fontFamily: 'monospace',
                fontSize: 13.2,
                height: 1.45,
              ),
            ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: IconButton(
              tooltip: _copied ? 'Disalin' : 'Salin kod',
              visualDensity: VisualDensity.compact,
              constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
              padding: EdgeInsets.zero,
              iconSize: 16,
              onPressed: _copy,
              icon: Icon(
                _copied ? Icons.check_rounded : Icons.copy_rounded,
                color: _copied ? AppTheme.success : AppTheme.textMuted,
                size: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageCopyBar extends StatefulWidget {
  const _MessageCopyBar({required this.text});

  final String text;

  @override
  State<_MessageCopyBar> createState() => _MessageCopyBarState();
}

class _MessageCopyBarState extends State<_MessageCopyBar> {
  bool _copied = false;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.text));
    if (!mounted) return;
    setState(() => _copied = true);
    Future<void>.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 2),
      child: Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: _copy,
          style: TextButton.styleFrom(
            foregroundColor: AppTheme.textMuted,
            visualDensity: VisualDensity.compact,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            minimumSize: const Size(0, 28),
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          icon: Icon(
            _copied ? Icons.check_rounded : Icons.copy_rounded,
            size: 14,
            color: _copied ? AppTheme.success : AppTheme.textMuted,
          ),
          label: Text(
            _copied ? 'Disalin' : 'Salin',
            style: const TextStyle(fontSize: 12),
          ),
        ),
      ),
    );
  }
}

class _AttachmentGrid extends StatelessWidget {
  const _AttachmentGrid({
    required this.attachments,
    required this.compact,
  });

  final List<ChatAttachment> attachments;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final images = attachments
        .where((a) => a.kind == AttachmentKind.image)
        .toList();
    final videos = attachments
        .where((a) => a.kind == AttachmentKind.video)
        .toList();
    final others = attachments
        .where(
          (a) =>
              a.kind != AttachmentKind.image && a.kind != AttachmentKind.video,
        )
        .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (images.isNotEmpty || videos.isNotEmpty)
          _MediaCarousel(
            items: <_CarouselItem>[
              ...images.map(
                (a) => _CarouselItem(
                  path: a.path,
                  url: a.sourceUrl,
                  title: a.name,
                  mimeType: a.mimeType,
                ),
              ),
              ...videos.map(
                (a) => _CarouselItem(
                  path: a.path,
                  url: a.sourceUrl,
                  title: a.name,
                  mimeType: a.mimeType,
                  isVideo: true,
                ),
              ),
            ],
          ),
        ...others.map(
          (a) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: _AttachmentPreview(
              key: ValueKey<String>(a.id),
              attachment: a,
              compact: compact,
            ),
          ),
        ),
      ],
    );
  }
}

class _AttachmentPreview extends StatelessWidget {
  const _AttachmentPreview({
    required this.attachment,
    required this.compact,
    super.key,
  });

  final ChatAttachment attachment;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return switch (attachment.kind) {
      AttachmentKind.image => _ImagePreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
          mimeType: attachment.mimeType,
        ),
      AttachmentKind.video => _VideoPreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
          mimeType: attachment.mimeType,
        ),
      AttachmentKind.audio => _AudioPreview(
          path: attachment.path,
          url: attachment.sourceUrl,
          title: attachment.name,
          mimeType: attachment.mimeType,
        ),
      _ => _FileCard(
          title: attachment.name,
          subtitle:
              '${attachment.mimeType} · ${_formatBytes(attachment.sizeBytes)}',
          path: attachment.path,
          url: attachment.sourceUrl ?? '',
          compact: compact,
        ),
    };
  }
}

class _ArtifactList extends StatelessWidget {
  const _ArtifactList({required this.artifacts});

  final List<ChatArtifact> artifacts;

  @override
  Widget build(BuildContext context) {
    final media = artifacts
        .where(
          (a) =>
              a.kind == ArtifactKind.image ||
              a.kind == ArtifactKind.video ||
              a.kind == ArtifactKind.webpage ||
              a.kind == ArtifactKind.html,
        )
        .toList();
    final seen = <String>{};
    final uniqueMedia = <ChatArtifact>[];
    for (final a in media) {
      final key = a.url.trim().isNotEmpty
          ? 'u:${a.url}'
          : 'p:${a.localPath}|${a.title}';
      if (seen.add(key)) uniqueMedia.add(a);
    }
    final rest = artifacts
        .where(
          (a) =>
              a.kind != ArtifactKind.image &&
              a.kind != ArtifactKind.video &&
              a.kind != ArtifactKind.webpage &&
              a.kind != ArtifactKind.html &&
              a.kind != ArtifactKind.searchResults,
        )
        .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (uniqueMedia.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _MediaCarousel(
              items: uniqueMedia
                  .map(
                    (a) => _CarouselItem(
                      path: a.localPath,
                      url: a.url,
                      title: a.title,
                      mimeType: a.mimeType,
                      isVideo: a.kind == ArtifactKind.video,
                      isHtml: a.kind == ArtifactKind.webpage ||
                          a.kind == ArtifactKind.html,
                      html: a.html,
                      subtitle: a.subtitle,
                    ),
                  )
                  .toList(),
            ),
          ),
        ...rest.map(
          (artifact) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _ArtifactCard(
              key: ValueKey<String>(artifact.id),
              artifact: artifact,
            ),
          ),
        ),
      ],
    );
  }
}

class _CarouselItem {
  const _CarouselItem({
    required this.path,
    this.url,
    required this.title,
    this.mimeType = '',
    this.isVideo = false,
    this.isHtml = false,
    this.html = '',
    this.subtitle = '',
  });
  final String path;
  final String? url;
  final String title;
  final String mimeType;
  final bool isVideo;
  final bool isHtml;
  final String html;
  final String subtitle;
}

/// Carousel gaya Grok: leret sisi, indicator, tinggi tetap (tak memanjang chat).
class _MediaCarousel extends StatefulWidget {
  const _MediaCarousel({required this.items});
  final List<_CarouselItem> items;

  @override
  State<_MediaCarousel> createState() => _MediaCarouselState();
}

class _MediaCarouselState extends State<_MediaCarousel> {
  late final PageController _controller;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _controller = PageController();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.items;
    if (items.isEmpty) return const SizedBox.shrink();
    final hasHtml = items.any((item) => item.isHtml);
    return Column(
      children: <Widget>[
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: SizedBox(
            height: hasHtml ? 420 : 280,
            width: double.infinity,
            child: PageView.builder(
              controller: _controller,
              itemCount: items.length,
              onPageChanged: (i) => setState(() => _index = i),
              itemBuilder: (context, i) {
                final item = items[i];
                if (item.isHtml) {
                  return _HtmlPreview(
                    title: item.title,
                    subtitle: item.subtitle,
                    html: item.html,
                    url: item.url ?? '',
                    localPath: item.path,
                  );
                }
                if (item.isVideo) {
                  return _VideoPreview(
                    path: item.path,
                    url: item.url,
                    title: item.title,
                    mimeType: item.mimeType,
                  );
                }
                return _ImagePreview(
                  path: item.path,
                  url: item.url,
                  title: item.title,
                  mimeType: item.mimeType,
                  compactHeight: 280,
                  showFooter: false,
                );
              },
            ),
          ),
        ),
        if (items.length > 1) ...<Widget>[
          const SizedBox(height: 8),
          SizedBox(
            height: 58,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final item = items[i];
                final active = i == _index;
                return GestureDetector(
                  onTap: () {
                    _controller.animateToPage(
                      i,
                      duration: const Duration(milliseconds: 220),
                      curve: Curves.easeOut,
                    );
                    setState(() => _index = i);
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    width: 58,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: active ? AppTheme.purpleLight : AppTheme.outline,
                        width: active ? 2 : 1,
                      ),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: item.isHtml
                        ? const ColoredBox(
                            color: Color(0xFF161B28),
                            child: Icon(Icons.language_rounded),
                          )
                        : item.isVideo
                            ? const ColoredBox(
                                color: Color(0xFF161B28),
                                child: Icon(Icons.play_circle_fill_rounded),
                              )
                            : _ThumbImage(path: item.path, url: item.url),
                  ),
                );
              },
            ),
          ),
        ],
      ],
    );
  }
}

class _ThumbImage extends StatelessWidget {
  const _ThumbImage({required this.path, this.url});

  final String path;
  final String? url;

  @override
  Widget build(BuildContext context) {
    final file = path.isNotEmpty ? File(path) : null;
    if (file != null && file.existsSync()) {
      return Image.file(file, fit: BoxFit.cover);
    }
    final remote = url == null ? null : Uri.tryParse(url!);
    if (remote != null && <String>{'http', 'https'}.contains(remote.scheme)) {
      return Image.network(remote.toString(), fit: BoxFit.cover);
    }
    return const ColoredBox(color: Color(0xFF161B28));
  }
}

class _ArtifactCard extends StatelessWidget {
  const _ArtifactCard({required this.artifact, super.key});

  final ChatArtifact artifact;

  @override
  Widget build(BuildContext context) {
    return switch (artifact.kind) {
      ArtifactKind.image => _ImagePreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
          mimeType: artifact.mimeType,
        ),
      ArtifactKind.video => _VideoPreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
          mimeType: artifact.mimeType,
        ),
      ArtifactKind.audio => _AudioPreview(
          path: artifact.localPath,
          url: artifact.url,
          title: artifact.title,
          mimeType: artifact.mimeType,
        ),
      ArtifactKind.webpage || ArtifactKind.html => _HtmlPreview(
          title: artifact.title,
          subtitle: artifact.subtitle,
          html: artifact.html,
          url: artifact.url,
          localPath: artifact.localPath,
        ),
      ArtifactKind.searchResults => _SearchResultsCard(artifact: artifact),
      ArtifactKind.file => artifact.subtitle == 'Skill local' ||
              (artifact.data['id'] != null &&
                  artifact.data['instructions'] != null)
          ? _SkillArtifactCard(artifact: artifact)
          : _FileCard(
              title: artifact.title,
              subtitle: artifact.subtitle.isEmpty
                  ? artifact.mimeType
                  : artifact.subtitle,
              path: artifact.localPath,
              url: artifact.url,
              compact: false,
            ),
    };
  }
}

final MediaExportService _mediaExportService = MediaExportService();

Future<void> _saveMediaFile(
  BuildContext context, {
  required String title,
  required String mimeType,
  String path = '',
  String url = '',
}) async {
  final result = await _mediaExportService.save(
    title: title,
    mimeType: mimeType,
    localPath: path,
    remoteUrl: url.isEmpty ? null : url,
  );
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(result.message)),
  );
}

class _ImagePreview extends StatefulWidget {
  const _ImagePreview({
    required this.path,
    required this.url,
    required this.title,
    this.mimeType = '',
    this.compactHeight,
    this.showFooter = true,
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;
  /// Jika diset (cth. carousel), tinggi tetap — elak chat memanjang.
  final double? compactHeight;
  final bool showFooter;

  @override
  State<_ImagePreview> createState() => _ImagePreviewState();
}

class _ImagePreviewState extends State<_ImagePreview> {
  bool _saving = false;

  ImageProvider? _provider() {
    final localFile = widget.path.isNotEmpty ? File(widget.path) : null;
    if (localFile?.existsSync() ?? false) return FileImage(localFile!);
    final remoteUri = _validRemoteUri(widget.url);
    return remoteUri == null ? null : NetworkImage(remoteUri.toString());
  }

  @override
  Widget build(BuildContext context) {
    final provider = _provider();
    if (provider == null) return _MediaError(title: widget.title);
    return Material(
      color: Colors.black,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => _FullImagePreviewPage(
              path: widget.path,
              url: widget.url,
              title: widget.title,
              mimeType: _mediaMime(
                widget.mimeType,
                widget.path,
                widget.url,
                fallback: 'image/png',
              ),
            ),
          ),
        ),
        child: Stack(
          children: <Widget>[
            SizedBox(
              width: double.infinity,
              height: widget.compactHeight ?? 220,
              child: Image(
                image: provider,
                fit: BoxFit.cover,
                alignment: Alignment.center,
                errorBuilder: (_, __, ___) => _MediaError(title: widget.title),
              ),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: _MediaToolbar(
                saving: _saving,
                onExpand: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => _FullImagePreviewPage(
                      path: widget.path,
                      url: widget.url,
                      title: widget.title,
                      mimeType: _mediaMime(
                        widget.mimeType,
                        widget.path,
                        widget.url,
                        fallback: 'image/png',
                      ),
                    ),
                  ),
                ),
                onSave: _save,
              ),
            ),
            if (widget.showFooter)
              Positioned(
              left: 8,
              right: 8,
              bottom: 8,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: .66),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  child: Row(
                    children: <Widget>[
                      const Icon(Icons.zoom_out_map_rounded, color: Colors.white70, size: 16),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Text(
                          widget.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const Text(
                        'Tekan untuk pratonton penuh',
                        style: TextStyle(color: Colors.white70, fontSize: 10.5),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: _mediaMime(
        widget.mimeType,
        widget.path,
        widget.url,
        fallback: 'image/png',
      ),
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _FullImagePreviewPage extends StatefulWidget {
  const _FullImagePreviewPage({
    required this.path,
    required this.url,
    required this.title,
    required this.mimeType,
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_FullImagePreviewPage> createState() => _FullImagePreviewPageState();
}

class _FullImagePreviewPageState extends State<_FullImagePreviewPage> {
  bool _saving = false;

  ImageProvider? _provider() {
    final file = widget.path.isNotEmpty ? File(widget.path) : null;
    if (file?.existsSync() ?? false) return FileImage(file!);
    final uri = _validRemoteUri(widget.url);
    return uri == null ? null : NetworkImage(uri.toString());
  }

  @override
  Widget build(BuildContext context) {
    final provider = _provider();
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: <Widget>[
          IconButton(
            tooltip: 'Simpan ke peranti',
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded),
          ),
        ],
      ),
      body: provider == null
          ? _MediaError(title: widget.title)
          : SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) => InteractiveViewer(
                  constrained: false,
                  alignment: Alignment.topCenter,
                  minScale: .5,
                  maxScale: 8,
                  boundaryMargin: const EdgeInsets.all(120),
                  child: Image(
                    image: provider,
                    width: constraints.maxWidth,
                    fit: BoxFit.fitWidth,
                    alignment: Alignment.topCenter,
                    errorBuilder: (_, __, ___) => _MediaError(title: widget.title),
                  ),
                ),
              ),
            ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: widget.mimeType,
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _VideoPreview extends StatefulWidget {
  const _VideoPreview({
    required this.path,
    required this.url,
    required this.title,
    this.mimeType = '',
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_VideoPreview> createState() => _VideoPreviewState();
}

class _VideoPreviewState extends State<_VideoPreview>
    with WidgetsBindingObserver {
  VideoPlayerController? _controller;
  Future<void>? _initialize;
  String? _error;
  bool _saving = false;
  bool _lastPlaying = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = _videoController(widget.path, widget.url);
    if (_controller == null) {
      _error = 'Sumber video tidak sah.';
      return;
    }
    _controller!.addListener(_onControllerChanged);
    _initialize = _controller!.initialize().then((_) async {
      await _controller?.setLooping(false);
      await _controller?.setVolume(1);
      if (mounted) setState(() {});
    }).catchError((Object error) {
      if (mounted) setState(() => _error = error.toString());
    });
  }

  void _onControllerChanged() {
    final playing = _controller?.value.isPlaying ?? false;
    if (playing == _lastPlaying || !mounted) return;
    _lastPlaying = playing;
    setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      _controller?.pause();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.removeListener(_onControllerChanged);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (controller == null || _error != null) {
      return _MediaError(title: widget.title);
    }
    return FutureBuilder<void>(
      future: _initialize,
      builder: (context, snapshot) {
        if (snapshot.hasError) return _MediaError(title: widget.title);
        if (snapshot.connectionState != ConnectionState.done ||
            !controller.value.isInitialized) {
          return Container(
            height: 190,
            decoration: BoxDecoration(
              color: const Color(0xFF090C13),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Center(child: _BufferOrb()),
          );
        }
        final ratio = controller.value.aspectRatio > 0
            ? controller.value.aspectRatio
            : 16 / 9;
        return LayoutBuilder(
          builder: (context, constraints) {
            final height = (constraints.maxWidth / ratio).clamp(190.0, 440.0);
            return ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: ColoredBox(
                color: Colors.black,
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      width: double.infinity,
                      height: height,
                      child: Stack(
                        alignment: Alignment.center,
                        children: <Widget>[
                          Positioned.fill(
                            child: FittedBox(
                              fit: BoxFit.contain,
                              child: SizedBox(
                                width: controller.value.size.width,
                                height: controller.value.size.height,
                                child: VideoPlayer(controller),
                              ),
                            ),
                          ),
                          Positioned.fill(
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                onTap: () async {
                                  if (controller.value.isPlaying) {
                                    await controller.pause();
                                  } else {
                                    await controller.play();
                                  }
                                  if (mounted) setState(() {});
                                },
                              ),
                            ),
                          ),
                          AnimatedOpacity(
                            opacity: controller.value.isPlaying ? 0 : 1,
                            duration: const Duration(milliseconds: 180),
                            child: IgnorePointer(
                              child: Container(
                                width: 58,
                                height: 58,
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: .62),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.play_arrow_rounded,
                                  color: Colors.white,
                                  size: 35,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            top: 8,
                            left: 8,
                            right: 8,
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      color: Colors.black.withValues(alpha: .62),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                                      child: Text(
                                        widget.title,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                _MediaToolbar(
                                  saving: _saving,
                                  onExpand: _openFullScreen,
                                  onSave: _save,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    VideoProgressIndicator(
                      controller,
                      allowScrubbing: true,
                      colors: const VideoProgressColors(
                        playedColor: AppTheme.purpleLight,
                        bufferedColor: Color(0xFF7A7290),
                        backgroundColor: Color(0xFF252937),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 6),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _openFullScreen() async {
    await _controller?.pause();
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _FullVideoPreviewPage(
          path: widget.path,
          url: widget.url,
          title: widget.title,
          mimeType: _mediaMime(
            widget.mimeType,
            widget.path,
            widget.url,
            fallback: 'video/mp4',
          ),
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: _mediaMime(
        widget.mimeType,
        widget.path,
        widget.url,
        fallback: 'video/mp4',
      ),
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _FullVideoPreviewPage extends StatefulWidget {
  const _FullVideoPreviewPage({
    required this.path,
    required this.url,
    required this.title,
    required this.mimeType,
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_FullVideoPreviewPage> createState() => _FullVideoPreviewPageState();
}

class _FullVideoPreviewPageState extends State<_FullVideoPreviewPage>
    with WidgetsBindingObserver {
  VideoPlayerController? _controller;
  Future<void>? _initialize;
  String? _error;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = _videoController(widget.path, widget.url);
    if (_controller == null) {
      _error = 'Sumber video tidak sah.';
      return;
    }
    _initialize = _controller!.initialize().then((_) async {
      await _controller?.setLooping(false);
      await _controller?.setVolume(1);
      if (mounted) setState(() {});
    }).catchError((Object error) {
      if (mounted) setState(() => _error = error.toString());
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _controller?.pause();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: <Widget>[
          IconButton(
            tooltip: 'Simpan ke peranti',
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded),
          ),
        ],
      ),
      body: controller == null || _error != null
          ? _MediaError(title: widget.title)
          : FutureBuilder<void>(
              future: _initialize,
              builder: (context, snapshot) {
                if (snapshot.hasError) return _MediaError(title: widget.title);
                if (snapshot.connectionState != ConnectionState.done ||
                    !controller.value.isInitialized) {
                  return const Center(child: _BufferOrb());
                }
                return SafeArea(
                  child: Column(
                    children: <Widget>[
                      Expanded(
                        child: Center(
                          child: AspectRatio(
                            aspectRatio: controller.value.aspectRatio > 0
                                ? controller.value.aspectRatio
                                : 16 / 9,
                            child: VideoPlayer(controller),
                          ),
                        ),
                      ),
                      VideoProgressIndicator(
                        controller,
                        allowScrubbing: true,
                        colors: const VideoProgressColors(
                          playedColor: AppTheme.purpleLight,
                          bufferedColor: Color(0xFF7A7290),
                          backgroundColor: Color(0xFF252937),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 18),
                        child: FilledButton.icon(
                          onPressed: () async {
                            if (controller.value.isPlaying) {
                              await controller.pause();
                            } else {
                              await controller.play();
                            }
                            if (mounted) setState(() {});
                          },
                          icon: Icon(
                            controller.value.isPlaying
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                          ),
                          label: Text(
                            controller.value.isPlaying ? 'Jeda' : 'Mainkan',
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: widget.mimeType,
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _AudioPreview extends StatefulWidget {
  const _AudioPreview({
    required this.path,
    required this.url,
    required this.title,
    this.mimeType = '',
  });

  final String path;
  final String? url;
  final String title;
  final String mimeType;

  @override
  State<_AudioPreview> createState() => _AudioPreviewState();
}

class _AudioPreviewState extends State<_AudioPreview>
    with WidgetsBindingObserver {
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<Duration?>? _durationSub;
  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<PlayerState>? _stateSub;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  bool _playing = false;
  bool _ready = false;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _durationSub = _player.durationStream.listen((value) {
      if (mounted && value != null) setState(() => _duration = value);
    });
    _positionSub = _player.positionStream.listen((value) {
      if (mounted) setState(() => _position = value);
    });
    _stateSub = _player.playerStateStream.listen((value) {
      if (!mounted) return;
      setState(() {
        _playing = value.playing;
        if (value.processingState == ProcessingState.completed) {
          _playing = false;
        }
      });
    });
    _load();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _player.pause();
  }

  Future<void> _load() async {
    try {
      if (widget.path.isNotEmpty && File(widget.path).existsSync()) {
        await _player.setFilePath(widget.path);
      } else {
        final uri = _validRemoteUri(widget.url);
        if (uri == null) throw const FormatException('Sumber audio tidak sah.');
        await _player.setUrl(uri.toString());
      }
      if (mounted) setState(() => _ready = true);
    } catch (error) {
      if (mounted) setState(() => _error = error.toString());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _durationSub?.cancel();
    _positionSub?.cancel();
    _stateSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final maxMs = _duration.inMilliseconds <= 0
        ? 1.0
        : _duration.inMilliseconds.toDouble();
    final value = _position.inMilliseconds.clamp(0, maxMs.toInt()).toDouble();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Row(
        children: <Widget>[
          IconButton.filled(
            onPressed: !_ready || _error != null
                ? null
                : () async {
                    if (_playing) {
                      await _player.pause();
                    } else {
                      if (_position >= _duration && _duration > Duration.zero) {
                        await _player.seek(Duration.zero);
                      }
                      await _player.play();
                    }
                  },
            icon: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                if (_error != null)
                  const Text(
                    'Audio tidak dapat dimainkan.',
                    style: TextStyle(color: AppTheme.danger, fontSize: 12),
                  )
                else
                  Slider(
                    value: value,
                    max: maxMs,
                    min: 0,
                    onChanged: _ready
                        ? (next) => _player.seek(Duration(milliseconds: next.round()))
                        : null,
                  ),
                Text(
                  '${_formatDuration(_position)} / ${_formatDuration(_duration)}',
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Simpan ke peranti',
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded),
          ),
        ],
      ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final result = await _mediaExportService.save(
      title: widget.title,
      mimeType: _mediaMime(
        widget.mimeType,
        widget.path,
        widget.url,
        fallback: 'audio/mpeg',
      ),
      localPath: widget.path,
      remoteUrl: widget.url,
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (!result.cancelled) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message)),
      );
    }
  }
}

class _MediaToolbar extends StatelessWidget {
  const _MediaToolbar({
    required this.saving,
    required this.onExpand,
    required this.onSave,
  });

  final bool saving;
  final VoidCallback onExpand;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: .66),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          IconButton(
            tooltip: 'Pratonton penuh',
            onPressed: onExpand,
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.fullscreen_rounded, color: Colors.white),
          ),
          IconButton(
            tooltip: 'Simpan ke peranti',
            onPressed: saving ? null : onSave,
            visualDensity: VisualDensity.compact,
            icon: saving
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download_rounded, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

VideoPlayerController? _videoController(String path, String? url) {
  final local = path.isNotEmpty ? File(path) : null;
  if (local?.existsSync() ?? false) return VideoPlayerController.file(local!);
  final uri = _validRemoteUri(url);
  return uri == null ? null : VideoPlayerController.networkUrl(uri);
}

Uri? _validRemoteUri(String? value) {
  final uri = Uri.tryParse(value?.trim() ?? '');
  if (uri == null ||
      !<String>{'http', 'https'}.contains(uri.scheme) ||
      uri.host.isEmpty) {
    return null;
  }
  return uri;
}

String _mediaMime(
  String declared,
  String path,
  String? url, {
  required String fallback,
}) {
  if (declared.trim().isNotEmpty) return declared.trim();
  final source = path.isNotEmpty ? path : (url ?? '');
  final clean = source.split('?').first.toLowerCase();
  if (clean.endsWith('.png')) return 'image/png';
  if (clean.endsWith('.jpg') || clean.endsWith('.jpeg')) return 'image/jpeg';
  if (clean.endsWith('.webp')) return 'image/webp';
  if (clean.endsWith('.gif')) return 'image/gif';
  if (clean.endsWith('.mp4') || clean.endsWith('.m4v')) return 'video/mp4';
  if (clean.endsWith('.webm')) return 'video/webm';
  if (clean.endsWith('.mov')) return 'video/quicktime';
  if (clean.endsWith('.mp3')) return 'audio/mpeg';
  if (clean.endsWith('.m4a')) return 'audio/mp4';
  if (clean.endsWith('.wav')) return 'audio/wav';
  if (clean.endsWith('.ogg') || clean.endsWith('.opus')) return 'audio/ogg';
  return fallback;
}

/// Kad skill dalam chat — tekan untuk buka Skills / aktifkan.
class _SkillArtifactCard extends StatelessWidget {
  const _SkillArtifactCard({required this.artifact});
  final ChatArtifact artifact;

  @override
  Widget build(BuildContext context) {
    final skillId = artifact.data['id']?.toString() ?? '';
    return Material(
      color: AppTheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
        side: const BorderSide(color: AppTheme.outline),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: () async {
          final state = AppScope.read(context);
          await state.reloadSkills();
          SkillDefinition? skill;
          if (skillId.isNotEmpty) {
            try {
              skill = state.skills.firstWhere((s) => s.id == skillId);
            } catch (_) {
              skill = null;
            }
          }
          skill ??= () {
            try {
              return state.skills.firstWhere((s) => s.name == artifact.title);
            } catch (_) {
              return null;
            }
          }();
          if (!context.mounted) return;
          if (skill != null && !skill.isBuiltIn) {
            await Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => SkillEditorScreen(skill: skill),
              ),
            );
          } else {
            await Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SkillsScreen()),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: AppTheme.purple.withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: const Icon(
                  Icons.extension_rounded,
                  color: AppTheme.purpleLight,
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      artifact.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      artifact.subtitle.isEmpty
                          ? 'Skill local · ketik untuk buka'
                          : '${artifact.subtitle} · ketik untuk buka',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                color: AppTheme.textSecondary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FileCard extends StatelessWidget {
  const _FileCard({
    required this.title,
    required this.subtitle,
    required this.path,
    required this.url,
    required this.compact,
  });

  final String title;
  final String subtitle;
  final String path;
  final String url;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: compact
          ? Colors.white.withValues(alpha: .1)
          : const Color(0xFF0B0E16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
        side: BorderSide(
          color: compact
              ? Colors.white.withValues(alpha: .15)
              : AppTheme.outline,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => _FilePreviewPage(
                title: title,
                path: path,
                url: url,
                subtitle: subtitle,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: compact
                      ? Colors.white.withValues(alpha: .12)
                      : AppTheme.purple.withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  _fileIcon(title),
                  color: compact ? Colors.white : AppTheme.purpleLight,
                ),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    if (subtitle.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: compact
                              ? Colors.white70
                              : AppTheme.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Muat turun',
                onPressed: () => _saveMediaFile(
                  context,
                  title: title,
                  mimeType: 'application/octet-stream',
                  path: path,
                  url: url,
                ),
                icon: Icon(
                  Icons.download_rounded,
                  size: compact ? 18 : 20,
                  color: compact ? Colors.white : AppTheme.textSecondary,
                ),
              ),
              Icon(
                Icons.chevron_right_rounded,
                size: 18,
                color: compact ? Colors.white70 : AppTheme.textSecondary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FilePreviewPage extends StatelessWidget {
  const _FilePreviewPage({
    required this.title,
    required this.path,
    required this.url,
    required this.subtitle,
  });

  final String title;
  final String path;
  final String url;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final ext = p.extension(title).toLowerCase();
    final file = path.isNotEmpty ? File(path) : null;
    final exists = file?.existsSync() ?? false;
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: <Widget>[
          IconButton(
            tooltip: 'Muat turun',
            onPressed: () => _saveMediaFile(
              context,
              title: title,
              mimeType: _mimeGuess(ext),
              path: path,
              url: url,
            ),
            icon: const Icon(Icons.download_rounded),
          ),
          if (exists)
            IconButton(
              tooltip: 'Buka luar',
              onPressed: () => OpenFilex.open(path),
              icon: const Icon(Icons.open_in_new_rounded),
            ),
        ],
      ),
      body: !exists
          ? const Center(child: Text('Fail tidak ada pada peranti.'))
          : _body(context, file!, ext),
    );
  }

  Widget _body(BuildContext context, File file, String ext) {
    if (<String>{'.html', '.htm'}.contains(ext)) {
      return _HtmlPreview(
        title: title,
        subtitle: subtitle,
        html: '',
        url: url,
        localPath: file.path,
      );
    }
    if (ext == '.zip') {
      return _ZipListing(file: file);
    }
    if (_isTextExt(ext) && file.lengthSync() <= 2 * 1024 * 1024) {
      String text;
      try {
        text = file.readAsStringSync();
      } catch (_) {
        text = 'Fail ini bukan teks yang boleh dibaca.';
      }
      return SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
        child: SelectableText(
          text,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 13, height: 1.45),
        ),
      );
    }
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(_fileIcon(title), size: 56, color: AppTheme.purpleLight),
            const SizedBox(height: 12),
            Text(title, textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(
              subtitle.isEmpty ? _formatBytes(file.lengthSync()) : subtitle,
              style: const TextStyle(color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: () => OpenFilex.open(file.path),
              icon: const Icon(Icons.open_in_new_rounded),
              label: const Text('Buka'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ZipListing extends StatelessWidget {
  const _ZipListing({required this.file});

  final File file;

  @override
  Widget build(BuildContext context) {
    try {
      final archive = ZipDecoder().decodeBytes(file.readAsBytesSync());
      final files = archive.files.where((f) => f.isFile).toList();
      if (files.isEmpty) {
        return const Center(child: Text('ZIP kosong.'));
      }
      return ListView.separated(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 40),
        itemCount: files.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final item = files[index];
          return ListTile(
            dense: true,
            leading: Icon(_fileIcon(item.name), color: AppTheme.purpleLight),
            title: Text(item.name, maxLines: 2, overflow: TextOverflow.ellipsis),
            subtitle: Text(_formatBytes(item.size)),
          );
        },
      );
    } catch (error) {
      return Center(child: Text('ZIP tidak boleh dibaca: $error'));
    }
  }
}

bool _isTextExt(String ext) => <String>{
      '.txt',
      '.md',
      '.json',
      '.js',
      '.ts',
      '.dart',
      '.py',
      '.css',
      '.xml',
      '.yaml',
      '.yml',
      '.csv',
      '.log',
      '.sh',
      '.html',
      '.htm',
      '.svg',
      '.ini',
      '.toml',
    }.contains(ext);

String _mimeGuess(String ext) {
  return switch (ext) {
    '.html' || '.htm' => 'text/html',
    '.zip' => 'application/zip',
    '.json' => 'application/json',
    '.pdf' => 'application/pdf',
    _ => 'application/octet-stream',
  };
}

class _HtmlPreview extends StatefulWidget {
  const _HtmlPreview({
    required this.title,
    required this.subtitle,
    required this.html,
    required this.url,
    this.localPath = '',
  });

  final String title;
  final String subtitle;
  final String html;
  final String url;
  final String localPath;

  @override
  State<_HtmlPreview> createState() => _HtmlPreviewState();
}

class _HtmlPreviewState extends State<_HtmlPreview> {
  WebViewController? _controller;

  @override
  void initState() {
    super.initState();
    _ensureController();
  }

  String get _htmlSource {
    if (widget.html.trim().isNotEmpty) return widget.html;
    final path = widget.localPath.trim();
    if (path.isEmpty) return '';
    final file = File(path);
    if (!file.existsSync()) return '';
    try {
      return file.readAsStringSync();
    } catch (_) {
      return '';
    }
  }

  void _ensureController() {
    if (_controller != null) return;
    final path = widget.localPath.trim();
    final local = path.isNotEmpty ? File(path) : null;
    final source = _htmlSource;
    final liveUrl = widget.url.trim();
    final liveUri = Uri.tryParse(liveUrl);
    final hasLive = liveUri != null &&
        (liveUri.scheme == 'http' || liveUri.scheme == 'https');
    if (!hasLive &&
        (local == null || !local.existsSync()) &&
        source.trim().isEmpty) {
      return;
    }
    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFFCFCFC))
      ..setUserAgent(
        'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (_) => NavigationDecision.navigate,
        ),
      );
    if (hasLive) {
      controller.loadRequest(liveUri);
    } else if (local != null && local.existsSync()) {
      controller.loadFile(local.path);
    } else {
      controller.loadHtmlString(
        _document(source),
        baseUrl: liveUrl.isNotEmpty ? liveUrl : null,
      );
    }
    _controller = controller;
  }

  String _document(String content) {
    final head = content.trimLeft().toLowerCase();
    if (head.startsWith('<!doctype') || head.startsWith('<html')) return content;
    return '''
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:-apple-system,BlinkMacSystemFont,Roboto,Arial,sans-serif;margin:16px;color:#171923;background:#fff;line-height:1.5;overflow-wrap:anywhere}
img{max-width:100%;height:auto} video,audio{max-width:100%;display:block;margin:12px 0} table{border-collapse:collapse;max-width:100%;display:block;overflow:auto} td,th{border:1px solid #ddd;padding:7px} a{color:#5d36c9} pre{white-space:pre-wrap;background:#f4f3f8;padding:12px;border-radius:10px}
</style>
</head>
<body>$content</body>
</html>
''';
  }

  void _openFullscreen() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _HtmlFullscreenPage(
          title: widget.title,
          html: widget.html,
          url: widget.url,
          localPath: widget.localPath,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.outline),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(13, 6, 4, 6),
            child: Row(
              children: <Widget>[
                const Icon(
                  Icons.language_rounded,
                  size: 20,
                  color: AppTheme.cyan,
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        widget.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      if (widget.subtitle.isNotEmpty)
                        Text(
                          widget.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 11,
                          ),
                        ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Skrin penuh',
                  onPressed: _openFullscreen,
                  icon: const Icon(Icons.fullscreen_rounded, size: 20),
                ),
                if (widget.localPath.isNotEmpty)
                  IconButton(
                    tooltip: 'Muat turun',
                    onPressed: () => _saveMediaFile(
                      context,
                      title: widget.title,
                      mimeType: 'text/html',
                      path: widget.localPath,
                      url: widget.url,
                    ),
                    icon: const Icon(Icons.download_rounded, size: 19),
                  ),
                if (widget.url.isNotEmpty)
                  IconButton(
                    tooltip: 'Buka di browser luar',
                    onPressed: () async {
                      final uri = Uri.tryParse(widget.url);
                      if (uri != null) {
                        await launchUrl(
                          uri,
                          mode: LaunchMode.externalApplication,
                        );
                      }
                    },
                    icon: const Icon(Icons.open_in_new_rounded, size: 19),
                  ),
              ],
            ),
          ),
          SizedBox(
            height: 420,
            child: _controller == null
                ? const Center(
                    child: Text(
                      'Pratonton halaman tidak tersedia.',
                      style: TextStyle(color: AppTheme.textSecondary),
                    ),
                  )
                : WebViewWidget(controller: _controller!),
          ),
        ],
      ),
    );
  }
}

class _HtmlFullscreenPage extends StatefulWidget {
  const _HtmlFullscreenPage({
    required this.title,
    required this.html,
    required this.url,
    required this.localPath,
  });

  final String title;
  final String html;
  final String url;
  final String localPath;

  @override
  State<_HtmlFullscreenPage> createState() => _HtmlFullscreenPageState();
}

class _HtmlFullscreenPageState extends State<_HtmlFullscreenPage> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setUserAgent(
        'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (_) => NavigationDecision.navigate,
        ),
      );
    final local = widget.localPath.trim();
    final live = Uri.tryParse(widget.url.trim());
    final hasLive =
        live != null && (live.scheme == 'http' || live.scheme == 'https');
    if (hasLive) {
      _controller.loadRequest(live);
    } else if (local.isNotEmpty && File(local).existsSync()) {
      _controller.loadFile(local);
    } else if (widget.html.trim().isNotEmpty) {
      _controller.loadHtmlString(
        widget.html,
        baseUrl: widget.url.trim().isEmpty ? null : widget.url.trim(),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: <Widget>[
          if (widget.localPath.isNotEmpty)
            IconButton(
              tooltip: 'Muat turun',
              onPressed: () => _saveMediaFile(
                context,
                title: widget.title,
                mimeType: 'text/html',
                path: widget.localPath,
                url: widget.url,
              ),
              icon: const Icon(Icons.download_rounded),
            ),
        ],
      ),
      body: WebViewWidget(controller: _controller),
    );
  }
}

class _SearchResultsCard extends StatelessWidget {
  const _SearchResultsCard({required this.artifact});

  final ChatArtifact artifact;

  @override
  Widget build(BuildContext context) {
    final results = (artifact.data['results'] as List? ?? const <dynamic>[])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .take(8)
        .toList();
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(
                Icons.travel_explore_rounded,
                color: AppTheme.cyan,
                size: 21,
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  artifact.title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          if (artifact.subtitle.isNotEmpty) ...<Widget>[
            const SizedBox(height: 3),
            Text(
              artifact.subtitle,
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 12,
              ),
            ),
          ],
          if (results.isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            ...results.map(
              (result) => InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () async {
                  final uri = Uri.tryParse(result['url']?.toString() ?? '');
                  if (uri != null) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        width: 25,
                        height: 25,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceHigh,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '${result['rank'] ?? ''}',
                          style: const TextStyle(
                            color: AppTheme.purpleLight,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              result['title']?.toString() ?? 'Hasil',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              result['display_url']?.toString() ??
                                  result['url']?.toString() ??
                                  '',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppTheme.cyan,
                                fontSize: 11,
                              ),
                            ),
                            if ((result['snippet']?.toString() ?? '')
                                .isNotEmpty) ...<Widget>[
                              const SizedBox(height: 3),
                              Text(
                                result['snippet'].toString(),
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: AppTheme.textSecondary,
                                  fontSize: 12,
                                  height: 1.35,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _CompletedProcessCard extends StatefulWidget {
  const _CompletedProcessCard({required this.events, this.durationMs});

  final List<RunEvent> events;
  final int? durationMs;

  @override
  State<_CompletedProcessCard> createState() => _CompletedProcessCardState();
}

class _CompletedProcessCardState extends State<_CompletedProcessCard> {
  // Selepas task siap: tertutup sendiri. Tekan untuk buka semula.
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final failed = widget.events.any(
      (item) => item.state == RunEventState.failed,
    );
    final durationSeconds = widget.durationMs == null
        ? null
        : (widget.durationMs! / 1000).round().clamp(1, 99999);
    final label = durationSeconds == null
        ? 'Berfikir'
        : 'Berfikir selama ${durationSeconds}s';
    // Gaya ChatGPT: teks sahaja, berada sebelum jawapan dan tiada kotak.
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        InkWell(
          onTap: () => setState(() => _expanded = !_expanded),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  label,
                  style: TextStyle(
                    color: failed ? AppTheme.danger : AppTheme.textMuted,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                Icon(
                  _expanded
                      ? Icons.keyboard_arrow_up_rounded
                      : Icons.keyboard_arrow_down_rounded,
                  size: 18,
                  color: AppTheme.textMuted,
                ),
              ],
            ),
          ),
        ),
        if (_expanded)
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 4),
            child: Column(
              children: List<Widget>.generate(widget.events.length, (index) {
                final event = widget.events[index];
                return _ThinkingStep(
                  icon: _thinkingIconForEvent(event),
                  title: event.title,
                  detail: event.detail,
                  isLast: index == widget.events.length - 1,
                  running: false,
                  failed: event.state == RunEventState.failed,
                  done: event.state == RunEventState.success,
                );
              }),
            ),
          ),
      ],
    );
  }
}

class _LiveProcessCard extends StatefulWidget {
  const _LiveProcessCard({
    required this.events,
    required this.detail,
    this.followUpCount = 0,
    this.startedAt,
  });

  final List<RunEvent> events;
  final String detail;
  final int followUpCount;
  final DateTime? startedAt;

  @override
  State<_LiveProcessCard> createState() => _LiveProcessCardState();
}

class _LiveProcessCardState extends State<_LiveProcessCard> {
  // Semasa agent berjalan: terbuka secara lalai. Tekan untuk tutup.
  // Bila siap diganti kad selesai yang tertutup (boleh dibuka semula).
  bool _expanded = true;
  Timer? _tick;
  int _elapsedSec = 0;

  @override
  void initState() {
    super.initState();
    _elapsedSec = _computeElapsed();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _elapsedSec = _computeElapsed());
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  int _computeElapsed() {
    final start = widget.startedAt;
    if (start == null) return 0;
    return DateTime.now().difference(start).inSeconds.clamp(0, 99999);
  }

  @override
  Widget build(BuildContext context) {
    final events = widget.events;
    final header = _elapsedSec > 0
        ? 'Sedang berfikir… ${_elapsedSec}s'
        : 'Sedang berfikir…';

    // Gaya ChatGPT: teks kelabu sahaja, tiada kad/kotak.
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 4, 2, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    header,
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                    ),
                  ),
                  Icon(
                    _expanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    size: 18,
                    color: AppTheme.textMuted,
                  ),
                ],
              ),
            ),
          ),
              if (_expanded) ...<Widget>[
                const SizedBox(height: 10),
                if (events.isEmpty)
                  Text(
                    widget.detail.isNotEmpty
                        ? widget.detail
                        : 'Menunggu model / orchestrator…',
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 12.5,
                    ),
                  )
                else
                  ...List<Widget>.generate(events.length, (index) {
                    final event = events[index];
                    return _ThinkingStep(
                      icon: _thinkingIconForEvent(event),
                      title: event.title,
                      detail: event.detail,
                      isLast: index == events.length - 1,
                      running: event.state == RunEventState.running,
                      failed: event.state == RunEventState.failed,
                      done: event.state == RunEventState.success,
                    );
                  }),
                if (widget.followUpCount > 0) ...<Widget>[
                  const SizedBox(height: 6),
                  Text(
                    '${widget.followUpCount} susulan dalam barisan',
                    style: const TextStyle(
                      color: AppTheme.textMuted,
                      fontSize: 12,
                    ),
                  ),
                ],
              ],
        ],
      ),
    );
  }

}

IconData _thinkingIconForEvent(RunEvent event) {
  final title = event.title.toLowerCase();
  if (event.state == RunEventState.failed) return Icons.error_outline_rounded;
  if (title.contains('memahami') ||
      title.contains('rancang') ||
      title.contains('plan')) {
    return Icons.lightbulb_outline_rounded;
  }
  if (title.contains('shell') ||
      title.contains('terminal') ||
      title.contains('cmd')) {
    return Icons.terminal_rounded;
  }
  if (title.contains('browser') ||
      title.contains('web') ||
      title.contains('carian')) {
    return Icons.language_rounded;
  }
  if (title.contains('windows') || title.contains('pc ')) {
    return Icons.desktop_windows_outlined;
  }
  if (title.contains('fail') ||
      title.contains('file') ||
      title.contains('baca')) {
    return Icons.description_outlined;
  }
  if (title.contains('tulis') ||
      title.contains('hasil') ||
      title.contains('jawab')) {
    return Icons.edit_note_rounded;
  }
  return Icons.circle_outlined;
}

class _ThinkingStep extends StatefulWidget {
  const _ThinkingStep({
    required this.icon,
    required this.title,
    this.detail = '',
    required this.isLast,
    this.running = false,
    this.failed = false,
    this.done = false,
  });

  final IconData icon;
  final String title;
  final String detail;
  final bool isLast;
  final bool running;
  final bool failed;
  final bool done;

  @override
  State<_ThinkingStep> createState() => _ThinkingStepState();
}

class _ThinkingStepState extends State<_ThinkingStep> {
  late bool _open;

  @override
  void initState() {
    super.initState();
    // Shell, error, log: buka terus supaya user nampak apa AI buat.
    _open = true;
  }

  @override
  void didUpdateWidget(covariant _ThinkingStep oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.failed && !_open) _open = true;
  }

  bool get _looksLikeLog {
    final d = widget.detail;
    return d.contains('--- stdout ---') ||
        d.contains('--- stderr ---') ||
        d.contains('Exit code:') ||
        d.trimLeft().startsWith('\$ ');
  }

  bool get _looksLikeCommand {
    final d = widget.detail.trim();
    if (d.isEmpty) return false;
    final lower = d.toLowerCase();
    final title = widget.title.toLowerCase();
    if (title.contains('shell') ||
        title.contains('terminal') ||
        title.contains('cmd') ||
        title.contains('exe') ||
        title.contains('pantau')) {
      return true;
    }
    return lower.startsWith('\$ ') ||
        lower.startsWith('apk ') ||
        lower.startsWith('wine ') ||
        lower.startsWith('python') ||
        lower.startsWith('cd ') ||
        lower.startsWith('git ') ||
        lower.startsWith('curl ') ||
        lower.startsWith('wget ') ||
        lower.startsWith('sh ') ||
        lower.startsWith('bash ') ||
        lower.contains('&&') ||
        lower.contains('|') ||
        lower.contains('--') ||
        lower.startsWith('http');
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.failed
        ? AppTheme.danger
        : widget.running
            ? AppTheme.textSecondary
            : AppTheme.textMuted;
    final detail = widget.detail.trim();
    final canExpand =
        detail.length > 40 || _looksLikeCommand || _looksLikeLog || widget.failed;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          SizedBox(
            width: 28,
            child: Column(
              children: <Widget>[
                Icon(widget.icon, size: 18, color: color),
                if (!widget.isLast)
                  Expanded(
                    child: Container(
                      width: 1.5,
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      color: const Color(0xFF2A3344),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: widget.isLast ? 0 : 14),
              child: InkWell(
                onTap: canExpand ? () => setState(() => _open = !_open) : null,
                borderRadius: BorderRadius.circular(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            widget.title,
                            style: TextStyle(
                              color: color,
                              fontSize: 13.5,
                              fontWeight:
                                  widget.running ? FontWeight.w600 : FontWeight.w500,
                              height: 1.3,
                            ),
                          ),
                        ),
                        if (canExpand)
                          Icon(
                            _open
                                ? Icons.keyboard_arrow_up_rounded
                                : Icons.keyboard_arrow_down_rounded,
                            size: 16,
                            color: AppTheme.textMuted,
                          ),
                      ],
                    ),
                    if (detail.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: _open || !canExpand
                            ? Container(
                                width: double.infinity,
                                constraints: const BoxConstraints(maxHeight: 420),
                                padding: (_looksLikeCommand || _looksLikeLog)
                                    ? const EdgeInsets.fromLTRB(8, 6, 8, 6)
                                    : EdgeInsets.zero,
                                decoration: (_looksLikeCommand || _looksLikeLog)
                                    ? BoxDecoration(
                                        color: const Color(0xFF12171F),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: widget.failed
                                              ? AppTheme.danger
                                                  .withValues(alpha: .45)
                                              : const Color(0xFF243044),
                                        ),
                                      )
                                    : null,
                                child: SingleChildScrollView(
                                  child: SelectableText(
                                    detail,
                                    style: TextStyle(
                                      color: widget.failed
                                          ? const Color(0xFFFFB4B4)
                                          : AppTheme.textMuted,
                                      fontSize: 12,
                                      height: 1.4,
                                      fontFamily:
                                          (_looksLikeCommand || _looksLikeLog)
                                              ? 'monospace'
                                              : null,
                                    ),
                                  ),
                                ),
                              )
                            : Text(
                                detail,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: widget.failed
                                      ? const Color(0xFFFFB4B4)
                                      : AppTheme.textMuted,
                                  fontSize: 12,
                                  height: 1.35,
                                ),
                              ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EditMessagePanel extends StatelessWidget {
  const _EditMessagePanel({
    required this.controller,
    required this.attachments,
    required this.onClose,
    required this.onAttach,
    required this.onRemoveAttachment,
    required this.onSend,
  });

  final TextEditingController controller;
  final List<ChatAttachment> attachments;
  final VoidCallback onClose;
  final VoidCallback onAttach;
  final void Function(ChatAttachment attachment) onRemoveAttachment;
  final VoidCallback onSend;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
        child: Material(
          color: const Color(0xFF151A24),
          elevation: 10,
          borderRadius: BorderRadius.circular(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 8, 4, 0),
                child: Row(
                  children: <Widget>[
                    const Icon(Icons.edit_outlined, size: 18, color: AppTheme.textSecondary),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        'Edit mesej',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Batal edit',
                      onPressed: onClose,
                      icon: const Icon(Icons.close_rounded),
                    ),
                  ],
                ),
              ),
              if (attachments.isNotEmpty)
                SizedBox(
                  height: 72,
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                    scrollDirection: Axis.horizontal,
                    itemCount: attachments.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final item = attachments[index];
                      return Stack(
                        clipBehavior: Clip.none,
                        children: <Widget>[
                          Container(
                            width: 72,
                            height: 64,
                            decoration: BoxDecoration(
                              color: AppTheme.surfaceHigh,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: AppTheme.outline),
                            ),
                            child: item.kind == AttachmentKind.image &&
                                    File(item.path).existsSync()
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(13),
                                    child: Image.file(
                                      File(item.path),
                                      fit: BoxFit.cover,
                                    ),
                                  )
                                : Icon(
                                    _attachmentIcon(item.kind),
                                    color: AppTheme.purpleLight,
                                  ),
                          ),
                          Positioned(
                            top: -6,
                            right: -6,
                            child: Material(
                              color: const Color(0xFF2A3140),
                              shape: const CircleBorder(),
                              child: InkWell(
                                customBorder: const CircleBorder(),
                                onTap: () => onRemoveAttachment(item),
                                child: const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: Icon(Icons.close_rounded, size: 14),
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
                child: TextField(
                  controller: controller,
                  autofocus: true,
                  minLines: 2,
                  maxLines: 8,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(
                    hintText: 'Edit mesej…',
                    filled: false,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                child: Row(
                  children: <Widget>[
                    IconButton(
                      tooltip: 'Tambah media',
                      onPressed: onAttach,
                      icon: const Icon(Icons.add_rounded),
                    ),
                    const Spacer(),
                    Material(
                      color: AppTheme.purple,
                      shape: const CircleBorder(),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: onSend,
                        child: const SizedBox(
                          width: 42,
                          height: 42,
                          child: Icon(Icons.arrow_upward_rounded, color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Composer extends StatelessWidget {
  const _Composer({
    required this.controller,
    required this.attachments,
    required this.listening,
    required this.sending,
    required this.onAttach,
    required this.onRemoveAttachment,
    required this.onVoice,
    required this.onSend,
    required this.onStop,
  });

  final TextEditingController controller;
  final List<ChatAttachment> attachments;
  final bool listening;
  final bool sending;
  final VoidCallback onAttach;
  final Future<void> Function(ChatAttachment attachment) onRemoveAttachment;
  final VoidCallback onVoice;
  final VoidCallback onSend;
  final VoidCallback onStop;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
        decoration: const BoxDecoration(
          color: Color(0xFF090C14),
          border: Border(
            top: BorderSide(color: Color(0xFF171D2A), width: .8),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (attachments.isNotEmpty) ...<Widget>[
              SizedBox(
                height: 68,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: attachments.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final item = attachments[index];
                    return Container(
                      width: 190,
                      padding: const EdgeInsets.fromLTRB(9, 8, 5, 8),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceHigh,
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: AppTheme.outline),
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: AppTheme.purple.withValues(alpha: .12),
                              borderRadius: BorderRadius.circular(11),
                            ),
                            child: Icon(
                              _attachmentIcon(item.kind),
                              size: 19,
                              color: AppTheme.purpleLight,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              item.name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            tooltip: 'Buang',
                            onPressed: sending
                                ? null
                                : () => onRemoveAttachment(item),
                            icon: const Icon(Icons.close_rounded, size: 18),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
            ],
            Container(
              decoration: BoxDecoration(
                color: AppTheme.surfaceHigh,
                borderRadius: BorderRadius.circular(23),
                border: Border.all(color: const Color(0xFF282F41)),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: Colors.black.withValues(alpha: .14),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 4),
                    child: IconButton(
                      tooltip: 'Lampirkan fail',
                      onPressed: sending ? null : onAttach,
                      icon: const Icon(Icons.add_rounded),
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 6,
                      textCapitalization: TextCapitalization.sentences,
                      keyboardType: TextInputType.multiline,
                      textInputAction: TextInputAction.newline,
                      decoration: InputDecoration(
                        hintText: sending ? 'Tulis susulan…' : 'Tulis arahan…',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding:
                            const EdgeInsets.fromLTRB(5, 15, 8, 15),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: IconButton(
                      tooltip: listening ? 'Henti suara' : 'Input suara',
                      onPressed: onVoice,
                      icon: Icon(
                        listening
                            ? Icons.graphic_eq_rounded
                            : Icons.mic_none_rounded,
                        color: listening
                            ? AppTheme.danger
                            : AppTheme.textSecondary,
                      ),
                    ),
                  ),
                  // Satu butang: stop MERAH bila agent jalan + input kosong;
                  // send bila ada teks (susulan atau arahan baru).
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 4, 5, 4),
                    child: ValueListenableBuilder<TextEditingValue>(
                      valueListenable: controller,
                      builder: (context, value, _) {
                        final hasText = value.text.trim().isNotEmpty;
                        final showStop = sending && !hasText;
                        if (showStop) {
                          return IconButton.filled(
                            tooltip: 'Hentikan AI',
                            onPressed: onStop,
                            style: IconButton.styleFrom(
                              backgroundColor: AppTheme.danger,
                              foregroundColor: Colors.white,
                            ),
                            icon: const Icon(Icons.stop_rounded),
                          );
                        }
                        return IconButton.filled(
                          tooltip: sending ? 'Hantar susulan' : 'Hantar',
                          onPressed: hasText ? onSend : null,
                          style: IconButton.styleFrom(
                            backgroundColor: hasText
                                ? AppTheme.purple
                                : AppTheme.surfaceHighest,
                            foregroundColor: hasText
                                ? Colors.white
                                : AppTheme.textSecondary,
                            disabledBackgroundColor: AppTheme.surfaceHighest,
                            disabledForegroundColor: AppTheme.textSecondary,
                            side: hasText
                                ? BorderSide.none
                                : const BorderSide(color: AppTheme.outline),
                          ),
                          icon: const Icon(Icons.arrow_upward_rounded),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BufferOrb extends StatefulWidget {
  const _BufferOrb({this.size = 40});

  final double size;

  @override
  State<_BufferOrb> createState() => _BufferOrbState();
}

class _BufferOrbState extends State<_BufferOrb>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1300),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) => CustomPaint(
          painter: _OrbPainter(progress: _controller.value),
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  const _OrbPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.shortestSide * .34;
    final glow = Paint()
      ..shader = const RadialGradient(
        colors: <Color>[
          Color(0xFFB9A2FF),
          Color(0x668E63FF),
          Color(0x008E63FF),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius * 1.5));
    canvas.drawCircle(center, radius * 1.5, glow);

    for (var i = 0; i < 3; i++) {
      final phase = (progress + i / 3) % 1;
      final angle = phase * 6.283185307179586;
      final point = Offset(
        center.dx + radius * math.cos(angle),
        center.dy + radius * math.sin(angle),
      );
      final dot = Paint()
        ..color = Color.lerp(
              AppTheme.purpleLight,
              AppTheme.cyan,
              i / 2,
            ) ??
            AppTheme.purpleLight;
      canvas.drawCircle(point, size.shortestSide * .09, dot);
    }
    canvas.drawCircle(
      center,
      size.shortestSide * .12,
      Paint()..color = Colors.white.withValues(alpha: .9),
    );
  }

  @override
  bool shouldRepaint(covariant _OrbPainter oldDelegate) =>
      oldDelegate.progress != progress;
}



class _MediaError extends StatelessWidget {
  const _MediaError({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceHigh,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.outline),
      ),
      child: Row(
        children: <Widget>[
          const Icon(
            Icons.broken_image_outlined,
            color: AppTheme.danger,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title.isEmpty ? 'Media' : title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                const Text(
                  'Media tidak dapat dipaparkan.',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

IconData _fileIcon(String name) {
  final extension = name.toLowerCase().split('.').last;
  return switch (extension) {
    'png' || 'jpg' || 'jpeg' || 'gif' || 'webp' || 'bmp' || 'svg' =>
      Icons.image_outlined,
    'mp4' || 'mkv' || 'mov' || 'avi' || 'webm' || 'm4v' =>
      Icons.movie_outlined,
    'mp3' || 'wav' || 'm4a' || 'aac' || 'flac' || 'ogg' =>
      Icons.audio_file_outlined,
    'pdf' => Icons.picture_as_pdf_outlined,
    'doc' || 'docx' || 'odt' || 'rtf' || 'txt' || 'md' =>
      Icons.description_outlined,
    'xls' || 'xlsx' || 'ods' || 'csv' => Icons.table_chart_outlined,
    'ppt' || 'pptx' || 'odp' => Icons.slideshow_outlined,
    'zip' || 'rar' || '7z' || 'tar' || 'gz' || 'xz' =>
      Icons.folder_zip_outlined,
    'dart' || 'kt' || 'java' || 'py' || 'js' || 'ts' || 'html' ||
    'css' || 'json' || 'xml' || 'yaml' || 'yml' || 'sh' || 'rs' ||
    'go' || 'c' || 'cpp' || 'h' => Icons.code_rounded,
    _ => Icons.insert_drive_file_outlined,
  };
}

IconData _attachmentIcon(AttachmentKind kind) {
  return switch (kind) {
    AttachmentKind.image => Icons.image_outlined,
    AttachmentKind.video => Icons.movie_outlined,
    AttachmentKind.audio => Icons.audio_file_outlined,
    AttachmentKind.document => Icons.description_outlined,
    AttachmentKind.archive => Icons.folder_zip_outlined,
    AttachmentKind.code => Icons.code_rounded,
    AttachmentKind.other => Icons.attach_file_rounded,
  };
}

String _formatBytes(int bytes) {
  if (bytes >= 1024 * 1024 * 1024) {
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
  if (bytes >= 1024 * 1024) {
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
  if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '$bytes B';
}

String _formatDuration(Duration value) {
  final minutes = value.inMinutes.remainder(60).toString().padLeft(2, '0');
  final seconds = value.inSeconds.remainder(60).toString().padLeft(2, '0');
  if (value.inHours > 0) {
    return '${value.inHours}:$minutes:$seconds';
  }
  return '$minutes:$seconds';
}


/// Konsol terminal gaya console dalam chat — log penuh + input stdin.
class _LiveTerminalConsole extends StatefulWidget {
  const _LiveTerminalConsole({this.sessionStartedAt});

  /// Hanya papar job yang bermula pada/selepas run ini (elak konsol chat lama).
  final DateTime? sessionStartedAt;

  @override
  State<_LiveTerminalConsole> createState() => _LiveTerminalConsoleState();
}

class _LiveTerminalConsoleState extends State<_LiveTerminalConsole> {
  Timer? _tick;
  final TextEditingController _input = TextEditingController();
  String? _selectedJobId;
  final ScrollController _logScroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _tick = Timer.periodic(const Duration(milliseconds: 500), (_) {
      if (!mounted) return;
      setState(() {});
      _autoSelect();
    });
    _autoSelect();
  }

  List<TerminalJob> _sessionJobs() {
    final all = TerminalService().jobs.toList();
    final start = widget.sessionStartedAt;
    if (start == null) return const <TerminalJob>[];
    // Hanya job turn ini (startedAt >= skop). Job chat/turn sebelum = buang.
    return all
        .where((j) => !j.startedAt.isBefore(start))
        .toList();
  }

  void _autoSelect() {
    final jobs = _sessionJobs();
    if (jobs.isEmpty) {
      _selectedJobId = null;
      return;
    }
    if (_selectedJobId == null ||
        !jobs.any((j) => j.id == _selectedJobId)) {
      final running = jobs.where((j) => j.running).toList();
      _selectedJobId =
          (running.isNotEmpty ? running.last : jobs.last).id;
    }
  }

  @override
  void dispose() {
    _tick?.cancel();
    _input.dispose();
    _logScroll.dispose();
    super.dispose();
  }

  Future<void> _sendInput(TerminalJob job) async {
    final text = _input.text;
    if (text.trim().isEmpty) return;
    _input.clear();
    await TerminalService().writeStdin(job.id, text);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final jobs = _sessionJobs().reversed.toList();
    if (jobs.isEmpty) return const SizedBox.shrink();

    final job = jobs.firstWhere(
      (j) => j.id == _selectedJobId,
      orElse: () => jobs.first,
    );
    final log = StringBuffer()
      ..writeln('\$ ${job.command}')
      ..writeln(
        job.running
            ? 'Status: running…'
            : 'Exit code: ${job.exitCode ?? '?'}',
      )
      ..writeln('--- stdout ---')
      ..writeln(job.stdout.toString())
      ..writeln('--- stderr ---')
      ..writeln(job.stderr.toString());

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0B0E16),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.outline),
      ),
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(Icons.terminal_rounded,
                  size: 16, color: AppTheme.purpleLight),
              const SizedBox(width: 6),
              const Expanded(
                child: Text(
                  'Konsol Terminal',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                  ),
                ),
              ),
              if (jobs.length > 1)
                DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: job.id,
                    isDense: true,
                    dropdownColor: const Color(0xFF12171F),
                    items: jobs
                        .map(
                          (j) => DropdownMenuItem<String>(
                            value: j.id,
                            child: Text(
                              j.running
                                  ? '● ${j.command.length > 28 ? '${j.command.substring(0, 28)}…' : j.command}'
                                  : '○ exit ${j.exitCode}',
                              style: const TextStyle(fontSize: 11),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (id) {
                      if (id == null) return;
                      setState(() => _selectedJobId = id);
                    },
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            height: 200,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF070A10),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFF243044)),
            ),
            child: SingleChildScrollView(
              controller: _logScroll,
              reverse: true,
              child: SelectableText(
                log.toString(),
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 11.5,
                  height: 1.35,
                  color: Color(0xFFC8D0E0),
                ),
              ),
            ),
          ),
          if (job.running) ...<Widget>[
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _input,
                    style: const TextStyle(fontSize: 13, fontFamily: 'monospace'),
                    decoration: const InputDecoration(
                      isDense: true,
                      hintText: 'Input ke proses (stdin)…',
                      border: OutlineInputBorder(),
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    ),
                    onSubmitted: (_) => _sendInput(job),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: () => _sendInput(job),
                  icon: const Icon(Icons.send_rounded, size: 18),
                  tooltip: 'Hantar stdin',
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
