import 'package:flutter/material.dart';

import '../../core/storage/native_bridge.dart';
import '../../core/theme/app_theme.dart';
import '../../state/app_scope.dart';
import '../widgets/panel.dart';
import '../widgets/status_pill.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  static const _privacyUrl = 'https://app.earlstore.online/privacy';
  static const _channelUrl = 'https://t.me/earlstore2004';
  static const _contactUrl = 'https://t.me/earlxz';

  Future<void> _openLink(BuildContext context, String url) async {
    try {
      await NativeBridge.openExternalUrl(url);
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pautan tidak dapat dibuka pada peranti ini.')),
      );
    }
  }

  Future<void> _clear(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Padam semua akaun?'),
        content: const Text(
          'Semua PAT dan metadata akaun akan dipadam dari peranti ini.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('Padam semua'),
          ),
        ],
      ),
    );
    if (confirmed == true && context.mounted) {
      await AppScope.of(context, listen: false).clearAllAccounts();
    }
  }

  @override
  Widget build(BuildContext context) {
    final controller = AppScope.of(context);
    final permission = controller.storagePermission;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 100),
        children: <Widget>[
          Text('Tetapan', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 5),
          const Text(
            'Kawalan privasi dan akses peranti.',
            style: TextStyle(color: AppColors.muted),
          ),
          const SizedBox(height: 22),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Icon(Icons.storefront_rounded, color: AppColors.accent),
                    const SizedBox(width: 10),
                    Text('Earlxz Store', style: Theme.of(context).textTheme.titleMedium),
                  ],
                ),
                const SizedBox(height: 12),
                const Text(
                  'Pusat rasmi Earlxz Store untuk kemas kini, saluran komuniti dan bantuan terus.',
                  style: TextStyle(color: AppColors.muted, height: 1.45),
                ),
                const SizedBox(height: 14),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _openLink(context, _channelUrl),
                        icon: const Icon(Icons.campaign_outlined),
                        label: const Text('My Channel'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () => _openLink(context, _contactUrl),
                        icon: const Icon(Icons.support_agent_rounded),
                        label: const Text('Contact Us'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Icon(Icons.security_rounded, color: AppColors.accent),
                    const SizedBox(width: 10),
                    Text('Token dan sambungan', style: Theme.of(context).textTheme.titleMedium),
                  ],
                ),
                const SizedBox(height: 14),
                const Text(
                  'PAT disimpan dalam storan selamat Android. Aplikasi tidak meletakkan token dalam URL, fail projek, atau log paparan.',
                  style: TextStyle(color: AppColors.muted, height: 1.5),
                ),
                const SizedBox(height: 14),
                const StatusPill(
                  label: 'Permission ikut PAT',
                  icon: Icons.admin_panel_settings_outlined,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Icon(Icons.folder_open_rounded, color: AppColors.warning),
                    const SizedBox(width: 10),
                    Text('Akses fail', style: Theme.of(context).textTheme.titleMedium),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  permission == null
                      ? 'Status izin belum tersedia.'
                      : permission.required
                          ? permission.granted
                              ? 'Izin storan Android lama sudah diberi.'
                              : 'Izin storan Android lama belum diberi.'
                          : 'Android moden menggunakan pemilih fail sistem. Tiada izin storan luas diperlukan.',
                  style: const TextStyle(color: AppColors.muted, height: 1.45),
                ),
                if (permission?.permanentlyDenied == true) ...<Widget>[
                  const SizedBox(height: 14),
                  OutlinedButton.icon(
                    onPressed: NativeBridge.openAppSettings,
                    icon: const Icon(Icons.settings_outlined),
                    label: const Text('Buka tetapan aplikasi'),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            borderColor: AppColors.danger.withValues(alpha: 0.38),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Zon sensitif', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                const Text(
                  'Tindakan seperti delete repository, merge, dan force push akan meminta pengesahan tambahan.',
                  style: TextStyle(color: AppColors.muted, height: 1.45),
                ),
                const SizedBox(height: 14),
                OutlinedButton.icon(
                  onPressed: () => _clear(context),
                  icon: const Icon(Icons.delete_sweep_outlined, color: AppColors.danger),
                  label: const Text(
                    'Padam semua akaun dari peranti',
                    style: TextStyle(color: AppColors.danger),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: TextButton(
              onPressed: () => _openLink(context, _privacyUrl),
              style: TextButton.styleFrom(
                foregroundColor: AppColors.muted,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              ),
              child: const Text(
                '© 2026 Earlxz. All rights reserved.',
                style: TextStyle(fontSize: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
