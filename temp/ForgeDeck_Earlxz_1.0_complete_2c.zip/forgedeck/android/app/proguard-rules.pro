# App-specific R8 rules.
# Flutter/Android entry points are supplied by the Android manifest and Flutter Gradle plugin.
# Keep this file intentionally minimal so R8 can optimize the release build effectively.
