import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

/// Represents a single search result from web scraping.
class SearchResult {
  final String title;
  final String url;
  final String snippet;

  const SearchResult({
    required this.title,
    required this.url,
    required this.snippet,
  });

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is SearchResult && other.url == url;
  }

  @override
  int get hashCode => url.hashCode;

  @override
  String toString() => 'SearchResult(title: $title, url: $url)';
}

/// On-device web scraper service that searches DuckDuckGo Lite and Yahoo
/// in parallel, then merges and deduplicates results.
///
/// All methods are designed to fail silently – they never throw.
class SearchService {
  static const Duration _timeout = Duration(seconds: 8);
  static const String _ddgUrl = 'https://lite.duckduckgo.com/lite';
  static const int _maxResults = 10;

  final http.Client _client;

  /// Creates a [SearchService] with an optional custom HTTP [client].
  SearchService({http.Client? client}) : _client = client ?? http.Client();

  /// Searches for [query] across DuckDuckGo Lite and Yahoo concurrently.
  ///
  /// Returns a deduplicated list of [SearchResult]s, or an empty list
  /// if all sources fail.
  Future<List<SearchResult>> search(String query) async {
    if (query.trim().isEmpty) return <SearchResult>[];

    try {
      final List<List<SearchResult>> results = await Future.wait(
        <Future<List<SearchResult>>>[
          _searchDuckDuckGo(query),
          _searchYahoo(query),
        ],
        eagerError: false,
      );

      return _deduplicateAndMerge(results);
    } catch (_) {
      return <SearchResult>[];
    }
  }

  /// Formats a list of [SearchResult]s as a hidden context block
  /// suitable for injection into a chat prompt.
  String formatForPrompt(List<SearchResult> results) {
    if (results.isEmpty) return '';

    final StringBuffer sb = StringBuffer();
    sb.writeln('[SEARCH_CONTEXT]');
    sb.writeln(
        'Berikut adalah maklumat carian web terkini yang relevan:');
    sb.writeln();

    for (int i = 0; i < results.length; i++) {
      final SearchResult r = results[i];
      sb.writeln('${i + 1}. **${_sanitize(r.title)}**');
      sb.writeln('   Sumber: ${r.url}');
      sb.writeln('   ${_sanitize(r.snippet)}');
      sb.writeln();
    }

    sb.writeln('Gunakan maklumat di atas untuk menjawab soalan pengguna.');
    sb.writeln(
        'Sekiranya maklumat carian tidak relevan, abaikan dan jawab berdasarkan pengetahuan anda.');
    sb.writeln('[/SEARCH_CONTEXT]');

    return sb.toString();
  }

  /// Disposes the HTTP client.
  void dispose() {
    _client.close();
  }

  // ---------------------------------------------------------------------------
  // DuckDuckGo Lite
  // ---------------------------------------------------------------------------

  Future<List<SearchResult>> _searchDuckDuckGo(String query) async {
    try {
      final http.Response response = await _client.post(
        Uri.parse(_ddgUrl),
        headers: <String, String>{
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
          'Accept': 'text/html',
        },
        body: 'q=${Uri.encodeComponent(query)}',
      ).timeout(_timeout);

      if (response.statusCode != 200) return <SearchResult>[];

      return _parseDuckDuckGoHtml(response.body);
    } catch (_) {
      return <SearchResult>[];
    }
  }

  List<SearchResult> _parseDuckDuckGoHtml(String html) {
    final List<SearchResult> results = <SearchResult>[];

    // DuckDuckGo Lite returns results inside <a class="result-link"> tags.
    // Each result row has a link + snippet in subsequent <td> elements.

    // Strategy 1: Extract links with class 'result-link'
    final RegExp linkRegex = RegExp(
      r'<a[^>]*class="result-link"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
      caseSensitive: false,
      dotAll: true,
    );

    // Strategy 2: Broader fallback – find links followed by snippets
    final RegExp rowRegex = RegExp(
      r'<td[^>]*class="result-link"[^>]*>.*?<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>.*?</td>'
      r'.*?<td[^>]*class="result-snippet"[^>]*>(.*?)</td>',
      caseSensitive: false,
      dotAll: true,
    );

    // Try the row-based regex first (captures both link + snippet).
    for (final RegExpMatch match in rowRegex.allMatches(html)) {
      if (results.length >= _maxResults) break;

      final String url = _decodeHtml(match.group(1) ?? '').trim();
      final String title =
          _stripHtml(_decodeHtml(match.group(2) ?? '')).trim();
      final String snippet =
          _stripHtml(_decodeHtml(match.group(3) ?? '')).trim();

      if (url.isNotEmpty && title.isNotEmpty && _isValidUrl(url)) {
        results.add(SearchResult(
          title: title,
          url: url,
          snippet: snippet,
        ));
      }
    }

    // Fallback: if row regex found nothing, try link-only regex.
    if (results.isEmpty) {
      for (final RegExpMatch match in linkRegex.allMatches(html)) {
        if (results.length >= _maxResults) break;

        final String url = _decodeHtml(match.group(1) ?? '').trim();
        final String title =
            _stripHtml(_decodeHtml(match.group(2) ?? '')).trim();

        if (url.isNotEmpty && title.isNotEmpty && _isValidUrl(url)) {
          results.add(SearchResult(
            title: title,
            url: url,
            snippet: '',
          ));
        }
      }
    }

    // Third fallback: generic anchor tag extraction from result tables.
    if (results.isEmpty) {
      final RegExp genericRegex = RegExp(
        r'<a[^>]+href="(https?://[^"]+)"[^>]*>(.*?)</a>',
        caseSensitive: false,
        dotAll: true,
      );

      final Set<String> seen = <String>{};
      for (final RegExpMatch match in genericRegex.allMatches(html)) {
        if (results.length >= _maxResults) break;

        final String url = _decodeHtml(match.group(1) ?? '').trim();
        final String title =
            _stripHtml(_decodeHtml(match.group(2) ?? '')).trim();

        if (url.isNotEmpty &&
            title.isNotEmpty &&
            title.length > 5 &&
            _isValidUrl(url) &&
            !url.contains('duckduckgo.com') &&
            seen.add(url)) {
          results.add(SearchResult(
            title: title,
            url: url,
            snippet: '',
          ));
        }
      }
    }

    return results;
  }

  // ---------------------------------------------------------------------------
  // Yahoo Search
  // ---------------------------------------------------------------------------

  Future<List<SearchResult>> _searchYahoo(String query) async {
    try {
      final Uri uri = Uri.parse(
          'https://search.yahoo.com/search?p=${Uri.encodeComponent(query)}');

      final http.Response response = await _client.get(
        uri,
        headers: <String, String>{
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
          'Accept': 'text/html',
          'Accept-Language': 'en-US,en;q=0.9,ms;q=0.8',
        },
      ).timeout(_timeout);

      if (response.statusCode != 200) return <SearchResult>[];

      return _parseYahooHtml(response.body);
    } catch (_) {
      return <SearchResult>[];
    }
  }

  List<SearchResult> _parseYahooHtml(String html) {
    final List<SearchResult> results = <SearchResult>[];

    // Yahoo search results are wrapped in <div class="dd algo ...">
    final RegExp resultBlockRegex = RegExp(
      r'<div[^>]*class="[^"]*\balgo\b[^"]*"[^>]*>(.*?)</div>\s*</div>',
      caseSensitive: false,
      dotAll: true,
    );

    // Extract link + title from <a> inside <h3>
    final RegExp titleLinkRegex = RegExp(
      r'<h3[^>]*>.*?<a[^>]+href="([^"]*)"[^>]*>(.*?)</a>',
      caseSensitive: false,
      dotAll: true,
    );

    // Extract snippet (typically <p class="..."> or <span class="fc-falcon">)
    final RegExp snippetRegex = RegExp(
      r'<(?:p|span)[^>]*class="[^"]*(?:fc-falcon|compText)[^"]*"[^>]*>(.*?)</(?:p|span)>',
      caseSensitive: false,
      dotAll: true,
    );

    for (final RegExpMatch block in resultBlockRegex.allMatches(html)) {
      if (results.length >= _maxResults) break;

      final String blockHtml = block.group(1) ?? '';

      final RegExpMatch? titleMatch =
          titleLinkRegex.firstMatch(blockHtml);
      if (titleMatch == null) continue;

      String url = _decodeHtml(titleMatch.group(1) ?? '').trim();
      final String title =
          _stripHtml(_decodeHtml(titleMatch.group(2) ?? '')).trim();

      // Yahoo sometimes wraps URLs in a redirect – attempt to extract real URL.
      url = _extractRealUrl(url);

      String snippet = '';
      final RegExpMatch? snippetMatch =
          snippetRegex.firstMatch(blockHtml);
      if (snippetMatch != null) {
        snippet =
            _stripHtml(_decodeHtml(snippetMatch.group(1) ?? '')).trim();
      }

      if (url.isNotEmpty && title.isNotEmpty && _isValidUrl(url)) {
        results.add(SearchResult(
          title: title,
          url: url,
          snippet: snippet,
        ));
      }
    }

    // Fallback: simple anchor tag extraction from the page.
    if (results.isEmpty) {
      final RegExp fallbackRegex = RegExp(
        r'<a[^>]+class="[^"]*(?:ac-algo|d-ib)[^"]*"[^>]+href="([^"]*)"[^>]*>(.*?)</a>',
        caseSensitive: false,
        dotAll: true,
      );

      for (final RegExpMatch match in fallbackRegex.allMatches(html)) {
        if (results.length >= _maxResults) break;

        String url = _decodeHtml(match.group(1) ?? '').trim();
        url = _extractRealUrl(url);
        final String title =
            _stripHtml(_decodeHtml(match.group(2) ?? '')).trim();

        if (url.isNotEmpty && title.isNotEmpty && _isValidUrl(url)) {
          results.add(SearchResult(
            title: title,
            url: url,
            snippet: '',
          ));
        }
      }
    }

    return results;
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  /// Merges lists of results and removes duplicates (by URL).
  List<SearchResult> _deduplicateAndMerge(
      List<List<SearchResult>> allResults) {
    final Map<String, SearchResult> unique = <String, SearchResult>{};

    for (final List<SearchResult> list in allResults) {
      for (final SearchResult result in list) {
        final String normalised = _normaliseUrl(result.url);
        if (!unique.containsKey(normalised)) {
          unique[normalised] = result;
        } else {
          // If existing entry lacks snippet, prefer the one with snippet.
          final SearchResult existing = unique[normalised]!;
          if (existing.snippet.isEmpty && result.snippet.isNotEmpty) {
            unique[normalised] = result;
          }
        }
      }
    }

    final List<SearchResult> merged = unique.values.toList();
    if (merged.length > _maxResults) {
      return merged.sublist(0, _maxResults);
    }
    return merged;
  }

  /// Normalises a URL by removing trailing slash and lowercasing the host.
  String _normaliseUrl(String url) {
    try {
      final Uri uri = Uri.parse(url);
      return '${uri.scheme}://${uri.host.toLowerCase()}${uri.path}'
          .replaceAll(RegExp(r'/+$'), '');
    } catch (_) {
      return url.toLowerCase().replaceAll(RegExp(r'/+$'), '');
    }
  }

  /// Strips all HTML tags from [input].
  String _stripHtml(String input) {
    return input
        .replaceAll(RegExp(r'<[^>]*>'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  /// Decodes common HTML entities.
  String _decodeHtml(String input) {
    return input
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&apos;', "'")
        .replaceAll('&#x27;', "'")
        .replaceAll('&#x2F;', '/')
        .replaceAll('&nbsp;', ' ');
  }

  /// Validates that a [url] looks like a proper HTTP(S) URL.
  bool _isValidUrl(String url) {
    try {
      final Uri uri = Uri.parse(url);
      return uri.hasScheme &&
          (uri.scheme == 'http' || uri.scheme == 'https') &&
          uri.host.isNotEmpty &&
          uri.host.contains('.');
    } catch (_) {
      return false;
    }
  }

  /// Sanitises text for use inside markdown by escaping special chars.
  String _sanitize(String text) {
    return text
        .replaceAll('[', r'\[')
        .replaceAll(']', r'\]');
  }

  /// Extracts the real destination URL from Yahoo's redirect wrapper.
  ///
  /// Yahoo links often look like:
  /// `https://r.search.yahoo.com/_ylt=.../RU=<encoded_url>/...`
  String _extractRealUrl(String url) {
    // Pattern: /RU=<url>/
    final RegExp ruRegex = RegExp(r'RU=(https?[^/]+)');
    final RegExpMatch? match = ruRegex.firstMatch(url);
    if (match != null) {
      try {
        return Uri.decodeComponent(match.group(1)!);
      } catch (_) {
        // Fall through to return the original URL.
      }
    }

    // Alternative pattern: Yahoo encodes the real URL in the redirect query.
    try {
      final Uri uri = Uri.parse(url);
      final String? redirectUrl = uri.queryParameters['u'] ??
          uri.queryParameters['url'] ??
          uri.queryParameters['r'];
      if (redirectUrl != null &&
          redirectUrl.startsWith('http') &&
          _isValidUrl(redirectUrl)) {
        return redirectUrl;
      }
    } catch (_) {
      // Ignore and return original.
    }

    return url;
  }
}
