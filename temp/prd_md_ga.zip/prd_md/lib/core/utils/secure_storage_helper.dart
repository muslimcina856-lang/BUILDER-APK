import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Secure key-value storage helper for sensitive and preference data.
///
/// Uses [FlutterSecureStorage] under the hood, providing typed
/// convenience methods for the app's storage needs.
class SecureStorageHelper {
  static const String _keyApiKey = 'deepseek_api_key';
  static const String _keyDefaultModel = 'default_model';
  static const String _keyWebSearchDefault = 'web_search_default';
  static const String _keyDarkMode = 'dark_mode';

  final FlutterSecureStorage _storage;

  /// Creates a [SecureStorageHelper] with optional custom [storage] instance.
  SecureStorageHelper({FlutterSecureStorage? storage})
      : _storage = storage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(
                encryptedSharedPreferences: true,
              ),
            );

  // ---------------------------------------------------------------------------
  // API Key
  // ---------------------------------------------------------------------------

  /// Saves the DeepSeek API key securely.
  Future<void> saveApiKey(String apiKey) async {
    try {
      await _storage.write(key: _keyApiKey, value: apiKey);
    } catch (e) {
      throw StorageException('Gagal menyimpan kunci API: $e');
    }
  }

  /// Retrieves the stored API key, or `null` if not set.
  Future<String?> getApiKey() async {
    try {
      return await _storage.read(key: _keyApiKey);
    } catch (e) {
      throw StorageException('Gagal membaca kunci API: $e');
    }
  }

  /// Deletes the stored API key.
  Future<void> deleteApiKey() async {
    try {
      await _storage.delete(key: _keyApiKey);
    } catch (e) {
      throw StorageException('Gagal memadam kunci API: $e');
    }
  }

  /// Returns `true` if an API key is present in storage.
  Future<bool> hasApiKey() async {
    try {
      final String? key = await _storage.read(key: _keyApiKey);
      return key != null && key.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Default Model
  // ---------------------------------------------------------------------------

  /// Saves the default model identifier (e.g. `deepseek-chat`).
  Future<void> saveDefaultModel(String model) async {
    try {
      await _storage.write(key: _keyDefaultModel, value: model);
    } catch (e) {
      throw StorageException('Gagal menyimpan model lalai: $e');
    }
  }

  /// Retrieves the default model, or `deepseek-chat` if not set.
  Future<String> getDefaultModel() async {
    try {
      final String? model = await _storage.read(key: _keyDefaultModel);
      return model ?? 'deepseek-chat';
    } catch (_) {
      return 'deepseek-chat';
    }
  }

  // ---------------------------------------------------------------------------
  // Web Search Default
  // ---------------------------------------------------------------------------

  /// Saves the web-search-enabled default (`true`/`false`).
  Future<void> saveWebSearchDefault(bool enabled) async {
    try {
      await _storage.write(
        key: _keyWebSearchDefault,
        value: enabled.toString(),
      );
    } catch (e) {
      throw StorageException(
          'Gagal menyimpan tetapan carian web: $e');
    }
  }

  /// Retrieves the web-search default. Returns `false` if not set.
  Future<bool> getWebSearchDefault() async {
    try {
      final String? value =
          await _storage.read(key: _keyWebSearchDefault);
      return value == 'true';
    } catch (_) {
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Dark Mode
  // ---------------------------------------------------------------------------

  /// Saves the dark mode preference.
  Future<void> saveDarkMode(bool enabled) async {
    try {
      await _storage.write(
        key: _keyDarkMode,
        value: enabled.toString(),
      );
    } catch (e) {
      throw StorageException(
          'Gagal menyimpan tetapan mod gelap: $e');
    }
  }

  /// Returns `true` if dark mode is enabled, `false` otherwise.
  Future<bool> isDarkMode() async {
    try {
      final String? value = await _storage.read(key: _keyDarkMode);
      return value == 'true';
    } catch (_) {
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Utility
  // ---------------------------------------------------------------------------

  /// Clears all stored values.
  Future<void> clearAll() async {
    try {
      await _storage.deleteAll();
    } catch (e) {
      throw StorageException('Gagal memadam semua data: $e');
    }
  }
}

/// Exception thrown by [SecureStorageHelper] on storage operation failures.
class StorageException implements Exception {
  final String message;
  const StorageException(this.message);

  @override
  String toString() => 'StorageException: $message';
}
