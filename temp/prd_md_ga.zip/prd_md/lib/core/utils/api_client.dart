import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';

/// DeepSeek API client with SSE streaming support.
///
/// Handles communication with the DeepSeek chat completion endpoint,
/// including streaming responses, error handling, and connection testing.
class DeepSeekApiClient {
  static const String _baseUrl = 'https://api.deepseek.com/v1';
  static const double _temperature = 0.2;

  final Dio _dio;
  final String _apiKey;
  final String _model;

  CancelToken? _activeCancelToken;

  /// Creates a new [DeepSeekApiClient].
  ///
  /// [apiKey] – DeepSeek API key for authentication.
  /// [model] – Model identifier (e.g. `deepseek-chat`, `deepseek-reasoner`).
  DeepSeekApiClient({
    required String apiKey,
    String model = 'deepseek-chat',
    Dio? dio,
  })  : _apiKey = apiKey,
        _model = model,
        _dio = dio ??
            Dio(
              BaseOptions(
                baseUrl: _baseUrl,
                connectTimeout: const Duration(seconds: 30),
                receiveTimeout: const Duration(minutes: 5),
                headers: <String, dynamic>{
                  'Content-Type': 'application/json',
                  'Accept': 'text/event-stream',
                },
              ),
            );

  /// Sends a chat message to DeepSeek and returns a [Stream] of content tokens.
  ///
  /// When [stream] is `true` (default), responses are streamed via SSE.
  /// When `false`, the full response is awaited and returned as a single chunk.
  Stream<String> sendChatMessage(
    List<Map<String, String>> messages, {
    bool stream = true,
  }) {
    if (stream) {
      return _streamChat(messages);
    }
    return _nonStreamChat(messages);
  }

  /// Streams SSE chunks from the DeepSeek `/chat/completions` endpoint.
  Stream<String> _streamChat(List<Map<String, String>> messages) async* {
    _activeCancelToken?.cancel('New request started');
    _activeCancelToken = CancelToken();

    final Map<String, dynamic> payload = <String, dynamic>{
      'model': _model,
      'messages': messages,
      'temperature': _temperature,
      'stream': true,
    };

    Response<ResponseBody> response;

    try {
      response = await _dio.post<ResponseBody>(
        '/chat/completions',
        data: payload,
        options: Options(
          responseType: ResponseType.stream,
          headers: <String, dynamic>{
            'Authorization': 'Bearer $_apiKey',
          },
        ),
        cancelToken: _activeCancelToken,
      );
    } on DioException catch (e) {
      yield* _handleDioError(e);
      return;
    }

    final ResponseBody? body = response.data;
    if (body == null) {
      yield '[ERROR] Tiada data diterima daripada pelayan.';
      return;
    }

    // Buffer for incomplete SSE lines across chunks.
    String buffer = '';

    await for (final List<int> chunk in body.stream) {
      if (_activeCancelToken?.isCancelled ?? false) break;

      buffer += utf8.decode(chunk, allowMalformed: true);

      // Split by double-newline (SSE event boundary) or single newline.
      final List<String> lines = buffer.split('\n');

      // Keep the last element in buffer in case it's an incomplete line.
      buffer = lines.removeLast();

      for (final String line in lines) {
        final String trimmed = line.trim();
        if (trimmed.isEmpty) continue;

        if (!trimmed.startsWith('data:')) continue;

        final String data = trimmed.substring(5).trim();

        if (data == '[DONE]') return;

        try {
          final Map<String, dynamic> json =
              jsonDecode(data) as Map<String, dynamic>;

          final List<dynamic>? choices =
              json['choices'] as List<dynamic>?;
          if (choices == null || choices.isEmpty) continue;

          final Map<String, dynamic> choice =
              choices.first as Map<String, dynamic>;

          final Map<String, dynamic>? delta =
              choice['delta'] as Map<String, dynamic>?;
          if (delta == null) continue;

          // reasoning_content for reasoner models
          final String? reasoning =
              delta['reasoning_content'] as String?;
          if (reasoning != null && reasoning.isNotEmpty) {
            yield reasoning;
          }

          final String? content = delta['content'] as String?;
          if (content != null && content.isNotEmpty) {
            yield content;
          }
        } on FormatException {
          // Malformed JSON – skip this chunk silently.
          continue;
        }
      }
    }

    // Process any remaining buffer content.
    if (buffer.trim().isNotEmpty) {
      final String trimmed = buffer.trim();
      if (trimmed.startsWith('data:')) {
        final String data = trimmed.substring(5).trim();
        if (data != '[DONE]') {
          try {
            final Map<String, dynamic> json =
                jsonDecode(data) as Map<String, dynamic>;
            final List<dynamic>? choices =
                json['choices'] as List<dynamic>?;
            if (choices != null && choices.isNotEmpty) {
              final Map<String, dynamic> choice =
                  choices.first as Map<String, dynamic>;
              final Map<String, dynamic>? delta =
                  choice['delta'] as Map<String, dynamic>?;
              if (delta != null) {
                final String? content = delta['content'] as String?;
                if (content != null && content.isNotEmpty) {
                  yield content;
                }
              }
            }
          } on FormatException {
            // Ignore trailing malformed data.
          }
        }
      }
    }
  }

  /// Non-streaming completion – returns the full message at once.
  Stream<String> _nonStreamChat(
      List<Map<String, String>> messages) async* {
    _activeCancelToken?.cancel('New request started');
    _activeCancelToken = CancelToken();

    final Map<String, dynamic> payload = <String, dynamic>{
      'model': _model,
      'messages': messages,
      'temperature': _temperature,
      'stream': false,
    };

    try {
      final Response<Map<String, dynamic>> response =
          await _dio.post<Map<String, dynamic>>(
        '/chat/completions',
        data: payload,
        options: Options(
          headers: <String, dynamic>{
            'Authorization': 'Bearer $_apiKey',
          },
        ),
        cancelToken: _activeCancelToken,
      );

      final Map<String, dynamic>? body = response.data;
      if (body == null) {
        yield '[ERROR] Tiada data diterima daripada pelayan.';
        return;
      }

      final List<dynamic>? choices =
          body['choices'] as List<dynamic>?;
      if (choices == null || choices.isEmpty) {
        yield '[ERROR] Tiada jawapan dijana oleh model.';
        return;
      }

      final Map<String, dynamic> choice =
          choices.first as Map<String, dynamic>;
      final Map<String, dynamic>? message =
          choice['message'] as Map<String, dynamic>?;

      final String content =
          (message?['content'] as String?) ?? '';
      if (content.isNotEmpty) {
        yield content;
      }
    } on DioException catch (e) {
      yield* _handleDioError(e);
    }
  }

  /// Tests whether the API key is valid by sending a minimal request.
  ///
  /// Returns `true` if the API responds successfully, `false` otherwise.
  Future<bool> testConnection() async {
    try {
      final Response<Map<String, dynamic>> response =
          await _dio.post<Map<String, dynamic>>(
        '/chat/completions',
        data: <String, dynamic>{
          'model': _model,
          'messages': <Map<String, String>>[
            <String, String>{
              'role': 'user',
              'content': 'Hi',
            },
          ],
          'temperature': _temperature,
          'stream': false,
          'max_tokens': 5,
        },
        options: Options(
          headers: <String, dynamic>{
            'Authorization': 'Bearer $_apiKey',
          },
          receiveTimeout: const Duration(seconds: 15),
        ),
      );

      return response.statusCode == 200;
    } on DioException {
      return false;
    } catch (_) {
      return false;
    }
  }

  /// Cancels any active streaming request.
  void cancelActiveRequest() {
    _activeCancelToken?.cancel('Request cancelled by user');
    _activeCancelToken = null;
  }

  /// Releases resources held by the Dio instance.
  void dispose() {
    cancelActiveRequest();
    _dio.close(force: true);
  }

  /// Maps [DioException] to user-friendly error messages in Bahasa Melayu.
  Stream<String> _handleDioError(DioException e) async* {
    if (e.type == DioExceptionType.cancel) {
      // Cancelled deliberately – no error to surface.
      return;
    }

    final int? statusCode = e.response?.statusCode;

    switch (statusCode) {
      case 401:
        yield '[ERROR] Kunci API tidak sah atau telah tamat tempoh. '
            'Sila semak tetapan API anda.';
      case 429:
        yield '[ERROR] Had kadar API telah dicapai. '
            'Sila tunggu sebentar dan cuba lagi.';
      case 500:
        yield '[ERROR] Ralat pelayan DeepSeek (500). '
            'Sila cuba lagi kemudian.';
      case 502:
        yield '[ERROR] Pelayan DeepSeek tidak tersedia (502). '
            'Sila cuba lagi kemudian.';
      case 503:
        yield '[ERROR] Perkhidmatan DeepSeek sedang penyelenggaraan (503). '
            'Sila cuba lagi kemudian.';
      default:
        if (e.type == DioExceptionType.connectionTimeout ||
            e.type == DioExceptionType.sendTimeout ||
            e.type == DioExceptionType.receiveTimeout) {
          yield '[ERROR] Sambungan tamat masa. '
              'Sila semak sambungan internet anda.';
        } else if (e.type == DioExceptionType.connectionError) {
          yield '[ERROR] Gagal menyambung ke pelayan. '
              'Sila semak sambungan internet anda.';
        } else {
          yield '[ERROR] Ralat tidak dijangka: '
              '${e.message ?? 'Tiada maklumat lanjut.'}';
        }
    }
  }
}
