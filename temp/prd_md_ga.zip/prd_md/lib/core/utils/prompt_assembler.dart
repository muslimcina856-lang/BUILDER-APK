/// Represents an AI skill/persona that can be activated in a session.
///
/// This is a lightweight data class used by [PromptAssembler] to build
/// system prompts. The full domain entity lives in the skills feature.
class AISkill {
  final String name;
  final String description;
  final String systemPrompt;
  final bool isActive;

  const AISkill({
    required this.name,
    required this.description,
    required this.systemPrompt,
    this.isActive = true,
  });
}

/// Assembles system prompts from active skills, search context,
/// and special instructions for PRD/README generation.
class PromptAssembler {
  const PromptAssembler();

  // ---------------------------------------------------------------------------
  // Constants
  // ---------------------------------------------------------------------------

  static const String _header =
      'Sila bertindak mengikut spesifikasi dan peranan kemahiran berikut:';

  static const String _footer =
      'Sila jawab input pengguna berasaskan gabungan kepakaran di atas.';

  static const String _prdInstruction =
      'Apabila diminta menjana PRD, gunakan format 40-seksyen standard industri.';

  static const String _readmeInstruction =
      'Apabila diminta menjana README.md, gunakan format 17-seksyen standard.';

  static const String _clarificationFormInstruction = '''
Apabila anda memerlukan maklumat tambahan dari pengguna, kembalikan soalan dalam format berikut:
[CLARIFICATION_FORM]{"question":"...","field_name":"...","selection_type":"single|multiple","options":[{"label":"...","value":"..."}],"allow_custom":true/false,"custom_placeholder":"..."}[/CLARIFICATION_FORM]
JSON format: {"question":"...","field_name":"...","selection_type":"single|multiple","options":[{"label":"...","value":"..."}],"allow_custom":true/false,"custom_placeholder":"..."}''';

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------

  /// Assembles a system prompt incorporating all [activeSkills].
  ///
  /// Each skill is formatted as a `[KEMAHIRAN: <name>]` block containing
  /// its system prompt. Special instructions for PRD/README generation
  /// and the clarification form protocol are appended automatically.
  String assembleSystemPrompt(List<AISkill> activeSkills) {
    final StringBuffer sb = StringBuffer();

    sb.writeln(_header);
    sb.writeln();

    if (activeSkills.isEmpty) {
      sb.writeln(getDefaultSystemPrompt());
    } else {
      for (final AISkill skill in activeSkills) {
        sb.writeln('[KEMAHIRAN: ${skill.name}]');
        sb.writeln(skill.systemPrompt);
        sb.writeln('[/KEMAHIRAN]');
        sb.writeln();
      }
    }

    sb.writeln();
    sb.writeln('---');
    sb.writeln();
    sb.writeln('ARAHAN KHAS:');
    sb.writeln(_prdInstruction);
    sb.writeln(_readmeInstruction);
    sb.writeln();
    sb.writeln('PROTOKOL BORANG PENJELASAN:');
    sb.writeln(_clarificationFormInstruction);
    sb.writeln();
    sb.writeln('---');
    sb.writeln();
    sb.writeln(_footer);

    return sb.toString();
  }

  /// Wraps [searchResults] and [userMessage] into a combined prompt
  /// that includes web search context.
  String assembleSearchContext(
      String searchResults, String userMessage) {
    final StringBuffer sb = StringBuffer();

    sb.writeln(searchResults);
    sb.writeln();
    sb.writeln('Soalan pengguna:');
    sb.writeln(userMessage);

    return sb.toString();
  }

  /// Returns a default system prompt for use when no skills are active.
  ///
  /// Acts as a combined Product Manager & Software Architect persona.
  String getDefaultSystemPrompt() {
    return '''
Anda adalah pembantu AI yang menggabungkan kepakaran sebagai Pengurus Produk (Product Manager) dan Arkitek Perisian (Software Architect).

Sebagai Pengurus Produk:
- Anda mahir dalam merancang produk digital dari konsep hingga pelancaran.
- Anda boleh menulis PRD (Product Requirements Document) lengkap dengan 40 seksyen standard industri.
- Anda memahami analisis pasaran, persona pengguna, user story, dan metrik kejayaan.
- Anda boleh merancang roadmap produk dan menetapkan keutamaan ciri.

Sebagai Arkitek Perisian:
- Anda mahir dalam mereka bentuk sistem perisian berskala.
- Anda memahami pelbagai corak seni bina: Clean Architecture, Microservices, Event-Driven, CQRS.
- Anda boleh menulis README.md profesional dengan 17 seksyen standard.
- Anda mahir dalam membuat keputusan teknologi (tech stack) yang tepat.
- Anda memahami keperluan keselamatan, prestasi, dan kebolehskalaan.

Gaya Komunikasi:
- Jawab dalam Bahasa Melayu secara lalai kecuali diminta sebaliknya.
- Berikan jawapan yang terstruktur, padat, dan boleh dilaksanakan.
- Gunakan format Markdown untuk kejelasan.
- Sertakan contoh kod apabila relevan.
- Berfikir secara kritikal dan berikan analisis mendalam.
''';
  }
}
