/// Semua rentetan UI untuk aplikasi PRD MD.
///
/// Ditulis dalam Bahasa Melayu untuk keseluruhan antara muka.
abstract final class AppStrings {
  // ─── Umum / Jenama ─────────────────────────────────────────────────
  static const String appName = 'PRD MD';
  static const String appTagline = 'AI-Powered PRD & README Generator';
  static const String appVersion = 'v1.0.0';

  // ─── Navigasi ──────────────────────────────────────────────────────
  static const String navDashboard = 'Papan Pemuka';
  static const String navChat = 'Chat AI';
  static const String navSkills = 'Kemahiran';
  static const String navSettings = 'Tetapan';
  static const String navHistory = 'Sejarah';

  // ─── Butang ────────────────────────────────────────────────────────
  static const String btnGenerate = 'Jana';
  static const String btnSave = 'Simpan';
  static const String btnCancel = 'Batal';
  static const String btnDelete = 'Padam';
  static const String btnEdit = 'Sunting';
  static const String btnCopy = 'Salin';
  static const String btnShare = 'Kongsi';
  static const String btnExport = 'Eksport';
  static const String btnRetry = 'Cuba Lagi';
  static const String btnSend = 'Hantar';
  static const String btnContinue = 'Teruskan';
  static const String btnBack = 'Kembali';
  static const String btnClose = 'Tutup';
  static const String btnConfirm = 'Sahkan';
  static const String btnNewChat = 'Chat Baharu';
  static const String btnNewProject = 'Projek Baharu';
  static const String btnViewAll = 'Lihat Semua';
  static const String btnApply = 'Gunakan';
  static const String btnReset = 'Set Semula';
  static const String btnClearAll = 'Padam Semua';
  static const String btnSelectAll = 'Pilih Semua';

  // ─── Tajuk / Header ───────────────────────────────────────────────
  static const String titleDashboard = 'Papan Pemuka';
  static const String titleChat = 'Chat dengan AI';
  static const String titleSkills = 'Kemahiran AI';
  static const String titleSettings = 'Tetapan';
  static const String titleHistory = 'Sejarah Projek';
  static const String titleApiKey = 'Kunci API';
  static const String titleNewProject = 'Projek Baharu';
  static const String titleEditProject = 'Sunting Projek';
  static const String titleProjectDetail = 'Butiran Projek';
  static const String titleExport = 'Eksport Dokumen';
  static const String titleAbout = 'Tentang Aplikasi';
  static const String titleDeleteConfirm = 'Sahkan Pemadaman';
  static const String titleClearConfirm = 'Sahkan Pembersihan';
  static const String titleSelectSkill = 'Pilih Kemahiran';

  // ─── Hint / Placeholder ───────────────────────────────────────────
  static const String hintApiKey = 'Masukkan kunci API DeepSeek anda...';
  static const String hintMessage = 'Tulis mesej anda di sini...';
  static const String hintProjectName = 'Nama projek anda...';
  static const String hintProjectDesc = 'Huraikan projek anda secara ringkas...';
  static const String hintSearch = 'Cari...';
  static const String hintSkillName = 'Nama kemahiran...';
  static const String hintSkillPrompt = 'Prompt untuk kemahiran ini...';

  // ─── Label ─────────────────────────────────────────────────────────
  static const String labelApiKey = 'Kunci API DeepSeek';
  static const String labelProjectName = 'Nama Projek';
  static const String labelProjectDesc = 'Huraian Projek';
  static const String labelModel = 'Model AI';
  static const String labelTemperature = 'Suhu (Temperature)';
  static const String labelMaxTokens = 'Token Maksimum';
  static const String labelSkillName = 'Nama Kemahiran';
  static const String labelSkillPrompt = 'Prompt Kemahiran';
  static const String labelCategory = 'Kategori';
  static const String labelCreatedAt = 'Dicipta pada';
  static const String labelUpdatedAt = 'Dikemas kini pada';
  static const String labelTotalProjects = 'Jumlah Projek';
  static const String labelTotalChats = 'Jumlah Chat';
  static const String labelRecentProjects = 'Projek Terkini';
  static const String labelQuickActions = 'Tindakan Pantas';

  // ─── Mesej Berjaya ─────────────────────────────────────────────────
  static const String successApiKeySaved = 'Kunci API berjaya disimpan.';
  static const String successProjectSaved = 'Projek berjaya disimpan.';
  static const String successProjectDeleted = 'Projek berjaya dipadam.';
  static const String successCopied = 'Berjaya disalin ke papan klip.';
  static const String successExported = 'Dokumen berjaya dieksport.';
  static const String successSkillSaved = 'Kemahiran berjaya disimpan.';
  static const String successSkillDeleted = 'Kemahiran berjaya dipadam.';
  static const String successHistoryCleared = 'Sejarah berjaya dipadam.';

  // ─── Mesej Ralat ──────────────────────────────────────────────────
  static const String errorGeneric = 'Ralat tidak dijangka berlaku. Sila cuba lagi.';
  static const String errorNoInternet = 'Tiada sambungan internet. Sila semak rangkaian anda.';
  static const String errorApiKeyMissing = 'Kunci API belum ditetapkan. Sila masukkan kunci API dalam Tetapan.';
  static const String errorApiKeyInvalid = 'Kunci API tidak sah. Sila semak dan cuba lagi.';
  static const String errorServerDown = 'Pelayan tidak dapat dihubungi. Sila cuba sebentar lagi.';
  static const String errorTimeout = 'Permintaan tamat masa. Sila cuba lagi.';
  static const String errorEmptyMessage = 'Mesej tidak boleh kosong.';
  static const String errorEmptyProjectName = 'Nama projek tidak boleh kosong.';
  static const String errorEmptyField = 'Ruangan ini tidak boleh kosong.';
  static const String errorParsingResponse = 'Gagal memproses respons dari AI.';
  static const String errorSaveFailed = 'Gagal menyimpan data. Sila cuba lagi.';
  static const String errorLoadFailed = 'Gagal memuatkan data. Sila cuba lagi.';
  static const String errorDeleteFailed = 'Gagal memadam data. Sila cuba lagi.';
  static const String errorRateLimited = 'Terlalu banyak permintaan. Sila tunggu sebentar.';
  static const String errorTokenLimit = 'Had token dicapai. Sila mulakan chat baharu.';

  // ─── Dialog / Pengesahan ──────────────────────────────────────────
  static const String confirmDelete =
      'Adakah anda pasti mahu memadam item ini? Tindakan ini tidak boleh dibatalkan.';
  static const String confirmClearHistory =
      'Adakah anda pasti mahu memadam semua sejarah? Tindakan ini tidak boleh dibatalkan.';
  static const String confirmDeleteProject =
      'Adakah anda pasti mahu memadam projek ini? Semua chat berkaitan juga akan dipadam.';
  static const String confirmNewChat =
      'Adakah anda mahu memulakan chat baharu? Chat semasa akan disimpan dalam sejarah.';

  // ─── Status / Info ────────────────────────────────────────────────
  static const String statusGenerating = 'Sedang menjana...';
  static const String statusConnecting = 'Menyambung ke AI...';
  static const String statusLoading = 'Memuatkan...';
  static const String statusEmpty = 'Tiada data ditemui.';
  static const String statusNoProjects = 'Belum ada projek. Mulakan projek baharu!';
  static const String statusNoChats = 'Belum ada chat. Mula bersembang dengan AI!';
  static const String statusNoSkills = 'Belum ada kemahiran. Tambah kemahiran baharu!';
  static const String statusNoHistory = 'Tiada sejarah untuk dipaparkan.';

  // ─── Splash / Onboarding ──────────────────────────────────────────
  static const String splashWelcome = 'Selamat Datang ke PRD MD';
  static const String splashSubtitle =
      'Jana dokumen PRD & README profesional dengan kuasa AI.';
  static const String onboardingStep1Title = 'Tetapkan Kunci API';
  static const String onboardingStep1Desc =
      'Masukkan kunci API DeepSeek anda untuk bermula.';
  static const String onboardingStep2Title = 'Cipta Projek';
  static const String onboardingStep2Desc =
      'Huraikan projek anda dan biarkan AI menjana dokumentasi.';
  static const String onboardingStep3Title = 'Eksport & Kongsi';
  static const String onboardingStep3Desc =
      'Eksport dokumen dalam format Markdown dan kongsi.';

  // ─── Kemahiran Lalai ──────────────────────────────────────────────
  static const String skillPrdName = 'Penjana PRD';
  static const String skillPrdDesc =
      'Jana dokumen PRD lengkap berdasarkan huraian projek.';
  static const String skillReadmeName = 'Penjana README';
  static const String skillReadmeDesc =
      'Jana fail README.md profesional untuk repositori anda.';
  static const String skillUserStoryName = 'Penjana User Story';
  static const String skillUserStoryDesc =
      'Jana user story mengikut format Agile standard.';
  static const String skillApiDocName = 'Penjana Dokumentasi API';
  static const String skillApiDocDesc =
      'Jana dokumentasi API berdasarkan spesifikasi endpoint.';

  // ─── System Prompt (Template) ─────────────────────────────────────
  static const String defaultSystemPrompt = '''
Anda adalah pembantu AI profesional yang pakar dalam pembangunan perisian.
Anda membantu pengguna menjana dokumen teknikal seperti PRD (Product Requirements Document),
README.md, User Story, dan dokumentasi API.

Arahan utama:
1. Sentiasa gunakan Bahasa Melayu dalam respons melainkan diminta sebaliknya.
2. Hasilkan output dalam format Markdown yang kemas dan terstruktur.
3. Pastikan setiap dokumen lengkap, terperinci, dan sedia untuk digunakan.
4. Ikut amalan terbaik industri untuk setiap jenis dokumen.
5. Berikan contoh kod jika berkaitan.
6. Gunakan tajuk, senarai, dan jadual untuk kejelasan.
''';

  /// Template untuk memasang prompt kemahiran bersama mesej pengguna.
  static const String skillPromptTemplate = '''
### Kemahiran Aktif: {skill_name}

{skill_prompt}

---

### Permintaan Pengguna:
{user_message}
''';

  // ─── About ────────────────────────────────────────────────────────
  static const String aboutDescription =
      'PRD MD ialah aplikasi penjana dokumen teknikal berkuasa AI. '
      'Gunakan AI untuk menjana PRD, README, User Story dan banyak lagi '
      'dengan pantas dan profesional.';
  static const String aboutDeveloper = 'Dibangunkan dengan ❤️';
  static const String aboutPoweredBy = 'Dikuasakan oleh DeepSeek AI';
}
