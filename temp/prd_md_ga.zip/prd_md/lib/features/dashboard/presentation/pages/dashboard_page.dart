import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../chat/domain/entities/chat_session.dart';
import '../../../chat/presentation/pages/chat_room_page.dart';
import '../bloc/dashboard_bloc.dart';
import '../widgets/empty_state_widget.dart';
import '../widgets/session_card.dart';
import 'pre_chat_config_sheet.dart';
import '../../../settings/presentation/pages/settings_page.dart';
import '../../../settings/presentation/bloc/settings_bloc.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    context.read<DashboardBloc>().add(LoadDashboard());
    context.read<SettingsBloc>().add(LoadSettings());
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _openNewChatConfig(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const PreChatConfigSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          AppStrings.appName,
          style: GoogleFonts.inter(
            fontSize: 20,
            fontWeight: FontWeight.w900,
            letterSpacing: 1,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.scaffold.withValues(alpha: 0.9),
                AppColors.scaffold.withValues(alpha: 0.0),
              ],
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined, color: Colors.white),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (context) => const SettingsPage(),
                ),
              ).then((_) {
                // Segarkan semula dashboard sekiranya data dipadam dalam settings
                context.read<DashboardBloc>().add(LoadDashboard());
              });
            },
          ),
        ],
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: AppColors.backgroundGradient,
        ),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search Input
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                child: TextField(
                  controller: _searchController,
                  onChanged: (val) {
                    context.read<DashboardBloc>().add(SearchDashboardSessions(val));
                  },
                  decoration: const InputDecoration(
                    hintText: 'Cari tajuk perbualan...',
                    prefixIcon: Icon(Icons.search, color: AppColors.textMuted),
                    contentPadding: EdgeInsets.symmetric(vertical: 12),
                  ),
                  style: const TextStyle(color: Colors.white),
                ),
              ),
              // Sessions list or Empty state
              Expanded(
                child: BlocBuilder<DashboardBloc, DashboardState>(
                  builder: (context, state) {
                    if (state is DashboardLoading) {
                      return const Center(
                        child: CircularProgressIndicator(color: AppColors.accent),
                      );
                    }
                    if (state is DashboardError) {
                      return Center(
                        child: Text(
                          state.message,
                          style: const TextStyle(color: AppColors.error),
                        ),
                      );
                    }
                    if (state is DashboardLoaded) {
                      final List<ChatSession> list = state.sessions;
                      if (list.isEmpty) {
                        return EmptyStateWidget(
                          onTapNewChat: () => _openNewChatConfig(context),
                        );
                      }
                      return RefreshIndicator(
                        onRefresh: () async {
                          context.read<DashboardBloc>().add(LoadDashboard());
                        },
                        color: AppColors.accent,
                        backgroundColor: AppColors.card,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                          itemCount: list.length,
                          itemBuilder: (context, index) {
                            final ChatSession session = list[index];
                            return SessionCard(
                              session: session,
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute<void>(
                                    builder: (context) => ChatRoomPage(session: session),
                                  ),
                                ).then((_) {
                                  context.read<DashboardBloc>().add(LoadDashboard());
                                });
                              },
                              onDelete: () {
                                context.read<DashboardBloc>().add(DeleteDashboardSession(session.id));
                              },
                            )
                                .animate()
                                .fadeIn(duration: 300.ms, delay: (index * 50).ms)
                                .slideY(begin: 0.1, end: 0);
                          },
                        ),
                      );
                    }
                    return const SizedBox();
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openNewChatConfig(context),
        child: Container(
          width: 56,
          height: 56,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            gradient: AppColors.accentGradient,
          ),
          child: const Icon(Icons.add, color: AppColors.scaffold, size: 28),
        ),
      ),
    );
  }
}
