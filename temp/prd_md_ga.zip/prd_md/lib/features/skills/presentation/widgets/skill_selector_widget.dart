import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/ai_skill.dart';
import '../bloc/skills_bloc.dart';
import 'create_skill_dialog.dart';

class SkillSelectorWidget extends StatefulWidget {
  const SkillSelectorWidget({super.key});

  @override
  State<SkillSelectorWidget> createState() => _SkillSelectorWidgetState();
}

class _SkillSelectorWidgetState extends State<SkillSelectorWidget> {
  String _activeCategory = 'Semua';
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _applyFilter() {
    context.read<SkillsBloc>().add(
          FilterSkills(
            query: _searchController.text,
            category: _activeCategory,
          ),
        );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
        border: Border(
          top: BorderSide(color: AppColors.cardBorder),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            margin: const EdgeInsets.only(top: 12, bottom: 8),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.cardBorder,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Hab Kemahiran AI',
                  style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                TextButton.icon(
                  icon: const Icon(Icons.add, size: 18, color: AppColors.accent),
                  label: const Text('Kustom Baru', style: TextStyle(color: AppColors.accent)),
                  onPressed: () {
                    showDialog<void>(
                      context: context,
                      builder: (context) => const CreateSkillDialog(),
                    );
                  },
                ),
              ],
            ),
          ),
          // Search & Filter
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            child: TextField(
              controller: _searchController,
              onChanged: (_) => _applyFilter(),
              decoration: const InputDecoration(
                hintText: 'Cari kemahiran...',
                prefixIcon: Icon(Icons.search, size: 20, color: AppColors.textMuted),
                contentPadding: EdgeInsets.symmetric(vertical: 10),
              ),
              style: const TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(height: 8),
          // Filter Tabs
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(width: 20),
              _buildFilterTab('Semua'),
              const SizedBox(width: 8),
              _buildFilterTab('Sistem'),
              const SizedBox(width: 8),
              _buildFilterTab('Kustom'),
            ],
          ),
          const SizedBox(height: 12),
          // Skills List
          Flexible(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 350),
              child: BlocBuilder<SkillsBloc, SkillsState>(
                builder: (context, state) {
                  if (state is SkillsLoading) {
                    return const Center(
                      child: Padding(
                        padding: EdgeInsets.all(32),
                        child: CircularProgressIndicator(color: AppColors.accent),
                      ),
                    );
                  }
                  if (state is SkillsLoaded) {
                    final List<AISkill> list = state.filteredSkills;
                    if (list.isEmpty) {
                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.all(32),
                          child: Text(
                            'Tiada kemahiran ditemui.',
                            style: TextStyle(color: AppColors.textMuted),
                          ),
                        ),
                      );
                    }
                    return ListView.builder(
                      shrinkWrap: true,
                      itemCount: list.length,
                      itemBuilder: (context, index) {
                        final AISkill skill = list[index];
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.scaffold,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: skill.isActive ? AppColors.accent.withValues(alpha: 0.3) : AppColors.cardBorder,
                            ),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            title: Row(
                              children: [
                                Text(
                                  skill.name,
                                  style: GoogleFonts.inter(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontSize: 14,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                _buildBadge(skill.isDefault),
                              ],
                            ),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                skill.instruction,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                              ),
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Checkbox(
                                  value: skill.isActive,
                                  activeColor: AppColors.accent,
                                  checkColor: AppColors.scaffold,
                                  onChanged: (val) {
                                    context.read<SkillsBloc>().add(
                                          ToggleSkillActive(
                                            skillId: skill.id,
                                            isActive: val ?? false,
                                          ),
                                    );
                                  },
                                ),
                                if (!skill.isDefault) ...[
                                  IconButton(
                                    icon: const Icon(Icons.delete_outline, size: 20, color: AppColors.error),
                                    onPressed: () {
                                      context.read<SkillsBloc>().add(DeleteSkill(skill.id));
                                    },
                                  ),
                                ],
                              ],
                            ),
                          ],
                        );
                      },
                    );
                  }
                  return const SizedBox();
                },
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildFilterTab(String cat) {
    final bool active = _activeCategory == cat;
    return GestureDetector(
      onTap: () {
        setState(() {
          _activeCategory = cat;
        });
        _applyFilter();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.accent.withValues(alpha: 0.15) : AppColors.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? AppColors.accent : AppColors.cardBorder,
          ),
        ),
        child: Text(
          cat,
          style: GoogleFonts.inter(
            color: active ? Colors.white : AppColors.textMuted,
            fontSize: 12,
            fontWeight: active ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildBadge(bool isDefault) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: isDefault ? AppColors.accent.withValues(alpha: 0.1) : AppColors.secondary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(
          color: isDefault ? AppColors.accent : AppColors.secondary,
          width: 0.5,
        ),
      ),
      child: Text(
        isDefault ? 'Sistem' : 'Kustom',
        style: TextStyle(
          color: isDefault ? AppColors.accent : AppColors.secondary,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
