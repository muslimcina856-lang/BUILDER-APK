import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../bloc/skills_bloc.dart';

class CreateSkillDialog extends StatefulWidget {
  const CreateSkillDialog({super.key});

  @override
  State<CreateSkillDialog> createState() => _CreateSkillDialogState();
}

class _CreateSkillDialogState extends State<CreateSkillDialog> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _instructionController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _instructionController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      context.read<SkillsBloc>().add(
            CreateSkill(
              name: _nameController.text.trim(),
              instruction: _instructionController.text.trim(),
            ),
          );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(AppTheme.radiusMd),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Cipta Kemahiran Baru',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 16),
              // Name Field
              TextFormField(
                controller: _nameController,
                style: const TextStyle(color: Colors.white),
                maxLength: 50,
                decoration: const InputDecoration(
                  labelText: 'Nama Kemahiran (Skills Name)',
                  hintText: 'Contoh: Arkitek Microservices',
                  counterStyle: TextStyle(color: AppColors.textMuted),
                ),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) {
                    return 'Sila masukkan nama kemahiran';
                  }
                  if (val.trim().length > 50) {
                    return 'Nama tidak boleh melebihi 50 aksara';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              // Instruction Field
              TextFormField(
                controller: _instructionController,
                style: const TextStyle(color: Colors.white),
                maxLength: 2000,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'Arahan / Instruction',
                  hintText: 'Nyatakan peranan dan syarat yang mesti dipatuhi oleh AI...',
                  counterStyle: TextStyle(color: AppColors.textMuted),
                ),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) {
                    return 'Sila masukkan arahan kemahiran';
                  }
                  if (val.trim().length < 10) {
                    return 'Arahan mestilah sekurang-kurangnya 10 aksara';
                  }
                  if (val.trim().length > 2000) {
                    return 'Arahan tidak boleh melebihi 2000 aksara';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Batal', style: TextStyle(color: AppColors.textMuted)),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      foregroundColor: AppColors.scaffold,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    ),
                    child: const Text('Simpan'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
