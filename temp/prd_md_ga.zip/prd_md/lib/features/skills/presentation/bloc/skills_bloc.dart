import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

import '../../domain/entities/ai_skill.dart';
import '../../../../services/database_service.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class SkillsEvent extends Equatable {
  const SkillsEvent();
  @override
  List<Object?> get props => [];
}

class LoadSkills extends SkillsEvent {}

class CreateSkill extends SkillsEvent {
  final String name;
  final String instruction;
  const CreateSkill({required this.name, required this.instruction});
  @override
  List<Object?> get props => [name, instruction];
}

class ToggleSkillActive extends SkillsEvent {
  final String skillId;
  final bool isActive;
  const ToggleSkillActive({required this.skillId, required this.isActive});
  @override
  List<Object?> get props => [skillId, isActive];
}

class DeleteSkill extends SkillsEvent {
  final String skillId;
  const DeleteSkill(this.skillId);
  @override
  List<Object?> get props => [skillId];
}

class FilterSkills extends SkillsEvent {
  final String query;
  final String category; // 'Semua', 'Sistem', 'Kustom'
  const FilterSkills({required this.query, required this.category});
  @override
  List<Object?> get props => [query, category];
}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class SkillsState extends Equatable {
  const SkillsState();
  @override
  List<Object?> get props => [];
}

class SkillsInitial extends SkillsState {}

class SkillsLoading extends SkillsState {}

class SkillsLoaded extends SkillsState {
  final List<AISkill> allSkills;
  final List<AISkill> filteredSkills;
  final List<String> activeSkillIds;

  const SkillsLoaded({
    required this.allSkills,
    required this.filteredSkills,
    required this.activeSkillIds,
  });

  SkillsLoaded copyWith({
    List<AISkill>? allSkills,
    List<AISkill>? filteredSkills,
    List<String>? activeSkillIds,
  }) {
    return SkillsLoaded(
      allSkills: allSkills ?? this.allSkills,
      filteredSkills: filteredSkills ?? this.filteredSkills,
      activeSkillIds: activeSkillIds ?? this.activeSkillIds,
    );
  }

  @override
  List<Object?> get props => [allSkills, filteredSkills, activeSkillIds];
}

class SkillCreated extends SkillsState {
  final AISkill skill;
  const SkillCreated(this.skill);
  @override
  List<Object?> get props => [skill];
}

class SkillsError extends SkillsState {
  final String message;
  const SkillsError(this.message);
  @override
  List<Object?> get props => [message];
}

// -----------------------------------------------------------------------------
// BLOC IMPLEMENTATION
// -----------------------------------------------------------------------------
class SkillsBloc extends Bloc<SkillsEvent, SkillsState> {
  final DatabaseService _dbService;
  final Uuid _uuid = const Uuid();

  SkillsBloc({DatabaseService? dbService})
      : _dbService = dbService ?? DatabaseService(),
        super(SkillsInitial()) {
    on<LoadSkills>(_onLoadSkills);
    on<CreateSkill>(_onCreateSkill);
    on<ToggleSkillActive>(_onToggleSkillActive);
    on<DeleteSkill>(_onDeleteSkill);
    on<FilterSkills>(_onFilterSkills);
  }

  Future<void> _onLoadSkills(LoadSkills event, Emitter<SkillsState> emit) async {
    emit(SkillsLoading());
    try {
      final List<Map<String, dynamic>> rawSkills = await _dbService.getAllSkills();
      
      // Seed default skills jika kosong
      if (rawSkills.isEmpty) {
        await _seedDefaultSkills();
        final List<Map<String, dynamic>> reloaded = await _dbService.getAllSkills();
        _emitLoaded(reloaded, emit);
        return;
      }

      _emitLoaded(rawSkills, emit);
    } catch (e) {
      emit(SkillsError('Gagal memuatkan kemahiran: $e'));
    }
  }

  void _emitLoaded(List<Map<String, dynamic>> rawSkills, Emitter<SkillsState> emit) {
    final List<AISkill> skills = rawSkills.map((row) {
      final Map<String, dynamic> mapped = Map<String, dynamic>.from(row);
      mapped['isDefault'] = row['is_default'];
      mapped['isActive'] = row['is_active'];
      mapped['instruction'] = row['system_prompt'];
      return AISkill.fromMap(mapped);
    }).toList();

    final List<String> activeIds = skills
        .where((s) => s.isActive)
        .map((s) => s.id)
        .toList();

    emit(SkillsLoaded(
      allSkills: skills,
      filteredSkills: skills,
      activeSkillIds: activeIds,
    ));
  }

  Future<void> _seedDefaultSkills() async {
    final List<Map<String, String>> defaultList = [
      {
        'name': 'Pakar PM & Arkitek Perisian',
        'desc': 'Sistem prompt standard untuk Product Manager & Arkitek Perisian am.',
        'prompt': 'Anda adalah Pakar Pengurusan Produk (Product Manager) senior dan Arkitek Perisian. Tugas anda adalah membantu merangka spesifikasi produk yang jelas, ERD Mermaid, dan struktur fail sistem dengan reka bentuk terbaik.'
      },
      {
        'name': 'Database Architect',
        'desc': 'Reka bentuk pangkalan data 3NF beserta schema ERD Mermaid.',
        'prompt': 'Sila bertindak mengikut spesifikasi Database Architect. Pastikan semua reka bentuk pangkalan data mematuhi bentuk normalisasi ketiga (3NF) dan menyediakan schema ERD Mermaid yang jelas.'
      },
      {
        'name': 'Security Analyst',
        'desc': 'Memastikan standard keselamatan OWASP Top 10 dan dasar penyulitan API.',
        'prompt': 'Sila bertindak mengikut spesifikasi Security Analyst. Sertakan keperluan keselamatan OWASP Top 10 dan dasar penyulitan bagi setiap pangkalan data atau API yang direka.'
      },
      {
        'name': 'QA & Testing Expert',
        'desc': 'Menulis rancangan ujian (test plan) dan kes ujian terperinci.',
        'prompt': 'Sila bertindak sebagai Pakar QA & Ujian Perisian. Sediakan strategi ujian yang menyeluruh, kes ujian (unit, integrasi, E2E), dan checklist penerimaan kualiti.'
      }
    ];

    for (final Map<String, String> item in defaultList) {
      await _dbService.createSkill(
        id: _uuid.v4(),
        name: item['name']!,
        description: item['desc']!,
        systemPrompt: item['prompt']!,
        isDefault: true,
        isActive: true,
      );
    }
  }

  Future<void> _onCreateSkill(CreateSkill event, Emitter<SkillsState> emit) async {
    final String name = event.name.trim();
    final String instruction = event.instruction.trim();

    // Validasi
    if (name.isEmpty || name.length > 50) {
      emit(const SkillsError('Nama skill mestilah antara 1 hingga 50 aksara.'));
      return;
    }
    if (instruction.length < 10 || instruction.length > 2000) {
      emit(const SkillsError('Arahan skill mestilah antara 10 hingga 2000 aksara.'));
      return;
    }

    try {
      final String id = _uuid.v4();
      await _dbService.createSkill(
        id: id,
        name: name,
        description: name, // use name as desc
        systemPrompt: instruction,
        isDefault: false,
        isActive: true,
      );

      final AISkill newSkill = AISkill(
        id: id,
        name: name,
        instruction: instruction,
        isDefault: false,
        isActive: true,
      );

      emit(SkillCreated(newSkill));
      add(LoadSkills());
    } catch (e) {
      emit(SkillsError('Gagal mencipta kemahiran kustom: $e'));
    }
  }

  Future<void> _onToggleSkillActive(ToggleSkillActive event, Emitter<SettingsState> _emit) async {
    final SkillsState currentState = state;
    if (currentState is SkillsLoaded) {
      try {
        await _dbService.updateSkill(
          id: event.skillId,
          isActive: event.isActive,
        );

        final List<AISkill> updatedSkills = currentState.allSkills.map((s) {
          if (s.id == event.skillId) {
            return s.copyWith(isActive: event.isActive);
          }
          return s;
        }).toList();

        final List<String> updatedActiveIds = List<String>.from(currentState.activeSkillIds);
        if (event.isActive) {
          if (!updatedActiveIds.contains(event.skillId)) {
            updatedActiveIds.add(event.skillId);
          }
        } else {
          updatedActiveIds.remove(event.skillId);
        }

        emit(currentState.copyWith(
          allSkills: updatedSkills,
          filteredSkills: updatedSkills,
          activeSkillIds: updatedActiveIds,
        ));
      } catch (e) {
        emit(SkillsError('Gagal menukar status aktif skill: $e'));
      }
    }
  }

  Future<void> _onDeleteSkill(DeleteSkill event, Emitter<SkillsState> emit) async {
    try {
      await _dbService.deleteSkill(event.skillId);
      add(LoadSkills());
    } catch (e) {
      emit(SkillsError('Gagal memadam kemahiran: $e'));
    }
  }

  void _onFilterSkills(FilterSkills event, Emitter<SkillsState> emit) {
    final SkillsState currentState = state;
    if (currentState is SkillsLoaded) {
      final String query = event.query.toLowerCase();
      final String cat = event.category;

      final List<AISkill> filtered = currentState.allSkills.where((s) {
        final bool matchesQuery = s.name.toLowerCase().contains(query) ||
            s.instruction.toLowerCase().contains(query);
        
        final bool matchesCategory = cat == 'Semua' ||
            (cat == 'Sistem' && s.isDefault) ||
            (cat == 'Kustom' && !s.isDefault);

        return matchesQuery && matchesCategory;
      }).toList();

      emit(currentState.copyWith(filteredSkills: filtered));
    }
  }
}
