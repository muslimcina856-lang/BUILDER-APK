import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:uuid/uuid.dart';

import '../../domain/entities/chat_session.dart';
import '../../domain/entities/chat_message.dart';
import '../../domain/repositories/chat_repository.dart';
import '../../data/repositories/chat_repository_impl.dart';
import '../../../../core/utils/search_service.dart';
import '../../../../core/utils/prompt_assembler.dart';
import '../../../../core/utils/clarification_parser.dart';
import '../../../../services/database_service.dart';
import '../../../skills/domain/entities/ai_skill.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class ChatEvent extends Equatable {
  const ChatEvent();
  @override
  List<Object?> get props => [];
}

class LoadChatSessions extends ChatEvent {}

class CreateNewSession extends ChatEvent {
  final String title;
  final String modelType;
  final List<String> skillIds;

  const CreateNewSession({
    required this.title,
    required this.modelType,
    required this.skillIds,
  });

  @override
  List<Object?> get props => [title, modelType, skillIds];
}

class LoadMessages extends ChatEvent {
  final String sessionId;
  const LoadMessages(this.sessionId);
  @override
  List<Object?> get props => [sessionId];
}

class SendMessage extends ChatEvent {
  final String sessionId;
  final String content;
  final String apiKey;
  final String model;
  final bool isWebSearchEnabled;

  const SendMessage({
    required this.sessionId,
    required this.content,
    required this.apiKey,
    required this.model,
    required this.isWebSearchEnabled,
  });

  @override
  List<Object?> get props => [sessionId, content, apiKey, model, isWebSearchEnabled];
}

class SubmitFormResponse extends ChatEvent {
  final String sessionId;
  final String messageId; // message id that contains the form
  final String fieldName;
  final List<String> selectedValues;
  final String? customValue;
  final String apiKey;
  final String model;

  const SubmitFormResponse({
    required this.sessionId,
    required this.messageId,
    required this.fieldName,
    required this.selectedValues,
    this.customValue,
    required this.apiKey,
    required this.model,
  });

  @override
  List<Object?> get props => [sessionId, messageId, fieldName, selectedValues, customValue, apiKey, model];
}

class UpdateSessionTitle extends ChatEvent {
  final String sessionId;
  final String newTitle;
  const UpdateSessionTitle({required this.sessionId, required this.newTitle});
  @override
  List<Object?> get props => [sessionId, newTitle];
}

class DeleteSession extends ChatEvent {
  final String sessionId;
  const DeleteSession(this.sessionId);
  @override
  List<Object?> get props => [sessionId];
}

class StopGeneration extends ChatEvent {}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class ChatState extends Equatable {
  const ChatState();
  @override
  List<Object?> get props => [];
}

class ChatInitial extends ChatState {}

class ChatLoading extends ChatState {}

class SessionsLoaded extends ChatState {
  final List<ChatSession> sessions;
  const SessionsLoaded(this.sessions);
  @override
  List<Object?> get props => [sessions];
}

class MessagesLoaded extends ChatState {
  final List<ChatMessage> messages;
  final String sessionId;
  final bool isGenerating;

  const MessagesLoaded({
    required this.messages,
    required this.sessionId,
    this.isGenerating = false,
  });

  MessagesLoaded copyWith({
    List<ChatMessage>? messages,
    String? sessionId,
    bool? isGenerating,
  }) {
    return MessagesLoaded(
      messages: messages ?? this.messages,
      sessionId: sessionId ?? this.sessionId,
      isGenerating: isGenerating ?? this.isGenerating,
    );
  }

  @override
  List<Object?> get props => [messages, sessionId, isGenerating];
}

class MessageStreaming extends ChatState {
  final List<ChatMessage> messages;
  final String currentStreamText;
  final String sessionId;

  const MessageStreaming({
    required this.messages,
    required this.currentStreamText,
    required this.sessionId,
  });

  @override
  List<Object?> get props => [messages, currentStreamText, sessionId];
}

class ChatError extends ChatState {
  final String message;
  const ChatError(this.message);
  @override
  List<Object?> get props => [message];
}

class SessionCreated extends ChatState {
  final ChatSession session;
  const SessionCreated(this.session);
  @override
  List<Object?> get props => [session];
}

// -----------------------------------------------------------------------------
// BLOC IMPLEMENTATION
// -----------------------------------------------------------------------------
class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final ChatRepository _chatRepository;
  final SearchService _searchService = SearchService();
  final PromptAssembler _promptAssembler = const PromptAssembler();
  final ClarificationParser _clarificationParser = const ClarificationParser();
  final DatabaseService _dbService = DatabaseService();
  final Uuid _uuid = const Uuid();
  
  StreamSubscription<String>? _apiSubscription;

  ChatBloc({ChatRepository? chatRepository})
      : _chatRepository = chatRepository ?? ChatRepositoryImpl(),
        super(ChatInitial()) {
    on<LoadChatSessions>(_onLoadChatSessions);
    on<CreateNewSession>(_onCreateNewSession);
    on<LoadMessages>(_onLoadMessages);
    on<SendMessage>(_onSendMessage);
    on<SubmitFormResponse>(_onSubmitFormResponse);
    on<UpdateSessionTitle>(_onUpdateSessionTitle);
    on<DeleteSession>(_onDeleteSession);
    on<StopGeneration>(_onStopGeneration);
  }

  Future<void> _onLoadChatSessions(LoadChatSessions event, Emitter<ChatState> emit) async {
    try {
      final List<ChatSession> sessions = await _chatRepository.getAllSessions();
      emit(SessionsLoaded(sessions));
    } catch (e) {
      emit(ChatError('Gagal memuatkan perbualan: $e'));
    }
  }

  Future<void> _onCreateNewSession(CreateNewSession event, Emitter<ChatState> emit) async {
    emit(ChatLoading());
    try {
      final ChatSession session = await _chatRepository.createSession(
        title: event.title,
        modelType: event.modelType,
        skillIds: event.skillIds,
      );
      emit(SessionCreated(session));
      add(LoadChatSessions());
    } catch (e) {
      emit(ChatError('Gagal membina sesi perbualan: $e'));
    }
  }

  Future<void> _onLoadMessages(LoadMessages event, Emitter<ChatState> emit) async {
    emit(ChatLoading());
    try {
      final List<ChatMessage> messages = await _chatRepository.getMessages(event.sessionId);
      emit(MessagesLoaded(messages: messages, sessionId: event.sessionId));
    } catch (e) {
      emit(ChatError('Gagal memuatkan mesej perbualan: $e'));
    }
  }

  Future<void> _onSendMessage(SendMessage event, Emitter<ChatState> emit) async {
    final List<ChatMessage> currentMessages = await _chatRepository.getMessages(event.sessionId);
    
    // 1. Simpan & letak mesej user ke senarai
    final ChatMessage userMsg = ChatMessage(
      id: _uuid.v4(),
      sessionId: event.sessionId,
      role: ChatMessage.roleUser,
      content: event.content,
      timestamp: DateTime.now(),
    );

    await _chatRepository.saveMessage(userMsg);
    final List<ChatMessage> updatedMessages = [...currentMessages, userMsg];
    
    emit(MessagesLoaded(messages: updatedMessages, sessionId: event.sessionId, isGenerating: true));

    // 2. Jalankan carian internet jika diaktifkan
    String searchInjection = '';
    if (event.isWebSearchEnabled) {
      try {
        final List<SearchResult> searchResults = await _searchService.search(event.content);
        if (searchResults.isNotEmpty) {
          searchInjection = _promptAssembler.assembleSearchContext(
            _searchService.formatForPrompt(searchResults),
            event.content,
          );
        }
      } catch (_) {
        // Graceful degradation - teruskan tanpa carian
      }
    }

    // 3. Bina list messages untuk dihantar ke DeepSeek API
    // Dapatkan active skills untuk sesi ini
    final List<Map<String, dynamic>> rawSkills = await _dbService.getActiveSkillsForSession(event.sessionId);
    final List<AISkill> activeSkills = rawSkills.map((row) {
      final Map<String, dynamic> mapped = Map<String, dynamic>.from(row);
      mapped['isDefault'] = row['is_default'];
      mapped['isActive'] = row['is_active'];
      mapped['instruction'] = row['system_prompt'];
      return AISkill.fromMap(mapped);
    }).toList();

    final String systemPrompt = _promptAssembler.assembleSystemPrompt(activeSkills);
    
    final List<Map<String, String>> apiMessages = [];
    apiMessages.add({'role': 'system', 'content': systemPrompt});

    // Tambah mesej terdahulu
    for (final ChatMessage msg in updatedMessages) {
      if (msg.id == userMsg.id && searchInjection.isNotEmpty) {
        apiMessages.add({'role': 'user', 'content': searchInjection});
      } else {
        apiMessages.add({'role': msg.role, 'content': msg.content});
      }
    }

    // 4. Mulakan penstriman
    await _streamResponse(
      emit: emit,
      sessionId: event.sessionId,
      apiKey: event.apiKey,
      model: event.model,
      apiMessages: apiMessages,
      historyMessages: updatedMessages,
    );
  }

  Future<void> _streamResponse({
    required Emitter<ChatState> emit,
    required String sessionId,
    required String apiKey,
    required String model,
    required List<Map<String, String>> apiMessages,
    required List<ChatMessage> historyMessages,
  }) async {
    final Completer<void> completer = Completer<void>();
    String accumulatedText = '';
    
    final String assistantMsgId = _uuid.v4();
    final DateTime assistantTimestamp = DateTime.now();

    final Stream<String> stream = _chatRepository.sendChatMessage(
      apiKey: apiKey,
      model: model,
      messages: apiMessages,
    );

    _apiSubscription = stream.listen(
      (chunk) {
        accumulatedText += chunk;
        emit(MessageStreaming(
          messages: historyMessages,
          currentStreamText: accumulatedText,
          sessionId: sessionId,
        ));
      },
      onError: (dynamic error) {
        emit(ChatError('Ralat penstriman: $error'));
        completer.complete();
      },
      onDone: () async {
        // 5. Stream Selesai -> Parse Clarification Form
        final ClarificationResult parsed = _clarificationParser.parse(accumulatedText);
        
        final ChatMessage aiMsg = ChatMessage(
          id: assistantMsgId,
          sessionId: sessionId,
          role: ChatMessage.roleAssistant,
          content: parsed.beforeText + parsed.afterText,
          containsForm: parsed.hasForm,
          rawFormJson: parsed.formData != null ? accumulatedText.substring(
            accumulatedText.indexOf('[CLARIFICATION_FORM]'),
            accumulatedText.indexOf('[/CLARIFICATION_FORM]') + '[/CLARIFICATION_FORM]'.length,
          ) : null,
          isFormSubmitted: false,
          timestamp: assistantTimestamp,
        );

        await _chatRepository.saveMessage(aiMsg);
        
        final List<ChatMessage> finalHistory = [...historyMessages, aiMsg];
        emit(MessagesLoaded(messages: finalHistory, sessionId: sessionId, isGenerating: false));
        completer.complete();
      },
      cancelOnError: true,
    );

    await completer.future;
  }

  Future<void> _onSubmitFormResponse(SubmitFormResponse event, Emitter<ChatState> emit) async {
    // 1. Kemaskini status borang lama
    await _chatRepository.updateMessageFormStatus(event.messageId, true);

    // 2. Format jawapan mesra-AI
    final String formattedAnswer = _clarificationParser.formatResponse(
      event.fieldName,
      event.selectedValues,
      event.customValue,
    );

    // 3. Hantar jawapan sebagai user message baharu
    add(SendMessage(
      sessionId: event.sessionId,
      content: formattedAnswer,
      apiKey: event.apiKey,
      model: event.model,
      isWebSearchEnabled: false, // carian web dimatikan semasa menjawab borang
    ));
  }

  Future<void> _onUpdateSessionTitle(UpdateSessionTitle event, Emitter<ChatState> emit) async {
    try {
      await _chatRepository.updateSessionTitle(event.sessionId, event.newTitle);
      add(LoadChatSessions());
      
      final List<ChatMessage> messages = await _chatRepository.getMessages(event.sessionId);
      emit(MessagesLoaded(messages: messages, sessionId: event.sessionId));
    } catch (e) {
      emit(ChatError('Gagal mengemaskini tajuk: $e'));
    }
  }

  Future<void> _onDeleteSession(DeleteSession event, Emitter<ChatState> emit) async {
    try {
      await _chatRepository.deleteSession(event.sessionId);
      add(LoadChatSessions());
      emit(ChatInitial());
    } catch (e) {
      emit(ChatError('Gagal memadam sesi perbualan: $e'));
    }
  }

  void _onStopGeneration(StopGeneration event, Emitter<ChatState> emit) {
    _apiSubscription?.cancel();
    _apiSubscription = null;
    
    // Kemaskini keadaan semasa
    final ChatState currentState = state;
    if (currentState is MessageStreaming) {
      final ChatMessage aiMsg = ChatMessage(
        id: _uuid.v4(),
        sessionId: currentState.sessionId,
        role: ChatMessage.roleAssistant,
        content: '${currentState.currentStreamText}\n\n*[Penjanaan dihentikan oleh pengguna]*',
        timestamp: DateTime.now(),
      );
      
      _chatRepository.saveMessage(aiMsg);
      
      emit(MessagesLoaded(
        messages: [...currentState.messages, aiMsg],
        sessionId: currentState.sessionId,
        isGenerating: false,
      ));
    }
  }

  @override
  Future<void> close() {
    _apiSubscription?.cancel();
    return super.close();
  }
}
