import 'package:equatable/equatable.dart';

/// Entiti mesej perbualan individu dalam sesi.
///
/// Menyokong tiga peranan: 'user', 'assistant', dan 'system'.
/// Boleh mengandungi borang interaktif melalui [containsForm] dan [rawFormJson].
class ChatMessage extends Equatable {
  final String id;
  final String sessionId;
  final String role;
  final String content;
  final bool containsForm;
  final String? rawFormJson;
  final bool isFormSubmitted;
  final DateTime timestamp;

  /// Peranan mesej yang disokong.
  static const String roleUser = 'user';
  static const String roleAssistant = 'assistant';
  static const String roleSystem = 'system';

  static const List<String> supportedRoles = [
    roleUser,
    roleAssistant,
    roleSystem,
  ];

  const ChatMessage({
    required this.id,
    required this.sessionId,
    required this.role,
    required this.content,
    this.containsForm = false,
    this.rawFormJson,
    this.isFormSubmitted = false,
    required this.timestamp,
  }) : assert(
         role == roleUser || role == roleAssistant || role == roleSystem,
         'role mesti salah satu daripada: $roleUser, $roleAssistant, $roleSystem',
       );

  /// Semak jika mesej ini daripada pengguna.
  bool get isUser => role == roleUser;

  /// Semak jika mesej ini daripada AI.
  bool get isAssistant => role == roleAssistant;

  /// Semak jika mesej ini adalah arahan sistem.
  bool get isSystem => role == roleSystem;

  /// Buat salinan dengan nilai yang dikemaskini.
  ChatMessage copyWith({
    String? id,
    String? sessionId,
    String? role,
    String? content,
    bool? containsForm,
    String? rawFormJson,
    bool? isFormSubmitted,
    DateTime? timestamp,
  }) {
    return ChatMessage(
      id: id ?? this.id,
      sessionId: sessionId ?? this.sessionId,
      role: role ?? this.role,
      content: content ?? this.content,
      containsForm: containsForm ?? this.containsForm,
      rawFormJson: rawFormJson ?? this.rawFormJson,
      isFormSubmitted: isFormSubmitted ?? this.isFormSubmitted,
      timestamp: timestamp ?? this.timestamp,
    );
  }

  /// Bina dari Map (biasanya dari SQLite).
  factory ChatMessage.fromMap(Map<String, dynamic> map) {
    return ChatMessage(
      id: map['id'] as String,
      sessionId: map['sessionId'] as String,
      role: map['role'] as String,
      content: map['content'] as String,
      containsForm: (map['containsForm'] as int?) == 1,
      rawFormJson: map['rawFormJson'] as String?,
      isFormSubmitted: (map['isFormSubmitted'] as int?) == 1,
      timestamp: DateTime.fromMillisecondsSinceEpoch(map['timestamp'] as int),
    );
  }

  /// Tukar ke Map untuk simpanan SQLite.
  /// Boolean ditukar ke int (0/1) kerana SQLite tidak menyokong bool.
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'sessionId': sessionId,
      'role': role,
      'content': content,
      'containsForm': containsForm ? 1 : 0,
      'rawFormJson': rawFormJson,
      'isFormSubmitted': isFormSubmitted ? 1 : 0,
      'timestamp': timestamp.millisecondsSinceEpoch,
    };
  }

  @override
  List<Object?> get props => [
        id,
        sessionId,
        role,
        content,
        containsForm,
        rawFormJson,
        isFormSubmitted,
        timestamp,
      ];

  @override
  bool get stringify => true;
}
