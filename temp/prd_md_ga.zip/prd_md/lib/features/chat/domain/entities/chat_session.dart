import 'package:equatable/equatable.dart';

/// Entiti sesi perbualan yang menyimpan metadata sesi.
///
/// Setiap sesi mempunyai model AI yang dipilih dan senarai skill aktif.
class ChatSession extends Equatable {
  final String id;
  final String title;
  final String modelType;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<String> activeSkillIds;

  /// Model AI yang disokong.
  static const String modelDeepseekFlash = 'deepseek-v4-flash';
  static const String modelDeepseekPro = 'deepseek-v4-pro';

  static const List<String> supportedModels = [
    modelDeepseekFlash,
    modelDeepseekPro,
  ];

  const ChatSession({
    required this.id,
    required this.title,
    required this.modelType,
    required this.createdAt,
    required this.updatedAt,
    this.activeSkillIds = const [],
  }) : assert(
         modelType == modelDeepseekFlash || modelType == modelDeepseekPro,
         'modelType mesti salah satu daripada: $modelDeepseekFlash, $modelDeepseekPro',
       );

  /// Buat salinan dengan nilai yang dikemaskini.
  ChatSession copyWith({
    String? id,
    String? title,
    String? modelType,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<String>? activeSkillIds,
  }) {
    return ChatSession(
      id: id ?? this.id,
      title: title ?? this.title,
      modelType: modelType ?? this.modelType,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      activeSkillIds: activeSkillIds ?? this.activeSkillIds,
    );
  }

  /// Bina dari Map (biasanya dari SQLite).
  factory ChatSession.fromMap(Map<String, dynamic> map) {
    final String skillIdsRaw = (map['activeSkillIds'] as String?) ?? '';
    final List<String> parsedSkillIds = skillIdsRaw.isEmpty
        ? <String>[]
        : skillIdsRaw.split(',').where((s) => s.isNotEmpty).toList();

    return ChatSession(
      id: map['id'] as String,
      title: map['title'] as String,
      modelType: map['modelType'] as String,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt'] as int),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(map['updatedAt'] as int),
      activeSkillIds: parsedSkillIds,
    );
  }

  /// Tukar ke Map untuk simpanan SQLite.
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'modelType': modelType,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'updatedAt': updatedAt.millisecondsSinceEpoch,
      'activeSkillIds': activeSkillIds.join(','),
    };
  }

  @override
  List<Object?> get props => [
        id,
        title,
        modelType,
        createdAt,
        updatedAt,
        activeSkillIds,
      ];

  @override
  bool get stringify => true;
}
