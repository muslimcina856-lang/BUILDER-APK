# Multi Agent AI

Unified interface for multiple AI providers with SSE streaming, token counting, and flexible adapters.

## Features

- **Multi-Provider Support**: DeepSeek, OpenAI, Gemini, Claude, Mimo, and custom providers
- **SSE Streaming**: Real-time response streaming
- **Token Counting**: Track usage and estimated costs
- **API Key Fallback**: Automatic failover when keys fail
- **Skills System**: Create and reuse custom instructions
- **Shell Access**: Execute commands and read/write files
- **Chat History**: Searchable local storage
- **Export/Import**: Share configurations

## Getting Started

### Prerequisites

- Flutter SDK 3.16+
- Android Studio / Xcode

### Installation

```bash
# Clone the repository
git clone https://github.com/username/multi_agent_ai.git
cd multi_agent_ai

# Install dependencies
flutter pub get

# Run the app
flutter run
```

### Setup

1. Add a provider in Settings > Providers
2. Add API key(s) for the provider
3. Add model(s) for the provider
4. Start chatting!

## Architecture

```
lib/
├── core/           # Constants, themes, utils
├── data/           # Models, repositories, datasources, services
├── domain/         # Entities and use cases
├── presentation/   # BLoC, pages, widgets
└── main.dart
```

## Tech Stack

- **Flutter** - Cross-platform UI
- **BLoC/Cubit** - State management
- **SQLite** - Local database
- **flutter_secure_storage** - API key encryption
- **Dio** - HTTP client
- **process_run** - Shell access

## API Adapters

| Provider | Adapter | Format |
|----------|---------|--------|
| DeepSeek | `deepseek_adapter.dart` | OpenAI-compatible |
| OpenAI | `openai_adapter.dart` | OpenAI standard |
| Gemini | `gemini_adapter.dart` | Google AI |
| Claude | `claude_adapter.dart` | Anthropic |
| Mimo | `mimo_adapter.dart` | OpenAI-compatible |
| Custom | `custom_adapter.dart` | User-defined |

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT License

## Acknowledgments

- Flutter community
- AI provider APIs
- All beta testers
