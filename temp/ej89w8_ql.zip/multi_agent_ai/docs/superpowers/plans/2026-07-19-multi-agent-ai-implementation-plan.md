# Multi Agent AI — Implementation Plan

## Delivery strategy

Build a complete Android Flutter source project in vertical slices. Every slice leaves the app runnable and testable. The initial deliverable is source code plus documentation; release signing and Google Play upload use the owner's credentials on their PC or CI.

## 1. Project foundation

- Create a Flutter application named `multi_agent_ai` with Android API 24 minimum and target API 36.
- Add Material 3 theme, routing, dependency injection, BLoC/Cubit, generated immutable models, local storage, secure storage, networking, file picker, biometric lock, and test dependencies.
- Add `.gitignore`, analysis options, README, Android permissions, release configuration placeholders, and GitHub Actions quality workflow.
- Verify: `flutter pub get`, `flutter analyze`, basic widget test.

## 2. Domain model and local persistence

- Implement immutable entities for provider, model, API key metadata, chat, message, agent profile, agent run, skill, workspace snapshot, audit event, connector, and backup manifest.
- Implement encrypted SQLite schema/migrations with full-text search for chat content and repository interfaces.
- Seed the built-in Skill Creator and default Coordinator/Explorer/Builder/Reviewer/Planner profiles.
- Implement room lifecycle: create workspace, open room, delete room plus workspace cleanup, search history.
- Verify: repository unit tests for isolation, deletion, search, and migration.

## 3. Provider configuration and secure keys

- Build provider/model/key CRUD screens and BLoCs.
- Store actual secrets only in Android secure storage; retain opaque key metadata in SQLite.
- Implement connection test, model selection eligibility, global instruction, and ordered fallback health state.
- Verify: widget tests for validation and unit tests proving secrets never appear in export/log models.

## 4. Provider adapter and streaming layer

- Define a provider adapter interface with normalized request, streaming event, tool-call, and error models.
- Implement OpenAI-compatible, Gemini, and Anthropic adapters; DeepSeek uses the OpenAI-compatible adapter.
- Implement fallback only on pre-response 401/429, cooldown from Retry-After, cancellation, and sanitized error mapping.
- Verify: mock HTTP tests for streaming, fallback, cooldown, and no duplicate retry after a visible response.

## 5. Agent runtime and tool registry

- Implement the coordinator run loop, task planner, subagent queue, max-concurrency policy, role profiles, and compact child summaries.
- Implement workspace-native tools: list/search/read/write/edit/create/rename/move/delete, snapshot/Undo, path lock, and audit log.
- Implement Android Kotlin workspace command bridge with canonical-root checks, timeout, bounded output, cancellation, and capability errors.
- Implement room autonomy policies and permission decision persistence.
- Verify: orchestration, path-escape, file-lock, snapshot, autonomy, and cancellation unit/integration tests.

## 6. Chat-first Flutter UI

- Build the searchable chat list, new-chat model picker, chat composer, streaming answer bubbles, and inline agent activity cards.
- Build agent activity expansion, stop/retry/Undo actions, tool output cards, error/retry cards, and accessibility labels.
- Build the per-chat workspace file manager launched from the top-right folder icon, text editor, import, and export flow.
- Verify: widget tests for navigation, transcript ordering, activity cards, and workspace actions.

## 7. Skills, agents, and connectors

- Build Skills and Agents screens, editor forms, role/profile model override, tool policy, activation rules, and Skill Creator wizard.
- Add per-room `AGENT.md` editor and prompt-context assembler with budget warnings and run snapshots.
- Build remote HTTPS MCP connector CRUD with consent review; expose configured remote tools through the registry.
- Add declarative `.maa-plugin` import preview for skills/assets/MCP configurations only.
- Verify: context-order, skill matching, connector-consent, and plugin validation tests.

## 8. Backup, privacy, and settings

- Build encrypted `.maa-backup` export/import, passphrase flow, conflict preview, and restore report.
- Implement local app lock/biometric option, theme, privacy disclosure, analytics opt-in, backup preferences, and workspace defaults.
- Verify: backup round-trip, invalid archive, merge/replace, and app-lock tests.

## 9. Release hardening

- Complete unit, widget, and integration test coverage for critical workflows.
- Run static analysis without warnings, profile long chat and search behavior, validate Android lifecycle/background interruption handling, and test physical API 24+ device behavior.
- Build release AAB with owner-supplied signing configuration, update README/Play privacy checklist, and generate a source ZIP excluding secrets/build artifacts.

## Source ZIP contents

- Flutter source, Android configuration, tests, docs, CI workflow, and `README.md`.
- No API keys, keystore files, build output, local database, workspace files, or backup archives.

## Definition of done

The app opens on Android API 24+, lets a user configure a provider and key, create an isolated chat workspace, converse with a selected model, delegate to subagents, allow full workspace autonomy, inspect/edit/export workspace files, create/use skills, search local chat history, recover through API-key fallback, create encrypted backups, and pass the documented automated checks.
