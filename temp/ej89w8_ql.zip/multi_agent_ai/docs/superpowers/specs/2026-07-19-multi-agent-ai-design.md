# Multi Agent AI — Release Android Design

## Status and intent

This document defines the first production Android release of **Multi Agent AI**. It is a Flutter application for a single user who brings their own AI provider credentials. It is not a comparison-chat app and does not depend on a product backend or account system.

The product behaves like a mobile, workspace-scoped agent client: a selected main model coordinates work, creates subagents when a task merits delegation, uses reusable skills and tools, and records all work in the owning chat.

## Platform boundary

- Platform: Android only for release 1.
- Flutter deployment floor: Android API 24.
- Google Play target: Android API 36.
- Distribution: Google Play release; the owner can install the same release for personal use.
- No root, ADB, or access to other apps' private data is promised. All file and command actions run as the application UID inside Android's application sandbox.

## Product model

### Chat rooms

Each chat is an independent room identified by a stable UUID. A room owns:

- its complete message history and searchable title;
- selected main model, active skill set, and durable `AGENT.md` instructions;
- agent runs, subagent runs, task status, tool audit events, and file snapshots;
- one private workspace at `files/chat-workspaces/<chat-id>/`.

No chat may access another chat's workspace. Deleting a chat requires confirmation, then atomically removes its messages, runs, audit entries, snapshots, and workspace directory. A failed deletion remains marked for retry so that no orphaned private workspace is silently retained.

### Navigation and UI direction

The app is chat-first, with a calm professional Material 3 visual system rather than generic AI styling.

- **Chats** is the landing screen: searchable history, recent chat metadata, and a prominent new-chat action.
- **Agents** lists reusable agent profiles and currently running or completed agent runs.
- **Skills** lists, creates, edits, enables, disables, imports, and exports skills.
- **Settings** contains provider, API key, global instruction, tool connector, backup, appearance, privacy, and workspace defaults.

The chat screen has a back button, title/model subtitle, workspace folder icon in the top-right corner, and overflow actions. Agent activity is embedded directly in the chat transcript as chronological expandable cards. Cards show the delegated task, child-agent status, changed files, output summary, failure state, stop/retry actions, and Undo when a snapshot exists.

The workspace folder icon opens the room's in-app file manager. It supports folder navigation, file preview, text editing, create/rename/move/delete, import through the Android picker, and user-triggered download/export through the Android picker. It never exposes another chat's directory.

## Main agent and subagents

### Model selection

Users configure providers, models, and API keys themselves. A model is selectable only when its provider has at least one enabled API key. Selecting a model when creating or editing a chat makes it that room's **main model**.

The main model owns user communication, task decomposition, final synthesis, and the decision to delegate. It may create direct subagents when work is complex, independent, long-running, or benefits from specialization. The default subagent model is the room's main model. An agent profile may override it with another configured model.

### Agent profiles

An agent profile has a name, description, role instructions, default model reference, reasoning preference, enabled skills, allowed tools, and display icon. Built-in profiles are:

- **Coordinator**: main chat agent; plans, delegates, and synthesizes.
- **Explorer**: read-heavy workspace inspection, search, and summarization.
- **Builder**: file edits and workspace command execution.
- **Reviewer**: verifies changes, tests, and reports risks.
- **Planner**: breaks large goals into bounded tasks.

Users can create or edit profiles. Child agents inherit the parent room's workspace boundary and autonomy policy. They cannot create child agents in release 1; the coordinator is the sole orchestrator. The default concurrency cap is three active workers per chat and is configurable up to six. This prevents uncontrolled fan-out while allowing parallel independent work.

### Shared workspace execution

Subagents may read, edit, and run tools in the same room workspace. The tool executor serializes writes to the same canonical file path with a per-path lock. Before every destructive or overwriting write, it stores a snapshot in the room's private snapshot store. The main agent receives compact subagent summaries rather than raw output by default; the user can expand any activity card for the full trace.

## Autonomy and permissions

Every room carries one workspace autonomy policy:

- **Ask**: prompt before a state-changing workspace action.
- **Task approval**: allow changes while the current top-level task runs.
- **Full workspace autonomy**: allow main agent and subagents to read, create, edit, rename, move, delete, and run workspace-scoped commands without further prompts.

When a prompt is shown, the UI offers: **Allow once**, **Allow for this task**, **Allow everything in this chat workspace**, and **Deny**. Full workspace autonomy is persisted per room and clearly displayed in the chat subtitle and workspace screen.

Even under full workspace autonomy, the agent asks when it cannot infer the user's goal or when an action crosses a boundary: deleting the entire chat/workspace, importing from or exporting to user-selected external storage, sharing a file with a third party, sending credentials, changing provider or connector configuration, or using a previously unapproved remote connector.

Every tool invocation creates an immutable audit record with agent ID, tool name, canonical path or destination, sanitized input summary, outcome, duration, and a snapshot reference when relevant. Secrets are redacted before storage or display.

## Tools and remote connectors

Native tools are implemented by the app, not simulated in model text:

- list, search, read, write, edit, create, rename, move, and delete workspace files;
- text preview and structured search;
- workspace-scoped command execution through a Kotlin platform bridge with the room directory as working directory;
- import and export using Android's Storage Access Framework;
- web search and web fetch, when explicitly configured by the user;
- task list and agent delegation tools.

The command executor resolves every path to a canonical descendant of the room root, applies timeout and output-size limits, captures exit code/stdout/stderr, and refuses to claim a command succeeded when Android does not provide the runtime capability. It does not grant root, ADB, broad storage, or another application's filesystem access.

Remote integrations use HTTPS Model Context Protocol (MCP) connectors. A connector configuration stores its endpoint, authentication reference, supplied tool schema, consent status, and tool policy. Release 1 supports remote HTTP/streamable connectors only; local stdio MCP servers and downloaded executable plugins are intentionally excluded from Android release 1.

## Skills, instructions, and plugins

### Instructions

The final system context is built in this order:

1. immutable application safety and provider instructions;
2. global user instruction;
3. room-level `AGENT.md` instruction file;
4. active skill instructions;
5. agent-profile role instructions;
6. recent chat context and task-specific workspace evidence.

The app measures the assembled context before sending it and warns when it exceeds the selected model's configured budget. It stores a versioned prompt snapshot with each agent run for reproducibility.

### Skills

A skill is a user-owned workflow containing a unique name, short trigger description, instructions, optional references, preferred agent profile/model, and a tool policy. The skill library shows only concise metadata until the main agent activates a matching skill; the full body is then loaded. Skills may be explicitly selected or chosen by the main agent based on their description.

The built-in **Skill Creator** guides the user to produce a name, trigger description, step-by-step instructions, expected outputs, and permitted tools. It validates unique names and minimum content length.

### Plugins

Release 1 accepts declarative `.maa-plugin` archives containing skills, presentation assets, and remote MCP configurations. It does not execute downloaded code. Import previews all requested tools and connector endpoints; the user must approve each remote capability before it becomes usable.

## Providers and fallback

The provider registry supports:

- OpenAI-compatible custom endpoints;
- built-in OpenAI-compatible presets for OpenAI and DeepSeek;
- native Gemini adapter;
- native Anthropic adapter.

Additional vendors, including any vendor marketed as Mimo, use the OpenAI-compatible custom adapter until their documented request and streaming protocol has been verified.

Each provider has a name, HTTPS base URL, adapter type, models, optional extra headers, enabled state, and ordered API-key references. Secrets are stored only in Secure Storage/Android Keystore; the database stores opaque key IDs, labels, priority, health state, and timestamps.

For a request, the adapter normalizes messages, system instruction, streaming chunks, tool calls, errors, token usage, and response text. If a key receives HTTP 401 or 429 before a usable response begins, the fallback manager tries the next enabled key in priority order. A 429 honors `Retry-After` when supplied and marks the key cooling down. The app does not retry a request after a visible streamed answer has begun, preventing duplicate tool actions or billing ambiguity.

## Data, encryption, and backup

The app uses an encrypted SQLite database for structured local data and full-text chat search. It stores chats, messages, providers without secrets, model definitions, API key metadata, skills, agent profiles, agent runs, tool audits, snapshots metadata, and settings. A database encryption key is generated locally and protected by Android Keystore-backed secure storage.

Private workspace files live in Android app-specific internal storage. API keys, OAuth tokens, the database key, and backup credential metadata never appear in message logs, exports, error reports, or screenshots.

Backup is user initiated. The app creates an encrypted `.maa-backup` archive containing selected chats, their workspaces, skills, agent profiles, providers without secrets, global instructions, and user settings. The archive uses AES-256-GCM with a key derived from a user passphrase using Argon2id. API keys are excluded by default and require a separate explicit export/import flow. Restore previews conflicts and offers merge or replace; it never silently activates imported connectors.

## Error handling and recovery

- Network failure: retain the user message and show a retry card.
- Provider failure: show sanitized provider error; surface fallback progress without key details.
- All keys unavailable: show provider/model recovery actions.
- Interrupted agent: mark run paused or failed with its latest persisted tool/audit state; offer retry or resume when idempotent.
- Concurrent file edits: serialize access by canonical path and show the waiting agent status.
- Shell/tool failure: show bounded output, exit code, and a retry or open-workspace action.
- Invalid imported data: reject only invalid records, show a preview report, and leave existing data unchanged unless the user confirms replacement.

## Flutter architecture

The application uses a layered Flutter architecture with BLoC/Cubit state management and dependency injection.

```text
Presentation (pages, widgets, BLoCs)
        ↓
Domain (entities, orchestration use cases, policies)
        ↓
Data (repositories)
        ↓
Services (database, secure vault, HTTP adapters, workspace bridge, MCP)
```

Feature modules are Chat, Agent Runtime, Workspace, Skills, Providers, Connectors, Backup, and Settings. The Android command executor and Storage Access Framework integration live behind platform-service interfaces so UI and orchestration remain testable.

## Release quality gates

Before release, CI must run formatting, static analysis with zero warnings, unit tests, widget tests, integration tests, and an Android release build. Test coverage includes:

- key fallback on 401 and 429;
- provider adapter normalization and streaming;
- isolation between two room workspaces;
- full-workspace autonomy choices and boundary prompts;
- concurrent subagent file locks and Undo snapshots;
- chat deletion with workspace cleanup;
- full-text history search;
- encrypted backup export and restore conflict handling;
- app launch, provider setup, send-message, agent delegation, and workspace file-manager flows on a physical Android device.

The release build includes privacy disclosure that workspace content may be sent to the selected external AI provider when an agent reads or uses it. Analytics is disabled by default. Crash reporting, if enabled later, must be opt-in and redact prompts, file contents, URLs with credentials, and API keys.

## Explicit non-goals for release 1

- iOS, desktop, web, cloud sync, and multi-user accounts.
- Root, ADB, arbitrary system administration, or access to other applications' private storage.
- Local executable MCP servers, unreviewed downloaded code, and executable third-party plugins.
- Automatic use of a provider/model for which the user has not supplied a valid key.
- Automatic external sharing of workspace files or secrets.
