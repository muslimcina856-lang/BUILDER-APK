# PRD — Product Requirements Document

## Multi Agent AI

---

## 1. Executive Summary

Multi Agent AI ialah aplikasi mudah alih pintar yang bertindak sebagai antara muka tunggal untuk berinteraksi dengan pelbagai model AI dari pelbagai penyedia (DeepSeek, OpenAI, Google Gemini, Anthropic Claude, Mimo, dan lain-lain). Aplikasi ini direka untuk pengguna power yang mahukan fleksibiliti mutlak: menambah sebarang provider, menguruskan berbilang kunci API dengan fallback, memberi arahan sistem tersuai, mencipta "skill" (kemahiran) tanpa had, dan menggunakan model AI secara serentak untuk pelbagai tugas. Selain itu, ia mampu mengakses sistem fail dan menjalankan arahan shell pada peranti (Android/Linux) untuk automasi lanjutan. Ciri sejarah chat yang boleh dicari dan sentiasa aktif (tanpa togol) memastikan pengalaman pengguna lancar. Aplikasi ini dibina dengan Flutter untuk prestasi dan pengalaman asli, serta tidak kelihatan seperti dijana AI – reka bentuk manusiawai dan profesional.

**Ciri Baharu (Kemaskini):**
- **SSE Streaming** - Respons dipaparkan secara real-time perkataan demi perkataan
- **Token Counting** - Paparan penggunaan token & anggaran kos setiap permintaan
- **Adapter Fleksibel** - Membaca dokumentasi rasmi setiap provider untuk format API

Ikon Aplikasi: 📥 Muat turun dari sini – Letakkan di assets/icons/app_icon.png

---

## 2. Problem Statement

- Pengguna perlu melanggan pelbagai platform AI untuk mengakses model terbaik, tetapi tiada antara muka bersatu.
- Kunci API sering tamat atau had laju, menyukarkan aliran kerja.
- Arahan sistem dan keperluan khusus (skill) sukar disimpan dan digunakan semula merentas sesi.
- Tiada keupayaan untuk menggabungkan kepintaran AI dengan kawalan sistem (menjalankan skrip, membaca fail) dalam satu aplikasi.
- Sejarah perbualan bertaburan dan sukar dicari.
- Kebanyakan aplikasi AI kelihatan generik dan "dijana AI", kurang sentuhan manusia.
- Tiada cara mudah untuk memantau penggunaan token dan kos API.

---

## 3. Goals & Objectives

- **Matlamat Utama:** Menyediakan aplikasi AI serba guna dengan pengurusan provider fleksibel, sejarah boleh dicari, dan sokongan skill tanpa had.
- **Objektif MVP:**
  - Pengguna boleh menambah dan mengurus provider AI (termasuk custom).
  - Menyokong model DeepSeek V4, Flash, Pro, Mimo 2.5 Pro, dan model lain melalui API.
  - Fallback API key bagi setiap provider.
  - Arahan sistem (instruction) global dan per-skill.
  - Cipta, edit, padam skill (nama + kandungan).
  - Skill default "Skill Creator" untuk membimbing pengguna mencipta skill baru.
  - Sejarah chat disimpan secara lokal, boleh dicari mengikut kandungan dan tarikh.
  - Paparan chat dalam mod senarai, tiada togol on/off (sentiasa aktif).
  - Akses ke sistem fail dan shell (dengan kebenaran).
  - **SSE Streaming** untuk respons masa nyata.
  - **Token Counting** untuk memantau penggunaan.
  - **Adapter** berdasarkan dokumentasi rasmi setiap provider.
  - Reka bentuk UI yang tidak kelihatan dijana AI – menggunakan tipografi, ruang, dan warna yang selesa.

---

## 4. Target Users

- **Pembangun & DevOps:** Menggunakan AI untuk automasi, debugging, dan penulisan skrip dengan akses sistem.
- **Penulis & Penyelidik:** Memerlukan pelbagai model untuk penjanaan idea dan penyuntingan.
- **Pengguna Power:** Ingin mengawal sepenuhnya persekitaran AI mereka tanpa bergantung pada platform tunggal.
- **Penggemar AI:** Suka bereksperimen dengan model dan provider baharu.

---

## 5. User Personas

### 1. Amir (DevOps)
- **Umur:** 30 tahun
- **Peranan:** Mengurus infrastruktur cloud
- **Matlamat:** Menggunakan AI untuk menjana skrip shell dan memantau log
- **Keperluan:** Akses shell, arahan sistem yang tepat, skill untuk tugasan berulang

### 2. Siti (Penulis Kreatif)
- **Umur:** 27 tahun
- **Peranan:** Penulis novel dan artikel
- **Matlamat:** Mendapat bantuan gaya penulisan dari pelbagai model
- **Keperluan:** Sejarah carian, skill untuk nada penulisan, arahan sistem tersuai

### 3. Rizal (Pelajar)
- **Umur:** 22 tahun
- **Peranan:** Pelajar sains data
- **Matlamat:** Belajar dengan bertanya soalan dan membandingkan jawapan dari model berbeza
- **Keperluan:** Paparan perbandingan, tiada togol (sentiasa boleh bertanya)

---

## 6. User Stories

1. Sebagai pengguna, saya ingin menambah provider AI dengan memasukkan nama, URL API, dan model yang disokong.
2. Sebagai pengguna, saya ingin menambah berbilang kunci API untuk provider yang sama sebagai fallback.
3. Sebagai pengguna, saya ingin memilih model AI sebelum memulakan perbualan.
4. Sebagai pengguna, saya ingin menetapkan arahan sistem global yang akan dihantar bersama setiap permintaan.
5. Sebagai pengguna, saya ingin mencipta skill (nama + kandungan) dan mengaitkannya dengan arahan sistem tertentu.
6. Sebagai pengguna, saya ingin menggunakan skill yang telah dicipta dalam sesi chat.
7. Sebagai pengguna, saya ingin melihat sejarah chat yang disimpan, dan mencari berdasarkan kata kunci.
8. Sebagai pengguna, saya ingin memadam atau membersihkan sejarah chat.
9. Sebagai pengguna, saya ingin membolehkan akses sistem fail dan menjalankan arahan shell daripada chat.
10. Sebagai pengguna, saya ingin mengeksport atau mengimport tetapan (provider, skill) untuk berkongsi.
11. **Sebagai pengguna, saya ingin melihat respons muncul secara real-time (streaming).**
12. **Sebagai pengguna, saya ingin melihat penggunaan token dan anggaran kos setiap permintaan.**

---

## 7. Functional Requirements

| ID | Requirement | Description |
|----|-------------|-------------|
| FR1 | Pengurusan Provider AI | Tambah, sunting, padam provider. Sertakan URL, model, dan API keys. |
| FR2 | Pengurusan Kunci API | Tambah berbilang kunci untuk setiap provider, atur keutamaan fallback. |
| FR3 | Pemilihan Model | Paparan senarai model dari provider yang dipilih. |
| FR4 | Arahan Sistem (Instruction) | Tetapkan arahan global atau per-skill. |
| FR5 | Pengurusan Skill | Cipta, sunting, padam skill dengan nama dan kandungan (teks panjang). |
| FR6 | Skill Default "Skill Creator" | Skill terbina untuk membimbing pengguna cara mencipta skill baru. |
| FR7 | Sesi Chat | Mulakan chat baru, pilih model, hantar mesej, terima balasan. |
| FR8 | Sejarah Chat | Simpan semua chat secara lokal, paparan senarai, dan fungsi carian. |
| FR9 | Carian Sejarah | Cari mengikut teks dalam mesej atau tajuk chat. |
| FR10 | Akses Sistem (Shell & Fail) | Benarkan pengguna menjalankan arahan shell dan membaca/menulis fail melalui chat. |
| FR11 | Eksport/Import Konfigurasi | Eksport tetapan provider dan skill ke fail JSON, dan import balik. |
| FR12 | Notifikasi (Pilihan) | Notifikasi ringan untuk status permintaan AI. |
| **FR13** | **SSE Streaming** | **Respons dipaparkan secara real-time menggunakan Server-Sent Events.** |
| **FR14** | **Token Counting** | **Paparan jumlah token (prompt + completion) dan anggaran kos.** |
| **FR15** | **Adapter Provider** | **Adapter berdasarkan dokumentasi rasmi setiap provider (DeepSeek, OpenAI, Gemini, Claude, Mimo, Custom).** |

---

## 8. Non-Functional Requirements

1. **Keselamatan:** Kunci API disimpan secara selamat menggunakan penyimpanan terenkripsi (Flutter Secure Storage). Tiada perkongsian data tanpa kebenaran.
2. **Prestasi:** Respons UI < 100ms untuk interaksi. Permintaan AI dijalankan secara asynchronous dengan streaming.
3. **Kebolehgunaan:** Reka bentuk intuitif, tidak kelihatan generik AI. Tipografi dan jarak yang selesa.
4. **Kebolehskalaan:** Sokongan untuk berbilang provider dan skill tanpa had.
5. **Kebolehpercayaan:** Fallback API key automatik jika kunci utama gagal.
6. **Keserasian:** Android 5.0+ dan iOS 12+.

---

## 9. Core Features

1. **Pengurusan Provider & Kunci:** Tambah provider, model, dan kunci fallback.
2. **Arahan & Skill:** Sistem arahan global dan skill tersuai.
3. **Chat & Sejarah:** Perbualan dengan model, disimpan dan boleh dicari.
4. **Akses Sistem:** Integrasi shell dan fail.
5. **Eksport/Import:** Mudah alih tetapan.
6. **SSE Streaming:** Respons masa nyata.
7. **Token Counting:** Pemantauan penggunaan.

---

## 10. Detailed Feature Specifications

### Feature 1: Pengurusan Provider (FR1, FR2, FR15)

- **Tambah Provider:** Pengguna memasukkan Nama, URL Base (contoh: https://api.deepseek.com/v1), dan model-model yang disokong (dipisahkan koma). Juga pilihan untuk menambah header tambahan.
- **Model:** Setiap provider mempunyai senarai model. Pengguna boleh menambah model baharu secara manual.
- **Kunci API:** Untuk setiap provider, senarai kunci. Pengguna boleh menambah, menyusun keutamaan (drag-and-drop). Apabila kunci pertama gagal (status 401/429), sistem akan cuba kunci seterusnya.
- **Ujian Sambungan:** Butang "Uji" untuk mengesahkan kunci dan model.
- **Adapter:** Setiap provider mempunyai adapter yang membaca format API berdasarkan dokumentasi rasmi:
  - **DeepSeek:** OpenAI-compatible format (https://api-docs.deepseek.com/)
  - **OpenAI:** Standard OpenAI format (https://platform.openai.com/docs/api-reference)
  - **Gemini:** Google AI format (https://ai.google.dev/api/rest)
  - **Claude:** Anthropic format (https://docs.anthropic.com/claude/reference/)
  - **Mimo:** OpenAI-compatible format
  - **Custom:** Pengguna boleh tetapkan format tersuai (headers, body format, response format)

### Feature 2: Arahan Sistem & Skill (FR4, FR5, FR6)

- **Arahan Global:** Satu kotak teks panjang untuk arahan yang akan disertakan dalam setiap permintaan (contoh: "Anda adalah pembantu yang berguna").
- **Skill:** Setiap skill mempunyai:
  - Nama (pendek)
  - Kandungan (teks panjang, tanpa had aksara) – ini adalah arahan khusus atau deskripsi tugas.
- **Skill Default:** "Skill Creator" – Kandungannya memberitahu pengguna cara mencipta skill baru dengan contoh dan templat.
- **Penggunaan Skill:** Dalam chat, pengguna boleh memilih skill yang akan digabungkan dengan arahan global untuk sesi tersebut.

### Feature 3: Chat & Sejarah dengan SSE Streaming (FR7, FR8, FR9, FR13, FR14)

- **Mulakan Chat:** Pengguna pilih model (daripada provider yang aktif), kemudian masukkan mesej.
- **SSE Streaming:** 
  - Apabila pengguna hantar mesej, aplikasi membuka sambungan SSE ke provider.
  - Token dipaparkan secara real-time apabila diterima.
  - Indikator "menaip" semasa streaming aktif.
  - Pengguna boleh hentikan streaming pada bila-bila masa (butang stop).
- **Token Counting:**
  - Paparan jumlah token selepas respons selesai.
  - Butiran: prompt tokens, completion tokens, total tokens.
  - Anggaran kos berdasarkan harga model (boleh dikonfigurasi per provider).
  - Paparan dalam bubble mesej atau butiran chat.
- **Balasan:** Dipaparkan dalam gelembung chat, dengan masa, model, dan token count.
- **Simpan Sejarah:** Setiap chat disimpan dengan metadata (model, tarikh, mesej, token count).
- **Carian:** Bar carian di atas senarai chat; carian merentas tajuk dan kandungan mesej.
- **Padam:** Swipe atau butang padam untuk chat individu atau kosongkan semua.

### Feature 4: Akses Sistem (FR10)

- **Kebenaran:** Pada mulanya, aplikasi akan meminta kebenaran storan dan (untuk Android) kebenaran menjalankan arahan shell (melalui plugin).
- **Perintah Shell:** Pengguna boleh menaip !shell <command> dalam chat, dan output akan dipaparkan.
- **Operasi Fail:** !read <path> – baca kandungan fail; !write <path> <content> – tulis fail.
- **Keselamatan:** Aplikasi akan meminta pengesahan sebelum menjalankan arahan yang berpotensi berbahaya.

### Feature 5: Eksport/Import (FR11)

- **Eksport:** Menghasilkan fail JSON yang merangkumi semua provider (tanpa kunci API atas sebab keselamatan? – boleh pilihan untuk sertakan atau tidak), skill, dan arahan global.
- **Import:** Membaca fail JSON dan menambah/menggantikan tetapan.

---

## 11. User Flow

1. **Pertama Kali:** Pengguna dibawa ke skrin "Sambungkan Provider" untuk menambah provider pertama.
2. **Tetapan:** Pengguna boleh mengakses tetapan dari navigasi bawah.
3. **Chat:** Pengguna ketik "Chat Baru", pilih model, taip mesej, hantar. Respons muncul secara streaming.
4. **Sejarah:** Pengguna ketik ikon sejarah, lihat senarai, cari, dan buka chat lama.
5. **Skill:** Pengguna ke bahagian Skill, lihat skill sedia ada, tambah baru, atau sunting.

---

## 12. System Flow

### Permintaan Chat dengan SSE Streaming:

1. Pengguna hantar mesej.
2. Aplikasi bina payload (arahan global + skill + mesej).
3. Buka sambungan SSE ke provider dengan kunci pertama.
4. Jika gagal, cuba kunci seterusnya (fallback).
5. Token dipaparkan secara real-time semasa diterima.
6. Selepas selesai, papar jumlah token dan anggaran kos.
7. Simpan ke sejarah.

### Akses Shell:

1. Pengguna taip !shell ls.
2. Aplikasi jalankan arahan melalui Process.run.
3. Output ditangkap dan dipaparkan sebagai balasan.

---

## 13. Information Architecture

- **Skrin Utama (Chat):** Senarai chat, butang chat baru, carian.
- **Skrin Chat:** Paparan mesej, input, pemilihan model, token count.
- **Skrin Tetapan:** Bahagian Provider, Skill, Arahan Global, Eksport/Import.
- **Skrin Sejarah:** Senarai semua chat dengan carian.

---

## 14. Database Schema (ERD Mermaid)

```mermaid
erDiagram
    PROVIDER ||--o{ API_KEY : has
    PROVIDER ||--o{ MODEL : supports
    CHAT ||--o{ MESSAGE : contains
    CHAT ||--|| MODEL : uses
    SKILL ||--o{ CHAT : applied

    PROVIDER {
        string id
        string name
        string baseUrl
        string extraHeaders
        string adapterType "deepseek,openai,gemini,claude,mimo,custom"
        bool isActive
    }

    API_KEY {
        string id
        string providerId
        string key
        int priority
    }

    MODEL {
        string id
        string providerId
        string name
        bool isDefault
        decimal inputPricePer1k
        decimal outputPricePer1k
    }

    CHAT {
        string id
        string title
        string modelId
        string skillId
        string instructionOverride
        datetime createdAt
        datetime updatedAt
    }

    MESSAGE {
        string id
        string chatId
        string role "user,assistant,system"
        string content
        int promptTokens
        int completionTokens
        int totalTokens
        decimal estimatedCost
        datetime timestamp
    }

    SKILL {
        string id
        string name
        string content
        datetime createdAt
    }
```

---

## 15. Sequence Diagram (Mermaid)

### Send Message with SSE Streaming & Fallback

```mermaid
sequenceDiagram
    participant User
    participant UI
    participant ChatBloc
    participant ProviderManager
    participant SSEClient
    participant Storage

    User->>UI: Type message & send
    UI->>ChatBloc: SendMessageEvent
    ChatBloc->>ChatBloc: Get current model & skill
    ChatBloc->>ProviderManager: Get provider and API keys
    ProviderManager-->>ChatBloc: List of keys (priority order)
    
    loop Try each key
        ChatBloc->>SSEClient: Open SSE connection with key
        SSEClient-->>ChatBloc: Stream tokens (real-time)
        ChatBloc-->>UI: Update chat with streaming text
        
        alt Success
            SSEClient-->>ChatBloc: Stream complete (with token count)
            ChatBloc->>Storage: Save message & response with tokens
            ChatBloc-->>UI: Final update with token count
        else Failure (401/429)
            SSEClient-->>ChatBloc: Error
            ChatBloc->>ChatBloc: Try next key
        end
    end
    
    ChatBloc-->>UI: Show error if all fail
```

---

## 16. Architecture Diagram (Mermaid)

```mermaid
graph TD
    subgraph Flutter App
        UI[UI Layer]
        BLoC[Business Logic BLoC/Cubit]
        Repo[Repository]
        LocalDB[(SQLite)]
        SecureStorage[(Secure Storage)]
        ShellExecutor[Shell Executor]
        SSEClient[SSE Client]
    end

    subgraph External
        Provider1[DeepSeek API]
        Provider2[OpenAI API]
        Provider3[Gemini API]
        ProviderN[Custom Provider]
    end

    UI --> BLoC
    BLoC --> Repo
    Repo --> LocalDB
    Repo --> SecureStorage
    Repo --> ShellExecutor
    ShellExecutor --> OS[Operating System]
    Repo --> SSEClient
    SSEClient --> Provider1
    SSEClient --> Provider2
    SSEClient --> Provider3
    SSEClient --> ProviderN
```

---

## 17. API Design & Adapter Format

### Standard Payload (OpenAI-compatible):

```json
{
  "model": "deepseek-v4",
  "messages": [
    {"role": "system", "content": "Arahan global + skill"},
    {"role": "user", "content": "Mesej pengguna"}
  ],
  "temperature": 0.7,
  "max_tokens": 2000,
  "stream": true
}
```

### Response Standard (SSE):

```
data: {"id":"chatcmpl-...","choices":[{"delta":{"content":"Hello"}}],"usage":{"prompt_tokens":10,"completion_tokens":1}}
data: {"id":"chatcmpl-...","choices":[{"delta":{"content":" world"}}],"usage":{"prompt_tokens":10,"completion_tokens":2}}
data: [DONE]
```

### Adapter Specifications:

| Provider | Base URL | Format | Streaming | Docs |
|----------|----------|--------|-----------|------|
| DeepSeek | https://api.deepseek.com/v1 | OpenAI-compatible | SSE | https://api-docs.deepseek.com/ |
| OpenAI | https://api.openai.com/v1 | OpenAI standard | SSE | https://platform.openai.com/docs/api-reference |
| Gemini | https://generativelanguage.googleapis.com/v1beta | Google AI | SSE | https://ai.google.dev/api/rest |
| Claude | https://api.anthropic.com/v1 | Anthropic | SSE | https://docs.anthropic.com/claude/reference/ |
| Mimo | https://api.mimo.com/v1 | OpenAI-compatible | SSE | - |
| Custom | User-defined | User-defined | Optional | - |

### Token Counting:

Setiap respons mengandungi `usage` object:
```json
{
  "usage": {
    "prompt_tokens": 150,
    "completion_tokens": 50,
    "total_tokens": 200
  }
}
```

Anggaran kos = `(prompt_tokens / 1000 * input_price) + (completion_tokens / 1000 * output_price)`

---

## 18. Permissions & Roles

Tiada sistem pengguna berbilang; aplikasi adalah single-user. Namun, kami ada konsep "kebenaran" untuk akses sistem:

- **Akses Shell:** Pengguna mesti memberikan kebenaran secara eksplisit pada kali pertama.
- **Akses Fail:** Pengguna boleh membenarkan atau menafikan akses ke direktori tertentu.

---

## 19. Business Rules

1. Setiap provider mesti mempunyai sekurang-kurangnya satu kunci API.
2. Model yang dipilih mestilah sah untuk provider tersebut.
3. Skill tidak boleh mempunyai nama yang sama (unik).
4. Arahan global akan digabungkan dengan skill jika skill dipilih.
5. Sejarah chat disimpan selama-lamanya sehingga dipadam.
6. Fallback hanya akan digunakan jika kunci utama gagal dengan status 401 atau 429.
7. Token count disimpan untuk setiap mesej untuk tujuan analisis.

---

## 20. Validation Rules

| Entity | Field | Rule |
|--------|-------|------|
| Provider | Nama | Wajib, minimum 3 aksara. |
| Provider | Base URL | Wajib, format URL yang sah (http/https). |
| API Key | Key | Wajib, tidak kosong. |
| Model | Nama | Wajib, tidak kosong. |
| Model | Harga | Pilihan, nombor positif. |
| Skill | Nama | Wajib, unik, minimum 3 aksara. |
| Skill | Kandungan | Wajib, minimum 10 aksara. |
| Chat | Mesej | Wajib, tidak kosong. |
| Arahan Global | - | Pilihan, maksimum 10000 aksara. |

---

## 21. Edge Cases

- **Tiada Provider Aktif:** Aplikasi akan memaparkan skrin kosong dengan arahan menambah provider.
- **Kunci API Semua Gagal:** Paparan mesej ralat dan menawarkan untuk menguji semula.
- **Arahan Shell Berbahaya:** Aplikasi akan meminta pengesahan untuk arahan seperti rm -rf.
- **Kandungan Skill Sangat Panjang:** Tiada had, tetapi UI akan menggunakan scroll.
- **Sejarah Chat Beribu-ribu:** Gunakan lazy loading dan indeks carian.
- **SSE Connection Terputus:** Auto-reconnect dengan exponential backoff.
- **Token Count Tidak Tersedia:** Paparan "N/A" untuk token count.

---

## 22. Error Handling

- **Network Error:** Paparan "Sambungan gagal, semak internet".
- **API Error (4xx/5xx):** Paparan mesej ralat daripada API jika ada.
- **Fallback Gagal:** Paparan "Semua kunci API gagal, sila semak baki atau tambah kunci baru".
- **Shell Error:** Paparan output ralat daripada arahan.
- **SSE Error:** Paparan "Stream terputus" dengan butang retry.
- **Token Limit Exceeded:** Paparan amaran dan cadangan untuk kurangkan mesej.

---

## 23. Security Requirements

1. **Kunci API:** Disulitkan menggunakan AES-256 dengan kunci yang berasal dari pengguna (pengesahan biometrik jika ada) atau disimpan dalam SecureStorage.
2. **HTTPS:** Semua permintaan ke provider menggunakan HTTPS.
3. **Input Sanitization:** Kandungan mesej akan disanitasi sebelum dipaparkan (untuk mengelakkan XSS dalam UI).
4. **Kebenaran Shell:** Pengguna mesti memberikan kebenaran runtime; aplikasi tidak akan menjalankan arahan tanpa kebenaran eksplisit.

---

## 24. Performance Requirements

1. **Responsif:** Animasi lancar 60fps.
2. **Masa Muatan:** Skrin utama < 500ms.
3. **Penggunaan Memori:** Minimum 50MB untuk operasi biasa.
4. **Carian Sejarah:** Menggunakan indeks FTS SQLite untuk carian pantas.
5. **Streaming Latency:** < 100ms untuk setiap token.

---

## 25. Responsive Design Requirements

- **Telefon:** Susun atur satu lajur, navigasi bawah.
- **Tablet:** Dua lajur (senarai chat di kiri, paparan chat di kanan) untuk landskap.
- **Desktop (Web):** Jika dijalankan di web, gunakan susun atur lebar penuh.

---

## 26. Accessibility Requirements

- **WCAG 2.1 AA:** Sasaran.
- **Skrin Pembaca:** Label ARIA pada butang dan input.
- **Kontras:** Nisbah minimum 4.5:1.
- **Saiz Font:** Boleh dilaras mengikut tetapan sistem.

---

## 27. Analytics & Logging

- **Logging Tempatan:** Log ralat disimpan dalam fail untuk debugging (pilihan pengguna untuk hantar).
- **Analytik:** Tiada pengumpulan data automatik; pengguna boleh pilih untuk berkongsi statistik penggunaan secara anonim.
- **Token Usage Tracking:** Simpan sejarah penggunaan token untuk analisis kos.

---

## 28. Notifications

- **Pemberitahuan:** Apabila balasan AI tiba (jika aplikasi di latar belakang) – menggunakan push notification tempatan.
- **Status:** Paparan indikator "menaip" semasa menunggu balasan.

---

## 29. Search & Filtering

- **Carian Chat:** Carian teks penuh dalam mesej dan tajuk.
- **Penapis:** Mengikut model atau tarikh (akan datang).

---

## 30. Dashboard Requirements

- Skrin utama memaparkan senarai chat terkini dan butang "Chat Baru".
- Bahagian "Quick Skill" untuk memilih skill sebelum chat.

---

## 31. Admin Panel Requirements

Tiada admin panel kerana aplikasi single-user.

---

## 32. Settings

- **Provider:** Tambah, sunting, padam.
- **Skill:** Tambah, sunting, padam.
- **Arahan Global:** Kotak teks.
- **Eksport/Import:** Butang.
- **Tema:** Gelap/Terang.
- **Kebenaran:** Urus kebenaran shell dan fail.
- **Harga Model:** Konfigurasi harga per 1000 token untuk setiap model.

---

## 33. Future Enhancements

1. Sokongan untuk plugin pihak ketiga.
2. Integrasi dengan RAG (Retrieval-Augmented Generation) – indeks dokumen tempatan.
3. Mod perbandingan – hantar soalan ke berbilang model serentak.
4. Penyegerakan sejarah merentas peranti (cloud).
5. Keupayaan untuk melatih skill berdasarkan interaksi.
6. Sokongan untuk image generation (DALL-E, Midjourney).
7. Voice input/output.

---

## 34. Technical Constraints

- **Platform:** Flutter (Android, iOS, dan mungkin desktop/web).
- **Penyimpanan:** SQLite (sqflite) untuk chat, SecureStorage untuk kunci.
- **HTTP:** Dio atau http package dengan SSE support.
- **Shell:** Plugin process_run atau flutter_pty untuk akses terminal.

---

## 35. Suggested Tech Stack

| Komponen | Teknologi | Penerangan |
|----------|-----------|------------|
| Frontend | Flutter (Dart) | Aplikasi merentas platform dengan prestasi asli. |
| State Management | BLoC/Cubit | Pengurusan keadaan yang jelas dan boleh diuji. |
| Local DB | SQLite (sqflite) + floor atau drift | Penyimpanan chat dan metadata. |
| Secure Storage | flutter_secure_storage | Menyimpan kunci API dengan selamat. |
| HTTP Client | Dio | Dengan interceptor untuk fallback dan log. |
| SSE Client | dart:io HttpClient atau package sse | Untuk streaming response. |
| Shell Access | process_run | Menjalankan arahan sistem. |
| Dependency Injection | get_it | Untuk pengurusan ketergantungan. |
| Testing | flutter_test, mockito | Ujian unit dan widget. |

---

## 36. Folder Structure

```
lib/
├── main.dart
├── app.dart
├── core/
│   ├── constants/
│   ├── themes/
│   ├── utils/
│   └── extensions/
├── data/
│   ├── models/
│   │   ├── provider.dart
│   │   ├── api_key.dart
│   │   ├── model.dart
│   │   ├── chat.dart
│   │   ├── message.dart
│   │   └── skill.dart
│   ├── repositories/
│   │   ├── provider_repository.dart
│   │   ├── chat_repository.dart
│   │   └── skill_repository.dart
│   ├── datasources/
│   │   ├── local/
│   │   │   ├── database.dart
│   │   │   └── secure_storage.dart
│   │   └── remote/
│   │       ├── api_client.dart
│   │       ├── sse_client.dart
│   │       └── adapters/
│   │           ├── base_adapter.dart
│   │           ├── deepseek_adapter.dart
│   │           ├── openai_adapter.dart
│   │           ├── gemini_adapter.dart
│   │           ├── claude_adapter.dart
│   │           ├── mimo_adapter.dart
│   │           └── custom_adapter.dart
│   └── services/
│       ├── shell_service.dart
│       ├── fallback_manager.dart
│       └── token_counter.dart
├── domain/
│   ├── entities/
│   ├── usecases/
│   └── repositories/ (interfaces)
├── presentation/
│   ├── bloc/
│   │   ├── chat_bloc/
│   │   ├── provider_bloc/
│   │   └── skill_bloc/
│   ├── pages/
│   │   ├── chat_list_page.dart
│   │   ├── chat_detail_page.dart
│   │   ├── provider_page.dart
│   │   ├── skill_page.dart
│   │   └── settings_page.dart
│   ├── widgets/
│   │   ├── chat_bubble.dart
│   │   ├── model_selector.dart
│   │   ├── skill_selector.dart
│   │   ├── token_display.dart
│   │   └── custom_text_field.dart
│   └── routes/
└── assets/
    ├── icons/
    │   └── app_icon.png   # 📥 Muat turun dari: https://temp.sh/QzohH/IMG_20260719_164147.png
    └── translations/
```

---

## 37. Development Roadmap

| Fasa | Tempoh | Tugasan Utama |
|------|--------|---------------|
| 1 | Minggu 1-2 | **Persediaan & Data Layer** - Setup Flutter project, dependencies. - Models dan database SQLite. - Repository untuk provider dan skill. - SSE client base. |
| 2 | Minggu 3-4 | **Pengurusan Provider & Kunci** - UI untuk tambah provider, kunci, model. - Fallback manager. - Ujian sambungan. - Adapter untuk setiap provider. |
| 3 | Minggu 5-6 | **Chat & Sejarah dengan Streaming** - Chat BLoC, integrasi API dengan adapter. - SSE streaming implementation. - Token counting. - Simpan dan papar chat. - Carian sejarah. |
| 4 | Minggu 7-8 | **Skill & Arahan** - CRUD skill. - Skill default "Skill Creator". - Gabungan arahan global + skill dalam chat. |
| 5 | Minggu 9-10 | **Akses Sistem & Polishing** - Integrasi shell dan fail. - Eksport/import. - Tema, aksesibiliti, dan penggilapan UI. - Ujian menyeluruh dan beta. |

---

## 38. Acceptance Criteria

### Feature: Tambah Provider
- Given pengguna di skrin Provider.
- When pengguna mengisi nama, URL, model dan kunci, kemudian tekan "Simpan".
- Then provider baru muncul dalam senarai dan boleh dipilih untuk chat.

### Feature: Fallback API Key
- Given provider dengan dua kunci (utama dan fallback).
- When kunci utama menghasilkan 401.
- Then sistem secara automatik mencuba kunci fallback dan berjaya.

### Feature: Skill Creator Default
- Given pengguna baru.
- When membuka skrin Skill.
- Then terdapat skill bernama "Skill Creator" dengan kandungan panduan.

### Feature: Carian Sejarah
- Given terdapat banyak chat.
- When pengguna menaip kata kunci dalam bar carian.
- Then hanya chat yang mengandungi kata kunci dalam mesej atau tajuk dipaparkan.

### Feature: Akses Shell
- Given pengguna telah memberi kebenaran.
- When pengguna menaip !shell ls dalam chat.
- Then output arahan ls dipaparkan sebagai balasan.

### Feature: SSE Streaming
- Given pengguna hantar mesej.
- When API mula membalas.
- Then token dipaparkan secara real-time dalam chat bubble.

### Feature: Token Counting
- Given respons AI selesai.
- When paparan mesej akhir.
- Then jumlah token dan anggaran kos dipaparkan.

---

## 39. Testing Checklist

- **Unit Tests:** Ujian untuk repository, fallback manager, adapter, dan token counter.
- **Widget Tests:** Ujian untuk komponen UI utama.
- **Integration Tests:** Ujian aliran chat penuh dengan provider sebenar (gunakan mock).
- **Security Tests:** Pastikan kunci API tidak tersimpan dalam plain text.
- **Performance Tests:** Ujian carian dengan 1000 chat.
- **Streaming Tests:** Ujian SSE connection dan reconnect.

---

## 40. Deployment Requirements

1. **Android:** Bangunkan APK/AAB, tandatangani, dan hantar ke Google Play Store.
2. **iOS:** Bangunkan IPA, hantar ke App Store Connect.
3. **Web (Pilihan):** Gunakan Flutter Web, deploy ke Firebase Hosting atau Netlify.
4. **CI/CD:** Gunakan GitHub Actions untuk automasi ujian dan build.

---

# README.md

## Project Introduction

### Nama Projek
Multi Agent AI

### Ringkasan Aplikasi
Multi Agent AI ialah aplikasi mudah alih pintar yang menggabungkan kuasa pelbagai model AI (DeepSeek, OpenAI, Gemini, Claude, Mimo, dan custom) dalam satu antara muka yang elegan dan tidak kelihatan seperti dijana AI. Anda boleh menguruskan berbilang provider, kunci API fallback, skill tanpa had, arahan sistem, dan juga mengakses shell serta sistem fail peranti anda. Sejarah chat disimpan dan boleh dicari dengan mudah. Aplikasi ini sesuai untuk pembangun, penulis, dan sesiapa yang mahukan kawalan penuh ke atas interaksi AI mereka.

**Ciri Utama:**
- SSE Streaming untuk respons masa nyata
- Token counting untuk memantau kos
- Adapter fleksibel berdasarkan dokumentasi rasmi setiap provider

### Tujuan Projek
Menyediakan platform AI serba guna yang fleksibel, selamat, dan mesra pengguna, tanpa bergantung pada mana-mana provider tunggal, dengan keupayaan automasi sistem.

### Masalah yang Diselesaikan
- Menggabungkan pelbagai provider AI dalam satu aplikasi.
- Menyediakan mekanisme fallback untuk kunci API.
- Membolehkan pengguna mencipta dan menggunakan semula skill (arahan kompleks).
- Memberi akses ke sistem fail dan shell untuk automasi.
- Menyimpan dan mencari sejarah chat dengan mudah.
- Memantau penggunaan token dan kos API.

---

## Main Features

1. **Pengurusan Provider & Kunci:** Tambah provider AI (DeepSeek, OpenAI, Gemini, Claude, Mimo, custom), tambah berbilang kunci API dengan fallback automatik.
2. **Model & Pemilihan:** Pilih model dari provider yang disokong.
3. **Arahan Sistem & Skill:** Tetapkan arahan global, cipta skill tanpa had, dan skill default "Skill Creator" untuk panduan.
4. **Chat & Sejarah dengan Streaming:** Sesi chat dengan model, disimpan secara lokal, carian teks penuh, SSE streaming.
5. **Token Counting:** Paparan penggunaan token dan anggaran kos.
6. **Akses Sistem:** Jalankan arahan shell dan baca/tulis fail melalui chat (dengan kebenaran).
7. **Eksport/Import:** Kongsi konfigurasi provider dan skill.

---

## Tech Stack

### Frontend
- **Framework:** Flutter (Dart)
- **State Management:** BLoC/Cubit
- **Local DB:** SQLite (sqflite) + floor/drift
- **Secure Storage:** flutter_secure_storage
- **HTTP Client:** Dio
- **SSE Client:** dart:io HttpClient
- **Shell Access:** process_run

### Backend
Tiada backend khusus; aplikasi terus berkomunikasi dengan API provider AI.

### Database
- **SQLite:** Untuk chat, provider, skill, dan metadata.

### Infrastructure
- **Build Tools:** Flutter SDK, Android Studio/Xcode
- **CI/CD:** GitHub Actions

### Third-party Services
- DeepSeek API
- OpenAI API
- Google Gemini API
- Anthropic Claude API
- Mimo API (atau lain-lain)

---

## System Requirements

### Hardware Requirement
- **Minimum:** 2GB RAM, 200MB ruang storan.
- **Recommended:** 4GB RAM.

### Software Requirement
- **Flutter SDK:** v3.16 atau lebih tinggi.
- **Android Studio / Xcode** untuk pembangunan.
- **Git** untuk cloning.

### Operating System
- **Development:** Windows, macOS, Linux.
- **Production:** Android 5.0+, iOS 12+.

---

## Installation Guide

### 1. Clone Project
```bash
git clone https://github.com/username/multi_agent_ai.git
cd multi_agent_ai
```

### 2. Install Dependencies
```bash
flutter pub get
```

### 3. Setup Configuration
Tiada fail .env; semua konfigurasi dilakukan dalam aplikasi.

### 4. Database Setup
Aplikasi akan mencipta pangkalan data secara automatik pada kali pertama dijalankan.

---

## Running The Project

### Development Mode
```bash
flutter run
```

### Production Mode
```bash
flutter build apk --release
flutter build ios --release
```

---

## Project Structure

```
lib/
├── core/             # Utiliti, tema, konstanta
├── data/             # Model, repository, datasource, service
├── domain/           # Entiti dan use case (jika guna clean architecture)
├── presentation/     # BLoC, halaman, widget
└── main.dart
```

---

## Build & Deployment

### Android
```bash
flutter build apk --split-per-abi
```

### iOS
```bash
flutter build ios --release
# Kemudian buka Xcode dan arkibkan
```

---

## Testing

```bash
# Unit dan widget tests
flutter test

# Integration tests
flutter test integration_test/
```

---

## API Overview

Aplikasi menggunakan REST API daripada provider. Contoh endpoint:

- **DeepSeek:** https://api.deepseek.com/v1/chat/completions
- **OpenAI:** https://api.openai.com/v1/chat/completions
- **Gemini:** https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent

Sila rujuk dokumentasi masing-masing untuk format.

---

## FAQ

1. **Bolehkah saya menambah provider custom?**
   Ya, masukkan URL base dan model-model yang disokong.

2. **Bagaimana fallback API key berfungsi?**
   Sistem akan mencuba kunci mengikut keutamaan. Jika satu gagal (401/429), ia akan beralih ke kunci seterusnya.

3. **Adakah data saya disimpan di cloud?**
   Tidak, semua data disimpan secara lokal di peranti anda.

4. **Bolehkah saya menggunakan aplikasi ini di desktop?**
   Ya, Flutter menyokong Windows, macOS, dan Linux.

5. **Bagaimana untuk melihat penggunaan token?**
   Token count dipaparkan di bawah setiap mesej AI selepas respons selesai.

---

## Troubleshooting

- **Ralat "Provider not found":** Pastikan anda telah menambah provider dan kunci API yang sah.
- **Arahan shell tidak berfungsi:** Pastikan kebenaran telah diberikan dan peranti menyokong.
- **Carian lambat:** Jika sejarah sangat besar, pertimbangkan untuk memadam chat lama.
- **Stream terputus:** Semak sambungan internet dan cuba lagi.

---

## License

MIT License

---

## Credits

- **Pembangun Utama:** [Nama Anda]
- **Ikon Aplikasi:**
  - 📥 Muat turun dari sini
  - Letakkan fail di: assets/icons/app_icon.png
- **Dokumentasi:** [Nama Anda]
- **Terima kasih kepada:** Komuniti Flutter, penyedia AI, dan semua penguji beta.

---

## Multi Application / External Service Documentation

Aplikasi ini adalah standalone (tiada backend berasingan). Walau bagaimanapun, ia bergantung pada perkhidmatan AI luaran. Dokumentasi integrasi:

### Senarai Komponen

1. **Aplikasi Multi Agent AI (Flutter)** – klien utama.
2. **Provider AI Luaran** – DeepSeek, OpenAI, Gemini, Claude, Mimo, dan lain-lain.

### Fungsi Setiap Komponen

- **Aplikasi:** Mengurus UI, logik perniagaan, storan, dan komunikasi dengan provider.
- **Provider:** Menyediakan model AI melalui API.

### Hubungan

Aplikasi menghantar permintaan HTTP ke endpoint provider yang dipilih.

### Data Flow

1. Pengguna memasukkan mesej.
2. Aplikasi membina payload, menghantar ke provider melalui SSE.
3. Provider memproses dan menghantar token secara streaming.
4. Aplikasi memaparkan token secara real-time dan menyimpan respons.

### API Communication

- **Protokol:** HTTPS + SSE
- **Format:** JSON
- **Pengesahan:** Menggunakan API key dalam header Authorization: Bearer <key>.

### Authentication Antara Service

Tiada autentikasi antara aplikasi dan provider selain daripada kunci API.

### Dependency

- Aplikasi bergantung pada sambungan internet dan kunci API yang sah.

### Environment Configuration

Tiada fail persekitaran; semua dimasukkan melalui UI.

### Cara Menjalankan Keseluruhan Ecosystem

1. Bina dan jalankan aplikasi Flutter.
2. Tambahkan provider dan kunci API melalui tetapan.
3. Mulakan chat.

---

**Tamat PRD**
