import 'package:uuid/uuid.dart';

class AiModel {
  final String id;
  final String providerId;
  final String name;
  final bool isDefault;
  final double inputPricePer1k;
  final double outputPricePer1k;
  final DateTime createdAt;

  AiModel({
    String? id,
    required this.providerId,
    required this.name,
    this.isDefault = false,
    this.inputPricePer1k = 0.0,
    this.outputPricePer1k = 0.0,
    DateTime? createdAt,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'provider_id': providerId,
      'name': name,
      'is_default': isDefault ? 1 : 0,
      'input_price_per_1k': inputPricePer1k,
      'output_price_per_1k': outputPricePer1k,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory AiModel.fromMap(Map<String, dynamic> map) {
    return AiModel(
      id: map['id'],
      providerId: map['provider_id'],
      name: map['name'],
      isDefault: map['is_default'] == 1,
      inputPricePer1k: (map['input_price_per_1k'] as num?)?.toDouble() ?? 0.0,
      outputPricePer1k: (map['output_price_per_1k'] as num?)?.toDouble() ?? 0.0,
      createdAt: DateTime.parse(map['created_at']),
    );
  }

  AiModel copyWith({
    String? name,
    bool? isDefault,
    double? inputPricePer1k,
    double? outputPricePer1k,
  }) {
    return AiModel(
      id: id,
      providerId: providerId,
      name: name ?? this.name,
      isDefault: isDefault ?? this.isDefault,
      inputPricePer1k: inputPricePer1k ?? this.inputPricePer1k,
      outputPricePer1k: outputPricePer1k ?? this.outputPricePer1k,
      createdAt: createdAt,
    );
  }
}
