import 'package:uuid/uuid.dart';

class Skill {
  final String id;
  final String name;
  final String content;
  final DateTime createdAt;

  Skill({
    String? id,
    required this.name,
    required this.content,
    DateTime? createdAt,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'content': content,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Skill.fromMap(Map<String, dynamic> map) {
    return Skill(
      id: map['id'],
      name: map['name'],
      content: map['content'],
      createdAt: DateTime.parse(map['created_at']),
    );
  }

  Skill copyWith({
    String? name,
    String? content,
  }) {
    return Skill(
      id: id,
      name: name ?? this.name,
      content: content ?? this.content,
      createdAt: createdAt,
    );
  }

  // Default Skill Creator
  static Skill get skillCreator => Skill(
        name: 'Skill Creator',
        content: '''Anda adalah pembantu yang membantu pengguna mencipta skill baru.

Untuk mencipta skill, pengguna perlu memberikan:
1. **Nama Skill** - Nama pendek dan deskriptif (contoh: "Code Reviewer", "Email Writer")
2. **Kandungan** - Arahan terperinci tentang apa yang skill ini lakukan

Contoh format skill:
```
Nama: Code Reviewer
Kandungan: Anda adalah pakar kod yang akan menyemak kod pengguna. Berikan:
1. Analisis struktur kod
2. Cadangan penambahbaikan
3. Pengesanan potensi bug
4. Amalan terbaik yang dicadangkan
```

Bimbing pengguna melalui proses ini dan bantu mereka mencipta skill yang berguna.''',
      );
}
