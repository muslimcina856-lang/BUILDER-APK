import 'package:uuid/uuid.dart';

enum MessageRole {
  user,
  assistant,
  system,
}

class Message {
  final String id;
  final String chatId;
  final MessageRole role;
  final String content;
  final int? promptTokens;
  final int? completionTokens;
  final int? totalTokens;
  final double? estimatedCost;
  final DateTime timestamp;

  Message({
    String? id,
    required this.chatId,
    required this.role,
    required this.content,
    this.promptTokens,
    this.completionTokens,
    this.totalTokens,
    this.estimatedCost,
    DateTime? timestamp,
  })  : id = id ?? const Uuid().v4(),
        timestamp = timestamp ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'chat_id': chatId,
      'role': role.name,
      'content': content,
      'prompt_tokens': promptTokens,
      'completion_tokens': completionTokens,
      'total_tokens': totalTokens,
      'estimated_cost': estimatedCost,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory Message.fromMap(Map<String, dynamic> map) {
    return Message(
      id: map['id'],
      chatId: map['chat_id'],
      role: MessageRole.values.firstWhere((e) => e.name == map['role']),
      content: map['content'],
      promptTokens: map['prompt_tokens'],
      completionTokens: map['completion_tokens'],
      totalTokens: map['total_tokens'],
      estimatedCost: (map['estimated_cost'] as num?)?.toDouble(),
      timestamp: DateTime.parse(map['timestamp']),
    );
  }

  Message copyWith({
    String? content,
    int? promptTokens,
    int? completionTokens,
    int? totalTokens,
    double? estimatedCost,
  }) {
    return Message(
      id: id,
      chatId: chatId,
      role: role,
      content: content ?? this.content,
      promptTokens: promptTokens ?? this.promptTokens,
      completionTokens: completionTokens ?? this.completionTokens,
      totalTokens: totalTokens ?? this.totalTokens,
      estimatedCost: estimatedCost ?? this.estimatedCost,
      timestamp: timestamp,
    );
  }

  bool get isUser => role == MessageRole.user;
  bool get isAssistant => role == MessageRole.assistant;
  bool get isSystem => role == MessageRole.system;

  String get tokenInfo {
    if (totalTokens == null) return '';
    final parts = <String>[];
    if (promptTokens != null) parts.add('Prompt: $promptTokens');
    if (completionTokens != null) parts.add('Completion: $completionTokens');
    parts.add('Total: $totalTokens');
    if (estimatedCost != null) parts.add('Cost: \$${estimatedCost!.toStringAsFixed(4)}');
    return parts.join(' | ');
  }
}
