import 'package:uuid/uuid.dart';

class Chat {
  final String id;
  final String title;
  final String modelId;
  final String? skillId;
  final String? instructionOverride;
  final DateTime createdAt;
  final DateTime updatedAt;

  Chat({
    String? id,
    required this.title,
    required this.modelId,
    this.skillId,
    this.instructionOverride,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'model_id': modelId,
      'skill_id': skillId,
      'instruction_override': instructionOverride,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  factory Chat.fromMap(Map<String, dynamic> map) {
    return Chat(
      id: map['id'],
      title: map['title'],
      modelId: map['model_id'],
      skillId: map['skill_id'],
      instructionOverride: map['instruction_override'],
      createdAt: DateTime.parse(map['created_at']),
      updatedAt: DateTime.parse(map['updated_at']),
    );
  }

  Chat copyWith({
    String? title,
    String? modelId,
    String? skillId,
    String? instructionOverride,
  }) {
    return Chat(
      id: id,
      title: title ?? this.title,
      modelId: modelId ?? this.modelId,
      skillId: skillId ?? this.skillId,
      instructionOverride: instructionOverride ?? this.instructionOverride,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}
