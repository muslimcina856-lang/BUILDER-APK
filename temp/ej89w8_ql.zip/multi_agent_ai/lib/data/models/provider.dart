import 'package:uuid/uuid.dart';

class AiProvider {
  final String id;
  final String name;
  final String baseUrl;
  final String adapterType;
  final Map<String, String> extraHeaders;
  final bool isActive;
  final DateTime createdAt;

  AiProvider({
    String? id,
    required this.name,
    required this.baseUrl,
    required this.adapterType,
    this.extraHeaders = const {},
    this.isActive = true,
    DateTime? createdAt,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'base_url': baseUrl,
      'adapter_type': adapterType,
      'extra_headers': extraHeaders.entries.map((e) => '${e.key}: ${e.value}').join('\n'),
      'is_active': isActive ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory AiProvider.fromMap(Map<String, dynamic> map) {
    final headersStr = map['extra_headers'] as String? ?? '';
    final headers = <String, String>{};
    if (headersStr.isNotEmpty) {
      for (final line in headersStr.split('\n')) {
        final parts = line.split(': ');
        if (parts.length == 2) {
          headers[parts[0]] = parts[1];
        }
      }
    }
    
    return AiProvider(
      id: map['id'],
      name: map['name'],
      baseUrl: map['base_url'],
      adapterType: map['adapter_type'],
      extraHeaders: headers,
      isActive: map['is_active'] == 1,
      createdAt: DateTime.parse(map['created_at']),
    );
  }

  AiProvider copyWith({
    String? name,
    String? baseUrl,
    String? adapterType,
    Map<String, String>? extraHeaders,
    bool? isActive,
  }) {
    return AiProvider(
      id: id,
      name: name ?? this.name,
      baseUrl: baseUrl ?? this.baseUrl,
      adapterType: adapterType ?? this.adapterType,
      extraHeaders: extraHeaders ?? this.extraHeaders,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
    );
  }
}
