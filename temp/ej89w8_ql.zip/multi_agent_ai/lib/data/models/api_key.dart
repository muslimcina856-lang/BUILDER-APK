import 'package:uuid/uuid.dart';

class ApiKey {
  final String id;
  final String providerId;
  final String key;
  final int priority;
  final bool isActive;
  final DateTime createdAt;

  ApiKey({
    String? id,
    required this.providerId,
    required this.key,
    required this.priority,
    this.isActive = true,
    DateTime? createdAt,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'provider_id': providerId,
      'key': key,
      'priority': priority,
      'is_active': isActive ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory ApiKey.fromMap(Map<String, dynamic> map) {
    return ApiKey(
      id: map['id'],
      providerId: map['provider_id'],
      key: map['key'],
      priority: map['priority'],
      isActive: map['is_active'] == 1,
      createdAt: DateTime.parse(map['created_at']),
    );
  }

  ApiKey copyWith({
    String? key,
    int? priority,
    bool? isActive,
  }) {
    return ApiKey(
      id: id,
      providerId: providerId,
      key: key ?? this.key,
      priority: priority ?? this.priority,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
    );
  }
}
