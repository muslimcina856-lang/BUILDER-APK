import '../datasources/local/database.dart';
import '../models/api_key.dart';

class FallbackManager {
  final DatabaseHelper _db = DatabaseHelper();

  // Get active API keys for a provider, sorted by priority
  Future<List<ApiKey>> getActiveKeys(String providerId) async {
    final keys = await _db.getApiKeys(providerId);
    return keys.where((key) => key.isActive).toList()
      ..sort((a, b) => a.priority.compareTo(b.priority));
  }

  // Try each key in order, return first successful result
  Future<T> tryWithFallback<T>({
    required String providerId,
    required Future<T> Function(String apiKey) action,
  }) async {
    final keys = await getActiveKeys(providerId);
    
    if (keys.isEmpty) {
      throw Exception('No API keys available for this provider');
    }

    Exception? lastException;

    for (final apiKey in keys) {
      try {
        return await action(apiKey.key);
      } catch (e) {
        lastException = e is Exception ? e : Exception(e.toString());
        
        // Check if it's a retryable error (401 or 429)
        final errorStr = e.toString();
        if (errorStr.contains('401') || errorStr.contains('429')) {
          // Try next key
          continue;
        }
        
        // Non-retryable error, throw immediately
        rethrow;
      }
    }

    // All keys failed
    throw lastException ?? Exception('All API keys failed');
  }

  // Mark a key as inactive
  Future<void> deactivateKey(String keyId) async {
    final db = await _db.database;
    await db.update(
      'api_keys',
      {'is_active': 0},
      where: 'id = ?',
      whereArgs: [keyId],
    );
  }

  // Get next priority number for a provider
  Future<int> getNextPriority(String providerId) async {
    final keys = await _db.getApiKeys(providerId);
    if (keys.isEmpty) return 1;
    return keys.map((k) => k.priority).reduce((a, b) => a > b ? a : b) + 1;
  }
}
