import 'dart:io';
import 'package:process_run/process_run.dart';

class ShellService {
  static final ShellService _instance = ShellService._internal();
  factory ShellService() => _instance;
  ShellService._internal();

  bool _isAuthorized = false;

  bool get isAuthorized => _isAuthorized;

  // Request authorization
  Future<bool> requestAuthorization() async {
    // In a real app, this would show a dialog
    // For now, we'll just set it to true
    _isAuthorized = true;
    return _isAuthorized;
  }

  // Check if command is dangerous
  bool isDangerousCommand(String command) {
    final dangerousPatterns = [
      'rm -rf',
      'rm -r',
      'sudo',
      'chmod 777',
      'dd if=',
      'mkfs',
      ':(){:|:&};:',
      'shutdown',
      'reboot',
      'format',
    ];

    final lowerCommand = command.toLowerCase();
    return dangerousPatterns.any((pattern) => lowerCommand.contains(pattern));
  }

  // Execute shell command
  Future<ShellResult> executeCommand(String command) async {
    if (!_isAuthorized) {
      return ShellResult(
        success: false,
        output: 'Shell access not authorized. Please authorize first.',
        error: 'Unauthorized',
      );
    }

    try {
      final shell = Shell();
      final result = await shell.run(command);

      return ShellResult(
        success: result.exitCode == 0,
        output: result.outText,
        error: result.errText,
        exitCode: result.exitCode,
      );
    } catch (e) {
      return ShellResult(
        success: false,
        output: '',
        error: e.toString(),
      );
    }
  }

  // Read file
  Future<ShellResult> readFile(String path) async {
    if (!_isAuthorized) {
      return ShellResult(
        success: false,
        output: '',
        error: 'File access not authorized.',
      );
    }

    try {
      final file = File(path);
      if (!await file.exists()) {
        return ShellResult(
          success: false,
          output: '',
          error: 'File not found: $path',
        );
      }

      final content = await file.readAsString();
      return ShellResult(
        success: true,
        output: content,
        error: '',
      );
    } catch (e) {
      return ShellResult(
        success: false,
        output: '',
        error: e.toString(),
      );
    }
  }

  // Write file
  Future<ShellResult> writeFile(String path, String content) async {
    if (!_isAuthorized) {
      return ShellResult(
        success: false,
        output: '',
        error: 'File access not authorized.',
      );
    }

    try {
      final file = File(path);
      await file.writeAsString(content);
      return ShellResult(
        success: true,
        output: 'File written successfully: $path',
        error: '',
      );
    } catch (e) {
      return ShellResult(
        success: false,
        output: '',
        error: e.toString(),
      );
    }
  }
}

class ShellResult {
  final bool success;
  final String output;
  final String error;
  final int? exitCode;

  ShellResult({
    required this.success,
    required this.output,
    required this.error,
    this.exitCode,
  });

  String get formattedOutput {
    if (success) {
      return output.isNotEmpty ? output : 'Command executed successfully.';
    } else {
      return 'Error: $error';
    }
  }
}
