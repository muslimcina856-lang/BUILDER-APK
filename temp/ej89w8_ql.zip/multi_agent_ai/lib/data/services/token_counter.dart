class TokenCounter {
  static final TokenCounter _instance = TokenCounter._internal();
  factory TokenCounter() => _instance;
  TokenCounter._internal();

  // Calculate estimated cost based on token counts and model pricing
  double calculateCost({
    required int promptTokens,
    required int completionTokens,
    required double inputPricePer1k,
    required double outputPricePer1k,
  }) {
    final inputCost = (promptTokens / 1000) * inputPricePer1k;
    final outputCost = (completionTokens / 1000) * outputPricePer1k;
    return inputCost + outputCost;
  }

  // Format token count for display
  String formatTokenCount(int tokens) {
    if (tokens >= 1000) {
      return '${(tokens / 1000).toStringAsFixed(1)}k';
    }
    return tokens.toString();
  }

  // Format cost for display
  String formatCost(double cost) {
    if (cost < 0.01) {
      return '\$${cost.toStringAsFixed(4)}';
    }
    return '\$${cost.toStringAsFixed(2)}';
  }

  // Get token info string
  String getTokenInfo({
    required int? promptTokens,
    required int? completionTokens,
    required int? totalTokens,
    required double? estimatedCost,
  }) {
    if (totalTokens == null) return '';

    final parts = <String>[];
    if (promptTokens != null) parts.add('Prompt: ${formatTokenCount(promptTokens)}');
    if (completionTokens != null) parts.add('Completion: ${formatTokenCount(completionTokens)}');
    parts.add('Total: ${formatTokenCount(totalTokens)}');
    if (estimatedCost != null) parts.add('Cost: ${formatCost(estimatedCost)}');

    return parts.join(' | ');
  }
}
