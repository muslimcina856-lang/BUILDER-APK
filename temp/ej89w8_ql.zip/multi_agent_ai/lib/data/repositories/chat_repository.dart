import 'dart:async';
import '../datasources/local/database.dart';
import '../datasources/remote/api_client.dart';
import '../datasources/remote/adapters/base_adapter.dart';
import '../models/chat.dart';
import '../models/message.dart';
import '../models/provider.dart';
import '../models/model.dart';
import '../services/fallback_manager.dart';
import '../services/token_counter.dart';
import 'provider_repository.dart';

class ChatRepository {
  final DatabaseHelper _db = DatabaseHelper();
  final ApiClient _apiClient = ApiClient();
  final FallbackManager _fallbackManager = FallbackManager();
  final TokenCounter _tokenCounter = TokenCounter();
  final ProviderRepository _providerRepository = ProviderRepository();

  // ==================== CHATS ====================

  Future<List<Chat>> getChats() async {
    return await _db.getChats();
  }

  Future<Chat?> getChat(String id) async {
    return await _db.getChat(id);
  }

  Future<void> createChat(Chat chat) async {
    await _db.insertChat(chat);
  }

  Future<void> updateChat(Chat chat) async {
    await _db.updateChat(chat);
  }

  Future<void> deleteChat(String id) async {
    await _db.deleteMessagesByChat(id);
    await _db.deleteChat(id);
  }

  Future<List<Chat>> searchChats(String query) async {
    return await _db.searchChats(query);
  }

  // ==================== MESSAGES ====================

  Future<List<Message>> getMessages(String chatId) async {
    return await _db.getMessages(chatId);
  }

  Future<void> saveMessage(Message message) async {
    await _db.insertMessage(message);
  }

  // ==================== SEND MESSAGE WITH STREAMING ====================

  Stream<StreamingResponse> sendMessage({
    required Chat chat,
    required String content,
    required AiProvider provider,
    required AiModel model,
    String? systemInstruction,
  }) async* {
    // Save user message
    final userMessage = Message(
      chatId: chat.id,
      role: MessageRole.user,
      content: content,
    );
    await _db.insertMessage(userMessage);

    // Get conversation history
    final messages = await _db.getMessages(chat.id);

    // Get API key with fallback
    final keys = await _providerRepository.getActiveApiKeys(provider.id);
    if (keys.isEmpty) {
      yield StreamingResponse(error: 'No API keys available');
      return;
    }

    // Build system instruction
    final fullInstruction = _buildSystemInstruction(
      globalInstruction: systemInstruction ?? '',
      skillContent: '', // TODO: Get from skill
      chatInstruction: chat.instructionOverride,
    );

    // Try each key
    Exception? lastException;
    for (final apiKey in keys) {
      final actualKey = await _providerRepository.getActualApiKey(apiKey.id);
      if (actualKey == null) continue;

      try {
        final stream = _apiClient.sendMessage(
          provider: provider,
          apiKey: actualKey,
          model: model.name,
          messages: messages,
          systemInstruction: fullInstruction,
        );

        String fullContent = '';
        int? promptTokens;
        int? completionTokens;
        int? totalTokens;

        await for (final response in stream) {
          if (response.error != null) {
            throw Exception(response.error);
          }

          if (response.content != null) {
            fullContent += response.content!;
          }

          if (response.promptTokens != null) promptTokens = response.promptTokens;
          if (response.completionTokens != null) completionTokens = response.completionTokens;
          if (response.totalTokens != null) totalTokens = response.totalTokens;

          yield response;

          if (response.isDone) {
            // Save assistant message
            final estimatedCost = _tokenCounter.calculateCost(
              promptTokens: promptTokens ?? 0,
              completionTokens: completionTokens ?? 0,
              inputPricePer1k: model.inputPricePer1k,
              outputPricePer1k: model.outputPricePer1k,
            );

            final assistantMessage = Message(
              chatId: chat.id,
              role: MessageRole.assistant,
              content: fullContent,
              promptTokens: promptTokens,
              completionTokens: completionTokens,
              totalTokens: totalTokens,
              estimatedCost: estimatedCost,
            );
            await _db.insertMessage(assistantMessage);

            // Update chat timestamp
            await _db.updateChat(chat.copyWith());
            return;
          }
        }
      } catch (e) {
        lastException = e is Exception ? e : Exception(e.toString());
        
        final errorStr = e.toString();
        if (errorStr.contains('401') || errorStr.contains('429')) {
          continue; // Try next key
        }
        
        yield StreamingResponse(error: e.toString());
        return;
      }
    }

    yield StreamingResponse(
      error: lastException?.toString() ?? 'All API keys failed',
    );
  }

  // Cancel current request
  void cancelRequest() {
    _apiClient.cancel();
  }

  // ==================== HELPERS ====================

  String _buildSystemInstruction({
    required String globalInstruction,
    required String skillContent,
    String? chatInstruction,
  }) {
    final parts = <String>[];
    
    if (globalInstruction.isNotEmpty) parts.add(globalInstruction);
    if (skillContent.isNotEmpty) parts.add(skillContent);
    if (chatInstruction != null && chatInstruction.isNotEmpty) {
      parts.add(chatInstruction);
    }
    
    return parts.join('\n\n');
  }

  // ==================== STATS ====================

  Future<Map<String, dynamic>> getStats() async {
    return await _db.getStats();
  }

  void dispose() {
    _apiClient.dispose();
  }
}
