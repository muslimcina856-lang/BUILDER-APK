import '../datasources/local/database.dart';
import '../models/skill.dart';

class SkillRepository {
  final DatabaseHelper _db = DatabaseHelper();

  Future<List<Skill>> getSkills() async {
    return await _db.getSkills();
  }

  Future<Skill?> getSkill(String id) async {
    return await _db.getSkill(id);
  }

  Future<void> addSkill(Skill skill) async {
    // Check for duplicate name
    final existing = await _db.getSkills();
    if (existing.any((s) => s.name == skill.name)) {
      throw Exception('Skill with this name already exists');
    }
    
    await _db.insertSkill(skill);
  }

  Future<void> updateSkill(Skill skill) async {
    // Check for duplicate name (excluding current skill)
    final existing = await _db.getSkills();
    if (existing.any((s) => s.name == skill.name && s.id != skill.id)) {
      throw Exception('Skill with this name already exists');
    }
    
    await _db.updateSkill(skill);
  }

  Future<void> deleteSkill(String id) async {
    // Don't allow deleting the default skill creator
    final skill = await _db.getSkill(id);
    if (skill?.name == 'Skill Creator') {
      throw Exception('Cannot delete the default Skill Creator');
    }
    
    await _db.deleteSkill(id);
  }

  Future<Skill> getOrCreateSkillCreator() async {
    final skills = await _db.getSkills();
    final creator = skills.where((s) => s.name == 'Skill Creator').firstOrNull;
    
    if (creator != null) {
      return creator;
    }
    
    // Create default skill creator
    await _db.insertSkill(Skill.skillCreator);
    return Skill.skillCreator;
  }
}
