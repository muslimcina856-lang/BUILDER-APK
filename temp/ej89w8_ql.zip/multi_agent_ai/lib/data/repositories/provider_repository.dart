import '../datasources/local/database.dart';
import '../datasources/local/secure_storage.dart';
import '../models/provider.dart';
import '../models/api_key.dart';
import '../models/model.dart';

class ProviderRepository {
  final DatabaseHelper _db = DatabaseHelper();
  final SecureStorageHelper _secureStorage = SecureStorageHelper();

  // ==================== PROVIDERS ====================

  Future<List<AiProvider>> getProviders() async {
    return await _db.getProviders();
  }

  Future<AiProvider?> getProvider(String id) async {
    return await _db.getProvider(id);
  }

  Future<void> addProvider(AiProvider provider) async {
    await _db.insertProvider(provider);
  }

  Future<void> updateProvider(AiProvider provider) async {
    await _db.updateProvider(provider);
  }

  Future<void> deleteProvider(String id) async {
    // Delete all API keys for this provider
    final keys = await _db.getApiKeys(id);
    for (final key in keys) {
      await _secureStorage.deleteApiKey(key.id);
    }
    
    await _db.deleteProvider(id);
  }

  Future<List<AiProvider>> getActiveProviders() async {
    final providers = await _db.getProviders();
    return providers.where((p) => p.isActive).toList();
  }

  // ==================== API KEYS ====================

  Future<List<ApiKey>> getApiKeys(String providerId) async {
    return await _db.getApiKeys(providerId);
  }

  Future<void> addApiKey(ApiKey apiKey) async {
    // Store the actual key in secure storage
    await _secureStorage.saveApiKey(apiKey.id, apiKey.key);
    
    // Store metadata in database (with masked key)
    final maskedKey = _maskKey(apiKey.key);
    final dbKey = apiKey.copyWith(key: maskedKey);
    await _db.insertApiKey(dbKey);
  }

  Future<void> updateApiKey(ApiKey apiKey) async {
    // Update in secure storage
    await _secureStorage.saveApiKey(apiKey.id, apiKey.key);
    
    // Update in database
    final maskedKey = _maskKey(apiKey.key);
    final dbKey = apiKey.copyWith(key: maskedKey);
    await _db.updateApiKey(dbKey);
  }

  Future<void> deleteApiKey(String id) async {
    await _secureStorage.deleteApiKey(id);
    await _db.deleteApiKey(id);
  }

  Future<String?> getActualApiKey(String keyId) async {
    return await _secureStorage.getApiKey(keyId);
  }

  Future<List<ApiKey>> getActiveApiKeys(String providerId) async {
    final keys = await _db.getApiKeys(providerId);
    return keys.where((k) => k.isActive).toList()
      ..sort((a, b) => a.priority.compareTo(b.priority));
  }

  // ==================== MODELS ====================

  Future<List<AiModel>> getModels(String providerId) async {
    return await _db.getModels(providerId);
  }

  Future<AiModel?> getModel(String id) async {
    return await _db.getModel(id);
  }

  Future<void> addModel(AiModel model) async {
    await _db.insertModel(model);
  }

  Future<void> updateModel(AiModel model) async {
    await _db.updateModel(model);
  }

  Future<void> deleteModel(String id) async {
    await _db.deleteModel(id);
  }

  // ==================== HELPERS ====================

  String _maskKey(String key) {
    if (key.length <= 8) return '****';
    return '${key.substring(0, 4)}****${key.substring(key.length - 4)}';
  }
}
