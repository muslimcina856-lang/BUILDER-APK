import 'dart:async';
import 'dart:convert';
import 'dart:io';

class SSEEvent {
  final String? id;
  final String? event;
  final String data;

  SSEEvent({this.id, this.event, required this.data});

  bool get isDone => data.trim() == '[DONE]';
}

class SSEClient {
  HttpClient? _httpClient;
  HttpClientRequest? _request;
  HttpClientResponse? _response;
  StreamController<SSEEvent>? _controller;
  bool _isCancelled = false;

  Stream<SSEEvent> connect({
    required String url,
    required Map<String, String> headers,
    required String body,
  }) {
    _controller = StreamController<SSEEvent>();
    _isCancelled = false;

    _connect(url, headers, body);

    return _controller!.stream;
  }

  Future<void> _connect(
    String url,
    Map<String, String> headers,
    String body,
  ) async {
    try {
      _httpClient = HttpClient();
      final uri = Uri.parse(url);
      _request = await _httpClient!.postUrl(uri);

      // Set headers
      headers.forEach((key, value) {
        _request!.headers.set(key, value);
      });
      _request!.headers.set('Accept', 'text/event-stream');
      _request!.headers.set('Cache-Control', 'no-cache');

      // Set body
      _request!.write(body);
      _response = await _request!.close();

      if (_response!.statusCode != 200) {
        final responseBody = await _response!.transform(utf8.decoder).join();
        _controller?.addError(Exception(
          'HTTP ${_response!.statusCode}: $responseBody',
        ));
        _controller?.close();
        return;
      }

      // Listen to SSE stream
      String buffer = '';
      
      await for (final chunk in _response!.transform(utf8.decoder)) {
        if (_isCancelled) break;

        buffer += chunk;
        final lines = buffer.split('\n');
        buffer = lines.removeLast(); // Keep incomplete line in buffer

        for (final line in lines) {
          if (_isCancelled) break;

          if (line.startsWith('data: ')) {
            final data = line.substring(6);
            
            if (data.trim() == '[DONE]') {
              _controller?.add(SSEEvent(data: '[DONE]'));
              _controller?.close();
              return;
            }

            try {
              _controller?.add(SSEEvent(data: data));
            } catch (e) {
              // Skip malformed JSON
            }
          }
        }
      }

      if (!_isCancelled) {
        _controller?.close();
      }
    } catch (e) {
      if (!_isCancelled) {
        _controller?.addError(e);
        _controller?.close();
      }
    }
  }

  void cancel() {
    _isCancelled = true;
    _httpClient?.close();
    _controller?.close();
  }

  void dispose() {
    cancel();
    _controller = null;
  }
}
