import 'dart:convert';
import 'base_adapter.dart';
import '../../models/message.dart';

class ClaudeAdapter extends BaseAdapter {
  @override
  String get providerType => 'claude';

  @override
  String buildUrl(String baseUrl, String model) {
    return '$baseUrl/messages';
  }

  @override
  Map<String, String> buildHeaders(String apiKey, Map<String, String> extraHeaders) {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    };
    headers.addAll(extraHeaders);
    return headers;
  }

  @override
  String buildBody({
    required String model,
    required List<Message> messages,
    required String systemInstruction,
    double? temperature,
    int? maxTokens,
    bool stream = true,
  }) {
    final messagesList = <Map<String, String>>[];
    
    // Add messages (Claude doesn't use system in messages array)
    for (final msg in messages) {
      if (msg.role != MessageRole.system) {
        messagesList.add({'role': msg.role.name, 'content': msg.content});
      }
    }

    final body = <String, dynamic>{
      'model': model,
      'messages': messagesList,
      'max_tokens': maxTokens ?? 2000,
      'stream': stream,
    };

    // Add system instruction separately
    if (systemInstruction.isNotEmpty) {
      body['system'] = systemInstruction;
    }

    if (temperature != null) body['temperature'] = temperature;

    return jsonEncode(body);
  }

  @override
  StreamingResponse parseStreamEvent(String data) {
    try {
      final json = jsonDecode(data) as Map<String, dynamic>;
      final eventType = json['type'] as String;

      // Check for error
      if (eventType == 'error') {
        return StreamingResponse(
          error: json['error']['message'] ?? 'Unknown error',
        );
      }

      // Handle content block delta
      if (eventType == 'content_block_delta') {
        final delta = json['delta'] as Map<String, dynamic>;
        final content = delta['text'] as String?;
        return StreamingResponse(content: content);
      }

      // Handle message delta (with usage)
      if (eventType == 'message_delta') {
        final delta = json['delta'] as Map<String, dynamic>;
        final stopReason = delta['stop_reason'] as String?;
        
        final usage = json['usage'] as Map<String, dynamic>?;
        int? completionTokens;
        if (usage != null) {
          completionTokens = usage['output_tokens'] as int?;
        }

        if (stopReason == 'end_turn' || stopReason == 'max_tokens') {
          return StreamingResponse(
            isDone: true,
            completionTokens: completionTokens,
          );
        }
      }

      // Handle message start (with usage)
      if (eventType == 'message_start') {
        final message = json['message'] as Map<String, dynamic>;
        final usage = message['usage'] as Map<String, dynamic>?;
        int? promptTokens;
        if (usage != null) {
          promptTokens = usage['input_tokens'] as int?;
        }
        return StreamingResponse(promptTokens: promptTokens);
      }

      // Handle ping and other events
      return StreamingResponse();
    } catch (e) {
      return StreamingResponse(error: 'Failed to parse response: $e');
    }
  }

  @override
  CompleteResponse parseCompleteResponse(Map<String, dynamic> data) {
    final content = data['content'][0]['text'] as String;
    final usage = data['usage'] as Map<String, dynamic>;

    return CompleteResponse(
      content: content,
      promptTokens: usage['input_tokens'] as int,
      completionTokens: usage['output_tokens'] as int,
      totalTokens: (usage['input_tokens'] as int) + (usage['output_tokens'] as int),
    );
  }
}
