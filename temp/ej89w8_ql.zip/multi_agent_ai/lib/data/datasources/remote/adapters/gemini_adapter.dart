import 'dart:convert';
import 'base_adapter.dart';
import '../../models/message.dart';

class GeminiAdapter extends BaseAdapter {
  @override
  String get providerType => 'gemini';

  @override
  String buildUrl(String baseUrl, String model) {
    return '$baseUrl/models/$model:streamGenerateContent?alt=sse';
  }

  @override
  Map<String, String> buildHeaders(String apiKey, Map<String, String> extraHeaders) {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'x-goog-api-key': apiKey,
    };
    headers.addAll(extraHeaders);
    return headers;
  }

  @override
  String buildBody({
    required String model,
    required List<Message> messages,
    required String systemInstruction,
    double? temperature,
    int? maxTokens,
    bool stream = true,
  }) {
    final contents = <Map<String, dynamic>>[];
    
    // Convert messages to Gemini format
    for (final msg in messages) {
      final role = msg.role == MessageRole.user ? 'user' : 'model';
      contents.add({
        'role': role,
        'parts': [{'text': msg.content}],
      });
    }

    final body = <String, dynamic>{
      'contents': contents,
    };

    // Add system instruction if provided
    if (systemInstruction.isNotEmpty) {
      body['systemInstruction'] = {
        'parts': [{'text': systemInstruction}],
      };
    }

    // Add generation config
    final generationConfig = <String, dynamic>{};
    if (temperature != null) generationConfig['temperature'] = temperature;
    if (maxTokens != null) generationConfig['maxOutputTokens'] = maxTokens;
    if (generationConfig.isNotEmpty) {
      body['generationConfig'] = generationConfig;
    }

    return jsonEncode(body);
  }

  @override
  StreamingResponse parseStreamEvent(String data) {
    try {
      final json = jsonDecode(data) as Map<String, dynamic>;
      
      // Check for error
      if (json.containsKey('error')) {
        return StreamingResponse(
          error: json['error']['message'] ?? 'Unknown error',
        );
      }

      final candidates = json['candidates'] as List?;
      if (candidates == null || candidates.isEmpty) {
        return StreamingResponse(isDone: true);
      }

      final candidate = candidates[0] as Map<String, dynamic>;
      final content = candidate['content'] as Map<String, dynamic>?;
      final parts = content?['parts'] as List?;
      final finishReason = candidate['finishReason'] as String?;

      // Get content text
      String? text;
      if (parts != null && parts.isNotEmpty) {
        text = parts[0]['text'] as String?;
      }

      // Get usage metadata
      final usageMetadata = json['usageMetadata'] as Map<String, dynamic>?;
      int? promptTokens;
      int? completionTokens;
      int? totalTokens;

      if (usageMetadata != null) {
        promptTokens = usageMetadata['promptTokenCount'] as int?;
        completionTokens = usageMetadata['candidatesTokenCount'] as int?;
        totalTokens = usageMetadata['totalTokenCount'] as int?;
      }

      if (finishReason == 'STOP' || text == null) {
        return StreamingResponse(
          content: text,
          isDone: true,
          promptTokens: promptTokens,
          completionTokens: completionTokens,
          totalTokens: totalTokens,
        );
      }

      return StreamingResponse(
        content: text,
        promptTokens: promptTokens,
        completionTokens: completionTokens,
        totalTokens: totalTokens,
      );
    } catch (e) {
      return StreamingResponse(error: 'Failed to parse response: $e');
    }
  }

  @override
  CompleteResponse parseCompleteResponse(Map<String, dynamic> data) {
    final candidates = data['candidates'] as List;
    final content = candidates[0]['content']['parts'][0]['text'] as String;
    final usageMetadata = data['usageMetadata'] as Map<String, dynamic>;

    return CompleteResponse(
      content: content,
      promptTokens: usageMetadata['promptTokenCount'] as int,
      completionTokens: usageMetadata['candidatesTokenCount'] as int,
      totalTokens: usageMetadata['totalTokenCount'] as int,
    );
  }
}
