import 'dart:convert';
import 'base_adapter.dart';
import '../../models/message.dart';

class CustomAdapter extends BaseAdapter {
  @override
  String get providerType => 'custom';

  @override
  String buildUrl(String baseUrl, String model) {
    return '$baseUrl/chat/completions';
  }

  @override
  Map<String, String> buildHeaders(String apiKey, Map<String, String> extraHeaders) {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $apiKey',
    };
    headers.addAll(extraHeaders);
    return headers;
  }

  @override
  String buildBody({
    required String model,
    required List<Message> messages,
    required String systemInstruction,
    double? temperature,
    int? maxTokens,
    bool stream = true,
  }) {
    final messagesList = <Map<String, String>>[];
    
    if (systemInstruction.isNotEmpty) {
      messagesList.add({'role': 'system', 'content': systemInstruction});
    }
    
    for (final msg in messages) {
      messagesList.add({'role': msg.role.name, 'content': msg.content});
    }

    final body = <String, dynamic>{
      'model': model,
      'messages': messagesList,
      'stream': stream,
    };

    if (temperature != null) body['temperature'] = temperature;
    if (maxTokens != null) body['max_tokens'] = maxTokens;

    return jsonEncode(body);
  }

  @override
  StreamingResponse parseStreamEvent(String data) {
    try {
      final json = jsonDecode(data) as Map<String, dynamic>;
      
      if (json.containsKey('error')) {
        return StreamingResponse(
          error: json['error']['message'] ?? 'Unknown error',
        );
      }

      final choices = json['choices'] as List?;
      if (choices == null || choices.isEmpty) {
        return StreamingResponse(isDone: true);
      }

      final choice = choices[0] as Map<String, dynamic>;
      final delta = choice['delta'] as Map<String, dynamic>?;
      final finishReason = choice['finish_reason'] as String?;

      final content = delta?['content'] as String?;

      final usage = json['usage'] as Map<String, dynamic>?;
      int? promptTokens;
      int? completionTokens;
      int? totalTokens;

      if (usage != null) {
        promptTokens = usage['prompt_tokens'] as int?;
        completionTokens = usage['completion_tokens'] as int?;
        totalTokens = usage['total_tokens'] as int?;
      }

      if (finishReason == 'stop' || content == null && delta == null) {
        return StreamingResponse(
          content: content,
          isDone: true,
          promptTokens: promptTokens,
          completionTokens: completionTokens,
          totalTokens: totalTokens,
        );
      }

      return StreamingResponse(
        content: content,
        promptTokens: promptTokens,
        completionTokens: completionTokens,
        totalTokens: totalTokens,
      );
    } catch (e) {
      return StreamingResponse(error: 'Failed to parse response: $e');
    }
  }

  @override
  CompleteResponse parseCompleteResponse(Map<String, dynamic> data) {
    final choices = data['choices'] as List;
    final content = choices[0]['message']['content'] as String;
    final usage = data['usage'] as Map<String, dynamic>;

    return CompleteResponse(
      content: content,
      promptTokens: usage['prompt_tokens'] as int,
      completionTokens: usage['completion_tokens'] as int,
      totalTokens: usage['total_tokens'] as int,
    );
  }
}
