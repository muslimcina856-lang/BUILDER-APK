import 'openai_adapter.dart';

class MimoAdapter extends OpenAIAdapter {
  @override
  String get providerType => 'mimo';
}
