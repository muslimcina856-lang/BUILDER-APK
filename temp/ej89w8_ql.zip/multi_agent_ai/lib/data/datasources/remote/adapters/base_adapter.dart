import '../../models/message.dart';

abstract class BaseAdapter {
  String get providerType;
  
  // Build request URL
  String buildUrl(String baseUrl, String model);
  
  // Build request headers
  Map<String, String> buildHeaders(String apiKey, Map<String, String> extraHeaders);
  
  // Build request body
  String buildBody({
    required String model,
    required List<Message> messages,
    required String systemInstruction,
    double? temperature,
    int? maxTokens,
    bool stream = true,
  });
  
  // Parse streaming response
  StreamingResponse parseStreamEvent(String data);
  
  // Parse complete response (non-streaming)
  CompleteResponse parseCompleteResponse(Map<String, dynamic> data);
}

class StreamingResponse {
  final String? content;
  final bool isDone;
  final int? promptTokens;
  final int? completionTokens;
  final int? totalTokens;
  final String? error;

  StreamingResponse({
    this.content,
    this.isDone = false,
    this.promptTokens,
    this.completionTokens,
    this.totalTokens,
    this.error,
  });
}

class CompleteResponse {
  final String content;
  final int promptTokens;
  final int completionTokens;
  final int totalTokens;

  CompleteResponse({
    required this.content,
    required this.promptTokens,
    required this.completionTokens,
    required this.totalTokens,
  });
}
