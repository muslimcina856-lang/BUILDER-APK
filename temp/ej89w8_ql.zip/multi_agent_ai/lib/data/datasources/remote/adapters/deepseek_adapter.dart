import 'openai_adapter.dart';

class DeepSeekAdapter extends OpenAIAdapter {
  @override
  String get providerType => 'deepseek';
}
