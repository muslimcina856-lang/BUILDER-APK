import 'dart:async';
import 'adapters/base_adapter.dart';
import 'adapters/openai_adapter.dart';
import 'adapters/deepseek_adapter.dart';
import 'adapters/gemini_adapter.dart';
import 'adapters/claude_adapter.dart';
import 'adapters/mimo_adapter.dart';
import 'adapters/custom_adapter.dart';
import 'sse_client.dart';
import '../models/provider.dart';
import '../models/message.dart';

class ApiClient {
  final SSEClient _sseClient = SSEClient();
  
  BaseAdapter getAdapter(String adapterType) {
    switch (adapterType) {
      case 'deepseek':
        return DeepSeekAdapter();
      case 'openai':
        return OpenAIAdapter();
      case 'gemini':
        return GeminiAdapter();
      case 'claude':
        return ClaudeAdapter();
      case 'mimo':
        return MimoAdapter();
      case 'custom':
        return CustomAdapter();
      default:
        return OpenAIAdapter();
    }
  }

  Stream<StreamingResponse> sendMessage({
    required AiProvider provider,
    required String apiKey,
    required String model,
    required List<Message> messages,
    required String systemInstruction,
    double? temperature,
    int? maxTokens,
  }) {
    final adapter = getAdapter(provider.adapterType);
    
    final url = adapter.buildUrl(provider.baseUrl, model);
    final headers = adapter.buildHeaders(apiKey, provider.extraHeaders);
    final body = adapter.buildBody(
      model: model,
      messages: messages,
      systemInstruction: systemInstruction,
      temperature: temperature,
      maxTokens: maxTokens,
    );

    final stream = _sseClient.connect(
      url: url,
      headers: headers,
      body: body,
    );

    return stream.map((event) {
      if (event.isDone) {
        return StreamingResponse(isDone: true);
      }
      return adapter.parseStreamEvent(event.data);
    });
  }

  void cancel() {
    _sseClient.cancel();
  }

  void dispose() {
    _sseClient.dispose();
  }
}
