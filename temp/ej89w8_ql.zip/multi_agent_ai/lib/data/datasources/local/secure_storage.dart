import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageHelper {
  static final SecureStorageHelper _instance = SecureStorageHelper._internal();
  factory SecureStorageHelper() => _instance;
  SecureStorageHelper._internal();

  final _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device),
  );

  // API Keys
  Future<void> saveApiKey(String keyId, String apiKey) async {
    await _storage.write(key: 'api_key_$keyId', value: apiKey);
  }

  Future<String?> getApiKey(String keyId) async {
    return await _storage.read(key: 'api_key_$keyId');
  }

  Future<void> deleteApiKey(String keyId) async {
    await _storage.delete(key: 'api_key_$keyId');
  }

  // Global Instruction
  Future<void> saveGlobalInstruction(String instruction) async {
    await _storage.write(key: 'global_instruction', value: instruction);
  }

  Future<String?> getGlobalInstruction() async {
    return await _storage.read(key: 'global_instruction');
  }

  // Clear All
  Future<void> clearAll() async {
    await _storage.deleteAll();
  }
}
