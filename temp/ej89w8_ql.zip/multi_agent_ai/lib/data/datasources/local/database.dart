import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/provider.dart';
import '../models/api_key.dart';
import '../models/model.dart';
import '../models/chat.dart';
import '../models/message.dart';
import '../models/skill.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'multi_agent_ai.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // Create providers table
    await db.execute('''
      CREATE TABLE providers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        base_url TEXT NOT NULL,
        adapter_type TEXT NOT NULL,
        extra_headers TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT NOT NULL
      )
    ''');

    // Create api_keys table
    await db.execute('''
      CREATE TABLE api_keys (
        id TEXT PRIMARY KEY,
        provider_id TEXT NOT NULL,
        key TEXT NOT NULL,
        priority INTEGER NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_at TEXT NOT NULL,
        FOREIGN KEY (provider_id) REFERENCES providers (id) ON DELETE CASCADE
      )
    ''');

    // Create models table
    await db.execute('''
      CREATE TABLE models (
        id TEXT PRIMARY KEY,
        provider_id TEXT NOT NULL,
        name TEXT NOT NULL,
        is_default INTEGER DEFAULT 0,
        input_price_per_1k REAL DEFAULT 0.0,
        output_price_per_1k REAL DEFAULT 0.0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (provider_id) REFERENCES providers (id) ON DELETE CASCADE
      )
    ''');

    // Create skills table
    await db.execute('''
      CREATE TABLE skills (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    // Create chats table
    await db.execute('''
      CREATE TABLE chats (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        model_id TEXT NOT NULL,
        skill_id TEXT,
        instruction_override TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (model_id) REFERENCES models (id),
        FOREIGN KEY (skill_id) REFERENCES skills (id)
      )
    ''');

    // Create messages table
    await db.execute('''
      CREATE TABLE messages (
        id TEXT PRIMARY KEY,
        chat_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        prompt_tokens INTEGER,
        completion_tokens INTEGER,
        total_tokens INTEGER,
        estimated_cost REAL,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (chat_id) REFERENCES chats (id) ON DELETE CASCADE
      )
    ''');

    // Create indexes
    await db.execute('CREATE INDEX idx_messages_chat_id ON messages (chat_id)');
    await db.execute('CREATE INDEX idx_chats_model_id ON chats (model_id)');
    await db.execute('CREATE INDEX idx_api_keys_provider_id ON api_keys (provider_id)');
    await db.execute('CREATE INDEX idx_models_provider_id ON models (provider_id)');

    // Insert default skill creator
    final skillCreator = Skill.skillCreator;
    await db.insert('skills', skillCreator.toMap());
  }

  // ==================== PROVIDERS ====================

  Future<List<AiProvider>> getProviders() async {
    final db = await database;
    final maps = await db.query('providers', orderBy: 'created_at DESC');
    return maps.map((map) => AiProvider.fromMap(map)).toList();
  }

  Future<AiProvider?> getProvider(String id) async {
    final db = await database;
    final maps = await db.query('providers', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return AiProvider.fromMap(maps.first);
  }

  Future<void> insertProvider(AiProvider provider) async {
    final db = await database;
    await db.insert('providers', provider.toMap());
  }

  Future<void> updateProvider(AiProvider provider) async {
    final db = await database;
    await db.update(
      'providers',
      provider.toMap(),
      where: 'id = ?',
      whereArgs: [provider.id],
    );
  }

  Future<void> deleteProvider(String id) async {
    final db = await database;
    await db.delete('providers', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== API KEYS ====================

  Future<List<ApiKey>> getApiKeys(String providerId) async {
    final db = await database;
    final maps = await db.query(
      'api_keys',
      where: 'provider_id = ?',
      whereArgs: [providerId],
      orderBy: 'priority ASC',
    );
    return maps.map((map) => ApiKey.fromMap(map)).toList();
  }

  Future<void> insertApiKey(ApiKey apiKey) async {
    final db = await database;
    await db.insert('api_keys', apiKey.toMap());
  }

  Future<void> updateApiKey(ApiKey apiKey) async {
    final db = await database;
    await db.update(
      'api_keys',
      apiKey.toMap(),
      where: 'id = ?',
      whereArgs: [apiKey.id],
    );
  }

  Future<void> deleteApiKey(String id) async {
    final db = await database;
    await db.delete('api_keys', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== MODELS ====================

  Future<List<AiModel>> getModels(String providerId) async {
    final db = await database;
    final maps = await db.query(
      'models',
      where: 'provider_id = ?',
      whereArgs: [providerId],
      orderBy: 'name ASC',
    );
    return maps.map((map) => AiModel.fromMap(map)).toList();
  }

  Future<AiModel?> getModel(String id) async {
    final db = await database;
    final maps = await db.query('models', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return AiModel.fromMap(maps.first);
  }

  Future<void> insertModel(AiModel model) async {
    final db = await database;
    await db.insert('models', model.toMap());
  }

  Future<void> updateModel(AiModel model) async {
    final db = await database;
    await db.update(
      'models',
      model.toMap(),
      where: 'id = ?',
      whereArgs: [model.id],
    );
  }

  Future<void> deleteModel(String id) async {
    final db = await database;
    await db.delete('models', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== SKILLS ====================

  Future<List<Skill>> getSkills() async {
    final db = await database;
    final maps = await db.query('skills', orderBy: 'created_at DESC');
    return maps.map((map) => Skill.fromMap(map)).toList();
  }

  Future<Skill?> getSkill(String id) async {
    final db = await database;
    final maps = await db.query('skills', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Skill.fromMap(maps.first);
  }

  Future<void> insertSkill(Skill skill) async {
    final db = await database;
    await db.insert('skills', skill.toMap());
  }

  Future<void> updateSkill(Skill skill) async {
    final db = await database;
    await db.update(
      'skills',
      skill.toMap(),
      where: 'id = ?',
      whereArgs: [skill.id],
    );
  }

  Future<void> deleteSkill(String id) async {
    final db = await database;
    await db.delete('skills', where: 'id = ?', whereArgs: [id]);
  }

  // ==================== CHATS ====================

  Future<List<Chat>> getChats() async {
    final db = await database;
    final maps = await db.query('chats', orderBy: 'updated_at DESC');
    return maps.map((map) => Chat.fromMap(map)).toList();
  }

  Future<Chat?> getChat(String id) async {
    final db = await database;
    final maps = await db.query('chats', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Chat.fromMap(maps.first);
  }

  Future<void> insertChat(Chat chat) async {
    final db = await database;
    await db.insert('chats', chat.toMap());
  }

  Future<void> updateChat(Chat chat) async {
    final db = await database;
    await db.update(
      'chats',
      chat.toMap(),
      where: 'id = ?',
      whereArgs: [chat.id],
    );
  }

  Future<void> deleteChat(String id) async {
    final db = await database;
    await db.delete('chats', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Chat>> searchChats(String query) async {
    final db = await database;
    final maps = await db.rawQuery('''
      SELECT DISTINCT c.* FROM chats c
      LEFT JOIN messages m ON c.id = m.chat_id
      WHERE c.title LIKE ? OR m.content LIKE ?
      ORDER BY c.updated_at DESC
    ''', ['%$query%', '%$query%']);
    return maps.map((map) => Chat.fromMap(map)).toList();
  }

  // ==================== MESSAGES ====================

  Future<List<Message>> getMessages(String chatId) async {
    final db = await database;
    final maps = await db.query(
      'messages',
      where: 'chat_id = ?',
      whereArgs: [chatId],
      orderBy: 'timestamp ASC',
    );
    return maps.map((map) => Message.fromMap(map)).toList();
  }

  Future<void> insertMessage(Message message) async {
    final db = await database;
    await db.insert('messages', message.toMap());
  }

  Future<void> updateMessage(Message message) async {
    final db = await database;
    await db.update(
      'messages',
      message.toMap(),
      where: 'id = ?',
      whereArgs: [message.id],
    );
  }

  Future<void> deleteMessage(String id) async {
    final db = await database;
    await db.delete('messages', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteMessagesByChat(String chatId) async {
    final db = await database;
    await db.delete('messages', where: 'chat_id = ?', whereArgs: [chatId]);
  }

  // ==================== STATS ====================

  Future<Map<String, dynamic>> getStats() async {
    final db = await database;
    
    final chatCount = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM chats'),
    ) ?? 0;
    
    final messageCount = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM messages'),
    ) ?? 0;
    
    final totalTokens = Sqflite.firstIntValue(
      await db.rawQuery('SELECT SUM(total_tokens) FROM messages'),
    ) ?? 0;
    
    final totalCost = await db.rawQuery(
      'SELECT SUM(estimated_cost) as total FROM messages',
    );
    
    return {
      'chat_count': chatCount,
      'message_count': messageCount,
      'total_tokens': totalTokens,
      'total_cost': (totalCost.first['total'] as num?)?.toDouble() ?? 0.0,
    };
  }
}
