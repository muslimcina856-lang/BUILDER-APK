import 'package:flutter/material.dart';
import '../../data/repositories/provider_repository.dart';
import '../../data/models/provider.dart';
import '../../data/models/api_key.dart';
import '../../data/models/model.dart';

class ProviderPage extends StatefulWidget {
  const ProviderPage({super.key});

  @override
  State<ProviderPage> createState() => _ProviderPageState();
}

class _ProviderPageState extends State<ProviderPage> {
  final ProviderRepository _repository = ProviderRepository();
  List<AiProvider> _providers = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProviders();
  }

  Future<void> _loadProviders() async {
    setState(() => _isLoading = true);
    final providers = await _repository.getProviders();
    setState(() {
      _providers = providers;
      _isLoading = false;
    });
  }

  Future<void> _addProvider() async {
    final result = await showDialog<AiProvider>(
      context: context,
      builder: (context) => const _AddProviderDialog(),
    );

    if (result != null) {
      await _repository.addProvider(result);
      _loadProviders();
    }
  }

  Future<void> _deleteProvider(AiProvider provider) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Provider'),
        content: Text('Delete "${provider.name}" and all its keys?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _repository.deleteProvider(provider.id);
      _loadProviders();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Providers'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _providers.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.cloud_off,
                        size: 64,
                        color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                      ),
                      const SizedBox(height: 16),
                      const Text('No providers added'),
                      const SizedBox(height: 8),
                      ElevatedButton.icon(
                        onPressed: _addProvider,
                        icon: const Icon(Icons.add),
                        label: const Text('Add Provider'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _providers.length,
                  itemBuilder: (context, index) {
                    final provider = _providers[index];
                    return _ProviderListItem(
                      provider: provider,
                      repository: _repository,
                      onDelete: () => _deleteProvider(provider),
                      onRefresh: _loadProviders,
                    );
                  },
                ),
      floatingActionButton: _providers.isNotEmpty
          ? FloatingActionButton.extended(
              onPressed: _addProvider,
              icon: const Icon(Icons.add),
              label: const Text('Add Provider'),
            )
          : null,
    );
  }
}

class _ProviderListItem extends StatefulWidget {
  final AiProvider provider;
  final ProviderRepository repository;
  final VoidCallback onDelete;
  final VoidCallback onRefresh;

  const _ProviderListItem({
    required this.provider,
    required this.repository,
    required this.onDelete,
    required this.onRefresh,
  });

  @override
  State<_ProviderListItem> createState() => _ProviderListItemState();
}

class _ProviderListItemState extends State<_ProviderListItem> {
  List<ApiKey> _keys = [];
  List<AiModel> _models = [];
  bool _isExpanded = false;

  @override
  void initState() {
    super.initState();
    _loadDetails();
  }

  Future<void> _loadDetails() async {
    final keys = await widget.repository.getApiKeys(widget.provider.id);
    final models = await widget.repository.getModels(widget.provider.id);
    setState(() {
      _keys = keys;
      _models = models;
    });
  }

  Future<void> _addApiKey() async {
    final result = await showDialog<ApiKey>(
      context: context,
      builder: (context) => _AddApiKeyDialog(providerId: widget.provider.id),
    );

    if (result != null) {
      await widget.repository.addApiKey(result);
      _loadDetails();
    }
  }

  Future<void> _addModel() async {
    final result = await showDialog<AiModel>(
      context: context,
      builder: (context) => _AddModelDialog(providerId: widget.provider.id),
    );

    if (result != null) {
      await widget.repository.addModel(result);
      _loadDetails();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: ExpansionTile(
        leading: Icon(
          Icons.cloud,
          color: widget.provider.isActive
              ? Theme.of(context).colorScheme.primary
              : Colors.grey,
        ),
        title: Text(widget.provider.name),
        subtitle: Text(widget.provider.baseUrl),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Switch(
              value: widget.provider.isActive,
              onChanged: (value) async {
                await widget.repository.updateProvider(
                  widget.provider.copyWith(isActive: value),
                );
                widget.onRefresh();
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: widget.onDelete,
            ),
          ],
        ),
        onExpansionChanged: (expanded) {
          setState(() => _isExpanded = expanded);
        },
        children: [
          // API Keys section
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'API Keys',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    TextButton.icon(
                      onPressed: _addApiKey,
                      icon: const Icon(Icons.add, size: 16),
                      label: const Text('Add Key'),
                    ),
                  ],
                ),
                if (_keys.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text('No API keys added'),
                  )
                else
                  ..._keys.map((key) => ListTile(
                    leading: const Icon(Icons.key),
                    title: Text(key.key),
                    subtitle: Text('Priority: ${key.priority}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, size: 20),
                      onPressed: () async {
                        await widget.repository.deleteApiKey(key.id);
                        _loadDetails();
                      },
                    ),
                  )),
                
                const Divider(),
                
                // Models section
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Models',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    TextButton.icon(
                      onPressed: _addModel,
                      icon: const Icon(Icons.add, size: 16),
                      label: const Text('Add Model'),
                    ),
                  ],
                ),
                if (_models.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text('No models added'),
                  )
                else
                  ..._models.map((model) => ListTile(
                    leading: const Icon(Icons.smart_toy),
                    title: Text(model.name),
                    subtitle: Text(
                      'Input: \$${model.inputPricePer1k}/1k | Output: \$${model.outputPricePer1k}/1k',
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, size: 20),
                      onPressed: () async {
                        await widget.repository.deleteModel(model.id);
                        _loadDetails();
                      },
                    ),
                  )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AddProviderDialog extends StatefulWidget {
  const _AddProviderDialog();

  @override
  State<_AddProviderDialog> createState() => _AddProviderDialogState();
}

class _AddProviderDialogState extends State<_AddProviderDialog> {
  final _nameController = TextEditingController();
  final _urlController = TextEditingController();
  String _adapterType = 'openai';

  @override
  void dispose() {
    _nameController.dispose();
    _urlController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add Provider'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'Name',
              hintText: 'e.g., DeepSeek',
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _urlController,
            decoration: const InputDecoration(
              labelText: 'Base URL',
              hintText: 'e.g., https://api.deepseek.com/v1',
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _adapterType,
            decoration: const InputDecoration(labelText: 'Adapter Type'),
            items: const [
              DropdownMenuItem(value: 'openai', child: Text('OpenAI Compatible')),
              DropdownMenuItem(value: 'deepseek', child: Text('DeepSeek')),
              DropdownMenuItem(value: 'gemini', child: Text('Google Gemini')),
              DropdownMenuItem(value: 'claude', child: Text('Anthropic Claude')),
              DropdownMenuItem(value: 'mimo', child: Text('Mimo')),
              DropdownMenuItem(value: 'custom', child: Text('Custom')),
            ],
            onChanged: (value) {
              setState(() => _adapterType = value!);
            },
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_nameController.text.isNotEmpty && _urlController.text.isNotEmpty) {
              Navigator.pop(
                context,
                AiProvider(
                  name: _nameController.text,
                  baseUrl: _urlController.text,
                  adapterType: _adapterType,
                ),
              );
            }
          },
          child: const Text('Add'),
        ),
      ],
    );
  }
}

class _AddApiKeyDialog extends StatefulWidget {
  final String providerId;

  const _AddApiKeyDialog({required this.providerId});

  @override
  State<_AddApiKeyDialog> createState() => _AddApiKeyDialogState();
}

class _AddApiKeyDialogState extends State<_AddApiKeyDialog> {
  final _keyController = TextEditingController();
  final _priorityController = TextEditingController(text: '1');

  @override
  void dispose() {
    _keyController.dispose();
    _priorityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add API Key'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _keyController,
            decoration: const InputDecoration(
              labelText: 'API Key',
              hintText: 'sk-...',
            ),
            obscureText: true,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _priorityController,
            decoration: const InputDecoration(
              labelText: 'Priority',
              hintText: '1 = highest',
            ),
            keyboardType: TextInputType.number,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_keyController.text.isNotEmpty) {
              Navigator.pop(
                context,
                ApiKey(
                  providerId: widget.providerId,
                  key: _keyController.text,
                  priority: int.tryParse(_priorityController.text) ?? 1,
                ),
              );
            }
          },
          child: const Text('Add'),
        ),
      ],
    );
  }
}

class _AddModelDialog extends StatefulWidget {
  final String providerId;

  const _AddModelDialog({required this.providerId});

  @override
  State<_AddModelDialog> createState() => _AddModelDialogState();
}

class _AddModelDialogState extends State<_AddModelDialog> {
  final _nameController = TextEditingController();
  final _inputPriceController = TextEditingController(text: '0');
  final _outputPriceController = TextEditingController(text: '0');

  @override
  void dispose() {
    _nameController.dispose();
    _inputPriceController.dispose();
    _outputPriceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add Model'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'Model Name',
              hintText: 'e.g., deepseek-v4',
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _inputPriceController,
            decoration: const InputDecoration(
              labelText: 'Input Price (per 1k tokens)',
              hintText: '0.001',
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _outputPriceController,
            decoration: const InputDecoration(
              labelText: 'Output Price (per 1k tokens)',
              hintText: '0.002',
            ),
            keyboardType: TextInputType.number,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_nameController.text.isNotEmpty) {
              Navigator.pop(
                context,
                AiModel(
                  providerId: widget.providerId,
                  name: _nameController.text,
                  inputPricePer1k: double.tryParse(_inputPriceController.text) ?? 0,
                  outputPricePer1k: double.tryParse(_outputPriceController.text) ?? 0,
                ),
              );
            }
          },
          child: const Text('Add'),
        ),
      ],
    );
  }
}
