import 'package:flutter/material.dart';
import 'dart:async';
import '../../data/repositories/chat_repository.dart';
import '../../data/repositories/provider_repository.dart';
import '../../data/repositories/skill_repository.dart';
import '../../data/models/chat.dart';
import '../../data/models/message.dart';
import '../../data/models/provider.dart';
import '../../data/models/model.dart';
import '../../data/models/skill.dart';
import '../../data/datasources/remote/adapters/base_adapter.dart';
import '../../data/services/token_counter.dart';

class ChatDetailPage extends StatefulWidget {
  final String? chatId;

  const ChatDetailPage({super.key, this.chatId});

  @override
  State<ChatDetailPage> createState() => _ChatDetailPageState();
}

class _ChatDetailPageState extends State<ChatDetailPage> {
  final ChatRepository _chatRepository = ChatRepository();
  final ProviderRepository _providerRepository = ProviderRepository();
  final SkillRepository _skillRepository = SkillRepository();
  final TokenCounter _tokenCounter = TokenCounter();
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  Chat? _chat;
  List<Message> _messages = [];
  List<AiProvider> _providers = [];
  List<AiModel> _models = [];
  List<Skill> _skills = [];

  AiProvider? _selectedProvider;
  AiModel? _selectedModel;
  Skill? _selectedSkill;

  bool _isLoading = true;
  bool _isSending = false;
  String _streamingContent = '';
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _chatRepository.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    try {
      // Load providers
      _providers = await _providerRepository.getActiveProviders();

      // Load skills
      _skills = await _skillRepository.getSkills();

      // Load chat if editing
      if (widget.chatId != null) {
        _chat = await _chatRepository.getChat(widget.chatId!);
        _messages = await _chatRepository.getMessages(widget.chatId!);

        if (_chat != null) {
          _selectedProvider = _providers.where((p) => p.id == _chat!.id).firstOrNull;
          if (_selectedProvider != null) {
            _models = await _providerRepository.getModels(_selectedProvider!.id);
            _selectedModel = _models.where((m) => m.id == _chat!.modelId).firstOrNull;
          }
          if (_chat!.skillId != null) {
            _selectedSkill = _skills.where((s) => s.id == _chat!.skillId).firstOrNull;
          }
        }
      }

      // Select defaults if needed
      if (_selectedProvider == null && _providers.isNotEmpty) {
        _selectedProvider = _providers.first;
        _models = await _providerRepository.getModels(_selectedProvider!.id);
        if (_models.isNotEmpty) {
          _selectedModel = _models.first;
        }
      }

      setState(() => _isLoading = false);
    } catch (e) {
      setState(() {
        _isLoading = false;
        _error = e.toString();
      });
    }
  }

  Future<void> _sendMessage() async {
    final content = _messageController.text.trim();
    if (content.isEmpty || _isSending) return;

    if (_selectedProvider == null || _selectedModel == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a provider and model')),
      );
      return;
    }

    // Create chat if new
    if (_chat == null) {
      _chat = Chat(
        title: content.length > 50 ? '${content.substring(0, 50)}...' : content,
        modelId: _selectedModel!.id,
        skillId: _selectedSkill?.id,
      );
      await _chatRepository.createChat(_chat!);
    }

    // Add user message to UI
    final userMessage = Message(
      chatId: _chat!.id,
      role: MessageRole.user,
      content: content,
    );

    setState(() {
      _messages.add(userMessage);
      _isSending = true;
      _streamingContent = '';
      _error = null;
    });

    _messageController.clear();
    _scrollToBottom();

    // Send message with streaming
    final stream = _chatRepository.sendMessage(
      chat: _chat!,
      content: content,
      provider: _selectedProvider!,
      model: _selectedModel!,
    );

    stream.listen(
      (response) {
        if (response.error != null) {
          setState(() {
            _error = response.error;
            _isSending = false;
          });
        } else if (response.content != null) {
          setState(() {
            _streamingContent += response.content!;
          });
          _scrollToBottom();
        }

        if (response.isDone) {
          setState(() {
            _isSending = false;
            if (_streamingContent.isNotEmpty) {
              final assistantMessage = Message(
                chatId: _chat!.id,
                role: MessageRole.assistant,
                content: _streamingContent,
                promptTokens: response.promptTokens,
                completionTokens: response.completionTokens,
                totalTokens: response.totalTokens,
                estimatedCost: _tokenCounter.calculateCost(
                  promptTokens: response.promptTokens ?? 0,
                  completionTokens: response.completionTokens ?? 0,
                  inputPricePer1k: _selectedModel!.inputPricePer1k,
                  outputPricePer1k: _selectedModel!.outputPricePer1k,
                ),
              );
              _messages.add(assistantMessage);
              _streamingContent = '';
            }
          });
          _loadMessages();
        }
      },
      onError: (error) {
        setState(() {
          _error = error.toString();
          _isSending = false;
        });
      },
    );
  }

  Future<void> _loadMessages() async {
    if (_chat != null) {
      final messages = await _chatRepository.getMessages(_chat!.id);
      setState(() => _messages = messages);
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 100),
        curve: Curves.easeOut,
      );
    }
  }

  void _cancelRequest() {
    _chatRepository.cancelRequest();
    setState(() => _isSending = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_chat?.title ?? 'New Chat'),
        actions: [
          // Provider selector
          if (_providers.isNotEmpty)
            PopupMenuButton<AiProvider>(
              icon: const Icon(Icons.cloud),
              tooltip: 'Select Provider',
              onSelected: (provider) async {
                setState(() => _selectedProvider = provider);
                _models = await _providerRepository.getModels(provider.id);
                if (_models.isNotEmpty) {
                  setState(() => _selectedModel = _models.first);
                }
              },
              itemBuilder: (context) => _providers.map((p) {
                return PopupMenuItem(value: p, child: Text(p.name));
              }).toList(),
            ),
          
          // Model selector
          if (_models.isNotEmpty)
            PopupMenuButton<AiModel>(
              icon: const Icon(Icons.smart_toy),
              tooltip: 'Select Model',
              onSelected: (model) {
                setState(() => _selectedModel = model);
              },
              itemBuilder: (context) => _models.map((m) {
                return PopupMenuItem(value: m, child: Text(m.name));
              }).toList(),
            ),
          
          // Skill selector
          if (_skills.isNotEmpty)
            PopupMenuButton<Skill?>(
              icon: Icon(
                Icons.psychology,
                color: _selectedSkill != null
                    ? Theme.of(context).colorScheme.primary
                    : null,
              ),
              tooltip: 'Select Skill',
              onSelected: (skill) {
                setState(() => _selectedSkill = skill);
              },
              itemBuilder: (context) => [
                const PopupMenuItem(value: null, child: Text('No Skill')),
                ..._skills.map((s) {
                  return PopupMenuItem(value: s, child: Text(s.name));
                }),
              ],
            ),
        ],
      ),
      body: Column(
        children: [
          // Messages
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length + (_streamingContent.isNotEmpty ? 1 : 0) + (_error != null ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (index < _messages.length) {
                        return _MessageBubble(
                          message: _messages[index],
                          tokenCounter: _tokenCounter,
                        );
                      } else if (_streamingContent.isNotEmpty && index == _messages.length) {
                        return _StreamingBubble(content: _streamingContent);
                      } else {
                        return _ErrorBubble(
                          error: _error!,
                          onRetry: () {
                            setState(() => _error = null);
                          },
                        );
                      }
                    },
                  ),
          ),
          
          // Input
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              border: Border(
                top: BorderSide(
                  color: Theme.of(context).dividerColor,
                ),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    maxLines: null,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                const SizedBox(width: 8),
                _isSending
                    ? IconButton(
                        onPressed: _cancelRequest,
                        icon: const Icon(Icons.stop),
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                        ),
                      )
                    : IconButton(
                        onPressed: _sendMessage,
                        icon: const Icon(Icons.send),
                        style: IconButton.styleFrom(
                          backgroundColor: Theme.of(context).colorScheme.primary,
                          foregroundColor: Colors.white,
                        ),
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final Message message;
  final TokenCounter tokenCounter;

  const _MessageBubble({
    required this.message,
    required this.tokenCounter,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8,
        ),
        decoration: BoxDecoration(
          color: isUser
              ? Theme.of(context).colorScheme.primary
              : Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: isUser
              ? null
              : Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              message.content,
              style: TextStyle(
                color: isUser ? Colors.white : null,
              ),
            ),
            if (!isUser && message.totalTokens != null) ...[
              const SizedBox(height: 8),
              Text(
                tokenCounter.getTokenInfo(
                  promptTokens: message.promptTokens,
                  completionTokens: message.completionTokens,
                  totalTokens: message.totalTokens,
                  estimatedCost: message.estimatedCost,
                ),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: isUser ? Colors.white70 : null,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _StreamingBubble extends StatelessWidget {
  final String content;

  const _StreamingBubble({required this.content});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8,
        ),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(content),
            const SizedBox(height: 4),
            SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorBubble extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;

  const _ErrorBubble({
    required this.error,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.error.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Theme.of(context).colorScheme.error.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.error_outline,
            color: Theme.of(context).colorScheme.error,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              error,
              style: TextStyle(
                color: Theme.of(context).colorScheme.error,
              ),
            ),
          ),
          TextButton(
            onPressed: onRetry,
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }
}
