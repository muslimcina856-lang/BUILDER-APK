import 'package:flutter/material.dart';
import 'dart:convert';
import '../../data/repositories/provider_repository.dart';
import '../../data/repositories/skill_repository.dart';
import '../../data/repositories/chat_repository.dart';
import '../../data/datasources/local/secure_storage.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final ProviderRepository _providerRepository = ProviderRepository();
  final SkillRepository _skillRepository = SkillRepository();
  final ChatRepository _chatRepository = ChatRepository();
  final SecureStorageHelper _secureStorage = SecureStorageHelper();
  
  final TextEditingController _globalInstructionController = TextEditingController();
  
  Map<String, dynamic> _stats = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _globalInstructionController.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    setState(() => _isLoading = true);
    
    final instruction = await _secureStorage.getGlobalInstruction();
    _globalInstructionController.text = instruction ?? '';
    
    final stats = await _chatRepository.getStats();
    
    setState(() {
      _stats = stats;
      _isLoading = false;
    });
  }

  Future<void> _saveGlobalInstruction() async {
    await _secureStorage.saveGlobalInstruction(_globalInstructionController.text);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Global instruction saved')),
      );
    }
  }

  Future<void> _exportConfig() async {
    try {
      final providers = await _providerRepository.getProviders();
      final skills = await _skillRepository.getSkills();
      
      final config = {
        'providers': providers.map((p) => p.toMap()).toList(),
        'skills': skills.map((s) => s.toMap()).toList(),
        'global_instruction': _globalInstructionController.text,
      };
      
      final json = const JsonEncoder.withIndent('  ').convert(config);
      
      if (mounted) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Export Config'),
            content: SingleChildScrollView(
              child: SelectableText(json),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Close'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export failed: $e')),
        );
      }
    }
  }

  Future<void> _importConfig() async {
    // TODO: Implement file picker and import
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Import coming soon')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                // Stats Section
                _SectionHeader(title: 'Statistics'),
                _StatsCard(stats: _stats),
                
                // Navigation Section
                _SectionHeader(title: 'Manage'),
                _NavigationTile(
                  icon: Icons.cloud,
                  title: 'Providers',
                  subtitle: 'Manage AI providers and API keys',
                  onTap: () => Navigator.pushNamed(context, '/providers'),
                ),
                _NavigationTile(
                  icon: Icons.psychology,
                  title: 'Skills',
                  subtitle: 'Create and manage skills',
                  onTap: () => Navigator.pushNamed(context, '/skills'),
                ),
                
                // Global Instruction Section
                _SectionHeader(title: 'Global Instruction'),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(
                        controller: _globalInstructionController,
                        decoration: const InputDecoration(
                          hintText: 'Enter global instruction...',
                          alignLabelWithHint: true,
                        ),
                        maxLines: 5,
                        minLines: 3,
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _saveGlobalInstruction,
                          child: const Text('Save Instruction'),
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Import/Export Section
                _SectionHeader(title: 'Data'),
                _NavigationTile(
                  icon: Icons.upload,
                  title: 'Export Config',
                  subtitle: 'Export providers and skills',
                  onTap: _exportConfig,
                ),
                _NavigationTile(
                  icon: Icons.download,
                  title: 'Import Config',
                  subtitle: 'Import providers and skills',
                  onTap: _importConfig,
                ),
                
                // Danger Zone
                _SectionHeader(title: 'Danger Zone'),
                _NavigationTile(
                  icon: Icons.delete_forever,
                  title: 'Clear All Data',
                  subtitle: 'Delete all chats, providers, and skills',
                  iconColor: Colors.red,
                  onTap: () async {
                    final confirmed = await showDialog<bool>(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text('Clear All Data'),
                        content: const Text(
                          'This will permanently delete all your data. Are you sure?',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context, false),
                            child: const Text('Cancel'),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pop(context, true),
                            style: TextButton.styleFrom(
                              foregroundColor: Colors.red,
                            ),
                            child: const Text('Clear All'),
                          ),
                        ],
                      ),
                    );
                    
                    if (confirmed == true) {
                      await _secureStorage.clearAll();
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('All data cleared')),
                        );
                      }
                    }
                  },
                ),
                
                const SizedBox(height: 32),
                
                // About
                Center(
                  child: Text(
                    'Multi Agent AI v1.0.0',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;

  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title.toUpperCase(),
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
          fontWeight: FontWeight.bold,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
    );
  }
}

class _StatsCard extends StatelessWidget {
  final Map<String, dynamic> stats;

  const _StatsCard({required this.stats});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _StatItem(
              icon: Icons.chat,
              label: 'Chats',
              value: '${stats['chat_count'] ?? 0}',
            ),
            _StatItem(
              icon: Icons.message,
              label: 'Messages',
              value: '${stats['message_count'] ?? 0}',
            ),
            _StatItem(
              icon: Icons.token,
              label: 'Tokens',
              value: _formatNumber(stats['total_tokens'] ?? 0),
            ),
            _StatItem(
              icon: Icons.attach_money,
              label: 'Cost',
              value: '\$${(stats['total_cost'] ?? 0.0).toStringAsFixed(2)}',
            ),
          ],
        ),
      ),
    );
  }

  String _formatNumber(int number) {
    if (number >= 1000000) {
      return '${(number / 1000000).toStringAsFixed(1)}M';
    } else if (number >= 1000) {
      return '${(number / 1000).toStringAsFixed(1)}K';
    }
    return '$number';
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _StatItem({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 4),
        Text(
          value,
          style: Theme.of(context).textTheme.titleLarge,
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}

class _NavigationTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color? iconColor;
  final VoidCallback onTap;

  const _NavigationTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.iconColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: iconColor),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
}
