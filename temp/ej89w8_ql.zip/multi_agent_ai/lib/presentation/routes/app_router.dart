import 'package:flutter/material.dart';
import '../presentation/pages/chat_list_page.dart';
import '../presentation/pages/chat_detail_page.dart';
import '../presentation/pages/provider_page.dart';
import '../presentation/pages/skill_page.dart';
import '../presentation/pages/settings_page.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const ChatListPage());
      
      case '/chat':
        final chatId = settings.arguments as String?;
        return MaterialPageRoute(
          builder: (_) => ChatDetailPage(chatId: chatId),
        );
      
      case '/providers':
        return MaterialPageRoute(builder: (_) => const ProviderPage());
      
      case '/skills':
        return MaterialPageRoute(builder: (_) => const SkillPage());
      
      case '/settings':
        return MaterialPageRoute(builder: (_) => const SettingsPage());
      
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text('No route defined for ${settings.name}'),
            ),
          ),
        );
    }
  }
}
