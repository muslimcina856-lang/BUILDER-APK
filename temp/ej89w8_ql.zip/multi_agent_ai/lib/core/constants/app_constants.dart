import 'package:flutter/material.dart';

class AppConstants {
  // App Info
  static const String appName = 'Multi Agent AI';
  static const String appVersion = '1.0.0';
  
  // Database
  static const String dbName = 'multi_agent_ai.db';
  static const int dbVersion = 1;
  
  // Secure Storage Keys
  static const String apiKeyPrefix = 'api_key_';
  static const String globalInstructionKey = 'global_instruction';
  
  // Default Values
  static const String defaultTemperature = '0.7';
  static const String defaultMaxTokens = '2000';
  
  // Shell Commands
  static const String shellPrefix = '!shell ';
  static const String readPrefix = '!read ';
  static const String writePrefix = '!write ';
  
  // Dangerous Commands (require confirmation)
  static const List<String> dangerousCommands = [
    'rm -rf',
    'rm -r',
    'sudo',
    'chmod 777',
    'dd if=',
    'mkfs',
    ':(){:|:&};:',
  ];
  
  // Provider Adapter Types
  static const String adapterDeepseek = 'deepseek';
  static const String adapterOpenai = 'openai';
  static const String adapterGemini = 'gemini';
  static const String adapterClaude = 'claude';
  static const String adapterMimo = 'mimo';
  static const String adapterCustom = 'custom';
  
  // API Status Codes
  static const int statusUnauthorized = 401;
  static const int statusRateLimited = 429;
  static const int statusServerError = 500;
  
  // SSE Events
  static const String sseDataPrefix = 'data: ';
  static const String sseDone = '[DONE]';
}
