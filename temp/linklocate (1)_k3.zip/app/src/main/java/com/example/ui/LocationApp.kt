package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.TrackedPoint
import com.example.data.TrackingSession
import com.example.viewmodel.LocationViewModel
import com.example.viewmodel.UiState
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun LocationApp(viewModel: LocationViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    // Handles detail view of received points for a specific session topic
    var activeDetailSession by remember { mutableStateOf<TrackingSession?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val allPoints by viewModel.allPoints.collectAsStateWithLifecycle()
    val createSessionState by viewModel.createSessionState.collectAsStateWithLifecycle()

    // Location Permission for tracking ourselves
    val locationPermissionState = rememberPermissionState(
        android.Manifest.permission.ACCESS_FINE_LOCATION
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Logo Launcher",
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Lacak Lokasi",
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                ),
                actions = {
                    if (selectedTab == 0 && activeDetailSession == null) {
                        IconButton(
                            onClick = { showCreateDialog = true },
                            modifier = Modifier.testTag("add_session_bar_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Buat Link Tracker")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (activeDetailSession == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        label = { Text("Lacak Teman") },
                        icon = { Icon(Icons.Default.Share, contentDescription = "Tab Lacak Teman") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        label = { Text("Lacak Mantap") }, // Or "Lacak Saya"
                        icon = { Icon(Icons.Default.Person, contentDescription = "Tab Lacak Saya") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        label = { Text("Log Semua") },
                        icon = { Icon(Icons.Default.List, contentDescription = "Tab Log") }
                    )
                }
            }
        },
        floatingActionButton = {
            if (selectedTab == 0 && activeDetailSession == null) {
                ExtendedFloatingActionButton(
                    onClick = { showCreateDialog = true },
                    modifier = Modifier.testTag("create_link_fab"),
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Buat Link")
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Check if detail screen for a specific friend session is active
            activeDetailSession?.let { currentSession ->
                FriendDetailScreen(
                    session = currentSession,
                    viewModel = viewModel,
                    points = allPoints.filter { it.sessionId == currentSession.topicId },
                    onBack = { activeDetailSession = null }
                )
            } ?: run {
                // Otherwise show standard tab content
                when (selectedTab) {
                    0 -> TrackFriendsScreen(
                        sessions = sessions,
                        viewModel = viewModel,
                        currentPoints = allPoints,
                        onViewSessionDetails = { activeDetailSession = it }
                    )
                    1 -> TrackSelfScreen(
                        viewModel = viewModel,
                        isPermissionGranted = locationPermissionState.status.isGranted,
                        onReqPermission = { locationPermissionState.launchPermissionRequest() }
                    )
                    2 -> ReceivedCoordinatesLogs(
                        points = allPoints.filter { it.sessionId != "self" },
                        sessions = sessions
                    )
                }
            }
        }

        // Generate link Dialog Screen
        if (showCreateDialog) {
            var friendName by remember { mutableStateOf("") }

            Dialog(onDismissRequest = {
                showCreateDialog = false
                viewModel.resetCreateState()
            }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(24.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Buat Link Tracker",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "Masukkan nama teman untuk mengidentifikasi siapa yang membuka link pembagi lokasi Anda.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = friendName,
                            onValueChange = { friendName = it },
                            label = { Text("Nama Teman (cth: Budi)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("friend_name_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        when (val state = createSessionState) {
                            is UiState.Loading -> {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                Text("Mempersiapkan link Base64 & Enkripsi...", style = MaterialTheme.typography.bodySmall)
                            }
                            is UiState.Success -> {
                                val createdSession = state.data
                                Text(
                                    text = "Sukses dibuat!",
                                    color = Color(0xFF10B981),
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedTextField(
                                    value = createdSession.shortUrl,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Link Pendek (is.gd)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MaterialTheme.colorScheme.primary
                                    )
                                )

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Button(
                                        onClick = {
                                            copyToClipboard(context, createdSession.shortUrl)
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Salin")
                                    }

                                    Button(
                                        onClick = {
                                            shareText(context, "Bantu bagikan lokasimu di sini agar bisa saling melacak: ${createdSession.shortUrl}")
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Bagikan")
                                    }
                                }
                            }
                            is UiState.Error -> {
                                Text(
                                    text = "Gagal: ${state.message}",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            UiState.Idle -> { /* Nothing needed */ }
                        }

                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TextButton(onClick = {
                                showCreateDialog = false
                                viewModel.resetCreateState()
                            }) {
                                Text("Selesai")
                            }
                            if (createSessionState is UiState.Idle) {
                                Button(
                                    onClick = { viewModel.generateLink(friendName) },
                                    modifier = Modifier.testTag("dialog_create_button")
                                ) {
                                    Text("Simpan")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun Modifier.sizeModifier() = this.size(16.dp)

// -------------------------------------------------------------
// TRACK FRIENDS TAB SCREEN
// -------------------------------------------------------------
@Composable
fun TrackFriendsScreen(
    sessions: List<TrackingSession>,
    viewModel: LocationViewModel,
    currentPoints: List<TrackedPoint>,
    onViewSessionDetails: (TrackingSession) -> Unit
) {
    if (sessions.isEmpty()) {
        EmptyStateView(
            title = "Belum Ada Link Tracker",
            subtitle = "Ketuk tombol 'Buat Link' di kanan bawah untuk membuat tracker baru. Bagikan link tersebut ke teman Anda, dan lokasi mereka akan otomatis terpantau real-time di sini!",
            icon = Icons.Default.Share
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Daftar Tracking Teman",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            items(sessions) { session ->
                val statsPoints = currentPoints.filter { it.sessionId == session.topicId }
                val pollingStates by viewModel.pollingStates.collectAsStateWithLifecycle()
                val isPolling = pollingStates[session.topicId] ?: false

                // Auto-start polling for each registered session to keep live updates working cleanly
                LaunchedEffect(session.topicId) {
                    viewModel.startPolling(session.topicId)
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onViewSessionDetails(session) },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = session.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "ID: ${session.topicId}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                            
                            // Active status blinker Badge
                            Surface(
                                shape = RoundedCornerShape(100.dp),
                                color = if (isPolling) Color(0xFFE6F4EA) else MaterialTheme.colorScheme.errorContainer,
                                border = if (isPolling) null else CardDefaults.outlinedCardBorder()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(RoundedCornerShape(100.dp))
                                            .background(if (isPolling) Color(0xFF10B981) else Color(0xFFEF4444))
                                    )
                                    Text(
                                        text = if (isPolling) "Berjalan" else "Mati",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isPolling) Color(0xFF137333) else MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Lokasi Diterima: ${statsPoints.size} Titik",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (statsPoints.isNotEmpty()) {
                                val lastUpdate = statsPoints.maxBy { it.timestamp }
                                Text(
                                    text = "Terakhir: " + formatTime(lastUpdate.timestamp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }
                        }

                        // Options buttons
                        val context = LocalContext.current
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = { onViewSessionDetails(session) },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Detail GPS/IP", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { shareText(context, "Bantu share lokasimu di link ini ya: ${session.shortUrl}") },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Kirim Link", fontSize = 12.sp)
                            }

                            IconButton(
                                onClick = { viewModel.deleteSession(session) },
                                colors = IconButtonDefaults.iconButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Hapus Session")
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// FRIEND DETAILED POINTS SCREEN
// -------------------------------------------------------------
@Composable
fun FriendDetailScreen(
    session: TrackingSession,
    viewModel: LocationViewModel,
    points: List<TrackedPoint>,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var isRefreshing by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Kembali")
                }
                Column {
                    Text(
                        text = session.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ID: ${session.topicId}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        isRefreshing = true
                        viewModel.forceRefreshSession(session.topicId)
                        Toast.makeText(context, "Memperbarui data dari satelit dan cloud...", Toast.LENGTH_SHORT).show()
                        isRefreshing = false
                    }
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Tautan Pembagian:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = session.shortUrl,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(onClick = { copyToClipboard(context, session.shortUrl) }) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Salin Link")
                    }
                    TextButton(onClick = { shareText(context, "Kirim link pelacak lokasi real-time: ${session.shortUrl}") }) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bagikan")
                    }
                }
            }
        }

        if (points.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.outline)
                    Text(
                        text = "Sesi Aktif. Menunggu teman membuka link...",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Ketika teman Anda mengklik link, lokasi mereka (IP pertama kali, dilanjutkan presisi GPS) akan otomatis terunggah.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "Riwayat Kunjungan & Lokasi (${points.size} Data)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(points) { pt ->
                    PointCardView(point = pt, showTitle = false)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// TRACK SELF TAB SCREEN
// -------------------------------------------------------------
@Composable
fun TrackSelfScreen(
    viewModel: LocationViewModel,
    isPermissionGranted: Boolean,
    onReqPermission: () -> Unit
) {
    val context = LocalContext.current
    val selfState by viewModel.selfLocationState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = {}, colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Icon(Icons.Default.LocationOn, contentDescription = null)
                }

                Text(
                    text = "Lacak Koordinatku",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Lacak koordinat lokasi Android-mu dengan sistem GPS internal atau lacak lokasi jaringan via Alamat IP.",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Mode Lacak Saya",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (isPermissionGranted) {
                                viewModel.trackSelfByGPS(context)
                            } else {
                                onReqPermission()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("GPS Sinyal", fontSize = 12.sp)
                    }

                    Button(
                        onClick = { viewModel.trackSelfByIP() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Jaringan IP", fontSize = 12.sp)
                    }
                }

                if (!isPermissionGranted) {
                    TextButton(
                        onClick = onReqPermission,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("⚠️ Izin lokasi belum aktif. Hubungkan GPS", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        // Output Display Box
        when (val state = selfState) {
            is UiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxWidth().height(150.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator()
                        Text("Sedang membaca satelit GPS/Provider IP...", fontSize = 11.sp)
                    }
                }
            }
            is UiState.Success -> {
                val pt = state.data
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Lokasi Saat Ini Terdeteksi",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )

                    PointCardView(point = pt, showTitle = true)
                }
            }
            is UiState.Error -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Text(
                        text = "Error: ${state.message}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(16.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
            UiState.Idle -> { /* Idle */ }
        }
    }
}

// -------------------------------------------------------------
// LOG ALL RECEIVED COORDINATES TAB SCREEN
// -------------------------------------------------------------
@Composable
fun ReceivedCoordinatesLogs(points: List<TrackedPoint>, sessions: List<TrackingSession>) {
    if (points.isEmpty()) {
        EmptyStateView(
            title = "Belum Ada Koordinat Masuk",
            subtitle = "Saling bagikan link pelacak ke teman Anda. Begitu mereka mengetuk link pembagi, log lintasan perjalanan IP & GPS mereka akan otomatis terdaftar dan diarsipkan di halaman riwayat ini.",
            icon = Icons.Default.List
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "Riwayat Koordinat Lapangan",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            items(points) { pt ->
                val associatedSession = sessions.find { it.topicId == pt.sessionId }
                val captionForPoint = associatedSession?.title ?: "Sesi: ${pt.sessionId}"
                PointCardView(point = pt, customTitle = captionForPoint)
            }
        }
    }
}

// -------------------------------------------------------------
// DYNAMIC HELPER COMPONENTS
// -------------------------------------------------------------
@Composable
fun PointCardView(
    point: TrackedPoint,
    showTitle: Boolean = false,
    customTitle: String? = null
) {
    val context = LocalContext.current
    val titleText = customTitle ?: (if (showTitle) "Pelacakan ${point.type}" else null)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                titleText?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Type Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (point.type.contains("GPS")) Color(0xFFE8F0FE) else Color(0xFFFEF7E0)
                ) {
                    Text(
                        text = point.type,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (point.type.contains("GPS")) Color(0xFF1967D2) else Color(0xFFB06000),
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = formatTime(point.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }

            Text(
                text = "Koordinat: ${point.latitude}, ${point.longitude}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )

            if (point.ip.isNotEmpty() && point.ip != "Unknown") {
                Text(
                    text = "IP: ${point.ip}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (point.type.contains("IP") && point.city.isNotEmpty()) {
                Text(
                    text = "Lokasi: ${point.city}, ${point.region}, ${point.country}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
            } else if (point.type.contains("GPS")) {
                Text(
                    text = "Akurasi GPS: %1.1fm".format(point.accuracy),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = {
                    openGoogleMaps(context, point.latitude, point.longitude, titleText ?: "Ditemukan")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Buka di Google Maps")
            }
        }
    }
}

@Composable
fun EmptyStateView(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                shape = RoundedCornerShape(100.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 22.sp
            )
        }
    }
}

// -------------------------------------------------------------
// INLINE INTENTS UTILITIES
// -------------------------------------------------------------
fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Shortened tracking url", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Link disalin ke papan klip!", Toast.LENGTH_SHORT).show()
}

fun shareText(context: Context, text: String) {
    val sendIntent: Intent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, text)
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Bagikan Link")
    context.startActivity(shareIntent)
}

fun openGoogleMaps(context: Context, latitude: Double, longitude: Double, label: String) {
    val labelEncoded = Uri.encode(label)
    val uri = "geo:$latitude,$longitude?q=$latitude,$longitude($labelEncoded)"
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
        setPackage("com.google.android.apps.maps")
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback to web link if maps app is missing on device
        val webUri = "https://www.google.com/maps/search/?api=1&query=$latitude,$longitude"
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUri))
        context.startActivity(webIntent)
    }
}

fun formatTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
