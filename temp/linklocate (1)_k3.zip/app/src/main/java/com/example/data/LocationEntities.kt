package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "tracking_sessions")
data class TrackingSession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val topicId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val shortUrl: String = ""
) : Serializable

@Entity(tableName = "tracked_points")
data class TrackedPoint(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sessionId: String, // links to TrackingSession.topicId
    val latitude: Double,
    val longitude: Double,
    val accuracy: Double = 0.0,
    val ip: String = "",
    val type: String = "GPS", // "GPS" or "IP"
    val city: String = "",
    val region: String = "",
    val country: String = "",
    val timestamp: Long = System.currentTimeMillis()
) : Serializable
