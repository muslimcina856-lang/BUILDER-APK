package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.data.LocationDatabase
import com.example.data.LocationRepository
import com.example.ui.LocationApp
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.LocationViewModel

class MainActivity : ComponentActivity() {
    private val db by lazy { LocationDatabase.getDatabase(applicationContext) }
    private val repository by lazy { LocationRepository(db.dao) }
    
    private val viewModel: LocationViewModel by viewModels {
        LocationViewModel.Factory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                LocationApp(viewModel = viewModel)
            }
        }
    }
}
