package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LocationDao {
    @Query("SELECT * FROM tracking_sessions ORDER BY createdAt DESC")
    fun getAllSessions(): Flow<List<TrackingSession>>

    @Query("SELECT * FROM tracking_sessions WHERE topicId = :topicId LIMIT 1")
    suspend fun getSessionByTopicId(topicId: String): TrackingSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: TrackingSession): Long

    @Update
    suspend fun updateSession(session: TrackingSession)

    @Delete
    suspend fun deleteSession(session: TrackingSession)

    @Query("SELECT * FROM tracked_points WHERE sessionId = :sessionId ORDER BY timestamp DESC")
    fun getPointsForSession(sessionId: String): Flow<List<TrackedPoint>>

    @Query("SELECT * FROM tracked_points ORDER BY timestamp DESC")
    fun getAllPoints(): Flow<List<TrackedPoint>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPoint(point: TrackedPoint): Long

    @Query("DELETE FROM tracked_points WHERE sessionId = :sessionId")
    suspend fun deletePointsForSession(sessionId: String)
}
