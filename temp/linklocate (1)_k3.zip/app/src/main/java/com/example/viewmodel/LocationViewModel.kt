package com.example.viewmodel

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.LocationRepository
import com.example.data.TrackedPoint
import com.example.data.TrackingSession
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    object Idle : UiState<Nothing>
    object Loading : UiState<Nothing>
    data class Success<out T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

class LocationViewModel(private val repository: LocationRepository) : ViewModel() {

    private val _createSessionState = MutableStateFlow<UiState<TrackingSession>>(UiState.Idle)
    val createSessionState: StateFlow<UiState<TrackingSession>> = _createSessionState.asStateFlow()

    private val _selfLocationState = MutableStateFlow<UiState<TrackedPoint>>(UiState.Idle)
    val selfLocationState: StateFlow<UiState<TrackedPoint>> = _selfLocationState.asStateFlow()

    private val _pollingStates = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val pollingStates: StateFlow<Map<String, Boolean>> = _pollingStates.asStateFlow()

    val sessions: StateFlow<List<TrackingSession>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPoints: StateFlow<List<TrackedPoint>> = repository.allPoints
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun resetCreateState() {
        _createSessionState.value = UiState.Idle
    }

    /**
     * Generates a tracker web link Session
     */
    fun generateLink(title: String) {
        viewModelScope.launch {
            _createSessionState.value = UiState.Loading
            try {
                if (title.isBlank()) {
                    _createSessionState.value = UiState.Error("Judul tidak boleh kosong!")
                    return@launch
                }
                val newSession = repository.createTrackingSession(title)
                _createSessionState.value = UiState.Success(newSession)
                
                // Automatically start polling for this new session
                startPolling(newSession.topicId)
            } catch (e: Exception) {
                _createSessionState.value = UiState.Error(e.localizedMessage ?: "Gagal membuat tautan")
            }
        }
    }

    /**
     * Deletes a session and its tracked locations
     */
    fun deleteSession(session: TrackingSession) {
        viewModelScope.launch {
            stopPolling(session.topicId)
            repository.deleteSession(session)
        }
    }

    /**
     * Polling mechanism to check if our friend has accessed the link
     * and posted location details. We do a periodic poll every 5 seconds.
     */
    fun startPolling(topicId: String) {
        val currentMap = _pollingStates.value.toMutableMap()
        if (currentMap[topicId] == true) return // already polling

        currentMap[topicId] = true
        _pollingStates.value = currentMap

        viewModelScope.launch(Dispatchers.IO) {
            while (_pollingStates.value[topicId] == true) {
                try {
                    Log.d("LocationViewModel", "Polling points for topic: $topicId")
                    repository.refreshSessionPoints(topicId)
                } catch (e: Exception) {
                    Log.e("LocationViewModel", "Error polling points for $topicId", e)
                }
                delay(5000) // Poll every 5 seconds
            }
        }
    }

    fun stopPolling(topicId: String) {
        val currentMap = _pollingStates.value.toMutableMap()
        currentMap[topicId] = false
        _pollingStates.value = currentMap
    }

    fun forceRefreshSession(topicId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.refreshSessionPoints(topicId)
            } catch (e: Exception) {
                Log.e("LocationViewModel", "Force refresh failed for $topicId", e)
            }
        }
    }

    /**
     * Obtains user's own location using IP Geolocation
     */
    fun trackSelfByIP() {
        viewModelScope.launch {
            _selfLocationState.value = UiState.Loading
            try {
                val point = repository.trackSelfIP()
                if (point != null) {
                    _selfLocationState.value = UiState.Success(point)
                } else {
                    _selfLocationState.value = UiState.Error("Gagal mengambil data IP Geolocation.")
                }
            } catch (e: Exception) {
                _selfLocationState.value = UiState.Error(e.localizedMessage ?: "Gagal melacak IP")
            }
        }
    }

    /**
     * Obtains user's own location using GPS Fine Location Service
     */
    @SuppressLint("MissingPermission")
    fun trackSelfByGPS(context: Context) {
        _selfLocationState.value = UiState.Loading
        try {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            fusedLocationClient.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                null
            ).addOnSuccessListener { location: Location? ->
                if (location != null) {
                    val gpPoint = TrackedPoint(
                        sessionId = "self",
                        latitude = location.latitude,
                        longitude = location.longitude,
                        accuracy = location.accuracy.toDouble(),
                        type = "GPS",
                        timestamp = System.currentTimeMillis()
                    )
                    viewModelScope.launch {
                        repository.saveSelfPoint(gpPoint)
                        _selfLocationState.value = UiState.Success(gpPoint)
                    }
                } else {
                    // Try getting last known location as fallback
                    fusedLocationClient.lastLocation.addOnSuccessListener { lastLoc: Location? ->
                        if (lastLoc != null) {
                            val gpPoint = TrackedPoint(
                                sessionId = "self",
                                latitude = lastLoc.latitude,
                                longitude = lastLoc.longitude,
                                accuracy = lastLoc.accuracy.toDouble(),
                                type = "GPS (Last)",
                                timestamp = System.currentTimeMillis()
                            )
                            viewModelScope.launch {
                                repository.saveSelfPoint(gpPoint)
                                _selfLocationState.value = UiState.Success(gpPoint)
                            }
                        } else {
                            _selfLocationState.value = UiState.Error("GPS tidak memberikan koordinat. Cobalah IP atau aktifkan GPS Anda.")
                        }
                    }.addOnFailureListener {
                        _selfLocationState.value = UiState.Error("Gagal mendapatkan lokasi GPS: ${it.localizedMessage}")
                    }
                }
            }.addOnFailureListener {
                _selfLocationState.value = UiState.Error("Koneksi GPS bermasalah: ${it.localizedMessage}")
            }
        } catch (e: Exception) {
            _selfLocationState.value = UiState.Error("Izin lokasi belum diberikan atau GPS mati.")
        }
    }

    class Factory(private val repository: LocationRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LocationViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return LocationViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
