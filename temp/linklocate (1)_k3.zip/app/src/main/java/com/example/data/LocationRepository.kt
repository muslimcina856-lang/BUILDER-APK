package com.example.data

import android.util.Base64
import android.util.Log
import com.example.network.LocationNetworkService
import kotlinx.coroutines.flow.Flow
import java.nio.charset.StandardCharsets

class LocationRepository(private val dao: LocationDao) {

    val allSessions: Flow<List<TrackingSession>> = dao.getAllSessions()
    val allPoints: Flow<List<TrackedPoint>> = dao.getAllPoints()

    fun getPointsForSession(sessionId: String): Flow<List<TrackedPoint>> {
        return dao.getPointsForSession(sessionId)
    }

    suspend fun getSessionByTopicId(topicId: String): TrackingSession? {
        return dao.getSessionByTopicId(topicId)
    }

    /**
     * Creates a new tracking session.
     * Generates a unique topic ID, embeds it inside our minimal tracker HTML page,
     * encodes the HTML code as a base64 Data URI, and shortens it via is.gd API.
     */
    suspend fun createTrackingSession(title: String): TrackingSession {
        // Generate random 6 characters topic id
        val randomStr = java.util.UUID.randomUUID().toString().substring(0, 6).lowercase()
        val topicId = "loc_track_$randomStr"

        // Inject topic ID into our customized tracking page
        val filledHtml = HTML_TEMPLATE.replace("TOPIC_ID", topicId)

        // Convert page string to UTF-8 Base64 data URI
        val base64Html = Base64.encodeToString(
            filledHtml.toByteArray(StandardCharsets.UTF_8),
            Base64.NO_PADDING or Base64.NO_WRAP
        )
        val dataUri = "data:text/html;base64,$base64Html"

        // Shorten the url to a compact shareable link
        Log.d("LocationRepository", "Shortening link of length: ${dataUri.length}")
        var shortUrl = LocationNetworkService.shortenUrl(dataUri) ?: ""
        if (shortUrl.isEmpty()) {
            // fallback if is.gd is unavailable or hits a sizing error
            // (e.g. is.gd might refuse sometimes, we can also give them a standard web direct link or copy details)
            shortUrl = "https://is.gd/create.php?url=" + Base64.encodeToString(
                filledHtml.toByteArray(StandardCharsets.UTF_8),
                Base64.NO_PADDING or Base64.NO_WRAP
            ).substring(0, 50) + " (Error: Gunakan Raw Link)"
        }

        val session = TrackingSession(
            title = title,
            topicId = topicId,
            shortUrl = shortUrl
        )

        dao.insertSession(session)
        return session
    }

    suspend fun deleteSession(session: TrackingSession) {
        dao.deleteSession(session)
        dao.deletePointsForSession(session.topicId)
    }

    suspend fun refreshSessionPoints(topicId: String): Int {
        val remotePoints = LocationNetworkService.pollTrackedPoints(topicId)
        var addedCount = 0
        for (pt in remotePoints) {
            val insertedId = dao.insertPoint(pt)
            if (insertedId > 0) {
                addedCount++
            }
        }
        return addedCount
    }

    suspend fun trackSelfIP(): TrackedPoint? {
        val selfIPPoint = LocationNetworkService.getIpGeolocation()
        if (selfIPPoint != null) {
            // Also store it inside the DB under 'self' session
            dao.insertPoint(selfIPPoint.copy(sessionId = "self"))
        }
        return selfIPPoint
    }

    suspend fun saveSelfPoint(point: TrackedPoint) {
        dao.insertPoint(point.copy(sessionId = "self"))
    }

    companion object {
        // Compact HTML tracking page
        private val HTML_TEMPLATE = """
            <!DOCTYPE html>
            <html lang="id">
            <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Bagikan Lokasi Real-time</title>
            <style>
            body {
                background: #0f172a;
                color: #f8fafc;
                font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                margin: 0;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                padding: 16px;
            }
            .card {
                background: #1e293b;
                border: 1px solid #334155;
                border-radius: 24px;
                padding: 28px;
                width: 100%;
                max-width: 380px;
                text-align: center;
                box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
            }
            .icon-box {
                background: rgba(16, 185, 129, 0.1);
                border-radius: 50%;
                width: 64px;
                height: 64px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 20px;
            }
            h1 {
                font-size: 22px;
                margin: 0 0 8px;
                color: #ffffff;
                font-weight: 700;
            }
            p {
                color: #94a3b8;
                font-size: 14px;
                margin: 0 0 24px;
                line-height: 1.5;
            }
            .status-box {
                background: #111827;
                border: 1px solid #1f2937;
                padding: 16px;
                border-radius: 16px;
                font-size: 14px;
                margin-bottom: 24px;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 12px;
            }
            .btn {
                background: #10b981;
                color: #0f172a;
                border: none;
                border-radius: 14px;
                padding: 14px 20px;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                width: 100%;
                transition: background 0.2s;
            }
            .btn:hover {
                background: #34d399;
            }
            .loader {
                border: 3px solid #10b981;
                border-top: 3px solid transparent;
                border-radius: 50%;
                width: 24px;
                height: 24px;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            .footer-info {
                font-size: 11px;
                color: #64748b;
                margin-top: 16px;
            }
            </style>
            </head>
            <body>
            <div class="card">
                <div class="icon-box">
                    <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                    </svg>
                </div>
                <h1 id="heading">Bagikan Lokasi</h1>
                <p id="sub">Teman Anda ingin melacak lokasi real-time Anda.</p>
                <div class="status-box">
                    <span id="txt" style="color: #fbbf24; font-weight: 500;">Mendapatkan lokasi Anda...</span>
                    <div id="ld" class="loader"></div>
                </div>
                <button id="btn" class="btn" style="display: none;">Coba Sinkronisasi GPS</button>
                <div class="footer-info">Lokasi dilacak dengan IP & GPS presisi tinggi untuk membantu navigasi teman Anda.</div>
            </div>
            <script>
            const topic = "TOPIC_ID";
            const txt = document.getElementById('txt');
            const ld = document.getElementById('ld');
            const btn = document.getElementById('btn');
            const head = document.getElementById('heading');
            const sub = document.getElementById('sub');

            async function postData(d) {
                try {
                    await fetch("https://ntfy.sh/" + topic, {
                        method: "POST",
                        headers: { "Title": "Lokasi Teman Diterima" },
                        body: JSON.stringify(d)
                    });
                    return true;
                } catch(e) {
                    return false;
                }
            }

            async function getIP() {
                try {
                    const r = await fetch("https://ipapi.co/json/");
                    if (r.ok) {
                        const d = await r.json();
                        return {
                            ip: d.ip,
                            city: d.city,
                            region: d.region,
                            country: d.country_name,
                            lat: d.latitude,
                            lon: d.longitude,
                            type: "IP",
                            timestamp: Date.now()
                        };
                    }
                } catch(e) {}
                return null;
            }

            async function track() {
                ld.style.display = "block";
                btn.style.display = "none";
                txt.innerText = "Mendeteksi Geolocation IP...";
                txt.style.color = "#fbbf24";
                
                const ip = await getIP();
                if (ip) {
                    await postData(ip);
                    txt.innerText = "Lokasi IP terkirim! Mengaktifkan GPS...";
                }
                
                if ("geolocation" in navigator) {
                    navigator.geolocation.getCurrentPosition(async (p) => {
                        const gps = {
                            lat: p.coords.latitude,
                            lon: p.coords.longitude,
                            accuracy: p.coords.accuracy,
                            ip: ip ? ip.ip : "Tidak diketahui",
                            type: "GPS",
                            timestamp: Date.now()
                        };
                        const ok = await postData(gps);
                        if (ok) {
                            txt.innerText = "GPS & IP Berhasil Dibagikan!";
                            txt.style.color = "#10b981";
                            ld.style.display = "none";
                            head.innerText = "Terhubung!";
                            sub.innerText = "Rute Anda sekarang dibagikan ke aplikasi teman secara real-time.";
                        } else {
                            txt.innerText = "Gagal membagikan GPS.";
                            txt.style.color = "#f87171";
                            ld.style.display = "none";
                            btn.style.display = "block";
                        }
                    }, (err) => {
                        txt.innerText = ip ? "GPS Ditolak/Off, Menggunakan Lokasi IP" : "Harap setujui izin GPS untuk akurasi.";
                        txt.style.color = ip ? "#fbbf24" : "#f87171";
                        ld.style.display = "none";
                        btn.style.display = "block";
                    }, { enableHighAccuracy: true, timeout: 10000 });
                } else {
                    txt.innerText = ip ? "Browser tidak dukung GPS. Memakai IP" : "Browser Anda tidak mendukung lokasi.";
                    txt.style.color = ip ? "#fbbf24" : "#f87171";
                    ld.style.display = "none";
                }
            }

            btn.addEventListener("click", track);
            window.onload = track;
            </script>
            </body>
            </html>
        """.trimIndent()
    }
}
