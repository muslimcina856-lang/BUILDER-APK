package com.example.network

import android.util.Log
import com.example.data.TrackedPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object LocationNetworkService {
    private const val TAG = "LocationNetworkService"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    /**
     * Shortens a long URL using the is.gd API.
     */
    suspend fun shortenUrl(longUrl: String): String? = withContext(Dispatchers.IO) {
        try {
            val encodedUrl = URLEncoder.encode(longUrl, "UTF-8")
            val url = "https://is.gd/create.php?format=json&url=$encodedUrl"
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: return@use null
                    val json = JSONObject(bodyString)
                    if (json.has("shorturl")) {
                        return@withContext json.getString("shorturl")
                    } else if (json.has("errormessage")) {
                        Log.e(TAG, "is.gd failure message: ${json.getString("errormessage")}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to shorten URL: ", e)
        }
        null
    }

    /**
     * Obtains the public IP details and location data using connection to ipapi.co
     */
    suspend fun getIpGeolocation(): TrackedPoint? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("https://ipapi.co/json/")
                .header("User-Agent", "Mozilla/5.0")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: return@use null
                    val json = JSONObject(bodyString)
                    
                    val lat = json.optDouble("latitude", 0.0)
                    val lon = json.optDouble("longitude", 0.0)
                    val ip = json.optString("ip", "Unknown")
                    val city = json.optString("city", "Unknown")
                    val region = json.optString("region", "Unknown")
                    val country = json.optString("country_name", "Unknown")

                    return@withContext TrackedPoint(
                        sessionId = "self",
                        latitude = lat,
                        longitude = lon,
                        accuracy = 10000.0, // High accuracy range estimate for IP Geolocation
                        ip = ip,
                        type = "IP",
                        city = city,
                        region = region,
                        country = country,
                        timestamp = System.currentTimeMillis()
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get IP Geolocation: ", e)
        }
        null
    }

    /**
     * Polls the ntfy.sh server for messages. Each notification's dynamic metadata
     * (originally uploaded from HTML JS) represents location points shared by our friend.
     */
    suspend fun pollTrackedPoints(topicId: String): List<TrackedPoint> = withContext(Dispatchers.IO) {
        val points = mutableListOf<TrackedPoint>()
        try {
            val url = "https://ntfy.sh/$topicId/json?poll=1"
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseBody = response.body?.string() ?: return@use points
                    // ntfy.sh formats poll output as a line-separated list of JSON objects
                    val lines = responseBody.split("\n")
                    for (line in lines) {
                        if (line.trim().isEmpty()) continue
                        try {
                            val eventObj = JSONObject(line)
                            val eventType = eventObj.optString("event", "")
                            if (eventType == "message") {
                                val messageBody = eventObj.optString("message", "")
                                if (messageBody.startsWith("{") && messageBody.endsWith("}")) {
                                    val locObj = JSONObject(messageBody)
                                    val lat = locObj.optDouble("lat", 0.0)
                                    val lon = locObj.optDouble("lon", 0.0)
                                    val type = locObj.optString("type", "GPS")
                                    val ip = locObj.optString("ip", "")
                                    val accuracy = locObj.optDouble("accuracy", 0.0)
                                    val city = locObj.optString("city", "")
                                    val region = locObj.optString("region", "")
                                    val country = locObj.optString("country", "")
                                    val timestamp = locObj.optLong("timestamp", System.currentTimeMillis())

                                    points.add(
                                        TrackedPoint(
                                            sessionId = topicId,
                                            latitude = lat,
                                            longitude = lon,
                                            accuracy = accuracy,
                                            ip = ip,
                                            type = type,
                                            city = city,
                                            region = region,
                                            country = country,
                                            timestamp = timestamp
                                        )
                                    )
                                }
                            }
                        } catch (itemEx: Exception) {
                            Log.e(TAG, "Failed parsing a ntfy item line $line: ", itemEx)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed polling ntfy data for topic $topicId: ", e)
        }
        points
    }
}
