package com.example.prd_md

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
