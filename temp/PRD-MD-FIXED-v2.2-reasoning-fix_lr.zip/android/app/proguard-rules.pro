# Proguard rules untuk sqflite & SQLite
-keep class.sqlite.** { *; }
-keep class org.sqlite.** { *; }
-keep class com.tekartik.sqflite.** { *; }
-dontwarn class.sqlite.**
-dontwarn org.sqlite.**
-dontwarn com.tekartik.sqflite.**
