import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../features/settings/domain/entities/mimo_api_key.dart';

/// Bilangan kegagalan berturut-turut sebelum satu kunci di-skip ke kunci
/// seterusnya dalam pusingan fallback semasa. Kunci yang sama akan dicuba
/// semula sehingga had ini tercapai (bukan skip serta-merta pada ralat
/// sementara seperti rate-limit).
const int kMaxConsecutiveFailuresBeforeFallback = 3;

/// Mengurus senarai kunci API MiMo AI: penyimpanan, pendaftaran, pemadaman,
/// serta logik pusingan fallback (round-robin) apabila kunci semasa gagal.
///
/// Kunci disimpan sebagai satu senarai JSON tersulit dalam
/// [FlutterSecureStorage], dilabel mengikut `order` (1, 2, 3, ...).
/// Apabila kunci gagal [kMaxConsecutiveFailuresBeforeFallback] kali
/// berturut-turut, sistem beralih ke kunci seterusnya mengikut `order`;
/// apabila sampai ke penghujung senarai, ia berpusing semula ke kunci #1.
class MimoKeyManager {
  static const String _storageKey = 'mimo_api_keys_v1';
  static const String _lastUsedIndexKey = 'mimo_last_used_key_order_v1';
  static const String _errorActionKey = 'mimo_key_error_action_v1';

  final FlutterSecureStorage _storage;

  MimoKeyManager({FlutterSecureStorage? storage})
      : _storage = storage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(encryptedSharedPreferences: true),
            );

  // ---------------------------------------------------------------------
  // CRUD Kunci
  // ---------------------------------------------------------------------

  /// Memulangkan semua kunci tersimpan, tersusun mengikut `order`.
  Future<List<MimoApiKey>> getAllKeys() async {
    final String? raw = await _storage.read(key: _storageKey);
    if (raw == null || raw.isEmpty) return [];

    try {
      final List<dynamic> decoded = jsonDecode(raw) as List<dynamic>;
      final List<MimoApiKey> keys = decoded
          .map((e) => MimoApiKey.fromJson(e as Map<String, dynamic>))
          .toList();
      keys.sort((a, b) => a.order.compareTo(b.order));
      return keys;
    } catch (_) {
      return [];
    }
  }

  Future<void> _saveAllKeys(List<MimoApiKey> keys) async {
    keys.sort((a, b) => a.order.compareTo(b.order));
    final String encoded =
        jsonEncode(keys.map((k) => k.toJson()).toList());
    await _storage.write(key: _storageKey, value: encoded);
  }

  /// Menambah kunci API baharu. Melontar [DuplicateKeyException] jika
  /// kunci yang sama (case-sensitive, selepas trim) sudah wujud.
  ///
  /// Kunci baharu diberikan `order` seterusnya selepas kunci terbesar
  /// sedia ada (mengekalkan urutan 1, 2, 3, ...).
  Future<MimoApiKey> addKey(String rawKey) async {
    final String trimmed = rawKey.trim();
    if (trimmed.isEmpty) {
      throw const InvalidKeyException('Kunci API tidak boleh kosong.');
    }

    final List<MimoApiKey> existing = await getAllKeys();

    final bool isDuplicate =
        existing.any((k) => k.key == trimmed);
    if (isDuplicate) {
      throw const DuplicateKeyException(
        'Kunci API ini sudah wujud dalam senarai.',
      );
    }

    final int nextOrder = existing.isEmpty
        ? 1
        : (existing.map((k) => k.order).reduce((a, b) => a > b ? a : b) + 1);

    final MimoApiKey newKey = MimoApiKey(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      order: nextOrder,
      key: trimmed,
    );

    existing.add(newKey);
    await _saveAllKeys(existing);
    return newKey;
  }

  /// Memadam satu kunci mengikut id, dan menyusun semula `order`
  /// baki kunci supaya sentiasa berturutan (1, 2, 3, ...) tanpa jurang.
  Future<void> deleteKey(String keyId) async {
    final List<MimoApiKey> existing = await getAllKeys();
    existing.removeWhere((k) => k.id == keyId);

    // Susun semula order supaya tiada jurang (cth 1, 3 -> 1, 2)
    existing.sort((a, b) => a.order.compareTo(b.order));
    final List<MimoApiKey> renumbered = [
      for (int i = 0; i < existing.length; i++)
        existing[i].copyWith(order: i + 1),
    ];

    await _saveAllKeys(renumbered);
  }

  /// Memulangkan `true` jika sekurang-kurangnya satu kunci wujud.
  Future<bool> hasAnyKey() async {
    final keys = await getAllKeys();
    return keys.isNotEmpty;
  }

  // ---------------------------------------------------------------------
  // Logik Fallback / Rotation
  // ---------------------------------------------------------------------

  /// Memulangkan kunci yang patut digunakan untuk permintaan seterusnya.
  ///
  /// Cuba teruskan dengan kunci terakhir yang digunakan (mengikut `order`)
  /// selagi ia belum mencapai had kegagalan berturut-turut. Apabila had
  /// tercapai, beralih ke kunci `active` seterusnya dalam senarai; jika
  /// sampai ke penghujung, berpusing semula ke kunci #1.
  ///
  /// Memulangkan `null` jika tiada kunci `active` langsung dalam senarai.
  Future<MimoApiKey?> getNextKeyToUse() async {
    final List<MimoApiKey> allKeys = await getAllKeys();
    final List<MimoApiKey> usableKeys =
        allKeys.where((k) => k.status == MimoKeyStatus.active).toList()
          ..sort((a, b) => a.order.compareTo(b.order));

    if (usableKeys.isEmpty) return null;

    final String? lastUsedOrderRaw =
        await _storage.read(key: _lastUsedIndexKey);
    final int? lastUsedOrder =
        lastUsedOrderRaw != null ? int.tryParse(lastUsedOrderRaw) : null;

    if (lastUsedOrder == null) {
      // Belum pernah guna kunci apa-apa lagi — mula dari kunci pertama.
      return usableKeys.first;
    }

    final MimoApiKey? lastUsedKey = allKeys.cast<MimoApiKey?>().firstWhere(
          (k) => k?.order == lastUsedOrder,
          orElse: () => null,
        );

    // Jika kunci terakhir digunakan masih aktif dan belum capai had
    // kegagalan, teruskan dengan kunci yang sama.
    if (lastUsedKey != null &&
        lastUsedKey.status == MimoKeyStatus.active &&
        lastUsedKey.consecutiveFailures < kMaxConsecutiveFailuresBeforeFallback) {
      return lastUsedKey;
    }

    // Cari kunci usable seterusnya selepas order semasa; jika tiada,
    // pusing semula ke yang pertama (round-robin).
    final MimoApiKey? nextKey = usableKeys
        .cast<MimoApiKey?>()
        .firstWhere((k) => k!.order > lastUsedOrder, orElse: () => null);

    return nextKey ?? usableKeys.first;
  }

  /// Merekodkan bahawa `key` berjaya digunakan — reset bilangan kegagalan
  /// berturut-turut dan tandakan sebagai kunci terakhir digunakan.
  Future<void> recordSuccess(String keyId) async {
    final List<MimoApiKey> existing = await getAllKeys();
    final int index = existing.indexWhere((k) => k.id == keyId);
    if (index == -1) return;

    existing[index] = existing[index].copyWith(
      consecutiveFailures: 0,
      status: MimoKeyStatus.active,
      clearLastError: true,
    );

    await _saveAllKeys(existing);
    await _storage.write(
      key: _lastUsedIndexKey,
      value: existing[index].order.toString(),
    );
  }

  /// Merekodkan bahawa `key` gagal dengan `errorReason`, dan menerapkan
  /// [onErrorAction] apabila had kegagalan berturut-turut tercapai:
  /// padam terus, atau simpan dengan penanda status = error.
  ///
  /// Kunci yang ditanda `error` (bukan dipadam) tetap kekal dalam senarai
  /// dan akan digunakan semula bila-bila pusingan fallback kembali
  /// memerlukannya — tanda ralat sekadar maklumat, bukan sekatan kekal.
  ///
  /// Tindakan yang diambil apabila had kegagalan tercapai (padam automatik
  /// atau simpan dengan penanda) dibaca daripada keutamaan tersimpan
  /// melalui [getKeyErrorAction] — lihat kaedah tersebut untuk nilai lalai.
  Future<void> recordFailure({
    required String keyId,
    required String errorReason,
  }) async {
    final List<MimoApiKey> existing = await getAllKeys();
    final int index = existing.indexWhere((k) => k.id == keyId);
    if (index == -1) return;

    final int newFailureCount = existing[index].consecutiveFailures + 1;
    final bool hasReachedLimit =
        newFailureCount >= kMaxConsecutiveFailuresBeforeFallback;

    final KeyErrorAction onErrorAction = await getKeyErrorAction();

    if (hasReachedLimit && onErrorAction == KeyErrorAction.autoDelete) {
      existing.removeAt(index);
      // Susun semula order supaya tiada jurang.
      existing.sort((a, b) => a.order.compareTo(b.order));
      final List<MimoApiKey> renumbered = [
        for (int i = 0; i < existing.length; i++)
          existing[i].copyWith(order: i + 1),
      ];
      await _saveAllKeys(renumbered);
      return;
    }

    existing[index] = existing[index].copyWith(
      consecutiveFailures: newFailureCount,
      status: hasReachedLimit ? MimoKeyStatus.error : MimoKeyStatus.active,
      lastErrorReason: errorReason,
      lastErrorAt: DateTime.now(),
    );

    await _saveAllKeys(existing);
  }

  /// Membenarkan pengguna menetapkan semula status kunci yang ditanda
  /// `error` kembali kepada `active` secara manual (cth selepas menambah
  /// credit baharu pada akaun MiMo mereka).
  Future<void> reactivateKey(String keyId) async {
    final List<MimoApiKey> existing = await getAllKeys();
    final int index = existing.indexWhere((k) => k.id == keyId);
    if (index == -1) return;

    existing[index] = existing[index].copyWith(
      status: MimoKeyStatus.active,
      consecutiveFailures: 0,
      clearLastError: true,
    );

    await _saveAllKeys(existing);
  }

  // ---------------------------------------------------------------------
  // Keutamaan Tindakan Kunci Bermasalah
  // ---------------------------------------------------------------------

  /// Mendapatkan tindakan yang patut diambil apabila kunci gagal berulang:
  /// padam automatik, atau simpan dengan penanda. Lalai kepada
  /// [KeyErrorAction.keepWithMarker] jika belum ditetapkan oleh pengguna,
  /// supaya tiada kunci hilang tanpa makluman secara tidak sengaja.
  Future<KeyErrorAction> getKeyErrorAction() async {
    final String? raw = await _storage.read(key: _errorActionKey);
    if (raw == KeyErrorAction.autoDelete.name) {
      return KeyErrorAction.autoDelete;
    }
    return KeyErrorAction.keepWithMarker;
  }

  /// Menyimpan pilihan tindakan kunci bermasalah pengguna secara berterusan.
  Future<void> setKeyErrorAction(KeyErrorAction action) async {
    await _storage.write(key: _errorActionKey, value: action.name);
  }

  /// Memadam semua kunci tersimpan (digunakan oleh fungsi padam data).
  Future<void> clearAll() async {
    await _storage.delete(key: _storageKey);
    await _storage.delete(key: _lastUsedIndexKey);
    await _storage.delete(key: _errorActionKey);
  }
}

/// Dilontar apabila kunci API yang cuba ditambah adalah salinan kunci
/// yang sudah wujud dalam senarai.
class DuplicateKeyException implements Exception {
  final String message;
  const DuplicateKeyException(this.message);
  @override
  String toString() => message;
}

/// Dilontar apabila kunci API yang cuba ditambah tidak sah (cth kosong).
class InvalidKeyException implements Exception {
  final String message;
  const InvalidKeyException(this.message);
  @override
  String toString() => message;
}

/// Dilontar apabila tiada kunci API yang boleh digunakan (senarai kosong,
/// atau semua kunci ditanda `error`).
class NoUsableKeyException implements Exception {
  final String message;
  const NoUsableKeyException(this.message);
  @override
  String toString() => message;
}
