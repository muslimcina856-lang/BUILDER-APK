import 'package:flutter/material.dart';

/// Sistem warna utama untuk PRD MD.
///
/// Palet ini direka untuk estetik premium gelap dengan
/// gabungan biru tengah malam, ungu elektrik dan sian terang.
abstract final class AppColors {
  // ─── Brand Primaries ───────────────────────────────────────────────
  static const Color primary = Color(0xFF0D1B2A);
  static const Color primaryLight = Color(0xFF1B2838);
  static const Color primaryDark = Color(0xFF060F18);

  static const Color secondary = Color(0xFF7B2FBE);
  static const Color secondaryLight = Color(0xFF9B59D0);
  static const Color secondaryDark = Color(0xFF5A1F8E);

  static const Color accent = Color(0xFF00D4FF);
  static const Color accentLight = Color(0xFF5CE1FF);
  static const Color accentDark = Color(0xFF009DC0);

  // ─── Surfaces ──────────────────────────────────────────────────────
  static const Color surface = Color(0xFF0F1923);
  static const Color surfaceLight = Color(0xFF162030);
  static const Color surfaceVariant = Color(0xFF1A2736);

  static const Color card = Color(0xFF12202E);
  static const Color cardHover = Color(0xFF182A3A);
  static const Color cardBorder = Color(0xFF1E3248);

  static const Color scaffold = Color(0xFF0A1220);

  // ─── Background Gradients ─────────────────────────────────────────
  static const Color gradientStart = Color(0xFF0D1B2A);
  static const Color gradientMiddle = Color(0xFF11203A);
  static const Color gradientEnd = Color(0xFF1A1040);

  static const Color shimmerBase = Color(0xFF162030);
  static const Color shimmerHighlight = Color(0xFF1E3248);

  // ─── Text ──────────────────────────────────────────────────────────
  static const Color textPrimary = Color(0xFFF0F4F8);
  static const Color textSecondary = Color(0xFFB0BEC5);
  static const Color textMuted = Color(0xFF607D8B);
  static const Color textHint = Color(0xFF455A64);
  static const Color textOnAccent = Color(0xFF0D1B2A);
  static const Color textOnSecondary = Color(0xFFFFFFFF);

  // ─── Semantic / Status ─────────────────────────────────────────────
  static const Color success = Color(0xFF00E676);
  static const Color successDark = Color(0xFF00C853);
  static const Color error = Color(0xFFFF5252);
  static const Color errorDark = Color(0xFFD32F2F);
  static const Color warning = Color(0xFFFFAB40);
  static const Color warningDark = Color(0xFFF57C00);
  static const Color info = Color(0xFF448AFF);
  static const Color infoDark = Color(0xFF2962FF);

  // ─── Chat Bubbles ─────────────────────────────────────────────────
  static const Color aiBubble = Color(0xFF162A3E);
  static const Color aiBubbleBorder = Color(0xFF1E3A52);
  static const Color userBubble = Color(0xFF7B2FBE);
  static const Color userBubbleBorder = Color(0xFF9B59D0);

  // ─── Form / Input Widgets ─────────────────────────────────────────
  static const Color inputFill = Color(0xFF0F1923);
  static const Color inputBorder = Color(0xFF1E3248);
  static const Color inputBorderFocused = Color(0xFF00D4FF);
  static const Color inputBorderError = Color(0xFFFF5252);

  // ─── Dividers & Misc ──────────────────────────────────────────────
  static const Color divider = Color(0xFF1E3248);
  static const Color overlay = Color(0xCC000000); // 80% opacity black
  static const Color disabled = Color(0xFF37474F);
  static const Color icon = Color(0xFFB0BEC5);
  static const Color iconActive = Color(0xFF00D4FF);

  // ─── Chip / Badge ─────────────────────────────────────────────────
  static const Color chipBackground = Color(0xFF1A2736);
  static const Color chipSelected = Color(0xFF7B2FBE);

  // ─── Predefined Gradients ─────────────────────────────────────────
  static const LinearGradient backgroundGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [gradientStart, gradientMiddle, gradientEnd],
  );

  static const LinearGradient accentGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [secondary, accent],
  );

  static const LinearGradient cardGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [card, surfaceVariant],
  );

  static const LinearGradient buttonGradient = LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [secondary, Color(0xFF5B4FE6), accent],
  );

  /// Warna transparensi untuk kesan glassmorphism.
  static Color glass({double opacity = 0.08}) =>
      Colors.white.withOpacity(opacity);

  /// Border halus untuk kesan glassmorphism.
  static Color glassBorder({double opacity = 0.12}) =>
      Colors.white.withOpacity(opacity);
}
