import 'package:equatable/equatable.dart';

/// Kelas asas untuk semua kegagalan dalam aplikasi.
///
/// Setiap jenis kegagalan memanjangkan [Failure] dan menyediakan
/// mesej yang boleh dipaparkan kepada pengguna.
sealed class Failure extends Equatable {
  const Failure({required this.message, this.statusCode});

  /// Mesej kegagalan yang boleh dipaparkan kepada pengguna.
  final String message;

  /// Kod status HTTP (jika berkenaan).
  final int? statusCode;

  @override
  List<Object?> get props => [message, statusCode];
}

/// Kegagalan dari pelayan / API.
final class ServerFailure extends Failure {
  const ServerFailure({
    required super.message,
    super.statusCode,
    this.responseBody,
  });

  /// Badan respons mentah dari pelayan (untuk debugging).
  final String? responseBody;

  @override
  List<Object?> get props => [message, statusCode, responseBody];
}

/// Kegagalan berkaitan cache / storan tempatan.
final class CacheFailure extends Failure {
  const CacheFailure({
    super.message = 'Gagal mengakses storan tempatan.',
  });
}

/// Kegagalan rangkaian (tiada internet, tamat masa, dsb.).
final class NetworkFailure extends Failure {
  const NetworkFailure({
    super.message = 'Tiada sambungan internet. Sila semak rangkaian anda.',
  });
}

/// Kegagalan berkaitan kunci API (tiada, tidak sah, dsb.).
final class ApiKeyFailure extends Failure {
  const ApiKeyFailure({
    super.message = 'Kunci API tidak sah atau tidak ditetapkan.',
  });
}

/// Kegagalan semasa menghurai data (JSON, Markdown, dsb.).
final class ParseFailure extends Failure {
  const ParseFailure({
    super.message = 'Gagal memproses data yang diterima.',
    this.rawData,
  });

  /// Data mentah yang gagal dihurai.
  final String? rawData;

  @override
  List<Object?> get props => [message, rawData];
}

/// Kegagalan pengesahan input pengguna.
final class ValidationFailure extends Failure {
  const ValidationFailure({
    required super.message,
    this.field,
  });

  /// Nama medan yang gagal pengesahan.
  final String? field;

  @override
  List<Object?> get props => [message, field];
}

/// Kegagalan yang tidak dijangka / tidak diketahui.
final class UnexpectedFailure extends Failure {
  const UnexpectedFailure({
    super.message = 'Ralat tidak dijangka berlaku. Sila cuba lagi.',
    this.exception,
  });

  /// Pengecualian asal (untuk logging).
  final Object? exception;

  @override
  List<Object?> get props => [message, exception];
}
