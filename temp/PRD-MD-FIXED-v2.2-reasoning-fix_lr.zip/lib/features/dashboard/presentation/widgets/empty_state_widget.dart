import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../../core/constants/app_colors.dart';

class EmptyStateWidget extends StatelessWidget {
  final VoidCallback onTapNewChat;

  const EmptyStateWidget({super.key, required this.onTapNewChat});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Glowing animated icon
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity( 0.08),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.accent.withOpacity( 0.15), width: 2),
              ),
              child: const Icon(
                Icons.chat_bubble_outline_rounded,
                size: 64,
                color: AppColors.accent,
              ),
            )
                .animate(onPlay: (controller) => controller.repeat())
                .shimmer(duration: 2.seconds, color: AppColors.accent.withOpacity( 0.3))
                .scale(begin: const Offset(1, 1), end: const Offset(1.03, 1.03), duration: 1200.ms, curve: Curves.easeInOut),
            const SizedBox(height: 24),
            Text(
              'Tiada perbualan lagi',
              style: GoogleFonts.inter(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Sila bina draf PRD atau README pertama anda dengan menekan butang tambah sembang baharu di bawah.',
              style: TextStyle(color: AppColors.textMuted, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              icon: const Icon(Icons.add_rounded),
              label: const Text('Mula Sembang Baru'),
              onPressed: onTapNewChat,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
