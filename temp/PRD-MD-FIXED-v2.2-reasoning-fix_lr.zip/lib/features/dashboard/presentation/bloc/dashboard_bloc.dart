import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../chat/domain/entities/chat_session.dart';
import '../../../chat/domain/repositories/chat_repository.dart';
import '../../../chat/data/repositories/chat_repository_impl.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class DashboardEvent extends Equatable {
  const DashboardEvent();
  @override
  List<Object?> get props => [];
}

class LoadDashboard extends DashboardEvent {}

class SearchDashboardSessions extends DashboardEvent {
  final String query;
  const SearchDashboardSessions(this.query);
  @override
  List<Object?> get props => [query];
}

class DeleteDashboardSession extends DashboardEvent {
  final String sessionId;
  const DeleteDashboardSession(this.sessionId);
  @override
  List<Object?> get props => [sessionId];
}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class DashboardState extends Equatable {
  const DashboardState();
  @override
  List<Object?> get props => [];
}

class DashboardInitial extends DashboardState {}

class DashboardLoading extends DashboardState {}

class DashboardLoaded extends DashboardState {
  final List<ChatSession> sessions;
  final String searchQuery;

  const DashboardLoaded({
    required this.sessions,
    this.searchQuery = '',
  });

  DashboardLoaded copyWith({
    List<ChatSession>? sessions,
    String? searchQuery,
  }) {
    return DashboardLoaded(
      sessions: sessions ?? this.sessions,
      searchQuery: searchQuery ?? this.searchQuery,
    );
  }

  @override
  List<Object?> get props => [sessions, searchQuery];
}

class DashboardError extends DashboardState {
  final String message;
  const DashboardError(this.message);
  @override
  List<Object?> get props => [message];
}

// -----------------------------------------------------------------------------
// BLOC IMPLEMENTATION
// -----------------------------------------------------------------------------
class DashboardBloc extends Bloc<DashboardEvent, DashboardState> {
  final ChatRepository _chatRepository;

  DashboardBloc({ChatRepository? chatRepository})
      : _chatRepository = chatRepository ?? ChatRepositoryImpl(),
        super(DashboardInitial()) {
    on<LoadDashboard>(_onLoadDashboard);
    on<SearchDashboardSessions>(_onSearchDashboardSessions);
    on<DeleteDashboardSession>(_onDeleteDashboardSession);
  }

  Future<void> _onLoadDashboard(LoadDashboard event, Emitter<DashboardState> emit) async {
    emit(DashboardLoading());
    try {
      final List<ChatSession> sessions = await _chatRepository.getAllSessions();
      emit(DashboardLoaded(sessions: sessions));
    } catch (e) {
      emit(DashboardError('Gagal memuatkan sejarah sembang: $e'));
    }
  }

  Future<void> _onSearchDashboardSessions(SearchDashboardSessions event, Emitter<DashboardState> emit) async {
    final String query = event.query.trim();
    try {
      if (query.isEmpty) {
        final List<ChatSession> sessions = await _chatRepository.getAllSessions();
        emit(DashboardLoaded(sessions: sessions, searchQuery: ''));
        return;
      }

      final List<ChatSession> sessions = await _chatRepository.searchSessions(query);
      emit(DashboardLoaded(sessions: sessions, searchQuery: query));
    } catch (e) {
      emit(DashboardError('Ralat carian sembang: $e'));
    }
  }

  Future<void> _onDeleteDashboardSession(DeleteDashboardSession event, Emitter<DashboardState> emit) async {
    try {
      await _chatRepository.deleteSession(event.sessionId);
      add(LoadDashboard());
    } catch (e) {
      emit(DashboardError('Gagal memadam perbualan: $e'));
    }
  }
}
