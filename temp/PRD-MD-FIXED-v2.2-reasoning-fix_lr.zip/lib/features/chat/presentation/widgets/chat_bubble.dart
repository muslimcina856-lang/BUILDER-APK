import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/chat_message.dart';
import 'markdown_viewer.dart';

class ChatBubble extends StatelessWidget {
  final ChatMessage message;
  final Widget? formWidget;

  const ChatBubble({
    super.key,
    required this.message,
    this.formWidget,
  });

  void _copyToClipboard(BuildContext context) {
    Clipboard.setData(ClipboardData(text: message.content));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Kandungan mesej disalin!'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _shareContent() {
    Share.share(message.content, subject: 'PRD / README MD Generated Document');
  }

  @override
  Widget build(BuildContext context) {
    final bool isUser = message.isUser;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isUser) ...[
            Container(
              margin: const EdgeInsets.only(right: 8, top: 4),
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                gradient: AppColors.accentGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.psychology, size: 20, color: Colors.white),
            ),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                // Bubble Container
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: isUser ? AppColors.userBubble : AppColors.card,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft: isUser ? const Radius.circular(16) : Radius.zero,
                      bottomRight: isUser ? Radius.zero : const Radius.circular(16),
                    ),
                    border: Border.all(
                      color: isUser ? Colors.transparent : AppColors.cardBorder,
                    ),
                  ),
                  child: isUser
                      ? Text(
                          message.content,
                          style: GoogleFonts.inter(
                            color: Colors.white,
                            fontSize: 14,
                            height: 1.4,
                          ),
                        )
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            MarkdownViewer(text: message.content),
                            if (formWidget != null) ...[
                              const SizedBox(height: 12),
                              formWidget!,
                            ],
                          ],
                        ),
                ),
                const SizedBox(height: 4),
                // Metadata Actions (Copy, Share, Timestamp)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _formatTime(message.timestamp),
                        style: const TextStyle(color: AppColors.textMuted, fontSize: 10),
                      ),
                      if (!isUser && message.content.isNotEmpty && !message.content.startsWith('[ERROR]')) ...[
                        const SizedBox(width: 12),
                        GestureDetector(
                          onTap: () => _copyToClipboard(context),
                          child: const Row(
                            children: [
                              Icon(Icons.copy_all, size: 12, color: AppColors.textMuted),
                              SizedBox(width: 2),
                              Text('Salin', style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        GestureDetector(
                          onTap: _shareContent,
                          child: const Row(
                            children: [
                              Icon(Icons.share, size: 12, color: AppColors.textMuted),
                              SizedBox(width: 2),
                              Text('Kongsi', style: TextStyle(color: AppColors.textMuted, fontSize: 10)),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            Container(
              margin: const EdgeInsets.only(top: 4),
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: AppColors.secondary.withOpacity( 0.2),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.secondary.withOpacity( 0.5)),
              ),
              child: const Icon(Icons.person_outline, size: 20, color: Colors.white),
            ),
          ],
        ],
      ),
    );
  }

  String _formatTime(DateTime time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }
}
