import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';

class MarkdownViewer extends StatelessWidget {
  final String text;

  const MarkdownViewer({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return MarkdownBody(
      data: text,
      selectable: true,
      shrinkWrap: true,
      styleSheet: MarkdownStyleSheet(
        p: GoogleFonts.inter(color: AppColors.textPrimary, fontSize: 14, height: 1.5),
        h1: GoogleFonts.inter(
          color: Colors.white,
          fontSize: 22,
          fontWeight: FontWeight.w800,
          height: 1.4,
        ),
        h2: GoogleFonts.inter(
          color: Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          height: 1.4,
        ),
        h3: GoogleFonts.inter(
          color: Colors.white,
          fontSize: 15,
          fontWeight: FontWeight.bold,
          height: 1.4,
        ),
        h4: GoogleFonts.inter(
          color: Colors.white,
          fontSize: 13,
          fontWeight: FontWeight.bold,
        ),
        code: GoogleFonts.firaCode(
          color: AppColors.accent,
          backgroundColor: AppColors.scaffold,
          fontSize: 12,
        ),
        codeblockPadding: const EdgeInsets.all(12),
        codeblockDecoration: BoxDecoration(
          color: AppColors.scaffold,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.cardBorder),
        ),
        blockquote: GoogleFonts.inter(
          color: AppColors.textMuted,
          fontSize: 13,
        ),
        blockquotePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        blockquoteDecoration: const BoxDecoration(
          border: Border(
            left: BorderSide(color: AppColors.accent, width: 4),
          ),
        ),
        tableHead: GoogleFonts.inter(fontWeight: FontWeight.bold, color: Colors.white),
        tableBody: GoogleFonts.inter(color: AppColors.textPrimary),
        tableBorder: TableBorder.all(color: AppColors.cardBorder, width: 0.5),
        tableCellsPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        listBullet: GoogleFonts.inter(color: AppColors.accent),
      ),
      imageBuilder: (uri, title, alt) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(
            uri.toString(),
            errorBuilder: (context, error, stackTrace) => const Icon(Icons.broken_image, color: AppColors.error),
          ),
        );
      },
    );
  }
}
