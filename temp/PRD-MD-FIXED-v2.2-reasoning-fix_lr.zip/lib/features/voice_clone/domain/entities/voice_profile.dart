import 'package:equatable/equatable.dart';

/// Satu profil suara yang disimpan pengguna untuk tujuan klon suara.
///
/// Profil menyimpan sampel audio rujukan (base64) yang akan dihantar ke
/// MiMo AI (`mimo-v2.5-tts-voiceclone`) setiap kali pengguna mahu menjana
/// pertuturan baharu menggunakan suara ini.
class VoiceProfile extends Equatable {
  final String id;
  final String name;

  /// Sampel audio rujukan sebagai base64 tulen (TANPA prefix data URI).
  final String audioBase64;

  /// MIME type sampel audio, cth `audio/mpeg` (mp3) atau `audio/wav`.
  final String mimeType;

  /// Sumber sampel: direkod dalam app, atau dimuat naik daripada fail.
  final VoiceProfileSource source;

  final DateTime createdAt;

  const VoiceProfile({
    required this.id,
    required this.name,
    required this.audioBase64,
    required this.mimeType,
    required this.source,
    required this.createdAt,
  });

  VoiceProfile copyWith({
    String? id,
    String? name,
    String? audioBase64,
    String? mimeType,
    VoiceProfileSource? source,
    DateTime? createdAt,
  }) {
    return VoiceProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      audioBase64: audioBase64 ?? this.audioBase64,
      mimeType: mimeType ?? this.mimeType,
      source: source ?? this.source,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  factory VoiceProfile.fromJson(Map<String, dynamic> json) {
    return VoiceProfile(
      id: json['id'] as String,
      name: json['name'] as String,
      audioBase64: json['audioBase64'] as String,
      mimeType: json['mimeType'] as String,
      source: VoiceProfileSource.values.firstWhere(
        (s) => s.name == json['source'],
        orElse: () => VoiceProfileSource.upload,
      ),
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'audioBase64': audioBase64,
      'mimeType': mimeType,
      'source': source.name,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [id, name, audioBase64, mimeType, source, createdAt];

  @override
  bool get stringify => true;
}

/// Sumber dari mana sampel audio rujukan diperoleh.
enum VoiceProfileSource {
  /// Direkod terus dalam aplikasi menggunakan mikrofon peranti.
  recorded,

  /// Dimuat naik daripada fail audio sedia ada (.mp3 / .wav).
  upload,
}

/// Satu hasil penjanaan suara klon (output audio yang telah disintesis).
class VoiceCloneResult extends Equatable {
  final String id;
  final String voiceProfileId;
  final String text;

  /// Laluan fail audio output yang telah disimpan pada peranti.
  final String outputFilePath;

  final DateTime createdAt;

  const VoiceCloneResult({
    required this.id,
    required this.voiceProfileId,
    required this.text,
    required this.outputFilePath,
    required this.createdAt,
  });

  factory VoiceCloneResult.fromJson(Map<String, dynamic> json) {
    return VoiceCloneResult(
      id: json['id'] as String,
      voiceProfileId: json['voiceProfileId'] as String,
      text: json['text'] as String,
      outputFilePath: json['outputFilePath'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'voiceProfileId': voiceProfileId,
      'text': text,
      'outputFilePath': outputFilePath,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [id, voiceProfileId, text, outputFilePath, createdAt];

  @override
  bool get stringify => true;
}
