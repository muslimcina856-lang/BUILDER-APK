import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../domain/entities/voice_profile.dart';
import '../bloc/voice_clone_bloc.dart';

/// Skrin penjanaan pertuturan menggunakan satu profil suara klon terpilih.
///
/// Pengguna menaip teks yang mahu disebut, boleh menambah arahan gaya
/// pertuturan pilihan, dan menjana audio. Hasil terkini boleh dimainkan
/// terus dalam skrin ini menggunakan pemain audio terbina-dalam.
class GenerateVoicePage extends StatefulWidget {
  final VoiceProfile profile;

  const GenerateVoicePage({super.key, required this.profile});

  @override
  State<GenerateVoicePage> createState() => _GenerateVoicePageState();
}

class _GenerateVoicePageState extends State<GenerateVoicePage> {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _styleController = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();

  bool _isPlaying = false;
  String? _currentlyPlayingPath;

  @override
  void initState() {
    super.initState();
    context.read<VoiceCloneBloc>().add(LoadVoiceProfiles());

    _audioPlayer.playerStateStream.listen((playerState) {
      if (!mounted) return;
      setState(() {
        _isPlaying = playerState.playing && playerState.processingState != ProcessingState.completed;
      });
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    _styleController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _handleGenerate() {
    final String text = _textController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sila masukkan teks yang mahu disebut.')),
      );
      return;
    }

    context.read<VoiceCloneBloc>().add(
          GenerateVoiceClone(
            profileId: widget.profile.id,
            text: text,
            styleInstruction: _styleController.text.trim(),
          ),
        );
  }

  Future<void> _playAudio(String filePath) async {
    try {
      if (_currentlyPlayingPath == filePath && _isPlaying) {
        await _audioPlayer.pause();
        return;
      }

      if (_currentlyPlayingPath != filePath) {
        await _audioPlayer.setFilePath(filePath);
        _currentlyPlayingPath = filePath;
      }

      await _audioPlayer.play();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memainkan audio: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  void _confirmDeleteResult(VoiceCloneResult result) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Padam Hasil Ini?'),
          content: const Text('Fail audio yang dijana akan dipadam secara kekal.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                context.read<VoiceCloneBloc>().add(
                      DeleteVoiceCloneResult(
                        resultId: result.id,
                        outputFilePath: result.outputFilePath,
                      ),
                    );
                Navigator.pop(dialogContext);
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Padam'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          tooltip: 'Kembali',
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          widget.profile.name,
          style: GoogleFonts.inter(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.scaffold.withOpacity(0.9),
                AppColors.scaffold.withOpacity(0.0),
              ],
            ),
          ),
        ),
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: BlocConsumer<VoiceCloneBloc, VoiceCloneState>(
            listener: (context, state) {
              if (state is VoiceCloneError) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(state.message), backgroundColor: AppColors.error),
                );
              } else if (state is VoiceCloneGenerated) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Suara klon berjaya dijana!'),
                    backgroundColor: AppColors.success,
                  ),
                );
              }
            },
            builder: (context, state) {
              bool isGenerating = false;
              List<VoiceCloneResult> results = [];

              if (state is VoiceProfilesLoaded) {
                isGenerating = state.isGenerating;
                results = state.results.where((r) => r.voiceProfileId == widget.profile.id).toList();
              }

              return ListView(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                children: [
                  TextField(
                    controller: _textController,
                    maxLines: 4,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'Teks Untuk Disebut',
                      hintText: 'Taip ayat yang mahu disebut menggunakan suara klon ini...',
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _styleController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'Arahan Gaya (Pilihan)',
                      hintText: 'cth: Sebut dengan nada gembira dan pantas...',
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: isGenerating ? null : _handleGenerate,
                      icon: isGenerating
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.auto_awesome_rounded),
                      label: Text(isGenerating ? 'Sedang Menjana...' : 'Jana Suara'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  if (results.isNotEmpty) ...[
                    Text(
                      'Hasil Terdahulu',
                      style: GoogleFonts.inter(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15),
                    ),
                    const SizedBox(height: 12),
                    ...results.map((result) => _buildResultCard(result)),
                  ],
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildResultCard(VoiceCloneResult result) {
    final bool isCurrentlyPlaying = _currentlyPlayingPath == result.outputFilePath && _isPlaying;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _playAudio(result.outputFilePath),
            child: Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                gradient: AppColors.accentGradient,
                shape: BoxShape.circle,
              ),
              child: Icon(
                isCurrentlyPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              result.text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 13),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.textMuted, size: 20),
            onPressed: () => _confirmDeleteResult(result),
          ),
        ],
      ),
    );
  }
}
