import 'dart:io';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

import '../../../../core/utils/mimo_api_client.dart';
import '../../../../core/utils/mimo_key_manager.dart';
import '../../../../services/database_service.dart';
import '../../../settings/domain/entities/mimo_api_key.dart';
import '../../domain/entities/voice_profile.dart';

// -----------------------------------------------------------------------------
// EVENTS
// -----------------------------------------------------------------------------
abstract class VoiceCloneEvent extends Equatable {
  const VoiceCloneEvent();
  @override
  List<Object?> get props => [];
}

class LoadVoiceProfiles extends VoiceCloneEvent {}

/// Menyimpan profil suara baharu daripada sampel audio (rakaman atau upload).
class SaveVoiceProfile extends VoiceCloneEvent {
  final String name;
  final String audioBase64;
  final String mimeType;
  final VoiceProfileSource source;

  const SaveVoiceProfile({
    required this.name,
    required this.audioBase64,
    required this.mimeType,
    required this.source,
  });

  @override
  List<Object?> get props => [name, audioBase64, mimeType, source];
}

class DeleteVoiceProfile extends VoiceCloneEvent {
  final String profileId;
  const DeleteVoiceProfile(this.profileId);
  @override
  List<Object?> get props => [profileId];
}

/// Menjana pertuturan baharu menggunakan profil suara yang dipilih.
class GenerateVoiceClone extends VoiceCloneEvent {
  final String profileId;
  final String text;
  final String styleInstruction;

  const GenerateVoiceClone({
    required this.profileId,
    required this.text,
    this.styleInstruction = '',
  });

  @override
  List<Object?> get props => [profileId, text, styleInstruction];
}

class DeleteVoiceCloneResult extends VoiceCloneEvent {
  final String resultId;
  final String outputFilePath;
  const DeleteVoiceCloneResult({required this.resultId, required this.outputFilePath});
  @override
  List<Object?> get props => [resultId, outputFilePath];
}

// -----------------------------------------------------------------------------
// STATES
// -----------------------------------------------------------------------------
abstract class VoiceCloneState extends Equatable {
  const VoiceCloneState();
  @override
  List<Object?> get props => [];
}

class VoiceCloneInitial extends VoiceCloneState {}

class VoiceProfilesLoaded extends VoiceCloneState {
  final List<VoiceProfile> profiles;
  final List<VoiceCloneResult> results;

  /// `true` semasa satu penjanaan suara sedang berjalan (menunjukkan
  /// indikator loading pada UI tanpa menyekat senarai sedia ada).
  final bool isGenerating;

  const VoiceProfilesLoaded({
    required this.profiles,
    required this.results,
    this.isGenerating = false,
  });

  VoiceProfilesLoaded copyWith({
    List<VoiceProfile>? profiles,
    List<VoiceCloneResult>? results,
    bool? isGenerating,
  }) {
    return VoiceProfilesLoaded(
      profiles: profiles ?? this.profiles,
      results: results ?? this.results,
      isGenerating: isGenerating ?? this.isGenerating,
    );
  }

  @override
  List<Object?> get props => [profiles, results, isGenerating];
}

class VoiceCloneError extends VoiceCloneState {
  final String message;
  const VoiceCloneError(this.message);
  @override
  List<Object?> get props => [message];
}

/// State transient yang dipancarkan sebaik penjanaan berjaya, supaya UI
/// boleh terus memainkan audio hasil tanpa menunggu senarai reload.
class VoiceCloneGenerated extends VoiceCloneState {
  final VoiceCloneResult result;
  const VoiceCloneGenerated(this.result);
  @override
  List<Object?> get props => [result];
}

// -----------------------------------------------------------------------------
// BLOC IMPLEMENTATION
// -----------------------------------------------------------------------------
class VoiceCloneBloc extends Bloc<VoiceCloneEvent, VoiceCloneState> {
  final DatabaseService _dbService;
  final MimoKeyManager _keyManager;
  final Uuid _uuid = const Uuid();

  VoiceCloneBloc({
    DatabaseService? dbService,
    MimoKeyManager? keyManager,
  })  : _dbService = dbService ?? DatabaseService(),
        _keyManager = keyManager ?? MimoKeyManager(),
        super(VoiceCloneInitial()) {
    on<LoadVoiceProfiles>(_onLoadVoiceProfiles);
    on<SaveVoiceProfile>(_onSaveVoiceProfile);
    on<DeleteVoiceProfile>(_onDeleteVoiceProfile);
    on<GenerateVoiceClone>(_onGenerateVoiceClone);
    on<DeleteVoiceCloneResult>(_onDeleteVoiceCloneResult);
  }

  Future<void> _onLoadVoiceProfiles(
      LoadVoiceProfiles event, Emitter<VoiceCloneState> emit) async {
    try {
      final List<VoiceProfile> profiles = await _loadProfiles();
      final List<VoiceCloneResult> results = await _loadResults();
      emit(VoiceProfilesLoaded(profiles: profiles, results: results));
    } catch (e) {
      emit(VoiceCloneError('Gagal memuatkan profil suara: $e'));
    }
  }

  Future<List<VoiceProfile>> _loadProfiles() async {
    final List<Map<String, dynamic>> rows = await _dbService.getAllVoiceProfiles();
    return rows.map((row) {
      final Map<String, dynamic> mapped = {
        'id': row['id'],
        'name': row['name'],
        'audioBase64': row['audio_base64'],
        'mimeType': row['mime_type'],
        'source': row['source'],
        'createdAt': row['created_at'],
      };
      return VoiceProfile.fromJson(mapped);
    }).toList();
  }

  Future<List<VoiceCloneResult>> _loadResults() async {
    final List<Map<String, dynamic>> rows = await _dbService.getAllVoiceCloneResults();
    return rows.map((row) {
      final Map<String, dynamic> mapped = {
        'id': row['id'],
        'voiceProfileId': row['voice_profile_id'],
        'text': row['text'],
        'outputFilePath': row['output_file_path'],
        'createdAt': row['created_at'],
      };
      return VoiceCloneResult.fromJson(mapped);
    }).toList();
  }

  Future<void> _onSaveVoiceProfile(
      SaveVoiceProfile event, Emitter<VoiceCloneState> emit) async {
    try {
      final VoiceProfile profile = VoiceProfile(
        id: _uuid.v4(),
        name: event.name,
        audioBase64: event.audioBase64,
        mimeType: event.mimeType,
        source: event.source,
        createdAt: DateTime.now(),
      );

      final Map<String, dynamic> row = {
        'id': profile.id,
        'name': profile.name,
        'audio_base64': profile.audioBase64,
        'mime_type': profile.mimeType,
        'source': profile.source.name,
        'created_at': profile.createdAt.toIso8601String(),
      };

      await _dbService.saveVoiceProfile(row);
      add(LoadVoiceProfiles());
    } catch (e) {
      emit(VoiceCloneError('Gagal menyimpan profil suara: $e'));
      add(LoadVoiceProfiles());
    }
  }

  Future<void> _onDeleteVoiceProfile(
      DeleteVoiceProfile event, Emitter<VoiceCloneState> emit) async {
    try {
      await _dbService.deleteVoiceProfile(event.profileId);
      add(LoadVoiceProfiles());
    } catch (e) {
      emit(VoiceCloneError('Gagal memadam profil suara: $e'));
      add(LoadVoiceProfiles());
    }
  }

  Future<void> _onGenerateVoiceClone(
      GenerateVoiceClone event, Emitter<VoiceCloneState> emit) async {
    final VoiceCloneState currentState = state;
    if (currentState is! VoiceProfilesLoaded) return;

    emit(currentState.copyWith(isGenerating: true));

    final VoiceProfile? profile = currentState.profiles
        .cast<VoiceProfile?>()
        .firstWhere((p) => p?.id == event.profileId, orElse: () => null);

    if (profile == null) {
      emit(const VoiceCloneError('Profil suara tidak dijumpai.'));
      add(LoadVoiceProfiles());
      return;
    }

    final MimoApiKey? keyToUse = await _keyManager.getNextKeyToUse();
    if (keyToUse == null) {
      emit(const VoiceCloneError(
        'Tiada Kunci API MiMo AI. Sila masukkan kunci API anda di Tetapan.',
      ));
      emit(currentState.copyWith(isGenerating: false));
      return;
    }

    final MimoApiClient client = MimoApiClient(apiKey: keyToUse.key);

    try {
      final List<int> audioBytes = await client.synthesizeVoiceClone(
        text: event.text,
        referenceAudioBase64: profile.audioBase64,
        referenceMimeType: profile.mimeType,
        styleInstruction: event.styleInstruction,
      );

      await _keyManager.recordSuccess(keyToUse.id);

      // Simpan audio output ke fail dalam direktori dokumen aplikasi.
      final Directory appDir = await getApplicationDocumentsDirectory();
      final Directory voiceDir = Directory('${appDir.path}/voice_clone_outputs');
      if (!await voiceDir.exists()) {
        await voiceDir.create(recursive: true);
      }

      final String resultId = _uuid.v4();
      final String outputPath = '${voiceDir.path}/$resultId.wav';
      final File outputFile = File(outputPath);
      await outputFile.writeAsBytes(audioBytes);

      final VoiceCloneResult result = VoiceCloneResult(
        id: resultId,
        voiceProfileId: event.profileId,
        text: event.text,
        outputFilePath: outputPath,
        createdAt: DateTime.now(),
      );

      final Map<String, dynamic> row = {
        'id': result.id,
        'voice_profile_id': result.voiceProfileId,
        'text': result.text,
        'output_file_path': result.outputFilePath,
        'created_at': result.createdAt.toIso8601String(),
      };

      await _dbService.saveVoiceCloneResult(row);

      emit(VoiceCloneGenerated(result));

      final List<VoiceProfile> profiles = await _loadProfiles();
      final List<VoiceCloneResult> results = await _loadResults();
      emit(VoiceProfilesLoaded(profiles: profiles, results: results, isGenerating: false));
    } on MimoVoiceCloneException catch (e) {
      await _keyManager.recordFailure(keyId: keyToUse.id, errorReason: e.message);
      emit(VoiceCloneError(e.message));
      add(LoadVoiceProfiles());
    } catch (e) {
      await _keyManager.recordFailure(keyId: keyToUse.id, errorReason: e.toString());
      emit(VoiceCloneError('Ralat menjana suara klon: $e'));
      add(LoadVoiceProfiles());
    } finally {
      client.dispose();
    }
  }

  Future<void> _onDeleteVoiceCloneResult(
      DeleteVoiceCloneResult event, Emitter<VoiceCloneState> emit) async {
    try {
      final Database db = await _dbService.database;
      await db.delete(
        'voice_clone_results',
        where: 'id = ?',
        whereArgs: <dynamic>[event.resultId],
      );

      final File outputFile = File(event.outputFilePath);
      if (await outputFile.exists()) {
        await outputFile.delete();
      }

      add(LoadVoiceProfiles());
    } catch (e) {
      emit(VoiceCloneError('Gagal memadam hasil: $e'));
      add(LoadVoiceProfiles());
    }
  }
}
