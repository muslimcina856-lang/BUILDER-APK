import 'package:equatable/equatable.dart';

/// Status semasa satu kunci API MiMo.
enum MimoKeyStatus {
  /// Kunci sedia digunakan, belum pernah gagal (atau sudah pulih).
  active,

  /// Kunci gagal (credit habis / ralat berulang) tetapi masih disimpan
  /// dengan penanda, mengikut pilihan `onErrorAction = keep`.
  error,
}

/// Tindakan yang diambil apabila satu kunci API gagal (credit habis /
/// ralat berterusan): sama ada dipadam terus, atau disimpan dengan
/// penanda supaya senang dikenal pasti.
enum KeyErrorAction {
  /// Padam kunci daripada senarai secara automatik apabila ia gagal.
  autoDelete,

  /// Simpan kunci dalam senarai dengan penanda ralat (status = error).
  keepWithMarker,
}

/// Satu slot kunci API MiMo AI dalam senarai fallback pengguna.
///
/// Pengguna boleh mendaftar berbilang kunci (dilabel 1, 2, 3, ...).
/// Apabila satu kunci gagal berulang kali, sistem beralih (fallback)
/// ke kunci seterusnya secara automatik mengikut `order`.
class MimoApiKey extends Equatable {
  final String id;

  /// Kedudukan kunci dalam urutan fallback (1-based). Dipaparkan sebagai
  /// label "1", "2", "3", dst. dan menentukan urutan cubaan semula/fallback.
  final int order;

  final String key;

  final MimoKeyStatus status;

  /// Bilangan kegagalan berturut-turut sejak kali terakhir berjaya.
  /// Reset ke 0 apabila kunci berjaya digunakan.
  final int consecutiveFailures;

  /// Mesej ringkas sebab kegagalan terakhir (untuk paparan tap-untuk-lihat
  /// pada ikon amaran). `null` jika tiada kegagalan direkodkan.
  final String? lastErrorReason;

  final DateTime? lastErrorAt;

  const MimoApiKey({
    required this.id,
    required this.order,
    required this.key,
    this.status = MimoKeyStatus.active,
    this.consecutiveFailures = 0,
    this.lastErrorReason,
    this.lastErrorAt,
  });

  /// Label paparan untuk kunci ini, contoh "Kunci 1", "Kunci 2".
  String get label => 'Kunci $order';

  /// Versi topeng kunci untuk paparan selamat, cth "sk-mimo...ab12".
  String get maskedKey {
    if (key.length <= 10) return '••••••••';
    return '${key.substring(0, 6)}...${key.substring(key.length - 4)}';
  }

  MimoApiKey copyWith({
    String? id,
    int? order,
    String? key,
    MimoKeyStatus? status,
    int? consecutiveFailures,
    String? lastErrorReason,
    DateTime? lastErrorAt,
    bool clearLastError = false,
  }) {
    return MimoApiKey(
      id: id ?? this.id,
      order: order ?? this.order,
      key: key ?? this.key,
      status: status ?? this.status,
      consecutiveFailures: consecutiveFailures ?? this.consecutiveFailures,
      lastErrorReason:
          clearLastError ? null : (lastErrorReason ?? this.lastErrorReason),
      lastErrorAt: clearLastError ? null : (lastErrorAt ?? this.lastErrorAt),
    );
  }

  factory MimoApiKey.fromJson(Map<String, dynamic> json) {
    return MimoApiKey(
      id: json['id'] as String,
      order: json['order'] as int,
      key: json['key'] as String,
      status: MimoKeyStatus.values.firstWhere(
        (s) => s.name == json['status'],
        orElse: () => MimoKeyStatus.active,
      ),
      consecutiveFailures: json['consecutiveFailures'] as int? ?? 0,
      lastErrorReason: json['lastErrorReason'] as String?,
      lastErrorAt: json['lastErrorAt'] != null
          ? DateTime.tryParse(json['lastErrorAt'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'order': order,
      'key': key,
      'status': status.name,
      'consecutiveFailures': consecutiveFailures,
      'lastErrorReason': lastErrorReason,
      'lastErrorAt': lastErrorAt?.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [
        id,
        order,
        key,
        status,
        consecutiveFailures,
        lastErrorReason,
        lastErrorAt,
      ];

  @override
  bool get stringify => true;
}
