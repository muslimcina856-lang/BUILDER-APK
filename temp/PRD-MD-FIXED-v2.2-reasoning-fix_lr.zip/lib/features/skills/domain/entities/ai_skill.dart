import 'package:equatable/equatable.dart';

/// Entiti kemahiran AI (AI Skill) yang menentukan peranan sistem prompt.
class AISkill extends Equatable {
  final String id;
  final String name;
  final String instruction;
  final bool isDefault;
  final bool isActive;

  const AISkill({
    required this.id,
    required this.name,
    required this.instruction,
    this.isDefault = false,
    this.isActive = false,
  });

  /// Buat salinan dengan nilai yang dikemaskini.
  AISkill copyWith({
    String? id,
    String? name,
    String? instruction,
    bool? isDefault,
    bool? isActive,
  }) {
    return AISkill(
      id: id ?? this.id,
      name: name ?? this.name,
      instruction: instruction ?? this.instruction,
      isDefault: isDefault ?? this.isDefault,
      isActive: isActive ?? this.isActive,
    );
  }

  /// Membina daripada Map (untuk pangkalan data).
  factory AISkill.fromMap(Map<String, dynamic> map) {
    return AISkill(
      id: map['id'] as String,
      name: map['name'] as String,
      instruction: map['instruction'] as String,
      isDefault: (map['isDefault'] as int) == 1,
      isActive: (map['isActive'] as int) == 1,
    );
  }

  /// Menukar entiti ke Map untuk disimpan di pangkalan data.
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'instruction': instruction,
      'isDefault': isDefault ? 1 : 0,
      'isActive': isActive ? 1 : 0,
    };
  }

  @override
  List<Object?> get props => [id, name, instruction, isDefault, isActive];

  @override
  bool get stringify => true;
}
