import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Singleton SQLite database service for the PRD MD app.
///
/// Manages tables: settings, ai_skills, chat_sessions, messages,
/// session_skills junction table, voice_profiles, and voice_clone_results.
class DatabaseService {
  static const String _dbName = 'prd_md.db';
  static const int _dbVersion = 3;

  // Singleton
  DatabaseService._internal();
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;

  Database? _db;

  /// Returns the initialised database instance, creating it if needed.
  Future<Database> get database async {
    if (_db != null && _db!.isOpen) return _db!;
    _db = await _initDatabase();
    return _db!;
  }

  Future<Database> _initDatabase() async {
    final String dbPath = join(await getDatabasesPath(), _dbName);
    return openDatabase(
      dbPath,
      version: _dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
      onConfigure: (Database db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
    );
  }

  // ---------------------------------------------------------------------------
  // Schema
  // ---------------------------------------------------------------------------

  Future<void> _onCreate(Database db, int version) async {
    final Batch batch = db.batch();

    batch.execute('''
      CREATE TABLE settings (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE ai_skills (
        id            TEXT PRIMARY KEY,
        name          TEXT NOT NULL,
        description   TEXT NOT NULL DEFAULT '',
        system_prompt TEXT NOT NULL,
        icon          TEXT NOT NULL DEFAULT 'psychology',
        color         INTEGER NOT NULL DEFAULT 0xFF6C63FF,
        is_default    INTEGER NOT NULL DEFAULT 0,
        is_active     INTEGER NOT NULL DEFAULT 1,
        created_at    TEXT NOT NULL,
        updated_at    TEXT NOT NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE chat_sessions (
        id         TEXT PRIMARY KEY,
        title      TEXT NOT NULL,
        model      TEXT NOT NULL DEFAULT 'mimo-v2.5',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE messages (
        id                  TEXT PRIMARY KEY,
        session_id          TEXT NOT NULL,
        role                TEXT NOT NULL,
        content             TEXT NOT NULL,
        contains_form       INTEGER NOT NULL DEFAULT 0,
        raw_form_json       TEXT,
        is_form_submitted   INTEGER NOT NULL DEFAULT 0,
        created_at          TEXT NOT NULL,
        reasoning_content   TEXT,
        FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
      )
    ''');

    batch.execute('''
      CREATE TABLE session_skills (
        session_id TEXT NOT NULL,
        skill_id   TEXT NOT NULL,
        PRIMARY KEY (session_id, skill_id),
        FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
        FOREIGN KEY (skill_id)   REFERENCES ai_skills(id)     ON DELETE CASCADE
      )
    ''');

    batch.execute('''
      CREATE TABLE voice_profiles (
        id            TEXT PRIMARY KEY,
        name          TEXT NOT NULL,
        audio_base64  TEXT NOT NULL,
        mime_type     TEXT NOT NULL,
        source        TEXT NOT NULL DEFAULT 'upload',
        created_at    TEXT NOT NULL
      )
    ''');

    batch.execute('''
      CREATE TABLE voice_clone_results (
        id                TEXT PRIMARY KEY,
        voice_profile_id  TEXT NOT NULL,
        text              TEXT NOT NULL,
        output_file_path  TEXT NOT NULL,
        created_at        TEXT NOT NULL,
        FOREIGN KEY (voice_profile_id) REFERENCES voice_profiles(id) ON DELETE CASCADE
      )
    ''');

    // Indexes for common queries.
    batch.execute(
        'CREATE INDEX idx_messages_session ON messages(session_id)');
    batch.execute(
        'CREATE INDEX idx_sessions_updated ON chat_sessions(updated_at DESC)');
    batch.execute(
        'CREATE INDEX idx_skills_default ON ai_skills(is_default)');
    batch.execute(
        'CREATE INDEX idx_voice_results_profile ON voice_clone_results(voice_profile_id)');

    await batch.commit(noResult: true);
  }

  Future<void> _onUpgrade(
      Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      // Menambah sokongan Klon Suara (Voice Clone) untuk pengguna sedia ada
      // yang meningkatkan (upgrade) daripada skema versi 1.
      await db.execute('''
        CREATE TABLE IF NOT EXISTS voice_profiles (
          id            TEXT PRIMARY KEY,
          name          TEXT NOT NULL,
          audio_base64  TEXT NOT NULL,
          mime_type     TEXT NOT NULL,
          source        TEXT NOT NULL DEFAULT 'upload',
          created_at    TEXT NOT NULL
        )
      ''');

      await db.execute('''
        CREATE TABLE IF NOT EXISTS voice_clone_results (
          id                TEXT PRIMARY KEY,
          voice_profile_id  TEXT NOT NULL,
          text              TEXT NOT NULL,
          output_file_path  TEXT NOT NULL,
          created_at        TEXT NOT NULL,
          FOREIGN KEY (voice_profile_id) REFERENCES voice_profiles(id) ON DELETE CASCADE
        )
      ''');

      await db.execute(
          'CREATE INDEX IF NOT EXISTS idx_voice_results_profile ON voice_clone_results(voice_profile_id)');
    }

    if (oldVersion < 3) {
      // Menambah lajur reasoning_content untuk menyimpan teks penaakulan
      // (reasoning) model MiMo berasingan daripada content, supaya ia
      // tidak terpapar sebagai sebahagian mesej utama kepada pengguna.
      await db.execute(
          'ALTER TABLE messages ADD COLUMN reasoning_content TEXT');
    }
  }

  // ---------------------------------------------------------------------------
  // Chat Sessions – CRUD
  // ---------------------------------------------------------------------------

  /// Creates a new chat session and returns its ID.
  Future<String> createSession({
    required String id,
    required String title,
    String model = 'mimo-v2.5',
  }) async {
    final Database db = await database;
    final String now = DateTime.now().toUtc().toIso8601String();

    await db.insert('chat_sessions', <String, dynamic>{
      'id': id,
      'title': title,
      'model': model,
      'created_at': now,
      'updated_at': now,
    });

    return id;
  }

  /// Returns all chat sessions ordered by [updated_at] descending.
  Future<List<Map<String, dynamic>>> getAllSessions() async {
    final Database db = await database;
    return db.query(
      'chat_sessions',
      orderBy: 'updated_at DESC',
    );
  }

  /// Returns a single session by [id], or `null` if not found.
  Future<Map<String, dynamic>?> getSessionById(String id) async {
    final Database db = await database;
    final List<Map<String, dynamic>> rows = await db.query(
      'chat_sessions',
      where: 'id = ?',
      whereArgs: <dynamic>[id],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  /// Updates the title (and [updated_at]) of a session.
  Future<int> updateSessionTitle(String id, String newTitle) async {
    final Database db = await database;
    return db.update(
      'chat_sessions',
      <String, dynamic>{
        'title': newTitle,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  /// Touches [updated_at] for a session (e.g. when a new message is added).
  Future<int> touchSession(String id) async {
    final Database db = await database;
    return db.update(
      'chat_sessions',
      <String, dynamic>{
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  /// Deletes a session and its messages (via CASCADE).
  Future<int> deleteSession(String id) async {
    final Database db = await database;
    return db.delete(
      'chat_sessions',
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  /// Deletes all sessions (and all related messages + skill links).
  Future<int> deleteAllSessions() async {
    final Database db = await database;
    return db.delete('chat_sessions');
  }

  /// Searches sessions whose title contains [query] (case-insensitive).
  Future<List<Map<String, dynamic>>> searchSessions(String query) async {
    final Database db = await database;
    return db.query(
      'chat_sessions',
      where: 'title LIKE ?',
      whereArgs: <dynamic>['%$query%'],
      orderBy: 'updated_at DESC',
    );
  }

  // ---------------------------------------------------------------------------
  // Messages – CRUD
  // ---------------------------------------------------------------------------

  /// Creates a new message in a session.
  Future<String> createMessage({
    required String id,
    required String sessionId,
    required String role,
    required String content,
  }) async {
    final Database db = await database;
    final String now = DateTime.now().toUtc().toIso8601String();

    await db.insert('messages', <String, dynamic>{
      'id': id,
      'session_id': sessionId,
      'role': role,
      'content': content,
      'created_at': now,
    });

    // Touch the parent session.
    await touchSession(sessionId);

    return id;
  }

  /// Returns all messages for a session ordered by creation time.
  Future<List<Map<String, dynamic>>> getMessagesBySessionId(
      String sessionId) async {
    final Database db = await database;
    return db.query(
      'messages',
      where: 'session_id = ?',
      whereArgs: <dynamic>[sessionId],
      orderBy: 'created_at ASC',
    );
  }

  /// Deletes all messages belonging to a session.
  Future<int> deleteMessagesBySession(String sessionId) async {
    final Database db = await database;
    return db.delete(
      'messages',
      where: 'session_id = ?',
      whereArgs: <dynamic>[sessionId],
    );
  }

  // ---------------------------------------------------------------------------
  // AI Skills – CRUD
  // ---------------------------------------------------------------------------

  /// Creates a new AI skill.
  Future<String> createSkill({
    required String id,
    required String name,
    required String description,
    required String systemPrompt,
    String icon = 'psychology',
    int color = 0xFF6C63FF,
    bool isDefault = false,
    bool isActive = true,
  }) async {
    final Database db = await database;
    final String now = DateTime.now().toUtc().toIso8601String();

    await db.insert('ai_skills', <String, dynamic>{
      'id': id,
      'name': name,
      'description': description,
      'system_prompt': systemPrompt,
      'icon': icon,
      'color': color,
      'is_default': isDefault ? 1 : 0,
      'is_active': isActive ? 1 : 0,
      'created_at': now,
      'updated_at': now,
    });

    return id;
  }

  /// Returns all skills.
  Future<List<Map<String, dynamic>>> getAllSkills() async {
    final Database db = await database;
    return db.query('ai_skills', orderBy: 'name ASC');
  }

  /// Returns only default (built-in) skills.
  Future<List<Map<String, dynamic>>> getDefaultSkills() async {
    final Database db = await database;
    return db.query(
      'ai_skills',
      where: 'is_default = ?',
      whereArgs: <dynamic>[1],
      orderBy: 'name ASC',
    );
  }

  /// Returns only custom (user-created) skills.
  Future<List<Map<String, dynamic>>> getCustomSkills() async {
    final Database db = await database;
    return db.query(
      'ai_skills',
      where: 'is_default = ?',
      whereArgs: <dynamic>[0],
      orderBy: 'name ASC',
    );
  }

  /// Returns a skill by [id], or `null`.
  Future<Map<String, dynamic>?> getSkillById(String id) async {
    final Database db = await database;
    final List<Map<String, dynamic>> rows = await db.query(
      'ai_skills',
      where: 'id = ?',
      whereArgs: <dynamic>[id],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  /// Updates a skill's editable fields.
  Future<int> updateSkill({
    required String id,
    String? name,
    String? description,
    String? systemPrompt,
    String? icon,
    int? color,
    bool? isActive,
  }) async {
    final Database db = await database;
    final Map<String, dynamic> updates = <String, dynamic>{
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };

    if (name != null) updates['name'] = name;
    if (description != null) updates['description'] = description;
    if (systemPrompt != null) updates['system_prompt'] = systemPrompt;
    if (icon != null) updates['icon'] = icon;
    if (color != null) updates['color'] = color;
    if (isActive != null) updates['is_active'] = isActive ? 1 : 0;

    return db.update(
      'ai_skills',
      updates,
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  /// Deletes a skill by [id].
  Future<int> deleteSkill(String id) async {
    final Database db = await database;
    return db.delete(
      'ai_skills',
      where: 'id = ?',
      whereArgs: <dynamic>[id],
    );
  }

  /// Returns skills linked to a specific session.
  Future<List<Map<String, dynamic>>> getActiveSkillsForSession(
      String sessionId) async {
    final Database db = await database;
    return db.rawQuery('''
      SELECT s.*
      FROM ai_skills s
      INNER JOIN session_skills ss ON s.id = ss.skill_id
      WHERE ss.session_id = ?
      ORDER BY s.name ASC
    ''', <dynamic>[sessionId]);
  }

  // ---------------------------------------------------------------------------
  // Session–Skill Junction
  // ---------------------------------------------------------------------------

  /// Links a skill to a session.
  Future<void> linkSkillToSession(
      String sessionId, String skillId) async {
    final Database db = await database;
    await db.insert(
      'session_skills',
      <String, dynamic>{
        'session_id': sessionId,
        'skill_id': skillId,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  /// Links multiple skills to a session in a single batch.
  Future<void> linkSkillsToSession(
      String sessionId, List<String> skillIds) async {
    final Database db = await database;
    final Batch batch = db.batch();
    for (final String skillId in skillIds) {
      batch.insert(
        'session_skills',
        <String, dynamic>{
          'session_id': sessionId,
          'skill_id': skillId,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    await batch.commit(noResult: true);
  }

  /// Removes a skill–session link.
  Future<int> unlinkSkillFromSession(
      String sessionId, String skillId) async {
    final Database db = await database;
    return db.delete(
      'session_skills',
      where: 'session_id = ? AND skill_id = ?',
      whereArgs: <dynamic>[sessionId, skillId],
    );
  }

  /// Removes all skill links for a session.
  Future<int> unlinkAllSkillsFromSession(String sessionId) async {
    final Database db = await database;
    return db.delete(
      'session_skills',
      where: 'session_id = ?',
      whereArgs: <dynamic>[sessionId],
    );
  }

  // ---------------------------------------------------------------------------
  // Settings – Key-Value
  // ---------------------------------------------------------------------------

  /// Saves a setting (upsert).
  Future<void> saveSetting(String key, String value) async {
    final Database db = await database;
    await db.insert(
      'settings',
      <String, dynamic>{'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Retrieves a setting by [key], or [defaultValue] if not found.
  Future<String?> getSetting(String key, {String? defaultValue}) async {
    final Database db = await database;
    final List<Map<String, dynamic>> rows = await db.query(
      'settings',
      where: 'key = ?',
      whereArgs: <dynamic>[key],
      limit: 1,
    );

    if (rows.isEmpty) return defaultValue;
    return (rows.first['value'] as String?) ?? defaultValue;
  }

  /// Returns all settings as a key-value map.
  Future<Map<String, String>> getAllSettings() async {
    final Database db = await database;
    final List<Map<String, dynamic>> rows = await db.query('settings');

    final Map<String, String> settings = <String, String>{};
    for (final Map<String, dynamic> row in rows) {
      final String key = row['key'] as String;
      final String value = row['value'] as String;
      settings[key] = value;
    }
    return settings;
  }

  /// Deletes a setting.
  Future<int> deleteSetting(String key) async {
    final Database db = await database;
    return db.delete(
      'settings',
      where: 'key = ?',
      whereArgs: <dynamic>[key],
    );
  }

  // ---------------------------------------------------------------------------
  // Voice Profiles (Klon Suara) – CRUD
  // ---------------------------------------------------------------------------

  /// Menyimpan satu profil suara baharu.
  Future<void> saveVoiceProfile(Map<String, dynamic> profileMap) async {
    final Database db = await database;
    await db.insert(
      'voice_profiles',
      profileMap,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Mendapatkan semua profil suara tersimpan, tersusun mengikut yang
  /// terbaharu dahulu.
  Future<List<Map<String, dynamic>>> getAllVoiceProfiles() async {
    final Database db = await database;
    return db.query('voice_profiles', orderBy: 'created_at DESC');
  }

  /// Memadam satu profil suara mengikut id. Turut memadam semua hasil
  /// penjanaan yang berkaitan (ON DELETE CASCADE).
  Future<int> deleteVoiceProfile(String id) async {
    final Database db = await database;
    return db.delete('voice_profiles', where: 'id = ?', whereArgs: <dynamic>[id]);
  }

  // ---------------------------------------------------------------------------
  // Voice Clone Results – CRUD
  // ---------------------------------------------------------------------------

  /// Menyimpan satu rekod hasil penjanaan suara klon.
  Future<void> saveVoiceCloneResult(Map<String, dynamic> resultMap) async {
    final Database db = await database;
    await db.insert(
      'voice_clone_results',
      resultMap,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Mendapatkan semua hasil penjanaan bagi satu profil suara tertentu,
  /// tersusun mengikut yang terbaharu dahulu.
  Future<List<Map<String, dynamic>>> getVoiceCloneResultsForProfile(
      String voiceProfileId) async {
    final Database db = await database;
    return db.query(
      'voice_clone_results',
      where: 'voice_profile_id = ?',
      whereArgs: <dynamic>[voiceProfileId],
      orderBy: 'created_at DESC',
    );
  }

  /// Mendapatkan semua hasil penjanaan suara klon merentasi semua profil.
  Future<List<Map<String, dynamic>>> getAllVoiceCloneResults() async {
    final Database db = await database;
    return db.query('voice_clone_results', orderBy: 'created_at DESC');
  }

  // ---------------------------------------------------------------------------
  // Lifecycle
  // ---------------------------------------------------------------------------

  /// Closes the database connection.
  Future<void> close() async {
    final Database? db = _db;
    if (db != null && db.isOpen) {
      await db.close();
      _db = null;
    }
  }
}
