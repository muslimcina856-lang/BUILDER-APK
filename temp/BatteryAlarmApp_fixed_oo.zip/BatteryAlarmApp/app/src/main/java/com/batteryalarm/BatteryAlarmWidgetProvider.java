package com.batteryalarm;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.widget.RemoteViews;

public class BatteryAlarmWidgetProvider extends AppWidgetProvider {

    private static final String PREFS_NAME = "battery_alarm_prefs";
    private static final String KEY_THRESHOLD = "threshold";
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_RINGTONE_URI = "ringtone_uri";

    private static final int MIN_THRESHOLD = 10;
    private static final int MAX_THRESHOLD = 100;
    private static final int STEP = 5;

    public static final String ACTION_TOGGLE = "com.batteryalarm.widget.ACTION_TOGGLE";
    public static final String ACTION_INCREASE = "com.batteryalarm.widget.ACTION_INCREASE";
    public static final String ACTION_DECREASE = "com.batteryalarm.widget.ACTION_DECREASE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // First placement / periodic refresh - no action was just taken, so it's safe to read
        // the live service state directly here.
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int threshold = prefs.getInt(KEY_THRESHOLD, 80);
        boolean running = BatteryAlarmService.isRunning();
        for (int appWidgetId : appWidgetIds) {
            pushWidgetViews(context, appWidgetManager, appWidgetId, threshold, running);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();
        if (action == null) return;

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int threshold = prefs.getInt(KEY_THRESHOLD, 80);
        boolean running = prefs.getBoolean(KEY_SERVICE_RUNNING, false);

        if (ACTION_TOGGLE.equals(action)) {
            running = !running;
            if (running) {
                Intent serviceIntent = new Intent(context, BatteryAlarmService.class);
                serviceIntent.putExtra("threshold", threshold);
                String ringtoneUriStr = prefs.getString(KEY_RINGTONE_URI, null);
                if (ringtoneUriStr != null) {
                    serviceIntent.putExtra("ringtone_uri", ringtoneUriStr);
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            } else {
                context.stopService(new Intent(context, BatteryAlarmService.class));
            }
            prefs.edit().putBoolean(KEY_SERVICE_RUNNING, running).apply();
            // Reflects the action just taken rather than re-reading BatteryAlarmService.isRunning()
            // immediately afterward - startForegroundService()/stopService() are both async, so
            // that flag wouldn't have updated yet. Same race as the double-tap switch bug in
            // MainActivity, fixed the same way here.
        } else if (ACTION_INCREASE.equals(action) || ACTION_DECREASE.equals(action)) {
            int delta = ACTION_INCREASE.equals(action) ? STEP : -STEP;
            threshold = Math.max(MIN_THRESHOLD, Math.min(MAX_THRESHOLD, threshold + delta));
            prefs.edit().putInt(KEY_THRESHOLD, threshold).apply();

            if (running) {
                Intent serviceIntent = new Intent(context, BatteryAlarmService.class);
                serviceIntent.putExtra("threshold", threshold);
                String ringtoneUriStr = prefs.getString(KEY_RINGTONE_URI, null);
                if (ringtoneUriStr != null) {
                    serviceIntent.putExtra("ringtone_uri", ringtoneUriStr);
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            }
        } else {
            return;
        }

        refreshAllWidgets(context, threshold, running);
    }

    // Called from MainActivity too (after it starts/stops monitoring or changes the threshold),
    // so a widget on the home screen doesn't go stale until its next periodic update.
    public static void refreshAllWidgets(Context context, int threshold, boolean running) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName thisWidget = new ComponentName(context, BatteryAlarmWidgetProvider.class);
        int[] ids = appWidgetManager.getAppWidgetIds(thisWidget);
        for (int id : ids) {
            pushWidgetViews(context, appWidgetManager, id, threshold, running);
        }
    }

    private static void pushWidgetViews(Context context, AppWidgetManager appWidgetManager,
                                         int appWidgetId, int threshold, boolean running) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_battery_alarm);
        views.setTextViewText(R.id.widget_threshold_value, threshold + "%");
        views.setTextViewText(R.id.widget_status, running ? "Status: Monitoring" : "Status: Stopped");
        views.setTextViewText(R.id.widget_btn_toggle, running ? "Turn Off" : "Turn On");

        views.setOnClickPendingIntent(R.id.widget_btn_toggle, actionPendingIntent(context, ACTION_TOGGLE));
        views.setOnClickPendingIntent(R.id.widget_btn_plus, actionPendingIntent(context, ACTION_INCREASE));
        views.setOnClickPendingIntent(R.id.widget_btn_minus, actionPendingIntent(context, ACTION_DECREASE));

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static PendingIntent actionPendingIntent(Context context, String action) {
        Intent intent = new Intent(context, BatteryAlarmWidgetProvider.class);
        intent.setAction(action);
        return PendingIntent.getBroadcast(
            context, action.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }
}
