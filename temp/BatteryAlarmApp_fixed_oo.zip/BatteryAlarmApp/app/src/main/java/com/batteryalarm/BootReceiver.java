package com.batteryalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {

    private static final String PREFS_NAME = "battery_alarm_prefs";
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_THRESHOLD = "threshold";
    private static final String KEY_RINGTONE_URI = "ringtone_uri";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            boolean wasRunning = prefs.getBoolean(KEY_SERVICE_RUNNING, false);

            if (wasRunning) {
                int threshold = prefs.getInt(KEY_THRESHOLD, 80);
                String ringtoneUri = prefs.getString(KEY_RINGTONE_URI, null);

                Intent serviceIntent = new Intent(context, BatteryAlarmService.class);
                serviceIntent.putExtra("threshold", threshold);
                if (ringtoneUri != null) {
                    serviceIntent.putExtra("ringtone_uri", ringtoneUri);
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            }
        }
    }
}
