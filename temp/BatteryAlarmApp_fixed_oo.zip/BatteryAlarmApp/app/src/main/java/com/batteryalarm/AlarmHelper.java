package com.batteryalarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

import androidx.core.app.NotificationCompat;

public class AlarmHelper {

    private static final String CHANNEL_ALARM_ID = "battery_alarm_alert";
    private static final String PREFS_NAME = "battery_alarm_prefs";
    private static final String KEY_ALARM_PLAYING = "alarm_playing";

    private static final long LOOP_CHECK_INTERVAL_MS = 500;

    private static Ringtone ringtone;
    private static Handler loopHandler;
    private static Runnable loopRunnable;
    private static boolean alarmActive = false;

    public static void startAlarm(Context context, Uri ringtoneUri, int threshold) {
        if (alarmActive) return;
        alarmActive = true;
        saveAlarmState(context, true);

        Uri effectiveUri = ringtoneUri != null
            ? ringtoneUri
            : RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

        showAlarmNotification(context, effectiveUri, threshold);
        playSound(context, effectiveUri);
        vibrate(context);
    }

    public static void stopAlarm(Context context) {
        alarmActive = false;
        saveAlarmState(context, false);

        stopSound();
        cancelVibration(context);

        NotificationManager manager =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.cancel(2);
        }
    }

    public static boolean isAlarmActive() {
        return alarmActive;
    }

    // Uses android.media.Ringtone instead of a raw MediaPlayer. A ringtone picked from the
    // device's own music/downloads comes back as a content://media/external/... Uri, which
    // MediaPlayer can only open directly if the app holds READ_MEDIA_AUDIO / READ_EXTERNAL_STORAGE.
    // Ringtone doesn't need that permission: if it can't read the file itself, it quietly asks
    // the system's own ringtone player to play it instead. That's why a picked ringtone produced
    // no sound (only the vibration ran) while a built-in system tone happened to still work.
    private static void playSound(Context context, Uri ringtoneUri) {
        stopSound();

        ringtone = RingtoneManager.getRingtone(context, ringtoneUri);
        if (ringtone == null) {
            return;
        }

        ringtone.setAudioAttributes(new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build());

        try {
            ringtone.play();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        // Ringtone has no cross-version loop flag (setLooping() only exists from API 28), so
        // it's kept sounding by restarting it whenever it finishes, for as long as the alarm
        // is active. This is what makes it ring continuously until dismissed, or until the
        // battery drops back below the threshold.
        if (loopHandler == null) {
            loopHandler = new Handler(Looper.getMainLooper());
        }
        loopRunnable = new Runnable() {
            @Override
            public void run() {
                if (!alarmActive || ringtone == null) return;
                if (!ringtone.isPlaying()) {
                    ringtone.play();
                }
                loopHandler.postDelayed(this, LOOP_CHECK_INTERVAL_MS);
            }
        };
        loopHandler.postDelayed(loopRunnable, LOOP_CHECK_INTERVAL_MS);
    }

    private static void stopSound() {
        if (loopHandler != null && loopRunnable != null) {
            loopHandler.removeCallbacks(loopRunnable);
        }
        loopRunnable = null;

        if (ringtone != null) {
            try {
                if (ringtone.isPlaying()) {
                    ringtone.stop();
                }
            } catch (Exception ignored) {}
            ringtone = null;
        }
    }

    private static void vibrate(Context context) {
        Vibrator vibrator = getVibrator(context);
        if (vibrator != null && vibrator.hasVibrator()) {
            long[] pattern = {0, 500, 500, 500, 500, 500};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 1));
            } else {
                vibrator.vibrate(pattern, 1);
            }
        }
    }

    // The repeat index (1, not -1) in vibrate() above makes the device buzz indefinitely until
    // something explicitly cancels it - nothing did, anywhere in this file, which is why
    // vibration kept going even after the ringtone had already stopped and the status said
    // Stopped. Vibrator.cancel() stops whatever this app is currently vibrating, regardless of
    // which Vibrator instance requested it, so this doesn't need to be the same object vibrate()
    // used.
    private static void cancelVibration(Context context) {
        Vibrator vibrator = getVibrator(context);
        if (vibrator != null) {
            vibrator.cancel();
        }
    }

    private static Vibrator getVibrator(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm =
                (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            return vm != null ? vm.getDefaultVibrator() : null;
        } else {
            return (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        }
    }

    private static void showAlarmNotification(Context context, Uri ringtoneUri, int threshold) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ALARM_ID,
                "Battery Alarm Alert",
                NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Alert when battery reaches threshold");
            channel.enableVibration(true);
            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
            channel.setSound(null, attrs);

            NotificationManager manager =
                context.getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Intent dismissIntent = new Intent(context, AlarmDismissReceiver.class);
        PendingIntent dismissPendingIntent = PendingIntent.getBroadcast(
            context, 0, dismissIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentPendingIntent = PendingIntent.getActivity(
            context, 0, launchIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ALARM_ID)
            .setContentTitle("Battery Full!")
            .setContentText("Battery has reached " + threshold + "% threshold")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(contentPendingIntent, true)
            .addAction(android.R.drawable.ic_media_pause, "Dismiss", dismissPendingIntent)
            .setAutoCancel(false)
            .setOngoing(true)
            .build();

        NotificationManager manager =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(2, notification);
        }
    }

    private static void saveAlarmState(Context context, boolean active) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ALARM_PLAYING, active)
            .apply();
    }
}
