import 'package:video_player/video_player.dart';

/// Singleton — video + suara tetap hidup saat pindah menu.
class VideoService {
  VideoService._();
  static final VideoService instance = VideoService._();

  VideoPlayerController? _controller;
  bool _initialized = false;
  bool _hasError = false;
  final List<void Function()> _listeners = [];

  VideoPlayerController? get controller => _controller;
  bool get isInitialized => _initialized;
  bool get hasError => _hasError;

  Future<void> init() async {
    if (_controller != null) {
      // Pastikan volume & play tetap on
      await _controller!.setVolume(1.0);
      if (!_controller!.value.isPlaying) {
        await _controller!.play();
      }
      return;
    }
    try {
      _controller = VideoPlayerController.asset('assets/banner.mp4');
      await _controller!.initialize();
      await _controller!.setLooping(true);
      await _controller!.setVolume(1.0);
      await _controller!.play();
      _initialized = true;
      _hasError = false;
    } catch (_) {
      _hasError = true;
      _initialized = false;
    }
    _notify();
  }

  void play() {
    if (_controller != null && _initialized) {
      _controller!.setVolume(1.0);
      _controller!.play();
    }
  }

  void ensurePlaying() {
    if (_controller != null && _initialized) {
      _controller!.setVolume(1.0);
      if (!_controller!.value.isPlaying) {
        _controller!.play();
      }
    }
  }

  void addListener(void Function() listener) {
    _listeners.add(listener);
  }

  void removeListener(void Function() listener) {
    _listeners.remove(listener);
  }

  void _notify() {
    for (final l in List.of(_listeners)) {
      l();
    }
  }

  Future<void> dispose() async {
    await _controller?.dispose();
    _controller = null;
    _initialized = false;
  }
}
