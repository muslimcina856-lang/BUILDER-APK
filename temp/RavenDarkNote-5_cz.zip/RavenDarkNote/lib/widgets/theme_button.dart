import 'package:flutter/material.dart';

class ThemeButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final Color? color;

  const ThemeButton({
    super.key,
    required this.label,
    required this.isSelected,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final primary = color ?? Theme.of(context).colorScheme.primary;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    // Teks selalu kontras: selected pakai primary, unselected pakai onSurface yang jelas
    final textColor = isSelected
        ? primary
        : (isDark ? Colors.white.withValues(alpha: 0.85) : const Color(0xFF333333));

    final bgColor = isSelected
        ? primary.withValues(alpha: isDark ? 0.22 : 0.12)
        : (isDark ? const Color(0xFF2A2A2A) : const Color(0xFFF0F0F0));

    final borderCol = isSelected
        ? primary
        : (isDark ? Colors.white.withValues(alpha: 0.12) : const Color(0xFFDDDDDD));

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: borderCol, width: isSelected ? 2 : 1),
            boxShadow: isSelected
                ? [
                    BoxShadow(
                      color: primary.withValues(alpha: 0.25),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ]
                : null,
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              color: textColor,
            ),
          ),
        ),
      ),
    );
  }
}
