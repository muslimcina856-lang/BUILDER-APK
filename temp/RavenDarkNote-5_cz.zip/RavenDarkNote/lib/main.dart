import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'pages/dashboard.dart';
import 'services/storage_service.dart';
import 'services/video_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.init();
  // Video banner start early (dengan suara) — tetap hidup saat pindah menu
  VideoService.instance.init();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const RavenDarkNoteApp());
}

class RavenDarkNoteApp extends StatefulWidget {
  const RavenDarkNoteApp({super.key});

  @override
  State<RavenDarkNoteApp> createState() => _RavenDarkNoteAppState();
}

class _RavenDarkNoteAppState extends State<RavenDarkNoteApp> {
  ThemeMode _themeMode = ThemeMode.dark;
  Color _seedColor = const Color(0xFF7C3AED);

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final themeStr = prefs.getString('theme') ?? 'dark';
    final colorStr = prefs.getString('seed_color') ?? 'purple';
    setState(() {
      _themeMode = _parseThemeMode(themeStr);
      _seedColor = _parseSeedColor(colorStr);
    });
  }

  ThemeMode _parseThemeMode(String theme) {
    switch (theme) {
      case 'light':
        return ThemeMode.light;
      case 'system':
        return ThemeMode.system;
      default:
        return ThemeMode.dark;
    }
  }

  Color _parseSeedColor(String color) {
    switch (color) {
      case 'blue':
        return const Color(0xFF3B82F6);
      case 'red':
        return const Color(0xFFEF4444);
      case 'green':
        return const Color(0xFF22C55E);
      case 'orange':
        return const Color(0xFFF97316);
      case 'purple':
      default:
        return const Color(0xFF7C3AED);
    }
  }

  void updateTheme(String theme, String color) {
    setState(() {
      _themeMode = _parseThemeMode(theme);
      _seedColor = _parseSeedColor(color);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Raven DarkNote',
      debugShowCheckedModeBanner: false,
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorSchemeSeed: _seedColor,
        scaffoldBackgroundColor: const Color(0xFFF7F5FF),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        appBarTheme: AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: const Color(0xFFF7F5FF),
          foregroundColor: const Color(0xFF1A1A1A),
          titleTextStyle: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Color(0xFF1A1A1A),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 0,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: _seedColor,
        scaffoldBackgroundColor: const Color(0xFF0D0D0D),
        cardTheme: CardThemeData(
          color: const Color(0xFF1A1A1A),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: Color(0xFF0D0D0D),
          foregroundColor: Colors.white,
          titleTextStyle: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
      ),
      home: DashboardPage(onThemeChanged: updateTheme),
    );
  }
}
