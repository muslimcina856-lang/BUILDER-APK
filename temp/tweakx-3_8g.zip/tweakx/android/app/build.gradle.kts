plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.tweakx.android"
    compileSdk = 35
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.tweakx.android"
        // Shizuku requires API 23+; we target a realistic modern floor.
        minSdk = 24
        targetSdk = 35
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        create("release") {
            // Falls back to debug signing when no release keystore is provided.
            // GitHub Actions builds an unsigned/debug-signed APK by default.
            // Provide a real keystore via env/secrets to sign for production.
            storeFile = System.getenv("TWEAKX_KEYSTORE_PATH")?.let { file(it) }
            storePassword = System.getenv("TWEAKX_KEYSTORE_PASSWORD")
            keyAlias = System.getenv("TWEAKX_KEY_ALIAS")
            keyPassword = System.getenv("TWEAKX_KEY_PASSWORD")
        }
    }

    buildTypes {
        release {
            signingConfig = if (System.getenv("TWEAKX_KEYSTORE_PATH") != null) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // Shizuku API — real, published library (rikka.dev / JitPack: dev.rikka.shizuku)
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")

    testImplementation("junit:junit:4.13.2")
}
