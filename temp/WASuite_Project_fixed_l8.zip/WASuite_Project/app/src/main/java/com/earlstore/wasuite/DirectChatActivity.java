package com.earlstore.wasuite;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

/* loaded from: classes3.dex */
public class DirectChatActivity extends AppCompatActivity {
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direct_chat);
        final EditText etPhone = (EditText) findViewById(R.id.etPhone);
        final EditText etMessage = (EditText) findViewById(R.id.etMessage);
        Button btnSend = (Button) findViewById(R.id.btnSend);
        btnSend.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.DirectChatActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                DirectChatActivity.this.lambda$onCreate$0(etPhone, etMessage, view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(EditText etPhone, EditText etMessage, View v) {
        String phone = etPhone.getText().toString().trim();
        String message = etMessage.getText().toString();
        if (!phone.isEmpty()) {
            String url = "https://wa.me/" + phone + "?text=" + Uri.encode(message);
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }
}
