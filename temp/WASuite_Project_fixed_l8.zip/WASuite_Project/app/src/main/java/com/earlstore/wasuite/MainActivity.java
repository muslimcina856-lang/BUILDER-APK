package com.earlstore.wasuite;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

/* loaded from: classes3.dex */
public class MainActivity extends AppCompatActivity {
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MaterialCardView btnWebClone = (MaterialCardView) findViewById(R.id.btnWebClone);
        MaterialCardView btnStatusSaver = (MaterialCardView) findViewById(R.id.btnStatusSaver);
        MaterialCardView btnDirectChat = (MaterialCardView) findViewById(R.id.btnDirectChat);
        MaterialCardView btnAbout = (MaterialCardView) findViewById(R.id.btnAbout);
        btnWebClone.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.MainActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$0(view);
            }
        });
        btnStatusSaver.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.MainActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$1(view);
            }
        });
        btnDirectChat.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.MainActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$2(view);
            }
        });
        btnAbout.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.MainActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.lambda$onCreate$3(view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View v) {
        startActivity(new Intent(this, (Class<?>) AccountsActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$1(View v) {
        startActivity(new Intent(this, (Class<?>) StatusActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$2(View v) {
        startActivity(new Intent(this, (Class<?>) DirectChatActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$3(View v) {
        startActivity(new Intent(this, (Class<?>) AboutActivity.class));
    }
}
