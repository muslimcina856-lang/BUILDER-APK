package com.earlstore.wasuite;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.UriPermission;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes3.dex */
public class StatusActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_OPEN_DIRECTORY = 1001;
    private StatusAdapter adapter;
    private RecyclerView rvStatus;
    private List<DocumentFile> statusList = new ArrayList();

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        this.rvStatus = (RecyclerView) findViewById(R.id.rvStatus);
        this.rvStatus.setLayoutManager(new GridLayoutManager(this, 2));
        this.adapter = new StatusAdapter(this, this.statusList);
        this.rvStatus.setAdapter(this.adapter);
        if (!checkPermission()) {
            requestPermission();
        } else {
            loadStatuses();
        }
    }

    private boolean checkPermission() {
        List<UriPermission> permissions = getContentResolver().getPersistedUriPermissions();
        for (UriPermission permission : permissions) {
            if (permission.isReadPermission()) {
                return true;
            }
        }
        return false;
    }

    private void requestPermission() {
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
        intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse("content://com.android.externalstorage.documents/document/primary%3AAndroid%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses"));
        startActivityForResult(intent, 1001);
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Uri uri;
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && resultCode == -1 && (uri = data.getData()) != null) {
            getContentResolver().takePersistableUriPermission(uri, 3);
            loadStatuses();
        }
    }

    private void loadStatuses() {
        List<UriPermission> permissions = getContentResolver().getPersistedUriPermissions();
        if (permissions == null || permissions.isEmpty()) {
            requestPermission();
            return;
        }
        Uri uri = permissions.get(0).getUri();
        DocumentFile directory = DocumentFile.fromTreeUri(this, uri);
        if (directory != null) {
            this.statusList.clear();
            for (DocumentFile file : directory.listFiles()) {
                if (file.getName() != null && (file.getName().endsWith(".jpg") || file.getName().endsWith(".mp4"))) {
                    this.statusList.add(file);
                }
            }
            this.adapter.notifyDataSetChanged();
            if (this.statusList.isEmpty()) {
                Toast.makeText(this, "No statuses found", 0).show();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    class StatusAdapter extends RecyclerView.Adapter<StatusAdapter.ViewHolder> {
        private Context context;
        private List<DocumentFile> files;

        public StatusAdapter(Context context, List<DocumentFile> files) {
            this.context = context;
            this.files = files;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(this.context).inflate(R.layout.item_status, parent, false);
            return new ViewHolder(view);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public void onBindViewHolder(ViewHolder holder, int position) {
            final DocumentFile file = this.files.get(position);
            Glide.with(this.context).load(file.getUri()).into(holder.ivStatus);
            holder.ivVideoIcon.setVisibility(file.getName().endsWith(".mp4") ? 0 : 8);
            holder.btnDownload.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.StatusActivity$StatusAdapter$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    StatusActivity.StatusAdapter.this.lambda$onBindViewHolder$0(file, view);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$onBindViewHolder$0(DocumentFile file, View v) {
            saveStatus(file);
        }

        @Override // androidx.recyclerview.widget.RecyclerView.Adapter
        public int getItemCount() {
            return this.files.size();
        }

        private void saveStatus(DocumentFile file) {
            Uri externalUri;
            try {
                ContentResolver resolver = StatusActivity.this.getContentResolver();
                InputStream in = resolver.openInputStream(file.getUri());
                ContentValues values = new ContentValues();
                values.put("_display_name", file.getName());
                values.put("mime_type", file.getType());
                if (Build.VERSION.SDK_INT >= 29) {
                    values.put("relative_path", Environment.DIRECTORY_DOWNLOADS + "/WA_Suite");
                    externalUri = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                } else {
                    externalUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                }
                Uri newFileUri = resolver.insert(externalUri, values);
                if (newFileUri != null) {
                    OutputStream out = resolver.openOutputStream(newFileUri);
                    byte[] buf = new byte[1024];
                    while (true) {
                        int len = in.read(buf);
                        if (len > 0) {
                            out.write(buf, 0, len);
                        } else {
                            in.close();
                            out.close();
                            Toast.makeText(this.context, "Saved to Downloads/WA_Suite", 0).show();
                            return;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this.context, "Failed to save: " + e.getMessage(), 0).show();
            }
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            ImageButton btnDownload;
            ImageView ivStatus;
            ImageView ivVideoIcon;

            public ViewHolder(View itemView) {
                super(itemView);
                this.ivStatus = (ImageView) itemView.findViewById(R.id.ivStatus);
                this.ivVideoIcon = (ImageView) itemView.findViewById(R.id.ivVideoIcon);
                this.btnDownload = (ImageButton) itemView.findViewById(R.id.btnDownload);
            }
        }
    }
}
