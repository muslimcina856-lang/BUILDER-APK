package com.earlstore.wasuite;

import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class WebActivity extends AppCompatActivity {
    private static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36";
    
    private View btnSlide;
    private ViewGroup panelControl;
    private LinearLayout toolbarAdvance;
    private WebView webView;
    private boolean isToolbarVisible = false;
    private boolean isKeyboardDisabled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        this.webView = findViewById(R.id.webView);
        this.panelControl = findViewById(R.id.panelControl);
        this.toolbarAdvance = findViewById(R.id.toolbarAdvance);
        this.btnSlide = findViewById(R.id.btnSlide);
        final Button btnToggleKeyboard = findViewById(R.id.btnToggleKeyboard);
        Button btnRefresh = findViewById(R.id.btnRefresh);

        setupWebView();

        this.btnSlide.setOnClickListener(v -> toggleToolbar());

        this.webView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN && isToolbarVisible) {
                toggleToolbar();
            }
            return false;
        });

        btnToggleKeyboard.setOnClickListener(v -> {
            isKeyboardDisabled = !isKeyboardDisabled;
            btnToggleKeyboard.setText(isKeyboardDisabled ? "Enable Keyboard" : "Disable Keyboard");
            updateKeyboardStatus();
        });

        btnRefresh.setOnClickListener(v -> webView.reload());

        applyModeSettings();
        this.webView.loadUrl("https://web.whatsapp.com/");
    }

    private void toggleToolbar() {
        TransitionManager.beginDelayedTransition(this.panelControl);
        isToolbarVisible = !isToolbarVisible;
        this.toolbarAdvance.setVisibility(isToolbarVisible ? View.VISIBLE : View.GONE);
    }

    private void setupWebView() {
        WebSettings settings = this.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setUserAgentString(DESKTOP_UA);
        this.webView.setWebViewClient(new WebViewClient());
    }

    private void applyModeSettings() {
        this.webView.evaluateJavascript(
            "var style = document.createElement('style');" +
            "style.innerHTML = '.app-wrapper-web ._1X8_j { min-width: 100% !important; }';" +
            "document.head.appendChild(style);", null);
    }

    private void updateKeyboardStatus() {
        if (this.isKeyboardDisabled) {
            this.webView.evaluateJavascript(
                "(function() { " +
                "  window.kbBlurHandler = function(e) { if(e.target.blur) e.target.blur(); }; " +
                "  document.body.addEventListener('focusin', window.kbBlurHandler, true); " +
                "  if(document.activeElement) document.activeElement.blur(); " +
                "})();", null);
        } else {
            this.webView.evaluateJavascript(
                "(function() { " +
                "  if(window.kbBlurHandler) { " +
                "    document.body.removeEventListener('focusin', window.kbBlurHandler, true); " +
                "    window.kbBlurHandler = null; " +
                "  } " +
                "})();", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (this.webView.canGoBack()) {
            this.webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
