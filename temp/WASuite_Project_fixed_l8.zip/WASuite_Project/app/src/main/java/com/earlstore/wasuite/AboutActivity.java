package com.earlstore.wasuite;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

/* loaded from: classes3.dex */
public class AboutActivity extends AppCompatActivity {
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        Button btnChannel = (Button) findViewById(R.id.btnChannel);
        Button btnContact = (Button) findViewById(R.id.btnContact);
        btnChannel.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.AboutActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AboutActivity.this.lambda$onCreate$0(view);
            }
        });
        btnContact.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.AboutActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AboutActivity.this.lambda$onCreate$1(view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(View v) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("https://t.me/earlstore2004"));
        startActivity(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$1(View v) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("https://t.me/earlxz"));
        startActivity(intent);
    }
}
