package com.earlstore.wasuite;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* loaded from: classes3.dex */
public class AccountsActivity extends AppCompatActivity {
    private List<String> accountsList;
    private ArrayAdapter<String> adapter;
    private ListView lvAccounts;
    private SharedPreferences prefs;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accounts);
        this.lvAccounts = (ListView) findViewById(R.id.lvAccounts);
        Button btnAddAccount = (Button) findViewById(R.id.btnAddAccount);
        this.prefs = getSharedPreferences("WA_ACCOUNTS", 0);
        loadAccounts();
        this.adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, this.accountsList);
        this.lvAccounts.setAdapter((ListAdapter) this.adapter);
        this.lvAccounts.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.earlstore.wasuite.AccountsActivity$$ExternalSyntheticLambda2
            @Override // android.widget.AdapterView.OnItemClickListener
            public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                AccountsActivity.this.lambda$onCreate$0(adapterView, view, i, j);
            }
        });
        this.lvAccounts.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // from class: com.earlstore.wasuite.AccountsActivity$$ExternalSyntheticLambda3
            @Override // android.widget.AdapterView.OnItemLongClickListener
            public final boolean onItemLongClick(AdapterView adapterView, View view, int i, long j) {
                boolean lambda$onCreate$1;
                lambda$onCreate$1 = AccountsActivity.this.lambda$onCreate$1(adapterView, view, i, j);
                return lambda$onCreate$1;
            }
        });
        btnAddAccount.setOnClickListener(new View.OnClickListener() { // from class: com.earlstore.wasuite.AccountsActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AccountsActivity.this.lambda$onCreate$2(view);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$0(AdapterView parent, View view, int position, long id) {
        Intent intent = new Intent(this, (Class<?>) WebActivity.class);
        intent.putExtra("ACCOUNT_ID", position);
        startActivity(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean lambda$onCreate$1(AdapterView parent, View view, int position, long id) {
        showRenameDialog(position);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onCreate$2(View v) {
        showAddDialog();
    }

    private void loadAccounts() {
        String accountsStr = this.prefs.getString("accounts_list", "Account 1");
        this.accountsList = new ArrayList(Arrays.asList(accountsStr.split(",")));
    }

    private void saveAccounts() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.accountsList.size(); i++) {
            sb.append(this.accountsList.get(i));
            if (i < this.accountsList.size() - 1) {
                sb.append(",");
            }
        }
        this.prefs.edit().putString("accounts_list", sb.toString()).apply();
    }

    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("New Account Name");
        final EditText input = new EditText(this);
        input.setInputType(1);
        builder.setView(input);
        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() { // from class: com.earlstore.wasuite.AccountsActivity$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                AccountsActivity.this.lambda$showAddDialog$3(input, dialogInterface, i);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() { // from class: com.earlstore.wasuite.AccountsActivity$$ExternalSyntheticLambda1
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showAddDialog$3(EditText input, DialogInterface dialog, int which) {
        String name = input.getText().toString().trim();
        if (!name.isEmpty()) {
            this.accountsList.add(name);
            this.adapter.notifyDataSetChanged();
            saveAccounts();
        }
    }

    private void showRenameDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Rename Account");
        final EditText input = new EditText(this);
        input.setInputType(1);
        input.setText(this.accountsList.get(position));
        builder.setView(input);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.earlstore.wasuite.AccountsActivity$$ExternalSyntheticLambda5
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                AccountsActivity.this.lambda$showRenameDialog$5(input, position, dialogInterface, i);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() { // from class: com.earlstore.wasuite.AccountsActivity$$ExternalSyntheticLambda6
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showRenameDialog$5(EditText input, int position, DialogInterface dialog, int which) {
        String name = input.getText().toString().trim();
        if (!name.isEmpty()) {
            this.accountsList.set(position, name);
            this.adapter.notifyDataSetChanged();
            saveAccounts();
        }
    }
}
