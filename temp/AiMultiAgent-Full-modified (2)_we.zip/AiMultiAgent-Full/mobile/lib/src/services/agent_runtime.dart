import 'dart:convert';

import 'package:uuid/uuid.dart';

import '../config/app_config.dart';
import '../models/app_models.dart';
import 'local_database.dart';
import 'permission_manager.dart';
import 'provider_model_policy.dart';
import 'provider_service.dart';
import 'tool_engine.dart';

class RunControl {
  bool _cancelled = false;
  bool get cancelled => _cancelled;
  void cancel() => _cancelled = true;
}

/// Menyelaras model, tools, skills dan sub-agent dinamik.
///
/// UI hanya menerima status operasi yang boleh diperhati (model, tool,
/// sub-agent, hasil). Pemikiran dalaman model tidak direkod atau dipaparkan.
class AgentRuntime {
  AgentRuntime({
    required this.providerService,
    required this.toolEngine,
    required this.permissionManager,
    required this.database,
  });

  final ProviderService providerService;
  final ToolEngine toolEngine;
  final PermissionManager permissionManager;
  final LocalDatabase database;

  static const Uuid _uuid = Uuid();

  /// Shared blackboard per sesi chat (gaya multi-agent framework).
  /// Sub-agent & orchestrator baca/tulis nota bersama dalam sesi yang sama.
  static final Map<String, Map<String, String>> _blackboards = <String, Map<String, String>>{};
  static final Map<String, List<String>> _discussThreads = <String, List<String>>{};

  static String _rootSessionId(String sessionId) {
    final i = sessionId.indexOf('/sub/');
    return i > 0 ? sessionId.substring(0, i) : sessionId;
  }

  static Map<String, String> _board(String sessionId) =>
      _blackboards.putIfAbsent(_rootSessionId(sessionId), () => <String, String>{});

  static List<String> _thread(String sessionId) =>
      _discussThreads.putIfAbsent(_rootSessionId(sessionId), () => <String>[]);

  static String _boardSnapshot(String sessionId, {int maxChars = 4000}) {
    final board = _board(sessionId);
    if (board.isEmpty) return '';
    final buf = StringBuffer();
    for (final e in board.entries) {
      buf.writeln('- ${e.key}: ${_clipText(e.value, 500)}');
    }
    return _clipText(buf.toString(), maxChars);
  }

  Future<ChatMessage> run({
    required String sessionId,
    required ProviderConfig provider,
    required String apiKey,
    required AgentProfile agent,
    required List<SkillDefinition> skills,
    required List<ChatMessage> history,
    required String userInput,
    List<ChatAttachment> userAttachments = const <ChatAttachment>[],
    List<AgentProfile> agents = const <AgentProfile>[],
    List<ProviderConfig> providers = const <ProviderConfig>[],
    Future<String> Function(String providerId)? apiKeyResolver,
    RunControl? control,
    int depth = 0,
    void Function(RunStatus status, String detail)? onProgress,
    void Function(RunEvent event)? onEvent,
  }) async {
    // Parameter legacy ini dikekalkan supaya data lama/worker lama masih serasi.
    // Sub-agent baharu sentiasa menggunakan provider/model yang dipilih pengguna.
    final _ = (agents, providers, apiKeyResolver);
    final runControl = control ?? RunControl();
    final activeSkills = skills.where((item) => item.enabled).toList();
    toolEngine.boundProvider = provider;
    toolEngine.boundApiKey = apiKey;
    final selectedTools = _selectTools(agent, activeSkills, provider)
      ..add(_delegateAgentDefinition())
      ..add(_blackboardSetDefinition())
      ..add(_blackboardGetDefinition())
      ..add(_agentDiscussDefinition())
      ..add(_agentCritiqueDefinition());
    final artifacts = <ChatArtifact>[];
    final runtimeContext = await toolEngine.runtimeContextSnapshot();

    final messages = <ChatMessage>[
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.system,
        content: _systemPrompt(
          agent,
          activeSkills,
          selectedTools,
          runtimeContext,
          sessionId: sessionId,
        ),
        createdAt: DateTime.now(),
      ),
      ...history.where((message) => message.role != MessageRole.system),
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.user,
        content: userInput,
        createdAt: DateTime.now(),
        metadata: <String, dynamic>{
          // Guna path sebenar (toJson), bukan toModelJson yang tukar path ke
          // /attachments/nama — itu pecahkan baca fail & inline vision.
          if (userAttachments.isNotEmpty)
            'attachments':
                userAttachments.map((item) => item.toJson()).toList(),
        },
      ),
    ];

    var step = 0;
    while (!runControl.cancelled) {
      final modelEventId = 'model:$depth:$step';
      final firstTurn = step == 0;
      final modelTitle = firstTurn
          ? (depth == 0
              ? 'Memahami permintaan'
              : '${agent.name} memproses subtugas')
          : 'Menyusun hasil';
      _emit(
        onEvent,
        RunEvent(
          id: modelEventId,
          title: modelTitle,
          detail: '${provider.name} · ${agent.modelOverride ?? provider.model}',
          state: RunEventState.running,
          createdAt: DateTime.now(),
          agentRole: agent.name,
        ),
      );
      onProgress?.call(
        firstTurn ? RunStatus.planning : RunStatus.runningTool,
        modelTitle,
      );

      ModelTurn turn;
      try {
        onProgress?.call(
          firstTurn ? RunStatus.planning : RunStatus.runningTool,
          firstTurn && userAttachments.isNotEmpty
              ? 'Memampat & menghantar ${userAttachments.length} lampiran ke model…'
              : 'Menunggu jawapan ${provider.name}…',
        );
        turn = await providerService.complete(
          config: provider,
          apiKey: apiKey,
          messages: messages,
          tools: selectedTools,
          modelOverride: agent.modelOverride,
          isCancelled: () => runControl.cancelled,
          onPartial: (partial) {
            final clipped = partial.length > 900
                ? '${partial.substring(partial.length - 900)}'
                : partial;
            onProgress?.call(
              firstTurn ? RunStatus.planning : RunStatus.runningTool,
              clipped,
            );
            _emit(
              onEvent,
              RunEvent(
                id: modelEventId,
                title: modelTitle,
                detail: clipped,
                state: RunEventState.running,
                createdAt: DateTime.now(),
                agentRole: agent.name,
              ),
            );
          },
        );
        // Selepas pusingan pertama: jangan hantar semula base64 gambar besar
        // pada setiap tool-call (elak timeout / connection abort).
        if (firstTurn) {
          _stripInlineAttachments(messages);
        }
        final reasoning = turn.reasoning.trim();
        _emit(
          onEvent,
          RunEvent(
            id: modelEventId,
            title: modelTitle,
            detail: reasoning.isNotEmpty
                ? reasoning
                : (turn.toolCalls.isEmpty
                    ? 'Respons akhir diterima'
                    : '${turn.toolCalls.length} tindakan dipilih'),
            state: RunEventState.success,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
        if (reasoning.isNotEmpty) {
          _emit(
            onEvent,
            RunEvent(
              id: '$modelEventId:think',
              title: 'Fikiran model',
              detail: _cleanReasoning(reasoning),
              state: RunEventState.success,
              createdAt: DateTime.now(),
              agentRole: agent.name,
            ),
          );
        }
      } catch (error) {
        _emit(
          onEvent,
          RunEvent(
            id: modelEventId,
            title: modelTitle,
            detail: error.toString(),
            state: RunEventState.failed,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
        rethrow;
      }

      if (runControl.cancelled) break;
      if (turn.toolCalls.isEmpty) {
        final text = turn.text.trim().isEmpty
            ? (artifacts.isNotEmpty
                ? 'Fail: ${artifacts.map((item) => item.title).toSet().join(', ')}'
                : 'Tiada teks tambahan. Cuba sebut nama fail yang dikehendaki.')
            : turn.text.trim();
        _emit(
          onEvent,
          RunEvent(
            id: 'final:$depth',
            title: depth == 0 ? 'Jawapan siap' : '${agent.name} selesai',
            detail: artifacts.isEmpty
                ? 'Selesai'
                : '${artifacts.length} hasil dilampirkan',
            state: RunEventState.success,
            createdAt: DateTime.now(),
            agentRole: agent.name,
          ),
        );
        onProgress?.call(RunStatus.completed, 'Selesai');
        return ChatMessage(
          id: _uuid.v4(),
          sessionId: sessionId,
          role: MessageRole.assistant,
          content: text,
          createdAt: DateTime.now(),
          metadata: <String, dynamic>{
            'agentId': agent.id,
            'agentName': agent.name,
            'providerId': provider.id,
            'model': agent.modelOverride ?? provider.model,
            'steps': step + 1,
            'delegationDepth': depth,
            if (artifacts.isNotEmpty)
              'artifacts': artifacts.map((item) => item.toJson()).toList(),
          },
        );
      }

      messages.add(
        ChatMessage(
          id: _uuid.v4(),
          sessionId: sessionId,
          role: MessageRole.assistant,
          content: turn.text,
          createdAt: DateTime.now(),
          metadata: <String, dynamic>{
            'toolCalls': turn.toolCalls
                .map(
                  (call) => <String, dynamic>{
                    'id': call.id,
                    'name': call.name,
                    'arguments': call.arguments,
                  },
                )
                .toList(),
          },
        ),
      );

      // Tool biasa: berurutan. Sub-agent (delegate_agent): serentak (tiada had 8).
      // Had 8 concurrent hanya untuk job terminal Shell, bukan sub-agent.
      final orderedCalls = turn.toolCalls.toList(growable: false);
      final pendingDelegates =
          <({int index, ToolCall call, ToolDefinition definition, String title, String eventId})>[];
      final slotResults = List<ToolResult?>.filled(orderedCalls.length, null);

      for (var i = 0; i < orderedCalls.length; i++) {
        if (runControl.cancelled) break;
        final call = orderedCalls[i];
        final resolvedName = _resolveToolName(call.name, selectedTools);
        final definition = selectedTools.firstWhereOrNull(
              (item) => item.id == resolvedName,
            ) ??
            toolEngine.definition(resolvedName ?? call.name);
        if (definition == null ||
            !selectedTools.any((item) => item.id == definition.id)) {
          final unavailable = ToolResult(
            success: false,
            output: 'Tool ${call.name} tidak tersedia.',
          );
          slotResults[i] = unavailable;
          messages.add(_toolMessage(sessionId, call, unavailable));
          _emitToolResult(
            onEvent: onEvent,
            eventId: 'tool:${call.id}',
            title: call.name,
            result: unavailable,
            agentName: agent.name,
          );
          continue;
        }

        final isDelegation = call.name == 'delegate_agent';
        final eventId = isDelegation ? 'agent:${call.id}' : 'tool:${call.id}';
        final title = isDelegation
            ? (call.arguments['role']?.toString().trim().isNotEmpty == true
                ? call.arguments['role'].toString().trim()
                : 'Sub-agent')
            : definition.name;

        if (isDelegation) {
          _emit(
            onEvent,
            RunEvent(
              id: eventId,
              title: title,
              detail: _eventDetail(call.name, call.arguments),
              state: RunEventState.running,
              createdAt: DateTime.now(),
              toolId: call.name,
              agentRole: agent.name,
            ),
          );
          pendingDelegates.add((
            index: i,
            call: call,
            definition: definition,
            title: title,
            eventId: eventId,
          ));
          continue;
        }

        _emit(
          onEvent,
          RunEvent(
            id: eventId,
            title: title,
            detail: _eventDetail(call.name, call.arguments),
            state: RunEventState.running,
            createdAt: DateTime.now(),
            toolId: call.name,
            agentRole: agent.name,
          ),
        );

        late ToolResult result;
        final scope = toolEngine.permissionScope(call.name, call.arguments);
        if (await toolEngine.requiresPermission(call.name, call.arguments)) {
          _emit(
            onEvent,
            RunEvent(
              id: eventId,
              title: title,
              detail: 'Menunggu kelulusan tindakan berisiko',
              state: RunEventState.waiting,
              createdAt: DateTime.now(),
              toolId: call.name,
              agentRole: agent.name,
            ),
          );
          onProgress?.call(
            RunStatus.waitingPermission,
            'Menunggu kelulusan untuk ${definition.name}',
          );
          final decision = await permissionManager.request(
            tool: definition,
            scope: scope,
            description:
                toolEngine.permissionDescription(call.name, call.arguments),
          );
          if (decision == PermissionDecision.deny) {
            result = const ToolResult(
              success: false,
              output: 'Pengguna menolak tindakan berisiko ini.',
            );
            slotResults[i] = result;
            messages.add(_toolMessage(sessionId, call, result));
            await _logTool(
              sessionId: sessionId,
              toolId: call.name,
              scope: scope,
              result: result,
            );
            _emitToolResult(
              onEvent: onEvent,
              eventId: eventId,
              title: title,
              result: result,
              agentName: agent.name,
              toolId: call.name,
            );
            continue;
          }
        }
        onProgress?.call(RunStatus.runningTool, title);
        try {
          result = await _executeRuntimeOrTool(
            sessionId: sessionId,
            call: call,
            provider: provider,
            apiKey: apiKey,
            skills: activeSkills,
            control: runControl,
            depth: depth,
            onProgress: onProgress,
            onEvent: onEvent,
          );
        } catch (error) {
          // Ralat tool ≠ gagal tugasan. Beri hasil ke model, teruskan.
          result = ToolResult(
            success: false,
            output:
                'Tool ${call.name} gagal: $error\n'
                'Jangan henti. Cuba pendekatan lain (URL http(s), click, tab lain).',
          );
        }
        await _logTool(
          sessionId: sessionId,
          toolId: call.name,
          scope: scope,
          result: result,
        );
        slotResults[i] = result;
        _collectArtifacts(result.data, artifacts);
        messages.add(_toolMessage(sessionId, call, result));
        _injectVideoFrames(messages, sessionId, result);
        _emitToolResult(
          onEvent: onEvent,
          eventId: eventId,
          title: title,
          result: result,
          agentName: agent.name,
          toolId: call.name,
        );
      }

      // Jalankan semua sub-agent serentak — tiada had maxConcurrentJobs (itu untuk Shell).
      if (pendingDelegates.isNotEmpty && !runControl.cancelled) {
        onProgress?.call(
          RunStatus.runningTool,
          '${pendingDelegates.length} sub-agent serentak',
        );
        final futures = pendingDelegates.map((item) async {
          final result = await _delegate(
            sessionId: sessionId,
            call: item.call,
            provider: provider,
            apiKey: apiKey,
            skills: activeSkills,
            control: runControl,
            depth: depth,
            onProgress: onProgress,
            onEvent: onEvent,
          );
          return (item: item, result: result);
        }).toList(growable: false);

        final completed = await Future.wait(futures);
        // Susun semula mengikut urutan tool_call asal supaya sejarah model konsisten.
        completed.sort((a, b) => a.item.index.compareTo(b.item.index));
        for (final entry in completed) {
          final item = entry.item;
          final result = entry.result;
          slotResults[item.index] = result;
          // Auto-tulis ke blackboard bersama (shared state gaya framework).
          final roleKey = item.title.replaceAll(RegExp(r'\s+'), '_').toLowerCase();
          _board(sessionId)['sub:$roleKey'] = _clipText(result.output, 2000);
          _thread(sessionId).add(
            '[${item.title}] ${_clipText(result.output, 400)}',
          );
          _collectArtifacts(result.data, artifacts);
          messages.add(_toolMessage(sessionId, item.call, result));
          _emitToolResult(
            onEvent: onEvent,
            eventId: item.eventId,
            title: item.title,
            result: result,
            agentName: agent.name,
            toolId: item.call.name,
          );
        }
      }
      step++;
    }

    return ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.assistant,
      content: 'Tugasan dihentikan.',
      createdAt: DateTime.now(),
      metadata: <String, dynamic>{
        'cancelled': true,
        if (artifacts.isNotEmpty)
          'artifacts': artifacts.map((item) => item.toJson()).toList(),
      },
    );
  }

  Future<ToolResult> _executeRuntimeOrTool({
    required String sessionId,
    required ToolCall call,
    required ProviderConfig provider,
    required String apiKey,
    required List<SkillDefinition> skills,
    required RunControl control,
    required int depth,
    required void Function(RunStatus status, String detail)? onProgress,
    required void Function(RunEvent event)? onEvent,
  }) async {
    switch (call.name) {
      case 'blackboard_set':
        final key = call.arguments['key']?.toString().trim() ?? '';
        final value = call.arguments['value']?.toString() ?? '';
        if (key.isEmpty) {
          return const ToolResult(success: false, output: 'key blackboard kosong.');
        }
        _board(sessionId)[key] = _clipText(value, 8000);
        return ToolResult(
          success: true,
          output: 'Blackboard set: $key (${value.length} aksara).',
        );
      case 'blackboard_get':
        final key = call.arguments['key']?.toString().trim() ?? '';
        if (key.isEmpty) {
          final snap = _boardSnapshot(sessionId, maxChars: 6000);
          return ToolResult(
            success: true,
            output: snap.isEmpty ? 'Blackboard kosong.' : 'Blackboard:\n$snap',
          );
        }
        final v = _board(sessionId)[key];
        return ToolResult(
          success: v != null,
          output: v ?? 'Tiada kunci "$key" pada blackboard.',
        );
      case 'agent_discuss':
        final from = call.arguments['from']?.toString().trim().isNotEmpty == true
            ? call.arguments['from'].toString().trim()
            : 'agent';
        final message = call.arguments['message']?.toString().trim() ?? '';
        if (message.isEmpty) {
          return const ToolResult(success: false, output: 'Mesej discuss kosong.');
        }
        final line = '[$from] ${_clipText(message, 1500)}';
        _thread(sessionId).add(line);
        final recent = _thread(sessionId).length > 20
            ? _thread(sessionId).sublist(_thread(sessionId).length - 20)
            : _thread(sessionId);
        return ToolResult(
          success: true,
          output: 'Thread agent (terkini):\n${recent.join('\n')}',
        );
      case 'agent_critique':
        // Critic loop formal: sub-agent Penyemak baca blackboard + target.
        final target = call.arguments['target']?.toString().trim() ?? '';
        final focus = call.arguments['focus']?.toString().trim() ??
            'Ketepatan, jurang, percanggahan, dan cadangan pembetulan.';
        final board = _boardSnapshot(sessionId, maxChars: 5000);
        final critiqueCall = ToolCall(
          id: call.id,
          name: 'delegate_agent',
          arguments: <String, dynamic>{
            'role': 'Penyemak QA',
            'task':
                'Lakukan critic loop formal.\nFokus: $focus\n\nBahan untuk disemak:\n${_clipText(target, 6000)}\n\nBlackboard:\n$board',
            'expected_output':
                'Senarai isu (kritikal/sederhana), fakta yang disahkan, dan cadangan pembetulan padat.',
            'context': board,
          },
        );
        return _delegate(
          sessionId: sessionId,
          call: critiqueCall,
          provider: provider,
          apiKey: apiKey,
          skills: skills,
          control: control,
          depth: depth,
          onProgress: onProgress,
          onEvent: onEvent,
        );
      default:
        return toolEngine.execute(call.name, call.arguments);
    }
  }

  Future<ToolResult> _delegate({
    required String sessionId,
    required ToolCall call,
    required ProviderConfig provider,
    required String apiKey,
    required List<SkillDefinition> skills,
    required RunControl control,
    required int depth,
    required void Function(RunStatus status, String detail)? onProgress,
    required void Function(RunEvent event)? onEvent,
  }) async {
    final role = call.arguments['role']?.toString().trim() ?? '';
    final task = call.arguments['task']?.toString().trim() ?? '';
    final expected =
        call.arguments['expected_output']?.toString().trim() ?? '';
    // Had memori: potong konteks rakan supaya sub-agent tidak muat teks besar.
    final peerContext = _clipText(
      call.arguments['context']?.toString().trim() ?? '',
      6000,
    );
    var requestedTools = (call.arguments['tool_ids'] as List? ??
            const <dynamic>[])
        .map((item) => item.toString())
        .where((item) => toolEngine.definition(item) != null)
        .toList();
    if (task.isEmpty) {
      return const ToolResult(
        success: false,
        output: 'Subtugas tidak boleh kosong.',
      );
    }

    final name = role.isEmpty ? 'Sub-agent' : role;
    final expertise = _expertiseForRole(name);
    // Jika model tak pilih tool, guna set pakar ikut peranan (jimat token + fokus).
    if (requestedTools.isEmpty) {
      requestedTools = expertise.defaultToolIds
          .where((id) => toolEngine.definition(id) != null)
          .toList();
    }

    final subAgent = AgentProfile(
      id: 'sub_${_uuid.v4()}',
      name: name,
      description: expertise.summary,
      systemPrompt: [
        'Kepakaran: ${expertise.summary}',
        expertise.instructions,
        'Fokus HANYA pada subtugas. Jangan ulang kerja orchestrator.',
        'Jawab padat, berstruktur. Elak ulang HTML/log panjang.',
        if (expected.isNotEmpty) 'Hasil yang diperlukan: $expected',
        if (peerContext.isNotEmpty)
          'Konteks/hasil rakan (semakan silang, sudah dipotong):\n$peerContext',
        'Pulangkan ringkasan jelas kepada orchestrator utama.',
      ].join('\n'),
      iconCode: expertise.iconCode,
      toolIds: requestedTools,
      enabled: true,
      isBuiltIn: false,
    );

    final response = await run(
      sessionId: '$sessionId/sub/${_uuid.v4()}',
      provider: provider,
      apiKey: apiKey,
      agent: subAgent,
      // Tiada history induk — jimat memori; subtugas standalone.
      skills: skills,
      history: const <ChatMessage>[],
      userInput: _clipText(task, 12000),
      control: control,
      depth: depth + 1,
      onProgress: onProgress,
      onEvent: onEvent,
    );
    // Pulangkan output dipotong + tanpa artifact besar (orchestrator gabungkan).
    final compact = _clipText(response.content, 10000);
    return ToolResult(
      success: !control.cancelled,
      output: compact,
      data: <String, dynamic>{
        'role': name,
        'expertise': expertise.summary,
        'provider_id': provider.id,
        'model': provider.model,
        'depth': depth + 1,
        'artifact_count': response.artifacts.length,
      },
    );
  }

  static String _clipText(String value, int maxChars) {
    final t = value.trim();
    if (t.length <= maxChars) return t;
    return '${t.substring(0, maxChars)}…';
  }

  /// Profil kepakaran sub-agent mengikut nama peranan.
  static _SubExpertise _expertiseForRole(String role) {
    final r = role.toLowerCase();
    if (r.contains('web') ||
        r.contains('cari') ||
        r.contains('research') ||
        r.contains('penyelidik') ||
        r.contains('browser')) {
      return const _SubExpertise(
        summary: 'Pakar penyelidikan web & sumber dalam talian',
        instructions:
            'Guna web_search (max 2–3 query), kemudian browser_open/read. '
            'Sahkan fakta dari sumber. Jangan spam carian.',
        defaultToolIds: <String>[
          'web_search',
          'browser_open',
          'browser_read',
          'browser_click',
          'browser_fill',
          'browser_screenshot',
        ],
        iconCode: 0xe894,
      );
    }
    if (r.contains('kod') ||
        r.contains('code') ||
        r.contains('dev') ||
        r.contains('program') ||
        r.contains('shell') ||
        r.contains('linux') ||
        r.contains('terminal')) {
      return const _SubExpertise(
        summary: 'Pakar kod, Shell Linux & automasi fail',
        instructions:
            'Guna terminal_start + terminal_poll, file_read/write, archive_*. '
            'Untuk .exe guna run_exe / wine. Laporkan exit_code sebenar.',
        defaultToolIds: <String>[
          'terminal_start',
          'terminal_poll',
          'terminal_stop',
          'file_read',
          'file_write',
          'file_replace',
          'file_list',
          'run_exe',
          'linux_workspace_status',
        ],
        iconCode: 0xefb0,
      );
    }
    if (r.contains('data') ||
        r.contains('analis') ||
        r.contains('analysis') ||
        r.contains('nombor') ||
        r.contains('statistik')) {
      return const _SubExpertise(
        summary: 'Pakar analisis data & penstrukturan maklumat',
        instructions:
            'Ekstrak angka, jadual, trend. Susun dalam bullet/jadual markdown. '
            'Guna file_read jika ada fail; web_search untuk angka awam.',
        defaultToolIds: <String>[
          'web_search',
          'file_read',
          'file_list',
          'browser_open',
          'browser_read',
        ],
        iconCode: 0xe1db,
      );
    }
    if (r.contains('tulis') ||
        r.contains('write') ||
        r.contains('editor') ||
        r.contains('copy') ||
        r.contains('kandungan')) {
      return const _SubExpertise(
        summary: 'Pakar penulisan & penyusunan kandungan',
        instructions:
            'Tulis jelas, struktur baik (tajuk, bullet). Bahasa ikut pengguna. '
            'Boleh rujuk web_search untuk fakta ringkas.',
        defaultToolIds: <String>['web_search', 'file_read'],
        iconCode: 0xe3c9,
      );
    }
    if (r.contains('semak') ||
        r.contains('review') ||
        r.contains('qa') ||
        r.contains('audit') ||
        r.contains('kritik')) {
      return const _SubExpertise(
        summary: 'Pakar semakan kualiti & semakan silang',
        instructions:
            'Semak ketepatan, percanggahan, jurang. Guna parameter context. '
            'Laporkan isu + cadangan pembetulan secara padat.',
        defaultToolIds: <String>['web_search', 'file_read', 'browser_read'],
        iconCode: 0xe8e8,
      );
    }
    return const _SubExpertise(
      summary: 'Sub-agent umum berfokus tugas',
      instructions:
          'Selesaikan subtugas dengan tool yang perlu sahaja. Jawab padat.',
      defaultToolIds: <String>[],
      iconCode: 0xf1b3,
    );
  }

  ToolDefinition _delegateAgentDefinition() {
    return const ToolDefinition(
      id: 'delegate_agent',
      name: 'Cipta sub-agent',
      category: 'Multi-Agent',
      risk: ToolRisk.readOnly,
      description:
          'Cipta sub-agent dinamik. Panggil beberapa delegate_agent dalam satu pusingan untuk jalan SERENTAK (tiada had 8 — itu hanya untuk job Shell). '
          'Selepas hasil kembali, boleh deploy pusingan semakan dengan parameter context yang mengandungi hasil rakan.',
      parameters: <String, dynamic>{
        'type': 'object',
        'properties': <String, dynamic>{
          'role': <String, dynamic>{
            'type': 'string',
            'description':
                'Nama peranan khusus, contoh Penyelidik Web atau Penganalisis Dokumen.',
          },
          'task': <String, dynamic>{
            'type': 'string',
            'description': 'Subtugas lengkap beserta konteks penting.',
          },
          'expected_output': <String, dynamic>{
            'type': 'string',
            'description': 'Bentuk hasil yang perlu dipulangkan.',
          },
          'tool_ids': <String, dynamic>{
            'type': 'array',
            'items': <String, dynamic>{'type': 'string'},
            'description':
                'Pilihan tool khusus. Kosong bermaksud semua tool tersedia.',
          },
          'context': <String, dynamic>{
            'type': 'string',
            'description':
                'Hasil/ringkasan sub-agent lain untuk semakan silang (peer review).',
          },
        },
        'required': <String>['role', 'task'],
      },
    );
  }

  ToolDefinition _blackboardSetDefinition() {
    return const ToolDefinition(
      id: 'blackboard_set',
      name: 'Blackboard tulis',
      category: 'Multi-Agent',
      risk: ToolRisk.readOnly,
      description:
          'Tulis nota ke shared blackboard sesi. Semua agent dalam sesi ini boleh baca.',
      parameters: <String, dynamic>{
        'type': 'object',
        'properties': <String, dynamic>{
          'key': <String, dynamic>{
            'type': 'string',
            'description': 'Kunci nota, contoh findings.web atau plan.v1',
          },
          'value': <String, dynamic>{
            'type': 'string',
            'description': 'Kandungan nota (akan dipotong jika terlalu panjang).',
          },
        },
        'required': <String>['key', 'value'],
      },
    );
  }

  ToolDefinition _blackboardGetDefinition() {
    return const ToolDefinition(
      id: 'blackboard_get',
      name: 'Blackboard baca',
      category: 'Multi-Agent',
      risk: ToolRisk.readOnly,
      description:
          'Baca satu kunci atau seluruh shared blackboard sesi (kosongkan key untuk semua).',
      parameters: <String, dynamic>{
        'type': 'object',
        'properties': <String, dynamic>{
          'key': <String, dynamic>{
            'type': 'string',
            'description': 'Kunci spesifik. Kosong = senarai semua.',
          },
        },
      },
    );
  }

  ToolDefinition _agentDiscussDefinition() {
    return const ToolDefinition(
      id: 'agent_discuss',
      name: 'Agent discuss',
      category: 'Multi-Agent',
      risk: ToolRisk.readOnly,
      description:
          'Hantar mesej ke thread perbincangan agent (shared). Guna untuk koordinasi / hujah antara agent.',
      parameters: <String, dynamic>{
        'type': 'object',
        'properties': <String, dynamic>{
          'from': <String, dynamic>{
            'type': 'string',
            'description': 'Nama pengirim (role agent).',
          },
          'message': <String, dynamic>{
            'type': 'string',
            'description': 'Mesej ringkas kepada thread bersama.',
          },
        },
        'required': <String>['message'],
      },
    );
  }

  ToolDefinition _agentCritiqueDefinition() {
    return const ToolDefinition(
      id: 'agent_critique',
      name: 'Critic loop',
      category: 'Multi-Agent',
      risk: ToolRisk.readOnly,
      description:
          'Jalankan critic loop formal: sub-agent Penyemak QA menilai target + blackboard, pulangkan isu dan cadangan.',
      parameters: <String, dynamic>{
        'type': 'object',
        'properties': <String, dynamic>{
          'target': <String, dynamic>{
            'type': 'string',
            'description': 'Teks/hasil yang hendak dikritik.',
          },
          'focus': <String, dynamic>{
            'type': 'string',
            'description': 'Fokus semakan (pilihan).',
          },
        },
        'required': <String>['target'],
      },
    );
  }

  List<ToolDefinition> _selectTools(
    AgentProfile agent,
    List<SkillDefinition> skills,
    ProviderConfig provider,
  ) {
    final ids = <String>{...agent.toolIds};
    for (final skill in skills) {
      ids.addAll(skill.toolIds);
    }
    final caps = ProviderModelPolicy.mediaGen(provider);
    bool allowed(ToolDefinition item) {
      if (item.id == 'generate_speech') return caps.speech;
      if (item.id == 'generate_image') return caps.image;
      if (item.id == 'generate_video') return caps.video;
      if (ids.isEmpty || agent.id == 'orchestrator') return true;
      return ids.contains(item.id);
    }

    return toolEngine.definitions.where(allowed).toList(growable: true);
  }

  String _systemPrompt(
    AgentProfile agent,
    List<SkillDefinition> skills,
    List<ToolDefinition> tools,
    Map<String, dynamic> runtimeContext, {
    String sessionId = '',
  }) {
    final skillText = skills.isEmpty
        ? 'Tiada skill aktif.'
        : skills
            .map(
              (skill) =>
                  'SKILL ${skill.name}\nTujuan: ${skill.description}\nArahan:\n${skill.instructions}\nTools: ${skill.toolIds.join(', ')}',
            )
            .join('\n\n');
    return '''
Anda ialah ${agent.name} dalam Ai MultiAgent.
${runtimeContext['userNickname'] == null || runtimeContext['userNickname'].toString().trim().isEmpty ? '' : '\nPengguna mahu dipanggil: ${runtimeContext['userNickname']}.'}
${runtimeContext['customInstructions'] == null || runtimeContext['customInstructions'].toString().trim().isEmpty ? '' : '\nArahan tersuai pengguna:\n${runtimeContext['customInstructions']}'}

Peranan:
${agent.systemPrompt}

Arahan operasi:
- Jawab dalam bahasa pengguna kecuali diminta sebaliknya.
- Tentukan sendiri bila tool, skill atau sub-agent diperlukan; tiada kata kunci pemicu.
- Gunakan hasil tool sebenar dan jangan mendakwa tindakan berjaya sebelum hasil diterima.
- KONTEKS CHAT: Sejarah mesej dalam sesi ini ialah konteks aktif. Jangan ulang kerja yang sudah siap dalam sejarah (contoh: jangan buka semula laman yang sudah dibaca, jangan pasang semula yang sudah siap) kecuali pengguna minta semula. Topik boleh bertukar bila-bila; ikut mesej terkini tanpa membuang pemahaman kerja lepas yang masih relevan.
- Untuk web, gunakan web_search kemudian browser_open/browser_read bagi sumber penting. Aplikasi mempunyai Android System WebView/Chromium tersembunyi dan browser_open menggunakan mod desktop secara lalai. Jangan kata tiada akses browser sebelum mencuba tool tersebut.
- Carian web: elak banyak web_search berturut-turut dalam satu pusingan (maksimum 2–3). Gabungkan topik dalam satu query bila boleh. Jika web_search gagal (rate-limit/parser), cuba semula sekali dengan query lebih pendek atau terus browser_open — jangan tandakan seluruh tugasan gagal hanya kerana satu carian gagal.
- Aliran browser (gaya Browser-use): (1) browser_open URL, (2) browser_read → interactive_elements berindex + bbox (data untuk AI sahaja), (3) browser_click/fill guna index. Screenshot ke chat = gambar BERSIH tanpa kotak nombor; index bukan overlay pada imej pengguna.
- Multi-tab (max 5): browser_open new_tab=true untuk tab baharu; window.open/target=_blank auto-tab. browser_tabs, browser_switch_tab(tab_id), browser_close_tab. Login/OTP sering buka tab lain — senarai tab, tukar, baca, teruskan. JS sentiasa aktif.
- Self-heal browser: jika click/fill gagal, page dibaca semula automatik dan index baharu diberi. Tiada had max retry hardcoded — terus cuba dengan index/text baharu sehingga berjaya atau pengguna batalkan. Jangan berhenti awal hanya kerana satu percubaan gagal.
- Untuk URL gambar, video atau audio langsung yang hendak dihantar kepada pengguna, gunakan media_preview supaya media boleh dipratonton/dimainkan sebelum pengguna memilih Simpan. Jangan gunakan browser_download terlebih dahulu kecuali pengguna memang meminta fail dimuat turun ke workspace.
- browser_screenshot sudah melampirkan PNG terus ke chat. Selepas screenshot berjaya, jangan panggil media_preview untuk path fail screenshot atau URL halaman; terus jawab pengguna bahawa screenshot tersedia.
- Apabila pengguna bertanya cara menggunakan aplikasi atau sesuatu fungsi, panggil app_usage_guide dan jawab berdasarkan panduan itu.
- Apabila ditanya tentang kemampuan akses, browser atau Shell, panggil runtime_info. Jangan minta atau cuba dapatkan maklumat peranti sebenar (jenama, model, SDK, path host Android). Fokus hanya pada Shell guest (Alpine Linux) dan browser tersembunyi dalam aplikasi. Jangan dakwa boleh melihat atau mengawal PC jauh kecuali tool MCP/companion berkaitan benar-benar tersedia.
- LARANGAN PATH HOST: Jangan sekali-kali cuba list/baca/tulis path host Android seperti /data/..., /storage/..., /sdcard, /proc, /sys, /dev. Gunakan path guest: /workspace, /root, /tmp (Shell).
- LAMPIRAN CHAT: Fail pengguna (gambar/video/audio/zip) ADA dalam sesi. Untuk hantar semula ke chat: media_preview dengan path=nama fail (cth. file_000000.png) ATAU path dari metadata attachments. JANGAN kata "tiada akses". JANGAN minta user upload semula jika lampiran sudah ada dalam history mesej ini/sebelumnya dalam sesi yang sama.
- LAMPIRAN PATH: nama fail sahaja, /attachments/nama, atau path metadata. Elak dedah path host /data/... kepada pengguna.
- ARKIB: Gunakan tool archive_unzip untuk extract ZIP, archive_zip untuk cipta ZIP, file_read/file_write/file_list untuk fail biasa. Untuk skill ZIP lampiran: skill_install_url dengan path="nama.zip" (bukan URL).
- SKILL: skill_install_url terima ZIP dengan skill.json ATAU SKILL.md. Repo source biasa (tiada keduanya) BUKAN skill pack — jangan report gagal format; baca README/SKILL.md lalu skill_create. Skill Creator = skill_create.
- skill_run_script HANYA untuk skill berfolder skrip (pasang ZIP). Skill skill_create = arahan sahaja → ikut arahan dengan terminal_start/file_*, JANGAN skill_run_script.
- GANTI TEKS FAIL: file_replace(path, find, replace). Jangan tulis semula fail besar.
- FAIL BESAR / APK: Jangan file_read seluruh APK, ZIP, DEX, JSON ber-MB. file_read guna offset+length atau start_line+max_lines. APK = ZIP: archive_unzip → edit XML/smali kecil dengan file_replace → archive_zip / send_file. Shell (apktool/zipalign) kalau pakej ada. Hantar hasil ke chat dengan send_file, bukan File Manager.
- Jangan minta URL jika fail ZIP sudah dilampirkan dalam chat — terus pasang/extract dari path lampiran.
- HANTAR KE CHAT: send_file atau media_preview dengan path workspace. Bukan media sahaja — json, zip, pdf, html, txt, csv, imej, video, audio. Contoh: send_file path=trylink_all_users.json. JANGAN suruh buka File Manager / PRoot server jika fail sudah dalam /workspace. JANGAN kata media_preview hanya support imej/video/audio.
- FORMAT: zip/unzip, teks, imej, audio, video, http, browser, shell. working_directory terminal: "." atau relatif sahaja — JANGAN "" atau path host. Dalam command shell boleh guna /workspace/...
- Untuk menjalankan fail .exe: gunakan tool run_exe (disyorkan) atau terminal_start dengan wine. Contoh: pasang dulu dengan apk add --no-cache wine, kemudian wine /workspace/fail.exe. Nota: keserasian aarch64 terhad; bukan semua aplikasi Windows akan berfungsi.
- Untuk terminal Shell, panggil linux_workspace_status dahulu apabila keadaan Linux belum diketahui. Gunakan terminal_start, ambil job_id, kemudian terminal_poll berulang kali sehingga running=false supaya stdout, stderr dan exit_code sebenar diperiksa.
- ${AppConfig.isFullEdition ? 'Full mempunyai Alpine Linux ARM64 terbina dalam melalui PRoot. Runtime dipasang automatik pada arahan pertama. Pengurus pakej ialah apk, bukan apt/dpkg. Untuk memasang pakej gunakan contoh: apk update && apk add --no-cache git python3 wine. Workspace projek ialah /workspace dan home ialah /root. Untuk .exe gunakan run_exe atau wine.' : 'Edisi Standard tidak mempunyai PRoot/rootfs. Jangan cuba apt, dpkg atau apk; gunakan tools native yang dibundel.'}
- Terminal: utamakan arahan non-interaktif (--yes). Jika perlu input, gunakan terminal_stdin atau minta pengguna taip dalam Konsol Terminal chat. Jangan guna sudo (guest sudah root).
- Shell memberi root di dalam guest PRoot sahaja, bukan root Android. Ia tiada systemd, kernel sendiri, desktop GUI atau akses ke /sdcard/data aplikasi lain secara lalai. Jangan dakwa Shell itu PC jauh atau VM penuh.
- Jika terminal gagal, laporkan stderr/exit_code sebenar dan cuba pembetulan yang selamat; jangan terus mendakwa Linux tidak tersedia sebelum memanggil linux_workspace_status atau terminal_start. Jangan cuba 'baiki' dengan mengakses path host Android.
- MULTI-AGENT (gaya framework): Gunakan delegate_agent dengan role pakar. Hasil sub-agent auto-masuk blackboard sesi. Guna blackboard_set/blackboard_get untuk shared state. Guna agent_discuss untuk mesej antara agent (thread). Guna agent_critique untuk critic loop formal (Penyemak QA). Boleh berbilang pusingan: kerja → critique → betulkan.
- FAIL: Satu tugasan = satu fail bermakna. JANGAN dokumen.txt / output.txt / fail kosong. Fail kecil: file_write sekali. Fail besar (HTML/JS panjang): file_write bahagian pertama ~2000 aksara, kemudian file_append berulang pada PATH SAMA. JANGAN hantar seluruh fail besar dalam satu tool call (akan terpotong). JANGAN guna terminal_start kosong untuk tulis fail.
- VIDEO FAHAM: video_sample_frames(path/url, fps). Tiada had frame — AI tentukan fps (dan frames jika mahu potong sendiri). fps=1 = 1 frame setiap saat sepanjang video.
- MEDIA GEN: Tool generate_speech / generate_image / generate_video HANYA wujud jika pengguna isi model suara/gambar/video pada provider. Kosong = tiada tool itu. Jangan dakwa boleh jana jika tool tiada.
- MCP: jika pengguna beri URL/token server MCP dalam chat, terus mcp_configure (url, name, headers). Kemudian mcp_list_tools + mcp_call. Jangan kata MCP local-only.
- Semua tool dibenarkan automatik (tiada dialog kebenaran).
- Untuk paparan kaya: markdown, ```mermaid, ```chart (label|nilai), code fence dengan salin.
- SAPAAN / SOALAN RINGKAS: Jika pengguna hanya menyapa, berterima kasih, atau soalan sangat ringkas tanpa perlu tool — jawab terus dalam 1 pusingan, JANGAN panggil tool, JANGAN delegate_agent.
- Terminal: selepas terminal_start, terminal_poll sehingga selesai. Jika exit_code != 0, baca stderr dan jelaskan sebab gagal kepada pengguna (jangan sembunyikan). Jangan ulang arahan yang sama lebih dari 2 kali jika rangkaian/tool gagal berulang.
- Rangkaian: jika API gagal kerana net/DNS, runtime cuba semula tanpa had (backoff) sehingga berjaya atau pengguna batal. Jangan tukar provider.
- Ralat tool (URL tidak sah, javascript:void(0), tab tiada, browser_busy, 404) BUKAN tamat tugasan. Baca mesej tool, betulkan, teruskan. Jangan jadikan teks FormatException/PlatformException sebagai jawapan akhir kepada pengguna.
- Jangan tukar provider atau model; gunakan pilihan pengguna.
- Semua tool dibenarkan automatik; tiada dialog kelulusan.
- Jangan keluarkan chain-of-thought. UI memaparkan status operasi secara berasingan.

Konteks runtime sebenar aplikasi pada permulaan tugasan:
${const JsonEncoder.withIndent('  ').convert(runtimeContext)}

Shared blackboard sesi (boleh dibaca/dikemas kini oleh semua agent):
${sessionId.isEmpty ? '(kosong)' : (_boardSnapshot(sessionId).isEmpty ? '(kosong)' : _boardSnapshot(sessionId))}

Tools tersedia: ${tools.map((item) => item.id).join(', ')}

Skills aktif:
$skillText
'''.trim();
  }

  void _injectVideoFrames(
    List<ChatMessage> messages,
    String sessionId,
    ToolResult result,
  ) {
    final raw = result.data['attachments'];
    if (raw is! List || raw.isEmpty) return;
    messages.add(
      ChatMessage(
        id: _uuid.v4(),
        sessionId: sessionId,
        role: MessageRole.user,
        content: 'Frame sampel video untuk dilihat:',
        createdAt: DateTime.now(),
        metadata: <String, dynamic>{'attachments': raw},
      ),
    );
  }

  ChatMessage _toolMessage(
    String sessionId,
    ToolCall call,
    ToolResult result,
  ) {
    return ChatMessage(
      id: _uuid.v4(),
      sessionId: sessionId,
      role: MessageRole.tool,
      name: call.name,
      toolCallId: call.id,
      content: _toolResultForModel(call.name, result),
      createdAt: DateTime.now(),
    );
  }

  String _toolResultForModel(String toolId, ToolResult result) {
    final safeData = _modelSafeValue(result.data, key: 'data');
    var output = result.output.trim();
    // Redaksi path host Android supaya model tidak belajar atau cuba
    // mengakses /data/user/0/... atau path private aplikasi.
    output = output.replaceAllMapped(
      RegExp(
        r'''/(?:data/(?:user/\d+/|data/)|storage|sdcard|mnt)[^\s"']*''',
        caseSensitive: false,
      ),
      (_) => '[path-host-disembunyikan]',
    );
    if (output.length > 14000) {
      output = '${output.substring(0, 14000)}…';
    }
    return jsonEncode(<String, dynamic>{
      'success': result.success,
      'tool': toolId,
      'output': output,
      'data': safeData,
    });
  }

  dynamic _modelSafeValue(
    dynamic value, {
    required String key,
    int depth = 0,
  }) {
    if (depth > 6) return '[dipendekkan]';
    final normalizedKey = key.toLowerCase();
    if (<String>{'artifact', 'artifacts', 'html', 'base64', 'datauri'}
        .contains(normalizedKey)) {
      return null;
    }
    if (value is String) {
      final limit = normalizedKey == 'text' ? 16000 : 8000;
      return value.length <= limit ? value : '${value.substring(0, limit)}…';
    }
    if (value is Map) {
      final output = <String, dynamic>{};
      for (final entry in value.entries) {
        final childKey = entry.key.toString();
        final child = _modelSafeValue(
          entry.value,
          key: childKey,
          depth: depth + 1,
        );
        if (child != null) output[childKey] = child;
      }
      return output;
    }
    if (value is List) {
      final limit = switch (normalizedKey) {
        'links' => 40,
        'forms' => 10,
        'fields' => 20,
        _ => 30,
      };
      return value
          .take(limit)
          .map(
            (item) => _modelSafeValue(
              item,
              key: key,
              depth: depth + 1,
            ),
          )
          .where((item) => item != null)
          .toList();
    }
    return value;
  }

  Future<void> _logTool({
    required String sessionId,
    required String toolId,
    required String scope,
    required ToolResult result,
  }) async {
    await database.logTool(
      sessionId: sessionId,
      toolId: toolId,
      scope: scope,
      success: result.success,
      summary: _redactedSummary(result.output),
    );
  }

  String _redactedSummary(String value) {
    var text = value
        .replaceAll(
          RegExp(
            r'(api[_-]?key|authorization|token|secret|password)["\s:=]+[^,\s"}]+',
            caseSensitive: false,
          ),
          r'$1=[REDACTED]',
        )
        .replaceAll(
          RegExp(
            r'bearer\s+[A-Za-z0-9._~+/-]+=*',
            caseSensitive: false,
          ),
          'Bearer [REDACTED]',
        );
    if (text.length > 1200) text = '${text.substring(0, 1200)}…';
    return text;
  }

  void _collectArtifacts(
    Map<String, dynamic> data,
    List<ChatArtifact> output,
  ) {
    final rawArtifact = data['artifact'];
    if (rawArtifact is Map) {
      _addArtifact(
        ChatArtifact.fromJson(Map<String, dynamic>.from(rawArtifact)),
        output,
      );
    }
    for (final raw in data['artifacts'] as List? ?? const <dynamic>[]) {
      if (raw is Map) {
        _addArtifact(
          ChatArtifact.fromJson(Map<String, dynamic>.from(raw)),
          output,
        );
      }
    }
  }

  void _addArtifact(ChatArtifact artifact, List<ChatArtifact> output) {
    if (artifact.id.isEmpty) return;
    if (output.any((item) => item.id == artifact.id)) return;
    final path = artifact.localPath.trim();
    if (path.isNotEmpty) {
      final existing = output.indexWhere((item) => item.localPath == path);
      if (existing >= 0) {
        output[existing] = artifact;
        return;
      }
    }
    output.add(artifact);
  }

  String? _resolveToolName(String raw, List<ToolDefinition> tools) {
    final exact = raw.trim();
    if (tools.any((item) => item.id == exact)) return exact;
    final compact = exact.toLowerCase().replaceAll(RegExp(r'[^a-z0-9_]+'), '');
    for (final tool in tools) {
      final id = tool.id.toLowerCase().replaceAll('_', '');
      if (compact == id || compact.contains(id) || id.contains(compact)) {
        return tool.id;
      }
    }
    return exact.isEmpty ? null : exact;
  }

  String _cleanReasoning(String raw) {
    var text = raw.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (text.contains('_Sequence') ||
        text.contains('tool_no_spaces') ||
        RegExp(r'[A-Za-z_]{48,}').hasMatch(text)) {
      final first = text.split(RegExp(r'(?<=[.!?])\s+')).first;
      text = first.length > 220 ? '${first.substring(0, 220)}…' : first;
    }
    if (text.length > 900) text = '${text.substring(0, 900)}…';
    return text;
  }

  void _emit(
    void Function(RunEvent event)? callback,
    RunEvent event,
  ) {
    callback?.call(event);
  }

  void _emitToolResult({
    required void Function(RunEvent event)? onEvent,
    required String eventId,
    required String title,
    required ToolResult result,
    required String agentName,
    String? toolId,
  }) {
    final detail = _toolEventDetail(toolId, result);
    // Terminal/log: simpan penuh (hampir) supaya user boleh baca keseluruhan.
    final isTerminal = toolId == 'terminal_start' ||
        toolId == 'terminal_poll' ||
        toolId == 'terminal_stop' ||
        toolId == 'terminal_stdin' ||
        toolId == 'run_exe';
    final maxDetail = isTerminal || !result.success ? 24000 : 400;
    final clipped = detail.isEmpty
        ? (result.success ? 'Selesai' : 'Gagal')
        : (detail.length > maxDetail
            ? '${detail.substring(0, maxDetail)}\n… (log dipotong ${detail.length - maxDetail} aksara)'
            : detail);
    _emit(
      onEvent,
      RunEvent(
        id: eventId,
        title: title,
        detail: clipped,
        state: result.success ? RunEventState.success : RunEventState.failed,
        createdAt: DateTime.now(),
        toolId: toolId,
        agentRole: agentName,
      ),
    );
  }

  String _toolEventDetail(String? toolId, ToolResult result) {
    final data = result.data;
    switch (toolId) {
      case 'browser_open':
      case 'browser_read':
      case 'open_url':
      case 'browser_follow_link':
      case 'browser_click':
      case 'browser_fill':
      case 'browser_submit_form':
        final title = data['title']?.toString().trim() ?? '';
        final url = data['url']?.toString().trim() ?? '';
        if (title.isNotEmpty && url.isNotEmpty) return '$title · $url';
        if (url.isNotEmpty) return url;
        return result.success ? 'Halaman browser selesai diproses' : result.output;
      case 'browser_screenshot':
        final width = data['width'];
        final height = data['height'];
        if (width != null && height != null) {
          return 'Screenshot penuh ${width}×$height tersedia';
        }
        return result.success ? 'Screenshot penuh tersedia' : result.output;
      case 'media_preview':
        final kind = data['kind']?.toString() ?? 'media';
        return 'Pratonton $kind tersedia tanpa simpanan automatik';
      case 'browser_download':
        final path = data['path']?.toString() ?? '';
        final bytes = data['bytes'];
        return path.isNotEmpty
            ? 'Disimpan: $path${bytes == null ? '' : ' · $bytes bait'}'
            : result.output;
      case 'app_usage_guide':
        return 'Panduan cara guna aplikasi dibaca';
      case 'terminal_start':
      case 'terminal_poll':
      case 'terminal_stop':
      case 'terminal_stdin':
      case 'run_exe':
        return _terminalLogDetail(data, result);
    }
    if (!result.success && result.output.trim().isNotEmpty) {
      return result.output.trim();
    }
    return result.output.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  /// Log terminal yang jelas: command + exit + ekor stdout/stderr.
  static String _terminalLogDetail(Map<String, dynamic>? data, ToolResult result) {
    final buf = StringBuffer();
    final command = data?['command']?.toString().trim() ?? '';
    final running = data?['running'] == true;
    final exitCode = data?['exit_code'];
    final stdout = data?['stdout']?.toString() ?? '';
    final stderr = data?['stderr']?.toString() ?? '';

    if (command.isNotEmpty) {
      buf.writeln('\$ $command');
    }
    if (running) {
      buf.writeln('Status: sedang berjalan…');
    } else if (exitCode != null) {
      buf.writeln('Exit code: $exitCode${exitCode == 0 ? ' (ok)' : ' (gagal)'}');
    }
    // Papar hampir seluruh log (bukan 18 baris sahaja).
    final outTail = _tailLines(stdout, 400);
    final errTail = _tailLines(stderr, 120);
    if (outTail.isNotEmpty) {
      buf.writeln('--- stdout ---');
      buf.writeln(outTail);
    }
    if (errTail.isNotEmpty) {
      buf.writeln('--- stderr ---');
      buf.writeln(errTail);
    }
    final text = buf.toString().trim();
    if (text.isNotEmpty) return text;
    return result.output.trim().isNotEmpty
        ? result.output.trim()
        : (running ? 'Proses terminal sedang berjalan' : 'Terminal tiada output');
  }

  static String _tailLines(String text, int maxLines) {
    final lines = text.replaceAll('\r\n', '\n').split('\n').toList();
    if (lines.isEmpty) return '';
    // Untuk paparan step: ekor log. Chat console akan ambil snapshot penuh.
    final start = lines.length > maxLines ? lines.length - maxLines : 0;
    return lines.sublist(start).join('\n').trimRight();
  }

  String _eventDetail(String toolId, Map<String, dynamic> arguments) {
    switch (toolId) {
      case 'web_search':
        return arguments['query']?.toString() ?? 'Carian web';
      case 'browser_open':
      case 'open_url':
        return arguments['url']?.toString() ?? 'Membuka halaman';
      case 'browser_download':
        return arguments['filename']?.toString() ??
            arguments['url']?.toString() ??
            'Memuat turun fail';
      case 'file_read':
      case 'file_write':
      case 'file_delete':
        return arguments['path']?.toString() ?? 'Workspace local';
      case 'terminal_start':
        // Penuh — UI step boleh dikembang untuk lihat arahan shell sebenar.
        return arguments['command']?.toString() ?? '';
      case 'run_exe':
        return arguments['path']?.toString() ?? 'Menjalankan EXE via Wine';
      case 'delegate_agent':
        final task = arguments['task']?.toString() ?? '';
        return task.length > 120 ? '${task.substring(0, 120)}…' : task;
      default:
        return 'Berjalan di latar belakang';
    }
  }
}

/// Buang binary lampiran selepas model dah terima sekali (elak resend setiap tool step).
void _stripInlineAttachments(List<ChatMessage> messages) {
  for (var i = 0; i < messages.length; i++) {
    final m = messages[i];
    if (m.attachments.isEmpty) continue;
    final names = m.attachments.map((a) => a.name).join(', ');
    final meta = Map<String, dynamic>.from(m.metadata)..remove('attachments');
    final note = '[Lampiran sudah dihantar: $names]';
    messages[i] = m.copyWith(
      content: m.content.trim().isEmpty ? note : '${m.content}\n$note',
      metadata: meta,
    );
  }
}

class _SubExpertise {
  const _SubExpertise({
    required this.summary,
    required this.instructions,
    required this.defaultToolIds,
    required this.iconCode,
  });

  final String summary;
  final String instructions;
  final List<String> defaultToolIds;
  final int iconCode;
}

extension _FirstWhereOrNull<E> on Iterable<E> {
  E? firstWhereOrNull(bool Function(E item) test) {
    for (final item in this) {
      if (test(item)) return item;
    }
    return null;
  }
}
