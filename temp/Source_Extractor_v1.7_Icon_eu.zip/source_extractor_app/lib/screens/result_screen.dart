import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';
import '../providers/theme_provider.dart';
import '../models/extract_result.dart';
import '../services/zip_service.dart';
import '../services/mirror_service.dart';
import '../models/site_mirror.dart';
import '../widgets/code_view.dart';
import '../widgets/premium_button.dart';
import 'preview_screen.dart';

class ResultScreen extends StatefulWidget {
  final ExtractResult result;

  const ResultScreen({super.key, required this.result});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isZipping = false;
  bool _isMirroring = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  
  Future<void> _downloadMirror() async {
    setState(() => _isMirroring = true);
    try {
      final mirror = await MirrorService.createMirror(
        rawUrl: widget.result.url,
        html: widget.result.html,
        onProgress: (step) {
          // could show snackbar or update UI
        },
      );
      await MirrorService.shareAsZip(mirror);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Mirror ZIP: ${mirror.assets.length + 1} files')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal mirror: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isMirroring = false);
    }
  }

  Future<void> _downloadZip() async {
    setState(() => _isZipping = true);
    HapticFeedback.mediumImpact();
    try {
      await ZipService.createAndShareZip(widget.result);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ZIP berjaya dicipta')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isZipping = false);
    }
  }

  void _shareAll() {
    final text = '''
SOURCE EXTRACTOR
URL: ${widget.result.url}
Size: ${widget.result.formattedTotalSize}

===== HTML =====
${widget.result.html}

===== CSS =====
${widget.result.css}

===== JS =====
${widget.result.js}
''';
    Share.share(text, subject: 'Source - ${widget.result.url}');
  }

  void _copyCurrent() {
    String content;
    switch (_tabController.index) {
      case 0:
        content = widget.result.html;
        break;
      case 1:
        content = widget.result.css;
        break;
      default:
        content = widget.result.js;
    }
    Clipboard.setData(ClipboardData(text: content));
    HapticFeedback.selectionClick();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Disalin')),
    );
  }

  Future<void> _openOriginal() async {
    final uri = Uri.tryParse(widget.result.url);
    if (uri != null) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDark;
    final host = Uri.tryParse(widget.result.url)?.host ?? widget.result.url;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 6, 8, 0),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back_rounded),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          host,
                          style: GoogleFonts.spaceGrotesk(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          widget.result.formattedTotalSize,
                          style: TextStyle(
                            fontSize: 12,
                            color: isDark ? AppTheme.textMuted : AppTheme.lightTextMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: _openOriginal,
                    icon: const Icon(Icons.open_in_new_rounded, size: 20),
                    tooltip: 'Buka asal',
                  ),
                  IconButton(
                    onPressed: _copyCurrent,
                    icon: const Icon(Icons.copy_all_rounded, size: 20),
                    tooltip: 'Copy',
                  ),
                  IconButton(
                    onPressed: _shareAll,
                    icon: const Icon(Icons.share_rounded, size: 20),
                    tooltip: 'Share',
                  ),
                ],
              ),
            ),

            // Stats
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
              child: Row(
                children: [
                  _StatChip(label: 'HTML', value: _fmt(widget.result.htmlSize), color: const Color(0xFFE34C26)),
                  const SizedBox(width: 8),
                  _StatChip(label: 'CSS', value: _fmt(widget.result.cssSize), color: const Color(0xFF264DE4)),
                  const SizedBox(width: 8),
                  _StatChip(label: 'JS', value: _fmt(widget.result.jsSize), color: const Color(0xFFCA8A04)),
                ],
              ),
            ),

            // Tabs
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: isDark ? AppTheme.surfaceLight : AppTheme.lightSurfaceLight,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: isDark ? AppTheme.border : AppTheme.lightBorder),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: AppTheme.primary,
                unselectedLabelColor: isDark ? AppTheme.textMuted : AppTheme.lightTextMuted,
                labelStyle: GoogleFonts.spaceGrotesk(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
                tabs: const [
                  Tab(text: 'HTML'),
                  Tab(text: 'CSS'),
                  Tab(text: 'JS'),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // Code views
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    CodeView(code: widget.result.html, language: 'html'),
                    CodeView(code: widget.result.css, language: 'css'),
                    CodeView(code: widget.result.js, language: 'javascript'),
                  ],
                ),
              ),
            ),

            // Bottom bar
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(
                    color: (isDark ? AppTheme.border : AppTheme.lightBorder).withOpacity(0.7),
                  ),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: PremiumButton(
                      label: 'Full Mirror',
                      icon: Icons.account_tree_rounded,
                      isLoading: _isMirroring,
                      onPressed: _downloadMirror,
                    ),
                  ),
                  const SizedBox(width: 8),
                  PremiumButton(
                    label: 'Code ZIP',
                    icon: Icons.folder_zip_rounded,
                    isOutlined: true,
                    isLoading: _isZipping,
                    onPressed: _downloadZip,
                  ),
                  const SizedBox(width: 8),
                  PremiumButton(
                    label: 'Preview',
                    icon: Icons.visibility_rounded,
                    isOutlined: true,
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PreviewScreen(result: widget.result),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _fmt(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatChip({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color, letterSpacing: 0.5),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}
