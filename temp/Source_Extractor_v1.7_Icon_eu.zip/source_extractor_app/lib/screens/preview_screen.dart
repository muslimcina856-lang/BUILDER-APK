import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../theme/app_theme.dart';
import '../models/extract_result.dart';

class PreviewScreen extends StatefulWidget {
  final ExtractResult result;

  const PreviewScreen({super.key, required this.result});

  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _isLoading = false);
          },
        ),
      );

    // Load the extracted HTML directly
    final htmlContent = '''
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    /* Inject extracted CSS */
    ${widget.result.css}
  </style>
</head>
<body>
  ${widget.result.html.contains('<body') ? _extractBody(widget.result.html) : widget.result.html}
  <script>
    // Inject extracted JS (best effort)
    try {
      ${widget.result.js.replaceAll('</script>', '<\\/script>')}
    } catch(e) {}
  </script>
</body>
</html>
''';

    _controller.loadHtmlString(htmlContent, baseUrl: widget.result.url);
  }

  String _extractBody(String html) {
    final bodyMatch = RegExp(r'<body[^>]*>([\s\S]*)</body>', caseSensitive: false).firstMatch(html);
    if (bodyMatch != null) return bodyMatch.group(1) ?? html;
    return html;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LIVE PREVIEW'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () {
              setState(() => _isLoading = true);
              _controller.reload();
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            const Center(
              child: CircularProgressIndicator(color: AppTheme.primary),
            ),
        ],
      ),
    );
  }
}
