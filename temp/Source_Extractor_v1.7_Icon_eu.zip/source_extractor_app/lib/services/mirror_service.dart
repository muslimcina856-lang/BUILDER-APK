import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:archive/archive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';
import '../models/site_mirror.dart';

class MirrorService {
  static const _ua =
      'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';

  static Future<SiteMirror> createMirror({
    required String rawUrl,
    required String html,
    required void Function(String step) onProgress,
  }) async {
    String url = rawUrl.trim();
    if (!url.startsWith('http')) url = 'https://$url';
    final baseUri = Uri.parse(url);
    final host = baseUri.host;

    onProgress('Mencari semua aset...');

    // Collect all resource URLs
    final assetUrls = <String>{};

    // From HTML
    final patterns = [
      RegExp(r'''(?:href|src)=["']([^"']+)["']''', caseSensitive: false),
      RegExp(r'''url\(["']?([^"')]+)["']?\)''', caseSensitive: false),
      RegExp(r'''srcset=["']([^"']+)["']''', caseSensitive: false),
    ];

    for (final p in patterns) {
      for (final m in p.allMatches(html)) {
        final raw = m.group(1)!;
        // srcset can have multiple
        for (final part in raw.split(',')) {
          final u = part.trim().split(' ').first.trim();
          if (u.isNotEmpty && !u.startsWith('data:') && !u.startsWith('javascript:')) {
            assetUrls.add(u);
          }
        }
      }
    }

    onProgress('Menyusun ${assetUrls.length} aset...');

    final assets = <SiteAsset>[];
    final pathSet = <String>{};

    // Always keep index.html
    pathSet.add('index.html');

    int downloaded = 0;
    for (final rel in assetUrls) {
      try {
        final fullUrl = _resolve(rel, baseUri);
        if (fullUrl == null) continue;

        // Only same host or common CDNs for safety/speed
        final assetUri = Uri.parse(fullUrl);
        // Allow same host + common static CDNs
        final allowed = assetUri.host == host ||
            assetUri.host.endsWith(host) ||
            assetUri.host.contains('cdn') ||
            assetUri.host.contains('cloudflare') ||
            assetUri.host.contains('jsdelivr') ||
            assetUri.host.contains('unpkg') ||
            assetUri.host.contains('googleapis') ||
            assetUri.host.contains('gstatic');

        if (!allowed && assetUri.host != host) continue;

        onProgress('Download (${++downloaded}/${assetUrls.length}): ${assetUri.pathSegments.isNotEmpty ? assetUri.pathSegments.last : assetUri.host}');

        final res = await http.get(Uri.parse(fullUrl), headers: {'User-Agent': _ua})
            .timeout(const Duration(seconds: 12));

        if (res.statusCode != 200) continue;

        final localPath = _toLocalPath(assetUri, host);
        if (pathSet.contains(localPath)) continue;
        pathSet.add(localPath);

        final contentType = res.headers['content-type'] ?? 'application/octet-stream';
        assets.add(SiteAsset(
          originalUrl: fullUrl,
          localPath: localPath,
          contentType: contentType,
          bytes: res.bodyBytes,
          size: res.bodyBytes.length,
        ));
      } catch (_) {}
    }

    // Rewrite HTML links to local paths
    onProgress('Menulis semula link ke lokal...');
    String localHtml = html;
    for (final asset in assets) {
      // Replace absolute and relative versions
      localHtml = localHtml.replaceAll(asset.originalUrl, asset.localPath);
      // Also try path-only
      try {
        final pathOnly = Uri.parse(asset.originalUrl).path;
        if (pathOnly.isNotEmpty) {
          localHtml = localHtml.replaceAll('"$pathOnly"', '"${asset.localPath}"');
          localHtml = localHtml.replaceAll("'$pathOnly'", "'${asset.localPath}'");
        }
      } catch (_) {}
    }

    // Build tree text
    final tree = _buildTree(pathSet.toList()..sort());

    return SiteMirror(
      url: url,
      host: host,
      indexHtml: localHtml,
      assets: assets,
      extractedAt: DateTime.now(),
      treeText: tree,
    );
  }

  static Future<void> shareAsZip(SiteMirror mirror) async {
    final archive = Archive();

    // index.html
    final indexBytes = utf8.encode(mirror.indexHtml);
    archive.addFile(ArchiveFile('index.html', indexBytes.length, indexBytes));

    // All assets
    for (final asset in mirror.assets) {
      archive.addFile(ArchiveFile(asset.localPath, asset.bytes.length, asset.bytes));
    }

    // structure.txt
    final structure = '''
Source Extractor - Site Mirror
==============================
URL      : ${mirror.url}
Host     : ${mirror.host}
Extracted: ${mirror.extractedAt.toLocal()}
Total    : ${mirror.formattedTotalSize}
Files    : ${mirror.assets.length + 1}

DIRECTORY TREE
--------------
${mirror.treeText}
''';
    final structBytes = utf8.encode(structure);
    archive.addFile(ArchiveFile('structure.txt', structBytes.length, structBytes));

    final zipData = ZipEncoder().encode(archive);
    if (zipData == null) throw Exception('Gagal create ZIP');

    final dir = await getTemporaryDirectory();
    final safeHost = mirror.host.replaceAll(RegExp(r'[^a-zA-Z0-9.-]'), '_');
    final file = File('${dir.path}/mirror_${safeHost}_${DateTime.now().millisecondsSinceEpoch}.zip');
    await file.writeAsBytes(zipData);

    await Share.shareXFiles(
      [XFile(file.path)],
      text: 'Site mirror: ${mirror.url}',
      subject: 'Mirror - ${mirror.host}',
    );
  }

  static String? _resolve(String href, Uri base) {
    href = href.trim();
    if (href.isEmpty || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) {
      return null;
    }
    if (href.startsWith('http://') || href.startsWith('https://')) return href;
    if (href.startsWith('//')) return '${base.scheme}:$href';
    if (href.startsWith('/')) return '${base.scheme}://${base.host}$href';
    // relative
    final basePath = base.path.endsWith('/')
        ? base.path
        : base.path.substring(0, base.path.lastIndexOf('/') + 1);
    return '${base.scheme}://${base.host}$basePath$href';
  }

  static String _toLocalPath(Uri uri, String host) {
    // Keep path structure, remove leading slash
    String path = uri.path;
    if (path.startsWith('/')) path = path.substring(1);
    if (path.isEmpty) path = 'index';

    // If from different host (CDN), put under _cdn/hostname/
    if (uri.host != host && !uri.host.endsWith(host)) {
      path = '_cdn/${uri.host}/$path';
    }

    // Avoid empty or invalid
    path = path.replaceAll('..', '_');
    if (path.endsWith('/')) path += 'index.html';

    // Add extension if missing for common types
    if (!path.contains('.')) {
      path += '.html';
    }

    return path;
  }

  static String _buildTree(List<String> paths) {
    final buf = StringBuffer();
    buf.writeln('.');
    final sorted = paths.toSet().toList()..sort();
    for (final p in sorted) {
      final parts = p.split('/');
      final indent = '  ' * (parts.length - 1);
      buf.writeln('$indent├── ${parts.last}');
    }
    return buf.toString();
  }
}
