import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/extract_result.dart';

class HistoryService {
  static const _key = 'extract_history';
  static const _maxItems = 20;

  static Future<List<ExtractResult>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_key) ?? [];
    return list
        .map((e) {
          try {
            return ExtractResult.fromJson(jsonDecode(e));
          } catch (_) {
            return null;
          }
        })
        .whereType<ExtractResult>()
        .toList()
      ..sort((a, b) => b.extractedAt.compareTo(a.extractedAt));
  }

  static Future<void> addToHistory(ExtractResult result) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_key) ?? [];

    // Remove duplicate same URL
    list.removeWhere((e) {
      try {
        final r = ExtractResult.fromJson(jsonDecode(e));
        return r.url == result.url;
      } catch (_) {
        return false;
      }
    });

    list.insert(0, jsonEncode(result.toJson()));

    // Keep only latest
    if (list.length > _maxItems) {
      list.removeRange(_maxItems, list.length);
    }

    await prefs.setStringList(_key, list);
  }

  static Future<void> clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  static Future<void> removeItem(String url) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_key) ?? [];
    list.removeWhere((e) {
      try {
        final r = ExtractResult.fromJson(jsonDecode(e));
        return r.url == url;
      } catch (_) {
        return false;
      }
    });
    await prefs.setStringList(_key, list);
  }
}
