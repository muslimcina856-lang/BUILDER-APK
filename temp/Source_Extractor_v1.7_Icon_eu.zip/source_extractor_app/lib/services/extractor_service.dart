import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:webview_flutter/webview_flutter.dart';
import '../models/extract_result.dart';

class ExtractorService {
  static const _userAgent =
      'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';

  /// Real extraction using WebView (executes JS → better for Next.js / React / Vue)
  static Future<ExtractResult> extractWithWebView({
    required String rawUrl,
    required void Function(String step) onProgress,
  }) async {
    String url = rawUrl.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url';
    }

    final uri = Uri.tryParse(url);
    if (uri == null || !uri.hasAuthority) {
      throw Exception('URL tidak valid.');
    }

    onProgress('Menyediakan browser...');

    final completer = Completer<ExtractResult>();
    late WebViewController controller;
    bool hasFinished = false;

    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(_userAgent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            onProgress('Memuat halaman...');
          },
          onPageFinished: (String finishedUrl) async {
            if (hasFinished) return;
            hasFinished = true;

            try {
              onProgress('Menunggu JavaScript selesai...');
              // Give time for Next.js / React hydration
              await Future.delayed(const Duration(milliseconds: 2200));

              onProgress('Mengambil HTML...');
              final htmlResult = await controller.runJavaScriptReturningResult(
                'document.documentElement.outerHTML',
              );
              final html = _cleanJsResult(htmlResult.toString());

              onProgress('Mengambil CSS...');
              final cssResult = await controller.runJavaScriptReturningResult('''
                (function() {
                  let css = '';
                  document.querySelectorAll('style').forEach((s, i) => {
                    css += '/* ===== INLINE STYLE #' + (i+1) + ' ===== */\\n';
                    css += s.innerHTML + '\\n\\n';
                  });
                  document.querySelectorAll('link[rel="stylesheet"]').forEach(link => {
                    css += '/* ===== LINK: ' + link.href + ' ===== */\\n';
                    try {
                      if (link.sheet && link.sheet.cssRules) {
                        for (let rule of link.sheet.cssRules) {
                          css += rule.cssText + '\\n';
                        }
                      } else {
                        css += '/* (external - akan cuba fetch) */\\n';
                      }
                    } catch(e) {
                      css += '/* CORS blocked: ' + link.href + ' */\\n';
                    }
                    css += '\\n';
                  });
                  return css;
                })()
              ''');
              String css = _cleanJsResult(cssResult.toString());

              // Fetch external CSS that WebView couldn't read due to CORS
              css = await _enrichExternalCss(css, html, uri);

              onProgress('Mengambil JavaScript...');
              final jsResult = await controller.runJavaScriptReturningResult('''
                (function() {
                  let js = '';
                  let i = 0;
                  document.querySelectorAll('script').forEach(s => {
                    if (s.src) {
                      js += '/* ===== EXTERNAL: ' + s.src + ' ===== */\\n';
                      js += '// Source: ' + s.src + '\\n\\n';
                    } else if (s.innerHTML && s.innerHTML.trim().length > 0) {
                      i++;
                      js += '/* ===== INLINE SCRIPT #' + i + ' ===== */\\n';
                      js += s.innerHTML + '\\n\\n';
                    }
                  });
                  return js;
                })()
              ''');
              String js = _cleanJsResult(jsResult.toString());

              // Also try to fetch external JS files
              js = await _enrichExternalJs(js, html, uri);

              final result = ExtractResult(
                url: url,
                html: _beautifyHtml(html),
                css: css.isEmpty ? '/* Tiada CSS dijumpai */' : css,
                js: js.isEmpty ? '/* Tiada JavaScript dijumpai */' : js,
                extractedAt: DateTime.now(),
                htmlSize: utf8.encode(html).length,
                cssSize: utf8.encode(css).length,
                jsSize: utf8.encode(js).length,
              );

              if (!completer.isCompleted) completer.complete(result);
            } catch (e) {
              if (!completer.isCompleted) {
                completer.completeError(Exception('Gagal extract: $e'));
              }
            }
          },
          onWebResourceError: (error) {
            if (!completer.isCompleted) {
              completer.completeError(Exception('Ralat load: ${error.description}'));
            }
          },
        ),
      );

    // Timeout safety
    Future.delayed(const Duration(seconds: 45), () {
      if (!completer.isCompleted) {
        completer.completeError(Exception('Timeout. Website ambil masa terlalu lama.'));
      }
    });

    onProgress('Membuka website...');
    await controller.loadRequest(Uri.parse(url));

    return completer.future;
  }

  /// Fallback simple HTTP extraction (faster, less complete)
  static Future<ExtractResult> extractHttp(String rawUrl) async {
    String url = rawUrl.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url';
    }

    final uri = Uri.tryParse(url);
    if (uri == null || !uri.hasAuthority) {
      throw Exception('URL tidak valid.');
    }

    final response = await http.get(
      uri,
      headers: {
        'User-Agent': _userAgent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      },
    ).timeout(const Duration(seconds: 25));

    if (response.statusCode < 200 || response.statusCode >= 400) {
      throw Exception('Gagal load (Status ${response.statusCode})');
    }

    final htmlRaw = response.body;
    final results = await Future.wait([
      _extractCssHttp(htmlRaw, uri),
      _extractJsHttp(htmlRaw, uri),
    ]);

    return ExtractResult(
      url: url,
      html: _beautifyHtml(htmlRaw),
      css: results[0],
      js: results[1],
      extractedAt: DateTime.now(),
      htmlSize: utf8.encode(htmlRaw).length,
      cssSize: utf8.encode(results[0]).length,
      jsSize: utf8.encode(results[1]).length,
    );
  }

  // ========== Helpers ==========

  static String _cleanJsResult(String input) {
    if (input.startsWith('"') && input.endsWith('"')) {
      input = input.substring(1, input.length - 1);
    }
    return input
        .replaceAll(r'\"', '"')
        .replaceAll(r'\n', '\n')
        .replaceAll(r'\t', '\t')
        .replaceAll(r'\\', '\\')
        .replaceAll(r'\u003C', '<');
  }

  static Future<String> _enrichExternalCss(String css, String html, Uri base) async {
    final hrefs = <String>{};
    final regex = RegExp(
      r'''<link[^>]*rel=["']stylesheet["'][^>]*href=["']([^"']+)["'][^>]*>''',
      caseSensitive: false,
    );
    final regex2 = RegExp(
      r'''<link[^>]*href=["']([^"']+)["'][^>]*rel=["']stylesheet["'][^>]*>''',
      caseSensitive: false,
    );
    for (final m in regex.allMatches(html)) hrefs.add(m.group(1)!);
    for (final m in regex2.allMatches(html)) hrefs.add(m.group(1)!);

    final buffer = StringBuffer(css);
    for (final href in hrefs) {
      if (href.startsWith('data:')) continue;
      if (css.contains(href)) continue; // already tried
      try {
        final full = _resolveUrl(href, base);
        final res = await http.get(Uri.parse(full), headers: {'User-Agent': _userAgent})
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) {
          buffer.writeln('\n/* ===== FETCHED: $full ===== */');
          buffer.writeln(res.body);
        }
      } catch (_) {}
    }
    return buffer.toString();
  }

  static Future<String> _enrichExternalJs(String js, String html, Uri base) async {
    final srcs = <String>{};
    final regex = RegExp(r'''<script[^>]*src=["']([^"']+)["'][^>]*>''', caseSensitive: false);
    for (final m in regex.allMatches(html)) srcs.add(m.group(1)!);

    final buffer = StringBuffer(js);
    for (final src in srcs) {
      if (src.startsWith('data:')) continue;
      if (js.contains(src)) continue;
      try {
        final full = _resolveUrl(src, base);
        final res = await http.get(Uri.parse(full), headers: {'User-Agent': _userAgent})
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) {
          final body = res.body;
          buffer.writeln('\n/* ===== FETCHED: $full ===== */');
          if (body.length > 2 * 1024 * 1024) {
            buffer.writeln('/* truncated (too large) */');
            buffer.writeln(body.substring(0, 120 * 1024));
          } else {
            buffer.writeln(body);
          }
        }
      } catch (_) {}
    }
    return buffer.toString();
  }

  static Future<String> _extractCssHttp(String html, Uri base) async {
    final buffer = StringBuffer();
    final styleRegex = RegExp(r'<style[^>]*>([\s\S]*?)</style>', caseSensitive: false);
    int i = 0;
    for (final m in styleRegex.allMatches(html)) {
      final c = m.group(1)?.trim() ?? '';
      if (c.isNotEmpty) {
        i++;
        buffer.writeln('/* INLINE #$i */\n$c\n');
      }
    }
    final hrefs = <String>{};
    for (final m in RegExp(r'''href=["']([^"']+\.css[^"']*)["']''', caseSensitive: false).allMatches(html)) {
      hrefs.add(m.group(1)!);
    }
    for (final href in hrefs) {
      try {
        final full = _resolveUrl(href, base);
        final res = await http.get(Uri.parse(full), headers: {'User-Agent': _userAgent}).timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) buffer.writeln('/* $full */\n${res.body}\n');
      } catch (_) {}
    }
    return buffer.toString().trim().isEmpty ? '/* Tiada CSS */' : buffer.toString();
  }

  static Future<String> _extractJsHttp(String html, Uri base) async {
    final buffer = StringBuffer();
    final inline = RegExp(r'<script(?![^>]*src)[^>]*>([\s\S]*?)</script>', caseSensitive: false);
    int i = 0;
    for (final m in inline.allMatches(html)) {
      final c = m.group(1)?.trim() ?? '';
      if (c.isNotEmpty) {
        i++;
        buffer.writeln('/* INLINE #$i */\n$c\n');
      }
    }
    final srcs = <String>{};
    for (final m in RegExp(r'''src=["']([^"']+\.js[^"']*)["']''', caseSensitive: false).allMatches(html)) {
      srcs.add(m.group(1)!);
    }
    for (final src in srcs) {
      try {
        final full = _resolveUrl(src, base);
        final res = await http.get(Uri.parse(full), headers: {'User-Agent': _userAgent}).timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) {
          buffer.writeln('/* $full */\n${res.body.length > 1500000 ? res.body.substring(0, 120000) + "\n/* truncated */" : res.body}\n');
        }
      } catch (_) {}
    }
    return buffer.toString().trim().isEmpty ? '/* Tiada JS */' : buffer.toString();
  }

  static String _resolveUrl(String href, Uri base) {
    href = href.trim();
    if (href.startsWith('http')) return href;
    if (href.startsWith('//')) return '${base.scheme}:$href';
    if (href.startsWith('/')) return '${base.scheme}://${base.host}$href';
    final path = base.path.endsWith('/') ? base.path : '${base.path.substring(0, base.path.lastIndexOf('/') + 1)}';
    return '${base.scheme}://${base.host}$path$href';
  }

  static String _beautifyHtml(String html) {
    return html.replaceAllMapped(RegExp(r'>(\s*)<'), (m) => '>\n<').replaceAll(RegExp(r'\n{3,}'), '\n\n');
  }
}
