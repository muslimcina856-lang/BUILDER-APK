class SiteAsset {
  final String originalUrl;
  final String localPath; // relative path inside the zip
  final String contentType;
  final List<int> bytes;
  final int size;

  SiteAsset({
    required this.originalUrl,
    required this.localPath,
    required this.contentType,
    required this.bytes,
    required this.size,
  });
}

class SiteMirror {
  final String url;
  final String host;
  final String indexHtml;
  final List<SiteAsset> assets;
  final DateTime extractedAt;
  final String treeText;

  SiteMirror({
    required this.url,
    required this.host,
    required this.indexHtml,
    required this.assets,
    required this.extractedAt,
    required this.treeText,
  });

  int get totalSize => assets.fold(0, (sum, a) => sum + a.size) + indexHtml.length;

  String get formattedTotalSize {
    final s = totalSize;
    if (s < 1024) return '$s B';
    if (s < 1024 * 1024) return '${(s / 1024).toStringAsFixed(1)} KB';
    return '${(s / (1024 * 1024)).toStringAsFixed(2)} MB';
  }
}
