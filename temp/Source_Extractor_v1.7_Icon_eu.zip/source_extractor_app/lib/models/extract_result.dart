class ExtractResult {
  final String url;
  final String html;
  final String css;
  final String js;
  final DateTime extractedAt;
  final int htmlSize;
  final int cssSize;
  final int jsSize;

  ExtractResult({
    required this.url,
    required this.html,
    required this.css,
    required this.js,
    required this.extractedAt,
    required this.htmlSize,
    required this.cssSize,
    required this.jsSize,
  });

  int get totalSize => htmlSize + cssSize + jsSize;

  String get formattedTotalSize {
    if (totalSize < 1024) return '$totalSize B';
    if (totalSize < 1024 * 1024) {
      return '${(totalSize / 1024).toStringAsFixed(1)} KB';
    }
    return '${(totalSize / (1024 * 1024)).toStringAsFixed(2)} MB';
  }

  Map<String, dynamic> toJson() => {
        'url': url,
        'html': html,
        'css': css,
        'js': js,
        'extractedAt': extractedAt.toIso8601String(),
        'htmlSize': htmlSize,
        'cssSize': cssSize,
        'jsSize': jsSize,
      };

  factory ExtractResult.fromJson(Map<String, dynamic> json) {
    return ExtractResult(
      url: json['url'] as String,
      html: json['html'] as String,
      css: json['css'] as String,
      js: json['js'] as String,
      extractedAt: DateTime.parse(json['extractedAt'] as String),
      htmlSize: json['htmlSize'] as int,
      cssSize: json['cssSize'] as int,
      jsSize: json['jsSize'] as int,
    );
  }
}
