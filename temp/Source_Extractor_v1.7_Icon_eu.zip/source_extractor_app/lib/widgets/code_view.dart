import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_highlight/flutter_highlight.dart';
import 'package:flutter_highlight/themes/atom-one-dark.dart';
import 'package:flutter_highlight/themes/github.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/theme_provider.dart';

class CodeView extends StatefulWidget {
  final String code;
  final String language;
  final VoidCallback? onCopy;

  const CodeView({
    super.key,
    required this.code,
    required this.language,
    this.onCopy,
  });

  @override
  State<CodeView> createState() => _CodeViewState();
}

class _CodeViewState extends State<CodeView> {
  final _searchController = TextEditingController();
  bool _showSearch = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().isDark;
    final theme = isDark ? atomOneDarkTheme : githubTheme;

    final hasCode = widget.code.trim().isNotEmpty &&
        !widget.code.startsWith('/* Tiada') &&
        !widget.code.startsWith('/* No');

    return Column(
      children: [
        // Header
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: isDark ? AppTheme.surfaceLight : AppTheme.lightSurfaceLight,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
            border: Border.all(color: isDark ? AppTheme.border : AppTheme.lightBorder),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  widget.language.toUpperCase(),
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primary,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                _formatSize(widget.code.length),
                style: TextStyle(
                  fontSize: 12,
                  color: isDark ? AppTheme.textMuted : AppTheme.lightTextMuted,
                ),
              ),
              const SizedBox(width: 6),
              IconButton(
                onPressed: () => setState(() => _showSearch = !_showSearch),
                icon: Icon(
                  _showSearch ? Icons.search_off_rounded : Icons.search_rounded,
                  size: 18,
                ),
                color: isDark ? AppTheme.textSecondary : AppTheme.lightTextSecondary,
                visualDensity: VisualDensity.compact,
              ),
              IconButton(
                onPressed: hasCode
                    ? () {
                        Clipboard.setData(ClipboardData(text: widget.code));
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('${widget.language.toUpperCase()} disalin')),
                        );
                        widget.onCopy?.call();
                      }
                    : null,
                icon: const Icon(Icons.copy_rounded, size: 18),
                color: isDark ? AppTheme.textSecondary : AppTheme.lightTextSecondary,
                visualDensity: VisualDensity.compact,
              ),
            ],
          ),
        ),

        if (_showSearch)
          Container(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            color: isDark ? AppTheme.surfaceLight : AppTheme.lightSurfaceLight,
            child: TextField(
              controller: _searchController,
              autofocus: true,
              style: const TextStyle(fontSize: 14),
              decoration: const InputDecoration(
                hintText: 'Cari...',
                isDense: true,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                prefixIcon: Icon(Icons.search, size: 18),
              ),
            ),
          ),

        // Code area
        Expanded(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF0F0F0F) : const Color(0xFFFAFAFA),
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(8)),
              border: Border.all(color: isDark ? AppTheme.border : AppTheme.lightBorder),
            ),
            child: !hasCode
                ? Center(
                    child: Text(
                      'Tiada ${widget.language} dijumpai',
                      style: TextStyle(
                        color: isDark ? AppTheme.textMuted : AppTheme.lightTextMuted,
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    padding: const EdgeInsets.all(14),
                    child: HighlightView(
                      widget.code,
                      language: widget.language,
                      theme: theme,
                      textStyle: GoogleFonts.jetBrainsMono(
                        fontSize: 12.5,
                        height: 1.5,
                      ),
                      padding: EdgeInsets.zero,
                    ),
                  ),
          ),
        ),
      ],
    );
  }

  String _formatSize(int length) {
    if (length < 1024) return '$length B';
    if (length < 1024 * 1024) return '${(length / 1024).toStringAsFixed(1)} KB';
    return '${(length / (1024 * 1024)).toStringAsFixed(2)} MB';
  }
}
