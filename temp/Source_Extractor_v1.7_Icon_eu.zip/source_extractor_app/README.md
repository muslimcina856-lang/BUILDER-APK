# Source Extractor

Industrial Utility tool untuk extract & mirror website.

## Features

### Extraction
- Real WebView extraction (support Next.js, React, Vue, etc.)
- HTML + CSS + JS view dengan syntax highlighting
- Live Preview

### Full Site Mirror (Directory Tree)
- Scan semua aset (CSS, JS, images, fonts, etc.)
- Download ikut struktur path asal
- ZIP mengandungi folder tree yang kemas
- Ada `structure.txt` yang tunjuk directory tree
- `index.html` sudah di-rewrite link ke lokal

### Lain-lain
- History
- Dark / Light mode
- Share
- Industrial design

## Butang di Result Screen
- **Full Mirror** → ZIP dengan directory tree lengkap
- **Code ZIP** → HTML + CSS + JS sahaja (ringkas)
- **Preview** → Live preview

## Run
```bash
flutter pub get
flutter run
```
