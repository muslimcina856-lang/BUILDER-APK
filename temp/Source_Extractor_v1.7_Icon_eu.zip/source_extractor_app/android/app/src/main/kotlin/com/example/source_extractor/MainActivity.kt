package com.example.source_extractor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
