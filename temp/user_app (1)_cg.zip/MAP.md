# Earl Builder User App — MAP

## Peranan

Aplikasi Flutter untuk pengguna Earl Builder. Versi semasa ialah **link-only**:
pengguna menghantar pautan projek dan nama fail hasil pilihan. Aplikasi tidak
memilih atau mengupload fail ZIP secara terus dalam aliran semasa.

## Aliran permulaan

1. `lib/main.dart` memuatkan bahasa tersimpan.
2. Pengguna baharu melihat `LanguageSelectScreen` dan memilih English, Melayu
   atau Indonesia.
3. `HomeScreen` mendapatkan Device ID kekal daripada Android SSAID dan
   menyimpannya dalam `SharedPreferences` sebagai `device_<ssaid>`.
4. Aplikasi mendaftar atau mendapatkan pengguna daripada backend. Pengguna
   baharu bermula dengan 5 kredit.
5. Status server diperiksa setiap 5 saat.
6. Status queue build diperiksa setiap 15 saat; iklan hanya diminta apabila popup Free Credits dibuka.

## Struktur utama

```text
user_app/ (projek Flutter yang digunakan oleh pengguna Earl Builder)
├── lib/ (semua kod Dart utama aplikasi)
│   ├── main.dart (entry point, muat bahasa dan pilih skrin permulaan)
│   ├── config.dart (URL backend, nama aplikasi dan pautan berkaitan)
│   ├── i18n/
│   │   └── app_strings.dart (semua teks English, Melayu dan Indonesia)
│   ├── theme/
│   │   └── app_theme.dart (warna, spacing, typography dan gaya UI User App)
│   ├── models/
│   │   └── upload_history.dart (model rekod sejarah submission setempat)
│   ├── services/
│   │   ├── api_service.dart (semua komunikasi dengan Vercel API)
│   │   ├── storage_service.dart (Device ID dan sejarah submission dalam SharedPreferences)
│   │   └── language_service.dart (simpan dan tukar bahasa aplikasi)
│   └── screens/
│       ├── language_select_screen.dart (pilihan bahasa pada pelancaran pertama)
│       ├── home_screen.dart (dashboard pengguna, kredit, queue dan menu Free Credits/My Ads)
│       ├── my_ads_screen.dart (pemantauan read-only progress iklan pembeli)
│       ├── upload_screen.dart (hantar pautan projek dan nama fail hasil pilihan)
│       ├── bind_telegram_screen.dart (bind, sahkan dan unbind akaun Telegram)
│       ├── claim_code_screen.dart (tebus kod kredit)
│       ├── ad_view_screen.dart (papar iklan, kira 30 saat dan tuntut ganjaran)
│       └── about_screen.dart (maklumat aplikasi, pautan dan pertukaran bahasa)
├── android/ (konfigurasi binaan dan signing Android)
├── ios/ (konfigurasi binaan iOS)
├── web/ (konfigurasi binaan web)
├── windows/ (konfigurasi binaan Windows)
├── linux/ (konfigurasi binaan Linux)
├── macos/ (konfigurasi binaan macOS)
├── pubspec.yaml (dependencies, aset dan metadata projek Flutter)
├── analysis_options.yaml (peraturan lint dan analisis Dart)
├── README.md (panduan umum projek)
├── SECURITY.md (panduan keselamatan)
├── CHANGELOG.md (rekod perubahan versi)
└── MAP.md (peta dan penerangan codebase User App)
```

## Skrin

| Skrin | Fail | Fungsi sebenar |
|---|---|---|
| Language Select | `language_select_screen.dart` | Pilih bahasa pada pelancaran pertama |
| Home | `home_screen.dart` | Kredit, jumlah submission, Device ID, status Telegram, queue build, popup Free Credits, menu My Ads dan maintenance lock |
| My Ads | `my_ads_screen.dart` | Senarai read-only iklan milik Device ID/Telegram pengguna serta progress views atau hari |
| Submit Project | `upload_screen.dart` | Terima pautan projek dan nama fail hasil pilihan; hantar kepada `/api/upload/link` |
| Bind Telegram | `bind_telegram_screen.dart` | Ikat Telegram melalui kod enam digit, countdown lima minit dan fungsi unbind |
| Redeem Code | `claim_code_screen.dart` | Tebus kod kredit daripada owner |
| Watch Ad | `ad_view_screen.dart` | Mainkan iklan imej/video yang dipilih melalui popup Free Credits, kira 30 saat tontonan sah dan tuntut kredit |
| About / Settings | `about_screen.dart` | Maklumat aplikasi, pautan owner/channel dan tukar bahasa |

## Submission projek

Aliran semasa:

1. Pengguna mesti mempunyai Telegram yang sudah terikat.
2. Pengguna masukkan URL projek.
3. Pengguna boleh masukkan nama hasil sehingga 80 aksara.
4. User App menghantar `device_id`, `project_url` dan `file_name` pilihan kepada
   `POST /api/upload/link`.
5. Backend menyimpan URL tersebut sebagai fail `.txt` dalam repo build dan
   memulakan GitHub Actions.
6. Satu kredit dipotong apabila submission diterima untuk dihantar.
7. Sejarah hasil disimpan secara tempatan sahaja, maksimum 10 rekod.

Nama pilihan dibersihkan oleh backend. Extension seperti `.zip`, `.txt`, `.apk`,
`.aab` dan `.apks` dibuang, kemudian `.txt` ditambah semula. Backend menambah
suffix rawak empat aksara untuk mengelakkan nama bertindih.

Tiada pemilihan fail, upload ZIP terus atau pemeriksaan kandungan ZIP dilakukan
oleh `upload_screen.dart` dalam versi semasa.

## Sistem iklan dan kredit percuma

- Backend memberikan satu iklan aktif secara rawak daripada pool semua iklan aktif apabila pengguna menekan **Watch Ads** dalam popup Free Credits.
- Halaman utama tidak memaparkan kad iklan atau butang Watch Now.
- Iklan yang dipilih dihantar terus kepada `AdViewScreen`; skrin tontonan tidak meminta iklan kedua.
- My Ads memaparkan iklan yang sepadan dengan Device ID atau Telegram ID pengguna secara read-only, tanpa mendedahkan ID pembeli kepada penonton lain.
- Iklan boleh berupa imej atau video dan boleh mempunyai URL klik.
- Countdown bermula hanya selepas media benar-benar sedia.
- Untuk video, countdown hanya berjalan ketika video sedang dimainkan dan tidak buffering.
- Tontonan minimum ialah 30 saat.
- Ganjaran ditentukan oleh backend secara rawak sama rata antara 1 hingga 10 kredit.
- Had tuntutan ialah 10 iklan sehari bagi setiap Device ID.
- Reset harian backend menggunakan tarikh `Asia/Kuala_Lumpur`.
- Iklan yang telah mencapai had views atau tempoh days tidak lagi aktif.

## Maintenance dan status server

- `GET /api/health` membezakan server online, maintenance dan backend/database
  yang tidak dapat dicapai.
- Ketika maintenance atau server unavailable, semua tindakan utama dikunci.
- URL muzik yang ditetapkan owner dimainkan secara loop pada overlay maintenance.
- Queue GitHub Actions dipaparkan bersama anggaran `queue × 5 minit`.

## Data setempat

| Data | Lokasi | Catatan |
|---|---|---|
| Device ID | `SharedPreferences` | Berdasarkan Android SSAID; fallback kepada timestamp |
| Bahasa | `SharedPreferences` | `en`, `ms` atau `id` |
| Sejarah submission | `SharedPreferences` | Maksimum 10 rekod; bukan status live daripada GitHub |

## Data dihantar kepada backend

- Device ID.
- Telegram ID dan kod pengesahan apabila pengguna memilih untuk bind.
- Kod kredit yang hendak ditebus.
- URL projek dan nama fail pilihan.
- ID iklan serta nilai `watch_seconds` semasa tuntutan ganjaran.

Aplikasi tidak meminta lokasi, kamera, mikrofon, contacts atau advertising ID.

## Route backend yang digunakan

| Method | Route | Kegunaan |
|---|---|---|
| `GET` | `/api/health` | Status server dan maintenance |
| `GET` | `/api/build/status` | Queue build GitHub Actions |
| `POST` | `/api/user/register` | Daftar/dapatkan pengguna |
| `GET` | `/api/user/me` | Kredit, Telegram dan jumlah submission |
| `POST` | `/api/user/bind-telegram` | Minta kod pengesahan Telegram |
| `POST` | `/api/user/bind-telegram/confirm` | Sahkan kod Telegram |
| `POST` | `/api/user/unbind-telegram` | Putuskan ikatan Telegram |
| `POST` | `/api/user/claim-code` | Tebus kod kredit |
| `GET` | `/api/user/ads` | Ambil satu iklan aktif secara rawak dan baki harian |
| `GET` | `/api/user/my-ads` | Ambil senarai read-only iklan milik pengguna |
| `POST` | `/api/user/claim-ad-reward` | Tuntut ganjaran selepas 30 saat |
| `POST` | `/api/upload/link` | Hantar pautan projek dan nama fail pilihan |

## Dependencies

Digunakan dalam source semasa:

- `dio` — HTTP API.
- `shared_preferences` — bahasa, Device ID dan sejarah.
- `provider` — state bahasa.
- `url_launcher` — pautan Telegram, iklan dan About.
- `android_id` — Android SSAID.
- `just_audio` — muzik maintenance.
- `video_player` — video iklan.

Dideklarasikan tetapi tidak dirujuk oleh fail dalam `lib/` versi semasa:

- `file_picker`
- `archive`
- `path_provider`

## Permission Android

Manifest mendeklarasikan:

- `INTERNET`
- `ACCESS_NETWORK_STATE`
- `POST_NOTIFICATIONS`
- `WAKE_LOCK`

Tiada broad storage permission atau all-files permission. Aliran semasa juga
tidak menggunakan file picker.

## Konfigurasi

- Tetapkan `AppConfig.baseUrl` dalam `lib/config.dart` kepada deployment Vercel,
  tanpa `/` di hujung.
- Semua key terjemahan baharu perlu ditambah dalam ketiga-tiga bahasa di
  `lib/i18n/app_strings.dart`.
- Fail signing sebenar tidak disertakan; gunakan
  `android/key.properties.example` sebagai template.
