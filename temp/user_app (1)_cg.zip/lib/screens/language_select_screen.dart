import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../i18n/app_strings.dart';
import '../services/language_service.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';

class LanguageSelectScreen extends StatefulWidget {
  const LanguageSelectScreen({super.key});

  @override
  State<LanguageSelectScreen> createState() => _LanguageSelectScreenState();
}

class _LanguageSelectScreenState extends State<LanguageSelectScreen> {
  AppLanguage _selected = AppLanguage.en;

  void _continue() {
    context.read<LanguageService>().setLanguage(_selected);
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.xxl),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(AppRadius.hero),
                ),
                alignment: Alignment.center,
                child: const Icon(
                  Icons.language_rounded,
                  size: AppIcons.hero,
                  color: AppColors.onAccent,
                ),
              ),
              const SizedBox(height: AppSpacing.xl),
              Text(
                AppStrings.of(_selected, 'lang_select_title'),
                style: AppText.title,
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                AppStrings.of(_selected, 'lang_select_subtitle'),
                style: AppText.subtitle,
              ),
              const SizedBox(height: AppSpacing.xxxl),
              _LanguageOption(
                label: 'English',
                selected: _selected == AppLanguage.en,
                onTap: () => setState(() => _selected = AppLanguage.en),
              ),
              const SizedBox(height: AppSpacing.sm),
              _LanguageOption(
                label: 'Bahasa Melayu',
                selected: _selected == AppLanguage.ms,
                onTap: () => setState(() => _selected = AppLanguage.ms),
              ),
              const SizedBox(height: AppSpacing.sm),
              _LanguageOption(
                label: 'Bahasa Indonesia',
                selected: _selected == AppLanguage.id,
                onTap: () => setState(() => _selected = AppLanguage.id),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _continue,
                  child: Text(AppStrings.of(_selected, 'lang_select_continue')),
                ),
              ),
              const SizedBox(height: AppSpacing.md),
            ],
          ),
        ),
      ),
    );
  }
}

class _LanguageOption extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _LanguageOption({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? AppColors.accent.withAlpha(25) : AppColors.bgElevated,
      borderRadius: BorderRadius.circular(AppRadius.card),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppRadius.card),
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg,
            vertical: AppSpacing.lg,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadius.card),
            border: Border.all(
              color: selected ? AppColors.accent : Colors.transparent,
            ),
          ),
          child: Row(
            children: [
              Icon(
                selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                color: selected ? AppColors.accent : AppColors.textMuted,
                size: AppIcons.md,
              ),
              const SizedBox(width: AppSpacing.md),
              Text(
                label,
                style: AppText.body.copyWith(
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: selected ? AppColors.accent : AppColors.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
