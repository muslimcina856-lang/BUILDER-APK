import 'package:flutter/material.dart';
import 'package:earl_builder/i18n/app_strings.dart';
import 'package:earl_builder/services/api_service.dart';
import 'package:earl_builder/theme/app_theme.dart';

class ClaimCodeScreen extends StatefulWidget {
  final String deviceId;
  const ClaimCodeScreen({super.key, required this.deviceId});

  @override
  State<ClaimCodeScreen> createState() => _ClaimCodeScreenState();
}

class _ClaimCodeScreenState extends State<ClaimCodeScreen> {
  final _controller = TextEditingController();
  bool _isLoading = false;
  bool _isSuccess = false;
  String? _resultMessage;
  int? _newCredits;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _claim() async {
    final code = _controller.text.trim();
    if (code.isEmpty) {
      setState(() {
        _resultMessage = trStatic(context, 'claim_enter_code');
        _isSuccess = false;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _resultMessage = null;
    });

    try {
      final result = await ApiService.claimCode(widget.deviceId, code);
      if (!mounted) return;
      setState(() {
        _isSuccess = result['success'] == true;
        _resultMessage = (result['message'] ?? '').toString();
        _newCredits = result['credits'] as int?;
      });
      if (_isSuccess) _controller.clear();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSuccess = false;
        _resultMessage = '${trStatic(context, 'upload_failed_colon')} $e';
      });
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'home_redeem_code_title'))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.xxl,
            AppSpacing.xl,
            AppSpacing.xxl,
            AppSpacing.huge,
          ),
          children: [
            Text(tr(context, 'claim_title'), style: AppText.title),
            const SizedBox(height: AppSpacing.sm),
            Text(
              tr(context, 'claim_subtitle'),
              style: AppText.subtitle,
            ),
            const SizedBox(height: AppSpacing.xxl),
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: tr(context, 'claim_code_label'),
                hintText: 'XXXX-XXXX-XXXX',
                prefixIcon: const Icon(
                  Icons.redeem_rounded,
                  size: AppIcons.md,
                  color: AppColors.textSecondary,
                ),
              ),
              textCapitalization: TextCapitalization.characters,
              autocorrect: false,
              maxLength: 14,
              style: AppText.body.copyWith(
                fontFamily: 'monospace',
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _claim,
                child: _isLoading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.onAccent,
                        ),
                      )
                    : Text(tr(context, 'claim_redeem_button')),
              ),
            ),
            if (_resultMessage != null) ...[
              const SizedBox(height: AppSpacing.xl),
              _ResultCard(
                isSuccess: _isSuccess,
                message: _resultMessage!,
                newCredits: _newCredits,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final bool isSuccess;
  final String message;
  final int? newCredits;

  const _ResultCard({
    required this.isSuccess,
    required this.message,
    this.newCredits,
  });

  @override
  Widget build(BuildContext context) {
    final color = isSuccess ? AppColors.success : AppColors.error;
    return Container(
      padding: const EdgeInsets.all(AppSpacing.lg),
      decoration: BoxDecoration(
        color: color.withAlpha(15),
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: color.withAlpha(60)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isSuccess ? Icons.check_circle_rounded : Icons.error_rounded,
                size: AppIcons.md,
                color: color,
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Text(
                  message,
                  style: AppText.body.copyWith(color: color),
                ),
              ),
            ],
          ),
          if (newCredits != null) ...[
            const SizedBox(height: AppSpacing.md),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.md,
                vertical: AppSpacing.sm,
              ),
              decoration: BoxDecoration(
                color: AppColors.bgRaised,
                borderRadius: BorderRadius.circular(AppRadius.input),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.account_balance_wallet_rounded,
                    size: AppIcons.sm,
                    color: AppColors.accent,
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Text(
                    '${tr(context, 'claim_new_balance')} $newCredits ${tr(context, 'claim_credits')}',
                    style: AppText.body.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppColors.accent,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
