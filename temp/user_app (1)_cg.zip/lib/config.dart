/// Centralized configuration for Earl Builder User App.
///
/// ╔═══════════════════════════════════════════════════════╗
/// ║  HARDCODED — Edit values below before building       ║
/// ╚═══════════════════════════════════════════════════════╝
class AppConfig {
  /// URL of your Vercel deployment (NO trailing slash)
  /// Example: 'https://earl-builder.vercel.app'
  static const String baseUrl = 'https://apikey-botbuild-w9qg.vercel.app';

  /// (No bot username here anymore — the server reads it straight from
  /// the bot token and returns it in the bind-telegram response, so it
  /// can never drift out of sync with whichever bot is actually configured.)

  /// ═══════════════════════════════════════════════════════
  ///  DO NOT EDIT — Permanent links to owner & channel
  /// ═══════════════════════════════════════════════════════
  static const String ownerLink = 'https://t.me/earlxz';
  static const String channelLink = 'https://t.me/earlstore2004';

  /// ═══════════════════════════════════════════════════════
  ///  INTERNAL — Do not edit
  /// ═══════════════════════════════════════════════════════

  static const String appName = 'Earl Builder';
  static const String appTagline = 'Build APK from a project link';

  static const String aboutDescription =
      'Earl Builder lets you build an APK from a project download link. '
      'Just paste the link and the system will download and build the project '
      'automatically.\n\n'
      'Designed for developers who want a quick, hassle-free way to produce '
      'APKs without setting up a full Android build environment.';
}
