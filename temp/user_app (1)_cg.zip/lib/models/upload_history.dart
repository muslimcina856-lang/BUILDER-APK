/// Model for locally stored upload history entries.
class UploadHistory {
  final String fileName;
  final int fileSize; // bytes
  final String status; // 'success', 'failed', 'building'
  final String uniqueName;
  final String timestamp; // ISO string
  final int creditsUsed;
  final String frameworkType; // auto-detected project type, e.g. 'Flutter'

  UploadHistory({
    required this.fileName,
    required this.fileSize,
    required this.status,
    required this.uniqueName,
    required this.timestamp,
    this.creditsUsed = 1,
    this.frameworkType = '',
  });

  String get fileSizeFormatted {
    if (fileSize < 1024) return '$fileSize B';
    if (fileSize < 1024 * 1024) return '${(fileSize / 1024).toStringAsFixed(1)} KB';
    return '${(fileSize / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  String get statusLabel {
    switch (status) {
      case 'success':
        return 'Selesai';
      case 'building':
        return 'Membina...';
      case 'failed':
        return 'Gagal';
      default:
        return status;
    }
  }

  Map<String, dynamic> toJson() => {
        'fileName': fileName,
        'fileSize': fileSize,
        'status': status,
        'uniqueName': uniqueName,
        'timestamp': timestamp,
        'creditsUsed': creditsUsed,
        'frameworkType': frameworkType,
      };

  factory UploadHistory.fromJson(Map<String, dynamic> json) => UploadHistory(
        fileName: json['fileName'] as String,
        fileSize: json['fileSize'] as int,
        status: json['status'] as String,
        uniqueName: json['uniqueName'] as String? ?? '',
        timestamp: json['timestamp'] as String,
        creditsUsed: json['creditsUsed'] as int? ?? 1,
        frameworkType: json['frameworkType'] as String? ?? '',
      );
}
