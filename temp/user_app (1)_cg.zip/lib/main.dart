import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'screens/home_screen.dart';
import 'screens/language_select_screen.dart';
import 'services/language_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColors.bgBase,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  final languageService = LanguageService();
  await languageService.load();
  runApp(EarlBuilderApp(languageService: languageService));
}

class EarlBuilderApp extends StatelessWidget {
  final LanguageService languageService;
  const EarlBuilderApp({super.key, required this.languageService});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<LanguageService>.value(
      value: languageService,
      child: MaterialApp(
        title: 'Earl Builder',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        home: languageService.isSet
            ? const HomeScreen()
            : const LanguageSelectScreen(),
      ),
    );
  }
}
