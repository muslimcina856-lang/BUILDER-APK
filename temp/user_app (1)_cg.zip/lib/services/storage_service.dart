import 'dart:convert';
import 'package:android_id/android_id.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:earl_builder/models/upload_history.dart';

/// Local storage service for device ID and upload history.
class StorageService {
  static const String _deviceIdKey = 'device_id';
  static const String _historyKey = 'upload_history';

  // ─── Device ID ────────────────────────────────────────────────

  /// Get or create a persistent device ID in device_xxx format.
  static Future<String> getDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    final storedId = prefs.getString(_deviceIdKey);

    // Return existing SSAID-based device_xxx ID if already stored
    if (storedId != null && storedId.isNotEmpty && storedId.startsWith('device_')) {
      return storedId;
    }

    // Get Android SSAID — unique per device, survives app reinstall (Android 8+)
    String ssaid = '';
    try {
      ssaid = await const AndroidId().getId() ?? '';
    } catch (_) {}

    final generatedId = ssaid.isNotEmpty
        ? 'device_$ssaid'
        : 'device_${DateTime.now().millisecondsSinceEpoch}';
    await prefs.setString(_deviceIdKey, generatedId);
    return generatedId;
  }

  // ─── Upload History ──────────────────────────────────────────

  /// Load all upload history entries.
  static Future<List<UploadHistory>> loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_historyKey);
    if (raw == null) return [];

    try {
      final List<dynamic> list = json.decode(raw);
      return list.map((e) => UploadHistory.fromJson(e)).toList();
    } catch (_) {
      return [];
    }
  }

  /// Add a new entry to upload history.
  static Future<void> addHistory(UploadHistory entry) async {
    final prefs = await SharedPreferences.getInstance();
    final history = await loadHistory();
    history.insert(0, entry); // newest first
    // Keep max 100 entries
    if (history.length > 10) {
      history.removeRange(10, history.length);
    }
    await prefs.setString(
      _historyKey,
      json.encode(history.map((e) => e.toJson()).toList()),
    );
  }

  /// Clear all history.
  static Future<void> clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_historyKey);
  }
}
