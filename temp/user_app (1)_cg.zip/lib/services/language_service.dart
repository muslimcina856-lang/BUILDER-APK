import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AppLanguage { en, ms, id }

class LanguageService extends ChangeNotifier {
  static const _prefsKey = 'app_language';

  AppLanguage? _language;
  bool _loaded = false;

  AppLanguage? get language => _language;
  bool get isSet => _language != null;
  bool get isLoaded => _loaded;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString(_prefsKey);
    if (code != null) {
      _language = AppLanguage.values.firstWhere(
        (l) => l.name == code,
        orElse: () => AppLanguage.en,
      );
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> setLanguage(AppLanguage lang) async {
    _language = lang;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, lang.name);
    notifyListeners();
  }
}
