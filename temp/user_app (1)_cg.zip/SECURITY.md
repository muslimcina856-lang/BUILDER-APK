# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.5.x   | :white_check_mark: Active |
| 1.4.x   | :warning: Bug fixes only |
| < 1.4   | :x: End of life |

## Reporting a Vulnerability

If you discover a security vulnerability in Earl Builder, please report it
privately to the project owner. **Do NOT open a public GitHub issue for
security bugs.**

### Contact

- **Telegram:** [@earlxz](https://t.me/earlxz)
- **Channel:** [@earlstore2004](https://t.me/earlstore2004)

### What to Include

Please provide:
1. Vulnerability description and impact (what an attacker could do)
2. Reproduction steps (or proof-of-concept code)
3. Affected version(s)
4. Component (user app / owner app / Vercel API)
5. Any suggested mitigations you may have

### Response Targets

- Acknowledgement: within 48 hours
- Triage + fix timeline: communicated within 7 days
- Patch release for critical issues: within 14 days

## Security Measures

Earl Builder includes:

- INTERNET, ACCESS_NETWORK_STATE, POST_NOTIFICATIONS, WAKE_LOCK permissions only (no scope creep)
- HTTPS-only API endpoints (`https://your-project.vercel.app`)
- `dio` client with TLS verification enabled by default
- No third-party tracking SDKs
- Local preferences contain language and history; device ID, Telegram ID and
  submitted projects are sent only as required for app functionality
- Installation identity is read through `android_id`

## API Hardening (Vercel)

- `vercel-api/` deploys as serverless functions — no long-lived secrets
- Telegram bot token via `BOT_TOKEN` environment variable (not hardcoded)
- GitHub API token via `GITHUB_TOKEN` env var (rotate quarterly)
- Owner routes require `X-Owner-API-Key` and fail closed without `OWNER_API_KEY`
- Direct ZIP submissions are capped at 3 MB on both app and backend

## Reporting Out-of-Scope Issues

For non-security bugs (crashes, UX issues, feature requests), please open a
regular GitHub issue instead.
