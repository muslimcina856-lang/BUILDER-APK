# Flutter plugin entry points. Dependency consumer rules keep any additional
# classes that a plugin accesses through reflection.
-keep class io.flutter.plugins.GeneratedPluginRegistrant { *; }
-keep class * implements io.flutter.embedding.engine.plugins.FlutterPlugin { *; }

# just_audio (com.ryanheise.*)
-keep class com.ryanheise.** { *; }

# video_player — backed by ExoPlayer/Media3, which uses reflection for
# codec/extractor discovery. Without these, videos can fail silently in
# release builds even though debug builds work fine.
-keep class com.google.android.exoplayer2.** { *; }
-dontwarn com.google.android.exoplayer2.**
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# file_picker — not under the io.flutter.plugins namespace.
-keep class com.mr.flutter.plugin.filepicker.** { *; }

# Keep metadata used by reflection without disabling R8 for whole packages.
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes EnclosingMethod
