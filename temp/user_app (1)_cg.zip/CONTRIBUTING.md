# Contributing to Earl Builder

Thank you for your interest in contributing! This document outlines the
process for submitting changes.

## Development Setup

1. Install Flutter SDK (3.4.0+):
   ```bash
   git clone https://github.com/flutter/flutter.git --depth 1 -b stable
   export PATH="$PATH:$PWD/flutter/bin"
   flutter doctor
   ```

2. Clone this repository and run `flutter pub get`:
   ```bash
   cd user_app
   flutter pub get
   ```

3. Verify clean state:
   ```bash
   flutter analyze
   ```

Expected: `No issues found!` or only `prefer_const_constructors` INFO hints.

## Code Style

- Follow existing tokens defined in `lib/theme/app_theme.dart` (AppColors, AppSpacing, AppText, AppRadius, AppIcons)
- Use PascalCase for class names, camelCase for variables/functions
- 2-space indent, trailing commas for multi-line lists
- Run `dart format lib/` before committing

## Branching & Commits

- `main` is the stable branch — don't commit there directly
- Use feature branches: `feature/<short-name>` or `fix/<short-name>`
- Commit message format: `<scope>: <summary>` — e.g. `upload: fix chunk timeout`

## Pull Request Checklist

- [ ] `flutter analyze` returns 0 errors / 0 warnings
- [ ] No empty/incomplete files added
- [ ] All DART files pass `dart format` check
- [ ] Tested on at least one Android device
- [ ] README.md updated if public API changed
- [ ] CHANGELOG.md updated under "Unreleased" section

## Reporting Bugs

Open an issue with:
- Reproduction steps
- Expected vs actual behavior
- Device + Flutter version
- Screenshots if applicable

## License

By contributing, you agree that your contributions will be licensed under the
MIT License (see LICENSE file).
