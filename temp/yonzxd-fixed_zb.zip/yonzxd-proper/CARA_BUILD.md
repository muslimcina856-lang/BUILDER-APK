# Cara Build YONZXD Jadi APK Android

Project ini sudah disiapkan dalam bentuk **Capacitor**, yaitu pembungkus resmi yang mengubah web app (HTML/CSS/JS) jadi aplikasi Android asli.

## ⚠️ PERBEDAAN DENGAN FILE LAMA

File `yonzxd-app.zip` yang lama punya masalah:
- ❌ Berisi **Node.js/Express server** (gak bisa berjalan di Android)
- ❌ Sudah dikonfigurasi untuk **WhatsApp & Telegram Bot** (kebutuhan server)
- ❌ File-file berantakan dan tidak sesuai struktur Capacitor

**File baru ini** sudah diperbaiki untuk:
- ✅ Hanya frontend (HTML/CSS/JS) tanpa server
- ✅ Struktur Capacitor yang benar
- ✅ Siap dibuild langsung menjadi APK

---

## Yang harus disiapkan dulu di komputer kamu

1. **Node.js** (versi 18 ke atas) — unduh di https://nodejs.org
2. **Android Studio** — unduh di https://developer.android.com/studio
   (saat instalasi pertama, biarkan Android Studio mengunduh Android SDK-nya)
3. **Java JDK 17** (biasanya sudah ikut terpasang bersama Android Studio)

---

## Langkah build YONZXD APK

### 1. Persiapan folder
```
Ekstrak folder ini, lalu buka di terminal/command prompt
```

### 2. Install dependency
```bash
npm install
```

### 3. Tambahkan platform Android
```bash
npx cap add android
```
Tunggu sampai selesai. Ini akan membuat folder `android/` di project kamu.

### 4. Sinkronkan file web
```bash
npx cap sync
```
Perintah ini menyalin file `index.html` ke folder `www/` di project Android.

### 5. Buka di Android Studio
```bash
npx cap open android
```
Android Studio akan terbuka otomatis dengan project "YONZXD".

### 6. Tunggu Gradle Sync
Di pojok kanan bawah Android Studio, ada progress bar "Gradle Sync". Tunggu sampai selesai (bisa makan waktu 3-10 menit di percobaan pertama).

### 7. Build APK
Di Android Studio, klik menu:
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

### 8. Tunggu notifikasi
Tunggu sampai muncul notifikasi "APK(s) generated successfully". Klik "locate" untuk membuka folder APK.

APK biasanya ada di:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### 9. Install ke HP
Salin `app-debug.apk` ke HP Android kamu (via USB, Google Drive, atau Bluetooth), lalu install seperti biasa.

> **Catatan:** Kamu mungkin perlu mengizinkan "Install dari sumber tidak dikenal" di Pengaturan HP.

---

## Custom: Mengganti Ikon & Nama

### Mengubah Nama Aplikasi
Edit file `capacitor.config.json`:
```json
{
  "appName": "YONZXD v2"
}
```

Lalu jalankan:
```bash
npx cap sync
```

### Mengubah Ikon Aplikasi
Setelah `npx cap add android` selesai, ikon ada di:
```
android/app/src/main/res/mipmap-*/ic_launcher.png
```

Ganti file `.png` itu dengan ikon kamu (ukuran berbeda untuk berbagai resolusi):
- `mipmap-ldpi/` (36x36)
- `mipmap-mdpi/` (48x48)
- `mipmap-hdpi/` (72x72)
- `mipmap-xhdpi/` (96x96)
- `mipmap-xxhdpi/` (144x144)
- `mipmap-xxxhdpi/` (192x192)

Atau gunakan **Image Asset Studio** di Android Studio:
1. Klik kanan folder `res` → New → Image Asset
2. Pilih ikon PNG kamu
3. Klik Next/Finish

---

## Troubleshooting

### Error: "npm: command not found"
- Pastikan Node.js sudah terinstall
- Restart terminal/command prompt
- Verifikasi: `node -v` dan `npm -v`

### Error: "Android SDK not found"
- Buka Android Studio
- Tools → SDK Manager → Pasang Android SDK yang diperlukan
- Atur environment variable `ANDROID_HOME` ke lokasi Android SDK

### Error saat "npx cap add android"
- Pastikan Java JDK 17 sudah terinstall
- Atur environment variable `JAVA_HOME` ke lokasi JDK

### APK terlalu besar atau error saat build
- Di Android Studio: File → Project Structure → Modules → app → Build Types
- Pastikan Release/Debug config sudah benar
- Coba bersihkan build: Build → Clean Project, lalu Build lagi

---

## Fitur yang Tersedia di App

✅ **Auto-Scroll** - Scroll otomatis pada area tertentu
✅ **Auto-Click** - Klik otomatis yang dapat dijadwalkan
✅ **Translator** - Terjemahan teks ke berbagai bahasa
✅ **Scheduler** - Jadwalkan tugas untuk waktu tertentu
✅ **Logger** - Catat aktivitas dan error
✅ **Analytics** - Lihat statistik penggunaan
✅ **Messenger** - Kirim pesan cepat
✅ **Backup** - Sinkronkan data
✅ **Security** - Pengaturan keamanan

---

## Tips Pengembangan Lebih Lanjut

Jika kamu ingin menambah fitur:

### 1. Edit file `index.html`
Semua HTML/CSS/JS ada dalam satu file. Tinggal edit dan sinkronkan:
```bash
npx cap sync
```

### 2. Tambah plugin Capacitor
Contoh untuk Camera:
```bash
npm install @capacitor/camera
npx cap sync
```
Kemudian gunakan di JavaScript:
```javascript
import { Camera } from '@capacitor/camera';
const photo = await Camera.getPhoto({ resultType: 'uri' });
```

### 3. Rebuild APK
```bash
npx cap sync
npx cap open android
# (Build di Android Studio)
```

---

## Catatan Penting

- **Koneksi Internet**: Beberapa fitur seperti Translator memerlukan internet
- **Izin Akses**: App bisa minta izin untuk clipboard, storage, camera, dll di runtime
- **Debug vs Release**: File APK yang di-build sekarang adalah DEBUG APK (ada watermark dev). Untuk release production, gunakan "Build Bundle(s)" dan sign dengan key store.

---

**Happy Building! 🚀**

Butuh bantuan? Hubungi AYONZ Soul Founder di ayonsoulfounder@gmail.com
