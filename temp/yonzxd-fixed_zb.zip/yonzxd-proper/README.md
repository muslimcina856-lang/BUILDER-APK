# YONZXD - Multi-Tools Dashboard Application

**Status:** ✅ Fixed & Ready to Build APK

Aplikasi Android berbasis Capacitor dengan dashboard tools lengkap untuk produktivitas dan otomasi.

## 🎯 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Add Android platform
npx cap add android

# 3. Sync web files
npx cap sync

# 4. Open in Android Studio
npx cap open android

# 5. Build APK (via Android Studio menu: Build → Build APK(s))
```

Untuk detail lengkap, baca **CARA_BUILD.md**

---

## 📱 Fitur Utama

| Fitur | Deskripsi |
|-------|-----------|
| ⬆️ **Auto-Scroll** | Scroll otomatis pada konten |
| 🖱️ **Auto-Click** | Klik otomatis yang terjadwal |
| 🌐 **Translator** | Terjemahan multi-bahasa |
| ⏰ **Scheduler** | Penjadwalan tugas |
| 📝 **Logger** | Pencatatan aktivitas |
| 📊 **Analytics** | Statistik penggunaan |
| 💬 **Messenger** | Kirim pesan cepat |
| 💾 **Backup** | Sinkronisasi data |
| 🔒 **Security** | Pengaturan keamanan |

---

## 📁 Struktur Folder

```
yonzxd-proper/
├── package.json              # Dependencies & scripts
├── capacitor.config.json     # Konfigurasi Capacitor
├── index.html               # App frontend (semua dalam satu file)
├── CARA_BUILD.md            # Panduan build detail
├── README.md                # File ini
└── android/                 # Folder Android project (dibuat saat build)
```

---

## 🛠️ Requirements

- **Node.js** 18+ ([nodejs.org](https://nodejs.org))
- **Android Studio** ([developer.android.com/studio](https://developer.android.com/studio))
- **Java JDK 17** (biasanya ikut Android Studio)

---

## ⚠️ Yang Diperbaiki dari File Lama

❌ **Masalah file `yonzxd-app.zip` lama:**
- Backend Node.js/Express (tidak bisa di Android)
- Dependensi WhatsApp Bot (Baileys) & Telegram Bot
- Struktur file berantakan

✅ **File baru ini:**
- Frontend-only (tanpa server)
- Struktur Capacitor yang benar
- Siap build menjadi APK native

---

## 🚀 Build Commands

```bash
# Rebuild saat ada perubahan
npm install
npx cap sync
npx cap open android

# Manual sync tanpa buka Android Studio
npx cap sync

# Cek status
npx cap list
```

---

## 📝 Customization

### Ubah Nama App
Edit `capacitor.config.json`:
```json
{
  "appName": "Nama Baru"
}
```

### Ubah Ikon App
Ganti file di `android/app/src/main/res/mipmap-*/ic_launcher.png`

---

## 📞 Support

**Developer:** AYONZ Soul Founder  
**Email:** ayonsoulfounder@gmail.com  
**Version:** 1.0.0  
**License:** ISC

---

**Selamat membangun! 🎉**
